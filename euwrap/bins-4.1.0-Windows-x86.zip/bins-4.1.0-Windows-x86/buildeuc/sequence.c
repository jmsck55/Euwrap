// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _23reverse(object _target_4528, object _pFrom_4529, object _pTo_4530)
{
    object _uppr_4531 = NOVALUE;
    object _n_4532 = NOVALUE;
    object _lLimit_4533 = NOVALUE;
    object _t_4534 = NOVALUE;
    object _2261 = NOVALUE;
    object _2260 = NOVALUE;
    object _2259 = NOVALUE;
    object _2257 = NOVALUE;
    object _2256 = NOVALUE;
    object _2254 = NOVALUE;
    object _2252 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:549		n = length(target)*/
    if (IS_SEQUENCE(_target_4528)){
            _n_4532 = SEQ_PTR(_target_4528)->length;
    }
    else {
        _n_4532 = 1;
    }

    /** sequence.e:550		if n < 2 then*/
    if (_n_4532 >= 2)
    goto L1; // [12] 23

    /** sequence.e:551			return target*/
    DeRef(_t_4534);
    return _target_4528;
L1: 

    /** sequence.e:553		if pFrom < 1 then*/
    if (_pFrom_4529 >= 1)
    goto L2; // [25] 35

    /** sequence.e:554			pFrom = 1*/
    _pFrom_4529 = 1;
L2: 

    /** sequence.e:556		if pTo < 1 then*/
    if (_pTo_4530 >= 1)
    goto L3; // [37] 48

    /** sequence.e:557			pTo = n + pTo*/
    _pTo_4530 = _n_4532 + _pTo_4530;
L3: 

    /** sequence.e:559		if pTo < pFrom or pFrom >= n then*/
    _2252 = (_pTo_4530 < _pFrom_4529);
    if (_2252 != 0) {
        goto L4; // [54] 67
    }
    _2254 = (_pFrom_4529 >= _n_4532);
    if (_2254 == 0)
    {
        DeRef(_2254);
        _2254 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2254);
        _2254 = NOVALUE;
    }
L4: 

    /** sequence.e:560			return target*/
    DeRef(_t_4534);
    DeRef(_2252);
    _2252 = NOVALUE;
    return _target_4528;
L5: 

    /** sequence.e:562		if pTo > n then*/
    if (_pTo_4530 <= _n_4532)
    goto L6; // [76] 86

    /** sequence.e:563			pTo = n*/
    _pTo_4530 = _n_4532;
L6: 

    /** sequence.e:566		lLimit = floor((pFrom+pTo-1)/2)*/
    _2256 = _pFrom_4529 + _pTo_4530;
    if ((object)((uintptr_t)_2256 + (uintptr_t)HIGH_BITS) >= 0){
        _2256 = NewDouble((eudouble)_2256);
    }
    if (IS_ATOM_INT(_2256)) {
        _2257 = _2256 - 1;
        if ((object)((uintptr_t)_2257 +(uintptr_t) HIGH_BITS) >= 0){
            _2257 = NewDouble((eudouble)_2257);
        }
    }
    else {
        _2257 = NewDouble(DBL_PTR(_2256)->dbl - (eudouble)1);
    }
    DeRef(_2256);
    _2256 = NOVALUE;
    if (IS_ATOM_INT(_2257)) {
        _lLimit_4533 = _2257 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2257, 2);
        _lLimit_4533 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2257);
    _2257 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_4533)) {
        _1 = (object)(DBL_PTR(_lLimit_4533)->dbl);
        DeRefDS(_lLimit_4533);
        _lLimit_4533 = _1;
    }

    /** sequence.e:567		t = target*/
    Ref(_target_4528);
    DeRef(_t_4534);
    _t_4534 = _target_4528;

    /** sequence.e:568		uppr = pTo*/
    _uppr_4531 = _pTo_4530;

    /** sequence.e:569		for lowr = pFrom to lLimit do*/
    _2259 = _lLimit_4533;
    {
        object _lowr_4553;
        _lowr_4553 = _pFrom_4529;
L7: 
        if (_lowr_4553 > _2259){
            goto L8; // [119] 159
        }

        /** sequence.e:570			t[uppr] = target[lowr]*/
        _2 = (object)SEQ_PTR(_target_4528);
        _2260 = (object)*(((s1_ptr)_2)->base + _lowr_4553);
        Ref(_2260);
        _2 = (object)SEQ_PTR(_t_4534);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_4534 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _uppr_4531);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2260;
        if( _1 != _2260 ){
            DeRef(_1);
        }
        _2260 = NOVALUE;

        /** sequence.e:571			t[lowr] = target[uppr]*/
        _2 = (object)SEQ_PTR(_target_4528);
        _2261 = (object)*(((s1_ptr)_2)->base + _uppr_4531);
        Ref(_2261);
        _2 = (object)SEQ_PTR(_t_4534);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_4534 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lowr_4553);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2261;
        if( _1 != _2261 ){
            DeRef(_1);
        }
        _2261 = NOVALUE;

        /** sequence.e:572			uppr -= 1*/
        _uppr_4531 = _uppr_4531 - 1;

        /** sequence.e:573		end for*/
        _lowr_4553 = _lowr_4553 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** sequence.e:574		return t*/
    DeRef(_target_4528);
    DeRef(_2252);
    _2252 = NOVALUE;
    return _t_4534;
    ;
}


object _23pad_tail(object _target_4629, object _size_4630, object _ch_4631)
{
    object _2298 = NOVALUE;
    object _2297 = NOVALUE;
    object _2296 = NOVALUE;
    object _2295 = NOVALUE;
    object _2293 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1022		if size <= length(target) then*/
    if (IS_SEQUENCE(_target_4629)){
            _2293 = SEQ_PTR(_target_4629)->length;
    }
    else {
        _2293 = 1;
    }
    if (_size_4630 > _2293)
    goto L1; // [8] 19

    /** sequence.e:1023			return target*/
    return _target_4629;
L1: 

    /** sequence.e:1026		return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_4629)){
            _2295 = SEQ_PTR(_target_4629)->length;
    }
    else {
        _2295 = 1;
    }
    _2296 = _size_4630 - _2295;
    _2295 = NOVALUE;
    _2297 = Repeat(_ch_4631, _2296);
    _2296 = NOVALUE;
    if (IS_SEQUENCE(_target_4629) && IS_ATOM(_2297)) {
    }
    else if (IS_ATOM(_target_4629) && IS_SEQUENCE(_2297)) {
        Ref(_target_4629);
        Prepend(&_2298, _2297, _target_4629);
    }
    else {
        Concat((object_ptr)&_2298, _target_4629, _2297);
    }
    DeRefDS(_2297);
    _2297 = NOVALUE;
    DeRef(_target_4629);
    return _2298;
    ;
}


object _23filter(object _source_4883, object _rid_4884, object _userdata_4885, object _rangetype_4886)
{
    object _dest_4887 = NOVALUE;
    object _idx_4888 = NOVALUE;
    object _2612 = NOVALUE;
    object _2611 = NOVALUE;
    object _2609 = NOVALUE;
    object _2608 = NOVALUE;
    object _2607 = NOVALUE;
    object _2606 = NOVALUE;
    object _2605 = NOVALUE;
    object _2602 = NOVALUE;
    object _2601 = NOVALUE;
    object _2600 = NOVALUE;
    object _2599 = NOVALUE;
    object _2596 = NOVALUE;
    object _2595 = NOVALUE;
    object _2594 = NOVALUE;
    object _2593 = NOVALUE;
    object _2592 = NOVALUE;
    object _2589 = NOVALUE;
    object _2588 = NOVALUE;
    object _2587 = NOVALUE;
    object _2586 = NOVALUE;
    object _2583 = NOVALUE;
    object _2582 = NOVALUE;
    object _2581 = NOVALUE;
    object _2580 = NOVALUE;
    object _2579 = NOVALUE;
    object _2576 = NOVALUE;
    object _2575 = NOVALUE;
    object _2574 = NOVALUE;
    object _2573 = NOVALUE;
    object _2570 = NOVALUE;
    object _2569 = NOVALUE;
    object _2568 = NOVALUE;
    object _2567 = NOVALUE;
    object _2566 = NOVALUE;
    object _2563 = NOVALUE;
    object _2562 = NOVALUE;
    object _2561 = NOVALUE;
    object _2560 = NOVALUE;
    object _2557 = NOVALUE;
    object _2556 = NOVALUE;
    object _2555 = NOVALUE;
    object _2554 = NOVALUE;
    object _2553 = NOVALUE;
    object _2550 = NOVALUE;
    object _2549 = NOVALUE;
    object _2548 = NOVALUE;
    object _2544 = NOVALUE;
    object _2541 = NOVALUE;
    object _2540 = NOVALUE;
    object _2539 = NOVALUE;
    object _2537 = NOVALUE;
    object _2536 = NOVALUE;
    object _2535 = NOVALUE;
    object _2534 = NOVALUE;
    object _2533 = NOVALUE;
    object _2530 = NOVALUE;
    object _2529 = NOVALUE;
    object _2528 = NOVALUE;
    object _2526 = NOVALUE;
    object _2525 = NOVALUE;
    object _2524 = NOVALUE;
    object _2523 = NOVALUE;
    object _2522 = NOVALUE;
    object _2519 = NOVALUE;
    object _2518 = NOVALUE;
    object _2517 = NOVALUE;
    object _2515 = NOVALUE;
    object _2514 = NOVALUE;
    object _2513 = NOVALUE;
    object _2512 = NOVALUE;
    object _2511 = NOVALUE;
    object _2508 = NOVALUE;
    object _2507 = NOVALUE;
    object _2506 = NOVALUE;
    object _2504 = NOVALUE;
    object _2503 = NOVALUE;
    object _2502 = NOVALUE;
    object _2501 = NOVALUE;
    object _2500 = NOVALUE;
    object _2498 = NOVALUE;
    object _2497 = NOVALUE;
    object _2496 = NOVALUE;
    object _2492 = NOVALUE;
    object _2489 = NOVALUE;
    object _2488 = NOVALUE;
    object _2487 = NOVALUE;
    object _2484 = NOVALUE;
    object _2481 = NOVALUE;
    object _2480 = NOVALUE;
    object _2479 = NOVALUE;
    object _2476 = NOVALUE;
    object _2473 = NOVALUE;
    object _2472 = NOVALUE;
    object _2471 = NOVALUE;
    object _2468 = NOVALUE;
    object _2465 = NOVALUE;
    object _2464 = NOVALUE;
    object _2463 = NOVALUE;
    object _2459 = NOVALUE;
    object _2456 = NOVALUE;
    object _2455 = NOVALUE;
    object _2454 = NOVALUE;
    object _2451 = NOVALUE;
    object _2448 = NOVALUE;
    object _2447 = NOVALUE;
    object _2446 = NOVALUE;
    object _2440 = NOVALUE;
    object _2438 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1731		if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_4883)){
            _2438 = SEQ_PTR(_source_4883)->length;
    }
    else {
        _2438 = 1;
    }
    if (_2438 != 0)
    goto L1; // [8] 19

    /** sequence.e:1732			return source*/
    DeRefDS(_userdata_4885);
    DeRefDS(_rangetype_4886);
    DeRef(_dest_4887);
    return _source_4883;
L1: 

    /** sequence.e:1734		dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_4883)){
            _2440 = SEQ_PTR(_source_4883)->length;
    }
    else {
        _2440 = 1;
    }
    DeRef(_dest_4887);
    _dest_4887 = Repeat(0, _2440);
    _2440 = NOVALUE;

    /** sequence.e:1735		idx = 0*/
    _idx_4888 = 0;

    /** sequence.e:1736		switch rid do*/
    _1 = find(_rid_4884, _2442);
    switch ( _1 ){ 

        /** sequence.e:1737			case "<", "lt" then*/
        case 1:
        case 2:

        /** sequence.e:1738				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2446 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2446 = 1;
        }
        {
            object _a_4900;
            _a_4900 = 1;
L2: 
            if (_a_4900 > _2446){
                goto L3; // [51] 96
            }

            /** sequence.e:1739					if compare(source[a], userdata) < 0 then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2447 = (object)*(((s1_ptr)_2)->base + _a_4900);
            if (IS_ATOM_INT(_2447) && IS_ATOM_INT(_userdata_4885)){
                _2448 = (_2447 < _userdata_4885) ? -1 : (_2447 > _userdata_4885);
            }
            else{
                _2448 = compare(_2447, _userdata_4885);
            }
            _2447 = NOVALUE;
            if (_2448 >= 0)
            goto L4; // [68] 89

            /** sequence.e:1740						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1741						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2451 = (object)*(((s1_ptr)_2)->base + _a_4900);
            Ref(_2451);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2451;
            if( _1 != _2451 ){
                DeRef(_1);
            }
            _2451 = NOVALUE;
L4: 

            /** sequence.e:1743				end for*/
            _a_4900 = _a_4900 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** sequence.e:1745			case "<=", "le" then*/
        case 3:
        case 4:

        /** sequence.e:1746				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2454 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2454 = 1;
        }
        {
            object _a_4912;
            _a_4912 = 1;
L6: 
            if (_a_4912 > _2454){
                goto L7; // [109] 154
            }

            /** sequence.e:1747					if compare(source[a], userdata) <= 0 then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2455 = (object)*(((s1_ptr)_2)->base + _a_4912);
            if (IS_ATOM_INT(_2455) && IS_ATOM_INT(_userdata_4885)){
                _2456 = (_2455 < _userdata_4885) ? -1 : (_2455 > _userdata_4885);
            }
            else{
                _2456 = compare(_2455, _userdata_4885);
            }
            _2455 = NOVALUE;
            if (_2456 > 0)
            goto L8; // [126] 147

            /** sequence.e:1748						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1749						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2459 = (object)*(((s1_ptr)_2)->base + _a_4912);
            Ref(_2459);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2459;
            if( _1 != _2459 ){
                DeRef(_1);
            }
            _2459 = NOVALUE;
L8: 

            /** sequence.e:1751				end for*/
            _a_4912 = _a_4912 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** sequence.e:1753			case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** sequence.e:1754				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2463 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2463 = 1;
        }
        {
            object _a_4925;
            _a_4925 = 1;
L9: 
            if (_a_4925 > _2463){
                goto LA; // [169] 214
            }

            /** sequence.e:1755					if compare(source[a], userdata) = 0 then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2464 = (object)*(((s1_ptr)_2)->base + _a_4925);
            if (IS_ATOM_INT(_2464) && IS_ATOM_INT(_userdata_4885)){
                _2465 = (_2464 < _userdata_4885) ? -1 : (_2464 > _userdata_4885);
            }
            else{
                _2465 = compare(_2464, _userdata_4885);
            }
            _2464 = NOVALUE;
            if (_2465 != 0)
            goto LB; // [186] 207

            /** sequence.e:1756						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1757						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2468 = (object)*(((s1_ptr)_2)->base + _a_4925);
            Ref(_2468);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2468;
            if( _1 != _2468 ){
                DeRef(_1);
            }
            _2468 = NOVALUE;
LB: 

            /** sequence.e:1759				end for*/
            _a_4925 = _a_4925 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** sequence.e:1761			case "!=", "ne" then*/
        case 8:
        case 9:

        /** sequence.e:1762				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2471 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2471 = 1;
        }
        {
            object _a_4937;
            _a_4937 = 1;
LC: 
            if (_a_4937 > _2471){
                goto LD; // [227] 272
            }

            /** sequence.e:1763					if compare(source[a], userdata) != 0 then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2472 = (object)*(((s1_ptr)_2)->base + _a_4937);
            if (IS_ATOM_INT(_2472) && IS_ATOM_INT(_userdata_4885)){
                _2473 = (_2472 < _userdata_4885) ? -1 : (_2472 > _userdata_4885);
            }
            else{
                _2473 = compare(_2472, _userdata_4885);
            }
            _2472 = NOVALUE;
            if (_2473 == 0)
            goto LE; // [244] 265

            /** sequence.e:1764						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1765						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2476 = (object)*(((s1_ptr)_2)->base + _a_4937);
            Ref(_2476);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2476;
            if( _1 != _2476 ){
                DeRef(_1);
            }
            _2476 = NOVALUE;
LE: 

            /** sequence.e:1767				end for*/
            _a_4937 = _a_4937 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** sequence.e:1769			case ">", "gt" then*/
        case 10:
        case 11:

        /** sequence.e:1770				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2479 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2479 = 1;
        }
        {
            object _a_4949;
            _a_4949 = 1;
LF: 
            if (_a_4949 > _2479){
                goto L10; // [285] 330
            }

            /** sequence.e:1771					if compare(source[a], userdata) > 0 then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2480 = (object)*(((s1_ptr)_2)->base + _a_4949);
            if (IS_ATOM_INT(_2480) && IS_ATOM_INT(_userdata_4885)){
                _2481 = (_2480 < _userdata_4885) ? -1 : (_2480 > _userdata_4885);
            }
            else{
                _2481 = compare(_2480, _userdata_4885);
            }
            _2480 = NOVALUE;
            if (_2481 <= 0)
            goto L11; // [302] 323

            /** sequence.e:1772						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1773						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2484 = (object)*(((s1_ptr)_2)->base + _a_4949);
            Ref(_2484);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2484;
            if( _1 != _2484 ){
                DeRef(_1);
            }
            _2484 = NOVALUE;
L11: 

            /** sequence.e:1775				end for*/
            _a_4949 = _a_4949 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** sequence.e:1777			case ">=", "ge" then*/
        case 12:
        case 13:

        /** sequence.e:1778				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2487 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2487 = 1;
        }
        {
            object _a_4961;
            _a_4961 = 1;
L12: 
            if (_a_4961 > _2487){
                goto L13; // [343] 388
            }

            /** sequence.e:1779					if compare(source[a], userdata) >= 0 then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2488 = (object)*(((s1_ptr)_2)->base + _a_4961);
            if (IS_ATOM_INT(_2488) && IS_ATOM_INT(_userdata_4885)){
                _2489 = (_2488 < _userdata_4885) ? -1 : (_2488 > _userdata_4885);
            }
            else{
                _2489 = compare(_2488, _userdata_4885);
            }
            _2488 = NOVALUE;
            if (_2489 < 0)
            goto L14; // [360] 381

            /** sequence.e:1780						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1781						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2492 = (object)*(((s1_ptr)_2)->base + _a_4961);
            Ref(_2492);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2492;
            if( _1 != _2492 ){
                DeRef(_1);
            }
            _2492 = NOVALUE;
L14: 

            /** sequence.e:1783				end for*/
            _a_4961 = _a_4961 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** sequence.e:1785			case "in" then*/
        case 14:

        /** sequence.e:1786				switch rangetype do*/
        _1 = find(_rangetype_4886, _2494);
        switch ( _1 ){ 

            /** sequence.e:1787					case "" then*/
            case 1:

            /** sequence.e:1788						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2496 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2496 = 1;
            }
            {
                object _a_4975;
                _a_4975 = 1;
L15: 
                if (_a_4975 > _2496){
                    goto L16; // [410] 455
                }

                /** sequence.e:1789							if find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2497 = (object)*(((s1_ptr)_2)->base + _a_4975);
                _2498 = find_from(_2497, _userdata_4885, 1);
                _2497 = NOVALUE;
                if (_2498 == 0)
                {
                    _2498 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _2498 = NOVALUE;
                }

                /** sequence.e:1790								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1791								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2500 = (object)*(((s1_ptr)_2)->base + _a_4975);
                Ref(_2500);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2500;
                if( _1 != _2500 ){
                    DeRef(_1);
                }
                _2500 = NOVALUE;
L17: 

                /** sequence.e:1793						end for*/
                _a_4975 = _a_4975 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** sequence.e:1795					case "[]" then*/
            case 2:

            /** sequence.e:1796						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2501 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2501 = 1;
            }
            {
                object _a_4984;
                _a_4984 = 1;
L18: 
                if (_a_4984 > _2501){
                    goto L19; // [466] 534
                }

                /** sequence.e:1797							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2502 = (object)*(((s1_ptr)_2)->base + _a_4984);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2503 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2502) && IS_ATOM_INT(_2503)){
                    _2504 = (_2502 < _2503) ? -1 : (_2502 > _2503);
                }
                else{
                    _2504 = compare(_2502, _2503);
                }
                _2502 = NOVALUE;
                _2503 = NOVALUE;
                if (_2504 < 0)
                goto L1A; // [487] 527

                /** sequence.e:1798								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2506 = (object)*(((s1_ptr)_2)->base + _a_4984);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2507 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2506) && IS_ATOM_INT(_2507)){
                    _2508 = (_2506 < _2507) ? -1 : (_2506 > _2507);
                }
                else{
                    _2508 = compare(_2506, _2507);
                }
                _2506 = NOVALUE;
                _2507 = NOVALUE;
                if (_2508 > 0)
                goto L1B; // [505] 526

                /** sequence.e:1799									idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1800									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2511 = (object)*(((s1_ptr)_2)->base + _a_4984);
                Ref(_2511);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2511;
                if( _1 != _2511 ){
                    DeRef(_1);
                }
                _2511 = NOVALUE;
L1B: 
L1A: 

                /** sequence.e:1803						end for*/
                _a_4984 = _a_4984 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** sequence.e:1805					case "[)" then*/
            case 3:

            /** sequence.e:1806						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2512 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2512 = 1;
            }
            {
                object _a_5000;
                _a_5000 = 1;
L1C: 
                if (_a_5000 > _2512){
                    goto L1D; // [545] 613
                }

                /** sequence.e:1807							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2513 = (object)*(((s1_ptr)_2)->base + _a_5000);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2514 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2513) && IS_ATOM_INT(_2514)){
                    _2515 = (_2513 < _2514) ? -1 : (_2513 > _2514);
                }
                else{
                    _2515 = compare(_2513, _2514);
                }
                _2513 = NOVALUE;
                _2514 = NOVALUE;
                if (_2515 < 0)
                goto L1E; // [566] 606

                /** sequence.e:1808								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2517 = (object)*(((s1_ptr)_2)->base + _a_5000);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2518 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2517) && IS_ATOM_INT(_2518)){
                    _2519 = (_2517 < _2518) ? -1 : (_2517 > _2518);
                }
                else{
                    _2519 = compare(_2517, _2518);
                }
                _2517 = NOVALUE;
                _2518 = NOVALUE;
                if (_2519 >= 0)
                goto L1F; // [584] 605

                /** sequence.e:1809									idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1810									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2522 = (object)*(((s1_ptr)_2)->base + _a_5000);
                Ref(_2522);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2522;
                if( _1 != _2522 ){
                    DeRef(_1);
                }
                _2522 = NOVALUE;
L1F: 
L1E: 

                /** sequence.e:1813						end for*/
                _a_5000 = _a_5000 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** sequence.e:1814					case "(]" then*/
            case 4:

            /** sequence.e:1815						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2523 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2523 = 1;
            }
            {
                object _a_5016;
                _a_5016 = 1;
L20: 
                if (_a_5016 > _2523){
                    goto L21; // [624] 692
                }

                /** sequence.e:1816							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2524 = (object)*(((s1_ptr)_2)->base + _a_5016);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2525 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2524) && IS_ATOM_INT(_2525)){
                    _2526 = (_2524 < _2525) ? -1 : (_2524 > _2525);
                }
                else{
                    _2526 = compare(_2524, _2525);
                }
                _2524 = NOVALUE;
                _2525 = NOVALUE;
                if (_2526 <= 0)
                goto L22; // [645] 685

                /** sequence.e:1817								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2528 = (object)*(((s1_ptr)_2)->base + _a_5016);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2529 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2528) && IS_ATOM_INT(_2529)){
                    _2530 = (_2528 < _2529) ? -1 : (_2528 > _2529);
                }
                else{
                    _2530 = compare(_2528, _2529);
                }
                _2528 = NOVALUE;
                _2529 = NOVALUE;
                if (_2530 > 0)
                goto L23; // [663] 684

                /** sequence.e:1818									idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1819									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2533 = (object)*(((s1_ptr)_2)->base + _a_5016);
                Ref(_2533);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2533;
                if( _1 != _2533 ){
                    DeRef(_1);
                }
                _2533 = NOVALUE;
L23: 
L22: 

                /** sequence.e:1822						end for*/
                _a_5016 = _a_5016 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** sequence.e:1823					case "()" then*/
            case 5:

            /** sequence.e:1824						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2534 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2534 = 1;
            }
            {
                object _a_5032;
                _a_5032 = 1;
L24: 
                if (_a_5032 > _2534){
                    goto L25; // [703] 771
                }

                /** sequence.e:1825							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2535 = (object)*(((s1_ptr)_2)->base + _a_5032);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2536 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2535) && IS_ATOM_INT(_2536)){
                    _2537 = (_2535 < _2536) ? -1 : (_2535 > _2536);
                }
                else{
                    _2537 = compare(_2535, _2536);
                }
                _2535 = NOVALUE;
                _2536 = NOVALUE;
                if (_2537 <= 0)
                goto L26; // [724] 764

                /** sequence.e:1826								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2539 = (object)*(((s1_ptr)_2)->base + _a_5032);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2540 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2539) && IS_ATOM_INT(_2540)){
                    _2541 = (_2539 < _2540) ? -1 : (_2539 > _2540);
                }
                else{
                    _2541 = compare(_2539, _2540);
                }
                _2539 = NOVALUE;
                _2540 = NOVALUE;
                if (_2541 >= 0)
                goto L27; // [742] 763

                /** sequence.e:1827									idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1828									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2544 = (object)*(((s1_ptr)_2)->base + _a_5032);
                Ref(_2544);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2544;
                if( _1 != _2544 ){
                    DeRef(_1);
                }
                _2544 = NOVALUE;
L27: 
L26: 

                /** sequence.e:1831						end for*/
                _a_5032 = _a_5032 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** sequence.e:1833					case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** sequence.e:1838			case "out" then*/
        case 15:

        /** sequence.e:1839				switch rangetype do*/
        _1 = find(_rangetype_4886, _2546);
        switch ( _1 ){ 

            /** sequence.e:1840					case "" then*/
            case 1:

            /** sequence.e:1841						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2548 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2548 = 1;
            }
            {
                object _a_5053;
                _a_5053 = 1;
L28: 
                if (_a_5053 > _2548){
                    goto L29; // [800] 845
                }

                /** sequence.e:1842							if not find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2549 = (object)*(((s1_ptr)_2)->base + _a_5053);
                _2550 = find_from(_2549, _userdata_4885, 1);
                _2549 = NOVALUE;
                if (_2550 != 0)
                goto L2A; // [818] 838
                _2550 = NOVALUE;

                /** sequence.e:1843								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1844								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2553 = (object)*(((s1_ptr)_2)->base + _a_5053);
                Ref(_2553);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2553;
                if( _1 != _2553 ){
                    DeRef(_1);
                }
                _2553 = NOVALUE;
L2A: 

                /** sequence.e:1846						end for*/
                _a_5053 = _a_5053 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** sequence.e:1848					case "[]" then*/
            case 2:

            /** sequence.e:1849						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2554 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2554 = 1;
            }
            {
                object _a_5063;
                _a_5063 = 1;
L2B: 
                if (_a_5063 > _2554){
                    goto L2C; // [856] 943
                }

                /** sequence.e:1850							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2555 = (object)*(((s1_ptr)_2)->base + _a_5063);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2556 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2555) && IS_ATOM_INT(_2556)){
                    _2557 = (_2555 < _2556) ? -1 : (_2555 > _2556);
                }
                else{
                    _2557 = compare(_2555, _2556);
                }
                _2555 = NOVALUE;
                _2556 = NOVALUE;
                if (_2557 >= 0)
                goto L2D; // [877] 900

                /** sequence.e:1851								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1852								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2560 = (object)*(((s1_ptr)_2)->base + _a_5063);
                Ref(_2560);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2560;
                if( _1 != _2560 ){
                    DeRef(_1);
                }
                _2560 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** sequence.e:1853							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2561 = (object)*(((s1_ptr)_2)->base + _a_5063);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2562 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2561) && IS_ATOM_INT(_2562)){
                    _2563 = (_2561 < _2562) ? -1 : (_2561 > _2562);
                }
                else{
                    _2563 = compare(_2561, _2562);
                }
                _2561 = NOVALUE;
                _2562 = NOVALUE;
                if (_2563 <= 0)
                goto L2F; // [914] 935

                /** sequence.e:1854								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1855								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2566 = (object)*(((s1_ptr)_2)->base + _a_5063);
                Ref(_2566);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2566;
                if( _1 != _2566 ){
                    DeRef(_1);
                }
                _2566 = NOVALUE;
L2F: 
L2E: 

                /** sequence.e:1857						end for*/
                _a_5063 = _a_5063 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** sequence.e:1859					case "[)" then*/
            case 3:

            /** sequence.e:1860						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2567 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2567 = 1;
            }
            {
                object _a_5081;
                _a_5081 = 1;
L30: 
                if (_a_5081 > _2567){
                    goto L31; // [954] 1041
                }

                /** sequence.e:1861							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2568 = (object)*(((s1_ptr)_2)->base + _a_5081);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2569 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2568) && IS_ATOM_INT(_2569)){
                    _2570 = (_2568 < _2569) ? -1 : (_2568 > _2569);
                }
                else{
                    _2570 = compare(_2568, _2569);
                }
                _2568 = NOVALUE;
                _2569 = NOVALUE;
                if (_2570 >= 0)
                goto L32; // [975] 998

                /** sequence.e:1862								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1863								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2573 = (object)*(((s1_ptr)_2)->base + _a_5081);
                Ref(_2573);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2573;
                if( _1 != _2573 ){
                    DeRef(_1);
                }
                _2573 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** sequence.e:1864							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2574 = (object)*(((s1_ptr)_2)->base + _a_5081);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2575 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2574) && IS_ATOM_INT(_2575)){
                    _2576 = (_2574 < _2575) ? -1 : (_2574 > _2575);
                }
                else{
                    _2576 = compare(_2574, _2575);
                }
                _2574 = NOVALUE;
                _2575 = NOVALUE;
                if (_2576 < 0)
                goto L34; // [1012] 1033

                /** sequence.e:1865								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1866								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2579 = (object)*(((s1_ptr)_2)->base + _a_5081);
                Ref(_2579);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2579;
                if( _1 != _2579 ){
                    DeRef(_1);
                }
                _2579 = NOVALUE;
L34: 
L33: 

                /** sequence.e:1868						end for*/
                _a_5081 = _a_5081 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** sequence.e:1869					case "(]" then*/
            case 4:

            /** sequence.e:1870						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2580 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2580 = 1;
            }
            {
                object _a_5099;
                _a_5099 = 1;
L35: 
                if (_a_5099 > _2580){
                    goto L36; // [1052] 1139
                }

                /** sequence.e:1871							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2581 = (object)*(((s1_ptr)_2)->base + _a_5099);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2582 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2581) && IS_ATOM_INT(_2582)){
                    _2583 = (_2581 < _2582) ? -1 : (_2581 > _2582);
                }
                else{
                    _2583 = compare(_2581, _2582);
                }
                _2581 = NOVALUE;
                _2582 = NOVALUE;
                if (_2583 > 0)
                goto L37; // [1073] 1096

                /** sequence.e:1872								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1873								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2586 = (object)*(((s1_ptr)_2)->base + _a_5099);
                Ref(_2586);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2586;
                if( _1 != _2586 ){
                    DeRef(_1);
                }
                _2586 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** sequence.e:1874							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2587 = (object)*(((s1_ptr)_2)->base + _a_5099);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2588 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2587) && IS_ATOM_INT(_2588)){
                    _2589 = (_2587 < _2588) ? -1 : (_2587 > _2588);
                }
                else{
                    _2589 = compare(_2587, _2588);
                }
                _2587 = NOVALUE;
                _2588 = NOVALUE;
                if (_2589 <= 0)
                goto L39; // [1110] 1131

                /** sequence.e:1875								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1876								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2592 = (object)*(((s1_ptr)_2)->base + _a_5099);
                Ref(_2592);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2592;
                if( _1 != _2592 ){
                    DeRef(_1);
                }
                _2592 = NOVALUE;
L39: 
L38: 

                /** sequence.e:1878						end for*/
                _a_5099 = _a_5099 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** sequence.e:1879					case "()" then*/
            case 5:

            /** sequence.e:1880						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4883)){
                    _2593 = SEQ_PTR(_source_4883)->length;
            }
            else {
                _2593 = 1;
            }
            {
                object _a_5117;
                _a_5117 = 1;
L3A: 
                if (_a_5117 > _2593){
                    goto L3B; // [1150] 1237
                }

                /** sequence.e:1881							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2594 = (object)*(((s1_ptr)_2)->base + _a_5117);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2595 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2594) && IS_ATOM_INT(_2595)){
                    _2596 = (_2594 < _2595) ? -1 : (_2594 > _2595);
                }
                else{
                    _2596 = compare(_2594, _2595);
                }
                _2594 = NOVALUE;
                _2595 = NOVALUE;
                if (_2596 > 0)
                goto L3C; // [1171] 1194

                /** sequence.e:1882								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1883								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2599 = (object)*(((s1_ptr)_2)->base + _a_5117);
                Ref(_2599);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2599;
                if( _1 != _2599 ){
                    DeRef(_1);
                }
                _2599 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** sequence.e:1884							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2600 = (object)*(((s1_ptr)_2)->base + _a_5117);
                _2 = (object)SEQ_PTR(_userdata_4885);
                _2601 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2600) && IS_ATOM_INT(_2601)){
                    _2602 = (_2600 < _2601) ? -1 : (_2600 > _2601);
                }
                else{
                    _2602 = compare(_2600, _2601);
                }
                _2600 = NOVALUE;
                _2601 = NOVALUE;
                if (_2602 < 0)
                goto L3E; // [1208] 1229

                /** sequence.e:1885								idx += 1*/
                _idx_4888 = _idx_4888 + 1;

                /** sequence.e:1886								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_4883);
                _2605 = (object)*(((s1_ptr)_2)->base + _a_5117);
                Ref(_2605);
                _2 = (object)SEQ_PTR(_dest_4887);
                _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _2605;
                if( _1 != _2605 ){
                    DeRef(_1);
                }
                _2605 = NOVALUE;
L3E: 
L3D: 

                /** sequence.e:1888						end for*/
                _a_5117 = _a_5117 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** sequence.e:1889					case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** sequence.e:1894			case else*/
        case 0:

        /** sequence.e:1895				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4883)){
                _2606 = SEQ_PTR(_source_4883)->length;
        }
        else {
            _2606 = 1;
        }
        {
            object _a_5136;
            _a_5136 = 1;
L3F: 
            if (_a_5136 > _2606){
                goto L40; // [1255] 1303
            }

            /** sequence.e:1896					if call_func(rid, {source[a], userdata}) then*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2607 = (object)*(((s1_ptr)_2)->base + _a_5136);
            Ref(_userdata_4885);
            Ref(_2607);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _2607;
            ((intptr_t *)_2)[2] = _userdata_4885;
            _2608 = MAKE_SEQ(_1);
            _2607 = NOVALUE;
            _1 = (object)SEQ_PTR(_2608);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_rid_4884].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            _1 = (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1), 
                                *( ((intptr_t *)_2) + 2)
                                 );
            DeRef(_2609);
            _2609 = _1;
            DeRefDS(_2608);
            _2608 = NOVALUE;
            if (_2609 == 0) {
                DeRef(_2609);
                _2609 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_2609) && DBL_PTR(_2609)->dbl == 0.0){
                    DeRef(_2609);
                    _2609 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_2609);
                _2609 = NOVALUE;
            }
            DeRef(_2609);
            _2609 = NOVALUE;

            /** sequence.e:1897						idx += 1*/
            _idx_4888 = _idx_4888 + 1;

            /** sequence.e:1898						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_4883);
            _2611 = (object)*(((s1_ptr)_2)->base + _a_5136);
            Ref(_2611);
            _2 = (object)SEQ_PTR(_dest_4887);
            _2 = (object)(((s1_ptr)_2)->base + _idx_4888);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _2611;
            if( _1 != _2611 ){
                DeRef(_1);
            }
            _2611 = NOVALUE;
L41: 

            /** sequence.e:1900				end for*/
            _a_5136 = _a_5136 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** sequence.e:1902		return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_2612;
    RHS_Slice(_dest_4887, 1, _idx_4888);
    DeRefDS(_source_4883);
    DeRef(_userdata_4885);
    DeRef(_rangetype_4886);
    DeRefDS(_dest_4887);
    return _2612;
    ;
}


object _23filter_alpha(object _elem_5148, object _ud_5149)
{
    object _2613 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1907		return t_alpha(elem)*/
    Ref(_elem_5148);
    _2613 = _13t_alpha(_elem_5148);
    DeRef(_elem_5148);
    return _2613;
    ;
}


object _23split(object _st_5193, object _delim_5194, object _no_empty_5195, object _limit_5196)
{
    object _ret_5197 = NOVALUE;
    object _start_5198 = NOVALUE;
    object _pos_5199 = NOVALUE;
    object _k_5251 = NOVALUE;
    object _2681 = NOVALUE;
    object _2679 = NOVALUE;
    object _2678 = NOVALUE;
    object _2674 = NOVALUE;
    object _2673 = NOVALUE;
    object _2672 = NOVALUE;
    object _2669 = NOVALUE;
    object _2668 = NOVALUE;
    object _2663 = NOVALUE;
    object _2662 = NOVALUE;
    object _2658 = NOVALUE;
    object _2654 = NOVALUE;
    object _2652 = NOVALUE;
    object _2651 = NOVALUE;
    object _2647 = NOVALUE;
    object _2645 = NOVALUE;
    object _2644 = NOVALUE;
    object _2643 = NOVALUE;
    object _2642 = NOVALUE;
    object _2639 = NOVALUE;
    object _2638 = NOVALUE;
    object _2637 = NOVALUE;
    object _2636 = NOVALUE;
    object _2635 = NOVALUE;
    object _2633 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2088		sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_5197);
    _ret_5197 = _5;

    /** sequence.e:2092		if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_5193)){
            _2633 = SEQ_PTR(_st_5193)->length;
    }
    else {
        _2633 = 1;
    }
    if (_2633 != 0)
    goto L1; // [19] 30

    /** sequence.e:2093			return ret*/
    DeRefDS(_st_5193);
    DeRefi(_delim_5194);
    return _ret_5197;
L1: 

    /** sequence.e:2097		if sequence(delim) then*/
    _2635 = IS_SEQUENCE(_delim_5194);
    if (_2635 == 0)
    {
        _2635 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _2635 = NOVALUE;
    }

    /** sequence.e:2099			if equal(delim, "") then*/
    if (_delim_5194 == _5)
    _2636 = 1;
    else if (IS_ATOM_INT(_delim_5194) && IS_ATOM_INT(_5))
    _2636 = 0;
    else
    _2636 = (compare(_delim_5194, _5) == 0);
    if (_2636 == 0)
    {
        _2636 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _2636 = NOVALUE;
    }

    /** sequence.e:2100				for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_5193)){
            _2637 = SEQ_PTR(_st_5193)->length;
    }
    else {
        _2637 = 1;
    }
    {
        object _i_5208;
        _i_5208 = 1;
L4: 
        if (_i_5208 > _2637){
            goto L5; // [52] 120
        }

        /** sequence.e:2101					st[i] = {st[i]}*/
        _2 = (object)SEQ_PTR(_st_5193);
        _2638 = (object)*(((s1_ptr)_2)->base + _i_5208);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_2638);
        ((intptr_t*)_2)[1] = _2638;
        _2639 = MAKE_SEQ(_1);
        _2638 = NOVALUE;
        _2 = (object)SEQ_PTR(_st_5193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _st_5193 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_5208);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2639;
        if( _1 != _2639 ){
            DeRef(_1);
        }
        _2639 = NOVALUE;

        /** sequence.e:2102					limit -= 1*/
        _limit_5196 = _limit_5196 - 1;

        /** sequence.e:2103					if limit = 0 then*/
        if (_limit_5196 != 0)
        goto L6; // [81] 113

        /** sequence.e:2104						st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_2642;
        RHS_Slice(_st_5193, 1, _i_5208);
        _2643 = _i_5208 + 1;
        if (IS_SEQUENCE(_st_5193)){
                _2644 = SEQ_PTR(_st_5193)->length;
        }
        else {
            _2644 = 1;
        }
        rhs_slice_target = (object_ptr)&_2645;
        RHS_Slice(_st_5193, _2643, _2644);
        RefDS(_2645);
        Append(&_st_5193, _2642, _2645);
        DeRefDS(_2642);
        _2642 = NOVALUE;
        DeRefDS(_2645);
        _2645 = NOVALUE;

        /** sequence.e:2105						exit*/
        goto L5; // [110] 120
L6: 

        /** sequence.e:2107				end for*/
        _i_5208 = _i_5208 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** sequence.e:2109				return st*/
    DeRefi(_delim_5194);
    DeRef(_ret_5197);
    DeRef(_2643);
    _2643 = NOVALUE;
    return _st_5193;
L3: 

    /** sequence.e:2112			start = 1*/
    _start_5198 = 1;

    /** sequence.e:2113			while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_5193)){
            _2647 = SEQ_PTR(_st_5193)->length;
    }
    else {
        _2647 = 1;
    }
    if (_start_5198 > _2647)
    goto L8; // [140] 290

    /** sequence.e:2114				pos = match(delim, st, start)*/
    _pos_5199 = e_match_from(_delim_5194, _st_5193, _start_5198);

    /** sequence.e:2116				if pos = 0 then*/
    if (_pos_5199 != 0)
    goto L9; // [153] 162

    /** sequence.e:2117					exit*/
    goto L8; // [159] 290
L9: 

    /** sequence.e:2120				ret = append(ret, st[start..pos-1])*/
    _2651 = _pos_5199 - 1;
    rhs_slice_target = (object_ptr)&_2652;
    RHS_Slice(_st_5193, _start_5198, _2651);
    RefDS(_2652);
    Append(&_ret_5197, _ret_5197, _2652);
    DeRefDS(_2652);
    _2652 = NOVALUE;

    /** sequence.e:2121				start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_5194)){
            _2654 = SEQ_PTR(_delim_5194)->length;
    }
    else {
        _2654 = 1;
    }
    _start_5198 = _pos_5199 + _2654;
    _2654 = NOVALUE;

    /** sequence.e:2122				limit -= 1*/
    _limit_5196 = _limit_5196 - 1;

    /** sequence.e:2123				if limit = 0 then*/
    if (_limit_5196 != 0)
    goto L7; // [194] 137

    /** sequence.e:2124					exit*/
    goto L8; // [200] 290

    /** sequence.e:2126			end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** sequence.e:2128			start = 1*/
    _start_5198 = 1;

    /** sequence.e:2129			while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_5193)){
            _2658 = SEQ_PTR(_st_5193)->length;
    }
    else {
        _2658 = 1;
    }
    if (_start_5198 > _2658)
    goto LB; // [224] 289

    /** sequence.e:2130				pos = find(delim, st, start)*/
    _pos_5199 = find_from(_delim_5194, _st_5193, _start_5198);

    /** sequence.e:2132				if pos = 0 then*/
    if (_pos_5199 != 0)
    goto LC; // [237] 246

    /** sequence.e:2133					exit*/
    goto LB; // [243] 289
LC: 

    /** sequence.e:2136				ret = append(ret, st[start..pos-1])*/
    _2662 = _pos_5199 - 1;
    rhs_slice_target = (object_ptr)&_2663;
    RHS_Slice(_st_5193, _start_5198, _2662);
    RefDS(_2663);
    Append(&_ret_5197, _ret_5197, _2663);
    DeRefDS(_2663);
    _2663 = NOVALUE;

    /** sequence.e:2137				start = pos + 1*/
    _start_5198 = _pos_5199 + 1;

    /** sequence.e:2138				limit -= 1*/
    _limit_5196 = _limit_5196 - 1;

    /** sequence.e:2139				if limit = 0 then*/
    if (_limit_5196 != 0)
    goto LA; // [275] 221

    /** sequence.e:2140					exit*/
    goto LB; // [281] 289

    /** sequence.e:2142			end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** sequence.e:2145		ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_5193)){
            _2668 = SEQ_PTR(_st_5193)->length;
    }
    else {
        _2668 = 1;
    }
    rhs_slice_target = (object_ptr)&_2669;
    RHS_Slice(_st_5193, _start_5198, _2668);
    RefDS(_2669);
    Append(&_ret_5197, _ret_5197, _2669);
    DeRefDS(_2669);
    _2669 = NOVALUE;

    /** sequence.e:2147		integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_5197)){
            _k_5251 = SEQ_PTR(_ret_5197)->length;
    }
    else {
        _k_5251 = 1;
    }

    /** sequence.e:2148		if no_empty then*/
    if (_no_empty_5195 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** sequence.e:2149			k = 0*/
    _k_5251 = 0;

    /** sequence.e:2150			for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_5197)){
            _2672 = SEQ_PTR(_ret_5197)->length;
    }
    else {
        _2672 = 1;
    }
    {
        object _i_5255;
        _i_5255 = 1;
LE: 
        if (_i_5255 > _2672){
            goto LF; // [326] 377
        }

        /** sequence.e:2151				if length(ret[i]) != 0 then*/
        _2 = (object)SEQ_PTR(_ret_5197);
        _2673 = (object)*(((s1_ptr)_2)->base + _i_5255);
        if (IS_SEQUENCE(_2673)){
                _2674 = SEQ_PTR(_2673)->length;
        }
        else {
            _2674 = 1;
        }
        _2673 = NOVALUE;
        if (_2674 == 0)
        goto L10; // [342] 370

        /** sequence.e:2152					k += 1*/
        _k_5251 = _k_5251 + 1;

        /** sequence.e:2153					if k != i then*/
        if (_k_5251 == _i_5255)
        goto L11; // [354] 369

        /** sequence.e:2154						ret[k] = ret[i]*/
        _2 = (object)SEQ_PTR(_ret_5197);
        _2678 = (object)*(((s1_ptr)_2)->base + _i_5255);
        Ref(_2678);
        _2 = (object)SEQ_PTR(_ret_5197);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _ret_5197 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _k_5251);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2678;
        if( _1 != _2678 ){
            DeRef(_1);
        }
        _2678 = NOVALUE;
L11: 
L10: 

        /** sequence.e:2157			end for*/
        _i_5255 = _i_5255 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** sequence.e:2160		if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_5197)){
            _2679 = SEQ_PTR(_ret_5197)->length;
    }
    else {
        _2679 = 1;
    }
    if (_k_5251 >= _2679)
    goto L12; // [383] 401

    /** sequence.e:2161			return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_2681;
    RHS_Slice(_ret_5197, 1, _k_5251);
    DeRefDS(_st_5193);
    DeRefi(_delim_5194);
    DeRefDS(_ret_5197);
    DeRef(_2651);
    _2651 = NOVALUE;
    _2673 = NOVALUE;
    DeRef(_2662);
    _2662 = NOVALUE;
    DeRef(_2643);
    _2643 = NOVALUE;
    return _2681;
    goto L13; // [398] 408
L12: 

    /** sequence.e:2163			return ret*/
    DeRefDS(_st_5193);
    DeRefi(_delim_5194);
    DeRef(_2651);
    _2651 = NOVALUE;
    _2673 = NOVALUE;
    DeRef(_2662);
    _2662 = NOVALUE;
    DeRef(_2643);
    _2643 = NOVALUE;
    DeRef(_2681);
    _2681 = NOVALUE;
    return _ret_5197;
L13: 
    ;
}


object _23join(object _items_5320, object _delim_5321)
{
    object _ret_5323 = NOVALUE;
    object _2716 = NOVALUE;
    object _2715 = NOVALUE;
    object _2713 = NOVALUE;
    object _2712 = NOVALUE;
    object _2711 = NOVALUE;
    object _2710 = NOVALUE;
    object _2708 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2279		if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_5320)){
            _2708 = SEQ_PTR(_items_5320)->length;
    }
    else {
        _2708 = 1;
    }
    if (_2708 != 0)
    goto L1; // [8] 16
    _2708 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_5320);
    DeRef(_ret_5323);
    return _5;
L1: 

    /** sequence.e:2281		ret = {}*/
    RefDS(_5);
    DeRef(_ret_5323);
    _ret_5323 = _5;

    /** sequence.e:2282		for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_5320)){
            _2710 = SEQ_PTR(_items_5320)->length;
    }
    else {
        _2710 = 1;
    }
    _2711 = _2710 - 1;
    _2710 = NOVALUE;
    {
        object _i_5328;
        _i_5328 = 1;
L2: 
        if (_i_5328 > _2711){
            goto L3; // [30] 58
        }

        /** sequence.e:2283			ret &= items[i] & delim*/
        _2 = (object)SEQ_PTR(_items_5320);
        _2712 = (object)*(((s1_ptr)_2)->base + _i_5328);
        if (IS_SEQUENCE(_2712) && IS_ATOM(_delim_5321)) {
            Append(&_2713, _2712, _delim_5321);
        }
        else if (IS_ATOM(_2712) && IS_SEQUENCE(_delim_5321)) {
        }
        else {
            Concat((object_ptr)&_2713, _2712, _delim_5321);
            _2712 = NOVALUE;
        }
        _2712 = NOVALUE;
        if (IS_SEQUENCE(_ret_5323) && IS_ATOM(_2713)) {
        }
        else if (IS_ATOM(_ret_5323) && IS_SEQUENCE(_2713)) {
            Ref(_ret_5323);
            Prepend(&_ret_5323, _2713, _ret_5323);
        }
        else {
            Concat((object_ptr)&_ret_5323, _ret_5323, _2713);
        }
        DeRefDS(_2713);
        _2713 = NOVALUE;

        /** sequence.e:2284		end for*/
        _i_5328 = _i_5328 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** sequence.e:2286		ret &= items[$]*/
    if (IS_SEQUENCE(_items_5320)){
            _2715 = SEQ_PTR(_items_5320)->length;
    }
    else {
        _2715 = 1;
    }
    _2 = (object)SEQ_PTR(_items_5320);
    _2716 = (object)*(((s1_ptr)_2)->base + _2715);
    if (IS_SEQUENCE(_ret_5323) && IS_ATOM(_2716)) {
        Ref(_2716);
        Append(&_ret_5323, _ret_5323, _2716);
    }
    else if (IS_ATOM(_ret_5323) && IS_SEQUENCE(_2716)) {
        Ref(_ret_5323);
        Prepend(&_ret_5323, _2716, _ret_5323);
    }
    else {
        Concat((object_ptr)&_ret_5323, _ret_5323, _2716);
    }
    _2716 = NOVALUE;

    /** sequence.e:2288		return ret*/
    DeRefDS(_items_5320);
    DeRef(_2711);
    _2711 = NOVALUE;
    return _ret_5323;
    ;
}


object _23flatten(object _s_5430, object _delim_5431)
{
    object _ret_5432 = NOVALUE;
    object _x_5433 = NOVALUE;
    object _len_5434 = NOVALUE;
    object _pos_5435 = NOVALUE;
    object _temp_5453 = NOVALUE;
    object _2802 = NOVALUE;
    object _2801 = NOVALUE;
    object _2800 = NOVALUE;
    object _2798 = NOVALUE;
    object _2797 = NOVALUE;
    object _2796 = NOVALUE;
    object _2794 = NOVALUE;
    object _2792 = NOVALUE;
    object _2791 = NOVALUE;
    object _2790 = NOVALUE;
    object _2788 = NOVALUE;
    object _2787 = NOVALUE;
    object _2786 = NOVALUE;
    object _2785 = NOVALUE;
    object _2784 = NOVALUE;
    object _2783 = NOVALUE;
    object _2781 = NOVALUE;
    object _2780 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2491		ret = s*/
    RefDS(_s_5430);
    DeRef(_ret_5432);
    _ret_5432 = _s_5430;

    /** sequence.e:2492		pos = 1*/
    _pos_5435 = 1;

    /** sequence.e:2493		len = length(ret)*/
    if (IS_SEQUENCE(_ret_5432)){
            _len_5434 = SEQ_PTR(_ret_5432)->length;
    }
    else {
        _len_5434 = 1;
    }

    /** sequence.e:2494		while pos <= len do*/
L1: 
    if (_pos_5435 > _len_5434)
    goto L2; // [25] 183

    /** sequence.e:2495			x = ret[pos]*/
    DeRef(_x_5433);
    _2 = (object)SEQ_PTR(_ret_5432);
    _x_5433 = (object)*(((s1_ptr)_2)->base + _pos_5435);
    Ref(_x_5433);

    /** sequence.e:2496			if sequence(x) then*/
    _2780 = IS_SEQUENCE(_x_5433);
    if (_2780 == 0)
    {
        _2780 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _2780 = NOVALUE;
    }

    /** sequence.e:2497				if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_5431)){
            _2781 = SEQ_PTR(_delim_5431)->length;
    }
    else {
        _2781 = 1;
    }
    if (_2781 != 0)
    goto L4; // [48] 89

    /** sequence.e:2498					ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _2783 = _pos_5435 - 1;
    rhs_slice_target = (object_ptr)&_2784;
    RHS_Slice(_ret_5432, 1, _2783);
    Ref(_x_5433);
    RefDS(_5);
    _2785 = _23flatten(_x_5433, _5);
    _2786 = _pos_5435 + 1;
    if (_2786 > MAXINT){
        _2786 = NewDouble((eudouble)_2786);
    }
    if (IS_SEQUENCE(_ret_5432)){
            _2787 = SEQ_PTR(_ret_5432)->length;
    }
    else {
        _2787 = 1;
    }
    rhs_slice_target = (object_ptr)&_2788;
    RHS_Slice(_ret_5432, _2786, _2787);
    {
        object concat_list[3];

        concat_list[0] = _2788;
        concat_list[1] = _2785;
        concat_list[2] = _2784;
        Concat_N((object_ptr)&_ret_5432, concat_list, 3);
    }
    DeRefDS(_2788);
    _2788 = NOVALUE;
    DeRef(_2785);
    _2785 = NOVALUE;
    DeRefDS(_2784);
    _2784 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** sequence.e:2500					sequence temp = ret[1..pos-1] & flatten(x)*/
    _2790 = _pos_5435 - 1;
    rhs_slice_target = (object_ptr)&_2791;
    RHS_Slice(_ret_5432, 1, _2790);
    Ref(_x_5433);
    RefDS(_5);
    _2792 = _23flatten(_x_5433, _5);
    if (IS_SEQUENCE(_2791) && IS_ATOM(_2792)) {
        Ref(_2792);
        Append(&_temp_5453, _2791, _2792);
    }
    else if (IS_ATOM(_2791) && IS_SEQUENCE(_2792)) {
    }
    else {
        Concat((object_ptr)&_temp_5453, _2791, _2792);
        DeRefDS(_2791);
        _2791 = NOVALUE;
    }
    DeRef(_2791);
    _2791 = NOVALUE;
    DeRef(_2792);
    _2792 = NOVALUE;

    /** sequence.e:2501					if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_5432)){
            _2794 = SEQ_PTR(_ret_5432)->length;
    }
    else {
        _2794 = 1;
    }
    if (_pos_5435 == _2794)
    goto L6; // [114] 141

    /** sequence.e:2502						ret = temp &  delim & ret[pos+1 .. $]*/
    _2796 = _pos_5435 + 1;
    if (_2796 > MAXINT){
        _2796 = NewDouble((eudouble)_2796);
    }
    if (IS_SEQUENCE(_ret_5432)){
            _2797 = SEQ_PTR(_ret_5432)->length;
    }
    else {
        _2797 = 1;
    }
    rhs_slice_target = (object_ptr)&_2798;
    RHS_Slice(_ret_5432, _2796, _2797);
    {
        object concat_list[3];

        concat_list[0] = _2798;
        concat_list[1] = _delim_5431;
        concat_list[2] = _temp_5453;
        Concat_N((object_ptr)&_ret_5432, concat_list, 3);
    }
    DeRefDS(_2798);
    _2798 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** sequence.e:2504						ret = temp & ret[pos+1 .. $]*/
    _2800 = _pos_5435 + 1;
    if (_2800 > MAXINT){
        _2800 = NewDouble((eudouble)_2800);
    }
    if (IS_SEQUENCE(_ret_5432)){
            _2801 = SEQ_PTR(_ret_5432)->length;
    }
    else {
        _2801 = 1;
    }
    rhs_slice_target = (object_ptr)&_2802;
    RHS_Slice(_ret_5432, _2800, _2801);
    Concat((object_ptr)&_ret_5432, _temp_5453, _2802);
    DeRefDS(_2802);
    _2802 = NOVALUE;
L7: 
    DeRef(_temp_5453);
    _temp_5453 = NOVALUE;
L5: 

    /** sequence.e:2507				len = length(ret)*/
    if (IS_SEQUENCE(_ret_5432)){
            _len_5434 = SEQ_PTR(_ret_5432)->length;
    }
    else {
        _len_5434 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** sequence.e:2509				pos += 1*/
    _pos_5435 = _pos_5435 + 1;

    /** sequence.e:2511		end while*/
    goto L1; // [180] 25
L2: 

    /** sequence.e:2513		return ret*/
    DeRefDS(_s_5430);
    DeRefi(_delim_5431);
    DeRef(_x_5433);
    DeRef(_2783);
    _2783 = NOVALUE;
    DeRef(_2800);
    _2800 = NOVALUE;
    DeRef(_2786);
    _2786 = NOVALUE;
    DeRef(_2790);
    _2790 = NOVALUE;
    DeRef(_2796);
    _2796 = NOVALUE;
    return _ret_5432;
    ;
}


object _23remove_dups(object _source_data_5800, object _proc_option_5801)
{
    object _lTo_5802 = NOVALUE;
    object _lFrom_5803 = NOVALUE;
    object _lResult_5826 = NOVALUE;
    object _3031 = NOVALUE;
    object _3029 = NOVALUE;
    object _3028 = NOVALUE;
    object _3027 = NOVALUE;
    object _3026 = NOVALUE;
    object _3024 = NOVALUE;
    object _3020 = NOVALUE;
    object _3019 = NOVALUE;
    object _3018 = NOVALUE;
    object _3016 = NOVALUE;
    object _3011 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:3111		if length(source_data) < 2 then*/
    if (IS_SEQUENCE(_source_data_5800)){
            _3011 = SEQ_PTR(_source_data_5800)->length;
    }
    else {
        _3011 = 1;
    }
    if (_3011 >= 2)
    goto L1; // [10] 21

    /** sequence.e:3112			return source_data*/
    DeRef(_lResult_5826);
    return _source_data_5800;
L1: 

    /** sequence.e:3115		if proc_option = RD_SORT then*/
    if (_proc_option_5801 != 3)
    goto L2; // [23] 42

    /** sequence.e:3116			source_data = stdsort:sort(source_data)*/
    RefDS(_source_data_5800);
    _0 = _source_data_5800;
    _source_data_5800 = _24sort(_source_data_5800, 1);
    DeRefDS(_0);

    /** sequence.e:3117			proc_option = RD_PRESORTED*/
    _proc_option_5801 = 2;
L2: 

    /** sequence.e:3119		if proc_option = RD_PRESORTED then*/
    if (_proc_option_5801 != 2)
    goto L3; // [44] 134

    /** sequence.e:3120			lTo = 1*/
    _lTo_5802 = 1;

    /** sequence.e:3121			lFrom = 2*/
    _lFrom_5803 = 2;

    /** sequence.e:3123			while lFrom <= length(source_data) do*/
L4: 
    if (IS_SEQUENCE(_source_data_5800)){
            _3016 = SEQ_PTR(_source_data_5800)->length;
    }
    else {
        _3016 = 1;
    }
    if (_lFrom_5803 > _3016)
    goto L5; // [66] 122

    /** sequence.e:3124				if not equal(source_data[lFrom], source_data[lTo]) then*/
    _2 = (object)SEQ_PTR(_source_data_5800);
    _3018 = (object)*(((s1_ptr)_2)->base + _lFrom_5803);
    _2 = (object)SEQ_PTR(_source_data_5800);
    _3019 = (object)*(((s1_ptr)_2)->base + _lTo_5802);
    if (_3018 == _3019)
    _3020 = 1;
    else if (IS_ATOM_INT(_3018) && IS_ATOM_INT(_3019))
    _3020 = 0;
    else
    _3020 = (compare(_3018, _3019) == 0);
    _3018 = NOVALUE;
    _3019 = NOVALUE;
    if (_3020 != 0)
    goto L6; // [84] 111
    _3020 = NOVALUE;

    /** sequence.e:3125					lTo += 1*/
    _lTo_5802 = _lTo_5802 + 1;

    /** sequence.e:3126					if lTo != lFrom then*/
    if (_lTo_5802 == _lFrom_5803)
    goto L7; // [95] 110

    /** sequence.e:3127						source_data[lTo] = source_data[lFrom]*/
    _2 = (object)SEQ_PTR(_source_data_5800);
    _3024 = (object)*(((s1_ptr)_2)->base + _lFrom_5803);
    Ref(_3024);
    _2 = (object)SEQ_PTR(_source_data_5800);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _source_data_5800 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _lTo_5802);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3024;
    if( _1 != _3024 ){
        DeRef(_1);
    }
    _3024 = NOVALUE;
L7: 
L6: 

    /** sequence.e:3130				lFrom += 1*/
    _lFrom_5803 = _lFrom_5803 + 1;

    /** sequence.e:3131			end while*/
    goto L4; // [119] 63
L5: 

    /** sequence.e:3132			return source_data[1 .. lTo]*/
    rhs_slice_target = (object_ptr)&_3026;
    RHS_Slice(_source_data_5800, 1, _lTo_5802);
    DeRefDS(_source_data_5800);
    DeRef(_lResult_5826);
    return _3026;
L3: 

    /** sequence.e:3135		sequence lResult*/

    /** sequence.e:3136		lResult = {}*/
    RefDS(_5);
    DeRef(_lResult_5826);
    _lResult_5826 = _5;

    /** sequence.e:3137		for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_5800)){
            _3027 = SEQ_PTR(_source_data_5800)->length;
    }
    else {
        _3027 = 1;
    }
    {
        object _i_5828;
        _i_5828 = 1;
L8: 
        if (_i_5828 > _3027){
            goto L9; // [148] 187
        }

        /** sequence.e:3138			if not find(source_data[i], lResult) then*/
        _2 = (object)SEQ_PTR(_source_data_5800);
        _3028 = (object)*(((s1_ptr)_2)->base + _i_5828);
        _3029 = find_from(_3028, _lResult_5826, 1);
        _3028 = NOVALUE;
        if (_3029 != 0)
        goto LA; // [166] 180
        _3029 = NOVALUE;

        /** sequence.e:3139				lResult = append(lResult, source_data[i])*/
        _2 = (object)SEQ_PTR(_source_data_5800);
        _3031 = (object)*(((s1_ptr)_2)->base + _i_5828);
        Ref(_3031);
        Append(&_lResult_5826, _lResult_5826, _3031);
        _3031 = NOVALUE;
LA: 

        /** sequence.e:3141		end for*/
        _i_5828 = _i_5828 + 1;
        goto L8; // [182] 155
L9: 
        ;
    }

    /** sequence.e:3142		return lResult*/
    DeRefDS(_source_data_5800);
    DeRef(_3026);
    _3026 = NOVALUE;
    return _lResult_5826;
    ;
}



// 0x6A004B5A
