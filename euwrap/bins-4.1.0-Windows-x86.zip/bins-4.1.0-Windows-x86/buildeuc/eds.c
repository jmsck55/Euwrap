// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _43fatal(object _errcode_17142, object _msg_17143, object _routine_name_17144, object _parms_17145)
{
    object _9754 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:231		vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _errcode_17142;
    RefDS(_msg_17143);
    ((intptr_t*)_2)[2] = _msg_17143;
    RefDS(_routine_name_17144);
    ((intptr_t*)_2)[3] = _routine_name_17144;
    RefDS(_parms_17145);
    ((intptr_t*)_2)[4] = _parms_17145;
    _9754 = MAKE_SEQ(_1);
    RefDS(_9754);
    Append(&_43vLastErrors_17139, _43vLastErrors_17139, _9754);
    DeRefDS(_9754);
    _9754 = NOVALUE;

    /** eds.e:232		if db_fatal_id >= 0 then*/

    /** eds.e:235	end procedure*/
    DeRefDSi(_msg_17143);
    DeRefDSi(_routine_name_17144);
    DeRefDS(_parms_17145);
    return;
    ;
}


object _43get4()
{
    object _9770 = NOVALUE;
    object _9769 = NOVALUE;
    object _9768 = NOVALUE;
    object _9767 = NOVALUE;
    object _9766 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:250		poke(mem0, getc(current_db))*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9766 = getKBchar();
        }
        else{
            _9766 = getc(last_r_file_ptr);
        }
    }
    else{
        _9766 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem0_17157)){
        poke_addr = (uint8_t *)_43mem0_17157;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem0_17157)->dbl);
    }
    *poke_addr = (uint8_t)_9766;
    _9766 = NOVALUE;

    /** eds.e:251		poke(mem1, getc(current_db))*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9767 = getKBchar();
        }
        else{
            _9767 = getc(last_r_file_ptr);
        }
    }
    else{
        _9767 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem1_17158)){
        poke_addr = (uint8_t *)_43mem1_17158;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem1_17158)->dbl);
    }
    *poke_addr = (uint8_t)_9767;
    _9767 = NOVALUE;

    /** eds.e:252		poke(mem2, getc(current_db))*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9768 = getKBchar();
        }
        else{
            _9768 = getc(last_r_file_ptr);
        }
    }
    else{
        _9768 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem2_17159)){
        poke_addr = (uint8_t *)_43mem2_17159;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem2_17159)->dbl);
    }
    *poke_addr = (uint8_t)_9768;
    _9768 = NOVALUE;

    /** eds.e:253		poke(mem3, getc(current_db))*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9769 = getKBchar();
        }
        else{
            _9769 = getc(last_r_file_ptr);
        }
    }
    else{
        _9769 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_43mem3_17160)){
        poke_addr = (uint8_t *)_43mem3_17160;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_43mem3_17160)->dbl);
    }
    *poke_addr = (uint8_t)_9769;
    _9769 = NOVALUE;

    /** eds.e:254		return peek4u(mem0)*/
    if (IS_ATOM_INT(_43mem0_17157)) {
        _9770 = (object)*(uint32_t *)_43mem0_17157;
        if ((uintptr_t)_9770 > (uintptr_t)MAXINT){
            _9770 = NewDouble((eudouble)(uintptr_t)_9770);
        }
    }
    else {
        _9770 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_43mem0_17157)->dbl);
        if ((uintptr_t)_9770 > (uintptr_t)MAXINT){
            _9770 = NewDouble((eudouble)(uintptr_t)_9770);
        }
    }
    return _9770;
    ;
}


object _43get_string()
{
    object _where_inlined_where_at_31_17185 = NOVALUE;
    object _s_17174 = NOVALUE;
    object _c_17175 = NOVALUE;
    object _i_17176 = NOVALUE;
    object _9783 = NOVALUE;
    object _9780 = NOVALUE;
    object _9778 = NOVALUE;
    object _9776 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:263		s = repeat(0, 256)*/
    DeRefi(_s_17174);
    _s_17174 = Repeat(0, 256);

    /** eds.e:264		i = 0*/
    _i_17176 = 0;

    /** eds.e:265		while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_17175 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** eds.e:266			if c = -1 then*/
    if (_c_17175 != -1)
    goto L4; // [24] 54

    /** eds.e:267				fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_17185);
    _where_inlined_where_at_31_17185 = machine(20, _43current_db_17115);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_17185);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_31_17185;
    _9776 = MAKE_SEQ(_1);
    RefDS(_9774);
    RefDS(_9775);
    _43fatal(900, _9774, _9775, _9776);
    _9776 = NOVALUE;

    /** eds.e:268				exit*/
    goto L3; // [51] 101
L4: 

    /** eds.e:270			i += 1*/
    _i_17176 = _i_17176 + 1;

    /** eds.e:271			if i > length(s) then*/
    if (IS_SEQUENCE(_s_17174)){
            _9778 = SEQ_PTR(_s_17174)->length;
    }
    else {
        _9778 = 1;
    }
    if (_i_17176 <= _9778)
    goto L5; // [65] 80

    /** eds.e:272				s &= repeat(0, 256)*/
    _9780 = Repeat(0, 256);
    Concat((object_ptr)&_s_17174, _s_17174, _9780);
    DeRefDS(_9780);
    _9780 = NOVALUE;
L5: 

    /** eds.e:274			s[i] = c*/
    _2 = (object)SEQ_PTR(_s_17174);
    _2 = (object)(((s1_ptr)_2)->base + _i_17176);
    *(intptr_t *)_2 = _c_17175;

    /** eds.e:275		  entry*/
L1: 

    /** eds.e:276			c = getc(current_db)*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17175 = getKBchar();
        }
        else{
            _c_17175 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_17175 = getc(last_r_file_ptr);
    }

    /** eds.e:277		end while*/
    goto L2; // [98] 17
L3: 

    /** eds.e:278		return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9783;
    RHS_Slice(_s_17174, 1, _i_17176);
    DeRefDSi(_s_17174);
    return _9783;
    ;
}


object _43equal_string(object _target_17197)
{
    object _c_17198 = NOVALUE;
    object _i_17199 = NOVALUE;
    object _where_inlined_where_at_27_17205 = NOVALUE;
    object _9794 = NOVALUE;
    object _9793 = NOVALUE;
    object _9790 = NOVALUE;
    object _9788 = NOVALUE;
    object _9786 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:286		i = 0*/
    _i_17199 = 0;

    /** eds.e:287		while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_17198 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** eds.e:288			if c = -1 then*/
    if (_c_17198 != -1)
    goto L4; // [20] 52

    /** eds.e:289				fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_17205);
    _where_inlined_where_at_27_17205 = machine(20, _43current_db_17115);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_17205);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_27_17205;
    _9786 = MAKE_SEQ(_1);
    RefDS(_9774);
    RefDS(_9785);
    _43fatal(900, _9774, _9785, _9786);
    _9786 = NOVALUE;

    /** eds.e:290				return DB_FATAL_FAIL*/
    DeRefDS(_target_17197);
    return -404;
L4: 

    /** eds.e:292			i += 1*/
    _i_17199 = _i_17199 + 1;

    /** eds.e:293			if i > length(target) then*/
    if (IS_SEQUENCE(_target_17197)){
            _9788 = SEQ_PTR(_target_17197)->length;
    }
    else {
        _9788 = 1;
    }
    if (_i_17199 <= _9788)
    goto L5; // [63] 74

    /** eds.e:294				return 0*/
    DeRefDS(_target_17197);
    return 0;
L5: 

    /** eds.e:296			if target[i] != c then*/
    _2 = (object)SEQ_PTR(_target_17197);
    _9790 = (object)*(((s1_ptr)_2)->base + _i_17199);
    if (binary_op_a(EQUALS, _9790, _c_17198)){
        _9790 = NOVALUE;
        goto L6; // [80] 91
    }
    _9790 = NOVALUE;

    /** eds.e:297				return 0*/
    DeRefDS(_target_17197);
    return 0;
L6: 

    /** eds.e:299		  entry*/
L1: 

    /** eds.e:300			c = getc(current_db)*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17198 = getKBchar();
        }
        else{
            _c_17198 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_17198 = getc(last_r_file_ptr);
    }

    /** eds.e:301		end while*/
    goto L2; // [103] 13
L3: 

    /** eds.e:302		return (i = length(target))*/
    if (IS_SEQUENCE(_target_17197)){
            _9793 = SEQ_PTR(_target_17197)->length;
    }
    else {
        _9793 = 1;
    }
    _9794 = (_i_17199 == _9793);
    _9793 = NOVALUE;
    DeRefDS(_target_17197);
    return _9794;
    ;
}


object _43decompress(object _c_17256)
{
    object _s_17257 = NOVALUE;
    object _len_17258 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_176_17294 = NOVALUE;
    object _ieee32_inlined_float32_to_atom_at_173_17293 = NOVALUE;
    object _float64_to_atom_inlined_float64_to_atom_at_251_17307 = NOVALUE;
    object _ieee64_inlined_float64_to_atom_at_248_17306 = NOVALUE;
    object _9863 = NOVALUE;
    object _9862 = NOVALUE;
    object _9861 = NOVALUE;
    object _9858 = NOVALUE;
    object _9853 = NOVALUE;
    object _9852 = NOVALUE;
    object _9851 = NOVALUE;
    object _9850 = NOVALUE;
    object _9849 = NOVALUE;
    object _9848 = NOVALUE;
    object _9847 = NOVALUE;
    object _9846 = NOVALUE;
    object _9845 = NOVALUE;
    object _9844 = NOVALUE;
    object _9843 = NOVALUE;
    object _9842 = NOVALUE;
    object _9841 = NOVALUE;
    object _9840 = NOVALUE;
    object _9839 = NOVALUE;
    object _9838 = NOVALUE;
    object _9837 = NOVALUE;
    object _9836 = NOVALUE;
    object _9835 = NOVALUE;
    object _9834 = NOVALUE;
    object _9832 = NOVALUE;
    object _9831 = NOVALUE;
    object _9830 = NOVALUE;
    object _9829 = NOVALUE;
    object _9828 = NOVALUE;
    object _9827 = NOVALUE;
    object _9826 = NOVALUE;
    object _9825 = NOVALUE;
    object _9824 = NOVALUE;
    object _9821 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:332		if c = 0 then*/
    if (_c_17256 != 0)
    goto L1; // [5] 34

    /** eds.e:333			c = getc(current_db)*/
    if (_43current_db_17115 != last_r_file_no) {
        last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
        last_r_file_no = _43current_db_17115;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_17256 = getKBchar();
        }
        else{
            _c_17256 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_17256 = getc(last_r_file_ptr);
    }

    /** eds.e:334			if c < I2B then*/
    if (_c_17256 >= 249)
    goto L2; // [18] 33

    /** eds.e:335				return c + MIN1B*/
    _9821 = _c_17256 + -9;
    DeRef(_s_17257);
    return _9821;
L2: 
L1: 

    /** eds.e:339		switch c with fallthru do*/
    _0 = _c_17256;
    switch ( _0 ){ 

        /** eds.e:340			case I2B then*/
        case 249:

        /** eds.e:341				return getc(current_db) +*/
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9824 = getKBchar();
            }
            else{
                _9824 = getc(last_r_file_ptr);
            }
        }
        else{
            _9824 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9825 = getKBchar();
            }
            else{
                _9825 = getc(last_r_file_ptr);
            }
        }
        else{
            _9825 = getc(last_r_file_ptr);
        }
        _9826 = 256 * _9825;
        _9825 = NOVALUE;
        _9827 = _9824 + _9826;
        _9824 = NOVALUE;
        _9826 = NOVALUE;
        _9828 = _9827 + _43MIN2B_17236;
        if ((object)((uintptr_t)_9828 + (uintptr_t)HIGH_BITS) >= 0){
            _9828 = NewDouble((eudouble)_9828);
        }
        _9827 = NOVALUE;
        DeRef(_s_17257);
        DeRef(_9821);
        _9821 = NOVALUE;
        return _9828;

        /** eds.e:345			case I3B then*/
        case 250:

        /** eds.e:346				return getc(current_db) +*/
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9829 = getKBchar();
            }
            else{
                _9829 = getc(last_r_file_ptr);
            }
        }
        else{
            _9829 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9830 = getKBchar();
            }
            else{
                _9830 = getc(last_r_file_ptr);
            }
        }
        else{
            _9830 = getc(last_r_file_ptr);
        }
        _9831 = 256 * _9830;
        _9830 = NOVALUE;
        _9832 = _9829 + _9831;
        _9829 = NOVALUE;
        _9831 = NOVALUE;
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9834 = getKBchar();
            }
            else{
                _9834 = getc(last_r_file_ptr);
            }
        }
        else{
            _9834 = getc(last_r_file_ptr);
        }
        _9835 = 65536 * _9834;
        _9834 = NOVALUE;
        _9836 = _9832 + _9835;
        _9832 = NOVALUE;
        _9835 = NOVALUE;
        _9837 = _9836 + _43MIN3B_17243;
        if ((object)((uintptr_t)_9837 + (uintptr_t)HIGH_BITS) >= 0){
            _9837 = NewDouble((eudouble)_9837);
        }
        _9836 = NOVALUE;
        DeRef(_s_17257);
        DeRef(_9821);
        _9821 = NOVALUE;
        DeRef(_9828);
        _9828 = NOVALUE;
        return _9837;

        /** eds.e:351			case I4B then*/
        case 251:

        /** eds.e:352				return get4() + MIN4B*/
        _9838 = _43get4();
        if (IS_ATOM_INT(_9838) && IS_ATOM_INT(_43MIN4B_17250)) {
            _9839 = _9838 + _43MIN4B_17250;
            if ((object)((uintptr_t)_9839 + (uintptr_t)HIGH_BITS) >= 0){
                _9839 = NewDouble((eudouble)_9839);
            }
        }
        else {
            _9839 = binary_op(PLUS, _9838, _43MIN4B_17250);
        }
        DeRef(_9838);
        _9838 = NOVALUE;
        DeRef(_s_17257);
        DeRef(_9821);
        _9821 = NOVALUE;
        DeRef(_9828);
        _9828 = NOVALUE;
        DeRef(_9837);
        _9837 = NOVALUE;
        return _9839;

        /** eds.e:354			case F4B then*/
        case 252:

        /** eds.e:355				return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9840 = getKBchar();
            }
            else{
                _9840 = getc(last_r_file_ptr);
            }
        }
        else{
            _9840 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9841 = getKBchar();
            }
            else{
                _9841 = getc(last_r_file_ptr);
            }
        }
        else{
            _9841 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9842 = getKBchar();
            }
            else{
                _9842 = getc(last_r_file_ptr);
            }
        }
        else{
            _9842 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9843 = getKBchar();
            }
            else{
                _9843 = getc(last_r_file_ptr);
            }
        }
        else{
            _9843 = getc(last_r_file_ptr);
        }
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9840;
        ((intptr_t*)_2)[2] = _9841;
        ((intptr_t*)_2)[3] = _9842;
        ((intptr_t*)_2)[4] = _9843;
        _9844 = MAKE_SEQ(_1);
        _9843 = NOVALUE;
        _9842 = NOVALUE;
        _9841 = NOVALUE;
        _9840 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17293);
        _ieee32_inlined_float32_to_atom_at_173_17293 = _9844;
        _9844 = NOVALUE;

        /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_17294);
        _float32_to_atom_inlined_float32_to_atom_at_176_17294 = machine(49, _ieee32_inlined_float32_to_atom_at_173_17293);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17293);
        _ieee32_inlined_float32_to_atom_at_173_17293 = NOVALUE;
        DeRef(_s_17257);
        DeRef(_9821);
        _9821 = NOVALUE;
        DeRef(_9839);
        _9839 = NOVALUE;
        DeRef(_9828);
        _9828 = NOVALUE;
        DeRef(_9837);
        _9837 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_17294;

        /** eds.e:358			case F8B then*/
        case 253:

        /** eds.e:359				return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9845 = getKBchar();
            }
            else{
                _9845 = getc(last_r_file_ptr);
            }
        }
        else{
            _9845 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9846 = getKBchar();
            }
            else{
                _9846 = getc(last_r_file_ptr);
            }
        }
        else{
            _9846 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9847 = getKBchar();
            }
            else{
                _9847 = getc(last_r_file_ptr);
            }
        }
        else{
            _9847 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9848 = getKBchar();
            }
            else{
                _9848 = getc(last_r_file_ptr);
            }
        }
        else{
            _9848 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9849 = getKBchar();
            }
            else{
                _9849 = getc(last_r_file_ptr);
            }
        }
        else{
            _9849 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9850 = getKBchar();
            }
            else{
                _9850 = getc(last_r_file_ptr);
            }
        }
        else{
            _9850 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9851 = getKBchar();
            }
            else{
                _9851 = getc(last_r_file_ptr);
            }
        }
        else{
            _9851 = getc(last_r_file_ptr);
        }
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9852 = getKBchar();
            }
            else{
                _9852 = getc(last_r_file_ptr);
            }
        }
        else{
            _9852 = getc(last_r_file_ptr);
        }
        _1 = NewS1(8);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9845;
        ((intptr_t*)_2)[2] = _9846;
        ((intptr_t*)_2)[3] = _9847;
        ((intptr_t*)_2)[4] = _9848;
        ((intptr_t*)_2)[5] = _9849;
        ((intptr_t*)_2)[6] = _9850;
        ((intptr_t*)_2)[7] = _9851;
        ((intptr_t*)_2)[8] = _9852;
        _9853 = MAKE_SEQ(_1);
        _9852 = NOVALUE;
        _9851 = NOVALUE;
        _9850 = NOVALUE;
        _9849 = NOVALUE;
        _9848 = NOVALUE;
        _9847 = NOVALUE;
        _9846 = NOVALUE;
        _9845 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17306);
        _ieee64_inlined_float64_to_atom_at_248_17306 = _9853;
        _9853 = NOVALUE;

        /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_17307);
        _float64_to_atom_inlined_float64_to_atom_at_251_17307 = machine(47, _ieee64_inlined_float64_to_atom_at_248_17306);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17306);
        _ieee64_inlined_float64_to_atom_at_248_17306 = NOVALUE;
        DeRef(_s_17257);
        DeRef(_9821);
        _9821 = NOVALUE;
        DeRef(_9839);
        _9839 = NOVALUE;
        DeRef(_9828);
        _9828 = NOVALUE;
        DeRef(_9837);
        _9837 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_17307;

        /** eds.e:364			case else*/
        default:

        /** eds.e:366				if c = S1B then*/
        if (_c_17256 != 254)
        goto L3; // [273] 287

        /** eds.e:367					len = getc(current_db)*/
        if (_43current_db_17115 != last_r_file_no) {
            last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
            last_r_file_no = _43current_db_17115;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_17258 = getKBchar();
            }
            else{
                _len_17258 = getc(last_r_file_ptr);
            }
        }
        else{
            _len_17258 = getc(last_r_file_ptr);
        }
        goto L4; // [284] 295
L3: 

        /** eds.e:369					len = get4()*/
        _len_17258 = _43get4();
        if (!IS_ATOM_INT(_len_17258)) {
            _1 = (object)(DBL_PTR(_len_17258)->dbl);
            DeRefDS(_len_17258);
            _len_17258 = _1;
        }
L4: 

        /** eds.e:371				s = repeat(0, len)*/
        DeRef(_s_17257);
        _s_17257 = Repeat(0, _len_17258);

        /** eds.e:372				for i = 1 to len do*/
        _9858 = _len_17258;
        {
            object _i_17316;
            _i_17316 = 1;
L5: 
            if (_i_17316 > _9858){
                goto L6; // [308] 362
            }

            /** eds.e:374					c = getc(current_db)*/
            if (_43current_db_17115 != last_r_file_no) {
                last_r_file_ptr = which_file(_43current_db_17115, EF_READ);
                last_r_file_no = _43current_db_17115;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_17256 = getKBchar();
                }
                else{
                    _c_17256 = getc(last_r_file_ptr);
                }
            }
            else{
                _c_17256 = getc(last_r_file_ptr);
            }

            /** eds.e:375					if c < I2B then*/
            if (_c_17256 >= 249)
            goto L7; // [324] 341

            /** eds.e:376						s[i] = c + MIN1B*/
            _9861 = _c_17256 + -9;
            _2 = (object)SEQ_PTR(_s_17257);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_17257 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_17316);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9861;
            if( _1 != _9861 ){
                DeRef(_1);
            }
            _9861 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** eds.e:378						s[i] = decompress(c)*/
            DeRef(_9862);
            _9862 = _c_17256;
            _9863 = _43decompress(_9862);
            _9862 = NOVALUE;
            _2 = (object)SEQ_PTR(_s_17257);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_17257 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_17316);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9863;
            if( _1 != _9863 ){
                DeRef(_1);
            }
            _9863 = NOVALUE;
L8: 

            /** eds.e:380				end for*/
            _i_17316 = _i_17316 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** eds.e:381				return s*/
        DeRef(_9821);
        _9821 = NOVALUE;
        DeRef(_9839);
        _9839 = NOVALUE;
        DeRef(_9828);
        _9828 = NOVALUE;
        DeRef(_9837);
        _9837 = NOVALUE;
        return _s_17257;
    ;}    ;
}


void _43save_keys()
{
    object _k_18042 = NOVALUE;
    object _10191 = NOVALUE;
    object _10187 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:926		if caching_option = 1 then*/

    /** eds.e:927			if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _43current_table_pos_17116, 0)){
        goto L1; // [13] 81
    }

    /** eds.e:928				k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_43current_table_pos_17116);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _43current_table_pos_17116;
    _10187 = MAKE_SEQ(_1);
    _k_18042 = find_from(_10187, _43cache_index_17124, 1);
    DeRefDS(_10187);
    _10187 = NOVALUE;

    /** eds.e:929				if k != 0 then*/
    if (_k_18042 == 0)
    goto L2; // [36] 53

    /** eds.e:930					key_cache[k] = key_pointers*/
    RefDS(_43key_pointers_17122);
    _2 = (object)SEQ_PTR(_43key_cache_17123);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43key_cache_17123 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _k_18042);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43key_pointers_17122;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** eds.e:932					key_cache = append(key_cache, key_pointers)*/
    RefDS(_43key_pointers_17122);
    Append(&_43key_cache_17123, _43key_cache_17123, _43key_pointers_17122);

    /** eds.e:933					cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_43current_table_pos_17116);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _43current_table_pos_17116;
    _10191 = MAKE_SEQ(_1);
    RefDS(_10191);
    Append(&_43cache_index_17124, _43cache_index_17124, _10191);
    DeRefDS(_10191);
    _10191 = NOVALUE;
L3: 
L1: 

    /** eds.e:937	end procedure*/
    return;
    ;
}


object _43db_open(object _path_18224, object _lock_method_18225)
{
    object _db_18226 = NOVALUE;
    object _magic_18227 = NOVALUE;
    object _lock_file_1__tmp_at141_18254 = NOVALUE;
    object _lock_file_inlined_lock_file_at_141_18253 = NOVALUE;
    object _lock_file_1__tmp_at181_18261 = NOVALUE;
    object _lock_file_inlined_lock_file_at_181_18260 = NOVALUE;
    object _10302 = NOVALUE;
    object _10300 = NOVALUE;
    object _10298 = NOVALUE;
    object _10296 = NOVALUE;
    object _10295 = NOVALUE;
    object _10293 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1273		db = find(path, Known_Aliases)*/
    _db_18226 = find_from(_path_18224, _43Known_Aliases_17136, 1);

    /** eds.e:1274		if db then*/
    if (_db_18226 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1276			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_17137);
    _10293 = (object)*(((s1_ptr)_2)->base + _db_18226);
    DeRefDS(_path_18224);
    _2 = (object)SEQ_PTR(_10293);
    _path_18224 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18224);
    _10293 = NOVALUE;

    /** eds.e:1277			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_17137);
    _10295 = (object)*(((s1_ptr)_2)->base + _db_18226);
    _2 = (object)SEQ_PTR(_10295);
    _10296 = (object)*(((s1_ptr)_2)->base + 2);
    _10295 = NOVALUE;
    _2 = (object)SEQ_PTR(_10296);
    _lock_method_18225 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18225)){
        _lock_method_18225 = (object)DBL_PTR(_lock_method_18225)->dbl;
    }
    _10296 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1279			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18224);
    RefDS(_10245);
    _10298 = _17defaultext(_path_18224, _10245);
    _0 = _path_18224;
    _path_18224 = _17canonical_path(_10298, 0, 0);
    DeRefDS(_0);
    _10298 = NOVALUE;
L2: 

    /** eds.e:1282		if lock_method = DB_LOCK_NO or*/
    _10300 = (_lock_method_18225 == 0);
    if (_10300 != 0) {
        goto L3; // [76] 89
    }
    _10302 = (_lock_method_18225 == 2);
    if (_10302 == 0)
    {
        DeRef(_10302);
        _10302 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10302);
        _10302 = NOVALUE;
    }
L3: 

    /** eds.e:1285			db = open(path, "ub")*/
    _db_18226 = EOpen(_path_18224, _10272, 0);
    goto L5; // [96] 107
L4: 

    /** eds.e:1288			db = open(path, "rb")*/
    _db_18226 = EOpen(_path_18224, _10266, 0);
L5: 

    /** eds.e:1291	ifdef WINDOWS then*/

    /** eds.e:1292		if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18225 != 1)
    goto L6; // [111] 121

    /** eds.e:1293			lock_method = DB_LOCK_EXCLUSIVE*/
    _lock_method_18225 = 2;
L6: 

    /** eds.e:1298		if db = -1 then*/
    if (_db_18226 != -1)
    goto L7; // [123] 134

    /** eds.e:1299			return DB_OPEN_FAIL*/
    DeRefDS(_path_18224);
    DeRef(_10300);
    _10300 = NOVALUE;
    return -1;
L7: 

    /** eds.e:1301		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18225 != 2)
    goto L8; // [136] 174

    /** eds.e:1302			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at141_18254;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_18226;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at141_18254 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_141_18253 = machine(61, _lock_file_1__tmp_at141_18254);
    DeRef(_lock_file_1__tmp_at141_18254);
    _lock_file_1__tmp_at141_18254 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_141_18253 != 0)
    goto L9; // [157] 213

    /** eds.e:1303				close(db)*/
    EClose(_db_18226);

    /** eds.e:1304				return DB_LOCK_FAIL*/
    DeRefDS(_path_18224);
    DeRef(_10300);
    _10300 = NOVALUE;
    return -3;
    goto L9; // [171] 213
L8: 

    /** eds.e:1306		elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18225 != 1)
    goto LA; // [176] 212

    /** eds.e:1307			if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at181_18261;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_18226;
    ((intptr_t*)_2)[2] = 1;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at181_18261 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_181_18260 = machine(61, _lock_file_1__tmp_at181_18261);
    DeRef(_lock_file_1__tmp_at181_18261);
    _lock_file_1__tmp_at181_18261 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_181_18260 != 0)
    goto LB; // [197] 211

    /** eds.e:1308				close(db)*/
    EClose(_db_18226);

    /** eds.e:1309				return DB_LOCK_FAIL*/
    DeRefDS(_path_18224);
    DeRef(_10300);
    _10300 = NOVALUE;
    return -3;
LB: 
LA: 
L9: 

    /** eds.e:1312		magic = getc(db)*/
    if (_db_18226 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_18226, EF_READ);
        last_r_file_no = _db_18226;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_18227 = getKBchar();
        }
        else{
            _magic_18227 = getc(last_r_file_ptr);
        }
    }
    else{
        _magic_18227 = getc(last_r_file_ptr);
    }

    /** eds.e:1313		if magic != DB_MAGIC then*/
    if (_magic_18227 == 77)
    goto LC; // [220] 235

    /** eds.e:1314			close(db)*/
    EClose(_db_18226);

    /** eds.e:1315			return DB_OPEN_FAIL*/
    DeRefDS(_path_18224);
    DeRef(_10300);
    _10300 = NOVALUE;
    return -1;
LC: 

    /** eds.e:1317		save_keys()*/
    _43save_keys();

    /** eds.e:1318		current_db = db */
    _43current_db_17115 = _db_18226;

    /** eds.e:1319		current_table_pos = -1*/
    DeRef(_43current_table_pos_17116);
    _43current_table_pos_17116 = -1;

    /** eds.e:1320		current_table_name = ""*/
    RefDS(_5);
    DeRef(_43current_table_name_17117);
    _43current_table_name_17117 = _5;

    /** eds.e:1321		current_lock = lock_method*/
    _43current_lock_17121 = _lock_method_18225;

    /** eds.e:1322		db_names = append(db_names, path)*/
    RefDS(_path_18224);
    Append(&_43db_names_17118, _43db_names_17118, _path_18224);

    /** eds.e:1323		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_43db_lock_methods_17120, _43db_lock_methods_17120, _lock_method_18225);

    /** eds.e:1324		db_file_nums = append(db_file_nums, db)*/
    Append(&_43db_file_nums_17119, _43db_file_nums_17119, _db_18226);

    /** eds.e:1325		return DB_OK*/
    DeRefDS(_path_18224);
    DeRef(_10300);
    _10300 = NOVALUE;
    return 0;
    ;
}


object _43db_select(object _path_18271, object _lock_method_18272)
{
    object _index_18273 = NOVALUE;
    object _10322 = NOVALUE;
    object _10320 = NOVALUE;
    object _10319 = NOVALUE;
    object _10317 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1372		index = find(path, Known_Aliases)*/
    _index_18273 = find_from(_path_18271, _43Known_Aliases_17136, 1);

    /** eds.e:1373		if index then*/
    if (_index_18273 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1375			path = Alias_Details[index][1]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_17137);
    _10317 = (object)*(((s1_ptr)_2)->base + _index_18273);
    DeRefDS(_path_18271);
    _2 = (object)SEQ_PTR(_10317);
    _path_18271 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18271);
    _10317 = NOVALUE;

    /** eds.e:1376			lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_43Alias_Details_17137);
    _10319 = (object)*(((s1_ptr)_2)->base + _index_18273);
    _2 = (object)SEQ_PTR(_10319);
    _10320 = (object)*(((s1_ptr)_2)->base + 2);
    _10319 = NOVALUE;
    _2 = (object)SEQ_PTR(_10320);
    _lock_method_18272 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18272)){
        _lock_method_18272 = (object)DBL_PTR(_lock_method_18272)->dbl;
    }
    _10320 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1378			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18271);
    RefDS(_10245);
    _10322 = _17defaultext(_path_18271, _10245);
    _0 = _path_18271;
    _path_18271 = _17canonical_path(_10322, 0, 0);
    DeRefDS(_0);
    _10322 = NOVALUE;
L2: 

    /** eds.e:1381		index = eu:find(path, db_names)*/
    _index_18273 = find_from(_path_18271, _43db_names_17118, 1);

    /** eds.e:1382		if index = 0 then*/
    if (_index_18273 != 0)
    goto L3; // [81] 130

    /** eds.e:1383			if lock_method = -1 then*/
    if (_lock_method_18272 != -1)
    goto L4; // [87] 98

    /** eds.e:1384				return DB_OPEN_FAIL*/
    DeRefDS(_path_18271);
    return -1;
L4: 

    /** eds.e:1386			index = db_open(path, lock_method)*/
    RefDS(_path_18271);
    _index_18273 = _43db_open(_path_18271, _lock_method_18272);
    if (!IS_ATOM_INT(_index_18273)) {
        _1 = (object)(DBL_PTR(_index_18273)->dbl);
        DeRefDS(_index_18273);
        _index_18273 = _1;
    }

    /** eds.e:1387			if index != DB_OK then*/
    if (_index_18273 == 0)
    goto L5; // [109] 120

    /** eds.e:1388				return index*/
    DeRefDS(_path_18271);
    return _index_18273;
L5: 

    /** eds.e:1390			index = eu:find(path, db_names)*/
    _index_18273 = find_from(_path_18271, _43db_names_17118, 1);
L3: 

    /** eds.e:1392		save_keys()*/
    _43save_keys();

    /** eds.e:1393		current_db = db_file_nums[index]*/
    _2 = (object)SEQ_PTR(_43db_file_nums_17119);
    _43current_db_17115 = (object)*(((s1_ptr)_2)->base + _index_18273);
    if (!IS_ATOM_INT(_43current_db_17115))
    _43current_db_17115 = (object)DBL_PTR(_43current_db_17115)->dbl;

    /** eds.e:1394		current_lock = db_lock_methods[index]*/
    _2 = (object)SEQ_PTR(_43db_lock_methods_17120);
    _43current_lock_17121 = (object)*(((s1_ptr)_2)->base + _index_18273);
    if (!IS_ATOM_INT(_43current_lock_17121))
    _43current_lock_17121 = (object)DBL_PTR(_43current_lock_17121)->dbl;

    /** eds.e:1395		current_table_pos = -1*/
    DeRef(_43current_table_pos_17116);
    _43current_table_pos_17116 = -1;

    /** eds.e:1396		current_table_name = ""*/
    RefDS(_5);
    DeRef(_43current_table_name_17117);
    _43current_table_name_17117 = _5;

    /** eds.e:1397		key_pointers = {}*/
    RefDS(_5);
    DeRef(_43key_pointers_17122);
    _43key_pointers_17122 = _5;

    /** eds.e:1398		return DB_OK*/
    DeRefDS(_path_18271);
    return 0;
    ;
}


void _43db_close()
{
    object _unlock_file_1__tmp_at25_18302 = NOVALUE;
    object _index_18297 = NOVALUE;
    object _10339 = NOVALUE;
    object _10338 = NOVALUE;
    object _10337 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1413		if current_db = -1 then*/
    if (_43current_db_17115 != -1)
    goto L1; // [5] 15

    /** eds.e:1414			return*/
    return;
L1: 

    /** eds.e:1417		if current_lock then*/
    if (_43current_lock_17121 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** eds.e:1418			io:unlock_file(current_db, {})*/

    /** io.e:1086		machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_18302);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_18302 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_18302);

    /** io.e:1087	end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_18302);
    _unlock_file_1__tmp_at25_18302 = NOVALUE;
L2: 

    /** eds.e:1420		close(current_db)*/
    EClose(_43current_db_17115);

    /** eds.e:1422		index = eu:find(current_db, db_file_nums)*/
    _index_18297 = find_from(_43current_db_17115, _43db_file_nums_17119, 1);

    /** eds.e:1423		db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_43db_names_17118);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18297)) ? _index_18297 : (object)(DBL_PTR(_index_18297)->dbl);
        int stop = (IS_ATOM_INT(_index_18297)) ? _index_18297 : (object)(DBL_PTR(_index_18297)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43db_names_17118), start, &_43db_names_17118 );
            }
            else Tail(SEQ_PTR(_43db_names_17118), stop+1, &_43db_names_17118);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43db_names_17118), start, &_43db_names_17118);
        }
        else {
            assign_slice_seq = &assign_space;
            _43db_names_17118 = Remove_elements(start, stop, (SEQ_PTR(_43db_names_17118)->ref == 1));
        }
    }

    /** eds.e:1424		db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_43db_file_nums_17119);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18297)) ? _index_18297 : (object)(DBL_PTR(_index_18297)->dbl);
        int stop = (IS_ATOM_INT(_index_18297)) ? _index_18297 : (object)(DBL_PTR(_index_18297)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43db_file_nums_17119), start, &_43db_file_nums_17119 );
            }
            else Tail(SEQ_PTR(_43db_file_nums_17119), stop+1, &_43db_file_nums_17119);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43db_file_nums_17119), start, &_43db_file_nums_17119);
        }
        else {
            assign_slice_seq = &assign_space;
            _43db_file_nums_17119 = Remove_elements(start, stop, (SEQ_PTR(_43db_file_nums_17119)->ref == 1));
        }
    }

    /** eds.e:1425		db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_43db_lock_methods_17120);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18297)) ? _index_18297 : (object)(DBL_PTR(_index_18297)->dbl);
        int stop = (IS_ATOM_INT(_index_18297)) ? _index_18297 : (object)(DBL_PTR(_index_18297)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43db_lock_methods_17120), start, &_43db_lock_methods_17120 );
            }
            else Tail(SEQ_PTR(_43db_lock_methods_17120), stop+1, &_43db_lock_methods_17120);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43db_lock_methods_17120), start, &_43db_lock_methods_17120);
        }
        else {
            assign_slice_seq = &assign_space;
            _43db_lock_methods_17120 = Remove_elements(start, stop, (SEQ_PTR(_43db_lock_methods_17120)->ref == 1));
        }
    }

    /** eds.e:1427		for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_43cache_index_17124)){
            _10337 = SEQ_PTR(_43cache_index_17124)->length;
    }
    else {
        _10337 = 1;
    }
    {
        object _i_18308;
        _i_18308 = _10337;
L4: 
        if (_i_18308 < 1){
            goto L5; // [94] 145
        }

        /** eds.e:1428			if cache_index[i][1] = current_db then*/
        _2 = (object)SEQ_PTR(_43cache_index_17124);
        _10338 = (object)*(((s1_ptr)_2)->base + _i_18308);
        _2 = (object)SEQ_PTR(_10338);
        _10339 = (object)*(((s1_ptr)_2)->base + 1);
        _10338 = NOVALUE;
        if (binary_op_a(NOTEQ, _10339, _43current_db_17115)){
            _10339 = NOVALUE;
            goto L6; // [115] 138
        }
        _10339 = NOVALUE;

        /** eds.e:1429				cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_43cache_index_17124);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18308)) ? _i_18308 : (object)(DBL_PTR(_i_18308)->dbl);
            int stop = (IS_ATOM_INT(_i_18308)) ? _i_18308 : (object)(DBL_PTR(_i_18308)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_43cache_index_17124), start, &_43cache_index_17124 );
                }
                else Tail(SEQ_PTR(_43cache_index_17124), stop+1, &_43cache_index_17124);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_43cache_index_17124), start, &_43cache_index_17124);
            }
            else {
                assign_slice_seq = &assign_space;
                _43cache_index_17124 = Remove_elements(start, stop, (SEQ_PTR(_43cache_index_17124)->ref == 1));
            }
        }

        /** eds.e:1430				key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_43key_cache_17123);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18308)) ? _i_18308 : (object)(DBL_PTR(_i_18308)->dbl);
            int stop = (IS_ATOM_INT(_i_18308)) ? _i_18308 : (object)(DBL_PTR(_i_18308)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_43key_cache_17123), start, &_43key_cache_17123 );
                }
                else Tail(SEQ_PTR(_43key_cache_17123), stop+1, &_43key_cache_17123);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_43key_cache_17123), start, &_43key_cache_17123);
            }
            else {
                assign_slice_seq = &assign_space;
                _43key_cache_17123 = Remove_elements(start, stop, (SEQ_PTR(_43key_cache_17123)->ref == 1));
            }
        }
L6: 

        /** eds.e:1432		end for*/
        _i_18308 = _i_18308 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** eds.e:1433		current_table_pos = -1*/
    DeRef(_43current_table_pos_17116);
    _43current_table_pos_17116 = -1;

    /** eds.e:1434		current_table_name = ""	*/
    RefDS(_5);
    DeRef(_43current_table_name_17117);
    _43current_table_name_17117 = _5;

    /** eds.e:1435		current_db = -1*/
    _43current_db_17115 = -1;

    /** eds.e:1436		key_pointers = {}*/
    RefDS(_5);
    DeRef(_43key_pointers_17122);
    _43key_pointers_17122 = _5;

    /** eds.e:1437	end procedure*/
    return;
    ;
}


object _43table_find(object _name_18318)
{
    object _tables_18319 = NOVALUE;
    object _nt_18320 = NOVALUE;
    object _t_header_18321 = NOVALUE;
    object _name_ptr_18322 = NOVALUE;
    object _seek_1__tmp_at6_18325 = NOVALUE;
    object _seek_inlined_seek_at_6_18324 = NOVALUE;
    object _seek_1__tmp_at44_18332 = NOVALUE;
    object _seek_inlined_seek_at_44_18331 = NOVALUE;
    object _seek_1__tmp_at84_18340 = NOVALUE;
    object _seek_inlined_seek_at_84_18339 = NOVALUE;
    object _seek_1__tmp_at106_18344 = NOVALUE;
    object _seek_inlined_seek_at_106_18343 = NOVALUE;
    object _10350 = NOVALUE;
    object _10348 = NOVALUE;
    object _10343 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1446		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_18325);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at6_18325 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_18324 = machine(19, _seek_1__tmp_at6_18325);
    DeRefi(_seek_1__tmp_at6_18325);
    _seek_1__tmp_at6_18325 = NOVALUE;

    /** eds.e:1447		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_43vLastErrors_17139)){
            _10343 = SEQ_PTR(_43vLastErrors_17139)->length;
    }
    else {
        _10343 = 1;
    }
    if (_10343 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_18318);
    DeRef(_tables_18319);
    DeRef(_nt_18320);
    DeRef(_t_header_18321);
    DeRef(_name_ptr_18322);
    return -1;
L1: 

    /** eds.e:1448		tables = get4()*/
    _0 = _tables_18319;
    _tables_18319 = _43get4();
    DeRef(_0);

    /** eds.e:1449		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18319);
    DeRef(_seek_1__tmp_at44_18332);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _tables_18319;
    _seek_1__tmp_at44_18332 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_18331 = machine(19, _seek_1__tmp_at44_18332);
    DeRef(_seek_1__tmp_at44_18332);
    _seek_1__tmp_at44_18332 = NOVALUE;

    /** eds.e:1450		nt = get4()*/
    _0 = _nt_18320;
    _nt_18320 = _43get4();
    DeRef(_0);

    /** eds.e:1451		t_header = tables+4*/
    DeRef(_t_header_18321);
    if (IS_ATOM_INT(_tables_18319)) {
        _t_header_18321 = _tables_18319 + 4;
        if ((object)((uintptr_t)_t_header_18321 + (uintptr_t)HIGH_BITS) >= 0){
            _t_header_18321 = NewDouble((eudouble)_t_header_18321);
        }
    }
    else {
        _t_header_18321 = NewDouble(DBL_PTR(_tables_18319)->dbl + (eudouble)4);
    }

    /** eds.e:1452		for i = 1 to nt do*/
    Ref(_nt_18320);
    DeRef(_10348);
    _10348 = _nt_18320;
    {
        object _i_18336;
        _i_18336 = 1;
L2: 
        if (binary_op_a(GREATER, _i_18336, _10348)){
            goto L3; // [74] 150
        }

        /** eds.e:1453			io:seek(current_db, t_header)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_18321);
        DeRef(_seek_1__tmp_at84_18340);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_17115;
        ((intptr_t *)_2)[2] = _t_header_18321;
        _seek_1__tmp_at84_18340 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_18339 = machine(19, _seek_1__tmp_at84_18340);
        DeRef(_seek_1__tmp_at84_18340);
        _seek_1__tmp_at84_18340 = NOVALUE;

        /** eds.e:1454			name_ptr = get4()*/
        _0 = _name_ptr_18322;
        _name_ptr_18322 = _43get4();
        DeRef(_0);

        /** eds.e:1455			io:seek(current_db, name_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_18322);
        DeRef(_seek_1__tmp_at106_18344);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_17115;
        ((intptr_t *)_2)[2] = _name_ptr_18322;
        _seek_1__tmp_at106_18344 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_18343 = machine(19, _seek_1__tmp_at106_18344);
        DeRef(_seek_1__tmp_at106_18344);
        _seek_1__tmp_at106_18344 = NOVALUE;

        /** eds.e:1456			if equal_string(name) > 0 then*/
        RefDS(_name_18318);
        _10350 = _43equal_string(_name_18318);
        if (binary_op_a(LESSEQ, _10350, 0)){
            DeRef(_10350);
            _10350 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10350);
        _10350 = NOVALUE;

        /** eds.e:1458				return t_header*/
        DeRef(_i_18336);
        DeRefDS(_name_18318);
        DeRef(_tables_18319);
        DeRef(_nt_18320);
        DeRef(_name_ptr_18322);
        return _t_header_18321;
L4: 

        /** eds.e:1460			t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_18321;
        if (IS_ATOM_INT(_t_header_18321)) {
            _t_header_18321 = _t_header_18321 + 16;
            if ((object)((uintptr_t)_t_header_18321 + (uintptr_t)HIGH_BITS) >= 0){
                _t_header_18321 = NewDouble((eudouble)_t_header_18321);
            }
        }
        else {
            _t_header_18321 = NewDouble(DBL_PTR(_t_header_18321)->dbl + (eudouble)16);
        }
        DeRef(_0);

        /** eds.e:1461		end for*/
        _0 = _i_18336;
        if (IS_ATOM_INT(_i_18336)) {
            _i_18336 = _i_18336 + 1;
            if ((object)((uintptr_t)_i_18336 +(uintptr_t) HIGH_BITS) >= 0){
                _i_18336 = NewDouble((eudouble)_i_18336);
            }
        }
        else {
            _i_18336 = binary_op_a(PLUS, _i_18336, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_18336);
    }

    /** eds.e:1462		return -1*/
    DeRefDS(_name_18318);
    DeRef(_tables_18319);
    DeRef(_nt_18320);
    DeRef(_t_header_18321);
    DeRef(_name_ptr_18322);
    return -1;
    ;
}


object _43db_select_table(object _name_18351)
{
    object _table_18352 = NOVALUE;
    object _nkeys_18353 = NOVALUE;
    object _index_18354 = NOVALUE;
    object _block_ptr_18355 = NOVALUE;
    object _block_size_18356 = NOVALUE;
    object _blocks_18357 = NOVALUE;
    object _k_18358 = NOVALUE;
    object _seek_1__tmp_at120_18377 = NOVALUE;
    object _seek_inlined_seek_at_120_18376 = NOVALUE;
    object _pos_inlined_seek_at_117_18375 = NOVALUE;
    object _seek_1__tmp_at178_18387 = NOVALUE;
    object _seek_inlined_seek_at_178_18386 = NOVALUE;
    object _seek_1__tmp_at205_18392 = NOVALUE;
    object _seek_inlined_seek_at_205_18391 = NOVALUE;
    object _10371 = NOVALUE;
    object _10370 = NOVALUE;
    object _10367 = NOVALUE;
    object _10362 = NOVALUE;
    object _10357 = NOVALUE;
    object _10353 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1501		if equal(current_table_name, name) then*/
    if (_43current_table_name_17117 == _name_18351)
    _10353 = 1;
    else if (IS_ATOM_INT(_43current_table_name_17117) && IS_ATOM_INT(_name_18351))
    _10353 = 0;
    else
    _10353 = (compare(_43current_table_name_17117, _name_18351) == 0);
    if (_10353 == 0)
    {
        _10353 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10353 = NOVALUE;
    }

    /** eds.e:1502			return DB_OK*/
    DeRefDS(_name_18351);
    DeRef(_table_18352);
    DeRef(_nkeys_18353);
    DeRef(_index_18354);
    DeRef(_block_ptr_18355);
    DeRef(_block_size_18356);
    return 0;
L1: 

    /** eds.e:1504		table = table_find(name)*/
    RefDS(_name_18351);
    _0 = _table_18352;
    _table_18352 = _43table_find(_name_18351);
    DeRef(_0);

    /** eds.e:1505		if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18352, -1)){
        goto L2; // [29] 40
    }

    /** eds.e:1506			return DB_OPEN_FAIL*/
    DeRefDS(_name_18351);
    DeRef(_table_18352);
    DeRef(_nkeys_18353);
    DeRef(_index_18354);
    DeRef(_block_ptr_18355);
    DeRef(_block_size_18356);
    return -1;
L2: 

    /** eds.e:1509		save_keys()*/
    _43save_keys();

    /** eds.e:1511		current_table_pos = table*/
    Ref(_table_18352);
    DeRef(_43current_table_pos_17116);
    _43current_table_pos_17116 = _table_18352;

    /** eds.e:1512		current_table_name = name*/
    RefDS(_name_18351);
    DeRef(_43current_table_name_17117);
    _43current_table_name_17117 = _name_18351;

    /** eds.e:1514		k = 0*/
    _k_18358 = 0;

    /** eds.e:1515		if caching_option = 1 then*/

    /** eds.e:1516			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_43current_table_pos_17116);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _43current_table_pos_17116;
    _10357 = MAKE_SEQ(_1);
    _k_18358 = find_from(_10357, _43cache_index_17124, 1);
    DeRefDS(_10357);
    _10357 = NOVALUE;

    /** eds.e:1517			if k != 0 then*/
    if (_k_18358 == 0)
    goto L3; // [88] 103

    /** eds.e:1518				key_pointers = key_cache[k]*/
    DeRef(_43key_pointers_17122);
    _2 = (object)SEQ_PTR(_43key_cache_17123);
    _43key_pointers_17122 = (object)*(((s1_ptr)_2)->base + _k_18358);
    Ref(_43key_pointers_17122);
L3: 

    /** eds.e:1521		if k = 0 then*/
    if (_k_18358 != 0)
    goto L4; // [106] 269

    /** eds.e:1523			io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18352)) {
        _10362 = _table_18352 + 4;
        if ((object)((uintptr_t)_10362 + (uintptr_t)HIGH_BITS) >= 0){
            _10362 = NewDouble((eudouble)_10362);
        }
    }
    else {
        _10362 = NewDouble(DBL_PTR(_table_18352)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_117_18375);
    _pos_inlined_seek_at_117_18375 = _10362;
    _10362 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_18375);
    DeRef(_seek_1__tmp_at120_18377);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_117_18375;
    _seek_1__tmp_at120_18377 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_18376 = machine(19, _seek_1__tmp_at120_18377);
    DeRef(_pos_inlined_seek_at_117_18375);
    _pos_inlined_seek_at_117_18375 = NOVALUE;
    DeRef(_seek_1__tmp_at120_18377);
    _seek_1__tmp_at120_18377 = NOVALUE;

    /** eds.e:1524			nkeys = get4()*/
    _0 = _nkeys_18353;
    _nkeys_18353 = _43get4();
    DeRef(_0);

    /** eds.e:1525			blocks = get4()*/
    _blocks_18357 = _43get4();
    if (!IS_ATOM_INT(_blocks_18357)) {
        _1 = (object)(DBL_PTR(_blocks_18357)->dbl);
        DeRefDS(_blocks_18357);
        _blocks_18357 = _1;
    }

    /** eds.e:1526			index = get4()*/
    _0 = _index_18354;
    _index_18354 = _43get4();
    DeRef(_0);

    /** eds.e:1527			key_pointers = repeat(0, nkeys)*/
    DeRef(_43key_pointers_17122);
    _43key_pointers_17122 = Repeat(0, _nkeys_18353);

    /** eds.e:1528			k = 1*/
    _k_18358 = 1;

    /** eds.e:1529			for b = 0 to blocks-1 do*/
    _10367 = _blocks_18357 - 1;
    if ((object)((uintptr_t)_10367 +(uintptr_t) HIGH_BITS) >= 0){
        _10367 = NewDouble((eudouble)_10367);
    }
    {
        object _b_18383;
        _b_18383 = 0;
L5: 
        if (binary_op_a(GREATER, _b_18383, _10367)){
            goto L6; // [168] 268
        }

        /** eds.e:1530				io:seek(current_db, index)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_18354);
        DeRef(_seek_1__tmp_at178_18387);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_17115;
        ((intptr_t *)_2)[2] = _index_18354;
        _seek_1__tmp_at178_18387 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_18386 = machine(19, _seek_1__tmp_at178_18387);
        DeRef(_seek_1__tmp_at178_18387);
        _seek_1__tmp_at178_18387 = NOVALUE;

        /** eds.e:1531				block_size = get4()*/
        _0 = _block_size_18356;
        _block_size_18356 = _43get4();
        DeRef(_0);

        /** eds.e:1532				block_ptr = get4()*/
        _0 = _block_ptr_18355;
        _block_ptr_18355 = _43get4();
        DeRef(_0);

        /** eds.e:1533				io:seek(current_db, block_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_18355);
        DeRef(_seek_1__tmp_at205_18392);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_17115;
        ((intptr_t *)_2)[2] = _block_ptr_18355;
        _seek_1__tmp_at205_18392 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_18391 = machine(19, _seek_1__tmp_at205_18392);
        DeRef(_seek_1__tmp_at205_18392);
        _seek_1__tmp_at205_18392 = NOVALUE;

        /** eds.e:1534				for j = 1 to block_size do*/
        Ref(_block_size_18356);
        DeRef(_10370);
        _10370 = _block_size_18356;
        {
            object _j_18394;
            _j_18394 = 1;
L7: 
            if (binary_op_a(GREATER, _j_18394, _10370)){
                goto L8; // [224] 255
            }

            /** eds.e:1535					key_pointers[k] = get4()*/
            _10371 = _43get4();
            _2 = (object)SEQ_PTR(_43key_pointers_17122);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _43key_pointers_17122 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _k_18358);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _10371;
            if( _1 != _10371 ){
                DeRef(_1);
            }
            _10371 = NOVALUE;

            /** eds.e:1536					k += 1*/
            _k_18358 = _k_18358 + 1;

            /** eds.e:1537				end for*/
            _0 = _j_18394;
            if (IS_ATOM_INT(_j_18394)) {
                _j_18394 = _j_18394 + 1;
                if ((object)((uintptr_t)_j_18394 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_18394 = NewDouble((eudouble)_j_18394);
                }
            }
            else {
                _j_18394 = binary_op_a(PLUS, _j_18394, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_18394);
        }

        /** eds.e:1538				index += 8*/
        _0 = _index_18354;
        if (IS_ATOM_INT(_index_18354)) {
            _index_18354 = _index_18354 + 8;
            if ((object)((uintptr_t)_index_18354 + (uintptr_t)HIGH_BITS) >= 0){
                _index_18354 = NewDouble((eudouble)_index_18354);
            }
        }
        else {
            _index_18354 = NewDouble(DBL_PTR(_index_18354)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** eds.e:1539			end for*/
        _0 = _b_18383;
        if (IS_ATOM_INT(_b_18383)) {
            _b_18383 = _b_18383 + 1;
            if ((object)((uintptr_t)_b_18383 +(uintptr_t) HIGH_BITS) >= 0){
                _b_18383 = NewDouble((eudouble)_b_18383);
            }
        }
        else {
            _b_18383 = binary_op_a(PLUS, _b_18383, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_18383);
    }
L4: 

    /** eds.e:1541		return DB_OK*/
    DeRefDS(_name_18351);
    DeRef(_table_18352);
    DeRef(_nkeys_18353);
    DeRef(_index_18354);
    DeRef(_block_ptr_18355);
    DeRef(_block_size_18356);
    DeRef(_10367);
    _10367 = NOVALUE;
    return 0;
    ;
}


object _43db_table_list()
{
    object _seek_1__tmp_at120_18774 = NOVALUE;
    object _seek_inlined_seek_at_120_18773 = NOVALUE;
    object _seek_1__tmp_at98_18770 = NOVALUE;
    object _seek_inlined_seek_at_98_18769 = NOVALUE;
    object _pos_inlined_seek_at_95_18768 = NOVALUE;
    object _seek_1__tmp_at42_18758 = NOVALUE;
    object _seek_inlined_seek_at_42_18757 = NOVALUE;
    object _seek_1__tmp_at4_18751 = NOVALUE;
    object _seek_inlined_seek_at_4_18750 = NOVALUE;
    object _table_names_18745 = NOVALUE;
    object _tables_18746 = NOVALUE;
    object _nt_18747 = NOVALUE;
    object _name_18748 = NOVALUE;
    object _10515 = NOVALUE;
    object _10514 = NOVALUE;
    object _10512 = NOVALUE;
    object _10511 = NOVALUE;
    object _10510 = NOVALUE;
    object _10509 = NOVALUE;
    object _10504 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1923		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18751);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at4_18751 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18750 = machine(19, _seek_1__tmp_at4_18751);
    DeRefi(_seek_1__tmp_at4_18751);
    _seek_1__tmp_at4_18751 = NOVALUE;

    /** eds.e:1924		if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_43vLastErrors_17139)){
            _10504 = SEQ_PTR(_43vLastErrors_17139)->length;
    }
    else {
        _10504 = 1;
    }
    if (_10504 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_18745);
    DeRef(_tables_18746);
    DeRef(_nt_18747);
    DeRef(_name_18748);
    return _5;
L1: 

    /** eds.e:1925		tables = get4()*/
    _0 = _tables_18746;
    _tables_18746 = _43get4();
    DeRef(_0);

    /** eds.e:1926		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18746);
    DeRef(_seek_1__tmp_at42_18758);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _tables_18746;
    _seek_1__tmp_at42_18758 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_18757 = machine(19, _seek_1__tmp_at42_18758);
    DeRef(_seek_1__tmp_at42_18758);
    _seek_1__tmp_at42_18758 = NOVALUE;

    /** eds.e:1927		nt = get4()*/
    _0 = _nt_18747;
    _nt_18747 = _43get4();
    DeRef(_0);

    /** eds.e:1928		table_names = repeat(0, nt)*/
    DeRef(_table_names_18745);
    _table_names_18745 = Repeat(0, _nt_18747);

    /** eds.e:1929		for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_18747)) {
        _10509 = _nt_18747 - 1;
        if ((object)((uintptr_t)_10509 +(uintptr_t) HIGH_BITS) >= 0){
            _10509 = NewDouble((eudouble)_10509);
        }
    }
    else {
        _10509 = NewDouble(DBL_PTR(_nt_18747)->dbl - (eudouble)1);
    }
    {
        object _i_18762;
        _i_18762 = 0;
L2: 
        if (binary_op_a(GREATER, _i_18762, _10509)){
            goto L3; // [73] 154
        }

        /** eds.e:1930			io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_18746)) {
            _10510 = _tables_18746 + 4;
            if ((object)((uintptr_t)_10510 + (uintptr_t)HIGH_BITS) >= 0){
                _10510 = NewDouble((eudouble)_10510);
            }
        }
        else {
            _10510 = NewDouble(DBL_PTR(_tables_18746)->dbl + (eudouble)4);
        }
        if (IS_ATOM_INT(_i_18762)) {
            if (_i_18762 == (short)_i_18762){
                _10511 = _i_18762 * 16;
            }
            else{
                _10511 = NewDouble(_i_18762 * (eudouble)16);
            }
        }
        else {
            _10511 = NewDouble(DBL_PTR(_i_18762)->dbl * (eudouble)16);
        }
        if (IS_ATOM_INT(_10510) && IS_ATOM_INT(_10511)) {
            _10512 = _10510 + _10511;
            if ((object)((uintptr_t)_10512 + (uintptr_t)HIGH_BITS) >= 0){
                _10512 = NewDouble((eudouble)_10512);
            }
        }
        else {
            if (IS_ATOM_INT(_10510)) {
                _10512 = NewDouble((eudouble)_10510 + DBL_PTR(_10511)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10511)) {
                    _10512 = NewDouble(DBL_PTR(_10510)->dbl + (eudouble)_10511);
                }
                else
                _10512 = NewDouble(DBL_PTR(_10510)->dbl + DBL_PTR(_10511)->dbl);
            }
        }
        DeRef(_10510);
        _10510 = NOVALUE;
        DeRef(_10511);
        _10511 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_18768);
        _pos_inlined_seek_at_95_18768 = _10512;
        _10512 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_18768);
        DeRef(_seek_1__tmp_at98_18770);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_17115;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_95_18768;
        _seek_1__tmp_at98_18770 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_18769 = machine(19, _seek_1__tmp_at98_18770);
        DeRef(_pos_inlined_seek_at_95_18768);
        _pos_inlined_seek_at_95_18768 = NOVALUE;
        DeRef(_seek_1__tmp_at98_18770);
        _seek_1__tmp_at98_18770 = NOVALUE;

        /** eds.e:1931			name = get4()*/
        _0 = _name_18748;
        _name_18748 = _43get4();
        DeRef(_0);

        /** eds.e:1932			io:seek(current_db, name)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_18748);
        DeRef(_seek_1__tmp_at120_18774);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _43current_db_17115;
        ((intptr_t *)_2)[2] = _name_18748;
        _seek_1__tmp_at120_18774 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_18773 = machine(19, _seek_1__tmp_at120_18774);
        DeRef(_seek_1__tmp_at120_18774);
        _seek_1__tmp_at120_18774 = NOVALUE;

        /** eds.e:1933			table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_18762)) {
            _10514 = _i_18762 + 1;
            if (_10514 > MAXINT){
                _10514 = NewDouble((eudouble)_10514);
            }
        }
        else
        _10514 = binary_op(PLUS, 1, _i_18762);
        _10515 = _43get_string();
        _2 = (object)SEQ_PTR(_table_names_18745);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _table_names_18745 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10514))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_10514)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _10514);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _10515;
        if( _1 != _10515 ){
            DeRef(_1);
        }
        _10515 = NOVALUE;

        /** eds.e:1934		end for*/
        _0 = _i_18762;
        if (IS_ATOM_INT(_i_18762)) {
            _i_18762 = _i_18762 + 1;
            if ((object)((uintptr_t)_i_18762 +(uintptr_t) HIGH_BITS) >= 0){
                _i_18762 = NewDouble((eudouble)_i_18762);
            }
        }
        else {
            _i_18762 = binary_op_a(PLUS, _i_18762, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_18762);
    }

    /** eds.e:1935		return table_names*/
    DeRef(_tables_18746);
    DeRef(_nt_18747);
    DeRef(_name_18748);
    DeRef(_10509);
    _10509 = NOVALUE;
    DeRef(_10514);
    _10514 = NOVALUE;
    return _table_names_18745;
    ;
}


object _43key_value(object _ptr_18779)
{
    object _seek_1__tmp_at11_18784 = NOVALUE;
    object _seek_inlined_seek_at_11_18783 = NOVALUE;
    object _pos_inlined_seek_at_8_18782 = NOVALUE;
    object _10517 = NOVALUE;
    object _10516 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1941		io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_18779)) {
        _10516 = _ptr_18779 + 4;
        if ((object)((uintptr_t)_10516 + (uintptr_t)HIGH_BITS) >= 0){
            _10516 = NewDouble((eudouble)_10516);
        }
    }
    else {
        _10516 = NewDouble(DBL_PTR(_ptr_18779)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_8_18782);
    _pos_inlined_seek_at_8_18782 = _10516;
    _10516 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18782);
    DeRef(_seek_1__tmp_at11_18784);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_18782;
    _seek_1__tmp_at11_18784 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18783 = machine(19, _seek_1__tmp_at11_18784);
    DeRef(_pos_inlined_seek_at_8_18782);
    _pos_inlined_seek_at_8_18782 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18784);
    _seek_1__tmp_at11_18784 = NOVALUE;

    /** eds.e:1942		return decompress(0)*/
    _10517 = _43decompress(0);
    DeRef(_ptr_18779);
    return _10517;
    ;
}


object _43db_find_key(object _key_18788, object _table_name_18789)
{
    object _lo_18790 = NOVALUE;
    object _hi_18791 = NOVALUE;
    object _mid_18792 = NOVALUE;
    object _c_18793 = NOVALUE;
    object _10541 = NOVALUE;
    object _10533 = NOVALUE;
    object _10532 = NOVALUE;
    object _10530 = NOVALUE;
    object _10527 = NOVALUE;
    object _10524 = NOVALUE;
    object _10520 = NOVALUE;
    object _10518 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2003		if not equal(table_name, current_table_name) then*/
    if (_table_name_18789 == _43current_table_name_17117)
    _10518 = 1;
    else if (IS_ATOM_INT(_table_name_18789) && IS_ATOM_INT(_43current_table_name_17117))
    _10518 = 0;
    else
    _10518 = (compare(_table_name_18789, _43current_table_name_17117) == 0);
    if (_10518 != 0)
    goto L1; // [9] 42
    _10518 = NOVALUE;

    /** eds.e:2004			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18789);
    _10520 = _43db_select_table(_table_name_18789);
    if (binary_op_a(EQUALS, _10520, 0)){
        DeRef(_10520);
        _10520 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10520);
    _10520 = NOVALUE;

    /** eds.e:2005				fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_18789);
    Ref(_key_18788);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_18788;
    ((intptr_t *)_2)[2] = _table_name_18789;
    _10524 = MAKE_SEQ(_1);
    RefDS(_10522);
    RefDS(_10523);
    _43fatal(903, _10522, _10523, _10524);
    _10524 = NOVALUE;

    /** eds.e:2006				return 0*/
    DeRef(_key_18788);
    DeRefDS(_table_name_18789);
    return 0;
L2: 
L1: 

    /** eds.e:2010		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_17116, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2011			fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_18789);
    Ref(_key_18788);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_18788;
    ((intptr_t *)_2)[2] = _table_name_18789;
    _10527 = MAKE_SEQ(_1);
    RefDS(_10526);
    RefDS(_10523);
    _43fatal(903, _10526, _10523, _10527);
    _10527 = NOVALUE;

    /** eds.e:2012			return 0*/
    DeRef(_key_18788);
    DeRef(_table_name_18789);
    return 0;
L3: 

    /** eds.e:2015		lo = 1*/
    _lo_18790 = 1;

    /** eds.e:2016		hi = length(key_pointers)*/
    if (IS_SEQUENCE(_43key_pointers_17122)){
            _hi_18791 = SEQ_PTR(_43key_pointers_17122)->length;
    }
    else {
        _hi_18791 = 1;
    }

    /** eds.e:2017		mid = 1*/
    _mid_18792 = 1;

    /** eds.e:2018		c = 0*/
    _c_18793 = 0;

    /** eds.e:2019		while lo <= hi do*/
L4: 
    if (_lo_18790 > _hi_18791)
    goto L5; // [96] 170

    /** eds.e:2020			mid = floor((lo + hi) / 2)*/
    _10530 = _lo_18790 + _hi_18791;
    if ((object)((uintptr_t)_10530 + (uintptr_t)HIGH_BITS) >= 0){
        _10530 = NewDouble((eudouble)_10530);
    }
    if (IS_ATOM_INT(_10530)) {
        _mid_18792 = _10530 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10530, 2);
        _mid_18792 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10530);
    _10530 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18792)) {
        _1 = (object)(DBL_PTR(_mid_18792)->dbl);
        DeRefDS(_mid_18792);
        _mid_18792 = _1;
    }

    /** eds.e:2021			c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (object)SEQ_PTR(_43key_pointers_17122);
    _10532 = (object)*(((s1_ptr)_2)->base + _mid_18792);
    Ref(_10532);
    _10533 = _43key_value(_10532);
    _10532 = NOVALUE;
    if (IS_ATOM_INT(_key_18788) && IS_ATOM_INT(_10533)){
        _c_18793 = (_key_18788 < _10533) ? -1 : (_key_18788 > _10533);
    }
    else{
        _c_18793 = compare(_key_18788, _10533);
    }
    DeRef(_10533);
    _10533 = NOVALUE;

    /** eds.e:2022			if c < 0 then*/
    if (_c_18793 >= 0)
    goto L6; // [130] 143

    /** eds.e:2023				hi = mid - 1*/
    _hi_18791 = _mid_18792 - 1;
    goto L4; // [140] 96
L6: 

    /** eds.e:2024			elsif c > 0 then*/
    if (_c_18793 <= 0)
    goto L7; // [145] 158

    /** eds.e:2025				lo = mid + 1*/
    _lo_18790 = _mid_18792 + 1;
    goto L4; // [155] 96
L7: 

    /** eds.e:2027				return mid*/
    DeRef(_key_18788);
    DeRef(_table_name_18789);
    return _mid_18792;

    /** eds.e:2029		end while*/
    goto L4; // [167] 96
L5: 

    /** eds.e:2031		if c > 0 then*/
    if (_c_18793 <= 0)
    goto L8; // [172] 183

    /** eds.e:2032			mid += 1*/
    _mid_18792 = _mid_18792 + 1;
L8: 

    /** eds.e:2034		return -mid*/
    if ((uintptr_t)_mid_18792 == (uintptr_t)HIGH_BITS){
        _10541 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _10541 = - _mid_18792;
    }
    DeRef(_key_18788);
    DeRef(_table_name_18789);
    return _10541;
    ;
}


object _43db_table_size(object _table_name_19199)
{
    object _10720 = NOVALUE;
    object _10719 = NOVALUE;
    object _10717 = NOVALUE;
    object _10714 = NOVALUE;
    object _10712 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2369		if not equal(table_name, current_table_name) then*/
    if (_table_name_19199 == _43current_table_name_17117)
    _10712 = 1;
    else if (IS_ATOM_INT(_table_name_19199) && IS_ATOM_INT(_43current_table_name_17117))
    _10712 = 0;
    else
    _10712 = (compare(_table_name_19199, _43current_table_name_17117) == 0);
    if (_10712 != 0)
    goto L1; // [9] 42
    _10712 = NOVALUE;

    /** eds.e:2370			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19199);
    _10714 = _43db_select_table(_table_name_19199);
    if (binary_op_a(EQUALS, _10714, 0)){
        DeRef(_10714);
        _10714 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10714);
    _10714 = NOVALUE;

    /** eds.e:2371				fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_19199);
    ((intptr_t*)_2)[1] = _table_name_19199;
    _10717 = MAKE_SEQ(_1);
    RefDS(_10522);
    RefDS(_10716);
    _43fatal(903, _10522, _10716, _10717);
    _10717 = NOVALUE;

    /** eds.e:2372				return -1*/
    DeRefDS(_table_name_19199);
    return -1;
L2: 
L1: 

    /** eds.e:2376		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_17116, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2377			fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_table_name_19199);
    ((intptr_t*)_2)[1] = _table_name_19199;
    _10719 = MAKE_SEQ(_1);
    RefDS(_10526);
    RefDS(_10716);
    _43fatal(903, _10526, _10716, _10719);
    _10719 = NOVALUE;

    /** eds.e:2378			return -1*/
    DeRef(_table_name_19199);
    return -1;
L3: 

    /** eds.e:2380		return length(key_pointers)*/
    if (IS_SEQUENCE(_43key_pointers_17122)){
            _10720 = SEQ_PTR(_43key_pointers_17122)->length;
    }
    else {
        _10720 = 1;
    }
    DeRef(_table_name_19199);
    return _10720;
    ;
}


object _43db_record_data(object _key_location_19214, object _table_name_19215)
{
    object _data_ptr_19216 = NOVALUE;
    object _data_value_19217 = NOVALUE;
    object _seek_1__tmp_at126_19239 = NOVALUE;
    object _seek_inlined_seek_at_126_19238 = NOVALUE;
    object _pos_inlined_seek_at_123_19237 = NOVALUE;
    object _seek_1__tmp_at164_19246 = NOVALUE;
    object _seek_inlined_seek_at_164_19245 = NOVALUE;
    object _10735 = NOVALUE;
    object _10734 = NOVALUE;
    object _10733 = NOVALUE;
    object _10732 = NOVALUE;
    object _10731 = NOVALUE;
    object _10729 = NOVALUE;
    object _10728 = NOVALUE;
    object _10726 = NOVALUE;
    object _10723 = NOVALUE;
    object _10721 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19214)) {
        _1 = (object)(DBL_PTR(_key_location_19214)->dbl);
        DeRefDS(_key_location_19214);
        _key_location_19214 = _1;
    }

    /** eds.e:2417		if not equal(table_name, current_table_name) then*/
    if (_table_name_19215 == _43current_table_name_17117)
    _10721 = 1;
    else if (IS_ATOM_INT(_table_name_19215) && IS_ATOM_INT(_43current_table_name_17117))
    _10721 = 0;
    else
    _10721 = (compare(_table_name_19215, _43current_table_name_17117) == 0);
    if (_10721 != 0)
    goto L1; // [11] 44
    _10721 = NOVALUE;

    /** eds.e:2418			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19215);
    _10723 = _43db_select_table(_table_name_19215);
    if (binary_op_a(EQUALS, _10723, 0)){
        DeRef(_10723);
        _10723 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10723);
    _10723 = NOVALUE;

    /** eds.e:2419				fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_19215);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_19214;
    ((intptr_t *)_2)[2] = _table_name_19215;
    _10726 = MAKE_SEQ(_1);
    RefDS(_10522);
    RefDS(_10725);
    _43fatal(903, _10522, _10725, _10726);
    _10726 = NOVALUE;

    /** eds.e:2420				return -1*/
    DeRefDS(_table_name_19215);
    DeRef(_data_ptr_19216);
    DeRef(_data_value_19217);
    return -1;
L2: 
L1: 

    /** eds.e:2424		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_17116, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2425			fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19215);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_19214;
    ((intptr_t *)_2)[2] = _table_name_19215;
    _10728 = MAKE_SEQ(_1);
    RefDS(_10526);
    RefDS(_10725);
    _43fatal(903, _10526, _10725, _10728);
    _10728 = NOVALUE;

    /** eds.e:2426			return -1*/
    DeRef(_table_name_19215);
    DeRef(_data_ptr_19216);
    DeRef(_data_value_19217);
    return -1;
L3: 

    /** eds.e:2428		if key_location < 1 or key_location > length(key_pointers) then*/
    _10729 = (_key_location_19214 < 1);
    if (_10729 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_43key_pointers_17122)){
            _10731 = SEQ_PTR(_43key_pointers_17122)->length;
    }
    else {
        _10731 = 1;
    }
    _10732 = (_key_location_19214 > _10731);
    _10731 = NOVALUE;
    if (_10732 == 0)
    {
        DeRef(_10732);
        _10732 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10732);
        _10732 = NOVALUE;
    }
L4: 

    /** eds.e:2429			fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19215);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_19214;
    ((intptr_t *)_2)[2] = _table_name_19215;
    _10733 = MAKE_SEQ(_1);
    RefDS(_10650);
    RefDS(_10725);
    _43fatal(905, _10650, _10725, _10733);
    _10733 = NOVALUE;

    /** eds.e:2430			return -1*/
    DeRef(_table_name_19215);
    DeRef(_data_ptr_19216);
    DeRef(_data_value_19217);
    DeRef(_10729);
    _10729 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2433		io:seek(current_db, key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_43key_pointers_17122);
    _10734 = (object)*(((s1_ptr)_2)->base + _key_location_19214);
    Ref(_10734);
    DeRef(_pos_inlined_seek_at_123_19237);
    _pos_inlined_seek_at_123_19237 = _10734;
    _10734 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_19237);
    DeRef(_seek_1__tmp_at126_19239);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_123_19237;
    _seek_1__tmp_at126_19239 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_19238 = machine(19, _seek_1__tmp_at126_19239);
    DeRef(_pos_inlined_seek_at_123_19237);
    _pos_inlined_seek_at_123_19237 = NOVALUE;
    DeRef(_seek_1__tmp_at126_19239);
    _seek_1__tmp_at126_19239 = NOVALUE;

    /** eds.e:2434		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_43vLastErrors_17139)){
            _10735 = SEQ_PTR(_43vLastErrors_17139)->length;
    }
    else {
        _10735 = 1;
    }
    if (_10735 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_19215);
    DeRef(_data_ptr_19216);
    DeRef(_data_value_19217);
    DeRef(_10729);
    _10729 = NOVALUE;
    return -1;
L6: 

    /** eds.e:2435		data_ptr = get4()*/
    _0 = _data_ptr_19216;
    _data_ptr_19216 = _43get4();
    DeRef(_0);

    /** eds.e:2436		io:seek(current_db, data_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_19216);
    DeRef(_seek_1__tmp_at164_19246);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _43current_db_17115;
    ((intptr_t *)_2)[2] = _data_ptr_19216;
    _seek_1__tmp_at164_19246 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_19245 = machine(19, _seek_1__tmp_at164_19246);
    DeRef(_seek_1__tmp_at164_19246);
    _seek_1__tmp_at164_19246 = NOVALUE;

    /** eds.e:2437		data_value = decompress(0)*/
    _0 = _data_value_19217;
    _data_value_19217 = _43decompress(0);
    DeRef(_0);

    /** eds.e:2439		return data_value*/
    DeRef(_table_name_19215);
    DeRef(_data_ptr_19216);
    DeRef(_10729);
    _10729 = NOVALUE;
    return _data_value_19217;
    ;
}


object _43db_fetch_record(object _key_19250, object _table_name_19251)
{
    object _pos_19252 = NOVALUE;
    object _10741 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2481		pos = db_find_key(key, table_name)*/
    Ref(_key_19250);
    RefDS(_table_name_19251);
    _pos_19252 = _43db_find_key(_key_19250, _table_name_19251);
    if (!IS_ATOM_INT(_pos_19252)) {
        _1 = (object)(DBL_PTR(_pos_19252)->dbl);
        DeRefDS(_pos_19252);
        _pos_19252 = _1;
    }

    /** eds.e:2482		if pos > 0 then*/
    if (_pos_19252 <= 0)
    goto L1; // [12] 30

    /** eds.e:2483			return db_record_data(pos, table_name)*/
    RefDS(_table_name_19251);
    _10741 = _43db_record_data(_pos_19252, _table_name_19251);
    DeRef(_key_19250);
    DeRefDS(_table_name_19251);
    return _10741;
    goto L2; // [27] 37
L1: 

    /** eds.e:2485			return pos*/
    DeRef(_key_19250);
    DeRef(_table_name_19251);
    DeRef(_10741);
    _10741 = NOVALUE;
    return _pos_19252;
L2: 
    ;
}


object _43db_record_key(object _key_location_19260, object _table_name_19261)
{
    object _10756 = NOVALUE;
    object _10755 = NOVALUE;
    object _10754 = NOVALUE;
    object _10753 = NOVALUE;
    object _10752 = NOVALUE;
    object _10750 = NOVALUE;
    object _10749 = NOVALUE;
    object _10747 = NOVALUE;
    object _10744 = NOVALUE;
    object _10742 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19260)) {
        _1 = (object)(DBL_PTR(_key_location_19260)->dbl);
        DeRefDS(_key_location_19260);
        _key_location_19260 = _1;
    }

    /** eds.e:2519		if not equal(table_name, current_table_name) then*/
    if (_table_name_19261 == _43current_table_name_17117)
    _10742 = 1;
    else if (IS_ATOM_INT(_table_name_19261) && IS_ATOM_INT(_43current_table_name_17117))
    _10742 = 0;
    else
    _10742 = (compare(_table_name_19261, _43current_table_name_17117) == 0);
    if (_10742 != 0)
    goto L1; // [11] 44
    _10742 = NOVALUE;

    /** eds.e:2520			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19261);
    _10744 = _43db_select_table(_table_name_19261);
    if (binary_op_a(EQUALS, _10744, 0)){
        DeRef(_10744);
        _10744 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10744);
    _10744 = NOVALUE;

    /** eds.e:2521				fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_19261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_19260;
    ((intptr_t *)_2)[2] = _table_name_19261;
    _10747 = MAKE_SEQ(_1);
    RefDS(_10522);
    RefDS(_10746);
    _43fatal(903, _10522, _10746, _10747);
    _10747 = NOVALUE;

    /** eds.e:2522				return -1*/
    DeRefDS(_table_name_19261);
    return -1;
L2: 
L1: 

    /** eds.e:2526		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _43current_table_pos_17116, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2527			fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_19260;
    ((intptr_t *)_2)[2] = _table_name_19261;
    _10749 = MAKE_SEQ(_1);
    RefDS(_10526);
    RefDS(_10746);
    _43fatal(903, _10526, _10746, _10749);
    _10749 = NOVALUE;

    /** eds.e:2528			return -1*/
    DeRef(_table_name_19261);
    return -1;
L3: 

    /** eds.e:2530		if key_location < 1 or key_location > length(key_pointers) then*/
    _10750 = (_key_location_19260 < 1);
    if (_10750 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_43key_pointers_17122)){
            _10752 = SEQ_PTR(_43key_pointers_17122)->length;
    }
    else {
        _10752 = 1;
    }
    _10753 = (_key_location_19260 > _10752);
    _10752 = NOVALUE;
    if (_10753 == 0)
    {
        DeRef(_10753);
        _10753 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10753);
        _10753 = NOVALUE;
    }
L4: 

    /** eds.e:2531			fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19261);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_19260;
    ((intptr_t *)_2)[2] = _table_name_19261;
    _10754 = MAKE_SEQ(_1);
    RefDS(_10650);
    RefDS(_10746);
    _43fatal(905, _10650, _10746, _10754);
    _10754 = NOVALUE;

    /** eds.e:2532			return -1*/
    DeRef(_table_name_19261);
    DeRef(_10750);
    _10750 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2534		return key_value(key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_43key_pointers_17122);
    _10755 = (object)*(((s1_ptr)_2)->base + _key_location_19260);
    Ref(_10755);
    _10756 = _43key_value(_10755);
    _10755 = NOVALUE;
    DeRef(_table_name_19261);
    DeRef(_10750);
    _10750 = NOVALUE;
    return _10756;
    ;
}



// 0x34BCE511
