// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _3extract_options(object _s_64993)
{
    object _0, _1, _2;
    

    /** traninit.e:69		return s*/
    return _s_64993;
    ;
}


void _3transoptions()
{
    object _tranopts_65180 = NOVALUE;
    object _opts_65192 = NOVALUE;
    object _opt_keys_65198 = NOVALUE;
    object _option_w_65200 = NOVALUE;
    object _key_65204 = NOVALUE;
    object _val_65206 = NOVALUE;
    object _tmp_65311 = NOVALUE;
    object _tmp_65331 = NOVALUE;
    object _filetype_65357 = NOVALUE;
    object _32212 = NOVALUE;
    object _32211 = NOVALUE;
    object _32210 = NOVALUE;
    object _32209 = NOVALUE;
    object _32207 = NOVALUE;
    object _32206 = NOVALUE;
    object _32205 = NOVALUE;
    object _32204 = NOVALUE;
    object _32203 = NOVALUE;
    object _32202 = NOVALUE;
    object _32197 = NOVALUE;
    object _32196 = NOVALUE;
    object _32195 = NOVALUE;
    object _32192 = NOVALUE;
    object _32191 = NOVALUE;
    object _32190 = NOVALUE;
    object _32189 = NOVALUE;
    object _32188 = NOVALUE;
    object _32185 = NOVALUE;
    object _32182 = NOVALUE;
    object _32181 = NOVALUE;
    object _32180 = NOVALUE;
    object _32179 = NOVALUE;
    object _32177 = NOVALUE;
    object _32174 = NOVALUE;
    object _32173 = NOVALUE;
    object _32172 = NOVALUE;
    object _32171 = NOVALUE;
    object _32170 = NOVALUE;
    object _32169 = NOVALUE;
    object _32168 = NOVALUE;
    object _32167 = NOVALUE;
    object _32166 = NOVALUE;
    object _32165 = NOVALUE;
    object _32164 = NOVALUE;
    object _32163 = NOVALUE;
    object _32162 = NOVALUE;
    object _32158 = NOVALUE;
    object _32155 = NOVALUE;
    object _32154 = NOVALUE;
    object _32153 = NOVALUE;
    object _32147 = NOVALUE;
    object _32144 = NOVALUE;
    object _32143 = NOVALUE;
    object _32141 = NOVALUE;
    object _32139 = NOVALUE;
    object _32135 = NOVALUE;
    object _32125 = NOVALUE;
    object _32123 = NOVALUE;
    object _32120 = NOVALUE;
    object _32118 = NOVALUE;
    object _32116 = NOVALUE;
    object _32115 = NOVALUE;
    object _32114 = NOVALUE;
    object _32113 = NOVALUE;
    object _32112 = NOVALUE;
    object _32107 = NOVALUE;
    object _32101 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:112		sequence tranopts = sort( get_options() )*/
    _32101 = _49get_options();
    _0 = _tranopts_65180;
    _tranopts_65180 = _24sort(_32101, 1);
    DeRef(_0);
    _32101 = NOVALUE;

    /** traninit.e:114		Argv = expand_config_options( Argv )*/
    RefDS(_36Argv_21778);
    _0 = _49expand_config_options(_36Argv_21778);
    DeRefDS(_36Argv_21778);
    _36Argv_21778 = _0;

    /** traninit.e:115		Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21778)){
            _36Argc_21777 = SEQ_PTR(_36Argv_21778)->length;
    }
    else {
        _36Argc_21777 = 1;
    }

    /** traninit.e:117		map:map opts = cmd_parse( tranopts, NO_HELP_ON_ERROR, Argv)*/
    RefDS(_tranopts_65180);
    RefDS(_36Argv_21778);
    _0 = _opts_65192;
    _opts_65192 = _4cmd_parse(_tranopts_65180, 10, _36Argv_21778);
    DeRef(_0);

    /** traninit.e:119		handle_common_options(opts)*/
    Ref(_opts_65192);
    _49handle_common_options(_opts_65192);

    /** traninit.e:121		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_65192);
    _0 = _opt_keys_65198;
    _opt_keys_65198 = _29keys(_opts_65192, 0);
    DeRef(_0);

    /** traninit.e:122		integer option_w = 0*/
    _option_w_65200 = 0;

    /** traninit.e:124		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_65198)){
            _32107 = SEQ_PTR(_opt_keys_65198)->length;
    }
    else {
        _32107 = 1;
    }
    {
        object _idx_65202;
        _idx_65202 = 1;
L1: 
        if (_idx_65202 > _32107){
            goto L2; // [68] 884
        }

        /** traninit.e:126			sequence key = opt_keys[idx]*/
        DeRef(_key_65204);
        _2 = (object)SEQ_PTR(_opt_keys_65198);
        _key_65204 = (object)*(((s1_ptr)_2)->base + _idx_65202);
        Ref(_key_65204);

        /** traninit.e:127			object val = map:get(opts, key)*/
        Ref(_opts_65192);
        RefDS(_key_65204);
        _0 = _val_65206;
        _val_65206 = _29get(_opts_65192, _key_65204, 0);
        DeRef(_0);

        /** traninit.e:129			switch key do*/
        _1 = find(_key_65204, _32110);
        switch ( _1 ){ 

            /** traninit.e:130				case "silent" then*/
            case 1:

            /** traninit.e:131					silent = TRUE*/
            _36silent_21886 = _13TRUE_447;
            goto L3; // [109] 875

            /** traninit.e:133				case "verbose" then*/
            case 2:

            /** traninit.e:134					verbose = TRUE*/
            _36verbose_21889 = _13TRUE_447;
            goto L3; // [122] 875

            /** traninit.e:136				case "rc-file" then*/
            case 3:

            /** traninit.e:137					rc_file[D_NAME] = canonical_path(val)*/
            Ref(_val_65206);
            _32112 = _17canonical_path(_val_65206, 0, 0);
            _2 = (object)SEQ_PTR(_56rc_file_45718);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45718 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 1);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _32112;
            if( _1 != _32112 ){
                DeRef(_1);
            }
            _32112 = NOVALUE;

            /** traninit.e:138					rc_file[D_ALTNAME] = adjust_for_command_line_passing((rc_file[D_NAME]))*/
            _2 = (object)SEQ_PTR(_56rc_file_45718);
            _32113 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_32113);
            _32114 = _56adjust_for_command_line_passing(_32113);
            _32113 = NOVALUE;
            _2 = (object)SEQ_PTR(_56rc_file_45718);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45718 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 11);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _32114;
            if( _1 != _32114 ){
                DeRef(_1);
            }
            _32114 = NOVALUE;

            /** traninit.e:139					if not file_exists(rc_file[D_NAME]) then*/
            _2 = (object)SEQ_PTR(_56rc_file_45718);
            _32115 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_32115);
            _32116 = _17file_exists(_32115);
            _32115 = NOVALUE;
            if (IS_ATOM_INT(_32116)) {
                if (_32116 != 0){
                    DeRef(_32116);
                    _32116 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            else {
                if (DBL_PTR(_32116)->dbl != 0.0){
                    DeRef(_32116);
                    _32116 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            DeRef(_32116);
            _32116 = NOVALUE;

            /** traninit.e:140						ShowMsg(2, RESOURCE_FILE_DOES_NOT_EXIST__1, { val })*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_val_65206);
            ((intptr_t*)_2)[1] = _val_65206;
            _32118 = MAKE_SEQ(_1);
            _39ShowMsg(2, 349, _32118, 1);
            _32118 = NOVALUE;

            /** traninit.e:141						abort(1)*/
            UserCleanup(1);
            goto L3; // [202] 875

            /** traninit.e:144				case "cflags" then*/
            case 4:

            /** traninit.e:145					cflags = val*/
            Ref(_val_65206);
            DeRef(_56cflags_45727);
            _56cflags_45727 = _val_65206;
            goto L3; // [215] 875

            /** traninit.e:147				case "extra-cflags" then*/
            case 5:

            /** traninit.e:148					extra_cflags = val*/
            Ref(_val_65206);
            DeRef(_56extra_cflags_45728);
            _56extra_cflags_45728 = _val_65206;
            goto L3; // [228] 875

            /** traninit.e:150				case "lflags" then*/
            case 6:

            /** traninit.e:151					lflags = val*/
            Ref(_val_65206);
            DeRef(_56lflags_45729);
            _56lflags_45729 = _val_65206;
            goto L3; // [241] 875

            /** traninit.e:153				case "extra-lflags" then*/
            case 7:

            /** traninit.e:154					extra_lflags = val*/
            Ref(_val_65206);
            DeRef(_56extra_lflags_45730);
            _56extra_lflags_45730 = _val_65206;
            goto L3; // [254] 875

            /** traninit.e:156				case "wat" then*/
            case 8:

            /** traninit.e:157					compiler_type = COMPILER_WATCOM*/
            _56compiler_type_45709 = 2;
            goto L3; // [269] 875

            /** traninit.e:159				case "gcc" then*/
            case 9:

            /** traninit.e:160					compiler_type = COMPILER_GCC*/
            _56compiler_type_45709 = 1;
            goto L3; // [284] 875

            /** traninit.e:162				case "com" then*/
            case 10:

            /** traninit.e:163					compiler_dir = val*/
            Ref(_val_65206);
            DeRef(_56compiler_dir_45711);
            _56compiler_dir_45711 = _val_65206;
            goto L3; // [297] 875

            /** traninit.e:165				case "con" then*/
            case 11:

            /** traninit.e:166					con_option = TRUE*/
            _58con_option_42895 = _13TRUE_447;

            /** traninit.e:167					OpDefines &= { "CONSOLE" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_32119);
            ((intptr_t*)_2)[1] = _32119;
            _32120 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _32120);
            DeRefDS(_32120);
            _32120 = NOVALUE;
            goto L3; // [324] 875

            /** traninit.e:169				case "dll", "so" then*/
            case 12:
            case 13:

            /** traninit.e:170					dll_option = TRUE*/
            _58dll_option_42893 = _13TRUE_447;

            /** traninit.e:171					OpDefines &= { "EUC_DLL" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_32122);
            ((intptr_t*)_2)[1] = _32122;
            _32123 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _32123);
            DeRefDS(_32123);
            _32123 = NOVALUE;
            goto L3; // [353] 875

            /** traninit.e:173				case "plat" then*/
            case 14:

            /** traninit.e:174					switch upper(val) do*/
            Ref(_val_65206);
            _32125 = _14upper(_val_65206);
            _1 = find(_32125, _32126);
            DeRef(_32125);
            _32125 = NOVALUE;
            switch ( _1 ){ 

                /** traninit.e:178						case "WINDOWS" then*/
                case 1:

                /** traninit.e:179							set_host_platform( WIN32 )*/
                _46set_host_platform(2);
                goto L3; // [381] 875

                /** traninit.e:181						case "LINUX" then*/
                case 2:

                /** traninit.e:182							set_host_platform( ULINUX )*/
                _46set_host_platform(3);
                goto L3; // [394] 875

                /** traninit.e:184						case "FREEBSD" then*/
                case 3:

                /** traninit.e:185							set_host_platform( UFREEBSD )*/
                _46set_host_platform(8);
                goto L3; // [407] 875

                /** traninit.e:187						case "OSX" then*/
                case 4:

                /** traninit.e:188							set_host_platform( UOSX )*/
                _46set_host_platform(4);
                goto L3; // [420] 875

                /** traninit.e:190						case "OPENBSD" then*/
                case 5:

                /** traninit.e:191							set_host_platform( UOPENBSD )*/
                _46set_host_platform(6);
                goto L3; // [433] 875

                /** traninit.e:193						case "NETBSD" then*/
                case 6:

                /** traninit.e:194							set_host_platform( UNETBSD )*/
                _46set_host_platform(7);
                goto L3; // [446] 875

                /** traninit.e:196						case else*/
                case 0:

                /** traninit.e:197							ShowMsg(2, UNKNOWN_PLATFORM_1__SUPPORTED_PLATFORMS_ARE_2, { val, "WINDOWS, LINUX, FREEBSD, OSX, OPENBSD, NETBSD" })*/
                RefDS(_32134);
                Ref(_val_65206);
                _1 = NewS1(2);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t *)_2)[1] = _val_65206;
                ((intptr_t *)_2)[2] = _32134;
                _32135 = MAKE_SEQ(_1);
                _39ShowMsg(2, 201, _32135, 1);
                _32135 = NOVALUE;

                /** traninit.e:198							abort(1)*/
                UserCleanup(1);
            ;}            goto L3; // [471] 875

            /** traninit.e:201				case "lib" then*/
            case 15:

            /** traninit.e:202					user_library = canonical_path(val)*/
            Ref(_val_65206);
            _0 = _17canonical_path(_val_65206, 0, 0);
            DeRef(_58user_library_42905);
            _58user_library_42905 = _0;
            goto L3; // [487] 875

            /** traninit.e:204				case "lib-pic" then*/
            case 16:

            /** traninit.e:205					user_pic_library = canonical_path( val )*/
            Ref(_val_65206);
            _0 = _17canonical_path(_val_65206, 0, 0);
            DeRef(_58user_pic_library_42906);
            _58user_pic_library_42906 = _0;
            goto L3; // [503] 875

            /** traninit.e:207				case "stack" then*/
            case 17:

            /** traninit.e:208					sequence tmp = value(val)*/
            Ref(_val_65206);
            _0 = _tmp_65311;
            _tmp_65311 = _6value(_val_65206, 1, _6GET_SHORT_ANSWER_11277);
            DeRef(_0);

            /** traninit.e:209					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_65311);
            _32139 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _32139, 0)){
                _32139 = NOVALUE;
                goto L4; // [529] 561
            }
            _32139 = NOVALUE;

            /** traninit.e:210						if tmp[2] >= 16384 then*/
            _2 = (object)SEQ_PTR(_tmp_65311);
            _32141 = (object)*(((s1_ptr)_2)->base + 2);
            if (binary_op_a(LESS, _32141, 16384)){
                _32141 = NOVALUE;
                goto L5; // [539] 560
            }
            _32141 = NOVALUE;

            /** traninit.e:211							total_stack_size = floor(tmp[2] / 4) * 4*/
            _2 = (object)SEQ_PTR(_tmp_65311);
            _32143 = (object)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_32143)) {
                if (4 > 0 && _32143 >= 0) {
                    _32144 = _32143 / 4;
                }
                else {
                    temp_dbl = EUFLOOR((eudouble)_32143 / (eudouble)4);
                    if (_32143 != MININT)
                    _32144 = (object)temp_dbl;
                    else
                    _32144 = NewDouble(temp_dbl);
                }
            }
            else {
                _2 = binary_op(DIVIDE, _32143, 4);
                _32144 = unary_op(FLOOR, _2);
                DeRef(_2);
            }
            _32143 = NOVALUE;
            if (IS_ATOM_INT(_32144)) {
                _58total_stack_size_42908 = _32144 * 4;
            }
            else {
                _58total_stack_size_42908 = binary_op(MULTIPLY, _32144, 4);
            }
            DeRef(_32144);
            _32144 = NOVALUE;
            if (!IS_ATOM_INT(_58total_stack_size_42908)) {
                _1 = (object)(DBL_PTR(_58total_stack_size_42908)->dbl);
                DeRefDS(_58total_stack_size_42908);
                _58total_stack_size_42908 = _1;
            }
L5: 
L4: 
            DeRef(_tmp_65311);
            _tmp_65311 = NOVALUE;
            goto L3; // [563] 875

            /** traninit.e:215				case "debug" then*/
            case 18:

            /** traninit.e:216					debug_option = TRUE*/
            _58debug_option_42903 = _13TRUE_447;

            /** traninit.e:217					keep = TRUE -- you'll need the sources to debug*/
            _58keep_42900 = _13TRUE_447;
            goto L3; // [583] 875

            /** traninit.e:219				case "maxsize" then*/
            case 19:

            /** traninit.e:220					sequence tmp = value(val)*/
            Ref(_val_65206);
            _0 = _tmp_65331;
            _tmp_65331 = _6value(_val_65206, 1, _6GET_SHORT_ANSWER_11277);
            DeRef(_0);

            /** traninit.e:221					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_65331);
            _32147 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _32147, 0)){
                _32147 = NOVALUE;
                goto L6; // [609] 624
            }
            _32147 = NOVALUE;

            /** traninit.e:222						max_cfile_size = tmp[2]*/
            _2 = (object)SEQ_PTR(_tmp_65331);
            _56max_cfile_size_45725 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_56max_cfile_size_45725)){
                _56max_cfile_size_45725 = (object)DBL_PTR(_56max_cfile_size_45725)->dbl;
            }
            goto L7; // [621] 639
L6: 

            /** traninit.e:224						ShowMsg(2, INVALID_MAXIMUM_FILE_SIZE)*/
            RefDS(_22190);
            _39ShowMsg(2, 202, _22190, 1);

            /** traninit.e:225						abort(1)*/
            UserCleanup(1);
L7: 
            DeRef(_tmp_65331);
            _tmp_65331 = NOVALUE;
            goto L3; // [641] 875

            /** traninit.e:228				case "keep" then*/
            case 20:

            /** traninit.e:229					keep = TRUE*/
            _58keep_42900 = _13TRUE_447;
            goto L3; // [654] 875

            /** traninit.e:231				case "makefile-partial" then*/
            case 21:

            /** traninit.e:232					build_system_type = BUILD_MAKEFILE_PARTIAL*/
            _56build_system_type_45705 = 1;
            goto L3; // [669] 875

            /** traninit.e:234				case "makefile" then*/
            case 22:

            /** traninit.e:235					build_system_type = BUILD_MAKEFILE_FULL*/
            _56build_system_type_45705 = 2;
            goto L3; // [684] 875

            /** traninit.e:237				case "nobuild" then*/
            case 23:

            /** traninit.e:238					build_system_type = BUILD_NONE*/
            _56build_system_type_45705 = 0;
            goto L3; // [699] 875

            /** traninit.e:240				case "build-dir" then*/
            case 24:

            /** traninit.e:241					output_dir = val*/
            Ref(_val_65206);
            DeRef(_58output_dir_42907);
            _58output_dir_42907 = _val_65206;

            /** traninit.e:242					integer filetype = file_type( output_dir )*/
            RefDS(_58output_dir_42907);
            _filetype_65357 = _17file_type(_58output_dir_42907);
            if (!IS_ATOM_INT(_filetype_65357)) {
                _1 = (object)(DBL_PTR(_filetype_65357)->dbl);
                DeRefDS(_filetype_65357);
                _filetype_65357 = _1;
            }

            /** traninit.e:244					if filetype = FILETYPE_FILE then*/
            if (_filetype_65357 != 1)
            goto L8; // [726] 747

            /** traninit.e:245						ShowMsg( 2, BUILDDIR_IS_FILE )*/
            RefDS(_22190);
            _39ShowMsg(2, 605, _22190, 1);

            /** traninit.e:246						abort(1)*/
            UserCleanup(1);
            goto L9; // [744] 771
L8: 

            /** traninit.e:247					elsif filetype = FILETYPE_UNDEFINED then*/
            if (_filetype_65357 != -1)
            goto LA; // [751] 770

            /** traninit.e:248						ShowMsg( 2, BUILDDIR_IS_UNDEFINED )*/
            RefDS(_22190);
            _39ShowMsg(2, 606, _22190, 1);

            /** traninit.e:249						abort(1)*/
            UserCleanup(1);
LA: 
L9: 

            /** traninit.e:251					if find(output_dir[$], "/\\") = 0 then*/
            if (IS_SEQUENCE(_58output_dir_42907)){
                    _32153 = SEQ_PTR(_58output_dir_42907)->length;
            }
            else {
                _32153 = 1;
            }
            _2 = (object)SEQ_PTR(_58output_dir_42907);
            _32154 = (object)*(((s1_ptr)_2)->base + _32153);
            _32155 = find_from(_32154, _24114, 1);
            _32154 = NOVALUE;
            if (_32155 != 0)
            goto LB; // [787] 802

            /** traninit.e:252						output_dir &= '/'*/
            Append(&_58output_dir_42907, _58output_dir_42907, 47);
LB: 
            goto L3; // [804] 875

            /** traninit.e:255				case "force-build" then*/
            case 25:

            /** traninit.e:256					force_build = 1*/
            _56force_build_45731 = 1;
            goto L3; // [817] 875

            /** traninit.e:258				case "o" then*/
            case 26:

            /** traninit.e:259					exe_name[D_NAME] = val*/
            Ref(_val_65206);
            _2 = (object)SEQ_PTR(_56exe_name_45712);
            _2 = (object)(((s1_ptr)_2)->base + 1);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _val_65206;
            DeRef(_1);
            goto L3; // [833] 875

            /** traninit.e:261				case "no-cygwin" then*/
            case 27:

            /** traninit.e:262					mno_cygwin = 1*/
            _56mno_cygwin_45733 = 1;
            goto L3; // [846] 875

            /** traninit.e:264				case "arch" then*/
            case 28:

            /** traninit.e:265					set_target_arch( upper( val ) )*/
            Ref(_val_65206);
            _32158 = _14upper(_val_65206);
            _46set_target_arch(_32158);
            _32158 = NOVALUE;
            goto L3; // [861] 875

            /** traninit.e:267				case "cc-prefix" then*/
            case 29:

            /** traninit.e:268					compiler_prefix = val*/
            Ref(_val_65206);
            DeRef(_56compiler_prefix_45710);
            _56compiler_prefix_45710 = _val_65206;
        ;}L3: 
        DeRef(_key_65204);
        _key_65204 = NOVALUE;
        DeRef(_val_65206);
        _val_65206 = NOVALUE;

        /** traninit.e:271		end for*/
        _idx_65202 = _idx_65202 + 1;
        goto L1; // [879] 75
L2: 
        ;
    }

    /** traninit.e:274		if dll_option then*/
    if (_58dll_option_42893 == 0)
    {
        goto LC; // [888] 925
    }
    else{
    }

    /** traninit.e:275			if TX86_64  then*/
    if (_46TX86_64_21930 == 0)
    {
        goto LD; // [895] 911
    }
    else{
    }

    /** traninit.e:277				user_pic_library = check_library( user_pic_library )*/
    RefDS(_58user_pic_library_42906);
    _0 = _3check_library(_58user_pic_library_42906);
    DeRefDS(_58user_pic_library_42906);
    _58user_pic_library_42906 = _0;
    goto LE; // [908] 936
LD: 

    /** traninit.e:279				user_library = check_library( user_library )*/
    RefDS(_58user_library_42905);
    _0 = _3check_library(_58user_library_42905);
    DeRefDS(_58user_library_42905);
    _58user_library_42905 = _0;
    goto LE; // [922] 936
LC: 

    /** traninit.e:282			user_library = check_library( user_library )*/
    RefDS(_58user_library_42905);
    _0 = _3check_library(_58user_library_42905);
    DeRefDS(_58user_library_42905);
    _58user_library_42905 = _0;
LE: 

    /** traninit.e:285		if length(exe_name[D_NAME]) and not absolute_path(exe_name[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _32162 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_32162)){
            _32163 = SEQ_PTR(_32162)->length;
    }
    else {
        _32163 = 1;
    }
    _32162 = NOVALUE;
    if (_32163 == 0) {
        goto LF; // [949] 1002
    }
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _32165 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32165);
    _32166 = _17absolute_path(_32165);
    _32165 = NOVALUE;
    if (IS_ATOM_INT(_32166)) {
        _32167 = (_32166 == 0);
    }
    else {
        _32167 = unary_op(NOT, _32166);
    }
    DeRef(_32166);
    _32166 = NOVALUE;
    if (_32167 == 0) {
        DeRef(_32167);
        _32167 = NOVALUE;
        goto LF; // [969] 1002
    }
    else {
        if (!IS_ATOM_INT(_32167) && DBL_PTR(_32167)->dbl == 0.0){
            DeRef(_32167);
            _32167 = NOVALUE;
            goto LF; // [969] 1002
        }
        DeRef(_32167);
        _32167 = NOVALUE;
    }
    DeRef(_32167);
    _32167 = NOVALUE;

    /** traninit.e:286			exe_name[D_NAME] = current_dir() & SLASH & exe_name[D_NAME]*/
    _32168 = _17current_dir();
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _32169 = (object)*(((s1_ptr)_2)->base + 1);
    {
        object concat_list[3];

        concat_list[0] = _32169;
        concat_list[1] = 92;
        concat_list[2] = _32168;
        Concat_N((object_ptr)&_32170, concat_list, 3);
    }
    _32169 = NOVALUE;
    DeRef(_32168);
    _32168 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32170;
    if( _1 != _32170 ){
        DeRef(_1);
    }
    _32170 = NOVALUE;
LF: 

    /** traninit.e:288		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _32171 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32171);
    _32172 = _56adjust_for_command_line_passing(_32171);
    _32171 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45712);
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32172;
    if( _1 != _32172 ){
        DeRef(_1);
    }
    _32172 = NOVALUE;

    /** traninit.e:290		if length(map:get(opts, OPT_EXTRAS)) = 0 then*/
    Ref(_opts_65192);
    RefDS(_4OPT_EXTRAS_14411);
    _32173 = _29get(_opts_65192, _4OPT_EXTRAS_14411, 0);
    if (IS_SEQUENCE(_32173)){
            _32174 = SEQ_PTR(_32173)->length;
    }
    else {
        _32174 = 1;
    }
    DeRef(_32173);
    _32173 = NOVALUE;
    if (_32174 != 0)
    goto L10; // [1037] 1060

    /** traninit.e:292			show_banner()*/
    _49show_banner();

    /** traninit.e:293			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_TRANSLATED_ON_THE_COMMAND_LINE)*/
    RefDS(_22190);
    _39ShowMsg(2, 203, _22190, 1);

    /** traninit.e:296			abort(1)*/
    UserCleanup(1);
L10: 

    /** traninit.e:299		OpDefines &= { "EUC" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_32176);
    ((intptr_t*)_2)[1] = _32176;
    _32177 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _32177);
    DeRefDS(_32177);
    _32177 = NOVALUE;

    /** traninit.e:301		if host_platform() = WIN32 and not con_option then*/
    _32179 = _46host_platform();
    if (IS_ATOM_INT(_32179)) {
        _32180 = (_32179 == 2);
    }
    else {
        _32180 = binary_op(EQUALS, _32179, 2);
    }
    DeRef(_32179);
    _32179 = NOVALUE;
    if (IS_ATOM_INT(_32180)) {
        if (_32180 == 0) {
            goto L11; // [1085] 1111
        }
    }
    else {
        if (DBL_PTR(_32180)->dbl == 0.0) {
            goto L11; // [1085] 1111
        }
    }
    _32182 = (_58con_option_42895 == 0);
    if (_32182 == 0)
    {
        DeRef(_32182);
        _32182 = NOVALUE;
        goto L11; // [1095] 1111
    }
    else{
        DeRef(_32182);
        _32182 = NOVALUE;
    }

    /** traninit.e:302			OpDefines = append( OpDefines, "GUI" )*/
    RefDS(_32183);
    Append(&_36OpDefines_21844, _36OpDefines_21844, _32183);
    goto L12; // [1108] 1135
L11: 

    /** traninit.e:303		elsif not find( "CONSOLE", OpDefines ) then*/
    _32185 = find_from(_32119, _36OpDefines_21844, 1);
    if (_32185 != 0)
    goto L13; // [1120] 1134
    _32185 = NOVALUE;

    /** traninit.e:304			OpDefines = append( OpDefines, "CONSOLE" )*/
    RefDS(_32119);
    Append(&_36OpDefines_21844, _36OpDefines_21844, _32119);
L13: 
L12: 

    /** traninit.e:307		ifdef not EUDIS then*/

    /** traninit.e:308			if build_system_type = BUILD_DIRECT and length(output_dir) = 0 then*/
    _32188 = (_56build_system_type_45705 == 3);
    if (_32188 == 0) {
        goto L14; // [1147] 1245
    }
    if (IS_SEQUENCE(_58output_dir_42907)){
            _32190 = SEQ_PTR(_58output_dir_42907)->length;
    }
    else {
        _32190 = 1;
    }
    _32191 = (_32190 == 0);
    _32190 = NOVALUE;
    if (_32191 == 0)
    {
        DeRef(_32191);
        _32191 = NOVALUE;
        goto L14; // [1161] 1245
    }
    else{
        DeRef(_32191);
        _32191 = NOVALUE;
    }

    /** traninit.e:309				output_dir = temp_file("." & SLASH, "build-", "")*/
    Append(&_32192, _23375, 92);
    RefDS(_32193);
    RefDS(_22190);
    _0 = _17temp_file(_32192, _32193, _22190, 0);
    DeRef(_58output_dir_42907);
    _58output_dir_42907 = _0;
    _32192 = NOVALUE;

    /** traninit.e:310				if find(output_dir[$], "/\\") = 0 then*/
    if (IS_SEQUENCE(_58output_dir_42907)){
            _32195 = SEQ_PTR(_58output_dir_42907)->length;
    }
    else {
        _32195 = 1;
    }
    _2 = (object)SEQ_PTR(_58output_dir_42907);
    _32196 = (object)*(((s1_ptr)_2)->base + _32195);
    _32197 = find_from(_32196, _24114, 1);
    _32196 = NOVALUE;
    if (_32197 != 0)
    goto L15; // [1197] 1212

    /** traninit.e:311					output_dir &= '/'*/
    Append(&_58output_dir_42907, _58output_dir_42907, 47);
L15: 

    /** traninit.e:314				if not silent then*/
    if (_36silent_21886 != 0)
    goto L16; // [1216] 1237

    /** traninit.e:315					printf(1, "Build directory: %s\n", { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42907);
    RefDS(_22190);
    _32202 = _17abbreviate_path(_58output_dir_42907, _22190);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32202;
    _32203 = MAKE_SEQ(_1);
    _32202 = NOVALUE;
    EPrintf(1, _32201, _32203);
    DeRefDS(_32203);
    _32203 = NOVALUE;
L16: 

    /** traninit.e:318				remove_output_dir = 1*/
    _56remove_output_dir_45732 = 1;
L14: 

    /** traninit.e:322		if length(rc_file[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _32204 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_32204)){
            _32205 = SEQ_PTR(_32204)->length;
    }
    else {
        _32205 = 1;
    }
    _32204 = NOVALUE;
    if (_32205 == 0)
    {
        _32205 = NOVALUE;
        goto L17; // [1258] 1320
    }
    else{
        _32205 = NOVALUE;
    }

    /** traninit.e:323			res_file[D_NAME] = canonical_path(output_dir & filebase(rc_file[D_NAME]) & ".res")*/
    _2 = (object)SEQ_PTR(_56rc_file_45718);
    _32206 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32206);
    _32207 = _17filebase(_32206);
    _32206 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _32208;
        concat_list[1] = _32207;
        concat_list[2] = _58output_dir_42907;
        Concat_N((object_ptr)&_32209, concat_list, 3);
    }
    DeRef(_32207);
    _32207 = NOVALUE;
    _32210 = _17canonical_path(_32209, 0, 0);
    _32209 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32210;
    if( _1 != _32210 ){
        DeRef(_1);
    }
    _32210 = NOVALUE;

    /** traninit.e:324			res_file[D_ALTNAME] = adjust_for_command_line_passing(res_file[D_NAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45724);
    _32211 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32211);
    _32212 = _56adjust_for_command_line_passing(_32211);
    _32211 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32212;
    if( _1 != _32212 ){
        DeRef(_1);
    }
    _32212 = NOVALUE;
L17: 

    /** traninit.e:327		finalize_command_line(opts)*/
    Ref(_opts_65192);
    _49finalize_command_line(_opts_65192);

    /** traninit.e:328	end procedure*/
    DeRef(_tranopts_65180);
    DeRef(_opts_65192);
    DeRef(_opt_keys_65198);
    _32162 = NOVALUE;
    DeRef(_32180);
    _32180 = NOVALUE;
    DeRef(_32188);
    _32188 = NOVALUE;
    _32173 = NOVALUE;
    _32204 = NOVALUE;
    return;
    ;
}


void _3OpenCFiles()
{
    object _32274 = NOVALUE;
    object _32224 = NOVALUE;
    object _32218 = NOVALUE;
    object _32216 = NOVALUE;
    object _32215 = NOVALUE;
    object _32214 = NOVALUE;
    object _32213 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:333		if sequence(output_dir) and length(output_dir) > 0 then*/
    _32213 = 1;
    if (_32213 == 0) {
        goto L1; // [8] 38
    }
    if (IS_SEQUENCE(_58output_dir_42907)){
            _32215 = SEQ_PTR(_58output_dir_42907)->length;
    }
    else {
        _32215 = 1;
    }
    _32216 = (_32215 > 0);
    _32215 = NOVALUE;
    if (_32216 == 0)
    {
        DeRef(_32216);
        _32216 = NOVALUE;
        goto L1; // [22] 38
    }
    else{
        DeRef(_32216);
        _32216 = NOVALUE;
    }

    /** traninit.e:334			create_directory(output_dir)*/
    RefDS(_58output_dir_42907);
    _32274 = _17create_directory(_58output_dir_42907, 448, 1);
    DeRef(_32274);
    _32274 = NOVALUE;
L1: 

    /** traninit.e:337		c_code = open(output_dir & "init-.c", "w")*/
    Concat((object_ptr)&_32218, _58output_dir_42907, _32217);
    _55c_code_46976 = EOpen(_32218, _22326, 0);
    DeRefDS(_32218);
    _32218 = NOVALUE;

    /** traninit.e:338		if c_code = -1 then*/
    if (_55c_code_46976 != -1)
    goto L2; // [57] 71

    /** traninit.e:339			CompileErr(CANT_OPEN_INITC_FOR_OUTPUT)*/
    RefDS(_22190);
    _50CompileErr(55, _22190, 0);
L2: 

    /** traninit.e:342		add_file("init-.c")*/
    RefDS(_32217);
    RefDS(_22190);
    _58add_file(_32217, _22190);

    /** traninit.e:344		emit_c_output = TRUE*/
    _55emit_c_output_46973 = _13TRUE_447;

    /** traninit.e:346		c_puts("#include \"")*/
    RefDS(_32221);
    _55c_puts(_32221);

    /** traninit.e:347		c_puts("include/euphoria.h\"\n")*/
    RefDS(_32222);
    _55c_puts(_32222);

    /** traninit.e:349		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22332);
    _55c_puts(_22332);

    /** traninit.e:350		c_h = open(output_dir & "main-.h", "w")*/
    Concat((object_ptr)&_32224, _58output_dir_42907, _32223);
    _55c_h_46977 = EOpen(_32224, _22326, 0);
    DeRefDS(_32224);
    _32224 = NOVALUE;

    /** traninit.e:351		if c_h = -1 then*/
    if (_55c_h_46977 != -1)
    goto L3; // [118] 132

    /** traninit.e:352			CompileErr(CANT_OPEN_MAINH_FILE_FOR_OUTPUT)*/
    RefDS(_22190);
    _50CompileErr(47, _22190, 0);
L3: 

    /** traninit.e:354		c_hputs("#include \"include/euphoria.h\"\n")*/
    RefDS(_22331);
    _55c_hputs(_22331);

    /** traninit.e:356		add_file("main-.h")*/
    RefDS(_32223);
    RefDS(_22190);
    _58add_file(_32223, _22190);

    /** traninit.e:357	end procedure*/
    return;
    ;
}


void _3InitBackEnd(object _c_65568)
{
    object _32257 = NOVALUE;
    object _32256 = NOVALUE;
    object _32254 = NOVALUE;
    object _32253 = NOVALUE;
    object _32252 = NOVALUE;
    object _32251 = NOVALUE;
    object _32250 = NOVALUE;
    object _32247 = NOVALUE;
    object _32246 = NOVALUE;
    object _32243 = NOVALUE;
    object _32242 = NOVALUE;
    object _32239 = NOVALUE;
    object _32238 = NOVALUE;
    object _32236 = NOVALUE;
    object _32233 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_65568)) {
        _1 = (object)(DBL_PTR(_c_65568)->dbl);
        DeRefDS(_c_65568);
        _c_65568 = _1;
    }

    /** traninit.e:363		if c = 1 then*/
    if (_c_65568 != 1)
    goto L1; // [5] 19

    /** traninit.e:364			OpenCFiles()*/
    _3OpenCFiles();

    /** traninit.e:366			return*/
    return;
L1: 

    /** traninit.e:369		init_opcodes()*/
    _59init_opcodes();

    /** traninit.e:370		transoptions()*/
    _3transoptions();

    /** traninit.e:372		if compiler_type = COMPILER_UNKNOWN then*/
    if (_56compiler_type_45709 != 0)
    goto L2; // [33] 75

    /** traninit.e:373			if TWINDOWS then*/
    if (_46TWINDOWS_21914 == 0)
    {
        goto L3; // [41] 56
    }
    else{
    }

    /** traninit.e:374				compiler_type = COMPILER_WATCOM*/
    _56compiler_type_45709 = 2;
    goto L4; // [53] 74
L3: 

    /** traninit.e:375			elsif TUNIX then*/
    if (_46TUNIX_21918 == 0)
    {
        goto L5; // [60] 73
    }
    else{
    }

    /** traninit.e:376				compiler_type = COMPILER_GCC*/
    _56compiler_type_45709 = 1;
L5: 
L4: 
L2: 

    /** traninit.e:380		switch compiler_type do*/
    _0 = _56compiler_type_45709;
    switch ( _0 ){ 

        /** traninit.e:381		  	case COMPILER_GCC then*/
        case 1:

        /** traninit.e:383				break -- to avoid empty block warning*/
        goto L6; // [90] 334
        goto L6; // [92] 334

        /** traninit.e:385			case COMPILER_WATCOM then*/
        case 2:

        /** traninit.e:386				wat_path = getenv("WATCOM")*/
        DeRefi(_36wat_path_21848);
        _36wat_path_21848 = EGetEnv(_32231);

        /** traninit.e:388				if atom(wat_path) then*/
        _32233 = IS_ATOM(_36wat_path_21848);
        if (_32233 == 0)
        {
            _32233 = NOVALUE;
            goto L7; // [110] 148
        }
        else{
            _32233 = NOVALUE;
        }

        /** traninit.e:389					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45705 != 3)
        goto L8; // [119] 135

        /** traninit.e:392						CompileErr(WATCOM_ENVIRONMENT_VARIABLE_IS_NOT_SET)*/
        RefDS(_22190);
        _50CompileErr(159, _22190, 0);
        goto L6; // [132] 334
L8: 

        /** traninit.e:397						Warning(159, translator_warning_flag)*/
        RefDS(_22190);
        _50Warning(159, 128, _22190);
        goto L6; // [145] 334
L7: 

        /** traninit.e:399				elsif find(' ', wat_path) then*/
        _32236 = find_from(32, _36wat_path_21848, 1);
        if (_32236 == 0)
        {
            _32236 = NOVALUE;
            goto L9; // [157] 172
        }
        else{
            _32236 = NOVALUE;
        }

        /** traninit.e:400					Warning( 214, translator_warning_flag)*/
        RefDS(_22190);
        _50Warning(214, 128, _22190);
        goto L6; // [169] 334
L9: 

        /** traninit.e:401				elsif atom(getenv("INCLUDE")) then*/
        _32238 = EGetEnv(_32237);
        _32239 = IS_ATOM(_32238);
        DeRef(_32238);
        _32238 = NOVALUE;
        if (_32239 == 0)
        {
            _32239 = NOVALUE;
            goto LA; // [180] 195
        }
        else{
            _32239 = NOVALUE;
        }

        /** traninit.e:402					Warning( 215, translator_warning_flag )*/
        RefDS(_22190);
        _50Warning(215, 128, _22190);
        goto L6; // [192] 334
LA: 

        /** traninit.e:403				elsif not file_exists(wat_path & SLASH & "binnt" & SLASH & "wcc386.exe") then*/
        {
            object concat_list[5];

            concat_list[0] = _32241;
            concat_list[1] = 92;
            concat_list[2] = _32240;
            concat_list[3] = 92;
            concat_list[4] = _36wat_path_21848;
            Concat_N((object_ptr)&_32242, concat_list, 5);
        }
        _32243 = _17file_exists(_32242);
        _32242 = NOVALUE;
        if (IS_ATOM_INT(_32243)) {
            if (_32243 != 0){
                DeRef(_32243);
                _32243 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        else {
            if (DBL_PTR(_32243)->dbl != 0.0){
                DeRef(_32243);
                _32243 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        DeRef(_32243);
        _32243 = NOVALUE;

        /** traninit.e:404					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45705 != 3)
        goto LC; // [224] 246

        /** traninit.e:405						CompileErr( THERE_IS_NO_WATCOM_INSTALATION_UNDER_SPECIFIED_WATOM_PATH_1, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21848);
        ((intptr_t*)_2)[1] = _36wat_path_21848;
        _32246 = MAKE_SEQ(_1);
        _50CompileErr(352, _32246, 0);
        _32246 = NOVALUE;
        goto L6; // [243] 334
LC: 

        /** traninit.e:407						Warning( 352, translator_warning_flag, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21848);
        ((intptr_t*)_2)[1] = _36wat_path_21848;
        _32247 = MAKE_SEQ(_1);
        _50Warning(352, 128, _32247);
        _32247 = NOVALUE;
        goto L6; // [262] 334
LB: 

        /** traninit.e:409				elsif match(upper(wat_path & "\\H;" & wat_path & "\\H\\NT"),*/
        {
            object concat_list[4];

            concat_list[0] = _32249;
            concat_list[1] = _36wat_path_21848;
            concat_list[2] = _32248;
            concat_list[3] = _36wat_path_21848;
            Concat_N((object_ptr)&_32250, concat_list, 4);
        }
        _32251 = _14upper(_32250);
        _32250 = NOVALUE;
        _32252 = EGetEnv(_32237);
        _32253 = _14upper(_32252);
        _32252 = NOVALUE;
        _32254 = e_match_from(_32251, _32253, 1);
        DeRef(_32251);
        _32251 = NOVALUE;
        DeRef(_32253);
        _32253 = NOVALUE;
        if (_32254 == 1)
        goto L6; // [294] 334

        /** traninit.e:412					Warning( 216, translator_warning_flag, {wat_path,getenv("INCLUDE")} )*/
        _32256 = EGetEnv(_32237);
        Ref(_36wat_path_21848);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _36wat_path_21848;
        ((intptr_t *)_2)[2] = _32256;
        _32257 = MAKE_SEQ(_1);
        _32256 = NOVALUE;
        _50Warning(216, 128, _32257);
        _32257 = NOVALUE;
        goto L6; // [318] 334

        /** traninit.e:415			case else*/
        default:

        /** traninit.e:416				CompileErr(UNKNOWN_COMPILER)*/
        RefDS(_22190);
        _50CompileErr(150, _22190, 0);
    ;}L6: 

    /** traninit.e:419	end procedure*/
    return;
    ;
}


void _3CheckPlatform()
{
    object _32263 = NOVALUE;
    object _32261 = NOVALUE;
    object _32260 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:425		OpDefines = eu:remove(OpDefines,*/
    _32260 = find_from(_25555, _36OpDefines_21844, 1);
    _32261 = find_from(_25556, _36OpDefines_21844, 1);
    {
        s1_ptr assign_space = SEQ_PTR(_36OpDefines_21844);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_32260)) ? _32260 : (object)(DBL_PTR(_32260)->dbl);
        int stop = (IS_ATOM_INT(_32261)) ? _32261 : (object)(DBL_PTR(_32261)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_36OpDefines_21844), start, &_36OpDefines_21844 );
            }
            else Tail(SEQ_PTR(_36OpDefines_21844), stop+1, &_36OpDefines_21844);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_36OpDefines_21844), start, &_36OpDefines_21844);
        }
        else {
            assign_slice_seq = &assign_space;
            _36OpDefines_21844 = Remove_elements(start, stop, (SEQ_PTR(_36OpDefines_21844)->ref == 1));
        }
    }
    _32260 = NOVALUE;
    _32261 = NOVALUE;

    /** traninit.e:428		OpDefines &= GetPlatformDefines(1)*/
    _32263 = _46GetPlatformDefines(1);
    if (IS_SEQUENCE(_36OpDefines_21844) && IS_ATOM(_32263)) {
        Ref(_32263);
        Append(&_36OpDefines_21844, _36OpDefines_21844, _32263);
    }
    else if (IS_ATOM(_36OpDefines_21844) && IS_SEQUENCE(_32263)) {
    }
    else {
        Concat((object_ptr)&_36OpDefines_21844, _36OpDefines_21844, _32263);
    }
    DeRef(_32263);
    _32263 = NOVALUE;

    /** traninit.e:429	end procedure*/
    return;
    ;
}


object _3check_library(object _lib_65685)
{
    object _32273 = NOVALUE;
    object _32272 = NOVALUE;
    object _32270 = NOVALUE;
    object _32268 = NOVALUE;
    object _32267 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:433		if equal( lib, "" ) then*/
    if (_lib_65685 == _22190)
    _32267 = 1;
    else if (IS_ATOM_INT(_lib_65685) && IS_ATOM_INT(_22190))
    _32267 = 0;
    else
    _32267 = (compare(_lib_65685, _22190) == 0);
    if (_32267 == 0)
    {
        _32267 = NOVALUE;
        goto L1; // [9] 19
    }
    else{
        _32267 = NOVALUE;
    }

    /** traninit.e:434			return ""*/
    RefDS(_22190);
    DeRefDS(_lib_65685);
    return _22190;
L1: 

    /** traninit.e:437		if not file_exists( lib ) then*/
    RefDS(_lib_65685);
    _32268 = _17file_exists(_lib_65685);
    if (IS_ATOM_INT(_32268)) {
        if (_32268 != 0){
            DeRef(_32268);
            _32268 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    else {
        if (DBL_PTR(_32268)->dbl != 0.0){
            DeRef(_32268);
            _32268 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    DeRef(_32268);
    _32268 = NOVALUE;

    /** traninit.e:438			ShowMsg(2, USER_SUPPLIED_LIBRARY_DOES_NOT_EXIST__1, { lib })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lib_65685);
    ((intptr_t*)_2)[1] = _lib_65685;
    _32270 = MAKE_SEQ(_1);
    _39ShowMsg(2, 348, _32270, 1);
    _32270 = NOVALUE;

    /** traninit.e:439			if force_build or build_system_type = BUILD_DIRECT then*/
    if (_56force_build_45731 != 0) {
        goto L3; // [46] 63
    }
    _32272 = (_56build_system_type_45705 == 3);
    if (_32272 == 0)
    {
        DeRef(_32272);
        _32272 = NOVALUE;
        goto L4; // [59] 68
    }
    else{
        DeRef(_32272);
        _32272 = NOVALUE;
    }
L3: 

    /** traninit.e:440				abort(1)*/
    UserCleanup(1);
L4: 
L2: 

    /** traninit.e:443		return canonical_path( lib )*/
    RefDS(_lib_65685);
    _32273 = _17canonical_path(_lib_65685, 0, 0);
    DeRefDS(_lib_65685);
    return _32273;
    ;
}



// 0xD8DE012C
