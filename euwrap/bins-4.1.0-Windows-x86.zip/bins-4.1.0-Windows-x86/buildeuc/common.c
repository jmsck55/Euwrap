// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _37open_locked(object _file_path_15667)
{
    object _fh_15668 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:55		fh = open(file_path, "u")*/
    _fh_15668 = EOpen(_file_path_15667, _8759, 0);

    /** common.e:57		if fh = -1 then*/
    if (_fh_15668 != -1)
    goto L1; // [12] 24

    /** common.e:58			fh = open(file_path, "r")*/
    _fh_15668 = EOpen(_file_path_15667, _3921, 0);
L1: 

    /** common.e:61		return fh*/
    DeRefDS(_file_path_15667);
    return _fh_15668;
    ;
}


object _37get_eudir()
{
    object _possible_paths_15685 = NOVALUE;
    object _homepath_15690 = NOVALUE;
    object _homedrive_15692 = NOVALUE;
    object _possible_path_15715 = NOVALUE;
    object _possible_path_15729 = NOVALUE;
    object _file_check_15743 = NOVALUE;
    object _8810 = NOVALUE;
    object _8809 = NOVALUE;
    object _8808 = NOVALUE;
    object _8806 = NOVALUE;
    object _8804 = NOVALUE;
    object _8802 = NOVALUE;
    object _8801 = NOVALUE;
    object _8800 = NOVALUE;
    object _8799 = NOVALUE;
    object _8798 = NOVALUE;
    object _8796 = NOVALUE;
    object _8794 = NOVALUE;
    object _8793 = NOVALUE;
    object _8789 = NOVALUE;
    object _8787 = NOVALUE;
    object _8784 = NOVALUE;
    object _8783 = NOVALUE;
    object _8782 = NOVALUE;
    object _8781 = NOVALUE;
    object _8780 = NOVALUE;
    object _8779 = NOVALUE;
    object _8778 = NOVALUE;
    object _8777 = NOVALUE;
    object _8776 = NOVALUE;
    object _8765 = NOVALUE;
    object _8763 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:82		if sequence(eudir) then*/
    _8763 = IS_SEQUENCE(_37eudir_15663);
    if (_8763 == 0)
    {
        _8763 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _8763 = NOVALUE;
    }

    /** common.e:83			return eudir*/
    Ref(_37eudir_15663);
    DeRef(_possible_paths_15685);
    DeRefi(_homepath_15690);
    DeRefi(_homedrive_15692);
    return _37eudir_15663;
L1: 

    /** common.e:86		eudir = getenv("EUDIR")*/
    DeRef(_37eudir_15663);
    _37eudir_15663 = EGetEnv(_3828);

    /** common.e:87		if sequence(eudir) then*/
    _8765 = IS_SEQUENCE(_37eudir_15663);
    if (_8765 == 0)
    {
        _8765 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _8765 = NOVALUE;
    }

    /** common.e:88			return eudir*/
    Ref(_37eudir_15663);
    DeRef(_possible_paths_15685);
    DeRefi(_homepath_15690);
    DeRefi(_homedrive_15692);
    return _37eudir_15663;
L2: 

    /** common.e:91		ifdef UNIX then*/

    /** common.e:102			sequence possible_paths = {*/
    _0 = _possible_paths_15685;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_8770);
    ((intptr_t*)_2)[1] = _8770;
    RefDS(_8771);
    ((intptr_t*)_2)[2] = _8771;
    RefDS(_8772);
    ((intptr_t*)_2)[3] = _8772;
    _possible_paths_15685 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:107			object homepath = getenv("HOMEPATH")*/
    DeRefi(_homepath_15690);
    _homepath_15690 = EGetEnv(_3458);

    /** common.e:108			object homedrive = getenv("HOMEDRIVE")*/
    DeRefi(_homedrive_15692);
    _homedrive_15692 = EGetEnv(_3456);

    /** common.e:109			if sequence(homepath) and sequence(homedrive) then*/
    _8776 = IS_SEQUENCE(_homepath_15690);
    if (_8776 == 0) {
        goto L3; // [69] 134
    }
    _8778 = IS_SEQUENCE(_homedrive_15692);
    if (_8778 == 0)
    {
        _8778 = NOVALUE;
        goto L3; // [77] 134
    }
    else{
        _8778 = NOVALUE;
    }

    /** common.e:110				if length(homepath) and not equal(homepath[$], SLASH) then*/
    if (IS_SEQUENCE(_homepath_15690)){
            _8779 = SEQ_PTR(_homepath_15690)->length;
    }
    else {
        _8779 = 1;
    }
    if (_8779 == 0) {
        goto L4; // [85] 118
    }
    if (IS_SEQUENCE(_homepath_15690)){
            _8781 = SEQ_PTR(_homepath_15690)->length;
    }
    else {
        _8781 = 1;
    }
    _2 = (object)SEQ_PTR(_homepath_15690);
    _8782 = (object)*(((s1_ptr)_2)->base + _8781);
    if (_8782 == 92)
    _8783 = 1;
    else if (IS_ATOM_INT(_8782) && IS_ATOM_INT(92))
    _8783 = 0;
    else
    _8783 = (compare(_8782, 92) == 0);
    _8782 = NOVALUE;
    _8784 = (_8783 == 0);
    _8783 = NOVALUE;
    if (_8784 == 0)
    {
        DeRef(_8784);
        _8784 = NOVALUE;
        goto L4; // [106] 118
    }
    else{
        DeRef(_8784);
        _8784 = NOVALUE;
    }

    /** common.e:111					homepath &= SLASH*/
    if (IS_SEQUENCE(_homepath_15690) && IS_ATOM(92)) {
        Append(&_homepath_15690, _homepath_15690, 92);
    }
    else if (IS_ATOM(_homepath_15690) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_homepath_15690, _homepath_15690, 92);
    }
L4: 

    /** common.e:114				possible_paths = append(possible_paths, homedrive & SLASH & homepath & "euphoria")*/
    {
        object concat_list[4];

        concat_list[0] = _8786;
        concat_list[1] = _homepath_15690;
        concat_list[2] = 92;
        concat_list[3] = _homedrive_15692;
        Concat_N((object_ptr)&_8787, concat_list, 4);
    }
    RefDS(_8787);
    Append(&_possible_paths_15685, _possible_paths_15685, _8787);
    DeRefDS(_8787);
    _8787 = NOVALUE;
L3: 

    /** common.e:118		for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_15685)){
            _8789 = SEQ_PTR(_possible_paths_15685)->length;
    }
    else {
        _8789 = 1;
    }
    {
        object _i_15713;
        _i_15713 = 1;
L5: 
        if (_i_15713 > _8789){
            goto L6; // [141] 200
        }

        /** common.e:119			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15715);
        _2 = (object)SEQ_PTR(_possible_paths_15685);
        _possible_path_15715 = (object)*(((s1_ptr)_2)->base + _i_15713);
        RefDS(_possible_path_15715);

        /** common.e:121			if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            object concat_list[5];

            concat_list[0] = _8792;
            concat_list[1] = 92;
            concat_list[2] = _8791;
            concat_list[3] = 92;
            concat_list[4] = _possible_path_15715;
            Concat_N((object_ptr)&_8793, concat_list, 5);
        }
        _8794 = _17file_exists(_8793);
        _8793 = NOVALUE;
        if (_8794 == 0) {
            DeRef(_8794);
            _8794 = NOVALUE;
            goto L7; // [174] 191
        }
        else {
            if (!IS_ATOM_INT(_8794) && DBL_PTR(_8794)->dbl == 0.0){
                DeRef(_8794);
                _8794 = NOVALUE;
                goto L7; // [174] 191
            }
            DeRef(_8794);
            _8794 = NOVALUE;
        }
        DeRef(_8794);
        _8794 = NOVALUE;

        /** common.e:122				eudir = possible_path*/
        RefDS(_possible_path_15715);
        DeRef(_37eudir_15663);
        _37eudir_15663 = _possible_path_15715;

        /** common.e:123				return eudir*/
        RefDS(_37eudir_15663);
        DeRefDS(_possible_path_15715);
        DeRefDS(_possible_paths_15685);
        DeRefi(_homepath_15690);
        DeRefi(_homedrive_15692);
        return _37eudir_15663;
L7: 
        DeRef(_possible_path_15715);
        _possible_path_15715 = NOVALUE;

        /** common.e:125		end for*/
        _i_15713 = _i_15713 + 1;
        goto L5; // [195] 148
L6: 
        ;
    }

    /** common.e:127		possible_paths = include_paths(0)*/
    _0 = _possible_paths_15685;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_3851);
    ((intptr_t*)_2)[1] = _3851;
    RefDS(_3850);
    ((intptr_t*)_2)[2] = _3850;
    _possible_paths_15685 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:128		for i = 1 to length(possible_paths) do*/
    _8796 = 2;
    {
        object _i_15727;
        _i_15727 = 1;
L8: 
        if (_i_15727 > 2){
            goto L9; // [212] 337
        }

        /** common.e:129			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15729);
        _2 = (object)SEQ_PTR(_possible_paths_15685);
        _possible_path_15729 = (object)*(((s1_ptr)_2)->base + _i_15727);
        RefDS(_possible_path_15729);

        /** common.e:130			if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_15729)){
                _8798 = SEQ_PTR(_possible_path_15729)->length;
        }
        else {
            _8798 = 1;
        }
        _2 = (object)SEQ_PTR(_possible_path_15729);
        _8799 = (object)*(((s1_ptr)_2)->base + _8798);
        if (_8799 == 92)
        _8800 = 1;
        else if (IS_ATOM_INT(_8799) && IS_ATOM_INT(92))
        _8800 = 0;
        else
        _8800 = (compare(_8799, 92) == 0);
        _8799 = NOVALUE;
        if (_8800 == 0)
        {
            _8800 = NOVALUE;
            goto LA; // [242] 260
        }
        else{
            _8800 = NOVALUE;
        }

        /** common.e:131				possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_15729)){
                _8801 = SEQ_PTR(_possible_path_15729)->length;
        }
        else {
            _8801 = 1;
        }
        _8802 = _8801 - 1;
        _8801 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_15729;
        RHS_Slice(_possible_path_15729, 1, _8802);
LA: 

        /** common.e:134			if not ends("include", possible_path) then*/
        RefDS(_8791);
        RefDS(_possible_path_15729);
        _8804 = _16ends(_8791, _possible_path_15729);
        if (IS_ATOM_INT(_8804)) {
            if (_8804 != 0){
                DeRef(_8804);
                _8804 = NOVALUE;
                goto LB; // [267] 277
            }
        }
        else {
            if (DBL_PTR(_8804)->dbl != 0.0){
                DeRef(_8804);
                _8804 = NOVALUE;
                goto LB; // [267] 277
            }
        }
        DeRef(_8804);
        _8804 = NOVALUE;

        /** common.e:135				continue*/
        DeRefDS(_possible_path_15729);
        _possible_path_15729 = NOVALUE;
        DeRef(_file_check_15743);
        _file_check_15743 = NOVALUE;
        goto LC; // [274] 332
LB: 

        /** common.e:138			sequence file_check = possible_path*/
        RefDS(_possible_path_15729);
        DeRef(_file_check_15743);
        _file_check_15743 = _possible_path_15729;

        /** common.e:139			file_check &= SLASH & "euphoria.h"*/
        Prepend(&_8806, _8792, 92);
        Concat((object_ptr)&_file_check_15743, _file_check_15743, _8806);
        DeRefDS(_8806);
        _8806 = NOVALUE;

        /** common.e:141			if file_exists(file_check) then*/
        RefDS(_file_check_15743);
        _8808 = _17file_exists(_file_check_15743);
        if (_8808 == 0) {
            DeRef(_8808);
            _8808 = NOVALUE;
            goto LD; // [302] 328
        }
        else {
            if (!IS_ATOM_INT(_8808) && DBL_PTR(_8808)->dbl == 0.0){
                DeRef(_8808);
                _8808 = NOVALUE;
                goto LD; // [302] 328
            }
            DeRef(_8808);
            _8808 = NOVALUE;
        }
        DeRef(_8808);
        _8808 = NOVALUE;

        /** common.e:142				eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_15729)){
                _8809 = SEQ_PTR(_possible_path_15729)->length;
        }
        else {
            _8809 = 1;
        }
        _8810 = _8809 - 8;
        _8809 = NOVALUE;
        rhs_slice_target = (object_ptr)&_37eudir_15663;
        RHS_Slice(_possible_path_15729, 1, _8810);

        /** common.e:143				return eudir*/
        RefDS(_37eudir_15663);
        DeRefDS(_possible_path_15729);
        DeRefDS(_file_check_15743);
        DeRef(_possible_paths_15685);
        DeRefi(_homepath_15690);
        DeRefi(_homedrive_15692);
        DeRef(_8802);
        _8802 = NOVALUE;
        _8810 = NOVALUE;
        return _37eudir_15663;
LD: 
        DeRef(_possible_path_15729);
        _possible_path_15729 = NOVALUE;
        DeRef(_file_check_15743);
        _file_check_15743 = NOVALUE;

        /** common.e:145		end for*/
LC: 
        _i_15727 = _i_15727 + 1;
        goto L8; // [332] 219
L9: 
        ;
    }

    /** common.e:147		return ""*/
    RefDS(_5);
    DeRef(_possible_paths_15685);
    DeRefi(_homepath_15690);
    DeRefi(_homedrive_15692);
    DeRef(_8802);
    _8802 = NOVALUE;
    DeRef(_8810);
    _8810 = NOVALUE;
    return _5;
    ;
}


void _37set_eudir(object _new_eudir_15755)
{
    object _0, _1, _2;
    

    /** common.e:151		eudir = new_eudir*/
    RefDS(_new_eudir_15755);
    DeRef(_37eudir_15663);
    _37eudir_15663 = _new_eudir_15755;

    /** common.e:152		cmdline_eudir = 1*/
    _37cmdline_eudir_15664 = 1;

    /** common.e:153	end procedure*/
    DeRefDS(_new_eudir_15755);
    return;
    ;
}


object _37is_eudir_from_cmdline()
{
    object _0, _1, _2;
    

    /** common.e:156		return cmdline_eudir*/
    return _37cmdline_eudir_15664;
    ;
}



// 0xF6D0C61E
