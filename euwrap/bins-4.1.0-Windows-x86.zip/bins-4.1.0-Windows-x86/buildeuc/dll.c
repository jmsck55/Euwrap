// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _12open_dll(object _file_name_951)
{
    object _fh_961 = NOVALUE;
    object _367 = NOVALUE;
    object _365 = NOVALUE;
    object _364 = NOVALUE;
    object _363 = NOVALUE;
    object _362 = NOVALUE;
    object _361 = NOVALUE;
    object _360 = NOVALUE;
    object _359 = NOVALUE;
    object _0, _1, _2;
    

    /** dll.e:182		if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_951)){
            _359 = SEQ_PTR(_file_name_951)->length;
    }
    else {
        _359 = 1;
    }
    _360 = (_359 > 0);
    _359 = NOVALUE;
    if (_360 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_951);
    _362 = _13string(_file_name_951);
    if (_362 == 0) {
        DeRef(_362);
        _362 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_362) && DBL_PTR(_362)->dbl == 0.0){
            DeRef(_362);
            _362 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_362);
        _362 = NOVALUE;
    }
    DeRef(_362);
    _362 = NOVALUE;

    /** dll.e:183			return machine_func(M_OPEN_DLL, file_name)*/
    _363 = machine(50, _file_name_951);
    DeRefDS(_file_name_951);
    DeRef(_360);
    _360 = NOVALUE;
    return _363;
L1: 

    /** dll.e:188		for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_951)){
            _364 = SEQ_PTR(_file_name_951)->length;
    }
    else {
        _364 = 1;
    }
    {
        object _idx_959;
        _idx_959 = 1;
L2: 
        if (_idx_959 > _364){
            goto L3; // [40] 82
        }

        /** dll.e:189			atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (object)SEQ_PTR(_file_name_951);
        _365 = (object)*(((s1_ptr)_2)->base + _idx_959);
        DeRef(_fh_961);
        _fh_961 = machine(50, _365);
        _365 = NOVALUE;

        /** dll.e:190			if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_961)) {
            _367 = (_fh_961 == 0);
        }
        else {
            _367 = unary_op(NOT, _fh_961);
        }
        if (_367 != 0)
        goto L4; // [62] 73

        /** dll.e:191				return fh*/
        DeRefDS(_file_name_951);
        DeRef(_360);
        _360 = NOVALUE;
        DeRef(_363);
        _363 = NOVALUE;
        _367 = NOVALUE;
        return _fh_961;
L4: 
        DeRef(_fh_961);
        _fh_961 = NOVALUE;

        /** dll.e:193		end for*/
        _idx_959 = _idx_959 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** dll.e:195		return 0*/
    DeRefDS(_file_name_951);
    DeRef(_360);
    _360 = NOVALUE;
    DeRef(_363);
    _363 = NOVALUE;
    DeRef(_367);
    _367 = NOVALUE;
    return 0;
    ;
}


object _12define_c_proc(object _lib_975, object _routine_name_976, object _arg_types_977)
{
    object _safe_address_inlined_safe_address_at_11_982 = NOVALUE;
    object _msg_inlined_crash_at_26_986 = NOVALUE;
    object _376 = NOVALUE;
    object _375 = NOVALUE;
    object _373 = NOVALUE;
    object _372 = NOVALUE;
    object _371 = NOVALUE;
    object _0, _1, _2;
    

    /** dll.e:298		if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _371 = 0;
    if (_371 == 0) {
        goto L1; // [8] 46
    }

    /** memory.e:118		return 1*/
    _safe_address_inlined_safe_address_at_11_982 = 1;
    _373 = (1 == 0);
    if (_373 == 0)
    {
        DeRef(_373);
        _373 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_373);
        _373 = NOVALUE;
    }

    /** dll.e:299	        error:crash("A C function is being defined from Non-executable memory.")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_986);
    _msg_inlined_crash_at_26_986 = EPrintf(-9999999, _374, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_986);

    /** error.e:53	end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_986);
    _msg_inlined_crash_at_26_986 = NOVALUE;
L1: 

    /** dll.e:301		return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, 0})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_lib_975);
    ((intptr_t*)_2)[1] = _lib_975;
    Ref(_routine_name_976);
    ((intptr_t*)_2)[2] = _routine_name_976;
    RefDS(_arg_types_977);
    ((intptr_t*)_2)[3] = _arg_types_977;
    ((intptr_t*)_2)[4] = 0;
    _375 = MAKE_SEQ(_1);
    _376 = machine(51, _375);
    DeRefDS(_375);
    _375 = NOVALUE;
    DeRef(_lib_975);
    DeRefi(_routine_name_976);
    DeRefDSi(_arg_types_977);
    return _376;
    ;
}


object _12define_c_func(object _lib_991, object _routine_name_992, object _arg_types_993, object _return_type_994)
{
    object _safe_address_inlined_safe_address_at_11_999 = NOVALUE;
    object _msg_inlined_crash_at_26_1002 = NOVALUE;
    object _381 = NOVALUE;
    object _380 = NOVALUE;
    object _379 = NOVALUE;
    object _378 = NOVALUE;
    object _377 = NOVALUE;
    object _0, _1, _2;
    

    /** dll.e:395		  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _377 = 0;
    if (_377 == 0) {
        goto L1; // [8] 46
    }

    /** memory.e:118		return 1*/
    _safe_address_inlined_safe_address_at_11_999 = 1;
    _379 = (1 == 0);
    if (_379 == 0)
    {
        DeRef(_379);
        _379 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_379);
        _379 = NOVALUE;
    }

    /** dll.e:396		      error:crash("A C function is being defined from Non-executable memory.")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_1002);
    _msg_inlined_crash_at_26_1002 = EPrintf(-9999999, _374, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_1002);

    /** error.e:53	end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_1002);
    _msg_inlined_crash_at_26_1002 = NOVALUE;
L1: 

    /** dll.e:398		  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_lib_991);
    ((intptr_t*)_2)[1] = _lib_991;
    Ref(_routine_name_992);
    ((intptr_t*)_2)[2] = _routine_name_992;
    RefDS(_arg_types_993);
    ((intptr_t*)_2)[3] = _arg_types_993;
    ((intptr_t*)_2)[4] = _return_type_994;
    _380 = MAKE_SEQ(_1);
    _381 = machine(51, _380);
    DeRefDS(_380);
    _380 = NOVALUE;
    DeRef(_lib_991);
    DeRefi(_routine_name_992);
    DeRefDSi(_arg_types_993);
    return _381;
    ;
}



// 0x955BDE8A
