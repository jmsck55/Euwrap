// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47Push(object _x_51619)
{
    object _26566 = NOVALUE;
    object _26564 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_51619)) {
        _1 = (object)(DBL_PTR(_x_51619)->dbl);
        DeRefDS(_x_51619);
        _x_51619 = _1;
    }

    /** emit.e:135		cgi += 1*/
    _47cgi_51380 = _47cgi_51380 + 1;

    /** emit.e:136		if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_47cg_stack_51379)){
            _26564 = SEQ_PTR(_47cg_stack_51379)->length;
    }
    else {
        _26564 = 1;
    }
    if (_47cgi_51380 <= _26564)
    goto L1; // [20] 37

    /** emit.e:137			cg_stack &= repeat(0, 400)*/
    _26566 = Repeat(0, 400);
    Concat((object_ptr)&_47cg_stack_51379, _47cg_stack_51379, _26566);
    DeRefDS(_26566);
    _26566 = NOVALUE;
L1: 

    /** emit.e:139		cg_stack[cgi] = x*/
    _2 = (object)SEQ_PTR(_47cg_stack_51379);
    _2 = (object)(((s1_ptr)_2)->base + _47cgi_51380);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_51619;
    DeRef(_1);

    /** emit.e:141	end procedure*/
    return;
    ;
}


object _47Top()
{
    object _26568 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:145		return cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_51379);
    _26568 = (object)*(((s1_ptr)_2)->base + _47cgi_51380);
    Ref(_26568);
    return _26568;
    ;
}


object _47Pop()
{
    object _t_51632 = NOVALUE;
    object _s_51638 = NOVALUE;
    object _26580 = NOVALUE;
    object _26578 = NOVALUE;
    object _26576 = NOVALUE;
    object _26573 = NOVALUE;
    object _26572 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:153		t = cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_51379);
    _t_51632 = (object)*(((s1_ptr)_2)->base + _47cgi_51380);
    if (!IS_ATOM_INT(_t_51632)){
        _t_51632 = (object)DBL_PTR(_t_51632)->dbl;
    }

    /** emit.e:154		cgi -= 1*/
    _47cgi_51380 = _47cgi_51380 - 1;

    /** emit.e:155		if t > 0 then*/
    if (_t_51632 <= 0)
    goto L1; // [23] 116

    /** emit.e:156			symtab_index s = t -- for type checking*/
    _s_51638 = _t_51632;

    /** emit.e:157			if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26572 = (object)*(((s1_ptr)_2)->base + _t_51632);
    _2 = (object)SEQ_PTR(_26572);
    _26573 = (object)*(((s1_ptr)_2)->base + 3);
    _26572 = NOVALUE;
    if (binary_op_a(NOTEQ, _26573, 3)){
        _26573 = NOVALUE;
        goto L2; // [50] 115
    }
    _26573 = NOVALUE;

    /** emit.e:158				if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_36use_private_list_21884 != 0)
    goto L3; // [58] 82

    /** emit.e:159					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26576 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** emit.e:163				elsif find(t, private_sym) = 0 then*/
    _26578 = find_from(_t_51632, _36private_sym_21883, 1);
    if (_26578 != 0)
    goto L5; // [91] 113

    /** emit.e:165					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51632 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26580 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** emit.e:169		return t*/
    return _t_51632;
    ;
}


void _47TempKeep(object _x_51666)
{
    object _26587 = NOVALUE;
    object _26586 = NOVALUE;
    object _26585 = NOVALUE;
    object _26584 = NOVALUE;
    object _26583 = NOVALUE;
    object _26582 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:173		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26582 = (_x_51666 > 0);
    if (_26582 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26584 = (object)*(((s1_ptr)_2)->base + _x_51666);
    _2 = (object)SEQ_PTR(_26584);
    _26585 = (object)*(((s1_ptr)_2)->base + 3);
    _26584 = NOVALUE;
    if (IS_ATOM_INT(_26585)) {
        _26586 = (_26585 == 3);
    }
    else {
        _26586 = binary_op(EQUALS, _26585, 3);
    }
    _26585 = NOVALUE;
    if (_26586 == 0) {
        DeRef(_26586);
        _26586 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26586) && DBL_PTR(_26586)->dbl == 0.0){
            DeRef(_26586);
            _26586 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26586);
        _26586 = NOVALUE;
    }
    DeRef(_26586);
    _26586 = NOVALUE;

    /** emit.e:174			SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51666 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _26587 = NOVALUE;
L1: 

    /** emit.e:176	end procedure*/
    DeRef(_26582);
    _26582 = NOVALUE;
    return;
    ;
}


void _47TempFree(object _x_51684)
{
    object _26593 = NOVALUE;
    object _26591 = NOVALUE;
    object _26590 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:179		if x > 0 then*/
    if (_x_51684 <= 0)
    goto L1; // [5] 53

    /** emit.e:180			if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26590 = (object)*(((s1_ptr)_2)->base + _x_51684);
    _2 = (object)SEQ_PTR(_26590);
    _26591 = (object)*(((s1_ptr)_2)->base + 3);
    _26590 = NOVALUE;
    if (binary_op_a(NOTEQ, _26591, 3)){
        _26591 = NOVALUE;
        goto L2; // [25] 52
    }
    _26591 = NOVALUE;

    /** emit.e:181				SymTab[x][S_SCOPE] = FREE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51684 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26593 = NOVALUE;

    /** emit.e:182				clear_temp( x )*/
    _47clear_temp(_x_51684);
L2: 
L1: 

    /** emit.e:185	end procedure*/
    return;
    ;
}


void _47TempInteger(object _x_51703)
{
    object _26600 = NOVALUE;
    object _26599 = NOVALUE;
    object _26598 = NOVALUE;
    object _26597 = NOVALUE;
    object _26596 = NOVALUE;
    object _26595 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_51703)) {
        _1 = (object)(DBL_PTR(_x_51703)->dbl);
        DeRefDS(_x_51703);
        _x_51703 = _1;
    }

    /** emit.e:188		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26595 = (_x_51703 > 0);
    if (_26595 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26597 = (object)*(((s1_ptr)_2)->base + _x_51703);
    _2 = (object)SEQ_PTR(_26597);
    _26598 = (object)*(((s1_ptr)_2)->base + 3);
    _26597 = NOVALUE;
    if (IS_ATOM_INT(_26598)) {
        _26599 = (_26598 == 3);
    }
    else {
        _26599 = binary_op(EQUALS, _26598, 3);
    }
    _26598 = NOVALUE;
    if (_26599 == 0) {
        DeRef(_26599);
        _26599 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26599) && DBL_PTR(_26599)->dbl == 0.0){
            DeRef(_26599);
            _26599 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26599);
        _26599 = NOVALUE;
    }
    DeRef(_26599);
    _26599 = NOVALUE;

    /** emit.e:189			SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51703 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _26600 = NOVALUE;
L1: 

    /** emit.e:191	end procedure*/
    DeRef(_26595);
    _26595 = NOVALUE;
    return;
    ;
}


object _47LexName(object _t_51720, object _defname_51721)
{
    object _name_51723 = NOVALUE;
    object _26609 = NOVALUE;
    object _26607 = NOVALUE;
    object _26605 = NOVALUE;
    object _26604 = NOVALUE;
    object _26603 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_51720)) {
        _1 = (object)(DBL_PTR(_t_51720)->dbl);
        DeRefDS(_t_51720);
        _t_51720 = _1;
    }

    /** emit.e:197		for i = 1 to length(token_name) do*/
    _26603 = 80;
    {
        object _i_51725;
        _i_51725 = 1;
L1: 
        if (_i_51725 > 80){
            goto L2; // [12] 82
        }

        /** emit.e:198			if t = token_name[i][LEX_NUMBER] then*/
        _2 = (object)SEQ_PTR(_47token_name_51387);
        _26604 = (object)*(((s1_ptr)_2)->base + _i_51725);
        _2 = (object)SEQ_PTR(_26604);
        _26605 = (object)*(((s1_ptr)_2)->base + 1);
        _26604 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_51720, _26605)){
            _26605 = NOVALUE;
            goto L3; // [31] 75
        }
        _26605 = NOVALUE;

        /** emit.e:199				name = token_name[i][LEX_NAME]*/
        _2 = (object)SEQ_PTR(_47token_name_51387);
        _26607 = (object)*(((s1_ptr)_2)->base + _i_51725);
        DeRef(_name_51723);
        _2 = (object)SEQ_PTR(_26607);
        _name_51723 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_name_51723);
        _26607 = NOVALUE;

        /** emit.e:200				if not find(' ', name) then*/
        _26609 = find_from(32, _name_51723, 1);
        if (_26609 != 0)
        goto L4; // [56] 68
        _26609 = NOVALUE;

        /** emit.e:201					name = "'" & name & "'"*/
        {
            object concat_list[3];

            concat_list[0] = _26611;
            concat_list[1] = _name_51723;
            concat_list[2] = _26611;
            Concat_N((object_ptr)&_name_51723, concat_list, 3);
        }
L4: 

        /** emit.e:203				return name*/
        DeRefDSi(_defname_51721);
        return _name_51723;
L3: 

        /** emit.e:205		end for*/
        _i_51725 = _i_51725 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** emit.e:206		return defname -- try to avoid this case*/
    DeRef(_name_51723);
    return _defname_51721;
    ;
}


void _47InitEmit()
{
    object _0, _1, _2;
    

    /** emit.e:212		cg_stack = repeat(0, 400)*/
    DeRef(_47cg_stack_51379);
    _47cg_stack_51379 = Repeat(0, 400);

    /** emit.e:213		cgi = 0*/
    _47cgi_51380 = 0;

    /** emit.e:214	end procedure*/
    return;
    ;
}


object _47IsInteger(object _sym_51744)
{
    object _mode_51745 = NOVALUE;
    object _t_51747 = NOVALUE;
    object _pt_51748 = NOVALUE;
    object _26634 = NOVALUE;
    object _26633 = NOVALUE;
    object _26631 = NOVALUE;
    object _26630 = NOVALUE;
    object _26629 = NOVALUE;
    object _26627 = NOVALUE;
    object _26626 = NOVALUE;
    object _26625 = NOVALUE;
    object _26624 = NOVALUE;
    object _26622 = NOVALUE;
    object _26618 = NOVALUE;
    object _26615 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_51744)) {
        _1 = (object)(DBL_PTR(_sym_51744)->dbl);
        DeRefDS(_sym_51744);
        _sym_51744 = _1;
    }

    /** emit.e:221		if sym < 1 then*/
    if (_sym_51744 >= 1)
    goto L1; // [5] 16

    /** emit.e:223			return 0*/
    return 0;
L1: 

    /** emit.e:226		mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26615 = (object)*(((s1_ptr)_2)->base + _sym_51744);
    _2 = (object)SEQ_PTR(_26615);
    _mode_51745 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_51745)){
        _mode_51745 = (object)DBL_PTR(_mode_51745)->dbl;
    }
    _26615 = NOVALUE;

    /** emit.e:227		if mode = M_NORMAL then*/
    if (_mode_51745 != 1)
    goto L2; // [36] 136

    /** emit.e:228			t = SymTab[sym][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26618 = (object)*(((s1_ptr)_2)->base + _sym_51744);
    _2 = (object)SEQ_PTR(_26618);
    _t_51747 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_51747)){
        _t_51747 = (object)DBL_PTR(_t_51747)->dbl;
    }
    _26618 = NOVALUE;

    /** emit.e:229			if t = integer_type then*/
    if (_t_51747 != _54integer_type_47142)
    goto L3; // [60] 73

    /** emit.e:230				return TRUE*/
    return _13TRUE_447;
L3: 

    /** emit.e:232			if t > 0 then*/
    if (_t_51747 <= 0)
    goto L4; // [75] 215

    /** emit.e:233				pt = SymTab[t][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26622 = (object)*(((s1_ptr)_2)->base + _t_51747);
    _2 = (object)SEQ_PTR(_26622);
    _pt_51748 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_51748)){
        _pt_51748 = (object)DBL_PTR(_pt_51748)->dbl;
    }
    _26622 = NOVALUE;

    /** emit.e:234				if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_51748 == 0) {
        goto L4; // [97] 215
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26625 = (object)*(((s1_ptr)_2)->base + _pt_51748);
    _2 = (object)SEQ_PTR(_26625);
    _26626 = (object)*(((s1_ptr)_2)->base + 15);
    _26625 = NOVALUE;
    if (IS_ATOM_INT(_26626)) {
        _26627 = (_26626 == _54integer_type_47142);
    }
    else {
        _26627 = binary_op(EQUALS, _26626, _54integer_type_47142);
    }
    _26626 = NOVALUE;
    if (_26627 == 0) {
        DeRef(_26627);
        _26627 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26627) && DBL_PTR(_26627)->dbl == 0.0){
            DeRef(_26627);
            _26627 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26627);
        _26627 = NOVALUE;
    }
    DeRef(_26627);
    _26627 = NOVALUE;

    /** emit.e:235					return TRUE   -- usertype(integer x)*/
    return _13TRUE_447;
    goto L4; // [133] 215
L2: 

    /** emit.e:239		elsif mode = M_CONSTANT then*/
    if (_mode_51745 != 2)
    goto L5; // [140] 176

    /** emit.e:240			if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26629 = (object)*(((s1_ptr)_2)->base + _sym_51744);
    _2 = (object)SEQ_PTR(_26629);
    _26630 = (object)*(((s1_ptr)_2)->base + 1);
    _26629 = NOVALUE;
    if (IS_ATOM_INT(_26630))
    _26631 = 1;
    else if (IS_ATOM_DBL(_26630))
    _26631 = IS_ATOM_INT(DoubleToInt(_26630));
    else
    _26631 = 0;
    _26630 = NOVALUE;
    if (_26631 == 0)
    {
        _26631 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26631 = NOVALUE;
    }

    /** emit.e:241				return TRUE*/
    return _13TRUE_447;
    goto L4; // [173] 215
L5: 

    /** emit.e:244		elsif mode = M_TEMP then*/
    if (_mode_51745 != 3)
    goto L6; // [180] 214

    /** emit.e:245			if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26633 = (object)*(((s1_ptr)_2)->base + _sym_51744);
    _2 = (object)SEQ_PTR(_26633);
    _26634 = (object)*(((s1_ptr)_2)->base + 5);
    _26633 = NOVALUE;
    if (binary_op_a(NOTEQ, _26634, 1)){
        _26634 = NOVALUE;
        goto L7; // [200] 213
    }
    _26634 = NOVALUE;

    /** emit.e:246				return TRUE*/
    return _13TRUE_447;
L7: 
L6: 
L4: 

    /** emit.e:250		return FALSE*/
    return _13FALSE_445;
    ;
}


void _47emit(object _val_51805)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_51805)) {
        _1 = (object)(DBL_PTR(_val_51805)->dbl);
        DeRefDS(_val_51805);
        _val_51805 = _1;
    }

    /** emit.e:260		Code = append(Code, val)*/
    Append(&_36Code_21859, _36Code_21859, _val_51805);

    /** emit.e:261	end procedure*/
    return;
    ;
}


void _47emit_opnd(object _opnd_51812)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_51812)) {
        _1 = (object)(DBL_PTR(_opnd_51812)->dbl);
        DeRefDS(_opnd_51812);
        _opnd_51812 = _1;
    }

    /** emit.e:271			Push(opnd)*/
    _47Push(_opnd_51812);

    /** emit.e:272			previous_op = -1  -- N.B.*/
    _36previous_op_21869 = -1;

    /** emit.e:273	end procedure*/
    return;
    ;
}


void _47emit_addr(object _x_51816)
{
    object _0, _1, _2;
    

    /** emit.e:277			Code = append(Code, x)*/
    Ref(_x_51816);
    Append(&_36Code_21859, _36Code_21859, _x_51816);

    /** emit.e:278	end procedure*/
    DeRef(_x_51816);
    return;
    ;
}


void _47emit_opcode(object _op_51822)
{
    object _0, _1, _2;
    

    /** emit.e:282		Code = append(Code, op)*/
    Append(&_36Code_21859, _36Code_21859, _op_51822);

    /** emit.e:283	end procedure*/
    return;
    ;
}


void _47emit_temp(object _tempsym_51856, object _referenced_51857)
{
    object _26665 = NOVALUE;
    object _26664 = NOVALUE;
    object _26663 = NOVALUE;
    object _26662 = NOVALUE;
    object _26661 = NOVALUE;
    object _26660 = NOVALUE;
    object _26659 = NOVALUE;
    object _26658 = NOVALUE;
    object _26657 = NOVALUE;
    object _26656 = NOVALUE;
    object _26655 = NOVALUE;
    object _26654 = NOVALUE;
    object _26653 = NOVALUE;
    object _26652 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:307		if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_36TRANSLATE_21369 != 0)
    goto L1; // [7] 129

    /** emit.e:308			if sequence(tempsym) then*/
    _26652 = IS_SEQUENCE(_tempsym_51856);
    if (_26652 == 0)
    {
        _26652 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26652 = NOVALUE;
    }

    /** emit.e:309				for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_51856)){
            _26653 = SEQ_PTR(_tempsym_51856)->length;
    }
    else {
        _26653 = 1;
    }
    {
        object _i_51864;
        _i_51864 = 1;
L3: 
        if (_i_51864 > _26653){
            goto L4; // [23] 50
        }

        /** emit.e:310					emit_temp( tempsym[i], referenced )*/
        _2 = (object)SEQ_PTR(_tempsym_51856);
        _26654 = (object)*(((s1_ptr)_2)->base + _i_51864);
        DeRef(_26655);
        _26655 = _referenced_51857;
        Ref(_26654);
        _47emit_temp(_26654, _26655);
        _26654 = NOVALUE;
        _26655 = NOVALUE;

        /** emit.e:311				end for*/
        _i_51864 = _i_51864 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** emit.e:313			elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_51856)) {
        _26656 = (_tempsym_51856 > 0);
    }
    else {
        _26656 = binary_op(GREATER, _tempsym_51856, 0);
    }
    if (IS_ATOM_INT(_26656)) {
        if (_26656 == 0) {
            DeRef(_26657);
            _26657 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26656)->dbl == 0.0) {
            DeRef(_26657);
            _26657 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_51856);
    _26658 = _54sym_mode(_tempsym_51856);
    if (IS_ATOM_INT(_26658)) {
        _26659 = (_26658 == 3);
    }
    else {
        _26659 = binary_op(EQUALS, _26658, 3);
    }
    DeRef(_26658);
    _26658 = NOVALUE;
    DeRef(_26657);
    if (IS_ATOM_INT(_26659))
    _26657 = (_26659 != 0);
    else
    _26657 = DBL_PTR(_26659)->dbl != 0.0;
L6: 
    if (_26657 == 0) {
        _26660 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_51856);
    _26661 = _47IsInteger(_tempsym_51856);
    if (IS_ATOM_INT(_26661)) {
        _26662 = (_26661 == 0);
    }
    else {
        _26662 = unary_op(NOT, _26661);
    }
    DeRef(_26661);
    _26661 = NOVALUE;
    if (IS_ATOM_INT(_26662))
    _26660 = (_26662 != 0);
    else
    _26660 = DBL_PTR(_26662)->dbl != 0.0;
L7: 
    if (_26660 == 0) {
        goto L8; // [92] 127
    }
    _26664 = find_from(_tempsym_51856, _47emitted_temps_51852, 1);
    _26665 = (_26664 == 0);
    _26664 = NOVALUE;
    if (_26665 == 0)
    {
        DeRef(_26665);
        _26665 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26665);
        _26665 = NOVALUE;
    }

    /** emit.e:319				emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_47emitted_temps_51852) && IS_ATOM(_tempsym_51856)) {
        Ref(_tempsym_51856);
        Append(&_47emitted_temps_51852, _47emitted_temps_51852, _tempsym_51856);
    }
    else if (IS_ATOM(_47emitted_temps_51852) && IS_SEQUENCE(_tempsym_51856)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51852, _47emitted_temps_51852, _tempsym_51856);
    }

    /** emit.e:320				emitted_temp_referenced &= referenced*/
    Append(&_47emitted_temp_referenced_51853, _47emitted_temp_referenced_51853, _referenced_51857);
L8: 
L5: 
L1: 

    /** emit.e:323	end procedure*/
    DeRef(_tempsym_51856);
    DeRef(_26662);
    _26662 = NOVALUE;
    DeRef(_26656);
    _26656 = NOVALUE;
    DeRef(_26659);
    _26659 = NOVALUE;
    return;
    ;
}


void _47flush_temps(object _except_for_51886)
{
    object _refs_51889 = NOVALUE;
    object _novalues_51890 = NOVALUE;
    object _sym_51895 = NOVALUE;
    object _26680 = NOVALUE;
    object _26679 = NOVALUE;
    object _26678 = NOVALUE;
    object _26677 = NOVALUE;
    object _26675 = NOVALUE;
    object _26671 = NOVALUE;
    object _26670 = NOVALUE;
    object _26668 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:332		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** emit.e:333			return*/
    DeRefDS(_except_for_51886);
    DeRef(_refs_51889);
    DeRefi(_novalues_51890);
    return;
L1: 

    /** emit.e:336		sequence*/

    /** emit.e:337			refs = {},*/
    RefDS(_22190);
    DeRef(_refs_51889);
    _refs_51889 = _22190;

    /** emit.e:338			novalues = {}*/
    RefDS(_22190);
    DeRefi(_novalues_51890);
    _novalues_51890 = _22190;

    /** emit.e:340		derefs = {}*/
    RefDS(_22190);
    DeRefi(_47derefs_51883);
    _47derefs_51883 = _22190;

    /** emit.e:341		for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_47emitted_temps_51852)){
            _26668 = SEQ_PTR(_47emitted_temps_51852)->length;
    }
    else {
        _26668 = 1;
    }
    {
        object _i_51892;
        _i_51892 = 1;
L2: 
        if (_i_51892 > _26668){
            goto L3; // [46] 119
        }

        /** emit.e:342			symtab_index sym = emitted_temps[i]*/
        _2 = (object)SEQ_PTR(_47emitted_temps_51852);
        _sym_51895 = (object)*(((s1_ptr)_2)->base + _i_51892);
        if (!IS_ATOM_INT(_sym_51895)){
            _sym_51895 = (object)DBL_PTR(_sym_51895)->dbl;
        }

        /** emit.e:344			if find( sym, except_for ) then*/
        _26670 = find_from(_sym_51895, _except_for_51886, 1);
        if (_26670 == 0)
        {
            _26670 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26670 = NOVALUE;
        }

        /** emit.e:345				continue*/
        goto L5; // [77] 114
L4: 

        /** emit.e:348			if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (object)SEQ_PTR(_47emitted_temp_referenced_51853);
        _26671 = (object)*(((s1_ptr)_2)->base + _i_51892);
        if (binary_op_a(NOTEQ, _26671, 1)){
            _26671 = NOVALUE;
            goto L6; // [88] 103
        }
        _26671 = NOVALUE;

        /** emit.e:349				derefs &= sym*/
        Append(&_47derefs_51883, _47derefs_51883, _sym_51895);
        goto L7; // [100] 110
L6: 

        /** emit.e:351				novalues &= sym*/
        Append(&_novalues_51890, _novalues_51890, _sym_51895);
L7: 

        /** emit.e:353		end for*/
L5: 
        _i_51892 = _i_51892 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** emit.e:355		if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_51886)){
            _26675 = SEQ_PTR(_except_for_51886)->length;
    }
    else {
        _26675 = 1;
    }
    if (_26675 != 0)
    goto L8; // [124] 132
    _26675 = NOVALUE;

    /** emit.e:356			clear_last()*/
    _47clear_last();
L8: 

    /** emit.e:359		for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_47derefs_51883)){
            _26677 = SEQ_PTR(_47derefs_51883)->length;
    }
    else {
        _26677 = 1;
    }
    {
        object _i_51910;
        _i_51910 = 1;
L9: 
        if (_i_51910 > _26677){
            goto LA; // [139] 171
        }

        /** emit.e:360			emit( DEREF_TEMP )*/
        _47emit(208);

        /** emit.e:361			emit( derefs[i] )*/
        _2 = (object)SEQ_PTR(_47derefs_51883);
        _26678 = (object)*(((s1_ptr)_2)->base + _i_51910);
        _47emit(_26678);
        _26678 = NOVALUE;

        /** emit.e:362		end for*/
        _i_51910 = _i_51910 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** emit.e:364		for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_51890)){
            _26679 = SEQ_PTR(_novalues_51890)->length;
    }
    else {
        _26679 = 1;
    }
    {
        object _i_51915;
        _i_51915 = 1;
LB: 
        if (_i_51915 > _26679){
            goto LC; // [176] 206
        }

        /** emit.e:365			emit( NOVALUE_TEMP )*/
        _47emit(209);

        /** emit.e:366			emit( novalues[i] )*/
        _2 = (object)SEQ_PTR(_novalues_51890);
        _26680 = (object)*(((s1_ptr)_2)->base + _i_51915);
        _47emit(_26680);
        _26680 = NOVALUE;

        /** emit.e:367		end for*/
        _i_51915 = _i_51915 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** emit.e:369		emitted_temps = {}*/
    RefDS(_22190);
    DeRef(_47emitted_temps_51852);
    _47emitted_temps_51852 = _22190;

    /** emit.e:370		emitted_temp_referenced = {}*/
    RefDS(_22190);
    DeRef(_47emitted_temp_referenced_51853);
    _47emitted_temp_referenced_51853 = _22190;

    /** emit.e:371	end procedure*/
    DeRefDS(_except_for_51886);
    DeRef(_refs_51889);
    DeRefi(_novalues_51890);
    return;
    ;
}


void _47flush_temp(object _temp_51922)
{
    object _except_for_51923 = NOVALUE;
    object _ix_51924 = NOVALUE;
    object _26682 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_51922)) {
        _1 = (object)(DBL_PTR(_temp_51922)->dbl);
        DeRefDS(_temp_51922);
        _temp_51922 = _1;
    }

    /** emit.e:374		sequence except_for = emitted_temps*/
    RefDS(_47emitted_temps_51852);
    DeRef(_except_for_51923);
    _except_for_51923 = _47emitted_temps_51852;

    /** emit.e:375		integer ix = find( temp, emitted_temps )*/
    _ix_51924 = find_from(_temp_51922, _47emitted_temps_51852, 1);

    /** emit.e:376		if ix then*/
    if (_ix_51924 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** emit.e:377			flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_51923);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51924)) ? _ix_51924 : (object)(DBL_PTR(_ix_51924)->dbl);
        int stop = (IS_ATOM_INT(_ix_51924)) ? _ix_51924 : (object)(DBL_PTR(_ix_51924)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_except_for_51923);
            DeRef(_26682);
            _26682 = _except_for_51923;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_51923), start, &_26682 );
            }
            else Tail(SEQ_PTR(_except_for_51923), stop+1, &_26682);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_51923), start, &_26682);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26682);
            _26682 = _1;
        }
    }
    _47flush_temps(_26682);
    _26682 = NOVALUE;
L1: 

    /** emit.e:379	end procedure*/
    DeRef(_except_for_51923);
    return;
    ;
}


void _47check_for_temps()
{
    object _26689 = NOVALUE;
    object _26688 = NOVALUE;
    object _26687 = NOVALUE;
    object _26686 = NOVALUE;
    object _26684 = NOVALUE;
    object _26683 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:382		if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_36TRANSLATE_21369 != 0) {
        _26683 = 1;
        goto L1; // [5] 19
    }
    _26684 = (_47last_op_52261 < 1);
    _26683 = (_26684 != 0);
L1: 
    if (_26683 != 0) {
        goto L2; // [19] 34
    }
    _26686 = (_47last_pc_52262 < 1);
    if (_26686 == 0)
    {
        DeRef(_26686);
        _26686 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26686);
        _26686 = NOVALUE;
    }
L2: 

    /** emit.e:383			return*/
    DeRef(_26684);
    _26684 = NOVALUE;
    return;
L3: 

    /** emit.e:386		emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_36Code_21859);
    _26687 = _66current_op(_47last_pc_52262, _36Code_21859);
    _26688 = _66get_target_sym(_26687);
    _26687 = NOVALUE;
    _2 = (object)SEQ_PTR(_47op_temp_ref_52074);
    _26689 = (object)*(((s1_ptr)_2)->base + _47last_op_52261);
    _47emit_temp(_26688, _26689);
    _26688 = NOVALUE;
    _26689 = NOVALUE;

    /** emit.e:388	end procedure*/
    DeRef(_26684);
    _26684 = NOVALUE;
    return;
    ;
}


void _47clear_temp(object _tempsym_51949)
{
    object _ix_51950 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_51949)) {
        _1 = (object)(DBL_PTR(_tempsym_51949)->dbl);
        DeRefDS(_tempsym_51949);
        _tempsym_51949 = _1;
    }

    /** emit.e:391		integer ix = find( tempsym, emitted_temps )*/
    _ix_51950 = find_from(_tempsym_51949, _47emitted_temps_51852, 1);

    /** emit.e:392		if ix then*/
    if (_ix_51950 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** emit.e:393			emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temps_51852);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51950)) ? _ix_51950 : (object)(DBL_PTR(_ix_51950)->dbl);
        int stop = (IS_ATOM_INT(_ix_51950)) ? _ix_51950 : (object)(DBL_PTR(_ix_51950)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temps_51852), start, &_47emitted_temps_51852 );
            }
            else Tail(SEQ_PTR(_47emitted_temps_51852), stop+1, &_47emitted_temps_51852);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temps_51852), start, &_47emitted_temps_51852);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temps_51852 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temps_51852)->ref == 1));
        }
    }

    /** emit.e:394			emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temp_referenced_51853);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51950)) ? _ix_51950 : (object)(DBL_PTR(_ix_51950)->dbl);
        int stop = (IS_ATOM_INT(_ix_51950)) ? _ix_51950 : (object)(DBL_PTR(_ix_51950)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temp_referenced_51853), start, &_47emitted_temp_referenced_51853 );
            }
            else Tail(SEQ_PTR(_47emitted_temp_referenced_51853), stop+1, &_47emitted_temp_referenced_51853);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temp_referenced_51853), start, &_47emitted_temp_referenced_51853);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temp_referenced_51853 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temp_referenced_51853)->ref == 1));
        }
    }
L1: 

    /** emit.e:396	end procedure*/
    return;
    ;
}


object _47pop_temps()
{
    object _new_emitted_51957 = NOVALUE;
    object _new_referenced_51958 = NOVALUE;
    object _26693 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:402		sequence new_emitted  = emitted_temps*/
    RefDS(_47emitted_temps_51852);
    DeRef(_new_emitted_51957);
    _new_emitted_51957 = _47emitted_temps_51852;

    /** emit.e:403		sequence new_referenced = emitted_temp_referenced*/
    RefDS(_47emitted_temp_referenced_51853);
    DeRef(_new_referenced_51958);
    _new_referenced_51958 = _47emitted_temp_referenced_51853;

    /** emit.e:405		emitted_temps  = {}*/
    RefDS(_22190);
    DeRefDS(_47emitted_temps_51852);
    _47emitted_temps_51852 = _22190;

    /** emit.e:406		emitted_temp_referenced = {}*/
    RefDS(_22190);
    DeRefDS(_47emitted_temp_referenced_51853);
    _47emitted_temp_referenced_51853 = _22190;

    /** emit.e:407		return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_51958);
    RefDS(_new_emitted_51957);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _new_emitted_51957;
    ((intptr_t *)_2)[2] = _new_referenced_51958;
    _26693 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_51957);
    DeRefDS(_new_referenced_51958);
    return _26693;
    ;
}


object _47get_temps(object _add_to_51962)
{
    object _26698 = NOVALUE;
    object _26697 = NOVALUE;
    object _26696 = NOVALUE;
    object _26695 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:416		add_to[1] &= emitted_temps*/
    _2 = (object)SEQ_PTR(_add_to_51962);
    _26695 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26695) && IS_ATOM(_47emitted_temps_51852)) {
    }
    else if (IS_ATOM(_26695) && IS_SEQUENCE(_47emitted_temps_51852)) {
        Ref(_26695);
        Prepend(&_26696, _47emitted_temps_51852, _26695);
    }
    else {
        Concat((object_ptr)&_26696, _26695, _47emitted_temps_51852);
        _26695 = NOVALUE;
    }
    _26695 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51962);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51962 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26696;
    if( _1 != _26696 ){
        DeRef(_1);
    }
    _26696 = NOVALUE;

    /** emit.e:417		add_to[2] &= emitted_temp_referenced*/
    _2 = (object)SEQ_PTR(_add_to_51962);
    _26697 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26697) && IS_ATOM(_47emitted_temp_referenced_51853)) {
    }
    else if (IS_ATOM(_26697) && IS_SEQUENCE(_47emitted_temp_referenced_51853)) {
        Ref(_26697);
        Prepend(&_26698, _47emitted_temp_referenced_51853, _26697);
    }
    else {
        Concat((object_ptr)&_26698, _26697, _47emitted_temp_referenced_51853);
        _26697 = NOVALUE;
    }
    _26697 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51962);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51962 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26698;
    if( _1 != _26698 ){
        DeRef(_1);
    }
    _26698 = NOVALUE;

    /** emit.e:418		return add_to*/
    return _add_to_51962;
    ;
}


void _47push_temps(object _temps_51970)
{
    object _26701 = NOVALUE;
    object _26699 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:426		emitted_temps &= temps[1]*/
    _2 = (object)SEQ_PTR(_temps_51970);
    _26699 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_47emitted_temps_51852) && IS_ATOM(_26699)) {
        Ref(_26699);
        Append(&_47emitted_temps_51852, _47emitted_temps_51852, _26699);
    }
    else if (IS_ATOM(_47emitted_temps_51852) && IS_SEQUENCE(_26699)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51852, _47emitted_temps_51852, _26699);
    }
    _26699 = NOVALUE;

    /** emit.e:427		emitted_temp_referenced &= temps[2]*/
    _2 = (object)SEQ_PTR(_temps_51970);
    _26701 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_47emitted_temp_referenced_51853) && IS_ATOM(_26701)) {
        Ref(_26701);
        Append(&_47emitted_temp_referenced_51853, _47emitted_temp_referenced_51853, _26701);
    }
    else if (IS_ATOM(_47emitted_temp_referenced_51853) && IS_SEQUENCE(_26701)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temp_referenced_51853, _47emitted_temp_referenced_51853, _26701);
    }
    _26701 = NOVALUE;

    /** emit.e:428		flush_temps()*/
    RefDS(_22190);
    _47flush_temps(_22190);

    /** emit.e:429	end procedure*/
    DeRefDS(_temps_51970);
    return;
    ;
}


void _47backpatch(object _index_51977, object _val_51978)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_51977)) {
        _1 = (object)(DBL_PTR(_index_51977)->dbl);
        DeRefDS(_index_51977);
        _index_51977 = _1;
    }
    if (!IS_ATOM_INT(_val_51978)) {
        _1 = (object)(DBL_PTR(_val_51978)->dbl);
        DeRefDS(_val_51978);
        _val_51978 = _1;
    }

    /** emit.e:433			Code[index] = val*/
    _2 = (object)SEQ_PTR(_36Code_21859);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21859 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_51977);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_51978;
    DeRef(_1);

    /** emit.e:434	end procedure*/
    return;
    ;
}


void _47cont11ii(object _op_52162, object _ii_52164)
{
    object _t_52165 = NOVALUE;
    object _source_52166 = NOVALUE;
    object _c_52167 = NOVALUE;
    object _26710 = NOVALUE;
    object _26709 = NOVALUE;
    object _26707 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:580		emit_opcode(op)*/
    _47emit_opcode(_op_52162);

    /** emit.e:581		source = Pop()*/
    _source_52166 = _47Pop();
    if (!IS_ATOM_INT(_source_52166)) {
        _1 = (object)(DBL_PTR(_source_52166)->dbl);
        DeRefDS(_source_52166);
        _source_52166 = _1;
    }

    /** emit.e:582		emit_addr(source)*/
    _47emit_addr(_source_52166);

    /** emit.e:583		assignable = TRUE*/
    _47assignable_51382 = _13TRUE_447;

    /** emit.e:584		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51980);
    _t_52165 = (object)*(((s1_ptr)_2)->base + _op_52162);

    /** emit.e:587		if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26707 = (_t_52165 == 1);
    if (_26707 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_52164 == 0) {
        _26709 = 0;
        goto L2; // [47] 59
    }
    _26710 = _47IsInteger(_source_52166);
    if (IS_ATOM_INT(_26710))
    _26709 = (_26710 != 0);
    else
    _26709 = DBL_PTR(_26710)->dbl != 0.0;
L2: 
    if (_26709 == 0)
    {
        _26709 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26709 = NOVALUE;
    }
L1: 

    /** emit.e:588			c = NewTempSym()*/
    _c_52167 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_52167)) {
        _1 = (object)(DBL_PTR(_c_52167)->dbl);
        DeRefDS(_c_52167);
        _c_52167 = _1;
    }

    /** emit.e:589			TempInteger(c)*/
    _47TempInteger(_c_52167);
    goto L4; // [77] 95
L3: 

    /** emit.e:591			c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_52167 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_52167)) {
        _1 = (object)(DBL_PTR(_c_52167)->dbl);
        DeRefDS(_c_52167);
        _c_52167 = _1;
    }

    /** emit.e:592			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_52167, 1);
L4: 

    /** emit.e:595		Push(c)*/
    _47Push(_c_52167);

    /** emit.e:596		emit_addr(c)*/
    _47emit_addr(_c_52167);

    /** emit.e:597	end procedure*/
    DeRef(_26707);
    _26707 = NOVALUE;
    DeRef(_26710);
    _26710 = NOVALUE;
    return;
    ;
}


void _47cont21d(object _op_52184, object _a_52185, object _b_52186, object _ii_52188)
{
    object _c_52189 = NOVALUE;
    object _t_52190 = NOVALUE;
    object _26720 = NOVALUE;
    object _26719 = NOVALUE;
    object _26718 = NOVALUE;
    object _26717 = NOVALUE;
    object _26715 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:602		assignable = TRUE*/
    _47assignable_51382 = _13TRUE_447;

    /** emit.e:603		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51980);
    _t_52190 = (object)*(((s1_ptr)_2)->base + _op_52184);

    /** emit.e:604		if op = C_FUNC then*/
    if (_op_52184 != 133)
    goto L1; // [26] 38

    /** emit.e:605			emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21775);
L1: 

    /** emit.e:607		if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26715 = (_t_52190 == 1);
    if (_26715 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_52188 == 0) {
        _26717 = 0;
        goto L3; // [50] 62
    }
    _26718 = _47IsInteger(_a_52185);
    if (IS_ATOM_INT(_26718))
    _26717 = (_26718 != 0);
    else
    _26717 = DBL_PTR(_26718)->dbl != 0.0;
L3: 
    if (_26717 == 0) {
        DeRef(_26719);
        _26719 = 0;
        goto L4; // [62] 74
    }
    _26720 = _47IsInteger(_b_52186);
    if (IS_ATOM_INT(_26720))
    _26719 = (_26720 != 0);
    else
    _26719 = DBL_PTR(_26720)->dbl != 0.0;
L4: 
    if (_26719 == 0)
    {
        _26719 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26719 = NOVALUE;
    }
L2: 

    /** emit.e:608			c = NewTempSym()*/
    _c_52189 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_52189)) {
        _1 = (object)(DBL_PTR(_c_52189)->dbl);
        DeRefDS(_c_52189);
        _c_52189 = _1;
    }

    /** emit.e:609			TempInteger(c)*/
    _47TempInteger(_c_52189);
    goto L6; // [92] 110
L5: 

    /** emit.e:611			c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_52189 = _54NewTempSym(0);
    if (!IS_ATOM_INT(_c_52189)) {
        _1 = (object)(DBL_PTR(_c_52189)->dbl);
        DeRefDS(_c_52189);
        _c_52189 = _1;
    }

    /** emit.e:612			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_52189, 1);
L6: 

    /** emit.e:614		Push(c)*/
    _47Push(_c_52189);

    /** emit.e:615		emit_addr(c)*/
    _47emit_addr(_c_52189);

    /** emit.e:616	end procedure*/
    DeRef(_26718);
    _26718 = NOVALUE;
    DeRef(_26715);
    _26715 = NOVALUE;
    DeRef(_26720);
    _26720 = NOVALUE;
    return;
    ;
}


void _47cont21ii(object _op_52212, object _ii_52214)
{
    object _a_52215 = NOVALUE;
    object _b_52216 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:621		b = Pop()*/
    _b_52216 = _47Pop();
    if (!IS_ATOM_INT(_b_52216)) {
        _1 = (object)(DBL_PTR(_b_52216)->dbl);
        DeRefDS(_b_52216);
        _b_52216 = _1;
    }

    /** emit.e:622		emit_opcode(op)*/
    _47emit_opcode(_op_52212);

    /** emit.e:623		a = Pop()*/
    _a_52215 = _47Pop();
    if (!IS_ATOM_INT(_a_52215)) {
        _1 = (object)(DBL_PTR(_a_52215)->dbl);
        DeRefDS(_a_52215);
        _a_52215 = _1;
    }

    /** emit.e:624		emit_addr(a)*/
    _47emit_addr(_a_52215);

    /** emit.e:625		emit_addr(b)*/
    _47emit_addr(_b_52216);

    /** emit.e:626		cont21d(op, a, b, ii)*/
    _47cont21d(_op_52212, _a_52215, _b_52216, _ii_52214);

    /** emit.e:627	end procedure*/
    return;
    ;
}


object _47good_string(object _elements_52221)
{
    object _obj_52222 = NOVALUE;
    object _ep_52224 = NOVALUE;
    object _e_52226 = NOVALUE;
    object _element_vals_52227 = NOVALUE;
    object _26743 = NOVALUE;
    object _26742 = NOVALUE;
    object _26741 = NOVALUE;
    object _26740 = NOVALUE;
    object _26739 = NOVALUE;
    object _26738 = NOVALUE;
    object _26737 = NOVALUE;
    object _26736 = NOVALUE;
    object _26735 = NOVALUE;
    object _26734 = NOVALUE;
    object _26733 = NOVALUE;
    object _26731 = NOVALUE;
    object _26728 = NOVALUE;
    object _26727 = NOVALUE;
    object _26726 = NOVALUE;
    object _26725 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:634		sequence element_vals*/

    /** emit.e:636		if TRANSLATE and length(elements) > 10000 then*/
    if (_36TRANSLATE_21369 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_52221)){
            _26726 = SEQ_PTR(_elements_52221)->length;
    }
    else {
        _26726 = 1;
    }
    _26727 = (_26726 > 10000);
    _26726 = NOVALUE;
    if (_26727 == 0)
    {
        DeRef(_26727);
        _26727 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26727);
        _26727 = NOVALUE;
    }

    /** emit.e:637			return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_52221);
    DeRef(_obj_52222);
    DeRef(_element_vals_52227);
    return -1;
L1: 

    /** emit.e:639		element_vals = {}*/
    RefDS(_22190);
    DeRef(_element_vals_52227);
    _element_vals_52227 = _22190;

    /** emit.e:640		for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_52221)){
            _26728 = SEQ_PTR(_elements_52221)->length;
    }
    else {
        _26728 = 1;
    }
    {
        object _i_52234;
        _i_52234 = 1;
L2: 
        if (_i_52234 > _26728){
            goto L3; // [43] 183
        }

        /** emit.e:641			ep = elements[i]*/
        _2 = (object)SEQ_PTR(_elements_52221);
        _ep_52224 = (object)*(((s1_ptr)_2)->base + _i_52234);
        if (!IS_ATOM_INT(_ep_52224)){
            _ep_52224 = (object)DBL_PTR(_ep_52224)->dbl;
        }

        /** emit.e:642			if ep < 1 then*/
        if (_ep_52224 >= 1)
        goto L4; // [60] 71

        /** emit.e:644				return -1*/
        DeRefDS(_elements_52221);
        DeRef(_obj_52222);
        DeRef(_element_vals_52227);
        return -1;
L4: 

        /** emit.e:646			e = ep*/
        _e_52226 = _ep_52224;

        /** emit.e:647			obj = SymTab[e][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26731 = (object)*(((s1_ptr)_2)->base + _e_52226);
        DeRef(_obj_52222);
        _2 = (object)SEQ_PTR(_26731);
        _obj_52222 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_52222);
        _26731 = NOVALUE;

        /** emit.e:648			if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26733 = (object)*(((s1_ptr)_2)->base + _e_52226);
        _2 = (object)SEQ_PTR(_26733);
        _26734 = (object)*(((s1_ptr)_2)->base + 3);
        _26733 = NOVALUE;
        if (IS_ATOM_INT(_26734)) {
            _26735 = (_26734 == 2);
        }
        else {
            _26735 = binary_op(EQUALS, _26734, 2);
        }
        _26734 = NOVALUE;
        if (IS_ATOM_INT(_26735)) {
            if (_26735 == 0) {
                DeRef(_26736);
                _26736 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26735)->dbl == 0.0) {
                DeRef(_26736);
                _26736 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_52222))
        _26737 = 1;
        else if (IS_ATOM_DBL(_obj_52222))
        _26737 = IS_ATOM_INT(DoubleToInt(_obj_52222));
        else
        _26737 = 0;
        DeRef(_26736);
        _26736 = (_26737 != 0);
L5: 
        if (_26736 == 0) {
            goto L6; // [123] 169
        }
        _26739 = (_36TRANSLATE_21369 == 0);
        if (_26739 != 0) {
            DeRef(_26740);
            _26740 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_52222)) {
            _26741 = (_obj_52222 >= 1);
        }
        else {
            _26741 = binary_op(GREATEREQ, _obj_52222, 1);
        }
        if (IS_ATOM_INT(_26741)) {
            if (_26741 == 0) {
                DeRef(_26742);
                _26742 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26741)->dbl == 0.0) {
                DeRef(_26742);
                _26742 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_52222)) {
            _26743 = (_obj_52222 <= 255);
        }
        else {
            _26743 = binary_op(LESSEQ, _obj_52222, 255);
        }
        DeRef(_26742);
        if (IS_ATOM_INT(_26743))
        _26742 = (_26743 != 0);
        else
        _26742 = DBL_PTR(_26743)->dbl != 0.0;
L8: 
        DeRef(_26740);
        _26740 = (_26742 != 0);
L7: 
        if (_26740 == 0)
        {
            _26740 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26740 = NOVALUE;
        }

        /** emit.e:653				element_vals = prepend(element_vals, obj)*/
        Ref(_obj_52222);
        Prepend(&_element_vals_52227, _element_vals_52227, _obj_52222);
        goto L9; // [166] 176
L6: 

        /** emit.e:655				return -1*/
        DeRefDS(_elements_52221);
        DeRef(_obj_52222);
        DeRef(_element_vals_52227);
        DeRef(_26739);
        _26739 = NOVALUE;
        DeRef(_26741);
        _26741 = NOVALUE;
        DeRef(_26743);
        _26743 = NOVALUE;
        DeRef(_26735);
        _26735 = NOVALUE;
        return -1;
L9: 

        /** emit.e:657		end for*/
        _i_52234 = _i_52234 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** emit.e:658		return element_vals*/
    DeRefDS(_elements_52221);
    DeRef(_obj_52222);
    DeRef(_26739);
    _26739 = NOVALUE;
    DeRef(_26741);
    _26741 = NOVALUE;
    DeRef(_26743);
    _26743 = NOVALUE;
    DeRef(_26735);
    _26735 = NOVALUE;
    return _element_vals_52227;
    ;
}


object _47Last_op()
{
    object _0, _1, _2;
    

    /** emit.e:664		return last_op*/
    return _47last_op_52261;
    ;
}


object _47Last_pc()
{
    object _0, _1, _2;
    

    /** emit.e:668		return last_pc*/
    return _47last_pc_52262;
    ;
}


void _47move_last_pc(object _amount_52269)
{
    object _0, _1, _2;
    

    /** emit.e:672		if last_pc > 0 then*/
    if (_47last_pc_52262 <= 0)
    goto L1; // [7] 20

    /** emit.e:673			last_pc += amount*/
    _47last_pc_52262 = _47last_pc_52262 + _amount_52269;
L1: 

    /** emit.e:675	end procedure*/
    return;
    ;
}


void _47clear_last()
{
    object _0, _1, _2;
    

    /** emit.e:678		last_op = 0*/
    _47last_op_52261 = 0;

    /** emit.e:679		last_pc = 0*/
    _47last_pc_52262 = 0;

    /** emit.e:680	end procedure*/
    return;
    ;
}


void _47clear_op()
{
    object _0, _1, _2;
    

    /** emit.e:683		previous_op = -1*/
    _36previous_op_21869 = -1;

    /** emit.e:684		assignable = FALSE*/
    _47assignable_51382 = _13FALSE_445;

    /** emit.e:685	end procedure*/
    return;
    ;
}


void _47inlined_function()
{
    object _0, _1, _2;
    

    /** emit.e:689		previous_op = PROC*/
    _36previous_op_21869 = 27;

    /** emit.e:690		assignable = TRUE*/
    _47assignable_51382 = _13TRUE_447;

    /** emit.e:691		inlined = TRUE*/
    _47inlined_52280 = _13TRUE_447;

    /** emit.e:692	end procedure*/
    return;
    ;
}


void _47add_inline_target(object _pc_52291)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52291)) {
        _1 = (object)(DBL_PTR(_pc_52291)->dbl);
        DeRefDS(_pc_52291);
        _pc_52291 = _1;
    }

    /** emit.e:696		inlined_targets &= pc*/
    Append(&_47inlined_targets_52288, _47inlined_targets_52288, _pc_52291);

    /** emit.e:697	end procedure*/
    return;
    ;
}


void _47clear_inline_targets()
{
    object _0, _1, _2;
    

    /** emit.e:700		inlined_targets = {}*/
    RefDS(_22190);
    DeRefi(_47inlined_targets_52288);
    _47inlined_targets_52288 = _22190;

    /** emit.e:701	end procedure*/
    return;
    ;
}


void _47emit_inline(object _code_52297)
{
    object _0, _1, _2;
    

    /** emit.e:704		last_pc = 0*/
    _47last_pc_52262 = 0;

    /** emit.e:705		last_op = 0*/
    _47last_op_52261 = 0;

    /** emit.e:706		Code &= code*/
    Concat((object_ptr)&_36Code_21859, _36Code_21859, _code_52297);

    /** emit.e:707	end procedure*/
    DeRefDS(_code_52297);
    return;
    ;
}


void _47emit_op(object _op_52302)
{
    object _a_52304 = NOVALUE;
    object _b_52305 = NOVALUE;
    object _c_52306 = NOVALUE;
    object _d_52307 = NOVALUE;
    object _source_52308 = NOVALUE;
    object _target_52309 = NOVALUE;
    object _subsym_52310 = NOVALUE;
    object _lhs_var_52312 = NOVALUE;
    object _ib_52313 = NOVALUE;
    object _ic_52314 = NOVALUE;
    object _n_52315 = NOVALUE;
    object _obj_52316 = NOVALUE;
    object _elements_52317 = NOVALUE;
    object _element_vals_52318 = NOVALUE;
    object _last_pc_backup_52319 = NOVALUE;
    object _last_op_backup_52320 = NOVALUE;
    object _temp_52329 = NOVALUE;
    object _real_op_52629 = NOVALUE;
    object _ref_52636 = NOVALUE;
    object _paths_52666 = NOVALUE;
    object _if_code_52746 = NOVALUE;
    object _if_code_52785 = NOVALUE;
    object _Top_inlined_Top_at_5482_53404 = NOVALUE;
    object _element_53475 = NOVALUE;
    object _Top_inlined_Top_at_7037_53622 = NOVALUE;
    object _31971 = NOVALUE;
    object _31970 = NOVALUE;
    object _27343 = NOVALUE;
    object _27342 = NOVALUE;
    object _27341 = NOVALUE;
    object _27337 = NOVALUE;
    object _27334 = NOVALUE;
    object _27332 = NOVALUE;
    object _27326 = NOVALUE;
    object _27325 = NOVALUE;
    object _27324 = NOVALUE;
    object _27322 = NOVALUE;
    object _27320 = NOVALUE;
    object _27319 = NOVALUE;
    object _27318 = NOVALUE;
    object _27317 = NOVALUE;
    object _27316 = NOVALUE;
    object _27315 = NOVALUE;
    object _27314 = NOVALUE;
    object _27313 = NOVALUE;
    object _27312 = NOVALUE;
    object _27311 = NOVALUE;
    object _27310 = NOVALUE;
    object _27308 = NOVALUE;
    object _27307 = NOVALUE;
    object _27306 = NOVALUE;
    object _27304 = NOVALUE;
    object _27303 = NOVALUE;
    object _27302 = NOVALUE;
    object _27301 = NOVALUE;
    object _27300 = NOVALUE;
    object _27299 = NOVALUE;
    object _27298 = NOVALUE;
    object _27297 = NOVALUE;
    object _27296 = NOVALUE;
    object _27293 = NOVALUE;
    object _27290 = NOVALUE;
    object _27289 = NOVALUE;
    object _27288 = NOVALUE;
    object _27287 = NOVALUE;
    object _27285 = NOVALUE;
    object _27283 = NOVALUE;
    object _27271 = NOVALUE;
    object _27263 = NOVALUE;
    object _27260 = NOVALUE;
    object _27259 = NOVALUE;
    object _27258 = NOVALUE;
    object _27257 = NOVALUE;
    object _27254 = NOVALUE;
    object _27253 = NOVALUE;
    object _27252 = NOVALUE;
    object _27251 = NOVALUE;
    object _27250 = NOVALUE;
    object _27249 = NOVALUE;
    object _27248 = NOVALUE;
    object _27247 = NOVALUE;
    object _27246 = NOVALUE;
    object _27245 = NOVALUE;
    object _27244 = NOVALUE;
    object _27242 = NOVALUE;
    object _27238 = NOVALUE;
    object _27237 = NOVALUE;
    object _27236 = NOVALUE;
    object _27235 = NOVALUE;
    object _27234 = NOVALUE;
    object _27233 = NOVALUE;
    object _27232 = NOVALUE;
    object _27231 = NOVALUE;
    object _27230 = NOVALUE;
    object _27229 = NOVALUE;
    object _27228 = NOVALUE;
    object _27226 = NOVALUE;
    object _27221 = NOVALUE;
    object _27220 = NOVALUE;
    object _27218 = NOVALUE;
    object _27217 = NOVALUE;
    object _27216 = NOVALUE;
    object _27214 = NOVALUE;
    object _27211 = NOVALUE;
    object _27207 = NOVALUE;
    object _27204 = NOVALUE;
    object _27203 = NOVALUE;
    object _27202 = NOVALUE;
    object _27201 = NOVALUE;
    object _27200 = NOVALUE;
    object _27199 = NOVALUE;
    object _27197 = NOVALUE;
    object _27196 = NOVALUE;
    object _27194 = NOVALUE;
    object _27193 = NOVALUE;
    object _27192 = NOVALUE;
    object _27191 = NOVALUE;
    object _27190 = NOVALUE;
    object _27189 = NOVALUE;
    object _27188 = NOVALUE;
    object _27187 = NOVALUE;
    object _27186 = NOVALUE;
    object _27185 = NOVALUE;
    object _27183 = NOVALUE;
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27180 = NOVALUE;
    object _27179 = NOVALUE;
    object _27178 = NOVALUE;
    object _27177 = NOVALUE;
    object _27176 = NOVALUE;
    object _27175 = NOVALUE;
    object _27174 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _27170 = NOVALUE;
    object _27169 = NOVALUE;
    object _27167 = NOVALUE;
    object _27164 = NOVALUE;
    object _27163 = NOVALUE;
    object _27162 = NOVALUE;
    object _27161 = NOVALUE;
    object _27160 = NOVALUE;
    object _27159 = NOVALUE;
    object _27158 = NOVALUE;
    object _27157 = NOVALUE;
    object _27156 = NOVALUE;
    object _27155 = NOVALUE;
    object _27154 = NOVALUE;
    object _27153 = NOVALUE;
    object _27152 = NOVALUE;
    object _27151 = NOVALUE;
    object _27150 = NOVALUE;
    object _27148 = NOVALUE;
    object _27144 = NOVALUE;
    object _27142 = NOVALUE;
    object _27141 = NOVALUE;
    object _27139 = NOVALUE;
    object _27137 = NOVALUE;
    object _27135 = NOVALUE;
    object _27134 = NOVALUE;
    object _27132 = NOVALUE;
    object _27131 = NOVALUE;
    object _27130 = NOVALUE;
    object _27129 = NOVALUE;
    object _27128 = NOVALUE;
    object _27127 = NOVALUE;
    object _27126 = NOVALUE;
    object _27125 = NOVALUE;
    object _27124 = NOVALUE;
    object _27123 = NOVALUE;
    object _27122 = NOVALUE;
    object _27121 = NOVALUE;
    object _27120 = NOVALUE;
    object _27119 = NOVALUE;
    object _27118 = NOVALUE;
    object _27117 = NOVALUE;
    object _27116 = NOVALUE;
    object _27115 = NOVALUE;
    object _27114 = NOVALUE;
    object _27112 = NOVALUE;
    object _27110 = NOVALUE;
    object _27109 = NOVALUE;
    object _27107 = NOVALUE;
    object _27104 = NOVALUE;
    object _27103 = NOVALUE;
    object _27101 = NOVALUE;
    object _27100 = NOVALUE;
    object _27099 = NOVALUE;
    object _27097 = NOVALUE;
    object _27089 = NOVALUE;
    object _27088 = NOVALUE;
    object _27087 = NOVALUE;
    object _27086 = NOVALUE;
    object _27085 = NOVALUE;
    object _27084 = NOVALUE;
    object _27083 = NOVALUE;
    object _27082 = NOVALUE;
    object _27081 = NOVALUE;
    object _27080 = NOVALUE;
    object _27079 = NOVALUE;
    object _27078 = NOVALUE;
    object _27077 = NOVALUE;
    object _27076 = NOVALUE;
    object _27075 = NOVALUE;
    object _27074 = NOVALUE;
    object _27073 = NOVALUE;
    object _27072 = NOVALUE;
    object _27071 = NOVALUE;
    object _27070 = NOVALUE;
    object _27069 = NOVALUE;
    object _27068 = NOVALUE;
    object _27067 = NOVALUE;
    object _27066 = NOVALUE;
    object _27060 = NOVALUE;
    object _27059 = NOVALUE;
    object _27056 = NOVALUE;
    object _27053 = NOVALUE;
    object _27052 = NOVALUE;
    object _27051 = NOVALUE;
    object _27050 = NOVALUE;
    object _27049 = NOVALUE;
    object _27048 = NOVALUE;
    object _27047 = NOVALUE;
    object _27046 = NOVALUE;
    object _27045 = NOVALUE;
    object _27044 = NOVALUE;
    object _27042 = NOVALUE;
    object _27041 = NOVALUE;
    object _27040 = NOVALUE;
    object _27038 = NOVALUE;
    object _27036 = NOVALUE;
    object _27035 = NOVALUE;
    object _27034 = NOVALUE;
    object _27033 = NOVALUE;
    object _27032 = NOVALUE;
    object _27031 = NOVALUE;
    object _27030 = NOVALUE;
    object _27029 = NOVALUE;
    object _27028 = NOVALUE;
    object _27027 = NOVALUE;
    object _27025 = NOVALUE;
    object _27024 = NOVALUE;
    object _27022 = NOVALUE;
    object _27021 = NOVALUE;
    object _27020 = NOVALUE;
    object _27019 = NOVALUE;
    object _27018 = NOVALUE;
    object _27016 = NOVALUE;
    object _27015 = NOVALUE;
    object _27014 = NOVALUE;
    object _27013 = NOVALUE;
    object _27012 = NOVALUE;
    object _27011 = NOVALUE;
    object _27010 = NOVALUE;
    object _27009 = NOVALUE;
    object _27007 = NOVALUE;
    object _27006 = NOVALUE;
    object _27005 = NOVALUE;
    object _27004 = NOVALUE;
    object _27003 = NOVALUE;
    object _27001 = NOVALUE;
    object _27000 = NOVALUE;
    object _26998 = NOVALUE;
    object _26997 = NOVALUE;
    object _26996 = NOVALUE;
    object _26995 = NOVALUE;
    object _26994 = NOVALUE;
    object _26992 = NOVALUE;
    object _26990 = NOVALUE;
    object _26988 = NOVALUE;
    object _26987 = NOVALUE;
    object _26985 = NOVALUE;
    object _26984 = NOVALUE;
    object _26983 = NOVALUE;
    object _26982 = NOVALUE;
    object _26981 = NOVALUE;
    object _26980 = NOVALUE;
    object _26979 = NOVALUE;
    object _26978 = NOVALUE;
    object _26977 = NOVALUE;
    object _26976 = NOVALUE;
    object _26975 = NOVALUE;
    object _26974 = NOVALUE;
    object _26973 = NOVALUE;
    object _26972 = NOVALUE;
    object _26971 = NOVALUE;
    object _26970 = NOVALUE;
    object _26969 = NOVALUE;
    object _26966 = NOVALUE;
    object _26965 = NOVALUE;
    object _26963 = NOVALUE;
    object _26962 = NOVALUE;
    object _26961 = NOVALUE;
    object _26960 = NOVALUE;
    object _26959 = NOVALUE;
    object _26957 = NOVALUE;
    object _26955 = NOVALUE;
    object _26954 = NOVALUE;
    object _26953 = NOVALUE;
    object _26952 = NOVALUE;
    object _26951 = NOVALUE;
    object _26950 = NOVALUE;
    object _26949 = NOVALUE;
    object _26948 = NOVALUE;
    object _26947 = NOVALUE;
    object _26944 = NOVALUE;
    object _26943 = NOVALUE;
    object _26941 = NOVALUE;
    object _26940 = NOVALUE;
    object _26939 = NOVALUE;
    object _26938 = NOVALUE;
    object _26937 = NOVALUE;
    object _26934 = NOVALUE;
    object _26933 = NOVALUE;
    object _26932 = NOVALUE;
    object _26931 = NOVALUE;
    object _26930 = NOVALUE;
    object _26929 = NOVALUE;
    object _26928 = NOVALUE;
    object _26923 = NOVALUE;
    object _26922 = NOVALUE;
    object _26921 = NOVALUE;
    object _26919 = NOVALUE;
    object _26918 = NOVALUE;
    object _26916 = NOVALUE;
    object _26915 = NOVALUE;
    object _26910 = NOVALUE;
    object _26909 = NOVALUE;
    object _26908 = NOVALUE;
    object _26907 = NOVALUE;
    object _26906 = NOVALUE;
    object _26900 = NOVALUE;
    object _26899 = NOVALUE;
    object _26897 = NOVALUE;
    object _26896 = NOVALUE;
    object _26895 = NOVALUE;
    object _26894 = NOVALUE;
    object _26893 = NOVALUE;
    object _26892 = NOVALUE;
    object _26891 = NOVALUE;
    object _26890 = NOVALUE;
    object _26889 = NOVALUE;
    object _26888 = NOVALUE;
    object _26887 = NOVALUE;
    object _26885 = NOVALUE;
    object _26884 = NOVALUE;
    object _26883 = NOVALUE;
    object _26882 = NOVALUE;
    object _26881 = NOVALUE;
    object _26880 = NOVALUE;
    object _26879 = NOVALUE;
    object _26878 = NOVALUE;
    object _26877 = NOVALUE;
    object _26876 = NOVALUE;
    object _26875 = NOVALUE;
    object _26874 = NOVALUE;
    object _26873 = NOVALUE;
    object _26872 = NOVALUE;
    object _26870 = NOVALUE;
    object _26869 = NOVALUE;
    object _26868 = NOVALUE;
    object _26867 = NOVALUE;
    object _26864 = NOVALUE;
    object _26863 = NOVALUE;
    object _26862 = NOVALUE;
    object _26861 = NOVALUE;
    object _26859 = NOVALUE;
    object _26858 = NOVALUE;
    object _26857 = NOVALUE;
    object _26856 = NOVALUE;
    object _26854 = NOVALUE;
    object _26853 = NOVALUE;
    object _26852 = NOVALUE;
    object _26851 = NOVALUE;
    object _26850 = NOVALUE;
    object _26849 = NOVALUE;
    object _26848 = NOVALUE;
    object _26847 = NOVALUE;
    object _26846 = NOVALUE;
    object _26845 = NOVALUE;
    object _26844 = NOVALUE;
    object _26843 = NOVALUE;
    object _26842 = NOVALUE;
    object _26841 = NOVALUE;
    object _26839 = NOVALUE;
    object _26838 = NOVALUE;
    object _26837 = NOVALUE;
    object _26836 = NOVALUE;
    object _26835 = NOVALUE;
    object _26833 = NOVALUE;
    object _26832 = NOVALUE;
    object _26831 = NOVALUE;
    object _26830 = NOVALUE;
    object _26829 = NOVALUE;
    object _26825 = NOVALUE;
    object _26824 = NOVALUE;
    object _26823 = NOVALUE;
    object _26822 = NOVALUE;
    object _26821 = NOVALUE;
    object _26819 = NOVALUE;
    object _26818 = NOVALUE;
    object _26817 = NOVALUE;
    object _26816 = NOVALUE;
    object _26815 = NOVALUE;
    object _26814 = NOVALUE;
    object _26813 = NOVALUE;
    object _26812 = NOVALUE;
    object _26811 = NOVALUE;
    object _26810 = NOVALUE;
    object _26809 = NOVALUE;
    object _26808 = NOVALUE;
    object _26807 = NOVALUE;
    object _26806 = NOVALUE;
    object _26805 = NOVALUE;
    object _26804 = NOVALUE;
    object _26803 = NOVALUE;
    object _26802 = NOVALUE;
    object _26800 = NOVALUE;
    object _26799 = NOVALUE;
    object _26798 = NOVALUE;
    object _26797 = NOVALUE;
    object _26796 = NOVALUE;
    object _26795 = NOVALUE;
    object _26794 = NOVALUE;
    object _26793 = NOVALUE;
    object _26792 = NOVALUE;
    object _26790 = NOVALUE;
    object _26789 = NOVALUE;
    object _26788 = NOVALUE;
    object _26786 = NOVALUE;
    object _26785 = NOVALUE;
    object _26783 = NOVALUE;
    object _26781 = NOVALUE;
    object _26780 = NOVALUE;
    object _26779 = NOVALUE;
    object _26778 = NOVALUE;
    object _26777 = NOVALUE;
    object _26776 = NOVALUE;
    object _26772 = NOVALUE;
    object _26771 = NOVALUE;
    object _26770 = NOVALUE;
    object _26768 = NOVALUE;
    object _26767 = NOVALUE;
    object _26766 = NOVALUE;
    object _26765 = NOVALUE;
    object _26764 = NOVALUE;
    object _26763 = NOVALUE;
    object _26762 = NOVALUE;
    object _26761 = NOVALUE;
    object _26760 = NOVALUE;
    object _26759 = NOVALUE;
    object _26758 = NOVALUE;
    object _26757 = NOVALUE;
    object _26756 = NOVALUE;
    object _26755 = NOVALUE;
    object _26754 = NOVALUE;
    object _26749 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_52302)) {
        _1 = (object)(DBL_PTR(_op_52302)->dbl);
        DeRefDS(_op_52302);
        _op_52302 = _1;
    }

    /** emit.e:717		integer ib, ic, n*/

    /** emit.e:718		object obj*/

    /** emit.e:719		sequence elements*/

    /** emit.e:720		object element_vals*/

    /** emit.e:722		check_for_temps()*/
    _47check_for_temps();

    /** emit.e:723		integer last_pc_backup = last_pc*/
    _last_pc_backup_52319 = _47last_pc_52262;

    /** emit.e:724		integer last_op_backup = last_op*/
    _last_op_backup_52320 = _47last_op_52261;

    /** emit.e:726		last_op = op*/
    _47last_op_52261 = _op_52302;

    /** emit.e:727		last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21859)){
            _26749 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _26749 = 1;
    }
    _47last_pc_52262 = _26749 + 1;
    _26749 = NOVALUE;

    /** emit.e:729		switch op label "EMIT" do*/
    _0 = _op_52302;
    switch ( _0 ){ 

        /** emit.e:730		case ASSIGN then*/
        case 18:

        /** emit.e:731			sequence temp = {}*/
        RefDS(_22190);
        DeRef(_temp_52329);
        _temp_52329 = _22190;

        /** emit.e:732			if not TRANSLATE and*/
        _26754 = (_36TRANSLATE_21369 == 0);
        if (_26754 == 0) {
            goto L1; // [70] 202
        }
        _26756 = (_36previous_op_21869 == 92);
        if (_26756 != 0) {
            DeRef(_26757);
            _26757 = 1;
            goto L2; // [82] 98
        }
        _26758 = (_36previous_op_21869 == 25);
        _26757 = (_26758 != 0);
L2: 
        if (_26757 == 0)
        {
            _26757 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26757 = NOVALUE;
        }

        /** emit.e:736				while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_36Code_21859)){
                _26759 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26759 = 1;
        }
        _26760 = _26759 - 1;
        _26759 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26761 = (object)*(((s1_ptr)_2)->base + _26760);
        if (IS_ATOM_INT(_26761)) {
            _26762 = (_26761 == 208);
        }
        else {
            _26762 = binary_op(EQUALS, _26761, 208);
        }
        _26761 = NOVALUE;
        if (IS_ATOM_INT(_26762)) {
            if (_26762 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26762)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_36Code_21859)){
                _26764 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26764 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26765 = (object)*(((s1_ptr)_2)->base + _26764);
        _26766 = find_from(_26765, _47derefs_51883, 1);
        _26765 = NOVALUE;
        if (_26766 == 0)
        {
            _26766 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26766 = NOVALUE;
        }

        /** emit.e:739					temp &= Code[$]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26767 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26767 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26768 = (object)*(((s1_ptr)_2)->base + _26767);
        if (IS_SEQUENCE(_temp_52329) && IS_ATOM(_26768)) {
            Ref(_26768);
            Append(&_temp_52329, _temp_52329, _26768);
        }
        else if (IS_ATOM(_temp_52329) && IS_SEQUENCE(_26768)) {
        }
        else {
            Concat((object_ptr)&_temp_52329, _temp_52329, _26768);
        }
        _26768 = NOVALUE;

        /** emit.e:740					Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26770 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26770 = 1;
        }
        _26771 = _26770 - 1;
        _26770 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21859)){
                _26772 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26772 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21859);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26771)) ? _26771 : (object)(DBL_PTR(_26771)->dbl);
            int stop = (IS_ATOM_INT(_26772)) ? _26772 : (object)(DBL_PTR(_26772)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21859), start, &_36Code_21859 );
                }
                else Tail(SEQ_PTR(_36Code_21859), stop+1, &_36Code_21859);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21859), start, &_36Code_21859);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21859 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21859)->ref == 1));
            }
        }
        _26771 = NOVALUE;
        _26772 = NOVALUE;

        /** emit.e:741					emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_52329);
        _47emit_temp(_temp_52329, 1);

        /** emit.e:742				end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** emit.e:746			source = Pop()*/
        _source_52308 = _47Pop();
        if (!IS_ATOM_INT(_source_52308)) {
            _1 = (object)(DBL_PTR(_source_52308)->dbl);
            DeRefDS(_source_52308);
            _source_52308 = _1;
        }

        /** emit.e:747			target = Pop()*/
        _target_52309 = _47Pop();
        if (!IS_ATOM_INT(_target_52309)) {
            _1 = (object)(DBL_PTR(_target_52309)->dbl);
            DeRefDS(_target_52309);
            _target_52309 = _1;
        }

        /** emit.e:748			if assignable then*/
        if (_47assignable_51382 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** emit.e:750				if inlined then*/
        if (_47inlined_52280 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** emit.e:751					inlined = 0*/
        _47inlined_52280 = 0;

        /** emit.e:752					if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_47inlined_targets_52288)){
                _26776 = SEQ_PTR(_47inlined_targets_52288)->length;
        }
        else {
            _26776 = 1;
        }
        if (_26776 == 0)
        {
            _26776 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26776 = NOVALUE;
        }

        /** emit.e:753						for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_47inlined_targets_52288)){
                _26777 = SEQ_PTR(_47inlined_targets_52288)->length;
        }
        else {
            _26777 = 1;
        }
        {
            object _i_52372;
            _i_52372 = 1;
L8: 
            if (_i_52372 > _26777){
                goto L9; // [252] 280
            }

            /** emit.e:754							Code[inlined_targets[i]] = target*/
            _2 = (object)SEQ_PTR(_47inlined_targets_52288);
            _26778 = (object)*(((s1_ptr)_2)->base + _i_52372);
            _2 = (object)SEQ_PTR(_36Code_21859);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _36Code_21859 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _26778);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _target_52309;
            DeRef(_1);

            /** emit.e:755						end for*/
            _i_52372 = _i_52372 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** emit.e:756						clear_inline_targets()*/

        /** emit.e:700		inlined_targets = {}*/
        RefDS(_22190);
        DeRefi(_47inlined_targets_52288);
        _47inlined_targets_52288 = _22190;

        /** emit.e:701	end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** emit.e:759					assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:760					clear_last()*/

        /** emit.e:678		last_op = 0*/
        _47last_op_52261 = 0;

        /** emit.e:679		last_pc = 0*/
        _47last_pc_52262 = 0;

        /** emit.e:680	end procedure*/
        goto LB; // [316] 319
LB: 

        /** emit.e:761					break "EMIT"*/
        DeRef(_temp_52329);
        _temp_52329 = NOVALUE;
        goto LC; // [323] 7739
L6: 

        /** emit.e:764				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26779 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26779 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26780 = (object)*(((s1_ptr)_2)->base + _26779);
        Ref(_26780);
        _47clear_temp(_26780);
        _26780 = NOVALUE;

        /** emit.e:765				Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26781 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26781 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21859);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26781)) ? _26781 : (object)(DBL_PTR(_26781)->dbl);
            int stop = (IS_ATOM_INT(_26781)) ? _26781 : (object)(DBL_PTR(_26781)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21859), start, &_36Code_21859 );
                }
                else Tail(SEQ_PTR(_36Code_21859), stop+1, &_36Code_21859);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21859), start, &_36Code_21859);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21859 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21859)->ref == 1));
            }
        }
        _26781 = NOVALUE;
        _26781 = NOVALUE;

        /** emit.e:766				op = previous_op -- keep same previous op*/
        _op_52302 = _36previous_op_21869;

        /** emit.e:767				if IsInteger(target) then*/
        _26783 = _47IsInteger(_target_52309);
        if (_26783 == 0) {
            DeRef(_26783);
            _26783 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26783) && DBL_PTR(_26783)->dbl == 0.0){
                DeRef(_26783);
                _26783 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26783);
            _26783 = NOVALUE;
        }
        DeRef(_26783);
        _26783 = NOVALUE;

        /** emit.e:768					if previous_op = RHS_SUBS then*/
        if (_36previous_op_21869 != 25)
        goto LE; // [381] 412

        /** emit.e:769						op = RHS_SUBS_I*/
        _op_52302 = 114;

        /** emit.e:770						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26785 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26785 = 1;
        }
        _26786 = _26785 - 2;
        _26785 = NOVALUE;
        _47backpatch(_26786, 114);
        _26786 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** emit.e:772					elsif previous_op = PLUS1 then*/
        if (_36previous_op_21869 != 93)
        goto L10; // [418] 449

        /** emit.e:773						op = PLUS1_I*/
        _op_52302 = 117;

        /** emit.e:774						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26788 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26788 = 1;
        }
        _26789 = _26788 - 2;
        _26788 = NOVALUE;
        _47backpatch(_26789, 117);
        _26789 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** emit.e:776					elsif previous_op = PLUS or previous_op = MINUS then*/
        _26790 = (_36previous_op_21869 == 11);
        if (_26790 != 0) {
            goto L11; // [459] 476
        }
        _26792 = (_36previous_op_21869 == 10);
        if (_26792 == 0)
        {
            DeRef(_26792);
            _26792 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26792);
            _26792 = NOVALUE;
        }
L11: 

        /** emit.e:777						if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26793 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26793 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26794 = (object)*(((s1_ptr)_2)->base + _26793);
        Ref(_26794);
        _26795 = _47IsInteger(_26794);
        _26794 = NOVALUE;
        if (IS_ATOM_INT(_26795)) {
            if (_26795 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26795)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_36Code_21859)){
                _26797 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26797 = 1;
        }
        _26798 = _26797 - 1;
        _26797 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26799 = (object)*(((s1_ptr)_2)->base + _26798);
        Ref(_26799);
        _26800 = _47IsInteger(_26799);
        _26799 = NOVALUE;
        if (_26800 == 0) {
            DeRef(_26800);
            _26800 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26800) && DBL_PTR(_26800)->dbl == 0.0){
                DeRef(_26800);
                _26800 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26800);
            _26800 = NOVALUE;
        }
        DeRef(_26800);
        _26800 = NOVALUE;

        /** emit.e:779							if previous_op = PLUS then*/
        if (_36previous_op_21869 != 11)
        goto L13; // [522] 538

        /** emit.e:780								op = PLUS_I*/
        _op_52302 = 115;
        goto L14; // [535] 548
L13: 

        /** emit.e:782								op = MINUS_I*/
        _op_52302 = 116;
L14: 

        /** emit.e:784							backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26802 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26802 = 1;
        }
        _26803 = _26802 - 2;
        _26802 = NOVALUE;
        _47backpatch(_26803, _op_52302);
        _26803 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** emit.e:790						if IsInteger(source) then*/
        _26804 = _47IsInteger(_source_52308);
        if (_26804 == 0) {
            DeRef(_26804);
            _26804 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26804) && DBL_PTR(_26804)->dbl == 0.0){
                DeRef(_26804);
                _26804 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26804);
            _26804 = NOVALUE;
        }
        DeRef(_26804);
        _26804 = NOVALUE;

        /** emit.e:791							op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_52302 = 113;
L15: 
LF: 
LD: 

        /** emit.e:795				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:796				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto L16; // [598] 743
L5: 

        /** emit.e:798				if IsInteger(source) and IsInteger(target) then*/
        _26805 = _47IsInteger(_source_52308);
        if (IS_ATOM_INT(_26805)) {
            if (_26805 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26805)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26807 = _47IsInteger(_target_52309);
        if (_26807 == 0) {
            DeRef(_26807);
            _26807 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26807) && DBL_PTR(_26807)->dbl == 0.0){
                DeRef(_26807);
                _26807 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26807);
            _26807 = NOVALUE;
        }
        DeRef(_26807);
        _26807 = NOVALUE;

        /** emit.e:799					op = ASSIGN_I*/
        _op_52302 = 113;
L17: 

        /** emit.e:801				if source > 0 and target > 0 and*/
        _26808 = (_source_52308 > 0);
        if (_26808 == 0) {
            _26809 = 0;
            goto L18; // [635] 647
        }
        _26810 = (_target_52309 > 0);
        _26809 = (_26810 != 0);
L18: 
        if (_26809 == 0) {
            _26811 = 0;
            goto L19; // [647] 673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26812 = (object)*(((s1_ptr)_2)->base + _source_52308);
        _2 = (object)SEQ_PTR(_26812);
        _26813 = (object)*(((s1_ptr)_2)->base + 3);
        _26812 = NOVALUE;
        if (IS_ATOM_INT(_26813)) {
            _26814 = (_26813 == 2);
        }
        else {
            _26814 = binary_op(EQUALS, _26813, 2);
        }
        _26813 = NOVALUE;
        if (IS_ATOM_INT(_26814))
        _26811 = (_26814 != 0);
        else
        _26811 = DBL_PTR(_26814)->dbl != 0.0;
L19: 
        if (_26811 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26816 = (object)*(((s1_ptr)_2)->base + _target_52309);
        _2 = (object)SEQ_PTR(_26816);
        _26817 = (object)*(((s1_ptr)_2)->base + 3);
        _26816 = NOVALUE;
        if (IS_ATOM_INT(_26817)) {
            _26818 = (_26817 == 2);
        }
        else {
            _26818 = binary_op(EQUALS, _26817, 2);
        }
        _26817 = NOVALUE;
        if (_26818 == 0) {
            DeRef(_26818);
            _26818 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26818) && DBL_PTR(_26818)->dbl == 0.0){
                DeRef(_26818);
                _26818 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26818);
            _26818 = NOVALUE;
        }
        DeRef(_26818);
        _26818 = NOVALUE;

        /** emit.e:806					SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_target_52309 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26821 = (object)*(((s1_ptr)_2)->base + _source_52308);
        _2 = (object)SEQ_PTR(_26821);
        _26822 = (object)*(((s1_ptr)_2)->base + 1);
        _26821 = NOVALUE;
        Ref(_26822);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26822;
        if( _1 != _26822 ){
            DeRef(_1);
        }
        _26822 = NOVALUE;
        _26819 = NOVALUE;
L1A: 

        /** emit.e:809				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:810				emit_addr(source)*/
        _47emit_addr(_source_52308);

        /** emit.e:811				last_op = op*/
        _47last_op_52261 = _op_52302;
L16: 

        /** emit.e:814			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:815			emit_addr(target)*/
        _47emit_addr(_target_52309);

        /** emit.e:817			if length(temp) then*/
        if (IS_SEQUENCE(_temp_52329)){
                _26823 = SEQ_PTR(_temp_52329)->length;
        }
        else {
            _26823 = 1;
        }
        if (_26823 == 0)
        {
            _26823 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26823 = NOVALUE;
        }

        /** emit.e:819				for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_52329)){
                _26824 = SEQ_PTR(_temp_52329)->length;
        }
        else {
            _26824 = 1;
        }
        {
            object _i_52475;
            _i_52475 = 1;
L1C: 
            if (_i_52475 > _26824){
                goto L1D; // [768] 791
            }

            /** emit.e:820					flush_temp( temp[i] )*/
            _2 = (object)SEQ_PTR(_temp_52329);
            _26825 = (object)*(((s1_ptr)_2)->base + _i_52475);
            Ref(_26825);
            _47flush_temp(_26825);
            _26825 = NOVALUE;

            /** emit.e:821				end for*/
            _i_52475 = _i_52475 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_52329);
        _temp_52329 = NOVALUE;
        goto LC; // [794] 7739

        /** emit.e:824		case RHS_SUBS then*/
        case 25:

        /** emit.e:825			b = Pop() -- subscript*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:826			c = Pop() -- sequence*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:827			target = NewTempSym() -- target*/
        _target_52309 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_target_52309)) {
            _1 = (object)(DBL_PTR(_target_52309)->dbl);
            DeRefDS(_target_52309);
            _target_52309 = _1;
        }

        /** emit.e:828			if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26829 = (_c_52306 < 0);
        if (_26829 != 0) {
            _26830 = 1;
            goto L1E; // [828] 851
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26831 = (object)*(((s1_ptr)_2)->base + _c_52306);
        if (IS_SEQUENCE(_26831)){
                _26832 = SEQ_PTR(_26831)->length;
        }
        else {
            _26832 = 1;
        }
        _26831 = NOVALUE;
        _26833 = (_26832 < 15);
        _26832 = NOVALUE;
        _26830 = (_26833 != 0);
L1E: 
        if (_26830 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26835 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_26835);
        _26836 = (object)*(((s1_ptr)_2)->base + 15);
        _26835 = NOVALUE;
        if (IS_ATOM_INT(_26836)) {
            _26837 = (_26836 < 0);
        }
        else {
            _26837 = binary_op(LESS, _26836, 0);
        }
        _26836 = NOVALUE;
        if (_26837 == 0) {
            DeRef(_26837);
            _26837 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26837) && DBL_PTR(_26837)->dbl == 0.0){
                DeRef(_26837);
                _26837 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26837);
            _26837 = NOVALUE;
        }
        DeRef(_26837);
        _26837 = NOVALUE;
L1F: 

        /** emit.e:830				op = RHS_SUBS_CHECK*/
        _op_52302 = 92;
        goto L21; // [885] 1049
L20: 

        /** emit.e:831			elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26838 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_26838);
        _26839 = (object)*(((s1_ptr)_2)->base + 3);
        _26838 = NOVALUE;
        if (binary_op_a(NOTEQ, _26839, 1)){
            _26839 = NOVALUE;
            goto L22; // [904] 991
        }
        _26839 = NOVALUE;

        /** emit.e:832				if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26841 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_26841);
        _26842 = (object)*(((s1_ptr)_2)->base + 15);
        _26841 = NOVALUE;
        if (IS_ATOM_INT(_26842)) {
            _26843 = (_26842 != _54sequence_type_47140);
        }
        else {
            _26843 = binary_op(NOTEQ, _26842, _54sequence_type_47140);
        }
        _26842 = NOVALUE;
        if (IS_ATOM_INT(_26843)) {
            if (_26843 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26843)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26845 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_26845);
        _26846 = (object)*(((s1_ptr)_2)->base + 15);
        _26845 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_26846)){
            _26847 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26846)->dbl));
        }
        else{
            _26847 = (object)*(((s1_ptr)_2)->base + _26846);
        }
        _2 = (object)SEQ_PTR(_26847);
        _26848 = (object)*(((s1_ptr)_2)->base + 2);
        _26847 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_26848)){
            _26849 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26848)->dbl));
        }
        else{
            _26849 = (object)*(((s1_ptr)_2)->base + _26848);
        }
        _2 = (object)SEQ_PTR(_26849);
        _26850 = (object)*(((s1_ptr)_2)->base + 15);
        _26849 = NOVALUE;
        if (IS_ATOM_INT(_26850)) {
            _26851 = (_26850 != _54sequence_type_47140);
        }
        else {
            _26851 = binary_op(NOTEQ, _26850, _54sequence_type_47140);
        }
        _26850 = NOVALUE;
        if (_26851 == 0) {
            DeRef(_26851);
            _26851 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26851) && DBL_PTR(_26851)->dbl == 0.0){
                DeRef(_26851);
                _26851 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26851);
            _26851 = NOVALUE;
        }
        DeRef(_26851);
        _26851 = NOVALUE;

        /** emit.e:835					op = RHS_SUBS_CHECK*/
        _op_52302 = 92;
        goto L21; // [988] 1049
L22: 

        /** emit.e:837			elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26852 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_26852);
        _26853 = (object)*(((s1_ptr)_2)->base + 3);
        _26852 = NOVALUE;
        if (IS_ATOM_INT(_26853)) {
            _26854 = (_26853 != 2);
        }
        else {
            _26854 = binary_op(NOTEQ, _26853, 2);
        }
        _26853 = NOVALUE;
        if (IS_ATOM_INT(_26854)) {
            if (_26854 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26854)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26856 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_26856);
        _26857 = (object)*(((s1_ptr)_2)->base + 1);
        _26856 = NOVALUE;
        _26858 = IS_SEQUENCE(_26857);
        _26857 = NOVALUE;
        _26859 = (_26858 == 0);
        _26858 = NOVALUE;
        if (_26859 == 0)
        {
            DeRef(_26859);
            _26859 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26859);
            _26859 = NOVALUE;
        }
L23: 

        /** emit.e:839				op = RHS_SUBS_CHECK*/
        _op_52302 = 92;
L24: 
L21: 

        /** emit.e:841			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:842			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:843			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:844			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:845			Push(target)*/
        _47Push(_target_52309);

        /** emit.e:846			emit_addr(target)*/
        _47emit_addr(_target_52309);

        /** emit.e:847			emit_temp(target, NEW_REFERENCE)*/
        _47emit_temp(_target_52309, 1);

        /** emit.e:848			current_sequence = append(current_sequence, target)*/
        Append(&_47current_sequence_51372, _47current_sequence_51372, _target_52309);

        /** emit.e:849			flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26861 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26861 = 1;
        }
        _26862 = _26861 - 2;
        _26861 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26863 = (object)*(((s1_ptr)_2)->base + _26862);
        Ref(_26863);
        _47flush_temp(_26863);
        _26863 = NOVALUE;
        goto LC; // [1113] 7739

        /** emit.e:851		case PROC then -- procedure, function and type calls*/
        case 27:

        /** emit.e:853			assignable = FALSE -- assume for now*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:854			subsym = op_info1*/
        _subsym_52310 = _47op_info1_51364;

        /** emit.e:855			n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26864 = (object)*(((s1_ptr)_2)->base + _subsym_52310);
        _2 = (object)SEQ_PTR(_26864);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
            _n_52315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
        }
        else{
            _n_52315 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
        }
        if (!IS_ATOM_INT(_n_52315)){
            _n_52315 = (object)DBL_PTR(_n_52315)->dbl;
        }
        _26864 = NOVALUE;

        /** emit.e:857			if subsym = CurrentSub then*/
        if (_subsym_52310 != _36CurrentSub_21775)
        goto L25; // [1155] 1340

        /** emit.e:860				for i = cgi-n+1 to cgi do*/
        _26867 = _47cgi_51380 - _n_52315;
        if ((object)((uintptr_t)_26867 +(uintptr_t) HIGH_BITS) >= 0){
            _26867 = NewDouble((eudouble)_26867);
        }
        if (IS_ATOM_INT(_26867)) {
            _26868 = _26867 + 1;
            if (_26868 > MAXINT){
                _26868 = NewDouble((eudouble)_26868);
            }
        }
        else
        _26868 = binary_op(PLUS, 1, _26867);
        DeRef(_26867);
        _26867 = NOVALUE;
        _26869 = _47cgi_51380;
        {
            object _i_52561;
            Ref(_26868);
            _i_52561 = _26868;
L26: 
            if (binary_op_a(GREATER, _i_52561, _26869)){
                goto L27; // [1176] 1339
            }

            /** emit.e:861					if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26870 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26870 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            if (binary_op_a(LESSEQ, _26870, 0)){
                _26870 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26870 = NOVALUE;

            /** emit.e:862						if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26872 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26872 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_26872)){
                _26873 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26872)->dbl));
            }
            else{
                _26873 = (object)*(((s1_ptr)_2)->base + _26872);
            }
            _2 = (object)SEQ_PTR(_26873);
            _26874 = (object)*(((s1_ptr)_2)->base + 4);
            _26873 = NOVALUE;
            if (IS_ATOM_INT(_26874)) {
                _26875 = (_26874 == 3);
            }
            else {
                _26875 = binary_op(EQUALS, _26874, 3);
            }
            _26874 = NOVALUE;
            if (IS_ATOM_INT(_26875)) {
                if (_26875 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26875)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26877 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_26877)){
                _26878 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26877)->dbl));
            }
            else{
                _26878 = (object)*(((s1_ptr)_2)->base + _26877);
            }
            _2 = (object)SEQ_PTR(_26878);
            _26879 = (object)*(((s1_ptr)_2)->base + 16);
            _26878 = NOVALUE;
            if (IS_ATOM_INT(_26879) && IS_ATOM_INT(_i_52561)) {
                _26880 = (_26879 < _i_52561);
            }
            else {
                _26880 = binary_op(LESS, _26879, _i_52561);
            }
            _26879 = NOVALUE;
            if (_26880 == 0) {
                DeRef(_26880);
                _26880 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26880) && DBL_PTR(_26880)->dbl == 0.0){
                    DeRef(_26880);
                    _26880 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26880);
                _26880 = NOVALUE;
            }
            DeRef(_26880);
            _26880 = NOVALUE;

            /** emit.e:865							emit_opcode(ASSIGN)*/
            _47emit_opcode(18);

            /** emit.e:866							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26881 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26881 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            Ref(_26881);
            _47emit_addr(_26881);
            _26881 = NOVALUE;

            /** emit.e:867							cg_stack[i] = NewTempSym()*/
            _26882 = _54NewTempSym(0);
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _i_52561);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _26882;
            if( _1 != _26882 ){
                DeRef(_1);
            }
            _26882 = NOVALUE;

            /** emit.e:868							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26883 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            Ref(_26883);
            _47emit_addr(_26883);
            _26883 = NOVALUE;

            /** emit.e:869							check_for_temps()*/
            _47check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** emit.e:870						elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26884 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26884 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            Ref(_26884);
            _26885 = _54sym_mode(_26884);
            _26884 = NOVALUE;
            if (binary_op_a(NOTEQ, _26885, 3)){
                DeRef(_26885);
                _26885 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26885);
            _26885 = NOVALUE;

            /** emit.e:871							emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52561)){
                _26887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52561)->dbl));
            }
            else{
                _26887 = (object)*(((s1_ptr)_2)->base + _i_52561);
            }
            Ref(_26887);
            _47emit_temp(_26887, 1);
            _26887 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** emit.e:874				end for*/
            _0 = _i_52561;
            if (IS_ATOM_INT(_i_52561)) {
                _i_52561 = _i_52561 + 1;
                if ((object)((uintptr_t)_i_52561 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52561 = NewDouble((eudouble)_i_52561);
                }
            }
            else {
                _i_52561 = binary_op_a(PLUS, _i_52561, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_52561);
        }
L25: 

        /** emit.e:877			if SymTab[subsym][S_DEPRECATED] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26888 = (object)*(((s1_ptr)_2)->base + _subsym_52310);
        _2 = (object)SEQ_PTR(_26888);
        _26889 = (object)*(((s1_ptr)_2)->base + 30);
        _26888 = NOVALUE;
        if (_26889 == 0) {
            _26889 = NOVALUE;
            goto L2C; // [1354] 1383
        }
        else {
            if (!IS_ATOM_INT(_26889) && DBL_PTR(_26889)->dbl == 0.0){
                _26889 = NOVALUE;
                goto L2C; // [1354] 1383
            }
            _26889 = NOVALUE;
        }
        _26889 = NOVALUE;

        /** emit.e:878				Warning(327, deprecated_warning_flag, { SymTab[subsym][S_NAME] })*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26890 = (object)*(((s1_ptr)_2)->base + _subsym_52310);
        _2 = (object)SEQ_PTR(_26890);
        if (!IS_ATOM_INT(_36S_NAME_21404)){
            _26891 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
        }
        else{
            _26891 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
        }
        _26890 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_26891);
        ((intptr_t*)_2)[1] = _26891;
        _26892 = MAKE_SEQ(_1);
        _26891 = NOVALUE;
        _50Warning(327, 16384, _26892);
        _26892 = NOVALUE;
L2C: 

        /** emit.e:881			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:882			emit_addr(subsym)*/
        _47emit_addr(_subsym_52310);

        /** emit.e:883			for i = cgi-n+1 to cgi do*/
        _26893 = _47cgi_51380 - _n_52315;
        if ((object)((uintptr_t)_26893 +(uintptr_t) HIGH_BITS) >= 0){
            _26893 = NewDouble((eudouble)_26893);
        }
        if (IS_ATOM_INT(_26893)) {
            _26894 = _26893 + 1;
            if (_26894 > MAXINT){
                _26894 = NewDouble((eudouble)_26894);
            }
        }
        else
        _26894 = binary_op(PLUS, 1, _26893);
        DeRef(_26893);
        _26893 = NOVALUE;
        _26895 = _47cgi_51380;
        {
            object _i_52608;
            Ref(_26894);
            _i_52608 = _26894;
L2D: 
            if (binary_op_a(GREATER, _i_52608, _26895)){
                goto L2E; // [1410] 1447
            }

            /** emit.e:884				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52608)){
                _26896 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52608)->dbl));
            }
            else{
                _26896 = (object)*(((s1_ptr)_2)->base + _i_52608);
            }
            Ref(_26896);
            _47emit_addr(_26896);
            _26896 = NOVALUE;

            /** emit.e:885				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52608)){
                _26897 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52608)->dbl));
            }
            else{
                _26897 = (object)*(((s1_ptr)_2)->base + _i_52608);
            }
            Ref(_26897);
            _47emit_temp(_26897, 1);
            _26897 = NOVALUE;

            /** emit.e:886			end for*/
            _0 = _i_52608;
            if (IS_ATOM_INT(_i_52608)) {
                _i_52608 = _i_52608 + 1;
                if ((object)((uintptr_t)_i_52608 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52608 = NewDouble((eudouble)_i_52608);
                }
            }
            else {
                _i_52608 = binary_op_a(PLUS, _i_52608, 1);
            }
            DeRef(_0);
            goto L2D; // [1442] 1417
L2E: 
            ;
            DeRef(_i_52608);
        }

        /** emit.e:888			cgi -= n*/
        _47cgi_51380 = _47cgi_51380 - _n_52315;

        /** emit.e:890			if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26899 = (object)*(((s1_ptr)_2)->base + _subsym_52310);
        _2 = (object)SEQ_PTR(_26899);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _26900 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _26900 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _26899 = NOVALUE;
        if (binary_op_a(EQUALS, _26900, 27)){
            _26900 = NOVALUE;
            goto LC; // [1471] 7739
        }
        _26900 = NOVALUE;

        /** emit.e:891				assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:892				c = NewTempSym() -- put final result in temp*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:893				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);

        /** emit.e:894				Push(c)*/
        _47Push(_c_52306);

        /** emit.e:896				emit_addr(c)*/
        _47emit_addr(_c_52306);
        goto LC; // [1507] 7739

        /** emit.e:900		case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** emit.e:901			assignable = FALSE -- assume for now*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:902			integer real_op*/

        /** emit.e:903			if op = PROC_FORWARD then*/
        if (_op_52302 != 195)
        goto L2F; // [1528] 1544

        /** emit.e:904				real_op = PROC*/
        _real_op_52629 = 27;
        goto L30; // [1541] 1554
L2F: 

        /** emit.e:906				real_op = FUNC*/
        _real_op_52629 = 501;
L30: 

        /** emit.e:908			integer ref*/

        /** emit.e:909			ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_52636 = _44new_forward_reference(_real_op_52629, _47op_info1_51364, _real_op_52629);
        if (!IS_ATOM_INT(_ref_52636)) {
            _1 = (object)(DBL_PTR(_ref_52636)->dbl);
            DeRefDS(_ref_52636);
            _ref_52636 = _1;
        }

        /** emit.e:910			n = Pop() -- number of known args*/
        _n_52315 = _47Pop();
        if (!IS_ATOM_INT(_n_52315)) {
            _1 = (object)(DBL_PTR(_n_52315)->dbl);
            DeRefDS(_n_52315);
            _n_52315 = _1;
        }

        /** emit.e:912			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:913			emit_addr(ref)*/
        _47emit_addr(_ref_52636);

        /** emit.e:914			emit_addr( n ) -- this changes to be the "next" instruction*/
        _47emit_addr(_n_52315);

        /** emit.e:915			for i = cgi-n+1 to cgi do*/
        _26906 = _47cgi_51380 - _n_52315;
        if ((object)((uintptr_t)_26906 +(uintptr_t) HIGH_BITS) >= 0){
            _26906 = NewDouble((eudouble)_26906);
        }
        if (IS_ATOM_INT(_26906)) {
            _26907 = _26906 + 1;
            if (_26907 > MAXINT){
                _26907 = NewDouble((eudouble)_26907);
            }
        }
        else
        _26907 = binary_op(PLUS, 1, _26906);
        DeRef(_26906);
        _26906 = NOVALUE;
        _26908 = _47cgi_51380;
        {
            object _i_52641;
            Ref(_26907);
            _i_52641 = _26907;
L31: 
            if (binary_op_a(GREATER, _i_52641, _26908)){
                goto L32; // [1609] 1646
            }

            /** emit.e:916				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52641)){
                _26909 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52641)->dbl));
            }
            else{
                _26909 = (object)*(((s1_ptr)_2)->base + _i_52641);
            }
            Ref(_26909);
            _47emit_addr(_26909);
            _26909 = NOVALUE;

            /** emit.e:917				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_51379);
            if (!IS_ATOM_INT(_i_52641)){
                _26910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52641)->dbl));
            }
            else{
                _26910 = (object)*(((s1_ptr)_2)->base + _i_52641);
            }
            Ref(_26910);
            _47emit_temp(_26910, 1);
            _26910 = NOVALUE;

            /** emit.e:918			end for*/
            _0 = _i_52641;
            if (IS_ATOM_INT(_i_52641)) {
                _i_52641 = _i_52641 + 1;
                if ((object)((uintptr_t)_i_52641 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52641 = NewDouble((eudouble)_i_52641);
                }
            }
            else {
                _i_52641 = binary_op_a(PLUS, _i_52641, 1);
            }
            DeRef(_0);
            goto L31; // [1641] 1616
L32: 
            ;
            DeRef(_i_52641);
        }

        /** emit.e:919			cgi -= n*/
        _47cgi_51380 = _47cgi_51380 - _n_52315;

        /** emit.e:921			if op != PROC_FORWARD then*/
        if (_op_52302 == 195)
        goto L33; // [1658] 1694

        /** emit.e:922				assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:923				c = NewTempSym() -- put final result in temp*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:924				Push(c)*/
        _47Push(_c_52306);

        /** emit.e:926				emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:927				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);
L33: 
        goto LC; // [1696] 7739

        /** emit.e:930		case WARNING then*/
        case 506:

        /** emit.e:931			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:932		    a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:933			Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26915 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_26915);
        _26916 = (object)*(((s1_ptr)_2)->base + 1);
        _26915 = NOVALUE;
        Ref(_26916);
        RefDS(_22190);
        _50Warning(_26916, 64, _22190);
        _26916 = NOVALUE;
        goto LC; // [1737] 7739

        /** emit.e:935		case INCLUDE_PATHS then*/
        case 507:

        /** emit.e:936			sequence paths*/

        /** emit.e:938			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:939		    a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:940		    emit_opcode(RIGHT_BRACE_N)*/
        _47emit_opcode(31);

        /** emit.e:941		    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26918 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_26918);
        _26919 = (object)*(((s1_ptr)_2)->base + 1);
        _26918 = NOVALUE;
        Ref(_26919);
        _0 = _paths_52666;
        _paths_52666 = _48Include_paths(_26919);
        DeRef(_0);
        _26919 = NOVALUE;

        /** emit.e:942		    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_52666)){
                _26921 = SEQ_PTR(_paths_52666)->length;
        }
        else {
            _26921 = 1;
        }
        _47emit(_26921);
        _26921 = NOVALUE;

        /** emit.e:943		    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_52666)){
                _26922 = SEQ_PTR(_paths_52666)->length;
        }
        else {
            _26922 = 1;
        }
        {
            object _i_52678;
            _i_52678 = _26922;
L34: 
            if (_i_52678 < 1){
                goto L35; // [1799] 1830
            }

            /** emit.e:944		        c = NewStringSym(paths[i])*/
            _2 = (object)SEQ_PTR(_paths_52666);
            _26923 = (object)*(((s1_ptr)_2)->base + _i_52678);
            Ref(_26923);
            _c_52306 = _54NewStringSym(_26923);
            _26923 = NOVALUE;
            if (!IS_ATOM_INT(_c_52306)) {
                _1 = (object)(DBL_PTR(_c_52306)->dbl);
                DeRefDS(_c_52306);
                _c_52306 = _1;
            }

            /** emit.e:945		        emit_addr(c)*/
            _47emit_addr(_c_52306);

            /** emit.e:946		    end for*/
            _i_52678 = _i_52678 + -1;
            goto L34; // [1825] 1806
L35: 
            ;
        }

        /** emit.e:947		    b = NewTempSym()*/
        _b_52305 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:948			emit_temp(b, NEW_REFERENCE)*/
        _47emit_temp(_b_52305, 1);

        /** emit.e:949		    Push(b)*/
        _47Push(_b_52305);

        /** emit.e:950		    emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:951			last_op = RIGHT_BRACE_N*/
        _47last_op_52261 = 31;

        /** emit.e:952			op = last_op*/
        _op_52302 = 31;
        DeRef(_paths_52666);
        _paths_52666 = NOVALUE;
        goto LC; // [1872] 7739

        /** emit.e:955		case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** emit.e:961			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:962			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:963			if op = UPDATE_GLOBALS then*/
        if (_op_52302 != 89)
        goto LC; // [1944] 7739

        /** emit.e:964				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:965				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto LC; // [1959] 7739

        /** emit.e:969		case IF, WHILE then*/
        case 20:
        case 47:

        /** emit.e:970			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:971			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:973			if previous_op >= LESS and previous_op <= NOT then*/
        _26928 = (_36previous_op_21869 >= 1);
        if (_26928 == 0) {
            goto L36; // [1991] 2283
        }
        _26930 = (_36previous_op_21869 <= 7);
        if (_26930 == 0)
        {
            DeRef(_26930);
            _26930 = NOVALUE;
            goto L36; // [2004] 2283
        }
        else{
            DeRef(_26930);
            _26930 = NOVALUE;
        }

        /** emit.e:974				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26931 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26931 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26932 = (object)*(((s1_ptr)_2)->base + _26931);
        Ref(_26932);
        _47clear_temp(_26932);
        _26932 = NOVALUE;

        /** emit.e:975				Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26933 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26933 = 1;
        }
        _26934 = _26933 - 1;
        _26933 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21859;
        RHS_Slice(_36Code_21859, 1, _26934);

        /** emit.e:976				if previous_op = NOT then*/
        if (_36previous_op_21869 != 7)
        goto L37; // [2045] 2125

        /** emit.e:977					op = NOT_IFW*/
        _op_52302 = 108;

        /** emit.e:978					backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26937 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26937 = 1;
        }
        _26938 = _26937 - 1;
        _26937 = NOVALUE;
        _47backpatch(_26938, 108);
        _26938 = NOVALUE;

        /** emit.e:979					sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26939 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26939 = 1;
        }
        _26940 = _26939 - 1;
        _26939 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21859)){
                _26941 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26941 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52746;
        RHS_Slice(_36Code_21859, _26940, _26941);

        /** emit.e:980					Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26943 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26943 = 1;
        }
        _26944 = _26943 - 2;
        _26943 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21859;
        RHS_Slice(_36Code_21859, 1, _26944);

        /** emit.e:981					Code &= if_code*/
        Concat((object_ptr)&_36Code_21859, _36Code_21859, _if_code_52746);
        DeRefDS(_if_code_52746);
        _if_code_52746 = NOVALUE;
        goto L38; // [2122] 2270
L37: 

        /** emit.e:983					if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26947 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26947 = 1;
        }
        _26948 = _26947 - 1;
        _26947 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26949 = (object)*(((s1_ptr)_2)->base + _26948);
        Ref(_26949);
        _26950 = _47IsInteger(_26949);
        _26949 = NOVALUE;
        if (IS_ATOM_INT(_26950)) {
            if (_26950 == 0) {
                goto L39; // [2144] 2186
            }
        }
        else {
            if (DBL_PTR(_26950)->dbl == 0.0) {
                goto L39; // [2144] 2186
            }
        }
        if (IS_SEQUENCE(_36Code_21859)){
                _26952 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26952 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26953 = (object)*(((s1_ptr)_2)->base + _26952);
        Ref(_26953);
        _26954 = _47IsInteger(_26953);
        _26953 = NOVALUE;
        if (_26954 == 0) {
            DeRef(_26954);
            _26954 = NOVALUE;
            goto L39; // [2162] 2186
        }
        else {
            if (!IS_ATOM_INT(_26954) && DBL_PTR(_26954)->dbl == 0.0){
                DeRef(_26954);
                _26954 = NOVALUE;
                goto L39; // [2162] 2186
            }
            DeRef(_26954);
            _26954 = NOVALUE;
        }
        DeRef(_26954);
        _26954 = NOVALUE;

        /** emit.e:984						op = previous_op + LESS_IFW_I - LESS*/
        _26955 = _36previous_op_21869 + 119;
        if ((object)((uintptr_t)_26955 + (uintptr_t)HIGH_BITS) >= 0){
            _26955 = NewDouble((eudouble)_26955);
        }
        if (IS_ATOM_INT(_26955)) {
            _op_52302 = _26955 - 1;
        }
        else {
            _op_52302 = NewDouble(DBL_PTR(_26955)->dbl - (eudouble)1);
        }
        DeRef(_26955);
        _26955 = NOVALUE;
        if (!IS_ATOM_INT(_op_52302)) {
            _1 = (object)(DBL_PTR(_op_52302)->dbl);
            DeRefDS(_op_52302);
            _op_52302 = _1;
        }
        goto L3A; // [2183] 2205
L39: 

        /** emit.e:986						op = previous_op + LESS_IFW - LESS*/
        _26957 = _36previous_op_21869 + 102;
        if ((object)((uintptr_t)_26957 + (uintptr_t)HIGH_BITS) >= 0){
            _26957 = NewDouble((eudouble)_26957);
        }
        if (IS_ATOM_INT(_26957)) {
            _op_52302 = _26957 - 1;
        }
        else {
            _op_52302 = NewDouble(DBL_PTR(_26957)->dbl - (eudouble)1);
        }
        DeRef(_26957);
        _26957 = NOVALUE;
        if (!IS_ATOM_INT(_op_52302)) {
            _1 = (object)(DBL_PTR(_op_52302)->dbl);
            DeRefDS(_op_52302);
            _op_52302 = _1;
        }
L3A: 

        /** emit.e:989					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26959 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26959 = 1;
        }
        _26960 = _26959 - 2;
        _26959 = NOVALUE;
        _47backpatch(_26960, _op_52302);
        _26960 = NOVALUE;

        /** emit.e:991					sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26961 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26961 = 1;
        }
        _26962 = _26961 - 2;
        _26961 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21859)){
                _26963 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26963 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52785;
        RHS_Slice(_36Code_21859, _26962, _26963);

        /** emit.e:992					Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26965 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26965 = 1;
        }
        _26966 = _26965 - 3;
        _26965 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21859;
        RHS_Slice(_36Code_21859, 1, _26966);

        /** emit.e:993					Code &= if_code*/
        Concat((object_ptr)&_36Code_21859, _36Code_21859, _if_code_52785);
        DeRefDS(_if_code_52785);
        _if_code_52785 = NOVALUE;
L38: 

        /** emit.e:997				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;

        /** emit.e:998				last_op = op*/
        _47last_op_52261 = _op_52302;
        goto LC; // [2280] 7739
L36: 

        /** emit.e:1000			elsif op = WHILE and*/
        _26969 = (_op_52302 == 47);
        if (_26969 == 0) {
            _26970 = 0;
            goto L3B; // [2291] 2303
        }
        _26971 = (_a_52304 > 0);
        _26970 = (_26971 != 0);
L3B: 
        if (_26970 == 0) {
            _26972 = 0;
            goto L3C; // [2303] 2329
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26973 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_26973);
        _26974 = (object)*(((s1_ptr)_2)->base + 3);
        _26973 = NOVALUE;
        if (IS_ATOM_INT(_26974)) {
            _26975 = (_26974 == 2);
        }
        else {
            _26975 = binary_op(EQUALS, _26974, 2);
        }
        _26974 = NOVALUE;
        if (IS_ATOM_INT(_26975))
        _26972 = (_26975 != 0);
        else
        _26972 = DBL_PTR(_26975)->dbl != 0.0;
L3C: 
        if (_26972 == 0) {
            _26976 = 0;
            goto L3D; // [2329] 2352
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26977 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_26977);
        _26978 = (object)*(((s1_ptr)_2)->base + 1);
        _26977 = NOVALUE;
        if (IS_ATOM_INT(_26978))
        _26979 = 1;
        else if (IS_ATOM_DBL(_26978))
        _26979 = IS_ATOM_INT(DoubleToInt(_26978));
        else
        _26979 = 0;
        _26978 = NOVALUE;
        _26976 = (_26979 != 0);
L3D: 
        if (_26976 == 0) {
            goto L3E; // [2352] 2401
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26981 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_26981);
        _26982 = (object)*(((s1_ptr)_2)->base + 1);
        _26981 = NOVALUE;
        if (_26982 == 0)
        _26983 = 1;
        else if (IS_ATOM_INT(_26982) && IS_ATOM_INT(0))
        _26983 = 0;
        else
        _26983 = (compare(_26982, 0) == 0);
        _26982 = NOVALUE;
        _26984 = (_26983 == 0);
        _26983 = NOVALUE;
        if (_26984 == 0)
        {
            DeRef(_26984);
            _26984 = NOVALUE;
            goto L3E; // [2376] 2401
        }
        else{
            DeRef(_26984);
            _26984 = NOVALUE;
        }

        /** emit.e:1005				optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _47optimized_while_51366 = _13TRUE_447;

        /** emit.e:1006				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;

        /** emit.e:1007				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;
        goto LC; // [2398] 7739
L3E: 

        /** emit.e:1009				flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _a_52304;
        _26985 = MAKE_SEQ(_1);
        _47flush_temps(_26985);
        _26985 = NOVALUE;

        /** emit.e:1010				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1011				emit_addr(a)*/
        _47emit_addr(_a_52304);
        goto LC; // [2421] 7739

        /** emit.e:1016		case INTEGER_CHECK then*/
        case 96:

        /** emit.e:1017			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:1018			if previous_op = ASSIGN then*/
        if (_36previous_op_21869 != 18)
        goto L3F; // [2440] 2499

        /** emit.e:1019				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26987 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26987 = 1;
        }
        _26988 = _26987 - 1;
        _26987 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _c_52306 = (object)*(((s1_ptr)_2)->base + _26988);
        if (!IS_ATOM_INT(_c_52306)){
            _c_52306 = (object)DBL_PTR(_c_52306)->dbl;
        }

        /** emit.e:1020				if not IsInteger(c) then*/
        _26990 = _47IsInteger(_c_52306);
        if (IS_ATOM_INT(_26990)) {
            if (_26990 != 0){
                DeRef(_26990);
                _26990 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        else {
            if (DBL_PTR(_26990)->dbl != 0.0){
                DeRef(_26990);
                _26990 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        DeRef(_26990);
        _26990 = NOVALUE;

        /** emit.e:1021					emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1022					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);
        goto L41; // [2482] 2556
L40: 

        /** emit.e:1024					last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1025					last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto L41; // [2496] 2556
L3F: 

        /** emit.e:1027			elsif previous_op = -1 or*/
        _26992 = (_36previous_op_21869 == -1);
        if (_26992 != 0) {
            goto L42; // [2507] 2530
        }
        _2 = (object)SEQ_PTR(_47op_result_51980);
        _26994 = (object)*(((s1_ptr)_2)->base + _36previous_op_21869);
        _26995 = (_26994 != 1);
        _26994 = NOVALUE;
        if (_26995 == 0)
        {
            DeRef(_26995);
            _26995 = NOVALUE;
            goto L43; // [2526] 2545
        }
        else{
            DeRef(_26995);
            _26995 = NOVALUE;
        }
L42: 

        /** emit.e:1029				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1030				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);
        goto L41; // [2542] 2556
L43: 

        /** emit.e:1032				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1033				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
L41: 

        /** emit.e:1035			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _26996 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _26996 = 1;
        }
        _26997 = _26996 - 1;
        _26996 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _26998 = (object)*(((s1_ptr)_2)->base + _26997);
        Ref(_26998);
        _47clear_temp(_26998);
        _26998 = NOVALUE;
        goto LC; // [2574] 7739

        /** emit.e:1037		case SEQUENCE_CHECK then*/
        case 97:

        /** emit.e:1038			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:1039			if previous_op = ASSIGN then*/
        if (_36previous_op_21869 != 18)
        goto L44; // [2593] 2720

        /** emit.e:1040				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27000 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27000 = 1;
        }
        _27001 = _27000 - 1;
        _27000 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _c_52306 = (object)*(((s1_ptr)_2)->base + _27001);
        if (!IS_ATOM_INT(_c_52306)){
            _c_52306 = (object)DBL_PTR(_c_52306)->dbl;
        }

        /** emit.e:1041				if c < 1 or*/
        _27003 = (_c_52306 < 1);
        if (_27003 != 0) {
            _27004 = 1;
            goto L45; // [2620] 2646
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27005 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27005);
        _27006 = (object)*(((s1_ptr)_2)->base + 3);
        _27005 = NOVALUE;
        if (IS_ATOM_INT(_27006)) {
            _27007 = (_27006 != 2);
        }
        else {
            _27007 = binary_op(NOTEQ, _27006, 2);
        }
        _27006 = NOVALUE;
        if (IS_ATOM_INT(_27007))
        _27004 = (_27007 != 0);
        else
        _27004 = DBL_PTR(_27007)->dbl != 0.0;
L45: 
        if (_27004 != 0) {
            goto L46; // [2646] 2673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27009 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27009);
        _27010 = (object)*(((s1_ptr)_2)->base + 1);
        _27009 = NOVALUE;
        _27011 = IS_SEQUENCE(_27010);
        _27010 = NOVALUE;
        _27012 = (_27011 == 0);
        _27011 = NOVALUE;
        if (_27012 == 0)
        {
            DeRef(_27012);
            _27012 = NOVALUE;
            goto L47; // [2669] 2706
        }
        else{
            DeRef(_27012);
            _27012 = NOVALUE;
        }
L46: 

        /** emit.e:1044					emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1045					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);

        /** emit.e:1046					clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27013 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27013 = 1;
        }
        _27014 = _27013 - 1;
        _27013 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _27015 = (object)*(((s1_ptr)_2)->base + _27014);
        Ref(_27015);
        _47clear_temp(_27015);
        _27015 = NOVALUE;
        goto LC; // [2703] 7739
L47: 

        /** emit.e:1048					last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1049					last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto LC; // [2717] 7739
L44: 

        /** emit.e:1051			elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _27016 = (_36previous_op_21869 == -1);
        if (_27016 != 0) {
            goto L48; // [2728] 2751
        }
        _2 = (object)SEQ_PTR(_47op_result_51980);
        _27018 = (object)*(((s1_ptr)_2)->base + _36previous_op_21869);
        _27019 = (_27018 != 2);
        _27018 = NOVALUE;
        if (_27019 == 0)
        {
            DeRef(_27019);
            _27019 = NOVALUE;
            goto L49; // [2747] 2784
        }
        else{
            DeRef(_27019);
            _27019 = NOVALUE;
        }
L48: 

        /** emit.e:1052				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1053				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);

        /** emit.e:1054				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27020 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27020 = 1;
        }
        _27021 = _27020 - 1;
        _27020 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _27022 = (object)*(((s1_ptr)_2)->base + _27021);
        Ref(_27022);
        _47clear_temp(_27022);
        _27022 = NOVALUE;
        goto LC; // [2781] 7739
L49: 

        /** emit.e:1056				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1057				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto LC; // [2795] 7739

        /** emit.e:1061		case ATOM_CHECK then*/
        case 101:

        /** emit.e:1062			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:1063			if previous_op = ASSIGN then*/
        if (_36previous_op_21869 != 18)
        goto L4A; // [2814] 3015

        /** emit.e:1064				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27024 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27024 = 1;
        }
        _27025 = _27024 - 1;
        _27024 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _c_52306 = (object)*(((s1_ptr)_2)->base + _27025);
        if (!IS_ATOM_INT(_c_52306)){
            _c_52306 = (object)DBL_PTR(_c_52306)->dbl;
        }

        /** emit.e:1065				if c > 1*/
        _27027 = (_c_52306 > 1);
        if (_27027 == 0) {
            goto L4B; // [2841] 2964
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27029 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27029);
        _27030 = (object)*(((s1_ptr)_2)->base + 3);
        _27029 = NOVALUE;
        if (IS_ATOM_INT(_27030)) {
            _27031 = (_27030 == 2);
        }
        else {
            _27031 = binary_op(EQUALS, _27030, 2);
        }
        _27030 = NOVALUE;
        if (_27031 == 0) {
            DeRef(_27031);
            _27031 = NOVALUE;
            goto L4B; // [2864] 2964
        }
        else {
            if (!IS_ATOM_INT(_27031) && DBL_PTR(_27031)->dbl == 0.0){
                DeRef(_27031);
                _27031 = NOVALUE;
                goto L4B; // [2864] 2964
            }
            DeRef(_27031);
            _27031 = NOVALUE;
        }
        DeRef(_27031);
        _27031 = NOVALUE;

        /** emit.e:1068					if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27032 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27032);
        _27033 = (object)*(((s1_ptr)_2)->base + 1);
        _27032 = NOVALUE;
        _27034 = IS_SEQUENCE(_27033);
        _27033 = NOVALUE;
        if (_27034 == 0)
        {
            _27034 = NOVALUE;
            goto L4C; // [2884] 2915
        }
        else{
            _27034 = NOVALUE;
        }

        /** emit.e:1070						ThisLine = ExprLine*/
        RefDS(_45ExprLine_57474);
        DeRef(_50ThisLine_49594);
        _50ThisLine_49594 = _45ExprLine_57474;

        /** emit.e:1071						bp = expr_bp*/
        _50bp_49598 = _45expr_bp_57475;

        /** emit.e:1072						CompileErr( TYPE_CHECK_ERROR__ASSIGNING_A_SEQUENCE_TO_AN_ATOM)*/
        RefDS(_22190);
        _50CompileErr(346, _22190, 0);
        goto L4D; // [2912] 3094
L4C: 

        /** emit.e:1074					elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27035 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27035);
        _27036 = (object)*(((s1_ptr)_2)->base + 1);
        _27035 = NOVALUE;
        if (binary_op_a(NOTEQ, _27036, _36NOVALUE_21621)){
            _27036 = NOVALUE;
            goto L4E; // [2931] 2950
        }
        _27036 = NOVALUE;

        /** emit.e:1075						emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1076						emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);
        goto L4D; // [2947] 3094
L4E: 

        /** emit.e:1078						last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1079						last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto L4D; // [2961] 3094
L4B: 

        /** emit.e:1082				elsif c < 1 */
        _27038 = (_c_52306 < 1);
        if (_27038 != 0) {
            goto L4F; // [2970] 2986
        }
        _27040 = _47IsInteger(_c_52306);
        if (IS_ATOM_INT(_27040)) {
            _27041 = (_27040 == 0);
        }
        else {
            _27041 = unary_op(NOT, _27040);
        }
        DeRef(_27040);
        _27040 = NOVALUE;
        if (_27041 == 0) {
            DeRef(_27041);
            _27041 = NOVALUE;
            goto L50; // [2982] 3001
        }
        else {
            if (!IS_ATOM_INT(_27041) && DBL_PTR(_27041)->dbl == 0.0){
                DeRef(_27041);
                _27041 = NOVALUE;
                goto L50; // [2982] 3001
            }
            DeRef(_27041);
            _27041 = NOVALUE;
        }
        DeRef(_27041);
        _27041 = NOVALUE;
L4F: 

        /** emit.e:1085					emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1086					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);
        goto L4D; // [2998] 3094
L50: 

        /** emit.e:1089					last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1090					last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto L4D; // [3012] 3094
L4A: 

        /** emit.e:1092			elsif previous_op = -1 or*/
        _27042 = (_36previous_op_21869 == -1);
        if (_27042 != 0) {
            goto L51; // [3023] 3068
        }
        _2 = (object)SEQ_PTR(_47op_result_51980);
        _27044 = (object)*(((s1_ptr)_2)->base + _36previous_op_21869);
        _27045 = (_27044 != 1);
        _27044 = NOVALUE;
        if (_27045 == 0) {
            DeRef(_27046);
            _27046 = 0;
            goto L52; // [3041] 3063
        }
        _2 = (object)SEQ_PTR(_47op_result_51980);
        _27047 = (object)*(((s1_ptr)_2)->base + _36previous_op_21869);
        _27048 = (_27047 != 3);
        _27047 = NOVALUE;
        _27046 = (_27048 != 0);
L52: 
        if (_27046 == 0)
        {
            _27046 = NOVALUE;
            goto L53; // [3064] 3083
        }
        else{
            _27046 = NOVALUE;
        }
L51: 

        /** emit.e:1095				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1096				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51364);
        goto L4D; // [3080] 3094
L53: 

        /** emit.e:1098				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1099				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
L4D: 

        /** emit.e:1101			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27049 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27049 = 1;
        }
        _27050 = _27049 - 1;
        _27049 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _27051 = (object)*(((s1_ptr)_2)->base + _27050);
        Ref(_27051);
        _47clear_temp(_27051);
        _27051 = NOVALUE;
        goto LC; // [3112] 7739

        /** emit.e:1103		case RIGHT_BRACE_N then*/
        case 31:

        /** emit.e:1105			n = op_info1*/
        _n_52315 = _47op_info1_51364;

        /** emit.e:1107			elements = {}*/
        RefDS(_22190);
        DeRef(_elements_52317);
        _elements_52317 = _22190;

        /** emit.e:1108			for i = 1 to n do*/
        _27052 = _n_52315;
        {
            object _i_52966;
            _i_52966 = 1;
L54: 
            if (_i_52966 > _27052){
                goto L55; // [3137] 3160
            }

            /** emit.e:1109				elements = append(elements, Pop())*/
            _27053 = _47Pop();
            Ref(_27053);
            Append(&_elements_52317, _elements_52317, _27053);
            DeRef(_27053);
            _27053 = NOVALUE;

            /** emit.e:1110			end for*/
            _i_52966 = _i_52966 + 1;
            goto L54; // [3155] 3144
L55: 
            ;
        }

        /** emit.e:1111			element_vals = good_string(elements)*/
        RefDS(_elements_52317);
        _0 = _element_vals_52318;
        _element_vals_52318 = _47good_string(_elements_52317);
        DeRef(_0);

        /** emit.e:1113			if sequence(element_vals) then*/
        _27056 = IS_SEQUENCE(_element_vals_52318);
        if (_27056 == 0)
        {
            _27056 = NOVALUE;
            goto L56; // [3171] 3202
        }
        else{
            _27056 = NOVALUE;
        }

        /** emit.e:1114				c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_52318);
        _c_52306 = _54NewStringSym(_element_vals_52318);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1115				assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:1116				last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1117				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto L57; // [3199] 3293
L56: 

        /** emit.e:1119				if n = 2 then*/
        if (_n_52315 != 2)
        goto L58; // [3204] 3227

        /** emit.e:1120					emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _47emit_opcode(85);

        /** emit.e:1121					last_op = RIGHT_BRACE_2*/
        _47last_op_52261 = 85;
        goto L59; // [3224] 3238
L58: 

        /** emit.e:1123					emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1124					emit(n)*/
        _47emit(_n_52315);
L59: 

        /** emit.e:1127				for i = 1 to n do*/
        _27059 = _n_52315;
        {
            object _i_52983;
            _i_52983 = 1;
L5A: 
            if (_i_52983 > _27059){
                goto L5B; // [3243] 3266
            }

            /** emit.e:1128					emit_addr(elements[i])*/
            _2 = (object)SEQ_PTR(_elements_52317);
            _27060 = (object)*(((s1_ptr)_2)->base + _i_52983);
            Ref(_27060);
            _47emit_addr(_27060);
            _27060 = NOVALUE;

            /** emit.e:1129				end for*/
            _i_52983 = _i_52983 + 1;
            goto L5A; // [3261] 3250
L5B: 
            ;
        }

        /** emit.e:1130				c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1131				emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1132				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);

        /** emit.e:1133				assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;
L57: 

        /** emit.e:1135			Push(c)*/
        _47Push(_c_52306);
        goto LC; // [3298] 7739

        /** emit.e:1138		case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** emit.e:1141			b = Pop() -- rhs value*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1142			a = Pop() -- subscript*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1143			c = Pop() -- sequence*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1144			if op = ASSIGN_SUBS then*/
        if (_op_52302 != 16)
        goto L5C; // [3333] 3525

        /** emit.e:1146				if (previous_op != LHS_SUBS) and*/
        _27066 = (_36previous_op_21869 != 95);
        if (_27066 == 0) {
            _27067 = 0;
            goto L5D; // [3347] 3359
        }
        _27068 = (_c_52306 > 0);
        _27067 = (_27068 != 0);
L5D: 
        if (_27067 == 0) {
            goto L5E; // [3359] 3497
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27070 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27070);
        _27071 = (object)*(((s1_ptr)_2)->base + 3);
        _27070 = NOVALUE;
        if (IS_ATOM_INT(_27071)) {
            _27072 = (_27071 != 1);
        }
        else {
            _27072 = binary_op(NOTEQ, _27071, 1);
        }
        _27071 = NOVALUE;
        if (IS_ATOM_INT(_27072)) {
            if (_27072 != 0) {
                DeRef(_27073);
                _27073 = 1;
                goto L5F; // [3381] 3481
            }
        }
        else {
            if (DBL_PTR(_27072)->dbl != 0.0) {
                DeRef(_27073);
                _27073 = 1;
                goto L5F; // [3381] 3481
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27074 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27074);
        _27075 = (object)*(((s1_ptr)_2)->base + 15);
        _27074 = NOVALUE;
        if (IS_ATOM_INT(_27075)) {
            _27076 = (_27075 != _54sequence_type_47140);
        }
        else {
            _27076 = binary_op(NOTEQ, _27075, _54sequence_type_47140);
        }
        _27075 = NOVALUE;
        if (IS_ATOM_INT(_27076)) {
            if (_27076 == 0) {
                DeRef(_27077);
                _27077 = 0;
                goto L60; // [3403] 3477
            }
        }
        else {
            if (DBL_PTR(_27076)->dbl == 0.0) {
                DeRef(_27077);
                _27077 = 0;
                goto L60; // [3403] 3477
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27078 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27078);
        _27079 = (object)*(((s1_ptr)_2)->base + 15);
        _27078 = NOVALUE;
        if (IS_ATOM_INT(_27079)) {
            _27080 = (_27079 > 0);
        }
        else {
            _27080 = binary_op(GREATER, _27079, 0);
        }
        _27079 = NOVALUE;
        if (IS_ATOM_INT(_27080)) {
            if (_27080 == 0) {
                DeRef(_27081);
                _27081 = 0;
                goto L61; // [3423] 3473
            }
        }
        else {
            if (DBL_PTR(_27080)->dbl == 0.0) {
                DeRef(_27081);
                _27081 = 0;
                goto L61; // [3423] 3473
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27082 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27082);
        _27083 = (object)*(((s1_ptr)_2)->base + 15);
        _27082 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27083)){
            _27084 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27083)->dbl));
        }
        else{
            _27084 = (object)*(((s1_ptr)_2)->base + _27083);
        }
        _2 = (object)SEQ_PTR(_27084);
        _27085 = (object)*(((s1_ptr)_2)->base + 2);
        _27084 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27085)){
            _27086 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27085)->dbl));
        }
        else{
            _27086 = (object)*(((s1_ptr)_2)->base + _27085);
        }
        _2 = (object)SEQ_PTR(_27086);
        _27087 = (object)*(((s1_ptr)_2)->base + 15);
        _27086 = NOVALUE;
        if (IS_ATOM_INT(_27087)) {
            _27088 = (_27087 != _54sequence_type_47140);
        }
        else {
            _27088 = binary_op(NOTEQ, _27087, _54sequence_type_47140);
        }
        _27087 = NOVALUE;
        DeRef(_27081);
        if (IS_ATOM_INT(_27088))
        _27081 = (_27088 != 0);
        else
        _27081 = DBL_PTR(_27088)->dbl != 0.0;
L61: 
        DeRef(_27077);
        _27077 = (_27081 != 0);
L60: 
        DeRef(_27073);
        _27073 = (_27077 != 0);
L5F: 
        if (_27073 == 0)
        {
            _27073 = NOVALUE;
            goto L5E; // [3482] 3497
        }
        else{
            _27073 = NOVALUE;
        }

        /** emit.e:1153					op = ASSIGN_SUBS_CHECK*/
        _op_52302 = 84;
        goto L62; // [3494] 3517
L5E: 

        /** emit.e:1155					if IsInteger(b) then*/
        _27089 = _47IsInteger(_b_52305);
        if (_27089 == 0) {
            DeRef(_27089);
            _27089 = NOVALUE;
            goto L63; // [3503] 3516
        }
        else {
            if (!IS_ATOM_INT(_27089) && DBL_PTR(_27089)->dbl == 0.0){
                DeRef(_27089);
                _27089 = NOVALUE;
                goto L63; // [3503] 3516
            }
            DeRef(_27089);
            _27089 = NOVALUE;
        }
        DeRef(_27089);
        _27089 = NOVALUE;

        /** emit.e:1156						op = ASSIGN_SUBS_I*/
        _op_52302 = 118;
L63: 
L62: 

        /** emit.e:1159				emit_opcode(op)*/
        _47emit_opcode(_op_52302);
        goto L64; // [3522] 3551
L5C: 

        /** emit.e:1161			elsif op = PASSIGN_SUBS then*/
        if (_op_52302 != 162)
        goto L65; // [3529] 3543

        /** emit.e:1162				emit_opcode(PASSIGN_SUBS) -- always*/
        _47emit_opcode(162);
        goto L64; // [3540] 3551
L65: 

        /** emit.e:1165				emit_opcode(ASSIGN_SUBS) -- always*/
        _47emit_opcode(16);
L64: 

        /** emit.e:1169			emit_addr(c) -- sequence*/
        _47emit_addr(_c_52306);

        /** emit.e:1170			emit_addr(a) -- subscript*/
        _47emit_addr(_a_52304);

        /** emit.e:1171			emit_addr(b) -- rhs value*/
        _47emit_addr(_b_52305);

        /** emit.e:1172			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [3573] 7739

        /** emit.e:1174		case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** emit.e:1176			a = Pop() -- subs*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1177			lhs_var = Pop() -- sequence*/
        _lhs_var_52312 = _47Pop();
        if (!IS_ATOM_INT(_lhs_var_52312)) {
            _1 = (object)(DBL_PTR(_lhs_var_52312)->dbl);
            DeRefDS(_lhs_var_52312);
            _lhs_var_52312 = _1;
        }

        /** emit.e:1178			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1179			emit_addr(lhs_var)*/
        _47emit_addr(_lhs_var_52312);

        /** emit.e:1180			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1181			if op = LHS_SUBS then*/
        if (_op_52302 != 95)
        goto L66; // [3616] 3647

        /** emit.e:1182				TempKeep(lhs_var) -- should be lhs_target_temp*/
        _47TempKeep(_lhs_var_52312);

        /** emit.e:1183				emit_addr(lhs_target_temp)*/
        _47emit_addr(_47lhs_target_temp_51378);

        /** emit.e:1184				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_51378);

        /** emit.e:1185				emit_addr(0) -- place holder*/
        _47emit_addr(0);
        goto L67; // [3644] 3701
L66: 

        /** emit.e:1189				lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _54NewTempSym(0);
        _47lhs_target_temp_51378 = _0;
        if (!IS_ATOM_INT(_47lhs_target_temp_51378)) {
            _1 = (object)(DBL_PTR(_47lhs_target_temp_51378)->dbl);
            DeRefDS(_47lhs_target_temp_51378);
            _47lhs_target_temp_51378 = _1;
        }

        /** emit.e:1190				emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _47emit_addr(_47lhs_target_temp_51378);

        /** emit.e:1191				emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_target_temp_51378, 1);

        /** emit.e:1192				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_51378);

        /** emit.e:1193				lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _54NewTempSym(0);
        _47lhs_subs1_copy_temp_51377 = _0;
        if (!IS_ATOM_INT(_47lhs_subs1_copy_temp_51377)) {
            _1 = (object)(DBL_PTR(_47lhs_subs1_copy_temp_51377)->dbl);
            DeRefDS(_47lhs_subs1_copy_temp_51377);
            _47lhs_subs1_copy_temp_51377 = _1;
        }

        /** emit.e:1194				emit_addr(lhs_subs1_copy_temp)*/
        _47emit_addr(_47lhs_subs1_copy_temp_51377);

        /** emit.e:1195				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_subs1_copy_temp_51377, 1);
L67: 

        /** emit.e:1198			current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_47current_sequence_51372, _47current_sequence_51372, _47lhs_target_temp_51378);

        /** emit.e:1199			assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [3718] 7739

        /** emit.e:1201		case PEEK_LONGS then*/
        case 436:

        /** emit.e:1202			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21913 != 0) {
            _27097 = 1;
            goto L68; // [3728] 3738
        }
        _27097 = (_46TWINDOWS_21914 != 0);
L68: 
        if (_27097 != 0) {
            goto L69; // [3738] 3762
        }
        if (_46IX86_64_21929 != 0) {
            DeRef(_27099);
            _27099 = 1;
            goto L6A; // [3744] 3754
        }
        _27099 = (_46TX86_64_21930 != 0);
L6A: 
        _27100 = (_27099 == 0);
        _27099 = NOVALUE;
        if (_27100 == 0)
        {
            DeRef(_27100);
            _27100 = NOVALUE;
            goto L6B; // [3758] 3774
        }
        else{
            DeRef(_27100);
            _27100 = NOVALUE;
        }
L69: 

        /** emit.e:1203				op = PEEK4S*/
        _op_52302 = 139;
        goto L6C; // [3771] 3784
L6B: 

        /** emit.e:1205				op = PEEK8S*/
        _op_52302 = 213;
L6C: 

        /** emit.e:1207			last_op = op*/
        _47last_op_52261 = _op_52302;

        /** emit.e:1208			cont11ii(op, TRUE )*/
        _47cont11ii(_op_52302, _13TRUE_447);
        goto LC; // [3797] 7739

        /** emit.e:1210		case PEEK_LONGU then*/
        case 435:

        /** emit.e:1211			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21913 != 0) {
            _27101 = 1;
            goto L6D; // [3807] 3817
        }
        _27101 = (_46TWINDOWS_21914 != 0);
L6D: 
        if (_27101 != 0) {
            goto L6E; // [3817] 3841
        }
        if (_46IX86_64_21929 != 0) {
            DeRef(_27103);
            _27103 = 1;
            goto L6F; // [3823] 3833
        }
        _27103 = (_46TX86_64_21930 != 0);
L6F: 
        _27104 = (_27103 == 0);
        _27103 = NOVALUE;
        if (_27104 == 0)
        {
            DeRef(_27104);
            _27104 = NOVALUE;
            goto L70; // [3837] 3853
        }
        else{
            DeRef(_27104);
            _27104 = NOVALUE;
        }
L6E: 

        /** emit.e:1212				op = PEEK4U*/
        _op_52302 = 140;
        goto L71; // [3850] 3863
L70: 

        /** emit.e:1214				op = PEEK8U*/
        _op_52302 = 214;
L71: 

        /** emit.e:1216			last_op = op*/
        _47last_op_52261 = _op_52302;

        /** emit.e:1217			cont11ii(op, TRUE )*/
        _47cont11ii(_op_52302, _13TRUE_447);
        goto LC; // [3876] 7739

        /** emit.e:1220		case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT, PEEK8U, PEEK8S, SIZEOF,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 214:
        case 213:
        case 217:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:
        case 216:

        /** emit.e:1222			cont11ii(op, TRUE)*/
        _47cont11ii(_op_52302, _13TRUE_447);
        goto LC; // [3918] 7739

        /** emit.e:1224		case UMINUS then*/
        case 12:

        /** emit.e:1226			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1228			if a > 0 then*/
        if (_a_52304 <= 0)
        goto L72; // [3933] 4180

        /** emit.e:1229				obj = SymTab[a][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27107 = (object)*(((s1_ptr)_2)->base + _a_52304);
        DeRef(_obj_52316);
        _2 = (object)SEQ_PTR(_27107);
        _obj_52316 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_52316);
        _27107 = NOVALUE;

        /** emit.e:1230				if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27109 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27109);
        _27110 = (object)*(((s1_ptr)_2)->base + 3);
        _27109 = NOVALUE;
        if (binary_op_a(NOTEQ, _27110, 2)){
            _27110 = NOVALUE;
            goto L73; // [3967] 4092
        }
        _27110 = NOVALUE;

        /** emit.e:1231					if is_integer(obj) then*/
        Ref(_obj_52316);
        _27112 = _36is_integer(_obj_52316);
        if (_27112 == 0) {
            DeRef(_27112);
            _27112 = NOVALUE;
            goto L74; // [3977] 4031
        }
        else {
            if (!IS_ATOM_INT(_27112) && DBL_PTR(_27112)->dbl == 0.0){
                DeRef(_27112);
                _27112 = NOVALUE;
                goto L74; // [3977] 4031
            }
            DeRef(_27112);
            _27112 = NOVALUE;
        }
        DeRef(_27112);
        _27112 = NOVALUE;

        /** emit.e:1232						if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_52316, -1073741824)){
            goto L75; // [3984] 4005
        }

        /** emit.e:1233							Push(NewDoubleSym(-MININT))*/
        if ((uintptr_t)-1073741824 == (uintptr_t)HIGH_BITS){
            _27114 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _27114 = - -1073741824;
        }
        _27115 = _54NewDoubleSym(_27114);
        _27114 = NOVALUE;
        _47Push(_27115);
        _27115 = NOVALUE;
        goto L76; // [4002] 4018
L75: 

        /** emit.e:1235							Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_52316)) {
            if ((uintptr_t)_obj_52316 == (uintptr_t)HIGH_BITS){
                _27116 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27116 = - _obj_52316;
            }
        }
        else {
            _27116 = unary_op(UMINUS, _obj_52316);
        }
        _27117 = _54NewIntSym(_27116);
        _27116 = NOVALUE;
        _47Push(_27117);
        _27117 = NOVALUE;
L76: 

        /** emit.e:1237						last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;

        /** emit.e:1238						last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;
        goto LC; // [4028] 7739
L74: 

        /** emit.e:1240					elsif atom(obj) and obj != NOVALUE then*/
        _27118 = IS_ATOM(_obj_52316);
        if (_27118 == 0) {
            goto L77; // [4036] 4075
        }
        if (IS_ATOM_INT(_obj_52316) && IS_ATOM_INT(_36NOVALUE_21621)) {
            _27120 = (_obj_52316 != _36NOVALUE_21621);
        }
        else {
            _27120 = binary_op(NOTEQ, _obj_52316, _36NOVALUE_21621);
        }
        if (_27120 == 0) {
            DeRef(_27120);
            _27120 = NOVALUE;
            goto L77; // [4047] 4075
        }
        else {
            if (!IS_ATOM_INT(_27120) && DBL_PTR(_27120)->dbl == 0.0){
                DeRef(_27120);
                _27120 = NOVALUE;
                goto L77; // [4047] 4075
            }
            DeRef(_27120);
            _27120 = NOVALUE;
        }
        DeRef(_27120);
        _27120 = NOVALUE;

        /** emit.e:1245						Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_52316)) {
            if ((uintptr_t)_obj_52316 == (uintptr_t)HIGH_BITS){
                _27121 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27121 = - _obj_52316;
            }
        }
        else {
            _27121 = unary_op(UMINUS, _obj_52316);
        }
        _27122 = _54NewDoubleSym(_27121);
        _27121 = NOVALUE;
        _47Push(_27122);
        _27122 = NOVALUE;

        /** emit.e:1246						last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;

        /** emit.e:1247						last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;
        goto LC; // [4072] 7739
L77: 

        /** emit.e:1250						Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1251						cont11ii(op, FALSE)*/
        _47cont11ii(_op_52302, _13FALSE_445);
        goto LC; // [4089] 7739
L73: 

        /** emit.e:1254				elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_36TRANSLATE_21369 == 0) {
            _27123 = 0;
            goto L78; // [4096] 4122
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27124 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27124);
        _27125 = (object)*(((s1_ptr)_2)->base + 3);
        _27124 = NOVALUE;
        if (IS_ATOM_INT(_27125)) {
            _27126 = (_27125 == 3);
        }
        else {
            _27126 = binary_op(EQUALS, _27125, 3);
        }
        _27125 = NOVALUE;
        if (IS_ATOM_INT(_27126))
        _27123 = (_27126 != 0);
        else
        _27123 = DBL_PTR(_27126)->dbl != 0.0;
L78: 
        if (_27123 == 0) {
            goto L79; // [4122] 4163
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27128 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27128);
        _27129 = (object)*(((s1_ptr)_2)->base + 36);
        _27128 = NOVALUE;
        if (IS_ATOM_INT(_27129)) {
            _27130 = (_27129 == 2);
        }
        else {
            _27130 = binary_op(EQUALS, _27129, 2);
        }
        _27129 = NOVALUE;
        if (_27130 == 0) {
            DeRef(_27130);
            _27130 = NOVALUE;
            goto L79; // [4145] 4163
        }
        else {
            if (!IS_ATOM_INT(_27130) && DBL_PTR(_27130)->dbl == 0.0){
                DeRef(_27130);
                _27130 = NOVALUE;
                goto L79; // [4145] 4163
            }
            DeRef(_27130);
            _27130 = NOVALUE;
        }
        DeRef(_27130);
        _27130 = NOVALUE;

        /** emit.e:1256					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_52316)) {
            if ((uintptr_t)_obj_52316 == (uintptr_t)HIGH_BITS){
                _27131 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27131 = - _obj_52316;
            }
        }
        else {
            _27131 = unary_op(UMINUS, _obj_52316);
        }
        _27132 = _54NewDoubleSym(_27131);
        _27131 = NOVALUE;
        _47Push(_27132);
        _27132 = NOVALUE;
        goto LC; // [4160] 7739
L79: 

        /** emit.e:1259					Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1260					cont11ii(op, FALSE)*/
        _47cont11ii(_op_52302, _13FALSE_445);
        goto LC; // [4177] 7739
L72: 

        /** emit.e:1263				Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1264				cont11ii(op, FALSE)*/
        _47cont11ii(_op_52302, _13FALSE_445);
        goto LC; // [4194] 7739

        /** emit.e:1267		case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** emit.e:1268			cont11ii(op, FALSE)*/
        _47cont11ii(_op_52302, _13FALSE_445);
        goto LC; // [4226] 7739

        /** emit.e:1270		case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** emit.e:1271			cont11ii(op, FALSE)*/
        _47cont11ii(_op_52302, _13FALSE_445);
        goto LC; // [4246] 7739

        /** emit.e:1275		case ROUTINE_ID then*/
        case 134:

        /** emit.e:1276			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1277			source = Pop()*/
        _source_52308 = _47Pop();
        if (!IS_ATOM_INT(_source_52308)) {
            _1 = (object)(DBL_PTR(_source_52308)->dbl);
            DeRefDS(_source_52308);
            _source_52308 = _1;
        }

        /** emit.e:1278			if TRANSLATE then*/
        if (_36TRANSLATE_21369 == 0)
        {
            goto L7A; // [4268] 4312
        }
        else{
        }

        /** emit.e:1279				emit_addr(num_routines-1)*/
        _27134 = _36num_routines_21776 - 1;
        if ((object)((uintptr_t)_27134 +(uintptr_t) HIGH_BITS) >= 0){
            _27134 = NewDouble((eudouble)_27134);
        }
        _47emit_addr(_27134);
        _27134 = NOVALUE;

        /** emit.e:1280				last_routine_id = num_routines*/
        _47last_routine_id_51369 = _36num_routines_21776;

        /** emit.e:1281				last_max_params = max_params*/
        _47last_max_params_51371 = _47max_params_51370;

        /** emit.e:1282				MarkTargets(source, S_RI_TARGET)*/
        _31971 = _54MarkTargets(_source_52308, 53);
        DeRef(_31971);
        _31971 = NOVALUE;
        goto L7B; // [4309] 4349
L7A: 

        /** emit.e:1285				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21775);

        /** emit.e:1286				emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_37SymTab_15637)){
                _27135 = SEQ_PTR(_37SymTab_15637)->length;
        }
        else {
            _27135 = 1;
        }
        _47emit_addr(_27135);
        _27135 = NOVALUE;

        /** emit.e:1288				if BIND then*/
        if (_36BIND_21372 == 0)
        {
            goto L7C; // [4333] 4348
        }
        else{
        }

        /** emit.e:1290					MarkTargets(source, S_NREFS)*/
        _31970 = _54MarkTargets(_source_52308, 12);
        DeRef(_31970);
        _31970 = NOVALUE;
L7C: 
L7B: 

        /** emit.e:1294			emit_addr(source)*/
        _47emit_addr(_source_52308);

        /** emit.e:1295			emit_addr(current_file_no)  -- necessary at top level*/
        _47emit_addr(_36current_file_no_21767);

        /** emit.e:1296			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1297			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1298			TempInteger(c) -- result will always be an integer*/
        _47TempInteger(_c_52306);

        /** emit.e:1299			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1300			emit_addr(c)*/
        _47emit_addr(_c_52306);
        goto LC; // [4391] 7739

        /** emit.e:1305		case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** emit.e:1306			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1307			emit_addr(Pop())*/
        _27137 = _47Pop();
        _47emit_addr(_27137);
        _27137 = NOVALUE;

        /** emit.e:1308			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1309			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1310			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1311			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [4437] 7739

        /** emit.e:1315		case POKE_LONG then*/
        case 434:

        /** emit.e:1316			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21913 != 0) {
            _27139 = 1;
            goto L7D; // [4447] 4457
        }
        _27139 = (_46TWINDOWS_21914 != 0);
L7D: 
        if (_27139 != 0) {
            goto L7E; // [4457] 4481
        }
        if (_46IX86_64_21929 != 0) {
            DeRef(_27141);
            _27141 = 1;
            goto L7F; // [4463] 4473
        }
        _27141 = (_46TX86_64_21930 != 0);
L7F: 
        _27142 = (_27141 == 0);
        _27141 = NOVALUE;
        if (_27142 == 0)
        {
            DeRef(_27142);
            _27142 = NOVALUE;
            goto L80; // [4477] 4493
        }
        else{
            DeRef(_27142);
            _27142 = NOVALUE;
        }
L7E: 

        /** emit.e:1317				op = POKE4*/
        _op_52302 = 138;
        goto L81; // [4490] 4503
L80: 

        /** emit.e:1319				op = POKE8*/
        _op_52302 = 212;
L81: 

        /** emit.e:1321			last_op = op*/
        _47last_op_52261 = _op_52302;

        /** emit.e:1324		case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:
        case 212:
        case 215:

        /** emit.e:1326			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1328			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1329			emit_addr(Pop())*/
        _27144 = _47Pop();
        _47emit_addr(_27144);
        _27144 = NOVALUE;

        /** emit.e:1330			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1331			if op = C_PROC then*/
        if (_op_52302 != 132)
        goto L82; // [4565] 4577

        /** emit.e:1332				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21775);
L82: 

        /** emit.e:1334			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [4584] 7739

        /** emit.e:1337		case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** emit.e:1339			cont21ii(op, TRUE)  -- both integer args => integer result*/
        _47cont21ii(_op_52302, _13TRUE_447);
        goto LC; // [4622] 7739

        /** emit.e:1341		case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** emit.e:1343			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1344			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1346			if b < 1 or a < 1 then*/
        _27148 = (_b_52305 < 1);
        if (_27148 != 0) {
            goto L83; // [4648] 4661
        }
        _27150 = (_a_52304 < 1);
        if (_27150 == 0)
        {
            DeRef(_27150);
            _27150 = NOVALUE;
            goto L84; // [4657] 4682
        }
        else{
            DeRef(_27150);
            _27150 = NOVALUE;
        }
L83: 

        /** emit.e:1347				Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1348				Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1349				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [4679] 7739
L84: 

        /** emit.e:1350			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27151 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27151);
        _27152 = (object)*(((s1_ptr)_2)->base + 3);
        _27151 = NOVALUE;
        if (IS_ATOM_INT(_27152)) {
            _27153 = (_27152 == 2);
        }
        else {
            _27153 = binary_op(EQUALS, _27152, 2);
        }
        _27152 = NOVALUE;
        if (IS_ATOM_INT(_27153)) {
            if (_27153 == 0) {
                goto L85; // [4702] 4763
            }
        }
        else {
            if (DBL_PTR(_27153)->dbl == 0.0) {
                goto L85; // [4702] 4763
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27155 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27155);
        _27156 = (object)*(((s1_ptr)_2)->base + 1);
        _27155 = NOVALUE;
        if (_27156 == 1)
        _27157 = 1;
        else if (IS_ATOM_INT(_27156) && IS_ATOM_INT(1))
        _27157 = 0;
        else
        _27157 = (compare(_27156, 1) == 0);
        _27156 = NOVALUE;
        if (_27157 == 0)
        {
            _27157 = NOVALUE;
            goto L85; // [4723] 4763
        }
        else{
            _27157 = NOVALUE;
        }

        /** emit.e:1351				op = PLUS1*/
        _op_52302 = 93;

        /** emit.e:1352				emit_opcode(op)*/
        _47emit_opcode(93);

        /** emit.e:1353				emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1354				emit_addr(0)*/
        _47emit_addr(0);

        /** emit.e:1355				cont21d(op, a, b, FALSE)*/
        _47cont21d(93, _a_52304, _b_52305, _13FALSE_445);
        goto LC; // [4760] 7739
L85: 

        /** emit.e:1356			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27158 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27158);
        _27159 = (object)*(((s1_ptr)_2)->base + 3);
        _27158 = NOVALUE;
        if (IS_ATOM_INT(_27159)) {
            _27160 = (_27159 == 2);
        }
        else {
            _27160 = binary_op(EQUALS, _27159, 2);
        }
        _27159 = NOVALUE;
        if (IS_ATOM_INT(_27160)) {
            if (_27160 == 0) {
                goto L86; // [4783] 4844
            }
        }
        else {
            if (DBL_PTR(_27160)->dbl == 0.0) {
                goto L86; // [4783] 4844
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27162 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27162);
        _27163 = (object)*(((s1_ptr)_2)->base + 1);
        _27162 = NOVALUE;
        if (_27163 == 1)
        _27164 = 1;
        else if (IS_ATOM_INT(_27163) && IS_ATOM_INT(1))
        _27164 = 0;
        else
        _27164 = (compare(_27163, 1) == 0);
        _27163 = NOVALUE;
        if (_27164 == 0)
        {
            _27164 = NOVALUE;
            goto L86; // [4804] 4844
        }
        else{
            _27164 = NOVALUE;
        }

        /** emit.e:1357				op = PLUS1*/
        _op_52302 = 93;

        /** emit.e:1358				emit_opcode(op)*/
        _47emit_opcode(93);

        /** emit.e:1359				emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1360				emit_addr(0)*/
        _47emit_addr(0);

        /** emit.e:1361				cont21d(op, a, b, FALSE)*/
        _47cont21d(93, _a_52304, _b_52305, _13FALSE_445);
        goto LC; // [4841] 7739
L86: 

        /** emit.e:1363				Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1364				Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1365				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [4863] 7739

        /** emit.e:1368		case rw:MULTIPLY then*/
        case 13:

        /** emit.e:1370			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1371			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1372			if a < 1 or b < 1 then*/
        _27167 = (_a_52304 < 1);
        if (_27167 != 0) {
            goto L87; // [4889] 4902
        }
        _27169 = (_b_52305 < 1);
        if (_27169 == 0)
        {
            DeRef(_27169);
            _27169 = NOVALUE;
            goto L88; // [4898] 4923
        }
        else{
            DeRef(_27169);
            _27169 = NOVALUE;
        }
L87: 

        /** emit.e:1373				Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1374				Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1375				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [4920] 7739
L88: 

        /** emit.e:1377			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27170 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27170);
        _27171 = (object)*(((s1_ptr)_2)->base + 3);
        _27170 = NOVALUE;
        if (IS_ATOM_INT(_27171)) {
            _27172 = (_27171 == 2);
        }
        else {
            _27172 = binary_op(EQUALS, _27171, 2);
        }
        _27171 = NOVALUE;
        if (IS_ATOM_INT(_27172)) {
            if (_27172 == 0) {
                goto L89; // [4943] 5004
            }
        }
        else {
            if (DBL_PTR(_27172)->dbl == 0.0) {
                goto L89; // [4943] 5004
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27174 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27174);
        _27175 = (object)*(((s1_ptr)_2)->base + 1);
        _27174 = NOVALUE;
        if (_27175 == 2)
        _27176 = 1;
        else if (IS_ATOM_INT(_27175) && IS_ATOM_INT(2))
        _27176 = 0;
        else
        _27176 = (compare(_27175, 2) == 0);
        _27175 = NOVALUE;
        if (_27176 == 0)
        {
            _27176 = NOVALUE;
            goto L89; // [4964] 5004
        }
        else{
            _27176 = NOVALUE;
        }

        /** emit.e:1379				op = PLUS*/
        _op_52302 = 11;

        /** emit.e:1380				emit_opcode(op)*/
        _47emit_opcode(11);

        /** emit.e:1381				emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1382				emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1383				cont21d(op, a, b, FALSE)*/
        _47cont21d(11, _a_52304, _b_52305, _13FALSE_445);
        goto LC; // [5001] 7739
L89: 

        /** emit.e:1385			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27177 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27177);
        _27178 = (object)*(((s1_ptr)_2)->base + 3);
        _27177 = NOVALUE;
        if (IS_ATOM_INT(_27178)) {
            _27179 = (_27178 == 2);
        }
        else {
            _27179 = binary_op(EQUALS, _27178, 2);
        }
        _27178 = NOVALUE;
        if (IS_ATOM_INT(_27179)) {
            if (_27179 == 0) {
                goto L8A; // [5024] 5085
            }
        }
        else {
            if (DBL_PTR(_27179)->dbl == 0.0) {
                goto L8A; // [5024] 5085
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27181 = (object)*(((s1_ptr)_2)->base + _a_52304);
        _2 = (object)SEQ_PTR(_27181);
        _27182 = (object)*(((s1_ptr)_2)->base + 1);
        _27181 = NOVALUE;
        if (_27182 == 2)
        _27183 = 1;
        else if (IS_ATOM_INT(_27182) && IS_ATOM_INT(2))
        _27183 = 0;
        else
        _27183 = (compare(_27182, 2) == 0);
        _27182 = NOVALUE;
        if (_27183 == 0)
        {
            _27183 = NOVALUE;
            goto L8A; // [5045] 5085
        }
        else{
            _27183 = NOVALUE;
        }

        /** emit.e:1386				op = PLUS*/
        _op_52302 = 11;

        /** emit.e:1387				emit_opcode(op)*/
        _47emit_opcode(11);

        /** emit.e:1388				emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1389				emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1390				cont21d(op, a, b, FALSE)*/
        _47cont21d(11, _a_52304, _b_52305, _13FALSE_445);
        goto LC; // [5082] 7739
L8A: 

        /** emit.e:1393				Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1394				Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1395				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [5104] 7739

        /** emit.e:1399		case rw:DIVIDE then*/
        case 14:

        /** emit.e:1400			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1401			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27185 = (_b_52305 > 0);
        if (_27185 == 0) {
            _27186 = 0;
            goto L8B; // [5123] 5149
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27187 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27187);
        _27188 = (object)*(((s1_ptr)_2)->base + 3);
        _27187 = NOVALUE;
        if (IS_ATOM_INT(_27188)) {
            _27189 = (_27188 == 2);
        }
        else {
            _27189 = binary_op(EQUALS, _27188, 2);
        }
        _27188 = NOVALUE;
        if (IS_ATOM_INT(_27189))
        _27186 = (_27189 != 0);
        else
        _27186 = DBL_PTR(_27189)->dbl != 0.0;
L8B: 
        if (_27186 == 0) {
            goto L8C; // [5149] 5220
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27191 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27191);
        _27192 = (object)*(((s1_ptr)_2)->base + 1);
        _27191 = NOVALUE;
        if (_27192 == 2)
        _27193 = 1;
        else if (IS_ATOM_INT(_27192) && IS_ATOM_INT(2))
        _27193 = 0;
        else
        _27193 = (compare(_27192, 2) == 0);
        _27192 = NOVALUE;
        if (_27193 == 0)
        {
            _27193 = NOVALUE;
            goto L8C; // [5170] 5220
        }
        else{
            _27193 = NOVALUE;
        }

        /** emit.e:1402				op = DIV2*/
        _op_52302 = 98;

        /** emit.e:1403				emit_opcode(op)*/
        _47emit_opcode(98);

        /** emit.e:1404				emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _27194 = _47Pop();
        _47emit_addr(_27194);
        _27194 = NOVALUE;

        /** emit.e:1405				a = 0*/
        _a_52304 = 0;

        /** emit.e:1406				emit_addr(0)*/
        _47emit_addr(0);

        /** emit.e:1407				cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _47cont21d(98, 0, _b_52305, _13FALSE_445);
        goto LC; // [5217] 7739
L8C: 

        /** emit.e:1409				Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1410				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [5234] 7739

        /** emit.e:1413		case FLOOR then*/
        case 83:

        /** emit.e:1414			if previous_op = rw:DIVIDE then*/
        if (_36previous_op_21869 != 14)
        goto L8D; // [5244] 5292

        /** emit.e:1415				op = FLOOR_DIV*/
        _op_52302 = 63;

        /** emit.e:1416				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27196 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27196 = 1;
        }
        _27197 = _27196 - 3;
        _27196 = NOVALUE;
        _47backpatch(_27197, 63);
        _27197 = NOVALUE;

        /** emit.e:1417				assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1418				last_op = op*/
        _47last_op_52261 = 63;

        /** emit.e:1419				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto LC; // [5289] 7739
L8D: 

        /** emit.e:1421			elsif previous_op = DIV2 then*/
        if (_36previous_op_21869 != 98)
        goto L8E; // [5298] 5385

        /** emit.e:1422				op = FLOOR_DIV2*/
        _op_52302 = 66;

        /** emit.e:1423				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27199 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27199 = 1;
        }
        _27200 = _27199 - 3;
        _27199 = NOVALUE;
        _47backpatch(_27200, 66);
        _27200 = NOVALUE;

        /** emit.e:1424				assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1425				if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_36Code_21859)){
                _27201 = SEQ_PTR(_36Code_21859)->length;
        }
        else {
            _27201 = 1;
        }
        _27202 = _27201 - 2;
        _27201 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21859);
        _27203 = (object)*(((s1_ptr)_2)->base + _27202);
        Ref(_27203);
        _27204 = _47IsInteger(_27203);
        _27203 = NOVALUE;
        if (_27204 == 0) {
            DeRef(_27204);
            _27204 = NOVALUE;
            goto L8F; // [5352] 5372
        }
        else {
            if (!IS_ATOM_INT(_27204) && DBL_PTR(_27204)->dbl == 0.0){
                DeRef(_27204);
                _27204 = NOVALUE;
                goto L8F; // [5352] 5372
            }
            DeRef(_27204);
            _27204 = NOVALUE;
        }
        DeRef(_27204);
        _27204 = NOVALUE;

        /** emit.e:1426					TempInteger(Top()) --mark temp as integer type*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5482_53404);
        _2 = (object)SEQ_PTR(_47cg_stack_51379);
        _Top_inlined_Top_at_5482_53404 = (object)*(((s1_ptr)_2)->base + _47cgi_51380);
        Ref(_Top_inlined_Top_at_5482_53404);
        Ref(_Top_inlined_Top_at_5482_53404);
        _47TempInteger(_Top_inlined_Top_at_5482_53404);
L8F: 

        /** emit.e:1428				last_op = op*/
        _47last_op_52261 = _op_52302;

        /** emit.e:1429				last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto LC; // [5382] 7739
L8E: 

        /** emit.e:1431				cont11ii(op, TRUE)*/
        _47cont11ii(_op_52302, _13TRUE_447);
        goto LC; // [5394] 7739

        /** emit.e:1437		case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** emit.e:1440			cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [5438] 7739

        /** emit.e:1442		case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** emit.e:1443			c = Pop()*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1444			TempKeep(c)*/
        _47TempKeep(_c_52306);

        /** emit.e:1445			b = Pop()  -- remove SC1's temp*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1446			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1447			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;

        /** emit.e:1448			last_op = last_op_backup*/
        _47last_op_52261 = _last_op_backup_52320;

        /** emit.e:1449			last_pc = last_pc_backup*/
        _47last_pc_52262 = _last_pc_backup_52319;
        goto LC; // [5485] 7739

        /** emit.e:1452		case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** emit.e:1453			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1454			emit_addr(Pop())*/
        _27207 = _47Pop();
        _47emit_addr(_27207);
        _27207 = NOVALUE;

        /** emit.e:1455			c = Pop()*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1456			TempKeep(c)*/
        _47TempKeep(_c_52306);

        /** emit.e:1457			emit_addr(c) -- target*/
        _47emit_addr(_c_52306);

        /** emit.e:1458			TempInteger(c)*/
        _47TempInteger(_c_52306);

        /** emit.e:1459			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1460			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [5540] 7739

        /** emit.e:1463		case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** emit.e:1464			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1465			c = Pop()*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1466			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1467			emit_addr(Pop())*/
        _27211 = _47Pop();
        _47emit_addr(_27211);
        _27211 = NOVALUE;

        /** emit.e:1468			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1469			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1470			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [5594] 7739

        /** emit.e:1473		case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** emit.e:1474			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1475			c = Pop()*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1476			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1477			emit_addr(Pop())*/
        _27214 = _47Pop();
        _47emit_addr(_27214);
        _27214 = NOVALUE;

        /** emit.e:1478			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1479			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1480			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1481			if op = FIND or op = FIND_FROM or op = OPEN then*/
        _27216 = (_op_52302 == 77);
        if (_27216 != 0) {
            _27217 = 1;
            goto L90; // [5669] 5683
        }
        _27218 = (_op_52302 == 176);
        _27217 = (_27218 != 0);
L90: 
        if (_27217 != 0) {
            goto L91; // [5683] 5698
        }
        _27220 = (_op_52302 == 37);
        if (_27220 == 0)
        {
            DeRef(_27220);
            _27220 = NOVALUE;
            goto L92; // [5694] 5706
        }
        else{
            DeRef(_27220);
            _27220 = NOVALUE;
        }
L91: 

        /** emit.e:1482				TempInteger( c )*/
        _47TempInteger(_c_52306);
        goto L93; // [5703] 5713
L92: 

        /** emit.e:1484				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);
L93: 

        /** emit.e:1486			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1487			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1488			emit_addr(c)*/
        _47emit_addr(_c_52306);
        goto LC; // [5730] 7739

        /** emit.e:1491		case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** emit.e:1492			n = op_info1  -- number of items to concatenate*/
        _n_52315 = _47op_info1_51364;

        /** emit.e:1493			emit_opcode(CONCAT_N)*/
        _47emit_opcode(157);

        /** emit.e:1494			emit(n)*/
        _47emit(_n_52315);

        /** emit.e:1495			for i = 1 to n do*/
        _27221 = _n_52315;
        {
            object _i_53472;
            _i_53472 = 1;
L94: 
            if (_i_53472 > _27221){
                goto L95; // [5760] 5788
            }

            /** emit.e:1496				symtab_index element = Pop()*/
            _element_53475 = _47Pop();
            if (!IS_ATOM_INT(_element_53475)) {
                _1 = (object)(DBL_PTR(_element_53475)->dbl);
                DeRefDS(_element_53475);
                _element_53475 = _1;
            }

            /** emit.e:1497				emit_addr( element )  -- reverse order*/
            _47emit_addr(_element_53475);

            /** emit.e:1498			end for*/
            _i_53472 = _i_53472 + 1;
            goto L94; // [5783] 5767
L95: 
            ;
        }

        /** emit.e:1499			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1500			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1501			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);

        /** emit.e:1502			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1503			Push(c)*/
        _47Push(_c_52306);
        goto LC; // [5819] 7739

        /** emit.e:1505		case FOR then*/
        case 21:

        /** emit.e:1506			c = Pop() -- increment*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1507			TempKeep(c)*/
        _47TempKeep(_c_52306);

        /** emit.e:1508			ic = IsInteger(c)*/
        _ic_52314 = _47IsInteger(_c_52306);
        if (!IS_ATOM_INT(_ic_52314)) {
            _1 = (object)(DBL_PTR(_ic_52314)->dbl);
            DeRefDS(_ic_52314);
            _ic_52314 = _1;
        }

        /** emit.e:1509			if c < 1 or*/
        _27226 = (_c_52306 < 1);
        if (_27226 != 0) {
            goto L96; // [5851] 5930
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27228 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27228);
        _27229 = (object)*(((s1_ptr)_2)->base + 3);
        _27228 = NOVALUE;
        if (IS_ATOM_INT(_27229)) {
            _27230 = (_27229 == 1);
        }
        else {
            _27230 = binary_op(EQUALS, _27229, 1);
        }
        _27229 = NOVALUE;
        if (IS_ATOM_INT(_27230)) {
            if (_27230 == 0) {
                DeRef(_27231);
                _27231 = 0;
                goto L97; // [5873] 5899
            }
        }
        else {
            if (DBL_PTR(_27230)->dbl == 0.0) {
                DeRef(_27231);
                _27231 = 0;
                goto L97; // [5873] 5899
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27232 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27232);
        _27233 = (object)*(((s1_ptr)_2)->base + 4);
        _27232 = NOVALUE;
        if (IS_ATOM_INT(_27233)) {
            _27234 = (_27233 != 2);
        }
        else {
            _27234 = binary_op(NOTEQ, _27233, 2);
        }
        _27233 = NOVALUE;
        DeRef(_27231);
        if (IS_ATOM_INT(_27234))
        _27231 = (_27234 != 0);
        else
        _27231 = DBL_PTR(_27234)->dbl != 0.0;
L97: 
        if (_27231 == 0) {
            DeRef(_27235);
            _27235 = 0;
            goto L98; // [5899] 5925
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27236 = (object)*(((s1_ptr)_2)->base + _c_52306);
        _2 = (object)SEQ_PTR(_27236);
        _27237 = (object)*(((s1_ptr)_2)->base + 4);
        _27236 = NOVALUE;
        if (IS_ATOM_INT(_27237)) {
            _27238 = (_27237 != 4);
        }
        else {
            _27238 = binary_op(NOTEQ, _27237, 4);
        }
        _27237 = NOVALUE;
        if (IS_ATOM_INT(_27238))
        _27235 = (_27238 != 0);
        else
        _27235 = DBL_PTR(_27238)->dbl != 0.0;
L98: 
        if (_27235 == 0)
        {
            _27235 = NOVALUE;
            goto L99; // [5926] 5967
        }
        else{
            _27235 = NOVALUE;
        }
L96: 

        /** emit.e:1514				emit_opcode(ASSIGN)*/
        _47emit_opcode(18);

        /** emit.e:1515				emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1516				c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1517				if ic then*/
        if (_ic_52314 == 0)
        {
            goto L9A; // [5952] 5961
        }
        else{
        }

        /** emit.e:1518					TempInteger( c )*/
        _47TempInteger(_c_52306);
L9A: 

        /** emit.e:1520				emit_addr(c)*/
        _47emit_addr(_c_52306);
L99: 

        /** emit.e:1522			b = Pop() -- limit*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1523			TempKeep(b)*/
        _47TempKeep(_b_52305);

        /** emit.e:1524			ib = IsInteger(b)*/
        _ib_52313 = _47IsInteger(_b_52305);
        if (!IS_ATOM_INT(_ib_52313)) {
            _1 = (object)(DBL_PTR(_ib_52313)->dbl);
            DeRefDS(_ib_52313);
            _ib_52313 = _1;
        }

        /** emit.e:1525			if b < 1 or*/
        _27242 = (_b_52305 < 1);
        if (_27242 != 0) {
            goto L9B; // [5993] 6072
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27244 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27244);
        _27245 = (object)*(((s1_ptr)_2)->base + 3);
        _27244 = NOVALUE;
        if (IS_ATOM_INT(_27245)) {
            _27246 = (_27245 == 1);
        }
        else {
            _27246 = binary_op(EQUALS, _27245, 1);
        }
        _27245 = NOVALUE;
        if (IS_ATOM_INT(_27246)) {
            if (_27246 == 0) {
                DeRef(_27247);
                _27247 = 0;
                goto L9C; // [6015] 6041
            }
        }
        else {
            if (DBL_PTR(_27246)->dbl == 0.0) {
                DeRef(_27247);
                _27247 = 0;
                goto L9C; // [6015] 6041
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27248 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27248);
        _27249 = (object)*(((s1_ptr)_2)->base + 4);
        _27248 = NOVALUE;
        if (IS_ATOM_INT(_27249)) {
            _27250 = (_27249 != 2);
        }
        else {
            _27250 = binary_op(NOTEQ, _27249, 2);
        }
        _27249 = NOVALUE;
        DeRef(_27247);
        if (IS_ATOM_INT(_27250))
        _27247 = (_27250 != 0);
        else
        _27247 = DBL_PTR(_27250)->dbl != 0.0;
L9C: 
        if (_27247 == 0) {
            DeRef(_27251);
            _27251 = 0;
            goto L9D; // [6041] 6067
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27252 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27252);
        _27253 = (object)*(((s1_ptr)_2)->base + 4);
        _27252 = NOVALUE;
        if (IS_ATOM_INT(_27253)) {
            _27254 = (_27253 != 4);
        }
        else {
            _27254 = binary_op(NOTEQ, _27253, 4);
        }
        _27253 = NOVALUE;
        if (IS_ATOM_INT(_27254))
        _27251 = (_27254 != 0);
        else
        _27251 = DBL_PTR(_27254)->dbl != 0.0;
L9D: 
        if (_27251 == 0)
        {
            _27251 = NOVALUE;
            goto L9E; // [6068] 6109
        }
        else{
            _27251 = NOVALUE;
        }
L9B: 

        /** emit.e:1530				emit_opcode(ASSIGN)*/
        _47emit_opcode(18);

        /** emit.e:1531				emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1532				b = NewTempSym()*/
        _b_52305 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1533				if ib then*/
        if (_ib_52313 == 0)
        {
            goto L9F; // [6094] 6103
        }
        else{
        }

        /** emit.e:1534					TempInteger( b )*/
        _47TempInteger(_b_52305);
L9F: 

        /** emit.e:1536				emit_addr(b)*/
        _47emit_addr(_b_52305);
L9E: 

        /** emit.e:1538			a = Pop() -- initial value*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1539			if IsInteger(a) and ib and ic then*/
        _27257 = _47IsInteger(_a_52304);
        if (IS_ATOM_INT(_27257)) {
            if (_27257 == 0) {
                DeRef(_27258);
                _27258 = 0;
                goto LA0; // [6122] 6130
            }
        }
        else {
            if (DBL_PTR(_27257)->dbl == 0.0) {
                DeRef(_27258);
                _27258 = 0;
                goto LA0; // [6122] 6130
            }
        }
        DeRef(_27258);
        _27258 = (_ib_52313 != 0);
LA0: 
        if (_27258 == 0) {
            goto LA1; // [6130] 6169
        }
        if (_ic_52314 == 0)
        {
            goto LA1; // [6135] 6169
        }
        else{
        }

        /** emit.e:1540				SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_47op_info1_51364 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _54integer_type_47142;
        DeRef(_1);
        _27260 = NOVALUE;

        /** emit.e:1541				op = FOR_I*/
        _op_52302 = 125;
        goto LA2; // [6166] 6179
LA1: 

        /** emit.e:1543				op = FOR*/
        _op_52302 = 21;
LA2: 

        /** emit.e:1545			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1546			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1547			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1548			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1549			emit_addr(CurrentSub) -- in case recursion check is needed*/
        _47emit_addr(_36CurrentSub_21775);

        /** emit.e:1550			Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1551			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1552			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6223] 7739

        /** emit.e:1555		case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** emit.e:1556			emit_opcode(op) -- will be patched at runtime*/
        _47emit_opcode(_op_52302);

        /** emit.e:1557			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1558			emit_addr(op_info2) -- address of top of loop*/
        _47emit_addr(_47op_info2_51365);

        /** emit.e:1559			emit_addr(Pop())    -- limit*/
        _27263 = _47Pop();
        _47emit_addr(_27263);
        _27263 = NOVALUE;

        /** emit.e:1560			emit_addr(op_info1) -- loop var*/
        _47emit_addr(_47op_info1_51364);

        /** emit.e:1561			emit_addr(a)        -- increment - not always used -*/
        _47emit_addr(_a_52304);

        /** emit.e:1563			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6277] 7739

        /** emit.e:1566		case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** emit.e:1568			b = Pop()      -- rhs value, keep on stack*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1569			TempKeep(b)*/
        _47TempKeep(_b_52305);

        /** emit.e:1571			a = Pop()      -- subscript, keep on stack*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1572			TempKeep(a)*/
        _47TempKeep(_a_52304);

        /** emit.e:1574			c = Pop()      -- lhs sequence, keep on stack*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1575			TempKeep(c)*/
        _47TempKeep(_c_52306);

        /** emit.e:1577			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1578			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1579			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1581			d = NewTempSym()*/
        _d_52307 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_d_52307)) {
            _1 = (object)(DBL_PTR(_d_52307)->dbl);
            DeRefDS(_d_52307);
            _d_52307 = _1;
        }

        /** emit.e:1582			emit_addr(d)   -- place to store result*/
        _47emit_addr(_d_52307);

        /** emit.e:1583			emit_temp( d, NEW_REFERENCE )*/
        _47emit_temp(_d_52307, 1);

        /** emit.e:1585			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1586			Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1587			Push(d)*/
        _47Push(_d_52307);

        /** emit.e:1588			Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1589			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6382] 7739

        /** emit.e:1592		case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** emit.e:1593			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1594			b = Pop() -- rhs value*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1595			a = Pop() -- 2nd subs*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1596			c = Pop() -- 1st subs*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1597			emit_addr(Pop()) -- sequence*/
        _27271 = _47Pop();
        _47emit_addr(_27271);
        _27271 = NOVALUE;

        /** emit.e:1598			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1599			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1600			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1601			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6446] 7739

        /** emit.e:1604		case REPLACE then*/
        case 201:

        /** emit.e:1605			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1607			b = Pop()  -- source*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1608			a = Pop()  -- replacement*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1609			c = Pop()  -- start of replaced slice*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1610			d = Pop()  -- end of replaced slice*/
        _d_52307 = _47Pop();
        if (!IS_ATOM_INT(_d_52307)) {
            _1 = (object)(DBL_PTR(_d_52307)->dbl);
            DeRefDS(_d_52307);
            _d_52307 = _1;
        }

        /** emit.e:1611			emit_addr(d)*/
        _47emit_addr(_d_52307);

        /** emit.e:1612			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1613			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1614			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1616			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1617			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1618			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_52306);

        /** emit.e:1619			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);

        /** emit.e:1620			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;
        goto LC; // [6536] 7739

        /** emit.e:1623		case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** emit.e:1625			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1627			b = Pop()        -- rhs value not used*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1628			TempKeep(b)*/
        _47TempKeep(_b_52305);

        /** emit.e:1630			a = Pop()        -- 2nd subs*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1631			TempKeep(a)*/
        _47TempKeep(_a_52304);

        /** emit.e:1633			c = Pop()        -- 1st subs*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1634			TempKeep(c)*/
        _47TempKeep(_c_52306);

        /** emit.e:1636			d = Pop()*/
        _d_52307 = _47Pop();
        if (!IS_ATOM_INT(_d_52307)) {
            _1 = (object)(DBL_PTR(_d_52307)->dbl);
            DeRefDS(_d_52307);
            _d_52307 = _1;
        }

        /** emit.e:1637			TempKeep(d)      -- sequence*/
        _47TempKeep(_d_52307);

        /** emit.e:1639			emit_addr(d)*/
        _47emit_addr(_d_52307);

        /** emit.e:1640			Push(d)*/
        _47Push(_d_52307);

        /** emit.e:1642			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1643			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1645			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1646			Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1648			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1649			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1650			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_52306);

        /** emit.e:1651			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);

        /** emit.e:1653			Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1654			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6663] 7739

        /** emit.e:1657		case CALL_PROC then*/
        case 136:

        /** emit.e:1658			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1659			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1660			emit_addr(Pop())*/
        _27283 = _47Pop();
        _47emit_addr(_27283);
        _27283 = NOVALUE;

        /** emit.e:1661			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1662			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6701] 7739

        /** emit.e:1664		case CALL_FUNC then*/
        case 137:

        /** emit.e:1665			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1666			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1667			emit_addr(Pop())*/
        _27285 = _47Pop();
        _47emit_addr(_27285);
        _27285 = NOVALUE;

        /** emit.e:1668			emit_addr(b)*/
        _47emit_addr(_b_52305);

        /** emit.e:1669			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1670			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1671			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1672			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1673			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);
        goto LC; // [6763] 7739

        /** emit.e:1675		case EXIT_BLOCK then*/
        case 206:

        /** emit.e:1676			emit_opcode( op )*/
        _47emit_opcode(_op_52302);

        /** emit.e:1677			emit_addr( Pop() )*/
        _27287 = _47Pop();
        _47emit_addr(_27287);
        _27287 = NOVALUE;

        /** emit.e:1678			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6789] 7739

        /** emit.e:1680		case RETURNP then*/
        case 29:

        /** emit.e:1681			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1682			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21775);

        /** emit.e:1683			emit_addr(top_block())*/
        _27288 = _65top_block(0);
        _47emit_addr(_27288);
        _27288 = NOVALUE;

        /** emit.e:1684			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6823] 7739

        /** emit.e:1686		case RETURNF then*/
        case 28:

        /** emit.e:1687			clear_temp( Top() )*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_7037_53622);
        _2 = (object)SEQ_PTR(_47cg_stack_51379);
        _Top_inlined_Top_at_7037_53622 = (object)*(((s1_ptr)_2)->base + _47cgi_51380);
        Ref(_Top_inlined_Top_at_7037_53622);
        Ref(_Top_inlined_Top_at_7037_53622);
        _47clear_temp(_Top_inlined_Top_at_7037_53622);

        /** emit.e:1688			flush_temps()*/
        RefDS(_22190);
        _47flush_temps(_22190);

        /** emit.e:1689			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1690			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21775);

        /** emit.e:1691			emit_addr(Least_block())*/
        _27289 = _65Least_block();
        _47emit_addr(_27289);
        _27289 = NOVALUE;

        /** emit.e:1692			emit_addr(Pop())*/
        _27290 = _47Pop();
        _47emit_addr(_27290);
        _27290 = NOVALUE;

        /** emit.e:1693			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6885] 7739

        /** emit.e:1695		case RETURNT then*/
        case 34:

        /** emit.e:1696			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1697			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [6903] 7739

        /** emit.e:1699		case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** emit.e:1701			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1702			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1703			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;

        /** emit.e:1704			if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_52302 != 79)
        goto LA3; // [6945] 6957

        /** emit.e:1705				TempInteger(c)*/
        _47TempInteger(_c_52306);
        goto LA4; // [6954] 6964
LA3: 

        /** emit.e:1707				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52306, 1);
LA4: 

        /** emit.e:1709			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1710			emit_addr(c)*/
        _47emit_addr(_c_52306);
        goto LC; // [6974] 7739

        /** emit.e:1712		case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** emit.e:1713			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1714			emit_addr(Pop())*/
        _27293 = _47Pop();
        _47emit_addr(_27293);
        _27293 = NOVALUE;

        /** emit.e:1715			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7006] 7739

        /** emit.e:1717		case POWER then*/
        case 72:

        /** emit.e:1719			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1720			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1721			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27296 = (_b_52305 > 0);
        if (_27296 == 0) {
            _27297 = 0;
            goto LA5; // [7032] 7058
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27298 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27298);
        _27299 = (object)*(((s1_ptr)_2)->base + 3);
        _27298 = NOVALUE;
        if (IS_ATOM_INT(_27299)) {
            _27300 = (_27299 == 2);
        }
        else {
            _27300 = binary_op(EQUALS, _27299, 2);
        }
        _27299 = NOVALUE;
        if (IS_ATOM_INT(_27300))
        _27297 = (_27300 != 0);
        else
        _27297 = DBL_PTR(_27300)->dbl != 0.0;
LA5: 
        if (_27297 == 0) {
            goto LA6; // [7058] 7115
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27302 = (object)*(((s1_ptr)_2)->base + _b_52305);
        _2 = (object)SEQ_PTR(_27302);
        _27303 = (object)*(((s1_ptr)_2)->base + 1);
        _27302 = NOVALUE;
        if (_27303 == 2)
        _27304 = 1;
        else if (IS_ATOM_INT(_27303) && IS_ATOM_INT(2))
        _27304 = 0;
        else
        _27304 = (compare(_27303, 2) == 0);
        _27303 = NOVALUE;
        if (_27304 == 0)
        {
            _27304 = NOVALUE;
            goto LA6; // [7079] 7115
        }
        else{
            _27304 = NOVALUE;
        }

        /** emit.e:1723				op = rw:MULTIPLY*/
        _op_52302 = 13;

        /** emit.e:1724				emit_opcode(op)*/
        _47emit_opcode(13);

        /** emit.e:1725				emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1726				emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1727				cont21d(op, a, b, FALSE)*/
        _47cont21d(13, _a_52304, _b_52305, _13FALSE_445);
        goto LC; // [7112] 7739
LA6: 

        /** emit.e:1729				Push(a)*/
        _47Push(_a_52304);

        /** emit.e:1730				Push(b)*/
        _47Push(_b_52305);

        /** emit.e:1731				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52302, _13FALSE_445);
        goto LC; // [7134] 7739

        /** emit.e:1735		case TYPE_CHECK then*/
        case 65:

        /** emit.e:1736			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1737			c = Pop()*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1738			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7159] 7739

        /** emit.e:1741		case DOLLAR then*/
        case -22:

        /** emit.e:1742			if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _27306 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _27306 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51372);
        _27307 = (object)*(((s1_ptr)_2)->base + _27306);
        if (IS_ATOM_INT(_27307)) {
            _27308 = (_27307 < 0);
        }
        else {
            _27308 = binary_op(LESS, _27307, 0);
        }
        _27307 = NOVALUE;
        if (IS_ATOM_INT(_27308)) {
            if (_27308 != 0) {
                goto LA7; // [7180] 7216
            }
        }
        else {
            if (DBL_PTR(_27308)->dbl != 0.0) {
                goto LA7; // [7180] 7216
            }
        }
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _27310 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _27310 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51372);
        _27311 = (object)*(((s1_ptr)_2)->base + _27310);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27311)){
            _27312 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27311)->dbl));
        }
        else{
            _27312 = (object)*(((s1_ptr)_2)->base + _27311);
        }
        _2 = (object)SEQ_PTR(_27312);
        _27313 = (object)*(((s1_ptr)_2)->base + 4);
        _27312 = NOVALUE;
        if (IS_ATOM_INT(_27313)) {
            _27314 = (_27313 == 9);
        }
        else {
            _27314 = binary_op(EQUALS, _27313, 9);
        }
        _27313 = NOVALUE;
        if (_27314 == 0) {
            DeRef(_27314);
            _27314 = NOVALUE;
            goto LA8; // [7212] 7286
        }
        else {
            if (!IS_ATOM_INT(_27314) && DBL_PTR(_27314)->dbl == 0.0){
                DeRef(_27314);
                _27314 = NOVALUE;
                goto LA8; // [7212] 7286
            }
            DeRef(_27314);
            _27314 = NOVALUE;
        }
        DeRef(_27314);
        _27314 = NOVALUE;
LA7: 

        /** emit.e:1743				if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_51374 == 0) {
            goto LA9; // [7220] 7249
        }
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _27316 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _27316 = 1;
        }
        _27317 = (_27316 == 1);
        _27316 = NOVALUE;
        if (_27317 == 0)
        {
            DeRef(_27317);
            _27317 = NOVALUE;
            goto LA9; // [7234] 7249
        }
        else{
            DeRef(_27317);
            _27317 = NOVALUE;
        }

        /** emit.e:1744					c = PLENGTH*/
        _c_52306 = 160;
        goto LAA; // [7246] 7259
LA9: 

        /** emit.e:1746					c = LENGTH*/
        _c_52306 = 42;
LAA: 

        /** emit.e:1748				c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _27318 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _27318 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51372);
        _27319 = (object)*(((s1_ptr)_2)->base + _27318);
        Ref(_27319);
        _27320 = _44new_forward_reference(-100, _27319, _c_52306);
        _27319 = NOVALUE;
        if (IS_ATOM_INT(_27320)) {
            if ((uintptr_t)_27320 == (uintptr_t)HIGH_BITS){
                _c_52306 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _c_52306 = - _27320;
            }
        }
        else {
            _c_52306 = unary_op(UMINUS, _27320);
        }
        DeRef(_27320);
        _27320 = NOVALUE;
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }
        goto LAB; // [7283] 7300
LA8: 

        /** emit.e:1750				c = current_sequence[$]*/
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _27322 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _27322 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51372);
        _c_52306 = (object)*(((s1_ptr)_2)->base + _27322);
        if (!IS_ATOM_INT(_c_52306)){
            _c_52306 = (object)DBL_PTR(_c_52306)->dbl;
        }
LAB: 

        /** emit.e:1754			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_51374 == 0) {
            goto LAC; // [7304] 7331
        }
        if (IS_SEQUENCE(_47current_sequence_51372)){
                _27325 = SEQ_PTR(_47current_sequence_51372)->length;
        }
        else {
            _27325 = 1;
        }
        _27326 = (_27325 == 1);
        _27325 = NOVALUE;
        if (_27326 == 0)
        {
            DeRef(_27326);
            _27326 = NOVALUE;
            goto LAC; // [7318] 7331
        }
        else{
            DeRef(_27326);
            _27326 = NOVALUE;
        }

        /** emit.e:1755				emit_opcode(PLENGTH)*/
        _47emit_opcode(160);
        goto LAD; // [7328] 7339
LAC: 

        /** emit.e:1757				emit_opcode(LENGTH)*/
        _47emit_opcode(42);
LAD: 

        /** emit.e:1760			emit_addr( c )*/
        _47emit_addr(_c_52306);

        /** emit.e:1762			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1763			TempInteger(c)*/
        _47TempInteger(_c_52306);

        /** emit.e:1764			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1765			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1766			assignable = FALSE -- it wouldn't be assigned anyway*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7374] 7739

        /** emit.e:1769		case TASK_SELF then*/
        case 170:

        /** emit.e:1770			c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1771			Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1772			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1773			emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1774			assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;
        goto LC; // [7410] 7739

        /** emit.e:1776		case SWITCH then*/
        case 185:

        /** emit.e:1777			emit_opcode( op )*/
        _47emit_opcode(_op_52302);

        /** emit.e:1778			c = Pop()*/
        _c_52306 = _47Pop();
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1779			b = Pop()*/
        _b_52305 = _47Pop();
        if (!IS_ATOM_INT(_b_52305)) {
            _1 = (object)(DBL_PTR(_b_52305)->dbl);
            DeRefDS(_b_52305);
            _b_52305 = _1;
        }

        /** emit.e:1780			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1781			emit_addr( a ) -- Switch Expr*/
        _47emit_addr(_a_52304);

        /** emit.e:1782			emit_addr( b ) -- Case values*/
        _47emit_addr(_b_52305);

        /** emit.e:1783			emit_addr( c ) -- Jump table*/
        _47emit_addr(_c_52306);

        /** emit.e:1785			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7464] 7739

        /** emit.e:1787		case CASE then*/
        case 186:

        /** emit.e:1789			emit_opcode( op )*/
        _47emit_opcode(_op_52302);

        /** emit.e:1790			emit( cg_stack[cgi] )  -- the case index*/
        _2 = (object)SEQ_PTR(_47cg_stack_51379);
        _27332 = (object)*(((s1_ptr)_2)->base + _47cgi_51380);
        Ref(_27332);
        _47emit(_27332);
        _27332 = NOVALUE;

        /** emit.e:1791			cgi -= 1*/
        _47cgi_51380 = _47cgi_51380 - 1;
        goto LC; // [7496] 7739

        /** emit.e:1794		case PLATFORM then*/
        case 155:

        /** emit.e:1795			if BIND and shroud_only then*/
        if (_36BIND_21372 == 0) {
            goto LAE; // [7506] 7554
        }
        if (_36shroud_only_21765 == 0)
        {
            goto LAE; // [7513] 7554
        }
        else{
        }

        /** emit.e:1797				c = NewTempSym()*/
        _c_52306 = _54NewTempSym(0);
        if (!IS_ATOM_INT(_c_52306)) {
            _1 = (object)(DBL_PTR(_c_52306)->dbl);
            DeRefDS(_c_52306);
            _c_52306 = _1;
        }

        /** emit.e:1798				TempInteger(c)*/
        _47TempInteger(_c_52306);

        /** emit.e:1799				Push(c)*/
        _47Push(_c_52306);

        /** emit.e:1800				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1801				emit_addr(c)*/
        _47emit_addr(_c_52306);

        /** emit.e:1802				assignable = TRUE*/
        _47assignable_51382 = _13TRUE_447;
        goto LC; // [7551] 7739
LAE: 

        /** emit.e:1806				n = host_platform()*/
        _n_52315 = _46host_platform();
        if (!IS_ATOM_INT(_n_52315)) {
            _1 = (object)(DBL_PTR(_n_52315)->dbl);
            DeRefDS(_n_52315);
            _n_52315 = _1;
        }

        /** emit.e:1807				Push(NewIntSym(n))*/
        _27337 = _54NewIntSym(_n_52315);
        _47Push(_27337);
        _27337 = NOVALUE;

        /** emit.e:1808				assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7578] 7739

        /** emit.e:1812		case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** emit.e:1813			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1814			emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1815			emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1816			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7610] 7739

        /** emit.e:1818		case TRACE then*/
        case 64:

        /** emit.e:1819			a = Pop()*/
        _a_52304 = _47Pop();
        if (!IS_ATOM_INT(_a_52304)) {
            _1 = (object)(DBL_PTR(_a_52304)->dbl);
            DeRefDS(_a_52304);
            _a_52304 = _1;
        }

        /** emit.e:1820			if OpTrace then*/
        if (_36OpTrace_21840 == 0)
        {
            goto LAF; // [7627] 7673
        }
        else{
        }

        /** emit.e:1822				emit_opcode(op)*/
        _47emit_opcode(_op_52302);

        /** emit.e:1823				emit_addr(a)*/
        _47emit_addr(_a_52304);

        /** emit.e:1824				if TRANSLATE then*/
        if (_36TRANSLATE_21369 == 0)
        {
            goto LB0; // [7644] 7672
        }
        else{
        }

        /** emit.e:1825					if not trace_called then*/
        if (_47trace_called_51367 != 0)
        goto LB1; // [7651] 7662

        /** emit.e:1826						Warning(217,0)*/
        RefDS(_22190);
        _50Warning(217, 0, _22190);
LB1: 

        /** emit.e:1828					trace_called = TRUE*/
        _47trace_called_51367 = _13TRUE_447;
LB0: 
LAF: 

        /** emit.e:1831			assignable = FALSE*/
        _47assignable_51382 = _13FALSE_445;
        goto LC; // [7680] 7739

        /** emit.e:1833		case REF_TEMP then*/
        case 207:

        /** emit.e:1835			emit_opcode( REF_TEMP )*/
        _47emit_opcode(207);

        /** emit.e:1836			emit_addr( Pop() )*/
        _27341 = _47Pop();
        _47emit_addr(_27341);
        _27341 = NOVALUE;
        goto LC; // [7701] 7739

        /** emit.e:1838		case DEREF_TEMP then*/
        case 208:

        /** emit.e:1839			emit_opcode( DEREF_TEMP )*/
        _47emit_opcode(208);

        /** emit.e:1840			emit_addr( Pop() )*/
        _27342 = _47Pop();
        _47emit_addr(_27342);
        _27342 = NOVALUE;
        goto LC; // [7722] 7739

        /** emit.e:1842		case else*/
        default:

        /** emit.e:1843			InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_52302;
        _27343 = MAKE_SEQ(_1);
        _50InternalErr(259, _27343);
        _27343 = NOVALUE;
    ;}LC: 

    /** emit.e:1847		previous_op = op*/
    _36previous_op_21869 = _op_52302;

    /** emit.e:1848		inlined = 0*/
    _47inlined_52280 = 0;

    /** emit.e:1850	end procedure*/
    DeRef(_obj_52316);
    DeRef(_elements_52317);
    DeRef(_element_vals_52318);
    DeRef(_26971);
    _26971 = NOVALUE;
    DeRef(_26962);
    _26962 = NOVALUE;
    DeRef(_27068);
    _27068 = NOVALUE;
    DeRef(_27001);
    _27001 = NOVALUE;
    DeRef(_26762);
    _26762 = NOVALUE;
    DeRef(_26944);
    _26944 = NOVALUE;
    DeRef(_27088);
    _27088 = NOVALUE;
    DeRef(_27179);
    _27179 = NOVALUE;
    DeRef(_26756);
    _26756 = NOVALUE;
    _27311 = NOVALUE;
    DeRef(_27250);
    _27250 = NOVALUE;
    DeRef(_27126);
    _27126 = NOVALUE;
    _26877 = NOVALUE;
    DeRef(_27066);
    _27066 = NOVALUE;
    DeRef(_26833);
    _26833 = NOVALUE;
    DeRef(_26907);
    _26907 = NOVALUE;
    DeRef(_26975);
    _26975 = NOVALUE;
    DeRef(_27300);
    _27300 = NOVALUE;
    DeRef(_27185);
    _27185 = NOVALUE;
    _27083 = NOVALUE;
    _27085 = NOVALUE;
    DeRef(_26808);
    _26808 = NOVALUE;
    DeRef(_27021);
    _27021 = NOVALUE;
    DeRef(_27216);
    _27216 = NOVALUE;
    DeRef(_26814);
    _26814 = NOVALUE;
    DeRef(_27308);
    _27308 = NOVALUE;
    DeRef(_27025);
    _27025 = NOVALUE;
    DeRef(_26928);
    _26928 = NOVALUE;
    DeRef(_27234);
    _27234 = NOVALUE;
    _26831 = NOVALUE;
    DeRef(_27189);
    _27189 = NOVALUE;
    DeRef(_26854);
    _26854 = NOVALUE;
    DeRef(_26810);
    _26810 = NOVALUE;
    DeRef(_27048);
    _27048 = NOVALUE;
    _26846 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_26758);
    _26758 = NOVALUE;
    DeRef(_27045);
    _27045 = NOVALUE;
    DeRef(_27038);
    _27038 = NOVALUE;
    DeRef(_27242);
    _27242 = NOVALUE;
    DeRef(_26940);
    _26940 = NOVALUE;
    DeRef(_26894);
    _26894 = NOVALUE;
    DeRef(_27167);
    _27167 = NOVALUE;
    DeRef(_27257);
    _27257 = NOVALUE;
    DeRef(_27172);
    _27172 = NOVALUE;
    DeRef(_26966);
    _26966 = NOVALUE;
    DeRef(_26934);
    _26934 = NOVALUE;
    DeRef(_27007);
    _27007 = NOVALUE;
    DeRef(_27042);
    _27042 = NOVALUE;
    DeRef(_26862);
    _26862 = NOVALUE;
    DeRef(_27072);
    _27072 = NOVALUE;
    DeRef(_26997);
    _26997 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_26754);
    _26754 = NOVALUE;
    DeRef(_27076);
    _27076 = NOVALUE;
    DeRef(_27016);
    _27016 = NOVALUE;
    DeRef(_26760);
    _26760 = NOVALUE;
    DeRef(_26843);
    _26843 = NOVALUE;
    DeRef(_27014);
    _27014 = NOVALUE;
    DeRef(_27050);
    _27050 = NOVALUE;
    DeRef(_26790);
    _26790 = NOVALUE;
    DeRef(_26868);
    _26868 = NOVALUE;
    DeRef(_26829);
    _26829 = NOVALUE;
    _26872 = NOVALUE;
    DeRef(_26992);
    _26992 = NOVALUE;
    DeRef(_26798);
    _26798 = NOVALUE;
    DeRef(_26875);
    _26875 = NOVALUE;
    DeRef(_26969);
    _26969 = NOVALUE;
    DeRef(_27148);
    _27148 = NOVALUE;
    DeRef(_27160);
    _27160 = NOVALUE;
    DeRef(_26805);
    _26805 = NOVALUE;
    DeRef(_27218);
    _27218 = NOVALUE;
    DeRef(_27027);
    _27027 = NOVALUE;
    DeRef(_26950);
    _26950 = NOVALUE;
    DeRef(_26795);
    _26795 = NOVALUE;
    DeRef(_26948);
    _26948 = NOVALUE;
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_26988);
    _26988 = NOVALUE;
    _26848 = NOVALUE;
    DeRef(_27296);
    _27296 = NOVALUE;
    DeRef(_27202);
    _27202 = NOVALUE;
    DeRef(_27080);
    _27080 = NOVALUE;
    DeRef(_27003);
    _27003 = NOVALUE;
    DeRef(_27246);
    _27246 = NOVALUE;
    DeRef(_27254);
    _27254 = NOVALUE;
    DeRef(_27153);
    _27153 = NOVALUE;
    _26778 = NOVALUE;
    return;
    ;
}


void _47emit_assign_op(object _op_53781)
{
    object _0, _1, _2;
    

    /** emit.e:1854		if op = PLUS_EQUALS then*/
    if (_op_53781 != 515)
    goto L1; // [7] 21

    /** emit.e:1855			emit_op(PLUS)*/
    _47emit_op(11);
    goto L2; // [18] 86
L1: 

    /** emit.e:1856		elsif op = MINUS_EQUALS then*/
    if (_op_53781 != 516)
    goto L3; // [25] 39

    /** emit.e:1857			emit_op(MINUS)*/
    _47emit_op(10);
    goto L2; // [36] 86
L3: 

    /** emit.e:1858		elsif op = MULTIPLY_EQUALS then*/
    if (_op_53781 != 517)
    goto L4; // [43] 55

    /** emit.e:1859			emit_op(rw:MULTIPLY)*/
    _47emit_op(13);
    goto L2; // [52] 86
L4: 

    /** emit.e:1860		elsif op = DIVIDE_EQUALS then*/
    if (_op_53781 != 518)
    goto L5; // [59] 71

    /** emit.e:1861			emit_op(rw:DIVIDE)*/
    _47emit_op(14);
    goto L2; // [68] 86
L5: 

    /** emit.e:1862		elsif op = CONCAT_EQUALS then*/
    if (_op_53781 != 519)
    goto L6; // [75] 85

    /** emit.e:1863			emit_op(rw:CONCAT)*/
    _47emit_op(15);
L6: 
L2: 

    /** emit.e:1865	end procedure*/
    return;
    ;
}


void _47StartSourceLine(object _sl_53801, object _dup_ok_53802, object _emit_coverage_53803)
{
    object _line_span_53806 = NOVALUE;
    object _27365 = NOVALUE;
    object _27363 = NOVALUE;
    object _27362 = NOVALUE;
    object _27361 = NOVALUE;
    object _27360 = NOVALUE;
    object _27359 = NOVALUE;
    object _27357 = NOVALUE;
    object _27354 = NOVALUE;
    object _27352 = NOVALUE;
    object _27351 = NOVALUE;
    object _27350 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1873		if gline_number = LastLineNumber then*/
    if (_36gline_number_21772 != _62LastLineNumber_25877)
    goto L1; // [13] 66

    /** emit.e:1874			if length(LineTable) then*/
    if (IS_SEQUENCE(_36LineTable_21860)){
            _27350 = SEQ_PTR(_36LineTable_21860)->length;
    }
    else {
        _27350 = 1;
    }
    if (_27350 == 0)
    {
        _27350 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27350 = NOVALUE;
    }

    /** emit.e:1875				if dup_ok then*/
    if (_dup_ok_53802 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** emit.e:1876					emit_op( STARTLINE )*/
    _47emit_op(58);

    /** emit.e:1877					emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21772);
L3: 

    /** emit.e:1879				return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** emit.e:1882				sl = FALSE -- top-level new statement to execute on same line*/
    _sl_53801 = _13FALSE_445;
L4: 
L1: 

    /** emit.e:1885		LastLineNumber = gline_number*/
    _62LastLineNumber_25877 = _36gline_number_21772;

    /** emit.e:1888		line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27351 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_27351);
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21444)){
        _27352 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21444)->dbl));
    }
    else{
        _27352 = (object)*(((s1_ptr)_2)->base + _36S_FIRSTLINE_21444);
    }
    _27351 = NOVALUE;
    if (IS_ATOM_INT(_27352)) {
        _line_span_53806 = _36gline_number_21772 - _27352;
    }
    else {
        _line_span_53806 = binary_op(MINUS, _36gline_number_21772, _27352);
    }
    _27352 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_53806)) {
        _1 = (object)(DBL_PTR(_line_span_53806)->dbl);
        DeRefDS(_line_span_53806);
        _line_span_53806 = _1;
    }

    /** emit.e:1889		while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_36LineTable_21860)){
            _27354 = SEQ_PTR(_36LineTable_21860)->length;
    }
    else {
        _27354 = 1;
    }
    if (_27354 >= _line_span_53806)
    goto L6; // [109] 128

    /** emit.e:1890			LineTable = append(LineTable, -1) -- filler*/
    Append(&_36LineTable_21860, _36LineTable_21860, -1);

    /** emit.e:1891		end while*/
    goto L5; // [125] 104
L6: 

    /** emit.e:1892		LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_36Code_21859)){
            _27357 = SEQ_PTR(_36Code_21859)->length;
    }
    else {
        _27357 = 1;
    }
    Append(&_36LineTable_21860, _36LineTable_21860, _27357);
    _27357 = NOVALUE;

    /** emit.e:1894		if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_53801 == 0) {
        goto L7; // [145] 190
    }
    if (_36TRANSLATE_21369 != 0) {
        DeRef(_27360);
        _27360 = 1;
        goto L8; // [151] 171
    }
    if (_36OpTrace_21840 != 0) {
        _27361 = 1;
        goto L9; // [157] 167
    }
    _27361 = (_36OpProfileStatement_21842 != 0);
L9: 
    DeRef(_27360);
    _27360 = (_27361 != 0);
L8: 
    if (_27360 == 0)
    {
        _27360 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27360 = NOVALUE;
    }

    /** emit.e:1896			emit_op(STARTLINE)*/
    _47emit_op(58);

    /** emit.e:1897			emit_addr(gline_number)*/
    _47emit_addr(_36gline_number_21772);
L7: 

    /** emit.e:1901		if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_53801 == 0) {
        _27362 = 0;
        goto LA; // [192] 206
    }
    _27363 = (_emit_coverage_53803 == 2);
    _27362 = (_27363 != 0);
LA: 
    if (_27362 != 0) {
        goto LB; // [206] 221
    }
    _27365 = (_emit_coverage_53803 == 3);
    if (_27365 == 0)
    {
        DeRef(_27365);
        _27365 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27365);
        _27365 = NOVALUE;
    }
LB: 

    /** emit.e:1902			include_line( gline_number )*/
    _51include_line(_36gline_number_21772);
LC: 

    /** emit.e:1905	end procedure*/
    DeRef(_27363);
    _27363 = NOVALUE;
    return;
    ;
}


object _47has_forward_params(object _sym_53860)
{
    object _27371 = NOVALUE;
    object _27370 = NOVALUE;
    object _27369 = NOVALUE;
    object _27368 = NOVALUE;
    object _27367 = NOVALUE;
    object _27366 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1908		for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27366 = (object)*(((s1_ptr)_2)->base + _sym_53860);
    _2 = (object)SEQ_PTR(_27366);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _27367 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _27367 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _27366 = NOVALUE;
    if (IS_ATOM_INT(_27367)) {
        _27368 = _27367 - 1;
        if ((object)((uintptr_t)_27368 +(uintptr_t) HIGH_BITS) >= 0){
            _27368 = NewDouble((eudouble)_27368);
        }
    }
    else {
        _27368 = binary_op(MINUS, _27367, 1);
    }
    _27367 = NOVALUE;
    if (IS_ATOM_INT(_27368)) {
        _27369 = _47cgi_51380 - _27368;
        if ((object)((uintptr_t)_27369 +(uintptr_t) HIGH_BITS) >= 0){
            _27369 = NewDouble((eudouble)_27369);
        }
    }
    else {
        _27369 = binary_op(MINUS, _47cgi_51380, _27368);
    }
    DeRef(_27368);
    _27368 = NOVALUE;
    _27370 = _47cgi_51380;
    {
        object _i_53862;
        Ref(_27369);
        _i_53862 = _27369;
L1: 
        if (binary_op_a(GREATER, _i_53862, _27370)){
            goto L2; // [32] 65
        }

        /** emit.e:1909			if cg_stack[i] < 0 then*/
        _2 = (object)SEQ_PTR(_47cg_stack_51379);
        if (!IS_ATOM_INT(_i_53862)){
            _27371 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_53862)->dbl));
        }
        else{
            _27371 = (object)*(((s1_ptr)_2)->base + _i_53862);
        }
        if (binary_op_a(GREATEREQ, _27371, 0)){
            _27371 = NOVALUE;
            goto L3; // [47] 58
        }
        _27371 = NOVALUE;

        /** emit.e:1910				return 1*/
        DeRef(_i_53862);
        DeRef(_27369);
        _27369 = NOVALUE;
        return 1;
L3: 

        /** emit.e:1912		end for*/
        _0 = _i_53862;
        if (IS_ATOM_INT(_i_53862)) {
            _i_53862 = _i_53862 + 1;
            if ((object)((uintptr_t)_i_53862 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53862 = NewDouble((eudouble)_i_53862);
            }
        }
        else {
            _i_53862 = binary_op_a(PLUS, _i_53862, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_53862);
    }

    /** emit.e:1913		return 0*/
    DeRef(_27369);
    _27369 = NOVALUE;
    return 0;
    ;
}



// 0xF2F29BE7
