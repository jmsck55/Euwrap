// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46host_platform()
{
    object _0, _1, _2;
    

    /** platform.e:113		return ihost_platform*/
    return _46ihost_platform_21939;
    ;
}


void _46set_host_platform(object _plat_21946)
{
    object _12366 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:119		ihost_platform = floor(plat)*/
    _46ihost_platform_21939 = e_floor(_plat_21946);

    /** platform.e:121		TUNIX    = (find(ihost_platform, unices) != 0) */
    _12366 = find_from(_46ihost_platform_21939, _46unices_21942, 1);
    _46TUNIX_21918 = (_12366 != 0);
    _12366 = NOVALUE;

    /** platform.e:122		TWINDOWS = (ihost_platform = WIN32)*/
    _46TWINDOWS_21914 = (_46ihost_platform_21939 == 2);

    /** platform.e:123		TBSD     = (ihost_platform = UFREEBSD)*/
    _46TBSD_21920 = (_46ihost_platform_21939 == 8);

    /** platform.e:124		TOSX     = (ihost_platform = UOSX)*/
    _46TOSX_21922 = (_46ihost_platform_21939 == 4);

    /** platform.e:125		TLINUX   = (ihost_platform = ULINUX)*/
    _46TLINUX_21916 = (_46ihost_platform_21939 == 3);

    /** platform.e:126		TOPENBSD = (ihost_platform = UOPENBSD)*/
    _46TOPENBSD_21924 = (_46ihost_platform_21939 == 6);

    /** platform.e:127		TNETBSD  = (ihost_platform = UNETBSD)*/
    _46TNETBSD_21926 = (_46ihost_platform_21939 == 7);

    /** platform.e:128		IUNIX    = TUNIX*/
    _46IUNIX_21917 = _46TUNIX_21918;

    /** platform.e:129		IWINDOWS = TWINDOWS*/
    _46IWINDOWS_21913 = _46TWINDOWS_21914;

    /** platform.e:130		IBSD     = TBSD*/
    _46IBSD_21919 = _46TBSD_21920;

    /** platform.e:131		IOSX     = TOSX*/
    _46IOSX_21921 = _46TOSX_21922;

    /** platform.e:132		ILINUX   = TLINUX*/
    _46ILINUX_21915 = _46TLINUX_21916;

    /** platform.e:133		IOPENBSD = TOPENBSD*/
    _46IOPENBSD_21923 = _46TOPENBSD_21924;

    /** platform.e:134		INETBSD  = TNETBSD*/
    _46INETBSD_21925 = _46TNETBSD_21926;

    /** platform.e:136		if TUNIX then*/
    if (_46TUNIX_21918 == 0)
    {
        goto L1; // [148] 161
    }
    else{
    }

    /** platform.e:137			HOSTNL = "\n"*/
    RefDS(_9945);
    DeRefi(_46HOSTNL_21937);
    _46HOSTNL_21937 = _9945;
    goto L2; // [158] 169
L1: 

    /** platform.e:139			HOSTNL = "\r\n"*/
    RefDS(_12363);
    DeRefi(_46HOSTNL_21937);
    _46HOSTNL_21937 = _12363;
L2: 

    /** platform.e:141	end procedure*/
    return;
    ;
}


void _46set_target_arch(object _arch_21961)
{
    object _12383 = NOVALUE;
    object _12374 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:144		IX86    = 0*/
    _46IX86_21927 = 0;

    /** platform.e:145		TX86    = 0*/
    _46TX86_21928 = 0;

    /** platform.e:146		IX86_64 = 0*/
    _46IX86_64_21929 = 0;

    /** platform.e:147		TX86_64 = 0*/
    _46TX86_64_21930 = 0;

    /** platform.e:148		IARM    = 0*/
    _46IARM_21931 = 0;

    /** platform.e:149		TARM    = 0*/
    _46TARM_21932 = 0;

    /** platform.e:150		switch upper( arch ) do*/
    RefDS(_arch_21961);
    _12374 = _14upper(_arch_21961);
    _1 = find(_12374, _12375);
    DeRef(_12374);
    _12374 = NOVALUE;
    switch ( _1 ){ 

        /** platform.e:151			case "X86", "IX86" then*/
        case 1:
        case 2:

        /** platform.e:152				IX86    = 1*/
        _46IX86_21927 = 1;

        /** platform.e:153				TX86    = 1*/
        _46TX86_21928 = 1;

        /** platform.e:154				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21589 = 4;
        goto L1; // [67] 140

        /** platform.e:156			case "X86_64", "IX86_64" then*/
        case 3:
        case 4:

        /** platform.e:157				IX86_64 = 1*/
        _46IX86_64_21929 = 1;

        /** platform.e:158				TX86_64 = 1*/
        _46TX86_64_21930 = 1;

        /** platform.e:159				TARGET_SIZEOF_POINTER = 8*/
        _36TARGET_SIZEOF_POINTER_21589 = 8;
        goto L1; // [92] 140

        /** platform.e:161			case "ARM" then*/
        case 5:

        /** platform.e:162				IARM = 1*/
        _46IARM_21931 = 1;

        /** platform.e:163				TARM = 1*/
        _46TARM_21932 = 1;

        /** platform.e:164				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21589 = 4;
        goto L1; // [115] 140

        /** platform.e:166			case else*/
        case 0:

        /** platform.e:167				ShowMsg( 2, UNKNOWN_ARCHITECTURE_1__SUPPORTED_ARCHITECTURES_ARE_2, { arch, "X86, X86_64, ARM" } )*/
        RefDS(_12382);
        RefDS(_arch_21961);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _arch_21961;
        ((intptr_t *)_2)[2] = _12382;
        _12383 = MAKE_SEQ(_1);
        _39ShowMsg(2, 357, _12383, 1);
        _12383 = NOVALUE;

        /** platform.e:168				abort( 1 )*/
        UserCleanup(1);
    ;}L1: 

    /** platform.e:170		set_target_integer_size( TARGET_SIZEOF_POINTER )	*/
    _36set_target_integer_size(_36TARGET_SIZEOF_POINTER_21589);

    /** platform.e:171	end procedure*/
    DeRefDS(_arch_21961);
    return;
    ;
}


object _46GetPlatformDefines(object _for_translator_21986)
{
    object _local_defines_21987 = NOVALUE;
    object _lcmds_21997 = NOVALUE;
    object _fh_21999 = NOVALUE;
    object _sk_22019 = NOVALUE;
    object _12508 = NOVALUE;
    object _12507 = NOVALUE;
    object _12505 = NOVALUE;
    object _12502 = NOVALUE;
    object _12501 = NOVALUE;
    object _12499 = NOVALUE;
    object _12498 = NOVALUE;
    object _12496 = NOVALUE;
    object _12493 = NOVALUE;
    object _12492 = NOVALUE;
    object _12490 = NOVALUE;
    object _12489 = NOVALUE;
    object _12487 = NOVALUE;
    object _12485 = NOVALUE;
    object _12483 = NOVALUE;
    object _12482 = NOVALUE;
    object _12480 = NOVALUE;
    object _12477 = NOVALUE;
    object _12475 = NOVALUE;
    object _12474 = NOVALUE;
    object _12472 = NOVALUE;
    object _12470 = NOVALUE;
    object _12468 = NOVALUE;
    object _12467 = NOVALUE;
    object _12465 = NOVALUE;
    object _12463 = NOVALUE;
    object _12461 = NOVALUE;
    object _12460 = NOVALUE;
    object _12458 = NOVALUE;
    object _12456 = NOVALUE;
    object _12454 = NOVALUE;
    object _12453 = NOVALUE;
    object _12451 = NOVALUE;
    object _12448 = NOVALUE;
    object _12446 = NOVALUE;
    object _12445 = NOVALUE;
    object _12443 = NOVALUE;
    object _12441 = NOVALUE;
    object _12439 = NOVALUE;
    object _12438 = NOVALUE;
    object _12435 = NOVALUE;
    object _12432 = NOVALUE;
    object _12429 = NOVALUE;
    object _12425 = NOVALUE;
    object _12424 = NOVALUE;
    object _12419 = NOVALUE;
    object _12418 = NOVALUE;
    object _12405 = NOVALUE;
    object _12402 = NOVALUE;
    object _12399 = NOVALUE;
    object _12398 = NOVALUE;
    object _12397 = NOVALUE;
    object _12393 = NOVALUE;
    object _12390 = NOVALUE;
    object _12387 = NOVALUE;
    object _12385 = NOVALUE;
    object _12384 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:174		sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_21987);
    _local_defines_21987 = _5;

    /** platform.e:176		if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21913 == 0) {
        _12384 = 0;
        goto L1; // [14] 25
    }
    _12385 = (_for_translator_21986 == 0);
    _12384 = (_12385 != 0);
L1: 
    if (_12384 != 0) {
        goto L2; // [25] 44
    }
    if (_46TWINDOWS_21914 == 0) {
        DeRef(_12387);
        _12387 = 0;
        goto L3; // [31] 39
    }
    _12387 = (_for_translator_21986 != 0);
L3: 
    if (_12387 == 0)
    {
        _12387 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _12387 = NOVALUE;
    }
L2: 

    /** platform.e:177			local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_12389);
    RefDS(_12388);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12388;
    ((intptr_t *)_2)[2] = _12389;
    _12390 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12390);
    DeRefDS(_12390);
    _12390 = NOVALUE;

    /** platform.e:178			sequence lcmds = command_line()*/
    DeRef(_lcmds_21997);
    _lcmds_21997 = Command_Line();

    /** platform.e:181			integer fh*/

    /** platform.e:182			fh = open(lcmds[1], "rb")*/
    _2 = (object)SEQ_PTR(_lcmds_21997);
    _12393 = (object)*(((s1_ptr)_2)->base + 1);
    _fh_21999 = EOpen(_12393, _10266, 0);
    _12393 = NOVALUE;

    /** platform.e:183			if fh = -1 then*/
    if (_fh_21999 != -1)
    goto L5; // [73] 123

    /** platform.e:185	 			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (object)SEQ_PTR(_lcmds_21997);
    _12397 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_12397);
    _12398 = _14lower(_12397);
    _12397 = NOVALUE;
    _12399 = e_match_from(_12396, _12398, 1);
    DeRef(_12398);
    _12398 = NOVALUE;
    if (_12399 == 0)
    goto L6; // [92] 109

    /** platform.e:186	 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12401);
    ((intptr_t*)_2)[1] = _12401;
    _12402 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12402);
    DeRefDS(_12402);
    _12402 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /** platform.e:188	 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12404);
    ((intptr_t*)_2)[1] = _12404;
    _12405 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12405);
    DeRefDS(_12405);
    _12405 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** platform.e:191				atom sk*/

    /** platform.e:192				sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_22019;
    _sk_22019 = _8seek(_fh_21999, 24);
    DeRef(_0);

    /** platform.e:193				sk = get_integer16(fh)*/
    _0 = _sk_22019;
    _sk_22019 = _8get_integer16(_fh_21999);
    DeRef(_0);

    /** platform.e:194				if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_22019, 64)){
        goto L8; // [140] 259
    }

    /** platform.e:196					sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_22019;
    _sk_22019 = _8seek(_fh_21999, 60);
    DeRef(_0);

    /** platform.e:197					sk = get_integer32(fh)*/
    _0 = _sk_22019;
    _sk_22019 = _8get_integer32(_fh_21999);
    DeRef(_0);

    /** platform.e:198					sk = seek(fh, sk)*/
    Ref(_sk_22019);
    _0 = _sk_22019;
    _sk_22019 = _8seek(_fh_21999, _sk_22019);
    DeRef(_0);

    /** platform.e:199					sk = get_integer16(fh)*/
    _0 = _sk_22019;
    _sk_22019 = _8get_integer16(_fh_21999);
    DeRef(_0);

    /** platform.e:200					if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_22019, 17744)){
        goto L9; // [172] 221
    }

    /** platform.e:201						sk = get_integer16(fh)*/
    _0 = _sk_22019;
    _sk_22019 = _8get_integer16(_fh_21999);
    DeRef(_0);

    /** platform.e:202						if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_22019, 0)){
        goto LA; // [184] 212
    }

    /** platform.e:204							sk = seek(fh, where(fh) + 88 )*/
    _12418 = _8where(_fh_21999);
    if (IS_ATOM_INT(_12418)) {
        _12419 = _12418 + 88;
        if ((object)((uintptr_t)_12419 + (uintptr_t)HIGH_BITS) >= 0){
            _12419 = NewDouble((eudouble)_12419);
        }
    }
    else {
        _12419 = binary_op(PLUS, _12418, 88);
    }
    DeRef(_12418);
    _12418 = NOVALUE;
    _0 = _sk_22019;
    _sk_22019 = _8seek(_fh_21999, _12419);
    DeRef(_0);
    _12419 = NOVALUE;

    /** platform.e:205							sk = get_integer16(fh)*/
    _0 = _sk_22019;
    _sk_22019 = _8get_integer16(_fh_21999);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** platform.e:207							sk = 0	-- Don't know this format.*/
    DeRef(_sk_22019);
    _sk_22019 = 0;
    goto LB; // [218] 265
L9: 

    /** platform.e:209					elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_22019, 17742)){
        goto LC; // [223] 250
    }

    /** platform.e:211						sk = seek(fh, where(fh) + 54 )*/
    _12424 = _8where(_fh_21999);
    if (IS_ATOM_INT(_12424)) {
        _12425 = _12424 + 54;
        if ((object)((uintptr_t)_12425 + (uintptr_t)HIGH_BITS) >= 0){
            _12425 = NewDouble((eudouble)_12425);
        }
    }
    else {
        _12425 = binary_op(PLUS, _12424, 54);
    }
    DeRef(_12424);
    _12424 = NOVALUE;
    _0 = _sk_22019;
    _sk_22019 = _8seek(_fh_21999, _12425);
    DeRef(_0);
    _12425 = NOVALUE;

    /** platform.e:212						sk = getc(fh)*/
    DeRef(_sk_22019);
    if (_fh_21999 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_21999, EF_READ);
        last_r_file_no = _fh_21999;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _sk_22019 = getKBchar();
        }
        else{
            _sk_22019 = getc(last_r_file_ptr);
        }
    }
    else{
        _sk_22019 = getc(last_r_file_ptr);
    }
    goto LB; // [247] 265
LC: 

    /** platform.e:214						sk = 0*/
    DeRef(_sk_22019);
    _sk_22019 = 0;
    goto LB; // [256] 265
L8: 

    /** platform.e:217					sk = 0*/
    DeRef(_sk_22019);
    _sk_22019 = 0;
LB: 

    /** platform.e:219				if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_22019, 2)){
        goto LD; // [267] 284
    }

    /** platform.e:220					local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12401);
    ((intptr_t*)_2)[1] = _12401;
    _12429 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12429);
    DeRefDS(_12429);
    _12429 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** platform.e:221				elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_22019, 3)){
        goto LF; // [286] 303
    }

    /** platform.e:222					local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12404);
    ((intptr_t*)_2)[1] = _12404;
    _12432 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12432);
    DeRefDS(_12432);
    _12432 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** platform.e:224					local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12434);
    ((intptr_t*)_2)[1] = _12434;
    _12435 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12435);
    DeRefDS(_12435);
    _12435 = NOVALUE;
LE: 

    /** platform.e:226				close(fh)*/
    EClose(_fh_21999);
    DeRef(_sk_22019);
    _sk_22019 = NOVALUE;
L7: 
    DeRef(_lcmds_21997);
    _lcmds_21997 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** platform.e:229			local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_12404);
    Append(&_local_defines_21987, _local_defines_21987, _12404);

    /** platform.e:230			if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_46ILINUX_21915 == 0) {
        _12438 = 0;
        goto L11; // [336] 347
    }
    _12439 = (_for_translator_21986 == 0);
    _12438 = (_12439 != 0);
L11: 
    if (_12438 != 0) {
        goto L12; // [347] 366
    }
    if (_46TLINUX_21916 == 0) {
        DeRef(_12441);
        _12441 = 0;
        goto L13; // [353] 361
    }
    _12441 = (_for_translator_21986 != 0);
L13: 
    if (_12441 == 0)
    {
        _12441 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _12441 = NOVALUE;
    }
L12: 

    /** platform.e:231				local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_12442);
    RefDS(_12171);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12171;
    ((intptr_t *)_2)[2] = _12442;
    _12443 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12443);
    DeRefDS(_12443);
    _12443 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** platform.e:232			elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (_46IOSX_21921 == 0) {
        _12445 = 0;
        goto L16; // [383] 394
    }
    _12446 = (_for_translator_21986 == 0);
    _12445 = (_12446 != 0);
L16: 
    if (_12445 != 0) {
        goto L17; // [394] 413
    }
    if (_46TOSX_21922 == 0) {
        DeRef(_12448);
        _12448 = 0;
        goto L18; // [400] 408
    }
    _12448 = (_for_translator_21986 != 0);
L18: 
    if (_12448 == 0)
    {
        _12448 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _12448 = NOVALUE;
    }
L17: 

    /** platform.e:233				local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12171);
    ((intptr_t*)_2)[1] = _12171;
    RefDS(_12449);
    ((intptr_t*)_2)[2] = _12449;
    RefDS(_12450);
    ((intptr_t*)_2)[3] = _12450;
    _12451 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12451);
    DeRefDS(_12451);
    _12451 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** platform.e:234			elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (_46IOPENBSD_21923 == 0) {
        _12453 = 0;
        goto L1A; // [432] 443
    }
    _12454 = (_for_translator_21986 == 0);
    _12453 = (_12454 != 0);
L1A: 
    if (_12453 != 0) {
        goto L1B; // [443] 462
    }
    if (_46TOPENBSD_21924 == 0) {
        DeRef(_12456);
        _12456 = 0;
        goto L1C; // [449] 457
    }
    _12456 = (_for_translator_21986 != 0);
L1C: 
    if (_12456 == 0)
    {
        _12456 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _12456 = NOVALUE;
    }
L1B: 

    /** platform.e:235				local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12171);
    ((intptr_t*)_2)[1] = _12171;
    RefDS(_12449);
    ((intptr_t*)_2)[2] = _12449;
    RefDS(_12457);
    ((intptr_t*)_2)[3] = _12457;
    _12458 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12458);
    DeRefDS(_12458);
    _12458 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** platform.e:236			elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (_46INETBSD_21925 == 0) {
        _12460 = 0;
        goto L1E; // [481] 492
    }
    _12461 = (_for_translator_21986 == 0);
    _12460 = (_12461 != 0);
L1E: 
    if (_12460 != 0) {
        goto L1F; // [492] 511
    }
    if (_46TNETBSD_21926 == 0) {
        DeRef(_12463);
        _12463 = 0;
        goto L20; // [498] 506
    }
    _12463 = (_for_translator_21986 != 0);
L20: 
    if (_12463 == 0)
    {
        _12463 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _12463 = NOVALUE;
    }
L1F: 

    /** platform.e:237				local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12171);
    ((intptr_t*)_2)[1] = _12171;
    RefDS(_12449);
    ((intptr_t*)_2)[2] = _12449;
    RefDS(_12464);
    ((intptr_t*)_2)[3] = _12464;
    _12465 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12465);
    DeRefDS(_12465);
    _12465 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** platform.e:238			elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (_46IBSD_21919 == 0) {
        _12467 = 0;
        goto L22; // [530] 541
    }
    _12468 = (_for_translator_21986 == 0);
    _12467 = (_12468 != 0);
L22: 
    if (_12467 != 0) {
        goto L23; // [541] 560
    }
    if (_46TBSD_21920 == 0) {
        DeRef(_12470);
        _12470 = 0;
        goto L24; // [547] 555
    }
    _12470 = (_for_translator_21986 != 0);
L24: 
    if (_12470 == 0)
    {
        _12470 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _12470 = NOVALUE;
    }
L23: 

    /** platform.e:239				local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12171);
    ((intptr_t*)_2)[1] = _12171;
    RefDS(_12449);
    ((intptr_t*)_2)[2] = _12449;
    RefDS(_12471);
    ((intptr_t*)_2)[3] = _12471;
    _12472 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12472);
    DeRefDS(_12472);
    _12472 = NOVALUE;
L25: 
L15: 
L10: 

    /** platform.e:243		if (IX86 and not for_translator) or (TX86 and for_translator) then*/
    if (_46IX86_21927 == 0) {
        _12474 = 0;
        goto L26; // [579] 590
    }
    _12475 = (_for_translator_21986 == 0);
    _12474 = (_12475 != 0);
L26: 
    if (_12474 != 0) {
        goto L27; // [590] 609
    }
    if (_46TX86_21928 == 0) {
        DeRef(_12477);
        _12477 = 0;
        goto L28; // [596] 604
    }
    _12477 = (_for_translator_21986 != 0);
L28: 
    if (_12477 == 0)
    {
        _12477 = NOVALUE;
        goto L29; // [605] 624
    }
    else{
        _12477 = NOVALUE;
    }
L27: 

    /** platform.e:244			local_defines &= {"X86", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12377);
    ((intptr_t*)_2)[1] = _12377;
    RefDS(_12478);
    ((intptr_t*)_2)[2] = _12478;
    RefDS(_12479);
    ((intptr_t*)_2)[3] = _12479;
    _12480 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12480);
    DeRefDS(_12480);
    _12480 = NOVALUE;
    goto L2A; // [621] 777
L29: 

    /** platform.e:246		elsif (IX86_64 and not for_translator) or (TX86_64 and for_translator) then*/
    if (_46IX86_64_21929 == 0) {
        _12482 = 0;
        goto L2B; // [628] 639
    }
    _12483 = (_for_translator_21986 == 0);
    _12482 = (_12483 != 0);
L2B: 
    if (_12482 != 0) {
        goto L2C; // [639] 658
    }
    if (_46TX86_64_21930 == 0) {
        DeRef(_12485);
        _12485 = 0;
        goto L2D; // [645] 653
    }
    _12485 = (_for_translator_21986 != 0);
L2D: 
    if (_12485 == 0)
    {
        _12485 = NOVALUE;
        goto L2E; // [654] 729
    }
    else{
        _12485 = NOVALUE;
    }
L2C: 

    /** platform.e:247			local_defines &= {"X86_64", "BITS64"}*/
    RefDS(_12486);
    RefDS(_12379);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12379;
    ((intptr_t *)_2)[2] = _12486;
    _12487 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12487);
    DeRefDS(_12487);
    _12487 = NOVALUE;

    /** platform.e:248			if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21913 == 0) {
        _12489 = 0;
        goto L2F; // [672] 683
    }
    _12490 = (_for_translator_21986 == 0);
    _12489 = (_12490 != 0);
L2F: 
    if (_12489 != 0) {
        goto L30; // [683] 702
    }
    if (_46TWINDOWS_21914 == 0) {
        DeRef(_12492);
        _12492 = 0;
        goto L31; // [689] 697
    }
    _12492 = (_for_translator_21986 != 0);
L31: 
    if (_12492 == 0)
    {
        _12492 = NOVALUE;
        goto L32; // [698] 715
    }
    else{
        _12492 = NOVALUE;
    }
L30: 

    /** platform.e:249				local_defines &= {"LONG32"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12479);
    ((intptr_t*)_2)[1] = _12479;
    _12493 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12493);
    DeRefDS(_12493);
    _12493 = NOVALUE;
    goto L2A; // [712] 777
L32: 

    /** platform.e:251				local_defines &= {"LONG64"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12495);
    ((intptr_t*)_2)[1] = _12495;
    _12496 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12496);
    DeRefDS(_12496);
    _12496 = NOVALUE;
    goto L2A; // [726] 777
L2E: 

    /** platform.e:253		elsif (IARM and not for_translator) or (TARM and for_translator) then*/
    if (_46IARM_21931 == 0) {
        _12498 = 0;
        goto L33; // [733] 744
    }
    _12499 = (_for_translator_21986 == 0);
    _12498 = (_12499 != 0);
L33: 
    if (_12498 != 0) {
        goto L34; // [744] 763
    }
    if (_46TARM_21932 == 0) {
        DeRef(_12501);
        _12501 = 0;
        goto L35; // [750] 758
    }
    _12501 = (_for_translator_21986 != 0);
L35: 
    if (_12501 == 0)
    {
        _12501 = NOVALUE;
        goto L36; // [759] 776
    }
    else{
        _12501 = NOVALUE;
    }
L34: 

    /** platform.e:254			local_defines &= {"ARM", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12381);
    ((intptr_t*)_2)[1] = _12381;
    RefDS(_12478);
    ((intptr_t*)_2)[2] = _12478;
    RefDS(_12479);
    ((intptr_t*)_2)[3] = _12479;
    _12502 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21987, _local_defines_21987, _12502);
    DeRefDS(_12502);
    _12502 = NOVALUE;
L36: 
L2A: 

    /** platform.e:259		return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12504);
    ((intptr_t*)_2)[1] = _12504;
    _12505 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12506);
    ((intptr_t*)_2)[1] = _12506;
    _12507 = MAKE_SEQ(_1);
    {
        object concat_list[3];

        concat_list[0] = _12507;
        concat_list[1] = _local_defines_21987;
        concat_list[2] = _12505;
        Concat_N((object_ptr)&_12508, concat_list, 3);
    }
    DeRefDS(_12507);
    _12507 = NOVALUE;
    DeRefDS(_12505);
    _12505 = NOVALUE;
    DeRefDS(_local_defines_21987);
    DeRef(_12490);
    _12490 = NOVALUE;
    DeRef(_12385);
    _12385 = NOVALUE;
    DeRef(_12483);
    _12483 = NOVALUE;
    DeRef(_12454);
    _12454 = NOVALUE;
    DeRef(_12468);
    _12468 = NOVALUE;
    DeRef(_12499);
    _12499 = NOVALUE;
    DeRef(_12461);
    _12461 = NOVALUE;
    DeRef(_12439);
    _12439 = NOVALUE;
    DeRef(_12475);
    _12475 = NOVALUE;
    DeRef(_12446);
    _12446 = NOVALUE;
    return _12508;
    ;
}



// 0xD3FE196E
