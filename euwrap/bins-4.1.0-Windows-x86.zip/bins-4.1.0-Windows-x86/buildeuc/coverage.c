// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _51check_coverage()
{
    object _25319 = NOVALUE;
    object _25318 = NOVALUE;
    object _25317 = NOVALUE;
    object _25316 = NOVALUE;
    object _25315 = NOVALUE;
    object _25314 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_51file_coverage_49181)){
            _25314 = SEQ_PTR(_51file_coverage_49181)->length;
    }
    else {
        _25314 = 1;
    }
    _25315 = _25314 + 1;
    _25314 = NOVALUE;
    if (IS_SEQUENCE(_37known_files_15638)){
            _25316 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _25316 = 1;
    }
    {
        object _i_49192;
        _i_49192 = _25315;
L1: 
        if (_i_49192 > _25316){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _25317 = (object)*(((s1_ptr)_2)->base + _i_49192);
        Ref(_25317);
        _25318 = _17canonical_path(_25317, 0, 1);
        _25317 = NOVALUE;
        _25319 = find_from(_25318, _51covered_files_49180, 1);
        DeRef(_25318);
        _25318 = NOVALUE;
        Append(&_51file_coverage_49181, _51file_coverage_49181, _25319);
        _25319 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_49192 = _i_49192 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25315);
    _25315 = NOVALUE;
    return;
    ;
}


void _51init_coverage()
{
    object _cmd_49216 = NOVALUE;
    object _25337 = NOVALUE;
    object _25336 = NOVALUE;
    object _25334 = NOVALUE;
    object _25333 = NOVALUE;
    object _25332 = NOVALUE;
    object _25330 = NOVALUE;
    object _25328 = NOVALUE;
    object _25327 = NOVALUE;
    object _25325 = NOVALUE;
    object _25324 = NOVALUE;
    object _25323 = NOVALUE;
    object _25322 = NOVALUE;
    object _25321 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_51initialized_coverage_49188 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _51initialized_coverage_49188 = 1;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_51file_coverage_49181)){
            _25321 = SEQ_PTR(_51file_coverage_49181)->length;
    }
    else {
        _25321 = 1;
    }
    {
        object _i_49207;
        _i_49207 = 1;
L2: 
        if (_i_49207 > _25321){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _25322 = (object)*(((s1_ptr)_2)->base + _i_49207);
        Ref(_25322);
        _25323 = _17canonical_path(_25322, 0, 1);
        _25322 = NOVALUE;
        _25324 = find_from(_25323, _51covered_files_49180, 1);
        DeRef(_25323);
        _25323 = NOVALUE;
        _2 = (object)SEQ_PTR(_51file_coverage_49181);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _51file_coverage_49181 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_49207);
        *(intptr_t *)_2 = _25324;
        if( _1 != _25324 ){
        }
        _25324 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_49207 = _i_49207 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_51coverage_db_name_49182 == _22190)
    _25325 = 1;
    else if (IS_ATOM_INT(_51coverage_db_name_49182) && IS_ATOM_INT(_22190))
    _25325 = 0;
    else
    _25325 = (compare(_51coverage_db_name_49182, _22190) == 0);
    if (_25325 == 0)
    {
        _25325 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25325 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_49216);
    _cmd_49216 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_49216);
    _25327 = (object)*(((s1_ptr)_2)->base + 2);
    RefDS(_25327);
    _25328 = _17filebase(_25327);
    _25327 = NOVALUE;
    if (IS_SEQUENCE(_25328) && IS_ATOM(_25329)) {
    }
    else if (IS_ATOM(_25328) && IS_SEQUENCE(_25329)) {
        Ref(_25328);
        Prepend(&_25330, _25329, _25328);
    }
    else {
        Concat((object_ptr)&_25330, _25328, _25329);
        DeRef(_25328);
        _25328 = NOVALUE;
    }
    DeRef(_25328);
    _25328 = NOVALUE;
    _0 = _17canonical_path(_25330, 0, 0);
    DeRefDS(_51coverage_db_name_49182);
    _51coverage_db_name_49182 = _0;
    _25330 = NOVALUE;
L4: 
    DeRef(_cmd_49216);
    _cmd_49216 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (0 == 0) {
        goto L5; // [111] 153
    }
    RefDS(_51coverage_db_name_49182);
    _25333 = _17file_exists(_51coverage_db_name_49182);
    if (_25333 == 0) {
        DeRef(_25333);
        _25333 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25333) && DBL_PTR(_25333)->dbl == 0.0){
            DeRef(_25333);
            _25333 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25333);
        _25333 = NOVALUE;
    }
    DeRef(_25333);
    _25333 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_51coverage_db_name_49182);
    _25334 = _17delete_file(_51coverage_db_name_49182);
    if (IS_ATOM_INT(_25334)) {
        if (_25334 != 0){
            DeRef(_25334);
            _25334 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25334)->dbl != 0.0){
            DeRef(_25334);
            _25334 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25334);
    _25334 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_51coverage_db_name_49182);
    ((intptr_t*)_2)[1] = _51coverage_db_name_49182;
    _25336 = MAKE_SEQ(_1);
    _50CompileErr(335, _25336, 0);
    _25336 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_51coverage_db_name_49182);
    _25337 = _43db_open(_51coverage_db_name_49182, 0);
    if (binary_op_a(NOTEQ, _25337, 0)){
        DeRef(_25337);
        _25337 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25337);
    _25337 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _51read_coverage_db();

    /** coverage.e:75			db_close()*/
    _43db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _51read_coverage_db()
{
    object _tables_49322 = NOVALUE;
    object _name_49328 = NOVALUE;
    object _fx_49332 = NOVALUE;
    object _the_map_49339 = NOVALUE;
    object _31972 = NOVALUE;
    object _25385 = NOVALUE;
    object _25384 = NOVALUE;
    object _25383 = NOVALUE;
    object _25379 = NOVALUE;
    object _25378 = NOVALUE;
    object _25377 = NOVALUE;
    object _25373 = NOVALUE;
    object _25372 = NOVALUE;
    object _25371 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_49322;
    _tables_49322 = _43db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_49322)){
            _25371 = SEQ_PTR(_tables_49322)->length;
    }
    else {
        _25371 = 1;
    }
    {
        object _i_49326;
        _i_49326 = 1;
L1: 
        if (_i_49326 > _25371){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_49322);
        _25372 = (object)*(((s1_ptr)_2)->base + _i_49326);
        if (IS_SEQUENCE(_25372)){
                _25373 = SEQ_PTR(_25372)->length;
        }
        else {
            _25373 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_49328;
        RHS_Slice(_25372, 2, _25373);
        _25372 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_49332 = find_from(_name_49328, _51covered_files_49180, 1);

        /** coverage.e:140			if not fx then*/
        if (_fx_49332 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_49328);
        _name_49328 = NOVALUE;
        DeRef(_the_map_49339);
        _the_map_49339 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_49322);
        _25377 = (object)*(((s1_ptr)_2)->base + _i_49326);
        Ref(_25377);
        _31972 = _43db_select_table(_25377);
        _25377 = NOVALUE;
        DeRef(_31972);
        _31972 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_49322);
        _25378 = (object)*(((s1_ptr)_2)->base + _i_49326);
        _2 = (object)SEQ_PTR(_25378);
        _25379 = (object)*(((s1_ptr)_2)->base + 1);
        _25378 = NOVALUE;
        if (binary_op_a(NOTEQ, _25379, 114)){
            _25379 = NOVALUE;
            goto L5; // [77] 92
        }
        _25379 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_49339);
        _2 = (object)SEQ_PTR(_51routine_map_49186);
        _the_map_49339 = (object)*(((s1_ptr)_2)->base + _fx_49332);
        Ref(_the_map_49339);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_49339);
        _2 = (object)SEQ_PTR(_51line_map_49185);
        _the_map_49339 = (object)*(((s1_ptr)_2)->base + _fx_49332);
        Ref(_the_map_49339);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_43current_table_name_17117);
        _25383 = _43db_table_size(_43current_table_name_17117);
        {
            object _j_49348;
            _j_49348 = 1;
L7: 
            if (binary_op_a(GREATER, _j_49348, _25383)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_49348);
            RefDS(_43current_table_name_17117);
            _25384 = _43db_record_key(_j_49348, _43current_table_name_17117);
            Ref(_j_49348);
            RefDS(_43current_table_name_17117);
            _25385 = _43db_record_data(_j_49348, _43current_table_name_17117);
            Ref(_the_map_49339);
            _29put(_the_map_49339, _25384, _25385, 2, 0);
            _25384 = NOVALUE;
            _25385 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_49348;
            if (IS_ATOM_INT(_j_49348)) {
                _j_49348 = _j_49348 + 1;
                if ((object)((uintptr_t)_j_49348 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_49348 = NewDouble((eudouble)_j_49348);
                }
            }
            else {
                _j_49348 = binary_op_a(PLUS, _j_49348, 1);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_49348);
        }
        DeRef(_name_49328);
        _name_49328 = NOVALUE;
        DeRef(_the_map_49339);
        _the_map_49339 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_49326 = _i_49326 + 1;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_49322);
    DeRef(_25383);
    _25383 = NOVALUE;
    return;
    ;
}


object _51coverage_on()
{
    object _25386 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_51file_coverage_49181);
    _25386 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    return _25386;
    ;
}


void _51include_line(object _line_number_49488)
{
    object _25447 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25447 = _51coverage_on();
    if (_25447 == 0) {
        DeRef(_25447);
        _25447 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25447) && DBL_PTR(_25447)->dbl == 0.0){
            DeRef(_25447);
            _25447 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25447);
        _25447 = NOVALUE;
    }
    DeRef(_25447);
    _25447 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _47emit_op(210);

    /** coverage.e:249			emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21772);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_51included_lines_49187, _51included_lines_49187, _line_number_49488);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _51include_routine()
{
    object _file_no_49504 = NOVALUE;
    object _25454 = NOVALUE;
    object _25453 = NOVALUE;
    object _25452 = NOVALUE;
    object _25450 = NOVALUE;
    object _25449 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25449 = _51coverage_on();
    if (_25449 == 0) {
        DeRef(_25449);
        _25449 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25449) && DBL_PTR(_25449)->dbl == 0.0){
            DeRef(_25449);
            _25449 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25449);
        _25449 = NOVALUE;
    }
    DeRef(_25449);
    _25449 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _47emit_op(211);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _47emit_addr(_36CurrentSub_21775);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25450 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25450);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _file_no_49504 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _file_no_49504 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_file_no_49504)){
        _file_no_49504 = (object)DBL_PTR(_file_no_49504)->dbl;
    }
    _25450 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_51file_coverage_49181);
    _25452 = (object)*(((s1_ptr)_2)->base + _file_no_49504);
    _2 = (object)SEQ_PTR(_51routine_map_49186);
    _25453 = (object)*(((s1_ptr)_2)->base + _25452);
    _25454 = _54sym_name(_36CurrentSub_21775);
    Ref(_25453);
    _29put(_25453, _25454, 0, 2, 0);
    _25453 = NOVALUE;
    _25454 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25452 = NOVALUE;
    return;
    ;
}



// 0xCFB062FB
