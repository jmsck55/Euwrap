// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _9allocate(object _n_1024, object _cleanup_1025)
{
    object _iaddr_1026 = NOVALUE;
    object _eaddr_1027 = NOVALUE;
    object _394 = NOVALUE;
    object _393 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:541		ifdef DATA_EXECUTE then*/

    /** machine.e:545			iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _393 = 0;
    if (IS_ATOM_INT(_n_1024)) {
        _394 = _n_1024 + 0;
        if ((object)((uintptr_t)_394 + (uintptr_t)HIGH_BITS) >= 0){
            _394 = NewDouble((eudouble)_394);
        }
    }
    else {
        _394 = NewDouble(DBL_PTR(_n_1024)->dbl + (eudouble)0);
    }
    _393 = NOVALUE;
    DeRef(_iaddr_1026);
    _iaddr_1026 = machine(16, _394);
    DeRef(_394);
    _394 = NOVALUE;

    /** machine.e:546			eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_1026);
    Ref(_n_1024);
    _0 = _eaddr_1027;
    _eaddr_1027 = _11prepare_block(_iaddr_1026, _n_1024, 4);
    DeRef(_0);

    /** machine.e:548		if cleanup then*/

    /** machine.e:551		return eaddr*/
    DeRef(_n_1024);
    DeRef(_iaddr_1026);
    return _eaddr_1027;
    ;
}


void _9free_pointer_array(object _pointers_array_1066)
{
    object _saved_1067 = NOVALUE;
    object _ptr_1068 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:661		atom saved = pointers_array*/
    Ref(_pointers_array_1066);
    DeRef(_saved_1067);
    _saved_1067 = _pointers_array_1066;

    /** machine.e:664		while ptr with entry do*/
    goto L1; // [8] 41
L2: 
    if (_ptr_1068 <= 0) {
        if (_ptr_1068 == 0) {
            goto L3; // [13] 51
        }
        else {
            if (!IS_ATOM_INT(_ptr_1068) && DBL_PTR(_ptr_1068)->dbl == 0.0){
                goto L3; // [13] 51
            }
        }
    }

    /** machine.e:665			memory:deallocate( ptr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_1068);

    /** memory.e:83	end procedure*/
    goto L4; // [27] 30
L4: 

    /** machine.e:666			pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1066;
    if (IS_ATOM_INT(_pointers_array_1066)) {
        _pointers_array_1066 = _pointers_array_1066 + _9ADDRESS_LENGTH_1012;
        if ((object)((uintptr_t)_pointers_array_1066 + (uintptr_t)HIGH_BITS) >= 0){
            _pointers_array_1066 = NewDouble((eudouble)_pointers_array_1066);
        }
    }
    else {
        _pointers_array_1066 = NewDouble(DBL_PTR(_pointers_array_1066)->dbl + (eudouble)_9ADDRESS_LENGTH_1012);
    }
    DeRef(_0);

    /** machine.e:668		entry*/
L1: 

    /** machine.e:669			ptr = peek_pointer(pointers_array)*/
    DeRef(_ptr_1068);
    if (IS_ATOM_INT(_pointers_array_1066)) {
        _ptr_1068 = *(intptr_t *)_pointers_array_1066;
        if ((uintptr_t)_ptr_1068 > (uintptr_t)MAXINT){
            _ptr_1068 = NewDouble((eudouble)(uintptr_t)_ptr_1068);
        }
    }
    else {
        _ptr_1068 = *(uintptr_t *)(uintptr_t)(DBL_PTR(_pointers_array_1066)->dbl);
        if ((uintptr_t)_ptr_1068 > (uintptr_t)MAXINT){
            _ptr_1068 = NewDouble((eudouble)(uintptr_t)_ptr_1068);
        }
    }

    /** machine.e:670		end while*/
    goto L2; // [48] 11
L3: 

    /** machine.e:672		free(saved)*/
    Ref(_saved_1067);
    _9free(_saved_1067);

    /** machine.e:673	end procedure*/
    DeRef(_pointers_array_1066);
    DeRef(_saved_1067);
    DeRef(_ptr_1068);
    return;
    ;
}


object _9VirtualAlloc(object _addr_1212, object _size_1213, object _allocation_type_1214, object _protect__1215)
{
    object _r1_1216 = NOVALUE;
    object _486 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:1979			r1 = c_func( VirtualAlloc_rid, {addr, size, allocation_type, protect_ } )*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 1;
    Ref(_allocation_type_1214);
    ((intptr_t*)_2)[3] = _allocation_type_1214;
    ((intptr_t*)_2)[4] = 64;
    _486 = MAKE_SEQ(_1);
    DeRef(_r1_1216);
    _r1_1216 = call_c(1, _9VirtualAlloc_rid_1152, _486);
    DeRefDS(_486);
    _486 = NOVALUE;

    /** machine.e:1980			return r1*/
    DeRef(_allocation_type_1214);
    return _r1_1216;
    ;
}


object _9allocate_string(object _s_1243, object _cleanup_1244)
{
    object _mem_1245 = NOVALUE;
    object _497 = NOVALUE;
    object _496 = NOVALUE;
    object _494 = NOVALUE;
    object _493 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2096		mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1243)){
            _493 = SEQ_PTR(_s_1243)->length;
    }
    else {
        _493 = 1;
    }
    _494 = _493 + 1;
    _493 = NOVALUE;
    _0 = _mem_1245;
    _mem_1245 = _9allocate(_494, 0);
    DeRef(_0);
    _494 = NOVALUE;

    /** machine.e:2098		if mem then*/
    if (_mem_1245 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1245) && DBL_PTR(_mem_1245)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** machine.e:2099			poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1245)){
        poke_addr = (uint8_t *)_mem_1245;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_mem_1245)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_1243);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** machine.e:2100			poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1243)){
            _496 = SEQ_PTR(_s_1243)->length;
    }
    else {
        _496 = 1;
    }
    if (IS_ATOM_INT(_mem_1245)) {
        _497 = _mem_1245 + _496;
        if ((object)((uintptr_t)_497 + (uintptr_t)HIGH_BITS) >= 0){
            _497 = NewDouble((eudouble)_497);
        }
    }
    else {
        _497 = NewDouble(DBL_PTR(_mem_1245)->dbl + (eudouble)_496);
    }
    _496 = NOVALUE;
    if (IS_ATOM_INT(_497)){
        poke_addr = (uint8_t *)_497;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_497)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_497);
    _497 = NOVALUE;

    /** machine.e:2101			if cleanup then*/
L1: 

    /** machine.e:2106		return mem*/
    DeRefDS(_s_1243);
    return _mem_1245;
    ;
}


void _9free(object _addr_1350)
{
    object _msg_inlined_crash_at_27_1359 = NOVALUE;
    object _data_inlined_crash_at_24_1358 = NOVALUE;
    object _addr_inlined_deallocate_at_64_1365 = NOVALUE;
    object _msg_inlined_crash_at_106_1370 = NOVALUE;
    object _539 = NOVALUE;
    object _538 = NOVALUE;
    object _537 = NOVALUE;
    object _536 = NOVALUE;
    object _534 = NOVALUE;
    object _533 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2319		if types:number_array (addr) then*/
    Ref(_addr_1350);
    _533 = _13number_array(_addr_1350);
    if (_533 == 0) {
        DeRef(_533);
        _533 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_533) && DBL_PTR(_533)->dbl == 0.0){
            DeRef(_533);
            _533 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_533);
        _533 = NOVALUE;
    }
    DeRef(_533);
    _533 = NOVALUE;

    /** machine.e:2320			if types:ascii_string(addr) then*/
    Ref(_addr_1350);
    _534 = _13ascii_string(_addr_1350);
    if (_534 == 0) {
        DeRef(_534);
        _534 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_534) && DBL_PTR(_534)->dbl == 0.0){
            DeRef(_534);
            _534 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_534);
        _534 = NOVALUE;
    }
    DeRef(_534);
    _534 = NOVALUE;

    /** machine.e:2321				error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_addr_1350);
    ((intptr_t*)_2)[1] = _addr_1350;
    _536 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1358);
    _data_inlined_crash_at_24_1358 = _536;
    _536 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1359);
    _msg_inlined_crash_at_27_1359 = EPrintf(-9999999, _535, _data_inlined_crash_at_24_1358);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1359);

    /** error.e:53	end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1358);
    _data_inlined_crash_at_24_1358 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1359);
    _msg_inlined_crash_at_27_1359 = NOVALUE;
L2: 

    /** machine.e:2324			for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1350)){
            _537 = SEQ_PTR(_addr_1350)->length;
    }
    else {
        _537 = 1;
    }
    {
        object _i_1361;
        _i_1361 = 1;
L4: 
        if (_i_1361 > _537){
            goto L5; // [52] 89
        }

        /** machine.e:2325				memory:deallocate( addr[i] )*/
        _2 = (object)SEQ_PTR(_addr_1350);
        _538 = (object)*(((s1_ptr)_2)->base + _i_1361);
        Ref(_538);
        DeRef(_addr_inlined_deallocate_at_64_1365);
        _addr_inlined_deallocate_at_64_1365 = _538;
        _538 = NOVALUE;

        /** memory.e:71		ifdef DATA_EXECUTE then*/

        /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1365);

        /** memory.e:83	end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1365);
        _addr_inlined_deallocate_at_64_1365 = NOVALUE;

        /** machine.e:2326			end for*/
        _i_1361 = _i_1361 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** machine.e:2327			return*/
    DeRef(_addr_1350);
    return;
    goto L7; // [94] 127
L1: 

    /** machine.e:2328		elsif sequence(addr) then*/
    _539 = IS_SEQUENCE(_addr_1350);
    if (_539 == 0)
    {
        _539 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _539 = NOVALUE;
    }

    /** machine.e:2329			error:crash("free() called with nested sequence")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1370);
    _msg_inlined_crash_at_106_1370 = EPrintf(-9999999, _540, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1370);

    /** error.e:53	end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1370);
    _msg_inlined_crash_at_106_1370 = NOVALUE;
L8: 
L7: 

    /** machine.e:2332		if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1350, 0)){
        goto LA; // [129] 139
    }

    /** machine.e:2335			return*/
    DeRef(_addr_1350);
    return;
LA: 

    /** machine.e:2338		memory:deallocate( addr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1350);

    /** memory.e:83	end procedure*/
    goto LB; // [150] 153
LB: 

    /** machine.e:2339	end procedure*/
    DeRef(_addr_1350);
    return;
    ;
}



// 0xD1586F5C
