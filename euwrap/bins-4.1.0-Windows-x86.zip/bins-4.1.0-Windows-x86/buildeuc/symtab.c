// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _54hashfn(object _name_47151)
{
    object _len_47152 = NOVALUE;
    object _val_47153 = NOVALUE;
    object _int_47154 = NOVALUE;
    object _24513 = NOVALUE;
    object _24512 = NOVALUE;
    object _24509 = NOVALUE;
    object _24508 = NOVALUE;
    object _24497 = NOVALUE;
    object _24493 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_47151)){
            _len_47152 = SEQ_PTR(_name_47151)->length;
    }
    else {
        _len_47152 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_47151);
    _val_47153 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_47153))
    _val_47153 = (object)DBL_PTR(_val_47153)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_47151)){
            _24493 = SEQ_PTR(_name_47151)->length;
    }
    else {
        _24493 = 1;
    }
    _2 = (object)SEQ_PTR(_name_47151);
    _int_47154 = (object)*(((s1_ptr)_2)->base + _24493);
    if (!IS_ATOM_INT(_int_47154))
    _int_47154 = (object)DBL_PTR(_int_47154)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_47154 = _int_47154 * 256;

    /** symtab.e:54		val *= 2*/
    _val_47153 = _val_47153 + _val_47153;

    /** symtab.e:55		val += int + len*/
    _24497 = _int_47154 + _len_47152;
    if ((object)((uintptr_t)_24497 + (uintptr_t)HIGH_BITS) >= 0){
        _24497 = NewDouble((eudouble)_24497);
    }
    if (IS_ATOM_INT(_24497)) {
        _val_47153 = _val_47153 + _24497;
    }
    else {
        _val_47153 = NewDouble((eudouble)_val_47153 + DBL_PTR(_24497)->dbl);
    }
    DeRef(_24497);
    _24497 = NOVALUE;
    if (!IS_ATOM_INT(_val_47153)) {
        _1 = (object)(DBL_PTR(_val_47153)->dbl);
        DeRefDS(_val_47153);
        _val_47153 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_47152 != 3)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_47153 = _val_47153 * 32;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47151);
    _int_47154 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_47154))
    _int_47154 = (object)DBL_PTR(_int_47154)->dbl;

    /** symtab.e:60			val += int*/
    _val_47153 = _val_47153 + _int_47154;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_47152 <= 3)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_47153 = _val_47153 * 32;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47151);
    _int_47154 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_47154))
    _int_47154 = (object)DBL_PTR(_int_47154)->dbl;

    /** symtab.e:64			val += int*/
    _val_47153 = _val_47153 + _int_47154;

    /** symtab.e:66			val *= 32*/
    _val_47153 = _val_47153 * 32;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_47151)){
            _24508 = SEQ_PTR(_name_47151)->length;
    }
    else {
        _24508 = 1;
    }
    _24509 = _24508 - 1;
    _24508 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_47151);
    _int_47154 = (object)*(((s1_ptr)_2)->base + _24509);
    if (!IS_ATOM_INT(_int_47154))
    _int_47154 = (object)DBL_PTR(_int_47154)->dbl;

    /** symtab.e:68			val += int*/
    _val_47153 = _val_47153 + _int_47154;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24512 = (_val_47153 % 2003);
    _24513 = _24512 + 1;
    _24512 = NOVALUE;
    DeRefDS(_name_47151);
    DeRef(_24509);
    _24509 = NOVALUE;
    return _24513;
    ;
}


void _54remove_symbol(object _sym_47183)
{
    object _hash_47184 = NOVALUE;
    object _st_ptr_47185 = NOVALUE;
    object _24528 = NOVALUE;
    object _24527 = NOVALUE;
    object _24525 = NOVALUE;
    object _24524 = NOVALUE;
    object _24523 = NOVALUE;
    object _24521 = NOVALUE;
    object _24519 = NOVALUE;
    object _24518 = NOVALUE;
    object _24517 = NOVALUE;
    object _24514 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24514 = (object)*(((s1_ptr)_2)->base + _sym_47183);
    _2 = (object)SEQ_PTR(_24514);
    _hash_47184 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_47184)){
        _hash_47184 = (object)DBL_PTR(_hash_47184)->dbl;
    }
    _24514 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _st_ptr_47185 = (object)*(((s1_ptr)_2)->base + _hash_47184);
    if (!IS_ATOM_INT(_st_ptr_47185))
    _st_ptr_47185 = (object)DBL_PTR(_st_ptr_47185)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_47185 == 0) {
        goto L2; // [32] 65
    }
    _24518 = (_st_ptr_47185 != _sym_47183);
    if (_24518 == 0)
    {
        DeRef(_24518);
        _24518 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24518);
        _24518 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24519 = (object)*(((s1_ptr)_2)->base + _st_ptr_47185);
    _2 = (object)SEQ_PTR(_24519);
    _st_ptr_47185 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_47185)){
        _st_ptr_47185 = (object)DBL_PTR(_st_ptr_47185)->dbl;
    }
    _24519 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_47185 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _24521 = (object)*(((s1_ptr)_2)->base + _hash_47184);
    if (binary_op_a(NOTEQ, _st_ptr_47185, _24521)){
        _24521 = NOVALUE;
        goto L4; // [78] 105
    }
    _24521 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24523 = (object)*(((s1_ptr)_2)->base + _st_ptr_47185);
    _2 = (object)SEQ_PTR(_24523);
    _24524 = (object)*(((s1_ptr)_2)->base + 9);
    _24523 = NOVALUE;
    Ref(_24524);
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _2 = (object)(((s1_ptr)_2)->base + _hash_47184);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24524;
    if( _1 != _24524 ){
        DeRef(_1);
    }
    _24524 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_47185 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24527 = (object)*(((s1_ptr)_2)->base + _sym_47183);
    _2 = (object)SEQ_PTR(_24527);
    _24528 = (object)*(((s1_ptr)_2)->base + 9);
    _24527 = NOVALUE;
    Ref(_24528);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24528;
    if( _1 != _24528 ){
        DeRef(_1);
    }
    _24528 = NOVALUE;
    _24525 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _54NewBasicEntry(object _name_47217, object _varnum_47218, object _scope_47219, object _token_47220, object _hashval_47221, object _samehash_47223, object _type_sym_47225)
{
    object _new_47226 = NOVALUE;
    object _24537 = NOVALUE;
    object _24535 = NOVALUE;
    object _24534 = NOVALUE;
    object _24533 = NOVALUE;
    object _24532 = NOVALUE;
    object _24531 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_47226);
    _new_47226 = Repeat(0, _36SIZEOF_ROUTINE_ENTRY_21530);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_47226);
    _new_47226 = Repeat(0, _36SIZEOF_VAR_ENTRY_21533);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_47217);
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21404))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21404);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_47217;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_47219;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21400))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21767;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _24531 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24531 = - _36NOVALUE_21621;
        }
    }
    else {
        _24531 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24531;
    if( _1 != _24531 ){
        DeRef(_1);
    }
    _24531 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _24532 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24532 = - _36NOVALUE_21621;
        }
    }
    else {
        _24532 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24532;
    if( _1 != _24532 ){
        DeRef(_1);
    }
    _24532 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _24533 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24533 = - _36NOVALUE_21621;
        }
    }
    else {
        _24533 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24533;
    if( _1 != _24533 ){
        DeRef(_1);
    }
    _24533 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13TRUE_447;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _24534 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24534 = - _36NOVALUE_21621;
        }
    }
    else {
        _24534 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24534;
    if( _1 != _24534 ){
        DeRef(_1);
    }
    _24534 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_36NOVALUE_21621)) {
        if ((uintptr_t)_36NOVALUE_21621 == (uintptr_t)HIGH_BITS){
            _24535 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24535 = - _36NOVALUE_21621;
        }
    }
    else {
        _24535 = unary_op(UMINUS, _36NOVALUE_21621);
    }
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24535;
    if( _1 != _24535 ){
        DeRef(_1);
    }
    _24535 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21409))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_47220;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_47218;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_47225;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_47221;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_47223;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_new_47226);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47226 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_47226);
    Append(&_37SymTab_15637, _37SymTab_15637, _new_47226);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _24537 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _24537 = 1;
    }
    DeRefDS(_name_47217);
    DeRefDS(_new_47226);
    return _24537;
    ;
}


object _54NewEntry(object _name_47305, object _varnum_47306, object _scope_47307, object _token_47308, object _hashval_47309, object _samehash_47311, object _type_sym_47313)
{
    object _new_47315 = NOVALUE;
    object _24539 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_47307)) {
        _1 = (object)(DBL_PTR(_scope_47307)->dbl);
        DeRefDS(_scope_47307);
        _scope_47307 = _1;
    }
    if (!IS_ATOM_INT(_token_47308)) {
        _1 = (object)(DBL_PTR(_token_47308)->dbl);
        DeRefDS(_token_47308);
        _token_47308 = _1;
    }
    if (!IS_ATOM_INT(_samehash_47311)) {
        _1 = (object)(DBL_PTR(_samehash_47311)->dbl);
        DeRefDS(_samehash_47311);
        _samehash_47311 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_47305);
    _new_47315 = _54NewBasicEntry(_name_47305, _varnum_47306, _scope_47307, _token_47308, _hashval_47309, _samehash_47311, _type_sym_47313);
    if (!IS_ATOM_INT(_new_47315)) {
        _1 = (object)(DBL_PTR(_new_47315)->dbl);
        DeRefDS(_new_47315);
        _new_47315 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_54last_sym_47145 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_47145 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_47315;
    DeRef(_1);
    _24539 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _54last_sym_47145 = _new_47315;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_47313 >= 0)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _44register_forward_type(_54last_sym_47145, _type_sym_47313);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_47305);
    return _54last_sym_47145;
    ;
}


object _54tmp_alloc()
{
    object _new_entry_47330 = NOVALUE;
    object _24553 = NOVALUE;
    object _24551 = NOVALUE;
    object _24548 = NOVALUE;
    object _24545 = NOVALUE;
    object _24544 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_47330);
    _new_entry_47330 = Repeat(0, _36SIZEOF_TEMP_ENTRY_21539);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    *(intptr_t *)_2 = 4;

    /** symtab.e:194		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = 16;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    *(intptr_t *)_2 = -1073741824;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    *(intptr_t *)_2 = 1073741823;

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = _36NOVALUE_21621;

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_36temp_name_type_21853)){
            _24544 = SEQ_PTR(_36temp_name_type_21853)->length;
    }
    else {
        _24544 = 1;
    }
    _24545 = _24544 + 1;
    _24544 = NOVALUE;
    if (_24545 != 8087)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _24548 = MAKE_SEQ(_1);
    RefDS(_24548);
    Append(&_36temp_name_type_21853, _36temp_name_type_21853, _24548);
    DeRefDS(_24548);
    _24548 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_55TYPES_OBNL_46970);
    Append(&_36temp_name_type_21853, _36temp_name_type_21853, _55TYPES_OBNL_46970);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_36temp_name_type_21853)){
            _24551 = SEQ_PTR(_36temp_name_type_21853)->length;
    }
    else {
        _24551 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_47330);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47330 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24551;
    if( _1 != _24551 ){
        DeRef(_1);
    }
    _24551 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_47330);
    Append(&_37SymTab_15637, _37SymTab_15637, _new_entry_47330);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _24553 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _24553 = 1;
    }
    DeRefDS(_new_entry_47330);
    DeRef(_24545);
    _24545 = NOVALUE;
    return _24553;
    ;
}


void _54DefinedYet(object _sym_47399)
{
    object _24573 = NOVALUE;
    object _24572 = NOVALUE;
    object _24571 = NOVALUE;
    object _24569 = NOVALUE;
    object _24568 = NOVALUE;
    object _24566 = NOVALUE;
    object _24565 = NOVALUE;
    object _24564 = NOVALUE;
    object _24563 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24563 = (object)*(((s1_ptr)_2)->base + _sym_47399);
    _2 = (object)SEQ_PTR(_24563);
    _24564 = (object)*(((s1_ptr)_2)->base + 4);
    _24563 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9;
    ((intptr_t*)_2)[2] = 10;
    ((intptr_t*)_2)[3] = 7;
    _24565 = MAKE_SEQ(_1);
    _24566 = find_from(_24564, _24565, 1);
    _24564 = NOVALUE;
    DeRefDS(_24565);
    _24565 = NOVALUE;
    if (_24566 != 0)
    goto L1; // [34] 84
    _24566 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24568 = (object)*(((s1_ptr)_2)->base + _sym_47399);
    _2 = (object)SEQ_PTR(_24568);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _24569 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _24569 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _24568 = NOVALUE;
    if (binary_op_a(NOTEQ, _24569, _36current_file_no_21767)){
        _24569 = NOVALUE;
        goto L2; // [53] 83
    }
    _24569 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24571 = (object)*(((s1_ptr)_2)->base + _sym_47399);
    _2 = (object)SEQ_PTR(_24571);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _24572 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _24572 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _24571 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24572);
    ((intptr_t*)_2)[1] = _24572;
    _24573 = MAKE_SEQ(_1);
    _24572 = NOVALUE;
    _50CompileErr(31, _24573, 0);
    _24573 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _54name_ext(object _s_47427)
{
    object _24580 = NOVALUE;
    object _24579 = NOVALUE;
    object _24578 = NOVALUE;
    object _24577 = NOVALUE;
    object _24575 = NOVALUE;
    object _24574 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47427)){
            _24574 = SEQ_PTR(_s_47427)->length;
    }
    else {
        _24574 = 1;
    }
    {
        object _i_47429;
        _i_47429 = _24574;
L1: 
        if (_i_47429 < 1){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47427);
        _24575 = (object)*(((s1_ptr)_2)->base + _i_47429);
        _24577 = find_from(_24575, _24576, 1);
        _24575 = NOVALUE;
        if (_24577 == 0)
        {
            _24577 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24577 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24578 = _i_47429 + 1;
        if (IS_SEQUENCE(_s_47427)){
                _24579 = SEQ_PTR(_s_47427)->length;
        }
        else {
            _24579 = 1;
        }
        rhs_slice_target = (object_ptr)&_24580;
        RHS_Slice(_s_47427, _24578, _24579);
        DeRefDS(_s_47427);
        _24578 = NOVALUE;
        return _24580;
L3: 

        /** symtab.e:245		end for*/
        _i_47429 = _i_47429 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24578);
    _24578 = NOVALUE;
    DeRef(_24580);
    _24580 = NOVALUE;
    return _s_47427;
    ;
}


object _54NewStringSym(object _s_47446)
{
    object _p_47448 = NOVALUE;
    object _tp_47449 = NOVALUE;
    object _prev_47450 = NOVALUE;
    object _search_count_47451 = NOVALUE;
    object _24624 = NOVALUE;
    object _24622 = NOVALUE;
    object _24621 = NOVALUE;
    object _24620 = NOVALUE;
    object _24618 = NOVALUE;
    object _24617 = NOVALUE;
    object _24614 = NOVALUE;
    object _24612 = NOVALUE;
    object _24610 = NOVALUE;
    object _24609 = NOVALUE;
    object _24608 = NOVALUE;
    object _24606 = NOVALUE;
    object _24604 = NOVALUE;
    object _24602 = NOVALUE;
    object _24600 = NOVALUE;
    object _24597 = NOVALUE;
    object _24595 = NOVALUE;
    object _24594 = NOVALUE;
    object _24593 = NOVALUE;
    object _24591 = NOVALUE;
    object _24589 = NOVALUE;
    object _24588 = NOVALUE;
    object _24587 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47449 = _54literal_init_47144;

    /** symtab.e:259		prev = 0*/
    _prev_47450 = 0;

    /** symtab.e:260		search_count = 0*/
    _search_count_47451 = 0;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47449 == 0)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47451 = _search_count_47451 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47451, _54SEARCH_LIMIT_47438)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24587 = (object)*(((s1_ptr)_2)->base + _tp_47449);
    _2 = (object)SEQ_PTR(_24587);
    _24588 = (object)*(((s1_ptr)_2)->base + 1);
    _24587 = NOVALUE;
    if (_s_47446 == _24588)
    _24589 = 1;
    else if (IS_ATOM_INT(_s_47446) && IS_ATOM_INT(_24588))
    _24589 = 0;
    else
    _24589 = (compare(_s_47446, _24588) == 0);
    _24588 = NOVALUE;
    if (_24589 == 0)
    {
        _24589 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24589 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47449 == _54literal_init_47144)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47450 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24593 = (object)*(((s1_ptr)_2)->base + _tp_47449);
    _2 = (object)SEQ_PTR(_24593);
    _24594 = (object)*(((s1_ptr)_2)->base + 2);
    _24593 = NOVALUE;
    Ref(_24594);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24594;
    if( _1 != _24594 ){
        DeRef(_1);
    }
    _24594 = NOVALUE;
    _24591 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47449 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47144;
    DeRef(_1);
    _24595 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _54literal_init_47144 = _tp_47449;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47446);
    return _tp_47449;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47450 = _tp_47449;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24597 = (object)*(((s1_ptr)_2)->base + _tp_47449);
    _2 = (object)SEQ_PTR(_24597);
    _tp_47449 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47449)){
        _tp_47449 = (object)DBL_PTR(_tp_47449)->dbl;
    }
    _24597 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47448 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47448)) {
        _1 = (object)(DBL_PTR(_p_47448)->dbl);
        DeRefDS(_p_47448);
        _p_47448 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    RefDS(_s_47446);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47446;
    DeRef(_1);
    _24600 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24602 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _24604 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47446)){
            _24608 = SEQ_PTR(_s_47446)->length;
    }
    else {
        _24608 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24608;
    if( _1 != _24608 ){
        DeRef(_1);
    }
    _24608 = NOVALUE;
    _24606 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24609 = (object)*(((s1_ptr)_2)->base + _p_47448);
    _2 = (object)SEQ_PTR(_24609);
    _24610 = (object)*(((s1_ptr)_2)->base + 32);
    _24609 = NOVALUE;
    if (binary_op_a(LESSEQ, _24610, 0)){
        _24610 = NOVALUE;
        goto L7; // [265] 289
    }
    _24610 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24612 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _24614 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24617 = (object)*(((s1_ptr)_2)->base + _p_47448);
    _2 = (object)SEQ_PTR(_24617);
    _24618 = (object)*(((s1_ptr)_2)->base + 34);
    _24617 = NOVALUE;
    RefDS(_24616);
    Ref(_24618);
    _55c_printf(_24616, _24618);
    _24618 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24620 = (object)*(((s1_ptr)_2)->base + _p_47448);
    _2 = (object)SEQ_PTR(_24620);
    _24621 = (object)*(((s1_ptr)_2)->base + 34);
    _24620 = NOVALUE;
    RefDS(_24619);
    Ref(_24621);
    _55c_hprintf(_24619, _24621);
    _24621 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24622 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47144;
    DeRef(_1);
    _24624 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _54literal_init_47144 = _p_47448;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47446);
    return _p_47448;
    ;
}


object _54NewIntSym(object _int_val_47544)
{
    object _p_47546 = NOVALUE;
    object _x_47547 = NOVALUE;
    object _24648 = NOVALUE;
    object _24646 = NOVALUE;
    object _24642 = NOVALUE;
    object _24640 = NOVALUE;
    object _24638 = NOVALUE;
    object _24636 = NOVALUE;
    object _24634 = NOVALUE;
    object _24632 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47547 = find_from(_int_val_47544, _54lastintval_47146, 1);

    /** symtab.e:311		if x then*/
    if (_x_47547 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_54lastintsym_47147);
    _24632 = (object)*(((s1_ptr)_2)->base + _x_47547);
    DeRef(_int_val_47544);
    return _24632;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47546 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47546)) {
        _1 = (object)(DBL_PTR(_p_47546)->dbl);
        DeRefDS(_p_47546);
        _p_47546 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47546 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24634 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47546 + ((s1_ptr)_2)->base);
    Ref(_int_val_47544);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47544;
    DeRef(_1);
    _24636 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47546 + ((s1_ptr)_2)->base);
    Ref(_int_val_47544);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47544;
    DeRef(_1);
    _24638 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47546 + ((s1_ptr)_2)->base);
    Ref(_int_val_47544);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47544;
    DeRef(_1);
    _24640 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47546 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24642 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47544);
    Prepend(&_54lastintval_47146, _54lastintval_47146, _int_val_47544);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_54lastintsym_47147, _54lastintsym_47147, _p_47546);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_54lastintval_47146)){
            _24646 = SEQ_PTR(_54lastintval_47146)->length;
    }
    else {
        _24646 = 1;
    }
    if (binary_op_a(LESSEQ, _24646, _54SEARCH_LIMIT_47438)){
        _24646 = NOVALUE;
        goto L5; // [198] 218
    }
    _24646 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_54SEARCH_LIMIT_47438)) {
        _24648 = _54SEARCH_LIMIT_47438 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _54SEARCH_LIMIT_47438, 2);
        _24648 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_54lastintval_47146;
    RHS_Slice(_54lastintval_47146, 1, _24648);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47544);
    _24632 = NOVALUE;
    DeRef(_24648);
    _24648 = NOVALUE;
    return _p_47546;
L2: 
    ;
}


object _54NewDoubleSym(object _d_47596)
{
    object _p_47598 = NOVALUE;
    object _tp_47599 = NOVALUE;
    object _prev_47600 = NOVALUE;
    object _search_count_47601 = NOVALUE;
    object _24678 = NOVALUE;
    object _24677 = NOVALUE;
    object _24676 = NOVALUE;
    object _24675 = NOVALUE;
    object _24674 = NOVALUE;
    object _24672 = NOVALUE;
    object _24670 = NOVALUE;
    object _24668 = NOVALUE;
    object _24666 = NOVALUE;
    object _24663 = NOVALUE;
    object _24661 = NOVALUE;
    object _24660 = NOVALUE;
    object _24659 = NOVALUE;
    object _24657 = NOVALUE;
    object _24655 = NOVALUE;
    object _24654 = NOVALUE;
    object _24653 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47599 = _54literal_init_47144;

    /** symtab.e:347		prev = 0*/
    _prev_47600 = 0;

    /** symtab.e:348		search_count = 0*/
    _search_count_47601 = 0;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47599 == 0)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47601 = _search_count_47601 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47601, _54SEARCH_LIMIT_47438)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24653 = (object)*(((s1_ptr)_2)->base + _tp_47599);
    _2 = (object)SEQ_PTR(_24653);
    _24654 = (object)*(((s1_ptr)_2)->base + 1);
    _24653 = NOVALUE;
    if (_d_47596 == _24654)
    _24655 = 1;
    else if (IS_ATOM_INT(_d_47596) && IS_ATOM_INT(_24654))
    _24655 = 0;
    else
    _24655 = (compare(_d_47596, _24654) == 0);
    _24654 = NOVALUE;
    if (_24655 == 0)
    {
        _24655 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24655 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47599 == _54literal_init_47144)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47600 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24659 = (object)*(((s1_ptr)_2)->base + _tp_47599);
    _2 = (object)SEQ_PTR(_24659);
    _24660 = (object)*(((s1_ptr)_2)->base + 2);
    _24659 = NOVALUE;
    Ref(_24660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24660;
    if( _1 != _24660 ){
        DeRef(_1);
    }
    _24660 = NOVALUE;
    _24657 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47599 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47144;
    DeRef(_1);
    _24661 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _54literal_init_47144 = _tp_47599;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47596);
    return _tp_47599;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47600 = _tp_47599;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24663 = (object)*(((s1_ptr)_2)->base + _tp_47599);
    _2 = (object)SEQ_PTR(_24663);
    _tp_47599 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47599)){
        _tp_47599 = (object)DBL_PTR(_tp_47599)->dbl;
    }
    _24663 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47598 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47598)) {
        _1 = (object)(DBL_PTR(_p_47598)->dbl);
        DeRefDS(_p_47598);
        _p_47598 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47598 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24666 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47598 + ((s1_ptr)_2)->base);
    Ref(_d_47596);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47596;
    DeRef(_1);
    _24668 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47598 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24670 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47598 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24672 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24674 = (object)*(((s1_ptr)_2)->base + _p_47598);
    _2 = (object)SEQ_PTR(_24674);
    _24675 = (object)*(((s1_ptr)_2)->base + 34);
    _24674 = NOVALUE;
    RefDS(_24616);
    Ref(_24675);
    _55c_printf(_24616, _24675);
    _24675 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24676 = (object)*(((s1_ptr)_2)->base + _p_47598);
    _2 = (object)SEQ_PTR(_24676);
    _24677 = (object)*(((s1_ptr)_2)->base + 34);
    _24676 = NOVALUE;
    RefDS(_24619);
    Ref(_24677);
    _55c_hprintf(_24619, _24677);
    _24677 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47598 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47144;
    DeRef(_1);
    _24678 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _54literal_init_47144 = _p_47598;

    /** symtab.e:381		return p*/
    DeRef(_d_47596);
    return _p_47598;
    ;
}


object _54NewTempSym(object _inlining_47670)
{
    object _p_47672 = NOVALUE;
    object _q_47673 = NOVALUE;
    object _24727 = NOVALUE;
    object _24725 = NOVALUE;
    object _24723 = NOVALUE;
    object _24721 = NOVALUE;
    object _24719 = NOVALUE;
    object _24717 = NOVALUE;
    object _24716 = NOVALUE;
    object _24715 = NOVALUE;
    object _24713 = NOVALUE;
    object _24712 = NOVALUE;
    object _24711 = NOVALUE;
    object _24709 = NOVALUE;
    object _24707 = NOVALUE;
    object _24704 = NOVALUE;
    object _24703 = NOVALUE;
    object _24702 = NOVALUE;
    object _24700 = NOVALUE;
    object _24698 = NOVALUE;
    object _24697 = NOVALUE;
    object _24696 = NOVALUE;
    object _24694 = NOVALUE;
    object _24692 = NOVALUE;
    object _24687 = NOVALUE;
    object _24686 = NOVALUE;
    object _24685 = NOVALUE;
    object _24684 = NOVALUE;
    object _24683 = NOVALUE;
    object _24682 = NOVALUE;
    object _24680 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47670 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24680 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_24680);
    if (!IS_ATOM_INT(_36S_TEMPS_21449)){
        _p_47672 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    }
    else{
        _p_47672 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    }
    if (!IS_ATOM_INT(_p_47672)){
        _p_47672 = (object)DBL_PTR(_p_47672)->dbl;
    }
    _24680 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24682 = (_p_47672 != 0);
    if (_24682 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24684 = (object)*(((s1_ptr)_2)->base + _p_47672);
    _2 = (object)SEQ_PTR(_24684);
    _24685 = (object)*(((s1_ptr)_2)->base + 4);
    _24684 = NOVALUE;
    if (IS_ATOM_INT(_24685)) {
        _24686 = (_24685 != 0);
    }
    else {
        _24686 = binary_op(NOTEQ, _24685, 0);
    }
    _24685 = NOVALUE;
    if (_24686 <= 0) {
        if (_24686 == 0) {
            DeRef(_24686);
            _24686 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24686) && DBL_PTR(_24686)->dbl == 0.0){
                DeRef(_24686);
                _24686 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24686);
            _24686 = NOVALUE;
        }
    }
    DeRef(_24686);
    _24686 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24687 = (object)*(((s1_ptr)_2)->base + _p_47672);
    _2 = (object)SEQ_PTR(_24687);
    _p_47672 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47672)){
        _p_47672 = (object)DBL_PTR(_p_47672)->dbl;
    }
    _24687 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47672 = 0;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47672 != 0)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _54temps_allocated_47667 = _54temps_allocated_47667 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47672 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47672)) {
        _1 = (object)(DBL_PTR(_p_47672)->dbl);
        DeRefDS(_p_47672);
        _p_47672 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24692 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24696 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_24696);
    if (!IS_ATOM_INT(_36S_TEMPS_21449)){
        _24697 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    }
    else{
        _24697 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    }
    _24696 = NOVALUE;
    Ref(_24697);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24697;
    if( _1 != _24697 ){
        DeRef(_1);
    }
    _24697 = NOVALUE;
    _24694 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21449))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47672;
    DeRef(_1);
    _24698 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47670 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464)){
        _24702 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    }
    else{
        _24702 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    }
    _24700 = NOVALUE;
    if (IS_ATOM_INT(_24702)) {
        _24703 = _24702 + 1;
        if (_24703 > MAXINT){
            _24703 = NewDouble((eudouble)_24703);
        }
    }
    else
    _24703 = binary_op(PLUS, 1, _24702);
    _24702 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21464))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21464)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21464);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24703;
    if( _1 != _24703 ){
        DeRef(_1);
    }
    _24703 = NOVALUE;
    _24700 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24704 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47673 = _54tmp_alloc();
    if (!IS_ATOM_INT(_q_47673)) {
        _1 = (object)(DBL_PTR(_q_47673)->dbl);
        DeRefDS(_q_47673);
        _q_47673 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47673 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24707 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47673 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24711 = (object)*(((s1_ptr)_2)->base + _p_47672);
    _2 = (object)SEQ_PTR(_24711);
    _24712 = (object)*(((s1_ptr)_2)->base + 34);
    _24711 = NOVALUE;
    Ref(_24712);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24712;
    if( _1 != _24712 ){
        DeRef(_1);
    }
    _24712 = NOVALUE;
    _24709 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47673 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24715 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_24715);
    if (!IS_ATOM_INT(_36S_TEMPS_21449)){
        _24716 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    }
    else{
        _24716 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    }
    _24715 = NOVALUE;
    Ref(_24716);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24716;
    if( _1 != _24716 ){
        DeRef(_1);
    }
    _24716 = NOVALUE;
    _24713 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21449))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21449)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21449);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47673;
    DeRef(_1);
    _24717 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47672 = _q_47673;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24719 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24721 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21621);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21621;
    DeRef(_1);
    _24723 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _24725 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47672 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24727 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24682);
    _24682 = NOVALUE;
    return _p_47672;
    ;
}


void _54InitSymTab()
{
    object _hashval_47789 = NOVALUE;
    object _len_47790 = NOVALUE;
    object _s_47792 = NOVALUE;
    object _st_index_47793 = NOVALUE;
    object _kname_47794 = NOVALUE;
    object _fixups_47795 = NOVALUE;
    object _si_47934 = NOVALUE;
    object _sj_47935 = NOVALUE;
    object _25313 = NOVALUE;
    object _25312 = NOVALUE;
    object _24842 = NOVALUE;
    object _24841 = NOVALUE;
    object _24840 = NOVALUE;
    object _24839 = NOVALUE;
    object _24838 = NOVALUE;
    object _24836 = NOVALUE;
    object _24835 = NOVALUE;
    object _24834 = NOVALUE;
    object _24833 = NOVALUE;
    object _24831 = NOVALUE;
    object _24829 = NOVALUE;
    object _24827 = NOVALUE;
    object _24826 = NOVALUE;
    object _24824 = NOVALUE;
    object _24822 = NOVALUE;
    object _24820 = NOVALUE;
    object _24819 = NOVALUE;
    object _24817 = NOVALUE;
    object _24816 = NOVALUE;
    object _24815 = NOVALUE;
    object _24814 = NOVALUE;
    object _24813 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24808 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24802 = NOVALUE;
    object _24801 = NOVALUE;
    object _24800 = NOVALUE;
    object _24797 = NOVALUE;
    object _24795 = NOVALUE;
    object _24793 = NOVALUE;
    object _24792 = NOVALUE;
    object _24789 = NOVALUE;
    object _24788 = NOVALUE;
    object _24786 = NOVALUE;
    object _24784 = NOVALUE;
    object _24782 = NOVALUE;
    object _24780 = NOVALUE;
    object _24779 = NOVALUE;
    object _24778 = NOVALUE;
    object _24775 = NOVALUE;
    object _24774 = NOVALUE;
    object _24772 = NOVALUE;
    object _24771 = NOVALUE;
    object _24769 = NOVALUE;
    object _24768 = NOVALUE;
    object _24767 = NOVALUE;
    object _24765 = NOVALUE;
    object _24763 = NOVALUE;
    object _24762 = NOVALUE;
    object _24760 = NOVALUE;
    object _24759 = NOVALUE;
    object _24758 = NOVALUE;
    object _24756 = NOVALUE;
    object _24755 = NOVALUE;
    object _24754 = NOVALUE;
    object _24752 = NOVALUE;
    object _24751 = NOVALUE;
    object _24750 = NOVALUE;
    object _24748 = NOVALUE;
    object _24747 = NOVALUE;
    object _24746 = NOVALUE;
    object _24745 = NOVALUE;
    object _24744 = NOVALUE;
    object _24743 = NOVALUE;
    object _24742 = NOVALUE;
    object _24741 = NOVALUE;
    object _24740 = NOVALUE;
    object _24739 = NOVALUE;
    object _24737 = NOVALUE;
    object _24736 = NOVALUE;
    object _24735 = NOVALUE;
    object _24734 = NOVALUE;
    object _24730 = NOVALUE;
    object _24729 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_22190);
    DeRefi(_fixups_47795);
    _fixups_47795 = _22190;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23441)){
            _24729 = SEQ_PTR(_63keylist_23441)->length;
    }
    else {
        _24729 = 1;
    }
    {
        object _k_47797;
        _k_47797 = 1;
L1: 
        if (_k_47797 > _24729){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24730 = (object)*(((s1_ptr)_2)->base + _k_47797);
        DeRef(_kname_47794);
        _2 = (object)SEQ_PTR(_24730);
        _kname_47794 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_47794);
        _24730 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47794)){
                _len_47790 = SEQ_PTR(_kname_47794)->length;
        }
        else {
            _len_47790 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47794);
        _hashval_47789 = _54hashfn(_kname_47794);
        if (!IS_ATOM_INT(_hashval_47789)) {
            _1 = (object)(DBL_PTR(_hashval_47789)->dbl);
            DeRefDS(_hashval_47789);
            _hashval_47789 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24734 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24734);
        _24735 = (object)*(((s1_ptr)_2)->base + 2);
        _24734 = NOVALUE;
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24736 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24736);
        _24737 = (object)*(((s1_ptr)_2)->base + 3);
        _24736 = NOVALUE;
        RefDS(_kname_47794);
        Ref(_24735);
        Ref(_24737);
        _st_index_47793 = _54NewEntry(_kname_47794, 0, _24735, _24737, _hashval_47789, 0, 0);
        _24735 = NOVALUE;
        _24737 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47793)) {
            _1 = (object)(DBL_PTR(_st_index_47793)->dbl);
            DeRefDS(_st_index_47793);
            _st_index_47793 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24739 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24739);
        _24740 = (object)*(((s1_ptr)_2)->base + 3);
        _24739 = NOVALUE;
        _24741 = find_from(_24740, _38RTN_TOKS_16291, 1);
        _24740 = NOVALUE;
        if (_24741 == 0)
        {
            _24741 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24741 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24742 = (object)*(((s1_ptr)_2)->base + _st_index_47793);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24743 = (object)*(((s1_ptr)_2)->base + _st_index_47793);
        if (IS_SEQUENCE(_24743)){
                _24744 = SEQ_PTR(_24743)->length;
        }
        else {
            _24744 = 1;
        }
        _24743 = NOVALUE;
        _24745 = _36SIZEOF_ROUTINE_ENTRY_21530 - _24744;
        _24744 = NOVALUE;
        _24746 = Repeat(0, _24745);
        _24745 = NOVALUE;
        if (IS_SEQUENCE(_24742) && IS_ATOM(_24746)) {
        }
        else if (IS_ATOM(_24742) && IS_SEQUENCE(_24746)) {
            Ref(_24742);
            Prepend(&_24747, _24746, _24742);
        }
        else {
            Concat((object_ptr)&_24747, _24742, _24746);
            _24742 = NOVALUE;
        }
        _24742 = NOVALUE;
        DeRefDS(_24746);
        _24746 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47793);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24747;
        if( _1 != _24747 ){
            DeRef(_1);
        }
        _24747 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24750 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24750);
        _24751 = (object)*(((s1_ptr)_2)->base + 5);
        _24750 = NOVALUE;
        Ref(_24751);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21455))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24751;
        if( _1 != _24751 ){
            DeRef(_1);
        }
        _24751 = NOVALUE;
        _24748 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24754 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24754);
        _24755 = (object)*(((s1_ptr)_2)->base + 4);
        _24754 = NOVALUE;
        Ref(_24755);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24755;
        if( _1 != _24755 ){
            DeRef(_1);
        }
        _24755 = NOVALUE;
        _24752 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24758 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24758);
        _24759 = (object)*(((s1_ptr)_2)->base + 6);
        _24758 = NOVALUE;
        Ref(_24759);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24759;
        if( _1 != _24759 ){
            DeRef(_1);
        }
        _24759 = NOVALUE;
        _24756 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
        RefDS(_22190);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22190;
        DeRef(_1);
        _24760 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24762 = (object)*(((s1_ptr)_2)->base + _k_47797);
        if (IS_SEQUENCE(_24762)){
                _24763 = SEQ_PTR(_24762)->length;
        }
        else {
            _24763 = 1;
        }
        _24762 = NOVALUE;
        if (_24763 <= 6)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24767 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24767);
        _24768 = (object)*(((s1_ptr)_2)->base + 7);
        _24767 = NOVALUE;
        Ref(_24768);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21416))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24768;
        if( _1 != _24768 ){
            DeRef(_1);
        }
        _24768 = NOVALUE;
        _24765 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24771 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24771);
        _24772 = (object)*(((s1_ptr)_2)->base + 8);
        _24771 = NOVALUE;
        Ref(_24772);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24772;
        if( _1 != _24772 ){
            DeRef(_1);
        }
        _24772 = NOVALUE;
        _24769 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47795, _fixups_47795, _st_index_47793);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24774 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24774);
        _24775 = (object)*(((s1_ptr)_2)->base + 3);
        _24774 = NOVALUE;
        if (binary_op_a(NOTEQ, _24775, 27)){
            _24775 = NOVALUE;
            goto L5; // [341] 365
        }
        _24775 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47794 == _24777)
        _24778 = 1;
        else if (IS_ATOM_INT(_kname_47794) && IS_ATOM_INT(_24777))
        _24778 = 0;
        else
        _24778 = (compare(_kname_47794, _24777) == 0);
        if (_24778 == 0)
        {
            _24778 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24778 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _36TopLevelSub_21774 = _st_index_47793;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_63keylist_23441);
        _24779 = (object)*(((s1_ptr)_2)->base + _k_47797);
        _2 = (object)SEQ_PTR(_24779);
        _24780 = (object)*(((s1_ptr)_2)->base + 3);
        _24779 = NOVALUE;
        if (binary_op_a(NOTEQ, _24780, 504)){
            _24780 = NOVALUE;
            goto L7; // [381] 461
        }
        _24780 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47794 == _23147)
        _24782 = 1;
        else if (IS_ATOM_INT(_kname_47794) && IS_ATOM_INT(_23147))
        _24782 = 0;
        else
        _24782 = (compare(_kname_47794, _23147) == 0);
        if (_24782 == 0)
        {
            _24782 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24782 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _54object_type_47136 = _st_index_47793;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47794 == _24783)
        _24784 = 1;
        else if (IS_ATOM_INT(_kname_47794) && IS_ATOM_INT(_24783))
        _24784 = 0;
        else
        _24784 = (compare(_kname_47794, _24783) == 0);
        if (_24784 == 0)
        {
            _24784 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24784 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _54atom_type_47138 = _st_index_47793;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47794 == _24785)
        _24786 = 1;
        else if (IS_ATOM_INT(_kname_47794) && IS_ATOM_INT(_24785))
        _24786 = 0;
        else
        _24786 = (compare(_kname_47794, _24785) == 0);
        if (_24786 == 0)
        {
            _24786 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24786 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _54integer_type_47142 = _st_index_47793;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47794 == _24787)
        _24788 = 1;
        else if (IS_ATOM_INT(_kname_47794) && IS_ATOM_INT(_24787))
        _24788 = 0;
        else
        _24788 = (compare(_kname_47794, _24787) == 0);
        if (_24788 == 0)
        {
            _24788 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24788 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _54sequence_type_47140 = _st_index_47793;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _24789 = (object)*(((s1_ptr)_2)->base + _hashval_47789);
        if (binary_op_a(NOTEQ, _24789, 0)){
            _24789 = NOVALUE;
            goto LD; // [470] 485
        }
        _24789 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47789);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47793;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_47132);
        _s_47792 = (object)*(((s1_ptr)_2)->base + _hashval_47789);
        if (!IS_ATOM_INT(_s_47792)){
            _s_47792 = (object)DBL_PTR(_s_47792)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24792 = (object)*(((s1_ptr)_2)->base + _s_47792);
        _2 = (object)SEQ_PTR(_24792);
        _24793 = (object)*(((s1_ptr)_2)->base + 9);
        _24792 = NOVALUE;
        if (binary_op_a(EQUALS, _24793, 0)){
            _24793 = NOVALUE;
            goto L10; // [512] 537
        }
        _24793 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24795 = (object)*(((s1_ptr)_2)->base + _s_47792);
        _2 = (object)SEQ_PTR(_24795);
        _s_47792 = (object)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_47792)){
            _s_47792 = (object)DBL_PTR(_s_47792)->dbl;
        }
        _24795 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47792 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47793;
        DeRef(_1);
        _24797 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47797 = _k_47797 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _36file_start_sym_21773 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _36file_start_sym_21773 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _36CurrentSub_21775 = _36TopLevelSub_21774;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47795)){
            _24800 = SEQ_PTR(_fixups_47795)->length;
    }
    else {
        _24800 = 1;
    }
    {
        object _i_47939;
        _i_47939 = 1;
L11: 
        if (_i_47939 > _24800){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47795);
        _24801 = (object)*(((s1_ptr)_2)->base + _i_47939);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24802 = (object)*(((s1_ptr)_2)->base + _24801);
        DeRef(_si_47934);
        _2 = (object)SEQ_PTR(_24802);
        if (!IS_ATOM_INT(_36S_CODE_21416)){
            _si_47934 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        }
        else{
            _si_47934 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21416);
        }
        Ref(_si_47934);
        _24802 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47934)){
                _24804 = SEQ_PTR(_si_47934)->length;
        }
        else {
            _24804 = 1;
        }
        {
            object _j_47947;
            _j_47947 = 1;
L13: 
            if (_j_47947 > _24804){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47934);
            _24805 = (object)*(((s1_ptr)_2)->base + _j_47947);
            _24806 = IS_SEQUENCE(_24805);
            _24805 = NOVALUE;
            if (_24806 == 0)
            {
                _24806 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24806 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47935);
            _2 = (object)SEQ_PTR(_si_47934);
            _sj_47935 = (object)*(((s1_ptr)_2)->base + _j_47947);
            Ref(_sj_47935);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47935)){
                    _24808 = SEQ_PTR(_sj_47935)->length;
            }
            else {
                _24808 = 1;
            }
            {
                object _ij_47954;
                _ij_47954 = 1;
L16: 
                if (_ij_47954 > _24808){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47935);
                _24809 = (object)*(((s1_ptr)_2)->base + _ij_47954);
                _2 = (object)SEQ_PTR(_24809);
                _24810 = (object)*(((s1_ptr)_2)->base + 1);
                _24809 = NOVALUE;
                if (IS_SEQUENCE(_24810) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24810)){
                    if( (DBL_PTR(_24810)->dbl != (eudouble) ((object) DBL_PTR(_24810)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24810)->dbl;
                }
                else {
                    _0 = _24810;
                };
                _24810 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    _24813 = (object)*(((s1_ptr)_2)->base + _ij_47954);
                    _2 = (object)SEQ_PTR(_24813);
                    _24814 = (object)*(((s1_ptr)_2)->base + 2);
                    _24813 = NOVALUE;
                    Ref(_24814);
                    _24815 = _36is_integer(_24814);
                    _24814 = NOVALUE;
                    if (_24815 == 0) {
                        DeRef(_24815);
                        _24815 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24815) && DBL_PTR(_24815)->dbl == 0.0){
                            DeRef(_24815);
                            _24815 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24815);
                        _24815 = NOVALUE;
                    }
                    DeRef(_24815);
                    _24815 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    _24816 = (object)*(((s1_ptr)_2)->base + _ij_47954);
                    _2 = (object)SEQ_PTR(_24816);
                    _24817 = (object)*(((s1_ptr)_2)->base + 2);
                    _24816 = NOVALUE;
                    Ref(_24817);
                    _st_index_47793 = _54NewIntSym(_24817);
                    _24817 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47793)) {
                        _1 = (object)(DBL_PTR(_st_index_47793)->dbl);
                        DeRefDS(_st_index_47793);
                        _st_index_47793 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    _24819 = (object)*(((s1_ptr)_2)->base + _ij_47954);
                    _2 = (object)SEQ_PTR(_24819);
                    _24820 = (object)*(((s1_ptr)_2)->base + 2);
                    _24819 = NOVALUE;
                    Ref(_24820);
                    _st_index_47793 = _54NewDoubleSym(_24820);
                    _24820 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47793)) {
                        _1 = (object)(DBL_PTR(_st_index_47793)->dbl);
                        DeRefDS(_st_index_47793);
                        _st_index_47793 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15637);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15637 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24822 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47935 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47954 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47793;
                    DeRef(_1);
                    _24824 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    _24826 = (object)*(((s1_ptr)_2)->base + _ij_47954);
                    _2 = (object)SEQ_PTR(_24826);
                    _24827 = (object)*(((s1_ptr)_2)->base + 2);
                    _24826 = NOVALUE;
                    Ref(_24827);
                    _st_index_47793 = _54NewStringSym(_24827);
                    _24827 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47793)) {
                        _1 = (object)(DBL_PTR(_st_index_47793)->dbl);
                        DeRefDS(_st_index_47793);
                        _st_index_47793 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15637);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15637 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47793 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24829 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47935 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47954 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47793;
                    DeRef(_1);
                    _24831 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    _24833 = (object)*(((s1_ptr)_2)->base + _ij_47954);
                    _2 = (object)SEQ_PTR(_24833);
                    _24834 = (object)*(((s1_ptr)_2)->base + 2);
                    _24833 = NOVALUE;
                    Ref(_24834);
                    DeRef(_25312);
                    _25312 = _24834;
                    _25313 = _54hashfn(_25312);
                    _25312 = NOVALUE;
                    Ref(_24834);
                    _24835 = _54keyfind(_24834, -1, _36current_file_no_21767, 0, _25313);
                    _24834 = NOVALUE;
                    _25313 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47935);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47935 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_47954);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24835;
                    if( _1 != _24835 ){
                        DeRef(_1);
                    }
                    _24835 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47935);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47935 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47954 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47795);
                    _24838 = (object)*(((s1_ptr)_2)->base + _i_47939);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24839 = (object)*(((s1_ptr)_2)->base + 2);
                    _24836 = NOVALUE;
                    if (IS_SEQUENCE(_24839) && IS_ATOM(_24838)) {
                        Append(&_24840, _24839, _24838);
                    }
                    else if (IS_ATOM(_24839) && IS_SEQUENCE(_24838)) {
                    }
                    else {
                        Concat((object_ptr)&_24840, _24839, _24838);
                        _24839 = NOVALUE;
                    }
                    _24839 = NOVALUE;
                    _24838 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24840;
                    if( _1 != _24840 ){
                        DeRef(_1);
                    }
                    _24840 = NOVALUE;
                    _24836 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_47954 = _ij_47954 + 1;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47935);
            _2 = (object)SEQ_PTR(_si_47934);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47934 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47947);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47935;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47947 = _j_47947 + 1;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47795);
        _24841 = (object)*(((s1_ptr)_2)->base + _i_47939);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24841 + ((s1_ptr)_2)->base);
        RefDS(_si_47934);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21416))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21416)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21416);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47934;
        DeRef(_1);
        _24842 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47939 = _i_47939 + 1;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47794);
    DeRefi(_fixups_47795);
    DeRef(_si_47934);
    DeRef(_sj_47935);
    _24743 = NOVALUE;
    _24762 = NOVALUE;
    _24841 = NOVALUE;
    _24801 = NOVALUE;
    return;
    ;
}


void _54add_ref(object _tok_48023)
{
    object _s_48025 = NOVALUE;
    object _24858 = NOVALUE;
    object _24857 = NOVALUE;
    object _24855 = NOVALUE;
    object _24854 = NOVALUE;
    object _24853 = NOVALUE;
    object _24851 = NOVALUE;
    object _24850 = NOVALUE;
    object _24849 = NOVALUE;
    object _24848 = NOVALUE;
    object _24847 = NOVALUE;
    object _24846 = NOVALUE;
    object _24845 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48023);
    _s_48025 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_48025)){
        _s_48025 = (object)DBL_PTR(_s_48025)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24845 = (_s_48025 != _36CurrentSub_21775);
    if (_24845 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24847 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_24847);
    _24848 = (object)*(((s1_ptr)_2)->base + 24);
    _24847 = NOVALUE;
    _24849 = find_from(_s_48025, _24848, 1);
    _24848 = NOVALUE;
    _24850 = (_24849 == 0);
    _24849 = NOVALUE;
    if (_24850 == 0)
    {
        DeRef(_24850);
        _24850 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24850);
        _24850 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48025 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24853 = (object)*(((s1_ptr)_2)->base + 12);
    _24851 = NOVALUE;
    if (IS_ATOM_INT(_24853)) {
        _24854 = _24853 + 1;
        if (_24854 > MAXINT){
            _24854 = NewDouble((eudouble)_24854);
        }
    }
    else
    _24854 = binary_op(PLUS, 1, _24853);
    _24853 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24854;
    if( _1 != _24854 ){
        DeRef(_1);
    }
    _24854 = NOVALUE;
    _24851 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21775 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24857 = (object)*(((s1_ptr)_2)->base + 24);
    _24855 = NOVALUE;
    if (IS_SEQUENCE(_24857) && IS_ATOM(_s_48025)) {
        Append(&_24858, _24857, _s_48025);
    }
    else if (IS_ATOM(_24857) && IS_SEQUENCE(_s_48025)) {
    }
    else {
        Concat((object_ptr)&_24858, _24857, _s_48025);
        _24857 = NOVALUE;
    }
    _24857 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24858;
    if( _1 != _24858 ){
        DeRef(_1);
    }
    _24858 = NOVALUE;
    _24855 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_48023);
    DeRef(_24845);
    _24845 = NOVALUE;
    return;
    ;
}


void _54mark_all(object _attribute_48055)
{
    object _p_48058 = NOVALUE;
    object _sym_file_48065 = NOVALUE;
    object _scope_48082 = NOVALUE;
    object _24890 = NOVALUE;
    object _24889 = NOVALUE;
    object _24888 = NOVALUE;
    object _24886 = NOVALUE;
    object _24884 = NOVALUE;
    object _24883 = NOVALUE;
    object _24882 = NOVALUE;
    object _24881 = NOVALUE;
    object _24880 = NOVALUE;
    object _24878 = NOVALUE;
    object _24877 = NOVALUE;
    object _24876 = NOVALUE;
    object _24875 = NOVALUE;
    object _24871 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24867 = NOVALUE;
    object _24866 = NOVALUE;
    object _24864 = NOVALUE;
    object _24862 = NOVALUE;
    object _24859 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_48052 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24859 = (object)*(((s1_ptr)_2)->base + _54just_mark_everything_from_48052);
    _2 = (object)SEQ_PTR(_24859);
    _p_48058 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_48058)){
        _p_48058 = (object)DBL_PTR(_p_48058)->dbl;
    }
    _24859 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_48058 == 0)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24862 = (object)*(((s1_ptr)_2)->base + _p_48058);
    _2 = (object)SEQ_PTR(_24862);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _sym_file_48065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _sym_file_48065 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_sym_file_48065)){
        _sym_file_48065 = (object)DBL_PTR(_sym_file_48065)->dbl;
    }
    _24862 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _54just_mark_everything_from_48052 = _p_48058;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24864 = (_sym_file_48065 == _36current_file_no_21767);
    if (_24864 != 0) {
        goto L4; // [68] 84
    }
    Ref(_54recheck_routines_48125);
    _24866 = _29has(_54recheck_routines_48125, _sym_file_48065);
    if (_24866 == 0) {
        DeRef(_24866);
        _24866 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24866) && DBL_PTR(_24866)->dbl == 0.0){
            DeRef(_24866);
            _24866 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24866);
        _24866 = NOVALUE;
    }
    DeRef(_24866);
    _24866 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_48058 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24869 = (object)*(((s1_ptr)_2)->base + _attribute_48055);
    _24867 = NOVALUE;
    if (IS_ATOM_INT(_24869)) {
        _24870 = _24869 + 1;
        if (_24870 > MAXINT){
            _24870 = NewDouble((eudouble)_24870);
        }
    }
    else
    _24870 = binary_op(PLUS, 1, _24869);
    _24869 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48055);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24870;
    if( _1 != _24870 ){
        DeRef(_1);
    }
    _24870 = NOVALUE;
    _24867 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24871 = (object)*(((s1_ptr)_2)->base + _p_48058);
    _2 = (object)SEQ_PTR(_24871);
    _scope_48082 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48082)){
        _scope_48082 = (object)DBL_PTR(_scope_48082)->dbl;
    }
    _24871 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_48082;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _24875 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
        _2 = (object)SEQ_PTR(_24875);
        _24876 = (object)*(((s1_ptr)_2)->base + _sym_file_48065);
        _24875 = NOVALUE;
        if (IS_ATOM_INT(_24876)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_24876;
                 _24877 = MAKE_UINT(tu);
            }
        }
        else {
            _24877 = binary_op(AND_BITS, 6, _24876);
        }
        _24876 = NOVALUE;
        if (_24877 == 0) {
            DeRef(_24877);
            _24877 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24877) && DBL_PTR(_24877)->dbl == 0.0){
                DeRef(_24877);
                _24877 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24877);
            _24877 = NOVALUE;
        }
        DeRef(_24877);
        _24877 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48058 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24880 = (object)*(((s1_ptr)_2)->base + _attribute_48055);
        _24878 = NOVALUE;
        if (IS_ATOM_INT(_24880)) {
            _24881 = _24880 + 1;
            if (_24881 > MAXINT){
                _24881 = NewDouble((eudouble)_24881);
            }
        }
        else
        _24881 = binary_op(PLUS, 1, _24880);
        _24880 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48055);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24881;
        if( _1 != _24881 ){
            DeRef(_1);
        }
        _24881 = NOVALUE;
        _24878 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _24882 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
        _2 = (object)SEQ_PTR(_24882);
        _24883 = (object)*(((s1_ptr)_2)->base + _sym_file_48065);
        _24882 = NOVALUE;
        if (IS_ATOM_INT(_24883)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_24883;
                 _24884 = MAKE_UINT(tu);
            }
        }
        else {
            _24884 = binary_op(AND_BITS, 2, _24883);
        }
        _24883 = NOVALUE;
        if (IS_ATOM_INT(_24884)) {
            if (_24884 != 0){
                DeRef(_24884);
                _24884 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24884)->dbl != 0.0){
                DeRef(_24884);
                _24884 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24884);
        _24884 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48058 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24888 = (object)*(((s1_ptr)_2)->base + _attribute_48055);
        _24886 = NOVALUE;
        if (IS_ATOM_INT(_24888)) {
            _24889 = _24888 + 1;
            if (_24889 > MAXINT){
                _24889 = NewDouble((eudouble)_24889);
            }
        }
        else
        _24889 = binary_op(PLUS, 1, _24888);
        _24888 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48055);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24889;
        if( _1 != _24889 ){
            DeRef(_1);
        }
        _24889 = NOVALUE;
        _24886 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24890 = (object)*(((s1_ptr)_2)->base + _p_48058);
    _2 = (object)SEQ_PTR(_24890);
    _p_48058 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_48058)){
        _p_48058 = (object)DBL_PTR(_p_48058)->dbl;
    }
    _24890 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24864);
    _24864 = NOVALUE;
    return;
    ;
}


void _54mark_rechecks(object _file_no_48131)
{
    object _recheck_targets_48134 = NOVALUE;
    object _remaining_48138 = NOVALUE;
    object _marked_48142 = NOVALUE;
    object _24897 = NOVALUE;
    object _24895 = NOVALUE;
    object _24894 = NOVALUE;
    object _24893 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_48131)) {
        _1 = (object)(DBL_PTR(_file_no_48131)->dbl);
        DeRefDS(_file_no_48131);
        _file_no_48131 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_54recheck_routines_48125);
    RefDS(_22190);
    _0 = _recheck_targets_48134;
    _recheck_targets_48134 = _29get(_54recheck_routines_48125, _file_no_48131, _22190);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_48134)){
            _24893 = SEQ_PTR(_recheck_targets_48134)->length;
    }
    else {
        _24893 = 1;
    }
    if (_24893 == 0)
    {
        _24893 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24893 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_22190);
    DeRefi(_remaining_48138);
    _remaining_48138 = _22190;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_48134)){
            _24894 = SEQ_PTR(_recheck_targets_48134)->length;
    }
    else {
        _24894 = 1;
    }
    {
        object _i_48140;
        _i_48140 = _24894;
L2: 
        if (_i_48140 < 1){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_48142 = 0;

        /** symtab.e:589				if TRANSLATE then*/
        if (_36TRANSLATE_21369 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48134);
        _24895 = (object)*(((s1_ptr)_2)->base + _i_48140);
        Ref(_24895);
        _marked_48142 = _54MarkTargets(_24895, 53);
        _24895 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48142)) {
            _1 = (object)(DBL_PTR(_marked_48142)->dbl);
            DeRefDS(_marked_48142);
            _marked_48142 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_36BIND_21372 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48134);
        _24897 = (object)*(((s1_ptr)_2)->base + _i_48140);
        Ref(_24897);
        _marked_48142 = _54MarkTargets(_24897, 12);
        _24897 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48142)) {
            _1 = (object)(DBL_PTR(_marked_48142)->dbl);
            DeRefDS(_marked_48142);
            _marked_48142 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_48142 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_48138, _remaining_48138, _file_no_48131);
L7: 

        /** symtab.e:597			end for*/
        _i_48140 = _i_48140 + -1;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_54recheck_routines_48125);
    RefDS(_recheck_targets_48134);
    _29put(_54recheck_routines_48125, _file_no_48131, _recheck_targets_48134, 1, 0);
L1: 
    DeRefi(_remaining_48138);
    _remaining_48138 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_48134);
    return;
    ;
}


void _54mark_final_targets()
{
    object _size_1__tmp_at47_48170 = NOVALUE;
    object _size_inlined_size_at_47_48169 = NOVALUE;
    object _recheck_files_48171 = NOVALUE;
    object _24903 = NOVALUE;
    object _24902 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_48052 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_36TRANSLATE_21369 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _54mark_all(53);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _54mark_all(12);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_48170);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_54recheck_routines_48125)){
        _size_1__tmp_at47_48170 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_54recheck_routines_48125)->dbl));
    }
    else{
        _size_1__tmp_at47_48170 = (object)*(((s1_ptr)_2)->base + _54recheck_routines_48125);
    }
    Ref(_size_1__tmp_at47_48170);
    DeRef(_size_inlined_size_at_47_48169);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_48170);
    _size_inlined_size_at_47_48169 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_size_inlined_size_at_47_48169);
    DeRef(_size_1__tmp_at47_48170);
    _size_1__tmp_at47_48170 = NOVALUE;
    if (_size_inlined_size_at_47_48169 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_48169) && DBL_PTR(_size_inlined_size_at_47_48169)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_54recheck_routines_48125);
    _0 = _recheck_files_48171;
    _recheck_files_48171 = _29keys(_54recheck_routines_48125, 0);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_48171)){
            _24902 = SEQ_PTR(_recheck_files_48171)->length;
    }
    else {
        _24902 = 1;
    }
    {
        object _i_48174;
        _i_48174 = 1;
L5: 
        if (_i_48174 > _24902){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_48171);
        _24903 = (object)*(((s1_ptr)_2)->base + _i_48174);
        Ref(_24903);
        _54mark_rechecks(_24903);
        _24903 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_48174 = _i_48174 + 1;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_48171);
    _recheck_files_48171 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _54is_routine(object _sym_48180)
{
    object _tok_48181 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_48181 = _54sym_token(_sym_48180);
    if (!IS_ATOM_INT(_tok_48181)) {
        _1 = (object)(DBL_PTR(_tok_48181)->dbl);
        DeRefDS(_tok_48181);
        _tok_48181 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_48181;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0;
    ;}L1: 
    ;
}


object _54is_visible(object _sym_48194, object _from_file_48195)
{
    object _scope_48196 = NOVALUE;
    object _sym_file_48199 = NOVALUE;
    object _visible_mask_48204 = NOVALUE;
    object _24915 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _24908 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_48196 = _54sym_scope(_sym_48194);
    if (!IS_ATOM_INT(_scope_48196)) {
        _1 = (object)(DBL_PTR(_scope_48196)->dbl);
        DeRefDS(_scope_48196);
        _scope_48196 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24908 = (object)*(((s1_ptr)_2)->base + _sym_48194);
    _2 = (object)SEQ_PTR(_24908);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _sym_file_48199 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _sym_file_48199 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_sym_file_48199)){
        _sym_file_48199 = (object)DBL_PTR(_sym_file_48199)->dbl;
    }
    _24908 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_48196;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_48204 = 6;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_48204 = 2;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24912 = (_from_file_48195 == _sym_file_48199);
        return _24912;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _24913 = (object)*(((s1_ptr)_2)->base + _from_file_48195);
    _2 = (object)SEQ_PTR(_24913);
    _24914 = (object)*(((s1_ptr)_2)->base + _sym_file_48199);
    _24913 = NOVALUE;
    if (IS_ATOM_INT(_24914)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_48204 & (uintptr_t)_24914;
             _24915 = MAKE_UINT(tu);
        }
    }
    else {
        _24915 = binary_op(AND_BITS, _visible_mask_48204, _24914);
    }
    _24914 = NOVALUE;
    DeRef(_24912);
    _24912 = NOVALUE;
    return _24915;
    ;
}


object _54MarkTargets(object _s_48224, object _attribute_48225)
{
    object _p_48227 = NOVALUE;
    object _sname_48228 = NOVALUE;
    object _string_48229 = NOVALUE;
    object _colon_48230 = NOVALUE;
    object _h_48231 = NOVALUE;
    object _scope_48232 = NOVALUE;
    object _found_48253 = NOVALUE;
    object _24963 = NOVALUE;
    object _24961 = NOVALUE;
    object _24960 = NOVALUE;
    object _24959 = NOVALUE;
    object _24958 = NOVALUE;
    object _24956 = NOVALUE;
    object _24955 = NOVALUE;
    object _24954 = NOVALUE;
    object _24953 = NOVALUE;
    object _24952 = NOVALUE;
    object _24950 = NOVALUE;
    object _24949 = NOVALUE;
    object _24948 = NOVALUE;
    object _24946 = NOVALUE;
    object _24944 = NOVALUE;
    object _24942 = NOVALUE;
    object _24941 = NOVALUE;
    object _24940 = NOVALUE;
    object _24939 = NOVALUE;
    object _24937 = NOVALUE;
    object _24936 = NOVALUE;
    object _24935 = NOVALUE;
    object _24934 = NOVALUE;
    object _24932 = NOVALUE;
    object _24931 = NOVALUE;
    object _24927 = NOVALUE;
    object _24926 = NOVALUE;
    object _24925 = NOVALUE;
    object _24924 = NOVALUE;
    object _24923 = NOVALUE;
    object _24922 = NOVALUE;
    object _24921 = NOVALUE;
    object _24920 = NOVALUE;
    object _24919 = NOVALUE;
    object _24918 = NOVALUE;
    object _24917 = NOVALUE;
    object _24916 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48224)) {
        _1 = (object)(DBL_PTR(_s_48224)->dbl);
        DeRefDS(_s_48224);
        _s_48224 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24916 = (object)*(((s1_ptr)_2)->base + _s_48224);
    _2 = (object)SEQ_PTR(_24916);
    _24917 = (object)*(((s1_ptr)_2)->base + 3);
    _24916 = NOVALUE;
    if (IS_ATOM_INT(_24917)) {
        _24918 = (_24917 == 3);
    }
    else {
        _24918 = binary_op(EQUALS, _24917, 3);
    }
    _24917 = NOVALUE;
    if (IS_ATOM_INT(_24918)) {
        if (_24918 != 0) {
            _24919 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24918)->dbl != 0.0) {
            _24919 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24920 = (object)*(((s1_ptr)_2)->base + _s_48224);
    _2 = (object)SEQ_PTR(_24920);
    _24921 = (object)*(((s1_ptr)_2)->base + 3);
    _24920 = NOVALUE;
    if (IS_ATOM_INT(_24921)) {
        _24922 = (_24921 == 2);
    }
    else {
        _24922 = binary_op(EQUALS, _24921, 2);
    }
    _24921 = NOVALUE;
    DeRef(_24919);
    if (IS_ATOM_INT(_24922))
    _24919 = (_24922 != 0);
    else
    _24919 = DBL_PTR(_24922)->dbl != 0.0;
L1: 
    if (_24919 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24924 = (object)*(((s1_ptr)_2)->base + _s_48224);
    _2 = (object)SEQ_PTR(_24924);
    _24925 = (object)*(((s1_ptr)_2)->base + 1);
    _24924 = NOVALUE;
    _24926 = IS_SEQUENCE(_24925);
    _24925 = NOVALUE;
    if (_24926 == 0)
    {
        _24926 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24926 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_48253 = 0;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24927 = (object)*(((s1_ptr)_2)->base + _s_48224);
    DeRef(_string_48229);
    _2 = (object)SEQ_PTR(_24927);
    _string_48229 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_string_48229);
    _24927 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_48230 = find_from(58, _string_48229, 1);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_48230 != 0)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_48229);
    DeRef(_sname_48228);
    _sname_48228 = _string_48229;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24931 = _colon_48230 + 1;
    if (_24931 > MAXINT){
        _24931 = NewDouble((eudouble)_24931);
    }
    if (IS_SEQUENCE(_string_48229)){
            _24932 = SEQ_PTR(_string_48229)->length;
    }
    else {
        _24932 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_48228;
    RHS_Slice(_string_48229, _24931, _24932);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_48228)){
            _24934 = SEQ_PTR(_sname_48228)->length;
    }
    else {
        _24934 = 1;
    }
    if (_24934 == 0) {
        _24935 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_48228);
    _24936 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24936)) {
        _24937 = (_24936 == 32);
    }
    else {
        _24937 = binary_op(EQUALS, _24936, 32);
    }
    _24936 = NOVALUE;
    if (IS_ATOM_INT(_24937))
    _24935 = (_24937 != 0);
    else
    _24935 = DBL_PTR(_24937)->dbl != 0.0;
L6: 
    if (_24935 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_48228);
    _24939 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24939)) {
        _24940 = (_24939 == 9);
    }
    else {
        _24940 = binary_op(EQUALS, _24939, 9);
    }
    _24939 = NOVALUE;
    if (_24940 <= 0) {
        if (_24940 == 0) {
            DeRef(_24940);
            _24940 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24940) && DBL_PTR(_24940)->dbl == 0.0){
                DeRef(_24940);
                _24940 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24940);
            _24940 = NOVALUE;
        }
    }
    DeRef(_24940);
    _24940 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_48228)){
            _24941 = SEQ_PTR(_sname_48228)->length;
    }
    else {
        _24941 = 1;
    }
    _24942 = _24941 - 1;
    _24941 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_48228)->length;
        int size = (IS_ATOM_INT(_24942)) ? _24942 : (object)(DBL_PTR(_24942)->dbl);
        if (size <= 0) {
            DeRef(_sname_48228);
            _sname_48228 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_48228);
            DeRef(_sname_48228);
            _sname_48228 = _sname_48228;
        }
        else Tail(SEQ_PTR(_sname_48228), len-size+1, &_sname_48228);
    }
    _24942 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_48228)){
            _24944 = SEQ_PTR(_sname_48228)->length;
    }
    else {
        _24944 = 1;
    }
    if (_24944 != 0)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_48228);
    DeRef(_string_48229);
    DeRef(_24922);
    _24922 = NOVALUE;
    DeRef(_24937);
    _24937 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    DeRef(_24918);
    _24918 = NOVALUE;
    return 1;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_48228);
    _24946 = _54hashfn(_sname_48228);
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_24946)){
        _h_48231 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24946)->dbl));
    }
    else{
        _h_48231 = (object)*(((s1_ptr)_2)->base + _24946);
    }
    if (!IS_ATOM_INT(_h_48231))
    _h_48231 = (object)DBL_PTR(_h_48231)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_48231 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24948 = (object)*(((s1_ptr)_2)->base + _h_48231);
    _2 = (object)SEQ_PTR(_24948);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _24949 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _24949 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _24948 = NOVALUE;
    if (_sname_48228 == _24949)
    _24950 = 1;
    else if (IS_ATOM_INT(_sname_48228) && IS_ATOM_INT(_24949))
    _24950 = 0;
    else
    _24950 = (compare(_sname_48228, _24949) == 0);
    _24949 = NOVALUE;
    if (_24950 == 0)
    {
        _24950 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24950 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_48225 != 12)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27;
    ((intptr_t *)_2)[2] = _h_48231;
    _24952 = MAKE_SEQ(_1);
    _54add_ref(_24952);
    _24952 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24953 = _54is_routine(_h_48231);
    if (IS_ATOM_INT(_24953)) {
        if (_24953 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24953)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24955 = _54is_visible(_h_48231, _36current_file_no_21767);
    if (_24955 == 0) {
        DeRef(_24955);
        _24955 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24955) && DBL_PTR(_24955)->dbl == 0.0){
            DeRef(_24955);
            _24955 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24955);
        _24955 = NOVALUE;
    }
    DeRef(_24955);
    _24955 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_48231 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24958 = (object)*(((s1_ptr)_2)->base + _attribute_48225);
    _24956 = NOVALUE;
    if (IS_ATOM_INT(_24958)) {
        _24959 = _24958 + 1;
        if (_24959 > MAXINT){
            _24959 = NewDouble((eudouble)_24959);
        }
    }
    else
    _24959 = binary_op(PLUS, 1, _24958);
    _24958 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48225);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24959;
    if( _1 != _24959 ){
        DeRef(_1);
    }
    _24959 = NOVALUE;
    _24956 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24960 = (object)*(((s1_ptr)_2)->base + _h_48231);
    _2 = (object)SEQ_PTR(_24960);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _24961 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _24961 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _24960 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21767, _24961)){
        _24961 = NOVALUE;
        goto L10; // [347] 357
    }
    _24961 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_48253 = 1;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24963 = (object)*(((s1_ptr)_2)->base + _h_48231);
    _2 = (object)SEQ_PTR(_24963);
    _h_48231 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_48231)){
        _h_48231 = (object)DBL_PTR(_h_48231)->dbl;
    }
    _24963 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_48253 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_54recheck_routines_48125);
    _29put(_54recheck_routines_48125, _36current_file_no_21767, _s_48224, 6, 0);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_48228);
    DeRef(_string_48229);
    DeRef(_24946);
    _24946 = NOVALUE;
    DeRef(_24922);
    _24922 = NOVALUE;
    DeRef(_24953);
    _24953 = NOVALUE;
    DeRef(_24937);
    _24937 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    DeRef(_24918);
    _24918 = NOVALUE;
    return _found_48253;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_54just_mark_everything_from_48052 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _54just_mark_everything_from_48052 = _36TopLevelSub_21774;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _54mark_all(_attribute_48225);

    /** symtab.e:700			return 1*/
    DeRef(_sname_48228);
    DeRef(_string_48229);
    DeRef(_24946);
    _24946 = NOVALUE;
    DeRef(_24922);
    _24922 = NOVALUE;
    DeRef(_24953);
    _24953 = NOVALUE;
    DeRef(_24937);
    _24937 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    DeRef(_24918);
    _24918 = NOVALUE;
    return 1;
L12: 
    ;
}


void _54resolve_unincluded_globals(object _ok_48331)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _54Resolve_unincluded_globals_48328 = 1;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _54get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _54Resolve_unincluded_globals_48328;
    ;
}


object _54keyfind(object _word_48337, object _file_no_48338, object _scanning_file_48339, object _namespace_ok_48342, object _hashval_48343)
{
    object _msg_48345 = NOVALUE;
    object _b_name_48346 = NOVALUE;
    object _scope_48347 = NOVALUE;
    object _defined_48348 = NOVALUE;
    object _ix_48349 = NOVALUE;
    object _st_ptr_48351 = NOVALUE;
    object _st_builtin_48352 = NOVALUE;
    object _tok_48354 = NOVALUE;
    object _gtok_48355 = NOVALUE;
    object _any_symbol_48358 = NOVALUE;
    object _tok_file_48526 = NOVALUE;
    object _good_48533 = NOVALUE;
    object _include_type_48543 = NOVALUE;
    object _msg_file_48599 = NOVALUE;
    object _25158 = NOVALUE;
    object _25157 = NOVALUE;
    object _25155 = NOVALUE;
    object _25153 = NOVALUE;
    object _25152 = NOVALUE;
    object _25151 = NOVALUE;
    object _25150 = NOVALUE;
    object _25149 = NOVALUE;
    object _25147 = NOVALUE;
    object _25145 = NOVALUE;
    object _25144 = NOVALUE;
    object _25143 = NOVALUE;
    object _25142 = NOVALUE;
    object _25141 = NOVALUE;
    object _25140 = NOVALUE;
    object _25139 = NOVALUE;
    object _25138 = NOVALUE;
    object _25136 = NOVALUE;
    object _25135 = NOVALUE;
    object _25134 = NOVALUE;
    object _25133 = NOVALUE;
    object _25132 = NOVALUE;
    object _25131 = NOVALUE;
    object _25130 = NOVALUE;
    object _25129 = NOVALUE;
    object _25128 = NOVALUE;
    object _25127 = NOVALUE;
    object _25126 = NOVALUE;
    object _25125 = NOVALUE;
    object _25124 = NOVALUE;
    object _25123 = NOVALUE;
    object _25122 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _25118 = NOVALUE;
    object _25117 = NOVALUE;
    object _25114 = NOVALUE;
    object _25110 = NOVALUE;
    object _25108 = NOVALUE;
    object _25107 = NOVALUE;
    object _25106 = NOVALUE;
    object _25105 = NOVALUE;
    object _25104 = NOVALUE;
    object _25102 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _25099 = NOVALUE;
    object _25097 = NOVALUE;
    object _25094 = NOVALUE;
    object _25093 = NOVALUE;
    object _25092 = NOVALUE;
    object _25091 = NOVALUE;
    object _25089 = NOVALUE;
    object _25086 = NOVALUE;
    object _25085 = NOVALUE;
    object _25084 = NOVALUE;
    object _25083 = NOVALUE;
    object _25082 = NOVALUE;
    object _25081 = NOVALUE;
    object _25080 = NOVALUE;
    object _25077 = NOVALUE;
    object _25076 = NOVALUE;
    object _25074 = NOVALUE;
    object _25072 = NOVALUE;
    object _25070 = NOVALUE;
    object _25069 = NOVALUE;
    object _25068 = NOVALUE;
    object _25064 = NOVALUE;
    object _25063 = NOVALUE;
    object _25058 = NOVALUE;
    object _25056 = NOVALUE;
    object _25054 = NOVALUE;
    object _25053 = NOVALUE;
    object _25049 = NOVALUE;
    object _25048 = NOVALUE;
    object _25046 = NOVALUE;
    object _25045 = NOVALUE;
    object _25043 = NOVALUE;
    object _25042 = NOVALUE;
    object _25041 = NOVALUE;
    object _25040 = NOVALUE;
    object _25039 = NOVALUE;
    object _25037 = NOVALUE;
    object _25036 = NOVALUE;
    object _25035 = NOVALUE;
    object _25034 = NOVALUE;
    object _25033 = NOVALUE;
    object _25032 = NOVALUE;
    object _25031 = NOVALUE;
    object _25030 = NOVALUE;
    object _25029 = NOVALUE;
    object _25028 = NOVALUE;
    object _25027 = NOVALUE;
    object _25026 = NOVALUE;
    object _25025 = NOVALUE;
    object _25024 = NOVALUE;
    object _25023 = NOVALUE;
    object _25022 = NOVALUE;
    object _25021 = NOVALUE;
    object _25020 = NOVALUE;
    object _25019 = NOVALUE;
    object _25018 = NOVALUE;
    object _25017 = NOVALUE;
    object _25016 = NOVALUE;
    object _25014 = NOVALUE;
    object _25013 = NOVALUE;
    object _25011 = NOVALUE;
    object _25010 = NOVALUE;
    object _25009 = NOVALUE;
    object _25008 = NOVALUE;
    object _25007 = NOVALUE;
    object _25005 = NOVALUE;
    object _25004 = NOVALUE;
    object _25003 = NOVALUE;
    object _25001 = NOVALUE;
    object _25000 = NOVALUE;
    object _24999 = NOVALUE;
    object _24998 = NOVALUE;
    object _24997 = NOVALUE;
    object _24996 = NOVALUE;
    object _24995 = NOVALUE;
    object _24993 = NOVALUE;
    object _24992 = NOVALUE;
    object _24987 = NOVALUE;
    object _24984 = NOVALUE;
    object _24983 = NOVALUE;
    object _24982 = NOVALUE;
    object _24981 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24976 = NOVALUE;
    object _24975 = NOVALUE;
    object _24974 = NOVALUE;
    object _24973 = NOVALUE;
    object _24972 = NOVALUE;
    object _24971 = NOVALUE;
    object _24970 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_48338)) {
        _1 = (object)(DBL_PTR(_file_no_48338)->dbl);
        DeRefDS(_file_no_48338);
        _file_no_48338 = _1;
    }
    if (!IS_ATOM_INT(_hashval_48343)) {
        _1 = (object)(DBL_PTR(_hashval_48343)->dbl);
        DeRefDS(_hashval_48343);
        _hashval_48343 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_22190);
    DeRef(_54dup_globals_48323);
    _54dup_globals_48323 = _22190;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_22190);
    DeRefi(_54dup_overrides_48324);
    _54dup_overrides_48324 = _22190;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_22190);
    DeRef(_54in_include_path_48325);
    _54in_include_path_48325 = _22190;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_22190);
    DeRef(_36symbol_resolution_warning_21872);
    _36symbol_resolution_warning_21872 = _22190;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_48352 = 0;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _st_ptr_48351 = (object)*(((s1_ptr)_2)->base + _hashval_48343);
    if (!IS_ATOM_INT(_st_ptr_48351)){
        _st_ptr_48351 = (object)DBL_PTR(_st_ptr_48351)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48358 = (_namespace_ok_48342 == -1);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_48351 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24970 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_24970);
    _24971 = (object)*(((s1_ptr)_2)->base + 4);
    _24970 = NOVALUE;
    if (IS_ATOM_INT(_24971)) {
        _24972 = (_24971 != 9);
    }
    else {
        _24972 = binary_op(NOTEQ, _24971, 9);
    }
    _24971 = NOVALUE;
    if (IS_ATOM_INT(_24972)) {
        if (_24972 == 0) {
            DeRef(_24973);
            _24973 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24972)->dbl == 0.0) {
            DeRef(_24973);
            _24973 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24974 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_24974);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _24975 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _24975 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _24974 = NOVALUE;
    if (_word_48337 == _24975)
    _24976 = 1;
    else if (IS_ATOM_INT(_word_48337) && IS_ATOM_INT(_24975))
    _24976 = 0;
    else
    _24976 = (compare(_word_48337, _24975) == 0);
    _24975 = NOVALUE;
    DeRef(_24973);
    _24973 = (_24976 != 0);
L3: 
    if (_24973 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48358 != 0) {
        DeRef(_24978);
        _24978 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24979 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_24979);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _24980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _24980 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _24979 = NOVALUE;
    if (IS_ATOM_INT(_24980)) {
        _24981 = (_24980 == 523);
    }
    else {
        _24981 = binary_op(EQUALS, _24980, 523);
    }
    _24980 = NOVALUE;
    if (IS_ATOM_INT(_24981)) {
        _24982 = (_namespace_ok_48342 == _24981);
    }
    else {
        _24982 = binary_op(EQUALS, _namespace_ok_48342, _24981);
    }
    DeRef(_24981);
    _24981 = NOVALUE;
    if (IS_ATOM_INT(_24982))
    _24978 = (_24982 != 0);
    else
    _24978 = DBL_PTR(_24982)->dbl != 0.0;
L5: 
    if (_24978 == 0)
    {
        _24978 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24978 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24983 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_24983);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _24984 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _24984 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _24983 = NOVALUE;
    Ref(_24984);
    DeRef(_tok_48354);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24984;
    ((intptr_t *)_2)[2] = _st_ptr_48351;
    _tok_48354 = MAKE_SEQ(_1);
    _24984 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_48338 != -1)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24987 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_24987);
    _scope_48347 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48347)){
        _scope_48347 = (object)DBL_PTR(_scope_48347)->dbl;
    }
    _24987 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_48347;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_54dup_overrides_48324, _54dup_overrides_48324, _st_ptr_48351);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_48352 = _st_ptr_48351;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24992 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_24992);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _24993 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _24993 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _24992 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48339, _24993)){
            _24993 = NOVALUE;
            goto L8; // [250] 274
        }
        _24993 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_36BIND_21372 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_48354);
        _54add_ref(_tok_48354);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_48337);
        DeRef(_msg_48345);
        DeRef(_b_name_48346);
        DeRef(_gtok_48355);
        DeRef(_24972);
        _24972 = NOVALUE;
        DeRef(_24982);
        _24982 = NOVALUE;
        return _tok_48354;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_54Resolve_unincluded_globals_48328 != 0) {
            _24995 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        _24996 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        if (_24996 == 0) {
            _24997 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _24998 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24999 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_24999);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25000 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25000 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _24999 = NOVALUE;
        _2 = (object)SEQ_PTR(_24998);
        if (!IS_ATOM_INT(_25000)){
            _25001 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25000)->dbl));
        }
        else{
            _25001 = (object)*(((s1_ptr)_2)->base + _25000);
        }
        _24998 = NOVALUE;
        if (IS_ATOM_INT(_25001))
        _24997 = (_25001 != 0);
        else
        _24997 = DBL_PTR(_25001)->dbl != 0.0;
LB: 
        _24995 = (_24997 != 0);
LA: 
        if (_24995 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25003 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25003);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _25004 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _25004 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _25003 = NOVALUE;
        if (IS_ATOM_INT(_25004)) {
            _25005 = (_25004 == 523);
        }
        else {
            _25005 = binary_op(EQUALS, _25004, 523);
        }
        _25004 = NOVALUE;
        if (_25005 == 0) {
            DeRef(_25005);
            _25005 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_25005) && DBL_PTR(_25005)->dbl == 0.0){
                DeRef(_25005);
                _25005 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_25005);
            _25005 = NOVALUE;
        }
        DeRef(_25005);
        _25005 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_48354);
        DeRef(_gtok_48355);
        _gtok_48355 = _tok_48354;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_54dup_globals_48323, _54dup_globals_48323, _st_ptr_48351);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25007 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25008 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25008);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25009 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25009 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25008 = NOVALUE;
        _2 = (object)SEQ_PTR(_25007);
        if (!IS_ATOM_INT(_25009)){
            _25010 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25009)->dbl));
        }
        else{
            _25010 = (object)*(((s1_ptr)_2)->base + _25009);
        }
        _25007 = NOVALUE;
        if (IS_ATOM_INT(_25010)) {
            _25011 = (_25010 != 0);
        }
        else {
            _25011 = binary_op(NOTEQ, _25010, 0);
        }
        _25010 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_48325) && IS_ATOM(_25011)) {
            Ref(_25011);
            Append(&_54in_include_path_48325, _54in_include_path_48325, _25011);
        }
        else if (IS_ATOM(_54in_include_path_48325) && IS_SEQUENCE(_25011)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_48325, _54in_include_path_48325, _25011);
        }
        DeRef(_25011);
        _25011 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25013 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25013);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25014 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25014 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25013 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48339, _25014)){
            _25014 = NOVALUE;
            goto LD; // [421] 445
        }
        _25014 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_36BIND_21372 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_48354);
        _54add_ref(_tok_48354);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_48337);
        DeRef(_msg_48345);
        DeRef(_b_name_48346);
        DeRef(_gtok_48355);
        _24996 = NOVALUE;
        DeRef(_24972);
        _24972 = NOVALUE;
        _25001 = NOVALUE;
        _25000 = NOVALUE;
        DeRef(_24982);
        _24982 = NOVALUE;
        _25009 = NOVALUE;
        return _tok_48354;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        _25016 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        if (_25016 != 0) {
            _25017 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_48342 == 0) {
            _25018 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25019 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25019);
        if (!IS_ATOM_INT(_36S_TOKEN_21409)){
            _25020 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
        }
        else{
            _25020 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
        }
        _25019 = NOVALUE;
        if (IS_ATOM_INT(_25020)) {
            _25021 = (_25020 == 523);
        }
        else {
            _25021 = binary_op(EQUALS, _25020, 523);
        }
        _25020 = NOVALUE;
        if (IS_ATOM_INT(_25021))
        _25018 = (_25021 != 0);
        else
        _25018 = DBL_PTR(_25021)->dbl != 0.0;
L10: 
        _25017 = (_25018 != 0);
LF: 
        if (_25017 == 0) {
            goto L7; // [487] 1011
        }
        _25023 = (_scope_48347 == 13);
        if (_25023 == 0) {
            _25024 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25025 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25026 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25026);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25027 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25026 = NOVALUE;
        _2 = (object)SEQ_PTR(_25025);
        if (!IS_ATOM_INT(_25027)){
            _25028 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25027)->dbl));
        }
        else{
            _25028 = (object)*(((s1_ptr)_2)->base + _25027);
        }
        _25025 = NOVALUE;
        if (IS_ATOM_INT(_25028)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_25028;
                 _25029 = MAKE_UINT(tu);
            }
        }
        else {
            _25029 = binary_op(AND_BITS, 6, _25028);
        }
        _25028 = NOVALUE;
        if (IS_ATOM_INT(_25029))
        _25024 = (_25029 != 0);
        else
        _25024 = DBL_PTR(_25029)->dbl != 0.0;
L11: 
        if (_25024 != 0) {
            DeRef(_25030);
            _25030 = 1;
            goto L12; // [533] 583
        }
        _25031 = (_scope_48347 == 11);
        if (_25031 == 0) {
            _25032 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25033 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25034 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25034);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25035 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25035 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25034 = NOVALUE;
        _2 = (object)SEQ_PTR(_25033);
        if (!IS_ATOM_INT(_25035)){
            _25036 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25035)->dbl));
        }
        else{
            _25036 = (object)*(((s1_ptr)_2)->base + _25035);
        }
        _25033 = NOVALUE;
        if (IS_ATOM_INT(_25036)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_25036;
                 _25037 = MAKE_UINT(tu);
            }
        }
        else {
            _25037 = binary_op(AND_BITS, 2, _25036);
        }
        _25036 = NOVALUE;
        if (IS_ATOM_INT(_25037))
        _25032 = (_25037 != 0);
        else
        _25032 = DBL_PTR(_25037)->dbl != 0.0;
L13: 
        DeRef(_25030);
        _25030 = (_25032 != 0);
L12: 
        if (_25030 == 0)
        {
            _25030 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _25030 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_48354);
        DeRef(_gtok_48355);
        _gtok_48355 = _tok_48354;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_54dup_globals_48323, _54dup_globals_48323, _st_ptr_48351);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25039 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25040 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25040);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25041 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25041 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25040 = NOVALUE;
        _2 = (object)SEQ_PTR(_25039);
        if (!IS_ATOM_INT(_25041)){
            _25042 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25041)->dbl));
        }
        else{
            _25042 = (object)*(((s1_ptr)_2)->base + _25041);
        }
        _25039 = NOVALUE;
        if (IS_ATOM_INT(_25042)) {
            _25043 = (_25042 != 0);
        }
        else {
            _25043 = binary_op(NOTEQ, _25042, 0);
        }
        _25042 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_48325) && IS_ATOM(_25043)) {
            Ref(_25043);
            Append(&_54in_include_path_48325, _54in_include_path_48325, _25043);
        }
        else if (IS_ATOM(_54in_include_path_48325) && IS_SEQUENCE(_25043)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_48325, _54in_include_path_48325, _25043);
        }
        DeRef(_25043);
        _25043 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25045 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
        _2 = (object)SEQ_PTR(_25045);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25046 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25046 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25045 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48339, _25046)){
            _25046 = NOVALUE;
            goto L7; // [659] 1011
        }
        _25046 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_36BIND_21372 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_48354);
        _54add_ref(_tok_48354);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_48337);
        DeRef(_msg_48345);
        DeRef(_b_name_48346);
        DeRef(_gtok_48355);
        _25016 = NOVALUE;
        DeRef(_25021);
        _25021 = NOVALUE;
        _24996 = NOVALUE;
        _25035 = NOVALUE;
        _25041 = NOVALUE;
        DeRef(_24972);
        _24972 = NOVALUE;
        DeRef(_25031);
        _25031 = NOVALUE;
        _25027 = NOVALUE;
        _25001 = NOVALUE;
        DeRef(_25037);
        _25037 = NOVALUE;
        DeRef(_25023);
        _25023 = NOVALUE;
        _25000 = NOVALUE;
        DeRef(_24982);
        _24982 = NOVALUE;
        DeRef(_25029);
        _25029 = NOVALUE;
        _25009 = NOVALUE;
        return _tok_48354;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_36BIND_21372 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_48354);
        _54add_ref(_tok_48354);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_48337);
        DeRef(_msg_48345);
        DeRef(_b_name_48346);
        DeRef(_gtok_48355);
        _25016 = NOVALUE;
        DeRef(_25021);
        _25021 = NOVALUE;
        _24996 = NOVALUE;
        _25035 = NOVALUE;
        _25041 = NOVALUE;
        DeRef(_24972);
        _24972 = NOVALUE;
        DeRef(_25031);
        _25031 = NOVALUE;
        _25027 = NOVALUE;
        _25001 = NOVALUE;
        DeRef(_25037);
        _25037 = NOVALUE;
        DeRef(_25023);
        _25023 = NOVALUE;
        _25000 = NOVALUE;
        DeRef(_24982);
        _24982 = NOVALUE;
        DeRef(_25029);
        _25029 = NOVALUE;
        _25009 = NOVALUE;
        return _tok_48354;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_48354);
    _25048 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25048)){
        _25049 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25048)->dbl));
    }
    else{
        _25049 = (object)*(((s1_ptr)_2)->base + _25048);
    }
    _2 = (object)SEQ_PTR(_25049);
    _scope_48347 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48347)){
        _scope_48347 = (object)DBL_PTR(_scope_48347)->dbl;
    }
    _25049 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_48338 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_48347 != 7)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_48354);
    _54add_ref(_tok_48354);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_gtok_48355);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25027 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25009 = NOVALUE;
    return _tok_48354;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_48354);
    _25053 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25053)){
        _25054 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25053)->dbl));
    }
    else{
        _25054 = (object)*(((s1_ptr)_2)->base + _25053);
    }
    _2 = (object)SEQ_PTR(_25054);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _tok_file_48526 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _tok_file_48526 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    if (!IS_ATOM_INT(_tok_file_48526)){
        _tok_file_48526 = (object)DBL_PTR(_tok_file_48526)->dbl;
    }
    _25054 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48533 = 0;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _25056 = (_scope_48347 == 3);
    if (_25056 != 0) {
        goto L19; // [807] 940
    }
    _25058 = (_scope_48347 == 7);
    if (_25058 == 0)
    {
        DeRef(_25058);
        _25058 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_25058);
        _25058 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_48338 != _tok_file_48526)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48533 = 1;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48543 = 0;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_48347;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_54Resolve_unincluded_globals_48328 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48543 = 7;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48543 = 6;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48526 == _file_no_48338)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48543 = 4;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48543 = 6;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _25063 = (object)*(((s1_ptr)_2)->base + _file_no_48338);
    _2 = (object)SEQ_PTR(_25063);
    _25064 = (object)*(((s1_ptr)_2)->base + _tok_file_48526);
    _25063 = NOVALUE;
    if (IS_ATOM_INT(_25064)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48543 & (uintptr_t)_25064;
             _good_48533 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48533 = binary_op(AND_BITS, _include_type_48543, _25064);
    }
    _25064 = NOVALUE;
    if (!IS_ATOM_INT(_good_48533)) {
        _1 = (object)(DBL_PTR(_good_48533)->dbl);
        DeRefDS(_good_48533);
        _good_48533 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48533 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_48338 != _tok_file_48526)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_48354);
    _54add_ref(_tok_48354);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_gtok_48355);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25027 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25053 = NOVALUE;
    _25009 = NOVALUE;
    return _tok_48354;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_48354);
    DeRef(_gtok_48355);
    _gtok_48355 = _tok_48354;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_54dup_globals_48323, _54dup_globals_48323, _st_ptr_48351);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _25068 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
    _2 = (object)SEQ_PTR(_25068);
    _25069 = (object)*(((s1_ptr)_2)->base + _tok_file_48526);
    _25068 = NOVALUE;
    if (IS_ATOM_INT(_25069)) {
        _25070 = (_25069 != 0);
    }
    else {
        _25070 = binary_op(NOTEQ, _25069, 0);
    }
    _25069 = NOVALUE;
    if (IS_SEQUENCE(_54in_include_path_48325) && IS_ATOM(_25070)) {
        Ref(_25070);
        Append(&_54in_include_path_48325, _54in_include_path_48325, _25070);
    }
    else if (IS_ATOM(_54in_include_path_48325) && IS_SEQUENCE(_25070)) {
    }
    else {
        Concat((object_ptr)&_54in_include_path_48325, _54in_include_path_48325, _25070);
    }
    DeRef(_25070);
    _25070 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25072 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_25072);
    _st_ptr_48351 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_48351)){
        _st_ptr_48351 = (object)DBL_PTR(_st_ptr_48351)->dbl;
    }
    _25072 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_48324)){
            _25074 = SEQ_PTR(_54dup_overrides_48324)->length;
    }
    else {
        _25074 = 1;
    }
    if (_25074 == 0)
    {
        _25074 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _25074 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_54dup_overrides_48324);
    _st_ptr_48351 = (object)*(((s1_ptr)_2)->base + 1);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25076 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_25076);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _25077 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _25077 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _25076 = NOVALUE;
    Ref(_25077);
    DeRef(_tok_48354);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25077;
    ((intptr_t *)_2)[2] = _st_ptr_48351;
    _tok_48354 = MAKE_SEQ(_1);
    _25077 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_48354);
    _54add_ref(_tok_48354);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_gtok_48355);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25027 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25053 = NOVALUE;
    _25009 = NOVALUE;
    return _tok_48354;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_48352 == 0)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25080 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25080 = 1;
    }
    if (_25080 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25082 = (object)*(((s1_ptr)_2)->base + _st_builtin_48352);
    _2 = (object)SEQ_PTR(_25082);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25083 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25083 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25082 = NOVALUE;
    _25084 = find_from(_25083, _54builtin_warnings_48327, 1);
    _25083 = NOVALUE;
    _25085 = (_25084 == 0);
    _25084 = NOVALUE;
    if (_25085 == 0)
    {
        DeRef(_25085);
        _25085 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_25085);
        _25085 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25086 = (object)*(((s1_ptr)_2)->base + _st_builtin_48352);
    DeRef(_b_name_48346);
    _2 = (object)SEQ_PTR(_25086);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _b_name_48346 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _b_name_48346 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_b_name_48346);
    _25086 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_48346);
    Append(&_54builtin_warnings_48327, _54builtin_warnings_48327, _b_name_48346);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25089 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25089 = 1;
    }
    if (_25089 <= 1)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22385);
    DeRef(_msg_48345);
    _msg_48345 = _22385;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_22190);
    DeRef(_msg_48345);
    _msg_48345 = _22190;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25091 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25091 = 1;
    }
    {
        object _i_48610;
        _i_48610 = 1;
L2A: 
        if (_i_48610 > _25091){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_54dup_globals_48323);
        _25092 = (object)*(((s1_ptr)_2)->base + _i_48610);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_25092)){
            _25093 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25092)->dbl));
        }
        else{
            _25093 = (object)*(((s1_ptr)_2)->base + _25092);
        }
        _2 = (object)SEQ_PTR(_25093);
        if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
            _25094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
        }
        else{
            _25094 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
        }
        _25093 = NOVALUE;
        DeRef(_msg_file_48599);
        _2 = (object)SEQ_PTR(_37known_files_15638);
        if (!IS_ATOM_INT(_25094)){
            _msg_file_48599 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25094)->dbl));
        }
        else{
            _msg_file_48599 = (object)*(((s1_ptr)_2)->base + _25094);
        }
        Ref(_msg_file_48599);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22385;
            concat_list[1] = _msg_file_48599;
            concat_list[2] = _25096;
            Concat_N((object_ptr)&_25097, concat_list, 3);
        }
        Concat((object_ptr)&_msg_48345, _msg_48345, _25097);
        DeRefDS(_25097);
        _25097 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48610 = _i_48610 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25099 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_48346);
    ((intptr_t*)_2)[1] = _b_name_48346;
    Ref(_25099);
    ((intptr_t*)_2)[2] = _25099;
    RefDS(_msg_48345);
    ((intptr_t*)_2)[3] = _msg_48345;
    _25100 = MAKE_SEQ(_1);
    _25099 = NOVALUE;
    _50Warning(234, 8, _25100);
    _25100 = NOVALUE;
L27: 
    DeRef(_msg_file_48599);
    _msg_file_48599 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25101 = (object)*(((s1_ptr)_2)->base + _st_builtin_48352);
    _2 = (object)SEQ_PTR(_25101);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _25102 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _25102 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _25101 = NOVALUE;
    Ref(_25102);
    DeRef(_tok_48354);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25102;
    ((intptr_t *)_2)[2] = _st_builtin_48352;
    _tok_48354 = MAKE_SEQ(_1);
    _25102 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_48354);
    _54add_ref(_tok_48354);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_gtok_48355);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25094 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25027 = NOVALUE;
    _25092 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25053 = NOVALUE;
    _25009 = NOVALUE;
    return _tok_48354;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25104 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25104 = 1;
    }
    _25105 = (_25104 > 1);
    _25104 = NOVALUE;
    if (_25105 == 0) {
        goto L2D; // [1333] 1452
    }
    _25107 = find_from(1, _54in_include_path_48325, 1);
    if (_25107 == 0)
    {
        _25107 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _25107 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_48349 = 1;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25108 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25108 = 1;
    }
    if (_ix_48349 > _25108)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_54in_include_path_48325);
    _25110 = (object)*(((s1_ptr)_2)->base + _ix_48349);
    if (_25110 == 0) {
        _25110 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_25110) && DBL_PTR(_25110)->dbl == 0.0){
            _25110 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _25110 = NOVALUE;
    }
    _25110 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_48349 = _ix_48349 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54dup_globals_48323);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48349)) ? _ix_48349 : (object)(DBL_PTR(_ix_48349)->dbl);
        int stop = (IS_ATOM_INT(_ix_48349)) ? _ix_48349 : (object)(DBL_PTR(_ix_48349)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54dup_globals_48323), start, &_54dup_globals_48323 );
            }
            else Tail(SEQ_PTR(_54dup_globals_48323), stop+1, &_54dup_globals_48323);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54dup_globals_48323), start, &_54dup_globals_48323);
        }
        else {
            assign_slice_seq = &assign_space;
            _54dup_globals_48323 = Remove_elements(start, stop, (SEQ_PTR(_54dup_globals_48323)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54in_include_path_48325);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48349)) ? _ix_48349 : (object)(DBL_PTR(_ix_48349)->dbl);
        int stop = (IS_ATOM_INT(_ix_48349)) ? _ix_48349 : (object)(DBL_PTR(_ix_48349)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54in_include_path_48325), start, &_54in_include_path_48325 );
            }
            else Tail(SEQ_PTR(_54in_include_path_48325), stop+1, &_54in_include_path_48325);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54in_include_path_48325), start, &_54in_include_path_48325);
        }
        else {
            assign_slice_seq = &assign_space;
            _54in_include_path_48325 = Remove_elements(start, stop, (SEQ_PTR(_54in_include_path_48325)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25114 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25114 = 1;
    }
    if (_25114 != 1)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_54dup_globals_48323);
    _st_ptr_48351 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_48351)){
        _st_ptr_48351 = (object)DBL_PTR(_st_ptr_48351)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25117 = (object)*(((s1_ptr)_2)->base + _st_ptr_48351);
    _2 = (object)SEQ_PTR(_25117);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _25118 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _25118 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _25117 = NOVALUE;
    Ref(_25118);
    DeRef(_gtok_48355);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25118;
    ((intptr_t *)_2)[2] = _st_ptr_48351;
    _gtok_48355 = MAKE_SEQ(_1);
    _25118 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25120 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25120 = 1;
    }
    _25121 = (_25120 == 1);
    _25120 = NOVALUE;
    if (_25121 == 0) {
        goto L32; // [1465] 1644
    }
    _25123 = (_st_builtin_48352 == 0);
    if (_25123 == 0)
    {
        DeRef(_25123);
        _25123 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_25123);
        _25123 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_36BIND_21372 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_48355);
    _54add_ref(_gtok_48355);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_54in_include_path_48325);
    _25124 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25124)) {
        _25125 = (_25124 == 0);
    }
    else {
        _25125 = unary_op(NOT, _25124);
    }
    _25124 = NOVALUE;
    if (IS_ATOM_INT(_25125)) {
        if (_25125 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_25125)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_48355);
    _25127 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25127)){
        _25128 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25127)->dbl));
    }
    else{
        _25128 = (object)*(((s1_ptr)_2)->base + _25127);
    }
    _2 = (object)SEQ_PTR(_25128);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _25129 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _25129 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _25128 = NOVALUE;
    Ref(_25129);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48339;
    ((intptr_t *)_2)[2] = _25129;
    _25130 = MAKE_SEQ(_1);
    _25129 = NOVALUE;
    _25131 = find_from(_25130, _54include_warnings_48326, 1);
    DeRefDS(_25130);
    _25130 = NOVALUE;
    _25132 = (_25131 == 0);
    _25131 = NOVALUE;
    if (_25132 == 0)
    {
        DeRef(_25132);
        _25132 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_25132);
        _25132 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_48355);
    _25133 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25133)){
        _25134 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25133)->dbl));
    }
    else{
        _25134 = (object)*(((s1_ptr)_2)->base + _25133);
    }
    _2 = (object)SEQ_PTR(_25134);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _25135 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _25135 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _25134 = NOVALUE;
    Ref(_25135);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48339;
    ((intptr_t *)_2)[2] = _25135;
    _25136 = MAKE_SEQ(_1);
    _25135 = NOVALUE;
    RefDS(_25136);
    Prepend(&_54include_warnings_48326, _54include_warnings_48326, _25136);
    DeRefDS(_25136);
    _25136 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25138 = (object)*(((s1_ptr)_2)->base + _scanning_file_48339);
    Ref(_25138);
    _25139 = _54name_ext(_25138);
    _25138 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_48355);
    _25140 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25140)){
        _25141 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25140)->dbl));
    }
    else{
        _25141 = (object)*(((s1_ptr)_2)->base + _25140);
    }
    _2 = (object)SEQ_PTR(_25141);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _25142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _25142 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _25141 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15638);
    if (!IS_ATOM_INT(_25142)){
        _25143 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25142)->dbl));
    }
    else{
        _25143 = (object)*(((s1_ptr)_2)->base + _25142);
    }
    Ref(_25143);
    _25144 = _54name_ext(_25143);
    _25143 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25139;
    ((intptr_t*)_2)[2] = _36line_number_21768;
    RefDS(_word_48337);
    ((intptr_t*)_2)[3] = _word_48337;
    ((intptr_t*)_2)[4] = _25144;
    _25145 = MAKE_SEQ(_1);
    _25144 = NOVALUE;
    _25139 = NOVALUE;
    _0 = _39GetMsgText(233, 0, _25145);
    DeRef(_36symbol_resolution_warning_21872);
    _36symbol_resolution_warning_21872 = _0;
    _25145 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_tok_48354);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25094 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25142 = NOVALUE;
    _25027 = NOVALUE;
    DeRef(_25105);
    _25105 = NOVALUE;
    _25092 = NOVALUE;
    DeRef(_25121);
    _25121 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25140 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_25125);
    _25125 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25127 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25133 = NOVALUE;
    _25053 = NOVALUE;
    _25009 = NOVALUE;
    return _gtok_48355;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25147 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25147 = 1;
    }
    if (_25147 != 0)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_48348 = 9;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_36fwd_line_number_21769 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_50ForwardLine_49595);
    DeRef(_50last_ForwardLine_49597);
    _50last_ForwardLine_49597 = _50ForwardLine_49595;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _50last_forward_bp_49601 = _50forward_bp_49599;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _36last_fwd_line_number_21771 = _36fwd_line_number_21769;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_50ThisLine_49594);
    DeRef(_50ForwardLine_49595);
    _50ForwardLine_49595 = _50ThisLine_49594;

    /** symtab.e:1061			forward_bp = bp*/
    _50forward_bp_49599 = _50bp_49598;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _36fwd_line_number_21769 = _36line_number_21768;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_54dup_globals_48323)){
            _25149 = SEQ_PTR(_54dup_globals_48323)->length;
    }
    else {
        _25149 = 1;
    }
    if (_25149 == 0)
    {
        _25149 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _25149 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_48348 = 10;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_48324)){
            _25150 = SEQ_PTR(_54dup_overrides_48324)->length;
    }
    else {
        _25150 = 1;
    }
    if (_25150 == 0)
    {
        _25150 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _25150 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_48348 = 12;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_54No_new_entry_48334 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509;
    RefDS(_word_48337);
    ((intptr_t*)_2)[2] = _word_48337;
    ((intptr_t*)_2)[3] = _defined_48348;
    RefDS(_54dup_globals_48323);
    ((intptr_t*)_2)[4] = _54dup_globals_48323;
    _25151 = MAKE_SEQ(_1);
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_tok_48354);
    DeRef(_gtok_48355);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25094 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25142 = NOVALUE;
    _25027 = NOVALUE;
    DeRef(_25105);
    _25105 = NOVALUE;
    _25092 = NOVALUE;
    DeRef(_25121);
    _25121 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25140 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_25125);
    _25125 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25127 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25133 = NOVALUE;
    _25053 = NOVALUE;
    _25009 = NOVALUE;
    return _25151;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _25152 = (object)*(((s1_ptr)_2)->base + _hashval_48343);
    RefDS(_word_48337);
    Ref(_25152);
    _25153 = _54NewEntry(_word_48337, 0, _defined_48348, -100, _hashval_48343, _25152, 0);
    _25152 = NOVALUE;
    DeRef(_tok_48354);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _25153;
    _tok_48354 = MAKE_SEQ(_1);
    _25153 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48354);
    _25155 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_25155);
    _2 = (object)SEQ_PTR(_54buckets_47132);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_48343);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25155;
    if( _1 != _25155 ){
        DeRef(_1);
    }
    _25155 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_48338 == -1)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_48354);
    _25157 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25157))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25157)->dbl));
    else
    _3 = (object)(_25157 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21400))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_48338;
    DeRef(_1);
    _25158 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_48337);
    DeRef(_msg_48345);
    DeRef(_b_name_48346);
    DeRef(_gtok_48355);
    _25016 = NOVALUE;
    DeRef(_25021);
    _25021 = NOVALUE;
    _24996 = NOVALUE;
    _25035 = NOVALUE;
    _25041 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    _25157 = NOVALUE;
    _25094 = NOVALUE;
    _25048 = NOVALUE;
    DeRef(_25031);
    _25031 = NOVALUE;
    _25142 = NOVALUE;
    _25027 = NOVALUE;
    DeRef(_25105);
    _25105 = NOVALUE;
    _25092 = NOVALUE;
    DeRef(_25121);
    _25121 = NOVALUE;
    _25001 = NOVALUE;
    DeRef(_25037);
    _25037 = NOVALUE;
    DeRef(_25023);
    _25023 = NOVALUE;
    _25140 = NOVALUE;
    _25000 = NOVALUE;
    DeRef(_25125);
    _25125 = NOVALUE;
    DeRef(_24982);
    _24982 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25127 = NOVALUE;
    DeRef(_25029);
    _25029 = NOVALUE;
    _25133 = NOVALUE;
    _25053 = NOVALUE;
    DeRef(_25151);
    _25151 = NOVALUE;
    _25009 = NOVALUE;
    return _tok_48354;
    ;
}


void _54Hide(object _s_48748)
{
    object _prev_48750 = NOVALUE;
    object _p_48751 = NOVALUE;
    object _25178 = NOVALUE;
    object _25177 = NOVALUE;
    object _25176 = NOVALUE;
    object _25174 = NOVALUE;
    object _25173 = NOVALUE;
    object _25172 = NOVALUE;
    object _25171 = NOVALUE;
    object _25170 = NOVALUE;
    object _25166 = NOVALUE;
    object _25165 = NOVALUE;
    object _25164 = NOVALUE;
    object _25163 = NOVALUE;
    object _25161 = NOVALUE;
    object _25160 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48748)) {
        _1 = (object)(DBL_PTR(_s_48748)->dbl);
        DeRefDS(_s_48748);
        _s_48748 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25160 = (object)*(((s1_ptr)_2)->base + _s_48748);
    _2 = (object)SEQ_PTR(_25160);
    _25161 = (object)*(((s1_ptr)_2)->base + 11);
    _25160 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_25161)){
        _p_48751 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25161)->dbl));
    }
    else{
        _p_48751 = (object)*(((s1_ptr)_2)->base + _25161);
    }
    if (!IS_ATOM_INT(_p_48751)){
        _p_48751 = (object)DBL_PTR(_p_48751)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48750 = 0;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _25163 = (_p_48751 != _s_48748);
    if (_25163 == 0) {
        goto L2; // [41] 81
    }
    _25165 = (_p_48751 != 0);
    if (_25165 == 0)
    {
        DeRef(_25165);
        _25165 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25165);
        _25165 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48750 = _p_48751;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25166 = (object)*(((s1_ptr)_2)->base + _p_48751);
    _2 = (object)SEQ_PTR(_25166);
    _p_48751 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_48751)){
        _p_48751 = (object)DBL_PTR(_p_48751)->dbl;
    }
    _25166 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48751 != 0)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _25161 = NOVALUE;
    DeRef(_25163);
    _25163 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48750 != 0)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25170 = (object)*(((s1_ptr)_2)->base + _s_48748);
    _2 = (object)SEQ_PTR(_25170);
    _25171 = (object)*(((s1_ptr)_2)->base + 11);
    _25170 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25172 = (object)*(((s1_ptr)_2)->base + _s_48748);
    _2 = (object)SEQ_PTR(_25172);
    _25173 = (object)*(((s1_ptr)_2)->base + 9);
    _25172 = NOVALUE;
    Ref(_25173);
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_25171))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25171)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25171);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25173;
    if( _1 != _25173 ){
        DeRef(_1);
    }
    _25173 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48750 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25176 = (object)*(((s1_ptr)_2)->base + _s_48748);
    _2 = (object)SEQ_PTR(_25176);
    _25177 = (object)*(((s1_ptr)_2)->base + 9);
    _25176 = NOVALUE;
    Ref(_25177);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25177;
    if( _1 != _25177 ){
        DeRef(_1);
    }
    _25177 = NOVALUE;
    _25174 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48748 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _25178 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _25161 = NOVALUE;
    DeRef(_25163);
    _25163 = NOVALUE;
    _25171 = NOVALUE;
    return;
    ;
}


void _54Show(object _s_48793)
{
    object _p_48795 = NOVALUE;
    object _25190 = NOVALUE;
    object _25189 = NOVALUE;
    object _25187 = NOVALUE;
    object _25186 = NOVALUE;
    object _25184 = NOVALUE;
    object _25183 = NOVALUE;
    object _25181 = NOVALUE;
    object _25180 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25180 = (object)*(((s1_ptr)_2)->base + _s_48793);
    _2 = (object)SEQ_PTR(_25180);
    _25181 = (object)*(((s1_ptr)_2)->base + 11);
    _25180 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_25181)){
        _p_48795 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25181)->dbl));
    }
    else{
        _p_48795 = (object)*(((s1_ptr)_2)->base + _25181);
    }
    if (!IS_ATOM_INT(_p_48795)){
        _p_48795 = (object)DBL_PTR(_p_48795)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25183 = (object)*(((s1_ptr)_2)->base + _s_48793);
    _2 = (object)SEQ_PTR(_25183);
    _25184 = (object)*(((s1_ptr)_2)->base + 9);
    _25183 = NOVALUE;
    if (IS_ATOM_INT(_25184)) {
        if (_25184 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25184)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25186 = (_p_48795 == _s_48793);
    if (_25186 == 0)
    {
        DeRef(_25186);
        _25186 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25186);
        _25186 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _25181 = NOVALUE;
    _25184 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48793 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48795;
    DeRef(_1);
    _25187 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25189 = (object)*(((s1_ptr)_2)->base + _s_48793);
    _2 = (object)SEQ_PTR(_25189);
    _25190 = (object)*(((s1_ptr)_2)->base + 11);
    _25189 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47132);
    if (!IS_ATOM_INT(_25190))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25190)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25190);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48793;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _25181 = NOVALUE;
    _25184 = NOVALUE;
    _25190 = NOVALUE;
    return;
    ;
}


void _54hide_params(object _s_48819)
{
    object _param_48821 = NOVALUE;
    object _25193 = NOVALUE;
    object _25192 = NOVALUE;
    object _25191 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48821 = _s_48819;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25191 = (object)*(((s1_ptr)_2)->base + _s_48819);
    _2 = (object)SEQ_PTR(_25191);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _25192 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _25192 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _25191 = NOVALUE;
    {
        object _i_48823;
        _i_48823 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48823, _25192)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25193 = (object)*(((s1_ptr)_2)->base + _s_48819);
        _2 = (object)SEQ_PTR(_25193);
        _param_48821 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48821)){
            _param_48821 = (object)DBL_PTR(_param_48821)->dbl;
        }
        _25193 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _54Hide(_param_48821);

        /** symtab.e:1131		end for*/
        _0 = _i_48823;
        if (IS_ATOM_INT(_i_48823)) {
            _i_48823 = _i_48823 + 1;
            if ((object)((uintptr_t)_i_48823 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48823 = NewDouble((eudouble)_i_48823);
            }
        }
        else {
            _i_48823 = binary_op_a(PLUS, _i_48823, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48823);
    }

    /** symtab.e:1132	end procedure*/
    _25192 = NOVALUE;
    return;
    ;
}


void _54show_params(object _s_48835)
{
    object _param_48837 = NOVALUE;
    object _25197 = NOVALUE;
    object _25196 = NOVALUE;
    object _25195 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48837 = _s_48835;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25195 = (object)*(((s1_ptr)_2)->base + _s_48835);
    _2 = (object)SEQ_PTR(_25195);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _25196 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _25196 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _25195 = NOVALUE;
    {
        object _i_48839;
        _i_48839 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48839, _25196)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25197 = (object)*(((s1_ptr)_2)->base + _s_48835);
        _2 = (object)SEQ_PTR(_25197);
        _param_48837 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48837)){
            _param_48837 = (object)DBL_PTR(_param_48837)->dbl;
        }
        _25197 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _54Show(_param_48837);

        /** symtab.e:1139		end for*/
        _0 = _i_48839;
        if (IS_ATOM_INT(_i_48839)) {
            _i_48839 = _i_48839 + 1;
            if ((object)((uintptr_t)_i_48839 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48839 = NewDouble((eudouble)_i_48839);
            }
        }
        else {
            _i_48839 = binary_op_a(PLUS, _i_48839, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48839);
    }

    /** symtab.e:1140	end procedure*/
    _25196 = NOVALUE;
    return;
    ;
}


void _54LintCheck(object _s_48851)
{
    object _warn_level_48852 = NOVALUE;
    object _file_48853 = NOVALUE;
    object _vscope_48854 = NOVALUE;
    object _vname_48855 = NOVALUE;
    object _vusage_48856 = NOVALUE;
    object _25258 = NOVALUE;
    object _25257 = NOVALUE;
    object _25256 = NOVALUE;
    object _25255 = NOVALUE;
    object _25254 = NOVALUE;
    object _25253 = NOVALUE;
    object _25251 = NOVALUE;
    object _25250 = NOVALUE;
    object _25249 = NOVALUE;
    object _25248 = NOVALUE;
    object _25247 = NOVALUE;
    object _25246 = NOVALUE;
    object _25243 = NOVALUE;
    object _25242 = NOVALUE;
    object _25241 = NOVALUE;
    object _25240 = NOVALUE;
    object _25239 = NOVALUE;
    object _25238 = NOVALUE;
    object _25236 = NOVALUE;
    object _25234 = NOVALUE;
    object _25233 = NOVALUE;
    object _25231 = NOVALUE;
    object _25230 = NOVALUE;
    object _25228 = NOVALUE;
    object _25227 = NOVALUE;
    object _25226 = NOVALUE;
    object _25225 = NOVALUE;
    object _25223 = NOVALUE;
    object _25222 = NOVALUE;
    object _25218 = NOVALUE;
    object _25215 = NOVALUE;
    object _25214 = NOVALUE;
    object _25213 = NOVALUE;
    object _25212 = NOVALUE;
    object _25209 = NOVALUE;
    object _25208 = NOVALUE;
    object _25203 = NOVALUE;
    object _25201 = NOVALUE;
    object _25199 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48851)) {
        _1 = (object)(DBL_PTR(_s_48851)->dbl);
        DeRefDS(_s_48851);
        _s_48851 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25199 = (object)*(((s1_ptr)_2)->base + _s_48851);
    _2 = (object)SEQ_PTR(_25199);
    _vusage_48856 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_48856)){
        _vusage_48856 = (object)DBL_PTR(_vusage_48856)->dbl;
    }
    _25199 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25201 = (object)*(((s1_ptr)_2)->base + _s_48851);
    _2 = (object)SEQ_PTR(_25201);
    _vscope_48854 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_48854)){
        _vscope_48854 = (object)DBL_PTR(_vscope_48854)->dbl;
    }
    _25201 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25203 = (object)*(((s1_ptr)_2)->base + _s_48851);
    DeRef(_vname_48855);
    _2 = (object)SEQ_PTR(_25203);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _vname_48855 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _vname_48855 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    Ref(_vname_48855);
    _25203 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48856;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48852 = 1;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48852 = 2;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48854 <= 5)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48852 = 0;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25208 = (object)*(((s1_ptr)_2)->base + _s_48851);
        _2 = (object)SEQ_PTR(_25208);
        _25209 = (object)*(((s1_ptr)_2)->base + 3);
        _25208 = NOVALUE;
        if (binary_op_a(NOTEQ, _25209, 2)){
            _25209 = NOVALUE;
            goto L1; // [110] 193
        }
        _25209 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_36Strict_is_on_21836 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48852 = 0;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25212 = (object)*(((s1_ptr)_2)->base + _s_48851);
        _2 = (object)SEQ_PTR(_25212);
        _25213 = (object)*(((s1_ptr)_2)->base + 16);
        _25212 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25214 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
        _2 = (object)SEQ_PTR(_25214);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
            _25215 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
        }
        else{
            _25215 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
        }
        _25214 = NOVALUE;
        if (binary_op_a(LESS, _25213, _25215)){
            _25213 = NOVALUE;
            _25215 = NOVALUE;
            goto L3; // [163] 175
        }
        _25213 = NOVALUE;
        _25215 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48852 = 3;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48852 = 0;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48852 = 0;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48852 != 0)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48853);
    DeRef(_vname_48855);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25218 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21767);
    Ref(_25218);
    RefDS(_22190);
    _0 = _file_48853;
    _file_48853 = _17abbreviate_path(_25218, _22190);
    DeRef(_0);
    _25218 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48852 != 3)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48854 != 5)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25222 = (object)*(((s1_ptr)_2)->base + _s_48851);
    _2 = (object)SEQ_PTR(_25222);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _25223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _25223 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _25222 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21767, _25223)){
        _25223 = NOVALUE;
        goto L7; // [254] 602
    }
    _25223 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48855);
    RefDS(_file_48853);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48853;
    ((intptr_t *)_2)[2] = _vname_48855;
    _25225 = MAKE_SEQ(_1);
    _50Warning(226, 32, _25225);
    _25225 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25226 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25226);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25227 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25227 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25226 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48853);
    ((intptr_t*)_2)[1] = _file_48853;
    RefDS(_vname_48855);
    ((intptr_t*)_2)[2] = _vname_48855;
    Ref(_25227);
    ((intptr_t*)_2)[3] = _25227;
    _25228 = MAKE_SEQ(_1);
    _25227 = NOVALUE;
    _50Warning(227, 32, _25228);
    _25228 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48854 != 5)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25230 = (object)*(((s1_ptr)_2)->base + _s_48851);
    _2 = (object)SEQ_PTR(_25230);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _25231 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _25231 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _25230 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21767, _25231)){
        _25231 = NOVALUE;
        goto L9; // [332] 601
    }
    _25231 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25233 = (object)*(((s1_ptr)_2)->base + _s_48851);
    _2 = (object)SEQ_PTR(_25233);
    _25234 = (object)*(((s1_ptr)_2)->base + 3);
    _25233 = NOVALUE;
    if (binary_op_a(NOTEQ, _25234, 2)){
        _25234 = NOVALUE;
        goto LA; // [352] 372
    }
    _25234 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48855);
    RefDS(_file_48853);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48853;
    ((intptr_t *)_2)[2] = _vname_48855;
    _25236 = MAKE_SEQ(_1);
    _50Warning(228, 16, _25236);
    _25236 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48852 != 1)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48855);
    RefDS(_file_48853);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48853;
    ((intptr_t *)_2)[2] = _vname_48855;
    _25238 = MAKE_SEQ(_1);
    _50Warning(229, 16, _25238);
    _25238 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48855);
    RefDS(_file_48853);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48853;
    ((intptr_t *)_2)[2] = _vname_48855;
    _25239 = MAKE_SEQ(_1);
    _50Warning(320, 16, _25239);
    _25239 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25240 = (object)*(((s1_ptr)_2)->base + _s_48851);
    _2 = (object)SEQ_PTR(_25240);
    _25241 = (object)*(((s1_ptr)_2)->base + 16);
    _25240 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25242 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25242);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21455)){
        _25243 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21455)->dbl));
    }
    else{
        _25243 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21455);
    }
    _25242 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25241, _25243)){
        _25241 = NOVALUE;
        _25243 = NOVALUE;
        goto LC; // [440] 523
    }
    _25241 = NOVALUE;
    _25243 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48852 != 1)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_36Strict_is_on_21836 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25246 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25246);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25247 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25247 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25246 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48853);
    ((intptr_t*)_2)[1] = _file_48853;
    RefDS(_vname_48855);
    ((intptr_t*)_2)[2] = _vname_48855;
    Ref(_25247);
    ((intptr_t*)_2)[3] = _25247;
    _25248 = MAKE_SEQ(_1);
    _25247 = NOVALUE;
    _50Warning(230, 16, _25248);
    _25248 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25249 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25249);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25250 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25250 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25249 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48853);
    ((intptr_t*)_2)[1] = _file_48853;
    RefDS(_vname_48855);
    ((intptr_t*)_2)[2] = _vname_48855;
    Ref(_25250);
    ((intptr_t*)_2)[3] = _25250;
    _25251 = MAKE_SEQ(_1);
    _25250 = NOVALUE;
    _50Warning(321, 16, _25251);
    _25251 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48852 != 1)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_36Strict_is_on_21836 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25253 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25253);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25254 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25254 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25253 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48853);
    ((intptr_t*)_2)[1] = _file_48853;
    RefDS(_vname_48855);
    ((intptr_t*)_2)[2] = _vname_48855;
    Ref(_25254);
    ((intptr_t*)_2)[3] = _25254;
    _25255 = MAKE_SEQ(_1);
    _25254 = NOVALUE;
    _50Warning(231, 16, _25255);
    _25255 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25256 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21775);
    _2 = (object)SEQ_PTR(_25256);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25257 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25257 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25256 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48853);
    ((intptr_t*)_2)[1] = _file_48853;
    RefDS(_vname_48855);
    ((intptr_t*)_2)[2] = _vname_48855;
    Ref(_25257);
    ((intptr_t*)_2)[3] = _25257;
    _25258 = MAKE_SEQ(_1);
    _25257 = NOVALUE;
    _50Warning(322, 16, _25258);
    _25258 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48853);
    DeRef(_vname_48855);
    return;
    ;
}


void _54HideLocals()
{
    object _s_49022 = NOVALUE;
    object _25271 = NOVALUE;
    object _25269 = NOVALUE;
    object _25268 = NOVALUE;
    object _25267 = NOVALUE;
    object _25266 = NOVALUE;
    object _25265 = NOVALUE;
    object _25264 = NOVALUE;
    object _25263 = NOVALUE;
    object _25262 = NOVALUE;
    object _25261 = NOVALUE;
    object _25260 = NOVALUE;
    object _25259 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _54mark_rechecks(_36current_file_no_21767);

    /** symtab.e:1245		s = file_start_sym*/
    _s_49022 = _36file_start_sym_21773;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_49022 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25259 = (object)*(((s1_ptr)_2)->base + _s_49022);
    _2 = (object)SEQ_PTR(_25259);
    _25260 = (object)*(((s1_ptr)_2)->base + 4);
    _25259 = NOVALUE;
    if (IS_ATOM_INT(_25260)) {
        _25261 = (_25260 == 5);
    }
    else {
        _25261 = binary_op(EQUALS, _25260, 5);
    }
    _25260 = NOVALUE;
    if (IS_ATOM_INT(_25261)) {
        if (_25261 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25261)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25263 = (object)*(((s1_ptr)_2)->base + _s_49022);
    _2 = (object)SEQ_PTR(_25263);
    if (!IS_ATOM_INT(_36S_FILE_NO_21400)){
        _25264 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21400)->dbl));
    }
    else{
        _25264 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21400);
    }
    _25263 = NOVALUE;
    if (IS_ATOM_INT(_25264)) {
        _25265 = (_25264 == _36current_file_no_21767);
    }
    else {
        _25265 = binary_op(EQUALS, _25264, _36current_file_no_21767);
    }
    _25264 = NOVALUE;
    if (_25265 == 0) {
        DeRef(_25265);
        _25265 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25265) && DBL_PTR(_25265)->dbl == 0.0){
            DeRef(_25265);
            _25265 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25265);
        _25265 = NOVALUE;
    }
    DeRef(_25265);
    _25265 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25266 = (_65current_block_25440 == _65top_level_block_25441);
    if (_25266 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _54Hide(_s_49022);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25268 = (object)*(((s1_ptr)_2)->base + _s_49022);
    _2 = (object)SEQ_PTR(_25268);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _25269 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _25269 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _25268 = NOVALUE;
    if (binary_op_a(NOTEQ, _25269, -100)){
        _25269 = NOVALUE;
        goto L6; // [116] 126
    }
    _25269 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _54LintCheck(_s_49022);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25271 = (object)*(((s1_ptr)_2)->base + _s_49022);
    _2 = (object)SEQ_PTR(_25271);
    _s_49022 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_49022)){
        _s_49022 = (object)DBL_PTR(_s_49022)->dbl;
    }
    _25271 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25261);
    _25261 = NOVALUE;
    DeRef(_25266);
    _25266 = NOVALUE;
    return;
    ;
}


object _54sym_name(object _sym_49061)
{
    object _25274 = NOVALUE;
    object _25273 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49061)) {
        _1 = (object)(DBL_PTR(_sym_49061)->dbl);
        DeRefDS(_sym_49061);
        _sym_49061 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25273 = (object)*(((s1_ptr)_2)->base + _sym_49061);
    _2 = (object)SEQ_PTR(_25273);
    if (!IS_ATOM_INT(_36S_NAME_21404)){
        _25274 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21404)->dbl));
    }
    else{
        _25274 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21404);
    }
    _25273 = NOVALUE;
    Ref(_25274);
    return _25274;
    ;
}


object _54sym_token(object _sym_49069)
{
    object _25276 = NOVALUE;
    object _25275 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49069)) {
        _1 = (object)(DBL_PTR(_sym_49069)->dbl);
        DeRefDS(_sym_49069);
        _sym_49069 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25275 = (object)*(((s1_ptr)_2)->base + _sym_49069);
    _2 = (object)SEQ_PTR(_25275);
    if (!IS_ATOM_INT(_36S_TOKEN_21409)){
        _25276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21409)->dbl));
    }
    else{
        _25276 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21409);
    }
    _25275 = NOVALUE;
    Ref(_25276);
    return _25276;
    ;
}


object _54sym_scope(object _sym_49077)
{
    object _25278 = NOVALUE;
    object _25277 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49077)) {
        _1 = (object)(DBL_PTR(_sym_49077)->dbl);
        DeRefDS(_sym_49077);
        _sym_49077 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25277 = (object)*(((s1_ptr)_2)->base + _sym_49077);
    _2 = (object)SEQ_PTR(_25277);
    _25278 = (object)*(((s1_ptr)_2)->base + 4);
    _25277 = NOVALUE;
    Ref(_25278);
    return _25278;
    ;
}


object _54sym_mode(object _sym_49085)
{
    object _25280 = NOVALUE;
    object _25279 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49085)) {
        _1 = (object)(DBL_PTR(_sym_49085)->dbl);
        DeRefDS(_sym_49085);
        _sym_49085 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25279 = (object)*(((s1_ptr)_2)->base + _sym_49085);
    _2 = (object)SEQ_PTR(_25279);
    _25280 = (object)*(((s1_ptr)_2)->base + 3);
    _25279 = NOVALUE;
    Ref(_25280);
    return _25280;
    ;
}


object _54sym_obj(object _sym_49093)
{
    object _25282 = NOVALUE;
    object _25281 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49093)) {
        _1 = (object)(DBL_PTR(_sym_49093)->dbl);
        DeRefDS(_sym_49093);
        _sym_49093 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25281 = (object)*(((s1_ptr)_2)->base + _sym_49093);
    _2 = (object)SEQ_PTR(_25281);
    _25282 = (object)*(((s1_ptr)_2)->base + 1);
    _25281 = NOVALUE;
    Ref(_25282);
    return _25282;
    ;
}


object _54sym_next(object _sym_49101)
{
    object _25284 = NOVALUE;
    object _25283 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25283 = (object)*(((s1_ptr)_2)->base + _sym_49101);
    _2 = (object)SEQ_PTR(_25283);
    _25284 = (object)*(((s1_ptr)_2)->base + 2);
    _25283 = NOVALUE;
    Ref(_25284);
    return _25284;
    ;
}


object _54sym_block(object _sym_49109)
{
    object _25286 = NOVALUE;
    object _25285 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25285 = (object)*(((s1_ptr)_2)->base + _sym_49109);
    _2 = (object)SEQ_PTR(_25285);
    if (!IS_ATOM_INT(_36S_BLOCK_21424)){
        _25286 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21424)->dbl));
    }
    else{
        _25286 = (object)*(((s1_ptr)_2)->base + _36S_BLOCK_21424);
    }
    _25285 = NOVALUE;
    Ref(_25286);
    return _25286;
    ;
}


object _54sym_next_in_block(object _sym_49117)
{
    object _25288 = NOVALUE;
    object _25287 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25287 = (object)*(((s1_ptr)_2)->base + _sym_49117);
    _2 = (object)SEQ_PTR(_25287);
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21396)){
        _25288 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21396)->dbl));
    }
    else{
        _25288 = (object)*(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21396);
    }
    _25287 = NOVALUE;
    Ref(_25288);
    return _25288;
    ;
}


object _54sym_usage(object _sym_49125)
{
    object _25290 = NOVALUE;
    object _25289 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25289 = (object)*(((s1_ptr)_2)->base + _sym_49125);
    _2 = (object)SEQ_PTR(_25289);
    _25290 = (object)*(((s1_ptr)_2)->base + 5);
    _25289 = NOVALUE;
    Ref(_25290);
    return _25290;
    ;
}



// 0xB016D33A
