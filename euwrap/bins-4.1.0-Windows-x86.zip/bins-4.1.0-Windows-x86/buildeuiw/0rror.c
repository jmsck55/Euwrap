// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49screen_output(object _f_49653, object _msg_49654)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2, _msg_49654); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49654);
    return;
    ;
}


void _49Warning(object _msg_49657, object _mask_49658, object _args_49659)
{
    object _orig_mask_49660 = NOVALUE;
    object _text_49661 = NOVALUE;
    object _w_name_49662 = NOVALUE;
    object _25527 = NOVALUE;
    object _25525 = NOVALUE;
    object _25523 = NOVALUE;
    object _25520 = NOVALUE;
    object _25515 = NOVALUE;
    object _25513 = NOVALUE;
    object _25512 = NOVALUE;
    object _25511 = NOVALUE;
    object _25510 = NOVALUE;
    object _25508 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/
    if (_49display_warnings_49641 != 0)
    goto L1; // [9] 19

    /** error.e:55			return*/
    DeRef(_msg_49657);
    DeRefDS(_args_49659);
    DeRef(_text_49661);
    DeRef(_w_name_49662);
    return;
L1: 

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25508 = (_27Strict_is_on_20637 == 0);
    if (_25508 != 0) {
        goto L2; // [26] 37
    }
    if (_27Strict_Override_20638 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25510 = find_from(_mask_49658, _27strict_only_warnings_20635, 1);
    if (_25510 == 0)
    {
        _25510 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25510 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49657);
    DeRefDS(_args_49659);
    DeRef(_text_49661);
    DeRef(_w_name_49662);
    DeRef(_25508);
    _25508 = NOVALUE;
    return;
L4: 
L3: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49660 = _mask_49658;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_27Strict_is_on_20637 == 0) {
        goto L5; // [65] 85
    }
    _25512 = (_27Strict_Override_20638 == 0);
    if (_25512 == 0)
    {
        DeRef(_25512);
        _25512 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25512);
        _25512 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49658 = 0;
L5: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25513 = (_mask_49658 == 0);
    if (_25513 != 0) {
        goto L6; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_27OpWarning_20639 & (uintptr_t)_mask_49658;
         _25515 = MAKE_UINT(tu);
    }
    if (_25515 == 0) {
        DeRef(_25515);
        _25515 = NOVALUE;
        goto L7; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25515) && DBL_PTR(_25515)->dbl == 0.0){
            DeRef(_25515);
            _25515 = NOVALUE;
            goto L7; // [102] 215
        }
        DeRef(_25515);
        _25515 = NOVALUE;
    }
    DeRef(_25515);
    _25515 = NOVALUE;
L6: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49660 == 0)
    goto L8; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49660 = find_from(_orig_mask_49660, _27warning_flags_20614, 1);
L8: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49660 == 0)
    goto L9; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_27warning_names_20616);
    _25520 = (object)*(((s1_ptr)_2)->base + _orig_mask_49660);
    {
        object concat_list[3];

        concat_list[0] = _25521;
        concat_list[1] = _25520;
        concat_list[2] = _25519;
        Concat_N((object_ptr)&_w_name_49662, concat_list, 3);
    }
    _25520 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_22209);
    DeRef(_w_name_49662);
    _w_name_49662 = _22209;
LA: 

    /** error.e:80			if atom(msg) then*/
    _25523 = IS_ATOM(_msg_49657);
    if (_25523 == 0)
    {
        _25523 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25523 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49657);
    RefDS(_args_49659);
    _0 = _msg_49657;
    _msg_49657 = _30GetMsgText(_msg_49657, 1, _args_49659);
    DeRef(_0);
LB: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49657);
    RefDS(_w_name_49662);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49662;
    ((intptr_t *)_2)[2] = _msg_49657;
    _25525 = MAKE_SEQ(_1);
    _0 = _text_49661;
    _text_49661 = _30GetMsgText(204, 0, _25525);
    DeRef(_0);
    _25525 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25527 = find_from(_text_49661, _49warning_list_49650, 1);
    if (_25527 == 0)
    {
        _25527 = NOVALUE;
        goto LC; // [197] 206
    }
    else{
        _25527 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49657);
    DeRefDS(_args_49659);
    DeRefDS(_text_49661);
    DeRefDS(_w_name_49662);
    DeRef(_25508);
    _25508 = NOVALUE;
    DeRef(_25513);
    _25513 = NOVALUE;
    return;
LC: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49661);
    Append(&_49warning_list_49650, _49warning_list_49650, _text_49661);
L7: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49657);
    DeRefDS(_args_49659);
    DeRef(_text_49661);
    DeRef(_w_name_49662);
    DeRef(_25508);
    _25508 = NOVALUE;
    DeRef(_25513);
    _25513 = NOVALUE;
    return;
    ;
}


object _49ShowWarnings()
{
    object _c_49727 = NOVALUE;
    object _errfile_49728 = NOVALUE;
    object _twf_49729 = NOVALUE;
    object _25566 = NOVALUE;
    object _25563 = NOVALUE;
    object _25562 = NOVALUE;
    object _25561 = NOVALUE;
    object _25560 = NOVALUE;
    object _25559 = NOVALUE;
    object _25558 = NOVALUE;
    object _25556 = NOVALUE;
    object _25555 = NOVALUE;
    object _25554 = NOVALUE;
    object _25552 = NOVALUE;
    object _25551 = NOVALUE;
    object _25550 = NOVALUE;
    object _25549 = NOVALUE;
    object _25547 = NOVALUE;
    object _25543 = NOVALUE;
    object _25541 = NOVALUE;
    object _25540 = NOVALUE;
    object _25539 = NOVALUE;
    object _25537 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25537 = (_49display_warnings_49641 == 0);
    if (_25537 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_49warning_list_49650)){
            _25539 = SEQ_PTR(_49warning_list_49650)->length;
    }
    else {
        _25539 = 1;
    }
    _25540 = (_25539 == 0);
    _25539 = NOVALUE;
    if (_25540 == 0)
    {
        DeRef(_25540);
        _25540 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25540);
        _25540 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49650)){
            _25541 = SEQ_PTR(_49warning_list_49650)->length;
    }
    else {
        _25541 = 1;
    }
    DeRef(_25537);
    _25537 = NOVALUE;
    return _25541;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_49TempErrFile_49639 <= 0)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49728 = _49TempErrFile_49639;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49728 = 2;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_27TempWarningName_20585))
    _25543 = 1;
    else if (IS_ATOM_DBL(_27TempWarningName_20585))
    _25543 = IS_ATOM_INT(DoubleToInt(_27TempWarningName_20585));
    else
    _25543 = 0;
    if (_25543 != 0)
    goto L5; // [74] 183
    _25543 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49729 = EOpen(_27TempWarningName_20585, _22345, 0);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49729 != -1)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27TempWarningName_20585);
    ((intptr_t*)_2)[1] = _27TempWarningName_20585;
    _25547 = MAKE_SEQ(_1);
    _30ShowMsg(_errfile_49728, 205, _25547, 1);
    _25547 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49728 == 2)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27TempWarningName_20585);
    ((intptr_t*)_2)[1] = _27TempWarningName_20585;
    _25549 = MAKE_SEQ(_1);
    _30ShowMsg(2, 205, _25549, 1);
    _25549 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49650)){
            _25550 = SEQ_PTR(_49warning_list_49650)->length;
    }
    else {
        _25550 = 1;
    }
    {
        object _i_49762;
        _i_49762 = 1;
L8: 
        if (_i_49762 > _25550){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49650);
        _25551 = (object)*(((s1_ptr)_2)->base + _i_49762);
        EPuts(_twf_49729, _25551); // DJP 
        _25551 = NOVALUE;

        /** error.e:137				end for*/
        _i_49762 = _i_49762 + 1;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49729);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_27TempWarningName_20585);
    _27TempWarningName_20585 = 99;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25552 = (_27batch_job_20584 == 0);
    if (_25552 != 0) {
        goto LA; // [191] 208
    }
    _25554 = (_errfile_49728 != 2);
    if (_25554 == 0)
    {
        DeRef(_25554);
        _25554 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25554);
        _25554 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_49warning_list_49650)){
            _25555 = SEQ_PTR(_49warning_list_49650)->length;
    }
    else {
        _25555 = 1;
    }
    {
        object _i_49773;
        _i_49773 = 1;
LC: 
        if (_i_49773 > _25555){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_49warning_list_49650);
        _25556 = (object)*(((s1_ptr)_2)->base + _i_49773);
        EPuts(_errfile_49728, _25556); // DJP 
        _25556 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49728 != 2)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25558 = (_i_49773 % 20);
        _25559 = (_25558 == 0);
        _25558 = NOVALUE;
        if (_25559 == 0) {
            _25560 = 0;
            goto LF; // [253] 267
        }
        _25561 = (_27batch_job_20584 == 0);
        _25560 = (_25561 != 0);
LF: 
        if (_25560 == 0) {
            goto L10; // [267] 308
        }
        _25563 = (_27test_only_20583 == 0);
        if (_25563 == 0)
        {
            DeRef(_25563);
            _25563 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25563);
            _25563 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_22209);
        _30ShowMsg(_errfile_49728, 206, _22209, 1);

        /** error.e:149						c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_49727 = getKBchar();
            }
            else{
                _c_49727 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49727 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49727 != 113)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49773 = _i_49773 + 1;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_49warning_list_49650)){
            _25566 = SEQ_PTR(_49warning_list_49650)->length;
    }
    else {
        _25566 = 1;
    }
    DeRef(_25559);
    _25559 = NOVALUE;
    DeRef(_25537);
    _25537 = NOVALUE;
    DeRef(_25552);
    _25552 = NOVALUE;
    DeRef(_25561);
    _25561 = NOVALUE;
    return _25566;
    ;
}


void _49ShowDefines(object _errfile_49796)
{
    object _c_49797 = NOVALUE;
    object _25580 = NOVALUE;
    object _25579 = NOVALUE;
    object _25577 = NOVALUE;
    object _25576 = NOVALUE;
    object _25573 = NOVALUE;
    object _25572 = NOVALUE;
    object _25571 = NOVALUE;
    object _25570 = NOVALUE;
    object _25569 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49796 != 0)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49796 = 2;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_22209);
    _25569 = _30GetMsgText(207, 0, _22209);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25569;
    _25570 = MAKE_SEQ(_1);
    _25569 = NOVALUE;
    RefDS(_25568);
    _25571 = _12format(_25568, _25570);
    _25570 = NOVALUE;
    EPuts(_errfile_49796, _25571); // DJP 
    DeRef(_25571);
    _25571 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_27OpDefines_20645)){
            _25572 = SEQ_PTR(_27OpDefines_20645)->length;
    }
    else {
        _25572 = 1;
    }
    {
        object _i_49809;
        _i_49809 = 1;
L2: 
        if (_i_49809 > _25572){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_27OpDefines_20645);
        _25573 = (object)*(((s1_ptr)_2)->base + _i_49809);
        RefDS(_25575);
        RefDS(_25574);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25574;
        ((intptr_t *)_2)[2] = _25575;
        _25576 = MAKE_SEQ(_1);
        _25577 = find_from(_25573, _25576, 1);
        _25573 = NOVALUE;
        DeRefDS(_25576);
        _25576 = NOVALUE;
        if (_25577 != 0)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_27OpDefines_20645);
        _25579 = (object)*(((s1_ptr)_2)->base + _i_49809);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25579);
        ((intptr_t*)_2)[1] = _25579;
        _25580 = MAKE_SEQ(_1);
        _25579 = NOVALUE;
        EPrintf(_errfile_49796, _25461, _25580);
        DeRefDS(_25580);
        _25580 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49809 = _i_49809 + 1;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49796, _25581); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _49Cleanup(object _status_49826)
{
    object _w_49827 = NOVALUE;
    object _show_error_49828 = NOVALUE;
    object _31991 = NOVALUE;
    object _25599 = NOVALUE;
    object _25598 = NOVALUE;
    object _25597 = NOVALUE;
    object _25596 = NOVALUE;
    object _25595 = NOVALUE;
    object _25594 = NOVALUE;
    object _25593 = NOVALUE;
    object _25592 = NOVALUE;
    object _25591 = NOVALUE;
    object _25590 = NOVALUE;
    object _25588 = NOVALUE;
    object _25587 = NOVALUE;
    object _25586 = NOVALUE;
    object _25585 = NOVALUE;
    object _25584 = NOVALUE;
    object _25582 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_49826)) {
        _1 = (object)(DBL_PTR(_status_49826)->dbl);
        DeRefDS(_status_49826);
        _status_49826 = _1;
    }

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49828 = 0;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:187			write_coverage_db()*/
    _31991 = _50write_coverage_db();
    DeRef(_31991);
    _31991 = NOVALUE;

    /** error.e:190		show_error = 1*/
    _show_error_49828 = 1;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _27src_file_20693 ){
        _25582 = 0;
    }
    else{
        _25582 = 1;
    }
    if (_25582 != 0)
    goto L1; // [27] 41

    /** error.e:197			src_file = -1*/
    _27src_file_20693 = -1;
    goto L2; // [38] 93
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25584 = (_27src_file_20693 >= 0);
    if (_25584 == 0) {
        goto L3; // [49] 92
    }
    _25586 = (_27src_file_20693 != 5555);
    if (_25586 != 0) {
        DeRef(_25587);
        _25587 = 1;
        goto L4; // [61] 74
    }
    _25588 = (0 == 0);
    _25587 = (_25588 != 0);
L4: 
    if (_25587 == 0)
    {
        _25587 = NOVALUE;
        goto L3; // [75] 92
    }
    else{
        _25587 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_27src_file_20693);

    /** error.e:200			src_file = -1*/
    _27src_file_20693 = -1;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49827 = _49ShowWarnings();
    if (!IS_ATOM_INT(_w_49827)) {
        _1 = (object)(DBL_PTR(_w_49827)->dbl);
        DeRefDS(_w_49827);
        _w_49827 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25590 = (_27TRANSLATE_20179 == 0);
    if (_25590 == 0) {
        _25591 = 0;
        goto L5; // [107] 125
    }
    if (_27BIND_20182 != 0) {
        _25592 = 1;
        goto L6; // [113] 121
    }
    _25592 = (_show_error_49828 != 0);
L6: 
    _25591 = (_25592 != 0);
L5: 
    if (_25591 == 0) {
        goto L7; // [125] 186
    }
    if (_w_49827 != 0) {
        DeRef(_25594);
        _25594 = 1;
        goto L8; // [129] 139
    }
    _25594 = (_49Errors_49638 != 0);
L8: 
    if (_25594 == 0)
    {
        _25594 = NOVALUE;
        goto L7; // [140] 186
    }
    else{
        _25594 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25595 = (_27batch_job_20584 == 0);
    if (_25595 == 0) {
        goto L9; // [150] 185
    }
    _25597 = (_27test_only_20583 == 0);
    if (_25597 == 0)
    {
        DeRef(_25597);
        _25597 = NOVALUE;
        goto L9; // [160] 185
    }
    else{
        DeRef(_25597);
        _25597 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_22209);
    _25598 = _30GetMsgText(208, 0, _22209);
    _49screen_output(2, _25598);
    _25598 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25599 = getKBchar();
        }
        else{
            _25599 = getc(last_r_file_ptr);
        }
    }
    else{
        _25599 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _61cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49826);

    /** error.e:214	end procedure*/
    DeRef(_25586);
    _25586 = NOVALUE;
    DeRef(_25595);
    _25595 = NOVALUE;
    DeRef(_25588);
    _25588 = NOVALUE;
    DeRef(_25590);
    _25590 = NOVALUE;
    DeRef(_25584);
    _25584 = NOVALUE;
    return;
    ;
}


void _49OpenErrFile()
{
    object _25606 = NOVALUE;
    object _25605 = NOVALUE;
    object _25603 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_49TempErrFile_49639 == -1)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _49TempErrFile_49639 = EOpen(_49TempErrName_49640, _22345, 0);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_49TempErrFile_49639 != -1)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25603 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_49TempErrName_49640);
    ((intptr_t*)_2)[1] = _49TempErrName_49640;
    _25605 = MAKE_SEQ(_1);
    _25606 = _30GetMsgText(209, 0, _25605);
    _25605 = NOVALUE;
    _49screen_output(2, _25606);
    _25606 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _49ShowErr(object _f_49885)
{
    object _msg_inlined_screen_output_at_43_49898 = NOVALUE;
    object _25613 = NOVALUE;
    object _25612 = NOVALUE;
    object _25611 = NOVALUE;
    object _25609 = NOVALUE;
    object _25607 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _25607 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _25607 = 1;
    }
    if (_25607 != 0)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_49ThisLine_49642);
    _25609 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25609, 26)){
        _25609 = NOVALUE;
        goto L2; // [30] 64
    }
    _25609 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_22209);
    _25611 = _30GetMsgText(210, 0, _22209);
    DeRef(_msg_inlined_screen_output_at_43_49898);
    _msg_inlined_screen_output_at_43_49898 = _25611;
    _25611 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49885, _msg_inlined_screen_output_at_43_49898); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49898);
    _msg_inlined_screen_output_at_43_49898 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49885, _49ThisLine_49642); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25612 = _49bp_49646 - 2;
    if ((object)((uintptr_t)_25612 +(uintptr_t) HIGH_BITS) >= 0){
        _25612 = NewDouble((eudouble)_25612);
    }
    {
        object _i_49902;
        _i_49902 = 1;
L6: 
        if (binary_op_a(GREATER, _i_49902, _25612)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_49ThisLine_49642);
        if (!IS_ATOM_INT(_i_49902)){
            _25613 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49902)->dbl));
        }
        else{
            _25613 = (object)*(((s1_ptr)_2)->base + _i_49902);
        }
        if (binary_op_a(NOTEQ, _25613, 9)){
            _25613 = NOVALUE;
            goto L8; // [104] 123
        }
        _25613 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49885, _24171); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49885, _23595); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49902;
        if (IS_ATOM_INT(_i_49902)) {
            _i_49902 = _i_49902 + 1;
            if ((object)((uintptr_t)_i_49902 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49902 = NewDouble((eudouble)_i_49902);
            }
        }
        else {
            _i_49902 = binary_op_a(PLUS, _i_49902, 1);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49902);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49885, _25615); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25612);
    _25612 = NOVALUE;
    return;
    ;
}


void _49CompileErr(object _msg_49914, object _args_49915, object _preproc_49916)
{
    object _errmsg_49917 = NOVALUE;
    object _25636 = NOVALUE;
    object _25632 = NOVALUE;
    object _25631 = NOVALUE;
    object _25630 = NOVALUE;
    object _25629 = NOVALUE;
    object _25628 = NOVALUE;
    object _25627 = NOVALUE;
    object _25625 = NOVALUE;
    object _25624 = NOVALUE;
    object _25622 = NOVALUE;
    object _25621 = NOVALUE;
    object _25620 = NOVALUE;
    object _25616 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49914))
    _25616 = 1;
    else if (IS_ATOM_DBL(_msg_49914))
    _25616 = IS_ATOM_INT(DoubleToInt(_msg_49914));
    else
    _25616 = 0;
    if (_25616 == 0)
    {
        _25616 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25616 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49914);
    RefDS(_22209);
    _0 = _msg_49914;
    _msg_49914 = _30GetMsgText(_msg_49914, 1, _22209);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49914);
    Ref(_args_49915);
    _0 = _msg_49914;
    _msg_49914 = _12format(_msg_49914, _args_49915);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _49Errors_49638 = _49Errors_49638 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25620 = (_preproc_49916 == 0);
    if (_25620 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _25622 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _25622 = 1;
    }
    if (_25622 == 0)
    {
        _25622 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25622 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25624 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25624);
    ((intptr_t*)_2)[1] = _25624;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    Ref(_msg_49914);
    ((intptr_t*)_2)[3] = _msg_49914;
    _25625 = MAKE_SEQ(_1);
    _25624 = NOVALUE;
    DeRef(_errmsg_49917);
    _errmsg_49917 = EPrintf(-9999999, _25623, _25625);
    DeRefDS(_25625);
    _25625 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49914);
    DeRef(_errmsg_49917);
    _errmsg_49917 = _msg_49914;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49914)){
            _25627 = SEQ_PTR(_msg_49914)->length;
    }
    else {
        _25627 = 1;
    }
    _25628 = (_25627 > 0);
    _25627 = NOVALUE;
    if (_25628 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49914)){
            _25630 = SEQ_PTR(_msg_49914)->length;
    }
    else {
        _25630 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49914);
    _25631 = (object)*(((s1_ptr)_2)->base + _25630);
    if (IS_ATOM_INT(_25631)) {
        _25632 = (_25631 != 10);
    }
    else {
        _25632 = binary_op(NOTEQ, _25631, 10);
    }
    _25631 = NOVALUE;
    if (_25632 == 0) {
        DeRef(_25632);
        _25632 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25632) && DBL_PTR(_25632)->dbl == 0.0){
            DeRef(_25632);
            _25632 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25632);
        _25632 = NOVALUE;
    }
    DeRef(_25632);
    _25632 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49917, _errmsg_49917, 10);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49916 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _49OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49917);
    _49screen_output(2, _errmsg_49917);

    /** error.e:283		if not preproc then*/
    if (_preproc_49916 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _49ShowErr(2);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_49TempErrFile_49639, _errmsg_49917); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _49ShowErr(_49TempErrFile_49639);

    /** error.e:290			ShowWarnings()*/
    _25636 = _49ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _49ShowDefines(_49TempErrFile_49639);

    /** error.e:294			close(TempErrFile)*/
    EClose(_49TempErrFile_49639);

    /** error.e:295			TempErrFile = -2*/
    _49TempErrFile_49639 = -2;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _49Cleanup(1);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49914);
    DeRef(_args_49915);
    DeRef(_errmsg_49917);
    DeRef(_25620);
    _25620 = NOVALUE;
    DeRef(_25628);
    _25628 = NOVALUE;
    DeRef(_25636);
    _25636 = NOVALUE;
    return;
    ;
}


void _49InternalErr(object _msgno_49961, object _args_49962)
{
    object _msg_49963 = NOVALUE;
    object _25651 = NOVALUE;
    object _25650 = NOVALUE;
    object _25649 = NOVALUE;
    object _25648 = NOVALUE;
    object _25647 = NOVALUE;
    object _25646 = NOVALUE;
    object _25645 = NOVALUE;
    object _25644 = NOVALUE;
    object _25643 = NOVALUE;
    object _25642 = NOVALUE;
    object _25641 = NOVALUE;
    object _25638 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25638 = 0;
    if (_25638 == 0)
    {
        _25638 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25638 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49962;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49962);
    ((intptr_t*)_2)[1] = _args_49962;
    _args_49962 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49962);
    _0 = _msg_49963;
    _msg_49963 = _30GetMsgText(_msgno_49961, 1, _args_49962);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49963);
    ((intptr_t*)_2)[1] = _msg_49963;
    _25641 = MAKE_SEQ(_1);
    _25642 = _30GetMsgText(211, 1, _25641);
    _25641 = NOVALUE;
    _49screen_output(2, _25642);
    _25642 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25643 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25643);
    ((intptr_t*)_2)[1] = _25643;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_msg_49963);
    ((intptr_t*)_2)[3] = _msg_49963;
    _25644 = MAKE_SEQ(_1);
    _25643 = NOVALUE;
    _25645 = _30GetMsgText(212, 1, _25644);
    _25644 = NOVALUE;
    _49screen_output(2, _25645);
    _25645 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25646 = (_27batch_job_20584 == 0);
    if (_25646 == 0) {
        goto L4; // [98] 133
    }
    _25648 = (_27test_only_20583 == 0);
    if (_25648 == 0)
    {
        DeRef(_25648);
        _25648 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25648);
        _25648 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_22209);
    _25649 = _30GetMsgText(208, 0, _22209);
    _49screen_output(2, _25649);
    _25649 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25650 = getKBchar();
        }
        else{
            _25650 = getc(last_r_file_ptr);
        }
    }
    else{
        _25650 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_22209);
    _25651 = _30GetMsgText(213, 1, _22209);
    machine(67, _25651);
    DeRef(_25651);
    _25651 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49962);
    DeRef(_msg_49963);
    DeRef(_25646);
    _25646 = NOVALUE;
    return;
    ;
}



// 0x8E3E54CA
