// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46convert_from_OEM(object _s_50746)
{
    object _ls_50747 = NOVALUE;
    object _rc_50748 = NOVALUE;
    object _26047 = NOVALUE;
    object _26046 = NOVALUE;
    object _26044 = NOVALUE;
    object _26043 = NOVALUE;
    object _26040 = NOVALUE;
    object _26039 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:37		ls=length(s)*/
    if (IS_SEQUENCE(_s_50746)){
            _ls_50747 = SEQ_PTR(_s_50746)->length;
    }
    else {
        _ls_50747 = 1;
    }

    /** pathopen.e:38		if ls>convert_length then*/
    if (_ls_50747 <= _46convert_length_50726)
    goto L1; // [12] 47

    /** pathopen.e:39			free(convert_buffer)*/
    Ref(_46convert_buffer_50725);
    _6free(_46convert_buffer_50725);

    /** pathopen.e:40			convert_length=and_bits(ls+15,-16)+1*/
    _26039 = _ls_50747 + 15;
    {uintptr_t tu;
         tu = (uintptr_t)_26039 & (uintptr_t)-16;
         _26040 = MAKE_UINT(tu);
    }
    _26039 = NOVALUE;
    if (IS_ATOM_INT(_26040)) {
        _46convert_length_50726 = _26040 + 1;
    }
    else
    { // coercing _46convert_length_50726 to an integer 1
        _46convert_length_50726 = 1+(object)(DBL_PTR(_26040)->dbl);
        if( !IS_ATOM_INT(_46convert_length_50726) ){
            _46convert_length_50726 = (object)DBL_PTR(_46convert_length_50726)->dbl;
        }
    }
    DeRef(_26040);
    _26040 = NOVALUE;

    /** pathopen.e:41			convert_buffer=allocate(convert_length)*/
    _0 = _6allocate(_46convert_length_50726, 0);
    DeRef(_46convert_buffer_50725);
    _46convert_buffer_50725 = _0;
L1: 

    /** pathopen.e:43		poke(convert_buffer,s)*/
    if (IS_ATOM_INT(_46convert_buffer_50725)){
        poke_addr = (uint8_t *)_46convert_buffer_50725;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_46convert_buffer_50725)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_50746);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** pathopen.e:44		poke(convert_buffer+ls,0)*/
    if (IS_ATOM_INT(_46convert_buffer_50725)) {
        _26043 = _46convert_buffer_50725 + _ls_50747;
        if ((object)((uintptr_t)_26043 + (uintptr_t)HIGH_BITS) >= 0){
            _26043 = NewDouble((eudouble)_26043);
        }
    }
    else {
        _26043 = NewDouble(DBL_PTR(_46convert_buffer_50725)->dbl + (eudouble)_ls_50747);
    }
    if (IS_ATOM_INT(_26043)){
        poke_addr = (uint8_t *)_26043;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_26043)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_26043);
    _26043 = NOVALUE;

    /** pathopen.e:45		rc=c_func(oem2char,{convert_buffer,convert_buffer}) -- always nonzero*/
    Ref(_46convert_buffer_50725);
    Ref(_46convert_buffer_50725);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _46convert_buffer_50725;
    ((intptr_t *)_2)[2] = _46convert_buffer_50725;
    _26044 = MAKE_SEQ(_1);
    _rc_50748 = call_c(1, _46oem2char_50724, _26044);
    DeRefDS(_26044);
    _26044 = NOVALUE;
    if (!IS_ATOM_INT(_rc_50748)) {
        _1 = (object)(DBL_PTR(_rc_50748)->dbl);
        DeRefDS(_rc_50748);
        _rc_50748 = _1;
    }

    /** pathopen.e:46		return peek({convert_buffer,ls}) */
    Ref(_46convert_buffer_50725);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _46convert_buffer_50725;
    ((intptr_t *)_2)[2] = _ls_50747;
    _26046 = MAKE_SEQ(_1);
    _1 = (object)SEQ_PTR(_26046);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _26047 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_26046);
    _26046 = NOVALUE;
    DeRefDS(_s_50746);
    return _26047;
    ;
}


object _46exe_path()
{
    object _26051 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _26051 = IS_SEQUENCE(_46exe_path_cache_50778);
    if (_26051 == 0)
    {
        _26051 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _26051 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_46exe_path_cache_50778);
    return _46exe_path_cache_50778;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_46exe_path_cache_50778);
    _46exe_path_cache_50778 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _46exe_path_cache_50778;
    _2 = (object)SEQ_PTR(_46exe_path_cache_50778);
    _46exe_path_cache_50778 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_46exe_path_cache_50778);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_46exe_path_cache_50778);
    return _46exe_path_cache_50778;
    ;
}


object _46check_cache(object _env_50790, object _inc_path_50791)
{
    object _delim_50792 = NOVALUE;
    object _pos_50793 = NOVALUE;
    object _26102 = NOVALUE;
    object _26101 = NOVALUE;
    object _26100 = NOVALUE;
    object _26099 = NOVALUE;
    object _26097 = NOVALUE;
    object _26096 = NOVALUE;
    object _26095 = NOVALUE;
    object _26094 = NOVALUE;
    object _26093 = NOVALUE;
    object _26092 = NOVALUE;
    object _26091 = NOVALUE;
    object _26090 = NOVALUE;
    object _26089 = NOVALUE;
    object _26088 = NOVALUE;
    object _26087 = NOVALUE;
    object _26083 = NOVALUE;
    object _26082 = NOVALUE;
    object _26081 = NOVALUE;
    object _26080 = NOVALUE;
    object _26079 = NOVALUE;
    object _26078 = NOVALUE;
    object _26077 = NOVALUE;
    object _26076 = NOVALUE;
    object _26074 = NOVALUE;
    object _26073 = NOVALUE;
    object _26072 = NOVALUE;
    object _26071 = NOVALUE;
    object _26070 = NOVALUE;
    object _26069 = NOVALUE;
    object _26067 = NOVALUE;
    object _26066 = NOVALUE;
    object _26065 = NOVALUE;
    object _26064 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_46num_var_50767 != 0)
    goto L1; // [9] 94

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50790);
    Append(&_46cache_vars_50768, _46cache_vars_50768, _env_50790);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50791);
    Append(&_46cache_strings_50769, _46cache_strings_50769, _inc_path_50791);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_22209);
    Append(&_46cache_substrings_50770, _46cache_substrings_50770, _22209);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_22209);
    Append(&_46cache_starts_50771, _46cache_starts_50771, _22209);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_22209);
    Append(&_46cache_ends_50772, _46cache_ends_50772, _22209);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:90				cache_converted = append(cache_converted,{})*/
    RefDS(_22209);
    Append(&_46cache_converted_50773, _46cache_converted_50773, _22209);

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_46cache_vars_50768)){
            _46num_var_50767 = SEQ_PTR(_46cache_vars_50768)->length;
    }
    else {
        _46num_var_50767 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_46cache_complete_50774, _46cache_complete_50774, 0);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_46cache_delims_50775, _46cache_delims_50775, 0);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50790);
    DeRefDSi(_inc_path_50791);
    return 0;
    goto L2; // [91] 456
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_46cache_strings_50769);
    _26064 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    if (IS_ATOM_INT(_inc_path_50791) && IS_ATOM_INT(_26064)){
        _26065 = (_inc_path_50791 < _26064) ? -1 : (_inc_path_50791 > _26064);
    }
    else{
        _26065 = compare(_inc_path_50791, _26064);
    }
    _26064 = NOVALUE;
    if (_26065 == 0)
    {
        _26065 = NOVALUE;
        goto L3; // [108] 455
    }
    else{
        _26065 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50791);
    _2 = (object)SEQ_PTR(_46cache_strings_50769);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_strings_50769 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50791;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_46cache_complete_50774);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50774 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
    *(intptr_t *)_2 = 0;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_46cache_strings_50769);
    _26066 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    _26067 = e_match_from(_26066, _inc_path_50791, 1);
    _26066 = NOVALUE;
    if (_26067 == 1)
    goto L4; // [146] 454

    /** pathopen.e:101					pos = -1*/
    _pos_50793 = -1;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_46cache_strings_50769);
    _26069 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    if (IS_SEQUENCE(_26069)){
            _26070 = SEQ_PTR(_26069)->length;
    }
    else {
        _26070 = 1;
    }
    _26069 = NOVALUE;
    {
        object _i_50814;
        _i_50814 = 1;
L5: 
        if (_i_50814 > _26070){
            goto L6; // [168] 453
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        _26071 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26071);
        _26072 = (object)*(((s1_ptr)_2)->base + _i_50814);
        _26071 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50791)){
                _26073 = SEQ_PTR(_inc_path_50791)->length;
        }
        else {
            _26073 = 1;
        }
        if (IS_ATOM_INT(_26072)) {
            _26074 = (_26072 > _26073);
        }
        else {
            _26074 = binary_op(GREATER, _26072, _26073);
        }
        _26072 = NOVALUE;
        _26073 = NOVALUE;
        if (IS_ATOM_INT(_26074)) {
            if (_26074 != 0) {
                goto L7; // [196] 250
            }
        }
        else {
            if (DBL_PTR(_26074)->dbl != 0.0) {
                goto L7; // [196] 250
            }
        }
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        _26076 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26076);
        _26077 = (object)*(((s1_ptr)_2)->base + _i_50814);
        _26076 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        _26078 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26078);
        _26079 = (object)*(((s1_ptr)_2)->base + _i_50814);
        _26078 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        _26080 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26080);
        _26081 = (object)*(((s1_ptr)_2)->base + _i_50814);
        _26080 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26082;
        RHS_Slice(_inc_path_50791, _26079, _26081);
        if (IS_ATOM_INT(_26077) && IS_ATOM_INT(_26082)){
            _26083 = (_26077 < _26082) ? -1 : (_26077 > _26082);
        }
        else{
            _26083 = compare(_26077, _26082);
        }
        _26077 = NOVALUE;
        DeRefDS(_26082);
        _26082 = NOVALUE;
        if (_26083 == 0)
        {
            _26083 = NOVALUE;
            goto L8; // [246] 261
        }
        else{
            _26083 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50793 = _i_50814 - 1;

        /** pathopen.e:108							exit*/
        goto L6; // [258] 453
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50793 != 0)
        goto L9; // [263] 276

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50790);
        DeRefDSi(_inc_path_50791);
        _26079 = NOVALUE;
        _26069 = NOVALUE;
        _26081 = NOVALUE;
        DeRef(_26074);
        _26074 = NOVALUE;
        return 0;
        goto LA; // [273] 446
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50793 <= 0)
        goto LB; // [278] 445

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        _26087 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        rhs_slice_target = (object_ptr)&_26088;
        RHS_Slice(_26087, 1, _pos_50793);
        _26087 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50770 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26088;
        if( _1 != _26088 ){
            DeRefDS(_1);
        }
        _26088 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        _26089 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        rhs_slice_target = (object_ptr)&_26090;
        RHS_Slice(_26089, 1, _pos_50793);
        _26089 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50771 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26090;
        if( _1 != _26090 ){
            DeRef(_1);
        }
        _26090 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        _26091 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        rhs_slice_target = (object_ptr)&_26092;
        RHS_Slice(_26091, 1, _pos_50793);
        _26091 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50772 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26092;
        if( _1 != _26092 ){
            DeRef(_1);
        }
        _26092 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:117								cache_converted[num_var] = cache_converted[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26093 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        rhs_slice_target = (object_ptr)&_26094;
        RHS_Slice(_26093, 1, _pos_50793);
        _26093 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26094;
        if( _1 != _26094 ){
            DeRef(_1);
        }
        _26094 = NOVALUE;

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        _26095 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26095)){
                _26096 = SEQ_PTR(_26095)->length;
        }
        else {
            _26096 = 1;
        }
        _2 = (object)SEQ_PTR(_26095);
        _26097 = (object)*(((s1_ptr)_2)->base + _26096);
        _26095 = NOVALUE;
        if (IS_ATOM_INT(_26097)) {
            _delim_50792 = _26097 + 1;
        }
        else
        { // coercing _delim_50792 to an integer 1
            _delim_50792 = 1+(object)(DBL_PTR(_26097)->dbl);
            if( !IS_ATOM_INT(_delim_50792) ){
                _delim_50792 = (object)DBL_PTR(_delim_50792)->dbl;
            }
        }
        _26097 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50791)){
                _26099 = SEQ_PTR(_inc_path_50791)->length;
        }
        else {
            _26099 = 1;
        }
        _26100 = (_delim_50792 <= _26099);
        _26099 = NOVALUE;
        if (_26100 == 0) {
            goto LD; // [409] 434
        }
        _26102 = (_delim_50792 != 59);
        if (_26102 == 0)
        {
            DeRef(_26102);
            _26102 = NOVALUE;
            goto LD; // [420] 434
        }
        else{
            DeRef(_26102);
            _26102 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50792 = _delim_50792 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [431] 402
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_46cache_delims_50775);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50775 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        *(intptr_t *)_2 = _delim_50792;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50814 = _i_50814 + 1;
        goto L5; // [448] 175
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50790);
    DeRefDSi(_inc_path_50791);
    DeRef(_26100);
    _26100 = NOVALUE;
    _26079 = NOVALUE;
    _26069 = NOVALUE;
    _26081 = NOVALUE;
    DeRef(_26074);
    _26074 = NOVALUE;
    return 1;
    ;
}


object _46get_conf_dirs()
{
    object _delimiter_50857 = NOVALUE;
    object _dirs_50858 = NOVALUE;
    object _26107 = NOVALUE;
    object _26105 = NOVALUE;
    object _26104 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:139			delimiter = ';'*/
    _delimiter_50857 = 59;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_22209);
    DeRef(_dirs_50858);
    _dirs_50858 = _22209;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50776)){
            _26104 = SEQ_PTR(_46config_inc_paths_50776)->length;
    }
    else {
        _26104 = 1;
    }
    {
        object _i_50860;
        _i_50860 = 1;
L1: 
        if (_i_50860 > _26104){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50776);
        _26105 = (object)*(((s1_ptr)_2)->base + _i_50860);
        Concat((object_ptr)&_dirs_50858, _dirs_50858, _26105);
        _26105 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_46config_inc_paths_50776)){
                _26107 = SEQ_PTR(_46config_inc_paths_50776)->length;
        }
        else {
            _26107 = 1;
        }
        if (_i_50860 == _26107)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50858, _dirs_50858, _delimiter_50857);
L3: 

        /** pathopen.e:148		end for*/
        _i_50860 = _i_50860 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50858;
    ;
}


object _46strip_file_from_path(object _full_path_50870)
{
    object _26113 = NOVALUE;
    object _26111 = NOVALUE;
    object _26110 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50870)){
            _26110 = SEQ_PTR(_full_path_50870)->length;
    }
    else {
        _26110 = 1;
    }
    {
        object _i_50872;
        _i_50872 = _26110;
L1: 
        if (_i_50872 < 1){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50870);
        _26111 = (object)*(((s1_ptr)_2)->base + _i_50872);
        if (binary_op_a(NOTEQ, _26111, 92)){
            _26111 = NOVALUE;
            goto L3; // [23] 39
        }
        _26111 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_26113;
        RHS_Slice(_full_path_50870, 1, _i_50872);
        DeRefDS(_full_path_50870);
        return _26113;
L3: 

        /** pathopen.e:160		end for*/
        _i_50872 = _i_50872 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_22209);
    DeRefDS(_full_path_50870);
    DeRef(_26113);
    _26113 = NOVALUE;
    return _22209;
    ;
}


object _46expand_path(object _path_50881, object _prefix_50882)
{
    object _absolute_50883 = NOVALUE;
    object _26128 = NOVALUE;
    object _26127 = NOVALUE;
    object _26126 = NOVALUE;
    object _26125 = NOVALUE;
    object _26124 = NOVALUE;
    object _26123 = NOVALUE;
    object _26119 = NOVALUE;
    object _26118 = NOVALUE;
    object _26117 = NOVALUE;
    object _26114 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50881)){
            _26114 = SEQ_PTR(_path_50881)->length;
    }
    else {
        _26114 = 1;
    }
    if (_26114 != 0)
    goto L1; // [10] 22
    _26114 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_46pwd_50779);
    DeRefDS(_path_50881);
    DeRefDS(_prefix_50882);
    return _46pwd_50779;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:185			absolute = find(path[1], SLASH_CHARS) or find(':', path)*/
    _2 = (object)SEQ_PTR(_path_50881);
    _26117 = (object)*(((s1_ptr)_2)->base + 1);
    _26118 = find_from(_26117, _44SLASH_CHARS_20736, 1);
    _26117 = NOVALUE;
    _26119 = find_from(58, _path_50881, 1);
    _absolute_50883 = (_26118 != 0 || _26119 != 0);
    _26118 = NOVALUE;
    _26119 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50883 != 0)
    goto L2; // [50] 64

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50881;
        concat_list[1] = 92;
        concat_list[2] = _prefix_50882;
        Concat_N((object_ptr)&_path_50881, concat_list, 3);
    }
L2: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50881)){
            _26123 = SEQ_PTR(_path_50881)->length;
    }
    else {
        _26123 = 1;
    }
    if (_26123 == 0) {
        goto L3; // [69] 103
    }
    if (IS_SEQUENCE(_path_50881)){
            _26125 = SEQ_PTR(_path_50881)->length;
    }
    else {
        _26125 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50881);
    _26126 = (object)*(((s1_ptr)_2)->base + _26125);
    _26127 = find_from(_26126, _44SLASH_CHARS_20736, 1);
    _26126 = NOVALUE;
    _26128 = (_26127 == 0);
    _26127 = NOVALUE;
    if (_26128 == 0)
    {
        DeRef(_26128);
        _26128 = NOVALUE;
        goto L3; // [91] 103
    }
    else{
        DeRef(_26128);
        _26128 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50881, _path_50881, 92);
L3: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50882);
    return _path_50881;
    ;
}


void _46add_include_directory(object _path_50909)
{
    object _26131 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50909);
    RefDS(_46pwd_50779);
    _0 = _path_50909;
    _path_50909 = _46expand_path(_path_50909, _46pwd_50779);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _26131 = find_from(_path_50909, _46config_inc_paths_50776, 1);
    if (_26131 != 0)
    goto L1; // [23] 35
    _26131 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50909);
    Append(&_46config_inc_paths_50776, _46config_inc_paths_50776, _path_50909);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50909);
    return;
    ;
}


object _46load_euphoria_config(object _file_50918)
{
    object _fn_50919 = NOVALUE;
    object _in_50920 = NOVALUE;
    object _spos_50921 = NOVALUE;
    object _epos_50922 = NOVALUE;
    object _conf_path_50923 = NOVALUE;
    object _new_args_50924 = NOVALUE;
    object _arg_50925 = NOVALUE;
    object _parm_50926 = NOVALUE;
    object _section_50927 = NOVALUE;
    object _needed_51024 = NOVALUE;
    object _26228 = NOVALUE;
    object _26227 = NOVALUE;
    object _26224 = NOVALUE;
    object _26222 = NOVALUE;
    object _26221 = NOVALUE;
    object _26199 = NOVALUE;
    object _26196 = NOVALUE;
    object _26195 = NOVALUE;
    object _26193 = NOVALUE;
    object _26189 = NOVALUE;
    object _26187 = NOVALUE;
    object _26185 = NOVALUE;
    object _26183 = NOVALUE;
    object _26181 = NOVALUE;
    object _26179 = NOVALUE;
    object _26178 = NOVALUE;
    object _26177 = NOVALUE;
    object _26176 = NOVALUE;
    object _26175 = NOVALUE;
    object _26174 = NOVALUE;
    object _26173 = NOVALUE;
    object _26172 = NOVALUE;
    object _26170 = NOVALUE;
    object _26168 = NOVALUE;
    object _26166 = NOVALUE;
    object _26162 = NOVALUE;
    object _26161 = NOVALUE;
    object _26156 = NOVALUE;
    object _26154 = NOVALUE;
    object _26152 = NOVALUE;
    object _26151 = NOVALUE;
    object _26143 = NOVALUE;
    object _26137 = NOVALUE;
    object _26136 = NOVALUE;
    object _26134 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_22209);
    DeRef(_new_args_50924);
    _new_args_50924 = _22209;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50918);
    _26134 = _15file_type(_file_50918);
    if (binary_op_a(NOTEQ, _26134, 2)){
        DeRef(_26134);
        _26134 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_26134);
    _26134 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50918)){
            _26136 = SEQ_PTR(_file_50918)->length;
    }
    else {
        _26136 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50918);
    _26137 = (object)*(((s1_ptr)_2)->base + _26136);
    if (binary_op_a(EQUALS, _26137, 92)){
        _26137 = NOVALUE;
        goto L2; // [33] 46
    }
    _26137 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50918, _file_50918, 92);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50918, _file_50918, _26140);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50918);
    _0 = _conf_path_50923;
    _conf_path_50923 = _15canonical_path(_file_50918, 0, 2);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _26143 = find_from(_conf_path_50923, _46seen_conf_50915, 1);
    if (_26143 == 0)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_22209);
    DeRefDS(_file_50918);
    DeRefi(_in_50920);
    DeRefDS(_conf_path_50923);
    DeRef(_new_args_50924);
    DeRefi(_arg_50925);
    DeRefi(_parm_50926);
    DeRef(_section_50927);
    return _22209;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50923);
    Append(&_46seen_conf_50915, _46seen_conf_50915, _conf_path_50923);

    /** pathopen.e:234		section = "all"*/
    RefDS(_26146);
    DeRef(_section_50927);
    _section_50927 = _26146;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50919 = EOpen(_conf_path_50923, _26147, 0);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50919 != -1)
    goto L4; // [109] 118
    RefDS(_22209);
    DeRefDS(_file_50918);
    DeRefi(_in_50920);
    DeRefDS(_conf_path_50923);
    DeRef(_new_args_50924);
    DeRefi(_arg_50925);
    DeRefi(_parm_50926);
    DeRefDSi(_section_50927);
    return _22209;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50920);
    _in_50920 = EGets(_fn_50919);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _26151 = IS_SEQUENCE(_in_50920);
    if (_26151 == 0)
    {
        _26151 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _26151 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50921 = 1;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50920)){
            _26152 = SEQ_PTR(_in_50920)->length;
    }
    else {
        _26152 = 1;
    }
    if (_spos_50921 > _26152)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50920);
    _26154 = (object)*(((s1_ptr)_2)->base + _spos_50921);
    _26156 = find_from(_26154, _26155, 1);
    _26154 = NOVALUE;
    if (_26156 != 0)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50921 = _spos_50921 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50920)){
            _epos_50922 = SEQ_PTR(_in_50920)->length;
    }
    else {
        _epos_50922 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50922 < _spos_50921)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50920);
    _26161 = (object)*(((s1_ptr)_2)->base + _epos_50922);
    _26162 = find_from(_26161, _26155, 1);
    _26161 = NOVALUE;
    if (_26162 != 0)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50922 = _epos_50922 - 1;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50920;
    RHS_Slice(_in_50920, _spos_50921, _epos_50922);

    /** pathopen.e:260			arg = ""*/
    RefDS(_22209);
    DeRefi(_arg_50925);
    _arg_50925 = _22209;

    /** pathopen.e:261			parm = ""*/
    RefDS(_22209);
    DeRefi(_parm_50926);
    _parm_50926 = _22209;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50920)){
            _26166 = SEQ_PTR(_in_50920)->length;
    }
    else {
        _26166 = 1;
    }
    if (_26166 <= 0)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50920);
    _26168 = (object)*(((s1_ptr)_2)->base + 1);
    if (_26168 != 91)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50920)){
            _26170 = SEQ_PTR(_in_50920)->length;
    }
    else {
        _26170 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50927;
    RHS_Slice(_in_50920, 2, _26170);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50927)){
            _26172 = SEQ_PTR(_section_50927)->length;
    }
    else {
        _26172 = 1;
    }
    _26173 = (_26172 > 0);
    _26172 = NOVALUE;
    if (_26173 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50927)){
            _26175 = SEQ_PTR(_section_50927)->length;
    }
    else {
        _26175 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50927);
    _26176 = (object)*(((s1_ptr)_2)->base + _26175);
    _26177 = (_26176 == 93);
    _26176 = NOVALUE;
    if (_26177 == 0)
    {
        DeRef(_26177);
        _26177 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26177);
        _26177 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50927)){
            _26178 = SEQ_PTR(_section_50927)->length;
    }
    else {
        _26178 = 1;
    }
    _26179 = _26178 - 1;
    _26178 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50927;
    RHS_Slice(_section_50927, 1, _26179);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50927);
    RefDS(_4905);
    _26181 = _12trim(_section_50927, _4905, 0);
    _0 = _section_50927;
    _section_50927 = _12lower(_26181);
    DeRefDS(_0);
    _26181 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50927)){
            _26183 = SEQ_PTR(_section_50927)->length;
    }
    else {
        _26183 = 1;
    }
    if (_26183 != 0)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_26146);
    DeRefDS(_section_50927);
    _section_50927 = _26146;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50920)){
            _26185 = SEQ_PTR(_in_50920)->length;
    }
    else {
        _26185 = 1;
    }
    if (_26185 <= 2)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50920);
    _26187 = (object)*(((s1_ptr)_2)->base + 1);
    if (_26187 != 45)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50920);
    _26189 = (object)*(((s1_ptr)_2)->base + 2);
    if (_26189 == 45)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50921 = find_from(32, _in_50920, 1);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50921 != 0)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50920);
    DeRefi(_arg_50925);
    _arg_50925 = _in_50920;

    /** pathopen.e:287								parm = ""*/
    RefDS(_22209);
    DeRefi(_parm_50926);
    _parm_50926 = _22209;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _26193 = _spos_50921 - 1;
    rhs_slice_target = (object_ptr)&_arg_50925;
    RHS_Slice(_in_50920, 1, _26193);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _26195 = _spos_50921 + 1;
    if (_26195 > MAXINT){
        _26195 = NewDouble((eudouble)_26195);
    }
    if (IS_SEQUENCE(_in_50920)){
            _26196 = SEQ_PTR(_in_50920)->length;
    }
    else {
        _26196 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50926;
    RHS_Slice(_in_50920, _26195, _26196);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_26198);
    DeRefi(_arg_50925);
    _arg_50925 = _26198;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50920);
    DeRefi(_parm_50926);
    _parm_50926 = _in_50920;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_26198);
    DeRefi(_arg_50925);
    _arg_50925 = _26198;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50920);
    DeRefi(_parm_50926);
    _parm_50926 = _in_50920;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50925)){
            _26199 = SEQ_PTR(_arg_50925)->length;
    }
    else {
        _26199 = 1;
    }
    if (_26199 <= 0)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_51024 = 0;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50927, _26201);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_51024 = 1;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_51024 = _44TWINDOWS_20715;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_51024 = 0;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_51024 = _27TRANSLATE_20179;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_51024 = (_27TRANSLATE_20179 != 0 && _44TWINDOWS_20715 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_51024 = (_27TRANSLATE_20179 != 0 && 0 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_51024 = _27INTERPRET_20176;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_51024 = (_27INTERPRET_20176 != 0 && _44TWINDOWS_20715 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_51024 = (_27INTERPRET_20176 != 0 && 0 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_51024 = _27BIND_20182;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_51024 = (_27BIND_20182 != 0 && _44TWINDOWS_20715 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_51024 = (_27BIND_20182 != 0 && 0 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_51024 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50925 == _26220)
    _26221 = 1;
    else if (IS_ATOM_INT(_arg_50925) && IS_ATOM_INT(_26220))
    _26221 = 0;
    else
    _26221 = (compare(_arg_50925, _26220) == 0);
    if (_26221 == 0)
    {
        _26221 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26221 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50926)){
            _26222 = SEQ_PTR(_parm_50926)->length;
    }
    else {
        _26222 = 1;
    }
    if (_26222 <= 0)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50926);
    _26224 = _46load_euphoria_config(_parm_50926);
    if (IS_SEQUENCE(_new_args_50924) && IS_ATOM(_26224)) {
        Ref(_26224);
        Append(&_new_args_50924, _new_args_50924, _26224);
    }
    else if (IS_ATOM(_new_args_50924) && IS_SEQUENCE(_26224)) {
    }
    else {
        Concat((object_ptr)&_new_args_50924, _new_args_50924, _26224);
    }
    DeRef(_26224);
    _26224 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50925);
    Append(&_new_args_50924, _new_args_50924, _arg_50925);

    /** pathopen.e:351						if length(parm > 0) then*/
    _26227 = binary_op(GREATER, _parm_50926, 0);
    if (IS_SEQUENCE(_26227)){
            _26228 = SEQ_PTR(_26227)->length;
    }
    else {
        _26228 = 1;
    }
    DeRefDS(_26227);
    _26227 = NOVALUE;
    if (_26228 == 0)
    {
        _26228 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26228 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50926);
    Append(&_new_args_50924, _new_args_50924, _parm_50926);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50920);
    _in_50920 = EGets(_fn_50919);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50919);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50918);
    DeRefi(_in_50920);
    DeRef(_conf_path_50923);
    DeRefi(_arg_50925);
    DeRefi(_parm_50926);
    DeRef(_section_50927);
    _26187 = NOVALUE;
    DeRef(_26173);
    _26173 = NOVALUE;
    DeRef(_26193);
    _26193 = NOVALUE;
    _26168 = NOVALUE;
    DeRef(_26179);
    _26179 = NOVALUE;
    _26227 = NOVALUE;
    _26189 = NOVALUE;
    DeRef(_26195);
    _26195 = NOVALUE;
    return _new_args_50924;
    ;
}


object _46GetDefaultArgs(object _user_files_51091)
{
    object _env_51092 = NOVALUE;
    object _default_args_51093 = NOVALUE;
    object _conf_file_51094 = NOVALUE;
    object _cmd_options_51096 = NOVALUE;
    object _user_config_51102 = NOVALUE;
    object _26273 = NOVALUE;
    object _26272 = NOVALUE;
    object _26271 = NOVALUE;
    object _26268 = NOVALUE;
    object _26267 = NOVALUE;
    object _26266 = NOVALUE;
    object _26264 = NOVALUE;
    object _26260 = NOVALUE;
    object _26259 = NOVALUE;
    object _26258 = NOVALUE;
    object _26257 = NOVALUE;
    object _26253 = NOVALUE;
    object _26252 = NOVALUE;
    object _26251 = NOVALUE;
    object _26249 = NOVALUE;
    object _26243 = NOVALUE;
    object _26242 = NOVALUE;
    object _26240 = NOVALUE;
    object _26238 = NOVALUE;
    object _26237 = NOVALUE;
    object _26233 = NOVALUE;
    object _26232 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_22209);
    DeRef(_default_args_51093);
    _default_args_51093 = _22209;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_26140);
    DeRefi(_conf_file_51094);
    _conf_file_51094 = _26140;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_46loaded_config_inc_paths_50777 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22209);
    DeRefDS(_user_files_51091);
    DeRef(_env_51092);
    DeRefDS(_default_args_51093);
    DeRefDSi(_conf_file_51094);
    DeRef(_cmd_options_51096);
    return _22209;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _46loaded_config_inc_paths_50777 = 1;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_51096;
    _cmd_options_51096 = _47get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_22209);
    DeRef(_default_args_51093);
    _default_args_51093 = _22209;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_51091)){
            _26232 = SEQ_PTR(_user_files_51091)->length;
    }
    else {
        _26232 = 1;
    }
    {
        object _i_51100;
        _i_51100 = 1;
L2: 
        if (_i_51100 > _26232){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_51091);
        _26233 = (object)*(((s1_ptr)_2)->base + _i_51100);
        Ref(_26233);
        _0 = _user_config_51102;
        _user_config_51102 = _46load_euphoria_config(_26233);
        DeRef(_0);
        _26233 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_51102);
        RefDS(_default_args_51093);
        RefDS(_cmd_options_51096);
        _0 = _default_args_51093;
        _default_args_51093 = _47merge_parameters(_user_config_51102, _default_args_51093, _cmd_options_51096, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_51102);
        _user_config_51102 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_51100 = _i_51100 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26237, _26236, _conf_file_51094);
    _26238 = _46load_euphoria_config(_26237);
    _26237 = NOVALUE;
    RefDS(_default_args_51093);
    RefDS(_cmd_options_51096);
    _0 = _default_args_51093;
    _default_args_51093 = _47merge_parameters(_26238, _default_args_51093, _cmd_options_51096, 1);
    DeRefDS(_0);
    _26238 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26240 = _46exe_path();
    _0 = _env_51092;
    _env_51092 = _46strip_file_from_path(_26240);
    DeRef(_0);
    _26240 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_51092) && IS_ATOM(_conf_file_51094)) {
    }
    else if (IS_ATOM(_env_51092) && IS_SEQUENCE(_conf_file_51094)) {
        Ref(_env_51092);
        Prepend(&_26242, _conf_file_51094, _env_51092);
    }
    else {
        Concat((object_ptr)&_26242, _env_51092, _conf_file_51094);
    }
    _26243 = _46load_euphoria_config(_26242);
    _26242 = NOVALUE;
    RefDS(_default_args_51093);
    RefDS(_cmd_options_51096);
    _0 = _default_args_51093;
    _default_args_51093 = _47merge_parameters(_26243, _default_args_51093, _cmd_options_51096, 1);
    DeRefDS(_0);
    _26243 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:407			env = getenv( "ALLUSERSPROFILE" )*/
    DeRef(_env_51092);
    _env_51092 = EGetEnv(_26247);

    /** pathopen.e:408			if sequence(env) then*/
    _26249 = IS_SEQUENCE(_env_51092);
    if (_26249 == 0)
    {
        _26249 = NOVALUE;
        goto L4; // [151] 179
    }
    else{
        _26249 = NOVALUE;
    }

    /** pathopen.e:409				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26250);
    Ref(_env_51092);
    _26251 = _46expand_path(_26250, _env_51092);
    if (IS_SEQUENCE(_26251) && IS_ATOM(_conf_file_51094)) {
    }
    else if (IS_ATOM(_26251) && IS_SEQUENCE(_conf_file_51094)) {
        Ref(_26251);
        Prepend(&_26252, _conf_file_51094, _26251);
    }
    else {
        Concat((object_ptr)&_26252, _26251, _conf_file_51094);
        DeRef(_26251);
        _26251 = NOVALUE;
    }
    DeRef(_26251);
    _26251 = NOVALUE;
    _26253 = _46load_euphoria_config(_26252);
    _26252 = NOVALUE;
    RefDS(_default_args_51093);
    RefDS(_cmd_options_51096);
    _0 = _default_args_51093;
    _default_args_51093 = _47merge_parameters(_26253, _default_args_51093, _cmd_options_51096, 1);
    DeRefDS(_0);
    _26253 = NOVALUE;
L4: 

    /** pathopen.e:412			env = getenv( "APPDATA" )*/
    DeRef(_env_51092);
    _env_51092 = EGetEnv(_26255);

    /** pathopen.e:413			if sequence(env) then*/
    _26257 = IS_SEQUENCE(_env_51092);
    if (_26257 == 0)
    {
        _26257 = NOVALUE;
        goto L5; // [189] 217
    }
    else{
        _26257 = NOVALUE;
    }

    /** pathopen.e:414				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26250);
    Ref(_env_51092);
    _26258 = _46expand_path(_26250, _env_51092);
    if (IS_SEQUENCE(_26258) && IS_ATOM(_conf_file_51094)) {
    }
    else if (IS_ATOM(_26258) && IS_SEQUENCE(_conf_file_51094)) {
        Ref(_26258);
        Prepend(&_26259, _conf_file_51094, _26258);
    }
    else {
        Concat((object_ptr)&_26259, _26258, _conf_file_51094);
        DeRef(_26258);
        _26258 = NOVALUE;
    }
    DeRef(_26258);
    _26258 = NOVALUE;
    _26260 = _46load_euphoria_config(_26259);
    _26259 = NOVALUE;
    RefDS(_default_args_51093);
    RefDS(_cmd_options_51096);
    _0 = _default_args_51093;
    _default_args_51093 = _47merge_parameters(_26260, _default_args_51093, _cmd_options_51096, 1);
    DeRefDS(_0);
    _26260 = NOVALUE;
L5: 

    /** pathopen.e:417			env = getenv( "HOMEPATH" )*/
    DeRef(_env_51092);
    _env_51092 = EGetEnv(_26262);

    /** pathopen.e:418			if sequence(env) then*/
    _26264 = IS_SEQUENCE(_env_51092);
    if (_26264 == 0)
    {
        _26264 = NOVALUE;
        goto L6; // [227] 256
    }
    else{
        _26264 = NOVALUE;
    }

    /** pathopen.e:419				default_args = merge_parameters( load_euphoria_config( getenv( "HOMEDRIVE" ) & env & "\\" & conf_file ), default_args, cmd_options, 1 )*/
    _26266 = EGetEnv(_26265);
    {
        object concat_list[4];

        concat_list[0] = _conf_file_51094;
        concat_list[1] = _23908;
        concat_list[2] = _env_51092;
        concat_list[3] = _26266;
        Concat_N((object_ptr)&_26267, concat_list, 4);
    }
    DeRef(_26266);
    _26266 = NOVALUE;
    _26268 = _46load_euphoria_config(_26267);
    _26267 = NOVALUE;
    RefDS(_default_args_51093);
    RefDS(_cmd_options_51096);
    _0 = _default_args_51093;
    _default_args_51093 = _47merge_parameters(_26268, _default_args_51093, _cmd_options_51096, 1);
    DeRefDS(_0);
    _26268 = NOVALUE;
L6: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_51092;
    _env_51092 = _28get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26271 = IS_SEQUENCE(_env_51092);
    if (_26271 == 0)
    {
        _26271 = NOVALUE;
        goto L7; // [266] 291
    }
    else{
        _26271 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_51094;
        concat_list[1] = _23785;
        concat_list[2] = _env_51092;
        Concat_N((object_ptr)&_26272, concat_list, 3);
    }
    _26273 = _46load_euphoria_config(_26272);
    _26272 = NOVALUE;
    RefDS(_default_args_51093);
    RefDS(_cmd_options_51096);
    _0 = _default_args_51093;
    _default_args_51093 = _47merge_parameters(_26273, _default_args_51093, _cmd_options_51096, 1);
    DeRefDS(_0);
    _26273 = NOVALUE;
L7: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_51091);
    DeRef(_env_51092);
    DeRefi(_conf_file_51094);
    DeRef(_cmd_options_51096);
    return _default_args_51093;
    ;
}


object _46ConfPath(object _file_name_51159)
{
    object _file_path_51160 = NOVALUE;
    object _try_51161 = NOVALUE;
    object _26280 = NOVALUE;
    object _26276 = NOVALUE;
    object _26275 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_46config_inc_paths_50776)){
            _26275 = SEQ_PTR(_46config_inc_paths_50776)->length;
    }
    else {
        _26275 = 1;
    }
    {
        object _i_51163;
        _i_51163 = 1;
L1: 
        if (_i_51163 > _26275){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_46config_inc_paths_50776);
        _26276 = (object)*(((s1_ptr)_2)->base + _i_51163);
        Concat((object_ptr)&_file_path_51160, _26276, _file_name_51159);
        _26276 = NOVALUE;
        _26276 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_51161 = EOpen(_file_path_51160, _26147, 0);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_51161 == -1)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_51160);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51160;
        ((intptr_t *)_2)[2] = _try_51161;
        _26280 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51159);
        DeRefDS(_file_path_51160);
        return _26280;
L3: 

        /** pathopen.e:446		end for*/
        _i_51163 = _i_51163 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_51159);
    DeRef(_file_path_51160);
    DeRef(_26280);
    _26280 = NOVALUE;
    return -1;
    ;
}


object _46ScanPath(object _file_name_51173, object _env_51174, object _flag_51175)
{
    object _inc_path_51176 = NOVALUE;
    object _full_path_51177 = NOVALUE;
    object _file_path_51178 = NOVALUE;
    object _strings_51179 = NOVALUE;
    object _end_path_51180 = NOVALUE;
    object _start_path_51181 = NOVALUE;
    object _try_51182 = NOVALUE;
    object _use_cache_51183 = NOVALUE;
    object _pos_51184 = NOVALUE;
    object _26358 = NOVALUE;
    object _26357 = NOVALUE;
    object _26356 = NOVALUE;
    object _26355 = NOVALUE;
    object _26354 = NOVALUE;
    object _26353 = NOVALUE;
    object _26352 = NOVALUE;
    object _26351 = NOVALUE;
    object _26350 = NOVALUE;
    object _26349 = NOVALUE;
    object _26348 = NOVALUE;
    object _26347 = NOVALUE;
    object _26346 = NOVALUE;
    object _26345 = NOVALUE;
    object _26344 = NOVALUE;
    object _26343 = NOVALUE;
    object _26338 = NOVALUE;
    object _26337 = NOVALUE;
    object _26336 = NOVALUE;
    object _26335 = NOVALUE;
    object _26334 = NOVALUE;
    object _26330 = NOVALUE;
    object _26329 = NOVALUE;
    object _26328 = NOVALUE;
    object _26327 = NOVALUE;
    object _26326 = NOVALUE;
    object _26325 = NOVALUE;
    object _26323 = NOVALUE;
    object _26321 = NOVALUE;
    object _26320 = NOVALUE;
    object _26318 = NOVALUE;
    object _26317 = NOVALUE;
    object _26316 = NOVALUE;
    object _26313 = NOVALUE;
    object _26312 = NOVALUE;
    object _26310 = NOVALUE;
    object _26309 = NOVALUE;
    object _26308 = NOVALUE;
    object _26306 = NOVALUE;
    object _26304 = NOVALUE;
    object _26299 = NOVALUE;
    object _26298 = NOVALUE;
    object _26297 = NOVALUE;
    object _26296 = NOVALUE;
    object _26295 = NOVALUE;
    object _26290 = NOVALUE;
    object _26282 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_51176);
    _inc_path_51176 = EGetEnv(_env_51174);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_51176) && IS_ATOM_INT(_22209)){
        _26282 = (_inc_path_51176 < _22209) ? -1 : (_inc_path_51176 > _22209);
    }
    else{
        _26282 = compare(_inc_path_51176, _22209);
    }
    if (_26282 == 1)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_51173);
    DeRefDSi(_env_51174);
    DeRefi(_inc_path_51176);
    DeRef(_full_path_51177);
    DeRef(_file_path_51178);
    DeRef(_strings_51179);
    return -1;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _46num_var_50767 = find_from(_env_51174, _46cache_vars_50768, 1);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_51174);
    Ref(_inc_path_51176);
    _use_cache_51183 = _46check_cache(_env_51174, _inc_path_51176);
    if (!IS_ATOM_INT(_use_cache_51183)) {
        _1 = (object)(DBL_PTR(_use_cache_51183)->dbl);
        DeRefDS(_use_cache_51183);
        _use_cache_51183 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51176, _inc_path_51176, 59);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_51173, _file_name_51173, 92);

    /** pathopen.e:469		if flag then*/
    if (_flag_51175 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_51173, _46include_subfolder_50763, _file_name_51173);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_51179);
    _2 = (object)SEQ_PTR(_46cache_substrings_50770);
    _strings_51179 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    RefDS(_strings_51179);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_51183 == 0)
    {
        goto L3; // [91] 292
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_51179)){
            _26290 = SEQ_PTR(_strings_51179)->length;
    }
    else {
        _26290 = 1;
    }
    {
        object _i_51200;
        _i_51200 = 1;
L4: 
        if (_i_51200 > _26290){
            goto L5; // [99] 252
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_51177);
        _2 = (object)SEQ_PTR(_strings_51179);
        _full_path_51177 = (object)*(((s1_ptr)_2)->base + _i_51200);
        Ref(_full_path_51177);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51178, _full_path_51177, _file_name_51173);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_51178);
        _try_51182 = _28open_locked(_file_path_51178);
        if (!IS_ATOM_INT(_try_51182)) {
            _1 = (object)(DBL_PTR(_try_51182)->dbl);
            DeRefDS(_try_51182);
            _try_51182 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_51182 == -1)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_51178);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51178;
        ((intptr_t *)_2)[2] = _try_51182;
        _26295 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51173);
        DeRefDSi(_env_51174);
        DeRefi(_inc_path_51176);
        DeRefDS(_full_path_51177);
        DeRefDS(_file_path_51178);
        DeRefDS(_strings_51179);
        return _26295;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:483					if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26296 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26296);
        _26297 = (object)*(((s1_ptr)_2)->base + _i_51200);
        _26296 = NOVALUE;
        _26298 = IS_SEQUENCE(_26297);
        _26297 = NOVALUE;
        if (_26298 == 0)
        {
            _26298 = NOVALUE;
            goto L7; // [164] 245
        }
        else{
            _26298 = NOVALUE;
        }

        /** pathopen.e:486						full_path = cache_converted[num_var][i]*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26299 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        DeRef(_full_path_51177);
        _2 = (object)SEQ_PTR(_26299);
        _full_path_51177 = (object)*(((s1_ptr)_2)->base + _i_51200);
        Ref(_full_path_51177);
        _26299 = NOVALUE;

        /** pathopen.e:487						file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51178, _full_path_51177, _file_name_51173);

        /** pathopen.e:488						try = open_locked(file_path)*/
        RefDS(_file_path_51178);
        _try_51182 = _28open_locked(_file_path_51178);
        if (!IS_ATOM_INT(_try_51182)) {
            _1 = (object)(DBL_PTR(_try_51182)->dbl);
            DeRefDS(_try_51182);
            _try_51182 = _1;
        }

        /** pathopen.e:489						if try != -1 then*/
        if (_try_51182 == -1)
        goto L8; // [199] 244

        /** pathopen.e:490							cache_converted[num_var][i] = 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _3 = (object)(_46num_var_50767 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51200);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _26304 = NOVALUE;

        /** pathopen.e:491							cache_substrings[num_var][i] = full_path*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50770 = MAKE_SEQ(_2);
        }
        _3 = (object)(_46num_var_50767 + ((s1_ptr)_2)->base);
        RefDS(_full_path_51177);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51200);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _full_path_51177;
        DeRef(_1);
        _26306 = NOVALUE;

        /** pathopen.e:492							return {file_path,try}*/
        RefDS(_file_path_51178);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51178;
        ((intptr_t *)_2)[2] = _try_51182;
        _26308 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51173);
        DeRefDSi(_env_51174);
        DeRefi(_inc_path_51176);
        DeRefDS(_full_path_51177);
        DeRefDS(_file_path_51178);
        DeRef(_strings_51179);
        DeRef(_26295);
        _26295 = NOVALUE;
        return _26308;
L8: 
L7: 

        /** pathopen.e:496			end for*/
        _i_51200 = _i_51200 + 1;
        goto L4; // [247] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_46cache_complete_50774);
    _26309 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    if (_26309 == 0)
    {
        _26309 = NOVALUE;
        goto L9; // [262] 274
    }
    else{
        _26309 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_51173);
    DeRefDSi(_env_51174);
    DeRefi(_inc_path_51176);
    DeRef(_full_path_51177);
    DeRef(_file_path_51178);
    DeRef(_strings_51179);
    DeRef(_26308);
    _26308 = NOVALUE;
    DeRef(_26295);
    _26295 = NOVALUE;
    return -1;
    goto LA; // [271] 298
L9: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_46cache_delims_50775);
    _26310 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    _pos_51184 = _26310 + 1;
    _26310 = NOVALUE;
    goto LA; // [289] 298
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_51184 = 1;
LA: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_51181 = 0;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51176)){
            _26312 = SEQ_PTR(_inc_path_51176)->length;
    }
    else {
        _26312 = 1;
    }
    {
        object _p_51232;
        _p_51232 = _pos_51184;
LB: 
        if (_p_51232 > _26312){
            goto LC; // [310] 716
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51176);
        _26313 = (object)*(((s1_ptr)_2)->base + _p_51232);
        if (_26313 != 59)
        goto LD; // [325] 665

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50775);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50775 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        *(intptr_t *)_2 = _p_51232;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_51180 = _p_51232 - 1;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LE: 
        _26316 = (_end_path_51180 >= _start_path_51181);
        if (_26316 == 0) {
            goto LF; // [354] 388
        }
        _2 = (object)SEQ_PTR(_inc_path_51176);
        _26318 = (object)*(((s1_ptr)_2)->base + _end_path_51180);
        Concat((object_ptr)&_26320, _26319, _44SLASH_CHARS_20736);
        _26321 = find_from(_26318, _26320, 1);
        _26318 = NOVALUE;
        DeRefDS(_26320);
        _26320 = NOVALUE;
        if (_26321 == 0)
        {
            _26321 = NOVALUE;
            goto LF; // [374] 388
        }
        else{
            _26321 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_51180 = _end_path_51180 - 1;

        /** pathopen.e:515				end while*/
        goto LE; // [385] 350
LF: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_51181 == 0) {
            goto L10; // [390] 709
        }
        if (_end_path_51180 == 0)
        {
            goto L10; // [395] 709
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51177;
        RHS_Slice(_inc_path_51176, _start_path_51181, _end_path_51180);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        _26325 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        RefDS(_full_path_51177);
        Append(&_26326, _26325, _full_path_51177);
        _26325 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50770 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26326;
        if( _1 != _26326 ){
            DeRefDS(_1);
        }
        _26326 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        _26327 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26327) && IS_ATOM(_start_path_51181)) {
            Append(&_26328, _26327, _start_path_51181);
        }
        else if (IS_ATOM(_26327) && IS_SEQUENCE(_start_path_51181)) {
        }
        else {
            Concat((object_ptr)&_26328, _26327, _start_path_51181);
            _26327 = NOVALUE;
        }
        _26327 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50771 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26328;
        if( _1 != _26328 ){
            DeRef(_1);
        }
        _26328 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        _26329 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26329) && IS_ATOM(_end_path_51180)) {
            Append(&_26330, _26329, _end_path_51180);
        }
        else if (IS_ATOM(_26329) && IS_SEQUENCE(_end_path_51180)) {
        }
        else {
            Concat((object_ptr)&_26330, _26329, _end_path_51180);
            _26329 = NOVALUE;
        }
        _26329 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50772 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26330;
        if( _1 != _26330 ){
            DeRef(_1);
        }
        _26330 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_51178, _full_path_51177, _file_name_51173);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_51178);
        _try_51182 = _28open_locked(_file_path_51178);
        if (!IS_ATOM_INT(_try_51182)) {
            _1 = (object)(DBL_PTR(_try_51182)->dbl);
            DeRefDS(_try_51182);
            _try_51182 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_51182 == -1)
        goto L11; // [479] 514

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:526							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26334 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26334) && IS_ATOM(0)) {
            Append(&_26335, _26334, 0);
        }
        else if (IS_ATOM(_26334) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26335, _26334, 0);
            _26334 = NOVALUE;
        }
        _26334 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26335;
        if( _1 != _26335 ){
            DeRef(_1);
        }
        _26335 = NOVALUE;

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_51178);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51178;
        ((intptr_t *)_2)[2] = _try_51182;
        _26336 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51173);
        DeRefDSi(_env_51174);
        DeRefi(_inc_path_51176);
        DeRefDSi(_full_path_51177);
        DeRefDS(_file_path_51178);
        DeRef(_strings_51179);
        _26313 = NOVALUE;
        DeRef(_26308);
        _26308 = NOVALUE;
        DeRef(_26295);
        _26295 = NOVALUE;
        DeRef(_26316);
        _26316 = NOVALUE;
        return _26336;
L11: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:531						if find(1, full_path>=128) then*/
        _26337 = binary_op(GREATEREQ, _full_path_51177, 128);
        _26338 = find_from(1, _26337, 1);
        DeRefDS(_26337);
        _26337 = NOVALUE;
        if (_26338 == 0)
        {
            _26338 = NOVALUE;
            goto L12; // [527] 637
        }
        else{
            _26338 = NOVALUE;
        }

        /** pathopen.e:533							full_path = convert_from_OEM(full_path)*/
        RefDS(_full_path_51177);
        _0 = _full_path_51177;
        _full_path_51177 = _46convert_from_OEM(_full_path_51177);
        DeRefDS(_0);

        /** pathopen.e:534							file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51178, _full_path_51177, _file_name_51173);

        /** pathopen.e:535							try = open_locked(file_path)*/
        RefDS(_file_path_51178);
        _try_51182 = _28open_locked(_file_path_51178);
        if (!IS_ATOM_INT(_try_51182)) {
            _1 = (object)(DBL_PTR(_try_51182)->dbl);
            DeRefDS(_try_51182);
            _try_51182 = _1;
        }

        /** pathopen.e:536							if try != -1 then -- that was it; record translation as the valid path*/
        if (_try_51182 == -1)
        goto L13; // [554] 611

        /** pathopen.e:537								cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26343 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26343) && IS_ATOM(0)) {
            Append(&_26344, _26343, 0);
        }
        else if (IS_ATOM(_26343) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26344, _26343, 0);
            _26343 = NOVALUE;
        }
        _26343 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26344;
        if( _1 != _26344 ){
            DeRef(_1);
        }
        _26344 = NOVALUE;

        /** pathopen.e:538								cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        _26345 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        RefDS(_full_path_51177);
        Append(&_26346, _26345, _full_path_51177);
        _26345 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50770 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26346;
        if( _1 != _26346 ){
            DeRefDS(_1);
        }
        _26346 = NOVALUE;

        /** pathopen.e:539								return {file_path,try}*/
        RefDS(_file_path_51178);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51178;
        ((intptr_t *)_2)[2] = _try_51182;
        _26347 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51173);
        DeRefDSi(_env_51174);
        DeRefi(_inc_path_51176);
        DeRefDS(_full_path_51177);
        DeRefDS(_file_path_51178);
        DeRef(_strings_51179);
        DeRef(_26336);
        _26336 = NOVALUE;
        _26313 = NOVALUE;
        DeRef(_26308);
        _26308 = NOVALUE;
        DeRef(_26295);
        _26295 = NOVALUE;
        DeRef(_26316);
        _26316 = NOVALUE;
        return _26347;
        goto L14; // [608] 656
L13: 

        /** pathopen.e:541								cache_converted[num_var] = append(cache_converted[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26348 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        RefDS(_full_path_51177);
        Append(&_26349, _26348, _full_path_51177);
        _26348 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26349;
        if( _1 != _26349 ){
            DeRef(_1);
        }
        _26349 = NOVALUE;
        goto L14; // [634] 656
L12: 

        /** pathopen.e:544							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26350 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26350) && IS_ATOM(0)) {
            Append(&_26351, _26350, 0);
        }
        else if (IS_ATOM(_26350) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26351, _26350, 0);
            _26350 = NOVALUE;
        }
        _26350 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26351;
        if( _1 != _26351 ){
            DeRef(_1);
        }
        _26351 = NOVALUE;
L14: 

        /** pathopen.e:547					start_path = 0*/
        _start_path_51181 = 0;
        goto L10; // [662] 709
LD: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26352 = (_start_path_51181 == 0);
        if (_26352 == 0) {
            goto L15; // [670] 708
        }
        _2 = (object)SEQ_PTR(_inc_path_51176);
        _26354 = (object)*(((s1_ptr)_2)->base + _p_51232);
        _26355 = (_26354 != 32);
        _26354 = NOVALUE;
        if (_26355 == 0) {
            DeRef(_26356);
            _26356 = 0;
            goto L16; // [682] 698
        }
        _2 = (object)SEQ_PTR(_inc_path_51176);
        _26357 = (object)*(((s1_ptr)_2)->base + _p_51232);
        _26358 = (_26357 != 9);
        _26357 = NOVALUE;
        _26356 = (_26358 != 0);
L16: 
        if (_26356 == 0)
        {
            _26356 = NOVALUE;
            goto L15; // [699] 708
        }
        else{
            _26356 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_51181 = _p_51232;
L15: 
L10: 

        /** pathopen.e:552		end for*/
        _p_51232 = _p_51232 + 1;
        goto LB; // [711] 317
LC: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50774);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50774 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_51173);
    DeRefDSi(_env_51174);
    DeRefi(_inc_path_51176);
    DeRef(_full_path_51177);
    DeRef(_file_path_51178);
    DeRef(_strings_51179);
    DeRef(_26358);
    _26358 = NOVALUE;
    DeRef(_26336);
    _26336 = NOVALUE;
    DeRef(_26352);
    _26352 = NOVALUE;
    _26313 = NOVALUE;
    DeRef(_26355);
    _26355 = NOVALUE;
    DeRef(_26308);
    _26308 = NOVALUE;
    DeRef(_26347);
    _26347 = NOVALUE;
    DeRef(_26295);
    _26295 = NOVALUE;
    DeRef(_26316);
    _26316 = NOVALUE;
    return -1;
    ;
}


object _46Include_paths(object _add_converted_51296)
{
    object _status_51297 = NOVALUE;
    object _pos_51298 = NOVALUE;
    object _inc_path_51299 = NOVALUE;
    object _full_path_51300 = NOVALUE;
    object _start_path_51301 = NOVALUE;
    object _end_path_51302 = NOVALUE;
    object _eudir_path_51318 = NOVALUE;
    object _26419 = NOVALUE;
    object _26418 = NOVALUE;
    object _26417 = NOVALUE;
    object _26416 = NOVALUE;
    object _26415 = NOVALUE;
    object _26414 = NOVALUE;
    object _26413 = NOVALUE;
    object _26411 = NOVALUE;
    object _26410 = NOVALUE;
    object _26409 = NOVALUE;
    object _26408 = NOVALUE;
    object _26407 = NOVALUE;
    object _26406 = NOVALUE;
    object _26405 = NOVALUE;
    object _26404 = NOVALUE;
    object _26403 = NOVALUE;
    object _26402 = NOVALUE;
    object _26401 = NOVALUE;
    object _26400 = NOVALUE;
    object _26399 = NOVALUE;
    object _26398 = NOVALUE;
    object _26397 = NOVALUE;
    object _26396 = NOVALUE;
    object _26395 = NOVALUE;
    object _26394 = NOVALUE;
    object _26393 = NOVALUE;
    object _26392 = NOVALUE;
    object _26391 = NOVALUE;
    object _26389 = NOVALUE;
    object _26387 = NOVALUE;
    object _26386 = NOVALUE;
    object _26385 = NOVALUE;
    object _26384 = NOVALUE;
    object _26383 = NOVALUE;
    object _26380 = NOVALUE;
    object _26379 = NOVALUE;
    object _26377 = NOVALUE;
    object _26375 = NOVALUE;
    object _26373 = NOVALUE;
    object _26372 = NOVALUE;
    object _26370 = NOVALUE;
    object _26367 = NOVALUE;
    object _26365 = NOVALUE;
    object _26360 = NOVALUE;
    object _26359 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_51296)) {
        _1 = (object)(DBL_PTR(_add_converted_51296)->dbl);
        DeRefDS(_add_converted_51296);
        _add_converted_51296 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_46include_Paths_51293)){
            _26359 = SEQ_PTR(_46include_Paths_51293)->length;
    }
    else {
        _26359 = 1;
    }
    if (_26359 == 0)
    {
        _26359 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26359 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_46include_Paths_51293);
    DeRefi(_inc_path_51299);
    DeRefi(_full_path_51300);
    DeRef(_eudir_path_51318);
    return _46include_Paths_51293;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26360 = _15current_dir();
    Ref(_26360);
    Append(&_46include_Paths_51293, _46config_inc_paths_50776, _26360);
    DeRef(_26360);
    _26360 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _46num_var_50767 = find_from(_26362, _46cache_vars_50768, 1);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_51299);
    _inc_path_51299 = EGetEnv(_26362);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26365 = IS_ATOM(_inc_path_51299);
    if (_26365 == 0)
    {
        _26365 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26365 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_22209);
    DeRefi(_inc_path_51299);
    _inc_path_51299 = _22209;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26362);
    Ref(_inc_path_51299);
    _status_51297 = _46check_cache(_26362, _inc_path_51299);
    if (!IS_ATOM_INT(_status_51297)) {
        _1 = (object)(DBL_PTR(_status_51297)->dbl);
        DeRefDS(_status_51297);
        _status_51297 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_51299)){
            _26367 = SEQ_PTR(_inc_path_51299)->length;
    }
    else {
        _26367 = 1;
    }
    if (_26367 == 0)
    {
        _26367 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26367 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51299, _inc_path_51299, 59);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_51318;
    _eudir_path_51318 = _28get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26370 = IS_SEQUENCE(_eudir_path_51318);
    if (_26370 == 0)
    {
        _26370 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26370 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_51318);
    ((intptr_t*)_2)[1] = _eudir_path_51318;
    _26372 = MAKE_SEQ(_1);
    _26373 = EPrintf(-9999999, _26371, _26372);
    DeRefDS(_26372);
    _26372 = NOVALUE;
    RefDS(_26373);
    Append(&_46include_Paths_51293, _46include_Paths_51293, _26373);
    DeRefDS(_26373);
    _26373 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_51297 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_46cache_complete_50774);
    _26375 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    if (_26375 == 0)
    {
        _26375 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26375 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_46cache_delims_50775);
    _26377 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    _pos_51298 = _26377 + 1;
    _26377 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_51298 = 1;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_51301 = 0;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51299)){
            _26379 = SEQ_PTR(_inc_path_51299)->length;
    }
    else {
        _26379 = 1;
    }
    {
        object _p_51335;
        _p_51335 = _pos_51298;
L9: 
        if (_p_51335 > _26379){
            goto LA; // [179] 456
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51299);
        _26380 = (object)*(((s1_ptr)_2)->base + _p_51335);
        if (_26380 != 59)
        goto LB; // [194] 405

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_46cache_delims_50775);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_delims_50775 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        *(intptr_t *)_2 = _p_51335;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_51302 = _p_51335 - 1;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26383 = (_end_path_51302 >= _start_path_51301);
        if (_26383 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_51299);
        _26385 = (object)*(((s1_ptr)_2)->base + _end_path_51302);
        Concat((object_ptr)&_26386, _26319, _44SLASH_CHARS_20736);
        _26387 = find_from(_26385, _26386, 1);
        _26385 = NOVALUE;
        DeRefDS(_26386);
        _26386 = NOVALUE;
        if (_26387 == 0)
        {
            _26387 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26387 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_51302 = _end_path_51302 - 1;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_51301 == 0) {
            goto LE; // [259] 449
        }
        if (_end_path_51302 == 0)
        {
            goto LE; // [264] 449
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51300;
        RHS_Slice(_inc_path_51299, _start_path_51301, _end_path_51302);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        _26391 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        RefDS(_full_path_51300);
        Append(&_26392, _26391, _full_path_51300);
        _26391 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_substrings_50770);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_substrings_50770 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26392;
        if( _1 != _26392 ){
            DeRefDS(_1);
        }
        _26392 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        _26393 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26393) && IS_ATOM(_start_path_51301)) {
            Append(&_26394, _26393, _start_path_51301);
        }
        else if (IS_ATOM(_26393) && IS_SEQUENCE(_start_path_51301)) {
        }
        else {
            Concat((object_ptr)&_26394, _26393, _start_path_51301);
            _26393 = NOVALUE;
        }
        _26393 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_starts_50771);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_starts_50771 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26394;
        if( _1 != _26394 ){
            DeRef(_1);
        }
        _26394 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        _26395 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26395) && IS_ATOM(_end_path_51302)) {
            Append(&_26396, _26395, _end_path_51302);
        }
        else if (IS_ATOM(_26395) && IS_SEQUENCE(_end_path_51302)) {
        }
        else {
            Concat((object_ptr)&_26396, _26395, _end_path_51302);
            _26395 = NOVALUE;
        }
        _26395 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_ends_50772);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_ends_50772 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26396;
        if( _1 != _26396 ){
            DeRef(_1);
        }
        _26396 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:611						if find(1, full_path>=128) then*/
        _26397 = binary_op(GREATEREQ, _full_path_51300, 128);
        _26398 = find_from(1, _26397, 1);
        DeRefDS(_26397);
        _26397 = NOVALUE;
        if (_26398 == 0)
        {
            _26398 = NOVALUE;
            goto LF; // [345] 377
        }
        else{
            _26398 = NOVALUE;
        }

        /** pathopen.e:614							cache_converted[num_var] = append(cache_converted[num_var], */
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26399 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        RefDS(_full_path_51300);
        _26400 = _46convert_from_OEM(_full_path_51300);
        Ref(_26400);
        Append(&_26401, _26399, _26400);
        _26399 = NOVALUE;
        DeRef(_26400);
        _26400 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26401;
        if( _1 != _26401 ){
            DeRef(_1);
        }
        _26401 = NOVALUE;
        goto L10; // [374] 396
LF: 

        /** pathopen.e:617							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26402 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        if (IS_SEQUENCE(_26402) && IS_ATOM(0)) {
            Append(&_26403, _26402, 0);
        }
        else if (IS_ATOM(_26402) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_26403, _26402, 0);
            _26402 = NOVALUE;
        }
        _26402 = NOVALUE;
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _46cache_converted_50773 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26403;
        if( _1 != _26403 ){
            DeRef(_1);
        }
        _26403 = NOVALUE;
L10: 

        /** pathopen.e:620					start_path = 0*/
        _start_path_51301 = 0;
        goto LE; // [402] 449
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26404 = (_start_path_51301 == 0);
        if (_26404 == 0) {
            goto L11; // [410] 448
        }
        _2 = (object)SEQ_PTR(_inc_path_51299);
        _26406 = (object)*(((s1_ptr)_2)->base + _p_51335);
        _26407 = (_26406 != 32);
        _26406 = NOVALUE;
        if (_26407 == 0) {
            DeRef(_26408);
            _26408 = 0;
            goto L12; // [422] 438
        }
        _2 = (object)SEQ_PTR(_inc_path_51299);
        _26409 = (object)*(((s1_ptr)_2)->base + _p_51335);
        _26410 = (_26409 != 9);
        _26409 = NOVALUE;
        _26408 = (_26410 != 0);
L12: 
        if (_26408 == 0)
        {
            _26408 = NOVALUE;
            goto L11; // [439] 448
        }
        else{
            _26408 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_51301 = _p_51335;
L11: 
LE: 

        /** pathopen.e:625		end for*/
        _p_51335 = _p_51335 + 1;
        goto L9; // [451] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_46cache_substrings_50770);
    _26411 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    Concat((object_ptr)&_46include_Paths_51293, _46include_Paths_51293, _26411);
    _26411 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_46cache_complete_50774);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _46cache_complete_50774 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _46num_var_50767);
    *(intptr_t *)_2 = 1;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:632			if add_converted then*/
    if (_add_converted_51296 == 0)
    {
        goto L13; // [490] 562
    }
    else{
    }

    /** pathopen.e:633		    	for i=1 to length(cache_converted[num_var]) do*/
    _2 = (object)SEQ_PTR(_46cache_converted_50773);
    _26413 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
    if (IS_SEQUENCE(_26413)){
            _26414 = SEQ_PTR(_26413)->length;
    }
    else {
        _26414 = 1;
    }
    _26413 = NOVALUE;
    {
        object _i_51380;
        _i_51380 = 1;
L14: 
        if (_i_51380 > _26414){
            goto L15; // [506] 561
        }

        /** pathopen.e:634		        	if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26415 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26415);
        _26416 = (object)*(((s1_ptr)_2)->base + _i_51380);
        _26415 = NOVALUE;
        _26417 = IS_SEQUENCE(_26416);
        _26416 = NOVALUE;
        if (_26417 == 0)
        {
            _26417 = NOVALUE;
            goto L16; // [530] 554
        }
        else{
            _26417 = NOVALUE;
        }

        /** pathopen.e:635			        	include_Paths = append(include_Paths, cache_converted[num_var][i])*/
        _2 = (object)SEQ_PTR(_46cache_converted_50773);
        _26418 = (object)*(((s1_ptr)_2)->base + _46num_var_50767);
        _2 = (object)SEQ_PTR(_26418);
        _26419 = (object)*(((s1_ptr)_2)->base + _i_51380);
        _26418 = NOVALUE;
        Ref(_26419);
        Append(&_46include_Paths_51293, _46include_Paths_51293, _26419);
        _26419 = NOVALUE;
L16: 

        /** pathopen.e:637				end for*/
        _i_51380 = _i_51380 + 1;
        goto L14; // [556] 513
L15: 
        ;
    }
L13: 

    /** pathopen.e:640		return include_Paths*/
    RefDS(_46include_Paths_51293);
    DeRefi(_inc_path_51299);
    DeRefi(_full_path_51300);
    DeRef(_eudir_path_51318);
    _26413 = NOVALUE;
    _26380 = NOVALUE;
    DeRef(_26404);
    _26404 = NOVALUE;
    DeRef(_26410);
    _26410 = NOVALUE;
    DeRef(_26407);
    _26407 = NOVALUE;
    DeRef(_26383);
    _26383 = NOVALUE;
    return _46include_Paths_51293;
    ;
}


object _46e_path_find(object _name_51392)
{
    object _scan_result_51393 = NOVALUE;
    object _26429 = NOVALUE;
    object _26428 = NOVALUE;
    object _26427 = NOVALUE;
    object _26424 = NOVALUE;
    object _26423 = NOVALUE;
    object _26422 = NOVALUE;
    object _26421 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_51392);
    _26421 = _15file_exists(_name_51392);
    if (_26421 == 0) {
        DeRef(_26421);
        _26421 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26421) && DBL_PTR(_26421)->dbl == 0.0){
            DeRef(_26421);
            _26421 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26421);
        _26421 = NOVALUE;
    }
    DeRef(_26421);
    _26421 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_51393);
    return _name_51392;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_44SLASH_CHARS_20736)){
            _26422 = SEQ_PTR(_44SLASH_CHARS_20736)->length;
    }
    else {
        _26422 = 1;
    }
    {
        object _i_51398;
        _i_51398 = 1;
L2: 
        if (_i_51398 > _26422){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_44SLASH_CHARS_20736);
        _26423 = (object)*(((s1_ptr)_2)->base + _i_51398);
        _26424 = find_from(_26423, _name_51392, 1);
        _26423 = NOVALUE;
        if (_26424 == 0)
        {
            _26424 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26424 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_51392);
        DeRef(_scan_result_51393);
        return -1;
L4: 

        /** pathopen.e:665		end for*/
        _i_51398 = _i_51398 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_51392);
    RefDS(_26425);
    _0 = _scan_result_51393;
    _scan_result_51393 = _46ScanPath(_name_51392, _26425, 0);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26427 = IS_SEQUENCE(_scan_result_51393);
    if (_26427 == 0)
    {
        _26427 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26427 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_51393);
    _26428 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26428))
    EClose(_26428);
    else
    EClose((object)DBL_PTR(_26428)->dbl);
    _26428 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_51393);
    _26429 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_26429);
    DeRefDS(_name_51392);
    DeRef(_scan_result_51393);
    return _26429;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_51392);
    DeRef(_scan_result_51393);
    _26429 = NOVALUE;
    return -1;
    ;
}



// 0x0F08EE3A
