// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _66advance(object _pc_53955, object _code_53956)
{
    object _27394 = NOVALUE;
    object _27392 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:63		prev_pc = pc*/
    _66prev_pc_53938 = _pc_53955;

    /** inline.e:64		if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_53956)){
            _27392 = SEQ_PTR(_code_53956)->length;
    }
    else {
        _27392 = 1;
    }
    if (_pc_53955 <= _27392)
    goto L1; // [15] 26

    /** inline.e:65			return pc*/
    DeRefDS(_code_53956);
    return _pc_53955;
L1: 

    /** inline.e:67		return shift:advance( pc, code )*/
    RefDS(_code_53956);
    _27394 = _65advance(_pc_53955, _code_53956);
    DeRefDS(_code_53956);
    return _27394;
    ;
}


void _66shift(object _start_53963, object _amount_53964, object _bound_53965)
{
    object _temp_LineTable_53966 = NOVALUE;
    object _temp_Code_53968 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_53964)) {
        _1 = (object)(DBL_PTR(_amount_53964)->dbl);
        DeRefDS(_amount_53964);
        _amount_53964 = _1;
    }

    /** inline.e:72			temp_LineTable = LineTable,*/
    RefDS(_27LineTable_20661);
    DeRef(_temp_LineTable_53966);
    _temp_LineTable_53966 = _27LineTable_20661;

    /** inline.e:73			temp_Code = Code*/
    RefDS(_27Code_20660);
    DeRef(_temp_Code_53968);
    _temp_Code_53968 = _27Code_20660;

    /** inline.e:74		LineTable = {}*/
    RefDS(_22209);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22209;

    /** inline.e:75		Code = inline_code*/
    RefDS(_66inline_code_53930);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _66inline_code_53930;

    /** inline.e:76		inline_code = {}*/
    RefDS(_22209);
    DeRefDS(_66inline_code_53930);
    _66inline_code_53930 = _22209;

    /** inline.e:78		shift:shift( start, amount, bound )*/
    _65shift(_start_53963, _amount_53964, _bound_53965);

    /** inline.e:80		LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_53966);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _temp_LineTable_53966;

    /** inline.e:81		inline_code = Code*/
    RefDS(_27Code_20660);
    DeRefDS(_66inline_code_53930);
    _66inline_code_53930 = _27Code_20660;

    /** inline.e:82		Code = temp_Code*/
    RefDS(_temp_Code_53968);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _temp_Code_53968;

    /** inline.e:83	end procedure*/
    DeRefDS(_temp_LineTable_53966);
    DeRefDS(_temp_Code_53968);
    return;
    ;
}


void _66replace_code(object _code_53983, object _start_53984, object _finish_53985)
{
    object _27401 = NOVALUE;
    object _27400 = NOVALUE;
    object _27399 = NOVALUE;
    object _27398 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_53985)) {
        _1 = (object)(DBL_PTR(_finish_53985)->dbl);
        DeRefDS(_finish_53985);
        _finish_53985 = _1;
    }

    /** inline.e:92		inline_code = replace( inline_code, code, start, finish )*/
    {
        intptr_t p1 = _66inline_code_53930;
        intptr_t p2 = _code_53983;
        intptr_t p3 = _start_53984;
        intptr_t p4 = _finish_53985;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_66inline_code_53930;
        Replace( &replace_params );
    }

    /** inline.e:93		shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_53983)){
            _27398 = SEQ_PTR(_code_53983)->length;
    }
    else {
        _27398 = 1;
    }
    _27399 = _finish_53985 - _start_53984;
    if ((object)((uintptr_t)_27399 +(uintptr_t) HIGH_BITS) >= 0){
        _27399 = NewDouble((eudouble)_27399);
    }
    if (IS_ATOM_INT(_27399)) {
        _27400 = _27399 + 1;
        if (_27400 > MAXINT){
            _27400 = NewDouble((eudouble)_27400);
        }
    }
    else
    _27400 = binary_op(PLUS, 1, _27399);
    DeRef(_27399);
    _27399 = NOVALUE;
    if (IS_ATOM_INT(_27400)) {
        _27401 = _27398 - _27400;
        if ((object)((uintptr_t)_27401 +(uintptr_t) HIGH_BITS) >= 0){
            _27401 = NewDouble((eudouble)_27401);
        }
    }
    else {
        _27401 = NewDouble((eudouble)_27398 - DBL_PTR(_27400)->dbl);
    }
    _27398 = NOVALUE;
    DeRef(_27400);
    _27400 = NOVALUE;
    _66shift(_start_53984, _27401, _finish_53985);
    _27401 = NOVALUE;

    /** inline.e:94	end procedure*/
    DeRefDS(_code_53983);
    return;
    ;
}


void _66defer()
{
    object _dx_53993 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:101		integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_53993 = find_from(_66inline_sub_53944, _66deferred_inline_decisions_53946, 1);

    /** inline.e:102		if not dx then*/
    if (_dx_53993 != 0)
    goto L1; // [14] 36

    /** inline.e:103			deferred_inline_decisions &= inline_sub*/
    Append(&_66deferred_inline_decisions_53946, _66deferred_inline_decisions_53946, _66inline_sub_53944);

    /** inline.e:104			deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_22209);
    Append(&_66deferred_inline_calls_53947, _66deferred_inline_calls_53947, _22209);
L1: 

    /** inline.e:106	end procedure*/
    return;
    ;
}


object _66new_inline_temp(object _sym_54002)
{
    object _27407 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:110		inline_temps &= sym*/
    Append(&_66inline_temps_53932, _66inline_temps_53932, _sym_54002);

    /** inline.e:111		return length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_53932)){
            _27407 = SEQ_PTR(_66inline_temps_53932)->length;
    }
    else {
        _27407 = 1;
    }
    return _27407;
    ;
}


object _66get_inline_temp(object _sym_54008)
{
    object _temp_num_54009 = NOVALUE;
    object _27411 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:117		integer temp_num = find( sym, inline_params )*/
    _temp_num_54009 = find_from(_sym_54008, _66inline_params_53935, 1);

    /** inline.e:118		if temp_num then*/
    if (_temp_num_54009 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** inline.e:119			return temp_num*/
    return _temp_num_54009;
L1: 

    /** inline.e:122		temp_num = find( sym, proc_vars )*/
    _temp_num_54009 = find_from(_sym_54008, _66proc_vars_53931, 1);

    /** inline.e:123		if temp_num then*/
    if (_temp_num_54009 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** inline.e:124			return temp_num*/
    return _temp_num_54009;
L2: 

    /** inline.e:127		temp_num = find( sym, inline_temps )*/
    _temp_num_54009 = find_from(_sym_54008, _66inline_temps_53932, 1);

    /** inline.e:128		if temp_num then*/
    if (_temp_num_54009 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** inline.e:129			return temp_num*/
    return _temp_num_54009;
L3: 

    /** inline.e:132		return new_inline_temp( sym )*/
    _27411 = _66new_inline_temp(_sym_54008);
    return _27411;
    ;
}


object _66generic_symbol(object _sym_54020)
{
    object _inline_type_54021 = NOVALUE;
    object _px_54022 = NOVALUE;
    object _eentry_54029 = NOVALUE;
    object _27420 = NOVALUE;
    object _27419 = NOVALUE;
    object _27418 = NOVALUE;
    object _27417 = NOVALUE;
    object _27415 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:137		integer px = find( sym, inline_params )*/
    _px_54022 = find_from(_sym_54020, _66inline_params_53935, 1);

    /** inline.e:138		if px then*/
    if (_px_54022 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** inline.e:139			inline_type = INLINE_PARAM*/
    _inline_type_54021 = 1;
    goto L2; // [22] 100
L1: 

    /** inline.e:141			px = find( sym, proc_vars )*/
    _px_54022 = find_from(_sym_54020, _66proc_vars_53931, 1);

    /** inline.e:142			if px then*/
    if (_px_54022 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** inline.e:143				inline_type = INLINE_VAR*/
    _inline_type_54021 = 6;
    goto L4; // [44] 99
L3: 

    /** inline.e:145				sequence eentry = SymTab[sym]*/
    DeRef(_eentry_54029);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_54029 = (object)*(((s1_ptr)_2)->base + _sym_54020);
    Ref(_eentry_54029);

    /** inline.e:146				if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27415 = _66is_literal(_sym_54020);
    if (IS_ATOM_INT(_27415)) {
        if (_27415 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27415)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (object)SEQ_PTR(_eentry_54029);
    _27417 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_27417)) {
        _27418 = (_27417 > 3);
    }
    else {
        _27418 = binary_op(GREATER, _27417, 3);
    }
    _27417 = NOVALUE;
    if (_27418 == 0) {
        DeRef(_27418);
        _27418 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27418) && DBL_PTR(_27418)->dbl == 0.0){
            DeRef(_27418);
            _27418 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27418);
        _27418 = NOVALUE;
    }
    DeRef(_27418);
    _27418 = NOVALUE;
L5: 

    /** inline.e:147					return sym*/
    DeRef(_eentry_54029);
    DeRef(_27415);
    _27415 = NOVALUE;
    return _sym_54020;
L6: 

    /** inline.e:149				inline_type = INLINE_TEMP*/
    _inline_type_54021 = 2;
    DeRef(_eentry_54029);
    _eentry_54029 = NOVALUE;
L4: 
L2: 

    /** inline.e:153		return { inline_type, get_inline_temp( sym ) }*/
    _27419 = _66get_inline_temp(_sym_54020);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _inline_type_54021;
    ((intptr_t *)_2)[2] = _27419;
    _27420 = MAKE_SEQ(_1);
    _27419 = NOVALUE;
    DeRef(_27415);
    _27415 = NOVALUE;
    return _27420;
    ;
}


object _66adjust_symbol(object _pc_54044)
{
    object _sym_54046 = NOVALUE;
    object _eentry_54052 = NOVALUE;
    object _27428 = NOVALUE;
    object _27426 = NOVALUE;
    object _27425 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54044)) {
        _1 = (object)(DBL_PTR(_pc_54044)->dbl);
        DeRefDS(_pc_54044);
        _pc_54044 = _1;
    }

    /** inline.e:160		symtab_index sym = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _sym_54046 = (object)*(((s1_ptr)_2)->base + _pc_54044);
    if (!IS_ATOM_INT(_sym_54046)){
        _sym_54046 = (object)DBL_PTR(_sym_54046)->dbl;
    }

    /** inline.e:161		if sym < 0 then*/
    if (_sym_54046 >= 0)
    goto L1; // [15] 28

    /** inline.e:162			return 0*/
    DeRef(_eentry_54052);
    return 0;
    goto L2; // [25] 41
L1: 

    /** inline.e:163		elsif not sym then*/
    if (_sym_54046 != 0)
    goto L3; // [30] 40

    /** inline.e:165			return 1*/
    DeRef(_eentry_54052);
    return 1;
L3: 
L2: 

    /** inline.e:168		sequence eentry = SymTab[sym]*/
    DeRef(_eentry_54052);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_54052 = (object)*(((s1_ptr)_2)->base + _sym_54046);
    Ref(_eentry_54052);

    /** inline.e:169		if is_literal( sym ) then*/
    _27425 = _66is_literal(_sym_54046);
    if (_27425 == 0) {
        DeRef(_27425);
        _27425 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27425) && DBL_PTR(_27425)->dbl == 0.0){
            DeRef(_27425);
            _27425 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27425);
        _27425 = NOVALUE;
    }
    DeRef(_27425);
    _27425 = NOVALUE;

    /** inline.e:170			return 1*/
    DeRefDS(_eentry_54052);
    return 1;
    goto L5; // [66] 95
L4: 

    /** inline.e:172		elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_eentry_54052);
    _27426 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _27426, 9)){
        _27426 = NOVALUE;
        goto L6; // [79] 94
    }
    _27426 = NOVALUE;

    /** inline.e:173			defer()*/
    _66defer();

    /** inline.e:174			return 0*/
    DeRefDS(_eentry_54052);
    return 0;
L6: 
L5: 

    /** inline.e:177		inline_code[pc] = generic_symbol( sym )*/
    _27428 = _66generic_symbol(_sym_54046);
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54044);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27428;
    if( _1 != _27428 ){
        DeRef(_1);
    }
    _27428 = NOVALUE;

    /** inline.e:178		return 1*/
    DeRef(_eentry_54052);
    return 1;
    ;
}


object _66check_for_param(object _pc_54066)
{
    object _px_54067 = NOVALUE;
    object _27431 = NOVALUE;
    object _27429 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54066)) {
        _1 = (object)(DBL_PTR(_pc_54066)->dbl);
        DeRefDS(_pc_54066);
        _pc_54066 = _1;
    }

    /** inline.e:182		integer px = find( inline_code[pc], inline_params )*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27429 = (object)*(((s1_ptr)_2)->base + _pc_54066);
    _px_54067 = find_from(_27429, _66inline_params_53935, 1);
    _27429 = NOVALUE;

    /** inline.e:183		if px then*/
    if (_px_54067 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** inline.e:184			if not find( px, assigned_params ) then*/
    _27431 = find_from(_px_54067, _66assigned_params_53936, 1);
    if (_27431 != 0)
    goto L2; // [32] 44
    _27431 = NOVALUE;

    /** inline.e:185				assigned_params &= px*/
    Append(&_66assigned_params_53936, _66assigned_params_53936, _px_54067);
L2: 

    /** inline.e:187			return 1*/
    return 1;
L1: 

    /** inline.e:189		return 0*/
    return 0;
    ;
}


void _66check_target(object _pc_54077, object _op_54078)
{
    object _targets_54079 = NOVALUE;
    object _27440 = NOVALUE;
    object _27439 = NOVALUE;
    object _27438 = NOVALUE;
    object _27437 = NOVALUE;
    object _27436 = NOVALUE;
    object _27434 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:194		sequence targets = op_info[op][OP_TARGET]*/
    _2 = (object)SEQ_PTR(_65op_info_24613);
    _27434 = (object)*(((s1_ptr)_2)->base + _op_54078);
    DeRef(_targets_54079);
    _2 = (object)SEQ_PTR(_27434);
    _targets_54079 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_54079);
    _27434 = NOVALUE;

    /** inline.e:196		if length( targets ) then*/
    if (IS_SEQUENCE(_targets_54079)){
            _27436 = SEQ_PTR(_targets_54079)->length;
    }
    else {
        _27436 = 1;
    }
    if (_27436 == 0)
    {
        _27436 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27436 = NOVALUE;
    }

    /** inline.e:197		for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_54079)){
            _27437 = SEQ_PTR(_targets_54079)->length;
    }
    else {
        _27437 = 1;
    }
    {
        object _i_54087;
        _i_54087 = 1;
L2: 
        if (_i_54087 > _27437){
            goto L3; // [34] 71
        }

        /** inline.e:198				if check_for_param( pc + targets[i] ) then*/
        _2 = (object)SEQ_PTR(_targets_54079);
        _27438 = (object)*(((s1_ptr)_2)->base + _i_54087);
        if (IS_ATOM_INT(_27438)) {
            _27439 = _pc_54077 + _27438;
            if ((object)((uintptr_t)_27439 + (uintptr_t)HIGH_BITS) >= 0){
                _27439 = NewDouble((eudouble)_27439);
            }
        }
        else {
            _27439 = binary_op(PLUS, _pc_54077, _27438);
        }
        _27438 = NOVALUE;
        _27440 = _66check_for_param(_27439);
        _27439 = NOVALUE;
        if (_27440 == 0) {
            DeRef(_27440);
            _27440 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27440) && DBL_PTR(_27440)->dbl == 0.0){
                DeRef(_27440);
                _27440 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27440);
            _27440 = NOVALUE;
        }
        DeRef(_27440);
        _27440 = NOVALUE;

        /** inline.e:199					return*/
        DeRefDS(_targets_54079);
        return;
L4: 

        /** inline.e:201			end for*/
        _i_54087 = _i_54087 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** inline.e:203	end procedure*/
    DeRef(_targets_54079);
    return;
    ;
}


object _66adjust_il(object _pc_54095, object _op_54096)
{
    object _addr_54104 = NOVALUE;
    object _sub_54110 = NOVALUE;
    object _27465 = NOVALUE;
    object _27464 = NOVALUE;
    object _27463 = NOVALUE;
    object _27462 = NOVALUE;
    object _27461 = NOVALUE;
    object _27460 = NOVALUE;
    object _27459 = NOVALUE;
    object _27457 = NOVALUE;
    object _27456 = NOVALUE;
    object _27455 = NOVALUE;
    object _27454 = NOVALUE;
    object _27453 = NOVALUE;
    object _27452 = NOVALUE;
    object _27451 = NOVALUE;
    object _27450 = NOVALUE;
    object _27448 = NOVALUE;
    object _27447 = NOVALUE;
    object _27445 = NOVALUE;
    object _27444 = NOVALUE;
    object _27443 = NOVALUE;
    object _27442 = NOVALUE;
    object _27441 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:208		for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (object)SEQ_PTR(_65op_info_24613);
    _27441 = (object)*(((s1_ptr)_2)->base + _op_54096);
    _2 = (object)SEQ_PTR(_27441);
    _27442 = (object)*(((s1_ptr)_2)->base + 2);
    _27441 = NOVALUE;
    if (IS_ATOM_INT(_27442)) {
        _27443 = _27442 - 1;
        if ((object)((uintptr_t)_27443 +(uintptr_t) HIGH_BITS) >= 0){
            _27443 = NewDouble((eudouble)_27443);
        }
    }
    else {
        _27443 = binary_op(MINUS, _27442, 1);
    }
    _27442 = NOVALUE;
    {
        object _i_54098;
        _i_54098 = 1;
L1: 
        if (binary_op_a(GREATER, _i_54098, _27443)){
            goto L2; // [23] 214
        }

        /** inline.e:210			integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (object)SEQ_PTR(_65op_info_24613);
        _27444 = (object)*(((s1_ptr)_2)->base + _op_54096);
        _2 = (object)SEQ_PTR(_27444);
        _27445 = (object)*(((s1_ptr)_2)->base + 3);
        _27444 = NOVALUE;
        _addr_54104 = find_from(_i_54098, _27445, 1);
        _27445 = NOVALUE;

        /** inline.e:211			integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (object)SEQ_PTR(_65op_info_24613);
        _27447 = (object)*(((s1_ptr)_2)->base + _op_54096);
        _2 = (object)SEQ_PTR(_27447);
        _27448 = (object)*(((s1_ptr)_2)->base + 5);
        _27447 = NOVALUE;
        _sub_54110 = find_from(_i_54098, _27448, 1);
        _27448 = NOVALUE;

        /** inline.e:212			if addr then*/
        if (_addr_54104 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** inline.e:213				if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_54098)) {
            _27450 = _pc_54095 + _i_54098;
        }
        else {
            _27450 = NewDouble((eudouble)_pc_54095 + DBL_PTR(_i_54098)->dbl);
        }
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        if (!IS_ATOM_INT(_27450)){
            _27451 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27450)->dbl));
        }
        else{
            _27451 = (object)*(((s1_ptr)_2)->base + _27450);
        }
        if (IS_ATOM_INT(_27451))
        _27452 = 1;
        else if (IS_ATOM_DBL(_27451))
        _27452 = IS_ATOM_INT(DoubleToInt(_27451));
        else
        _27452 = 0;
        _27451 = NOVALUE;
        if (_27452 == 0)
        {
            _27452 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27452 = NOVALUE;
        }

        /** inline.e:214					inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_54098)) {
            _27453 = _pc_54095 + _i_54098;
            if ((object)((uintptr_t)_27453 + (uintptr_t)HIGH_BITS) >= 0){
                _27453 = NewDouble((eudouble)_27453);
            }
        }
        else {
            _27453 = NewDouble((eudouble)_pc_54095 + DBL_PTR(_i_54098)->dbl);
        }
        if (IS_ATOM_INT(_i_54098)) {
            _27454 = _pc_54095 + _i_54098;
        }
        else {
            _27454 = NewDouble((eudouble)_pc_54095 + DBL_PTR(_i_54098)->dbl);
        }
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        if (!IS_ATOM_INT(_27454)){
            _27455 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27454)->dbl));
        }
        else{
            _27455 = (object)*(((s1_ptr)_2)->base + _27454);
        }
        Ref(_27455);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 4;
        ((intptr_t *)_2)[2] = _27455;
        _27456 = MAKE_SEQ(_1);
        _27455 = NOVALUE;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53930 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27453))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27453)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27453);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27456;
        if( _1 != _27456 ){
            DeRef(_1);
        }
        _27456 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** inline.e:217			elsif sub then*/
        if (_sub_54110 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** inline.e:218				inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_54098)) {
            _27457 = _pc_54095 + _i_54098;
        }
        else {
            _27457 = NewDouble((eudouble)_pc_54095 + DBL_PTR(_i_54098)->dbl);
        }
        RefDS(_27458);
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53930 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27457))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27457)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27457);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27458;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** inline.e:220				if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27459 = (_op_54096 != 58);
        if (_27459 == 0) {
            _27460 = 0;
            goto L6; // [149] 163
        }
        _27461 = (_op_54096 != 210);
        _27460 = (_27461 != 0);
L6: 
        if (_27460 == 0) {
            goto L7; // [163] 204
        }
        _27463 = (_op_54096 != 211);
        if (_27463 == 0)
        {
            DeRef(_27463);
            _27463 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27463);
            _27463 = NOVALUE;
        }

        /** inline.e:221					check_target( pc, op )*/
        _66check_target(_pc_54095, _op_54096);

        /** inline.e:222					if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_54098)) {
            _27464 = _pc_54095 + _i_54098;
            if ((object)((uintptr_t)_27464 + (uintptr_t)HIGH_BITS) >= 0){
                _27464 = NewDouble((eudouble)_27464);
            }
        }
        else {
            _27464 = NewDouble((eudouble)_pc_54095 + DBL_PTR(_i_54098)->dbl);
        }
        _27465 = _66adjust_symbol(_27464);
        _27464 = NOVALUE;
        if (IS_ATOM_INT(_27465)) {
            if (_27465 != 0){
                DeRef(_27465);
                _27465 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27465)->dbl != 0.0){
                DeRef(_27465);
                _27465 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27465);
        _27465 = NOVALUE;

        /** inline.e:223						return 0*/
        DeRef(_i_54098);
        DeRef(_27459);
        _27459 = NOVALUE;
        DeRef(_27453);
        _27453 = NOVALUE;
        DeRef(_27457);
        _27457 = NOVALUE;
        DeRef(_27450);
        _27450 = NOVALUE;
        DeRef(_27454);
        _27454 = NOVALUE;
        DeRef(_27443);
        _27443 = NOVALUE;
        DeRef(_27461);
        _27461 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** inline.e:227		end for*/
        _0 = _i_54098;
        if (IS_ATOM_INT(_i_54098)) {
            _i_54098 = _i_54098 + 1;
            if ((object)((uintptr_t)_i_54098 +(uintptr_t) HIGH_BITS) >= 0){
                _i_54098 = NewDouble((eudouble)_i_54098);
            }
        }
        else {
            _i_54098 = binary_op_a(PLUS, _i_54098, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_54098);
    }

    /** inline.e:228		return 1*/
    DeRef(_27459);
    _27459 = NOVALUE;
    DeRef(_27453);
    _27453 = NOVALUE;
    DeRef(_27457);
    _27457 = NOVALUE;
    DeRef(_27450);
    _27450 = NOVALUE;
    DeRef(_27454);
    _27454 = NOVALUE;
    DeRef(_27443);
    _27443 = NOVALUE;
    DeRef(_27461);
    _27461 = NOVALUE;
    return 1;
    ;
}


object _66is_temp(object _sym_54145)
{
    object _27476 = NOVALUE;
    object _27475 = NOVALUE;
    object _27474 = NOVALUE;
    object _27473 = NOVALUE;
    object _27472 = NOVALUE;
    object _27471 = NOVALUE;
    object _27470 = NOVALUE;
    object _27469 = NOVALUE;
    object _27468 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:232		if sym <= 0 then*/
    if (_sym_54145 > 0)
    goto L1; // [5] 16

    /** inline.e:233			return 0*/
    return 0;
L1: 

    /** inline.e:236		return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27468 = (object)*(((s1_ptr)_2)->base + _sym_54145);
    _2 = (object)SEQ_PTR(_27468);
    _27469 = (object)*(((s1_ptr)_2)->base + 3);
    _27468 = NOVALUE;
    if (IS_ATOM_INT(_27469)) {
        _27470 = (_27469 == 3);
    }
    else {
        _27470 = binary_op(EQUALS, _27469, 3);
    }
    _27469 = NOVALUE;
    _27471 = (_27TRANSLATE_20179 == 0);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27472 = (object)*(((s1_ptr)_2)->base + _sym_54145);
    _2 = (object)SEQ_PTR(_27472);
    _27473 = (object)*(((s1_ptr)_2)->base + 1);
    _27472 = NOVALUE;
    if (_27NOVALUE_20426 == _27473)
    _27474 = 1;
    else if (IS_ATOM_INT(_27NOVALUE_20426) && IS_ATOM_INT(_27473))
    _27474 = 0;
    else
    _27474 = (compare(_27NOVALUE_20426, _27473) == 0);
    _27473 = NOVALUE;
    _27475 = (_27471 != 0 || _27474 != 0);
    _27471 = NOVALUE;
    _27474 = NOVALUE;
    if (IS_ATOM_INT(_27470)) {
        _27476 = (_27470 != 0 && _27475 != 0);
    }
    else {
        _27476 = binary_op(AND, _27470, _27475);
    }
    DeRef(_27470);
    _27470 = NOVALUE;
    _27475 = NOVALUE;
    return _27476;
    ;
}


object _66is_literal(object _sym_54167)
{
    object _mode_54170 = NOVALUE;
    object _27491 = NOVALUE;
    object _27490 = NOVALUE;
    object _27489 = NOVALUE;
    object _27488 = NOVALUE;
    object _27487 = NOVALUE;
    object _27486 = NOVALUE;
    object _27484 = NOVALUE;
    object _27483 = NOVALUE;
    object _27482 = NOVALUE;
    object _27481 = NOVALUE;
    object _27480 = NOVALUE;
    object _27478 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:240		if sym <= 0 then*/
    if (_sym_54167 > 0)
    goto L1; // [5] 16

    /** inline.e:241			return 0*/
    return 0;
L1: 

    /** inline.e:244		integer mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27478 = (object)*(((s1_ptr)_2)->base + _sym_54167);
    _2 = (object)SEQ_PTR(_27478);
    _mode_54170 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_54170)){
        _mode_54170 = (object)DBL_PTR(_mode_54170)->dbl;
    }
    _27478 = NOVALUE;

    /** inline.e:245		if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27480 = (_mode_54170 == 2);
    if (_27480 == 0) {
        _27481 = 0;
        goto L2; // [40] 66
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27482 = (object)*(((s1_ptr)_2)->base + _sym_54167);
    _2 = (object)SEQ_PTR(_27482);
    _27483 = (object)*(((s1_ptr)_2)->base + 1);
    _27482 = NOVALUE;
    if (IS_ATOM_INT(_27NOVALUE_20426) && IS_ATOM_INT(_27483)){
        _27484 = (_27NOVALUE_20426 < _27483) ? -1 : (_27NOVALUE_20426 > _27483);
    }
    else{
        _27484 = compare(_27NOVALUE_20426, _27483);
    }
    _27483 = NOVALUE;
    _27481 = (_27484 != 0);
L2: 
    if (_27481 != 0) {
        goto L3; // [66] 117
    }
    if (_27TRANSLATE_20179 == 0) {
        _27486 = 0;
        goto L4; // [72] 86
    }
    _27487 = (_mode_54170 == 3);
    _27486 = (_27487 != 0);
L4: 
    if (_27486 == 0) {
        DeRef(_27488);
        _27488 = 0;
        goto L5; // [86] 112
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27489 = (object)*(((s1_ptr)_2)->base + _sym_54167);
    _2 = (object)SEQ_PTR(_27489);
    _27490 = (object)*(((s1_ptr)_2)->base + 1);
    _27489 = NOVALUE;
    if (IS_ATOM_INT(_27490) && IS_ATOM_INT(_27NOVALUE_20426)){
        _27491 = (_27490 < _27NOVALUE_20426) ? -1 : (_27490 > _27NOVALUE_20426);
    }
    else{
        _27491 = compare(_27490, _27NOVALUE_20426);
    }
    _27490 = NOVALUE;
    _27488 = (_27491 != 0);
L5: 
    if (_27488 == 0)
    {
        _27488 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27488 = NOVALUE;
    }
L3: 

    /** inline.e:247			return 1*/
    DeRef(_27480);
    _27480 = NOVALUE;
    DeRef(_27487);
    _27487 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** inline.e:249			return 0*/
    DeRef(_27480);
    _27480 = NOVALUE;
    DeRef(_27487);
    _27487 = NOVALUE;
    return 0;
L7: 
    ;
}


object _66returnf(object _pc_54217)
{
    object _retsym_54219 = NOVALUE;
    object _code_54252 = NOVALUE;
    object _ret_pc_54253 = NOVALUE;
    object _code_54298 = NOVALUE;
    object _ret_pc_54312 = NOVALUE;
    object _27564 = NOVALUE;
    object _27563 = NOVALUE;
    object _27561 = NOVALUE;
    object _27559 = NOVALUE;
    object _27558 = NOVALUE;
    object _27556 = NOVALUE;
    object _27555 = NOVALUE;
    object _27553 = NOVALUE;
    object _27552 = NOVALUE;
    object _27551 = NOVALUE;
    object _27549 = NOVALUE;
    object _27548 = NOVALUE;
    object _27546 = NOVALUE;
    object _27544 = NOVALUE;
    object _27543 = NOVALUE;
    object _27541 = NOVALUE;
    object _27540 = NOVALUE;
    object _27538 = NOVALUE;
    object _27537 = NOVALUE;
    object _27536 = NOVALUE;
    object _27534 = NOVALUE;
    object _27533 = NOVALUE;
    object _27532 = NOVALUE;
    object _27531 = NOVALUE;
    object _27530 = NOVALUE;
    object _27528 = NOVALUE;
    object _27527 = NOVALUE;
    object _27526 = NOVALUE;
    object _27525 = NOVALUE;
    object _27523 = NOVALUE;
    object _27521 = NOVALUE;
    object _27520 = NOVALUE;
    object _27519 = NOVALUE;
    object _27518 = NOVALUE;
    object _27517 = NOVALUE;
    object _27516 = NOVALUE;
    object _27515 = NOVALUE;
    object _27514 = NOVALUE;
    object _27513 = NOVALUE;
    object _27511 = NOVALUE;
    object _27510 = NOVALUE;
    object _27509 = NOVALUE;
    object _27507 = NOVALUE;
    object _27506 = NOVALUE;
    object _27505 = NOVALUE;
    object _27504 = NOVALUE;
    object _27503 = NOVALUE;
    object _27502 = NOVALUE;
    object _27500 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:259		symtab_index retsym = inline_code[pc+3]*/
    _27500 = _pc_54217 + 3;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _retsym_54219 = (object)*(((s1_ptr)_2)->base + _27500);
    if (!IS_ATOM_INT(_retsym_54219)){
        _retsym_54219 = (object)DBL_PTR(_retsym_54219)->dbl;
    }

    /** inline.e:260		if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27502 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27502 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27503 = (object)*(((s1_ptr)_2)->base + _27502);
    if (_27503 == 43)
    _27504 = 1;
    else if (IS_ATOM_INT(_27503) && IS_ATOM_INT(43))
    _27504 = 0;
    else
    _27504 = (compare(_27503, 43) == 0);
    _27503 = NOVALUE;
    if (_27504 == 0)
    {
        _27504 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27504 = NOVALUE;
    }

    /** inline.e:261			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** inline.e:262				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27505 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27505 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27505);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** inline.e:263			elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27506 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53944);
    _2 = (object)SEQ_PTR(_27506);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _27507 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _27507 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _27506 = NOVALUE;
    if (binary_op_a(NOTEQ, _27507, 27)){
        _27507 = NOVALUE;
        goto L4; // [78] 100
    }
    _27507 = NOVALUE;

    /** inline.e:264				replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27509 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27509 = 1;
    }
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27510 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27510 = 1;
    }
    RefDS(_22209);
    _66replace_code(_22209, _27509, _27510);
    _27509 = NOVALUE;
    _27510 = NOVALUE;
L4: 
L3: 
L1: 

    /** inline.e:270		if is_temp( retsym ) */
    _27511 = _66is_temp(_retsym_54219);
    if (IS_ATOM_INT(_27511)) {
        if (_27511 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27511)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27513 = _66is_literal(_retsym_54219);
    if (IS_ATOM_INT(_27513)) {
        _27514 = (_27513 == 0);
    }
    else {
        _27514 = unary_op(NOT, _27513);
    }
    DeRef(_27513);
    _27513 = NOVALUE;
    if (IS_ATOM_INT(_27514)) {
        if (_27514 == 0) {
            DeRef(_27515);
            _27515 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27514)->dbl == 0.0) {
            DeRef(_27515);
            _27515 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27516 = (object)*(((s1_ptr)_2)->base + _retsym_54219);
    _2 = (object)SEQ_PTR(_27516);
    _27517 = (object)*(((s1_ptr)_2)->base + 4);
    _27516 = NOVALUE;
    if (IS_ATOM_INT(_27517)) {
        _27518 = (_27517 <= 3);
    }
    else {
        _27518 = binary_op(LESSEQ, _27517, 3);
    }
    _27517 = NOVALUE;
    DeRef(_27515);
    if (IS_ATOM_INT(_27518))
    _27515 = (_27518 != 0);
    else
    _27515 = DBL_PTR(_27518)->dbl != 0.0;
L6: 
    if (_27515 == 0)
    {
        _27515 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27515 = NOVALUE;
    }
L5: 

    /** inline.e:272			sequence code = {}*/
    RefDS(_22209);
    DeRef(_code_54252);
    _code_54252 = _22209;

    /** inline.e:274			integer ret_pc = 0*/
    _ret_pc_54253 = 0;

    /** inline.e:276			if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27519 = find_from(_retsym_54219, _66inline_params_53935, 1);
    if (_27519 != 0) {
        DeRef(_27520);
        _27520 = 1;
        goto L8; // [171] 186
    }
    _27521 = find_from(_retsym_54219, _66proc_vars_53931, 1);
    _27520 = (_27521 != 0);
L8: 
    if (_27520 != 0)
    goto L9; // [186] 206
    _27520 = NOVALUE;

    /** inline.e:277				ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27523 = _66generic_symbol(_retsym_54219);
    RefDS(_66inline_code_53930);
    _ret_pc_54253 = _14rfind(_27523, _66inline_code_53930, _pc_54217);
    _27523 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_54253)) {
        _1 = (object)(DBL_PTR(_ret_pc_54253)->dbl);
        DeRefDS(_ret_pc_54253);
        _ret_pc_54253 = _1;
    }
L9: 

    /** inline.e:281			if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_54253 == 0) {
        goto LA; // [208] 277
    }
    _27526 = _ret_pc_54253 - 1;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27527 = (object)*(((s1_ptr)_2)->base + _27526);
    if (IS_ATOM_INT(_27527) && IS_ATOM_INT(30)){
        _27528 = (_27527 < 30) ? -1 : (_27527 > 30);
    }
    else{
        _27528 = compare(_27527, 30);
    }
    _27527 = NOVALUE;
    if (_27528 == 0)
    {
        _27528 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27528 = NOVALUE;
    }

    /** inline.e:282				inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27529);
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_pc_54253);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27529;
    DeRef(_1);

    /** inline.e:284				if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27530 = _ret_pc_54253 - 1;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27531 = (object)*(((s1_ptr)_2)->base + _27530);
    if (_27531 == 207)
    _27532 = 1;
    else if (IS_ATOM_INT(_27531) && IS_ATOM_INT(207))
    _27532 = 0;
    else
    _27532 = (compare(_27531, 207) == 0);
    _27531 = NOVALUE;
    if (_27532 == 0)
    {
        _27532 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27532 = NOVALUE;
    }

    /** inline.e:287					inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27533 = _ret_pc_54253 - 2;
    RefDS(_27529);
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27533);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27529;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** inline.e:290				code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27534 = _66generic_symbol(_retsym_54219);
    _0 = _code_54252;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _27534;
    RefDS(_27529);
    ((intptr_t*)_2)[3] = _27529;
    _code_54252 = MAKE_SEQ(_1);
    DeRef(_0);
    _27534 = NOVALUE;
LB: 

    /** inline.e:293			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27536 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27536 = 1;
    }
    _27537 = 3 + _27TRANSLATE_20179;
    _27538 = _27536 - _27537;
    _27536 = NOVALUE;
    _27537 = NOVALUE;
    if (_pc_54217 == _27538)
    goto LC; // [309] 330

    /** inline.e:294				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27540 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27540;
    _27541 = MAKE_SEQ(_1);
    _27540 = NOVALUE;
    Concat((object_ptr)&_code_54252, _code_54252, _27541);
    DeRefDS(_27541);
    _27541 = NOVALUE;
LC: 

    /** inline.e:298			replace_code( code, pc, pc + 3 )*/
    _27543 = _pc_54217 + 3;
    if ((object)((uintptr_t)_27543 + (uintptr_t)HIGH_BITS) >= 0){
        _27543 = NewDouble((eudouble)_27543);
    }
    RefDS(_code_54252);
    _66replace_code(_code_54252, _pc_54217, _27543);
    _27543 = NOVALUE;

    /** inline.e:299			ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27544 = MAKE_SEQ(_1);
    _ret_pc_54253 = find_from(_27544, _66inline_code_53930, _pc_54217);
    DeRefDS(_27544);
    _27544 = NOVALUE;

    /** inline.e:300			if ret_pc then*/
    if (_ret_pc_54253 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** inline.e:301				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_54253 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27548 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27548 = 1;
    }
    _27549 = _27548 + 1;
    _27548 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27549;
    if( _1 != _27549 ){
        DeRef(_1);
    }
    _27549 = NOVALUE;
    _27546 = NOVALUE;
LD: 

    /** inline.e:303			return 1*/
    DeRef(_code_54252);
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27518);
    _27518 = NOVALUE;
    DeRef(_27538);
    _27538 = NOVALUE;
    DeRef(_27526);
    _27526 = NOVALUE;
    DeRef(_27530);
    _27530 = NOVALUE;
    DeRef(_27533);
    _27533 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27500);
    _27500 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** inline.e:306			sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_54298;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _retsym_54219;
    RefDS(_27529);
    ((intptr_t*)_2)[3] = _27529;
    _code_54298 = MAKE_SEQ(_1);
    DeRef(_0);

    /** inline.e:307			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27551 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27551 = 1;
    }
    _27552 = 3 + _27TRANSLATE_20179;
    _27553 = _27551 - _27552;
    _27551 = NOVALUE;
    _27552 = NOVALUE;
    if (_pc_54217 == _27553)
    goto LF; // [420] 441

    /** inline.e:308				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27555 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27555;
    _27556 = MAKE_SEQ(_1);
    _27555 = NOVALUE;
    Concat((object_ptr)&_code_54298, _code_54298, _27556);
    DeRefDS(_27556);
    _27556 = NOVALUE;
LF: 

    /** inline.e:312			replace_code( code, pc, pc + 3 )*/
    _27558 = _pc_54217 + 3;
    if ((object)((uintptr_t)_27558 + (uintptr_t)HIGH_BITS) >= 0){
        _27558 = NewDouble((eudouble)_27558);
    }
    RefDS(_code_54298);
    _66replace_code(_code_54298, _pc_54217, _27558);
    _27558 = NOVALUE;

    /** inline.e:313			integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = -1;
    _27559 = MAKE_SEQ(_1);
    _ret_pc_54312 = find_from(_27559, _66inline_code_53930, _pc_54217);
    DeRefDS(_27559);
    _27559 = NOVALUE;

    /** inline.e:314			if ret_pc then*/
    if (_ret_pc_54312 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** inline.e:315				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_54312 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27563 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27563 = 1;
    }
    _27564 = _27563 + 1;
    _27563 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27564;
    if( _1 != _27564 ){
        DeRef(_1);
    }
    _27564 = NOVALUE;
    _27561 = NOVALUE;
L10: 

    /** inline.e:317			return 1*/
    DeRef(_code_54298);
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27518);
    _27518 = NOVALUE;
    DeRef(_27538);
    _27538 = NOVALUE;
    DeRef(_27526);
    _27526 = NOVALUE;
    DeRef(_27530);
    _27530 = NOVALUE;
    DeRef(_27533);
    _27533 = NOVALUE;
    DeRef(_27553);
    _27553 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27500);
    _27500 = NOVALUE;
    return 1;
LE: 

    /** inline.e:319		return 0*/
    DeRef(_27514);
    _27514 = NOVALUE;
    DeRef(_27518);
    _27518 = NOVALUE;
    DeRef(_27538);
    _27538 = NOVALUE;
    DeRef(_27526);
    _27526 = NOVALUE;
    DeRef(_27530);
    _27530 = NOVALUE;
    DeRef(_27533);
    _27533 = NOVALUE;
    DeRef(_27553);
    _27553 = NOVALUE;
    DeRef(_27511);
    _27511 = NOVALUE;
    DeRef(_27500);
    _27500 = NOVALUE;
    return 0;
    ;
}


object _66inline_op(object _pc_54322)
{
    object _op_54323 = NOVALUE;
    object _code_54328 = NOVALUE;
    object _stlen_54361 = NOVALUE;
    object _file_54366 = NOVALUE;
    object _ok_54371 = NOVALUE;
    object _original_table_54394 = NOVALUE;
    object _jump_table_54398 = NOVALUE;
    object _27625 = NOVALUE;
    object _27624 = NOVALUE;
    object _27623 = NOVALUE;
    object _27622 = NOVALUE;
    object _27621 = NOVALUE;
    object _27620 = NOVALUE;
    object _27619 = NOVALUE;
    object _27618 = NOVALUE;
    object _27617 = NOVALUE;
    object _27616 = NOVALUE;
    object _27615 = NOVALUE;
    object _27614 = NOVALUE;
    object _27611 = NOVALUE;
    object _27610 = NOVALUE;
    object _27609 = NOVALUE;
    object _27608 = NOVALUE;
    object _27606 = NOVALUE;
    object _27604 = NOVALUE;
    object _27603 = NOVALUE;
    object _27601 = NOVALUE;
    object _27597 = NOVALUE;
    object _27596 = NOVALUE;
    object _27595 = NOVALUE;
    object _27594 = NOVALUE;
    object _27593 = NOVALUE;
    object _27592 = NOVALUE;
    object _27589 = NOVALUE;
    object _27588 = NOVALUE;
    object _27586 = NOVALUE;
    object _27585 = NOVALUE;
    object _27583 = NOVALUE;
    object _27581 = NOVALUE;
    object _27580 = NOVALUE;
    object _27579 = NOVALUE;
    object _27578 = NOVALUE;
    object _27577 = NOVALUE;
    object _27576 = NOVALUE;
    object _27575 = NOVALUE;
    object _27573 = NOVALUE;
    object _27572 = NOVALUE;
    object _27571 = NOVALUE;
    object _27569 = NOVALUE;
    object _27568 = NOVALUE;
    object _27567 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:324		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _op_54323 = (object)*(((s1_ptr)_2)->base + _pc_54322);
    if (!IS_ATOM_INT(_op_54323))
    _op_54323 = (object)DBL_PTR(_op_54323)->dbl;

    /** inline.e:326		if op = RETURNP then*/
    if (_op_54323 != 29)
    goto L1; // [15] 150

    /** inline.e:333			sequence code = ""*/
    RefDS(_22209);
    DeRef(_code_54328);
    _code_54328 = _22209;

    /** inline.e:335			if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27567 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27567 = 1;
    }
    _27568 = _27567 - 1;
    _27567 = NOVALUE;
    _27569 = _27568 - _27TRANSLATE_20179;
    _27568 = NOVALUE;
    if (_pc_54322 == _27569)
    goto L2; // [43] 92

    /** inline.e:336				code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27571 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27571 = 1;
    }
    _27572 = _27571 + 1;
    _27571 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = _27572;
    _27573 = MAKE_SEQ(_1);
    _27572 = NOVALUE;
    DeRefDS(_code_54328);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23;
    ((intptr_t *)_2)[2] = _27573;
    _code_54328 = MAKE_SEQ(_1);
    _27573 = NOVALUE;

    /** inline.e:337				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** inline.e:338					inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27575 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27575 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27575);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** inline.e:341			elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_27TRANSLATE_20179 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27577 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27577 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27578 = (object)*(((s1_ptr)_2)->base + _27577);
    if (IS_ATOM_INT(_27578)) {
        _27579 = (_27578 == 43);
    }
    else {
        _27579 = binary_op(EQUALS, _27578, 43);
    }
    _27578 = NOVALUE;
    if (_27579 == 0) {
        DeRef(_27579);
        _27579 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27579) && DBL_PTR(_27579)->dbl == 0.0){
            DeRef(_27579);
            _27579 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27579);
        _27579 = NOVALUE;
    }
    DeRef(_27579);
    _27579 = NOVALUE;

    /** inline.e:342				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27580 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27580 = 1;
    }
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27580);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** inline.e:344			replace_code( code, pc, pc + 2 )*/
    _27581 = _pc_54322 + 2;
    if ((object)((uintptr_t)_27581 + (uintptr_t)HIGH_BITS) >= 0){
        _27581 = NewDouble((eudouble)_27581);
    }
    RefDS(_code_54328);
    _66replace_code(_code_54328, _pc_54322, _27581);
    _27581 = NOVALUE;
    DeRefDS(_code_54328);
    _code_54328 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** inline.e:346		elsif op = RETURNF then*/
    if (_op_54323 != 28)
    goto L6; // [154] 171

    /** inline.e:347			return returnf( pc )*/
    _27583 = _66returnf(_pc_54322);
    DeRef(_27569);
    _27569 = NOVALUE;
    return _27583;
    goto L5; // [168] 526
L6: 

    /** inline.e:349		elsif op = ROUTINE_ID then*/
    if (_op_54323 != 134)
    goto L7; // [175] 273

    /** inline.e:351			integer*/

    /** inline.e:352				stlen = inline_code[pc+2+TRANSLATE],*/
    _27585 = _pc_54322 + 2;
    if ((object)((uintptr_t)_27585 + (uintptr_t)HIGH_BITS) >= 0){
        _27585 = NewDouble((eudouble)_27585);
    }
    if (IS_ATOM_INT(_27585)) {
        _27586 = _27585 + _27TRANSLATE_20179;
    }
    else {
        _27586 = NewDouble(DBL_PTR(_27585)->dbl + (eudouble)_27TRANSLATE_20179);
    }
    DeRef(_27585);
    _27585 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!IS_ATOM_INT(_27586)){
        _stlen_54361 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27586)->dbl));
    }
    else{
        _stlen_54361 = (object)*(((s1_ptr)_2)->base + _27586);
    }
    if (!IS_ATOM_INT(_stlen_54361))
    _stlen_54361 = (object)DBL_PTR(_stlen_54361)->dbl;

    /** inline.e:353				file  = inline_code[pc+4+TRANSLATE],*/
    _27588 = _pc_54322 + 4;
    if ((object)((uintptr_t)_27588 + (uintptr_t)HIGH_BITS) >= 0){
        _27588 = NewDouble((eudouble)_27588);
    }
    if (IS_ATOM_INT(_27588)) {
        _27589 = _27588 + _27TRANSLATE_20179;
    }
    else {
        _27589 = NewDouble(DBL_PTR(_27588)->dbl + (eudouble)_27TRANSLATE_20179);
    }
    DeRef(_27588);
    _27588 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!IS_ATOM_INT(_27589)){
        _file_54366 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27589)->dbl));
    }
    else{
        _file_54366 = (object)*(((s1_ptr)_2)->base + _27589);
    }
    if (!IS_ATOM_INT(_file_54366))
    _file_54366 = (object)DBL_PTR(_file_54366)->dbl;

    /** inline.e:354				ok    = adjust_il( pc, op )*/
    _ok_54371 = _66adjust_il(_pc_54322, _op_54323);
    if (!IS_ATOM_INT(_ok_54371)) {
        _1 = (object)(DBL_PTR(_ok_54371)->dbl);
        DeRefDS(_ok_54371);
        _ok_54371 = _1;
    }

    /** inline.e:355			inline_code[pc+2+TRANSLATE] = stlen*/
    _27592 = _pc_54322 + 2;
    if ((object)((uintptr_t)_27592 + (uintptr_t)HIGH_BITS) >= 0){
        _27592 = NewDouble((eudouble)_27592);
    }
    if (IS_ATOM_INT(_27592)) {
        _27593 = _27592 + _27TRANSLATE_20179;
    }
    else {
        _27593 = NewDouble(DBL_PTR(_27592)->dbl + (eudouble)_27TRANSLATE_20179);
    }
    DeRef(_27592);
    _27592 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27593))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27593)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27593);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _stlen_54361;
    DeRef(_1);

    /** inline.e:356			inline_code[pc+4+TRANSLATE] = file*/
    _27594 = _pc_54322 + 4;
    if ((object)((uintptr_t)_27594 + (uintptr_t)HIGH_BITS) >= 0){
        _27594 = NewDouble((eudouble)_27594);
    }
    if (IS_ATOM_INT(_27594)) {
        _27595 = _27594 + _27TRANSLATE_20179;
    }
    else {
        _27595 = NewDouble(DBL_PTR(_27594)->dbl + (eudouble)_27TRANSLATE_20179);
    }
    DeRef(_27594);
    _27594 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27595))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27595)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27595);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_54366;
    DeRef(_1);

    /** inline.e:358			return ok*/
    DeRef(_27593);
    _27593 = NOVALUE;
    DeRef(_27583);
    _27583 = NOVALUE;
    DeRef(_27569);
    _27569 = NOVALUE;
    DeRef(_27595);
    _27595 = NOVALUE;
    DeRef(_27589);
    _27589 = NOVALUE;
    DeRef(_27586);
    _27586 = NOVALUE;
    return _ok_54371;
    goto L5; // [270] 526
L7: 

    /** inline.e:360		elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_65op_info_24613);
    _27596 = (object)*(((s1_ptr)_2)->base + _op_54323);
    _2 = (object)SEQ_PTR(_27596);
    _27597 = (object)*(((s1_ptr)_2)->base + 1);
    _27596 = NOVALUE;
    if (binary_op_a(NOTEQ, _27597, 1)){
        _27597 = NOVALUE;
        goto L8; // [289] 397
    }
    _27597 = NOVALUE;

    /** inline.e:361			switch op do*/
    _0 = _op_54323;
    switch ( _0 ){ 

        /** inline.e:362				case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** inline.e:364					symtab_index original_table = inline_code[pc + 3]*/
        _27601 = _pc_54322 + 3;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _original_table_54394 = (object)*(((s1_ptr)_2)->base + _27601);
        if (!IS_ATOM_INT(_original_table_54394)){
            _original_table_54394 = (object)DBL_PTR(_original_table_54394)->dbl;
        }

        /** inline.e:365					symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_28SymTab_11572)){
                _27603 = SEQ_PTR(_28SymTab_11572)->length;
        }
        else {
            _27603 = 1;
        }
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = _27603;
        _27604 = MAKE_SEQ(_1);
        _27603 = NOVALUE;
        _jump_table_54398 = _53NewStringSym(_27604);
        _27604 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_54398)) {
            _1 = (object)(DBL_PTR(_jump_table_54398)->dbl);
            DeRefDS(_jump_table_54398);
            _jump_table_54398 = _1;
        }

        /** inline.e:366					SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_jump_table_54398 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27608 = (object)*(((s1_ptr)_2)->base + _original_table_54394);
        _2 = (object)SEQ_PTR(_27608);
        _27609 = (object)*(((s1_ptr)_2)->base + 1);
        _27608 = NOVALUE;
        Ref(_27609);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27609;
        if( _1 != _27609 ){
            DeRef(_1);
        }
        _27609 = NOVALUE;
        _27606 = NOVALUE;

        /** inline.e:367					inline_code[pc+3] = jump_table*/
        _27610 = _pc_54322 + 3;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53930 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27610);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _jump_table_54398;
        DeRef(_1);
    ;}
    /** inline.e:369			return adjust_il( pc, op )*/
    _27611 = _66adjust_il(_pc_54322, _op_54323);
    DeRef(_27593);
    _27593 = NOVALUE;
    DeRef(_27583);
    _27583 = NOVALUE;
    DeRef(_27601);
    _27601 = NOVALUE;
    DeRef(_27569);
    _27569 = NOVALUE;
    DeRef(_27595);
    _27595 = NOVALUE;
    DeRef(_27589);
    _27589 = NOVALUE;
    DeRef(_27610);
    _27610 = NOVALUE;
    DeRef(_27586);
    _27586 = NOVALUE;
    return _27611;
    goto L5; // [394] 526
L8: 

    /** inline.e:372			switch op with fallthru do*/
    _0 = _op_54323;
    switch ( _0 ){ 

        /** inline.e:373				case REF_TEMP then*/
        case 207:

        /** inline.e:374					inline_code[pc+1] = {INLINE_TARGET}*/
        _27614 = _pc_54322 + 1;
        RefDS(_27529);
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66inline_code_53930 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27614);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27529;
        DeRef(_1);

        /** inline.e:376				case CONCAT_N then*/
        case 157:
        case 31:

        /** inline.e:379					if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27615 = _pc_54322 + 2;
        if ((object)((uintptr_t)_27615 + (uintptr_t)HIGH_BITS) >= 0){
            _27615 = NewDouble((eudouble)_27615);
        }
        _27616 = _pc_54322 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27617 = (object)*(((s1_ptr)_2)->base + _27616);
        if (IS_ATOM_INT(_27615) && IS_ATOM_INT(_27617)) {
            _27618 = _27615 + _27617;
            if ((object)((uintptr_t)_27618 + (uintptr_t)HIGH_BITS) >= 0){
                _27618 = NewDouble((eudouble)_27618);
            }
        }
        else {
            _27618 = binary_op(PLUS, _27615, _27617);
        }
        DeRef(_27615);
        _27615 = NOVALUE;
        _27617 = NOVALUE;
        _27619 = _66check_for_param(_27618);
        _27618 = NOVALUE;
        if (_27619 == 0) {
            DeRef(_27619);
            _27619 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27619) && DBL_PTR(_27619)->dbl == 0.0){
                DeRef(_27619);
                _27619 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27619);
            _27619 = NOVALUE;
        }
        DeRef(_27619);
        _27619 = NOVALUE;
L9: 

        /** inline.e:383					for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27620 = _pc_54322 + 2;
        if ((object)((uintptr_t)_27620 + (uintptr_t)HIGH_BITS) >= 0){
            _27620 = NewDouble((eudouble)_27620);
        }
        _27621 = _pc_54322 + 2;
        if ((object)((uintptr_t)_27621 + (uintptr_t)HIGH_BITS) >= 0){
            _27621 = NewDouble((eudouble)_27621);
        }
        _27622 = _pc_54322 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27623 = (object)*(((s1_ptr)_2)->base + _27622);
        if (IS_ATOM_INT(_27621) && IS_ATOM_INT(_27623)) {
            _27624 = _27621 + _27623;
            if ((object)((uintptr_t)_27624 + (uintptr_t)HIGH_BITS) >= 0){
                _27624 = NewDouble((eudouble)_27624);
            }
        }
        else {
            _27624 = binary_op(PLUS, _27621, _27623);
        }
        DeRef(_27621);
        _27621 = NOVALUE;
        _27623 = NOVALUE;
        {
            object _i_54430;
            Ref(_27620);
            _i_54430 = _27620;
LA: 
            if (binary_op_a(GREATER, _i_54430, _27624)){
                goto LB; // [478] 508
            }

            /** inline.e:384						if not adjust_symbol( i ) then*/
            Ref(_i_54430);
            _27625 = _66adjust_symbol(_i_54430);
            if (IS_ATOM_INT(_27625)) {
                if (_27625 != 0){
                    DeRef(_27625);
                    _27625 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27625)->dbl != 0.0){
                    DeRef(_27625);
                    _27625 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27625);
            _27625 = NOVALUE;

            /** inline.e:385							return 0*/
            DeRef(_i_54430);
            DeRef(_27620);
            _27620 = NOVALUE;
            DeRef(_27614);
            _27614 = NOVALUE;
            DeRef(_27611);
            _27611 = NOVALUE;
            DeRef(_27624);
            _27624 = NOVALUE;
            DeRef(_27593);
            _27593 = NOVALUE;
            DeRef(_27622);
            _27622 = NOVALUE;
            DeRef(_27583);
            _27583 = NOVALUE;
            DeRef(_27601);
            _27601 = NOVALUE;
            DeRef(_27569);
            _27569 = NOVALUE;
            DeRef(_27595);
            _27595 = NOVALUE;
            DeRef(_27589);
            _27589 = NOVALUE;
            DeRef(_27616);
            _27616 = NOVALUE;
            DeRef(_27610);
            _27610 = NOVALUE;
            DeRef(_27586);
            _27586 = NOVALUE;
            return 0;
LC: 

            /** inline.e:388					end for*/
            _0 = _i_54430;
            if (IS_ATOM_INT(_i_54430)) {
                _i_54430 = _i_54430 + 1;
                if ((object)((uintptr_t)_i_54430 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54430 = NewDouble((eudouble)_i_54430);
                }
            }
            else {
                _i_54430 = binary_op_a(PLUS, _i_54430, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_54430);
        }

        /** inline.e:389					return 1*/
        DeRef(_27620);
        _27620 = NOVALUE;
        DeRef(_27614);
        _27614 = NOVALUE;
        DeRef(_27611);
        _27611 = NOVALUE;
        DeRef(_27624);
        _27624 = NOVALUE;
        DeRef(_27593);
        _27593 = NOVALUE;
        DeRef(_27622);
        _27622 = NOVALUE;
        DeRef(_27583);
        _27583 = NOVALUE;
        DeRef(_27601);
        _27601 = NOVALUE;
        DeRef(_27569);
        _27569 = NOVALUE;
        DeRef(_27595);
        _27595 = NOVALUE;
        DeRef(_27589);
        _27589 = NOVALUE;
        DeRef(_27616);
        _27616 = NOVALUE;
        DeRef(_27610);
        _27610 = NOVALUE;
        DeRef(_27586);
        _27586 = NOVALUE;
        return 1;

        /** inline.e:390				case else*/
        default:

        /** inline.e:391					return 0*/
        DeRef(_27620);
        _27620 = NOVALUE;
        DeRef(_27614);
        _27614 = NOVALUE;
        DeRef(_27611);
        _27611 = NOVALUE;
        DeRef(_27624);
        _27624 = NOVALUE;
        DeRef(_27593);
        _27593 = NOVALUE;
        DeRef(_27622);
        _27622 = NOVALUE;
        DeRef(_27583);
        _27583 = NOVALUE;
        DeRef(_27601);
        _27601 = NOVALUE;
        DeRef(_27569);
        _27569 = NOVALUE;
        DeRef(_27595);
        _27595 = NOVALUE;
        DeRef(_27589);
        _27589 = NOVALUE;
        DeRef(_27616);
        _27616 = NOVALUE;
        DeRef(_27610);
        _27610 = NOVALUE;
        DeRef(_27586);
        _27586 = NOVALUE;
        return 0;
    ;}L5: 

    /** inline.e:394		return 1*/
    DeRef(_27620);
    _27620 = NOVALUE;
    DeRef(_27614);
    _27614 = NOVALUE;
    DeRef(_27611);
    _27611 = NOVALUE;
    DeRef(_27624);
    _27624 = NOVALUE;
    DeRef(_27593);
    _27593 = NOVALUE;
    DeRef(_27622);
    _27622 = NOVALUE;
    DeRef(_27583);
    _27583 = NOVALUE;
    DeRef(_27601);
    _27601 = NOVALUE;
    DeRef(_27569);
    _27569 = NOVALUE;
    DeRef(_27595);
    _27595 = NOVALUE;
    DeRef(_27589);
    _27589 = NOVALUE;
    DeRef(_27616);
    _27616 = NOVALUE;
    DeRef(_27610);
    _27610 = NOVALUE;
    DeRef(_27586);
    _27586 = NOVALUE;
    return 1;
    ;
}


void _66restore_code()
{
    object _27627 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:399		if length( temp_code ) then*/
    if (IS_SEQUENCE(_66temp_code_54440)){
            _27627 = SEQ_PTR(_66temp_code_54440)->length;
    }
    else {
        _27627 = 1;
    }
    if (_27627 == 0)
    {
        _27627 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27627 = NOVALUE;
    }

    /** inline.e:400			Code = temp_code*/
    RefDS(_66temp_code_54440);
    DeRef(_27Code_20660);
    _27Code_20660 = _66temp_code_54440;
L1: 

    /** inline.e:402	end procedure*/
    return;
    ;
}


void _66check_inline(object _sub_54449)
{
    object _pc_54478 = NOVALUE;
    object _s_54480 = NOVALUE;
    object _backpatch_op_54518 = NOVALUE;
    object _op_54522 = NOVALUE;
    object _rtn_idx_54533 = NOVALUE;
    object _args_54538 = NOVALUE;
    object _args_54570 = NOVALUE;
    object _values_54599 = NOVALUE;
    object _27714 = NOVALUE;
    object _27713 = NOVALUE;
    object _27711 = NOVALUE;
    object _27708 = NOVALUE;
    object _27706 = NOVALUE;
    object _27705 = NOVALUE;
    object _27704 = NOVALUE;
    object _27702 = NOVALUE;
    object _27701 = NOVALUE;
    object _27700 = NOVALUE;
    object _27699 = NOVALUE;
    object _27698 = NOVALUE;
    object _27697 = NOVALUE;
    object _27696 = NOVALUE;
    object _27695 = NOVALUE;
    object _27694 = NOVALUE;
    object _27692 = NOVALUE;
    object _27691 = NOVALUE;
    object _27690 = NOVALUE;
    object _27689 = NOVALUE;
    object _27688 = NOVALUE;
    object _27686 = NOVALUE;
    object _27685 = NOVALUE;
    object _27684 = NOVALUE;
    object _27683 = NOVALUE;
    object _27682 = NOVALUE;
    object _27680 = NOVALUE;
    object _27679 = NOVALUE;
    object _27678 = NOVALUE;
    object _27677 = NOVALUE;
    object _27676 = NOVALUE;
    object _27675 = NOVALUE;
    object _27674 = NOVALUE;
    object _27673 = NOVALUE;
    object _27672 = NOVALUE;
    object _27671 = NOVALUE;
    object _27670 = NOVALUE;
    object _27669 = NOVALUE;
    object _27668 = NOVALUE;
    object _27667 = NOVALUE;
    object _27665 = NOVALUE;
    object _27662 = NOVALUE;
    object _27657 = NOVALUE;
    object _27655 = NOVALUE;
    object _27652 = NOVALUE;
    object _27651 = NOVALUE;
    object _27650 = NOVALUE;
    object _27649 = NOVALUE;
    object _27648 = NOVALUE;
    object _27647 = NOVALUE;
    object _27646 = NOVALUE;
    object _27645 = NOVALUE;
    object _27643 = NOVALUE;
    object _27641 = NOVALUE;
    object _27640 = NOVALUE;
    object _27638 = NOVALUE;
    object _27636 = NOVALUE;
    object _27634 = NOVALUE;
    object _27632 = NOVALUE;
    object _27631 = NOVALUE;
    object _27630 = NOVALUE;
    object _27629 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:411		if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_27OpTrace_20641 != 0) {
        goto L1; // [7] 34
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27629 = (object)*(((s1_ptr)_2)->base + _sub_54449);
    _2 = (object)SEQ_PTR(_27629);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _27630 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _27630 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _27629 = NOVALUE;
    if (IS_ATOM_INT(_27630)) {
        _27631 = (_27630 == 504);
    }
    else {
        _27631 = binary_op(EQUALS, _27630, 504);
    }
    _27630 = NOVALUE;
    if (_27631 == 0) {
        DeRef(_27631);
        _27631 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27631) && DBL_PTR(_27631)->dbl == 0.0){
            DeRef(_27631);
            _27631 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27631);
        _27631 = NOVALUE;
    }
    DeRef(_27631);
    _27631 = NOVALUE;
L1: 

    /** inline.e:412			return*/
    DeRefi(_backpatch_op_54518);
    return;
L2: 

    /** inline.e:414		inline_sub      = sub*/
    _66inline_sub_53944 = _sub_54449;

    /** inline.e:415		if get_fwdref_count() then*/
    _27632 = _42get_fwdref_count();
    if (_27632 == 0) {
        DeRef(_27632);
        _27632 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27632) && DBL_PTR(_27632)->dbl == 0.0){
            DeRef(_27632);
            _27632 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27632);
        _27632 = NOVALUE;
    }
    DeRef(_27632);
    _27632 = NOVALUE;

    /** inline.e:416			defer()*/
    _66defer();

    /** inline.e:417			return*/
    DeRefi(_backpatch_op_54518);
    return;
L3: 

    /** inline.e:419		temp_code = ""*/
    RefDS(_22209);
    DeRef(_66temp_code_54440);
    _66temp_code_54440 = _22209;

    /** inline.e:420		if sub != CurrentSub then*/
    if (_sub_54449 == _27CurrentSub_20579)
    goto L4; // [76] 99

    /** inline.e:421			Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27634 = (object)*(((s1_ptr)_2)->base + _sub_54449);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_27634);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _27634 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** inline.e:423			temp_code = Code*/
    RefDS(_27Code_20660);
    DeRef(_66temp_code_54440);
    _66temp_code_54440 = _27Code_20660;
L5: 

    /** inline.e:426		if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_27Code_20660)){
            _27636 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _27636 = 1;
    }
    if (_27636 <= _27OpInline_20646)
    goto L6; // [118] 128

    /** inline.e:427			return*/
    DeRefi(_backpatch_op_54518);
    return;
L6: 

    /** inline.e:430		inline_code     = Code*/
    RefDS(_27Code_20660);
    DeRef(_66inline_code_53930);
    _66inline_code_53930 = _27Code_20660;

    /** inline.e:431		return_gotos    = 0*/
    _66return_gotos_53939 = 0;

    /** inline.e:432		prev_pc         = 1*/
    _66prev_pc_53938 = 1;

    /** inline.e:433		proc_vars       = {}*/
    RefDS(_22209);
    DeRefi(_66proc_vars_53931);
    _66proc_vars_53931 = _22209;

    /** inline.e:434		inline_temps    = {}*/
    RefDS(_22209);
    DeRef(_66inline_temps_53932);
    _66inline_temps_53932 = _22209;

    /** inline.e:435		inline_params   = {}*/
    RefDS(_22209);
    DeRefi(_66inline_params_53935);
    _66inline_params_53935 = _22209;

    /** inline.e:436		assigned_params = {}*/
    RefDS(_22209);
    DeRef(_66assigned_params_53936);
    _66assigned_params_53936 = _22209;

    /** inline.e:438		integer pc = 1*/
    _pc_54478 = 1;

    /** inline.e:439		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27638 = (object)*(((s1_ptr)_2)->base + _sub_54449);
    _2 = (object)SEQ_PTR(_27638);
    _s_54480 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54480)){
        _s_54480 = (object)DBL_PTR(_s_54480)->dbl;
    }
    _27638 = NOVALUE;

    /** inline.e:440		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27640 = (object)*(((s1_ptr)_2)->base + _sub_54449);
    _2 = (object)SEQ_PTR(_27640);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _27641 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _27641 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _27640 = NOVALUE;
    {
        object _p_54486;
        _p_54486 = 1;
L7: 
        if (binary_op_a(GREATER, _p_54486, _27641)){
            goto L8; // [210] 248
        }

        /** inline.e:441			inline_params &= s*/
        Append(&_66inline_params_53935, _66inline_params_53935, _s_54480);

        /** inline.e:442			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27643 = (object)*(((s1_ptr)_2)->base + _s_54480);
        _2 = (object)SEQ_PTR(_27643);
        _s_54480 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54480)){
            _s_54480 = (object)DBL_PTR(_s_54480)->dbl;
        }
        _27643 = NOVALUE;

        /** inline.e:443		end for*/
        _0 = _p_54486;
        if (IS_ATOM_INT(_p_54486)) {
            _p_54486 = _p_54486 + 1;
            if ((object)((uintptr_t)_p_54486 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54486 = NewDouble((eudouble)_p_54486);
            }
        }
        else {
            _p_54486 = binary_op_a(PLUS, _p_54486, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_54486);
    }

    /** inline.e:445		while s != 0 and */
L9: 
    _27645 = (_s_54480 != 0);
    if (_27645 == 0) {
        goto LA; // [257] 335
    }
    _27647 = _53sym_scope(_s_54480);
    if (IS_ATOM_INT(_27647)) {
        _27648 = (_27647 <= 3);
    }
    else {
        _27648 = binary_op(LESSEQ, _27647, 3);
    }
    DeRef(_27647);
    _27647 = NOVALUE;
    if (IS_ATOM_INT(_27648)) {
        if (_27648 != 0) {
            DeRef(_27649);
            _27649 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27648)->dbl != 0.0) {
            DeRef(_27649);
            _27649 = 1;
            goto LB; // [271] 289
        }
    }
    _27650 = _53sym_scope(_s_54480);
    if (IS_ATOM_INT(_27650)) {
        _27651 = (_27650 == 9);
    }
    else {
        _27651 = binary_op(EQUALS, _27650, 9);
    }
    DeRef(_27650);
    _27650 = NOVALUE;
    DeRef(_27649);
    if (IS_ATOM_INT(_27651))
    _27649 = (_27651 != 0);
    else
    _27649 = DBL_PTR(_27651)->dbl != 0.0;
LB: 
    if (_27649 == 0)
    {
        _27649 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27649 = NOVALUE;
    }

    /** inline.e:447			if sym_scope( s ) != SC_UNDEFINED then*/
    _27652 = _53sym_scope(_s_54480);
    if (binary_op_a(EQUALS, _27652, 9)){
        DeRef(_27652);
        _27652 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27652);
    _27652 = NOVALUE;

    /** inline.e:448				proc_vars &= s*/
    Append(&_66proc_vars_53931, _66proc_vars_53931, _s_54480);
LC: 

    /** inline.e:451			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27655 = (object)*(((s1_ptr)_2)->base + _s_54480);
    _2 = (object)SEQ_PTR(_27655);
    _s_54480 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54480)){
        _s_54480 = (object)DBL_PTR(_s_54480)->dbl;
    }
    _27655 = NOVALUE;

    /** inline.e:452		end while*/
    goto L9; // [332] 253
LA: 

    /** inline.e:453		sequence backpatch_op = {}*/
    RefDS(_22209);
    DeRefi(_backpatch_op_54518);
    _backpatch_op_54518 = _22209;

    /** inline.e:454		while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27657 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27657 = 1;
    }
    if (_pc_54478 >= _27657)
    goto LE; // [352] 869

    /** inline.e:456			integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _op_54522 = (object)*(((s1_ptr)_2)->base + _pc_54478);
    if (!IS_ATOM_INT(_op_54522))
    _op_54522 = (object)DBL_PTR(_op_54522)->dbl;

    /** inline.e:457			switch op do*/
    _0 = _op_54522;
    switch ( _0 ){ 

        /** inline.e:458				case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** inline.e:459					defer()*/
        _66defer();

        /** inline.e:460					restore_code()*/
        _66restore_code();

        /** inline.e:461					return*/
        DeRefi(_backpatch_op_54518);
        DeRef(_27648);
        _27648 = NOVALUE;
        DeRef(_27645);
        _27645 = NOVALUE;
        _27641 = NOVALUE;
        DeRef(_27651);
        _27651 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** inline.e:463				case PROC, FUNC then*/
        case 27:
        case 501:

        /** inline.e:464					symtab_index rtn_idx = inline_code[pc+1]*/
        _27662 = _pc_54478 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _rtn_idx_54533 = (object)*(((s1_ptr)_2)->base + _27662);
        if (!IS_ATOM_INT(_rtn_idx_54533)){
            _rtn_idx_54533 = (object)DBL_PTR(_rtn_idx_54533)->dbl;
        }

        /** inline.e:465					if rtn_idx = sub then*/
        if (_rtn_idx_54533 != _sub_54449)
        goto L10; // [414] 428

        /** inline.e:467						restore_code()*/
        _66restore_code();

        /** inline.e:468						return*/
        DeRefi(_backpatch_op_54518);
        DeRef(_27648);
        _27648 = NOVALUE;
        DeRef(_27645);
        _27645 = NOVALUE;
        _27641 = NOVALUE;
        _27662 = NOVALUE;
        DeRef(_27651);
        _27651 = NOVALUE;
        return;
L10: 

        /** inline.e:471					integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27665 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54533);
        _2 = (object)SEQ_PTR(_27665);
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
            _args_54538 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        }
        else{
            _args_54538 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        }
        if (!IS_ATOM_INT(_args_54538)){
            _args_54538 = (object)DBL_PTR(_args_54538)->dbl;
        }
        _27665 = NOVALUE;

        /** inline.e:472					if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27667 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54533);
        _2 = (object)SEQ_PTR(_27667);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _27668 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _27668 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _27667 = NOVALUE;
        if (IS_ATOM_INT(_27668)) {
            _27669 = (_27668 != 27);
        }
        else {
            _27669 = binary_op(NOTEQ, _27668, 27);
        }
        _27668 = NOVALUE;
        if (IS_ATOM_INT(_27669)) {
            if (_27669 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27669)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27671 = _pc_54478 + _args_54538;
        if ((object)((uintptr_t)_27671 + (uintptr_t)HIGH_BITS) >= 0){
            _27671 = NewDouble((eudouble)_27671);
        }
        if (IS_ATOM_INT(_27671)) {
            _27672 = _27671 + 2;
            if ((object)((uintptr_t)_27672 + (uintptr_t)HIGH_BITS) >= 0){
                _27672 = NewDouble((eudouble)_27672);
            }
        }
        else {
            _27672 = NewDouble(DBL_PTR(_27671)->dbl + (eudouble)2);
        }
        DeRef(_27671);
        _27671 = NOVALUE;
        _27673 = _66check_for_param(_27672);
        _27672 = NOVALUE;
        if (_27673 == 0) {
            DeRef(_27673);
            _27673 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27673) && DBL_PTR(_27673)->dbl == 0.0){
                DeRef(_27673);
                _27673 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27673);
            _27673 = NOVALUE;
        }
        DeRef(_27673);
        _27673 = NOVALUE;
L11: 

        /** inline.e:475					for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27674 = _args_54538 + 1;
        if (_27674 > MAXINT){
            _27674 = NewDouble((eudouble)_27674);
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27675 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54533);
        _2 = (object)SEQ_PTR(_27675);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _27676 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _27676 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _27675 = NOVALUE;
        if (IS_ATOM_INT(_27676)) {
            _27677 = (_27676 != 27);
        }
        else {
            _27677 = binary_op(NOTEQ, _27676, 27);
        }
        _27676 = NOVALUE;
        if (IS_ATOM_INT(_27674) && IS_ATOM_INT(_27677)) {
            _27678 = _27674 + _27677;
            if ((object)((uintptr_t)_27678 + (uintptr_t)HIGH_BITS) >= 0){
                _27678 = NewDouble((eudouble)_27678);
            }
        }
        else {
            _27678 = binary_op(PLUS, _27674, _27677);
        }
        DeRef(_27674);
        _27674 = NOVALUE;
        DeRef(_27677);
        _27677 = NOVALUE;
        {
            object _i_54555;
            _i_54555 = 2;
L12: 
            if (binary_op_a(GREATER, _i_54555, _27678)){
                goto L13; // [513] 550
            }

            /** inline.e:476						if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_54555)) {
                _27679 = _pc_54478 + _i_54555;
                if ((object)((uintptr_t)_27679 + (uintptr_t)HIGH_BITS) >= 0){
                    _27679 = NewDouble((eudouble)_27679);
                }
            }
            else {
                _27679 = NewDouble((eudouble)_pc_54478 + DBL_PTR(_i_54555)->dbl);
            }
            _27680 = _66adjust_symbol(_27679);
            _27679 = NOVALUE;
            if (IS_ATOM_INT(_27680)) {
                if (_27680 != 0){
                    DeRef(_27680);
                    _27680 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27680)->dbl != 0.0){
                    DeRef(_27680);
                    _27680 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27680);
            _27680 = NOVALUE;

            /** inline.e:477							defer()*/
            _66defer();

            /** inline.e:478							return*/
            DeRef(_i_54555);
            DeRefi(_backpatch_op_54518);
            DeRef(_27648);
            _27648 = NOVALUE;
            DeRef(_27645);
            _27645 = NOVALUE;
            _27641 = NOVALUE;
            DeRef(_27662);
            _27662 = NOVALUE;
            DeRef(_27669);
            _27669 = NOVALUE;
            DeRef(_27651);
            _27651 = NOVALUE;
            DeRef(_27678);
            _27678 = NOVALUE;
            return;
L14: 

            /** inline.e:480					end for*/
            _0 = _i_54555;
            if (IS_ATOM_INT(_i_54555)) {
                _i_54555 = _i_54555 + 1;
                if ((object)((uintptr_t)_i_54555 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54555 = NewDouble((eudouble)_i_54555);
                }
            }
            else {
                _i_54555 = binary_op_a(PLUS, _i_54555, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_54555);
        }
        goto LF; // [552] 851

        /** inline.e:482				case RIGHT_BRACE_N then*/
        case 31:

        /** inline.e:484					sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27682 = _pc_54478 + 2;
        if ((object)((uintptr_t)_27682 + (uintptr_t)HIGH_BITS) >= 0){
            _27682 = NewDouble((eudouble)_27682);
        }
        _27683 = _pc_54478 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27684 = (object)*(((s1_ptr)_2)->base + _27683);
        if (IS_ATOM_INT(_27684)) {
            _27685 = _27684 + _pc_54478;
            if ((object)((uintptr_t)_27685 + (uintptr_t)HIGH_BITS) >= 0){
                _27685 = NewDouble((eudouble)_27685);
            }
        }
        else {
            _27685 = binary_op(PLUS, _27684, _pc_54478);
        }
        _27684 = NOVALUE;
        if (IS_ATOM_INT(_27685)) {
            _27686 = _27685 + 1;
        }
        else
        _27686 = binary_op(PLUS, 1, _27685);
        DeRef(_27685);
        _27685 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_54570;
        RHS_Slice(_66inline_code_53930, _27682, _27686);

        /** inline.e:486					for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_54570)){
                _27688 = SEQ_PTR(_args_54570)->length;
        }
        else {
            _27688 = 1;
        }
        _27689 = _27688 - 1;
        _27688 = NOVALUE;
        {
            object _i_54578;
            _i_54578 = 1;
L15: 
            if (_i_54578 > _27689){
                goto L16; // [598] 644
            }

            /** inline.e:487						if find( args[i], args, i + 1 ) then*/
            _2 = (object)SEQ_PTR(_args_54570);
            _27690 = (object)*(((s1_ptr)_2)->base + _i_54578);
            _27691 = _i_54578 + 1;
            _27692 = find_from(_27690, _args_54570, _27691);
            _27690 = NOVALUE;
            _27691 = NOVALUE;
            if (_27692 == 0)
            {
                _27692 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27692 = NOVALUE;
            }

            /** inline.e:488							defer()*/
            _66defer();

            /** inline.e:489							restore_code()*/
            _66restore_code();

            /** inline.e:490							return*/
            DeRefDS(_args_54570);
            DeRefi(_backpatch_op_54518);
            DeRef(_27648);
            _27648 = NOVALUE;
            DeRef(_27683);
            _27683 = NOVALUE;
            DeRef(_27645);
            _27645 = NOVALUE;
            _27641 = NOVALUE;
            DeRef(_27662);
            _27662 = NOVALUE;
            DeRef(_27669);
            _27669 = NOVALUE;
            DeRef(_27682);
            _27682 = NOVALUE;
            DeRef(_27651);
            _27651 = NOVALUE;
            DeRef(_27678);
            _27678 = NOVALUE;
            DeRef(_27686);
            _27686 = NOVALUE;
            DeRef(_27689);
            _27689 = NOVALUE;
            return;
L17: 

            /** inline.e:492					end for*/
            _i_54578 = _i_54578 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** inline.e:493					goto "inline op"*/
        DeRef(_args_54570);
        _args_54570 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** inline.e:495				case RIGHT_BRACE_2 then*/
        case 85:

        /** inline.e:496					if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27694 = _pc_54478 + 1;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27695 = (object)*(((s1_ptr)_2)->base + _27694);
        _27696 = _pc_54478 + 2;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27697 = (object)*(((s1_ptr)_2)->base + _27696);
        if (_27695 == _27697)
        _27698 = 1;
        else if (IS_ATOM_INT(_27695) && IS_ATOM_INT(_27697))
        _27698 = 0;
        else
        _27698 = (compare(_27695, _27697) == 0);
        _27695 = NOVALUE;
        _27697 = NOVALUE;
        if (_27698 == 0)
        {
            _27698 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27698 = NOVALUE;
        }

        /** inline.e:497						defer()*/
        _66defer();

        /** inline.e:498						restore_code()*/
        _66restore_code();

        /** inline.e:499						return*/
        DeRefi(_backpatch_op_54518);
        DeRef(_27648);
        _27648 = NOVALUE;
        DeRef(_27683);
        _27683 = NOVALUE;
        DeRef(_27645);
        _27645 = NOVALUE;
        _27641 = NOVALUE;
        DeRef(_27662);
        _27662 = NOVALUE;
        DeRef(_27669);
        _27669 = NOVALUE;
        DeRef(_27682);
        _27682 = NOVALUE;
        DeRef(_27651);
        _27651 = NOVALUE;
        _27694 = NOVALUE;
        DeRef(_27678);
        _27678 = NOVALUE;
        DeRef(_27686);
        _27686 = NOVALUE;
        DeRef(_27689);
        _27689 = NOVALUE;
        _27696 = NOVALUE;
        return;
L19: 

        /** inline.e:501					goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** inline.e:503				case EXIT_BLOCK then*/
        case 206:

        /** inline.e:504					replace_code( "", pc, pc + 1 )*/
        _27699 = _pc_54478 + 1;
        if (_27699 > MAXINT){
            _27699 = NewDouble((eudouble)_27699);
        }
        RefDS(_22209);
        _66replace_code(_22209, _pc_54478, _27699);
        _27699 = NOVALUE;

        /** inline.e:505					continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** inline.e:507				case SWITCH_RT then*/
        case 202:

        /** inline.e:508					sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27700 = _pc_54478 + 2;
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27701 = (object)*(((s1_ptr)_2)->base + _27700);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_27701)){
            _27702 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27701)->dbl));
        }
        else{
            _27702 = (object)*(((s1_ptr)_2)->base + _27701);
        }
        DeRef(_values_54599);
        _2 = (object)SEQ_PTR(_27702);
        _values_54599 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_values_54599);
        _27702 = NOVALUE;

        /** inline.e:509					for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_54599)){
                _27704 = SEQ_PTR(_values_54599)->length;
        }
        else {
            _27704 = 1;
        }
        {
            object _i_54607;
            _i_54607 = 1;
L1A: 
            if (_i_54607 > _27704){
                goto L1B; // [771] 811
            }

            /** inline.e:510						if sequence( values[i] ) then*/
            _2 = (object)SEQ_PTR(_values_54599);
            _27705 = (object)*(((s1_ptr)_2)->base + _i_54607);
            _27706 = IS_SEQUENCE(_27705);
            _27705 = NOVALUE;
            if (_27706 == 0)
            {
                _27706 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27706 = NOVALUE;
            }

            /** inline.e:512							defer()*/
            _66defer();

            /** inline.e:513							restore_code()*/
            _66restore_code();

            /** inline.e:514							return*/
            DeRefDS(_values_54599);
            DeRefi(_backpatch_op_54518);
            DeRef(_27700);
            _27700 = NOVALUE;
            DeRef(_27648);
            _27648 = NOVALUE;
            DeRef(_27683);
            _27683 = NOVALUE;
            DeRef(_27645);
            _27645 = NOVALUE;
            _27641 = NOVALUE;
            DeRef(_27662);
            _27662 = NOVALUE;
            DeRef(_27669);
            _27669 = NOVALUE;
            DeRef(_27682);
            _27682 = NOVALUE;
            _27701 = NOVALUE;
            DeRef(_27651);
            _27651 = NOVALUE;
            DeRef(_27694);
            _27694 = NOVALUE;
            DeRef(_27678);
            _27678 = NOVALUE;
            DeRef(_27686);
            _27686 = NOVALUE;
            DeRef(_27689);
            _27689 = NOVALUE;
            DeRef(_27696);
            _27696 = NOVALUE;
            return;
L1C: 

            /** inline.e:516					end for*/
            _i_54607 = _i_54607 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** inline.e:517					backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_54518, _backpatch_op_54518, _pc_54478);
        DeRef(_values_54599);
        _values_54599 = NOVALUE;

        /** inline.e:520				case else*/
        default:

        /** inline.e:521				label "inline op"*/
G18:

        /** inline.e:522					if not inline_op( pc ) then*/
        _27708 = _66inline_op(_pc_54478);
        if (IS_ATOM_INT(_27708)) {
            if (_27708 != 0){
                DeRef(_27708);
                _27708 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27708)->dbl != 0.0){
                DeRef(_27708);
                _27708 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27708);
        _27708 = NOVALUE;

        /** inline.e:524						defer()*/
        _66defer();

        /** inline.e:525						restore_code()*/
        _66restore_code();

        /** inline.e:526						return*/
        DeRefi(_backpatch_op_54518);
        DeRef(_27700);
        _27700 = NOVALUE;
        DeRef(_27648);
        _27648 = NOVALUE;
        DeRef(_27683);
        _27683 = NOVALUE;
        DeRef(_27645);
        _27645 = NOVALUE;
        _27641 = NOVALUE;
        DeRef(_27662);
        _27662 = NOVALUE;
        DeRef(_27669);
        _27669 = NOVALUE;
        DeRef(_27682);
        _27682 = NOVALUE;
        _27701 = NOVALUE;
        DeRef(_27651);
        _27651 = NOVALUE;
        DeRef(_27694);
        _27694 = NOVALUE;
        DeRef(_27678);
        _27678 = NOVALUE;
        DeRef(_27686);
        _27686 = NOVALUE;
        DeRef(_27689);
        _27689 = NOVALUE;
        DeRef(_27696);
        _27696 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** inline.e:530			pc = advance( pc, inline_code )*/
    RefDS(_66inline_code_53930);
    _pc_54478 = _66advance(_pc_54478, _66inline_code_53930);
    if (!IS_ATOM_INT(_pc_54478)) {
        _1 = (object)(DBL_PTR(_pc_54478)->dbl);
        DeRefDS(_pc_54478);
        _pc_54478 = _1;
    }

    /** inline.e:532		end while*/
    goto LD; // [866] 347
LE: 

    /** inline.e:534		SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_54449 + ((s1_ptr)_2)->base);
    RefDS(_66assigned_params_53936);
    _27713 = _25sort(_66assigned_params_53936, 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27713;
    RefDS(_66inline_code_53930);
    ((intptr_t*)_2)[2] = _66inline_code_53930;
    RefDS(_backpatch_op_54518);
    ((intptr_t*)_2)[3] = _backpatch_op_54518;
    _27714 = MAKE_SEQ(_1);
    _27713 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27714;
    if( _1 != _27714 ){
        DeRef(_1);
    }
    _27714 = NOVALUE;
    _27711 = NOVALUE;

    /** inline.e:535		restore_code()*/
    _66restore_code();

    /** inline.e:536	end procedure*/
    DeRefDSi(_backpatch_op_54518);
    DeRef(_27700);
    _27700 = NOVALUE;
    DeRef(_27648);
    _27648 = NOVALUE;
    DeRef(_27683);
    _27683 = NOVALUE;
    DeRef(_27645);
    _27645 = NOVALUE;
    _27641 = NOVALUE;
    DeRef(_27662);
    _27662 = NOVALUE;
    DeRef(_27669);
    _27669 = NOVALUE;
    DeRef(_27682);
    _27682 = NOVALUE;
    _27701 = NOVALUE;
    DeRef(_27651);
    _27651 = NOVALUE;
    DeRef(_27694);
    _27694 = NOVALUE;
    DeRef(_27678);
    _27678 = NOVALUE;
    DeRef(_27686);
    _27686 = NOVALUE;
    DeRef(_27689);
    _27689 = NOVALUE;
    DeRef(_27696);
    _27696 = NOVALUE;
    return;
    ;
}


void _66replace_temp(object _pc_54627)
{
    object _temp_num_54628 = NOVALUE;
    object _needed_54631 = NOVALUE;
    object _27727 = NOVALUE;
    object _27726 = NOVALUE;
    object _27725 = NOVALUE;
    object _27724 = NOVALUE;
    object _27722 = NOVALUE;
    object _27720 = NOVALUE;
    object _27717 = NOVALUE;
    object _27715 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:539		integer temp_num = inline_code[pc][2]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27715 = (object)*(((s1_ptr)_2)->base + _pc_54627);
    _2 = (object)SEQ_PTR(_27715);
    _temp_num_54628 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_54628)){
        _temp_num_54628 = (object)DBL_PTR(_temp_num_54628)->dbl;
    }
    _27715 = NOVALUE;

    /** inline.e:540		integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_66inline_temps_53932)){
            _27717 = SEQ_PTR(_66inline_temps_53932)->length;
    }
    else {
        _27717 = 1;
    }
    _needed_54631 = _temp_num_54628 - _27717;
    _27717 = NOVALUE;

    /** inline.e:541		if needed > 0 then*/
    if (_needed_54631 <= 0)
    goto L1; // [30] 47

    /** inline.e:542			inline_temps &= repeat( 0, needed )*/
    _27720 = Repeat(0, _needed_54631);
    Concat((object_ptr)&_66inline_temps_53932, _66inline_temps_53932, _27720);
    DeRefDS(_27720);
    _27720 = NOVALUE;
L1: 

    /** inline.e:545		if not inline_temps[temp_num] then*/
    _2 = (object)SEQ_PTR(_66inline_temps_53932);
    _27722 = (object)*(((s1_ptr)_2)->base + _temp_num_54628);
    if (IS_ATOM_INT(_27722)) {
        if (_27722 != 0){
            _27722 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27722)->dbl != 0.0){
            _27722 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27722 = NOVALUE;

    /** inline.e:546			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** inline.e:547				inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((uintptr_t)_temp_num_54628 == (uintptr_t)HIGH_BITS){
        _27724 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27724 = - _temp_num_54628;
    }
    _27725 = _66new_inline_var(_27724, 0);
    _27724 = NOVALUE;
    _2 = (object)SEQ_PTR(_66inline_temps_53932);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_temps_53932 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54628);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27725;
    if( _1 != _27725 ){
        DeRef(_1);
    }
    _27725 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** inline.e:549				inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27726 = _53NewTempSym(_9TRUE_441);
    _2 = (object)SEQ_PTR(_66inline_temps_53932);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_temps_53932 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54628);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27726;
    if( _1 != _27726 ){
        DeRef(_1);
    }
    _27726 = NOVALUE;
L4: 
L2: 

    /** inline.e:554		inline_code[pc] = inline_temps[temp_num]*/
    _2 = (object)SEQ_PTR(_66inline_temps_53932);
    _27727 = (object)*(((s1_ptr)_2)->base + _temp_num_54628);
    Ref(_27727);
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54627);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27727;
    if( _1 != _27727 ){
        DeRef(_1);
    }
    _27727 = NOVALUE;

    /** inline.e:555	end procedure*/
    return;
    ;
}


object _66get_param_sym(object _pc_54653)
{
    object _il_54654 = NOVALUE;
    object _px_54662 = NOVALUE;
    object _27734 = NOVALUE;
    object _27731 = NOVALUE;
    object _27730 = NOVALUE;
    object _27729 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:558		object il = inline_code[pc]*/
    DeRef(_il_54654);
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _il_54654 = (object)*(((s1_ptr)_2)->base + _pc_54653);
    Ref(_il_54654);

    /** inline.e:559		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54654))
    _27729 = 1;
    else if (IS_ATOM_DBL(_il_54654))
    _27729 = IS_ATOM_INT(DoubleToInt(_il_54654));
    else
    _27729 = 0;
    if (_27729 == 0)
    {
        _27729 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27729 = NOVALUE;
    }

    /** inline.e:560			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27730 = (object)*(((s1_ptr)_2)->base + _pc_54653);
    Ref(_27730);
    DeRef(_il_54654);
    return _27730;
    goto L2; // [31] 53
L1: 

    /** inline.e:562		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54654)){
            _27731 = SEQ_PTR(_il_54654)->length;
    }
    else {
        _27731 = 1;
    }
    if (_27731 != 1)
    goto L3; // [39] 52

    /** inline.e:563			return inline_target*/
    DeRef(_il_54654);
    _27730 = NOVALUE;
    return _66inline_target_53937;
L3: 
L2: 

    /** inline.e:567		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54654);
    _px_54662 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54662)){
        _px_54662 = (object)DBL_PTR(_px_54662)->dbl;
    }

    /** inline.e:568		return passed_params[px]*/
    _2 = (object)SEQ_PTR(_66passed_params_53933);
    _27734 = (object)*(((s1_ptr)_2)->base + _px_54662);
    Ref(_27734);
    DeRef(_il_54654);
    _27730 = NOVALUE;
    return _27734;
    ;
}


object _66get_original_sym(object _pc_54667)
{
    object _il_54668 = NOVALUE;
    object _px_54676 = NOVALUE;
    object _27741 = NOVALUE;
    object _27738 = NOVALUE;
    object _27737 = NOVALUE;
    object _27736 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54667)) {
        _1 = (object)(DBL_PTR(_pc_54667)->dbl);
        DeRefDS(_pc_54667);
        _pc_54667 = _1;
    }

    /** inline.e:572		object il = inline_code[pc]*/
    DeRef(_il_54668);
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _il_54668 = (object)*(((s1_ptr)_2)->base + _pc_54667);
    Ref(_il_54668);

    /** inline.e:573		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54668))
    _27736 = 1;
    else if (IS_ATOM_DBL(_il_54668))
    _27736 = IS_ATOM_INT(DoubleToInt(_il_54668));
    else
    _27736 = 0;
    if (_27736 == 0)
    {
        _27736 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27736 = NOVALUE;
    }

    /** inline.e:574			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27737 = (object)*(((s1_ptr)_2)->base + _pc_54667);
    Ref(_27737);
    DeRef(_il_54668);
    return _27737;
    goto L2; // [31] 53
L1: 

    /** inline.e:576		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54668)){
            _27738 = SEQ_PTR(_il_54668)->length;
    }
    else {
        _27738 = 1;
    }
    if (_27738 != 1)
    goto L3; // [39] 52

    /** inline.e:577			return inline_target*/
    DeRef(_il_54668);
    _27737 = NOVALUE;
    return _66inline_target_53937;
L3: 
L2: 

    /** inline.e:581		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54668);
    _px_54676 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_54676)){
        _px_54676 = (object)DBL_PTR(_px_54676)->dbl;
    }

    /** inline.e:582		return original_params[px]*/
    _2 = (object)SEQ_PTR(_66original_params_53934);
    _27741 = (object)*(((s1_ptr)_2)->base + _px_54676);
    Ref(_27741);
    DeRef(_il_54668);
    _27737 = NOVALUE;
    return _27741;
    ;
}


void _66replace_var(object _pc_54685)
{
    object _27745 = NOVALUE;
    object _27744 = NOVALUE;
    object _27743 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:590		inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27743 = (object)*(((s1_ptr)_2)->base + _pc_54685);
    _2 = (object)SEQ_PTR(_27743);
    _27744 = (object)*(((s1_ptr)_2)->base + 2);
    _27743 = NOVALUE;
    _2 = (object)SEQ_PTR(_66proc_vars_53931);
    if (!IS_ATOM_INT(_27744)){
        _27745 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27744)->dbl));
    }
    else{
        _27745 = (object)*(((s1_ptr)_2)->base + _27744);
    }
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54685);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27745;
    if( _1 != _27745 ){
        DeRef(_1);
    }
    _27745 = NOVALUE;

    /** inline.e:591	end procedure*/
    _27744 = NOVALUE;
    return;
    ;
}


void _66fix_switch_rt(object _pc_54691)
{
    object _value_table_54693 = NOVALUE;
    object _jump_table_54700 = NOVALUE;
    object _27765 = NOVALUE;
    object _27764 = NOVALUE;
    object _27763 = NOVALUE;
    object _27762 = NOVALUE;
    object _27761 = NOVALUE;
    object _27760 = NOVALUE;
    object _27758 = NOVALUE;
    object _27757 = NOVALUE;
    object _27756 = NOVALUE;
    object _27755 = NOVALUE;
    object _27754 = NOVALUE;
    object _27752 = NOVALUE;
    object _27750 = NOVALUE;
    object _27749 = NOVALUE;
    object _27747 = NOVALUE;
    object _27746 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:594		symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _27746 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _27746 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27746;
    _27747 = MAKE_SEQ(_1);
    _27746 = NOVALUE;
    _value_table_54693 = _53NewStringSym(_27747);
    _27747 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_54693)) {
        _1 = (object)(DBL_PTR(_value_table_54693)->dbl);
        DeRefDS(_value_table_54693);
        _value_table_54693 = _1;
    }

    /** inline.e:595		symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _27749 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _27749 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _27749;
    _27750 = MAKE_SEQ(_1);
    _27749 = NOVALUE;
    _jump_table_54700 = _53NewStringSym(_27750);
    _27750 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_54700)) {
        _1 = (object)(DBL_PTR(_jump_table_54700)->dbl);
        DeRefDS(_jump_table_54700);
        _jump_table_54700 = _1;
    }

    /** inline.e:597		SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_value_table_54693 + ((s1_ptr)_2)->base);
    _27754 = _pc_54691 + 2;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27755 = (object)*(((s1_ptr)_2)->base + _27754);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_27755)){
        _27756 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27755)->dbl));
    }
    else{
        _27756 = (object)*(((s1_ptr)_2)->base + _27755);
    }
    _2 = (object)SEQ_PTR(_27756);
    _27757 = (object)*(((s1_ptr)_2)->base + 1);
    _27756 = NOVALUE;
    Ref(_27757);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27757;
    if( _1 != _27757 ){
        DeRef(_1);
    }
    _27757 = NOVALUE;
    _27752 = NOVALUE;

    /** inline.e:598		SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_54700 + ((s1_ptr)_2)->base);
    _27760 = _pc_54691 + 3;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _27761 = (object)*(((s1_ptr)_2)->base + _27760);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_27761)){
        _27762 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27761)->dbl));
    }
    else{
        _27762 = (object)*(((s1_ptr)_2)->base + _27761);
    }
    _2 = (object)SEQ_PTR(_27762);
    _27763 = (object)*(((s1_ptr)_2)->base + 1);
    _27762 = NOVALUE;
    Ref(_27763);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27763;
    if( _1 != _27763 ){
        DeRef(_1);
    }
    _27763 = NOVALUE;
    _27758 = NOVALUE;

    /** inline.e:600		inline_code[pc+2] = value_table*/
    _27764 = _pc_54691 + 2;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27764);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _value_table_54693;
    DeRef(_1);

    /** inline.e:601		inline_code[pc+3] = jump_table*/
    _27765 = _pc_54691 + 3;
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66inline_code_53930 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27765);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_table_54700;
    DeRef(_1);

    /** inline.e:603	end procedure*/
    _27765 = NOVALUE;
    _27760 = NOVALUE;
    _27754 = NOVALUE;
    _27764 = NOVALUE;
    _27761 = NOVALUE;
    _27755 = NOVALUE;
    return;
    ;
}


void _66fixup_special_op(object _pc_54730)
{
    object _op_54731 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54730)) {
        _1 = (object)(DBL_PTR(_pc_54730)->dbl);
        DeRefDS(_pc_54730);
        _pc_54730 = _1;
    }

    /** inline.e:606		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _op_54731 = (object)*(((s1_ptr)_2)->base + _pc_54730);
    if (!IS_ATOM_INT(_op_54731))
    _op_54731 = (object)DBL_PTR(_op_54731)->dbl;

    /** inline.e:607		switch op with fallthru do*/
    _0 = _op_54731;
    switch ( _0 ){ 

        /** inline.e:608			case SWITCH_RT then*/
        case 202:

        /** inline.e:609				fix_switch_rt( pc )*/
        _66fix_switch_rt(_pc_54730);

        /** inline.e:610				break*/
        goto L1; // [29] 32
    ;}L1: 

    /** inline.e:612	end procedure*/
    return;
    ;
}


object _66new_inline_var(object _ps_54742, object _reuse_54743)
{
    object _var_54745 = NOVALUE;
    object _vtype_54746 = NOVALUE;
    object _name_54747 = NOVALUE;
    object _s_54749 = NOVALUE;
    object _27828 = NOVALUE;
    object _27827 = NOVALUE;
    object _27825 = NOVALUE;
    object _27822 = NOVALUE;
    object _27821 = NOVALUE;
    object _27819 = NOVALUE;
    object _27816 = NOVALUE;
    object _27815 = NOVALUE;
    object _27814 = NOVALUE;
    object _27812 = NOVALUE;
    object _27807 = NOVALUE;
    object _27802 = NOVALUE;
    object _27801 = NOVALUE;
    object _27800 = NOVALUE;
    object _27799 = NOVALUE;
    object _27796 = NOVALUE;
    object _27794 = NOVALUE;
    object _27791 = NOVALUE;
    object _27786 = NOVALUE;
    object _27785 = NOVALUE;
    object _27784 = NOVALUE;
    object _27783 = NOVALUE;
    object _27782 = NOVALUE;
    object _27779 = NOVALUE;
    object _27778 = NOVALUE;
    object _27777 = NOVALUE;
    object _27776 = NOVALUE;
    object _27775 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_54742)) {
        _1 = (object)(DBL_PTR(_ps_54742)->dbl);
        DeRefDS(_ps_54742);
        _ps_54742 = _1;
    }

    /** inline.e:622			var = 0, */
    _var_54745 = 0;

    /** inline.e:624		sequence name*/

    /** inline.e:627		if reuse then*/

    /** inline.e:631		if not var then*/

    /** inline.e:632			if ps > 0 then*/
    if (_ps_54742 <= 0)
    goto L1; // [45] 222

    /** inline.e:633				s = ps*/
    _s_54749 = _ps_54742;

    /** inline.e:634				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** inline.e:635					name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27775 = (object)*(((s1_ptr)_2)->base + _s_54749);
    _2 = (object)SEQ_PTR(_27775);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27776 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27776 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27775 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27777 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53944);
    _2 = (object)SEQ_PTR(_27777);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27778 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27778 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27777 = NOVALUE;
    Ref(_27778);
    Ref(_27776);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27776;
    ((intptr_t *)_2)[2] = _27778;
    _27779 = MAKE_SEQ(_1);
    _27778 = NOVALUE;
    _27776 = NOVALUE;
    DeRefi(_name_54747);
    _name_54747 = EPrintf(-9999999, _27774, _27779);
    DeRefDS(_27779);
    _27779 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** inline.e:637					name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27782 = (object)*(((s1_ptr)_2)->base + _s_54749);
    _2 = (object)SEQ_PTR(_27782);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27783 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27783 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27782 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27784 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53944);
    _2 = (object)SEQ_PTR(_27784);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27785 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27785 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27784 = NOVALUE;
    Ref(_27785);
    Ref(_27783);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27783;
    ((intptr_t *)_2)[2] = _27785;
    _27786 = MAKE_SEQ(_1);
    _27785 = NOVALUE;
    _27783 = NOVALUE;
    DeRefi(_name_54747);
    _name_54747 = EPrintf(-9999999, _27781, _27786);
    DeRefDS(_27786);
    _27786 = NOVALUE;
L3: 

    /** inline.e:640				if reuse then*/
    if (_reuse_54743 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** inline.e:641					if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L5; // [148] 203

    /** inline.e:642						name &= ")"*/
    Concat((object_ptr)&_name_54747, _name_54747, _26551);
    goto L5; // [160] 203
L4: 

    /** inline.e:645					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** inline.e:646						name &= sprintf( "_at_%d", inline_start)*/
    _27791 = EPrintf(-9999999, _27790, _66inline_start_53942);
    Concat((object_ptr)&_name_54747, _name_54747, _27791);
    DeRefDS(_27791);
    _27791 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** inline.e:648						name &= sprintf( " at %d)", inline_start)*/
    _27794 = EPrintf(-9999999, _27793, _66inline_start_53942);
    Concat((object_ptr)&_name_54747, _name_54747, _27794);
    DeRefDS(_27794);
    _27794 = NOVALUE;
L7: 
L5: 

    /** inline.e:652				vtype = SymTab[s][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27796 = (object)*(((s1_ptr)_2)->base + _s_54749);
    _2 = (object)SEQ_PTR(_27796);
    _vtype_54746 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_54746)){
        _vtype_54746 = (object)DBL_PTR(_vtype_54746)->dbl;
    }
    _27796 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** inline.e:654				name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27799 = (object)*(((s1_ptr)_2)->base + _66inline_sub_53944);
    _2 = (object)SEQ_PTR(_27799);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27800 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27800 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27799 = NOVALUE;
    if ((uintptr_t)_ps_54742 == (uintptr_t)HIGH_BITS){
        _27801 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27801 = - _ps_54742;
    }
    Ref(_27800);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27800;
    ((intptr_t *)_2)[2] = _27801;
    _27802 = MAKE_SEQ(_1);
    _27801 = NOVALUE;
    _27800 = NOVALUE;
    DeRefi(_name_54747);
    _name_54747 = EPrintf(-9999999, _27798, _27802);
    DeRefDS(_27802);
    _27802 = NOVALUE;

    /** inline.e:655				if reuse then*/
    if (_reuse_54743 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** inline.e:656					name &= "__tmp"*/
    Concat((object_ptr)&_name_54747, _name_54747, _27804);
    goto LA; // [260] 276
L9: 

    /** inline.e:658					name &= sprintf( "__tmp_at%d", inline_start)*/
    _27807 = EPrintf(-9999999, _27806, _66inline_start_53942);
    Concat((object_ptr)&_name_54747, _name_54747, _27807);
    DeRefDS(_27807);
    _27807 = NOVALUE;
LA: 

    /** inline.e:660				vtype = object_type*/
    _vtype_54746 = _53object_type_47184;
L8: 

    /** inline.e:662			if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto LB; // [292] 325

    /** inline.e:663				var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54747);
    _var_54745 = _53NewEntry(_name_54747, _66varnum_53941, 5, -100, 2004, 0, _vtype_54746);
    if (!IS_ATOM_INT(_var_54745)) {
        _1 = (object)(DBL_PTR(_var_54745)->dbl);
        DeRefDS(_var_54745);
        _var_54745 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** inline.e:666				var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54747);
    _var_54745 = _53NewBasicEntry(_name_54747, _66varnum_53941, 3, -100, 2004, 0, _vtype_54746);
    if (!IS_ATOM_INT(_var_54745)) {
        _1 = (object)(DBL_PTR(_var_54745)->dbl);
        DeRefDS(_var_54745);
        _var_54745 = _1;
    }

    /** inline.e:667				SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54745 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27814 = (object)*(((s1_ptr)_2)->base + _66last_param_53945);
    _2 = (object)SEQ_PTR(_27814);
    _27815 = (object)*(((s1_ptr)_2)->base + 2);
    _27814 = NOVALUE;
    Ref(_27815);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27815;
    if( _1 != _27815 ){
        DeRef(_1);
    }
    _27815 = NOVALUE;
    _27812 = NOVALUE;

    /** inline.e:668				SymTab[last_param][S_NEXT] = var*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_66last_param_53945 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _var_54745;
    DeRef(_1);
    _27816 = NOVALUE;

    /** inline.e:669				if last_param = last_sym then*/
    if (_66last_param_53945 != _53last_sym_47193)
    goto LD; // [403] 415

    /** inline.e:670					last_sym = var*/
    _53last_sym_47193 = _var_54745;
LD: 
LC: 

    /** inline.e:673			if deferred_inlining then*/
    if (_66deferred_inlining_53940 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** inline.e:674				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _27821 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _27821 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _27819 = NOVALUE;
    if (IS_ATOM_INT(_27821)) {
        _27822 = _27821 + 1;
        if (_27822 > MAXINT){
            _27822 = NewDouble((eudouble)_27822);
        }
    }
    else
    _27822 = binary_op(PLUS, 1, _27821);
    _27821 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27822;
    if( _1 != _27822 ){
        DeRef(_1);
    }
    _27822 = NOVALUE;
    _27819 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** inline.e:676				if param_num != -1 then*/
    if (_43param_num_55414 == -1)
    goto L10; // [455] 470

    /** inline.e:677					param_num += 1*/
    _43param_num_55414 = _43param_num_55414 + 1;
L10: 
LF: 

    /** inline.e:680			SymTab[var][S_USAGE] = U_USED*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54745 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _27825 = NOVALUE;

    /** inline.e:681			if reuse then*/
    if (_reuse_54743 == 0)
    {
        goto L11; // [490] 511
    }
    else{
    }

    /** inline.e:682				map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27CurrentSub_20579;
    ((intptr_t *)_2)[2] = _ps_54742;
    _27827 = MAKE_SEQ(_1);
    Ref(_66inline_var_map_53949);
    _34nested_put(_66inline_var_map_53949, _27827, _var_54745, 1, 0);
    _27827 = NOVALUE;
L11: 

    /** inline.e:686		Block_var( var )*/
    _64Block_var(_var_54745);

    /** inline.e:687		if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L12; // [521] 536
    }
    else{
    }

    /** inline.e:688			add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _var_54745;
    _27828 = MAKE_SEQ(_1);
    _53add_ref(_27828);
    _27828 = NOVALUE;
L12: 

    /** inline.e:690		return var*/
    DeRefi(_name_54747);
    return _var_54745;
    ;
}


object _66get_inlined_code(object _sub_54879, object _start_54880, object _deferred_54881)
{
    object _is_proc_54882 = NOVALUE;
    object _backpatches_54900 = NOVALUE;
    object _prolog_54906 = NOVALUE;
    object _epilog_54907 = NOVALUE;
    object _s_54923 = NOVALUE;
    object _last_sym_54946 = NOVALUE;
    object _int_sym_54973 = NOVALUE;
    object _param_54981 = NOVALUE;
    object _ax_54984 = NOVALUE;
    object _var_54991 = NOVALUE;
    object _final_target_55006 = NOVALUE;
    object _var_55025 = NOVALUE;
    object _create_target_var_55038 = NOVALUE;
    object _check_pc_55061 = NOVALUE;
    object _op_55065 = NOVALUE;
    object _sym_55074 = NOVALUE;
    object _check_result_55079 = NOVALUE;
    object _inline_type_55157 = NOVALUE;
    object _replace_param_1__tmp_at1343_55168 = NOVALUE;
    object _27982 = NOVALUE;
    object _27981 = NOVALUE;
    object _27980 = NOVALUE;
    object _27979 = NOVALUE;
    object _27978 = NOVALUE;
    object _27977 = NOVALUE;
    object _27976 = NOVALUE;
    object _27975 = NOVALUE;
    object _27973 = NOVALUE;
    object _27970 = NOVALUE;
    object _27967 = NOVALUE;
    object _27966 = NOVALUE;
    object _27965 = NOVALUE;
    object _27964 = NOVALUE;
    object _27963 = NOVALUE;
    object _27962 = NOVALUE;
    object _27961 = NOVALUE;
    object _27960 = NOVALUE;
    object _27956 = NOVALUE;
    object _27955 = NOVALUE;
    object _27954 = NOVALUE;
    object _27953 = NOVALUE;
    object _27949 = NOVALUE;
    object _27948 = NOVALUE;
    object _27947 = NOVALUE;
    object _27946 = NOVALUE;
    object _27945 = NOVALUE;
    object _27944 = NOVALUE;
    object _27943 = NOVALUE;
    object _27941 = NOVALUE;
    object _27940 = NOVALUE;
    object _27939 = NOVALUE;
    object _27938 = NOVALUE;
    object _27937 = NOVALUE;
    object _27936 = NOVALUE;
    object _27935 = NOVALUE;
    object _27934 = NOVALUE;
    object _27933 = NOVALUE;
    object _27932 = NOVALUE;
    object _27931 = NOVALUE;
    object _27929 = NOVALUE;
    object _27928 = NOVALUE;
    object _27926 = NOVALUE;
    object _27925 = NOVALUE;
    object _27923 = NOVALUE;
    object _27922 = NOVALUE;
    object _27919 = NOVALUE;
    object _27918 = NOVALUE;
    object _27916 = NOVALUE;
    object _27914 = NOVALUE;
    object _27909 = NOVALUE;
    object _27905 = NOVALUE;
    object _27902 = NOVALUE;
    object _27898 = NOVALUE;
    object _27891 = NOVALUE;
    object _27890 = NOVALUE;
    object _27889 = NOVALUE;
    object _27888 = NOVALUE;
    object _27887 = NOVALUE;
    object _27886 = NOVALUE;
    object _27885 = NOVALUE;
    object _27883 = NOVALUE;
    object _27878 = NOVALUE;
    object _27875 = NOVALUE;
    object _27870 = NOVALUE;
    object _27869 = NOVALUE;
    object _27867 = NOVALUE;
    object _27866 = NOVALUE;
    object _27865 = NOVALUE;
    object _27862 = NOVALUE;
    object _27861 = NOVALUE;
    object _27860 = NOVALUE;
    object _27859 = NOVALUE;
    object _27858 = NOVALUE;
    object _27857 = NOVALUE;
    object _27856 = NOVALUE;
    object _27854 = NOVALUE;
    object _27853 = NOVALUE;
    object _27852 = NOVALUE;
    object _27850 = NOVALUE;
    object _27848 = NOVALUE;
    object _27847 = NOVALUE;
    object _27846 = NOVALUE;
    object _27845 = NOVALUE;
    object _27844 = NOVALUE;
    object _27843 = NOVALUE;
    object _27842 = NOVALUE;
    object _27839 = NOVALUE;
    object _27838 = NOVALUE;
    object _27836 = NOVALUE;
    object _27835 = NOVALUE;
    object _27833 = NOVALUE;
    object _27832 = NOVALUE;
    object _27830 = NOVALUE;
    object _27829 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_start_54880)) {
        _1 = (object)(DBL_PTR(_start_54880)->dbl);
        DeRefDS(_start_54880);
        _start_54880 = _1;
    }

    /** inline.e:694		integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27829 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27829);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _27830 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _27830 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _27829 = NOVALUE;
    if (IS_ATOM_INT(_27830)) {
        _is_proc_54882 = (_27830 == 27);
    }
    else {
        _is_proc_54882 = binary_op(EQUALS, _27830, 27);
    }
    _27830 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_54882)) {
        _1 = (object)(DBL_PTR(_is_proc_54882)->dbl);
        DeRefDS(_is_proc_54882);
        _is_proc_54882 = _1;
    }

    /** inline.e:695		clear_inline_targets()*/
    _45clear_inline_targets();

    /** inline.e:697		inline_temps = {}*/
    RefDS(_22209);
    DeRef(_66inline_temps_53932);
    _66inline_temps_53932 = _22209;

    /** inline.e:698		inline_params = {}*/
    RefDS(_22209);
    DeRefi(_66inline_params_53935);
    _66inline_params_53935 = _22209;

    /** inline.e:699		assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27832 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27832);
    _27833 = (object)*(((s1_ptr)_2)->base + 29);
    _27832 = NOVALUE;
    DeRef(_66assigned_params_53936);
    _2 = (object)SEQ_PTR(_27833);
    _66assigned_params_53936 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_66assigned_params_53936);
    _27833 = NOVALUE;

    /** inline.e:700		inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27835 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27835);
    _27836 = (object)*(((s1_ptr)_2)->base + 29);
    _27835 = NOVALUE;
    DeRef(_66inline_code_53930);
    _2 = (object)SEQ_PTR(_27836);
    _66inline_code_53930 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_66inline_code_53930);
    _27836 = NOVALUE;

    /** inline.e:701		sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27838 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27838);
    _27839 = (object)*(((s1_ptr)_2)->base + 29);
    _27838 = NOVALUE;
    DeRef(_backpatches_54900);
    _2 = (object)SEQ_PTR(_27839);
    _backpatches_54900 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_54900);
    _27839 = NOVALUE;

    /** inline.e:703		passed_params = {}*/
    RefDS(_22209);
    DeRef(_66passed_params_53933);
    _66passed_params_53933 = _22209;

    /** inline.e:704		original_params = {}*/
    RefDS(_22209);
    DeRef(_66original_params_53934);
    _66original_params_53934 = _22209;

    /** inline.e:705		proc_vars = {}*/
    RefDS(_22209);
    DeRefi(_66proc_vars_53931);
    _66proc_vars_53931 = _22209;

    /** inline.e:706		sequence prolog = {}*/
    RefDS(_22209);
    DeRefi(_prolog_54906);
    _prolog_54906 = _22209;

    /** inline.e:707		sequence epilog = {}*/
    RefDS(_22209);
    DeRef(_epilog_54907);
    _epilog_54907 = _22209;

    /** inline.e:709		Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27842 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27842);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27843 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27843 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27842 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27844 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_27844);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27845 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27845 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27844 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27843);
    ((intptr_t*)_2)[1] = _27843;
    Ref(_27845);
    ((intptr_t*)_2)[2] = _27845;
    ((intptr_t*)_2)[3] = _start_54880;
    _27846 = MAKE_SEQ(_1);
    _27845 = NOVALUE;
    _27843 = NOVALUE;
    _27847 = EPrintf(-9999999, _27841, _27846);
    DeRefDS(_27846);
    _27846 = NOVALUE;
    _64Start_block(206, _27847);
    _27847 = NOVALUE;

    /** inline.e:712		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27848 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27848);
    _s_54923 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54923)){
        _s_54923 = (object)DBL_PTR(_s_54923)->dbl;
    }
    _27848 = NOVALUE;

    /** inline.e:714		varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27850 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_27850);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _66varnum_53941 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _66varnum_53941 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_66varnum_53941)){
        _66varnum_53941 = (object)DBL_PTR(_66varnum_53941)->dbl;
    }
    _27850 = NOVALUE;

    /** inline.e:715		inline_start = start*/
    _66inline_start_53942 = _start_54880;

    /** inline.e:717		last_param = CurrentSub*/
    _66last_param_53945 = _27CurrentSub_20579;

    /** inline.e:718		for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27852 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_27852);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _27853 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _27853 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _27852 = NOVALUE;
    {
        object _p_54935;
        _p_54935 = 1;
L1: 
        if (binary_op_a(GREATER, _p_54935, _27853)){
            goto L2; // [250] 282
        }

        /** inline.e:719			last_param = SymTab[last_param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27854 = (object)*(((s1_ptr)_2)->base + _66last_param_53945);
        _2 = (object)SEQ_PTR(_27854);
        _66last_param_53945 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_66last_param_53945)){
            _66last_param_53945 = (object)DBL_PTR(_66last_param_53945)->dbl;
        }
        _27854 = NOVALUE;

        /** inline.e:720		end for*/
        _0 = _p_54935;
        if (IS_ATOM_INT(_p_54935)) {
            _p_54935 = _p_54935 + 1;
            if ((object)((uintptr_t)_p_54935 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54935 = NewDouble((eudouble)_p_54935);
            }
        }
        else {
            _p_54935 = binary_op_a(PLUS, _p_54935, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_54935);
    }

    /** inline.e:722		symtab_index last_sym = last_param*/
    _last_sym_54946 = _66last_param_53945;

    /** inline.e:723		while last_sym and */
L3: 
    if (_last_sym_54946 == 0) {
        goto L4; // [296] 368
    }
    _27857 = _53sym_scope(_last_sym_54946);
    if (IS_ATOM_INT(_27857)) {
        _27858 = (_27857 <= 3);
    }
    else {
        _27858 = binary_op(LESSEQ, _27857, 3);
    }
    DeRef(_27857);
    _27857 = NOVALUE;
    if (IS_ATOM_INT(_27858)) {
        if (_27858 != 0) {
            DeRef(_27859);
            _27859 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27858)->dbl != 0.0) {
            DeRef(_27859);
            _27859 = 1;
            goto L5; // [310] 328
        }
    }
    _27860 = _53sym_scope(_last_sym_54946);
    if (IS_ATOM_INT(_27860)) {
        _27861 = (_27860 == 9);
    }
    else {
        _27861 = binary_op(EQUALS, _27860, 9);
    }
    DeRef(_27860);
    _27860 = NOVALUE;
    DeRef(_27859);
    if (IS_ATOM_INT(_27861))
    _27859 = (_27861 != 0);
    else
    _27859 = DBL_PTR(_27861)->dbl != 0.0;
L5: 
    if (_27859 == 0)
    {
        _27859 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27859 = NOVALUE;
    }

    /** inline.e:725			last_param = last_sym*/
    _66last_param_53945 = _last_sym_54946;

    /** inline.e:726			last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27862 = (object)*(((s1_ptr)_2)->base + _last_sym_54946);
    _2 = (object)SEQ_PTR(_27862);
    _last_sym_54946 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_54946)){
        _last_sym_54946 = (object)DBL_PTR(_last_sym_54946)->dbl;
    }
    _27862 = NOVALUE;

    /** inline.e:727			varnum += 1*/
    _66varnum_53941 = _66varnum_53941 + 1;

    /** inline.e:728		end while*/
    goto L3; // [365] 296
L4: 

    /** inline.e:729		for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27865 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27865);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _27866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _27866 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _27865 = NOVALUE;
    {
        object _p_54964;
        Ref(_27866);
        _p_54964 = _27866;
L6: 
        if (binary_op_a(LESS, _p_54964, 1)){
            goto L7; // [382] 407
        }

        /** inline.e:730			passed_params = prepend( passed_params, Pop() )*/
        _27867 = _45Pop();
        Ref(_27867);
        Prepend(&_66passed_params_53933, _66passed_params_53933, _27867);
        DeRef(_27867);
        _27867 = NOVALUE;

        /** inline.e:731		end for*/
        _0 = _p_54964;
        if (IS_ATOM_INT(_p_54964)) {
            _p_54964 = _p_54964 + -1;
            if ((object)((uintptr_t)_p_54964 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54964 = NewDouble((eudouble)_p_54964);
            }
        }
        else {
            _p_54964 = binary_op_a(PLUS, _p_54964, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_54964);
    }

    /** inline.e:733		original_params = passed_params*/
    RefDS(_66passed_params_53933);
    DeRef(_66original_params_53934);
    _66original_params_53934 = _66passed_params_53933;

    /** inline.e:735		symtab_index int_sym = 0*/
    _int_sym_54973 = 0;

    /** inline.e:736		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27869 = (object)*(((s1_ptr)_2)->base + _sub_54879);
    _2 = (object)SEQ_PTR(_27869);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _27870 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _27870 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _27869 = NOVALUE;
    {
        object _p_54975;
        _p_54975 = 1;
L8: 
        if (binary_op_a(GREATER, _p_54975, _27870)){
            goto L9; // [437] 575
        }

        /** inline.e:737			symtab_index param = passed_params[p]*/
        _2 = (object)SEQ_PTR(_66passed_params_53933);
        if (!IS_ATOM_INT(_p_54975)){
            _param_54981 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54975)->dbl));
        }
        else{
            _param_54981 = (object)*(((s1_ptr)_2)->base + _p_54975);
        }
        if (!IS_ATOM_INT(_param_54981)){
            _param_54981 = (object)DBL_PTR(_param_54981)->dbl;
        }

        /** inline.e:738			inline_params &= s*/
        Append(&_66inline_params_53935, _66inline_params_53935, _s_54923);

        /** inline.e:739			integer ax = find( p, assigned_params )*/
        _ax_54984 = find_from(_p_54975, _66assigned_params_53936, 1);

        /** inline.e:740			if ax or is_temp( param ) then*/
        if (_ax_54984 != 0) {
            goto LA; // [473] 486
        }
        _27875 = _66is_temp(_param_54981);
        if (_27875 == 0) {
            DeRef(_27875);
            _27875 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27875) && DBL_PTR(_27875)->dbl == 0.0){
                DeRef(_27875);
                _27875 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27875);
            _27875 = NOVALUE;
        }
        DeRef(_27875);
        _27875 = NOVALUE;
LA: 

        /** inline.e:743				varnum += 1*/
        _66varnum_53941 = _66varnum_53941 + 1;

        /** inline.e:744				symtab_index var = new_inline_var( s, 0 )*/
        _var_54991 = _66new_inline_var(_s_54923, 0);
        if (!IS_ATOM_INT(_var_54991)) {
            _1 = (object)(DBL_PTR(_var_54991)->dbl);
            DeRefDS(_var_54991);
            _var_54991 = _1;
        }

        /** inline.e:745				prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 18;
        ((intptr_t*)_2)[2] = _param_54981;
        ((intptr_t*)_2)[3] = _var_54991;
        _27878 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_54906, _prolog_54906, _27878);
        DeRefDS(_27878);
        _27878 = NOVALUE;

        /** inline.e:746				if not int_sym then*/
        if (_int_sym_54973 != 0)
        goto LC; // [519] 531

        /** inline.e:747					int_sym = NewIntSym( 0 )*/
        _int_sym_54973 = _53NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_54973)) {
            _1 = (object)(DBL_PTR(_int_sym_54973)->dbl);
            DeRefDS(_int_sym_54973);
            _int_sym_54973 = _1;
        }
LC: 

        /** inline.e:750				inline_start += 3*/
        _66inline_start_53942 = _66inline_start_53942 + 3;

        /** inline.e:751				passed_params[p] = var*/
        _2 = (object)SEQ_PTR(_66passed_params_53933);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _66passed_params_53933 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_54975))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54975)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _p_54975);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _var_54991;
        DeRef(_1);
LB: 

        /** inline.e:753			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27883 = (object)*(((s1_ptr)_2)->base + _s_54923);
        _2 = (object)SEQ_PTR(_27883);
        _s_54923 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54923)){
            _s_54923 = (object)DBL_PTR(_s_54923)->dbl;
        }
        _27883 = NOVALUE;

        /** inline.e:755		end for*/
        _0 = _p_54975;
        if (IS_ATOM_INT(_p_54975)) {
            _p_54975 = _p_54975 + 1;
            if ((object)((uintptr_t)_p_54975 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54975 = NewDouble((eudouble)_p_54975);
            }
        }
        else {
            _p_54975 = binary_op_a(PLUS, _p_54975, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_54975);
    }

    /** inline.e:757		symtab_index final_target = 0*/
    _final_target_55006 = 0;

    /** inline.e:758		while s and */
LD: 
    if (_s_54923 == 0) {
        goto LE; // [587] 699
    }
    _27886 = _53sym_scope(_s_54923);
    if (IS_ATOM_INT(_27886)) {
        _27887 = (_27886 <= 3);
    }
    else {
        _27887 = binary_op(LESSEQ, _27886, 3);
    }
    DeRef(_27886);
    _27886 = NOVALUE;
    if (IS_ATOM_INT(_27887)) {
        if (_27887 != 0) {
            DeRef(_27888);
            _27888 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27887)->dbl != 0.0) {
            DeRef(_27888);
            _27888 = 1;
            goto LF; // [601] 619
        }
    }
    _27889 = _53sym_scope(_s_54923);
    if (IS_ATOM_INT(_27889)) {
        _27890 = (_27889 == 9);
    }
    else {
        _27890 = binary_op(EQUALS, _27889, 9);
    }
    DeRef(_27889);
    _27889 = NOVALUE;
    DeRef(_27888);
    if (IS_ATOM_INT(_27890))
    _27888 = (_27890 != 0);
    else
    _27888 = DBL_PTR(_27890)->dbl != 0.0;
LF: 
    if (_27888 == 0)
    {
        _27888 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27888 = NOVALUE;
    }

    /** inline.e:760			if sym_scope( s ) != SC_UNDEFINED then*/
    _27891 = _53sym_scope(_s_54923);
    if (binary_op_a(EQUALS, _27891, 9)){
        DeRef(_27891);
        _27891 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27891);
    _27891 = NOVALUE;

    /** inline.e:763				varnum += 1*/
    _66varnum_53941 = _66varnum_53941 + 1;

    /** inline.e:764				symtab_index var = new_inline_var( s, 0 )*/
    _var_55025 = _66new_inline_var(_s_54923, 0);
    if (!IS_ATOM_INT(_var_55025)) {
        _1 = (object)(DBL_PTR(_var_55025)->dbl);
        DeRefDS(_var_55025);
        _var_55025 = _1;
    }

    /** inline.e:765				proc_vars &= var*/
    Append(&_66proc_vars_53931, _66proc_vars_53931, _var_55025);

    /** inline.e:766				if int_sym = 0 then*/
    if (_int_sym_54973 != 0)
    goto L11; // [662] 675

    /** inline.e:767					int_sym = NewIntSym( 0 )*/
    _int_sym_54973 = _53NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_54973)) {
        _1 = (object)(DBL_PTR(_int_sym_54973)->dbl);
        DeRefDS(_int_sym_54973);
        _int_sym_54973 = _1;
    }
L11: 
L10: 

    /** inline.e:770			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27898 = (object)*(((s1_ptr)_2)->base + _s_54923);
    _2 = (object)SEQ_PTR(_27898);
    _s_54923 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_54923)){
        _s_54923 = (object)DBL_PTR(_s_54923)->dbl;
    }
    _27898 = NOVALUE;

    /** inline.e:771		end while*/
    goto LD; // [696] 587
LE: 

    /** inline.e:773		if not is_proc then*/
    if (_is_proc_54882 != 0)
    goto L12; // [701] 831

    /** inline.e:774			integer create_target_var = 1*/
    _create_target_var_55038 = 1;

    /** inline.e:775			if deferred then*/
    if (_deferred_54881 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** inline.e:776				inline_target = Pop()*/
    _0 = _45Pop();
    _66inline_target_53937 = _0;
    if (!IS_ATOM_INT(_66inline_target_53937)) {
        _1 = (object)(DBL_PTR(_66inline_target_53937)->dbl);
        DeRefDS(_66inline_target_53937);
        _66inline_target_53937 = _1;
    }

    /** inline.e:777				if is_temp( inline_target ) then*/
    _27902 = _66is_temp(_66inline_target_53937);
    if (_27902 == 0) {
        DeRef(_27902);
        _27902 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27902) && DBL_PTR(_27902)->dbl == 0.0){
            DeRef(_27902);
            _27902 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27902);
        _27902 = NOVALUE;
    }
    DeRef(_27902);
    _27902 = NOVALUE;

    /** inline.e:778					final_target = inline_target*/
    _final_target_55006 = _66inline_target_53937;
    goto L15; // [741] 750
L14: 

    /** inline.e:780					create_target_var = 0*/
    _create_target_var_55038 = 0;
L15: 
L13: 

    /** inline.e:784			if create_target_var then*/
    if (_create_target_var_55038 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** inline.e:785				varnum += 1*/
    _66varnum_53941 = _66varnum_53941 + 1;

    /** inline.e:786				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** inline.e:787					inline_target = new_inline_var( sub, 0 )*/
    _0 = _66new_inline_var(_sub_54879, 0);
    _66inline_target_53937 = _0;
    if (!IS_ATOM_INT(_66inline_target_53937)) {
        _1 = (object)(DBL_PTR(_66inline_target_53937)->dbl);
        DeRefDS(_66inline_target_53937);
        _66inline_target_53937 = _1;
    }

    /** inline.e:788					SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_66inline_target_53937 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_47184;
    DeRef(_1);
    _27905 = NOVALUE;

    /** inline.e:789					Pop_block_var()*/
    _64Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** inline.e:791					inline_target = NewTempSym()*/
    _0 = _53NewTempSym(0);
    _66inline_target_53937 = _0;
    if (!IS_ATOM_INT(_66inline_target_53937)) {
        _1 = (object)(DBL_PTR(_66inline_target_53937)->dbl);
        DeRefDS(_66inline_target_53937);
        _66inline_target_53937 = _1;
    }
L18: 
L16: 

    /** inline.e:794			proc_vars &= inline_target*/
    Append(&_66proc_vars_53931, _66proc_vars_53931, _66inline_target_53937);
    goto L19; // [828] 837
L12: 

    /** inline.e:796			inline_target = 0*/
    _66inline_target_53937 = 0;
L19: 

    /** inline.e:800		integer check_pc = 1*/
    _check_pc_55061 = 1;

    /** inline.e:802		while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27909 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27909 = 1;
    }
    if (_27909 <= _check_pc_55061)
    goto L1B; // [852] 1218

    /** inline.e:803			integer op = inline_code[check_pc]*/
    _2 = (object)SEQ_PTR(_66inline_code_53930);
    _op_55065 = (object)*(((s1_ptr)_2)->base + _check_pc_55061);
    if (!IS_ATOM_INT(_op_55065))
    _op_55065 = (object)DBL_PTR(_op_55065)->dbl;

    /** inline.e:805			switch op with fallthru do*/
    _0 = _op_55065;
    switch ( _0 ){ 

        /** inline.e:806				case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** inline.e:809					symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27914 = _check_pc_55061 + 1;
        if (_27914 > MAXINT){
            _27914 = NewDouble((eudouble)_27914);
        }
        _sym_55074 = _66get_original_sym(_27914);
        _27914 = NOVALUE;
        if (!IS_ATOM_INT(_sym_55074)) {
            _1 = (object)(DBL_PTR(_sym_55074)->dbl);
            DeRefDS(_sym_55074);
            _sym_55074 = _1;
        }

        /** inline.e:810					if is_literal( sym ) then*/
        _27916 = _66is_literal(_sym_55074);
        if (_27916 == 0) {
            DeRef(_27916);
            _27916 = NOVALUE;
            goto L1C; // [897] 1012
        }
        else {
            if (!IS_ATOM_INT(_27916) && DBL_PTR(_27916)->dbl == 0.0){
                DeRef(_27916);
                _27916 = NOVALUE;
                goto L1C; // [897] 1012
            }
            DeRef(_27916);
            _27916 = NOVALUE;
        }
        DeRef(_27916);
        _27916 = NOVALUE;

        /** inline.e:811						integer check_result*/

        /** inline.e:813						if op = INTEGER_CHECK then*/
        if (_op_55065 != 96)
        goto L1D; // [906] 930

        /** inline.e:814							check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27918 = (object)*(((s1_ptr)_2)->base + _sym_55074);
        _2 = (object)SEQ_PTR(_27918);
        _27919 = (object)*(((s1_ptr)_2)->base + 1);
        _27918 = NOVALUE;
        if (IS_ATOM_INT(_27919))
        _check_result_55079 = 1;
        else if (IS_ATOM_DBL(_27919))
        _check_result_55079 = IS_ATOM_INT(DoubleToInt(_27919));
        else
        _check_result_55079 = 0;
        _27919 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** inline.e:815						elsif op = SEQUENCE_CHECK then*/
        if (_op_55065 != 97)
        goto L1F; // [934] 958

        /** inline.e:816							check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27922 = (object)*(((s1_ptr)_2)->base + _sym_55074);
        _2 = (object)SEQ_PTR(_27922);
        _27923 = (object)*(((s1_ptr)_2)->base + 1);
        _27922 = NOVALUE;
        _check_result_55079 = IS_SEQUENCE(_27923);
        _27923 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** inline.e:818							check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27925 = (object)*(((s1_ptr)_2)->base + _sym_55074);
        _2 = (object)SEQ_PTR(_27925);
        _27926 = (object)*(((s1_ptr)_2)->base + 1);
        _27925 = NOVALUE;
        _check_result_55079 = IS_ATOM(_27926);
        _27926 = NOVALUE;
L1E: 

        /** inline.e:821						if check_result then*/
        if (_check_result_55079 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** inline.e:822							replace_code( {}, check_pc, check_pc+1 )*/
        _27928 = _check_pc_55061 + 1;
        if (_27928 > MAXINT){
            _27928 = NewDouble((eudouble)_27928);
        }
        RefDS(_22209);
        _66replace_code(_22209, _check_pc_55061, _27928);
        _27928 = NOVALUE;
        goto L21; // [994] 1007
L20: 

        /** inline.e:826							CompileErr(TYPE_CHECK_ERROR_WHEN_INLINING_LITERAL)*/
        RefDS(_22209);
        _49CompileErr(146, _22209, 0);
L21: 
        goto L22; // [1009] 1174
L1C: 

        /** inline.e:829					elsif not is_temp( sym ) then*/
        _27929 = _66is_temp(_sym_55074);
        if (IS_ATOM_INT(_27929)) {
            if (_27929 != 0){
                DeRef(_27929);
                _27929 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        else {
            if (DBL_PTR(_27929)->dbl != 0.0){
                DeRef(_27929);
                _27929 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        DeRef(_27929);
        _27929 = NOVALUE;

        /** inline.e:831						if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27931 = (_op_55065 == 96);
        if (_27931 == 0) {
            _27932 = 0;
            goto L24; // [1029] 1055
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27933 = (object)*(((s1_ptr)_2)->base + _sym_55074);
        _2 = (object)SEQ_PTR(_27933);
        _27934 = (object)*(((s1_ptr)_2)->base + 15);
        _27933 = NOVALUE;
        if (IS_ATOM_INT(_27934)) {
            _27935 = (_27934 == _53integer_type_47190);
        }
        else {
            _27935 = binary_op(EQUALS, _27934, _53integer_type_47190);
        }
        _27934 = NOVALUE;
        if (IS_ATOM_INT(_27935))
        _27932 = (_27935 != 0);
        else
        _27932 = DBL_PTR(_27935)->dbl != 0.0;
L24: 
        if (_27932 != 0) {
            _27936 = 1;
            goto L25; // [1055] 1095
        }
        _27937 = (_op_55065 == 97);
        if (_27937 == 0) {
            _27938 = 0;
            goto L26; // [1065] 1091
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27939 = (object)*(((s1_ptr)_2)->base + _sym_55074);
        _2 = (object)SEQ_PTR(_27939);
        _27940 = (object)*(((s1_ptr)_2)->base + 15);
        _27939 = NOVALUE;
        if (IS_ATOM_INT(_27940)) {
            _27941 = (_27940 == _53sequence_type_47188);
        }
        else {
            _27941 = binary_op(EQUALS, _27940, _53sequence_type_47188);
        }
        _27940 = NOVALUE;
        if (IS_ATOM_INT(_27941))
        _27938 = (_27941 != 0);
        else
        _27938 = DBL_PTR(_27941)->dbl != 0.0;
L26: 
        _27936 = (_27938 != 0);
L25: 
        if (_27936 != 0) {
            goto L27; // [1095] 1143
        }
        _27943 = (_op_55065 == 101);
        if (_27943 == 0) {
            DeRef(_27944);
            _27944 = 0;
            goto L28; // [1105] 1138
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27945 = (object)*(((s1_ptr)_2)->base + _sym_55074);
        _2 = (object)SEQ_PTR(_27945);
        _27946 = (object)*(((s1_ptr)_2)->base + 15);
        _27945 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _53integer_type_47190;
        ((intptr_t *)_2)[2] = _53atom_type_47186;
        _27947 = MAKE_SEQ(_1);
        _27948 = find_from(_27946, _27947, 1);
        _27946 = NOVALUE;
        DeRefDS(_27947);
        _27947 = NOVALUE;
        _27944 = (_27948 != 0);
L28: 
        if (_27944 == 0)
        {
            _27944 = NOVALUE;
            goto L29; // [1139] 1157
        }
        else{
            _27944 = NOVALUE;
        }
L27: 

        /** inline.e:834							replace_code( {}, check_pc, check_pc+1 )*/
        _27949 = _check_pc_55061 + 1;
        if (_27949 > MAXINT){
            _27949 = NewDouble((eudouble)_27949);
        }
        RefDS(_22209);
        _66replace_code(_22209, _check_pc_55061, _27949);
        _27949 = NOVALUE;
        goto L22; // [1154] 1174
L29: 

        /** inline.e:837							check_pc += 2*/
        _check_pc_55061 = _check_pc_55061 + 2;
        goto L22; // [1164] 1174
L23: 

        /** inline.e:841						check_pc += 2*/
        _check_pc_55061 = _check_pc_55061 + 2;
L22: 

        /** inline.e:843					continue*/
        goto L1A; // [1180] 847

        /** inline.e:844				case STARTLINE then*/
        case 58:

        /** inline.e:845					check_pc += 2*/
        _check_pc_55061 = _check_pc_55061 + 2;

        /** inline.e:846					continue*/
        goto L1A; // [1198] 847

        /** inline.e:848				case else*/
        default:

        /** inline.e:849					exit*/
        goto L1B; // [1208] 1218
    ;}
    /** inline.e:851		end while*/
    goto L1A; // [1215] 847
L1B: 

    /** inline.e:853		for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27953 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27953 = 1;
    }
    {
        object _pc_55152;
        _pc_55152 = 1;
L2A: 
        if (_pc_55152 > _27953){
            goto L2B; // [1225] 1422
        }

        /** inline.e:854			if sequence( inline_code[pc] ) then*/
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27954 = (object)*(((s1_ptr)_2)->base + _pc_55152);
        _27955 = IS_SEQUENCE(_27954);
        _27954 = NOVALUE;
        if (_27955 == 0)
        {
            _27955 = NOVALUE;
            goto L2C; // [1243] 1413
        }
        else{
            _27955 = NOVALUE;
        }

        /** inline.e:855				integer inline_type = inline_code[pc][1]*/
        _2 = (object)SEQ_PTR(_66inline_code_53930);
        _27956 = (object)*(((s1_ptr)_2)->base + _pc_55152);
        _2 = (object)SEQ_PTR(_27956);
        _inline_type_55157 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_55157)){
            _inline_type_55157 = (object)DBL_PTR(_inline_type_55157)->dbl;
        }
        _27956 = NOVALUE;

        /** inline.e:856				switch inline_type do*/
        _0 = _inline_type_55157;
        switch ( _0 ){ 

            /** inline.e:857					case INLINE_SUB then*/
            case 5:

            /** inline.e:858						inline_code[pc] = CurrentSub*/
            _2 = (object)SEQ_PTR(_66inline_code_53930);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53930 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55152);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27CurrentSub_20579;
            DeRef(_1);
            goto L2D; // [1281] 1412

            /** inline.e:860					case INLINE_VAR then*/
            case 6:

            /** inline.e:861						replace_var( pc )*/
            _66replace_var(_pc_55152);

            /** inline.e:862						break*/
            goto L2D; // [1294] 1412
            goto L2D; // [1296] 1412

            /** inline.e:863					case INLINE_TEMP then*/
            case 2:

            /** inline.e:864						replace_temp( pc )*/
            _66replace_temp(_pc_55152);
            goto L2D; // [1307] 1412

            /** inline.e:866					case INLINE_PARAM then*/
            case 1:

            /** inline.e:867						replace_param( pc )*/

            /** inline.e:586		inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1343_55168;
            _replace_param_1__tmp_at1343_55168 = _66get_param_sym(_pc_55152);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1343_55168);
            _2 = (object)SEQ_PTR(_66inline_code_53930);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53930 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55152);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _replace_param_1__tmp_at1343_55168;
            DeRef(_1);

            /** inline.e:587	end procedure*/
            goto L2E; // [1329] 1332
L2E: 
            DeRef(_replace_param_1__tmp_at1343_55168);
            _replace_param_1__tmp_at1343_55168 = NOVALUE;
            goto L2D; // [1334] 1412

            /** inline.e:869					case INLINE_ADDR then*/
            case 4:

            /** inline.e:870						inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (object)SEQ_PTR(_66inline_code_53930);
            _27960 = (object)*(((s1_ptr)_2)->base + _pc_55152);
            _2 = (object)SEQ_PTR(_27960);
            _27961 = (object)*(((s1_ptr)_2)->base + 2);
            _27960 = NOVALUE;
            if (IS_ATOM_INT(_27961)) {
                _27962 = _66inline_start_53942 + _27961;
                if ((object)((uintptr_t)_27962 + (uintptr_t)HIGH_BITS) >= 0){
                    _27962 = NewDouble((eudouble)_27962);
                }
            }
            else {
                _27962 = binary_op(PLUS, _66inline_start_53942, _27961);
            }
            _27961 = NOVALUE;
            _2 = (object)SEQ_PTR(_66inline_code_53930);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53930 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55152);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27962;
            if( _1 != _27962 ){
                DeRef(_1);
            }
            _27962 = NOVALUE;
            goto L2D; // [1364] 1412

            /** inline.e:872					case INLINE_TARGET then*/
            case 3:

            /** inline.e:873						inline_code[pc] = inline_target*/
            _2 = (object)SEQ_PTR(_66inline_code_53930);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _66inline_code_53930 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55152);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _66inline_target_53937;
            DeRef(_1);

            /** inline.e:874						add_inline_target( pc + inline_start )*/
            _27963 = _pc_55152 + _66inline_start_53942;
            if ((object)((uintptr_t)_27963 + (uintptr_t)HIGH_BITS) >= 0){
                _27963 = NewDouble((eudouble)_27963);
            }
            _45add_inline_target(_27963);
            _27963 = NOVALUE;

            /** inline.e:875						break*/
            goto L2D; // [1393] 1412
            goto L2D; // [1395] 1412

            /** inline.e:877					case else*/
            default:

            /** inline.e:878						InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _inline_type_55157;
            _27964 = MAKE_SEQ(_1);
            _49InternalErr(265, _27964);
            _27964 = NOVALUE;
        ;}L2D: 
L2C: 

        /** inline.e:881		end for*/
        _pc_55152 = _pc_55152 + 1;
        goto L2A; // [1417] 1232
L2B: 
        ;
    }

    /** inline.e:883		for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_54900)){
            _27965 = SEQ_PTR(_backpatches_54900)->length;
    }
    else {
        _27965 = 1;
    }
    {
        object _i_55180;
        _i_55180 = 1;
L2F: 
        if (_i_55180 > _27965){
            goto L30; // [1427] 1450
        }

        /** inline.e:884			fixup_special_op( backpatches[i] )*/
        _2 = (object)SEQ_PTR(_backpatches_54900);
        _27966 = (object)*(((s1_ptr)_2)->base + _i_55180);
        Ref(_27966);
        _66fixup_special_op(_27966);
        _27966 = NOVALUE;

        /** inline.e:885		end for*/
        _i_55180 = _i_55180 + 1;
        goto L2F; // [1445] 1434
L30: 
        ;
    }

    /** inline.e:887		epilog &= End_inline_block( EXIT_BLOCK )*/
    _27967 = _64End_inline_block(206);
    if (IS_SEQUENCE(_epilog_54907) && IS_ATOM(_27967)) {
        Ref(_27967);
        Append(&_epilog_54907, _epilog_54907, _27967);
    }
    else if (IS_ATOM(_epilog_54907) && IS_SEQUENCE(_27967)) {
    }
    else {
        Concat((object_ptr)&_epilog_54907, _epilog_54907, _27967);
    }
    DeRef(_27967);
    _27967 = NOVALUE;

    /** inline.e:889		if is_proc then*/
    if (_is_proc_54882 == 0)
    {
        goto L31; // [1464] 1474
    }
    else{
    }

    /** inline.e:890			clear_op()*/
    _45clear_op();
    goto L32; // [1471] 1597
L31: 

    /** inline.e:892			if not deferred then*/
    if (_deferred_54881 != 0)
    goto L33; // [1476] 1491

    /** inline.e:893				Push( inline_target )*/
    _45Push(_66inline_target_53937);

    /** inline.e:894				inlined_function()*/
    _45inlined_function();
L33: 

    /** inline.e:897			if final_target then*/
    if (_final_target_55006 == 0)
    {
        goto L34; // [1493] 1523
    }
    else{
    }

    /** inline.e:898				epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    ((intptr_t*)_2)[2] = _66inline_target_53937;
    ((intptr_t*)_2)[3] = _final_target_55006;
    _27970 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54907, _epilog_54907, _27970);
    DeRefDS(_27970);
    _27970 = NOVALUE;

    /** inline.e:899				emit_temp( final_target, NEW_REFERENCE )*/
    _45emit_temp(_final_target_55006, 1);
    goto L35; // [1520] 1596
L34: 

    /** inline.e:905				emit_temp( inline_target, NEW_REFERENCE )*/
    _45emit_temp(_66inline_target_53937, 1);

    /** inline.e:906				if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L36; // [1537] 1595

    /** inline.e:907					epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 23;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 30;
    ((intptr_t*)_2)[4] = _66inline_target_53937;
    _27973 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54907, _epilog_54907, _27973);
    DeRefDS(_27973);
    _27973 = NOVALUE;

    /** inline.e:908					epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_54907)){
            _27975 = SEQ_PTR(_epilog_54907)->length;
    }
    else {
        _27975 = 1;
    }
    _27976 = _27975 - 2;
    _27975 = NOVALUE;
    if (IS_SEQUENCE(_66inline_code_53930)){
            _27977 = SEQ_PTR(_66inline_code_53930)->length;
    }
    else {
        _27977 = 1;
    }
    if (IS_SEQUENCE(_epilog_54907)){
            _27978 = SEQ_PTR(_epilog_54907)->length;
    }
    else {
        _27978 = 1;
    }
    _27979 = _27977 + _27978;
    if ((object)((uintptr_t)_27979 + (uintptr_t)HIGH_BITS) >= 0){
        _27979 = NewDouble((eudouble)_27979);
    }
    _27977 = NOVALUE;
    _27978 = NOVALUE;
    if (IS_ATOM_INT(_27979)) {
        _27980 = _27979 + _66inline_start_53942;
        if ((object)((uintptr_t)_27980 + (uintptr_t)HIGH_BITS) >= 0){
            _27980 = NewDouble((eudouble)_27980);
        }
    }
    else {
        _27980 = NewDouble(DBL_PTR(_27979)->dbl + (eudouble)_66inline_start_53942);
    }
    DeRef(_27979);
    _27979 = NOVALUE;
    if (IS_ATOM_INT(_27980)) {
        _27981 = _27980 + 1;
        if (_27981 > MAXINT){
            _27981 = NewDouble((eudouble)_27981);
        }
    }
    else
    _27981 = binary_op(PLUS, 1, _27980);
    DeRef(_27980);
    _27980 = NOVALUE;
    _2 = (object)SEQ_PTR(_epilog_54907);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _epilog_54907 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27976);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27981;
    if( _1 != _27981 ){
        DeRef(_1);
    }
    _27981 = NOVALUE;
L36: 
L35: 
L32: 

    /** inline.e:914		return prolog & inline_code & epilog*/
    {
        object concat_list[3];

        concat_list[0] = _epilog_54907;
        concat_list[1] = _66inline_code_53930;
        concat_list[2] = _prolog_54906;
        Concat_N((object_ptr)&_27982, concat_list, 3);
    }
    DeRef(_backpatches_54900);
    DeRefDSi(_prolog_54906);
    DeRefDS(_epilog_54907);
    _27853 = NOVALUE;
    DeRef(_27890);
    _27890 = NOVALUE;
    DeRef(_27941);
    _27941 = NOVALUE;
    DeRef(_27931);
    _27931 = NOVALUE;
    _27870 = NOVALUE;
    DeRef(_27858);
    _27858 = NOVALUE;
    _27866 = NOVALUE;
    DeRef(_27937);
    _27937 = NOVALUE;
    DeRef(_27861);
    _27861 = NOVALUE;
    DeRef(_27976);
    _27976 = NOVALUE;
    DeRef(_27943);
    _27943 = NOVALUE;
    DeRef(_27935);
    _27935 = NOVALUE;
    DeRef(_27887);
    _27887 = NOVALUE;
    return _27982;
    ;
}


void _66defer_call()
{
    object _defer_55220 = NOVALUE;
    object _27985 = NOVALUE;
    object _27984 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:918		integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_55220 = find_from(_66inline_sub_53944, _66deferred_inline_decisions_53946, 1);

    /** inline.e:919		if defer then*/
    if (_defer_55220 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** inline.e:921			deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_66deferred_inline_calls_53947);
    _27984 = (object)*(((s1_ptr)_2)->base + _defer_55220);
    if (IS_SEQUENCE(_27984) && IS_ATOM(_27CurrentSub_20579)) {
        Append(&_27985, _27984, _27CurrentSub_20579);
    }
    else if (IS_ATOM(_27984) && IS_SEQUENCE(_27CurrentSub_20579)) {
    }
    else {
        Concat((object_ptr)&_27985, _27984, _27CurrentSub_20579);
        _27984 = NOVALUE;
    }
    _27984 = NOVALUE;
    _2 = (object)SEQ_PTR(_66deferred_inline_calls_53947);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66deferred_inline_calls_53947 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _defer_55220);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27985;
    if( _1 != _27985 ){
        DeRef(_1);
    }
    _27985 = NOVALUE;
L1: 

    /** inline.e:923	end procedure*/
    return;
    ;
}


void _66emit_or_inline()
{
    object _sub_55229 = NOVALUE;
    object _code_55260 = NOVALUE;
    object _27997 = NOVALUE;
    object _27996 = NOVALUE;
    object _27994 = NOVALUE;
    object _27993 = NOVALUE;
    object _27992 = NOVALUE;
    object _27990 = NOVALUE;
    object _27989 = NOVALUE;
    object _27988 = NOVALUE;
    object _27987 = NOVALUE;
    object _27986 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:928		symtab_index sub = op_info1*/
    _sub_55229 = _45op_info1_51413;

    /** inline.e:929		inline_sub = sub*/
    _66inline_sub_53944 = _sub_55229;

    /** inline.e:931		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27986 = (object)*(((s1_ptr)_2)->base + _sub_55229);
    _2 = (object)SEQ_PTR(_27986);
    _27987 = (object)*(((s1_ptr)_2)->base + 30);
    _27986 = NOVALUE;
    if (_27987 == 0) {
        _27987 = NOVALUE;
        goto L1; // [31] 60
    }
    else {
        if (!IS_ATOM_INT(_27987) && DBL_PTR(_27987)->dbl == 0.0){
            _27987 = NOVALUE;
            goto L1; // [31] 60
        }
        _27987 = NOVALUE;
    }
    _27987 = NOVALUE;

    /** inline.e:932			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27988 = (object)*(((s1_ptr)_2)->base + _sub_55229);
    _2 = (object)SEQ_PTR(_27988);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _27989 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _27989 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _27988 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27989);
    ((intptr_t*)_2)[1] = _27989;
    _27990 = MAKE_SEQ(_1);
    _27989 = NOVALUE;
    _49Warning(327, 16384, _27990);
    _27990 = NOVALUE;
L1: 

    /** inline.e:935		if Parser_mode != PAM_NORMAL then*/
    if (_27Parser_mode_20677 == 0)
    goto L2; // [66] 85

    /** inline.e:938			emit_op( PROC )*/
    _45emit_op(27);

    /** inline.e:939			return*/
    DeRef(_code_55260);
    return;
    goto L3; // [82] 133
L2: 

    /** inline.e:941		elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27992 = (object)*(((s1_ptr)_2)->base + _sub_55229);
    _2 = (object)SEQ_PTR(_27992);
    _27993 = (object)*(((s1_ptr)_2)->base + 29);
    _27992 = NOVALUE;
    _27994 = IS_ATOM(_27993);
    _27993 = NOVALUE;
    if (_27994 != 0) {
        goto L4; // [102] 115
    }
    _27996 = _45has_forward_params(_sub_55229);
    if (_27996 == 0) {
        DeRef(_27996);
        _27996 = NOVALUE;
        goto L5; // [111] 132
    }
    else {
        if (!IS_ATOM_INT(_27996) && DBL_PTR(_27996)->dbl == 0.0){
            DeRef(_27996);
            _27996 = NOVALUE;
            goto L5; // [111] 132
        }
        DeRef(_27996);
        _27996 = NOVALUE;
    }
    DeRef(_27996);
    _27996 = NOVALUE;
L4: 

    /** inline.e:942			defer_call()*/
    _66defer_call();

    /** inline.e:943			emit_op( PROC )*/
    _45emit_op(27);

    /** inline.e:944			return*/
    DeRef(_code_55260);
    return;
L5: 
L3: 

    /** inline.e:947		sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_27Code_20660)){
            _27997 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _27997 = 1;
    }
    _0 = _code_55260;
    _code_55260 = _66get_inlined_code(_sub_55229, _27997, 0);
    DeRef(_0);
    _27997 = NOVALUE;

    /** inline.e:948		emit_inline( code )*/
    RefDS(_code_55260);
    _45emit_inline(_code_55260);

    /** inline.e:949		clear_last()*/
    _45clear_last();

    /** inline.e:951	end procedure*/
    DeRefDS(_code_55260);
    return;
    ;
}


void _66inline_deferred_calls()
{
    object _sub_55274 = NOVALUE;
    object _ix_55286 = NOVALUE;
    object _calling_sub_55288 = NOVALUE;
    object _code_55310 = NOVALUE;
    object _calls_55311 = NOVALUE;
    object _is_func_55315 = NOVALUE;
    object _offset_55322 = NOVALUE;
    object _op_55333 = NOVALUE;
    object _size_55336 = NOVALUE;
    object _28059 = NOVALUE;
    object _28057 = NOVALUE;
    object _28055 = NOVALUE;
    object _28054 = NOVALUE;
    object _28053 = NOVALUE;
    object _28051 = NOVALUE;
    object _28050 = NOVALUE;
    object _28049 = NOVALUE;
    object _28048 = NOVALUE;
    object _28047 = NOVALUE;
    object _28046 = NOVALUE;
    object _28045 = NOVALUE;
    object _28044 = NOVALUE;
    object _28043 = NOVALUE;
    object _28042 = NOVALUE;
    object _28040 = NOVALUE;
    object _28039 = NOVALUE;
    object _28038 = NOVALUE;
    object _28037 = NOVALUE;
    object _28035 = NOVALUE;
    object _28034 = NOVALUE;
    object _28033 = NOVALUE;
    object _28031 = NOVALUE;
    object _28029 = NOVALUE;
    object _28027 = NOVALUE;
    object _28025 = NOVALUE;
    object _28024 = NOVALUE;
    object _28023 = NOVALUE;
    object _28022 = NOVALUE;
    object _28020 = NOVALUE;
    object _28019 = NOVALUE;
    object _28016 = NOVALUE;
    object _28014 = NOVALUE;
    object _28012 = NOVALUE;
    object _28010 = NOVALUE;
    object _28008 = NOVALUE;
    object _28007 = NOVALUE;
    object _28006 = NOVALUE;
    object _28005 = NOVALUE;
    object _28004 = NOVALUE;
    object _28003 = NOVALUE;
    object _28001 = NOVALUE;
    object _28000 = NOVALUE;
    object _27999 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:957		deferred_inlining = 1*/
    _66deferred_inlining_53940 = 1;

    /** inline.e:958		for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_66deferred_inline_decisions_53946)){
            _27999 = SEQ_PTR(_66deferred_inline_decisions_53946)->length;
    }
    else {
        _27999 = 1;
    }
    {
        object _i_55269;
        _i_55269 = 1;
L1: 
        if (_i_55269 > _27999){
            goto L2; // [13] 506
        }

        /** inline.e:960			if length( deferred_inline_calls[i] ) then*/
        _2 = (object)SEQ_PTR(_66deferred_inline_calls_53947);
        _28000 = (object)*(((s1_ptr)_2)->base + _i_55269);
        if (IS_SEQUENCE(_28000)){
                _28001 = SEQ_PTR(_28000)->length;
        }
        else {
            _28001 = 1;
        }
        _28000 = NOVALUE;
        if (_28001 == 0)
        {
            _28001 = NOVALUE;
            goto L3; // [31] 497
        }
        else{
            _28001 = NOVALUE;
        }

        /** inline.e:962				integer sub = deferred_inline_decisions[i]*/
        _2 = (object)SEQ_PTR(_66deferred_inline_decisions_53946);
        _sub_55274 = (object)*(((s1_ptr)_2)->base + _i_55269);

        /** inline.e:963				check_inline( sub )*/
        _66check_inline(_sub_55274);

        /** inline.e:964				if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28003 = (object)*(((s1_ptr)_2)->base + _sub_55274);
        _2 = (object)SEQ_PTR(_28003);
        _28004 = (object)*(((s1_ptr)_2)->base + 29);
        _28003 = NOVALUE;
        _28005 = IS_ATOM(_28004);
        _28004 = NOVALUE;
        if (_28005 == 0)
        {
            _28005 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _28005 = NOVALUE;
        }

        /** inline.e:965					continue*/
        goto L5; // [71] 501
L4: 

        /** inline.e:967				for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (object)SEQ_PTR(_66deferred_inline_calls_53947);
        _28006 = (object)*(((s1_ptr)_2)->base + _i_55269);
        if (IS_SEQUENCE(_28006)){
                _28007 = SEQ_PTR(_28006)->length;
        }
        else {
            _28007 = 1;
        }
        _28006 = NOVALUE;
        {
            object _cx_55283;
            _cx_55283 = 1;
L6: 
            if (_cx_55283 > _28007){
                goto L7; // [85] 496
            }

            /** inline.e:968					integer ix = 1*/
            _ix_55286 = 1;

            /** inline.e:969					symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (object)SEQ_PTR(_66deferred_inline_calls_53947);
            _28008 = (object)*(((s1_ptr)_2)->base + _i_55269);
            _2 = (object)SEQ_PTR(_28008);
            _calling_sub_55288 = (object)*(((s1_ptr)_2)->base + _cx_55283);
            if (!IS_ATOM_INT(_calling_sub_55288)){
                _calling_sub_55288 = (object)DBL_PTR(_calling_sub_55288)->dbl;
            }
            _28008 = NOVALUE;

            /** inline.e:970					CurrentSub = calling_sub*/
            _27CurrentSub_20579 = _calling_sub_55288;

            /** inline.e:971					Code = SymTab[calling_sub][S_CODE]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _28010 = (object)*(((s1_ptr)_2)->base + _calling_sub_55288);
            DeRef(_27Code_20660);
            _2 = (object)SEQ_PTR(_28010);
            if (!IS_ATOM_INT(_27S_CODE_20221)){
                _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
            }
            else{
                _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
            }
            Ref(_27Code_20660);
            _28010 = NOVALUE;

            /** inline.e:972					LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _28012 = (object)*(((s1_ptr)_2)->base + _calling_sub_55288);
            DeRef(_27LineTable_20661);
            _2 = (object)SEQ_PTR(_28012);
            if (!IS_ATOM_INT(_27S_LINETAB_20244)){
                _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
            }
            else{
                _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
            }
            Ref(_27LineTable_20661);
            _28012 = NOVALUE;

            /** inline.e:973					SymTab[calling_sub][S_CODE] = 0*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55288 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_27S_CODE_20221))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _28014 = NOVALUE;

            /** inline.e:974					SymTab[calling_sub][S_LINETAB] = 0*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55288 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_27S_LINETAB_20244))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0;
            DeRef(_1);
            _28016 = NOVALUE;

            /** inline.e:975					sequence code = {}*/
            RefDS(_22209);
            DeRef(_code_55310);
            _code_55310 = _22209;

            /** inline.e:977					sequence calls = find_ops( 1, PROC )*/
            RefDS(_27Code_20660);
            _0 = _calls_55311;
            _calls_55311 = _65find_ops(1, 27, _27Code_20660);
            DeRef(_0);

            /** inline.e:978					integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _28019 = (object)*(((s1_ptr)_2)->base + _sub_55274);
            _2 = (object)SEQ_PTR(_28019);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _28020 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _28020 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            _28019 = NOVALUE;
            if (IS_ATOM_INT(_28020)) {
                _is_func_55315 = (_28020 != 27);
            }
            else {
                _is_func_55315 = binary_op(NOTEQ, _28020, 27);
            }
            _28020 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_55315)) {
                _1 = (object)(DBL_PTR(_is_func_55315)->dbl);
                DeRefDS(_is_func_55315);
                _is_func_55315 = _1;
            }

            /** inline.e:979					integer offset = 0*/
            _offset_55322 = 0;

            /** inline.e:980					for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_55311)){
                    _28022 = SEQ_PTR(_calls_55311)->length;
            }
            else {
                _28022 = 1;
            }
            {
                object _o_55324;
                _o_55324 = 1;
L8: 
                if (_o_55324 > _28022){
                    goto L9; // [233] 453
                }

                /** inline.e:981						if calls[o][2][2] = sub then*/
                _2 = (object)SEQ_PTR(_calls_55311);
                _28023 = (object)*(((s1_ptr)_2)->base + _o_55324);
                _2 = (object)SEQ_PTR(_28023);
                _28024 = (object)*(((s1_ptr)_2)->base + 2);
                _28023 = NOVALUE;
                _2 = (object)SEQ_PTR(_28024);
                _28025 = (object)*(((s1_ptr)_2)->base + 2);
                _28024 = NOVALUE;
                if (binary_op_a(NOTEQ, _28025, _sub_55274)){
                    _28025 = NOVALUE;
                    goto LA; // [254] 444
                }
                _28025 = NOVALUE;

                /** inline.e:982							ix = calls[o][1]*/
                _2 = (object)SEQ_PTR(_calls_55311);
                _28027 = (object)*(((s1_ptr)_2)->base + _o_55324);
                _2 = (object)SEQ_PTR(_28027);
                _ix_55286 = (object)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_55286)){
                    _ix_55286 = (object)DBL_PTR(_ix_55286)->dbl;
                }
                _28027 = NOVALUE;

                /** inline.e:983							sequence op = calls[o][2]*/
                _2 = (object)SEQ_PTR(_calls_55311);
                _28029 = (object)*(((s1_ptr)_2)->base + _o_55324);
                DeRef(_op_55333);
                _2 = (object)SEQ_PTR(_28029);
                _op_55333 = (object)*(((s1_ptr)_2)->base + 2);
                Ref(_op_55333);
                _28029 = NOVALUE;

                /** inline.e:984							integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_55333)){
                        _28031 = SEQ_PTR(_op_55333)->length;
                }
                else {
                    _28031 = 1;
                }
                _size_55336 = _28031 - 1;
                _28031 = NOVALUE;

                /** inline.e:985							if is_func then*/
                if (_is_func_55315 == 0)
                {
                    goto LB; // [293] 319
                }
                else{
                }

                /** inline.e:987								Push( op[$] )*/
                if (IS_SEQUENCE(_op_55333)){
                        _28033 = SEQ_PTR(_op_55333)->length;
                }
                else {
                    _28033 = 1;
                }
                _2 = (object)SEQ_PTR(_op_55333);
                _28034 = (object)*(((s1_ptr)_2)->base + _28033);
                Ref(_28034);
                _45Push(_28034);
                _28034 = NOVALUE;

                /** inline.e:988								op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_55333)){
                        _28035 = SEQ_PTR(_op_55333)->length;
                }
                else {
                    _28035 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_55333);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_28035)) ? _28035 : (object)(DBL_PTR(_28035)->dbl);
                    int stop = (IS_ATOM_INT(_28035)) ? _28035 : (object)(DBL_PTR(_28035)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<1) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_55333), start, &_op_55333 );
                        }
                        else Tail(SEQ_PTR(_op_55333), stop+1, &_op_55333);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_55333), start, &_op_55333);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_55333 = Remove_elements(start, stop, (SEQ_PTR(_op_55333)->ref == 1));
                    }
                }
                _28035 = NOVALUE;
                _28035 = NOVALUE;
LB: 

                /** inline.e:992							for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_55333)){
                        _28037 = SEQ_PTR(_op_55333)->length;
                }
                else {
                    _28037 = 1;
                }
                {
                    object _p_55346;
                    _p_55346 = 3;
LC: 
                    if (_p_55346 > _28037){
                        goto LD; // [324] 347
                    }

                    /** inline.e:993								Push( op[p] )*/
                    _2 = (object)SEQ_PTR(_op_55333);
                    _28038 = (object)*(((s1_ptr)_2)->base + _p_55346);
                    Ref(_28038);
                    _45Push(_28038);
                    _28038 = NOVALUE;

                    /** inline.e:994							end for*/
                    _p_55346 = _p_55346 + 1;
                    goto LC; // [342] 331
LD: 
                    ;
                }

                /** inline.e:995							code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _28039 = _ix_55286 + _offset_55322;
                if ((object)((uintptr_t)_28039 + (uintptr_t)HIGH_BITS) >= 0){
                    _28039 = NewDouble((eudouble)_28039);
                }
                if (IS_ATOM_INT(_28039)) {
                    _28040 = _28039 - 1;
                    if ((object)((uintptr_t)_28040 +(uintptr_t) HIGH_BITS) >= 0){
                        _28040 = NewDouble((eudouble)_28040);
                    }
                }
                else {
                    _28040 = NewDouble(DBL_PTR(_28039)->dbl - (eudouble)1);
                }
                DeRef(_28039);
                _28039 = NOVALUE;
                _0 = _code_55310;
                _code_55310 = _66get_inlined_code(_sub_55274, _28040, 1);
                DeRef(_0);
                _28040 = NOVALUE;

                /** inline.e:996							shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_55310)){
                        _28042 = SEQ_PTR(_code_55310)->length;
                }
                else {
                    _28042 = 1;
                }
                _28043 = Repeat(159, _28042);
                _28042 = NOVALUE;
                _28044 = _ix_55286 + _offset_55322;
                if ((object)((uintptr_t)_28044 + (uintptr_t)HIGH_BITS) >= 0){
                    _28044 = NewDouble((eudouble)_28044);
                }
                _28045 = _ix_55286 + _offset_55322;
                if ((object)((uintptr_t)_28045 + (uintptr_t)HIGH_BITS) >= 0){
                    _28045 = NewDouble((eudouble)_28045);
                }
                if (IS_ATOM_INT(_28045)) {
                    _28046 = _28045 + _size_55336;
                    if ((object)((uintptr_t)_28046 + (uintptr_t)HIGH_BITS) >= 0){
                        _28046 = NewDouble((eudouble)_28046);
                    }
                }
                else {
                    _28046 = NewDouble(DBL_PTR(_28045)->dbl + (eudouble)_size_55336);
                }
                DeRef(_28045);
                _28045 = NOVALUE;
                _65replace_code(_28043, _28044, _28046);
                _28043 = NOVALUE;
                _28044 = NOVALUE;
                _28046 = NOVALUE;

                /** inline.e:999							Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _28047 = _ix_55286 + _offset_55322;
                if ((object)((uintptr_t)_28047 + (uintptr_t)HIGH_BITS) >= 0){
                    _28047 = NewDouble((eudouble)_28047);
                }
                _28048 = _ix_55286 + _offset_55322;
                if ((object)((uintptr_t)_28048 + (uintptr_t)HIGH_BITS) >= 0){
                    _28048 = NewDouble((eudouble)_28048);
                }
                if (IS_SEQUENCE(_code_55310)){
                        _28049 = SEQ_PTR(_code_55310)->length;
                }
                else {
                    _28049 = 1;
                }
                if (IS_ATOM_INT(_28048)) {
                    _28050 = _28048 + _28049;
                    if ((object)((uintptr_t)_28050 + (uintptr_t)HIGH_BITS) >= 0){
                        _28050 = NewDouble((eudouble)_28050);
                    }
                }
                else {
                    _28050 = NewDouble(DBL_PTR(_28048)->dbl + (eudouble)_28049);
                }
                DeRef(_28048);
                _28048 = NOVALUE;
                _28049 = NOVALUE;
                if (IS_ATOM_INT(_28050)) {
                    _28051 = _28050 - 1;
                    if ((object)((uintptr_t)_28051 +(uintptr_t) HIGH_BITS) >= 0){
                        _28051 = NewDouble((eudouble)_28051);
                    }
                }
                else {
                    _28051 = NewDouble(DBL_PTR(_28050)->dbl - (eudouble)1);
                }
                DeRef(_28050);
                _28050 = NOVALUE;
                {
                    intptr_t p1 = _27Code_20660;
                    intptr_t p2 = _code_55310;
                    intptr_t p3 = _28047;
                    intptr_t p4 = _28051;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_27Code_20660;
                    Replace( &replace_params );
                }
                DeRef(_28047);
                _28047 = NOVALUE;
                DeRef(_28051);
                _28051 = NOVALUE;

                /** inline.e:1000							offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_55310)){
                        _28053 = SEQ_PTR(_code_55310)->length;
                }
                else {
                    _28053 = 1;
                }
                _28054 = _28053 - _size_55336;
                if ((object)((uintptr_t)_28054 +(uintptr_t) HIGH_BITS) >= 0){
                    _28054 = NewDouble((eudouble)_28054);
                }
                _28053 = NOVALUE;
                if (IS_ATOM_INT(_28054)) {
                    _28055 = _28054 - 1;
                    if ((object)((uintptr_t)_28055 +(uintptr_t) HIGH_BITS) >= 0){
                        _28055 = NewDouble((eudouble)_28055);
                    }
                }
                else {
                    _28055 = NewDouble(DBL_PTR(_28054)->dbl - (eudouble)1);
                }
                DeRef(_28054);
                _28054 = NOVALUE;
                if (IS_ATOM_INT(_28055)) {
                    _offset_55322 = _offset_55322 + _28055;
                }
                else {
                    _offset_55322 = NewDouble((eudouble)_offset_55322 + DBL_PTR(_28055)->dbl);
                }
                DeRef(_28055);
                _28055 = NOVALUE;
                if (!IS_ATOM_INT(_offset_55322)) {
                    _1 = (object)(DBL_PTR(_offset_55322)->dbl);
                    DeRefDS(_offset_55322);
                    _offset_55322 = _1;
                }
LA: 
                DeRef(_op_55333);
                _op_55333 = NOVALUE;

                /** inline.e:1003					end for*/
                _o_55324 = _o_55324 + 1;
                goto L8; // [448] 240
L9: 
                ;
            }

            /** inline.e:1004					SymTab[calling_sub][S_CODE] = Code*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55288 + ((s1_ptr)_2)->base);
            RefDS(_27Code_20660);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_27S_CODE_20221))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27Code_20660;
            DeRef(_1);
            _28057 = NOVALUE;

            /** inline.e:1005					SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55288 + ((s1_ptr)_2)->base);
            RefDS(_27LineTable_20661);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_27S_LINETAB_20244))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27LineTable_20661;
            DeRef(_1);
            _28059 = NOVALUE;
            DeRef(_code_55310);
            _code_55310 = NOVALUE;
            DeRef(_calls_55311);
            _calls_55311 = NOVALUE;

            /** inline.e:1006				end for*/
            _cx_55283 = _cx_55283 + 1;
            goto L6; // [491] 92
L7: 
            ;
        }
L3: 

        /** inline.e:1008		end for*/
L5: 
        _i_55269 = _i_55269 + 1;
        goto L1; // [501] 20
L2: 
        ;
    }

    /** inline.e:1009	end procedure*/
    _28006 = NOVALUE;
    _28000 = NOVALUE;
    return;
    ;
}



// 0x337EE125
