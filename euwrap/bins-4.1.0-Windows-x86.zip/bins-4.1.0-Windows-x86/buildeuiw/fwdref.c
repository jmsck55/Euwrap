// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _42clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _42fwdref_count_63266 = 0;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _42get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _42fwdref_count_63266;
    ;
}


void _42set_glabel_block(object _ref_63273, object _block_63275)
{
    object _31120 = NOVALUE;
    object _31119 = NOVALUE;
    object _31117 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63273)) {
        _1 = (object)(DBL_PTR(_ref_63273)->dbl);
        DeRefDS(_ref_63273);
        _ref_63273 = _1;
    }
    if (!IS_ATOM_INT(_block_63275)) {
        _1 = (object)(DBL_PTR(_block_63275)->dbl);
        DeRefDS(_block_63275);
        _block_63275 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63273 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31119 = (object)*(((s1_ptr)_2)->base + 12);
    _31117 = NOVALUE;
    if (IS_SEQUENCE(_31119) && IS_ATOM(_block_63275)) {
        Append(&_31120, _31119, _block_63275);
    }
    else if (IS_ATOM(_31119) && IS_SEQUENCE(_block_63275)) {
    }
    else {
        Concat((object_ptr)&_31120, _31119, _block_63275);
        _31119 = NOVALUE;
    }
    _31119 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31120;
    if( _1 != _31120 ){
        DeRef(_1);
    }
    _31120 = NOVALUE;
    _31117 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _42replace_code(object _code_63287, object _start_63288, object _finish_63289, object _subprog_63290)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_63289)) {
        _1 = (object)(DBL_PTR(_finish_63289)->dbl);
        DeRefDS(_finish_63289);
        _finish_63289 = _1;
    }
    if (!IS_ATOM_INT(_subprog_63290)) {
        _1 = (object)(DBL_PTR(_subprog_63290)->dbl);
        DeRefDS(_subprog_63290);
        _subprog_63290 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_63290;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_63287);
    _65replace_code(_code_63287, _start_63288, _finish_63289);

    /** fwdref.e:90		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_63287);
    return;
    ;
}


void _42resolved_reference(object _ref_63293)
{
    object _file_63294 = NOVALUE;
    object _subprog_63297 = NOVALUE;
    object _tx_63300 = NOVALUE;
    object _ax_63301 = NOVALUE;
    object _sp_63302 = NOVALUE;
    object _r_63317 = NOVALUE;
    object _r_63335 = NOVALUE;
    object _31144 = NOVALUE;
    object _31143 = NOVALUE;
    object _31142 = NOVALUE;
    object _31140 = NOVALUE;
    object _31137 = NOVALUE;
    object _31135 = NOVALUE;
    object _31133 = NOVALUE;
    object _31132 = NOVALUE;
    object _31130 = NOVALUE;
    object _31128 = NOVALUE;
    object _31126 = NOVALUE;
    object _31125 = NOVALUE;
    object _31123 = NOVALUE;
    object _31121 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31121 = (object)*(((s1_ptr)_2)->base + _ref_63293);
    _2 = (object)SEQ_PTR(_31121);
    _file_63294 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_63294)){
        _file_63294 = (object)DBL_PTR(_file_63294)->dbl;
    }
    _31121 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31123 = (object)*(((s1_ptr)_2)->base + _ref_63293);
    _2 = (object)SEQ_PTR(_31123);
    _subprog_63297 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_63297)){
        _subprog_63297 = (object)DBL_PTR(_subprog_63297)->dbl;
    }
    _31123 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_63300 = 0;

    /** fwdref.e:100			ax = 0,*/
    _ax_63301 = 0;

    /** fwdref.e:101			sp = 0*/
    _sp_63302 = 0;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31125 = (object)*(((s1_ptr)_2)->base + _ref_63293);
    _2 = (object)SEQ_PTR(_31125);
    _31126 = (object)*(((s1_ptr)_2)->base + 4);
    _31125 = NOVALUE;
    if (binary_op_a(NOTEQ, _31126, _27TopLevelSub_20578)){
        _31126 = NOVALUE;
        goto L1; // [60] 80
    }
    _31126 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    _31128 = (object)*(((s1_ptr)_2)->base + _file_63294);
    _tx_63300 = find_from(_ref_63293, _31128, 1);
    _31128 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31130 = (object)*(((s1_ptr)_2)->base + _file_63294);
    _sp_63302 = find_from(_subprog_63297, _31130, 1);
    _31130 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _31132 = (object)*(((s1_ptr)_2)->base + _file_63294);
    _2 = (object)SEQ_PTR(_31132);
    _31133 = (object)*(((s1_ptr)_2)->base + _sp_63302);
    _31132 = NOVALUE;
    _ax_63301 = find_from(_ref_63293, _31133, 1);
    _31133 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_63301 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _31135 = (object)*(((s1_ptr)_2)->base + _file_63294);
    DeRef(_r_63317);
    _2 = (object)SEQ_PTR(_31135);
    _r_63317 = (object)*(((s1_ptr)_2)->base + _sp_63302);
    Ref(_r_63317);
    _31135 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63248 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63294 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63302);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31137 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63317);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_63301)) ? _ax_63301 : (object)(DBL_PTR(_ax_63301)->dbl);
        int stop = (IS_ATOM_INT(_ax_63301)) ? _ax_63301 : (object)(DBL_PTR(_ax_63301)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63317), start, &_r_63317 );
            }
            else Tail(SEQ_PTR(_r_63317), stop+1, &_r_63317);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63317), start, &_r_63317);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63317 = Remove_elements(start, stop, (SEQ_PTR(_r_63317)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63248 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63294 + ((s1_ptr)_2)->base);
    RefDS(_r_63317);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63302);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63317;
    DeRef(_1);
    _31140 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _31142 = (object)*(((s1_ptr)_2)->base + _file_63294);
    _2 = (object)SEQ_PTR(_31142);
    _31143 = (object)*(((s1_ptr)_2)->base + _sp_63302);
    _31142 = NOVALUE;
    if (IS_SEQUENCE(_31143)){
            _31144 = SEQ_PTR(_31143)->length;
    }
    else {
        _31144 = 1;
    }
    _31143 = NOVALUE;
    if (_31144 != 0)
    goto L4; // [178] 248
    _31144 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_63317);
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _r_63317 = (object)*(((s1_ptr)_2)->base + _file_63294);
    Ref(_r_63317);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63248 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63294);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63317);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63302)) ? _sp_63302 : (object)(DBL_PTR(_sp_63302)->dbl);
        int stop = (IS_ATOM_INT(_sp_63302)) ? _sp_63302 : (object)(DBL_PTR(_sp_63302)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63317), start, &_r_63317 );
            }
            else Tail(SEQ_PTR(_r_63317), stop+1, &_r_63317);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63317), start, &_r_63317);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63317 = Remove_elements(start, stop, (SEQ_PTR(_r_63317)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_63317);
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63248 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63294);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63317;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_63317);
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _r_63317 = (object)*(((s1_ptr)_2)->base + _file_63294);
    Ref(_r_63317);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_63247 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63294);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63317);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63302)) ? _sp_63302 : (object)(DBL_PTR(_sp_63302)->dbl);
        int stop = (IS_ATOM_INT(_sp_63302)) ? _sp_63302 : (object)(DBL_PTR(_sp_63302)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63317), start, &_r_63317 );
            }
            else Tail(SEQ_PTR(_r_63317), stop+1, &_r_63317);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63317), start, &_r_63317);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63317 = Remove_elements(start, stop, (SEQ_PTR(_r_63317)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_63317);
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_63247 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63294);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63317;
    DeRef(_1);
L4: 
    DeRef(_r_63317);
    _r_63317 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_63300 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_63335);
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    _r_63335 = (object)*(((s1_ptr)_2)->base + _file_63294);
    Ref(_r_63335);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_63249 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63294);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63335);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_63300)) ? _tx_63300 : (object)(DBL_PTR(_tx_63300)->dbl);
        int stop = (IS_ATOM_INT(_tx_63300)) ? _tx_63300 : (object)(DBL_PTR(_tx_63300)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63335), start, &_r_63335 );
            }
            else Tail(SEQ_PTR(_r_63335), stop+1, &_r_63335);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63335), start, &_r_63335);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63335 = Remove_elements(start, stop, (SEQ_PTR(_r_63335)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_63335);
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_63249 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63294);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63335;
    DeRef(_1);
    DeRefDS(_r_63335);
    _r_63335 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_22209);
    _49InternalErr(260, _22209);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_42inactive_references_63250, _42inactive_references_63250, _ref_63293);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63293);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _31143 = NOVALUE;
    return;
    ;
}


void _42set_code(object _ref_63349)
{
    object _31169 = NOVALUE;
    object _31167 = NOVALUE;
    object _31166 = NOVALUE;
    object _31165 = NOVALUE;
    object _31164 = NOVALUE;
    object _31162 = NOVALUE;
    object _31160 = NOVALUE;
    object _31158 = NOVALUE;
    object _31156 = NOVALUE;
    object _31153 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31153 = (object)*(((s1_ptr)_2)->base + _ref_63349);
    _2 = (object)SEQ_PTR(_31153);
    _42patch_code_sub_63344 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_42patch_code_sub_63344)){
        _42patch_code_sub_63344 = (object)DBL_PTR(_42patch_code_sub_63344)->dbl;
    }
    _31153 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_42patch_code_sub_63344 == _27CurrentSub_20579)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_27Code_20660);
    DeRef(_42patch_code_temp_63341);
    _42patch_code_temp_63341 = _27Code_20660;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_27LineTable_20661);
    DeRef(_42patch_linetab_temp_63342);
    _42patch_linetab_temp_63342 = _27LineTable_20661;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31156 = (object)*(((s1_ptr)_2)->base + _42patch_code_sub_63344);
    DeRefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(_31156);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _31156 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63344 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31158 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31160 = (object)*(((s1_ptr)_2)->base + _42patch_code_sub_63344);
    DeRefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(_31160);
    if (!IS_ATOM_INT(_27S_LINETAB_20244)){
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    }
    else{
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    }
    Ref(_27LineTable_20661);
    _31160 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63344 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31162 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _42patch_current_sub_63346 = _27CurrentSub_20579;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _27CurrentSub_20579 = _42patch_code_sub_63344;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _42patch_current_sub_63346 = _42patch_code_sub_63344;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31164 = (object)*(((s1_ptr)_2)->base + _42patch_current_sub_63346);
    _2 = (object)SEQ_PTR(_31164);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _31165 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _31165 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _31164 = NOVALUE;
    _31166 = IS_SEQUENCE(_31165);
    _31165 = NOVALUE;
    if (_31166 == 0)
    {
        _31166 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _31166 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63344 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31167 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63344 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _31169 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _42reset_code()
{
    object _31174 = NOVALUE;
    object _31172 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_42patch_code_sub_63344 == _42patch_current_sub_63346)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63344 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _31172 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_42patch_code_sub_63344 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _31174 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _27CurrentSub_20579 = _42patch_current_sub_63346;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_42patch_code_temp_63341);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _42patch_code_temp_63341;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_42patch_linetab_temp_63342);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _42patch_linetab_temp_63342;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_22209);
    DeRef(_42patch_code_temp_63341);
    _42patch_code_temp_63341 = _22209;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_22209);
    DeRef(_42patch_linetab_temp_63342);
    _42patch_linetab_temp_63342 = _22209;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _42set_data(object _ref_63411, object _data_63412)
{
    object _31176 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63411 + ((s1_ptr)_2)->base);
    Ref(_data_63412);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_63412;
    DeRef(_1);
    _31176 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_63412);
    return;
    ;
}


void _42add_data(object _ref_63417, object _data_63418)
{
    object _31182 = NOVALUE;
    object _31181 = NOVALUE;
    object _31180 = NOVALUE;
    object _31178 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63417)) {
        _1 = (object)(DBL_PTR(_ref_63417)->dbl);
        DeRefDS(_ref_63417);
        _ref_63417 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63417 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31180 = (object)*(((s1_ptr)_2)->base + _ref_63417);
    _2 = (object)SEQ_PTR(_31180);
    _31181 = (object)*(((s1_ptr)_2)->base + 12);
    _31180 = NOVALUE;
    Ref(_data_63418);
    Append(&_31182, _31181, _data_63418);
    _31181 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31182;
    if( _1 != _31182 ){
        DeRef(_1);
    }
    _31182 = NOVALUE;
    _31178 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_63418);
    return;
    ;
}


void _42set_line(object _ref_63426, object _line_no_63427, object _this_line_63428, object _bp_63429)
{
    object _31187 = NOVALUE;
    object _31185 = NOVALUE;
    object _31183 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63426)) {
        _1 = (object)(DBL_PTR(_ref_63426)->dbl);
        DeRefDS(_ref_63426);
        _ref_63426 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63426 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_63427;
    DeRef(_1);
    _31183 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63426 + ((s1_ptr)_2)->base);
    RefDS(_this_line_63428);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_63428;
    DeRef(_1);
    _31185 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63426 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_63429;
    DeRef(_1);
    _31187 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_63428);
    return;
    ;
}


void _42add_private_symbol(object _sym_63441, object _name_63442)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_63441)) {
        _1 = (object)(DBL_PTR(_sym_63441)->dbl);
        DeRefDS(_sym_63441);
        _sym_63441 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_42fwd_private_sym_63436, _42fwd_private_sym_63436, _sym_63441);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_63442);
    Append(&_42fwd_private_name_63437, _42fwd_private_name_63437, _name_63442);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_63442);
    return;
    ;
}


void _42patch_forward_goto(object _tok_63450, object _ref_63451)
{
    object _fr_63452 = NOVALUE;
    object _31203 = NOVALUE;
    object _31202 = NOVALUE;
    object _31201 = NOVALUE;
    object _31200 = NOVALUE;
    object _31199 = NOVALUE;
    object _31198 = NOVALUE;
    object _31197 = NOVALUE;
    object _31196 = NOVALUE;
    object _31194 = NOVALUE;
    object _31193 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_63452);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63452 = (object)*(((s1_ptr)_2)->base + _ref_63451);
    Ref(_fr_63452);

    /** fwdref.e:218		set_code( ref )*/
    _42set_code(_ref_63451);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63452);
    _42shifting_sub_63265 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_42shifting_sub_63265))
    _42shifting_sub_63265 = (object)DBL_PTR(_42shifting_sub_63265)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_63452);
    _31193 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31193)){
            _31194 = SEQ_PTR(_31193)->length;
    }
    else {
        _31194 = 1;
    }
    _31193 = NOVALUE;
    if (_31194 != 2)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63451);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_63452);
    _31196 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_31196);
    _31197 = (object)*(((s1_ptr)_2)->base + 2);
    _31196 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31197);
    ((intptr_t*)_2)[1] = _31197;
    _31198 = MAKE_SEQ(_1);
    _31197 = NOVALUE;
    _49CompileErr(156, _31198, 0);
    _31198 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_63452);
    _31199 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_31199);
    _31200 = (object)*(((s1_ptr)_2)->base + 1);
    _31199 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63452);
    _31201 = (object)*(((s1_ptr)_2)->base + 12);
    _2 = (object)SEQ_PTR(_31201);
    _31202 = (object)*(((s1_ptr)_2)->base + 3);
    _31201 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63452);
    _31203 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_31200);
    Ref(_31202);
    Ref(_31203);
    _64Goto_block(_31200, _31202, _31203);
    _31200 = NOVALUE;
    _31202 = NOVALUE;
    _31203 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:231		reset_code()*/
    _42reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _42resolved_reference(_ref_63451);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_63452);
    _31193 = NOVALUE;
    return;
    ;
}


void _42patch_forward_call(object _tok_63474, object _ref_63475)
{
    object _fr_63476 = NOVALUE;
    object _sub_63479 = NOVALUE;
    object _defarg_63485 = NOVALUE;
    object _paramsym_63489 = NOVALUE;
    object _old_63492 = NOVALUE;
    object _tx_63496 = NOVALUE;
    object _code_sub_63506 = NOVALUE;
    object _args_63508 = NOVALUE;
    object _is_func_63513 = NOVALUE;
    object _real_file_63527 = NOVALUE;
    object _code_63531 = NOVALUE;
    object _temp_sub_63533 = NOVALUE;
    object _pc_63535 = NOVALUE;
    object _next_pc_63537 = NOVALUE;
    object _supplied_args_63538 = NOVALUE;
    object _name_63541 = NOVALUE;
    object _old_temps_allocated_63577 = NOVALUE;
    object _temp_target_63586 = NOVALUE;
    object _converted_code_63589 = NOVALUE;
    object _target_63605 = NOVALUE;
    object _has_defaults_63611 = NOVALUE;
    object _goto_target_63612 = NOVALUE;
    object _defarg_63615 = NOVALUE;
    object _code_len_63616 = NOVALUE;
    object _extra_default_args_63618 = NOVALUE;
    object _param_sym_63621 = NOVALUE;
    object _params_63622 = NOVALUE;
    object _orig_code_63624 = NOVALUE;
    object _orig_linetable_63625 = NOVALUE;
    object _ar_sp_63629 = NOVALUE;
    object _pre_refs_63633 = NOVALUE;
    object _old_fwd_params_63648 = NOVALUE;
    object _temp_shifting_sub_63689 = NOVALUE;
    object _new_code_63693 = NOVALUE;
    object _routine_type_63702 = NOVALUE;
    object _31962 = NOVALUE;
    object _31344 = NOVALUE;
    object _31343 = NOVALUE;
    object _31342 = NOVALUE;
    object _31340 = NOVALUE;
    object _31339 = NOVALUE;
    object _31338 = NOVALUE;
    object _31337 = NOVALUE;
    object _31336 = NOVALUE;
    object _31335 = NOVALUE;
    object _31334 = NOVALUE;
    object _31333 = NOVALUE;
    object _31332 = NOVALUE;
    object _31331 = NOVALUE;
    object _31330 = NOVALUE;
    object _31329 = NOVALUE;
    object _31328 = NOVALUE;
    object _31326 = NOVALUE;
    object _31325 = NOVALUE;
    object _31324 = NOVALUE;
    object _31323 = NOVALUE;
    object _31322 = NOVALUE;
    object _31321 = NOVALUE;
    object _31320 = NOVALUE;
    object _31319 = NOVALUE;
    object _31317 = NOVALUE;
    object _31314 = NOVALUE;
    object _31313 = NOVALUE;
    object _31312 = NOVALUE;
    object _31311 = NOVALUE;
    object _31307 = NOVALUE;
    object _31306 = NOVALUE;
    object _31305 = NOVALUE;
    object _31304 = NOVALUE;
    object _31303 = NOVALUE;
    object _31301 = NOVALUE;
    object _31300 = NOVALUE;
    object _31299 = NOVALUE;
    object _31298 = NOVALUE;
    object _31297 = NOVALUE;
    object _31296 = NOVALUE;
    object _31294 = NOVALUE;
    object _31293 = NOVALUE;
    object _31291 = NOVALUE;
    object _31290 = NOVALUE;
    object _31289 = NOVALUE;
    object _31288 = NOVALUE;
    object _31286 = NOVALUE;
    object _31284 = NOVALUE;
    object _31283 = NOVALUE;
    object _31282 = NOVALUE;
    object _31280 = NOVALUE;
    object _31279 = NOVALUE;
    object _31277 = NOVALUE;
    object _31275 = NOVALUE;
    object _31272 = NOVALUE;
    object _31268 = NOVALUE;
    object _31266 = NOVALUE;
    object _31265 = NOVALUE;
    object _31263 = NOVALUE;
    object _31262 = NOVALUE;
    object _31261 = NOVALUE;
    object _31260 = NOVALUE;
    object _31258 = NOVALUE;
    object _31257 = NOVALUE;
    object _31256 = NOVALUE;
    object _31255 = NOVALUE;
    object _31254 = NOVALUE;
    object _31252 = NOVALUE;
    object _31251 = NOVALUE;
    object _31250 = NOVALUE;
    object _31249 = NOVALUE;
    object _31248 = NOVALUE;
    object _31247 = NOVALUE;
    object _31246 = NOVALUE;
    object _31245 = NOVALUE;
    object _31244 = NOVALUE;
    object _31243 = NOVALUE;
    object _31242 = NOVALUE;
    object _31241 = NOVALUE;
    object _31240 = NOVALUE;
    object _31239 = NOVALUE;
    object _31237 = NOVALUE;
    object _31236 = NOVALUE;
    object _31235 = NOVALUE;
    object _31234 = NOVALUE;
    object _31233 = NOVALUE;
    object _31230 = NOVALUE;
    object _31226 = NOVALUE;
    object _31225 = NOVALUE;
    object _31224 = NOVALUE;
    object _31223 = NOVALUE;
    object _31222 = NOVALUE;
    object _31221 = NOVALUE;
    object _31219 = NOVALUE;
    object _31216 = NOVALUE;
    object _31214 = NOVALUE;
    object _31213 = NOVALUE;
    object _31211 = NOVALUE;
    object _31208 = NOVALUE;
    object _31207 = NOVALUE;
    object _31206 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_63476);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63476 = (object)*(((s1_ptr)_2)->base + _ref_63475);
    Ref(_fr_63476);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63474);
    _sub_63479 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_63479)){
        _sub_63479 = (object)DBL_PTR(_sub_63479)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _31206 = (object)*(((s1_ptr)_2)->base + 12);
    _31207 = IS_SEQUENCE(_31206);
    _31206 = NOVALUE;
    if (_31207 == 0)
    {
        _31207 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _31207 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _31208 = (object)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_63485);
    _2 = (object)SEQ_PTR(_31208);
    _defarg_63485 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_63485);
    _31208 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63485);
    _paramsym_63489 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_63489)){
        _paramsym_63489 = (object)DBL_PTR(_paramsym_63489)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63485);
    _31211 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_31211);
    DeRef(_old_63492);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _31211;
    _old_63492 = MAKE_SEQ(_1);
    _31211 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31213 = (object)*(((s1_ptr)_2)->base + _paramsym_63489);
    _2 = (object)SEQ_PTR(_31213);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _31214 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _31214 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _31213 = NOVALUE;
    _tx_63496 = find_from(_old_63492, _31214, 1);
    _31214 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63489 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _3 = (object)(_27S_CODE_20221 + ((s1_ptr)_2)->base);
    _31216 = NOVALUE;
    Ref(_tok_63474);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63496);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_63474;
    DeRef(_1);
    _31216 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _42resolved_reference(_ref_63475);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63485);
    DeRefDS(_old_63492);
    DeRef(_tok_63474);
    DeRefDS(_fr_63476);
    DeRef(_code_63531);
    DeRef(_name_63541);
    DeRef(_params_63622);
    DeRef(_orig_code_63624);
    DeRef(_orig_linetable_63625);
    DeRef(_old_fwd_params_63648);
    DeRef(_new_code_63693);
    return;
L1: 
    DeRef(_defarg_63485);
    _defarg_63485 = NOVALUE;
    DeRef(_old_63492);
    _old_63492 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _code_sub_63506 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_63506))
    _code_sub_63506 = (object)DBL_PTR(_code_sub_63506)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31219 = (object)*(((s1_ptr)_2)->base + _sub_63479);
    _2 = (object)SEQ_PTR(_31219);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _args_63508 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _args_63508 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_args_63508)){
        _args_63508 = (object)DBL_PTR(_args_63508)->dbl;
    }
    _31219 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31221 = (object)*(((s1_ptr)_2)->base + _sub_63479);
    _2 = (object)SEQ_PTR(_31221);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _31222 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _31222 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _31221 = NOVALUE;
    if (IS_ATOM_INT(_31222)) {
        _31223 = (_31222 == 501);
    }
    else {
        _31223 = binary_op(EQUALS, _31222, 501);
    }
    _31222 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31224 = (object)*(((s1_ptr)_2)->base + _sub_63479);
    _2 = (object)SEQ_PTR(_31224);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _31225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _31225 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _31224 = NOVALUE;
    if (IS_ATOM_INT(_31225)) {
        _31226 = (_31225 == 504);
    }
    else {
        _31226 = binary_op(EQUALS, _31225, 504);
    }
    _31225 = NOVALUE;
    if (IS_ATOM_INT(_31223) && IS_ATOM_INT(_31226)) {
        _is_func_63513 = (_31223 != 0 || _31226 != 0);
    }
    else {
        _is_func_63513 = binary_op(OR, _31223, _31226);
    }
    DeRef(_31223);
    _31223 = NOVALUE;
    DeRef(_31226);
    _31226 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63513)) {
        _1 = (object)(DBL_PTR(_is_func_63513)->dbl);
        DeRefDS(_is_func_63513);
        _is_func_63513 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63527 = _27current_file_no_20571;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _42set_code(_ref_63475);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_27Code_20660);
    DeRef(_code_63531);
    _code_63531 = _27Code_20660;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63533 = _27CurrentSub_20579;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _pc_63535 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63535))
    _pc_63535 = (object)DBL_PTR(_pc_63535)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63537 = _pc_63535;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _31230 = _pc_63535 + 2;
    _2 = (object)SEQ_PTR(_code_63531);
    _supplied_args_63538 = (object)*(((s1_ptr)_2)->base + _31230);
    if (!IS_ATOM_INT(_supplied_args_63538))
    _supplied_args_63538 = (object)DBL_PTR(_supplied_args_63538)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63541);
    _2 = (object)SEQ_PTR(_fr_63476);
    _name_63541 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_name_63541);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _31233 = (object)*(((s1_ptr)_2)->base + _pc_63535);
    if (IS_ATOM_INT(_31233)) {
        _31234 = (_31233 != 196);
    }
    else {
        _31234 = binary_op(NOTEQ, _31233, 196);
    }
    _31233 = NOVALUE;
    if (IS_ATOM_INT(_31234)) {
        if (_31234 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_31234)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_27Code_20660);
    _31236 = (object)*(((s1_ptr)_2)->base + _pc_63535);
    if (IS_ATOM_INT(_31236)) {
        _31237 = (_31236 != 195);
    }
    else {
        _31237 = binary_op(NOTEQ, _31236, 195);
    }
    _31236 = NOVALUE;
    if (_31237 == 0) {
        DeRef(_31237);
        _31237 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_31237) && DBL_PTR(_31237)->dbl == 0.0){
            DeRef(_31237);
            _31237 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_31237);
        _31237 = NOVALUE;
    }
    DeRef(_31237);
    _31237 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63475);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31239 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _2 = (object)SEQ_PTR(_fr_63476);
    _31240 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_31240);
    _31241 = _53sym_name(_31240);
    _31240 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63476);
    _31242 = (object)*(((s1_ptr)_2)->base + 6);
    _2 = (object)SEQ_PTR(_fr_63476);
    _31243 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31239);
    ((intptr_t*)_2)[1] = _31239;
    ((intptr_t*)_2)[2] = _31241;
    Ref(_31242);
    ((intptr_t*)_2)[3] = _31242;
    Ref(_31243);
    ((intptr_t*)_2)[4] = _31243;
    _31244 = MAKE_SEQ(_1);
    _31243 = NOVALUE;
    _31242 = NOVALUE;
    _31241 = NOVALUE;
    _31239 = NOVALUE;
    RefDS(_31238);
    _49CompileErr(_31238, _31244, 0);
    _31244 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31245 = (object)*(((s1_ptr)_2)->base + _sub_63479);
    _2 = (object)SEQ_PTR(_31245);
    _31246 = (object)*(((s1_ptr)_2)->base + 30);
    _31245 = NOVALUE;
    if (_31246 == 0) {
        _31246 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_31246) && DBL_PTR(_31246)->dbl == 0.0){
            _31246 = NOVALUE;
            goto L3; // [346] 375
        }
        _31246 = NOVALUE;
    }
    _31246 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31247 = (object)*(((s1_ptr)_2)->base + _sub_63479);
    _2 = (object)SEQ_PTR(_31247);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _31248 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _31248 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _31247 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31248);
    ((intptr_t*)_2)[1] = _31248;
    _31249 = MAKE_SEQ(_1);
    _31248 = NOVALUE;
    _49Warning(327, 16384, _31249);
    _31249 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63577 = _53temps_allocated_47715;

    /** fwdref.e:283		temps_allocated = 0*/
    _53temps_allocated_47715 = 0;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63513 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_63476);
    _31251 = (object)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31251)) {
        _31252 = (_31251 == 27);
    }
    else {
        _31252 = binary_op(EQUALS, _31251, 27);
    }
    _31251 = NOVALUE;
    if (_31252 == 0) {
        DeRef(_31252);
        _31252 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_31252) && DBL_PTR(_31252)->dbl == 0.0){
            DeRef(_31252);
            _31252 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_31252);
        _31252 = NOVALUE;
    }
    DeRef(_31252);
    _31252 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63586 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_63586)) {
        _1 = (object)(DBL_PTR(_temp_target_63586)->dbl);
        DeRefDS(_temp_target_63586);
        _temp_target_63586 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _31254 = _pc_63535 + 1;
    if (_31254 > MAXINT){
        _31254 = NewDouble((eudouble)_31254);
    }
    _31255 = _pc_63535 + 2;
    if ((object)((uintptr_t)_31255 + (uintptr_t)HIGH_BITS) >= 0){
        _31255 = NewDouble((eudouble)_31255);
    }
    if (IS_ATOM_INT(_31255)) {
        _31256 = _31255 + _supplied_args_63538;
    }
    else {
        _31256 = NewDouble(DBL_PTR(_31255)->dbl + (eudouble)_supplied_args_63538);
    }
    DeRef(_31255);
    _31255 = NOVALUE;
    rhs_slice_target = (object_ptr)&_31257;
    RHS_Slice(_27Code_20660, _31254, _31256);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208;
    ((intptr_t *)_2)[2] = _temp_target_63586;
    _31258 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _31258;
        concat_list[1] = _temp_target_63586;
        concat_list[2] = _31257;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_63589, concat_list, 4);
    }
    DeRefDS(_31258);
    _31258 = NOVALUE;
    DeRefDS(_31257);
    _31257 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _31260 = _pc_63535 + 2;
    if ((object)((uintptr_t)_31260 + (uintptr_t)HIGH_BITS) >= 0){
        _31260 = NewDouble((eudouble)_31260);
    }
    if (IS_ATOM_INT(_31260)) {
        _31261 = _31260 + _supplied_args_63538;
        if ((object)((uintptr_t)_31261 + (uintptr_t)HIGH_BITS) >= 0){
            _31261 = NewDouble((eudouble)_31261);
        }
    }
    else {
        _31261 = NewDouble(DBL_PTR(_31260)->dbl + (eudouble)_supplied_args_63538);
    }
    DeRef(_31260);
    _31260 = NOVALUE;
    RefDS(_converted_code_63589);
    _42replace_code(_converted_code_63589, _pc_63535, _31261, _code_sub_63506);
    _31261 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_27Code_20660);
    DeRef(_code_63531);
    _code_63531 = _27Code_20660;
L4: 
    DeRef(_converted_code_63589);
    _converted_code_63589 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _31262 = 3 + _supplied_args_63538;
    if ((object)((uintptr_t)_31262 + (uintptr_t)HIGH_BITS) >= 0){
        _31262 = NewDouble((eudouble)_31262);
    }
    if (IS_ATOM_INT(_31262)) {
        _31263 = _31262 + _is_func_63513;
        if ((object)((uintptr_t)_31263 + (uintptr_t)HIGH_BITS) >= 0){
            _31263 = NewDouble((eudouble)_31263);
        }
    }
    else {
        _31263 = NewDouble(DBL_PTR(_31262)->dbl + (eudouble)_is_func_63513);
    }
    DeRef(_31262);
    _31262 = NOVALUE;
    if (IS_ATOM_INT(_31263)) {
        _next_pc_63537 = _next_pc_63537 + _31263;
    }
    else {
        _next_pc_63537 = NewDouble((eudouble)_next_pc_63537 + DBL_PTR(_31263)->dbl);
    }
    DeRef(_31263);
    _31263 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63537)) {
        _1 = (object)(DBL_PTR(_next_pc_63537)->dbl);
        DeRefDS(_next_pc_63537);
        _next_pc_63537 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63513 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _31265 = _pc_63535 + 3;
    if ((object)((uintptr_t)_31265 + (uintptr_t)HIGH_BITS) >= 0){
        _31265 = NewDouble((eudouble)_31265);
    }
    if (IS_ATOM_INT(_31265)) {
        _31266 = _31265 + _supplied_args_63538;
    }
    else {
        _31266 = NewDouble(DBL_PTR(_31265)->dbl + (eudouble)_supplied_args_63538);
    }
    DeRef(_31265);
    _31265 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_31266)){
        _target_63605 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31266)->dbl));
    }
    else{
        _target_63605 = (object)*(((s1_ptr)_2)->base + _31266);
    }
    if (!IS_ATOM_INT(_target_63605)){
        _target_63605 = (object)DBL_PTR(_target_63605)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63611 = 0;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63531)){
            _31268 = SEQ_PTR(_code_63531)->length;
    }
    else {
        _31268 = 1;
    }
    _goto_target_63612 = _31268 + 1;
    _31268 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63615 = 0;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63531)){
            _code_len_63616 = SEQ_PTR(_code_63531)->length;
    }
    else {
        _code_len_63616 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63618 = 0;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _61set_dont_read(1);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_22209);
    DeRefi(_42fwd_private_sym_63436);
    _42fwd_private_sym_63436 = _22209;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_22209);
    DeRef(_42fwd_private_name_63437);
    _42fwd_private_name_63437 = _22209;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63621 = _sub_63479;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63622);
    _params_63622 = Repeat(0, _args_63508);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63531);
    DeRef(_orig_code_63624);
    _orig_code_63624 = _code_63531;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_27LineTable_20661);
    DeRef(_orig_linetable_63625);
    _orig_linetable_63625 = _27LineTable_20661;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_22209);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22209;

    /** fwdref.e:320		Code = {}*/
    RefDS(_22209);
    DeRef(_27Code_20660);
    _27Code_20660 = _22209;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31272 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _ar_sp_63629 = find_from(_code_sub_63506, _31272, 1);
    _31272 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63506 != _27TopLevelSub_20578)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    _31275 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_31275)){
            _pre_refs_63633 = SEQ_PTR(_31275)->length;
    }
    else {
        _pre_refs_63633 = 1;
    }
    _31275 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31277 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _ar_sp_63629 = find_from(_code_sub_63506, _31277, 1);
    _31277 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _31279 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _2 = (object)SEQ_PTR(_31279);
    _31280 = (object)*(((s1_ptr)_2)->base + _ar_sp_63629);
    _31279 = NOVALUE;
    if (IS_SEQUENCE(_31280)){
            _pre_refs_63633 = SEQ_PTR(_31280)->length;
    }
    else {
        _pre_refs_63633 = 1;
    }
    _31280 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_22209);
    DeRef(_old_fwd_params_63648);
    _old_fwd_params_63648 = _22209;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _31282 = _pc_63535 + 3;
    if ((object)((uintptr_t)_31282 + (uintptr_t)HIGH_BITS) >= 0){
        _31282 = NewDouble((eudouble)_31282);
    }
    _31283 = _pc_63535 + _args_63508;
    if ((object)((uintptr_t)_31283 + (uintptr_t)HIGH_BITS) >= 0){
        _31283 = NewDouble((eudouble)_31283);
    }
    if (IS_ATOM_INT(_31283)) {
        _31284 = _31283 + 2;
        if ((object)((uintptr_t)_31284 + (uintptr_t)HIGH_BITS) >= 0){
            _31284 = NewDouble((eudouble)_31284);
        }
    }
    else {
        _31284 = NewDouble(DBL_PTR(_31283)->dbl + (eudouble)2);
    }
    DeRef(_31283);
    _31283 = NOVALUE;
    {
        object _i_63650;
        Ref(_31282);
        _i_63650 = _31282;
L9: 
        if (binary_op_a(GREATER, _i_63650, _31284)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63615 = _defarg_63615 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _31286 = (object)*(((s1_ptr)_2)->base + _param_sym_63621);
        _2 = (object)SEQ_PTR(_31286);
        _param_sym_63621 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_63621)){
            _param_sym_63621 = (object)DBL_PTR(_param_sym_63621)->dbl;
        }
        _31286 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _31288 = (_defarg_63615 > _supplied_args_63538);
        if (_31288 != 0) {
            _31289 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63531)){
                _31290 = SEQ_PTR(_code_63531)->length;
        }
        else {
            _31290 = 1;
        }
        if (IS_ATOM_INT(_i_63650)) {
            _31291 = (_i_63650 > _31290);
        }
        else {
            _31291 = (DBL_PTR(_i_63650)->dbl > (eudouble)_31290);
        }
        _31290 = NOVALUE;
        _31289 = (_31291 != 0);
LB: 
        if (_31289 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63531);
        if (!IS_ATOM_INT(_i_63650)){
            _31293 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63650)->dbl));
        }
        else{
            _31293 = (object)*(((s1_ptr)_2)->base + _i_63650);
        }
        if (IS_ATOM_INT(_31293)) {
            _31294 = (_31293 == 0);
        }
        else {
            _31294 = unary_op(NOT, _31293);
        }
        _31293 = NOVALUE;
        if (_31294 == 0) {
            DeRef(_31294);
            _31294 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31294) && DBL_PTR(_31294)->dbl == 0.0){
                DeRef(_31294);
                _31294 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31294);
            _31294 = NOVALUE;
        }
        DeRef(_31294);
        _31294 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63611 = 1;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63618 = _extra_default_args_63618 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _53show_params(_sub_63479);

        /** fwdref.e:346				set_error_info( ref )*/
        _42set_error_info(_ref_63475);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_42fwd_private_name_63437);
        RefDS(_42fwd_private_sym_63436);
        _43Parse_default_arg(_sub_63479, _defarg_63615, _42fwd_private_name_63437, _42fwd_private_sym_63436);

        /** fwdref.e:348				hide_params( sub )*/
        _53hide_params(_sub_63479);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31296 = _45Pop();
        _2 = (object)SEQ_PTR(_params_63622);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63615);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31296;
        if( _1 != _31296 ){
            DeRef(_1);
        }
        _31296 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63618 = 0;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63531);
        if (!IS_ATOM_INT(_i_63650)){
            _31297 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63650)->dbl));
        }
        else{
            _31297 = (object)*(((s1_ptr)_2)->base + _i_63650);
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _31298 = (object)*(((s1_ptr)_2)->base + _param_sym_63621);
        _2 = (object)SEQ_PTR(_31298);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _31299 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _31299 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _31298 = NOVALUE;
        Ref(_31297);
        Ref(_31299);
        _42add_private_symbol(_31297, _31299);
        _31297 = NOVALUE;
        _31299 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63531);
        if (!IS_ATOM_INT(_i_63650)){
            _31300 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63650)->dbl));
        }
        else{
            _31300 = (object)*(((s1_ptr)_2)->base + _i_63650);
        }
        Ref(_31300);
        _2 = (object)SEQ_PTR(_params_63622);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63615);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31300;
        if( _1 != _31300 ){
            DeRef(_1);
        }
        _31300 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63650;
        if (IS_ATOM_INT(_i_63650)) {
            _i_63650 = _i_63650 + 1;
            if ((object)((uintptr_t)_i_63650 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63650 = NewDouble((eudouble)_i_63650);
            }
        }
        else {
            _i_63650 = binary_op_a(PLUS, _i_63650, 1);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63650);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63506 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _31303 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _31303 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _31301 = NOVALUE;
    if (IS_ATOM_INT(_31303)) {
        _31304 = _31303 + _53temps_allocated_47715;
        if ((object)((uintptr_t)_31304 + (uintptr_t)HIGH_BITS) >= 0){
            _31304 = NewDouble((eudouble)_31304);
        }
    }
    else {
        _31304 = binary_op(PLUS, _31303, _53temps_allocated_47715);
    }
    _31303 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31304;
    if( _1 != _31304 ){
        DeRef(_1);
    }
    _31304 = NOVALUE;
    _31301 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _53temps_allocated_47715 = _old_temps_allocated_63577;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63689 = _42shifting_sub_63265;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63535 == (uintptr_t)HIGH_BITS){
        _31305 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31305 = - _pc_63535;
    }
    _31306 = _pc_63535 - 1;
    if ((object)((uintptr_t)_31306 +(uintptr_t) HIGH_BITS) >= 0){
        _31306 = NewDouble((eudouble)_31306);
    }
    Ref(_31305);
    DeRef(_31962);
    _31962 = _31305;
    _65shift(_31305, _31306, _31962);
    _31305 = NOVALUE;
    _31306 = NOVALUE;
    _31962 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_27Code_20660);
    DeRef(_new_code_63693);
    _new_code_63693 = _27Code_20660;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63624);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _orig_code_63624;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_22209);
    DeRefDS(_orig_code_63624);
    _orig_code_63624 = _22209;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63625);
    DeRef(_27LineTable_20661);
    _27LineTable_20661 = _orig_linetable_63625;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_22209);
    DeRefDS(_orig_linetable_63625);
    _orig_linetable_63625 = _22209;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _61set_dont_read(0);

    /** fwdref.e:372		current_file_no = real_file*/
    _27current_file_no_20571 = _real_file_63527;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31307 = _supplied_args_63538 + _extra_default_args_63618;
    if ((object)((uintptr_t)_31307 + (uintptr_t)HIGH_BITS) >= 0){
        _31307 = NewDouble((eudouble)_31307);
    }
    if (binary_op_a(EQUALS, _args_63508, _31307)){
        DeRef(_31307);
        _31307 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31307);
    _31307 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63513 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26484);
    DeRefi(_routine_type_63702);
    _routine_type_63702 = _26484;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26538);
    DeRefi(_routine_type_63702);
    _routine_type_63702 = _26538;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63476);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31311 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _31312 = _supplied_args_63538 + _extra_default_args_63618;
    if ((object)((uintptr_t)_31312 + (uintptr_t)HIGH_BITS) >= 0){
        _31312 = NewDouble((eudouble)_31312);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31311);
    ((intptr_t*)_2)[1] = _31311;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_routine_type_63702);
    ((intptr_t*)_2)[3] = _routine_type_63702;
    RefDS(_name_63541);
    ((intptr_t*)_2)[4] = _name_63541;
    ((intptr_t*)_2)[5] = _args_63508;
    ((intptr_t*)_2)[6] = _31312;
    _31313 = MAKE_SEQ(_1);
    _31312 = NOVALUE;
    _31311 = NOVALUE;
    _49CompileErr(158, _31313, 0);
    _31313 = NOVALUE;
LF: 
    DeRefi(_routine_type_63702);
    _routine_type_63702 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63622;
        concat_list[1] = _sub_63479;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_31314, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63693, _new_code_63693, _31314);
    DeRefDS(_31314);
    _31314 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63513 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63693, _new_code_63693, _target_63605);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31317 = _next_pc_63537 - 1;
    if ((object)((uintptr_t)_31317 +(uintptr_t) HIGH_BITS) >= 0){
        _31317 = NewDouble((eudouble)_31317);
    }
    RefDS(_new_code_63693);
    _42replace_code(_new_code_63693, _pc_63535, _31317, _code_sub_63506);
    _31317 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63506 != _27TopLevelSub_20578)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31319 = _pre_refs_63633 + 1;
    if (_31319 > MAXINT){
        _31319 = NewDouble((eudouble)_31319);
    }
    _2 = (object)SEQ_PTR(_fr_63476);
    _31320 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    if (!IS_ATOM_INT(_31320)){
        _31321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31320)->dbl));
    }
    else{
        _31321 = (object)*(((s1_ptr)_2)->base + _31320);
    }
    if (IS_SEQUENCE(_31321)){
            _31322 = SEQ_PTR(_31321)->length;
    }
    else {
        _31322 = 1;
    }
    _31321 = NOVALUE;
    {
        object _i_63727;
        Ref(_31319);
        _i_63727 = _31319;
L14: 
        if (binary_op_a(GREATER, _i_63727, _31322)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63476);
        _31323 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_42toplevel_references_63249);
        if (!IS_ATOM_INT(_31323)){
            _31324 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31323)->dbl));
        }
        else{
            _31324 = (object)*(((s1_ptr)_2)->base + _31323);
        }
        _2 = (object)SEQ_PTR(_31324);
        if (!IS_ATOM_INT(_i_63727)){
            _31325 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63727)->dbl));
        }
        else{
            _31325 = (object)*(((s1_ptr)_2)->base + _i_63727);
        }
        _31324 = NOVALUE;
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63246 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31325))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31325)->dbl));
        else
        _3 = (object)(_31325 + ((s1_ptr)_2)->base);
        _31328 = _pc_63535 - 1;
        if ((object)((uintptr_t)_31328 +(uintptr_t) HIGH_BITS) >= 0){
            _31328 = NewDouble((eudouble)_31328);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31329 = (object)*(((s1_ptr)_2)->base + 5);
        _31326 = NOVALUE;
        if (IS_ATOM_INT(_31329) && IS_ATOM_INT(_31328)) {
            _31330 = _31329 + _31328;
            if ((object)((uintptr_t)_31330 + (uintptr_t)HIGH_BITS) >= 0){
                _31330 = NewDouble((eudouble)_31330);
            }
        }
        else {
            _31330 = binary_op(PLUS, _31329, _31328);
        }
        _31329 = NOVALUE;
        DeRef(_31328);
        _31328 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31330;
        if( _1 != _31330 ){
            DeRef(_1);
        }
        _31330 = NOVALUE;
        _31326 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63727;
        if (IS_ATOM_INT(_i_63727)) {
            _i_63727 = _i_63727 + 1;
            if ((object)((uintptr_t)_i_63727 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63727 = NewDouble((eudouble)_i_63727);
            }
        }
        else {
            _i_63727 = binary_op_a(PLUS, _i_63727, 1);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63727);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31331 = _pre_refs_63633 + 1;
    if (_31331 > MAXINT){
        _31331 = NewDouble((eudouble)_31331);
    }
    _2 = (object)SEQ_PTR(_fr_63476);
    _31332 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!IS_ATOM_INT(_31332)){
        _31333 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31332)->dbl));
    }
    else{
        _31333 = (object)*(((s1_ptr)_2)->base + _31332);
    }
    _2 = (object)SEQ_PTR(_31333);
    _31334 = (object)*(((s1_ptr)_2)->base + _ar_sp_63629);
    _31333 = NOVALUE;
    if (IS_SEQUENCE(_31334)){
            _31335 = SEQ_PTR(_31334)->length;
    }
    else {
        _31335 = 1;
    }
    _31334 = NOVALUE;
    {
        object _i_63742;
        Ref(_31331);
        _i_63742 = _31331;
L17: 
        if (binary_op_a(GREATER, _i_63742, _31335)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63476);
        _31336 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_42active_references_63248);
        if (!IS_ATOM_INT(_31336)){
            _31337 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31336)->dbl));
        }
        else{
            _31337 = (object)*(((s1_ptr)_2)->base + _31336);
        }
        _2 = (object)SEQ_PTR(_31337);
        _31338 = (object)*(((s1_ptr)_2)->base + _ar_sp_63629);
        _31337 = NOVALUE;
        _2 = (object)SEQ_PTR(_31338);
        if (!IS_ATOM_INT(_i_63742)){
            _31339 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63742)->dbl));
        }
        else{
            _31339 = (object)*(((s1_ptr)_2)->base + _i_63742);
        }
        _31338 = NOVALUE;
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63246 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31339))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31339)->dbl));
        else
        _3 = (object)(_31339 + ((s1_ptr)_2)->base);
        _31342 = _pc_63535 - 1;
        if ((object)((uintptr_t)_31342 +(uintptr_t) HIGH_BITS) >= 0){
            _31342 = NewDouble((eudouble)_31342);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31343 = (object)*(((s1_ptr)_2)->base + 5);
        _31340 = NOVALUE;
        if (IS_ATOM_INT(_31343) && IS_ATOM_INT(_31342)) {
            _31344 = _31343 + _31342;
            if ((object)((uintptr_t)_31344 + (uintptr_t)HIGH_BITS) >= 0){
                _31344 = NewDouble((eudouble)_31344);
            }
        }
        else {
            _31344 = binary_op(PLUS, _31343, _31342);
        }
        _31343 = NOVALUE;
        DeRef(_31342);
        _31342 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31344;
        if( _1 != _31344 ){
            DeRef(_1);
        }
        _31344 = NOVALUE;
        _31340 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63742;
        if (IS_ATOM_INT(_i_63742)) {
            _i_63742 = _i_63742 + 1;
            if ((object)((uintptr_t)_i_63742 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63742 = NewDouble((eudouble)_i_63742);
            }
        }
        else {
            _i_63742 = binary_op_a(PLUS, _i_63742, 1);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63742);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _42reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _42resolved_reference(_ref_63475);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_63474);
    DeRef(_fr_63476);
    DeRef(_code_63531);
    DeRef(_name_63541);
    DeRef(_params_63622);
    DeRef(_orig_code_63624);
    DeRef(_orig_linetable_63625);
    DeRef(_old_fwd_params_63648);
    DeRef(_new_code_63693);
    DeRef(_31254);
    _31254 = NOVALUE;
    _31275 = NOVALUE;
    _31339 = NOVALUE;
    _31321 = NOVALUE;
    DeRef(_31288);
    _31288 = NOVALUE;
    _31280 = NOVALUE;
    DeRef(_31319);
    _31319 = NOVALUE;
    DeRef(_31266);
    _31266 = NOVALUE;
    DeRef(_31284);
    _31284 = NOVALUE;
    _31320 = NOVALUE;
    DeRef(_31256);
    _31256 = NOVALUE;
    _31334 = NOVALUE;
    DeRef(_31282);
    _31282 = NOVALUE;
    _31332 = NOVALUE;
    _31336 = NOVALUE;
    DeRef(_31234);
    _31234 = NOVALUE;
    _31325 = NOVALUE;
    DeRef(_31291);
    _31291 = NOVALUE;
    DeRef(_31230);
    _31230 = NOVALUE;
    DeRef(_31331);
    _31331 = NOVALUE;
    _31323 = NOVALUE;
    return;
    ;
}


void _42set_error_info(object _ref_63759)
{
    object _fr_63760 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63760);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63760 = (object)*(((s1_ptr)_2)->base + _ref_63759);
    Ref(_fr_63760);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_49ThisLine_49642);
    _2 = (object)SEQ_PTR(_fr_63760);
    _49ThisLine_49642 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_49ThisLine_49642);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63760);
    _49bp_49646 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_49bp_49646)){
        _49bp_49646 = (object)DBL_PTR(_49bp_49646)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63760);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63760);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63760);
    return;
    ;
}


void _42patch_forward_variable(object _tok_63773, object _ref_63774)
{
    object _fr_63775 = NOVALUE;
    object _sym_63778 = NOVALUE;
    object _pc_63831 = NOVALUE;
    object _vx_63835 = NOVALUE;
    object _d_63852 = NOVALUE;
    object _param_63862 = NOVALUE;
    object _old_63865 = NOVALUE;
    object _new_63870 = NOVALUE;
    object _31401 = NOVALUE;
    object _31400 = NOVALUE;
    object _31399 = NOVALUE;
    object _31397 = NOVALUE;
    object _31394 = NOVALUE;
    object _31392 = NOVALUE;
    object _31391 = NOVALUE;
    object _31390 = NOVALUE;
    object _31389 = NOVALUE;
    object _31387 = NOVALUE;
    object _31386 = NOVALUE;
    object _31385 = NOVALUE;
    object _31384 = NOVALUE;
    object _31383 = NOVALUE;
    object _31381 = NOVALUE;
    object _31379 = NOVALUE;
    object _31376 = NOVALUE;
    object _31375 = NOVALUE;
    object _31374 = NOVALUE;
    object _31372 = NOVALUE;
    object _31371 = NOVALUE;
    object _31370 = NOVALUE;
    object _31369 = NOVALUE;
    object _31367 = NOVALUE;
    object _31365 = NOVALUE;
    object _31364 = NOVALUE;
    object _31363 = NOVALUE;
    object _31362 = NOVALUE;
    object _31361 = NOVALUE;
    object _31360 = NOVALUE;
    object _31359 = NOVALUE;
    object _31358 = NOVALUE;
    object _31357 = NOVALUE;
    object _31356 = NOVALUE;
    object _31355 = NOVALUE;
    object _31354 = NOVALUE;
    object _31353 = NOVALUE;
    object _31352 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63775);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63775 = (object)*(((s1_ptr)_2)->base + _ref_63774);
    Ref(_fr_63775);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63773);
    _sym_63778 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_63778)){
        _sym_63778 = (object)DBL_PTR(_sym_63778)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31352 = (object)*(((s1_ptr)_2)->base + _sym_63778);
    _2 = (object)SEQ_PTR(_31352);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _31353 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _31353 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _31352 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63775);
    _31354 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31353) && IS_ATOM_INT(_31354)) {
        _31355 = (_31353 == _31354);
    }
    else {
        _31355 = binary_op(EQUALS, _31353, _31354);
    }
    _31353 = NOVALUE;
    _31354 = NOVALUE;
    if (IS_ATOM_INT(_31355)) {
        if (_31355 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31355)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63775);
    _31357 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31357)) {
        _31358 = (_31357 == _27TopLevelSub_20578);
    }
    else {
        _31358 = binary_op(EQUALS, _31357, _27TopLevelSub_20578);
    }
    _31357 = NOVALUE;
    if (_31358 == 0) {
        DeRef(_31358);
        _31358 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31358) && DBL_PTR(_31358)->dbl == 0.0){
            DeRef(_31358);
            _31358 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31358);
        _31358 = NOVALUE;
    }
    DeRef(_31358);
    _31358 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63773);
    DeRef(_fr_63775);
    DeRef(_31355);
    _31355 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63775);
    _31359 = (object)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_31359)) {
        _31360 = (_31359 == 18);
    }
    else {
        _31360 = binary_op(EQUALS, _31359, 18);
    }
    _31359 = NOVALUE;
    if (IS_ATOM_INT(_31360)) {
        if (_31360 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31360)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31362 = (object)*(((s1_ptr)_2)->base + _sym_63778);
    _2 = (object)SEQ_PTR(_31362);
    _31363 = (object)*(((s1_ptr)_2)->base + 3);
    _31362 = NOVALUE;
    if (IS_ATOM_INT(_31363)) {
        _31364 = (_31363 == 2);
    }
    else {
        _31364 = binary_op(EQUALS, _31363, 2);
    }
    _31363 = NOVALUE;
    if (_31364 == 0) {
        DeRef(_31364);
        _31364 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31364) && DBL_PTR(_31364)->dbl == 0.0){
            DeRef(_31364);
            _31364 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31364);
        _31364 = NOVALUE;
    }
    DeRef(_31364);
    _31364 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_63774);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22209);
    _49CompileErr(110, _22209, 0);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63775);
    _31365 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31365, 18)){
        _31365 = NOVALUE;
        goto L3; // [130] 170
    }
    _31365 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63778 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31369 = (object)*(((s1_ptr)_2)->base + _sym_63778);
    _2 = (object)SEQ_PTR(_31369);
    _31370 = (object)*(((s1_ptr)_2)->base + 5);
    _31369 = NOVALUE;
    if (IS_ATOM_INT(_31370)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_31370;
             _31371 = MAKE_UINT(tu);
        }
    }
    else {
        _31371 = binary_op(OR_BITS, 2, _31370);
    }
    _31370 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31371;
    if( _1 != _31371 ){
        DeRef(_1);
    }
    _31371 = NOVALUE;
    _31367 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63778 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31374 = (object)*(((s1_ptr)_2)->base + _sym_63778);
    _2 = (object)SEQ_PTR(_31374);
    _31375 = (object)*(((s1_ptr)_2)->base + 5);
    _31374 = NOVALUE;
    if (IS_ATOM_INT(_31375)) {
        {uintptr_t tu;
             tu = (uintptr_t)1 | (uintptr_t)_31375;
             _31376 = MAKE_UINT(tu);
        }
    }
    else {
        _31376 = binary_op(OR_BITS, 1, _31375);
    }
    _31375 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31376;
    if( _1 != _31376 ){
        DeRef(_1);
    }
    _31376 = NOVALUE;
    _31372 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _42set_code(_ref_63774);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63775);
    _pc_63831 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_63831))
    _pc_63831 = (object)DBL_PTR(_pc_63831)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63831 >= 1)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63831 = 1;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63774 == (uintptr_t)HIGH_BITS){
        _31379 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31379 = - _ref_63774;
    }
    _vx_63835 = find_from(_31379, _27Code_20660, _pc_63831);
    DeRef(_31379);
    _31379 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63835 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63835 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63835);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63778;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63774 == (uintptr_t)HIGH_BITS){
        _31381 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31381 = - _ref_63774;
    }
    _vx_63835 = find_from(_31381, _27Code_20660, _vx_63835);
    DeRef(_31381);
    _31381 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _42resolved_reference(_ref_63774);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63775);
    _31383 = (object)*(((s1_ptr)_2)->base + 12);
    _31384 = IS_SEQUENCE(_31383);
    _31383 = NOVALUE;
    if (_31384 == 0)
    {
        _31384 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31384 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63775);
    _31385 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_31385)){
            _31386 = SEQ_PTR(_31385)->length;
    }
    else {
        _31386 = 1;
    }
    _31385 = NOVALUE;
    {
        object _i_63849;
        _i_63849 = 1;
LA: 
        if (_i_63849 > _31386){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63775);
        _31387 = (object)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_63852);
        _2 = (object)SEQ_PTR(_31387);
        _d_63852 = (object)*(((s1_ptr)_2)->base + _i_63849);
        Ref(_d_63852);
        _31387 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31389 = IS_SEQUENCE(_d_63852);
        if (_31389 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63852);
        _31391 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31391)) {
            _31392 = (_31391 == 1);
        }
        else {
            _31392 = binary_op(EQUALS, _31391, 1);
        }
        _31391 = NOVALUE;
        if (_31392 == 0) {
            DeRef(_31392);
            _31392 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31392) && DBL_PTR(_31392)->dbl == 0.0){
                DeRef(_31392);
                _31392 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31392);
            _31392 = NOVALUE;
        }
        DeRef(_31392);
        _31392 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63852);
        _param_63862 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_63862)){
            _param_63862 = (object)DBL_PTR(_param_63862)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63852);
        _31394 = (object)*(((s1_ptr)_2)->base + 3);
        Ref(_31394);
        DeRef(_old_63865);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508;
        ((intptr_t *)_2)[2] = _31394;
        _old_63865 = MAKE_SEQ(_1);
        _31394 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63870);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _sym_63778;
        _new_63870 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63862 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _31399 = (object)*(((s1_ptr)_2)->base + _param_63862);
        _2 = (object)SEQ_PTR(_31399);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _31400 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _31400 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _31399 = NOVALUE;
        RefDS(_old_63865);
        Ref(_31400);
        RefDS(_new_63870);
        _31401 = _14find_replace(_old_63865, _31400, _new_63870, 0);
        _31400 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_CODE_20221))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31401;
        if( _1 != _31401 ){
            DeRef(_1);
        }
        _31401 = NOVALUE;
        _31397 = NOVALUE;
LC: 
        DeRef(_old_63865);
        _old_63865 = NOVALUE;
        DeRefi(_new_63870);
        _new_63870 = NOVALUE;
        DeRef(_d_63852);
        _d_63852 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63849 = _i_63849 + 1;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _42resolved_reference(_ref_63774);
L9: 

    /** fwdref.e:469		reset_code()*/
    _42reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63773);
    DeRef(_fr_63775);
    _31385 = NOVALUE;
    DeRef(_31355);
    _31355 = NOVALUE;
    DeRef(_31360);
    _31360 = NOVALUE;
    return;
    ;
}


void _42patch_forward_init_check(object _tok_63886, object _ref_63887)
{
    object _fr_63888 = NOVALUE;
    object _31409 = NOVALUE;
    object _31408 = NOVALUE;
    object _31407 = NOVALUE;
    object _31405 = NOVALUE;
    object _31404 = NOVALUE;
    object _31403 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63888);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63888 = (object)*(((s1_ptr)_2)->base + _ref_63887);
    Ref(_fr_63888);

    /** fwdref.e:475		set_code( ref )*/
    _42set_code(_ref_63887);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63888);
    _31403 = (object)*(((s1_ptr)_2)->base + 12);
    _31404 = IS_SEQUENCE(_31403);
    _31403 = NOVALUE;
    if (_31404 == 0)
    {
        _31404 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31404 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _42resolved_reference(_ref_63887);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63888);
    _31405 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _31405, 0)){
        _31405 = NOVALUE;
        goto L3; // [44] 78
    }
    _31405 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63888);
    _31407 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_31407)) {
        _31408 = _31407 + 1;
        if (_31408 > MAXINT){
            _31408 = NewDouble((eudouble)_31408);
        }
    }
    else
    _31408 = binary_op(PLUS, 1, _31407);
    _31407 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63886);
    _31409 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31409);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31408))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31408)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31408);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31409;
    if( _1 != _31409 ){
        DeRef(_1);
    }
    _31409 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _42resolved_reference(_ref_63887);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63886);
    _42forward_error(_tok_63886, _ref_63887);
L2: 

    /** fwdref.e:485		reset_code()*/
    _42reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63886);
    DeRef(_fr_63888);
    DeRef(_31408);
    _31408 = NOVALUE;
    return;
    ;
}


object _42expected_name(object _id_63905)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63905)) {
        _1 = (object)(DBL_PTR(_id_63905)->dbl);
        DeRefDS(_id_63905);
        _id_63905 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63905;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26536);
        return _26536;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26482);
        return _26482;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31412);
        return _31412;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31413);
        return _31413;
    ;}    ;
}


void _42patch_forward_type(object _tok_63922, object _ref_63923)
{
    object _fr_63924 = NOVALUE;
    object _syms_63926 = NOVALUE;
    object _31425 = NOVALUE;
    object _31424 = NOVALUE;
    object _31422 = NOVALUE;
    object _31421 = NOVALUE;
    object _31420 = NOVALUE;
    object _31418 = NOVALUE;
    object _31417 = NOVALUE;
    object _31416 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63924);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63924 = (object)*(((s1_ptr)_2)->base + _ref_63923);
    Ref(_fr_63924);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63926);
    _2 = (object)SEQ_PTR(_fr_63924);
    _syms_63926 = (object)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_63926);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63926)){
            _31416 = SEQ_PTR(_syms_63926)->length;
    }
    else {
        _31416 = 1;
    }
    {
        object _i_63929;
        _i_63929 = 2;
L1: 
        if (_i_63929 > _31416){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63926);
        _31417 = (object)*(((s1_ptr)_2)->base + _i_63929);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31417))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31417)->dbl));
        else
        _3 = (object)(_31417 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63922);
        _31420 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_31420);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31420;
        if( _1 != _31420 ){
            DeRef(_1);
        }
        _31420 = NOVALUE;
        _31418 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63926);
        _31421 = (object)*(((s1_ptr)_2)->base + _i_63929);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31421))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31421)->dbl));
        else
        _3 = (object)(_31421 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63922);
        _31424 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_31424);
        _31425 = _43CompileType(_31424);
        _31424 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31425;
        if( _1 != _31425 ){
            DeRef(_1);
        }
        _31425 = NOVALUE;
        _31422 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_63929 = _i_63929 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _42resolved_reference(_ref_63923);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63922);
    DeRef(_fr_63924);
    DeRef(_syms_63926);
    _31417 = NOVALUE;
    _31421 = NOVALUE;
    return;
    ;
}


void _42patch_forward_case(object _tok_63952, object _ref_63953)
{
    object _fr_63954 = NOVALUE;
    object _switch_pc_63956 = NOVALUE;
    object _case_sym_63959 = NOVALUE;
    object _case_values_63988 = NOVALUE;
    object _cx_63993 = NOVALUE;
    object _negative_64001 = NOVALUE;
    object _31463 = NOVALUE;
    object _31462 = NOVALUE;
    object _31461 = NOVALUE;
    object _31460 = NOVALUE;
    object _31459 = NOVALUE;
    object _31458 = NOVALUE;
    object _31456 = NOVALUE;
    object _31454 = NOVALUE;
    object _31453 = NOVALUE;
    object _31451 = NOVALUE;
    object _31450 = NOVALUE;
    object _31447 = NOVALUE;
    object _31445 = NOVALUE;
    object _31444 = NOVALUE;
    object _31443 = NOVALUE;
    object _31442 = NOVALUE;
    object _31441 = NOVALUE;
    object _31440 = NOVALUE;
    object _31439 = NOVALUE;
    object _31438 = NOVALUE;
    object _31437 = NOVALUE;
    object _31435 = NOVALUE;
    object _31434 = NOVALUE;
    object _31433 = NOVALUE;
    object _31432 = NOVALUE;
    object _31430 = NOVALUE;
    object _31428 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_63954);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_63954 = (object)*(((s1_ptr)_2)->base + _ref_63953);
    Ref(_fr_63954);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_63954);
    _switch_pc_63956 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_63956))
    _switch_pc_63956 = (object)DBL_PTR(_switch_pc_63956)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_63954);
    _31428 = (object)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _31428, _27TopLevelSub_20578)){
        _31428 = NOVALUE;
        goto L1; // [27] 48
    }
    _31428 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31430 = _switch_pc_63956 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _case_sym_63959 = (object)*(((s1_ptr)_2)->base + _31430);
    if (!IS_ATOM_INT(_case_sym_63959)){
        _case_sym_63959 = (object)DBL_PTR(_case_sym_63959)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_63954);
    _31432 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31432)){
        _31433 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31432)->dbl));
    }
    else{
        _31433 = (object)*(((s1_ptr)_2)->base + _31432);
    }
    _2 = (object)SEQ_PTR(_31433);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _31434 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _31434 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _31433 = NOVALUE;
    _31435 = _switch_pc_63956 + 2;
    _2 = (object)SEQ_PTR(_31434);
    _case_sym_63959 = (object)*(((s1_ptr)_2)->base + _31435);
    if (!IS_ATOM_INT(_case_sym_63959)){
        _case_sym_63959 = (object)DBL_PTR(_case_sym_63959)->dbl;
    }
    _31434 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_63952);
    _31437 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31437)){
        _31438 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31437)->dbl));
    }
    else{
        _31438 = (object)*(((s1_ptr)_2)->base + _31437);
    }
    _2 = (object)SEQ_PTR(_31438);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _31439 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _31439 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _31438 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63954);
    _31440 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_31439) && IS_ATOM_INT(_31440)) {
        _31441 = (_31439 == _31440);
    }
    else {
        _31441 = binary_op(EQUALS, _31439, _31440);
    }
    _31439 = NOVALUE;
    _31440 = NOVALUE;
    if (IS_ATOM_INT(_31441)) {
        if (_31441 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31441)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_63954);
    _31443 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_31443)) {
        _31444 = (_31443 == _27TopLevelSub_20578);
    }
    else {
        _31444 = binary_op(EQUALS, _31443, _27TopLevelSub_20578);
    }
    _31443 = NOVALUE;
    if (_31444 == 0) {
        DeRef(_31444);
        _31444 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31444) && DBL_PTR(_31444)->dbl == 0.0){
            DeRef(_31444);
            _31444 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31444);
        _31444 = NOVALUE;
    }
    DeRef(_31444);
    _31444 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_63952);
    DeRef(_fr_63954);
    DeRef(_case_values_63988);
    DeRef(_31441);
    _31441 = NOVALUE;
    _31437 = NOVALUE;
    DeRef(_31430);
    _31430 = NOVALUE;
    DeRef(_31435);
    _31435 = NOVALUE;
    _31432 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31445 = (object)*(((s1_ptr)_2)->base + _case_sym_63959);
    DeRef(_case_values_63988);
    _2 = (object)SEQ_PTR(_31445);
    _case_values_63988 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_63988);
    _31445 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_63953;
    _31447 = MAKE_SEQ(_1);
    _cx_63993 = find_from(_31447, _case_values_63988, 1);
    DeRefDS(_31447);
    _31447 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_63993 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_63953 == (uintptr_t)HIGH_BITS){
        _31450 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31450 = - _ref_63953;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31450;
    _31451 = MAKE_SEQ(_1);
    _31450 = NOVALUE;
    _cx_63993 = find_from(_31451, _case_values_63988, 1);
    DeRefDS(_31451);
    _31451 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_64001 = 0;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_63988);
    _31453 = (object)*(((s1_ptr)_2)->base + _cx_63993);
    _2 = (object)SEQ_PTR(_31453);
    _31454 = (object)*(((s1_ptr)_2)->base + 1);
    _31453 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31454, 0)){
        _31454 = NOVALUE;
        goto L5; // [195] 224
    }
    _31454 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_64001 = 1;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_63988);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63988 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_63993 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31458 = (object)*(((s1_ptr)_2)->base + 1);
    _31456 = NOVALUE;
    if (IS_ATOM_INT(_31458)) {
        if (_31458 == (short)_31458){
            _31459 = _31458 * -1;
        }
        else{
            _31459 = NewDouble(_31458 * (eudouble)-1);
        }
    }
    else {
        _31459 = binary_op(MULTIPLY, _31458, -1);
    }
    _31458 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31459;
    if( _1 != _31459 ){
        DeRef(_1);
    }
    _31459 = NOVALUE;
    _31456 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_64001 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63952);
    _31460 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_31460)) {
        if ((uintptr_t)_31460 == (uintptr_t)HIGH_BITS){
            _31461 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31461 = - _31460;
        }
    }
    else {
        _31461 = unary_op(UMINUS, _31460);
    }
    _31460 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_63988);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63988 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63993);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31461;
    if( _1 != _31461 ){
        DeRef(_1);
    }
    _31461 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63952);
    _31462 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31462);
    _2 = (object)SEQ_PTR(_case_values_63988);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63988 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63993);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31462;
    if( _1 != _31462 ){
        DeRef(_1);
    }
    _31462 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_63959 + ((s1_ptr)_2)->base);
    RefDS(_case_values_63988);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_63988;
    DeRef(_1);
    _31463 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _42resolved_reference(_ref_63953);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_63952);
    DeRef(_fr_63954);
    DeRefDS(_case_values_63988);
    DeRef(_31441);
    _31441 = NOVALUE;
    _31437 = NOVALUE;
    DeRef(_31430);
    _31430 = NOVALUE;
    DeRef(_31435);
    _31435 = NOVALUE;
    _31432 = NOVALUE;
    return;
    ;
}


void _42patch_forward_type_check(object _tok_64024, object _ref_64025)
{
    object _fr_64026 = NOVALUE;
    object _which_type_64029 = NOVALUE;
    object _var_64031 = NOVALUE;
    object _pc_64064 = NOVALUE;
    object _with_type_check_64066 = NOVALUE;
    object _c_64096 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_64105 = NOVALUE;
    object _code_inlined_insert_code_at_329_64104 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_64121 = NOVALUE;
    object _code_inlined_insert_code_at_412_64120 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_64131 = NOVALUE;
    object _code_inlined_insert_code_at_474_64130 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_64141 = NOVALUE;
    object _code_inlined_insert_code_at_536_64140 = NOVALUE;
    object _start_pc_64148 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_64165 = NOVALUE;
    object _code_inlined_insert_code_at_644_64164 = NOVALUE;
    object _c_64168 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_64184 = NOVALUE;
    object _code_inlined_insert_code_at_738_64183 = NOVALUE;
    object _start_pc_64195 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_64215 = NOVALUE;
    object _code_inlined_insert_code_at_883_64214 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_64236 = NOVALUE;
    object _code_inlined_insert_code_at_984_64235 = NOVALUE;
    object _31553 = NOVALUE;
    object _31552 = NOVALUE;
    object _31551 = NOVALUE;
    object _31550 = NOVALUE;
    object _31549 = NOVALUE;
    object _31548 = NOVALUE;
    object _31547 = NOVALUE;
    object _31545 = NOVALUE;
    object _31543 = NOVALUE;
    object _31542 = NOVALUE;
    object _31541 = NOVALUE;
    object _31540 = NOVALUE;
    object _31539 = NOVALUE;
    object _31538 = NOVALUE;
    object _31537 = NOVALUE;
    object _31535 = NOVALUE;
    object _31534 = NOVALUE;
    object _31533 = NOVALUE;
    object _31532 = NOVALUE;
    object _31531 = NOVALUE;
    object _31530 = NOVALUE;
    object _31528 = NOVALUE;
    object _31527 = NOVALUE;
    object _31526 = NOVALUE;
    object _31525 = NOVALUE;
    object _31523 = NOVALUE;
    object _31522 = NOVALUE;
    object _31519 = NOVALUE;
    object _31518 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31513 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31509 = NOVALUE;
    object _31508 = NOVALUE;
    object _31505 = NOVALUE;
    object _31504 = NOVALUE;
    object _31501 = NOVALUE;
    object _31500 = NOVALUE;
    object _31496 = NOVALUE;
    object _31495 = NOVALUE;
    object _31493 = NOVALUE;
    object _31492 = NOVALUE;
    object _31490 = NOVALUE;
    object _31489 = NOVALUE;
    object _31486 = NOVALUE;
    object _31483 = NOVALUE;
    object _31481 = NOVALUE;
    object _31478 = NOVALUE;
    object _31477 = NOVALUE;
    object _31474 = NOVALUE;
    object _31469 = NOVALUE;
    object _31468 = NOVALUE;
    object _31466 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_64026);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _fr_64026 = (object)*(((s1_ptr)_2)->base + _ref_64025);
    Ref(_fr_64026);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_64026);
    _31466 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31466, 197)){
        _31466 = NOVALUE;
        goto L1; // [21] 86
    }
    _31466 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_64024);
    _31468 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31468)){
        _31469 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31468)->dbl));
    }
    else{
        _31469 = (object)*(((s1_ptr)_2)->base + _31468);
    }
    _2 = (object)SEQ_PTR(_31469);
    _which_type_64029 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_64029)){
        _which_type_64029 = (object)DBL_PTR(_which_type_64029)->dbl;
    }
    _31469 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_64029 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64024);
    _which_type_64029 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_64029)){
        _which_type_64029 = (object)DBL_PTR(_which_type_64029)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_64031 = 0;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64024);
    _var_64031 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_64031)){
        _var_64031 = (object)DBL_PTR(_var_64031)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_64026);
    _31474 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _31474, 504)){
        _31474 = NOVALUE;
        goto L4; // [94] 118
    }
    _31474 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_64024);
    _which_type_64029 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_64029)){
        _which_type_64029 = (object)DBL_PTR(_which_type_64029)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_64031 = 0;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _42prep_forward_error(_ref_64025);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_64026);
    _31477 = (object)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65;
    ((intptr_t*)_2)[2] = 197;
    Ref(_31477);
    ((intptr_t*)_2)[3] = _31477;
    _31478 = MAKE_SEQ(_1);
    _31477 = NOVALUE;
    _49InternalErr(262, _31478);
    _31478 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_64029 >= 0)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_64024);
    DeRef(_fr_64026);
    _31468 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _42set_code(_ref_64025);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_64026);
    _pc_64064 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_64064))
    _pc_64064 = (object)DBL_PTR(_pc_64064)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31481 = _pc_64064 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _with_type_check_64066 = (object)*(((s1_ptr)_2)->base + _31481);
    if (!IS_ATOM_INT(_with_type_check_64066)){
        _with_type_check_64066 = (object)DBL_PTR(_with_type_check_64066)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _31483 = (object)*(((s1_ptr)_2)->base + _pc_64064);
    if (binary_op_a(EQUALS, _31483, 197)){
        _31483 = NOVALUE;
        goto L6; // [193] 204
    }
    _31483 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_64024);
    _42forward_error(_tok_64024, _ref_64025);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_64031 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31486 = _pc_64064 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _var_64031 = (object)*(((s1_ptr)_2)->base + _31486);
    if (!IS_ATOM_INT(_var_64031)){
        _var_64031 = (object)DBL_PTR(_var_64031)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_64031 >= 0)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_64024);
    DeRef(_fr_64026);
    _31468 = NOVALUE;
    DeRef(_31486);
    _31486 = NOVALUE;
    DeRef(_31481);
    _31481 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31489 = _pc_64064 + 2;
    if ((object)((uintptr_t)_31489 + (uintptr_t)HIGH_BITS) >= 0){
        _31489 = NewDouble((eudouble)_31489);
    }
    _2 = (object)SEQ_PTR(_fr_64026);
    _31490 = (object)*(((s1_ptr)_2)->base + 4);
    RefDS(_22209);
    Ref(_31490);
    _42replace_code(_22209, _pc_64064, _31489, _31490);
    _31489 = NOVALUE;
    _31490 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_64066 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_64029 == _53object_type_47184)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31492 = (object)*(((s1_ptr)_2)->base + _which_type_64029);
    _2 = (object)SEQ_PTR(_31492);
    _31493 = (object)*(((s1_ptr)_2)->base + 23);
    _31492 = NOVALUE;
    if (_31493 == 0) {
        _31493 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31493) && DBL_PTR(_31493)->dbl == 0.0){
            _31493 = NOVALUE;
            goto LB; // [288] 357
        }
        _31493 = NOVALUE;
    }
    _31493 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_64096 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_64096)) {
        _1 = (object)(DBL_PTR(_c_64096)->dbl);
        DeRefDS(_c_64096);
        _c_64096 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27;
    ((intptr_t*)_2)[2] = _which_type_64029;
    ((intptr_t*)_2)[3] = _var_64031;
    ((intptr_t*)_2)[4] = _c_64096;
    ((intptr_t*)_2)[5] = 65;
    _31495 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31496 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_64104);
    _code_inlined_insert_code_at_329_64104 = _31495;
    _31495 = NOVALUE;
    Ref(_31496);
    DeRef(_subprog_inlined_insert_code_at_332_64105);
    _subprog_inlined_insert_code_at_332_64105 = _31496;
    _31496 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_64105)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_64105)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_64105);
        _subprog_inlined_insert_code_at_332_64105 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_332_64105;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_64104);
    _65insert_code(_code_inlined_insert_code_at_329_64104, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_64104);
    _code_inlined_insert_code_at_329_64104 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_64105);
    _subprog_inlined_insert_code_at_332_64105 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_64064 = _pc_64064 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_64066 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_64029 != _53object_type_47184)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_64029 != _53integer_type_47190)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_64031;
    _31500 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31501 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_64120);
    _code_inlined_insert_code_at_412_64120 = _31500;
    _31500 = NOVALUE;
    Ref(_31501);
    DeRef(_subprog_inlined_insert_code_at_415_64121);
    _subprog_inlined_insert_code_at_415_64121 = _31501;
    _31501 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_64121)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_64121)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_64121);
        _subprog_inlined_insert_code_at_415_64121 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_415_64121;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_64120);
    _65insert_code(_code_inlined_insert_code_at_412_64120, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_64120);
    _code_inlined_insert_code_at_412_64120 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_64121);
    _subprog_inlined_insert_code_at_415_64121 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_64064 = _pc_64064 + 2;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_64029 != _53sequence_type_47188)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97;
    ((intptr_t *)_2)[2] = _var_64031;
    _31504 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31505 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_64130);
    _code_inlined_insert_code_at_474_64130 = _31504;
    _31504 = NOVALUE;
    Ref(_31505);
    DeRef(_subprog_inlined_insert_code_at_477_64131);
    _subprog_inlined_insert_code_at_477_64131 = _31505;
    _31505 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_64131)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_64131)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_64131);
        _subprog_inlined_insert_code_at_477_64131 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_477_64131;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_64130);
    _65insert_code(_code_inlined_insert_code_at_474_64130, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_64130);
    _code_inlined_insert_code_at_474_64130 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_64131);
    _subprog_inlined_insert_code_at_477_64131 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_64064 = _pc_64064 + 2;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_64029 != _53atom_type_47186)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101;
    ((intptr_t *)_2)[2] = _var_64031;
    _31508 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31509 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_64140);
    _code_inlined_insert_code_at_536_64140 = _31508;
    _31508 = NOVALUE;
    Ref(_31509);
    DeRef(_subprog_inlined_insert_code_at_539_64141);
    _subprog_inlined_insert_code_at_539_64141 = _31509;
    _31509 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_64141)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_64141)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_64141);
        _subprog_inlined_insert_code_at_539_64141 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_539_64141;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_64140);
    _65insert_code(_code_inlined_insert_code_at_536_64140, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_64140);
    _code_inlined_insert_code_at_536_64140 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_64141);
    _subprog_inlined_insert_code_at_539_64141 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_64064 = _pc_64064 + 2;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31511 = (object)*(((s1_ptr)_2)->base + _which_type_64029);
    _2 = (object)SEQ_PTR(_31511);
    _31512 = (object)*(((s1_ptr)_2)->base + 2);
    _31511 = NOVALUE;
    if (_31512 == 0) {
        _31512 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31512) && DBL_PTR(_31512)->dbl == 0.0){
            _31512 = NOVALUE;
            goto L17; // [580] 765
        }
        _31512 = NOVALUE;
    }
    _31512 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_64148 = _pc_64064;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31513 = (object)*(((s1_ptr)_2)->base + _which_type_64029);
    _2 = (object)SEQ_PTR(_31513);
    _31514 = (object)*(((s1_ptr)_2)->base + 2);
    _31513 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31514)){
        _31515 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31514)->dbl));
    }
    else{
        _31515 = (object)*(((s1_ptr)_2)->base + _31514);
    }
    _2 = (object)SEQ_PTR(_31515);
    _31516 = (object)*(((s1_ptr)_2)->base + 15);
    _31515 = NOVALUE;
    if (binary_op_a(NOTEQ, _31516, _53integer_type_47190)){
        _31516 = NOVALUE;
        goto L18; // [616] 672
    }
    _31516 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_64031;
    _31518 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31519 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_64164);
    _code_inlined_insert_code_at_644_64164 = _31518;
    _31518 = NOVALUE;
    Ref(_31519);
    DeRef(_subprog_inlined_insert_code_at_647_64165);
    _subprog_inlined_insert_code_at_647_64165 = _31519;
    _31519 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_64165)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_64165)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_64165);
        _subprog_inlined_insert_code_at_647_64165 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_647_64165;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_64164);
    _65insert_code(_code_inlined_insert_code_at_644_64164, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_64164);
    _code_inlined_insert_code_at_644_64164 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_64165);
    _subprog_inlined_insert_code_at_647_64165 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_64064 = _pc_64064 + 2;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_64168 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_64168)) {
        _1 = (object)(DBL_PTR(_c_64168)->dbl);
        DeRefDS(_c_64168);
        _c_64168 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_64026);
    _31522 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31522))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31522)->dbl));
    else
    _3 = (object)(_31522 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _31525 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _31525 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _31523 = NOVALUE;
    if (IS_ATOM_INT(_31525)) {
        _31526 = _31525 + 1;
        if (_31526 > MAXINT){
            _31526 = NewDouble((eudouble)_31526);
        }
    }
    else
    _31526 = binary_op(PLUS, 1, _31525);
    _31525 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31526;
    if( _1 != _31526 ){
        DeRef(_1);
    }
    _31526 = NOVALUE;
    _31523 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27;
    ((intptr_t*)_2)[2] = _which_type_64029;
    ((intptr_t*)_2)[3] = _var_64031;
    ((intptr_t*)_2)[4] = _c_64168;
    ((intptr_t*)_2)[5] = 65;
    _31527 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31528 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_64183);
    _code_inlined_insert_code_at_738_64183 = _31527;
    _31527 = NOVALUE;
    Ref(_31528);
    DeRef(_subprog_inlined_insert_code_at_741_64184);
    _subprog_inlined_insert_code_at_741_64184 = _31528;
    _31528 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_64184)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_64184)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_64184);
        _subprog_inlined_insert_code_at_741_64184 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_741_64184;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_64183);
    _65insert_code(_code_inlined_insert_code_at_738_64183, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_64183);
    _code_inlined_insert_code_at_738_64183 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_64184);
    _subprog_inlined_insert_code_at_741_64184 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_64064 = _pc_64064 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_27TRANSLATE_20179 != 0) {
        _31530 = 1;
        goto L1B; // [775] 786
    }
    _31531 = (_with_type_check_64066 == 0);
    _31530 = (_31531 != 0);
L1B: 
    if (_31530 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31533 = (object)*(((s1_ptr)_2)->base + _which_type_64029);
    _2 = (object)SEQ_PTR(_31533);
    _31534 = (object)*(((s1_ptr)_2)->base + 2);
    _31533 = NOVALUE;
    if (_31534 == 0) {
        _31534 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31534) && DBL_PTR(_31534)->dbl == 0.0){
            _31534 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31534 = NOVALUE;
    }
    _31534 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_64195 = _pc_64064;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31535 = (_which_type_64029 == _53sequence_type_47188);
    if (_31535 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31537 = (object)*(((s1_ptr)_2)->base + _which_type_64029);
    _2 = (object)SEQ_PTR(_31537);
    _31538 = (object)*(((s1_ptr)_2)->base + 2);
    _31537 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31538)){
        _31539 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31538)->dbl));
    }
    else{
        _31539 = (object)*(((s1_ptr)_2)->base + _31538);
    }
    _2 = (object)SEQ_PTR(_31539);
    _31540 = (object)*(((s1_ptr)_2)->base + 15);
    _31539 = NOVALUE;
    if (IS_ATOM_INT(_31540)) {
        _31541 = (_31540 == _53sequence_type_47188);
    }
    else {
        _31541 = binary_op(EQUALS, _31540, _53sequence_type_47188);
    }
    _31540 = NOVALUE;
    if (_31541 == 0) {
        DeRef(_31541);
        _31541 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31541) && DBL_PTR(_31541)->dbl == 0.0){
            DeRef(_31541);
            _31541 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31541);
        _31541 = NOVALUE;
    }
    DeRef(_31541);
    _31541 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97;
    ((intptr_t *)_2)[2] = _var_64031;
    _31542 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31543 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_64214);
    _code_inlined_insert_code_at_883_64214 = _31542;
    _31542 = NOVALUE;
    Ref(_31543);
    DeRef(_subprog_inlined_insert_code_at_886_64215);
    _subprog_inlined_insert_code_at_886_64215 = _31543;
    _31543 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_64215)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_64215)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_64215);
        _subprog_inlined_insert_code_at_886_64215 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_886_64215;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_64214);
    _65insert_code(_code_inlined_insert_code_at_883_64214, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_64214);
    _code_inlined_insert_code_at_883_64214 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_64215);
    _subprog_inlined_insert_code_at_886_64215 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_64064 = _pc_64064 + 2;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31545 = (_which_type_64029 == _53integer_type_47190);
    if (_31545 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31547 = (object)*(((s1_ptr)_2)->base + _which_type_64029);
    _2 = (object)SEQ_PTR(_31547);
    _31548 = (object)*(((s1_ptr)_2)->base + 2);
    _31547 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31548)){
        _31549 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31548)->dbl));
    }
    else{
        _31549 = (object)*(((s1_ptr)_2)->base + _31548);
    }
    _2 = (object)SEQ_PTR(_31549);
    _31550 = (object)*(((s1_ptr)_2)->base + 15);
    _31549 = NOVALUE;
    if (IS_ATOM_INT(_31550)) {
        _31551 = (_31550 == _53integer_type_47190);
    }
    else {
        _31551 = binary_op(EQUALS, _31550, _53integer_type_47190);
    }
    _31550 = NOVALUE;
    if (_31551 == 0) {
        DeRef(_31551);
        _31551 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31551) && DBL_PTR(_31551)->dbl == 0.0){
            DeRef(_31551);
            _31551 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31551);
        _31551 = NOVALUE;
    }
    DeRef(_31551);
    _31551 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96;
    ((intptr_t *)_2)[2] = _var_64031;
    _31552 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_64026);
    _31553 = (object)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_64235);
    _code_inlined_insert_code_at_984_64235 = _31552;
    _31552 = NOVALUE;
    Ref(_31553);
    DeRef(_subprog_inlined_insert_code_at_987_64236);
    _subprog_inlined_insert_code_at_987_64236 = _31553;
    _31553 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_64236)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_64236)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_64236);
        _subprog_inlined_insert_code_at_987_64236 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _42shifting_sub_63265 = _subprog_inlined_insert_code_at_987_64236;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_64235);
    _65insert_code(_code_inlined_insert_code_at_984_64235, _pc_64064);

    /** fwdref.e:84		shifting_sub = 0*/
    _42shifting_sub_63265 = 0;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_64235);
    _code_inlined_insert_code_at_984_64235 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_64236);
    _subprog_inlined_insert_code_at_987_64236 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_64064 = _pc_64064 + 4;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _42resolved_reference(_ref_64025);

    /** fwdref.e:687		reset_code()*/
    _42reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_64024);
    DeRef(_fr_64026);
    _31548 = NOVALUE;
    DeRef(_31545);
    _31545 = NOVALUE;
    _31468 = NOVALUE;
    DeRef(_31531);
    _31531 = NOVALUE;
    _31522 = NOVALUE;
    DeRef(_31486);
    _31486 = NOVALUE;
    DeRef(_31535);
    _31535 = NOVALUE;
    _31538 = NOVALUE;
    DeRef(_31481);
    _31481 = NOVALUE;
    _31514 = NOVALUE;
    return;
    ;
}


void _42prep_forward_error(object _ref_64240)
{
    object _31561 = NOVALUE;
    object _31559 = NOVALUE;
    object _31557 = NOVALUE;
    object _31555 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_64240)) {
        _1 = (object)(DBL_PTR(_ref_64240)->dbl);
        DeRefDS(_ref_64240);
        _ref_64240 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31555 = (object)*(((s1_ptr)_2)->base + _ref_64240);
    DeRef(_49ThisLine_49642);
    _2 = (object)SEQ_PTR(_31555);
    _49ThisLine_49642 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_49ThisLine_49642);
    _31555 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31557 = (object)*(((s1_ptr)_2)->base + _ref_64240);
    _2 = (object)SEQ_PTR(_31557);
    _49bp_49646 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_49bp_49646)){
        _49bp_49646 = (object)DBL_PTR(_49bp_49646)->dbl;
    }
    _31557 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31559 = (object)*(((s1_ptr)_2)->base + _ref_64240);
    _2 = (object)SEQ_PTR(_31559);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }
    _31559 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31561 = (object)*(((s1_ptr)_2)->base + _ref_64240);
    _2 = (object)SEQ_PTR(_31561);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }
    _31561 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _42forward_error(object _tok_64256, object _ref_64257)
{
    object _31568 = NOVALUE;
    object _31567 = NOVALUE;
    object _31566 = NOVALUE;
    object _31565 = NOVALUE;
    object _31564 = NOVALUE;
    object _31563 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _42prep_forward_error(_ref_64257);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31563 = (object)*(((s1_ptr)_2)->base + _ref_64257);
    _2 = (object)SEQ_PTR(_31563);
    _31564 = (object)*(((s1_ptr)_2)->base + 1);
    _31563 = NOVALUE;
    Ref(_31564);
    _31565 = _42expected_name(_31564);
    _31564 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_64256);
    _31566 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31566);
    _31567 = _42expected_name(_31566);
    _31566 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31565;
    ((intptr_t *)_2)[2] = _31567;
    _31568 = MAKE_SEQ(_1);
    _31567 = NOVALUE;
    _31565 = NOVALUE;
    _49CompileErr(68, _31568, 0);
    _31568 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_64256);
    return;
    ;
}


object _42find_reference(object _fr_64269)
{
    object _name_64270 = NOVALUE;
    object _file_64272 = NOVALUE;
    object _ns_file_64274 = NOVALUE;
    object _ix_64275 = NOVALUE;
    object _ns_64278 = NOVALUE;
    object _ns_tok_64282 = NOVALUE;
    object _tok_64294 = NOVALUE;
    object _31579 = NOVALUE;
    object _31576 = NOVALUE;
    object _31574 = NOVALUE;
    object _31572 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_64270);
    _2 = (object)SEQ_PTR(_fr_64269);
    _name_64270 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_name_64270);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_64269);
    _file_64272 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_64272))
    _file_64272 = (object)DBL_PTR(_file_64272)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_64274 = -1;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_64275 = find_from(58, _name_64270, 1);

    /** fwdref.e:711		if ix then*/
    if (_ix_64275 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31572 = _ix_64275 - 1;
    rhs_slice_target = (object_ptr)&_ns_64278;
    RHS_Slice(_name_64270, 1, _31572);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64269);
    _31574 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_64278);
    Ref(_31574);
    _0 = _ns_tok_64282;
    _ns_tok_64282 = _53keyfind(_ns_64278, -1, _file_64272, 1, _31574);
    DeRef(_0);
    _31574 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_64282);
    _31576 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _31576, 523)){
        _31576 = NOVALUE;
        goto L2; // [69] 80
    }
    _31576 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_64278);
    DeRefDS(_fr_64269);
    DeRefDS(_name_64270);
    DeRef(_tok_64294);
    _31572 = NOVALUE;
    return _ns_tok_64282;
L2: 
    DeRef(_ns_64278);
    _ns_64278 = NOVALUE;
    DeRef(_ns_tok_64282);
    _ns_tok_64282 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_64269);
    _ns_file_64274 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_64274))
    _ns_file_64274 = (object)DBL_PTR(_ns_file_64274)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64269);
    _31579 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_64270);
    Ref(_31579);
    _0 = _tok_64294;
    _tok_64294 = _53keyfind(_name_64270, _ns_file_64274, _file_64272, 0, _31579);
    DeRef(_0);
    _31579 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _53No_new_entry_48382 = 0;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_64269);
    DeRefDS(_name_64270);
    DeRef(_31572);
    _31572 = NOVALUE;
    return _tok_64294;
    ;
}


void _42register_forward_type(object _sym_64302, object _ref_64303)
{
    object _31586 = NOVALUE;
    object _31585 = NOVALUE;
    object _31583 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_64303 >= 0)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_64303 = - _ref_64303;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64303 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31585 = (object)*(((s1_ptr)_2)->base + 12);
    _31583 = NOVALUE;
    if (IS_SEQUENCE(_31585) && IS_ATOM(_sym_64302)) {
        Append(&_31586, _31585, _sym_64302);
    }
    else if (IS_ATOM(_31585) && IS_SEQUENCE(_sym_64302)) {
    }
    else {
        Concat((object_ptr)&_31586, _31585, _sym_64302);
        _31585 = NOVALUE;
    }
    _31585 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31586;
    if( _1 != _31586 ){
        DeRef(_1);
    }
    _31586 = NOVALUE;
    _31583 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _42new_forward_reference(object _fwd_op_64333, object _sym_64335, object _op_64336)
{
    object _ref_64337 = NOVALUE;
    object _len_64338 = NOVALUE;
    object _hashval_64368 = NOVALUE;
    object _default_sym_64443 = NOVALUE;
    object _param_64446 = NOVALUE;
    object _set_data_2__tmp_at578_64463 = NOVALUE;
    object _set_data_1__tmp_at578_64462 = NOVALUE;
    object _data_inlined_set_data_at_575_64461 = NOVALUE;
    object _31672 = NOVALUE;
    object _31671 = NOVALUE;
    object _31670 = NOVALUE;
    object _31667 = NOVALUE;
    object _31665 = NOVALUE;
    object _31664 = NOVALUE;
    object _31662 = NOVALUE;
    object _31661 = NOVALUE;
    object _31660 = NOVALUE;
    object _31658 = NOVALUE;
    object _31656 = NOVALUE;
    object _31654 = NOVALUE;
    object _31651 = NOVALUE;
    object _31650 = NOVALUE;
    object _31648 = NOVALUE;
    object _31646 = NOVALUE;
    object _31644 = NOVALUE;
    object _31642 = NOVALUE;
    object _31641 = NOVALUE;
    object _31640 = NOVALUE;
    object _31638 = NOVALUE;
    object _31635 = NOVALUE;
    object _31633 = NOVALUE;
    object _31631 = NOVALUE;
    object _31630 = NOVALUE;
    object _31629 = NOVALUE;
    object _31628 = NOVALUE;
    object _31626 = NOVALUE;
    object _31623 = NOVALUE;
    object _31622 = NOVALUE;
    object _31621 = NOVALUE;
    object _31619 = NOVALUE;
    object _31618 = NOVALUE;
    object _31617 = NOVALUE;
    object _31616 = NOVALUE;
    object _31614 = NOVALUE;
    object _31613 = NOVALUE;
    object _31612 = NOVALUE;
    object _31611 = NOVALUE;
    object _31609 = NOVALUE;
    object _31606 = NOVALUE;
    object _31605 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_64335)) {
        _1 = (object)(DBL_PTR(_sym_64335)->dbl);
        DeRefDS(_sym_64335);
        _sym_64335 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_42inactive_references_63250)){
            _len_64338 = SEQ_PTR(_42inactive_references_63250)->length;
    }
    else {
        _len_64338 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_64338 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_42inactive_references_63250);
    _ref_64337 = (object)*(((s1_ptr)_2)->base + _len_64338);
    if (!IS_ATOM_INT(_ref_64337))
    _ref_64337 = (object)DBL_PTR(_ref_64337)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_42inactive_references_63250);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_64338)) ? _len_64338 : (object)(DBL_PTR(_len_64338)->dbl);
        int stop = (IS_ATOM_INT(_len_64338)) ? _len_64338 : (object)(DBL_PTR(_len_64338)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_42inactive_references_63250), start, &_42inactive_references_63250 );
            }
            else Tail(SEQ_PTR(_42inactive_references_63250), stop+1, &_42inactive_references_63250);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_42inactive_references_63250), start, &_42inactive_references_63250);
        }
        else {
            assign_slice_seq = &assign_space;
            _42inactive_references_63250 = Remove_elements(start, stop, (SEQ_PTR(_42inactive_references_63250)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_42forward_references_63246, _42forward_references_63246, 0);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_42forward_references_63246)){
            _ref_64337 = SEQ_PTR(_42forward_references_63246)->length;
    }
    else {
        _ref_64337 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31605 = Repeat(0, 12);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_64337);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31605;
    if( _1 != _31605 ){
        DeRef(_1);
    }
    _31605 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_64333;
    DeRef(_1);
    _31606 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_64335 >= 0)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64335 == (uintptr_t)HIGH_BITS){
        _31611 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31611 = - _sym_64335;
    }
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!IS_ATOM_INT(_31611)){
        _31612 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31611)->dbl));
    }
    else{
        _31612 = (object)*(((s1_ptr)_2)->base + _31611);
    }
    _2 = (object)SEQ_PTR(_31612);
    _31613 = (object)*(((s1_ptr)_2)->base + 2);
    _31612 = NOVALUE;
    Ref(_31613);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31613;
    if( _1 != _31613 ){
        DeRef(_1);
    }
    _31613 = NOVALUE;
    _31609 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64335 == (uintptr_t)HIGH_BITS){
        _31616 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31616 = - _sym_64335;
    }
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!IS_ATOM_INT(_31616)){
        _31617 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31616)->dbl));
    }
    else{
        _31617 = (object)*(((s1_ptr)_2)->base + _31616);
    }
    _2 = (object)SEQ_PTR(_31617);
    _31618 = (object)*(((s1_ptr)_2)->base + 11);
    _31617 = NOVALUE;
    Ref(_31618);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31618;
    if( _1 != _31618 ){
        DeRef(_1);
    }
    _31618 = NOVALUE;
    _31614 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31621 = (object)*(((s1_ptr)_2)->base + _sym_64335);
    _2 = (object)SEQ_PTR(_31621);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _31622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _31622 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _31621 = NOVALUE;
    Ref(_31622);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31622;
    if( _1 != _31622 ){
        DeRef(_1);
    }
    _31622 = NOVALUE;
    _31619 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31623 = (object)*(((s1_ptr)_2)->base + _sym_64335);
    _2 = (object)SEQ_PTR(_31623);
    _hashval_64368 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_64368)){
        _hashval_64368 = (object)DBL_PTR(_hashval_64368)->dbl;
    }
    _31623 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0 != _hashval_64368)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    _31628 = (object)*(((s1_ptr)_2)->base + _ref_64337);
    _2 = (object)SEQ_PTR(_31628);
    _31629 = (object)*(((s1_ptr)_2)->base + 2);
    _31628 = NOVALUE;
    Ref(_31629);
    _31630 = _53hashfn(_31629);
    _31629 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31630;
    if( _1 != _31630 ){
        DeRef(_1);
    }
    _31630 = NOVALUE;
    _31626 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_64368;
    DeRef(_1);
    _31631 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _53remove_symbol(_sym_64335);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _31633 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27CurrentSub_20579;
    DeRef(_1);
    _31635 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_64333 == 504)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_27Code_20660)){
            _31640 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _31640 = 1;
    }
    _31641 = _31640 + 1;
    _31640 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31641;
    if( _1 != _31641 ){
        DeRef(_1);
    }
    _31641 = NOVALUE;
    _31638 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27fwd_line_number_20573;
    DeRef(_1);
    _31642 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    Ref(_49ForwardLine_49643);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _49ForwardLine_49643;
    DeRef(_1);
    _31644 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _49forward_bp_49647;
    DeRef(_1);
    _31646 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _31650 = _61get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31650;
    if( _1 != _31650 ){
        DeRef(_1);
    }
    _31650 = NOVALUE;
    _31648 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_64336;
    DeRef(_1);
    _31651 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_64336 != 188)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_64335;
    _31656 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31656;
    if( _1 != _31656 ){
        DeRef(_1);
    }
    _31656 = NOVALUE;
    _31654 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_42toplevel_references_63249)){
            _31658 = SEQ_PTR(_42toplevel_references_63249)->length;
    }
    else {
        _31658 = 1;
    }
    if (_31658 >= _27current_file_no_20571)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_42toplevel_references_63249)){
            _31660 = SEQ_PTR(_42toplevel_references_63249)->length;
    }
    else {
        _31660 = 1;
    }
    _31661 = _27current_file_no_20571 - _31660;
    _31660 = NOVALUE;
    _31662 = Repeat(_22209, _31661);
    _31661 = NOVALUE;
    Concat((object_ptr)&_42toplevel_references_63249, _42toplevel_references_63249, _31662);
    DeRefDS(_31662);
    _31662 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    _31664 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_31664) && IS_ATOM(_ref_64337)) {
        Append(&_31665, _31664, _ref_64337);
    }
    else if (IS_ATOM(_31664) && IS_SEQUENCE(_ref_64337)) {
    }
    else {
        Concat((object_ptr)&_31665, _31664, _ref_64337);
        _31664 = NOVALUE;
    }
    _31664 = NOVALUE;
    _2 = (object)SEQ_PTR(_42toplevel_references_63249);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42toplevel_references_63249 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31665;
    if( _1 != _31665 ){
        DeRef(_1);
    }
    _31665 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _42add_active_reference(_ref_64337, _27current_file_no_20571);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_64443 = _27CurrentSub_20579;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_64446 = 0;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_64443 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31667 = _53sym_scope(_default_sym_64443);
    if (binary_op_a(NOTEQ, _31667, 3)){
        DeRef(_31667);
        _31667 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31667);
    _31667 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_64446 = _default_sym_64443;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_64443 = _53sym_next(_default_sym_64443);
    if (!IS_ATOM_INT(_default_sym_64443)) {
        _1 = (object)(DBL_PTR(_default_sym_64443)->dbl);
        DeRefDS(_default_sym_64443);
        _default_sym_64443 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_27Recorded_sym_20680)){
            _31670 = SEQ_PTR(_27Recorded_sym_20680)->length;
    }
    else {
        _31670 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = _param_64446;
    ((intptr_t*)_2)[3] = _31670;
    _31671 = MAKE_SEQ(_1);
    _31670 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31671;
    _31672 = MAKE_SEQ(_1);
    _31671 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_64461);
    _data_inlined_set_data_at_575_64461 = _31672;
    _31672 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_42forward_references_63246);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42forward_references_63246 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64337 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_64461);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_64461;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_64461);
    _data_inlined_set_data_at_575_64461 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _42fwdref_count_63266 = _42fwdref_count_63266 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31616);
    _31616 = NOVALUE;
    DeRef(_31611);
    _31611 = NOVALUE;
    return _ref_64337;
    ;
}


void _42add_active_reference(object _ref_64467, object _file_no_64468)
{
    object _sp_64482 = NOVALUE;
    object _31696 = NOVALUE;
    object _31695 = NOVALUE;
    object _31693 = NOVALUE;
    object _31692 = NOVALUE;
    object _31691 = NOVALUE;
    object _31689 = NOVALUE;
    object _31688 = NOVALUE;
    object _31687 = NOVALUE;
    object _31684 = NOVALUE;
    object _31682 = NOVALUE;
    object _31681 = NOVALUE;
    object _31680 = NOVALUE;
    object _31678 = NOVALUE;
    object _31677 = NOVALUE;
    object _31676 = NOVALUE;
    object _31674 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_42active_references_63248)){
            _31674 = SEQ_PTR(_42active_references_63248)->length;
    }
    else {
        _31674 = 1;
    }
    if (_31674 >= _file_no_64468)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_42active_references_63248)){
            _31676 = SEQ_PTR(_42active_references_63248)->length;
    }
    else {
        _31676 = 1;
    }
    _31677 = _file_no_64468 - _31676;
    _31676 = NOVALUE;
    _31678 = Repeat(_22209, _31677);
    _31677 = NOVALUE;
    Concat((object_ptr)&_42active_references_63248, _42active_references_63248, _31678);
    DeRefDS(_31678);
    _31678 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_42active_subprogs_63247)){
            _31680 = SEQ_PTR(_42active_subprogs_63247)->length;
    }
    else {
        _31680 = 1;
    }
    _31681 = _file_no_64468 - _31680;
    _31680 = NOVALUE;
    _31682 = Repeat(_22209, _31681);
    _31681 = NOVALUE;
    Concat((object_ptr)&_42active_subprogs_63247, _42active_subprogs_63247, _31682);
    DeRefDS(_31682);
    _31682 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31684 = (object)*(((s1_ptr)_2)->base + _file_no_64468);
    _sp_64482 = find_from(_27CurrentSub_20579, _31684, 1);
    _31684 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64482 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31687 = (object)*(((s1_ptr)_2)->base + _file_no_64468);
    if (IS_SEQUENCE(_31687) && IS_ATOM(_27CurrentSub_20579)) {
        Append(&_31688, _31687, _27CurrentSub_20579);
    }
    else if (IS_ATOM(_31687) && IS_SEQUENCE(_27CurrentSub_20579)) {
    }
    else {
        Concat((object_ptr)&_31688, _31687, _27CurrentSub_20579);
        _31687 = NOVALUE;
    }
    _31687 = NOVALUE;
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_subprogs_63247 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64468);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31688;
    if( _1 != _31688 ){
        DeRef(_1);
    }
    _31688 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31689 = (object)*(((s1_ptr)_2)->base + _file_no_64468);
    if (IS_SEQUENCE(_31689)){
            _sp_64482 = SEQ_PTR(_31689)->length;
    }
    else {
        _sp_64482 = 1;
    }
    _31689 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _31691 = (object)*(((s1_ptr)_2)->base + _file_no_64468);
    RefDS(_22209);
    Append(&_31692, _31691, _22209);
    _31691 = NOVALUE;
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63248 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64468);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31692;
    if( _1 != _31692 ){
        DeRef(_1);
    }
    _31692 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _42active_references_63248 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_64468 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31695 = (object)*(((s1_ptr)_2)->base + _sp_64482);
    _31693 = NOVALUE;
    if (IS_SEQUENCE(_31695) && IS_ATOM(_ref_64467)) {
        Append(&_31696, _31695, _ref_64467);
    }
    else if (IS_ATOM(_31695) && IS_SEQUENCE(_ref_64467)) {
    }
    else {
        Concat((object_ptr)&_31696, _31695, _ref_64467);
        _31695 = NOVALUE;
    }
    _31695 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64482);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31696;
    if( _1 != _31696 ){
        DeRef(_1);
    }
    _31696 = NOVALUE;
    _31693 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31689 = NOVALUE;
    return;
    ;
}


object _42resolve_file(object _refs_64519, object _report_errors_64520, object _unincluded_ok_64521)
{
    object _errors_64522 = NOVALUE;
    object _ref_64526 = NOVALUE;
    object _fr_64528 = NOVALUE;
    object _tok_64541 = NOVALUE;
    object _code_sub_64549 = NOVALUE;
    object _fr_type_64551 = NOVALUE;
    object _sym_tok_64553 = NOVALUE;
    object _31750 = NOVALUE;
    object _31749 = NOVALUE;
    object _31748 = NOVALUE;
    object _31747 = NOVALUE;
    object _31746 = NOVALUE;
    object _31745 = NOVALUE;
    object _31740 = NOVALUE;
    object _31739 = NOVALUE;
    object _31738 = NOVALUE;
    object _31736 = NOVALUE;
    object _31735 = NOVALUE;
    object _31732 = NOVALUE;
    object _31731 = NOVALUE;
    object _31730 = NOVALUE;
    object _31726 = NOVALUE;
    object _31725 = NOVALUE;
    object _31717 = NOVALUE;
    object _31715 = NOVALUE;
    object _31714 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31711 = NOVALUE;
    object _31710 = NOVALUE;
    object _31707 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_22209);
    DeRefi(_errors_64522);
    _errors_64522 = _22209;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64519)){
            _31707 = SEQ_PTR(_refs_64519)->length;
    }
    else {
        _31707 = 1;
    }
    {
        object _ar_64524;
        _ar_64524 = _31707;
L1: 
        if (_ar_64524 < 1){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64519);
        _ref_64526 = (object)*(((s1_ptr)_2)->base + _ar_64524);
        if (!IS_ATOM_INT(_ref_64526))
        _ref_64526 = (object)DBL_PTR(_ref_64526)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64528);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        _fr_64528 = (object)*(((s1_ptr)_2)->base + _ref_64526);
        Ref(_fr_64528);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64528);
        _31710 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!IS_ATOM_INT(_31710)){
            _31711 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31710)->dbl));
        }
        else{
            _31711 = (object)*(((s1_ptr)_2)->base + _31710);
        }
        _2 = (object)SEQ_PTR(_31711);
        _31712 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
        _31711 = NOVALUE;
        if (IS_ATOM_INT(_31712)) {
            _31713 = (_31712 == 0);
        }
        else {
            _31713 = binary_op(EQUALS, _31712, 0);
        }
        _31712 = NOVALUE;
        if (IS_ATOM_INT(_31713)) {
            if (_31713 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31713)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31715 = (_unincluded_ok_64521 == 0);
        if (_31715 == 0)
        {
            DeRef(_31715);
            _31715 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31715);
            _31715 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64528);
        _fr_64528 = NOVALUE;
        DeRef(_tok_64541);
        _tok_64541 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64528);
        _0 = _tok_64541;
        _tok_64541 = _42find_reference(_fr_64528);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64541);
        _31717 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31717, 509)){
            _31717 = NOVALUE;
            goto L5; // [100] 117
        }
        _31717 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64522, _errors_64522, _ref_64526);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64528);
        _fr_64528 = NOVALUE;
        DeRef(_tok_64541);
        _tok_64541 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64528);
        _code_sub_64549 = (object)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_64549))
        _code_sub_64549 = (object)DBL_PTR(_code_sub_64549)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64528);
        _fr_type_64551 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_64551))
        _fr_type_64551 = (object)DBL_PTR(_fr_type_64551)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64551;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64541);
            _31725 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_31725)){
                _31726 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31725)->dbl));
            }
            else{
                _31726 = (object)*(((s1_ptr)_2)->base + _31725);
            }
            _2 = (object)SEQ_PTR(_31726);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _sym_tok_64553 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _sym_tok_64553 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            if (!IS_ATOM_INT(_sym_tok_64553)){
                _sym_tok_64553 = (object)DBL_PTR(_sym_tok_64553)->dbl;
            }
            _31726 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64553 != 504)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64553 = 501;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64553 == _fr_type_64551)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31730 = (_sym_tok_64553 != 501);
            if (_31730 == 0) {
                goto L8; // [198] 219
            }
            _31732 = (_fr_type_64551 != 27);
            if (_31732 == 0)
            {
                DeRef(_31732);
                _31732 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31732);
                _31732 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64541);
            _42forward_error(_tok_64541, _ref_64526);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64553;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64541);
                _42patch_forward_call(_tok_64541, _ref_64526);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64541);
                _42forward_error(_tok_64541, _ref_64526);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64541);
            _31735 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_31735)){
                _31736 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31735)->dbl));
            }
            else{
                _31736 = (object)*(((s1_ptr)_2)->base + _31735);
            }
            _2 = (object)SEQ_PTR(_31736);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _sym_tok_64553 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _sym_tok_64553 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            if (!IS_ATOM_INT(_sym_tok_64553)){
                _sym_tok_64553 = (object)DBL_PTR(_sym_tok_64553)->dbl;
            }
            _31736 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64541);
            _31738 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_31738)){
                _31739 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31738)->dbl));
            }
            else{
                _31739 = (object)*(((s1_ptr)_2)->base + _31738);
            }
            _2 = (object)SEQ_PTR(_31739);
            _31740 = (object)*(((s1_ptr)_2)->base + 4);
            _31739 = NOVALUE;
            if (binary_op_a(NOTEQ, _31740, 9)){
                _31740 = NOVALUE;
                goto LA; // [306] 323
            }
            _31740 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64522, _errors_64522, _ref_64526);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64528);
            _fr_64528 = NOVALUE;
            DeRef(_tok_64541);
            _tok_64541 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64553;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64541);
                _42patch_forward_variable(_tok_64541, _ref_64526);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64541);
                _42forward_error(_tok_64541, _ref_64526);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64541);
            _42patch_forward_type_check(_tok_64541, _ref_64526);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64541);
            _42patch_forward_init_check(_tok_64541, _ref_64526);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64541);
            _42patch_forward_case(_tok_64541, _ref_64526);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64541);
            _42patch_forward_type(_tok_64541, _ref_64526);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64541);
            _42patch_forward_goto(_tok_64541, _ref_64526);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64528);
            _31745 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_fr_64528);
            _31746 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_31746);
            Ref(_31745);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31745;
            ((intptr_t *)_2)[2] = _31746;
            _31747 = MAKE_SEQ(_1);
            _31746 = NOVALUE;
            _31745 = NOVALUE;
            _49InternalErr(263, _31747);
            _31747 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64520 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        _31749 = (object)*(((s1_ptr)_2)->base + _ref_64526);
        _31750 = IS_SEQUENCE(_31749);
        _31749 = NOVALUE;
        if (_31750 == 0)
        {
            _31750 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31750 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64522, _errors_64522, _ref_64526);
LB: 
        DeRef(_fr_64528);
        _fr_64528 = NOVALUE;
        DeRef(_tok_64541);
        _tok_64541 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64524 = _ar_64524 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64519);
    _31738 = NOVALUE;
    _31725 = NOVALUE;
    _31710 = NOVALUE;
    DeRef(_31713);
    _31713 = NOVALUE;
    DeRef(_31730);
    _31730 = NOVALUE;
    _31735 = NOVALUE;
    return _errors_64522;
    ;
}


object _42file_name_based_symindex_compare(object _si1_64631, object _si2_64632)
{
    object _fn1_64653 = NOVALUE;
    object _fn2_64658 = NOVALUE;
    object _31779 = NOVALUE;
    object _31778 = NOVALUE;
    object _31777 = NOVALUE;
    object _31776 = NOVALUE;
    object _31775 = NOVALUE;
    object _31774 = NOVALUE;
    object _31773 = NOVALUE;
    object _31772 = NOVALUE;
    object _31771 = NOVALUE;
    object _31770 = NOVALUE;
    object _31769 = NOVALUE;
    object _31768 = NOVALUE;
    object _31766 = NOVALUE;
    object _31764 = NOVALUE;
    object _31763 = NOVALUE;
    object _31762 = NOVALUE;
    object _31761 = NOVALUE;
    object _31760 = NOVALUE;
    object _31759 = NOVALUE;
    object _31758 = NOVALUE;
    object _31757 = NOVALUE;
    object _31756 = NOVALUE;
    object _31755 = NOVALUE;
    object _31753 = NOVALUE;
    object _31752 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64631)) {
        _1 = (object)(DBL_PTR(_si1_64631)->dbl);
        DeRefDS(_si1_64631);
        _si1_64631 = _1;
    }
    if (!IS_ATOM_INT(_si2_64632)) {
        _1 = (object)(DBL_PTR(_si2_64632)->dbl);
        DeRefDS(_si2_64632);
        _si2_64632 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31752 = _27symtab_index(_si1_64631);
    if (IS_ATOM_INT(_31752)) {
        _31753 = (_31752 == 0);
    }
    else {
        _31753 = unary_op(NOT, _31752);
    }
    DeRef(_31752);
    _31752 = NOVALUE;
    if (IS_ATOM_INT(_31753)) {
        if (_31753 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31753)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31755 = _27symtab_index(_si2_64632);
    if (IS_ATOM_INT(_31755)) {
        _31756 = (_31755 == 0);
    }
    else {
        _31756 = unary_op(NOT, _31755);
    }
    DeRef(_31755);
    _31755 = NOVALUE;
    if (_31756 == 0) {
        DeRef(_31756);
        _31756 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31756) && DBL_PTR(_31756)->dbl == 0.0){
            DeRef(_31756);
            _31756 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31756);
        _31756 = NOVALUE;
    }
    DeRef(_31756);
    _31756 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31753);
    _31753 = NOVALUE;
    return 1;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31757 = (object)*(((s1_ptr)_2)->base + _si1_64631);
    if (IS_SEQUENCE(_31757)){
            _31758 = SEQ_PTR(_31757)->length;
    }
    else {
        _31758 = 1;
    }
    _31757 = NOVALUE;
    if (IS_ATOM_INT(_27S_FILE_NO_20205)) {
        _31759 = (_27S_FILE_NO_20205 <= _31758);
    }
    else {
        _31759 = binary_op(LESSEQ, _27S_FILE_NO_20205, _31758);
    }
    _31758 = NOVALUE;
    if (IS_ATOM_INT(_31759)) {
        if (_31759 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31759)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31761 = (object)*(((s1_ptr)_2)->base + _si2_64632);
    if (IS_SEQUENCE(_31761)){
            _31762 = SEQ_PTR(_31761)->length;
    }
    else {
        _31762 = 1;
    }
    _31761 = NOVALUE;
    if (IS_ATOM_INT(_27S_FILE_NO_20205)) {
        _31763 = (_27S_FILE_NO_20205 <= _31762);
    }
    else {
        _31763 = binary_op(LESSEQ, _27S_FILE_NO_20205, _31762);
    }
    _31762 = NOVALUE;
    if (_31763 == 0) {
        DeRef(_31763);
        _31763 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31763) && DBL_PTR(_31763)->dbl == 0.0){
            DeRef(_31763);
            _31763 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31763);
        _31763 = NOVALUE;
    }
    DeRef(_31763);
    _31763 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31764 = (object)*(((s1_ptr)_2)->base + _si1_64631);
    _2 = (object)SEQ_PTR(_31764);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _fn1_64653 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _fn1_64653 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_fn1_64653)){
        _fn1_64653 = (object)DBL_PTR(_fn1_64653)->dbl;
    }
    _31764 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31766 = (object)*(((s1_ptr)_2)->base + _si2_64632);
    _2 = (object)SEQ_PTR(_31766);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _fn2_64658 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _fn2_64658 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_fn2_64658)){
        _fn2_64658 = (object)DBL_PTR(_fn2_64658)->dbl;
    }
    _31766 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64653;
    ((intptr_t *)_2)[2] = _fn2_64658;
    _31768 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_28known_files_11573)){
            _31769 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31769 = 1;
    }
    _31770 = binary_op(GREATER, _31768, _31769);
    DeRefDS(_31768);
    _31768 = NOVALUE;
    _31769 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64653;
    ((intptr_t *)_2)[2] = _fn2_64658;
    _31771 = MAKE_SEQ(_1);
    _31772 = binary_op(LESSEQ, _31771, 0);
    DeRefDS(_31771);
    _31771 = NOVALUE;
    _31773 = binary_op(OR, _31770, _31772);
    DeRefDS(_31770);
    _31770 = NOVALUE;
    DeRefDS(_31772);
    _31772 = NOVALUE;
    _31774 = find_from(1, _31773, 1);
    DeRefDS(_31773);
    _31773 = NOVALUE;
    if (_31774 == 0)
    {
        _31774 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31774 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    DeRef(_31759);
    _31759 = NOVALUE;
    _31757 = NOVALUE;
    DeRef(_31753);
    _31753 = NOVALUE;
    _31761 = NOVALUE;
    return 1;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31775 = (object)*(((s1_ptr)_2)->base + _fn1_64653);
    Ref(_31775);
    RefDS(_22209);
    _31776 = _15abbreviate_path(_31775, _22209);
    _31775 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _31777 = (object)*(((s1_ptr)_2)->base + _fn2_64658);
    Ref(_31777);
    RefDS(_22209);
    _31778 = _15abbreviate_path(_31777, _22209);
    _31777 = NOVALUE;
    if (IS_ATOM_INT(_31776) && IS_ATOM_INT(_31778)){
        _31779 = (_31776 < _31778) ? -1 : (_31776 > _31778);
    }
    else{
        _31779 = compare(_31776, _31778);
    }
    DeRef(_31776);
    _31776 = NOVALUE;
    DeRef(_31778);
    _31778 = NOVALUE;
    DeRef(_31759);
    _31759 = NOVALUE;
    _31757 = NOVALUE;
    DeRef(_31753);
    _31753 = NOVALUE;
    _31761 = NOVALUE;
    return _31779;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    DeRef(_31759);
    _31759 = NOVALUE;
    _31757 = NOVALUE;
    DeRef(_31753);
    _31753 = NOVALUE;
    _31761 = NOVALUE;
    return 1;
L5: 
    ;
}


void _42Resolve_forward_references(object _report_errors_64684)
{
    object _errors_64685 = NOVALUE;
    object _unincluded_ok_64686 = NOVALUE;
    object _msg_64747 = NOVALUE;
    object _errloc_64748 = NOVALUE;
    object _ref_64753 = NOVALUE;
    object _tok_64769 = NOVALUE;
    object _THIS_SCOPE_64771 = NOVALUE;
    object _THESE_GLOBALS_64772 = NOVALUE;
    object _syms_64830 = NOVALUE;
    object _s_64851 = NOVALUE;
    object _31912 = NOVALUE;
    object _31911 = NOVALUE;
    object _31910 = NOVALUE;
    object _31908 = NOVALUE;
    object _31903 = NOVALUE;
    object _31900 = NOVALUE;
    object _31898 = NOVALUE;
    object _31897 = NOVALUE;
    object _31896 = NOVALUE;
    object _31895 = NOVALUE;
    object _31894 = NOVALUE;
    object _31893 = NOVALUE;
    object _31892 = NOVALUE;
    object _31890 = NOVALUE;
    object _31889 = NOVALUE;
    object _31888 = NOVALUE;
    object _31886 = NOVALUE;
    object _31884 = NOVALUE;
    object _31883 = NOVALUE;
    object _31882 = NOVALUE;
    object _31881 = NOVALUE;
    object _31880 = NOVALUE;
    object _31879 = NOVALUE;
    object _31876 = NOVALUE;
    object _31872 = NOVALUE;
    object _31871 = NOVALUE;
    object _31870 = NOVALUE;
    object _31869 = NOVALUE;
    object _31868 = NOVALUE;
    object _31867 = NOVALUE;
    object _31864 = NOVALUE;
    object _31863 = NOVALUE;
    object _31862 = NOVALUE;
    object _31861 = NOVALUE;
    object _31860 = NOVALUE;
    object _31859 = NOVALUE;
    object _31856 = NOVALUE;
    object _31855 = NOVALUE;
    object _31854 = NOVALUE;
    object _31853 = NOVALUE;
    object _31852 = NOVALUE;
    object _31851 = NOVALUE;
    object _31850 = NOVALUE;
    object _31849 = NOVALUE;
    object _31848 = NOVALUE;
    object _31847 = NOVALUE;
    object _31844 = NOVALUE;
    object _31842 = NOVALUE;
    object _31839 = NOVALUE;
    object _31837 = NOVALUE;
    object _31835 = NOVALUE;
    object _31834 = NOVALUE;
    object _31832 = NOVALUE;
    object _31831 = NOVALUE;
    object _31830 = NOVALUE;
    object _31829 = NOVALUE;
    object _31828 = NOVALUE;
    object _31826 = NOVALUE;
    object _31825 = NOVALUE;
    object _31823 = NOVALUE;
    object _31822 = NOVALUE;
    object _31820 = NOVALUE;
    object _31819 = NOVALUE;
    object _31817 = NOVALUE;
    object _31816 = NOVALUE;
    object _31815 = NOVALUE;
    object _31814 = NOVALUE;
    object _31813 = NOVALUE;
    object _31812 = NOVALUE;
    object _31811 = NOVALUE;
    object _31810 = NOVALUE;
    object _31809 = NOVALUE;
    object _31808 = NOVALUE;
    object _31807 = NOVALUE;
    object _31806 = NOVALUE;
    object _31805 = NOVALUE;
    object _31804 = NOVALUE;
    object _31803 = NOVALUE;
    object _31802 = NOVALUE;
    object _31800 = NOVALUE;
    object _31799 = NOVALUE;
    object _31798 = NOVALUE;
    object _31797 = NOVALUE;
    object _31795 = NOVALUE;
    object _31794 = NOVALUE;
    object _31792 = NOVALUE;
    object _31791 = NOVALUE;
    object _31790 = NOVALUE;
    object _31789 = NOVALUE;
    object _31787 = NOVALUE;
    object _31786 = NOVALUE;
    object _31785 = NOVALUE;
    object _31784 = NOVALUE;
    object _31782 = NOVALUE;
    object _31781 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_22209);
    DeRef(_errors_64685);
    _errors_64685 = _22209;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64686 = _53get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64686)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64686)->dbl);
        DeRefDS(_unincluded_ok_64686);
        _unincluded_ok_64686 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_42active_references_63248)){
            _31781 = SEQ_PTR(_42active_references_63248)->length;
    }
    else {
        _31781 = 1;
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _31782 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31782 = 1;
    }
    if (_31781 >= _31782)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _31784 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31784 = 1;
    }
    if (IS_SEQUENCE(_42active_references_63248)){
            _31785 = SEQ_PTR(_42active_references_63248)->length;
    }
    else {
        _31785 = 1;
    }
    _31786 = _31784 - _31785;
    _31784 = NOVALUE;
    _31785 = NOVALUE;
    _31787 = Repeat(_22209, _31786);
    _31786 = NOVALUE;
    Concat((object_ptr)&_42active_references_63248, _42active_references_63248, _31787);
    DeRefDS(_31787);
    _31787 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _31789 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31789 = 1;
    }
    if (IS_SEQUENCE(_42active_subprogs_63247)){
            _31790 = SEQ_PTR(_42active_subprogs_63247)->length;
    }
    else {
        _31790 = 1;
    }
    _31791 = _31789 - _31790;
    _31789 = NOVALUE;
    _31790 = NOVALUE;
    _31792 = Repeat(_22209, _31791);
    _31791 = NOVALUE;
    Concat((object_ptr)&_42active_subprogs_63247, _42active_subprogs_63247, _31792);
    DeRefDS(_31792);
    _31792 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_42toplevel_references_63249)){
            _31794 = SEQ_PTR(_42toplevel_references_63249)->length;
    }
    else {
        _31794 = 1;
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _31795 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31795 = 1;
    }
    if (_31794 >= _31795)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _31797 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _31797 = 1;
    }
    if (IS_SEQUENCE(_42toplevel_references_63249)){
            _31798 = SEQ_PTR(_42toplevel_references_63249)->length;
    }
    else {
        _31798 = 1;
    }
    _31799 = _31797 - _31798;
    _31797 = NOVALUE;
    _31798 = NOVALUE;
    _31800 = Repeat(_22209, _31799);
    _31799 = NOVALUE;
    Concat((object_ptr)&_42toplevel_references_63249, _42toplevel_references_63249, _31800);
    DeRefDS(_31800);
    _31800 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_42active_subprogs_63247)){
            _31802 = SEQ_PTR(_42active_subprogs_63247)->length;
    }
    else {
        _31802 = 1;
    }
    {
        object _i_64718;
        _i_64718 = 1;
L3: 
        if (_i_64718 > _31802){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_42active_subprogs_63247);
        _31803 = (object)*(((s1_ptr)_2)->base + _i_64718);
        if (IS_SEQUENCE(_31803)){
                _31804 = SEQ_PTR(_31803)->length;
        }
        else {
            _31804 = 1;
        }
        _31803 = NOVALUE;
        if (_31804 != 0) {
            _31805 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_42toplevel_references_63249);
        _31806 = (object)*(((s1_ptr)_2)->base + _i_64718);
        if (IS_SEQUENCE(_31806)){
                _31807 = SEQ_PTR(_31806)->length;
        }
        else {
            _31807 = 1;
        }
        _31806 = NOVALUE;
        _31805 = (_31807 != 0);
L5: 
        if (_31805 == 0) {
            goto L6; // [171] 273
        }
        _31809 = (_i_64718 == _27current_file_no_20571);
        if (_31809 != 0) {
            _31810 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        _31811 = (object)*(((s1_ptr)_2)->base + _i_64718);
        _31810 = (_31811 != 0);
L7: 
        if (_31810 != 0) {
            DeRef(_31812);
            _31812 = 1;
            goto L8; // [195] 203
        }
        _31812 = (_unincluded_ok_64686 != 0);
L8: 
        if (_31812 == 0)
        {
            _31812 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31812 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_42active_references_63248);
        _31813 = (object)*(((s1_ptr)_2)->base + _i_64718);
        if (IS_SEQUENCE(_31813)){
                _31814 = SEQ_PTR(_31813)->length;
        }
        else {
            _31814 = 1;
        }
        _31813 = NOVALUE;
        {
            object _j_64734;
            _j_64734 = _31814;
L9: 
            if (_j_64734 < 1){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_42active_references_63248);
            _31815 = (object)*(((s1_ptr)_2)->base + _i_64718);
            _2 = (object)SEQ_PTR(_31815);
            _31816 = (object)*(((s1_ptr)_2)->base + _j_64734);
            _31815 = NOVALUE;
            Ref(_31816);
            _31817 = _42resolve_file(_31816, _report_errors_64684, _unincluded_ok_64686);
            _31816 = NOVALUE;
            if (IS_SEQUENCE(_errors_64685) && IS_ATOM(_31817)) {
                Ref(_31817);
                Append(&_errors_64685, _errors_64685, _31817);
            }
            else if (IS_ATOM(_errors_64685) && IS_SEQUENCE(_31817)) {
            }
            else {
                Concat((object_ptr)&_errors_64685, _errors_64685, _31817);
            }
            DeRef(_31817);
            _31817 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64734 = _j_64734 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_42toplevel_references_63249);
        _31819 = (object)*(((s1_ptr)_2)->base + _i_64718);
        Ref(_31819);
        _31820 = _42resolve_file(_31819, _report_errors_64684, _unincluded_ok_64686);
        _31819 = NOVALUE;
        if (IS_SEQUENCE(_errors_64685) && IS_ATOM(_31820)) {
            Ref(_31820);
            Append(&_errors_64685, _errors_64685, _31820);
        }
        else if (IS_ATOM(_errors_64685) && IS_SEQUENCE(_31820)) {
        }
        else {
            Concat((object_ptr)&_errors_64685, _errors_64685, _31820);
        }
        DeRef(_31820);
        _31820 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64718 = _i_64718 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64684 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64685)){
            _31823 = SEQ_PTR(_errors_64685)->length;
    }
    else {
        _31823 = 1;
    }
    if (_31823 == 0)
    {
        _31823 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31823 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_22209);
    DeRefi(_msg_64747);
    _msg_64747 = _22209;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31824);
    DeRefi(_errloc_64748);
    _errloc_64748 = _31824;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64685)){
            _31825 = SEQ_PTR(_errors_64685)->length;
    }
    else {
        _31825 = 1;
    }
    {
        object _e_64751;
        _e_64751 = _31825;
LC: 
        if (_e_64751 < 1){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64685);
        _31826 = (object)*(((s1_ptr)_2)->base + _e_64751);
        DeRef(_ref_64753);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!IS_ATOM_INT(_31826)){
            _ref_64753 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31826)->dbl));
        }
        else{
            _ref_64753 = (object)*(((s1_ptr)_2)->base + _31826);
        }
        Ref(_ref_64753);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64753);
        _31828 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31828)) {
            _31829 = (_31828 == 65);
        }
        else {
            _31829 = binary_op(EQUALS, _31828, 65);
        }
        _31828 = NOVALUE;
        if (IS_ATOM_INT(_31829)) {
            if (_31829 == 0) {
                DeRef(_31830);
                _31830 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31829)->dbl == 0.0) {
                DeRef(_31830);
                _31830 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64753);
        _31831 = (object)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31831)) {
            _31832 = (_31831 == 65);
        }
        else {
            _31832 = binary_op(EQUALS, _31831, 65);
        }
        _31831 = NOVALUE;
        DeRef(_31830);
        if (IS_ATOM_INT(_31832))
        _31830 = (_31832 != 0);
        else
        _31830 = DBL_PTR(_31832)->dbl != 0.0;
LE: 
        if (_31830 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64753);
        _31834 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31834)) {
            _31835 = (_31834 == 109);
        }
        else {
            _31835 = binary_op(EQUALS, _31834, 109);
        }
        _31834 = NOVALUE;
        if (_31835 == 0) {
            DeRef(_31835);
            _31835 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31835) && DBL_PTR(_31835)->dbl == 0.0){
                DeRef(_31835);
                _31835 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31835);
            _31835 = NOVALUE;
        }
        DeRef(_31835);
        _31835 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64753);
        _ref_64753 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64753);
        _0 = _tok_64769;
        _tok_64769 = _42find_reference(_ref_64753);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64771 = 3;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64772 = 4;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64769);
        _31837 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31837, 509)){
            _31837 = NOVALUE;
            goto L13; // [417] 760
        }
        _31837 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64769);
        _31839 = (object)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31839) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31839)){
            if( (DBL_PTR(_31839)->dbl != (eudouble) ((object) DBL_PTR(_31839)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31839)->dbl;
        }
        else {
            _0 = _31839;
        };
        _31839 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64753);
            _31842 = (object)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31842, -1)){
                _31842 = NOVALUE;
                goto L15; // [442] 556
            }
            _31842 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64753);
            _31844 = (object)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31844, 0)){
                _31844 = NOVALUE;
                goto L16; // [452] 517
            }
            _31844 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64753);
            _31847 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64753);
            _31848 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31848)){
                _31849 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31848)->dbl));
            }
            else{
                _31849 = (object)*(((s1_ptr)_2)->base + _31848);
            }
            Ref(_31849);
            RefDS(_22209);
            _31850 = _15abbreviate_path(_31849, _22209);
            _31849 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64753);
            _31851 = (object)*(((s1_ptr)_2)->base + 6);
            _2 = (object)SEQ_PTR(_ref_64753);
            _31852 = (object)*(((s1_ptr)_2)->base + 9);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31852)){
                _31853 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31852)->dbl));
            }
            else{
                _31853 = (object)*(((s1_ptr)_2)->base + _31852);
            }
            Ref(_31853);
            RefDS(_22209);
            _31854 = _15abbreviate_path(_31853, _22209);
            _31853 = NOVALUE;
            _31855 = _14find_replace(92, _31854, 47, 0);
            _31854 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31847);
            ((intptr_t*)_2)[1] = _31847;
            ((intptr_t*)_2)[2] = _31850;
            Ref(_31851);
            ((intptr_t*)_2)[3] = _31851;
            ((intptr_t*)_2)[4] = _31855;
            _31856 = MAKE_SEQ(_1);
            _31855 = NOVALUE;
            _31851 = NOVALUE;
            _31850 = NOVALUE;
            _31847 = NOVALUE;
            DeRefi(_errloc_64748);
            _errloc_64748 = EPrintf(-9999999, _31846, _31856);
            DeRefDS(_31856);
            _31856 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64753);
            _31859 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64753);
            _31860 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31860)){
                _31861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31860)->dbl));
            }
            else{
                _31861 = (object)*(((s1_ptr)_2)->base + _31860);
            }
            Ref(_31861);
            RefDS(_22209);
            _31862 = _15abbreviate_path(_31861, _22209);
            _31861 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64753);
            _31863 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31859);
            ((intptr_t*)_2)[1] = _31859;
            ((intptr_t*)_2)[2] = _31862;
            Ref(_31863);
            ((intptr_t*)_2)[3] = _31863;
            _31864 = MAKE_SEQ(_1);
            _31863 = NOVALUE;
            _31862 = NOVALUE;
            _31859 = NOVALUE;
            DeRefi(_errloc_64748);
            _errloc_64748 = EPrintf(-9999999, _31858, _31864);
            DeRefDS(_31864);
            _31864 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64753);
            _31867 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64753);
            _31868 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31868)){
                _31869 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31868)->dbl));
            }
            else{
                _31869 = (object)*(((s1_ptr)_2)->base + _31868);
            }
            Ref(_31869);
            RefDS(_22209);
            _31870 = _15abbreviate_path(_31869, _22209);
            _31869 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64753);
            _31871 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31867);
            ((intptr_t*)_2)[1] = _31867;
            ((intptr_t*)_2)[2] = _31870;
            Ref(_31871);
            ((intptr_t*)_2)[3] = _31871;
            _31872 = MAKE_SEQ(_1);
            _31871 = NOVALUE;
            _31870 = NOVALUE;
            _31867 = NOVALUE;
            DeRefi(_errloc_64748);
            _errloc_64748 = EPrintf(-9999999, _31866, _31872);
            DeRefDS(_31872);
            _31872 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64830);
            _2 = (object)SEQ_PTR(_tok_64769);
            _syms_64830 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64772);
            Ref(_syms_64830);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31876 = CRoutineId(1385, 42, _31875);
            RefDS(_syms_64830);
            RefDS(_22209);
            _0 = _syms_64830;
            _syms_64830 = _25custom_sort(_31876, _syms_64830, _22209, 1);
            DeRefDS(_0);
            _31876 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64753);
            _31879 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_ref_64753);
            _31880 = (object)*(((s1_ptr)_2)->base + 3);
            _2 = (object)SEQ_PTR(_28known_files_11573);
            if (!IS_ATOM_INT(_31880)){
                _31881 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31880)->dbl));
            }
            else{
                _31881 = (object)*(((s1_ptr)_2)->base + _31880);
            }
            Ref(_31881);
            RefDS(_22209);
            _31882 = _15abbreviate_path(_31881, _22209);
            _31881 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64753);
            _31883 = (object)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31879);
            ((intptr_t*)_2)[1] = _31879;
            ((intptr_t*)_2)[2] = _31882;
            Ref(_31883);
            ((intptr_t*)_2)[3] = _31883;
            _31884 = MAKE_SEQ(_1);
            _31883 = NOVALUE;
            _31882 = NOVALUE;
            _31879 = NOVALUE;
            DeRefi(_errloc_64748);
            _errloc_64748 = EPrintf(-9999999, _31878, _31884);
            DeRefDS(_31884);
            _31884 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64830)){
                    _31886 = SEQ_PTR(_syms_64830)->length;
            }
            else {
                _31886 = 1;
            }
            {
                object _si_64848;
                _si_64848 = 1;
L18: 
                if (_si_64848 > _31886){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64830);
                _s_64851 = (object)*(((s1_ptr)_2)->base + _si_64848);
                if (!IS_ATOM_INT(_s_64851)){
                    _s_64851 = (object)DBL_PTR(_s_64851)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64753);
                _31888 = (object)*(((s1_ptr)_2)->base + 2);
                _31889 = _53sym_name(_s_64851);
                if (_31888 == _31889)
                _31890 = 1;
                else if (IS_ATOM_INT(_31888) && IS_ATOM_INT(_31889))
                _31890 = 0;
                else
                _31890 = (compare(_31888, _31889) == 0);
                _31888 = NOVALUE;
                DeRef(_31889);
                _31889 = NOVALUE;
                if (_31890 == 0)
                {
                    _31890 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31890 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _31892 = (object)*(((s1_ptr)_2)->base + _s_64851);
                _2 = (object)SEQ_PTR(_31892);
                if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
                    _31893 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
                }
                else{
                    _31893 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
                }
                _31892 = NOVALUE;
                _2 = (object)SEQ_PTR(_28known_files_11573);
                if (!IS_ATOM_INT(_31893)){
                    _31894 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31893)->dbl));
                }
                else{
                    _31894 = (object)*(((s1_ptr)_2)->base + _31893);
                }
                Ref(_31894);
                RefDS(_22209);
                _31895 = _15abbreviate_path(_31894, _22209);
                _31894 = NOVALUE;
                _31896 = _14find_replace(92, _31895, 47, 0);
                _31895 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31896;
                _31897 = MAKE_SEQ(_1);
                _31896 = NOVALUE;
                _31898 = EPrintf(-9999999, _31891, _31897);
                DeRefDS(_31897);
                _31897 = NOVALUE;
                Concat((object_ptr)&_errloc_64748, _errloc_64748, _31898);
                DeRefDS(_31898);
                _31898 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64848 = _si_64848 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64830);
            _syms_64830 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31900 = e_match_from(_errloc_64748, _msg_64747, 1);
        if (_31900 != 0)
        goto L1B; // [767] 786
        _31900 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64747, _msg_64747, _errloc_64748);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64685);
        _31903 = (object)*(((s1_ptr)_2)->base + _e_64751);
        Ref(_31903);
        _42prep_forward_error(_31903);
        _31903 = NOVALUE;
L1B: 
        DeRef(_tok_64769);
        _tok_64769 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_49ThisLine_49642);
        _2 = (object)SEQ_PTR(_ref_64753);
        _49ThisLine_49642 = (object)*(((s1_ptr)_2)->base + 7);
        Ref(_49ThisLine_49642);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64753);
        _49bp_49646 = (object)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_49bp_49646)){
            _49bp_49646 = (object)DBL_PTR(_49bp_49646)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64753);
        _27CurrentSub_20579 = (object)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_27CurrentSub_20579)){
            _27CurrentSub_20579 = (object)DBL_PTR(_27CurrentSub_20579)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64753);
        _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_27line_number_20572)){
            _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
        }
        DeRefDS(_ref_64753);
        _ref_64753 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64751 = _e_64751 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64747)){
            _31908 = SEQ_PTR(_msg_64747)->length;
    }
    else {
        _31908 = 1;
    }
    if (_31908 <= 0)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64747);
    ((intptr_t*)_2)[1] = _msg_64747;
    _31910 = MAKE_SEQ(_1);
    _49CompileErr(74, _31910, 0);
    _31910 = NOVALUE;
L1C: 
    DeRefi(_msg_64747);
    _msg_64747 = NOVALUE;
    DeRefi(_errloc_64748);
    _errloc_64748 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64684 == 0) {
        goto L1E; // [858] 900
    }
    _31912 = (0 == 0);
    if (_31912 == 0)
    {
        DeRef(_31912);
        _31912 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31912);
        _31912 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_22209);
    DeRef(_42forward_references_63246);
    _42forward_references_63246 = _22209;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_22209);
    DeRef(_42active_references_63248);
    _42active_references_63248 = _22209;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_22209);
    DeRef(_42toplevel_references_63249);
    _42toplevel_references_63249 = _22209;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_22209);
    DeRef(_42inactive_references_63250);
    _42inactive_references_63250 = _22209;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _45clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64685);
    _31826 = NOVALUE;
    DeRef(_31809);
    _31809 = NOVALUE;
    _31868 = NOVALUE;
    _31803 = NOVALUE;
    _31852 = NOVALUE;
    _31813 = NOVALUE;
    _31880 = NOVALUE;
    DeRef(_31832);
    _31832 = NOVALUE;
    _31848 = NOVALUE;
    _31893 = NOVALUE;
    _31860 = NOVALUE;
    _31811 = NOVALUE;
    DeRef(_31829);
    _31829 = NOVALUE;
    _31806 = NOVALUE;
    return;
    ;
}


void _42shift_these(object _refs_64899, object _pc_64900, object _amount_64901)
{
    object _fr_64905 = NOVALUE;
    object _31930 = NOVALUE;
    object _31929 = NOVALUE;
    object _31928 = NOVALUE;
    object _31927 = NOVALUE;
    object _31926 = NOVALUE;
    object _31925 = NOVALUE;
    object _31924 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31921 = NOVALUE;
    object _31919 = NOVALUE;
    object _31917 = NOVALUE;
    object _31916 = NOVALUE;
    object _31914 = NOVALUE;
    object _31913 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64899)){
            _31913 = SEQ_PTR(_refs_64899)->length;
    }
    else {
        _31913 = 1;
    }
    {
        object _i_64903;
        _i_64903 = _31913;
L1: 
        if (_i_64903 < 1){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64899);
        _31914 = (object)*(((s1_ptr)_2)->base + _i_64903);
        DeRef(_fr_64905);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!IS_ATOM_INT(_31914)){
            _fr_64905 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31914)->dbl));
        }
        else{
            _fr_64905 = (object)*(((s1_ptr)_2)->base + _31914);
        }
        Ref(_fr_64905);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64899);
        _31916 = (object)*(((s1_ptr)_2)->base + _i_64903);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63246 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31916))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31916)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31916);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64905);
        _31917 = (object)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31917, _42shifting_sub_63265)){
            _31917 = NOVALUE;
            goto L3; // [53] 126
        }
        _31917 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64905);
        _31919 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31919, _pc_64900)){
            _31919 = NOVALUE;
            goto L4; // [63] 125
        }
        _31919 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64905);
        _31921 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31921)) {
            _31922 = _31921 + _amount_64901;
            if ((object)((uintptr_t)_31922 + (uintptr_t)HIGH_BITS) >= 0){
                _31922 = NewDouble((eudouble)_31922);
            }
        }
        else {
            _31922 = binary_op(PLUS, _31921, _amount_64901);
        }
        _31921 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64905);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64905 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31922;
        if( _1 != _31922 ){
            DeRef(_1);
        }
        _31922 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64905);
        _31923 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31923)) {
            _31924 = (_31923 == 186);
        }
        else {
            _31924 = binary_op(EQUALS, _31923, 186);
        }
        _31923 = NOVALUE;
        if (IS_ATOM_INT(_31924)) {
            if (_31924 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31924)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64905);
        _31926 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31926)) {
            _31927 = (_31926 >= _pc_64900);
        }
        else {
            _31927 = binary_op(GREATEREQ, _31926, _pc_64900);
        }
        _31926 = NOVALUE;
        if (_31927 == 0) {
            DeRef(_31927);
            _31927 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31927) && DBL_PTR(_31927)->dbl == 0.0){
                DeRef(_31927);
                _31927 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31927);
            _31927 = NOVALUE;
        }
        DeRef(_31927);
        _31927 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64905);
        _31928 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31928)) {
            _31929 = _31928 + _amount_64901;
            if ((object)((uintptr_t)_31929 + (uintptr_t)HIGH_BITS) >= 0){
                _31929 = NewDouble((eudouble)_31929);
            }
        }
        else {
            _31929 = binary_op(PLUS, _31928, _amount_64901);
        }
        _31928 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64905);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64905 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31929;
        if( _1 != _31929 ){
            DeRef(_1);
        }
        _31929 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64899);
        _31930 = (object)*(((s1_ptr)_2)->base + _i_64903);
        RefDS(_fr_64905);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63246 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31930))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31930)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31930);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64905;
        DeRef(_1);
        DeRefDS(_fr_64905);
        _fr_64905 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64903 = _i_64903 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64899);
    DeRef(_31924);
    _31924 = NOVALUE;
    _31914 = NOVALUE;
    _31916 = NOVALUE;
    _31930 = NOVALUE;
    return;
    ;
}


void _42shift_top(object _refs_64929, object _pc_64930, object _amount_64931)
{
    object _fr_64935 = NOVALUE;
    object _31946 = NOVALUE;
    object _31945 = NOVALUE;
    object _31944 = NOVALUE;
    object _31943 = NOVALUE;
    object _31942 = NOVALUE;
    object _31941 = NOVALUE;
    object _31940 = NOVALUE;
    object _31939 = NOVALUE;
    object _31938 = NOVALUE;
    object _31937 = NOVALUE;
    object _31935 = NOVALUE;
    object _31934 = NOVALUE;
    object _31932 = NOVALUE;
    object _31931 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64929)){
            _31931 = SEQ_PTR(_refs_64929)->length;
    }
    else {
        _31931 = 1;
    }
    {
        object _i_64933;
        _i_64933 = _31931;
L1: 
        if (_i_64933 < 1){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64929);
        _31932 = (object)*(((s1_ptr)_2)->base + _i_64933);
        DeRef(_fr_64935);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!IS_ATOM_INT(_31932)){
            _fr_64935 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31932)->dbl));
        }
        else{
            _fr_64935 = (object)*(((s1_ptr)_2)->base + _31932);
        }
        Ref(_fr_64935);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64929);
        _31934 = (object)*(((s1_ptr)_2)->base + _i_64933);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63246 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31934))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31934)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31934);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64935);
        _31935 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31935, _pc_64930)){
            _31935 = NOVALUE;
            goto L3; // [51] 113
        }
        _31935 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64935);
        _31937 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31937)) {
            _31938 = _31937 + _amount_64931;
            if ((object)((uintptr_t)_31938 + (uintptr_t)HIGH_BITS) >= 0){
                _31938 = NewDouble((eudouble)_31938);
            }
        }
        else {
            _31938 = binary_op(PLUS, _31937, _amount_64931);
        }
        _31937 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64935);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64935 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31938;
        if( _1 != _31938 ){
            DeRef(_1);
        }
        _31938 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64935);
        _31939 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31939)) {
            _31940 = (_31939 == 186);
        }
        else {
            _31940 = binary_op(EQUALS, _31939, 186);
        }
        _31939 = NOVALUE;
        if (IS_ATOM_INT(_31940)) {
            if (_31940 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31940)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_64935);
        _31942 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31942)) {
            _31943 = (_31942 >= _pc_64930);
        }
        else {
            _31943 = binary_op(GREATEREQ, _31942, _pc_64930);
        }
        _31942 = NOVALUE;
        if (_31943 == 0) {
            DeRef(_31943);
            _31943 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31943) && DBL_PTR(_31943)->dbl == 0.0){
                DeRef(_31943);
                _31943 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31943);
            _31943 = NOVALUE;
        }
        DeRef(_31943);
        _31943 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64935);
        _31944 = (object)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31944)) {
            _31945 = _31944 + _amount_64931;
            if ((object)((uintptr_t)_31945 + (uintptr_t)HIGH_BITS) >= 0){
                _31945 = NewDouble((eudouble)_31945);
            }
        }
        else {
            _31945 = binary_op(PLUS, _31944, _amount_64931);
        }
        _31944 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64935);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64935 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31945;
        if( _1 != _31945 ){
            DeRef(_1);
        }
        _31945 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64929);
        _31946 = (object)*(((s1_ptr)_2)->base + _i_64933);
        RefDS(_fr_64935);
        _2 = (object)SEQ_PTR(_42forward_references_63246);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _42forward_references_63246 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31946))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31946)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31946);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64935;
        DeRef(_1);
        DeRefDS(_fr_64935);
        _fr_64935 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_64933 = _i_64933 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_64929);
    _31934 = NOVALUE;
    _31932 = NOVALUE;
    _31946 = NOVALUE;
    DeRef(_31940);
    _31940 = NOVALUE;
    return;
    ;
}


void _42shift_fwd_refs(object _pc_64956, object _amount_64957)
{
    object _file_64968 = NOVALUE;
    object _sp_64973 = NOVALUE;
    object _31956 = NOVALUE;
    object _31955 = NOVALUE;
    object _31953 = NOVALUE;
    object _31951 = NOVALUE;
    object _31950 = NOVALUE;
    object _31949 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_42shifting_sub_63265 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_42shifting_sub_63265 != _27TopLevelSub_20578)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_42toplevel_references_63249)){
            _31949 = SEQ_PTR(_42toplevel_references_63249)->length;
    }
    else {
        _31949 = 1;
    }
    {
        object _file_64964;
        _file_64964 = 1;
L3: 
        if (_file_64964 > _31949){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_42toplevel_references_63249);
        _31950 = (object)*(((s1_ptr)_2)->base + _file_64964);
        Ref(_31950);
        _42shift_top(_31950, _pc_64956, _amount_64957);
        _31950 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_64964 = _file_64964 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _31951 = (object)*(((s1_ptr)_2)->base + _42shifting_sub_63265);
    _2 = (object)SEQ_PTR(_31951);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _file_64968 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _file_64968 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_file_64968)){
        _file_64968 = (object)DBL_PTR(_file_64968)->dbl;
    }
    _31951 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_42active_subprogs_63247);
    _31953 = (object)*(((s1_ptr)_2)->base + _file_64968);
    _sp_64973 = find_from(_42shifting_sub_63265, _31953, 1);
    _31953 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_42active_references_63248);
    _31955 = (object)*(((s1_ptr)_2)->base + _file_64968);
    _2 = (object)SEQ_PTR(_31955);
    _31956 = (object)*(((s1_ptr)_2)->base + _sp_64973);
    _31955 = NOVALUE;
    Ref(_31956);
    _42shift_these(_31956, _pc_64956, _amount_64957);
    _31956 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0x1FFB6E73
