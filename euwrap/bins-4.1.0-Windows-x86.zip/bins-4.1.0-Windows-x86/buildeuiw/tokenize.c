// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _72default_state()
{
    object _35431 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:177		return {*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 1;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 1;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 1;
    ((intptr_t*)_2)[7] = 0;
    ((intptr_t*)_2)[8] = 0;
    _35431 = MAKE_SEQ(_1);
    return _35431;
    ;
}


object _72new()
{
    object _state_71323 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:200		atom state = eumem:malloc()*/
    _0 = _state_71323;
    _state_71323 = _35malloc(1, 1);
    DeRef(_0);

    /** tokenize.e:202		reset(state)*/
    Ref(_state_71323);
    _72reset(_state_71323);

    /** tokenize.e:204		return state*/
    return _state_71323;
    ;
}


void _72reset(object _state_71328)
{
    object _35435 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _35435 = _72default_state();
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_71328))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_71328)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_71328);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35435;
    if( _1 != _35435 ){
        DeRef(_1);
    }
    _35435 = NOVALUE;

    /** tokenize.e:216	end procedure*/
    DeRef(_state_71328);
    return;
    ;
}



// 0x4E7C150A
