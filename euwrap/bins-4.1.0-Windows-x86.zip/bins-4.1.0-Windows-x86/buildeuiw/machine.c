// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _6allocate(object _n_905, object _cleanup_906)
{
    object _iaddr_907 = NOVALUE;
    object _eaddr_908 = NOVALUE;
    object _350 = NOVALUE;
    object _349 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:541		ifdef DATA_EXECUTE then*/

    /** machine.e:545			iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _349 = 0;
    if (IS_ATOM_INT(_n_905)) {
        _350 = _n_905 + 0;
        if ((object)((uintptr_t)_350 + (uintptr_t)HIGH_BITS) >= 0){
            _350 = NewDouble((eudouble)_350);
        }
    }
    else {
        _350 = NewDouble(DBL_PTR(_n_905)->dbl + (eudouble)0);
    }
    _349 = NOVALUE;
    DeRef(_iaddr_907);
    _iaddr_907 = machine(16, _350);
    DeRef(_350);
    _350 = NOVALUE;

    /** machine.e:546			eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_907);
    Ref(_n_905);
    _0 = _eaddr_908;
    _eaddr_908 = _8prepare_block(_iaddr_907, _n_905, 4);
    DeRef(_0);

    /** machine.e:548		if cleanup then*/

    /** machine.e:551		return eaddr*/
    DeRef(_n_905);
    DeRef(_iaddr_907);
    return _eaddr_908;
    ;
}


void _6free_pointer_array(object _pointers_array_947)
{
    object _saved_948 = NOVALUE;
    object _ptr_949 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:661		atom saved = pointers_array*/
    Ref(_pointers_array_947);
    DeRef(_saved_948);
    _saved_948 = _pointers_array_947;

    /** machine.e:664		while ptr with entry do*/
    goto L1; // [8] 41
L2: 
    if (_ptr_949 <= 0) {
        if (_ptr_949 == 0) {
            goto L3; // [13] 51
        }
        else {
            if (!IS_ATOM_INT(_ptr_949) && DBL_PTR(_ptr_949)->dbl == 0.0){
                goto L3; // [13] 51
            }
        }
    }

    /** machine.e:665			memory:deallocate( ptr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_949);

    /** memory.e:83	end procedure*/
    goto L4; // [27] 30
L4: 

    /** machine.e:666			pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_947;
    if (IS_ATOM_INT(_pointers_array_947)) {
        _pointers_array_947 = _pointers_array_947 + _6ADDRESS_LENGTH_892;
        if ((object)((uintptr_t)_pointers_array_947 + (uintptr_t)HIGH_BITS) >= 0){
            _pointers_array_947 = NewDouble((eudouble)_pointers_array_947);
        }
    }
    else {
        _pointers_array_947 = NewDouble(DBL_PTR(_pointers_array_947)->dbl + (eudouble)_6ADDRESS_LENGTH_892);
    }
    DeRef(_0);

    /** machine.e:668		entry*/
L1: 

    /** machine.e:669			ptr = peek_pointer(pointers_array)*/
    DeRef(_ptr_949);
    if (IS_ATOM_INT(_pointers_array_947)) {
        _ptr_949 = *(intptr_t *)_pointers_array_947;
        if ((uintptr_t)_ptr_949 > (uintptr_t)MAXINT){
            _ptr_949 = NewDouble((eudouble)(uintptr_t)_ptr_949);
        }
    }
    else {
        _ptr_949 = *(uintptr_t *)(uintptr_t)(DBL_PTR(_pointers_array_947)->dbl);
        if ((uintptr_t)_ptr_949 > (uintptr_t)MAXINT){
            _ptr_949 = NewDouble((eudouble)(uintptr_t)_ptr_949);
        }
    }

    /** machine.e:670		end while*/
    goto L2; // [48] 11
L3: 

    /** machine.e:672		free(saved)*/
    Ref(_saved_948);
    _6free(_saved_948);

    /** machine.e:673	end procedure*/
    DeRef(_pointers_array_947);
    DeRef(_saved_948);
    DeRef(_ptr_949);
    return;
    ;
}


object _6VirtualAlloc(object _addr_1115, object _size_1116, object _allocation_type_1117, object _protect__1118)
{
    object _r1_1119 = NOVALUE;
    object _442 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:1979			r1 = c_func( VirtualAlloc_rid, {addr, size, allocation_type, protect_ } )*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 1;
    Ref(_allocation_type_1117);
    ((intptr_t*)_2)[3] = _allocation_type_1117;
    ((intptr_t*)_2)[4] = 64;
    _442 = MAKE_SEQ(_1);
    DeRef(_r1_1119);
    _r1_1119 = call_c(1, _6VirtualAlloc_rid_1033, _442);
    DeRefDS(_442);
    _442 = NOVALUE;

    /** machine.e:1980			return r1*/
    DeRef(_allocation_type_1117);
    return _r1_1119;
    ;
}


object _6allocate_string(object _s_1146, object _cleanup_1147)
{
    object _mem_1148 = NOVALUE;
    object _453 = NOVALUE;
    object _452 = NOVALUE;
    object _450 = NOVALUE;
    object _449 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2096		mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1146)){
            _449 = SEQ_PTR(_s_1146)->length;
    }
    else {
        _449 = 1;
    }
    _450 = _449 + 1;
    _449 = NOVALUE;
    _0 = _mem_1148;
    _mem_1148 = _6allocate(_450, 0);
    DeRef(_0);
    _450 = NOVALUE;

    /** machine.e:2098		if mem then*/
    if (_mem_1148 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1148) && DBL_PTR(_mem_1148)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** machine.e:2099			poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1148)){
        poke_addr = (uint8_t *)_mem_1148;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_mem_1148)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_1146);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** machine.e:2100			poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1146)){
            _452 = SEQ_PTR(_s_1146)->length;
    }
    else {
        _452 = 1;
    }
    if (IS_ATOM_INT(_mem_1148)) {
        _453 = _mem_1148 + _452;
        if ((object)((uintptr_t)_453 + (uintptr_t)HIGH_BITS) >= 0){
            _453 = NewDouble((eudouble)_453);
        }
    }
    else {
        _453 = NewDouble(DBL_PTR(_mem_1148)->dbl + (eudouble)_452);
    }
    _452 = NOVALUE;
    if (IS_ATOM_INT(_453)){
        poke_addr = (uint8_t *)_453;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_453)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_453);
    _453 = NOVALUE;

    /** machine.e:2101			if cleanup then*/
L1: 

    /** machine.e:2106		return mem*/
    DeRefDS(_s_1146);
    return _mem_1148;
    ;
}


void _6local_free_protected_memory(object _p_1159, object _s_1160)
{
    object _459 = NOVALUE;
    object _458 = NOVALUE;
    object _457 = NOVALUE;
    object _456 = NOVALUE;
    object _455 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2110		ifdef WINDOWS then*/

    /** machine.e:2111			if dep_works() then*/
    _455 = _8dep_works();
    if (_455 == 0) {
        DeRef(_455);
        _455 = NOVALUE;
        goto L1; // [10] 33
    }
    else {
        if (!IS_ATOM_INT(_455) && DBL_PTR(_455)->dbl == 0.0){
            DeRef(_455);
            _455 = NOVALUE;
            goto L1; // [10] 33
        }
        DeRef(_455);
        _455 = NOVALUE;
    }
    DeRef(_455);
    _455 = NOVALUE;

    /** machine.e:2112				c_func(VirtualFree_rid, { p, s, MEM_RELEASE })*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1159);
    ((intptr_t*)_2)[1] = _p_1159;
    ((intptr_t*)_2)[2] = _s_1160;
    ((intptr_t*)_2)[3] = 32768;
    _456 = MAKE_SEQ(_1);
    _457 = call_c(1, _8VirtualFree_rid_419, _456);
    DeRefDS(_456);
    _456 = NOVALUE;
    goto L2; // [30] 46
L1: 

    /** machine.e:2114				machine_func(M_FREE, {p})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1159);
    ((intptr_t*)_2)[1] = _p_1159;
    _458 = MAKE_SEQ(_1);
    _459 = machine(17, _458);
    DeRefDS(_458);
    _458 = NOVALUE;
L2: 

    /** machine.e:2120	end procedure*/
    DeRef(_p_1159);
    DeRef(_459);
    _459 = NOVALUE;
    DeRef(_457);
    _457 = NOVALUE;
    return;
    ;
}


object _6allocate_protect(object _data_1174, object _wordsize_1175, object _protection_1177)
{
    object _iaddr_1178 = NOVALUE;
    object _eaddr_1180 = NOVALUE;
    object _size_1181 = NOVALUE;
    object _first_protection_1183 = NOVALUE;
    object _true_protection_1185 = NOVALUE;
    object _prepare_block_inlined_prepare_block_at_104_1200 = NOVALUE;
    object _msg_inlined_crash_at_193_1214 = NOVALUE;
    object _478 = NOVALUE;
    object _477 = NOVALUE;
    object _475 = NOVALUE;
    object _474 = NOVALUE;
    object _473 = NOVALUE;
    object _469 = NOVALUE;
    object _465 = NOVALUE;
    object _464 = NOVALUE;
    object _462 = NOVALUE;
    object _460 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2158		atom iaddr = 0*/
    DeRef(_iaddr_1178);
    _iaddr_1178 = 0;

    /** machine.e:2160		integer size*/

    /** machine.e:2163		valid_memory_protection_constant true_protection = protection*/
    _true_protection_1185 = 64;

    /** machine.e:2169		ifdef SAFE then	*/

    /** machine.e:2179		if atom(data) then*/
    _460 = 1;
    if (_460 == 0)
    {
        _460 = NOVALUE;
        goto L1; // [20] 39
    }
    else{
        _460 = NOVALUE;
    }

    /** machine.e:2180			size = data * wordsize*/
    _size_1181 = _data_1174 * 1;

    /** machine.e:2181			first_protection = true_protection*/
    _first_protection_1183 = 64;
    goto L2; // [36] 58
L1: 

    /** machine.e:2183			size = length(data) * wordsize*/
    _462 = 1;
    _size_1181 = 1 * _wordsize_1175;
    _462 = NOVALUE;

    /** machine.e:2184			first_protection = PAGE_READ_WRITE*/
    _first_protection_1183 = 4;
L2: 

    /** machine.e:2187		iaddr = local_allocate_protected_memory( size + memory:BORDER_SPACE * 2, first_protection )*/
    _464 = 0;
    _465 = _size_1181 + 0;
    _464 = NOVALUE;
    _0 = _iaddr_1178;
    _iaddr_1178 = _6local_allocate_protected_memory(_465, _first_protection_1183);
    DeRef(_0);
    _465 = NOVALUE;

    /** machine.e:2188		if iaddr = 0 then*/
    if (binary_op_a(NOTEQ, _iaddr_1178, 0)){
        goto L3; // [79] 90
    }

    /** machine.e:2189			return 0*/
    DeRef(_iaddr_1178);
    DeRef(_eaddr_1180);
    return 0;
L3: 

    /** machine.e:2193		eaddr = memory:prepare_block( iaddr, size, protection )*/
    if (!IS_ATOM_INT(_protection_1177)) {
        _1 = (object)(DBL_PTR(_protection_1177)->dbl);
        DeRefDS(_protection_1177);
        _protection_1177 = _1;
    }

    /** memory.e:134		return addr*/
    Ref(_iaddr_1178);
    DeRef(_eaddr_1180);
    _eaddr_1180 = _iaddr_1178;

    /** machine.e:2195		if eaddr = 0 then*/
    if (binary_op_a(NOTEQ, _eaddr_1180, 0)){
        goto L4; // [102] 113
    }

    /** machine.e:2196			return eaddr*/
    DeRef(_iaddr_1178);
    return _eaddr_1180;
L4: 

    /** machine.e:2199		if sequence( data ) then*/
    _469 = 0;
    if (_469 == 0)
    {
        _469 = NOVALUE;
        goto L5; // [118] 198
    }
    else{
        _469 = NOVALUE;
    }

    /** machine.e:2200			switch wordsize do*/
    _0 = _wordsize_1175;
    switch ( _0 ){ 

        /** machine.e:2201				case 1 then*/
        case 1:

        /** machine.e:2202					eu:poke( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1180)){
            poke_addr = (uint8_t *)_eaddr_1180;
        }
        else {
            poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_eaddr_1180)->dbl);
        }
        *poke_addr = (uint8_t)_data_1174;
        goto L6; // [137] 197

        /** machine.e:2204				case 2 then*/
        case 2:

        /** machine.e:2205					eu:poke2( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1180)){
            poke2_addr = (uint16_t *)_eaddr_1180;
        }
        else {
            poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_eaddr_1180)->dbl);
        }
        *poke2_addr = (uint16_t)_data_1174;
        goto L6; // [148] 197

        /** machine.e:2207				case 4 then*/
        case 4:

        /** machine.e:2208					eu:poke4( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1180)){
            poke4_addr = (uint32_t *)_eaddr_1180;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_eaddr_1180)->dbl);
        }
        *poke4_addr = (uint32_t)_data_1174;
        goto L6; // [159] 197

        /** machine.e:2210				case 8 then*/
        case 8:

        /** machine.e:2211					poke8( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1180)){
            poke8_addr = (uint64_t *)_eaddr_1180;
        }
        else {
            poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_eaddr_1180)->dbl);
        }
        *poke8_addr = (uint64_t)_data_1174;
        goto L6; // [170] 197

        /** machine.e:2213				case else*/
        default:

        /** machine.e:2214					error:crash("Parameter error: Wrong word size %d in allocate_protect().", wordsize)*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_193_1214);
        _msg_inlined_crash_at_193_1214 = EPrintf(-9999999, _472, _wordsize_1175);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_193_1214);

        /** error.e:53	end procedure*/
        goto L7; // [191] 194
L7: 
        DeRefi(_msg_inlined_crash_at_193_1214);
        _msg_inlined_crash_at_193_1214 = NOVALUE;
    ;}L6: 
L5: 

    /** machine.e:2218		ifdef SAFE then*/

    /** machine.e:2237		if local_change_protection_on_protected_memory( iaddr, size + memory:BORDER_SPACE * 2, true_protection ) = -1 then*/
    _473 = 0;
    _474 = _size_1181 + 0;
    _473 = NOVALUE;
    Ref(_iaddr_1178);
    _475 = _6local_change_protection_on_protected_memory(_iaddr_1178, _474, _true_protection_1185);
    _474 = NOVALUE;
    if (binary_op_a(NOTEQ, _475, -1)){
        DeRef(_475);
        _475 = NOVALUE;
        goto L8; // [216] 240
    }
    DeRef(_475);
    _475 = NOVALUE;

    /** machine.e:2238			local_free_protected_memory( iaddr, size + memory:BORDER_SPACE * 2 )*/
    _477 = 0;
    _478 = _size_1181 + 0;
    _477 = NOVALUE;
    Ref(_iaddr_1178);
    _6local_free_protected_memory(_iaddr_1178, _478);
    _478 = NOVALUE;

    /** machine.e:2239			eaddr = 0*/
    DeRef(_eaddr_1180);
    _eaddr_1180 = 0;
L8: 

    /** machine.e:2242		return eaddr*/
    DeRef(_iaddr_1178);
    return _eaddr_1180;
    ;
}


object _6local_allocate_protected_memory(object _s_1225, object _first_protection_1226)
{
    object _483 = NOVALUE;
    object _482 = NOVALUE;
    object _481 = NOVALUE;
    object _480 = NOVALUE;
    object _479 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2247		ifdef WINDOWS then     */

    /** machine.e:2248			if dep_works() then*/
    _479 = _8dep_works();
    if (_479 == 0) {
        DeRef(_479);
        _479 = NOVALUE;
        goto L1; // [12] 46
    }
    else {
        if (!IS_ATOM_INT(_479) && DBL_PTR(_479)->dbl == 0.0){
            DeRef(_479);
            _479 = NOVALUE;
            goto L1; // [12] 46
        }
        DeRef(_479);
        _479 = NOVALUE;
    }
    DeRef(_479);
    _479 = NOVALUE;

    /** machine.e:2249				return eu:c_func(VirtualAlloc_rid, */
    {uintptr_t tu;
         tu = (uintptr_t)8192 | (uintptr_t)4096;
         _480 = MAKE_UINT(tu);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = _s_1225;
    ((intptr_t*)_2)[3] = _480;
    ((intptr_t*)_2)[4] = _first_protection_1226;
    _481 = MAKE_SEQ(_1);
    _480 = NOVALUE;
    _482 = call_c(1, _6VirtualAlloc_rid_1033, _481);
    DeRefDS(_481);
    _481 = NOVALUE;
    return _482;
    goto L2; // [43] 61
L1: 

    /** machine.e:2252				return machine_func(M_ALLOC, PAGE_SIZE)*/
    _483 = machine(16, _6PAGE_SIZE_1112);
    DeRef(_482);
    _482 = NOVALUE;
    return _483;
L2: 
    ;
}


object _6local_change_protection_on_protected_memory(object _p_1240, object _s_1241, object _new_protection_1242)
{
    object _486 = NOVALUE;
    object _485 = NOVALUE;
    object _484 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2271		ifdef WINDOWS then*/

    /** machine.e:2272			if dep_works() then*/
    _484 = _8dep_works();
    if (_484 == 0) {
        DeRef(_484);
        _484 = NOVALUE;
        goto L1; // [12] 45
    }
    else {
        if (!IS_ATOM_INT(_484) && DBL_PTR(_484)->dbl == 0.0){
            DeRef(_484);
            _484 = NOVALUE;
            goto L1; // [12] 45
        }
        DeRef(_484);
        _484 = NOVALUE;
    }
    DeRef(_484);
    _484 = NOVALUE;

    /** machine.e:2273				if eu:c_func( VirtualProtect_rid, { p, s, new_protection , oldprotptr } ) = 0 then*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_p_1240);
    ((intptr_t*)_2)[1] = _p_1240;
    ((intptr_t*)_2)[2] = _s_1241;
    ((intptr_t*)_2)[3] = _new_protection_1242;
    Ref(_6oldprotptr_1028);
    ((intptr_t*)_2)[4] = _6oldprotptr_1028;
    _485 = MAKE_SEQ(_1);
    _486 = call_c(1, _6VirtualProtect_rid_1034, _485);
    DeRefDS(_485);
    _485 = NOVALUE;
    if (binary_op_a(NOTEQ, _486, 0)){
        DeRef(_486);
        _486 = NOVALUE;
        goto L2; // [33] 44
    }
    DeRef(_486);
    _486 = NOVALUE;

    /** machine.e:2275					return -1*/
    DeRef(_p_1240);
    return -1;
L2: 
L1: 

    /** machine.e:2278			return 0*/
    DeRef(_p_1240);
    return 0;
    ;
}


void _6free(object _addr_1253)
{
    object _msg_inlined_crash_at_27_1262 = NOVALUE;
    object _data_inlined_crash_at_24_1261 = NOVALUE;
    object _addr_inlined_deallocate_at_64_1268 = NOVALUE;
    object _msg_inlined_crash_at_106_1273 = NOVALUE;
    object _495 = NOVALUE;
    object _494 = NOVALUE;
    object _493 = NOVALUE;
    object _492 = NOVALUE;
    object _490 = NOVALUE;
    object _489 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:2319		if types:number_array (addr) then*/
    Ref(_addr_1253);
    _489 = _9number_array(_addr_1253);
    if (_489 == 0) {
        DeRef(_489);
        _489 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_489) && DBL_PTR(_489)->dbl == 0.0){
            DeRef(_489);
            _489 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_489);
        _489 = NOVALUE;
    }
    DeRef(_489);
    _489 = NOVALUE;

    /** machine.e:2320			if types:ascii_string(addr) then*/
    Ref(_addr_1253);
    _490 = _9ascii_string(_addr_1253);
    if (_490 == 0) {
        DeRef(_490);
        _490 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_490) && DBL_PTR(_490)->dbl == 0.0){
            DeRef(_490);
            _490 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_490);
        _490 = NOVALUE;
    }
    DeRef(_490);
    _490 = NOVALUE;

    /** machine.e:2321				error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_addr_1253);
    ((intptr_t*)_2)[1] = _addr_1253;
    _492 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1261);
    _data_inlined_crash_at_24_1261 = _492;
    _492 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1262);
    _msg_inlined_crash_at_27_1262 = EPrintf(-9999999, _491, _data_inlined_crash_at_24_1261);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1262);

    /** error.e:53	end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1261);
    _data_inlined_crash_at_24_1261 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1262);
    _msg_inlined_crash_at_27_1262 = NOVALUE;
L2: 

    /** machine.e:2324			for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1253)){
            _493 = SEQ_PTR(_addr_1253)->length;
    }
    else {
        _493 = 1;
    }
    {
        object _i_1264;
        _i_1264 = 1;
L4: 
        if (_i_1264 > _493){
            goto L5; // [52] 89
        }

        /** machine.e:2325				memory:deallocate( addr[i] )*/
        _2 = (object)SEQ_PTR(_addr_1253);
        _494 = (object)*(((s1_ptr)_2)->base + _i_1264);
        Ref(_494);
        DeRef(_addr_inlined_deallocate_at_64_1268);
        _addr_inlined_deallocate_at_64_1268 = _494;
        _494 = NOVALUE;

        /** memory.e:71		ifdef DATA_EXECUTE then*/

        /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1268);

        /** memory.e:83	end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1268);
        _addr_inlined_deallocate_at_64_1268 = NOVALUE;

        /** machine.e:2326			end for*/
        _i_1264 = _i_1264 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** machine.e:2327			return*/
    DeRef(_addr_1253);
    return;
    goto L7; // [94] 127
L1: 

    /** machine.e:2328		elsif sequence(addr) then*/
    _495 = IS_SEQUENCE(_addr_1253);
    if (_495 == 0)
    {
        _495 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _495 = NOVALUE;
    }

    /** machine.e:2329			error:crash("free() called with nested sequence")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1273);
    _msg_inlined_crash_at_106_1273 = EPrintf(-9999999, _496, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1273);

    /** error.e:53	end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1273);
    _msg_inlined_crash_at_106_1273 = NOVALUE;
L8: 
L7: 

    /** machine.e:2332		if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1253, 0)){
        goto LA; // [129] 139
    }

    /** machine.e:2335			return*/
    DeRef(_addr_1253);
    return;
LA: 

    /** machine.e:2338		memory:deallocate( addr )*/

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1253);

    /** memory.e:83	end procedure*/
    goto LB; // [150] 153
LB: 

    /** machine.e:2339	end procedure*/
    DeRef(_addr_1253);
    return;
    ;
}



// 0x010DC2FC
