// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _45Push(object _x_51668)
{
    object _26585 = NOVALUE;
    object _26583 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_51668)) {
        _1 = (object)(DBL_PTR(_x_51668)->dbl);
        DeRefDS(_x_51668);
        _x_51668 = _1;
    }

    /** emit.e:135		cgi += 1*/
    _45cgi_51429 = _45cgi_51429 + 1;

    /** emit.e:136		if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_45cg_stack_51428)){
            _26583 = SEQ_PTR(_45cg_stack_51428)->length;
    }
    else {
        _26583 = 1;
    }
    if (_45cgi_51429 <= _26583)
    goto L1; // [20] 37

    /** emit.e:137			cg_stack &= repeat(0, 400)*/
    _26585 = Repeat(0, 400);
    Concat((object_ptr)&_45cg_stack_51428, _45cg_stack_51428, _26585);
    DeRefDS(_26585);
    _26585 = NOVALUE;
L1: 

    /** emit.e:139		cg_stack[cgi] = x*/
    _2 = (object)SEQ_PTR(_45cg_stack_51428);
    _2 = (object)(((s1_ptr)_2)->base + _45cgi_51429);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_51668;
    DeRef(_1);

    /** emit.e:141	end procedure*/
    return;
    ;
}


object _45Top()
{
    object _26587 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:145		return cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_45cg_stack_51428);
    _26587 = (object)*(((s1_ptr)_2)->base + _45cgi_51429);
    Ref(_26587);
    return _26587;
    ;
}


object _45Pop()
{
    object _t_51681 = NOVALUE;
    object _s_51687 = NOVALUE;
    object _26599 = NOVALUE;
    object _26597 = NOVALUE;
    object _26595 = NOVALUE;
    object _26592 = NOVALUE;
    object _26591 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:153		t = cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_45cg_stack_51428);
    _t_51681 = (object)*(((s1_ptr)_2)->base + _45cgi_51429);
    if (!IS_ATOM_INT(_t_51681)){
        _t_51681 = (object)DBL_PTR(_t_51681)->dbl;
    }

    /** emit.e:154		cgi -= 1*/
    _45cgi_51429 = _45cgi_51429 - 1;

    /** emit.e:155		if t > 0 then*/
    if (_t_51681 <= 0)
    goto L1; // [23] 116

    /** emit.e:156			symtab_index s = t -- for type checking*/
    _s_51687 = _t_51681;

    /** emit.e:157			if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26591 = (object)*(((s1_ptr)_2)->base + _t_51681);
    _2 = (object)SEQ_PTR(_26591);
    _26592 = (object)*(((s1_ptr)_2)->base + 3);
    _26591 = NOVALUE;
    if (binary_op_a(NOTEQ, _26592, 3)){
        _26592 = NOVALUE;
        goto L2; // [50] 115
    }
    _26592 = NOVALUE;

    /** emit.e:158				if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_27use_private_list_20685 != 0)
    goto L3; // [58] 82

    /** emit.e:159					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51681 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26595 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** emit.e:163				elsif find(t, private_sym) = 0 then*/
    _26597 = find_from(_t_51681, _27private_sym_20684, 1);
    if (_26597 != 0)
    goto L5; // [91] 113

    /** emit.e:165					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51681 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26599 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** emit.e:169		return t*/
    return _t_51681;
    ;
}


void _45TempKeep(object _x_51715)
{
    object _26606 = NOVALUE;
    object _26605 = NOVALUE;
    object _26604 = NOVALUE;
    object _26603 = NOVALUE;
    object _26602 = NOVALUE;
    object _26601 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:173		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26601 = (_x_51715 > 0);
    if (_26601 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26603 = (object)*(((s1_ptr)_2)->base + _x_51715);
    _2 = (object)SEQ_PTR(_26603);
    _26604 = (object)*(((s1_ptr)_2)->base + 3);
    _26603 = NOVALUE;
    if (IS_ATOM_INT(_26604)) {
        _26605 = (_26604 == 3);
    }
    else {
        _26605 = binary_op(EQUALS, _26604, 3);
    }
    _26604 = NOVALUE;
    if (_26605 == 0) {
        DeRef(_26605);
        _26605 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26605) && DBL_PTR(_26605)->dbl == 0.0){
            DeRef(_26605);
            _26605 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26605);
        _26605 = NOVALUE;
    }
    DeRef(_26605);
    _26605 = NOVALUE;

    /** emit.e:174			SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51715 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _26606 = NOVALUE;
L1: 

    /** emit.e:176	end procedure*/
    DeRef(_26601);
    _26601 = NOVALUE;
    return;
    ;
}


void _45TempFree(object _x_51733)
{
    object _26612 = NOVALUE;
    object _26610 = NOVALUE;
    object _26609 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:179		if x > 0 then*/
    if (_x_51733 <= 0)
    goto L1; // [5] 53

    /** emit.e:180			if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26609 = (object)*(((s1_ptr)_2)->base + _x_51733);
    _2 = (object)SEQ_PTR(_26609);
    _26610 = (object)*(((s1_ptr)_2)->base + 3);
    _26609 = NOVALUE;
    if (binary_op_a(NOTEQ, _26610, 3)){
        _26610 = NOVALUE;
        goto L2; // [25] 52
    }
    _26610 = NOVALUE;

    /** emit.e:181				SymTab[x][S_SCOPE] = FREE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51733 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _26612 = NOVALUE;

    /** emit.e:182				clear_temp( x )*/
    _45clear_temp(_x_51733);
L2: 
L1: 

    /** emit.e:185	end procedure*/
    return;
    ;
}


void _45TempInteger(object _x_51752)
{
    object _26619 = NOVALUE;
    object _26618 = NOVALUE;
    object _26617 = NOVALUE;
    object _26616 = NOVALUE;
    object _26615 = NOVALUE;
    object _26614 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_51752)) {
        _1 = (object)(DBL_PTR(_x_51752)->dbl);
        DeRefDS(_x_51752);
        _x_51752 = _1;
    }

    /** emit.e:188		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26614 = (_x_51752 > 0);
    if (_26614 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26616 = (object)*(((s1_ptr)_2)->base + _x_51752);
    _2 = (object)SEQ_PTR(_26616);
    _26617 = (object)*(((s1_ptr)_2)->base + 3);
    _26616 = NOVALUE;
    if (IS_ATOM_INT(_26617)) {
        _26618 = (_26617 == 3);
    }
    else {
        _26618 = binary_op(EQUALS, _26617, 3);
    }
    _26617 = NOVALUE;
    if (_26618 == 0) {
        DeRef(_26618);
        _26618 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26618) && DBL_PTR(_26618)->dbl == 0.0){
            DeRef(_26618);
            _26618 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26618);
        _26618 = NOVALUE;
    }
    DeRef(_26618);
    _26618 = NOVALUE;

    /** emit.e:189			SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51752 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _26619 = NOVALUE;
L1: 

    /** emit.e:191	end procedure*/
    DeRef(_26614);
    _26614 = NOVALUE;
    return;
    ;
}


object _45LexName(object _t_51769, object _defname_51770)
{
    object _name_51772 = NOVALUE;
    object _26628 = NOVALUE;
    object _26626 = NOVALUE;
    object _26624 = NOVALUE;
    object _26623 = NOVALUE;
    object _26622 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_51769)) {
        _1 = (object)(DBL_PTR(_t_51769)->dbl);
        DeRefDS(_t_51769);
        _t_51769 = _1;
    }

    /** emit.e:197		for i = 1 to length(token_name) do*/
    _26622 = 80;
    {
        object _i_51774;
        _i_51774 = 1;
L1: 
        if (_i_51774 > 80){
            goto L2; // [12] 82
        }

        /** emit.e:198			if t = token_name[i][LEX_NUMBER] then*/
        _2 = (object)SEQ_PTR(_45token_name_51436);
        _26623 = (object)*(((s1_ptr)_2)->base + _i_51774);
        _2 = (object)SEQ_PTR(_26623);
        _26624 = (object)*(((s1_ptr)_2)->base + 1);
        _26623 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_51769, _26624)){
            _26624 = NOVALUE;
            goto L3; // [31] 75
        }
        _26624 = NOVALUE;

        /** emit.e:199				name = token_name[i][LEX_NAME]*/
        _2 = (object)SEQ_PTR(_45token_name_51436);
        _26626 = (object)*(((s1_ptr)_2)->base + _i_51774);
        DeRef(_name_51772);
        _2 = (object)SEQ_PTR(_26626);
        _name_51772 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_name_51772);
        _26626 = NOVALUE;

        /** emit.e:200				if not find(' ', name) then*/
        _26628 = find_from(32, _name_51772, 1);
        if (_26628 != 0)
        goto L4; // [56] 68
        _26628 = NOVALUE;

        /** emit.e:201					name = "'" & name & "'"*/
        {
            object concat_list[3];

            concat_list[0] = _26630;
            concat_list[1] = _name_51772;
            concat_list[2] = _26630;
            Concat_N((object_ptr)&_name_51772, concat_list, 3);
        }
L4: 

        /** emit.e:203				return name*/
        DeRefDSi(_defname_51770);
        return _name_51772;
L3: 

        /** emit.e:205		end for*/
        _i_51774 = _i_51774 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** emit.e:206		return defname -- try to avoid this case*/
    DeRef(_name_51772);
    return _defname_51770;
    ;
}


void _45InitEmit()
{
    object _0, _1, _2;
    

    /** emit.e:212		cg_stack = repeat(0, 400)*/
    DeRef(_45cg_stack_51428);
    _45cg_stack_51428 = Repeat(0, 400);

    /** emit.e:213		cgi = 0*/
    _45cgi_51429 = 0;

    /** emit.e:214	end procedure*/
    return;
    ;
}


object _45IsInteger(object _sym_51793)
{
    object _mode_51794 = NOVALUE;
    object _t_51796 = NOVALUE;
    object _pt_51797 = NOVALUE;
    object _26653 = NOVALUE;
    object _26652 = NOVALUE;
    object _26650 = NOVALUE;
    object _26649 = NOVALUE;
    object _26648 = NOVALUE;
    object _26646 = NOVALUE;
    object _26645 = NOVALUE;
    object _26644 = NOVALUE;
    object _26643 = NOVALUE;
    object _26641 = NOVALUE;
    object _26637 = NOVALUE;
    object _26634 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_51793)) {
        _1 = (object)(DBL_PTR(_sym_51793)->dbl);
        DeRefDS(_sym_51793);
        _sym_51793 = _1;
    }

    /** emit.e:221		if sym < 1 then*/
    if (_sym_51793 >= 1)
    goto L1; // [5] 16

    /** emit.e:223			return 0*/
    return 0;
L1: 

    /** emit.e:226		mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26634 = (object)*(((s1_ptr)_2)->base + _sym_51793);
    _2 = (object)SEQ_PTR(_26634);
    _mode_51794 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_51794)){
        _mode_51794 = (object)DBL_PTR(_mode_51794)->dbl;
    }
    _26634 = NOVALUE;

    /** emit.e:227		if mode = M_NORMAL then*/
    if (_mode_51794 != 1)
    goto L2; // [36] 136

    /** emit.e:228			t = SymTab[sym][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26637 = (object)*(((s1_ptr)_2)->base + _sym_51793);
    _2 = (object)SEQ_PTR(_26637);
    _t_51796 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_51796)){
        _t_51796 = (object)DBL_PTR(_t_51796)->dbl;
    }
    _26637 = NOVALUE;

    /** emit.e:229			if t = integer_type then*/
    if (_t_51796 != _53integer_type_47190)
    goto L3; // [60] 73

    /** emit.e:230				return TRUE*/
    return _9TRUE_441;
L3: 

    /** emit.e:232			if t > 0 then*/
    if (_t_51796 <= 0)
    goto L4; // [75] 215

    /** emit.e:233				pt = SymTab[t][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26641 = (object)*(((s1_ptr)_2)->base + _t_51796);
    _2 = (object)SEQ_PTR(_26641);
    _pt_51797 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_51797)){
        _pt_51797 = (object)DBL_PTR(_pt_51797)->dbl;
    }
    _26641 = NOVALUE;

    /** emit.e:234				if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_51797 == 0) {
        goto L4; // [97] 215
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26644 = (object)*(((s1_ptr)_2)->base + _pt_51797);
    _2 = (object)SEQ_PTR(_26644);
    _26645 = (object)*(((s1_ptr)_2)->base + 15);
    _26644 = NOVALUE;
    if (IS_ATOM_INT(_26645)) {
        _26646 = (_26645 == _53integer_type_47190);
    }
    else {
        _26646 = binary_op(EQUALS, _26645, _53integer_type_47190);
    }
    _26645 = NOVALUE;
    if (_26646 == 0) {
        DeRef(_26646);
        _26646 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26646) && DBL_PTR(_26646)->dbl == 0.0){
            DeRef(_26646);
            _26646 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26646);
        _26646 = NOVALUE;
    }
    DeRef(_26646);
    _26646 = NOVALUE;

    /** emit.e:235					return TRUE   -- usertype(integer x)*/
    return _9TRUE_441;
    goto L4; // [133] 215
L2: 

    /** emit.e:239		elsif mode = M_CONSTANT then*/
    if (_mode_51794 != 2)
    goto L5; // [140] 176

    /** emit.e:240			if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26648 = (object)*(((s1_ptr)_2)->base + _sym_51793);
    _2 = (object)SEQ_PTR(_26648);
    _26649 = (object)*(((s1_ptr)_2)->base + 1);
    _26648 = NOVALUE;
    if (IS_ATOM_INT(_26649))
    _26650 = 1;
    else if (IS_ATOM_DBL(_26649))
    _26650 = IS_ATOM_INT(DoubleToInt(_26649));
    else
    _26650 = 0;
    _26649 = NOVALUE;
    if (_26650 == 0)
    {
        _26650 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26650 = NOVALUE;
    }

    /** emit.e:241				return TRUE*/
    return _9TRUE_441;
    goto L4; // [173] 215
L5: 

    /** emit.e:244		elsif mode = M_TEMP then*/
    if (_mode_51794 != 3)
    goto L6; // [180] 214

    /** emit.e:245			if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _26652 = (object)*(((s1_ptr)_2)->base + _sym_51793);
    _2 = (object)SEQ_PTR(_26652);
    _26653 = (object)*(((s1_ptr)_2)->base + 5);
    _26652 = NOVALUE;
    if (binary_op_a(NOTEQ, _26653, 1)){
        _26653 = NOVALUE;
        goto L7; // [200] 213
    }
    _26653 = NOVALUE;

    /** emit.e:246				return TRUE*/
    return _9TRUE_441;
L7: 
L6: 
L4: 

    /** emit.e:250		return FALSE*/
    return _9FALSE_439;
    ;
}


void _45emit(object _val_51854)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_51854)) {
        _1 = (object)(DBL_PTR(_val_51854)->dbl);
        DeRefDS(_val_51854);
        _val_51854 = _1;
    }

    /** emit.e:260		Code = append(Code, val)*/
    Append(&_27Code_20660, _27Code_20660, _val_51854);

    /** emit.e:261	end procedure*/
    return;
    ;
}


void _45emit_opnd(object _opnd_51861)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_51861)) {
        _1 = (object)(DBL_PTR(_opnd_51861)->dbl);
        DeRefDS(_opnd_51861);
        _opnd_51861 = _1;
    }

    /** emit.e:271			Push(opnd)*/
    _45Push(_opnd_51861);

    /** emit.e:272			previous_op = -1  -- N.B.*/
    _27previous_op_20670 = -1;

    /** emit.e:273	end procedure*/
    return;
    ;
}


void _45emit_addr(object _x_51865)
{
    object _0, _1, _2;
    

    /** emit.e:277			Code = append(Code, x)*/
    Ref(_x_51865);
    Append(&_27Code_20660, _27Code_20660, _x_51865);

    /** emit.e:278	end procedure*/
    DeRef(_x_51865);
    return;
    ;
}


void _45emit_opcode(object _op_51871)
{
    object _0, _1, _2;
    

    /** emit.e:282		Code = append(Code, op)*/
    Append(&_27Code_20660, _27Code_20660, _op_51871);

    /** emit.e:283	end procedure*/
    return;
    ;
}


void _45emit_temp(object _tempsym_51905, object _referenced_51906)
{
    object _26684 = NOVALUE;
    object _26683 = NOVALUE;
    object _26682 = NOVALUE;
    object _26681 = NOVALUE;
    object _26680 = NOVALUE;
    object _26679 = NOVALUE;
    object _26678 = NOVALUE;
    object _26677 = NOVALUE;
    object _26676 = NOVALUE;
    object _26675 = NOVALUE;
    object _26674 = NOVALUE;
    object _26673 = NOVALUE;
    object _26672 = NOVALUE;
    object _26671 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:307		if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_27TRANSLATE_20179 != 0)
    goto L1; // [7] 129

    /** emit.e:308			if sequence(tempsym) then*/
    _26671 = IS_SEQUENCE(_tempsym_51905);
    if (_26671 == 0)
    {
        _26671 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26671 = NOVALUE;
    }

    /** emit.e:309				for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_51905)){
            _26672 = SEQ_PTR(_tempsym_51905)->length;
    }
    else {
        _26672 = 1;
    }
    {
        object _i_51913;
        _i_51913 = 1;
L3: 
        if (_i_51913 > _26672){
            goto L4; // [23] 50
        }

        /** emit.e:310					emit_temp( tempsym[i], referenced )*/
        _2 = (object)SEQ_PTR(_tempsym_51905);
        _26673 = (object)*(((s1_ptr)_2)->base + _i_51913);
        DeRef(_26674);
        _26674 = _referenced_51906;
        Ref(_26673);
        _45emit_temp(_26673, _26674);
        _26673 = NOVALUE;
        _26674 = NOVALUE;

        /** emit.e:311				end for*/
        _i_51913 = _i_51913 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** emit.e:313			elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_51905)) {
        _26675 = (_tempsym_51905 > 0);
    }
    else {
        _26675 = binary_op(GREATER, _tempsym_51905, 0);
    }
    if (IS_ATOM_INT(_26675)) {
        if (_26675 == 0) {
            DeRef(_26676);
            _26676 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26675)->dbl == 0.0) {
            DeRef(_26676);
            _26676 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_51905);
    _26677 = _53sym_mode(_tempsym_51905);
    if (IS_ATOM_INT(_26677)) {
        _26678 = (_26677 == 3);
    }
    else {
        _26678 = binary_op(EQUALS, _26677, 3);
    }
    DeRef(_26677);
    _26677 = NOVALUE;
    DeRef(_26676);
    if (IS_ATOM_INT(_26678))
    _26676 = (_26678 != 0);
    else
    _26676 = DBL_PTR(_26678)->dbl != 0.0;
L6: 
    if (_26676 == 0) {
        _26679 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_51905);
    _26680 = _45IsInteger(_tempsym_51905);
    if (IS_ATOM_INT(_26680)) {
        _26681 = (_26680 == 0);
    }
    else {
        _26681 = unary_op(NOT, _26680);
    }
    DeRef(_26680);
    _26680 = NOVALUE;
    if (IS_ATOM_INT(_26681))
    _26679 = (_26681 != 0);
    else
    _26679 = DBL_PTR(_26681)->dbl != 0.0;
L7: 
    if (_26679 == 0) {
        goto L8; // [92] 127
    }
    _26683 = find_from(_tempsym_51905, _45emitted_temps_51901, 1);
    _26684 = (_26683 == 0);
    _26683 = NOVALUE;
    if (_26684 == 0)
    {
        DeRef(_26684);
        _26684 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26684);
        _26684 = NOVALUE;
    }

    /** emit.e:319				emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_45emitted_temps_51901) && IS_ATOM(_tempsym_51905)) {
        Ref(_tempsym_51905);
        Append(&_45emitted_temps_51901, _45emitted_temps_51901, _tempsym_51905);
    }
    else if (IS_ATOM(_45emitted_temps_51901) && IS_SEQUENCE(_tempsym_51905)) {
    }
    else {
        Concat((object_ptr)&_45emitted_temps_51901, _45emitted_temps_51901, _tempsym_51905);
    }

    /** emit.e:320				emitted_temp_referenced &= referenced*/
    Append(&_45emitted_temp_referenced_51902, _45emitted_temp_referenced_51902, _referenced_51906);
L8: 
L5: 
L1: 

    /** emit.e:323	end procedure*/
    DeRef(_tempsym_51905);
    DeRef(_26678);
    _26678 = NOVALUE;
    DeRef(_26675);
    _26675 = NOVALUE;
    DeRef(_26681);
    _26681 = NOVALUE;
    return;
    ;
}


void _45flush_temps(object _except_for_51935)
{
    object _refs_51938 = NOVALUE;
    object _novalues_51939 = NOVALUE;
    object _sym_51944 = NOVALUE;
    object _26699 = NOVALUE;
    object _26698 = NOVALUE;
    object _26697 = NOVALUE;
    object _26696 = NOVALUE;
    object _26694 = NOVALUE;
    object _26690 = NOVALUE;
    object _26689 = NOVALUE;
    object _26687 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:332		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** emit.e:333			return*/
    DeRefDS(_except_for_51935);
    DeRef(_refs_51938);
    DeRefi(_novalues_51939);
    return;
L1: 

    /** emit.e:336		sequence*/

    /** emit.e:337			refs = {},*/
    RefDS(_22209);
    DeRef(_refs_51938);
    _refs_51938 = _22209;

    /** emit.e:338			novalues = {}*/
    RefDS(_22209);
    DeRefi(_novalues_51939);
    _novalues_51939 = _22209;

    /** emit.e:340		derefs = {}*/
    RefDS(_22209);
    DeRefi(_45derefs_51932);
    _45derefs_51932 = _22209;

    /** emit.e:341		for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_45emitted_temps_51901)){
            _26687 = SEQ_PTR(_45emitted_temps_51901)->length;
    }
    else {
        _26687 = 1;
    }
    {
        object _i_51941;
        _i_51941 = 1;
L2: 
        if (_i_51941 > _26687){
            goto L3; // [46] 119
        }

        /** emit.e:342			symtab_index sym = emitted_temps[i]*/
        _2 = (object)SEQ_PTR(_45emitted_temps_51901);
        _sym_51944 = (object)*(((s1_ptr)_2)->base + _i_51941);
        if (!IS_ATOM_INT(_sym_51944)){
            _sym_51944 = (object)DBL_PTR(_sym_51944)->dbl;
        }

        /** emit.e:344			if find( sym, except_for ) then*/
        _26689 = find_from(_sym_51944, _except_for_51935, 1);
        if (_26689 == 0)
        {
            _26689 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26689 = NOVALUE;
        }

        /** emit.e:345				continue*/
        goto L5; // [77] 114
L4: 

        /** emit.e:348			if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (object)SEQ_PTR(_45emitted_temp_referenced_51902);
        _26690 = (object)*(((s1_ptr)_2)->base + _i_51941);
        if (binary_op_a(NOTEQ, _26690, 1)){
            _26690 = NOVALUE;
            goto L6; // [88] 103
        }
        _26690 = NOVALUE;

        /** emit.e:349				derefs &= sym*/
        Append(&_45derefs_51932, _45derefs_51932, _sym_51944);
        goto L7; // [100] 110
L6: 

        /** emit.e:351				novalues &= sym*/
        Append(&_novalues_51939, _novalues_51939, _sym_51944);
L7: 

        /** emit.e:353		end for*/
L5: 
        _i_51941 = _i_51941 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** emit.e:355		if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_51935)){
            _26694 = SEQ_PTR(_except_for_51935)->length;
    }
    else {
        _26694 = 1;
    }
    if (_26694 != 0)
    goto L8; // [124] 132
    _26694 = NOVALUE;

    /** emit.e:356			clear_last()*/
    _45clear_last();
L8: 

    /** emit.e:359		for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_45derefs_51932)){
            _26696 = SEQ_PTR(_45derefs_51932)->length;
    }
    else {
        _26696 = 1;
    }
    {
        object _i_51959;
        _i_51959 = 1;
L9: 
        if (_i_51959 > _26696){
            goto LA; // [139] 171
        }

        /** emit.e:360			emit( DEREF_TEMP )*/
        _45emit(208);

        /** emit.e:361			emit( derefs[i] )*/
        _2 = (object)SEQ_PTR(_45derefs_51932);
        _26697 = (object)*(((s1_ptr)_2)->base + _i_51959);
        _45emit(_26697);
        _26697 = NOVALUE;

        /** emit.e:362		end for*/
        _i_51959 = _i_51959 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** emit.e:364		for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_51939)){
            _26698 = SEQ_PTR(_novalues_51939)->length;
    }
    else {
        _26698 = 1;
    }
    {
        object _i_51964;
        _i_51964 = 1;
LB: 
        if (_i_51964 > _26698){
            goto LC; // [176] 206
        }

        /** emit.e:365			emit( NOVALUE_TEMP )*/
        _45emit(209);

        /** emit.e:366			emit( novalues[i] )*/
        _2 = (object)SEQ_PTR(_novalues_51939);
        _26699 = (object)*(((s1_ptr)_2)->base + _i_51964);
        _45emit(_26699);
        _26699 = NOVALUE;

        /** emit.e:367		end for*/
        _i_51964 = _i_51964 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** emit.e:369		emitted_temps = {}*/
    RefDS(_22209);
    DeRef(_45emitted_temps_51901);
    _45emitted_temps_51901 = _22209;

    /** emit.e:370		emitted_temp_referenced = {}*/
    RefDS(_22209);
    DeRef(_45emitted_temp_referenced_51902);
    _45emitted_temp_referenced_51902 = _22209;

    /** emit.e:371	end procedure*/
    DeRefDS(_except_for_51935);
    DeRef(_refs_51938);
    DeRefi(_novalues_51939);
    return;
    ;
}


void _45flush_temp(object _temp_51971)
{
    object _except_for_51972 = NOVALUE;
    object _ix_51973 = NOVALUE;
    object _26701 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_51971)) {
        _1 = (object)(DBL_PTR(_temp_51971)->dbl);
        DeRefDS(_temp_51971);
        _temp_51971 = _1;
    }

    /** emit.e:374		sequence except_for = emitted_temps*/
    RefDS(_45emitted_temps_51901);
    DeRef(_except_for_51972);
    _except_for_51972 = _45emitted_temps_51901;

    /** emit.e:375		integer ix = find( temp, emitted_temps )*/
    _ix_51973 = find_from(_temp_51971, _45emitted_temps_51901, 1);

    /** emit.e:376		if ix then*/
    if (_ix_51973 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** emit.e:377			flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_51972);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51973)) ? _ix_51973 : (object)(DBL_PTR(_ix_51973)->dbl);
        int stop = (IS_ATOM_INT(_ix_51973)) ? _ix_51973 : (object)(DBL_PTR(_ix_51973)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_except_for_51972);
            DeRef(_26701);
            _26701 = _except_for_51972;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_51972), start, &_26701 );
            }
            else Tail(SEQ_PTR(_except_for_51972), stop+1, &_26701);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_51972), start, &_26701);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26701);
            _26701 = _1;
        }
    }
    _45flush_temps(_26701);
    _26701 = NOVALUE;
L1: 

    /** emit.e:379	end procedure*/
    DeRef(_except_for_51972);
    return;
    ;
}


void _45check_for_temps()
{
    object _26708 = NOVALUE;
    object _26707 = NOVALUE;
    object _26706 = NOVALUE;
    object _26705 = NOVALUE;
    object _26703 = NOVALUE;
    object _26702 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:382		if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_27TRANSLATE_20179 != 0) {
        _26702 = 1;
        goto L1; // [5] 19
    }
    _26703 = (_45last_op_52310 < 1);
    _26702 = (_26703 != 0);
L1: 
    if (_26702 != 0) {
        goto L2; // [19] 34
    }
    _26705 = (_45last_pc_52311 < 1);
    if (_26705 == 0)
    {
        DeRef(_26705);
        _26705 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26705);
        _26705 = NOVALUE;
    }
L2: 

    /** emit.e:383			return*/
    DeRef(_26703);
    _26703 = NOVALUE;
    return;
L3: 

    /** emit.e:386		emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_27Code_20660);
    _26706 = _65current_op(_45last_pc_52311, _27Code_20660);
    _26707 = _65get_target_sym(_26706);
    _26706 = NOVALUE;
    _2 = (object)SEQ_PTR(_45op_temp_ref_52123);
    _26708 = (object)*(((s1_ptr)_2)->base + _45last_op_52310);
    _45emit_temp(_26707, _26708);
    _26707 = NOVALUE;
    _26708 = NOVALUE;

    /** emit.e:388	end procedure*/
    DeRef(_26703);
    _26703 = NOVALUE;
    return;
    ;
}


void _45clear_temp(object _tempsym_51998)
{
    object _ix_51999 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_51998)) {
        _1 = (object)(DBL_PTR(_tempsym_51998)->dbl);
        DeRefDS(_tempsym_51998);
        _tempsym_51998 = _1;
    }

    /** emit.e:391		integer ix = find( tempsym, emitted_temps )*/
    _ix_51999 = find_from(_tempsym_51998, _45emitted_temps_51901, 1);

    /** emit.e:392		if ix then*/
    if (_ix_51999 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** emit.e:393			emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_45emitted_temps_51901);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51999)) ? _ix_51999 : (object)(DBL_PTR(_ix_51999)->dbl);
        int stop = (IS_ATOM_INT(_ix_51999)) ? _ix_51999 : (object)(DBL_PTR(_ix_51999)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45emitted_temps_51901), start, &_45emitted_temps_51901 );
            }
            else Tail(SEQ_PTR(_45emitted_temps_51901), stop+1, &_45emitted_temps_51901);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45emitted_temps_51901), start, &_45emitted_temps_51901);
        }
        else {
            assign_slice_seq = &assign_space;
            _45emitted_temps_51901 = Remove_elements(start, stop, (SEQ_PTR(_45emitted_temps_51901)->ref == 1));
        }
    }

    /** emit.e:394			emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_45emitted_temp_referenced_51902);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51999)) ? _ix_51999 : (object)(DBL_PTR(_ix_51999)->dbl);
        int stop = (IS_ATOM_INT(_ix_51999)) ? _ix_51999 : (object)(DBL_PTR(_ix_51999)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45emitted_temp_referenced_51902), start, &_45emitted_temp_referenced_51902 );
            }
            else Tail(SEQ_PTR(_45emitted_temp_referenced_51902), stop+1, &_45emitted_temp_referenced_51902);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45emitted_temp_referenced_51902), start, &_45emitted_temp_referenced_51902);
        }
        else {
            assign_slice_seq = &assign_space;
            _45emitted_temp_referenced_51902 = Remove_elements(start, stop, (SEQ_PTR(_45emitted_temp_referenced_51902)->ref == 1));
        }
    }
L1: 

    /** emit.e:396	end procedure*/
    return;
    ;
}


object _45pop_temps()
{
    object _new_emitted_52006 = NOVALUE;
    object _new_referenced_52007 = NOVALUE;
    object _26712 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:402		sequence new_emitted  = emitted_temps*/
    RefDS(_45emitted_temps_51901);
    DeRef(_new_emitted_52006);
    _new_emitted_52006 = _45emitted_temps_51901;

    /** emit.e:403		sequence new_referenced = emitted_temp_referenced*/
    RefDS(_45emitted_temp_referenced_51902);
    DeRef(_new_referenced_52007);
    _new_referenced_52007 = _45emitted_temp_referenced_51902;

    /** emit.e:405		emitted_temps  = {}*/
    RefDS(_22209);
    DeRefDS(_45emitted_temps_51901);
    _45emitted_temps_51901 = _22209;

    /** emit.e:406		emitted_temp_referenced = {}*/
    RefDS(_22209);
    DeRefDS(_45emitted_temp_referenced_51902);
    _45emitted_temp_referenced_51902 = _22209;

    /** emit.e:407		return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_52007);
    RefDS(_new_emitted_52006);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _new_emitted_52006;
    ((intptr_t *)_2)[2] = _new_referenced_52007;
    _26712 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_52006);
    DeRefDS(_new_referenced_52007);
    return _26712;
    ;
}


object _45get_temps(object _add_to_52011)
{
    object _26717 = NOVALUE;
    object _26716 = NOVALUE;
    object _26715 = NOVALUE;
    object _26714 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:416		add_to[1] &= emitted_temps*/
    _2 = (object)SEQ_PTR(_add_to_52011);
    _26714 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26714) && IS_ATOM(_45emitted_temps_51901)) {
    }
    else if (IS_ATOM(_26714) && IS_SEQUENCE(_45emitted_temps_51901)) {
        Ref(_26714);
        Prepend(&_26715, _45emitted_temps_51901, _26714);
    }
    else {
        Concat((object_ptr)&_26715, _26714, _45emitted_temps_51901);
        _26714 = NOVALUE;
    }
    _26714 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_52011);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_52011 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26715;
    if( _1 != _26715 ){
        DeRef(_1);
    }
    _26715 = NOVALUE;

    /** emit.e:417		add_to[2] &= emitted_temp_referenced*/
    _2 = (object)SEQ_PTR(_add_to_52011);
    _26716 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26716) && IS_ATOM(_45emitted_temp_referenced_51902)) {
    }
    else if (IS_ATOM(_26716) && IS_SEQUENCE(_45emitted_temp_referenced_51902)) {
        Ref(_26716);
        Prepend(&_26717, _45emitted_temp_referenced_51902, _26716);
    }
    else {
        Concat((object_ptr)&_26717, _26716, _45emitted_temp_referenced_51902);
        _26716 = NOVALUE;
    }
    _26716 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_52011);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_52011 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26717;
    if( _1 != _26717 ){
        DeRef(_1);
    }
    _26717 = NOVALUE;

    /** emit.e:418		return add_to*/
    return _add_to_52011;
    ;
}


void _45push_temps(object _temps_52019)
{
    object _26720 = NOVALUE;
    object _26718 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:426		emitted_temps &= temps[1]*/
    _2 = (object)SEQ_PTR(_temps_52019);
    _26718 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_45emitted_temps_51901) && IS_ATOM(_26718)) {
        Ref(_26718);
        Append(&_45emitted_temps_51901, _45emitted_temps_51901, _26718);
    }
    else if (IS_ATOM(_45emitted_temps_51901) && IS_SEQUENCE(_26718)) {
    }
    else {
        Concat((object_ptr)&_45emitted_temps_51901, _45emitted_temps_51901, _26718);
    }
    _26718 = NOVALUE;

    /** emit.e:427		emitted_temp_referenced &= temps[2]*/
    _2 = (object)SEQ_PTR(_temps_52019);
    _26720 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_45emitted_temp_referenced_51902) && IS_ATOM(_26720)) {
        Ref(_26720);
        Append(&_45emitted_temp_referenced_51902, _45emitted_temp_referenced_51902, _26720);
    }
    else if (IS_ATOM(_45emitted_temp_referenced_51902) && IS_SEQUENCE(_26720)) {
    }
    else {
        Concat((object_ptr)&_45emitted_temp_referenced_51902, _45emitted_temp_referenced_51902, _26720);
    }
    _26720 = NOVALUE;

    /** emit.e:428		flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** emit.e:429	end procedure*/
    DeRefDS(_temps_52019);
    return;
    ;
}


void _45backpatch(object _index_52026, object _val_52027)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_52026)) {
        _1 = (object)(DBL_PTR(_index_52026)->dbl);
        DeRefDS(_index_52026);
        _index_52026 = _1;
    }
    if (!IS_ATOM_INT(_val_52027)) {
        _1 = (object)(DBL_PTR(_val_52027)->dbl);
        DeRefDS(_val_52027);
        _val_52027 = _1;
    }

    /** emit.e:433			Code[index] = val*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_52026);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_52027;
    DeRef(_1);

    /** emit.e:434	end procedure*/
    return;
    ;
}


void _45cont11ii(object _op_52211, object _ii_52213)
{
    object _t_52214 = NOVALUE;
    object _source_52215 = NOVALUE;
    object _c_52216 = NOVALUE;
    object _26729 = NOVALUE;
    object _26728 = NOVALUE;
    object _26726 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:580		emit_opcode(op)*/
    _45emit_opcode(_op_52211);

    /** emit.e:581		source = Pop()*/
    _source_52215 = _45Pop();
    if (!IS_ATOM_INT(_source_52215)) {
        _1 = (object)(DBL_PTR(_source_52215)->dbl);
        DeRefDS(_source_52215);
        _source_52215 = _1;
    }

    /** emit.e:582		emit_addr(source)*/
    _45emit_addr(_source_52215);

    /** emit.e:583		assignable = TRUE*/
    _45assignable_51431 = _9TRUE_441;

    /** emit.e:584		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_45op_result_52029);
    _t_52214 = (object)*(((s1_ptr)_2)->base + _op_52211);

    /** emit.e:587		if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26726 = (_t_52214 == 1);
    if (_26726 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_52213 == 0) {
        _26728 = 0;
        goto L2; // [47] 59
    }
    _26729 = _45IsInteger(_source_52215);
    if (IS_ATOM_INT(_26729))
    _26728 = (_26729 != 0);
    else
    _26728 = DBL_PTR(_26729)->dbl != 0.0;
L2: 
    if (_26728 == 0)
    {
        _26728 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26728 = NOVALUE;
    }
L1: 

    /** emit.e:588			c = NewTempSym()*/
    _c_52216 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_52216)) {
        _1 = (object)(DBL_PTR(_c_52216)->dbl);
        DeRefDS(_c_52216);
        _c_52216 = _1;
    }

    /** emit.e:589			TempInteger(c)*/
    _45TempInteger(_c_52216);
    goto L4; // [77] 95
L3: 

    /** emit.e:591			c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_52216 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_52216)) {
        _1 = (object)(DBL_PTR(_c_52216)->dbl);
        DeRefDS(_c_52216);
        _c_52216 = _1;
    }

    /** emit.e:592			emit_temp( c, NEW_REFERENCE )*/
    _45emit_temp(_c_52216, 1);
L4: 

    /** emit.e:595		Push(c)*/
    _45Push(_c_52216);

    /** emit.e:596		emit_addr(c)*/
    _45emit_addr(_c_52216);

    /** emit.e:597	end procedure*/
    DeRef(_26729);
    _26729 = NOVALUE;
    DeRef(_26726);
    _26726 = NOVALUE;
    return;
    ;
}


void _45cont21d(object _op_52233, object _a_52234, object _b_52235, object _ii_52237)
{
    object _c_52238 = NOVALUE;
    object _t_52239 = NOVALUE;
    object _26739 = NOVALUE;
    object _26738 = NOVALUE;
    object _26737 = NOVALUE;
    object _26736 = NOVALUE;
    object _26734 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:602		assignable = TRUE*/
    _45assignable_51431 = _9TRUE_441;

    /** emit.e:603		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_45op_result_52029);
    _t_52239 = (object)*(((s1_ptr)_2)->base + _op_52233);

    /** emit.e:604		if op = C_FUNC then*/
    if (_op_52233 != 133)
    goto L1; // [26] 38

    /** emit.e:605			emit_addr(CurrentSub)*/
    _45emit_addr(_27CurrentSub_20579);
L1: 

    /** emit.e:607		if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26734 = (_t_52239 == 1);
    if (_26734 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_52237 == 0) {
        _26736 = 0;
        goto L3; // [50] 62
    }
    _26737 = _45IsInteger(_a_52234);
    if (IS_ATOM_INT(_26737))
    _26736 = (_26737 != 0);
    else
    _26736 = DBL_PTR(_26737)->dbl != 0.0;
L3: 
    if (_26736 == 0) {
        DeRef(_26738);
        _26738 = 0;
        goto L4; // [62] 74
    }
    _26739 = _45IsInteger(_b_52235);
    if (IS_ATOM_INT(_26739))
    _26738 = (_26739 != 0);
    else
    _26738 = DBL_PTR(_26739)->dbl != 0.0;
L4: 
    if (_26738 == 0)
    {
        _26738 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26738 = NOVALUE;
    }
L2: 

    /** emit.e:608			c = NewTempSym()*/
    _c_52238 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_52238)) {
        _1 = (object)(DBL_PTR(_c_52238)->dbl);
        DeRefDS(_c_52238);
        _c_52238 = _1;
    }

    /** emit.e:609			TempInteger(c)*/
    _45TempInteger(_c_52238);
    goto L6; // [92] 110
L5: 

    /** emit.e:611			c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_52238 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_52238)) {
        _1 = (object)(DBL_PTR(_c_52238)->dbl);
        DeRefDS(_c_52238);
        _c_52238 = _1;
    }

    /** emit.e:612			emit_temp( c, NEW_REFERENCE )*/
    _45emit_temp(_c_52238, 1);
L6: 

    /** emit.e:614		Push(c)*/
    _45Push(_c_52238);

    /** emit.e:615		emit_addr(c)*/
    _45emit_addr(_c_52238);

    /** emit.e:616	end procedure*/
    DeRef(_26739);
    _26739 = NOVALUE;
    DeRef(_26737);
    _26737 = NOVALUE;
    DeRef(_26734);
    _26734 = NOVALUE;
    return;
    ;
}


void _45cont21ii(object _op_52261, object _ii_52263)
{
    object _a_52264 = NOVALUE;
    object _b_52265 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:621		b = Pop()*/
    _b_52265 = _45Pop();
    if (!IS_ATOM_INT(_b_52265)) {
        _1 = (object)(DBL_PTR(_b_52265)->dbl);
        DeRefDS(_b_52265);
        _b_52265 = _1;
    }

    /** emit.e:622		emit_opcode(op)*/
    _45emit_opcode(_op_52261);

    /** emit.e:623		a = Pop()*/
    _a_52264 = _45Pop();
    if (!IS_ATOM_INT(_a_52264)) {
        _1 = (object)(DBL_PTR(_a_52264)->dbl);
        DeRefDS(_a_52264);
        _a_52264 = _1;
    }

    /** emit.e:624		emit_addr(a)*/
    _45emit_addr(_a_52264);

    /** emit.e:625		emit_addr(b)*/
    _45emit_addr(_b_52265);

    /** emit.e:626		cont21d(op, a, b, ii)*/
    _45cont21d(_op_52261, _a_52264, _b_52265, _ii_52263);

    /** emit.e:627	end procedure*/
    return;
    ;
}


object _45good_string(object _elements_52270)
{
    object _obj_52271 = NOVALUE;
    object _ep_52273 = NOVALUE;
    object _e_52275 = NOVALUE;
    object _element_vals_52276 = NOVALUE;
    object _26762 = NOVALUE;
    object _26761 = NOVALUE;
    object _26760 = NOVALUE;
    object _26759 = NOVALUE;
    object _26758 = NOVALUE;
    object _26757 = NOVALUE;
    object _26756 = NOVALUE;
    object _26755 = NOVALUE;
    object _26754 = NOVALUE;
    object _26753 = NOVALUE;
    object _26752 = NOVALUE;
    object _26750 = NOVALUE;
    object _26747 = NOVALUE;
    object _26746 = NOVALUE;
    object _26745 = NOVALUE;
    object _26744 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:634		sequence element_vals*/

    /** emit.e:636		if TRANSLATE and length(elements) > 10000 then*/
    if (_27TRANSLATE_20179 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_52270)){
            _26745 = SEQ_PTR(_elements_52270)->length;
    }
    else {
        _26745 = 1;
    }
    _26746 = (_26745 > 10000);
    _26745 = NOVALUE;
    if (_26746 == 0)
    {
        DeRef(_26746);
        _26746 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26746);
        _26746 = NOVALUE;
    }

    /** emit.e:637			return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_52270);
    DeRef(_obj_52271);
    DeRef(_element_vals_52276);
    return -1;
L1: 

    /** emit.e:639		element_vals = {}*/
    RefDS(_22209);
    DeRef(_element_vals_52276);
    _element_vals_52276 = _22209;

    /** emit.e:640		for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_52270)){
            _26747 = SEQ_PTR(_elements_52270)->length;
    }
    else {
        _26747 = 1;
    }
    {
        object _i_52283;
        _i_52283 = 1;
L2: 
        if (_i_52283 > _26747){
            goto L3; // [43] 183
        }

        /** emit.e:641			ep = elements[i]*/
        _2 = (object)SEQ_PTR(_elements_52270);
        _ep_52273 = (object)*(((s1_ptr)_2)->base + _i_52283);
        if (!IS_ATOM_INT(_ep_52273)){
            _ep_52273 = (object)DBL_PTR(_ep_52273)->dbl;
        }

        /** emit.e:642			if ep < 1 then*/
        if (_ep_52273 >= 1)
        goto L4; // [60] 71

        /** emit.e:644				return -1*/
        DeRefDS(_elements_52270);
        DeRef(_obj_52271);
        DeRef(_element_vals_52276);
        return -1;
L4: 

        /** emit.e:646			e = ep*/
        _e_52275 = _ep_52273;

        /** emit.e:647			obj = SymTab[e][S_OBJ]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26750 = (object)*(((s1_ptr)_2)->base + _e_52275);
        DeRef(_obj_52271);
        _2 = (object)SEQ_PTR(_26750);
        _obj_52271 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_52271);
        _26750 = NOVALUE;

        /** emit.e:648			if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26752 = (object)*(((s1_ptr)_2)->base + _e_52275);
        _2 = (object)SEQ_PTR(_26752);
        _26753 = (object)*(((s1_ptr)_2)->base + 3);
        _26752 = NOVALUE;
        if (IS_ATOM_INT(_26753)) {
            _26754 = (_26753 == 2);
        }
        else {
            _26754 = binary_op(EQUALS, _26753, 2);
        }
        _26753 = NOVALUE;
        if (IS_ATOM_INT(_26754)) {
            if (_26754 == 0) {
                DeRef(_26755);
                _26755 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26754)->dbl == 0.0) {
                DeRef(_26755);
                _26755 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_52271))
        _26756 = 1;
        else if (IS_ATOM_DBL(_obj_52271))
        _26756 = IS_ATOM_INT(DoubleToInt(_obj_52271));
        else
        _26756 = 0;
        DeRef(_26755);
        _26755 = (_26756 != 0);
L5: 
        if (_26755 == 0) {
            goto L6; // [123] 169
        }
        _26758 = (_27TRANSLATE_20179 == 0);
        if (_26758 != 0) {
            DeRef(_26759);
            _26759 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_52271)) {
            _26760 = (_obj_52271 >= 1);
        }
        else {
            _26760 = binary_op(GREATEREQ, _obj_52271, 1);
        }
        if (IS_ATOM_INT(_26760)) {
            if (_26760 == 0) {
                DeRef(_26761);
                _26761 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26760)->dbl == 0.0) {
                DeRef(_26761);
                _26761 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_52271)) {
            _26762 = (_obj_52271 <= 255);
        }
        else {
            _26762 = binary_op(LESSEQ, _obj_52271, 255);
        }
        DeRef(_26761);
        if (IS_ATOM_INT(_26762))
        _26761 = (_26762 != 0);
        else
        _26761 = DBL_PTR(_26762)->dbl != 0.0;
L8: 
        DeRef(_26759);
        _26759 = (_26761 != 0);
L7: 
        if (_26759 == 0)
        {
            _26759 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26759 = NOVALUE;
        }

        /** emit.e:653				element_vals = prepend(element_vals, obj)*/
        Ref(_obj_52271);
        Prepend(&_element_vals_52276, _element_vals_52276, _obj_52271);
        goto L9; // [166] 176
L6: 

        /** emit.e:655				return -1*/
        DeRefDS(_elements_52270);
        DeRef(_obj_52271);
        DeRef(_element_vals_52276);
        DeRef(_26760);
        _26760 = NOVALUE;
        DeRef(_26754);
        _26754 = NOVALUE;
        DeRef(_26762);
        _26762 = NOVALUE;
        DeRef(_26758);
        _26758 = NOVALUE;
        return -1;
L9: 

        /** emit.e:657		end for*/
        _i_52283 = _i_52283 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** emit.e:658		return element_vals*/
    DeRefDS(_elements_52270);
    DeRef(_obj_52271);
    DeRef(_26760);
    _26760 = NOVALUE;
    DeRef(_26754);
    _26754 = NOVALUE;
    DeRef(_26762);
    _26762 = NOVALUE;
    DeRef(_26758);
    _26758 = NOVALUE;
    return _element_vals_52276;
    ;
}


object _45Last_op()
{
    object _0, _1, _2;
    

    /** emit.e:664		return last_op*/
    return _45last_op_52310;
    ;
}


object _45Last_pc()
{
    object _0, _1, _2;
    

    /** emit.e:668		return last_pc*/
    return _45last_pc_52311;
    ;
}


void _45move_last_pc(object _amount_52318)
{
    object _0, _1, _2;
    

    /** emit.e:672		if last_pc > 0 then*/
    if (_45last_pc_52311 <= 0)
    goto L1; // [7] 20

    /** emit.e:673			last_pc += amount*/
    _45last_pc_52311 = _45last_pc_52311 + _amount_52318;
L1: 

    /** emit.e:675	end procedure*/
    return;
    ;
}


void _45clear_last()
{
    object _0, _1, _2;
    

    /** emit.e:678		last_op = 0*/
    _45last_op_52310 = 0;

    /** emit.e:679		last_pc = 0*/
    _45last_pc_52311 = 0;

    /** emit.e:680	end procedure*/
    return;
    ;
}


void _45clear_op()
{
    object _0, _1, _2;
    

    /** emit.e:683		previous_op = -1*/
    _27previous_op_20670 = -1;

    /** emit.e:684		assignable = FALSE*/
    _45assignable_51431 = _9FALSE_439;

    /** emit.e:685	end procedure*/
    return;
    ;
}


void _45inlined_function()
{
    object _0, _1, _2;
    

    /** emit.e:689		previous_op = PROC*/
    _27previous_op_20670 = 27;

    /** emit.e:690		assignable = TRUE*/
    _45assignable_51431 = _9TRUE_441;

    /** emit.e:691		inlined = TRUE*/
    _45inlined_52329 = _9TRUE_441;

    /** emit.e:692	end procedure*/
    return;
    ;
}


void _45add_inline_target(object _pc_52340)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52340)) {
        _1 = (object)(DBL_PTR(_pc_52340)->dbl);
        DeRefDS(_pc_52340);
        _pc_52340 = _1;
    }

    /** emit.e:696		inlined_targets &= pc*/
    Append(&_45inlined_targets_52337, _45inlined_targets_52337, _pc_52340);

    /** emit.e:697	end procedure*/
    return;
    ;
}


void _45clear_inline_targets()
{
    object _0, _1, _2;
    

    /** emit.e:700		inlined_targets = {}*/
    RefDS(_22209);
    DeRefi(_45inlined_targets_52337);
    _45inlined_targets_52337 = _22209;

    /** emit.e:701	end procedure*/
    return;
    ;
}


void _45emit_inline(object _code_52346)
{
    object _0, _1, _2;
    

    /** emit.e:704		last_pc = 0*/
    _45last_pc_52311 = 0;

    /** emit.e:705		last_op = 0*/
    _45last_op_52310 = 0;

    /** emit.e:706		Code &= code*/
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _code_52346);

    /** emit.e:707	end procedure*/
    DeRefDS(_code_52346);
    return;
    ;
}


void _45emit_op(object _op_52351)
{
    object _a_52353 = NOVALUE;
    object _b_52354 = NOVALUE;
    object _c_52355 = NOVALUE;
    object _d_52356 = NOVALUE;
    object _source_52357 = NOVALUE;
    object _target_52358 = NOVALUE;
    object _subsym_52359 = NOVALUE;
    object _lhs_var_52361 = NOVALUE;
    object _ib_52362 = NOVALUE;
    object _ic_52363 = NOVALUE;
    object _n_52364 = NOVALUE;
    object _obj_52365 = NOVALUE;
    object _elements_52366 = NOVALUE;
    object _element_vals_52367 = NOVALUE;
    object _last_pc_backup_52368 = NOVALUE;
    object _last_op_backup_52369 = NOVALUE;
    object _temp_52378 = NOVALUE;
    object _real_op_52678 = NOVALUE;
    object _ref_52685 = NOVALUE;
    object _paths_52715 = NOVALUE;
    object _if_code_52795 = NOVALUE;
    object _if_code_52834 = NOVALUE;
    object _Top_inlined_Top_at_5482_53453 = NOVALUE;
    object _element_53524 = NOVALUE;
    object _Top_inlined_Top_at_7037_53671 = NOVALUE;
    object _31990 = NOVALUE;
    object _31989 = NOVALUE;
    object _27362 = NOVALUE;
    object _27361 = NOVALUE;
    object _27360 = NOVALUE;
    object _27356 = NOVALUE;
    object _27353 = NOVALUE;
    object _27351 = NOVALUE;
    object _27345 = NOVALUE;
    object _27344 = NOVALUE;
    object _27343 = NOVALUE;
    object _27341 = NOVALUE;
    object _27339 = NOVALUE;
    object _27338 = NOVALUE;
    object _27337 = NOVALUE;
    object _27336 = NOVALUE;
    object _27335 = NOVALUE;
    object _27334 = NOVALUE;
    object _27333 = NOVALUE;
    object _27332 = NOVALUE;
    object _27331 = NOVALUE;
    object _27330 = NOVALUE;
    object _27329 = NOVALUE;
    object _27327 = NOVALUE;
    object _27326 = NOVALUE;
    object _27325 = NOVALUE;
    object _27323 = NOVALUE;
    object _27322 = NOVALUE;
    object _27321 = NOVALUE;
    object _27320 = NOVALUE;
    object _27319 = NOVALUE;
    object _27318 = NOVALUE;
    object _27317 = NOVALUE;
    object _27316 = NOVALUE;
    object _27315 = NOVALUE;
    object _27312 = NOVALUE;
    object _27309 = NOVALUE;
    object _27308 = NOVALUE;
    object _27307 = NOVALUE;
    object _27306 = NOVALUE;
    object _27304 = NOVALUE;
    object _27302 = NOVALUE;
    object _27290 = NOVALUE;
    object _27282 = NOVALUE;
    object _27279 = NOVALUE;
    object _27278 = NOVALUE;
    object _27277 = NOVALUE;
    object _27276 = NOVALUE;
    object _27273 = NOVALUE;
    object _27272 = NOVALUE;
    object _27271 = NOVALUE;
    object _27270 = NOVALUE;
    object _27269 = NOVALUE;
    object _27268 = NOVALUE;
    object _27267 = NOVALUE;
    object _27266 = NOVALUE;
    object _27265 = NOVALUE;
    object _27264 = NOVALUE;
    object _27263 = NOVALUE;
    object _27261 = NOVALUE;
    object _27257 = NOVALUE;
    object _27256 = NOVALUE;
    object _27255 = NOVALUE;
    object _27254 = NOVALUE;
    object _27253 = NOVALUE;
    object _27252 = NOVALUE;
    object _27251 = NOVALUE;
    object _27250 = NOVALUE;
    object _27249 = NOVALUE;
    object _27248 = NOVALUE;
    object _27247 = NOVALUE;
    object _27245 = NOVALUE;
    object _27240 = NOVALUE;
    object _27239 = NOVALUE;
    object _27237 = NOVALUE;
    object _27236 = NOVALUE;
    object _27235 = NOVALUE;
    object _27233 = NOVALUE;
    object _27230 = NOVALUE;
    object _27226 = NOVALUE;
    object _27223 = NOVALUE;
    object _27222 = NOVALUE;
    object _27221 = NOVALUE;
    object _27220 = NOVALUE;
    object _27219 = NOVALUE;
    object _27218 = NOVALUE;
    object _27216 = NOVALUE;
    object _27215 = NOVALUE;
    object _27213 = NOVALUE;
    object _27212 = NOVALUE;
    object _27211 = NOVALUE;
    object _27210 = NOVALUE;
    object _27209 = NOVALUE;
    object _27208 = NOVALUE;
    object _27207 = NOVALUE;
    object _27206 = NOVALUE;
    object _27205 = NOVALUE;
    object _27204 = NOVALUE;
    object _27202 = NOVALUE;
    object _27201 = NOVALUE;
    object _27200 = NOVALUE;
    object _27199 = NOVALUE;
    object _27198 = NOVALUE;
    object _27197 = NOVALUE;
    object _27196 = NOVALUE;
    object _27195 = NOVALUE;
    object _27194 = NOVALUE;
    object _27193 = NOVALUE;
    object _27192 = NOVALUE;
    object _27191 = NOVALUE;
    object _27190 = NOVALUE;
    object _27189 = NOVALUE;
    object _27188 = NOVALUE;
    object _27186 = NOVALUE;
    object _27183 = NOVALUE;
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27180 = NOVALUE;
    object _27179 = NOVALUE;
    object _27178 = NOVALUE;
    object _27177 = NOVALUE;
    object _27176 = NOVALUE;
    object _27175 = NOVALUE;
    object _27174 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _27170 = NOVALUE;
    object _27169 = NOVALUE;
    object _27167 = NOVALUE;
    object _27163 = NOVALUE;
    object _27161 = NOVALUE;
    object _27160 = NOVALUE;
    object _27158 = NOVALUE;
    object _27156 = NOVALUE;
    object _27154 = NOVALUE;
    object _27153 = NOVALUE;
    object _27151 = NOVALUE;
    object _27150 = NOVALUE;
    object _27149 = NOVALUE;
    object _27148 = NOVALUE;
    object _27147 = NOVALUE;
    object _27146 = NOVALUE;
    object _27145 = NOVALUE;
    object _27144 = NOVALUE;
    object _27143 = NOVALUE;
    object _27142 = NOVALUE;
    object _27141 = NOVALUE;
    object _27140 = NOVALUE;
    object _27139 = NOVALUE;
    object _27138 = NOVALUE;
    object _27137 = NOVALUE;
    object _27136 = NOVALUE;
    object _27135 = NOVALUE;
    object _27134 = NOVALUE;
    object _27133 = NOVALUE;
    object _27131 = NOVALUE;
    object _27129 = NOVALUE;
    object _27128 = NOVALUE;
    object _27126 = NOVALUE;
    object _27123 = NOVALUE;
    object _27122 = NOVALUE;
    object _27120 = NOVALUE;
    object _27119 = NOVALUE;
    object _27118 = NOVALUE;
    object _27116 = NOVALUE;
    object _27108 = NOVALUE;
    object _27107 = NOVALUE;
    object _27106 = NOVALUE;
    object _27105 = NOVALUE;
    object _27104 = NOVALUE;
    object _27103 = NOVALUE;
    object _27102 = NOVALUE;
    object _27101 = NOVALUE;
    object _27100 = NOVALUE;
    object _27099 = NOVALUE;
    object _27098 = NOVALUE;
    object _27097 = NOVALUE;
    object _27096 = NOVALUE;
    object _27095 = NOVALUE;
    object _27094 = NOVALUE;
    object _27093 = NOVALUE;
    object _27092 = NOVALUE;
    object _27091 = NOVALUE;
    object _27090 = NOVALUE;
    object _27089 = NOVALUE;
    object _27088 = NOVALUE;
    object _27087 = NOVALUE;
    object _27086 = NOVALUE;
    object _27085 = NOVALUE;
    object _27079 = NOVALUE;
    object _27078 = NOVALUE;
    object _27075 = NOVALUE;
    object _27072 = NOVALUE;
    object _27071 = NOVALUE;
    object _27070 = NOVALUE;
    object _27069 = NOVALUE;
    object _27068 = NOVALUE;
    object _27067 = NOVALUE;
    object _27066 = NOVALUE;
    object _27065 = NOVALUE;
    object _27064 = NOVALUE;
    object _27063 = NOVALUE;
    object _27061 = NOVALUE;
    object _27060 = NOVALUE;
    object _27059 = NOVALUE;
    object _27057 = NOVALUE;
    object _27055 = NOVALUE;
    object _27054 = NOVALUE;
    object _27053 = NOVALUE;
    object _27052 = NOVALUE;
    object _27051 = NOVALUE;
    object _27050 = NOVALUE;
    object _27049 = NOVALUE;
    object _27048 = NOVALUE;
    object _27047 = NOVALUE;
    object _27046 = NOVALUE;
    object _27044 = NOVALUE;
    object _27043 = NOVALUE;
    object _27041 = NOVALUE;
    object _27040 = NOVALUE;
    object _27039 = NOVALUE;
    object _27038 = NOVALUE;
    object _27037 = NOVALUE;
    object _27035 = NOVALUE;
    object _27034 = NOVALUE;
    object _27033 = NOVALUE;
    object _27032 = NOVALUE;
    object _27031 = NOVALUE;
    object _27030 = NOVALUE;
    object _27029 = NOVALUE;
    object _27028 = NOVALUE;
    object _27026 = NOVALUE;
    object _27025 = NOVALUE;
    object _27024 = NOVALUE;
    object _27023 = NOVALUE;
    object _27022 = NOVALUE;
    object _27020 = NOVALUE;
    object _27019 = NOVALUE;
    object _27017 = NOVALUE;
    object _27016 = NOVALUE;
    object _27015 = NOVALUE;
    object _27014 = NOVALUE;
    object _27013 = NOVALUE;
    object _27011 = NOVALUE;
    object _27009 = NOVALUE;
    object _27007 = NOVALUE;
    object _27006 = NOVALUE;
    object _27004 = NOVALUE;
    object _27003 = NOVALUE;
    object _27002 = NOVALUE;
    object _27001 = NOVALUE;
    object _27000 = NOVALUE;
    object _26999 = NOVALUE;
    object _26998 = NOVALUE;
    object _26997 = NOVALUE;
    object _26996 = NOVALUE;
    object _26995 = NOVALUE;
    object _26994 = NOVALUE;
    object _26993 = NOVALUE;
    object _26992 = NOVALUE;
    object _26991 = NOVALUE;
    object _26990 = NOVALUE;
    object _26989 = NOVALUE;
    object _26988 = NOVALUE;
    object _26985 = NOVALUE;
    object _26984 = NOVALUE;
    object _26982 = NOVALUE;
    object _26981 = NOVALUE;
    object _26980 = NOVALUE;
    object _26979 = NOVALUE;
    object _26978 = NOVALUE;
    object _26976 = NOVALUE;
    object _26974 = NOVALUE;
    object _26973 = NOVALUE;
    object _26972 = NOVALUE;
    object _26971 = NOVALUE;
    object _26970 = NOVALUE;
    object _26969 = NOVALUE;
    object _26968 = NOVALUE;
    object _26967 = NOVALUE;
    object _26966 = NOVALUE;
    object _26963 = NOVALUE;
    object _26962 = NOVALUE;
    object _26960 = NOVALUE;
    object _26959 = NOVALUE;
    object _26958 = NOVALUE;
    object _26957 = NOVALUE;
    object _26956 = NOVALUE;
    object _26953 = NOVALUE;
    object _26952 = NOVALUE;
    object _26951 = NOVALUE;
    object _26950 = NOVALUE;
    object _26949 = NOVALUE;
    object _26948 = NOVALUE;
    object _26947 = NOVALUE;
    object _26942 = NOVALUE;
    object _26941 = NOVALUE;
    object _26940 = NOVALUE;
    object _26938 = NOVALUE;
    object _26937 = NOVALUE;
    object _26935 = NOVALUE;
    object _26934 = NOVALUE;
    object _26929 = NOVALUE;
    object _26928 = NOVALUE;
    object _26927 = NOVALUE;
    object _26926 = NOVALUE;
    object _26925 = NOVALUE;
    object _26919 = NOVALUE;
    object _26918 = NOVALUE;
    object _26916 = NOVALUE;
    object _26915 = NOVALUE;
    object _26914 = NOVALUE;
    object _26913 = NOVALUE;
    object _26912 = NOVALUE;
    object _26911 = NOVALUE;
    object _26910 = NOVALUE;
    object _26909 = NOVALUE;
    object _26908 = NOVALUE;
    object _26907 = NOVALUE;
    object _26906 = NOVALUE;
    object _26904 = NOVALUE;
    object _26903 = NOVALUE;
    object _26902 = NOVALUE;
    object _26901 = NOVALUE;
    object _26900 = NOVALUE;
    object _26899 = NOVALUE;
    object _26898 = NOVALUE;
    object _26897 = NOVALUE;
    object _26896 = NOVALUE;
    object _26895 = NOVALUE;
    object _26894 = NOVALUE;
    object _26893 = NOVALUE;
    object _26892 = NOVALUE;
    object _26891 = NOVALUE;
    object _26889 = NOVALUE;
    object _26888 = NOVALUE;
    object _26887 = NOVALUE;
    object _26886 = NOVALUE;
    object _26883 = NOVALUE;
    object _26882 = NOVALUE;
    object _26881 = NOVALUE;
    object _26880 = NOVALUE;
    object _26878 = NOVALUE;
    object _26877 = NOVALUE;
    object _26876 = NOVALUE;
    object _26875 = NOVALUE;
    object _26873 = NOVALUE;
    object _26872 = NOVALUE;
    object _26871 = NOVALUE;
    object _26870 = NOVALUE;
    object _26869 = NOVALUE;
    object _26868 = NOVALUE;
    object _26867 = NOVALUE;
    object _26866 = NOVALUE;
    object _26865 = NOVALUE;
    object _26864 = NOVALUE;
    object _26863 = NOVALUE;
    object _26862 = NOVALUE;
    object _26861 = NOVALUE;
    object _26860 = NOVALUE;
    object _26858 = NOVALUE;
    object _26857 = NOVALUE;
    object _26856 = NOVALUE;
    object _26855 = NOVALUE;
    object _26854 = NOVALUE;
    object _26852 = NOVALUE;
    object _26851 = NOVALUE;
    object _26850 = NOVALUE;
    object _26849 = NOVALUE;
    object _26848 = NOVALUE;
    object _26844 = NOVALUE;
    object _26843 = NOVALUE;
    object _26842 = NOVALUE;
    object _26841 = NOVALUE;
    object _26840 = NOVALUE;
    object _26838 = NOVALUE;
    object _26837 = NOVALUE;
    object _26836 = NOVALUE;
    object _26835 = NOVALUE;
    object _26834 = NOVALUE;
    object _26833 = NOVALUE;
    object _26832 = NOVALUE;
    object _26831 = NOVALUE;
    object _26830 = NOVALUE;
    object _26829 = NOVALUE;
    object _26828 = NOVALUE;
    object _26827 = NOVALUE;
    object _26826 = NOVALUE;
    object _26825 = NOVALUE;
    object _26824 = NOVALUE;
    object _26823 = NOVALUE;
    object _26822 = NOVALUE;
    object _26821 = NOVALUE;
    object _26819 = NOVALUE;
    object _26818 = NOVALUE;
    object _26817 = NOVALUE;
    object _26816 = NOVALUE;
    object _26815 = NOVALUE;
    object _26814 = NOVALUE;
    object _26813 = NOVALUE;
    object _26812 = NOVALUE;
    object _26811 = NOVALUE;
    object _26809 = NOVALUE;
    object _26808 = NOVALUE;
    object _26807 = NOVALUE;
    object _26805 = NOVALUE;
    object _26804 = NOVALUE;
    object _26802 = NOVALUE;
    object _26800 = NOVALUE;
    object _26799 = NOVALUE;
    object _26798 = NOVALUE;
    object _26797 = NOVALUE;
    object _26796 = NOVALUE;
    object _26795 = NOVALUE;
    object _26791 = NOVALUE;
    object _26790 = NOVALUE;
    object _26789 = NOVALUE;
    object _26787 = NOVALUE;
    object _26786 = NOVALUE;
    object _26785 = NOVALUE;
    object _26784 = NOVALUE;
    object _26783 = NOVALUE;
    object _26782 = NOVALUE;
    object _26781 = NOVALUE;
    object _26780 = NOVALUE;
    object _26779 = NOVALUE;
    object _26778 = NOVALUE;
    object _26777 = NOVALUE;
    object _26776 = NOVALUE;
    object _26775 = NOVALUE;
    object _26774 = NOVALUE;
    object _26773 = NOVALUE;
    object _26768 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_52351)) {
        _1 = (object)(DBL_PTR(_op_52351)->dbl);
        DeRefDS(_op_52351);
        _op_52351 = _1;
    }

    /** emit.e:717		integer ib, ic, n*/

    /** emit.e:718		object obj*/

    /** emit.e:719		sequence elements*/

    /** emit.e:720		object element_vals*/

    /** emit.e:722		check_for_temps()*/
    _45check_for_temps();

    /** emit.e:723		integer last_pc_backup = last_pc*/
    _last_pc_backup_52368 = _45last_pc_52311;

    /** emit.e:724		integer last_op_backup = last_op*/
    _last_op_backup_52369 = _45last_op_52310;

    /** emit.e:726		last_op = op*/
    _45last_op_52310 = _op_52351;

    /** emit.e:727		last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _26768 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _26768 = 1;
    }
    _45last_pc_52311 = _26768 + 1;
    _26768 = NOVALUE;

    /** emit.e:729		switch op label "EMIT" do*/
    _0 = _op_52351;
    switch ( _0 ){ 

        /** emit.e:730		case ASSIGN then*/
        case 18:

        /** emit.e:731			sequence temp = {}*/
        RefDS(_22209);
        DeRef(_temp_52378);
        _temp_52378 = _22209;

        /** emit.e:732			if not TRANSLATE and*/
        _26773 = (_27TRANSLATE_20179 == 0);
        if (_26773 == 0) {
            goto L1; // [70] 202
        }
        _26775 = (_27previous_op_20670 == 92);
        if (_26775 != 0) {
            DeRef(_26776);
            _26776 = 1;
            goto L2; // [82] 98
        }
        _26777 = (_27previous_op_20670 == 25);
        _26776 = (_26777 != 0);
L2: 
        if (_26776 == 0)
        {
            _26776 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26776 = NOVALUE;
        }

        /** emit.e:736				while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_27Code_20660)){
                _26778 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26778 = 1;
        }
        _26779 = _26778 - 1;
        _26778 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26780 = (object)*(((s1_ptr)_2)->base + _26779);
        if (IS_ATOM_INT(_26780)) {
            _26781 = (_26780 == 208);
        }
        else {
            _26781 = binary_op(EQUALS, _26780, 208);
        }
        _26780 = NOVALUE;
        if (IS_ATOM_INT(_26781)) {
            if (_26781 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26781)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _26783 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26783 = 1;
        }
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26784 = (object)*(((s1_ptr)_2)->base + _26783);
        _26785 = find_from(_26784, _45derefs_51932, 1);
        _26784 = NOVALUE;
        if (_26785 == 0)
        {
            _26785 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26785 = NOVALUE;
        }

        /** emit.e:739					temp &= Code[$]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26786 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26786 = 1;
        }
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26787 = (object)*(((s1_ptr)_2)->base + _26786);
        if (IS_SEQUENCE(_temp_52378) && IS_ATOM(_26787)) {
            Ref(_26787);
            Append(&_temp_52378, _temp_52378, _26787);
        }
        else if (IS_ATOM(_temp_52378) && IS_SEQUENCE(_26787)) {
        }
        else {
            Concat((object_ptr)&_temp_52378, _temp_52378, _26787);
        }
        _26787 = NOVALUE;

        /** emit.e:740					Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26789 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26789 = 1;
        }
        _26790 = _26789 - 1;
        _26789 = NOVALUE;
        if (IS_SEQUENCE(_27Code_20660)){
                _26791 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26791 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_27Code_20660);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26790)) ? _26790 : (object)(DBL_PTR(_26790)->dbl);
            int stop = (IS_ATOM_INT(_26791)) ? _26791 : (object)(DBL_PTR(_26791)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_27Code_20660), start, &_27Code_20660 );
                }
                else Tail(SEQ_PTR(_27Code_20660), stop+1, &_27Code_20660);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_27Code_20660), start, &_27Code_20660);
            }
            else {
                assign_slice_seq = &assign_space;
                _27Code_20660 = Remove_elements(start, stop, (SEQ_PTR(_27Code_20660)->ref == 1));
            }
        }
        _26790 = NOVALUE;
        _26791 = NOVALUE;

        /** emit.e:741					emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_52378);
        _45emit_temp(_temp_52378, 1);

        /** emit.e:742				end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** emit.e:746			source = Pop()*/
        _source_52357 = _45Pop();
        if (!IS_ATOM_INT(_source_52357)) {
            _1 = (object)(DBL_PTR(_source_52357)->dbl);
            DeRefDS(_source_52357);
            _source_52357 = _1;
        }

        /** emit.e:747			target = Pop()*/
        _target_52358 = _45Pop();
        if (!IS_ATOM_INT(_target_52358)) {
            _1 = (object)(DBL_PTR(_target_52358)->dbl);
            DeRefDS(_target_52358);
            _target_52358 = _1;
        }

        /** emit.e:748			if assignable then*/
        if (_45assignable_51431 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** emit.e:750				if inlined then*/
        if (_45inlined_52329 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** emit.e:751					inlined = 0*/
        _45inlined_52329 = 0;

        /** emit.e:752					if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_45inlined_targets_52337)){
                _26795 = SEQ_PTR(_45inlined_targets_52337)->length;
        }
        else {
            _26795 = 1;
        }
        if (_26795 == 0)
        {
            _26795 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26795 = NOVALUE;
        }

        /** emit.e:753						for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_45inlined_targets_52337)){
                _26796 = SEQ_PTR(_45inlined_targets_52337)->length;
        }
        else {
            _26796 = 1;
        }
        {
            object _i_52421;
            _i_52421 = 1;
L8: 
            if (_i_52421 > _26796){
                goto L9; // [252] 280
            }

            /** emit.e:754							Code[inlined_targets[i]] = target*/
            _2 = (object)SEQ_PTR(_45inlined_targets_52337);
            _26797 = (object)*(((s1_ptr)_2)->base + _i_52421);
            _2 = (object)SEQ_PTR(_27Code_20660);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _27Code_20660 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _26797);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _target_52358;
            DeRef(_1);

            /** emit.e:755						end for*/
            _i_52421 = _i_52421 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** emit.e:756						clear_inline_targets()*/

        /** emit.e:700		inlined_targets = {}*/
        RefDS(_22209);
        DeRefi(_45inlined_targets_52337);
        _45inlined_targets_52337 = _22209;

        /** emit.e:701	end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** emit.e:759					assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:760					clear_last()*/

        /** emit.e:678		last_op = 0*/
        _45last_op_52310 = 0;

        /** emit.e:679		last_pc = 0*/
        _45last_pc_52311 = 0;

        /** emit.e:680	end procedure*/
        goto LB; // [316] 319
LB: 

        /** emit.e:761					break "EMIT"*/
        DeRef(_temp_52378);
        _temp_52378 = NOVALUE;
        goto LC; // [323] 7739
L6: 

        /** emit.e:764				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26798 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26798 = 1;
        }
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26799 = (object)*(((s1_ptr)_2)->base + _26798);
        Ref(_26799);
        _45clear_temp(_26799);
        _26799 = NOVALUE;

        /** emit.e:765				Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26800 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26800 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_27Code_20660);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26800)) ? _26800 : (object)(DBL_PTR(_26800)->dbl);
            int stop = (IS_ATOM_INT(_26800)) ? _26800 : (object)(DBL_PTR(_26800)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_27Code_20660), start, &_27Code_20660 );
                }
                else Tail(SEQ_PTR(_27Code_20660), stop+1, &_27Code_20660);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_27Code_20660), start, &_27Code_20660);
            }
            else {
                assign_slice_seq = &assign_space;
                _27Code_20660 = Remove_elements(start, stop, (SEQ_PTR(_27Code_20660)->ref == 1));
            }
        }
        _26800 = NOVALUE;
        _26800 = NOVALUE;

        /** emit.e:766				op = previous_op -- keep same previous op*/
        _op_52351 = _27previous_op_20670;

        /** emit.e:767				if IsInteger(target) then*/
        _26802 = _45IsInteger(_target_52358);
        if (_26802 == 0) {
            DeRef(_26802);
            _26802 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26802) && DBL_PTR(_26802)->dbl == 0.0){
                DeRef(_26802);
                _26802 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26802);
            _26802 = NOVALUE;
        }
        DeRef(_26802);
        _26802 = NOVALUE;

        /** emit.e:768					if previous_op = RHS_SUBS then*/
        if (_27previous_op_20670 != 25)
        goto LE; // [381] 412

        /** emit.e:769						op = RHS_SUBS_I*/
        _op_52351 = 114;

        /** emit.e:770						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26804 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26804 = 1;
        }
        _26805 = _26804 - 2;
        _26804 = NOVALUE;
        _45backpatch(_26805, 114);
        _26805 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** emit.e:772					elsif previous_op = PLUS1 then*/
        if (_27previous_op_20670 != 93)
        goto L10; // [418] 449

        /** emit.e:773						op = PLUS1_I*/
        _op_52351 = 117;

        /** emit.e:774						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26807 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26807 = 1;
        }
        _26808 = _26807 - 2;
        _26807 = NOVALUE;
        _45backpatch(_26808, 117);
        _26808 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** emit.e:776					elsif previous_op = PLUS or previous_op = MINUS then*/
        _26809 = (_27previous_op_20670 == 11);
        if (_26809 != 0) {
            goto L11; // [459] 476
        }
        _26811 = (_27previous_op_20670 == 10);
        if (_26811 == 0)
        {
            DeRef(_26811);
            _26811 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26811);
            _26811 = NOVALUE;
        }
L11: 

        /** emit.e:777						if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26812 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26812 = 1;
        }
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26813 = (object)*(((s1_ptr)_2)->base + _26812);
        Ref(_26813);
        _26814 = _45IsInteger(_26813);
        _26813 = NOVALUE;
        if (IS_ATOM_INT(_26814)) {
            if (_26814 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26814)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _26816 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26816 = 1;
        }
        _26817 = _26816 - 1;
        _26816 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26818 = (object)*(((s1_ptr)_2)->base + _26817);
        Ref(_26818);
        _26819 = _45IsInteger(_26818);
        _26818 = NOVALUE;
        if (_26819 == 0) {
            DeRef(_26819);
            _26819 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26819) && DBL_PTR(_26819)->dbl == 0.0){
                DeRef(_26819);
                _26819 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26819);
            _26819 = NOVALUE;
        }
        DeRef(_26819);
        _26819 = NOVALUE;

        /** emit.e:779							if previous_op = PLUS then*/
        if (_27previous_op_20670 != 11)
        goto L13; // [522] 538

        /** emit.e:780								op = PLUS_I*/
        _op_52351 = 115;
        goto L14; // [535] 548
L13: 

        /** emit.e:782								op = MINUS_I*/
        _op_52351 = 116;
L14: 

        /** emit.e:784							backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26821 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26821 = 1;
        }
        _26822 = _26821 - 2;
        _26821 = NOVALUE;
        _45backpatch(_26822, _op_52351);
        _26822 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** emit.e:790						if IsInteger(source) then*/
        _26823 = _45IsInteger(_source_52357);
        if (_26823 == 0) {
            DeRef(_26823);
            _26823 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26823) && DBL_PTR(_26823)->dbl == 0.0){
                DeRef(_26823);
                _26823 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26823);
            _26823 = NOVALUE;
        }
        DeRef(_26823);
        _26823 = NOVALUE;

        /** emit.e:791							op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_52351 = 113;
L15: 
LF: 
LD: 

        /** emit.e:795				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:796				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto L16; // [598] 743
L5: 

        /** emit.e:798				if IsInteger(source) and IsInteger(target) then*/
        _26824 = _45IsInteger(_source_52357);
        if (IS_ATOM_INT(_26824)) {
            if (_26824 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26824)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26826 = _45IsInteger(_target_52358);
        if (_26826 == 0) {
            DeRef(_26826);
            _26826 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26826) && DBL_PTR(_26826)->dbl == 0.0){
                DeRef(_26826);
                _26826 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26826);
            _26826 = NOVALUE;
        }
        DeRef(_26826);
        _26826 = NOVALUE;

        /** emit.e:799					op = ASSIGN_I*/
        _op_52351 = 113;
L17: 

        /** emit.e:801				if source > 0 and target > 0 and*/
        _26827 = (_source_52357 > 0);
        if (_26827 == 0) {
            _26828 = 0;
            goto L18; // [635] 647
        }
        _26829 = (_target_52358 > 0);
        _26828 = (_26829 != 0);
L18: 
        if (_26828 == 0) {
            _26830 = 0;
            goto L19; // [647] 673
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26831 = (object)*(((s1_ptr)_2)->base + _source_52357);
        _2 = (object)SEQ_PTR(_26831);
        _26832 = (object)*(((s1_ptr)_2)->base + 3);
        _26831 = NOVALUE;
        if (IS_ATOM_INT(_26832)) {
            _26833 = (_26832 == 2);
        }
        else {
            _26833 = binary_op(EQUALS, _26832, 2);
        }
        _26832 = NOVALUE;
        if (IS_ATOM_INT(_26833))
        _26830 = (_26833 != 0);
        else
        _26830 = DBL_PTR(_26833)->dbl != 0.0;
L19: 
        if (_26830 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26835 = (object)*(((s1_ptr)_2)->base + _target_52358);
        _2 = (object)SEQ_PTR(_26835);
        _26836 = (object)*(((s1_ptr)_2)->base + 3);
        _26835 = NOVALUE;
        if (IS_ATOM_INT(_26836)) {
            _26837 = (_26836 == 2);
        }
        else {
            _26837 = binary_op(EQUALS, _26836, 2);
        }
        _26836 = NOVALUE;
        if (_26837 == 0) {
            DeRef(_26837);
            _26837 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26837) && DBL_PTR(_26837)->dbl == 0.0){
                DeRef(_26837);
                _26837 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26837);
            _26837 = NOVALUE;
        }
        DeRef(_26837);
        _26837 = NOVALUE;

        /** emit.e:806					SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_target_52358 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26840 = (object)*(((s1_ptr)_2)->base + _source_52357);
        _2 = (object)SEQ_PTR(_26840);
        _26841 = (object)*(((s1_ptr)_2)->base + 1);
        _26840 = NOVALUE;
        Ref(_26841);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26841;
        if( _1 != _26841 ){
            DeRef(_1);
        }
        _26841 = NOVALUE;
        _26838 = NOVALUE;
L1A: 

        /** emit.e:809				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:810				emit_addr(source)*/
        _45emit_addr(_source_52357);

        /** emit.e:811				last_op = op*/
        _45last_op_52310 = _op_52351;
L16: 

        /** emit.e:814			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:815			emit_addr(target)*/
        _45emit_addr(_target_52358);

        /** emit.e:817			if length(temp) then*/
        if (IS_SEQUENCE(_temp_52378)){
                _26842 = SEQ_PTR(_temp_52378)->length;
        }
        else {
            _26842 = 1;
        }
        if (_26842 == 0)
        {
            _26842 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26842 = NOVALUE;
        }

        /** emit.e:819				for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_52378)){
                _26843 = SEQ_PTR(_temp_52378)->length;
        }
        else {
            _26843 = 1;
        }
        {
            object _i_52524;
            _i_52524 = 1;
L1C: 
            if (_i_52524 > _26843){
                goto L1D; // [768] 791
            }

            /** emit.e:820					flush_temp( temp[i] )*/
            _2 = (object)SEQ_PTR(_temp_52378);
            _26844 = (object)*(((s1_ptr)_2)->base + _i_52524);
            Ref(_26844);
            _45flush_temp(_26844);
            _26844 = NOVALUE;

            /** emit.e:821				end for*/
            _i_52524 = _i_52524 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_52378);
        _temp_52378 = NOVALUE;
        goto LC; // [794] 7739

        /** emit.e:824		case RHS_SUBS then*/
        case 25:

        /** emit.e:825			b = Pop() -- subscript*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:826			c = Pop() -- sequence*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:827			target = NewTempSym() -- target*/
        _target_52358 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_target_52358)) {
            _1 = (object)(DBL_PTR(_target_52358)->dbl);
            DeRefDS(_target_52358);
            _target_52358 = _1;
        }

        /** emit.e:828			if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26848 = (_c_52355 < 0);
        if (_26848 != 0) {
            _26849 = 1;
            goto L1E; // [828] 851
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26850 = (object)*(((s1_ptr)_2)->base + _c_52355);
        if (IS_SEQUENCE(_26850)){
                _26851 = SEQ_PTR(_26850)->length;
        }
        else {
            _26851 = 1;
        }
        _26850 = NOVALUE;
        _26852 = (_26851 < 15);
        _26851 = NOVALUE;
        _26849 = (_26852 != 0);
L1E: 
        if (_26849 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26854 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_26854);
        _26855 = (object)*(((s1_ptr)_2)->base + 15);
        _26854 = NOVALUE;
        if (IS_ATOM_INT(_26855)) {
            _26856 = (_26855 < 0);
        }
        else {
            _26856 = binary_op(LESS, _26855, 0);
        }
        _26855 = NOVALUE;
        if (_26856 == 0) {
            DeRef(_26856);
            _26856 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26856) && DBL_PTR(_26856)->dbl == 0.0){
                DeRef(_26856);
                _26856 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26856);
            _26856 = NOVALUE;
        }
        DeRef(_26856);
        _26856 = NOVALUE;
L1F: 

        /** emit.e:830				op = RHS_SUBS_CHECK*/
        _op_52351 = 92;
        goto L21; // [885] 1049
L20: 

        /** emit.e:831			elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26857 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_26857);
        _26858 = (object)*(((s1_ptr)_2)->base + 3);
        _26857 = NOVALUE;
        if (binary_op_a(NOTEQ, _26858, 1)){
            _26858 = NOVALUE;
            goto L22; // [904] 991
        }
        _26858 = NOVALUE;

        /** emit.e:832				if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26860 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_26860);
        _26861 = (object)*(((s1_ptr)_2)->base + 15);
        _26860 = NOVALUE;
        if (IS_ATOM_INT(_26861)) {
            _26862 = (_26861 != _53sequence_type_47188);
        }
        else {
            _26862 = binary_op(NOTEQ, _26861, _53sequence_type_47188);
        }
        _26861 = NOVALUE;
        if (IS_ATOM_INT(_26862)) {
            if (_26862 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26862)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26864 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_26864);
        _26865 = (object)*(((s1_ptr)_2)->base + 15);
        _26864 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_26865)){
            _26866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26865)->dbl));
        }
        else{
            _26866 = (object)*(((s1_ptr)_2)->base + _26865);
        }
        _2 = (object)SEQ_PTR(_26866);
        _26867 = (object)*(((s1_ptr)_2)->base + 2);
        _26866 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_26867)){
            _26868 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26867)->dbl));
        }
        else{
            _26868 = (object)*(((s1_ptr)_2)->base + _26867);
        }
        _2 = (object)SEQ_PTR(_26868);
        _26869 = (object)*(((s1_ptr)_2)->base + 15);
        _26868 = NOVALUE;
        if (IS_ATOM_INT(_26869)) {
            _26870 = (_26869 != _53sequence_type_47188);
        }
        else {
            _26870 = binary_op(NOTEQ, _26869, _53sequence_type_47188);
        }
        _26869 = NOVALUE;
        if (_26870 == 0) {
            DeRef(_26870);
            _26870 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26870) && DBL_PTR(_26870)->dbl == 0.0){
                DeRef(_26870);
                _26870 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26870);
            _26870 = NOVALUE;
        }
        DeRef(_26870);
        _26870 = NOVALUE;

        /** emit.e:835					op = RHS_SUBS_CHECK*/
        _op_52351 = 92;
        goto L21; // [988] 1049
L22: 

        /** emit.e:837			elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26871 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_26871);
        _26872 = (object)*(((s1_ptr)_2)->base + 3);
        _26871 = NOVALUE;
        if (IS_ATOM_INT(_26872)) {
            _26873 = (_26872 != 2);
        }
        else {
            _26873 = binary_op(NOTEQ, _26872, 2);
        }
        _26872 = NOVALUE;
        if (IS_ATOM_INT(_26873)) {
            if (_26873 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26873)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26875 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_26875);
        _26876 = (object)*(((s1_ptr)_2)->base + 1);
        _26875 = NOVALUE;
        _26877 = IS_SEQUENCE(_26876);
        _26876 = NOVALUE;
        _26878 = (_26877 == 0);
        _26877 = NOVALUE;
        if (_26878 == 0)
        {
            DeRef(_26878);
            _26878 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26878);
            _26878 = NOVALUE;
        }
L23: 

        /** emit.e:839				op = RHS_SUBS_CHECK*/
        _op_52351 = 92;
L24: 
L21: 

        /** emit.e:841			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:842			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:843			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:844			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:845			Push(target)*/
        _45Push(_target_52358);

        /** emit.e:846			emit_addr(target)*/
        _45emit_addr(_target_52358);

        /** emit.e:847			emit_temp(target, NEW_REFERENCE)*/
        _45emit_temp(_target_52358, 1);

        /** emit.e:848			current_sequence = append(current_sequence, target)*/
        Append(&_45current_sequence_51421, _45current_sequence_51421, _target_52358);

        /** emit.e:849			flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26880 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26880 = 1;
        }
        _26881 = _26880 - 2;
        _26880 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26882 = (object)*(((s1_ptr)_2)->base + _26881);
        Ref(_26882);
        _45flush_temp(_26882);
        _26882 = NOVALUE;
        goto LC; // [1113] 7739

        /** emit.e:851		case PROC then -- procedure, function and type calls*/
        case 27:

        /** emit.e:853			assignable = FALSE -- assume for now*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:854			subsym = op_info1*/
        _subsym_52359 = _45op_info1_51413;

        /** emit.e:855			n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26883 = (object)*(((s1_ptr)_2)->base + _subsym_52359);
        _2 = (object)SEQ_PTR(_26883);
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
            _n_52364 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        }
        else{
            _n_52364 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        }
        if (!IS_ATOM_INT(_n_52364)){
            _n_52364 = (object)DBL_PTR(_n_52364)->dbl;
        }
        _26883 = NOVALUE;

        /** emit.e:857			if subsym = CurrentSub then*/
        if (_subsym_52359 != _27CurrentSub_20579)
        goto L25; // [1155] 1340

        /** emit.e:860				for i = cgi-n+1 to cgi do*/
        _26886 = _45cgi_51429 - _n_52364;
        if ((object)((uintptr_t)_26886 +(uintptr_t) HIGH_BITS) >= 0){
            _26886 = NewDouble((eudouble)_26886);
        }
        if (IS_ATOM_INT(_26886)) {
            _26887 = _26886 + 1;
            if (_26887 > MAXINT){
                _26887 = NewDouble((eudouble)_26887);
            }
        }
        else
        _26887 = binary_op(PLUS, 1, _26886);
        DeRef(_26886);
        _26886 = NOVALUE;
        _26888 = _45cgi_51429;
        {
            object _i_52610;
            Ref(_26887);
            _i_52610 = _26887;
L26: 
            if (binary_op_a(GREATER, _i_52610, _26888)){
                goto L27; // [1176] 1339
            }

            /** emit.e:861					if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26889 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26889 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            if (binary_op_a(LESSEQ, _26889, 0)){
                _26889 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26889 = NOVALUE;

            /** emit.e:862						if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26891 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26891 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_26891)){
                _26892 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26891)->dbl));
            }
            else{
                _26892 = (object)*(((s1_ptr)_2)->base + _26891);
            }
            _2 = (object)SEQ_PTR(_26892);
            _26893 = (object)*(((s1_ptr)_2)->base + 4);
            _26892 = NOVALUE;
            if (IS_ATOM_INT(_26893)) {
                _26894 = (_26893 == 3);
            }
            else {
                _26894 = binary_op(EQUALS, _26893, 3);
            }
            _26893 = NOVALUE;
            if (IS_ATOM_INT(_26894)) {
                if (_26894 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26894)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26896 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26896 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!IS_ATOM_INT(_26896)){
                _26897 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26896)->dbl));
            }
            else{
                _26897 = (object)*(((s1_ptr)_2)->base + _26896);
            }
            _2 = (object)SEQ_PTR(_26897);
            _26898 = (object)*(((s1_ptr)_2)->base + 16);
            _26897 = NOVALUE;
            if (IS_ATOM_INT(_26898) && IS_ATOM_INT(_i_52610)) {
                _26899 = (_26898 < _i_52610);
            }
            else {
                _26899 = binary_op(LESS, _26898, _i_52610);
            }
            _26898 = NOVALUE;
            if (_26899 == 0) {
                DeRef(_26899);
                _26899 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26899) && DBL_PTR(_26899)->dbl == 0.0){
                    DeRef(_26899);
                    _26899 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26899);
                _26899 = NOVALUE;
            }
            DeRef(_26899);
            _26899 = NOVALUE;

            /** emit.e:865							emit_opcode(ASSIGN)*/
            _45emit_opcode(18);

            /** emit.e:866							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26900 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26900 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            Ref(_26900);
            _45emit_addr(_26900);
            _26900 = NOVALUE;

            /** emit.e:867							cg_stack[i] = NewTempSym()*/
            _26901 = _53NewTempSym(0);
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _i_52610);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _26901;
            if( _1 != _26901 ){
                DeRef(_1);
            }
            _26901 = NOVALUE;

            /** emit.e:868							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26902 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26902 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            Ref(_26902);
            _45emit_addr(_26902);
            _26902 = NOVALUE;

            /** emit.e:869							check_for_temps()*/
            _45check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** emit.e:870						elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26903 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26903 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            Ref(_26903);
            _26904 = _53sym_mode(_26903);
            _26903 = NOVALUE;
            if (binary_op_a(NOTEQ, _26904, 3)){
                DeRef(_26904);
                _26904 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26904);
            _26904 = NOVALUE;

            /** emit.e:871							emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52610)){
                _26906 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52610)->dbl));
            }
            else{
                _26906 = (object)*(((s1_ptr)_2)->base + _i_52610);
            }
            Ref(_26906);
            _45emit_temp(_26906, 1);
            _26906 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** emit.e:874				end for*/
            _0 = _i_52610;
            if (IS_ATOM_INT(_i_52610)) {
                _i_52610 = _i_52610 + 1;
                if ((object)((uintptr_t)_i_52610 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52610 = NewDouble((eudouble)_i_52610);
                }
            }
            else {
                _i_52610 = binary_op_a(PLUS, _i_52610, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_52610);
        }
L25: 

        /** emit.e:877			if SymTab[subsym][S_DEPRECATED] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26907 = (object)*(((s1_ptr)_2)->base + _subsym_52359);
        _2 = (object)SEQ_PTR(_26907);
        _26908 = (object)*(((s1_ptr)_2)->base + 30);
        _26907 = NOVALUE;
        if (_26908 == 0) {
            _26908 = NOVALUE;
            goto L2C; // [1354] 1383
        }
        else {
            if (!IS_ATOM_INT(_26908) && DBL_PTR(_26908)->dbl == 0.0){
                _26908 = NOVALUE;
                goto L2C; // [1354] 1383
            }
            _26908 = NOVALUE;
        }
        _26908 = NOVALUE;

        /** emit.e:878				Warning(327, deprecated_warning_flag, { SymTab[subsym][S_NAME] })*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26909 = (object)*(((s1_ptr)_2)->base + _subsym_52359);
        _2 = (object)SEQ_PTR(_26909);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _26910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _26910 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _26909 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_26910);
        ((intptr_t*)_2)[1] = _26910;
        _26911 = MAKE_SEQ(_1);
        _26910 = NOVALUE;
        _49Warning(327, 16384, _26911);
        _26911 = NOVALUE;
L2C: 

        /** emit.e:881			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:882			emit_addr(subsym)*/
        _45emit_addr(_subsym_52359);

        /** emit.e:883			for i = cgi-n+1 to cgi do*/
        _26912 = _45cgi_51429 - _n_52364;
        if ((object)((uintptr_t)_26912 +(uintptr_t) HIGH_BITS) >= 0){
            _26912 = NewDouble((eudouble)_26912);
        }
        if (IS_ATOM_INT(_26912)) {
            _26913 = _26912 + 1;
            if (_26913 > MAXINT){
                _26913 = NewDouble((eudouble)_26913);
            }
        }
        else
        _26913 = binary_op(PLUS, 1, _26912);
        DeRef(_26912);
        _26912 = NOVALUE;
        _26914 = _45cgi_51429;
        {
            object _i_52657;
            Ref(_26913);
            _i_52657 = _26913;
L2D: 
            if (binary_op_a(GREATER, _i_52657, _26914)){
                goto L2E; // [1410] 1447
            }

            /** emit.e:884				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52657)){
                _26915 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52657)->dbl));
            }
            else{
                _26915 = (object)*(((s1_ptr)_2)->base + _i_52657);
            }
            Ref(_26915);
            _45emit_addr(_26915);
            _26915 = NOVALUE;

            /** emit.e:885				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52657)){
                _26916 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52657)->dbl));
            }
            else{
                _26916 = (object)*(((s1_ptr)_2)->base + _i_52657);
            }
            Ref(_26916);
            _45emit_temp(_26916, 1);
            _26916 = NOVALUE;

            /** emit.e:886			end for*/
            _0 = _i_52657;
            if (IS_ATOM_INT(_i_52657)) {
                _i_52657 = _i_52657 + 1;
                if ((object)((uintptr_t)_i_52657 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52657 = NewDouble((eudouble)_i_52657);
                }
            }
            else {
                _i_52657 = binary_op_a(PLUS, _i_52657, 1);
            }
            DeRef(_0);
            goto L2D; // [1442] 1417
L2E: 
            ;
            DeRef(_i_52657);
        }

        /** emit.e:888			cgi -= n*/
        _45cgi_51429 = _45cgi_51429 - _n_52364;

        /** emit.e:890			if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26918 = (object)*(((s1_ptr)_2)->base + _subsym_52359);
        _2 = (object)SEQ_PTR(_26918);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _26919 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _26919 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _26918 = NOVALUE;
        if (binary_op_a(EQUALS, _26919, 27)){
            _26919 = NOVALUE;
            goto LC; // [1471] 7739
        }
        _26919 = NOVALUE;

        /** emit.e:891				assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:892				c = NewTempSym() -- put final result in temp*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:893				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);

        /** emit.e:894				Push(c)*/
        _45Push(_c_52355);

        /** emit.e:896				emit_addr(c)*/
        _45emit_addr(_c_52355);
        goto LC; // [1507] 7739

        /** emit.e:900		case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** emit.e:901			assignable = FALSE -- assume for now*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:902			integer real_op*/

        /** emit.e:903			if op = PROC_FORWARD then*/
        if (_op_52351 != 195)
        goto L2F; // [1528] 1544

        /** emit.e:904				real_op = PROC*/
        _real_op_52678 = 27;
        goto L30; // [1541] 1554
L2F: 

        /** emit.e:906				real_op = FUNC*/
        _real_op_52678 = 501;
L30: 

        /** emit.e:908			integer ref*/

        /** emit.e:909			ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_52685 = _42new_forward_reference(_real_op_52678, _45op_info1_51413, _real_op_52678);
        if (!IS_ATOM_INT(_ref_52685)) {
            _1 = (object)(DBL_PTR(_ref_52685)->dbl);
            DeRefDS(_ref_52685);
            _ref_52685 = _1;
        }

        /** emit.e:910			n = Pop() -- number of known args*/
        _n_52364 = _45Pop();
        if (!IS_ATOM_INT(_n_52364)) {
            _1 = (object)(DBL_PTR(_n_52364)->dbl);
            DeRefDS(_n_52364);
            _n_52364 = _1;
        }

        /** emit.e:912			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:913			emit_addr(ref)*/
        _45emit_addr(_ref_52685);

        /** emit.e:914			emit_addr( n ) -- this changes to be the "next" instruction*/
        _45emit_addr(_n_52364);

        /** emit.e:915			for i = cgi-n+1 to cgi do*/
        _26925 = _45cgi_51429 - _n_52364;
        if ((object)((uintptr_t)_26925 +(uintptr_t) HIGH_BITS) >= 0){
            _26925 = NewDouble((eudouble)_26925);
        }
        if (IS_ATOM_INT(_26925)) {
            _26926 = _26925 + 1;
            if (_26926 > MAXINT){
                _26926 = NewDouble((eudouble)_26926);
            }
        }
        else
        _26926 = binary_op(PLUS, 1, _26925);
        DeRef(_26925);
        _26925 = NOVALUE;
        _26927 = _45cgi_51429;
        {
            object _i_52690;
            Ref(_26926);
            _i_52690 = _26926;
L31: 
            if (binary_op_a(GREATER, _i_52690, _26927)){
                goto L32; // [1609] 1646
            }

            /** emit.e:916				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52690)){
                _26928 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52690)->dbl));
            }
            else{
                _26928 = (object)*(((s1_ptr)_2)->base + _i_52690);
            }
            Ref(_26928);
            _45emit_addr(_26928);
            _26928 = NOVALUE;

            /** emit.e:917				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_45cg_stack_51428);
            if (!IS_ATOM_INT(_i_52690)){
                _26929 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52690)->dbl));
            }
            else{
                _26929 = (object)*(((s1_ptr)_2)->base + _i_52690);
            }
            Ref(_26929);
            _45emit_temp(_26929, 1);
            _26929 = NOVALUE;

            /** emit.e:918			end for*/
            _0 = _i_52690;
            if (IS_ATOM_INT(_i_52690)) {
                _i_52690 = _i_52690 + 1;
                if ((object)((uintptr_t)_i_52690 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52690 = NewDouble((eudouble)_i_52690);
                }
            }
            else {
                _i_52690 = binary_op_a(PLUS, _i_52690, 1);
            }
            DeRef(_0);
            goto L31; // [1641] 1616
L32: 
            ;
            DeRef(_i_52690);
        }

        /** emit.e:919			cgi -= n*/
        _45cgi_51429 = _45cgi_51429 - _n_52364;

        /** emit.e:921			if op != PROC_FORWARD then*/
        if (_op_52351 == 195)
        goto L33; // [1658] 1694

        /** emit.e:922				assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:923				c = NewTempSym() -- put final result in temp*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:924				Push(c)*/
        _45Push(_c_52355);

        /** emit.e:926				emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:927				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);
L33: 
        goto LC; // [1696] 7739

        /** emit.e:930		case WARNING then*/
        case 506:

        /** emit.e:931			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:932		    a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:933			Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26934 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_26934);
        _26935 = (object)*(((s1_ptr)_2)->base + 1);
        _26934 = NOVALUE;
        Ref(_26935);
        RefDS(_22209);
        _49Warning(_26935, 64, _22209);
        _26935 = NOVALUE;
        goto LC; // [1737] 7739

        /** emit.e:935		case INCLUDE_PATHS then*/
        case 507:

        /** emit.e:936			sequence paths*/

        /** emit.e:938			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:939		    a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:940		    emit_opcode(RIGHT_BRACE_N)*/
        _45emit_opcode(31);

        /** emit.e:941		    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26937 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_26937);
        _26938 = (object)*(((s1_ptr)_2)->base + 1);
        _26937 = NOVALUE;
        Ref(_26938);
        _0 = _paths_52715;
        _paths_52715 = _46Include_paths(_26938);
        DeRef(_0);
        _26938 = NOVALUE;

        /** emit.e:942		    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_52715)){
                _26940 = SEQ_PTR(_paths_52715)->length;
        }
        else {
            _26940 = 1;
        }
        _45emit(_26940);
        _26940 = NOVALUE;

        /** emit.e:943		    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_52715)){
                _26941 = SEQ_PTR(_paths_52715)->length;
        }
        else {
            _26941 = 1;
        }
        {
            object _i_52727;
            _i_52727 = _26941;
L34: 
            if (_i_52727 < 1){
                goto L35; // [1799] 1830
            }

            /** emit.e:944		        c = NewStringSym(paths[i])*/
            _2 = (object)SEQ_PTR(_paths_52715);
            _26942 = (object)*(((s1_ptr)_2)->base + _i_52727);
            Ref(_26942);
            _c_52355 = _53NewStringSym(_26942);
            _26942 = NOVALUE;
            if (!IS_ATOM_INT(_c_52355)) {
                _1 = (object)(DBL_PTR(_c_52355)->dbl);
                DeRefDS(_c_52355);
                _c_52355 = _1;
            }

            /** emit.e:945		        emit_addr(c)*/
            _45emit_addr(_c_52355);

            /** emit.e:946		    end for*/
            _i_52727 = _i_52727 + -1;
            goto L34; // [1825] 1806
L35: 
            ;
        }

        /** emit.e:947		    b = NewTempSym()*/
        _b_52354 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:948			emit_temp(b, NEW_REFERENCE)*/
        _45emit_temp(_b_52354, 1);

        /** emit.e:949		    Push(b)*/
        _45Push(_b_52354);

        /** emit.e:950		    emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:951			last_op = RIGHT_BRACE_N*/
        _45last_op_52310 = 31;

        /** emit.e:952			op = last_op*/
        _op_52351 = 31;
        DeRef(_paths_52715);
        _paths_52715 = NOVALUE;
        goto LC; // [1872] 7739

        /** emit.e:955		case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** emit.e:961			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:962			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:963			if op = UPDATE_GLOBALS then*/
        if (_op_52351 != 89)
        goto LC; // [1944] 7739

        /** emit.e:964				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:965				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto LC; // [1959] 7739

        /** emit.e:969		case IF, WHILE then*/
        case 20:
        case 47:

        /** emit.e:970			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:971			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:973			if previous_op >= LESS and previous_op <= NOT then*/
        _26947 = (_27previous_op_20670 >= 1);
        if (_26947 == 0) {
            goto L36; // [1991] 2283
        }
        _26949 = (_27previous_op_20670 <= 7);
        if (_26949 == 0)
        {
            DeRef(_26949);
            _26949 = NOVALUE;
            goto L36; // [2004] 2283
        }
        else{
            DeRef(_26949);
            _26949 = NOVALUE;
        }

        /** emit.e:974				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26950 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26950 = 1;
        }
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26951 = (object)*(((s1_ptr)_2)->base + _26950);
        Ref(_26951);
        _45clear_temp(_26951);
        _26951 = NOVALUE;

        /** emit.e:975				Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26952 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26952 = 1;
        }
        _26953 = _26952 - 1;
        _26952 = NOVALUE;
        rhs_slice_target = (object_ptr)&_27Code_20660;
        RHS_Slice(_27Code_20660, 1, _26953);

        /** emit.e:976				if previous_op = NOT then*/
        if (_27previous_op_20670 != 7)
        goto L37; // [2045] 2125

        /** emit.e:977					op = NOT_IFW*/
        _op_52351 = 108;

        /** emit.e:978					backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26956 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26956 = 1;
        }
        _26957 = _26956 - 1;
        _26956 = NOVALUE;
        _45backpatch(_26957, 108);
        _26957 = NOVALUE;

        /** emit.e:979					sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26958 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26958 = 1;
        }
        _26959 = _26958 - 1;
        _26958 = NOVALUE;
        if (IS_SEQUENCE(_27Code_20660)){
                _26960 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26960 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52795;
        RHS_Slice(_27Code_20660, _26959, _26960);

        /** emit.e:980					Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26962 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26962 = 1;
        }
        _26963 = _26962 - 2;
        _26962 = NOVALUE;
        rhs_slice_target = (object_ptr)&_27Code_20660;
        RHS_Slice(_27Code_20660, 1, _26963);

        /** emit.e:981					Code &= if_code*/
        Concat((object_ptr)&_27Code_20660, _27Code_20660, _if_code_52795);
        DeRefDS(_if_code_52795);
        _if_code_52795 = NOVALUE;
        goto L38; // [2122] 2270
L37: 

        /** emit.e:983					if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26966 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26966 = 1;
        }
        _26967 = _26966 - 1;
        _26966 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26968 = (object)*(((s1_ptr)_2)->base + _26967);
        Ref(_26968);
        _26969 = _45IsInteger(_26968);
        _26968 = NOVALUE;
        if (IS_ATOM_INT(_26969)) {
            if (_26969 == 0) {
                goto L39; // [2144] 2186
            }
        }
        else {
            if (DBL_PTR(_26969)->dbl == 0.0) {
                goto L39; // [2144] 2186
            }
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _26971 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26971 = 1;
        }
        _2 = (object)SEQ_PTR(_27Code_20660);
        _26972 = (object)*(((s1_ptr)_2)->base + _26971);
        Ref(_26972);
        _26973 = _45IsInteger(_26972);
        _26972 = NOVALUE;
        if (_26973 == 0) {
            DeRef(_26973);
            _26973 = NOVALUE;
            goto L39; // [2162] 2186
        }
        else {
            if (!IS_ATOM_INT(_26973) && DBL_PTR(_26973)->dbl == 0.0){
                DeRef(_26973);
                _26973 = NOVALUE;
                goto L39; // [2162] 2186
            }
            DeRef(_26973);
            _26973 = NOVALUE;
        }
        DeRef(_26973);
        _26973 = NOVALUE;

        /** emit.e:984						op = previous_op + LESS_IFW_I - LESS*/
        _26974 = _27previous_op_20670 + 119;
        if ((object)((uintptr_t)_26974 + (uintptr_t)HIGH_BITS) >= 0){
            _26974 = NewDouble((eudouble)_26974);
        }
        if (IS_ATOM_INT(_26974)) {
            _op_52351 = _26974 - 1;
        }
        else {
            _op_52351 = NewDouble(DBL_PTR(_26974)->dbl - (eudouble)1);
        }
        DeRef(_26974);
        _26974 = NOVALUE;
        if (!IS_ATOM_INT(_op_52351)) {
            _1 = (object)(DBL_PTR(_op_52351)->dbl);
            DeRefDS(_op_52351);
            _op_52351 = _1;
        }
        goto L3A; // [2183] 2205
L39: 

        /** emit.e:986						op = previous_op + LESS_IFW - LESS*/
        _26976 = _27previous_op_20670 + 102;
        if ((object)((uintptr_t)_26976 + (uintptr_t)HIGH_BITS) >= 0){
            _26976 = NewDouble((eudouble)_26976);
        }
        if (IS_ATOM_INT(_26976)) {
            _op_52351 = _26976 - 1;
        }
        else {
            _op_52351 = NewDouble(DBL_PTR(_26976)->dbl - (eudouble)1);
        }
        DeRef(_26976);
        _26976 = NOVALUE;
        if (!IS_ATOM_INT(_op_52351)) {
            _1 = (object)(DBL_PTR(_op_52351)->dbl);
            DeRefDS(_op_52351);
            _op_52351 = _1;
        }
L3A: 

        /** emit.e:989					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26978 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26978 = 1;
        }
        _26979 = _26978 - 2;
        _26978 = NOVALUE;
        _45backpatch(_26979, _op_52351);
        _26979 = NOVALUE;

        /** emit.e:991					sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26980 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26980 = 1;
        }
        _26981 = _26980 - 2;
        _26980 = NOVALUE;
        if (IS_SEQUENCE(_27Code_20660)){
                _26982 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26982 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52834;
        RHS_Slice(_27Code_20660, _26981, _26982);

        /** emit.e:992					Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _26984 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _26984 = 1;
        }
        _26985 = _26984 - 3;
        _26984 = NOVALUE;
        rhs_slice_target = (object_ptr)&_27Code_20660;
        RHS_Slice(_27Code_20660, 1, _26985);

        /** emit.e:993					Code &= if_code*/
        Concat((object_ptr)&_27Code_20660, _27Code_20660, _if_code_52834);
        DeRefDS(_if_code_52834);
        _if_code_52834 = NOVALUE;
L38: 

        /** emit.e:997				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;

        /** emit.e:998				last_op = op*/
        _45last_op_52310 = _op_52351;
        goto LC; // [2280] 7739
L36: 

        /** emit.e:1000			elsif op = WHILE and*/
        _26988 = (_op_52351 == 47);
        if (_26988 == 0) {
            _26989 = 0;
            goto L3B; // [2291] 2303
        }
        _26990 = (_a_52353 > 0);
        _26989 = (_26990 != 0);
L3B: 
        if (_26989 == 0) {
            _26991 = 0;
            goto L3C; // [2303] 2329
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26992 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_26992);
        _26993 = (object)*(((s1_ptr)_2)->base + 3);
        _26992 = NOVALUE;
        if (IS_ATOM_INT(_26993)) {
            _26994 = (_26993 == 2);
        }
        else {
            _26994 = binary_op(EQUALS, _26993, 2);
        }
        _26993 = NOVALUE;
        if (IS_ATOM_INT(_26994))
        _26991 = (_26994 != 0);
        else
        _26991 = DBL_PTR(_26994)->dbl != 0.0;
L3C: 
        if (_26991 == 0) {
            _26995 = 0;
            goto L3D; // [2329] 2352
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _26996 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_26996);
        _26997 = (object)*(((s1_ptr)_2)->base + 1);
        _26996 = NOVALUE;
        if (IS_ATOM_INT(_26997))
        _26998 = 1;
        else if (IS_ATOM_DBL(_26997))
        _26998 = IS_ATOM_INT(DoubleToInt(_26997));
        else
        _26998 = 0;
        _26997 = NOVALUE;
        _26995 = (_26998 != 0);
L3D: 
        if (_26995 == 0) {
            goto L3E; // [2352] 2401
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27000 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27000);
        _27001 = (object)*(((s1_ptr)_2)->base + 1);
        _27000 = NOVALUE;
        if (_27001 == 0)
        _27002 = 1;
        else if (IS_ATOM_INT(_27001) && IS_ATOM_INT(0))
        _27002 = 0;
        else
        _27002 = (compare(_27001, 0) == 0);
        _27001 = NOVALUE;
        _27003 = (_27002 == 0);
        _27002 = NOVALUE;
        if (_27003 == 0)
        {
            DeRef(_27003);
            _27003 = NOVALUE;
            goto L3E; // [2376] 2401
        }
        else{
            DeRef(_27003);
            _27003 = NOVALUE;
        }

        /** emit.e:1005				optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _45optimized_while_51415 = _9TRUE_441;

        /** emit.e:1006				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;

        /** emit.e:1007				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;
        goto LC; // [2398] 7739
L3E: 

        /** emit.e:1009				flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _a_52353;
        _27004 = MAKE_SEQ(_1);
        _45flush_temps(_27004);
        _27004 = NOVALUE;

        /** emit.e:1010				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1011				emit_addr(a)*/
        _45emit_addr(_a_52353);
        goto LC; // [2421] 7739

        /** emit.e:1016		case INTEGER_CHECK then*/
        case 96:

        /** emit.e:1017			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:1018			if previous_op = ASSIGN then*/
        if (_27previous_op_20670 != 18)
        goto L3F; // [2440] 2499

        /** emit.e:1019				c = Code[$-1]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27006 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27006 = 1;
        }
        _27007 = _27006 - 1;
        _27006 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _c_52355 = (object)*(((s1_ptr)_2)->base + _27007);
        if (!IS_ATOM_INT(_c_52355)){
            _c_52355 = (object)DBL_PTR(_c_52355)->dbl;
        }

        /** emit.e:1020				if not IsInteger(c) then*/
        _27009 = _45IsInteger(_c_52355);
        if (IS_ATOM_INT(_27009)) {
            if (_27009 != 0){
                DeRef(_27009);
                _27009 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        else {
            if (DBL_PTR(_27009)->dbl != 0.0){
                DeRef(_27009);
                _27009 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        DeRef(_27009);
        _27009 = NOVALUE;

        /** emit.e:1021					emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1022					emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);
        goto L41; // [2482] 2556
L40: 

        /** emit.e:1024					last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1025					last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto L41; // [2496] 2556
L3F: 

        /** emit.e:1027			elsif previous_op = -1 or*/
        _27011 = (_27previous_op_20670 == -1);
        if (_27011 != 0) {
            goto L42; // [2507] 2530
        }
        _2 = (object)SEQ_PTR(_45op_result_52029);
        _27013 = (object)*(((s1_ptr)_2)->base + _27previous_op_20670);
        _27014 = (_27013 != 1);
        _27013 = NOVALUE;
        if (_27014 == 0)
        {
            DeRef(_27014);
            _27014 = NOVALUE;
            goto L43; // [2526] 2545
        }
        else{
            DeRef(_27014);
            _27014 = NOVALUE;
        }
L42: 

        /** emit.e:1029				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1030				emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);
        goto L41; // [2542] 2556
L43: 

        /** emit.e:1032				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1033				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
L41: 

        /** emit.e:1035			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27015 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27015 = 1;
        }
        _27016 = _27015 - 1;
        _27015 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _27017 = (object)*(((s1_ptr)_2)->base + _27016);
        Ref(_27017);
        _45clear_temp(_27017);
        _27017 = NOVALUE;
        goto LC; // [2574] 7739

        /** emit.e:1037		case SEQUENCE_CHECK then*/
        case 97:

        /** emit.e:1038			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:1039			if previous_op = ASSIGN then*/
        if (_27previous_op_20670 != 18)
        goto L44; // [2593] 2720

        /** emit.e:1040				c = Code[$-1]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27019 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27019 = 1;
        }
        _27020 = _27019 - 1;
        _27019 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _c_52355 = (object)*(((s1_ptr)_2)->base + _27020);
        if (!IS_ATOM_INT(_c_52355)){
            _c_52355 = (object)DBL_PTR(_c_52355)->dbl;
        }

        /** emit.e:1041				if c < 1 or*/
        _27022 = (_c_52355 < 1);
        if (_27022 != 0) {
            _27023 = 1;
            goto L45; // [2620] 2646
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27024 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27024);
        _27025 = (object)*(((s1_ptr)_2)->base + 3);
        _27024 = NOVALUE;
        if (IS_ATOM_INT(_27025)) {
            _27026 = (_27025 != 2);
        }
        else {
            _27026 = binary_op(NOTEQ, _27025, 2);
        }
        _27025 = NOVALUE;
        if (IS_ATOM_INT(_27026))
        _27023 = (_27026 != 0);
        else
        _27023 = DBL_PTR(_27026)->dbl != 0.0;
L45: 
        if (_27023 != 0) {
            goto L46; // [2646] 2673
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27028 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27028);
        _27029 = (object)*(((s1_ptr)_2)->base + 1);
        _27028 = NOVALUE;
        _27030 = IS_SEQUENCE(_27029);
        _27029 = NOVALUE;
        _27031 = (_27030 == 0);
        _27030 = NOVALUE;
        if (_27031 == 0)
        {
            DeRef(_27031);
            _27031 = NOVALUE;
            goto L47; // [2669] 2706
        }
        else{
            DeRef(_27031);
            _27031 = NOVALUE;
        }
L46: 

        /** emit.e:1044					emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1045					emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);

        /** emit.e:1046					clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27032 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27032 = 1;
        }
        _27033 = _27032 - 1;
        _27032 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _27034 = (object)*(((s1_ptr)_2)->base + _27033);
        Ref(_27034);
        _45clear_temp(_27034);
        _27034 = NOVALUE;
        goto LC; // [2703] 7739
L47: 

        /** emit.e:1048					last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1049					last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto LC; // [2717] 7739
L44: 

        /** emit.e:1051			elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _27035 = (_27previous_op_20670 == -1);
        if (_27035 != 0) {
            goto L48; // [2728] 2751
        }
        _2 = (object)SEQ_PTR(_45op_result_52029);
        _27037 = (object)*(((s1_ptr)_2)->base + _27previous_op_20670);
        _27038 = (_27037 != 2);
        _27037 = NOVALUE;
        if (_27038 == 0)
        {
            DeRef(_27038);
            _27038 = NOVALUE;
            goto L49; // [2747] 2784
        }
        else{
            DeRef(_27038);
            _27038 = NOVALUE;
        }
L48: 

        /** emit.e:1052				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1053				emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);

        /** emit.e:1054				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27039 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27039 = 1;
        }
        _27040 = _27039 - 1;
        _27039 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _27041 = (object)*(((s1_ptr)_2)->base + _27040);
        Ref(_27041);
        _45clear_temp(_27041);
        _27041 = NOVALUE;
        goto LC; // [2781] 7739
L49: 

        /** emit.e:1056				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1057				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto LC; // [2795] 7739

        /** emit.e:1061		case ATOM_CHECK then*/
        case 101:

        /** emit.e:1062			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:1063			if previous_op = ASSIGN then*/
        if (_27previous_op_20670 != 18)
        goto L4A; // [2814] 3015

        /** emit.e:1064				c = Code[$-1]*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27043 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27043 = 1;
        }
        _27044 = _27043 - 1;
        _27043 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _c_52355 = (object)*(((s1_ptr)_2)->base + _27044);
        if (!IS_ATOM_INT(_c_52355)){
            _c_52355 = (object)DBL_PTR(_c_52355)->dbl;
        }

        /** emit.e:1065				if c > 1*/
        _27046 = (_c_52355 > 1);
        if (_27046 == 0) {
            goto L4B; // [2841] 2964
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27048 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27048);
        _27049 = (object)*(((s1_ptr)_2)->base + 3);
        _27048 = NOVALUE;
        if (IS_ATOM_INT(_27049)) {
            _27050 = (_27049 == 2);
        }
        else {
            _27050 = binary_op(EQUALS, _27049, 2);
        }
        _27049 = NOVALUE;
        if (_27050 == 0) {
            DeRef(_27050);
            _27050 = NOVALUE;
            goto L4B; // [2864] 2964
        }
        else {
            if (!IS_ATOM_INT(_27050) && DBL_PTR(_27050)->dbl == 0.0){
                DeRef(_27050);
                _27050 = NOVALUE;
                goto L4B; // [2864] 2964
            }
            DeRef(_27050);
            _27050 = NOVALUE;
        }
        DeRef(_27050);
        _27050 = NOVALUE;

        /** emit.e:1068					if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27051 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27051);
        _27052 = (object)*(((s1_ptr)_2)->base + 1);
        _27051 = NOVALUE;
        _27053 = IS_SEQUENCE(_27052);
        _27052 = NOVALUE;
        if (_27053 == 0)
        {
            _27053 = NOVALUE;
            goto L4C; // [2884] 2915
        }
        else{
            _27053 = NOVALUE;
        }

        /** emit.e:1070						ThisLine = ExprLine*/
        RefDS(_43ExprLine_57523);
        DeRef(_49ThisLine_49642);
        _49ThisLine_49642 = _43ExprLine_57523;

        /** emit.e:1071						bp = expr_bp*/
        _49bp_49646 = _43expr_bp_57524;

        /** emit.e:1072						CompileErr( TYPE_CHECK_ERROR__ASSIGNING_A_SEQUENCE_TO_AN_ATOM)*/
        RefDS(_22209);
        _49CompileErr(346, _22209, 0);
        goto L4D; // [2912] 3094
L4C: 

        /** emit.e:1074					elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27054 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27054);
        _27055 = (object)*(((s1_ptr)_2)->base + 1);
        _27054 = NOVALUE;
        if (binary_op_a(NOTEQ, _27055, _27NOVALUE_20426)){
            _27055 = NOVALUE;
            goto L4E; // [2931] 2950
        }
        _27055 = NOVALUE;

        /** emit.e:1075						emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1076						emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);
        goto L4D; // [2947] 3094
L4E: 

        /** emit.e:1078						last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1079						last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto L4D; // [2961] 3094
L4B: 

        /** emit.e:1082				elsif c < 1 */
        _27057 = (_c_52355 < 1);
        if (_27057 != 0) {
            goto L4F; // [2970] 2986
        }
        _27059 = _45IsInteger(_c_52355);
        if (IS_ATOM_INT(_27059)) {
            _27060 = (_27059 == 0);
        }
        else {
            _27060 = unary_op(NOT, _27059);
        }
        DeRef(_27059);
        _27059 = NOVALUE;
        if (_27060 == 0) {
            DeRef(_27060);
            _27060 = NOVALUE;
            goto L50; // [2982] 3001
        }
        else {
            if (!IS_ATOM_INT(_27060) && DBL_PTR(_27060)->dbl == 0.0){
                DeRef(_27060);
                _27060 = NOVALUE;
                goto L50; // [2982] 3001
            }
            DeRef(_27060);
            _27060 = NOVALUE;
        }
        DeRef(_27060);
        _27060 = NOVALUE;
L4F: 

        /** emit.e:1085					emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1086					emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);
        goto L4D; // [2998] 3094
L50: 

        /** emit.e:1089					last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1090					last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto L4D; // [3012] 3094
L4A: 

        /** emit.e:1092			elsif previous_op = -1 or*/
        _27061 = (_27previous_op_20670 == -1);
        if (_27061 != 0) {
            goto L51; // [3023] 3068
        }
        _2 = (object)SEQ_PTR(_45op_result_52029);
        _27063 = (object)*(((s1_ptr)_2)->base + _27previous_op_20670);
        _27064 = (_27063 != 1);
        _27063 = NOVALUE;
        if (_27064 == 0) {
            DeRef(_27065);
            _27065 = 0;
            goto L52; // [3041] 3063
        }
        _2 = (object)SEQ_PTR(_45op_result_52029);
        _27066 = (object)*(((s1_ptr)_2)->base + _27previous_op_20670);
        _27067 = (_27066 != 3);
        _27066 = NOVALUE;
        _27065 = (_27067 != 0);
L52: 
        if (_27065 == 0)
        {
            _27065 = NOVALUE;
            goto L53; // [3064] 3083
        }
        else{
            _27065 = NOVALUE;
        }
L51: 

        /** emit.e:1095				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1096				emit_addr(op_info1)*/
        _45emit_addr(_45op_info1_51413);
        goto L4D; // [3080] 3094
L53: 

        /** emit.e:1098				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1099				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
L4D: 

        /** emit.e:1101			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27068 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27068 = 1;
        }
        _27069 = _27068 - 1;
        _27068 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _27070 = (object)*(((s1_ptr)_2)->base + _27069);
        Ref(_27070);
        _45clear_temp(_27070);
        _27070 = NOVALUE;
        goto LC; // [3112] 7739

        /** emit.e:1103		case RIGHT_BRACE_N then*/
        case 31:

        /** emit.e:1105			n = op_info1*/
        _n_52364 = _45op_info1_51413;

        /** emit.e:1107			elements = {}*/
        RefDS(_22209);
        DeRef(_elements_52366);
        _elements_52366 = _22209;

        /** emit.e:1108			for i = 1 to n do*/
        _27071 = _n_52364;
        {
            object _i_53015;
            _i_53015 = 1;
L54: 
            if (_i_53015 > _27071){
                goto L55; // [3137] 3160
            }

            /** emit.e:1109				elements = append(elements, Pop())*/
            _27072 = _45Pop();
            Ref(_27072);
            Append(&_elements_52366, _elements_52366, _27072);
            DeRef(_27072);
            _27072 = NOVALUE;

            /** emit.e:1110			end for*/
            _i_53015 = _i_53015 + 1;
            goto L54; // [3155] 3144
L55: 
            ;
        }

        /** emit.e:1111			element_vals = good_string(elements)*/
        RefDS(_elements_52366);
        _0 = _element_vals_52367;
        _element_vals_52367 = _45good_string(_elements_52366);
        DeRef(_0);

        /** emit.e:1113			if sequence(element_vals) then*/
        _27075 = IS_SEQUENCE(_element_vals_52367);
        if (_27075 == 0)
        {
            _27075 = NOVALUE;
            goto L56; // [3171] 3202
        }
        else{
            _27075 = NOVALUE;
        }

        /** emit.e:1114				c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_52367);
        _c_52355 = _53NewStringSym(_element_vals_52367);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1115				assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:1116				last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1117				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto L57; // [3199] 3293
L56: 

        /** emit.e:1119				if n = 2 then*/
        if (_n_52364 != 2)
        goto L58; // [3204] 3227

        /** emit.e:1120					emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _45emit_opcode(85);

        /** emit.e:1121					last_op = RIGHT_BRACE_2*/
        _45last_op_52310 = 85;
        goto L59; // [3224] 3238
L58: 

        /** emit.e:1123					emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1124					emit(n)*/
        _45emit(_n_52364);
L59: 

        /** emit.e:1127				for i = 1 to n do*/
        _27078 = _n_52364;
        {
            object _i_53032;
            _i_53032 = 1;
L5A: 
            if (_i_53032 > _27078){
                goto L5B; // [3243] 3266
            }

            /** emit.e:1128					emit_addr(elements[i])*/
            _2 = (object)SEQ_PTR(_elements_52366);
            _27079 = (object)*(((s1_ptr)_2)->base + _i_53032);
            Ref(_27079);
            _45emit_addr(_27079);
            _27079 = NOVALUE;

            /** emit.e:1129				end for*/
            _i_53032 = _i_53032 + 1;
            goto L5A; // [3261] 3250
L5B: 
            ;
        }

        /** emit.e:1130				c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1131				emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1132				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);

        /** emit.e:1133				assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;
L57: 

        /** emit.e:1135			Push(c)*/
        _45Push(_c_52355);
        goto LC; // [3298] 7739

        /** emit.e:1138		case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** emit.e:1141			b = Pop() -- rhs value*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1142			a = Pop() -- subscript*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1143			c = Pop() -- sequence*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1144			if op = ASSIGN_SUBS then*/
        if (_op_52351 != 16)
        goto L5C; // [3333] 3525

        /** emit.e:1146				if (previous_op != LHS_SUBS) and*/
        _27085 = (_27previous_op_20670 != 95);
        if (_27085 == 0) {
            _27086 = 0;
            goto L5D; // [3347] 3359
        }
        _27087 = (_c_52355 > 0);
        _27086 = (_27087 != 0);
L5D: 
        if (_27086 == 0) {
            goto L5E; // [3359] 3497
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27089 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27089);
        _27090 = (object)*(((s1_ptr)_2)->base + 3);
        _27089 = NOVALUE;
        if (IS_ATOM_INT(_27090)) {
            _27091 = (_27090 != 1);
        }
        else {
            _27091 = binary_op(NOTEQ, _27090, 1);
        }
        _27090 = NOVALUE;
        if (IS_ATOM_INT(_27091)) {
            if (_27091 != 0) {
                DeRef(_27092);
                _27092 = 1;
                goto L5F; // [3381] 3481
            }
        }
        else {
            if (DBL_PTR(_27091)->dbl != 0.0) {
                DeRef(_27092);
                _27092 = 1;
                goto L5F; // [3381] 3481
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27093 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27093);
        _27094 = (object)*(((s1_ptr)_2)->base + 15);
        _27093 = NOVALUE;
        if (IS_ATOM_INT(_27094)) {
            _27095 = (_27094 != _53sequence_type_47188);
        }
        else {
            _27095 = binary_op(NOTEQ, _27094, _53sequence_type_47188);
        }
        _27094 = NOVALUE;
        if (IS_ATOM_INT(_27095)) {
            if (_27095 == 0) {
                DeRef(_27096);
                _27096 = 0;
                goto L60; // [3403] 3477
            }
        }
        else {
            if (DBL_PTR(_27095)->dbl == 0.0) {
                DeRef(_27096);
                _27096 = 0;
                goto L60; // [3403] 3477
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27097 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27097);
        _27098 = (object)*(((s1_ptr)_2)->base + 15);
        _27097 = NOVALUE;
        if (IS_ATOM_INT(_27098)) {
            _27099 = (_27098 > 0);
        }
        else {
            _27099 = binary_op(GREATER, _27098, 0);
        }
        _27098 = NOVALUE;
        if (IS_ATOM_INT(_27099)) {
            if (_27099 == 0) {
                DeRef(_27100);
                _27100 = 0;
                goto L61; // [3423] 3473
            }
        }
        else {
            if (DBL_PTR(_27099)->dbl == 0.0) {
                DeRef(_27100);
                _27100 = 0;
                goto L61; // [3423] 3473
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27101 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27101);
        _27102 = (object)*(((s1_ptr)_2)->base + 15);
        _27101 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_27102)){
            _27103 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27102)->dbl));
        }
        else{
            _27103 = (object)*(((s1_ptr)_2)->base + _27102);
        }
        _2 = (object)SEQ_PTR(_27103);
        _27104 = (object)*(((s1_ptr)_2)->base + 2);
        _27103 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_27104)){
            _27105 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27104)->dbl));
        }
        else{
            _27105 = (object)*(((s1_ptr)_2)->base + _27104);
        }
        _2 = (object)SEQ_PTR(_27105);
        _27106 = (object)*(((s1_ptr)_2)->base + 15);
        _27105 = NOVALUE;
        if (IS_ATOM_INT(_27106)) {
            _27107 = (_27106 != _53sequence_type_47188);
        }
        else {
            _27107 = binary_op(NOTEQ, _27106, _53sequence_type_47188);
        }
        _27106 = NOVALUE;
        DeRef(_27100);
        if (IS_ATOM_INT(_27107))
        _27100 = (_27107 != 0);
        else
        _27100 = DBL_PTR(_27107)->dbl != 0.0;
L61: 
        DeRef(_27096);
        _27096 = (_27100 != 0);
L60: 
        DeRef(_27092);
        _27092 = (_27096 != 0);
L5F: 
        if (_27092 == 0)
        {
            _27092 = NOVALUE;
            goto L5E; // [3482] 3497
        }
        else{
            _27092 = NOVALUE;
        }

        /** emit.e:1153					op = ASSIGN_SUBS_CHECK*/
        _op_52351 = 84;
        goto L62; // [3494] 3517
L5E: 

        /** emit.e:1155					if IsInteger(b) then*/
        _27108 = _45IsInteger(_b_52354);
        if (_27108 == 0) {
            DeRef(_27108);
            _27108 = NOVALUE;
            goto L63; // [3503] 3516
        }
        else {
            if (!IS_ATOM_INT(_27108) && DBL_PTR(_27108)->dbl == 0.0){
                DeRef(_27108);
                _27108 = NOVALUE;
                goto L63; // [3503] 3516
            }
            DeRef(_27108);
            _27108 = NOVALUE;
        }
        DeRef(_27108);
        _27108 = NOVALUE;

        /** emit.e:1156						op = ASSIGN_SUBS_I*/
        _op_52351 = 118;
L63: 
L62: 

        /** emit.e:1159				emit_opcode(op)*/
        _45emit_opcode(_op_52351);
        goto L64; // [3522] 3551
L5C: 

        /** emit.e:1161			elsif op = PASSIGN_SUBS then*/
        if (_op_52351 != 162)
        goto L65; // [3529] 3543

        /** emit.e:1162				emit_opcode(PASSIGN_SUBS) -- always*/
        _45emit_opcode(162);
        goto L64; // [3540] 3551
L65: 

        /** emit.e:1165				emit_opcode(ASSIGN_SUBS) -- always*/
        _45emit_opcode(16);
L64: 

        /** emit.e:1169			emit_addr(c) -- sequence*/
        _45emit_addr(_c_52355);

        /** emit.e:1170			emit_addr(a) -- subscript*/
        _45emit_addr(_a_52353);

        /** emit.e:1171			emit_addr(b) -- rhs value*/
        _45emit_addr(_b_52354);

        /** emit.e:1172			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [3573] 7739

        /** emit.e:1174		case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** emit.e:1176			a = Pop() -- subs*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1177			lhs_var = Pop() -- sequence*/
        _lhs_var_52361 = _45Pop();
        if (!IS_ATOM_INT(_lhs_var_52361)) {
            _1 = (object)(DBL_PTR(_lhs_var_52361)->dbl);
            DeRefDS(_lhs_var_52361);
            _lhs_var_52361 = _1;
        }

        /** emit.e:1178			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1179			emit_addr(lhs_var)*/
        _45emit_addr(_lhs_var_52361);

        /** emit.e:1180			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1181			if op = LHS_SUBS then*/
        if (_op_52351 != 95)
        goto L66; // [3616] 3647

        /** emit.e:1182				TempKeep(lhs_var) -- should be lhs_target_temp*/
        _45TempKeep(_lhs_var_52361);

        /** emit.e:1183				emit_addr(lhs_target_temp)*/
        _45emit_addr(_45lhs_target_temp_51427);

        /** emit.e:1184				Push(lhs_target_temp)*/
        _45Push(_45lhs_target_temp_51427);

        /** emit.e:1185				emit_addr(0) -- place holder*/
        _45emit_addr(0);
        goto L67; // [3644] 3701
L66: 

        /** emit.e:1189				lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _53NewTempSym(0);
        _45lhs_target_temp_51427 = _0;
        if (!IS_ATOM_INT(_45lhs_target_temp_51427)) {
            _1 = (object)(DBL_PTR(_45lhs_target_temp_51427)->dbl);
            DeRefDS(_45lhs_target_temp_51427);
            _45lhs_target_temp_51427 = _1;
        }

        /** emit.e:1190				emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _45emit_addr(_45lhs_target_temp_51427);

        /** emit.e:1191				emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _45emit_temp(_45lhs_target_temp_51427, 1);

        /** emit.e:1192				Push(lhs_target_temp)*/
        _45Push(_45lhs_target_temp_51427);

        /** emit.e:1193				lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _53NewTempSym(0);
        _45lhs_subs1_copy_temp_51426 = _0;
        if (!IS_ATOM_INT(_45lhs_subs1_copy_temp_51426)) {
            _1 = (object)(DBL_PTR(_45lhs_subs1_copy_temp_51426)->dbl);
            DeRefDS(_45lhs_subs1_copy_temp_51426);
            _45lhs_subs1_copy_temp_51426 = _1;
        }

        /** emit.e:1194				emit_addr(lhs_subs1_copy_temp)*/
        _45emit_addr(_45lhs_subs1_copy_temp_51426);

        /** emit.e:1195				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _45emit_temp(_45lhs_subs1_copy_temp_51426, 1);
L67: 

        /** emit.e:1198			current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_45current_sequence_51421, _45current_sequence_51421, _45lhs_target_temp_51427);

        /** emit.e:1199			assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [3718] 7739

        /** emit.e:1201		case PEEK_LONGS then*/
        case 436:

        /** emit.e:1202			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_44IWINDOWS_20714 != 0) {
            _27116 = 1;
            goto L68; // [3728] 3738
        }
        _27116 = (_44TWINDOWS_20715 != 0);
L68: 
        if (_27116 != 0) {
            goto L69; // [3738] 3762
        }
        if (0 != 0) {
            DeRef(_27118);
            _27118 = 1;
            goto L6A; // [3744] 3754
        }
        _27118 = (0 != 0);
L6A: 
        _27119 = (_27118 == 0);
        _27118 = NOVALUE;
        if (_27119 == 0)
        {
            DeRef(_27119);
            _27119 = NOVALUE;
            goto L6B; // [3758] 3774
        }
        else{
            DeRef(_27119);
            _27119 = NOVALUE;
        }
L69: 

        /** emit.e:1203				op = PEEK4S*/
        _op_52351 = 139;
        goto L6C; // [3771] 3784
L6B: 

        /** emit.e:1205				op = PEEK8S*/
        _op_52351 = 213;
L6C: 

        /** emit.e:1207			last_op = op*/
        _45last_op_52310 = _op_52351;

        /** emit.e:1208			cont11ii(op, TRUE )*/
        _45cont11ii(_op_52351, _9TRUE_441);
        goto LC; // [3797] 7739

        /** emit.e:1210		case PEEK_LONGU then*/
        case 435:

        /** emit.e:1211			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_44IWINDOWS_20714 != 0) {
            _27120 = 1;
            goto L6D; // [3807] 3817
        }
        _27120 = (_44TWINDOWS_20715 != 0);
L6D: 
        if (_27120 != 0) {
            goto L6E; // [3817] 3841
        }
        if (0 != 0) {
            DeRef(_27122);
            _27122 = 1;
            goto L6F; // [3823] 3833
        }
        _27122 = (0 != 0);
L6F: 
        _27123 = (_27122 == 0);
        _27122 = NOVALUE;
        if (_27123 == 0)
        {
            DeRef(_27123);
            _27123 = NOVALUE;
            goto L70; // [3837] 3853
        }
        else{
            DeRef(_27123);
            _27123 = NOVALUE;
        }
L6E: 

        /** emit.e:1212				op = PEEK4U*/
        _op_52351 = 140;
        goto L71; // [3850] 3863
L70: 

        /** emit.e:1214				op = PEEK8U*/
        _op_52351 = 214;
L71: 

        /** emit.e:1216			last_op = op*/
        _45last_op_52310 = _op_52351;

        /** emit.e:1217			cont11ii(op, TRUE )*/
        _45cont11ii(_op_52351, _9TRUE_441);
        goto LC; // [3876] 7739

        /** emit.e:1220		case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT, PEEK8U, PEEK8S, SIZEOF,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 214:
        case 213:
        case 217:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:
        case 216:

        /** emit.e:1222			cont11ii(op, TRUE)*/
        _45cont11ii(_op_52351, _9TRUE_441);
        goto LC; // [3918] 7739

        /** emit.e:1224		case UMINUS then*/
        case 12:

        /** emit.e:1226			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1228			if a > 0 then*/
        if (_a_52353 <= 0)
        goto L72; // [3933] 4180

        /** emit.e:1229				obj = SymTab[a][S_OBJ]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27126 = (object)*(((s1_ptr)_2)->base + _a_52353);
        DeRef(_obj_52365);
        _2 = (object)SEQ_PTR(_27126);
        _obj_52365 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_52365);
        _27126 = NOVALUE;

        /** emit.e:1230				if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27128 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27128);
        _27129 = (object)*(((s1_ptr)_2)->base + 3);
        _27128 = NOVALUE;
        if (binary_op_a(NOTEQ, _27129, 2)){
            _27129 = NOVALUE;
            goto L73; // [3967] 4092
        }
        _27129 = NOVALUE;

        /** emit.e:1231					if is_integer(obj) then*/
        Ref(_obj_52365);
        _27131 = _27is_integer(_obj_52365);
        if (_27131 == 0) {
            DeRef(_27131);
            _27131 = NOVALUE;
            goto L74; // [3977] 4031
        }
        else {
            if (!IS_ATOM_INT(_27131) && DBL_PTR(_27131)->dbl == 0.0){
                DeRef(_27131);
                _27131 = NOVALUE;
                goto L74; // [3977] 4031
            }
            DeRef(_27131);
            _27131 = NOVALUE;
        }
        DeRef(_27131);
        _27131 = NOVALUE;

        /** emit.e:1232						if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_52365, -1073741824)){
            goto L75; // [3984] 4005
        }

        /** emit.e:1233							Push(NewDoubleSym(-MININT))*/
        if ((uintptr_t)-1073741824 == (uintptr_t)HIGH_BITS){
            _27133 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _27133 = - -1073741824;
        }
        _27134 = _53NewDoubleSym(_27133);
        _27133 = NOVALUE;
        _45Push(_27134);
        _27134 = NOVALUE;
        goto L76; // [4002] 4018
L75: 

        /** emit.e:1235							Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_52365)) {
            if ((uintptr_t)_obj_52365 == (uintptr_t)HIGH_BITS){
                _27135 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27135 = - _obj_52365;
            }
        }
        else {
            _27135 = unary_op(UMINUS, _obj_52365);
        }
        _27136 = _53NewIntSym(_27135);
        _27135 = NOVALUE;
        _45Push(_27136);
        _27136 = NOVALUE;
L76: 

        /** emit.e:1237						last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;

        /** emit.e:1238						last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;
        goto LC; // [4028] 7739
L74: 

        /** emit.e:1240					elsif atom(obj) and obj != NOVALUE then*/
        _27137 = IS_ATOM(_obj_52365);
        if (_27137 == 0) {
            goto L77; // [4036] 4075
        }
        if (IS_ATOM_INT(_obj_52365) && IS_ATOM_INT(_27NOVALUE_20426)) {
            _27139 = (_obj_52365 != _27NOVALUE_20426);
        }
        else {
            _27139 = binary_op(NOTEQ, _obj_52365, _27NOVALUE_20426);
        }
        if (_27139 == 0) {
            DeRef(_27139);
            _27139 = NOVALUE;
            goto L77; // [4047] 4075
        }
        else {
            if (!IS_ATOM_INT(_27139) && DBL_PTR(_27139)->dbl == 0.0){
                DeRef(_27139);
                _27139 = NOVALUE;
                goto L77; // [4047] 4075
            }
            DeRef(_27139);
            _27139 = NOVALUE;
        }
        DeRef(_27139);
        _27139 = NOVALUE;

        /** emit.e:1245						Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_52365)) {
            if ((uintptr_t)_obj_52365 == (uintptr_t)HIGH_BITS){
                _27140 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27140 = - _obj_52365;
            }
        }
        else {
            _27140 = unary_op(UMINUS, _obj_52365);
        }
        _27141 = _53NewDoubleSym(_27140);
        _27140 = NOVALUE;
        _45Push(_27141);
        _27141 = NOVALUE;

        /** emit.e:1246						last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;

        /** emit.e:1247						last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;
        goto LC; // [4072] 7739
L77: 

        /** emit.e:1250						Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1251						cont11ii(op, FALSE)*/
        _45cont11ii(_op_52351, _9FALSE_439);
        goto LC; // [4089] 7739
L73: 

        /** emit.e:1254				elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_27TRANSLATE_20179 == 0) {
            _27142 = 0;
            goto L78; // [4096] 4122
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27143 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27143);
        _27144 = (object)*(((s1_ptr)_2)->base + 3);
        _27143 = NOVALUE;
        if (IS_ATOM_INT(_27144)) {
            _27145 = (_27144 == 3);
        }
        else {
            _27145 = binary_op(EQUALS, _27144, 3);
        }
        _27144 = NOVALUE;
        if (IS_ATOM_INT(_27145))
        _27142 = (_27145 != 0);
        else
        _27142 = DBL_PTR(_27145)->dbl != 0.0;
L78: 
        if (_27142 == 0) {
            goto L79; // [4122] 4163
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27147 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27147);
        _27148 = (object)*(((s1_ptr)_2)->base + 36);
        _27147 = NOVALUE;
        if (IS_ATOM_INT(_27148)) {
            _27149 = (_27148 == 2);
        }
        else {
            _27149 = binary_op(EQUALS, _27148, 2);
        }
        _27148 = NOVALUE;
        if (_27149 == 0) {
            DeRef(_27149);
            _27149 = NOVALUE;
            goto L79; // [4145] 4163
        }
        else {
            if (!IS_ATOM_INT(_27149) && DBL_PTR(_27149)->dbl == 0.0){
                DeRef(_27149);
                _27149 = NOVALUE;
                goto L79; // [4145] 4163
            }
            DeRef(_27149);
            _27149 = NOVALUE;
        }
        DeRef(_27149);
        _27149 = NOVALUE;

        /** emit.e:1256					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_52365)) {
            if ((uintptr_t)_obj_52365 == (uintptr_t)HIGH_BITS){
                _27150 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27150 = - _obj_52365;
            }
        }
        else {
            _27150 = unary_op(UMINUS, _obj_52365);
        }
        _27151 = _53NewDoubleSym(_27150);
        _27150 = NOVALUE;
        _45Push(_27151);
        _27151 = NOVALUE;
        goto LC; // [4160] 7739
L79: 

        /** emit.e:1259					Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1260					cont11ii(op, FALSE)*/
        _45cont11ii(_op_52351, _9FALSE_439);
        goto LC; // [4177] 7739
L72: 

        /** emit.e:1263				Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1264				cont11ii(op, FALSE)*/
        _45cont11ii(_op_52351, _9FALSE_439);
        goto LC; // [4194] 7739

        /** emit.e:1267		case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** emit.e:1268			cont11ii(op, FALSE)*/
        _45cont11ii(_op_52351, _9FALSE_439);
        goto LC; // [4226] 7739

        /** emit.e:1270		case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** emit.e:1271			cont11ii(op, FALSE)*/
        _45cont11ii(_op_52351, _9FALSE_439);
        goto LC; // [4246] 7739

        /** emit.e:1275		case ROUTINE_ID then*/
        case 134:

        /** emit.e:1276			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1277			source = Pop()*/
        _source_52357 = _45Pop();
        if (!IS_ATOM_INT(_source_52357)) {
            _1 = (object)(DBL_PTR(_source_52357)->dbl);
            DeRefDS(_source_52357);
            _source_52357 = _1;
        }

        /** emit.e:1278			if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L7A; // [4268] 4312
        }
        else{
        }

        /** emit.e:1279				emit_addr(num_routines-1)*/
        _27153 = _27num_routines_20580 - 1;
        if ((object)((uintptr_t)_27153 +(uintptr_t) HIGH_BITS) >= 0){
            _27153 = NewDouble((eudouble)_27153);
        }
        _45emit_addr(_27153);
        _27153 = NOVALUE;

        /** emit.e:1280				last_routine_id = num_routines*/
        _45last_routine_id_51418 = _27num_routines_20580;

        /** emit.e:1281				last_max_params = max_params*/
        _45last_max_params_51420 = _45max_params_51419;

        /** emit.e:1282				MarkTargets(source, S_RI_TARGET)*/
        _31990 = _53MarkTargets(_source_52357, 53);
        DeRef(_31990);
        _31990 = NOVALUE;
        goto L7B; // [4309] 4349
L7A: 

        /** emit.e:1285				emit_addr(CurrentSub)*/
        _45emit_addr(_27CurrentSub_20579);

        /** emit.e:1286				emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_28SymTab_11572)){
                _27154 = SEQ_PTR(_28SymTab_11572)->length;
        }
        else {
            _27154 = 1;
        }
        _45emit_addr(_27154);
        _27154 = NOVALUE;

        /** emit.e:1288				if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L7C; // [4333] 4348
        }
        else{
        }

        /** emit.e:1290					MarkTargets(source, S_NREFS)*/
        _31989 = _53MarkTargets(_source_52357, 12);
        DeRef(_31989);
        _31989 = NOVALUE;
L7C: 
L7B: 

        /** emit.e:1294			emit_addr(source)*/
        _45emit_addr(_source_52357);

        /** emit.e:1295			emit_addr(current_file_no)  -- necessary at top level*/
        _45emit_addr(_27current_file_no_20571);

        /** emit.e:1296			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1297			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1298			TempInteger(c) -- result will always be an integer*/
        _45TempInteger(_c_52355);

        /** emit.e:1299			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1300			emit_addr(c)*/
        _45emit_addr(_c_52355);
        goto LC; // [4391] 7739

        /** emit.e:1305		case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** emit.e:1306			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1307			emit_addr(Pop())*/
        _27156 = _45Pop();
        _45emit_addr(_27156);
        _27156 = NOVALUE;

        /** emit.e:1308			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1309			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1310			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1311			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [4437] 7739

        /** emit.e:1315		case POKE_LONG then*/
        case 434:

        /** emit.e:1316			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_44IWINDOWS_20714 != 0) {
            _27158 = 1;
            goto L7D; // [4447] 4457
        }
        _27158 = (_44TWINDOWS_20715 != 0);
L7D: 
        if (_27158 != 0) {
            goto L7E; // [4457] 4481
        }
        if (0 != 0) {
            DeRef(_27160);
            _27160 = 1;
            goto L7F; // [4463] 4473
        }
        _27160 = (0 != 0);
L7F: 
        _27161 = (_27160 == 0);
        _27160 = NOVALUE;
        if (_27161 == 0)
        {
            DeRef(_27161);
            _27161 = NOVALUE;
            goto L80; // [4477] 4493
        }
        else{
            DeRef(_27161);
            _27161 = NOVALUE;
        }
L7E: 

        /** emit.e:1317				op = POKE4*/
        _op_52351 = 138;
        goto L81; // [4490] 4503
L80: 

        /** emit.e:1319				op = POKE8*/
        _op_52351 = 212;
L81: 

        /** emit.e:1321			last_op = op*/
        _45last_op_52310 = _op_52351;

        /** emit.e:1324		case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:
        case 212:
        case 215:

        /** emit.e:1326			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1328			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1329			emit_addr(Pop())*/
        _27163 = _45Pop();
        _45emit_addr(_27163);
        _27163 = NOVALUE;

        /** emit.e:1330			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1331			if op = C_PROC then*/
        if (_op_52351 != 132)
        goto L82; // [4565] 4577

        /** emit.e:1332				emit_addr(CurrentSub)*/
        _45emit_addr(_27CurrentSub_20579);
L82: 

        /** emit.e:1334			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [4584] 7739

        /** emit.e:1337		case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** emit.e:1339			cont21ii(op, TRUE)  -- both integer args => integer result*/
        _45cont21ii(_op_52351, _9TRUE_441);
        goto LC; // [4622] 7739

        /** emit.e:1341		case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** emit.e:1343			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1344			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1346			if b < 1 or a < 1 then*/
        _27167 = (_b_52354 < 1);
        if (_27167 != 0) {
            goto L83; // [4648] 4661
        }
        _27169 = (_a_52353 < 1);
        if (_27169 == 0)
        {
            DeRef(_27169);
            _27169 = NOVALUE;
            goto L84; // [4657] 4682
        }
        else{
            DeRef(_27169);
            _27169 = NOVALUE;
        }
L83: 

        /** emit.e:1347				Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1348				Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1349				cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [4679] 7739
L84: 

        /** emit.e:1350			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27170 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27170);
        _27171 = (object)*(((s1_ptr)_2)->base + 3);
        _27170 = NOVALUE;
        if (IS_ATOM_INT(_27171)) {
            _27172 = (_27171 == 2);
        }
        else {
            _27172 = binary_op(EQUALS, _27171, 2);
        }
        _27171 = NOVALUE;
        if (IS_ATOM_INT(_27172)) {
            if (_27172 == 0) {
                goto L85; // [4702] 4763
            }
        }
        else {
            if (DBL_PTR(_27172)->dbl == 0.0) {
                goto L85; // [4702] 4763
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27174 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27174);
        _27175 = (object)*(((s1_ptr)_2)->base + 1);
        _27174 = NOVALUE;
        if (_27175 == 1)
        _27176 = 1;
        else if (IS_ATOM_INT(_27175) && IS_ATOM_INT(1))
        _27176 = 0;
        else
        _27176 = (compare(_27175, 1) == 0);
        _27175 = NOVALUE;
        if (_27176 == 0)
        {
            _27176 = NOVALUE;
            goto L85; // [4723] 4763
        }
        else{
            _27176 = NOVALUE;
        }

        /** emit.e:1351				op = PLUS1*/
        _op_52351 = 93;

        /** emit.e:1352				emit_opcode(op)*/
        _45emit_opcode(93);

        /** emit.e:1353				emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1354				emit_addr(0)*/
        _45emit_addr(0);

        /** emit.e:1355				cont21d(op, a, b, FALSE)*/
        _45cont21d(93, _a_52353, _b_52354, _9FALSE_439);
        goto LC; // [4760] 7739
L85: 

        /** emit.e:1356			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27177 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27177);
        _27178 = (object)*(((s1_ptr)_2)->base + 3);
        _27177 = NOVALUE;
        if (IS_ATOM_INT(_27178)) {
            _27179 = (_27178 == 2);
        }
        else {
            _27179 = binary_op(EQUALS, _27178, 2);
        }
        _27178 = NOVALUE;
        if (IS_ATOM_INT(_27179)) {
            if (_27179 == 0) {
                goto L86; // [4783] 4844
            }
        }
        else {
            if (DBL_PTR(_27179)->dbl == 0.0) {
                goto L86; // [4783] 4844
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27181 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27181);
        _27182 = (object)*(((s1_ptr)_2)->base + 1);
        _27181 = NOVALUE;
        if (_27182 == 1)
        _27183 = 1;
        else if (IS_ATOM_INT(_27182) && IS_ATOM_INT(1))
        _27183 = 0;
        else
        _27183 = (compare(_27182, 1) == 0);
        _27182 = NOVALUE;
        if (_27183 == 0)
        {
            _27183 = NOVALUE;
            goto L86; // [4804] 4844
        }
        else{
            _27183 = NOVALUE;
        }

        /** emit.e:1357				op = PLUS1*/
        _op_52351 = 93;

        /** emit.e:1358				emit_opcode(op)*/
        _45emit_opcode(93);

        /** emit.e:1359				emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1360				emit_addr(0)*/
        _45emit_addr(0);

        /** emit.e:1361				cont21d(op, a, b, FALSE)*/
        _45cont21d(93, _a_52353, _b_52354, _9FALSE_439);
        goto LC; // [4841] 7739
L86: 

        /** emit.e:1363				Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1364				Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1365				cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [4863] 7739

        /** emit.e:1368		case rw:MULTIPLY then*/
        case 13:

        /** emit.e:1370			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1371			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1372			if a < 1 or b < 1 then*/
        _27186 = (_a_52353 < 1);
        if (_27186 != 0) {
            goto L87; // [4889] 4902
        }
        _27188 = (_b_52354 < 1);
        if (_27188 == 0)
        {
            DeRef(_27188);
            _27188 = NOVALUE;
            goto L88; // [4898] 4923
        }
        else{
            DeRef(_27188);
            _27188 = NOVALUE;
        }
L87: 

        /** emit.e:1373				Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1374				Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1375				cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [4920] 7739
L88: 

        /** emit.e:1377			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27189 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27189);
        _27190 = (object)*(((s1_ptr)_2)->base + 3);
        _27189 = NOVALUE;
        if (IS_ATOM_INT(_27190)) {
            _27191 = (_27190 == 2);
        }
        else {
            _27191 = binary_op(EQUALS, _27190, 2);
        }
        _27190 = NOVALUE;
        if (IS_ATOM_INT(_27191)) {
            if (_27191 == 0) {
                goto L89; // [4943] 5004
            }
        }
        else {
            if (DBL_PTR(_27191)->dbl == 0.0) {
                goto L89; // [4943] 5004
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27193 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27193);
        _27194 = (object)*(((s1_ptr)_2)->base + 1);
        _27193 = NOVALUE;
        if (_27194 == 2)
        _27195 = 1;
        else if (IS_ATOM_INT(_27194) && IS_ATOM_INT(2))
        _27195 = 0;
        else
        _27195 = (compare(_27194, 2) == 0);
        _27194 = NOVALUE;
        if (_27195 == 0)
        {
            _27195 = NOVALUE;
            goto L89; // [4964] 5004
        }
        else{
            _27195 = NOVALUE;
        }

        /** emit.e:1379				op = PLUS*/
        _op_52351 = 11;

        /** emit.e:1380				emit_opcode(op)*/
        _45emit_opcode(11);

        /** emit.e:1381				emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1382				emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1383				cont21d(op, a, b, FALSE)*/
        _45cont21d(11, _a_52353, _b_52354, _9FALSE_439);
        goto LC; // [5001] 7739
L89: 

        /** emit.e:1385			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27196 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27196);
        _27197 = (object)*(((s1_ptr)_2)->base + 3);
        _27196 = NOVALUE;
        if (IS_ATOM_INT(_27197)) {
            _27198 = (_27197 == 2);
        }
        else {
            _27198 = binary_op(EQUALS, _27197, 2);
        }
        _27197 = NOVALUE;
        if (IS_ATOM_INT(_27198)) {
            if (_27198 == 0) {
                goto L8A; // [5024] 5085
            }
        }
        else {
            if (DBL_PTR(_27198)->dbl == 0.0) {
                goto L8A; // [5024] 5085
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27200 = (object)*(((s1_ptr)_2)->base + _a_52353);
        _2 = (object)SEQ_PTR(_27200);
        _27201 = (object)*(((s1_ptr)_2)->base + 1);
        _27200 = NOVALUE;
        if (_27201 == 2)
        _27202 = 1;
        else if (IS_ATOM_INT(_27201) && IS_ATOM_INT(2))
        _27202 = 0;
        else
        _27202 = (compare(_27201, 2) == 0);
        _27201 = NOVALUE;
        if (_27202 == 0)
        {
            _27202 = NOVALUE;
            goto L8A; // [5045] 5085
        }
        else{
            _27202 = NOVALUE;
        }

        /** emit.e:1386				op = PLUS*/
        _op_52351 = 11;

        /** emit.e:1387				emit_opcode(op)*/
        _45emit_opcode(11);

        /** emit.e:1388				emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1389				emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1390				cont21d(op, a, b, FALSE)*/
        _45cont21d(11, _a_52353, _b_52354, _9FALSE_439);
        goto LC; // [5082] 7739
L8A: 

        /** emit.e:1393				Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1394				Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1395				cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [5104] 7739

        /** emit.e:1399		case rw:DIVIDE then*/
        case 14:

        /** emit.e:1400			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1401			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27204 = (_b_52354 > 0);
        if (_27204 == 0) {
            _27205 = 0;
            goto L8B; // [5123] 5149
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27206 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27206);
        _27207 = (object)*(((s1_ptr)_2)->base + 3);
        _27206 = NOVALUE;
        if (IS_ATOM_INT(_27207)) {
            _27208 = (_27207 == 2);
        }
        else {
            _27208 = binary_op(EQUALS, _27207, 2);
        }
        _27207 = NOVALUE;
        if (IS_ATOM_INT(_27208))
        _27205 = (_27208 != 0);
        else
        _27205 = DBL_PTR(_27208)->dbl != 0.0;
L8B: 
        if (_27205 == 0) {
            goto L8C; // [5149] 5220
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27210 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27210);
        _27211 = (object)*(((s1_ptr)_2)->base + 1);
        _27210 = NOVALUE;
        if (_27211 == 2)
        _27212 = 1;
        else if (IS_ATOM_INT(_27211) && IS_ATOM_INT(2))
        _27212 = 0;
        else
        _27212 = (compare(_27211, 2) == 0);
        _27211 = NOVALUE;
        if (_27212 == 0)
        {
            _27212 = NOVALUE;
            goto L8C; // [5170] 5220
        }
        else{
            _27212 = NOVALUE;
        }

        /** emit.e:1402				op = DIV2*/
        _op_52351 = 98;

        /** emit.e:1403				emit_opcode(op)*/
        _45emit_opcode(98);

        /** emit.e:1404				emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _27213 = _45Pop();
        _45emit_addr(_27213);
        _27213 = NOVALUE;

        /** emit.e:1405				a = 0*/
        _a_52353 = 0;

        /** emit.e:1406				emit_addr(0)*/
        _45emit_addr(0);

        /** emit.e:1407				cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _45cont21d(98, 0, _b_52354, _9FALSE_439);
        goto LC; // [5217] 7739
L8C: 

        /** emit.e:1409				Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1410				cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [5234] 7739

        /** emit.e:1413		case FLOOR then*/
        case 83:

        /** emit.e:1414			if previous_op = rw:DIVIDE then*/
        if (_27previous_op_20670 != 14)
        goto L8D; // [5244] 5292

        /** emit.e:1415				op = FLOOR_DIV*/
        _op_52351 = 63;

        /** emit.e:1416				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27215 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27215 = 1;
        }
        _27216 = _27215 - 3;
        _27215 = NOVALUE;
        _45backpatch(_27216, 63);
        _27216 = NOVALUE;

        /** emit.e:1417				assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1418				last_op = op*/
        _45last_op_52310 = 63;

        /** emit.e:1419				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto LC; // [5289] 7739
L8D: 

        /** emit.e:1421			elsif previous_op = DIV2 then*/
        if (_27previous_op_20670 != 98)
        goto L8E; // [5298] 5385

        /** emit.e:1422				op = FLOOR_DIV2*/
        _op_52351 = 66;

        /** emit.e:1423				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27218 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27218 = 1;
        }
        _27219 = _27218 - 3;
        _27218 = NOVALUE;
        _45backpatch(_27219, 66);
        _27219 = NOVALUE;

        /** emit.e:1424				assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1425				if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_27Code_20660)){
                _27220 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _27220 = 1;
        }
        _27221 = _27220 - 2;
        _27220 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _27222 = (object)*(((s1_ptr)_2)->base + _27221);
        Ref(_27222);
        _27223 = _45IsInteger(_27222);
        _27222 = NOVALUE;
        if (_27223 == 0) {
            DeRef(_27223);
            _27223 = NOVALUE;
            goto L8F; // [5352] 5372
        }
        else {
            if (!IS_ATOM_INT(_27223) && DBL_PTR(_27223)->dbl == 0.0){
                DeRef(_27223);
                _27223 = NOVALUE;
                goto L8F; // [5352] 5372
            }
            DeRef(_27223);
            _27223 = NOVALUE;
        }
        DeRef(_27223);
        _27223 = NOVALUE;

        /** emit.e:1426					TempInteger(Top()) --mark temp as integer type*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5482_53453);
        _2 = (object)SEQ_PTR(_45cg_stack_51428);
        _Top_inlined_Top_at_5482_53453 = (object)*(((s1_ptr)_2)->base + _45cgi_51429);
        Ref(_Top_inlined_Top_at_5482_53453);
        Ref(_Top_inlined_Top_at_5482_53453);
        _45TempInteger(_Top_inlined_Top_at_5482_53453);
L8F: 

        /** emit.e:1428				last_op = op*/
        _45last_op_52310 = _op_52351;

        /** emit.e:1429				last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto LC; // [5382] 7739
L8E: 

        /** emit.e:1431				cont11ii(op, TRUE)*/
        _45cont11ii(_op_52351, _9TRUE_441);
        goto LC; // [5394] 7739

        /** emit.e:1437		case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** emit.e:1440			cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [5438] 7739

        /** emit.e:1442		case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** emit.e:1443			c = Pop()*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1444			TempKeep(c)*/
        _45TempKeep(_c_52355);

        /** emit.e:1445			b = Pop()  -- remove SC1's temp*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1446			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1447			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;

        /** emit.e:1448			last_op = last_op_backup*/
        _45last_op_52310 = _last_op_backup_52369;

        /** emit.e:1449			last_pc = last_pc_backup*/
        _45last_pc_52311 = _last_pc_backup_52368;
        goto LC; // [5485] 7739

        /** emit.e:1452		case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** emit.e:1453			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1454			emit_addr(Pop())*/
        _27226 = _45Pop();
        _45emit_addr(_27226);
        _27226 = NOVALUE;

        /** emit.e:1455			c = Pop()*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1456			TempKeep(c)*/
        _45TempKeep(_c_52355);

        /** emit.e:1457			emit_addr(c) -- target*/
        _45emit_addr(_c_52355);

        /** emit.e:1458			TempInteger(c)*/
        _45TempInteger(_c_52355);

        /** emit.e:1459			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1460			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [5540] 7739

        /** emit.e:1463		case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** emit.e:1464			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1465			c = Pop()*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1466			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1467			emit_addr(Pop())*/
        _27230 = _45Pop();
        _45emit_addr(_27230);
        _27230 = NOVALUE;

        /** emit.e:1468			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1469			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1470			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [5594] 7739

        /** emit.e:1473		case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** emit.e:1474			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1475			c = Pop()*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1476			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1477			emit_addr(Pop())*/
        _27233 = _45Pop();
        _45emit_addr(_27233);
        _27233 = NOVALUE;

        /** emit.e:1478			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1479			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1480			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1481			if op = FIND or op = FIND_FROM or op = OPEN then*/
        _27235 = (_op_52351 == 77);
        if (_27235 != 0) {
            _27236 = 1;
            goto L90; // [5669] 5683
        }
        _27237 = (_op_52351 == 176);
        _27236 = (_27237 != 0);
L90: 
        if (_27236 != 0) {
            goto L91; // [5683] 5698
        }
        _27239 = (_op_52351 == 37);
        if (_27239 == 0)
        {
            DeRef(_27239);
            _27239 = NOVALUE;
            goto L92; // [5694] 5706
        }
        else{
            DeRef(_27239);
            _27239 = NOVALUE;
        }
L91: 

        /** emit.e:1482				TempInteger( c )*/
        _45TempInteger(_c_52355);
        goto L93; // [5703] 5713
L92: 

        /** emit.e:1484				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);
L93: 

        /** emit.e:1486			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1487			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1488			emit_addr(c)*/
        _45emit_addr(_c_52355);
        goto LC; // [5730] 7739

        /** emit.e:1491		case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** emit.e:1492			n = op_info1  -- number of items to concatenate*/
        _n_52364 = _45op_info1_51413;

        /** emit.e:1493			emit_opcode(CONCAT_N)*/
        _45emit_opcode(157);

        /** emit.e:1494			emit(n)*/
        _45emit(_n_52364);

        /** emit.e:1495			for i = 1 to n do*/
        _27240 = _n_52364;
        {
            object _i_53521;
            _i_53521 = 1;
L94: 
            if (_i_53521 > _27240){
                goto L95; // [5760] 5788
            }

            /** emit.e:1496				symtab_index element = Pop()*/
            _element_53524 = _45Pop();
            if (!IS_ATOM_INT(_element_53524)) {
                _1 = (object)(DBL_PTR(_element_53524)->dbl);
                DeRefDS(_element_53524);
                _element_53524 = _1;
            }

            /** emit.e:1497				emit_addr( element )  -- reverse order*/
            _45emit_addr(_element_53524);

            /** emit.e:1498			end for*/
            _i_53521 = _i_53521 + 1;
            goto L94; // [5783] 5767
L95: 
            ;
        }

        /** emit.e:1499			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1500			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1501			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);

        /** emit.e:1502			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1503			Push(c)*/
        _45Push(_c_52355);
        goto LC; // [5819] 7739

        /** emit.e:1505		case FOR then*/
        case 21:

        /** emit.e:1506			c = Pop() -- increment*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1507			TempKeep(c)*/
        _45TempKeep(_c_52355);

        /** emit.e:1508			ic = IsInteger(c)*/
        _ic_52363 = _45IsInteger(_c_52355);
        if (!IS_ATOM_INT(_ic_52363)) {
            _1 = (object)(DBL_PTR(_ic_52363)->dbl);
            DeRefDS(_ic_52363);
            _ic_52363 = _1;
        }

        /** emit.e:1509			if c < 1 or*/
        _27245 = (_c_52355 < 1);
        if (_27245 != 0) {
            goto L96; // [5851] 5930
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27247 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27247);
        _27248 = (object)*(((s1_ptr)_2)->base + 3);
        _27247 = NOVALUE;
        if (IS_ATOM_INT(_27248)) {
            _27249 = (_27248 == 1);
        }
        else {
            _27249 = binary_op(EQUALS, _27248, 1);
        }
        _27248 = NOVALUE;
        if (IS_ATOM_INT(_27249)) {
            if (_27249 == 0) {
                DeRef(_27250);
                _27250 = 0;
                goto L97; // [5873] 5899
            }
        }
        else {
            if (DBL_PTR(_27249)->dbl == 0.0) {
                DeRef(_27250);
                _27250 = 0;
                goto L97; // [5873] 5899
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27251 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27251);
        _27252 = (object)*(((s1_ptr)_2)->base + 4);
        _27251 = NOVALUE;
        if (IS_ATOM_INT(_27252)) {
            _27253 = (_27252 != 2);
        }
        else {
            _27253 = binary_op(NOTEQ, _27252, 2);
        }
        _27252 = NOVALUE;
        DeRef(_27250);
        if (IS_ATOM_INT(_27253))
        _27250 = (_27253 != 0);
        else
        _27250 = DBL_PTR(_27253)->dbl != 0.0;
L97: 
        if (_27250 == 0) {
            DeRef(_27254);
            _27254 = 0;
            goto L98; // [5899] 5925
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27255 = (object)*(((s1_ptr)_2)->base + _c_52355);
        _2 = (object)SEQ_PTR(_27255);
        _27256 = (object)*(((s1_ptr)_2)->base + 4);
        _27255 = NOVALUE;
        if (IS_ATOM_INT(_27256)) {
            _27257 = (_27256 != 4);
        }
        else {
            _27257 = binary_op(NOTEQ, _27256, 4);
        }
        _27256 = NOVALUE;
        if (IS_ATOM_INT(_27257))
        _27254 = (_27257 != 0);
        else
        _27254 = DBL_PTR(_27257)->dbl != 0.0;
L98: 
        if (_27254 == 0)
        {
            _27254 = NOVALUE;
            goto L99; // [5926] 5967
        }
        else{
            _27254 = NOVALUE;
        }
L96: 

        /** emit.e:1514				emit_opcode(ASSIGN)*/
        _45emit_opcode(18);

        /** emit.e:1515				emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1516				c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1517				if ic then*/
        if (_ic_52363 == 0)
        {
            goto L9A; // [5952] 5961
        }
        else{
        }

        /** emit.e:1518					TempInteger( c )*/
        _45TempInteger(_c_52355);
L9A: 

        /** emit.e:1520				emit_addr(c)*/
        _45emit_addr(_c_52355);
L99: 

        /** emit.e:1522			b = Pop() -- limit*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1523			TempKeep(b)*/
        _45TempKeep(_b_52354);

        /** emit.e:1524			ib = IsInteger(b)*/
        _ib_52362 = _45IsInteger(_b_52354);
        if (!IS_ATOM_INT(_ib_52362)) {
            _1 = (object)(DBL_PTR(_ib_52362)->dbl);
            DeRefDS(_ib_52362);
            _ib_52362 = _1;
        }

        /** emit.e:1525			if b < 1 or*/
        _27261 = (_b_52354 < 1);
        if (_27261 != 0) {
            goto L9B; // [5993] 6072
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27263 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27263);
        _27264 = (object)*(((s1_ptr)_2)->base + 3);
        _27263 = NOVALUE;
        if (IS_ATOM_INT(_27264)) {
            _27265 = (_27264 == 1);
        }
        else {
            _27265 = binary_op(EQUALS, _27264, 1);
        }
        _27264 = NOVALUE;
        if (IS_ATOM_INT(_27265)) {
            if (_27265 == 0) {
                DeRef(_27266);
                _27266 = 0;
                goto L9C; // [6015] 6041
            }
        }
        else {
            if (DBL_PTR(_27265)->dbl == 0.0) {
                DeRef(_27266);
                _27266 = 0;
                goto L9C; // [6015] 6041
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27267 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27267);
        _27268 = (object)*(((s1_ptr)_2)->base + 4);
        _27267 = NOVALUE;
        if (IS_ATOM_INT(_27268)) {
            _27269 = (_27268 != 2);
        }
        else {
            _27269 = binary_op(NOTEQ, _27268, 2);
        }
        _27268 = NOVALUE;
        DeRef(_27266);
        if (IS_ATOM_INT(_27269))
        _27266 = (_27269 != 0);
        else
        _27266 = DBL_PTR(_27269)->dbl != 0.0;
L9C: 
        if (_27266 == 0) {
            DeRef(_27270);
            _27270 = 0;
            goto L9D; // [6041] 6067
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27271 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27271);
        _27272 = (object)*(((s1_ptr)_2)->base + 4);
        _27271 = NOVALUE;
        if (IS_ATOM_INT(_27272)) {
            _27273 = (_27272 != 4);
        }
        else {
            _27273 = binary_op(NOTEQ, _27272, 4);
        }
        _27272 = NOVALUE;
        if (IS_ATOM_INT(_27273))
        _27270 = (_27273 != 0);
        else
        _27270 = DBL_PTR(_27273)->dbl != 0.0;
L9D: 
        if (_27270 == 0)
        {
            _27270 = NOVALUE;
            goto L9E; // [6068] 6109
        }
        else{
            _27270 = NOVALUE;
        }
L9B: 

        /** emit.e:1530				emit_opcode(ASSIGN)*/
        _45emit_opcode(18);

        /** emit.e:1531				emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1532				b = NewTempSym()*/
        _b_52354 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1533				if ib then*/
        if (_ib_52362 == 0)
        {
            goto L9F; // [6094] 6103
        }
        else{
        }

        /** emit.e:1534					TempInteger( b )*/
        _45TempInteger(_b_52354);
L9F: 

        /** emit.e:1536				emit_addr(b)*/
        _45emit_addr(_b_52354);
L9E: 

        /** emit.e:1538			a = Pop() -- initial value*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1539			if IsInteger(a) and ib and ic then*/
        _27276 = _45IsInteger(_a_52353);
        if (IS_ATOM_INT(_27276)) {
            if (_27276 == 0) {
                DeRef(_27277);
                _27277 = 0;
                goto LA0; // [6122] 6130
            }
        }
        else {
            if (DBL_PTR(_27276)->dbl == 0.0) {
                DeRef(_27277);
                _27277 = 0;
                goto LA0; // [6122] 6130
            }
        }
        DeRef(_27277);
        _27277 = (_ib_52362 != 0);
LA0: 
        if (_27277 == 0) {
            goto LA1; // [6130] 6169
        }
        if (_ic_52363 == 0)
        {
            goto LA1; // [6135] 6169
        }
        else{
        }

        /** emit.e:1540				SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_45op_info1_51413 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _53integer_type_47190;
        DeRef(_1);
        _27279 = NOVALUE;

        /** emit.e:1541				op = FOR_I*/
        _op_52351 = 125;
        goto LA2; // [6166] 6179
LA1: 

        /** emit.e:1543				op = FOR*/
        _op_52351 = 21;
LA2: 

        /** emit.e:1545			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1546			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1547			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1548			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1549			emit_addr(CurrentSub) -- in case recursion check is needed*/
        _45emit_addr(_27CurrentSub_20579);

        /** emit.e:1550			Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1551			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1552			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6223] 7739

        /** emit.e:1555		case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** emit.e:1556			emit_opcode(op) -- will be patched at runtime*/
        _45emit_opcode(_op_52351);

        /** emit.e:1557			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1558			emit_addr(op_info2) -- address of top of loop*/
        _45emit_addr(_45op_info2_51414);

        /** emit.e:1559			emit_addr(Pop())    -- limit*/
        _27282 = _45Pop();
        _45emit_addr(_27282);
        _27282 = NOVALUE;

        /** emit.e:1560			emit_addr(op_info1) -- loop var*/
        _45emit_addr(_45op_info1_51413);

        /** emit.e:1561			emit_addr(a)        -- increment - not always used -*/
        _45emit_addr(_a_52353);

        /** emit.e:1563			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6277] 7739

        /** emit.e:1566		case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** emit.e:1568			b = Pop()      -- rhs value, keep on stack*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1569			TempKeep(b)*/
        _45TempKeep(_b_52354);

        /** emit.e:1571			a = Pop()      -- subscript, keep on stack*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1572			TempKeep(a)*/
        _45TempKeep(_a_52353);

        /** emit.e:1574			c = Pop()      -- lhs sequence, keep on stack*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1575			TempKeep(c)*/
        _45TempKeep(_c_52355);

        /** emit.e:1577			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1578			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1579			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1581			d = NewTempSym()*/
        _d_52356 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_d_52356)) {
            _1 = (object)(DBL_PTR(_d_52356)->dbl);
            DeRefDS(_d_52356);
            _d_52356 = _1;
        }

        /** emit.e:1582			emit_addr(d)   -- place to store result*/
        _45emit_addr(_d_52356);

        /** emit.e:1583			emit_temp( d, NEW_REFERENCE )*/
        _45emit_temp(_d_52356, 1);

        /** emit.e:1585			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1586			Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1587			Push(d)*/
        _45Push(_d_52356);

        /** emit.e:1588			Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1589			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6382] 7739

        /** emit.e:1592		case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** emit.e:1593			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1594			b = Pop() -- rhs value*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1595			a = Pop() -- 2nd subs*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1596			c = Pop() -- 1st subs*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1597			emit_addr(Pop()) -- sequence*/
        _27290 = _45Pop();
        _45emit_addr(_27290);
        _27290 = NOVALUE;

        /** emit.e:1598			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1599			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1600			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1601			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6446] 7739

        /** emit.e:1604		case REPLACE then*/
        case 201:

        /** emit.e:1605			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1607			b = Pop()  -- source*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1608			a = Pop()  -- replacement*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1609			c = Pop()  -- start of replaced slice*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1610			d = Pop()  -- end of replaced slice*/
        _d_52356 = _45Pop();
        if (!IS_ATOM_INT(_d_52356)) {
            _1 = (object)(DBL_PTR(_d_52356)->dbl);
            DeRefDS(_d_52356);
            _d_52356 = _1;
        }

        /** emit.e:1611			emit_addr(d)*/
        _45emit_addr(_d_52356);

        /** emit.e:1612			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1613			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1614			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1616			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1617			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1618			emit_addr(c)     -- place to store result*/
        _45emit_addr(_c_52355);

        /** emit.e:1619			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);

        /** emit.e:1620			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;
        goto LC; // [6536] 7739

        /** emit.e:1623		case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** emit.e:1625			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1627			b = Pop()        -- rhs value not used*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1628			TempKeep(b)*/
        _45TempKeep(_b_52354);

        /** emit.e:1630			a = Pop()        -- 2nd subs*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1631			TempKeep(a)*/
        _45TempKeep(_a_52353);

        /** emit.e:1633			c = Pop()        -- 1st subs*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1634			TempKeep(c)*/
        _45TempKeep(_c_52355);

        /** emit.e:1636			d = Pop()*/
        _d_52356 = _45Pop();
        if (!IS_ATOM_INT(_d_52356)) {
            _1 = (object)(DBL_PTR(_d_52356)->dbl);
            DeRefDS(_d_52356);
            _d_52356 = _1;
        }

        /** emit.e:1637			TempKeep(d)      -- sequence*/
        _45TempKeep(_d_52356);

        /** emit.e:1639			emit_addr(d)*/
        _45emit_addr(_d_52356);

        /** emit.e:1640			Push(d)*/
        _45Push(_d_52356);

        /** emit.e:1642			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1643			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1645			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1646			Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1648			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1649			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1650			emit_addr(c)     -- place to store result*/
        _45emit_addr(_c_52355);

        /** emit.e:1651			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);

        /** emit.e:1653			Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1654			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6663] 7739

        /** emit.e:1657		case CALL_PROC then*/
        case 136:

        /** emit.e:1658			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1659			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1660			emit_addr(Pop())*/
        _27302 = _45Pop();
        _45emit_addr(_27302);
        _27302 = NOVALUE;

        /** emit.e:1661			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1662			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6701] 7739

        /** emit.e:1664		case CALL_FUNC then*/
        case 137:

        /** emit.e:1665			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1666			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1667			emit_addr(Pop())*/
        _27304 = _45Pop();
        _45emit_addr(_27304);
        _27304 = NOVALUE;

        /** emit.e:1668			emit_addr(b)*/
        _45emit_addr(_b_52354);

        /** emit.e:1669			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1670			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1671			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1672			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1673			emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);
        goto LC; // [6763] 7739

        /** emit.e:1675		case EXIT_BLOCK then*/
        case 206:

        /** emit.e:1676			emit_opcode( op )*/
        _45emit_opcode(_op_52351);

        /** emit.e:1677			emit_addr( Pop() )*/
        _27306 = _45Pop();
        _45emit_addr(_27306);
        _27306 = NOVALUE;

        /** emit.e:1678			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6789] 7739

        /** emit.e:1680		case RETURNP then*/
        case 29:

        /** emit.e:1681			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1682			emit_addr(CurrentSub)*/
        _45emit_addr(_27CurrentSub_20579);

        /** emit.e:1683			emit_addr(top_block())*/
        _27307 = _64top_block(0);
        _45emit_addr(_27307);
        _27307 = NOVALUE;

        /** emit.e:1684			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6823] 7739

        /** emit.e:1686		case RETURNF then*/
        case 28:

        /** emit.e:1687			clear_temp( Top() )*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_7037_53671);
        _2 = (object)SEQ_PTR(_45cg_stack_51428);
        _Top_inlined_Top_at_7037_53671 = (object)*(((s1_ptr)_2)->base + _45cgi_51429);
        Ref(_Top_inlined_Top_at_7037_53671);
        Ref(_Top_inlined_Top_at_7037_53671);
        _45clear_temp(_Top_inlined_Top_at_7037_53671);

        /** emit.e:1688			flush_temps()*/
        RefDS(_22209);
        _45flush_temps(_22209);

        /** emit.e:1689			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1690			emit_addr(CurrentSub)*/
        _45emit_addr(_27CurrentSub_20579);

        /** emit.e:1691			emit_addr(Least_block())*/
        _27308 = _64Least_block();
        _45emit_addr(_27308);
        _27308 = NOVALUE;

        /** emit.e:1692			emit_addr(Pop())*/
        _27309 = _45Pop();
        _45emit_addr(_27309);
        _27309 = NOVALUE;

        /** emit.e:1693			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6885] 7739

        /** emit.e:1695		case RETURNT then*/
        case 34:

        /** emit.e:1696			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1697			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [6903] 7739

        /** emit.e:1699		case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** emit.e:1701			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1702			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1703			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;

        /** emit.e:1704			if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_52351 != 79)
        goto LA3; // [6945] 6957

        /** emit.e:1705				TempInteger(c)*/
        _45TempInteger(_c_52355);
        goto LA4; // [6954] 6964
LA3: 

        /** emit.e:1707				emit_temp( c, NEW_REFERENCE )*/
        _45emit_temp(_c_52355, 1);
LA4: 

        /** emit.e:1709			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1710			emit_addr(c)*/
        _45emit_addr(_c_52355);
        goto LC; // [6974] 7739

        /** emit.e:1712		case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** emit.e:1713			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1714			emit_addr(Pop())*/
        _27312 = _45Pop();
        _45emit_addr(_27312);
        _27312 = NOVALUE;

        /** emit.e:1715			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7006] 7739

        /** emit.e:1717		case POWER then*/
        case 72:

        /** emit.e:1719			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1720			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1721			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27315 = (_b_52354 > 0);
        if (_27315 == 0) {
            _27316 = 0;
            goto LA5; // [7032] 7058
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27317 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27317);
        _27318 = (object)*(((s1_ptr)_2)->base + 3);
        _27317 = NOVALUE;
        if (IS_ATOM_INT(_27318)) {
            _27319 = (_27318 == 2);
        }
        else {
            _27319 = binary_op(EQUALS, _27318, 2);
        }
        _27318 = NOVALUE;
        if (IS_ATOM_INT(_27319))
        _27316 = (_27319 != 0);
        else
        _27316 = DBL_PTR(_27319)->dbl != 0.0;
LA5: 
        if (_27316 == 0) {
            goto LA6; // [7058] 7115
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _27321 = (object)*(((s1_ptr)_2)->base + _b_52354);
        _2 = (object)SEQ_PTR(_27321);
        _27322 = (object)*(((s1_ptr)_2)->base + 1);
        _27321 = NOVALUE;
        if (_27322 == 2)
        _27323 = 1;
        else if (IS_ATOM_INT(_27322) && IS_ATOM_INT(2))
        _27323 = 0;
        else
        _27323 = (compare(_27322, 2) == 0);
        _27322 = NOVALUE;
        if (_27323 == 0)
        {
            _27323 = NOVALUE;
            goto LA6; // [7079] 7115
        }
        else{
            _27323 = NOVALUE;
        }

        /** emit.e:1723				op = rw:MULTIPLY*/
        _op_52351 = 13;

        /** emit.e:1724				emit_opcode(op)*/
        _45emit_opcode(13);

        /** emit.e:1725				emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1726				emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1727				cont21d(op, a, b, FALSE)*/
        _45cont21d(13, _a_52353, _b_52354, _9FALSE_439);
        goto LC; // [7112] 7739
LA6: 

        /** emit.e:1729				Push(a)*/
        _45Push(_a_52353);

        /** emit.e:1730				Push(b)*/
        _45Push(_b_52354);

        /** emit.e:1731				cont21ii(op, FALSE)*/
        _45cont21ii(_op_52351, _9FALSE_439);
        goto LC; // [7134] 7739

        /** emit.e:1735		case TYPE_CHECK then*/
        case 65:

        /** emit.e:1736			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1737			c = Pop()*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1738			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7159] 7739

        /** emit.e:1741		case DOLLAR then*/
        case -22:

        /** emit.e:1742			if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _27325 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _27325 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51421);
        _27326 = (object)*(((s1_ptr)_2)->base + _27325);
        if (IS_ATOM_INT(_27326)) {
            _27327 = (_27326 < 0);
        }
        else {
            _27327 = binary_op(LESS, _27326, 0);
        }
        _27326 = NOVALUE;
        if (IS_ATOM_INT(_27327)) {
            if (_27327 != 0) {
                goto LA7; // [7180] 7216
            }
        }
        else {
            if (DBL_PTR(_27327)->dbl != 0.0) {
                goto LA7; // [7180] 7216
            }
        }
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _27329 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _27329 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51421);
        _27330 = (object)*(((s1_ptr)_2)->base + _27329);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_27330)){
            _27331 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27330)->dbl));
        }
        else{
            _27331 = (object)*(((s1_ptr)_2)->base + _27330);
        }
        _2 = (object)SEQ_PTR(_27331);
        _27332 = (object)*(((s1_ptr)_2)->base + 4);
        _27331 = NOVALUE;
        if (IS_ATOM_INT(_27332)) {
            _27333 = (_27332 == 9);
        }
        else {
            _27333 = binary_op(EQUALS, _27332, 9);
        }
        _27332 = NOVALUE;
        if (_27333 == 0) {
            DeRef(_27333);
            _27333 = NOVALUE;
            goto LA8; // [7212] 7286
        }
        else {
            if (!IS_ATOM_INT(_27333) && DBL_PTR(_27333)->dbl == 0.0){
                DeRef(_27333);
                _27333 = NOVALUE;
                goto LA8; // [7212] 7286
            }
            DeRef(_27333);
            _27333 = NOVALUE;
        }
        DeRef(_27333);
        _27333 = NOVALUE;
LA7: 

        /** emit.e:1743				if lhs_ptr and length(current_sequence) = 1 then*/
        if (_45lhs_ptr_51423 == 0) {
            goto LA9; // [7220] 7249
        }
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _27335 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _27335 = 1;
        }
        _27336 = (_27335 == 1);
        _27335 = NOVALUE;
        if (_27336 == 0)
        {
            DeRef(_27336);
            _27336 = NOVALUE;
            goto LA9; // [7234] 7249
        }
        else{
            DeRef(_27336);
            _27336 = NOVALUE;
        }

        /** emit.e:1744					c = PLENGTH*/
        _c_52355 = 160;
        goto LAA; // [7246] 7259
LA9: 

        /** emit.e:1746					c = LENGTH*/
        _c_52355 = 42;
LAA: 

        /** emit.e:1748				c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _27337 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _27337 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51421);
        _27338 = (object)*(((s1_ptr)_2)->base + _27337);
        Ref(_27338);
        _27339 = _42new_forward_reference(-100, _27338, _c_52355);
        _27338 = NOVALUE;
        if (IS_ATOM_INT(_27339)) {
            if ((uintptr_t)_27339 == (uintptr_t)HIGH_BITS){
                _c_52355 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _c_52355 = - _27339;
            }
        }
        else {
            _c_52355 = unary_op(UMINUS, _27339);
        }
        DeRef(_27339);
        _27339 = NOVALUE;
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }
        goto LAB; // [7283] 7300
LA8: 

        /** emit.e:1750				c = current_sequence[$]*/
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _27341 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _27341 = 1;
        }
        _2 = (object)SEQ_PTR(_45current_sequence_51421);
        _c_52355 = (object)*(((s1_ptr)_2)->base + _27341);
        if (!IS_ATOM_INT(_c_52355)){
            _c_52355 = (object)DBL_PTR(_c_52355)->dbl;
        }
LAB: 

        /** emit.e:1754			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_45lhs_ptr_51423 == 0) {
            goto LAC; // [7304] 7331
        }
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _27344 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _27344 = 1;
        }
        _27345 = (_27344 == 1);
        _27344 = NOVALUE;
        if (_27345 == 0)
        {
            DeRef(_27345);
            _27345 = NOVALUE;
            goto LAC; // [7318] 7331
        }
        else{
            DeRef(_27345);
            _27345 = NOVALUE;
        }

        /** emit.e:1755				emit_opcode(PLENGTH)*/
        _45emit_opcode(160);
        goto LAD; // [7328] 7339
LAC: 

        /** emit.e:1757				emit_opcode(LENGTH)*/
        _45emit_opcode(42);
LAD: 

        /** emit.e:1760			emit_addr( c )*/
        _45emit_addr(_c_52355);

        /** emit.e:1762			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1763			TempInteger(c)*/
        _45TempInteger(_c_52355);

        /** emit.e:1764			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1765			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1766			assignable = FALSE -- it wouldn't be assigned anyway*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7374] 7739

        /** emit.e:1769		case TASK_SELF then*/
        case 170:

        /** emit.e:1770			c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1771			Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1772			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1773			emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1774			assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;
        goto LC; // [7410] 7739

        /** emit.e:1776		case SWITCH then*/
        case 185:

        /** emit.e:1777			emit_opcode( op )*/
        _45emit_opcode(_op_52351);

        /** emit.e:1778			c = Pop()*/
        _c_52355 = _45Pop();
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1779			b = Pop()*/
        _b_52354 = _45Pop();
        if (!IS_ATOM_INT(_b_52354)) {
            _1 = (object)(DBL_PTR(_b_52354)->dbl);
            DeRefDS(_b_52354);
            _b_52354 = _1;
        }

        /** emit.e:1780			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1781			emit_addr( a ) -- Switch Expr*/
        _45emit_addr(_a_52353);

        /** emit.e:1782			emit_addr( b ) -- Case values*/
        _45emit_addr(_b_52354);

        /** emit.e:1783			emit_addr( c ) -- Jump table*/
        _45emit_addr(_c_52355);

        /** emit.e:1785			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7464] 7739

        /** emit.e:1787		case CASE then*/
        case 186:

        /** emit.e:1789			emit_opcode( op )*/
        _45emit_opcode(_op_52351);

        /** emit.e:1790			emit( cg_stack[cgi] )  -- the case index*/
        _2 = (object)SEQ_PTR(_45cg_stack_51428);
        _27351 = (object)*(((s1_ptr)_2)->base + _45cgi_51429);
        Ref(_27351);
        _45emit(_27351);
        _27351 = NOVALUE;

        /** emit.e:1791			cgi -= 1*/
        _45cgi_51429 = _45cgi_51429 - 1;
        goto LC; // [7496] 7739

        /** emit.e:1794		case PLATFORM then*/
        case 155:

        /** emit.e:1795			if BIND and shroud_only then*/
        if (_27BIND_20182 == 0) {
            goto LAE; // [7506] 7554
        }
        if (_27shroud_only_20569 == 0)
        {
            goto LAE; // [7513] 7554
        }
        else{
        }

        /** emit.e:1797				c = NewTempSym()*/
        _c_52355 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_52355)) {
            _1 = (object)(DBL_PTR(_c_52355)->dbl);
            DeRefDS(_c_52355);
            _c_52355 = _1;
        }

        /** emit.e:1798				TempInteger(c)*/
        _45TempInteger(_c_52355);

        /** emit.e:1799				Push(c)*/
        _45Push(_c_52355);

        /** emit.e:1800				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1801				emit_addr(c)*/
        _45emit_addr(_c_52355);

        /** emit.e:1802				assignable = TRUE*/
        _45assignable_51431 = _9TRUE_441;
        goto LC; // [7551] 7739
LAE: 

        /** emit.e:1806				n = host_platform()*/
        _n_52364 = _44host_platform();
        if (!IS_ATOM_INT(_n_52364)) {
            _1 = (object)(DBL_PTR(_n_52364)->dbl);
            DeRefDS(_n_52364);
            _n_52364 = _1;
        }

        /** emit.e:1807				Push(NewIntSym(n))*/
        _27356 = _53NewIntSym(_n_52364);
        _45Push(_27356);
        _27356 = NOVALUE;

        /** emit.e:1808				assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7578] 7739

        /** emit.e:1812		case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** emit.e:1813			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1814			emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1815			emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1816			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7610] 7739

        /** emit.e:1818		case TRACE then*/
        case 64:

        /** emit.e:1819			a = Pop()*/
        _a_52353 = _45Pop();
        if (!IS_ATOM_INT(_a_52353)) {
            _1 = (object)(DBL_PTR(_a_52353)->dbl);
            DeRefDS(_a_52353);
            _a_52353 = _1;
        }

        /** emit.e:1820			if OpTrace then*/
        if (_27OpTrace_20641 == 0)
        {
            goto LAF; // [7627] 7673
        }
        else{
        }

        /** emit.e:1822				emit_opcode(op)*/
        _45emit_opcode(_op_52351);

        /** emit.e:1823				emit_addr(a)*/
        _45emit_addr(_a_52353);

        /** emit.e:1824				if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto LB0; // [7644] 7672
        }
        else{
        }

        /** emit.e:1825					if not trace_called then*/
        if (_45trace_called_51416 != 0)
        goto LB1; // [7651] 7662

        /** emit.e:1826						Warning(217,0)*/
        RefDS(_22209);
        _49Warning(217, 0, _22209);
LB1: 

        /** emit.e:1828					trace_called = TRUE*/
        _45trace_called_51416 = _9TRUE_441;
LB0: 
LAF: 

        /** emit.e:1831			assignable = FALSE*/
        _45assignable_51431 = _9FALSE_439;
        goto LC; // [7680] 7739

        /** emit.e:1833		case REF_TEMP then*/
        case 207:

        /** emit.e:1835			emit_opcode( REF_TEMP )*/
        _45emit_opcode(207);

        /** emit.e:1836			emit_addr( Pop() )*/
        _27360 = _45Pop();
        _45emit_addr(_27360);
        _27360 = NOVALUE;
        goto LC; // [7701] 7739

        /** emit.e:1838		case DEREF_TEMP then*/
        case 208:

        /** emit.e:1839			emit_opcode( DEREF_TEMP )*/
        _45emit_opcode(208);

        /** emit.e:1840			emit_addr( Pop() )*/
        _27361 = _45Pop();
        _45emit_addr(_27361);
        _27361 = NOVALUE;
        goto LC; // [7722] 7739

        /** emit.e:1842		case else*/
        default:

        /** emit.e:1843			InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_52351;
        _27362 = MAKE_SEQ(_1);
        _49InternalErr(259, _27362);
        _27362 = NOVALUE;
    ;}LC: 

    /** emit.e:1847		previous_op = op*/
    _27previous_op_20670 = _op_52351;

    /** emit.e:1848		inlined = 0*/
    _45inlined_52329 = 0;

    /** emit.e:1850	end procedure*/
    DeRef(_obj_52365);
    DeRef(_elements_52366);
    DeRef(_element_vals_52367);
    DeRef(_26913);
    _26913 = NOVALUE;
    DeRef(_27011);
    _27011 = NOVALUE;
    DeRef(_26988);
    _26988 = NOVALUE;
    DeRef(_27319);
    _27319 = NOVALUE;
    DeRef(_26775);
    _26775 = NOVALUE;
    DeRef(_27057);
    _27057 = NOVALUE;
    DeRef(_26848);
    _26848 = NOVALUE;
    _26797 = NOVALUE;
    DeRef(_26777);
    _26777 = NOVALUE;
    DeRef(_26981);
    _26981 = NOVALUE;
    DeRef(_26862);
    _26862 = NOVALUE;
    DeRef(_27179);
    _27179 = NOVALUE;
    _26850 = NOVALUE;
    DeRef(_27064);
    _27064 = NOVALUE;
    DeRef(_26947);
    _26947 = NOVALUE;
    DeRef(_27261);
    _27261 = NOVALUE;
    DeRef(_26963);
    _26963 = NOVALUE;
    DeRef(_27040);
    _27040 = NOVALUE;
    DeRef(_27221);
    _27221 = NOVALUE;
    DeRef(_26959);
    _26959 = NOVALUE;
    DeRef(_26824);
    _26824 = NOVALUE;
    DeRef(_27191);
    _27191 = NOVALUE;
    DeRef(_27273);
    _27273 = NOVALUE;
    _27104 = NOVALUE;
    DeRef(_27315);
    _27315 = NOVALUE;
    DeRef(_27044);
    _27044 = NOVALUE;
    DeRef(_27253);
    _27253 = NOVALUE;
    _26896 = NOVALUE;
    DeRef(_26814);
    _26814 = NOVALUE;
    DeRef(_27167);
    _27167 = NOVALUE;
    DeRef(_26809);
    _26809 = NOVALUE;
    DeRef(_26773);
    _26773 = NOVALUE;
    DeRef(_26990);
    _26990 = NOVALUE;
    DeRef(_27145);
    _27145 = NOVALUE;
    DeRef(_26833);
    _26833 = NOVALUE;
    DeRef(_27035);
    _27035 = NOVALUE;
    DeRef(_27016);
    _27016 = NOVALUE;
    DeRef(_27022);
    _27022 = NOVALUE;
    DeRef(_27172);
    _27172 = NOVALUE;
    _27330 = NOVALUE;
    DeRef(_26829);
    _26829 = NOVALUE;
    DeRef(_27107);
    _27107 = NOVALUE;
    DeRef(_27091);
    _27091 = NOVALUE;
    DeRef(_27235);
    _27235 = NOVALUE;
    DeRef(_27061);
    _27061 = NOVALUE;
    DeRef(_27249);
    _27249 = NOVALUE;
    DeRef(_26881);
    _26881 = NOVALUE;
    DeRef(_27276);
    _27276 = NOVALUE;
    DeRef(_27265);
    _27265 = NOVALUE;
    DeRef(_27245);
    _27245 = NOVALUE;
    DeRef(_27095);
    _27095 = NOVALUE;
    DeRef(_26827);
    _26827 = NOVALUE;
    DeRef(_27085);
    _27085 = NOVALUE;
    DeRef(_26852);
    _26852 = NOVALUE;
    DeRef(_27099);
    _27099 = NOVALUE;
    DeRef(_27033);
    _27033 = NOVALUE;
    DeRef(_27026);
    _27026 = NOVALUE;
    DeRef(_27007);
    _27007 = NOVALUE;
    DeRef(_26985);
    _26985 = NOVALUE;
    DeRef(_26953);
    _26953 = NOVALUE;
    DeRef(_27198);
    _27198 = NOVALUE;
    DeRef(_27067);
    _27067 = NOVALUE;
    DeRef(_27208);
    _27208 = NOVALUE;
    _26891 = NOVALUE;
    DeRef(_26994);
    _26994 = NOVALUE;
    _27102 = NOVALUE;
    DeRef(_27257);
    _27257 = NOVALUE;
    DeRef(_27087);
    _27087 = NOVALUE;
    DeRef(_27020);
    _27020 = NOVALUE;
    _26867 = NOVALUE;
    _26865 = NOVALUE;
    DeRef(_26817);
    _26817 = NOVALUE;
    DeRef(_27046);
    _27046 = NOVALUE;
    DeRef(_26779);
    _26779 = NOVALUE;
    DeRef(_27269);
    _27269 = NOVALUE;
    DeRef(_26969);
    _26969 = NOVALUE;
    DeRef(_27069);
    _27069 = NOVALUE;
    DeRef(_26887);
    _26887 = NOVALUE;
    DeRef(_27186);
    _27186 = NOVALUE;
    DeRef(_27237);
    _27237 = NOVALUE;
    DeRef(_26894);
    _26894 = NOVALUE;
    DeRef(_26926);
    _26926 = NOVALUE;
    DeRef(_26967);
    _26967 = NOVALUE;
    DeRef(_26873);
    _26873 = NOVALUE;
    DeRef(_26781);
    _26781 = NOVALUE;
    DeRef(_27204);
    _27204 = NOVALUE;
    DeRef(_27327);
    _27327 = NOVALUE;
    return;
    ;
}


void _45emit_assign_op(object _op_53830)
{
    object _0, _1, _2;
    

    /** emit.e:1854		if op = PLUS_EQUALS then*/
    if (_op_53830 != 515)
    goto L1; // [7] 21

    /** emit.e:1855			emit_op(PLUS)*/
    _45emit_op(11);
    goto L2; // [18] 86
L1: 

    /** emit.e:1856		elsif op = MINUS_EQUALS then*/
    if (_op_53830 != 516)
    goto L3; // [25] 39

    /** emit.e:1857			emit_op(MINUS)*/
    _45emit_op(10);
    goto L2; // [36] 86
L3: 

    /** emit.e:1858		elsif op = MULTIPLY_EQUALS then*/
    if (_op_53830 != 517)
    goto L4; // [43] 55

    /** emit.e:1859			emit_op(rw:MULTIPLY)*/
    _45emit_op(13);
    goto L2; // [52] 86
L4: 

    /** emit.e:1860		elsif op = DIVIDE_EQUALS then*/
    if (_op_53830 != 518)
    goto L5; // [59] 71

    /** emit.e:1861			emit_op(rw:DIVIDE)*/
    _45emit_op(14);
    goto L2; // [68] 86
L5: 

    /** emit.e:1862		elsif op = CONCAT_EQUALS then*/
    if (_op_53830 != 519)
    goto L6; // [75] 85

    /** emit.e:1863			emit_op(rw:CONCAT)*/
    _45emit_op(15);
L6: 
L2: 

    /** emit.e:1865	end procedure*/
    return;
    ;
}


void _45StartSourceLine(object _sl_53850, object _dup_ok_53851, object _emit_coverage_53852)
{
    object _line_span_53855 = NOVALUE;
    object _27384 = NOVALUE;
    object _27382 = NOVALUE;
    object _27381 = NOVALUE;
    object _27380 = NOVALUE;
    object _27379 = NOVALUE;
    object _27378 = NOVALUE;
    object _27376 = NOVALUE;
    object _27373 = NOVALUE;
    object _27371 = NOVALUE;
    object _27370 = NOVALUE;
    object _27369 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1873		if gline_number = LastLineNumber then*/
    if (_27gline_number_20576 != _61LastLineNumber_25929)
    goto L1; // [13] 66

    /** emit.e:1874			if length(LineTable) then*/
    if (IS_SEQUENCE(_27LineTable_20661)){
            _27369 = SEQ_PTR(_27LineTable_20661)->length;
    }
    else {
        _27369 = 1;
    }
    if (_27369 == 0)
    {
        _27369 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27369 = NOVALUE;
    }

    /** emit.e:1875				if dup_ok then*/
    if (_dup_ok_53851 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** emit.e:1876					emit_op( STARTLINE )*/
    _45emit_op(58);

    /** emit.e:1877					emit_addr( gline_number )*/
    _45emit_addr(_27gline_number_20576);
L3: 

    /** emit.e:1879				return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** emit.e:1882				sl = FALSE -- top-level new statement to execute on same line*/
    _sl_53850 = _9FALSE_439;
L4: 
L1: 

    /** emit.e:1885		LastLineNumber = gline_number*/
    _61LastLineNumber_25929 = _27gline_number_20576;

    /** emit.e:1888		line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27370 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_27370);
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249)){
        _27371 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    }
    else{
        _27371 = (object)*(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    }
    _27370 = NOVALUE;
    if (IS_ATOM_INT(_27371)) {
        _line_span_53855 = _27gline_number_20576 - _27371;
    }
    else {
        _line_span_53855 = binary_op(MINUS, _27gline_number_20576, _27371);
    }
    _27371 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_53855)) {
        _1 = (object)(DBL_PTR(_line_span_53855)->dbl);
        DeRefDS(_line_span_53855);
        _line_span_53855 = _1;
    }

    /** emit.e:1889		while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_27LineTable_20661)){
            _27373 = SEQ_PTR(_27LineTable_20661)->length;
    }
    else {
        _27373 = 1;
    }
    if (_27373 >= _line_span_53855)
    goto L6; // [109] 128

    /** emit.e:1890			LineTable = append(LineTable, -1) -- filler*/
    Append(&_27LineTable_20661, _27LineTable_20661, -1);

    /** emit.e:1891		end while*/
    goto L5; // [125] 104
L6: 

    /** emit.e:1892		LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_27Code_20660)){
            _27376 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _27376 = 1;
    }
    Append(&_27LineTable_20661, _27LineTable_20661, _27376);
    _27376 = NOVALUE;

    /** emit.e:1894		if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_53850 == 0) {
        goto L7; // [145] 190
    }
    if (_27TRANSLATE_20179 != 0) {
        DeRef(_27379);
        _27379 = 1;
        goto L8; // [151] 171
    }
    if (_27OpTrace_20641 != 0) {
        _27380 = 1;
        goto L9; // [157] 167
    }
    _27380 = (_27OpProfileStatement_20643 != 0);
L9: 
    DeRef(_27379);
    _27379 = (_27380 != 0);
L8: 
    if (_27379 == 0)
    {
        _27379 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27379 = NOVALUE;
    }

    /** emit.e:1896			emit_op(STARTLINE)*/
    _45emit_op(58);

    /** emit.e:1897			emit_addr(gline_number)*/
    _45emit_addr(_27gline_number_20576);
L7: 

    /** emit.e:1901		if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_53850 == 0) {
        _27381 = 0;
        goto LA; // [192] 206
    }
    _27382 = (_emit_coverage_53852 == 2);
    _27381 = (_27382 != 0);
LA: 
    if (_27381 != 0) {
        goto LB; // [206] 221
    }
    _27384 = (_emit_coverage_53852 == 3);
    if (_27384 == 0)
    {
        DeRef(_27384);
        _27384 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27384);
        _27384 = NOVALUE;
    }
LB: 

    /** emit.e:1902			include_line( gline_number )*/
    _50include_line(_27gline_number_20576);
LC: 

    /** emit.e:1905	end procedure*/
    DeRef(_27382);
    _27382 = NOVALUE;
    return;
    ;
}


object _45has_forward_params(object _sym_53909)
{
    object _27390 = NOVALUE;
    object _27389 = NOVALUE;
    object _27388 = NOVALUE;
    object _27387 = NOVALUE;
    object _27386 = NOVALUE;
    object _27385 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1908		for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _27385 = (object)*(((s1_ptr)_2)->base + _sym_53909);
    _2 = (object)SEQ_PTR(_27385);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _27386 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _27386 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _27385 = NOVALUE;
    if (IS_ATOM_INT(_27386)) {
        _27387 = _27386 - 1;
        if ((object)((uintptr_t)_27387 +(uintptr_t) HIGH_BITS) >= 0){
            _27387 = NewDouble((eudouble)_27387);
        }
    }
    else {
        _27387 = binary_op(MINUS, _27386, 1);
    }
    _27386 = NOVALUE;
    if (IS_ATOM_INT(_27387)) {
        _27388 = _45cgi_51429 - _27387;
        if ((object)((uintptr_t)_27388 +(uintptr_t) HIGH_BITS) >= 0){
            _27388 = NewDouble((eudouble)_27388);
        }
    }
    else {
        _27388 = binary_op(MINUS, _45cgi_51429, _27387);
    }
    DeRef(_27387);
    _27387 = NOVALUE;
    _27389 = _45cgi_51429;
    {
        object _i_53911;
        Ref(_27388);
        _i_53911 = _27388;
L1: 
        if (binary_op_a(GREATER, _i_53911, _27389)){
            goto L2; // [32] 65
        }

        /** emit.e:1909			if cg_stack[i] < 0 then*/
        _2 = (object)SEQ_PTR(_45cg_stack_51428);
        if (!IS_ATOM_INT(_i_53911)){
            _27390 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_53911)->dbl));
        }
        else{
            _27390 = (object)*(((s1_ptr)_2)->base + _i_53911);
        }
        if (binary_op_a(GREATEREQ, _27390, 0)){
            _27390 = NOVALUE;
            goto L3; // [47] 58
        }
        _27390 = NOVALUE;

        /** emit.e:1910				return 1*/
        DeRef(_i_53911);
        DeRef(_27388);
        _27388 = NOVALUE;
        return 1;
L3: 

        /** emit.e:1912		end for*/
        _0 = _i_53911;
        if (IS_ATOM_INT(_i_53911)) {
            _i_53911 = _i_53911 + 1;
            if ((object)((uintptr_t)_i_53911 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53911 = NewDouble((eudouble)_i_53911);
            }
        }
        else {
            _i_53911 = binary_op_a(PLUS, _i_53911, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_53911);
    }

    /** emit.e:1913		return 0*/
    DeRef(_27388);
    _27388 = NOVALUE;
    return 0;
    ;
}



// 0x76C0A0D5
