// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _21abs(object _a_5261)
{
    object _t_5262 = NOVALUE;
    object _2691 = NOVALUE;
    object _2690 = NOVALUE;
    object _2689 = NOVALUE;
    object _2687 = NOVALUE;
    object _2685 = NOVALUE;
    object _2684 = NOVALUE;
    object _2682 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:58		if atom(a) then*/
    _2682 = IS_ATOM(_a_5261);
    if (_2682 == 0)
    {
        _2682 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _2682 = NOVALUE;
    }

    /** math.e:59			if a >= 0 then*/
    if (binary_op_a(LESS, _a_5261, 0)){
        goto L2; // [11] 24
    }

    /** math.e:60				return a*/
    DeRef(_t_5262);
    return _a_5261;
    goto L3; // [21] 34
L2: 

    /** math.e:62				return - a*/
    if (IS_ATOM_INT(_a_5261)) {
        if ((uintptr_t)_a_5261 == (uintptr_t)HIGH_BITS){
            _2684 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _2684 = - _a_5261;
        }
    }
    else {
        _2684 = unary_op(UMINUS, _a_5261);
    }
    DeRef(_a_5261);
    DeRef(_t_5262);
    return _2684;
L3: 
L1: 

    /** math.e:65		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5261)){
            _2685 = SEQ_PTR(_a_5261)->length;
    }
    else {
        _2685 = 1;
    }
    {
        object _i_5270;
        _i_5270 = 1;
L4: 
        if (_i_5270 > _2685){
            goto L5; // [40] 101
        }

        /** math.e:66			t = a[i]*/
        DeRef(_t_5262);
        _2 = (object)SEQ_PTR(_a_5261);
        _t_5262 = (object)*(((s1_ptr)_2)->base + _i_5270);
        Ref(_t_5262);

        /** math.e:67			if atom(t) then*/
        _2687 = IS_ATOM(_t_5262);
        if (_2687 == 0)
        {
            _2687 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _2687 = NOVALUE;
        }

        /** math.e:68				if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_5262, 0)){
            goto L7; // [63] 94
        }

        /** math.e:69					a[i] = - t*/
        if (IS_ATOM_INT(_t_5262)) {
            if ((uintptr_t)_t_5262 == (uintptr_t)HIGH_BITS){
                _2689 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _2689 = - _t_5262;
            }
        }
        else {
            _2689 = unary_op(UMINUS, _t_5262);
        }
        _2 = (object)SEQ_PTR(_a_5261);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_5261 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_5270);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2689;
        if( _1 != _2689 ){
            DeRef(_1);
        }
        _2689 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** math.e:72				a[i] = abs(t)*/
        Ref(_t_5262);
        DeRef(_2690);
        _2690 = _t_5262;
        _2691 = _21abs(_2690);
        _2690 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_5261);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_5261 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_5270);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _2691;
        if( _1 != _2691 ){
            DeRef(_1);
        }
        _2691 = NOVALUE;
L7: 

        /** math.e:74		end for*/
        _i_5270 = _i_5270 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** math.e:75		return a*/
    DeRef(_t_5262);
    DeRef(_2684);
    _2684 = NOVALUE;
    return _a_5261;
    ;
}


object _21max(object _a_5305)
{
    object _b_5306 = NOVALUE;
    object _c_5307 = NOVALUE;
    object _2701 = NOVALUE;
    object _2700 = NOVALUE;
    object _2699 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:199		if atom(a) then*/
    _2699 = IS_ATOM(_a_5305);
    if (_2699 == 0)
    {
        _2699 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2699 = NOVALUE;
    }

    /** math.e:200			return a*/
    DeRef(_b_5306);
    DeRef(_c_5307);
    return _a_5305;
L1: 

    /** math.e:202		b = mathcons:MINF*/
    Ref(_23MINF_5239);
    DeRef(_b_5306);
    _b_5306 = _23MINF_5239;

    /** math.e:203		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5305)){
            _2700 = SEQ_PTR(_a_5305)->length;
    }
    else {
        _2700 = 1;
    }
    {
        object _i_5311;
        _i_5311 = 1;
L2: 
        if (_i_5311 > _2700){
            goto L3; // [28] 64
        }

        /** math.e:204			c = max(a[i])*/
        _2 = (object)SEQ_PTR(_a_5305);
        _2701 = (object)*(((s1_ptr)_2)->base + _i_5311);
        Ref(_2701);
        _0 = _c_5307;
        _c_5307 = _21max(_2701);
        DeRef(_0);
        _2701 = NOVALUE;

        /** math.e:205			if c > b then*/
        if (binary_op_a(LESSEQ, _c_5307, _b_5306)){
            goto L4; // [47] 57
        }

        /** math.e:206				b = c*/
        Ref(_c_5307);
        DeRef(_b_5306);
        _b_5306 = _c_5307;
L4: 

        /** math.e:208		end for*/
        _i_5311 = _i_5311 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:209		return b*/
    DeRef(_a_5305);
    DeRef(_c_5307);
    return _b_5306;
    ;
}


object _21min(object _a_5319)
{
    object _b_5320 = NOVALUE;
    object _c_5321 = NOVALUE;
    object _2706 = NOVALUE;
    object _2705 = NOVALUE;
    object _2704 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:232		if atom(a) then*/
    _2704 = IS_ATOM(_a_5319);
    if (_2704 == 0)
    {
        _2704 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2704 = NOVALUE;
    }

    /** math.e:233				return a*/
    DeRef(_b_5320);
    DeRef(_c_5321);
    return _a_5319;
L1: 

    /** math.e:235		b = mathcons:PINF*/
    Ref(_23PINF_5237);
    DeRef(_b_5320);
    _b_5320 = _23PINF_5237;

    /** math.e:236		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5319)){
            _2705 = SEQ_PTR(_a_5319)->length;
    }
    else {
        _2705 = 1;
    }
    {
        object _i_5325;
        _i_5325 = 1;
L2: 
        if (_i_5325 > _2705){
            goto L3; // [28] 64
        }

        /** math.e:237			c = min(a[i])*/
        _2 = (object)SEQ_PTR(_a_5319);
        _2706 = (object)*(((s1_ptr)_2)->base + _i_5325);
        Ref(_2706);
        _0 = _c_5321;
        _c_5321 = _21min(_2706);
        DeRef(_0);
        _2706 = NOVALUE;

        /** math.e:238				if c < b then*/
        if (binary_op_a(GREATEREQ, _c_5321, _b_5320)){
            goto L4; // [47] 57
        }

        /** math.e:239					b = c*/
        Ref(_c_5321);
        DeRef(_b_5320);
        _b_5320 = _c_5321;
L4: 

        /** math.e:241		end for*/
        _i_5325 = _i_5325 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:242		return b*/
    DeRef(_a_5319);
    DeRef(_c_5321);
    return _b_5320;
    ;
}


object _21or_all(object _a_5698)
{
    object _b_5699 = NOVALUE;
    object _2905 = NOVALUE;
    object _2904 = NOVALUE;
    object _2902 = NOVALUE;
    object _2901 = NOVALUE;
    object _2900 = NOVALUE;
    object _2899 = NOVALUE;
    object _2898 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:1469		if atom(a) then*/
    _2898 = IS_ATOM(_a_5698);
    if (_2898 == 0)
    {
        _2898 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _2898 = NOVALUE;
    }

    /** math.e:1470			return a*/
    DeRef(_b_5699);
    return _a_5698;
L1: 

    /** math.e:1472		b = 0*/
    DeRef(_b_5699);
    _b_5699 = 0;

    /** math.e:1473		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5698)){
            _2899 = SEQ_PTR(_a_5698)->length;
    }
    else {
        _2899 = 1;
    }
    {
        object _i_5703;
        _i_5703 = 1;
L2: 
        if (_i_5703 > _2899){
            goto L3; // [26] 80
        }

        /** math.e:1474			if atom(a[i]) then*/
        _2 = (object)SEQ_PTR(_a_5698);
        _2900 = (object)*(((s1_ptr)_2)->base + _i_5703);
        _2901 = IS_ATOM(_2900);
        _2900 = NOVALUE;
        if (_2901 == 0)
        {
            _2901 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _2901 = NOVALUE;
        }

        /** math.e:1475				b = or_bits(b, a[i])*/
        _2 = (object)SEQ_PTR(_a_5698);
        _2902 = (object)*(((s1_ptr)_2)->base + _i_5703);
        _0 = _b_5699;
        if (IS_ATOM_INT(_b_5699) && IS_ATOM_INT(_2902)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_5699 | (uintptr_t)_2902;
                 _b_5699 = MAKE_UINT(tu);
            }
        }
        else {
            _b_5699 = binary_op(OR_BITS, _b_5699, _2902);
        }
        DeRef(_0);
        _2902 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** math.e:1477				b = or_bits(b, or_all(a[i]))*/
        _2 = (object)SEQ_PTR(_a_5698);
        _2904 = (object)*(((s1_ptr)_2)->base + _i_5703);
        Ref(_2904);
        _2905 = _21or_all(_2904);
        _2904 = NOVALUE;
        _0 = _b_5699;
        if (IS_ATOM_INT(_b_5699) && IS_ATOM_INT(_2905)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_5699 | (uintptr_t)_2905;
                 _b_5699 = MAKE_UINT(tu);
            }
        }
        else {
            _b_5699 = binary_op(OR_BITS, _b_5699, _2905);
        }
        DeRef(_0);
        DeRef(_2905);
        _2905 = NOVALUE;
L5: 

        /** math.e:1479		end for*/
        _i_5703 = _i_5703 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** math.e:1480		return b*/
    DeRef(_a_5698);
    return _b_5699;
    ;
}



// 0x4652AA7E
