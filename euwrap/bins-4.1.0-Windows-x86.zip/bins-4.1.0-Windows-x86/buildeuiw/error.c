// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _5warning_file(object _file_path_260)
{
    object _0, _1, _2;
    

    /** error.e:167		machine_proc(M_WARNING_FILE, file_path)*/
    machine(72, _file_path_260);

    /** error.e:168	end procedure*/
    DeRef(_file_path_260);
    return;
    ;
}



// 0xFB3C1B10
