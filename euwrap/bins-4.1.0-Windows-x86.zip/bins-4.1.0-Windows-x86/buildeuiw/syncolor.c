// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _71set_colors(object _pColorList_72344)
{
    object _lColorName_72345 = NOVALUE;
    object _36084 = NOVALUE;
    object _36081 = NOVALUE;
    object _36078 = NOVALUE;
    object _36075 = NOVALUE;
    object _36072 = NOVALUE;
    object _36069 = NOVALUE;
    object _36066 = NOVALUE;
    object _36061 = NOVALUE;
    object _36060 = NOVALUE;
    object _36059 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:48		for i = 1 to length(pColorList) do*/
    _36059 = 6;
    {
        object _i_72347;
        _i_72347 = 1;
L1: 
        if (_i_72347 > 6){
            goto L2; // [8] 168
        }

        /** syncolor.e:49			lColorName = text:upper(pColorList[i][1])*/
        _2 = (object)SEQ_PTR(_pColorList_72344);
        _36060 = (object)*(((s1_ptr)_2)->base + _i_72347);
        _2 = (object)SEQ_PTR(_36060);
        _36061 = (object)*(((s1_ptr)_2)->base + 1);
        _36060 = NOVALUE;
        Ref(_36061);
        _0 = _lColorName_72345;
        _lColorName_72345 = _12upper(_36061);
        DeRef(_0);
        _36061 = NOVALUE;

        /** syncolor.e:50			switch lColorName do*/
        _1 = find(_lColorName_72345, _36063);
        switch ( _1 ){ 

            /** syncolor.e:51				case "NORMAL" then*/
            case 1:

            /** syncolor.e:52					NORMAL_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72344);
            _36066 = (object)*(((s1_ptr)_2)->base + _i_72347);
            _2 = (object)SEQ_PTR(_36066);
            _71NORMAL_COLOR_72333 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71NORMAL_COLOR_72333)){
                _71NORMAL_COLOR_72333 = (object)DBL_PTR(_71NORMAL_COLOR_72333)->dbl;
            }
            _36066 = NOVALUE;
            goto L3; // [54] 161

            /** syncolor.e:53				case "COMMENT" then*/
            case 2:

            /** syncolor.e:54					COMMENT_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72344);
            _36069 = (object)*(((s1_ptr)_2)->base + _i_72347);
            _2 = (object)SEQ_PTR(_36069);
            _71COMMENT_COLOR_72334 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71COMMENT_COLOR_72334)){
                _71COMMENT_COLOR_72334 = (object)DBL_PTR(_71COMMENT_COLOR_72334)->dbl;
            }
            _36069 = NOVALUE;
            goto L3; // [72] 161

            /** syncolor.e:55				case "KEYWORD" then*/
            case 3:

            /** syncolor.e:56					KEYWORD_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72344);
            _36072 = (object)*(((s1_ptr)_2)->base + _i_72347);
            _2 = (object)SEQ_PTR(_36072);
            _71KEYWORD_COLOR_72335 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71KEYWORD_COLOR_72335)){
                _71KEYWORD_COLOR_72335 = (object)DBL_PTR(_71KEYWORD_COLOR_72335)->dbl;
            }
            _36072 = NOVALUE;
            goto L3; // [90] 161

            /** syncolor.e:57				case "BUILTIN" then*/
            case 4:

            /** syncolor.e:58					BUILTIN_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72344);
            _36075 = (object)*(((s1_ptr)_2)->base + _i_72347);
            _2 = (object)SEQ_PTR(_36075);
            _71BUILTIN_COLOR_72336 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71BUILTIN_COLOR_72336)){
                _71BUILTIN_COLOR_72336 = (object)DBL_PTR(_71BUILTIN_COLOR_72336)->dbl;
            }
            _36075 = NOVALUE;
            goto L3; // [108] 161

            /** syncolor.e:59				case "STRING" then*/
            case 5:

            /** syncolor.e:60					STRING_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72344);
            _36078 = (object)*(((s1_ptr)_2)->base + _i_72347);
            _2 = (object)SEQ_PTR(_36078);
            _71STRING_COLOR_72337 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_71STRING_COLOR_72337)){
                _71STRING_COLOR_72337 = (object)DBL_PTR(_71STRING_COLOR_72337)->dbl;
            }
            _36078 = NOVALUE;
            goto L3; // [126] 161

            /** syncolor.e:61				case "BRACKET" then*/
            case 6:

            /** syncolor.e:62					BRACKET_COLOR  = pColorList[i][2]*/
            _2 = (object)SEQ_PTR(_pColorList_72344);
            _36081 = (object)*(((s1_ptr)_2)->base + _i_72347);
            DeRef(_71BRACKET_COLOR_72338);
            _2 = (object)SEQ_PTR(_36081);
            _71BRACKET_COLOR_72338 = (object)*(((s1_ptr)_2)->base + 2);
            Ref(_71BRACKET_COLOR_72338);
            _36081 = NOVALUE;
            goto L3; // [144] 161

            /** syncolor.e:63				case else*/
            case 0:

            /** syncolor.e:64					printf(2, "syncolor.e: Unknown color name '%s', ignored.\n", {lColorName})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_lColorName_72345);
            ((intptr_t*)_2)[1] = _lColorName_72345;
            _36084 = MAKE_SEQ(_1);
            EPrintf(2, _36083, _36084);
            DeRefDS(_36084);
            _36084 = NOVALUE;
        ;}L3: 

        /** syncolor.e:66		end for*/
        _i_72347 = _i_72347 + 1;
        goto L1; // [163] 15
L2: 
        ;
    }

    /** syncolor.e:67	end procedure*/
    DeRefDS(_pColorList_72344);
    DeRef(_lColorName_72345);
    return;
    ;
}


void _71init_class()
{
    object _0, _1, _2;
    

    /** syncolor.e:71		NORMAL_COLOR  = #330033*/
    _71NORMAL_COLOR_72333 = 3342387;

    /** syncolor.e:72		COMMENT_COLOR = #FF0055*/
    _71COMMENT_COLOR_72334 = 16711765;

    /** syncolor.e:73		KEYWORD_COLOR = #0000FF*/
    _71KEYWORD_COLOR_72335 = 255;

    /** syncolor.e:74		BUILTIN_COLOR = #FF00FF*/
    _71BUILTIN_COLOR_72336 = 16711935;

    /** syncolor.e:75		STRING_COLOR  = #00A033*/
    _71STRING_COLOR_72337 = 41011;

    /** syncolor.e:76		BRACKET_COLOR = {NORMAL_COLOR, #993333, #0000FF, #5500FF, #00FF00}*/
    _0 = _71BRACKET_COLOR_72338;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 3342387;
    ((intptr_t*)_2)[2] = 10040115;
    ((intptr_t*)_2)[3] = 255;
    ((intptr_t*)_2)[4] = 5570815;
    ((intptr_t*)_2)[5] = 65280;
    _71BRACKET_COLOR_72338 = MAKE_SEQ(_1);
    DeRef(_0);

    /** syncolor.e:78	end procedure*/
    return;
    ;
}


object _71default_state(object _token_72411)
{
    object _36102 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:103		if not token then*/
    if (IS_ATOM_INT(_token_72411)) {
        if (_token_72411 != 0){
            goto L1; // [3] 12
        }
    }
    else {
        if (DBL_PTR(_token_72411)->dbl != 0.0){
            goto L1; // [3] 12
        }
    }

    /** syncolor.e:104			token = tokenize:new()*/
    _0 = _token_72411;
    _token_72411 = _72new();
    DeRef(_0);
L1: 

    /** syncolor.e:106		return {*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_token_72411);
    ((intptr_t*)_2)[1] = _token_72411;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    _36102 = MAKE_SEQ(_1);
    DeRef(_token_72411);
    return _36102;
    ;
}


object _71new()
{
    object _state_72421 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:124		atom state = eumem:malloc()*/
    _0 = _state_72421;
    _state_72421 = _35malloc(1, 1);
    DeRef(_0);

    /** syncolor.e:126		reset(state)*/
    Ref(_state_72421);
    _71reset(_state_72421);

    /** syncolor.e:128		return state*/
    return _state_72421;
    ;
}


void _71tokenize_reset(object _token_72426)
{
    object _reset_1__tmp_at7_72429 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:138		if token then*/
    if (_token_72426 == 0) {
        goto L1; // [3] 27
    }
    else {
        if (!IS_ATOM_INT(_token_72426) && DBL_PTR(_token_72426)->dbl == 0.0){
            goto L1; // [3] 27
        }
    }

    /** syncolor.e:139			tokenize:reset(token)*/

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _0 = _reset_1__tmp_at7_72429;
    _reset_1__tmp_at7_72429 = _72default_state();
    DeRef(_0);
    Ref(_reset_1__tmp_at7_72429);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_token_72426))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_token_72426)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _token_72426);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _reset_1__tmp_at7_72429;
    DeRef(_1);

    /** tokenize.e:216	end procedure*/
    goto L2; // [21] 24
L2: 
    DeRef(_reset_1__tmp_at7_72429);
    _reset_1__tmp_at7_72429 = NOVALUE;
L1: 

    /** syncolor.e:141	end procedure*/
    DeRef(_token_72426);
    return;
    ;
}


void _71reset(object _state_72432)
{
    object _token_72433 = NOVALUE;
    object _36109 = NOVALUE;
    object _36108 = NOVALUE;
    object _36106 = NOVALUE;
    object _0, _1, _2;
    

    /** syncolor.e:144		atom token = eumem:ram_space[state][S_TOKENIZER]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_state_72432)){
        _36106 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72432)->dbl));
    }
    else{
        _36106 = (object)*(((s1_ptr)_2)->base + _state_72432);
    }
    DeRef(_token_72433);
    _2 = (object)SEQ_PTR(_36106);
    _token_72433 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_token_72433);
    _36106 = NOVALUE;

    /** syncolor.e:145		tokenize_reset(token)*/
    Ref(_token_72433);
    _71tokenize_reset(_token_72433);

    /** syncolor.e:146		eumem:ram_space[state] = default_state(token)*/
    Ref(_token_72433);
    _36108 = _71default_state(_token_72433);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_72432))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72432)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_72432);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36108;
    if( _1 != _36108 ){
        DeRef(_1);
    }
    _36108 = NOVALUE;

    /** syncolor.e:147		eumem:ram_space[state] = default_state()*/
    _36109 = _71default_state(0);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_72432))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_72432)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_72432);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36109;
    if( _1 != _36109 ){
        DeRef(_1);
    }
    _36109 = NOVALUE;

    /** syncolor.e:148	end procedure*/
    DeRef(_state_72432);
    DeRef(_token_72433);
    return;
    ;
}



// 0xFAD9B309
