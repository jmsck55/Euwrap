// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _31get_text(object _MsgNum_18753, object _LocalQuals_18754, object _DBBase_18755)
{
    object _db_res_18757 = NOVALUE;
    object _lMsgText_18758 = NOVALUE;
    object _dbname_18759 = NOVALUE;
    object _10469 = NOVALUE;
    object _10467 = NOVALUE;
    object _10465 = NOVALUE;
    object _10464 = NOVALUE;
    object _10463 = NOVALUE;
    object _10461 = NOVALUE;
    object _10460 = NOVALUE;
    object _10459 = NOVALUE;
    object _10453 = NOVALUE;
    object _10452 = NOVALUE;
    object _10451 = NOVALUE;
    object _10444 = NOVALUE;
    object _10441 = NOVALUE;
    object _10439 = NOVALUE;
    object _10437 = NOVALUE;
    object _10436 = NOVALUE;
    object _10435 = NOVALUE;
    object _10434 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_18753)) {
        _1 = (object)(DBL_PTR(_MsgNum_18753)->dbl);
        DeRefDS(_MsgNum_18753);
        _MsgNum_18753 = _1;
    }

    /** locale.e:798		db_res = -1*/
    _db_res_18757 = -1;

    /** locale.e:799		lMsgText = 0*/
    DeRef(_lMsgText_18758);
    _lMsgText_18758 = 0;

    /** locale.e:801		if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_18754);
    _10434 = _9string(_LocalQuals_18754);
    if (IS_ATOM_INT(_10434)) {
        if (_10434 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_10434)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_18754)){
            _10436 = SEQ_PTR(_LocalQuals_18754)->length;
    }
    else {
        _10436 = 1;
    }
    _10437 = (_10436 > 0);
    _10436 = NOVALUE;
    if (_10437 == 0)
    {
        DeRef(_10437);
        _10437 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_10437);
        _10437 = NOVALUE;
    }

    /** locale.e:802			LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_18754;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_18754);
    ((intptr_t*)_2)[1] = _LocalQuals_18754;
    _LocalQuals_18754 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** locale.e:804		for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18754)){
            _10439 = SEQ_PTR(_LocalQuals_18754)->length;
    }
    else {
        _10439 = 1;
    }
    {
        object _i_18768;
        _i_18768 = 1;
L2: 
        if (_i_18768 > _10439){
            goto L3; // [50] 136
        }

        /** locale.e:805			dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (object)SEQ_PTR(_LocalQuals_18754);
        _10441 = (object)*(((s1_ptr)_2)->base + _i_18768);
        {
            object concat_list[4];

            concat_list[0] = _10442;
            concat_list[1] = _10441;
            concat_list[2] = _10440;
            concat_list[3] = _DBBase_18755;
            Concat_N((object_ptr)&_dbname_18759, concat_list, 4);
        }
        _10441 = NOVALUE;

        /** locale.e:806			db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_18759);
        RefDS(_5);
        RefDS(_5);
        _10444 = _15locate_file(_dbname_18759, _5, _5);
        _db_res_18757 = _41db_select(_10444, 3);
        _10444 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_18757)) {
            _1 = (object)(DBL_PTR(_db_res_18757)->dbl);
            DeRefDS(_db_res_18757);
            _db_res_18757 = _1;
        }

        /** locale.e:807			if db_res = eds:DB_OK then*/
        if (_db_res_18757 != 0)
        goto L4; // [87] 129

        /** locale.e:808				db_res = eds:db_select_table("1")*/
        RefDS(_10447);
        _db_res_18757 = _41db_select_table(_10447);
        if (!IS_ATOM_INT(_db_res_18757)) {
            _1 = (object)(DBL_PTR(_db_res_18757)->dbl);
            DeRefDS(_db_res_18757);
            _db_res_18757 = _1;
        }

        /** locale.e:809				if db_res = eds:DB_OK then*/
        if (_db_res_18757 != 0)
        goto L5; // [101] 128

        /** locale.e:810					lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_41current_table_name_16049);
        _0 = _lMsgText_18758;
        _lMsgText_18758 = _41db_fetch_record(_MsgNum_18753, _41current_table_name_16049);
        DeRef(_0);

        /** locale.e:811					if sequence(lMsgText) then*/
        _10451 = IS_SEQUENCE(_lMsgText_18758);
        if (_10451 == 0)
        {
            _10451 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _10451 = NOVALUE;
        }

        /** locale.e:812						exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** locale.e:816		end for*/
        _i_18768 = _i_18768 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** locale.e:819		if atom(lMsgText) then*/
    _10452 = IS_ATOM(_lMsgText_18758);
    if (_10452 == 0)
    {
        _10452 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _10452 = NOVALUE;
    }

    /** locale.e:820			dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_10453, _DBBase_18755, _10442);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_18759;
    _dbname_18759 = _15locate_file(_10453, _5, _5);
    DeRef(_0);
    _10453 = NOVALUE;

    /** locale.e:821			db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_18759);
    _db_res_18757 = _41db_select(_dbname_18759, 3);
    if (!IS_ATOM_INT(_db_res_18757)) {
        _1 = (object)(DBL_PTR(_db_res_18757)->dbl);
        DeRefDS(_db_res_18757);
        _db_res_18757 = _1;
    }

    /** locale.e:822			if db_res = eds:DB_OK then*/
    if (_db_res_18757 != 0)
    goto L8; // [171] 280

    /** locale.e:823				db_res = eds:db_select_table("1")*/
    RefDS(_10447);
    _db_res_18757 = _41db_select_table(_10447);
    if (!IS_ATOM_INT(_db_res_18757)) {
        _1 = (object)(DBL_PTR(_db_res_18757)->dbl);
        DeRefDS(_db_res_18757);
        _db_res_18757 = _1;
    }

    /** locale.e:824				if db_res = eds:DB_OK then*/
    if (_db_res_18757 != 0)
    goto L9; // [185] 279

    /** locale.e:825					for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_18754)){
            _10459 = SEQ_PTR(_LocalQuals_18754)->length;
    }
    else {
        _10459 = 1;
    }
    {
        object _i_18797;
        _i_18797 = 1;
LA: 
        if (_i_18797 > _10459){
            goto LB; // [194] 238
        }

        /** locale.e:826						lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (object)SEQ_PTR(_LocalQuals_18754);
        _10460 = (object)*(((s1_ptr)_2)->base + _i_18797);
        Ref(_10460);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _10460;
        ((intptr_t *)_2)[2] = _MsgNum_18753;
        _10461 = MAKE_SEQ(_1);
        _10460 = NOVALUE;
        RefDS(_41current_table_name_16049);
        _0 = _lMsgText_18758;
        _lMsgText_18758 = _41db_fetch_record(_10461, _41current_table_name_16049);
        DeRef(_0);
        _10461 = NOVALUE;

        /** locale.e:827						if sequence(lMsgText) then*/
        _10463 = IS_SEQUENCE(_lMsgText_18758);
        if (_10463 == 0)
        {
            _10463 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _10463 = NOVALUE;
        }

        /** locale.e:828							exit*/
        goto LB; // [228] 238
LC: 

        /** locale.e:830					end for*/
        _i_18797 = _i_18797 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** locale.e:831					if atom(lMsgText) then*/
    _10464 = IS_ATOM(_lMsgText_18758);
    if (_10464 == 0)
    {
        _10464 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _10464 = NOVALUE;
    }

    /** locale.e:832						lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5;
    ((intptr_t *)_2)[2] = _MsgNum_18753;
    _10465 = MAKE_SEQ(_1);
    RefDS(_41current_table_name_16049);
    _0 = _lMsgText_18758;
    _lMsgText_18758 = _41db_fetch_record(_10465, _41current_table_name_16049);
    DeRef(_0);
    _10465 = NOVALUE;
LD: 

    /** locale.e:834					if atom(lMsgText) then*/
    _10467 = IS_ATOM(_lMsgText_18758);
    if (_10467 == 0)
    {
        _10467 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _10467 = NOVALUE;
    }

    /** locale.e:835						lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_41current_table_name_16049);
    _0 = _lMsgText_18758;
    _lMsgText_18758 = _41db_fetch_record(_MsgNum_18753, _41current_table_name_16049);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** locale.e:840		if atom(lMsgText) then*/
    _10469 = IS_ATOM(_lMsgText_18758);
    if (_10469 == 0)
    {
        _10469 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _10469 = NOVALUE;
    }

    /** locale.e:841			return 0*/
    DeRefDS(_LocalQuals_18754);
    DeRefDS(_DBBase_18755);
    DeRef(_lMsgText_18758);
    DeRef(_dbname_18759);
    DeRef(_10434);
    _10434 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** locale.e:843			return lMsgText*/
    DeRefDS(_LocalQuals_18754);
    DeRefDS(_DBBase_18755);
    DeRef(_dbname_18759);
    DeRef(_10434);
    _10434 = NOVALUE;
    return _lMsgText_18758;
L10: 
    ;
}



// 0xCBF205E7
