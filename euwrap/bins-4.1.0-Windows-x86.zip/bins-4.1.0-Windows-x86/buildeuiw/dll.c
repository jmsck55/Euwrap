// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _4open_dll(object _file_name_1337)
{
    object _fh_1347 = NOVALUE;
    object _528 = NOVALUE;
    object _526 = NOVALUE;
    object _525 = NOVALUE;
    object _524 = NOVALUE;
    object _523 = NOVALUE;
    object _522 = NOVALUE;
    object _521 = NOVALUE;
    object _520 = NOVALUE;
    object _0, _1, _2;
    

    /** dll.e:182		if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_1337)){
            _520 = SEQ_PTR(_file_name_1337)->length;
    }
    else {
        _520 = 1;
    }
    _521 = (_520 > 0);
    _520 = NOVALUE;
    if (_521 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_1337);
    _523 = _9string(_file_name_1337);
    if (_523 == 0) {
        DeRef(_523);
        _523 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_523) && DBL_PTR(_523)->dbl == 0.0){
            DeRef(_523);
            _523 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_523);
        _523 = NOVALUE;
    }
    DeRef(_523);
    _523 = NOVALUE;

    /** dll.e:183			return machine_func(M_OPEN_DLL, file_name)*/
    _524 = machine(50, _file_name_1337);
    DeRefDS(_file_name_1337);
    DeRef(_521);
    _521 = NOVALUE;
    return _524;
L1: 

    /** dll.e:188		for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_1337)){
            _525 = SEQ_PTR(_file_name_1337)->length;
    }
    else {
        _525 = 1;
    }
    {
        object _idx_1345;
        _idx_1345 = 1;
L2: 
        if (_idx_1345 > _525){
            goto L3; // [40] 82
        }

        /** dll.e:189			atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (object)SEQ_PTR(_file_name_1337);
        _526 = (object)*(((s1_ptr)_2)->base + _idx_1345);
        DeRef(_fh_1347);
        _fh_1347 = machine(50, _526);
        _526 = NOVALUE;

        /** dll.e:190			if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_1347)) {
            _528 = (_fh_1347 == 0);
        }
        else {
            _528 = unary_op(NOT, _fh_1347);
        }
        if (_528 != 0)
        goto L4; // [62] 73

        /** dll.e:191				return fh*/
        DeRefDS(_file_name_1337);
        DeRef(_524);
        _524 = NOVALUE;
        _528 = NOVALUE;
        DeRef(_521);
        _521 = NOVALUE;
        return _fh_1347;
L4: 
        DeRef(_fh_1347);
        _fh_1347 = NOVALUE;

        /** dll.e:193		end for*/
        _idx_1345 = _idx_1345 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** dll.e:195		return 0*/
    DeRefDS(_file_name_1337);
    DeRef(_524);
    _524 = NOVALUE;
    DeRef(_528);
    _528 = NOVALUE;
    DeRef(_521);
    _521 = NOVALUE;
    return 0;
    ;
}


object _4define_c_proc(object _lib_1361, object _routine_name_1362, object _arg_types_1363)
{
    object _safe_address_inlined_safe_address_at_11_1368 = NOVALUE;
    object _msg_inlined_crash_at_26_1372 = NOVALUE;
    object _537 = NOVALUE;
    object _536 = NOVALUE;
    object _534 = NOVALUE;
    object _533 = NOVALUE;
    object _532 = NOVALUE;
    object _0, _1, _2;
    

    /** dll.e:298		if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _532 = 0;
    if (_532 == 0) {
        goto L1; // [8] 46
    }

    /** memory.e:118		return 1*/
    _safe_address_inlined_safe_address_at_11_1368 = 1;
    _534 = (1 == 0);
    if (_534 == 0)
    {
        DeRef(_534);
        _534 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_534);
        _534 = NOVALUE;
    }

    /** dll.e:299	        error:crash("A C function is being defined from Non-executable memory.")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_1372);
    _msg_inlined_crash_at_26_1372 = EPrintf(-9999999, _535, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_1372);

    /** error.e:53	end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_1372);
    _msg_inlined_crash_at_26_1372 = NOVALUE;
L1: 

    /** dll.e:301		return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, 0})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_lib_1361);
    ((intptr_t*)_2)[1] = _lib_1361;
    Ref(_routine_name_1362);
    ((intptr_t*)_2)[2] = _routine_name_1362;
    RefDS(_arg_types_1363);
    ((intptr_t*)_2)[3] = _arg_types_1363;
    ((intptr_t*)_2)[4] = 0;
    _536 = MAKE_SEQ(_1);
    _537 = machine(51, _536);
    DeRefDS(_536);
    _536 = NOVALUE;
    DeRef(_lib_1361);
    DeRefi(_routine_name_1362);
    DeRefDSi(_arg_types_1363);
    return _537;
    ;
}


object _4define_c_func(object _lib_1377, object _routine_name_1378, object _arg_types_1379, object _return_type_1380)
{
    object _safe_address_inlined_safe_address_at_11_1385 = NOVALUE;
    object _msg_inlined_crash_at_26_1388 = NOVALUE;
    object _542 = NOVALUE;
    object _541 = NOVALUE;
    object _540 = NOVALUE;
    object _539 = NOVALUE;
    object _538 = NOVALUE;
    object _0, _1, _2;
    

    /** dll.e:395		  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _538 = 0;
    if (_538 == 0) {
        goto L1; // [8] 46
    }

    /** memory.e:118		return 1*/
    _safe_address_inlined_safe_address_at_11_1385 = 1;
    _540 = (1 == 0);
    if (_540 == 0)
    {
        DeRef(_540);
        _540 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_540);
        _540 = NOVALUE;
    }

    /** dll.e:396		      error:crash("A C function is being defined from Non-executable memory.")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_1388);
    _msg_inlined_crash_at_26_1388 = EPrintf(-9999999, _535, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_1388);

    /** error.e:53	end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_1388);
    _msg_inlined_crash_at_26_1388 = NOVALUE;
L1: 

    /** dll.e:398		  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_lib_1377);
    ((intptr_t*)_2)[1] = _lib_1377;
    Ref(_routine_name_1378);
    ((intptr_t*)_2)[2] = _routine_name_1378;
    RefDS(_arg_types_1379);
    ((intptr_t*)_2)[3] = _arg_types_1379;
    ((intptr_t*)_2)[4] = _return_type_1380;
    _541 = MAKE_SEQ(_1);
    _542 = machine(51, _541);
    DeRefDS(_541);
    _541 = NOVALUE;
    DeRef(_lib_1377);
    DeRefi(_routine_name_1378);
    DeRefDSi(_arg_types_1379);
    return _542;
    ;
}



// 0x5AA0609E
