// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _62find_category(object _tokid_24374)
{
    object _catname_24375 = NOVALUE;
    object _13724 = NOVALUE;
    object _13723 = NOVALUE;
    object _13721 = NOVALUE;
    object _13720 = NOVALUE;
    object _13719 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24374)) {
        _1 = (object)(DBL_PTR(_tokid_24374)->dbl);
        DeRefDS(_tokid_24374);
        _tokid_24374 = _1;
    }

    /** keylist.e:194		sequence catname = "reserved word"*/
    RefDS(_13718);
    DeRef(_catname_24375);
    _catname_24375 = _13718;

    /** keylist.e:195		for i = 1 to length(token_category) do*/
    _13719 = 73;
    {
        object _i_24378;
        _i_24378 = 1;
L1: 
        if (_i_24378 > 73){
            goto L2; // [17] 72
        }

        /** keylist.e:196			if token_category[i][1] = tokid then*/
        _2 = (object)SEQ_PTR(_29token_category_12204);
        _13720 = (object)*(((s1_ptr)_2)->base + _i_24378);
        _2 = (object)SEQ_PTR(_13720);
        _13721 = (object)*(((s1_ptr)_2)->base + 1);
        _13720 = NOVALUE;
        if (binary_op_a(NOTEQ, _13721, _tokid_24374)){
            _13721 = NOVALUE;
            goto L3; // [36] 65
        }
        _13721 = NOVALUE;

        /** keylist.e:197				catname = token_catname[token_category[i][2]]*/
        _2 = (object)SEQ_PTR(_29token_category_12204);
        _13723 = (object)*(((s1_ptr)_2)->base + _i_24378);
        _2 = (object)SEQ_PTR(_13723);
        _13724 = (object)*(((s1_ptr)_2)->base + 2);
        _13723 = NOVALUE;
        DeRef(_catname_24375);
        _2 = (object)SEQ_PTR(_29token_catname_12191);
        if (!IS_ATOM_INT(_13724)){
            _catname_24375 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13724)->dbl));
        }
        else{
            _catname_24375 = (object)*(((s1_ptr)_2)->base + _13724);
        }
        RefDS(_catname_24375);

        /** keylist.e:198				exit*/
        goto L2; // [62] 72
L3: 

        /** keylist.e:200		end for*/
        _i_24378 = _i_24378 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** keylist.e:201		return catname*/
    _13724 = NOVALUE;
    return _catname_24375;
    ;
}


object _62find_token_text(object _tokid_24393)
{
    object _13733 = NOVALUE;
    object _13731 = NOVALUE;
    object _13730 = NOVALUE;
    object _13728 = NOVALUE;
    object _13727 = NOVALUE;
    object _13726 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24393)) {
        _1 = (object)(DBL_PTR(_tokid_24393)->dbl);
        DeRefDS(_tokid_24393);
        _tokid_24393 = _1;
    }

    /** keylist.e:205		for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23493)){
            _13726 = SEQ_PTR(_62keylist_23493)->length;
    }
    else {
        _13726 = 1;
    }
    {
        object _i_24395;
        _i_24395 = 1;
L1: 
        if (_i_24395 > _13726){
            goto L2; // [10] 57
        }

        /** keylist.e:206			if keylist[i][3] = tokid then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _13727 = (object)*(((s1_ptr)_2)->base + _i_24395);
        _2 = (object)SEQ_PTR(_13727);
        _13728 = (object)*(((s1_ptr)_2)->base + 3);
        _13727 = NOVALUE;
        if (binary_op_a(NOTEQ, _13728, _tokid_24393)){
            _13728 = NOVALUE;
            goto L3; // [29] 50
        }
        _13728 = NOVALUE;

        /** keylist.e:207				return keylist[i][1]*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _13730 = (object)*(((s1_ptr)_2)->base + _i_24395);
        _2 = (object)SEQ_PTR(_13730);
        _13731 = (object)*(((s1_ptr)_2)->base + 1);
        _13730 = NOVALUE;
        Ref(_13731);
        return _13731;
L3: 

        /** keylist.e:209		end for*/
        _i_24395 = _i_24395 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** keylist.e:210		return LexName(tokid, "unknown word")*/
    RefDS(_13732);
    _13733 = _45LexName(_tokid_24393, _13732);
    _13731 = NOVALUE;
    return _13733;
    ;
}



// 0xEDFB32DD
