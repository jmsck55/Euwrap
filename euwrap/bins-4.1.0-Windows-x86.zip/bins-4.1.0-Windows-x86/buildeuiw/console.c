// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _38any_key(object _prompt_14610, object _con_14612)
{
    object _wait_key_inlined_wait_key_at_27_14618 = NOVALUE;
    object _8376 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:883		if not find(con, {1,2}) then*/
    _8376 = find_from(_con_14612, _8375, 1);
    if (_8376 != 0)
    goto L1; // [12] 21
    _8376 = NOVALUE;

    /** console.e:884			con = 1*/
    _con_14612 = 1;
L1: 

    /** console.e:886		puts(con, prompt)*/
    EPuts(_con_14612, _prompt_14610); // DJP 

    /** console.e:887		wait_key()*/

    /** console.e:854		return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_14618 = machine(26, 0);

    /** console.e:888		puts(con, "\n")*/
    EPuts(_con_14612, _8378); // DJP 

    /** console.e:889	end procedure*/
    DeRefDS(_prompt_14610);
    return;
    ;
}


void _38maybe_any_key(object _prompt_14622, object _con_14623)
{
    object _has_console_inlined_has_console_at_6_14626 = NOVALUE;
    object _0, _1, _2;
    

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_14626);
    _has_console_inlined_has_console_at_6_14626 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_14626)) {
        if (_has_console_inlined_has_console_at_6_14626 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_14626)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_prompt_14622);
    _38any_key(_prompt_14622, _con_14623);
L1: 

    /** console.e:926	end procedure*/
    DeRefDS(_prompt_14622);
    return;
    ;
}



// 0x0A1AFD6D
