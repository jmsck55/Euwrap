// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _63is_file_newer(object _f1_24414, object _f2_24415)
{
    object _d1_24416 = NOVALUE;
    object _d2_24419 = NOVALUE;
    object _diff_2__tmp_at33_24428 = NOVALUE;
    object _diff_1__tmp_at33_24427 = NOVALUE;
    object _diff_inlined_diff_at_33_24426 = NOVALUE;
    object _13736 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:22		object d1 = file_timestamp(f1)*/
    RefDS(_f1_24414);
    _0 = _d1_24416;
    _d1_24416 = _15file_timestamp(_f1_24414);
    DeRef(_0);

    /** preproc.e:23		object d2 = file_timestamp(f2)*/
    RefDS(_f2_24415);
    _0 = _d2_24419;
    _d2_24419 = _15file_timestamp(_f2_24415);
    DeRef(_0);

    /** preproc.e:25		if atom(d2) then return 1 end if*/
    _13736 = IS_ATOM(_d2_24419);
    if (_13736 == 0)
    {
        _13736 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13736 = NOVALUE;
    }
    DeRefDS(_f1_24414);
    DeRefDS(_f2_24415);
    DeRef(_d1_24416);
    DeRef(_d2_24419);
    return 1;
L1: 

    /** preproc.e:27		if dt:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_24419);
    _0 = _diff_1__tmp_at33_24427;
    _diff_1__tmp_at33_24427 = _16datetimeToSeconds(_d2_24419);
    DeRef(_0);
    Ref(_d1_24416);
    _0 = _diff_2__tmp_at33_24428;
    _diff_2__tmp_at33_24428 = _16datetimeToSeconds(_d1_24416);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_24426);
    if (IS_ATOM_INT(_diff_1__tmp_at33_24427) && IS_ATOM_INT(_diff_2__tmp_at33_24428)) {
        _diff_inlined_diff_at_33_24426 = _diff_1__tmp_at33_24427 - _diff_2__tmp_at33_24428;
        if ((object)((uintptr_t)_diff_inlined_diff_at_33_24426 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_24426 = NewDouble((eudouble)_diff_inlined_diff_at_33_24426);
        }
    }
    else {
        _diff_inlined_diff_at_33_24426 = binary_op(MINUS, _diff_1__tmp_at33_24427, _diff_2__tmp_at33_24428);
    }
    DeRef(_diff_1__tmp_at33_24427);
    _diff_1__tmp_at33_24427 = NOVALUE;
    DeRef(_diff_2__tmp_at33_24428);
    _diff_2__tmp_at33_24428 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_24426, 0)){
        goto L2; // [49] 60
    }

    /** preproc.e:28			return 1*/
    DeRefDS(_f1_24414);
    DeRefDS(_f2_24415);
    DeRef(_d1_24416);
    DeRef(_d2_24419);
    return 1;
L2: 

    /** preproc.e:31		return 0*/
    DeRefDS(_f1_24414);
    DeRefDS(_f2_24415);
    DeRef(_d1_24416);
    DeRef(_d2_24419);
    return 0;
    ;
}


void _63add_preprocessor(object _file_ext_24432, object _command_24433, object _params_24434)
{
    object _tmp_24437 = NOVALUE;
    object _file_exts_24447 = NOVALUE;
    object _exts_24453 = NOVALUE;
    object _13753 = NOVALUE;
    object _13752 = NOVALUE;
    object _13751 = NOVALUE;
    object _13750 = NOVALUE;
    object _13748 = NOVALUE;
    object _13743 = NOVALUE;
    object _13738 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:46		if atom(command) then*/
    _13738 = 1;
    if (_13738 == 0)
    {
        _13738 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13738 = NOVALUE;
    }

    /** preproc.e:47			sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_24432);
    RefDS(_13739);
    _0 = _tmp_24437;
    _tmp_24437 = _24split(_file_ext_24432, _13739, 0, 0);
    DeRef(_0);

    /** preproc.e:48			file_ext = tmp[1]*/
    DeRefDS(_file_ext_24432);
    _2 = (object)SEQ_PTR(_tmp_24437);
    _file_ext_24432 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_24432);

    /** preproc.e:49			command = tmp[2]*/
    _2 = (object)SEQ_PTR(_tmp_24437);
    _command_24433 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_command_24433);

    /** preproc.e:50			if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_24437)){
            _13743 = SEQ_PTR(_tmp_24437)->length;
    }
    else {
        _13743 = 1;
    }
    if (_13743 < 3)
    goto L2; // [41] 52

    /** preproc.e:51				params = tmp[3]*/
    _2 = (object)SEQ_PTR(_tmp_24437);
    _params_24434 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_params_24434);
L2: 
L1: 
    DeRef(_tmp_24437);
    _tmp_24437 = NOVALUE;

    /** preproc.e:55		sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_24432);
    RefDS(_13746);
    _0 = _file_exts_24447;
    _file_exts_24447 = _24split(_file_ext_24432, _13746, 0, 0);
    DeRef(_0);

    /** preproc.e:57		if atom(params) then*/
    _13748 = IS_ATOM(_params_24434);
    if (_13748 == 0)
    {
        _13748 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13748 = NOVALUE;
    }

    /** preproc.e:58			params = ""*/
    RefDS(_5);
    DeRef(_params_24434);
    _params_24434 = _5;
L3: 

    /** preproc.e:61		sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_24432);
    RefDS(_13746);
    _0 = _exts_24453;
    _exts_24453 = _24split(_file_ext_24432, _13746, 0, 0);
    DeRef(_0);

    /** preproc.e:62		for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_24453)){
            _13750 = SEQ_PTR(_exts_24453)->length;
    }
    else {
        _13750 = 1;
    }
    {
        object _i_24457;
        _i_24457 = 1;
L4: 
        if (_i_24457 > _13750){
            goto L5; // [96] 135
        }

        /** preproc.e:63			preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (object)SEQ_PTR(_exts_24453);
        _13751 = (object)*(((s1_ptr)_2)->base + _i_24457);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_13751);
        ((intptr_t*)_2)[1] = _13751;
        Ref(_command_24433);
        ((intptr_t*)_2)[2] = _command_24433;
        Ref(_params_24434);
        ((intptr_t*)_2)[3] = _params_24434;
        ((intptr_t*)_2)[4] = -1;
        _13752 = MAKE_SEQ(_1);
        _13751 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _13752;
        _13753 = MAKE_SEQ(_1);
        _13752 = NOVALUE;
        Concat((object_ptr)&_28preprocessors_11590, _28preprocessors_11590, _13753);
        DeRefDS(_13753);
        _13753 = NOVALUE;

        /** preproc.e:64		end for*/
        _i_24457 = _i_24457 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** preproc.e:65	end procedure */
    DeRefDS(_file_ext_24432);
    DeRef(_command_24433);
    DeRef(_params_24434);
    DeRef(_file_exts_24447);
    DeRef(_exts_24453);
    return;
    ;
}


object _63maybe_preprocess(object _fname_24466)
{
    object _pp_24467 = NOVALUE;
    object _pp_id_24468 = NOVALUE;
    object _fext_24472 = NOVALUE;
    object _post_fname_24489 = NOVALUE;
    object _rid_24517 = NOVALUE;
    object _dll_id_24521 = NOVALUE;
    object _public_cmd_args_24557 = NOVALUE;
    object _cmd_args_24560 = NOVALUE;
    object _cmd_24589 = NOVALUE;
    object _pcmd_24594 = NOVALUE;
    object _result_24599 = NOVALUE;
    object _13832 = NOVALUE;
    object _13831 = NOVALUE;
    object _13826 = NOVALUE;
    object _13825 = NOVALUE;
    object _13823 = NOVALUE;
    object _13822 = NOVALUE;
    object _13820 = NOVALUE;
    object _13818 = NOVALUE;
    object _13817 = NOVALUE;
    object _13815 = NOVALUE;
    object _13812 = NOVALUE;
    object _13810 = NOVALUE;
    object _13808 = NOVALUE;
    object _13806 = NOVALUE;
    object _13805 = NOVALUE;
    object _13803 = NOVALUE;
    object _13802 = NOVALUE;
    object _13800 = NOVALUE;
    object _13797 = NOVALUE;
    object _13796 = NOVALUE;
    object _13795 = NOVALUE;
    object _13793 = NOVALUE;
    object _13789 = NOVALUE;
    object _13787 = NOVALUE;
    object _13786 = NOVALUE;
    object _13785 = NOVALUE;
    object _13781 = NOVALUE;
    object _13778 = NOVALUE;
    object _13777 = NOVALUE;
    object _13776 = NOVALUE;
    object _13774 = NOVALUE;
    object _13771 = NOVALUE;
    object _13769 = NOVALUE;
    object _13768 = NOVALUE;
    object _13766 = NOVALUE;
    object _13764 = NOVALUE;
    object _13762 = NOVALUE;
    object _13760 = NOVALUE;
    object _13759 = NOVALUE;
    object _13758 = NOVALUE;
    object _13757 = NOVALUE;
    object _13755 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** preproc.e:81		sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_24467);
    _pp_24467 = _5;

    /** preproc.e:84		if length(preprocessors) then*/
    if (IS_SEQUENCE(_28preprocessors_11590)){
            _13755 = SEQ_PTR(_28preprocessors_11590)->length;
    }
    else {
        _13755 = 1;
    }
    if (_13755 == 0)
    {
        _13755 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13755 = NOVALUE;
    }

    /** preproc.e:85			sequence fext = fileext(fname)*/
    RefDS(_fname_24466);
    _0 = _fext_24472;
    _fext_24472 = _15fileext(_fname_24466);
    DeRef(_0);

    /** preproc.e:87			for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_28preprocessors_11590)){
            _13757 = SEQ_PTR(_28preprocessors_11590)->length;
    }
    else {
        _13757 = 1;
    }
    {
        object _i_24476;
        _i_24476 = 1;
L2: 
        if (_i_24476 > _13757){
            goto L3; // [35] 88
        }

        /** preproc.e:88				if equal(fext, preprocessors[i][1]) then*/
        _2 = (object)SEQ_PTR(_28preprocessors_11590);
        _13758 = (object)*(((s1_ptr)_2)->base + _i_24476);
        _2 = (object)SEQ_PTR(_13758);
        _13759 = (object)*(((s1_ptr)_2)->base + 1);
        _13758 = NOVALUE;
        if (_fext_24472 == _13759)
        _13760 = 1;
        else if (IS_ATOM_INT(_fext_24472) && IS_ATOM_INT(_13759))
        _13760 = 0;
        else
        _13760 = (compare(_fext_24472, _13759) == 0);
        _13759 = NOVALUE;
        if (_13760 == 0)
        {
            _13760 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13760 = NOVALUE;
        }

        /** preproc.e:89					pp_id = i*/
        _pp_id_24468 = _i_24476;

        /** preproc.e:90					pp = preprocessors[pp_id]*/
        DeRef(_pp_24467);
        _2 = (object)SEQ_PTR(_28preprocessors_11590);
        _pp_24467 = (object)*(((s1_ptr)_2)->base + _pp_id_24468);
        RefDS(_pp_24467);

        /** preproc.e:91					exit*/
        goto L3; // [78] 88
L4: 

        /** preproc.e:93			end for*/
        _i_24476 = _i_24476 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_24472);
    _fext_24472 = NOVALUE;

    /** preproc.e:96		if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_24467)){
            _13762 = SEQ_PTR(_pp_24467)->length;
    }
    else {
        _13762 = 1;
    }
    if (_13762 != 0)
    goto L5; // [96] 107

    /** preproc.e:97			return fname*/
    DeRefDS(_pp_24467);
    DeRef(_post_fname_24489);
    return _fname_24466;
L5: 

    /** preproc.e:100		sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_24466);
    _13764 = _15filebase(_fname_24466);
    RefDS(_fname_24466);
    _13766 = _15fileext(_fname_24466);
    {
        object concat_list[3];

        concat_list[0] = _13766;
        concat_list[1] = _13765;
        concat_list[2] = _13764;
        Concat_N((object_ptr)&_post_fname_24489, concat_list, 3);
    }
    DeRef(_13766);
    _13766 = NOVALUE;
    DeRef(_13764);
    _13764 = NOVALUE;

    /** preproc.e:101		if length(dirname(fname)) > 0 then*/
    RefDS(_fname_24466);
    _13768 = _15dirname(_fname_24466, 0);
    if (IS_SEQUENCE(_13768)){
            _13769 = SEQ_PTR(_13768)->length;
    }
    else {
        _13769 = 1;
    }
    DeRef(_13768);
    _13768 = NOVALUE;
    if (_13769 <= 0)
    goto L6; // [133] 153

    /** preproc.e:102			post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_24466);
    _13771 = _15dirname(_fname_24466, 0);
    {
        object concat_list[3];

        concat_list[0] = _post_fname_24489;
        concat_list[1] = 92;
        concat_list[2] = _13771;
        Concat_N((object_ptr)&_post_fname_24489, concat_list, 3);
    }
    DeRef(_13771);
    _13771 = NOVALUE;
L6: 

    /** preproc.e:105		if not force_preprocessor then*/
    if (_28force_preprocessor_11591 != 0)
    goto L7; // [157] 178

    /** preproc.e:106			if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_24466);
    RefDS(_post_fname_24489);
    _13774 = _63is_file_newer(_fname_24466, _post_fname_24489);
    if (IS_ATOM_INT(_13774)) {
        if (_13774 != 0){
            DeRef(_13774);
            _13774 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13774)->dbl != 0.0){
            DeRef(_13774);
            _13774 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13774);
    _13774 = NOVALUE;

    /** preproc.e:107				return post_fname*/
    DeRefDS(_fname_24466);
    DeRef(_pp_24467);
    _13768 = NOVALUE;
    return _post_fname_24489;
L8: 
L7: 

    /** preproc.e:112		if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13776 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13776);
    _13777 = _15fileext(_13776);
    _13776 = NOVALUE;
    if (_13777 == _15SHARED_LIB_EXT_7827)
    _13778 = 1;
    else if (IS_ATOM_INT(_13777) && IS_ATOM_INT(_15SHARED_LIB_EXT_7827))
    _13778 = 0;
    else
    _13778 = (compare(_13777, _15SHARED_LIB_EXT_7827) == 0);
    DeRef(_13777);
    _13777 = NOVALUE;
    if (_13778 == 0)
    {
        _13778 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13778 = NOVALUE;
    }

    /** preproc.e:113			integer rid = pp[PP_RID]*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _rid_24517 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_24517))
    _rid_24517 = (object)DBL_PTR(_rid_24517)->dbl;

    /** preproc.e:114			if rid = -1 then*/
    if (_rid_24517 != -1)
    goto LA; // [205] 307

    /** preproc.e:115				integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13781 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13781);
    _dll_id_24521 = _4open_dll(_13781);
    _13781 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_24521)) {
        _1 = (object)(DBL_PTR(_dll_id_24521)->dbl);
        DeRefDS(_dll_id_24521);
        _dll_id_24521 = _1;
    }

    /** preproc.e:116				if dll_id = -1 then*/
    if (_dll_id_24521 != -1)
    goto LB; // [223] 247

    /** preproc.e:117					CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13785 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13785);
    ((intptr_t*)_2)[1] = _13785;
    _13786 = MAKE_SEQ(_1);
    _13785 = NOVALUE;
    _13787 = EPrintf(-9999999, _13784, _13786);
    DeRefDS(_13786);
    _13786 = NOVALUE;
    RefDS(_22209);
    _49CompileErr(_13787, _22209, 1);
    _13787 = NOVALUE;
LB: 

    /** preproc.e:121				rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 134217732;
    ((intptr_t*)_2)[2] = 134217732;
    ((intptr_t*)_2)[3] = 134217732;
    _13789 = MAKE_SEQ(_1);
    RefDS(_13788);
    _rid_24517 = _4define_c_func(_dll_id_24521, _13788, _13789, 100663300);
    _13789 = NOVALUE;
    if (!IS_ATOM_INT(_rid_24517)) {
        _1 = (object)(DBL_PTR(_rid_24517)->dbl);
        DeRefDS(_rid_24517);
        _rid_24517 = _1;
    }

    /** preproc.e:123				if rid = -1 then*/
    if (_rid_24517 != -1)
    goto LC; // [274] 291

    /** preproc.e:124					CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13792);
    RefDS(_22209);
    _49CompileErr(_13792, _22209, 1);

    /** preproc.e:126					Cleanup(1)*/
    _49Cleanup(1);
LC: 

    /** preproc.e:129				preprocessors[pp_id][PP_RID] = rid*/
    _2 = (object)SEQ_PTR(_28preprocessors_11590);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28preprocessors_11590 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pp_id_24468 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rid_24517;
    DeRef(_1);
    _13793 = NOVALUE;
LA: 

    /** preproc.e:132			if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13795 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_fname_24466);
    ((intptr_t*)_2)[1] = _fname_24466;
    RefDS(_post_fname_24489);
    ((intptr_t*)_2)[2] = _post_fname_24489;
    Ref(_13795);
    ((intptr_t*)_2)[3] = _13795;
    _13796 = MAKE_SEQ(_1);
    _13795 = NOVALUE;
    _13797 = call_c(1, _rid_24517, _13796);
    DeRefDS(_13796);
    _13796 = NOVALUE;
    if (binary_op_a(EQUALS, _13797, 0)){
        DeRef(_13797);
        _13797 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13797);
    _13797 = NOVALUE;

    /** preproc.e:133				CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13799);
    RefDS(_22209);
    _49CompileErr(_13799, _22209, 1);

    /** preproc.e:135				Cleanup(1)*/
    _49Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** preproc.e:138			sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13800 = (object)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_24557;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13800);
    ((intptr_t*)_2)[1] = _13800;
    _public_cmd_args_24557 = MAKE_SEQ(_1);
    DeRef(_0);
    _13800 = NOVALUE;

    /** preproc.e:139			sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13802 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13802);
    _13803 = _15canonical_path(_13802, 0, 4);
    _13802 = NOVALUE;
    _0 = _cmd_args_24560;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13803;
    _cmd_args_24560 = MAKE_SEQ(_1);
    DeRef(_0);
    _13803 = NOVALUE;

    /** preproc.e:141			if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (object)SEQ_PTR(_pp_24467);
    _13805 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_13805);
    _13806 = _15fileext(_13805);
    _13805 = NOVALUE;
    if (_13806 == _13807)
    _13808 = 1;
    else if (IS_ATOM_INT(_13806) && IS_ATOM_INT(_13807))
    _13808 = 0;
    else
    _13808 = (compare(_13806, _13807) == 0);
    DeRef(_13806);
    _13806 = NOVALUE;
    if (_13808 == 0)
    {
        _13808 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13808 = NOVALUE;
    }

    /** preproc.e:142				public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13809);
    ((intptr_t*)_2)[1] = _13809;
    _13810 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24557, _13810, _public_cmd_args_24557);
    DeRefDS(_13810);
    _13810 = NOVALUE;
    DeRef(_13810);
    _13810 = NOVALUE;

    /** preproc.e:143				cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13809);
    ((intptr_t*)_2)[1] = _13809;
    _13812 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_24560, _13812, _cmd_args_24560);
    DeRefDS(_13812);
    _13812 = NOVALUE;
    DeRef(_13812);
    _13812 = NOVALUE;
LF: 

    /** preproc.e:146			cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_24466);
    _13815 = _15canonical_path(_fname_24466, 0, 4);
    RefDS(_post_fname_24489);
    _13817 = _15canonical_path(_post_fname_24489, 0, 4);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13814);
    ((intptr_t*)_2)[1] = _13814;
    ((intptr_t*)_2)[2] = _13815;
    RefDS(_13816);
    ((intptr_t*)_2)[3] = _13816;
    ((intptr_t*)_2)[4] = _13817;
    _13818 = MAKE_SEQ(_1);
    _13817 = NOVALUE;
    _13815 = NOVALUE;
    Concat((object_ptr)&_cmd_args_24560, _cmd_args_24560, _13818);
    DeRefDS(_13818);
    _13818 = NOVALUE;

    /** preproc.e:147			public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13814);
    ((intptr_t*)_2)[1] = _13814;
    RefDS(_fname_24466);
    ((intptr_t*)_2)[2] = _fname_24466;
    RefDS(_13816);
    ((intptr_t*)_2)[3] = _13816;
    RefDS(_post_fname_24489);
    ((intptr_t*)_2)[4] = _post_fname_24489;
    _13820 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24557, _public_cmd_args_24557, _13820);
    DeRefDS(_13820);
    _13820 = NOVALUE;

    /** preproc.e:148			sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_24560);
    _13822 = _48build_commandline(_cmd_args_24560);
    _2 = (object)SEQ_PTR(_pp_24467);
    _13823 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13822) && IS_ATOM(_13823)) {
        Ref(_13823);
        Append(&_cmd_24589, _13822, _13823);
    }
    else if (IS_ATOM(_13822) && IS_SEQUENCE(_13823)) {
        Ref(_13822);
        Prepend(&_cmd_24589, _13823, _13822);
    }
    else {
        Concat((object_ptr)&_cmd_24589, _13822, _13823);
        DeRef(_13822);
        _13822 = NOVALUE;
    }
    DeRef(_13822);
    _13822 = NOVALUE;
    _13823 = NOVALUE;

    /** preproc.e:149			sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_24557);
    _13825 = _48build_commandline(_public_cmd_args_24557);
    _2 = (object)SEQ_PTR(_pp_24467);
    _13826 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13825) && IS_ATOM(_13826)) {
        Ref(_13826);
        Append(&_pcmd_24594, _13825, _13826);
    }
    else if (IS_ATOM(_13825) && IS_SEQUENCE(_13826)) {
        Ref(_13825);
        Prepend(&_pcmd_24594, _13826, _13825);
    }
    else {
        Concat((object_ptr)&_pcmd_24594, _13825, _13826);
        DeRef(_13825);
        _13825 = NOVALUE;
    }
    DeRef(_13825);
    _13825 = NOVALUE;
    _13826 = NOVALUE;

    /** preproc.e:150			integer result = system_exec(cmd, 2)*/
    _result_24599 = system_exec_call(_cmd_24589, 2);

    /** preproc.e:151			if result != 0 then*/
    if (_result_24599 == 0)
    goto L10; // [492] 517

    /** preproc.e:152				CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_24594);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _result_24599;
    ((intptr_t *)_2)[2] = _pcmd_24594;
    _13831 = MAKE_SEQ(_1);
    _13832 = EPrintf(-9999999, _13830, _13831);
    DeRefDS(_13831);
    _13831 = NOVALUE;
    RefDS(_22209);
    _49CompileErr(_13832, _22209, 1);
    _13832 = NOVALUE;

    /** preproc.e:154				Cleanup(1)*/
    _49Cleanup(1);
L10: 
    DeRef(_public_cmd_args_24557);
    _public_cmd_args_24557 = NOVALUE;
    DeRef(_cmd_args_24560);
    _cmd_args_24560 = NOVALUE;
    DeRef(_cmd_24589);
    _cmd_24589 = NOVALUE;
    DeRef(_pcmd_24594);
    _pcmd_24594 = NOVALUE;
LE: 

    /** preproc.e:158		return post_fname*/
    DeRefDS(_fname_24466);
    DeRef(_pp_24467);
    _13768 = NOVALUE;
    return _post_fname_24489;
    ;
}



// 0x51A797DA
