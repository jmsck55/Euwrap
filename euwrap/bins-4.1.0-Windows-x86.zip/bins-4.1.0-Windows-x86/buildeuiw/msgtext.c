// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _30GetMsgText(object _MsgNum_20123, object _WithNum_20124, object _Args_20125)
{
    object _idx_20126 = NOVALUE;
    object _msgtext_20127 = NOVALUE;
    object _11425 = NOVALUE;
    object _11424 = NOVALUE;
    object _11420 = NOVALUE;
    object _11419 = NOVALUE;
    object _11417 = NOVALUE;
    object _11414 = NOVALUE;
    object _11412 = NOVALUE;
    object _11411 = NOVALUE;
    object _11410 = NOVALUE;
    object _11409 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:757		integer idx = 1*/
    _idx_20126 = 1;

    /** msgtext.e:761		msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    Ref(_MsgNum_20123);
    RefDS(_28LocalizeQual_11592);
    RefDS(_28LocalDB_11593);
    _0 = _msgtext_20127;
    _msgtext_20127 = _31get_text(_MsgNum_20123, _28LocalizeQual_11592, _28LocalDB_11593);
    DeRef(_0);

    /** msgtext.e:764		if atom(msgtext) then*/
    _11409 = IS_ATOM(_msgtext_20127);
    if (_11409 == 0)
    {
        _11409 = NOVALUE;
        goto L1; // [25] 100
    }
    else{
        _11409 = NOVALUE;
    }

    /** msgtext.e:765			for i = 1 to length(StdErrMsgs) do*/
    _11410 = 365;
    {
        object _i_20135;
        _i_20135 = 1;
L2: 
        if (_i_20135 > 365){
            goto L3; // [35] 75
        }

        /** msgtext.e:766				if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (object)SEQ_PTR(_30StdErrMsgs_19394);
        _11411 = (object)*(((s1_ptr)_2)->base + _i_20135);
        _2 = (object)SEQ_PTR(_11411);
        _11412 = (object)*(((s1_ptr)_2)->base + 1);
        _11411 = NOVALUE;
        if (binary_op_a(NOTEQ, _11412, _MsgNum_20123)){
            _11412 = NOVALUE;
            goto L4; // [54] 68
        }
        _11412 = NOVALUE;

        /** msgtext.e:767					idx = i*/
        _idx_20126 = _i_20135;

        /** msgtext.e:768					exit*/
        goto L3; // [65] 75
L4: 

        /** msgtext.e:770			end for*/
        _i_20135 = _i_20135 + 1;
        goto L2; // [70] 42
L3: 
        ;
    }

    /** msgtext.e:771			msgtext = StdErrMsgs[idx][2]*/
    _2 = (object)SEQ_PTR(_30StdErrMsgs_19394);
    _11414 = (object)*(((s1_ptr)_2)->base + _idx_20126);
    DeRef(_msgtext_20127);
    _2 = (object)SEQ_PTR(_11414);
    _msgtext_20127 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_20127);
    _11414 = NOVALUE;

    /** msgtext.e:772			if idx = 1 then*/
    if (_idx_20126 != 1)
    goto L5; // [89] 99

    /** msgtext.e:773				Args = MsgNum*/
    Ref(_MsgNum_20123);
    DeRef(_Args_20125);
    _Args_20125 = _MsgNum_20123;
L5: 
L1: 

    /** msgtext.e:777		if atom(Args) or length(Args) != 0 then*/
    _11417 = IS_ATOM(_Args_20125);
    if (_11417 != 0) {
        goto L6; // [105] 121
    }
    if (IS_SEQUENCE(_Args_20125)){
            _11419 = SEQ_PTR(_Args_20125)->length;
    }
    else {
        _11419 = 1;
    }
    _11420 = (_11419 != 0);
    _11419 = NOVALUE;
    if (_11420 == 0)
    {
        DeRef(_11420);
        _11420 = NOVALUE;
        goto L7; // [117] 129
    }
    else{
        DeRef(_11420);
        _11420 = NOVALUE;
    }
L6: 

    /** msgtext.e:778			msgtext = format(msgtext, Args)*/
    Ref(_msgtext_20127);
    Ref(_Args_20125);
    _0 = _msgtext_20127;
    _msgtext_20127 = _12format(_msgtext_20127, _Args_20125);
    DeRef(_0);
L7: 

    /** msgtext.e:781		if WithNum != 0 then*/
    if (_WithNum_20124 == 0)
    goto L8; // [131] 152

    /** msgtext.e:782			return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_20127);
    Ref(_MsgNum_20123);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _MsgNum_20123;
    ((intptr_t *)_2)[2] = _msgtext_20127;
    _11424 = MAKE_SEQ(_1);
    _11425 = EPrintf(-9999999, _11423, _11424);
    DeRefDS(_11424);
    _11424 = NOVALUE;
    DeRef(_MsgNum_20123);
    DeRef(_Args_20125);
    DeRef(_msgtext_20127);
    return _11425;
    goto L9; // [149] 159
L8: 

    /** msgtext.e:784			return msgtext*/
    DeRef(_MsgNum_20123);
    DeRef(_Args_20125);
    DeRef(_11425);
    _11425 = NOVALUE;
    return _msgtext_20127;
L9: 
    ;
}


void _30ShowMsg(object _Cons_20160, object _Msg_20161, object _Args_20162, object _NL_20163)
{
    object _11432 = NOVALUE;
    object _11431 = NOVALUE;
    object _11429 = NOVALUE;
    object _11427 = NOVALUE;
    object _11426 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:790		if atom(Msg) then*/
    _11426 = 1;
    if (_11426 == 0)
    {
        _11426 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _11426 = NOVALUE;
    }

    /** msgtext.e:791			Msg = GetMsgText(floor(Msg), 0)*/
    _11427 = e_floor(_Msg_20161);
    RefDS(_5);
    _Msg_20161 = _30GetMsgText(_11427, 0, _5);
    _11427 = NOVALUE;
L1: 

    /** msgtext.e:794		if atom(Args) or length(Args) != 0 then*/
    _11429 = IS_ATOM(_Args_20162);
    if (_11429 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_20162)){
            _11431 = SEQ_PTR(_Args_20162)->length;
    }
    else {
        _11431 = 1;
    }
    _11432 = (_11431 != 0);
    _11431 = NOVALUE;
    if (_11432 == 0)
    {
        DeRef(_11432);
        _11432 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_11432);
        _11432 = NOVALUE;
    }
L2: 

    /** msgtext.e:795			Msg = format(Msg, Args)*/
    Ref(_Msg_20161);
    Ref(_Args_20162);
    _0 = _Msg_20161;
    _Msg_20161 = _12format(_Msg_20161, _Args_20162);
    DeRef(_0);
L3: 

    /** msgtext.e:798		puts(Cons, Msg)*/
    EPuts(_Cons_20160, _Msg_20161); // DJP 

    /** msgtext.e:800		if NL then*/
    if (_NL_20163 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** msgtext.e:801			puts(Cons, '\n')*/
    EPuts(_Cons_20160, 10); // DJP 
L4: 

    /** msgtext.e:804	end procedure*/
    DeRef(_Msg_20161);
    DeRef(_Args_20162);
    return;
    ;
}



// 0x8549F00F
