// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _24reverse(object _target_6407, object _pFrom_6408, object _pTo_6409)
{
    object _uppr_6410 = NOVALUE;
    object _n_6411 = NOVALUE;
    object _lLimit_6412 = NOVALUE;
    object _t_6413 = NOVALUE;
    object _3307 = NOVALUE;
    object _3306 = NOVALUE;
    object _3305 = NOVALUE;
    object _3303 = NOVALUE;
    object _3302 = NOVALUE;
    object _3300 = NOVALUE;
    object _3298 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:549		n = length(target)*/
    if (IS_SEQUENCE(_target_6407)){
            _n_6411 = SEQ_PTR(_target_6407)->length;
    }
    else {
        _n_6411 = 1;
    }

    /** sequence.e:550		if n < 2 then*/
    if (_n_6411 >= 2)
    goto L1; // [12] 23

    /** sequence.e:551			return target*/
    DeRef(_t_6413);
    return _target_6407;
L1: 

    /** sequence.e:553		if pFrom < 1 then*/
    if (_pFrom_6408 >= 1)
    goto L2; // [25] 35

    /** sequence.e:554			pFrom = 1*/
    _pFrom_6408 = 1;
L2: 

    /** sequence.e:556		if pTo < 1 then*/
    if (_pTo_6409 >= 1)
    goto L3; // [37] 48

    /** sequence.e:557			pTo = n + pTo*/
    _pTo_6409 = _n_6411 + _pTo_6409;
L3: 

    /** sequence.e:559		if pTo < pFrom or pFrom >= n then*/
    _3298 = (_pTo_6409 < _pFrom_6408);
    if (_3298 != 0) {
        goto L4; // [54] 67
    }
    _3300 = (_pFrom_6408 >= _n_6411);
    if (_3300 == 0)
    {
        DeRef(_3300);
        _3300 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_3300);
        _3300 = NOVALUE;
    }
L4: 

    /** sequence.e:560			return target*/
    DeRef(_t_6413);
    DeRef(_3298);
    _3298 = NOVALUE;
    return _target_6407;
L5: 

    /** sequence.e:562		if pTo > n then*/
    if (_pTo_6409 <= _n_6411)
    goto L6; // [76] 86

    /** sequence.e:563			pTo = n*/
    _pTo_6409 = _n_6411;
L6: 

    /** sequence.e:566		lLimit = floor((pFrom+pTo-1)/2)*/
    _3302 = _pFrom_6408 + _pTo_6409;
    if ((object)((uintptr_t)_3302 + (uintptr_t)HIGH_BITS) >= 0){
        _3302 = NewDouble((eudouble)_3302);
    }
    if (IS_ATOM_INT(_3302)) {
        _3303 = _3302 - 1;
        if ((object)((uintptr_t)_3303 +(uintptr_t) HIGH_BITS) >= 0){
            _3303 = NewDouble((eudouble)_3303);
        }
    }
    else {
        _3303 = NewDouble(DBL_PTR(_3302)->dbl - (eudouble)1);
    }
    DeRef(_3302);
    _3302 = NOVALUE;
    if (IS_ATOM_INT(_3303)) {
        _lLimit_6412 = _3303 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _3303, 2);
        _lLimit_6412 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_3303);
    _3303 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_6412)) {
        _1 = (object)(DBL_PTR(_lLimit_6412)->dbl);
        DeRefDS(_lLimit_6412);
        _lLimit_6412 = _1;
    }

    /** sequence.e:567		t = target*/
    Ref(_target_6407);
    DeRef(_t_6413);
    _t_6413 = _target_6407;

    /** sequence.e:568		uppr = pTo*/
    _uppr_6410 = _pTo_6409;

    /** sequence.e:569		for lowr = pFrom to lLimit do*/
    _3305 = _lLimit_6412;
    {
        object _lowr_6432;
        _lowr_6432 = _pFrom_6408;
L7: 
        if (_lowr_6432 > _3305){
            goto L8; // [119] 159
        }

        /** sequence.e:570			t[uppr] = target[lowr]*/
        _2 = (object)SEQ_PTR(_target_6407);
        _3306 = (object)*(((s1_ptr)_2)->base + _lowr_6432);
        Ref(_3306);
        _2 = (object)SEQ_PTR(_t_6413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_6413 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _uppr_6410);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3306;
        if( _1 != _3306 ){
            DeRef(_1);
        }
        _3306 = NOVALUE;

        /** sequence.e:571			t[lowr] = target[uppr]*/
        _2 = (object)SEQ_PTR(_target_6407);
        _3307 = (object)*(((s1_ptr)_2)->base + _uppr_6410);
        Ref(_3307);
        _2 = (object)SEQ_PTR(_t_6413);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_6413 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lowr_6432);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3307;
        if( _1 != _3307 ){
            DeRef(_1);
        }
        _3307 = NOVALUE;

        /** sequence.e:572			uppr -= 1*/
        _uppr_6410 = _uppr_6410 - 1;

        /** sequence.e:573		end for*/
        _lowr_6432 = _lowr_6432 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** sequence.e:574		return t*/
    DeRef(_target_6407);
    DeRef(_3298);
    _3298 = NOVALUE;
    return _t_6413;
    ;
}


object _24pad_tail(object _target_6508, object _size_6509, object _ch_6510)
{
    object _3344 = NOVALUE;
    object _3343 = NOVALUE;
    object _3342 = NOVALUE;
    object _3341 = NOVALUE;
    object _3339 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1022		if size <= length(target) then*/
    if (IS_SEQUENCE(_target_6508)){
            _3339 = SEQ_PTR(_target_6508)->length;
    }
    else {
        _3339 = 1;
    }
    if (_size_6509 > _3339)
    goto L1; // [8] 19

    /** sequence.e:1023			return target*/
    return _target_6508;
L1: 

    /** sequence.e:1026		return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_6508)){
            _3341 = SEQ_PTR(_target_6508)->length;
    }
    else {
        _3341 = 1;
    }
    _3342 = _size_6509 - _3341;
    _3341 = NOVALUE;
    _3343 = Repeat(_ch_6510, _3342);
    _3342 = NOVALUE;
    if (IS_SEQUENCE(_target_6508) && IS_ATOM(_3343)) {
    }
    else if (IS_ATOM(_target_6508) && IS_SEQUENCE(_3343)) {
        Ref(_target_6508);
        Prepend(&_3344, _3343, _target_6508);
    }
    else {
        Concat((object_ptr)&_3344, _target_6508, _3343);
    }
    DeRefDS(_3343);
    _3343 = NOVALUE;
    DeRef(_target_6508);
    return _3344;
    ;
}


object _24filter(object _source_6762, object _rid_6763, object _userdata_6764, object _rangetype_6765)
{
    object _dest_6766 = NOVALUE;
    object _idx_6767 = NOVALUE;
    object _3658 = NOVALUE;
    object _3657 = NOVALUE;
    object _3655 = NOVALUE;
    object _3654 = NOVALUE;
    object _3653 = NOVALUE;
    object _3652 = NOVALUE;
    object _3651 = NOVALUE;
    object _3648 = NOVALUE;
    object _3647 = NOVALUE;
    object _3646 = NOVALUE;
    object _3645 = NOVALUE;
    object _3642 = NOVALUE;
    object _3641 = NOVALUE;
    object _3640 = NOVALUE;
    object _3639 = NOVALUE;
    object _3638 = NOVALUE;
    object _3635 = NOVALUE;
    object _3634 = NOVALUE;
    object _3633 = NOVALUE;
    object _3632 = NOVALUE;
    object _3629 = NOVALUE;
    object _3628 = NOVALUE;
    object _3627 = NOVALUE;
    object _3626 = NOVALUE;
    object _3625 = NOVALUE;
    object _3622 = NOVALUE;
    object _3621 = NOVALUE;
    object _3620 = NOVALUE;
    object _3619 = NOVALUE;
    object _3616 = NOVALUE;
    object _3615 = NOVALUE;
    object _3614 = NOVALUE;
    object _3613 = NOVALUE;
    object _3612 = NOVALUE;
    object _3609 = NOVALUE;
    object _3608 = NOVALUE;
    object _3607 = NOVALUE;
    object _3606 = NOVALUE;
    object _3603 = NOVALUE;
    object _3602 = NOVALUE;
    object _3601 = NOVALUE;
    object _3600 = NOVALUE;
    object _3599 = NOVALUE;
    object _3596 = NOVALUE;
    object _3595 = NOVALUE;
    object _3594 = NOVALUE;
    object _3590 = NOVALUE;
    object _3587 = NOVALUE;
    object _3586 = NOVALUE;
    object _3585 = NOVALUE;
    object _3583 = NOVALUE;
    object _3582 = NOVALUE;
    object _3581 = NOVALUE;
    object _3580 = NOVALUE;
    object _3579 = NOVALUE;
    object _3576 = NOVALUE;
    object _3575 = NOVALUE;
    object _3574 = NOVALUE;
    object _3572 = NOVALUE;
    object _3571 = NOVALUE;
    object _3570 = NOVALUE;
    object _3569 = NOVALUE;
    object _3568 = NOVALUE;
    object _3565 = NOVALUE;
    object _3564 = NOVALUE;
    object _3563 = NOVALUE;
    object _3561 = NOVALUE;
    object _3560 = NOVALUE;
    object _3559 = NOVALUE;
    object _3558 = NOVALUE;
    object _3557 = NOVALUE;
    object _3554 = NOVALUE;
    object _3553 = NOVALUE;
    object _3552 = NOVALUE;
    object _3550 = NOVALUE;
    object _3549 = NOVALUE;
    object _3548 = NOVALUE;
    object _3547 = NOVALUE;
    object _3546 = NOVALUE;
    object _3544 = NOVALUE;
    object _3543 = NOVALUE;
    object _3542 = NOVALUE;
    object _3538 = NOVALUE;
    object _3535 = NOVALUE;
    object _3534 = NOVALUE;
    object _3533 = NOVALUE;
    object _3530 = NOVALUE;
    object _3527 = NOVALUE;
    object _3526 = NOVALUE;
    object _3525 = NOVALUE;
    object _3522 = NOVALUE;
    object _3519 = NOVALUE;
    object _3518 = NOVALUE;
    object _3517 = NOVALUE;
    object _3514 = NOVALUE;
    object _3511 = NOVALUE;
    object _3510 = NOVALUE;
    object _3509 = NOVALUE;
    object _3505 = NOVALUE;
    object _3502 = NOVALUE;
    object _3501 = NOVALUE;
    object _3500 = NOVALUE;
    object _3497 = NOVALUE;
    object _3494 = NOVALUE;
    object _3493 = NOVALUE;
    object _3492 = NOVALUE;
    object _3486 = NOVALUE;
    object _3484 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1731		if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_6762)){
            _3484 = SEQ_PTR(_source_6762)->length;
    }
    else {
        _3484 = 1;
    }
    if (_3484 != 0)
    goto L1; // [8] 19

    /** sequence.e:1732			return source*/
    DeRefDS(_userdata_6764);
    DeRefDS(_rangetype_6765);
    DeRef(_dest_6766);
    return _source_6762;
L1: 

    /** sequence.e:1734		dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_6762)){
            _3486 = SEQ_PTR(_source_6762)->length;
    }
    else {
        _3486 = 1;
    }
    DeRef(_dest_6766);
    _dest_6766 = Repeat(0, _3486);
    _3486 = NOVALUE;

    /** sequence.e:1735		idx = 0*/
    _idx_6767 = 0;

    /** sequence.e:1736		switch rid do*/
    _1 = find(_rid_6763, _3488);
    switch ( _1 ){ 

        /** sequence.e:1737			case "<", "lt" then*/
        case 1:
        case 2:

        /** sequence.e:1738				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3492 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3492 = 1;
        }
        {
            object _a_6779;
            _a_6779 = 1;
L2: 
            if (_a_6779 > _3492){
                goto L3; // [51] 96
            }

            /** sequence.e:1739					if compare(source[a], userdata) < 0 then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3493 = (object)*(((s1_ptr)_2)->base + _a_6779);
            if (IS_ATOM_INT(_3493) && IS_ATOM_INT(_userdata_6764)){
                _3494 = (_3493 < _userdata_6764) ? -1 : (_3493 > _userdata_6764);
            }
            else{
                _3494 = compare(_3493, _userdata_6764);
            }
            _3493 = NOVALUE;
            if (_3494 >= 0)
            goto L4; // [68] 89

            /** sequence.e:1740						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1741						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3497 = (object)*(((s1_ptr)_2)->base + _a_6779);
            Ref(_3497);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3497;
            if( _1 != _3497 ){
                DeRef(_1);
            }
            _3497 = NOVALUE;
L4: 

            /** sequence.e:1743				end for*/
            _a_6779 = _a_6779 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** sequence.e:1745			case "<=", "le" then*/
        case 3:
        case 4:

        /** sequence.e:1746				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3500 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3500 = 1;
        }
        {
            object _a_6791;
            _a_6791 = 1;
L6: 
            if (_a_6791 > _3500){
                goto L7; // [109] 154
            }

            /** sequence.e:1747					if compare(source[a], userdata) <= 0 then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3501 = (object)*(((s1_ptr)_2)->base + _a_6791);
            if (IS_ATOM_INT(_3501) && IS_ATOM_INT(_userdata_6764)){
                _3502 = (_3501 < _userdata_6764) ? -1 : (_3501 > _userdata_6764);
            }
            else{
                _3502 = compare(_3501, _userdata_6764);
            }
            _3501 = NOVALUE;
            if (_3502 > 0)
            goto L8; // [126] 147

            /** sequence.e:1748						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1749						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3505 = (object)*(((s1_ptr)_2)->base + _a_6791);
            Ref(_3505);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3505;
            if( _1 != _3505 ){
                DeRef(_1);
            }
            _3505 = NOVALUE;
L8: 

            /** sequence.e:1751				end for*/
            _a_6791 = _a_6791 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** sequence.e:1753			case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** sequence.e:1754				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3509 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3509 = 1;
        }
        {
            object _a_6804;
            _a_6804 = 1;
L9: 
            if (_a_6804 > _3509){
                goto LA; // [169] 214
            }

            /** sequence.e:1755					if compare(source[a], userdata) = 0 then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3510 = (object)*(((s1_ptr)_2)->base + _a_6804);
            if (IS_ATOM_INT(_3510) && IS_ATOM_INT(_userdata_6764)){
                _3511 = (_3510 < _userdata_6764) ? -1 : (_3510 > _userdata_6764);
            }
            else{
                _3511 = compare(_3510, _userdata_6764);
            }
            _3510 = NOVALUE;
            if (_3511 != 0)
            goto LB; // [186] 207

            /** sequence.e:1756						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1757						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3514 = (object)*(((s1_ptr)_2)->base + _a_6804);
            Ref(_3514);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3514;
            if( _1 != _3514 ){
                DeRef(_1);
            }
            _3514 = NOVALUE;
LB: 

            /** sequence.e:1759				end for*/
            _a_6804 = _a_6804 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** sequence.e:1761			case "!=", "ne" then*/
        case 8:
        case 9:

        /** sequence.e:1762				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3517 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3517 = 1;
        }
        {
            object _a_6816;
            _a_6816 = 1;
LC: 
            if (_a_6816 > _3517){
                goto LD; // [227] 272
            }

            /** sequence.e:1763					if compare(source[a], userdata) != 0 then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3518 = (object)*(((s1_ptr)_2)->base + _a_6816);
            if (IS_ATOM_INT(_3518) && IS_ATOM_INT(_userdata_6764)){
                _3519 = (_3518 < _userdata_6764) ? -1 : (_3518 > _userdata_6764);
            }
            else{
                _3519 = compare(_3518, _userdata_6764);
            }
            _3518 = NOVALUE;
            if (_3519 == 0)
            goto LE; // [244] 265

            /** sequence.e:1764						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1765						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3522 = (object)*(((s1_ptr)_2)->base + _a_6816);
            Ref(_3522);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3522;
            if( _1 != _3522 ){
                DeRef(_1);
            }
            _3522 = NOVALUE;
LE: 

            /** sequence.e:1767				end for*/
            _a_6816 = _a_6816 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** sequence.e:1769			case ">", "gt" then*/
        case 10:
        case 11:

        /** sequence.e:1770				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3525 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3525 = 1;
        }
        {
            object _a_6828;
            _a_6828 = 1;
LF: 
            if (_a_6828 > _3525){
                goto L10; // [285] 330
            }

            /** sequence.e:1771					if compare(source[a], userdata) > 0 then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3526 = (object)*(((s1_ptr)_2)->base + _a_6828);
            if (IS_ATOM_INT(_3526) && IS_ATOM_INT(_userdata_6764)){
                _3527 = (_3526 < _userdata_6764) ? -1 : (_3526 > _userdata_6764);
            }
            else{
                _3527 = compare(_3526, _userdata_6764);
            }
            _3526 = NOVALUE;
            if (_3527 <= 0)
            goto L11; // [302] 323

            /** sequence.e:1772						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1773						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3530 = (object)*(((s1_ptr)_2)->base + _a_6828);
            Ref(_3530);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3530;
            if( _1 != _3530 ){
                DeRef(_1);
            }
            _3530 = NOVALUE;
L11: 

            /** sequence.e:1775				end for*/
            _a_6828 = _a_6828 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** sequence.e:1777			case ">=", "ge" then*/
        case 12:
        case 13:

        /** sequence.e:1778				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3533 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3533 = 1;
        }
        {
            object _a_6840;
            _a_6840 = 1;
L12: 
            if (_a_6840 > _3533){
                goto L13; // [343] 388
            }

            /** sequence.e:1779					if compare(source[a], userdata) >= 0 then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3534 = (object)*(((s1_ptr)_2)->base + _a_6840);
            if (IS_ATOM_INT(_3534) && IS_ATOM_INT(_userdata_6764)){
                _3535 = (_3534 < _userdata_6764) ? -1 : (_3534 > _userdata_6764);
            }
            else{
                _3535 = compare(_3534, _userdata_6764);
            }
            _3534 = NOVALUE;
            if (_3535 < 0)
            goto L14; // [360] 381

            /** sequence.e:1780						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1781						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3538 = (object)*(((s1_ptr)_2)->base + _a_6840);
            Ref(_3538);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3538;
            if( _1 != _3538 ){
                DeRef(_1);
            }
            _3538 = NOVALUE;
L14: 

            /** sequence.e:1783				end for*/
            _a_6840 = _a_6840 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** sequence.e:1785			case "in" then*/
        case 14:

        /** sequence.e:1786				switch rangetype do*/
        _1 = find(_rangetype_6765, _3540);
        switch ( _1 ){ 

            /** sequence.e:1787					case "" then*/
            case 1:

            /** sequence.e:1788						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3542 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3542 = 1;
            }
            {
                object _a_6854;
                _a_6854 = 1;
L15: 
                if (_a_6854 > _3542){
                    goto L16; // [410] 455
                }

                /** sequence.e:1789							if find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3543 = (object)*(((s1_ptr)_2)->base + _a_6854);
                _3544 = find_from(_3543, _userdata_6764, 1);
                _3543 = NOVALUE;
                if (_3544 == 0)
                {
                    _3544 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _3544 = NOVALUE;
                }

                /** sequence.e:1790								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1791								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3546 = (object)*(((s1_ptr)_2)->base + _a_6854);
                Ref(_3546);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3546;
                if( _1 != _3546 ){
                    DeRef(_1);
                }
                _3546 = NOVALUE;
L17: 

                /** sequence.e:1793						end for*/
                _a_6854 = _a_6854 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** sequence.e:1795					case "[]" then*/
            case 2:

            /** sequence.e:1796						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3547 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3547 = 1;
            }
            {
                object _a_6863;
                _a_6863 = 1;
L18: 
                if (_a_6863 > _3547){
                    goto L19; // [466] 534
                }

                /** sequence.e:1797							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3548 = (object)*(((s1_ptr)_2)->base + _a_6863);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3549 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3548) && IS_ATOM_INT(_3549)){
                    _3550 = (_3548 < _3549) ? -1 : (_3548 > _3549);
                }
                else{
                    _3550 = compare(_3548, _3549);
                }
                _3548 = NOVALUE;
                _3549 = NOVALUE;
                if (_3550 < 0)
                goto L1A; // [487] 527

                /** sequence.e:1798								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3552 = (object)*(((s1_ptr)_2)->base + _a_6863);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3553 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3552) && IS_ATOM_INT(_3553)){
                    _3554 = (_3552 < _3553) ? -1 : (_3552 > _3553);
                }
                else{
                    _3554 = compare(_3552, _3553);
                }
                _3552 = NOVALUE;
                _3553 = NOVALUE;
                if (_3554 > 0)
                goto L1B; // [505] 526

                /** sequence.e:1799									idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1800									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3557 = (object)*(((s1_ptr)_2)->base + _a_6863);
                Ref(_3557);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3557;
                if( _1 != _3557 ){
                    DeRef(_1);
                }
                _3557 = NOVALUE;
L1B: 
L1A: 

                /** sequence.e:1803						end for*/
                _a_6863 = _a_6863 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** sequence.e:1805					case "[)" then*/
            case 3:

            /** sequence.e:1806						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3558 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3558 = 1;
            }
            {
                object _a_6879;
                _a_6879 = 1;
L1C: 
                if (_a_6879 > _3558){
                    goto L1D; // [545] 613
                }

                /** sequence.e:1807							if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3559 = (object)*(((s1_ptr)_2)->base + _a_6879);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3560 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3559) && IS_ATOM_INT(_3560)){
                    _3561 = (_3559 < _3560) ? -1 : (_3559 > _3560);
                }
                else{
                    _3561 = compare(_3559, _3560);
                }
                _3559 = NOVALUE;
                _3560 = NOVALUE;
                if (_3561 < 0)
                goto L1E; // [566] 606

                /** sequence.e:1808								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3563 = (object)*(((s1_ptr)_2)->base + _a_6879);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3564 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3563) && IS_ATOM_INT(_3564)){
                    _3565 = (_3563 < _3564) ? -1 : (_3563 > _3564);
                }
                else{
                    _3565 = compare(_3563, _3564);
                }
                _3563 = NOVALUE;
                _3564 = NOVALUE;
                if (_3565 >= 0)
                goto L1F; // [584] 605

                /** sequence.e:1809									idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1810									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3568 = (object)*(((s1_ptr)_2)->base + _a_6879);
                Ref(_3568);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3568;
                if( _1 != _3568 ){
                    DeRef(_1);
                }
                _3568 = NOVALUE;
L1F: 
L1E: 

                /** sequence.e:1813						end for*/
                _a_6879 = _a_6879 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** sequence.e:1814					case "(]" then*/
            case 4:

            /** sequence.e:1815						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3569 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3569 = 1;
            }
            {
                object _a_6895;
                _a_6895 = 1;
L20: 
                if (_a_6895 > _3569){
                    goto L21; // [624] 692
                }

                /** sequence.e:1816							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3570 = (object)*(((s1_ptr)_2)->base + _a_6895);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3571 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3570) && IS_ATOM_INT(_3571)){
                    _3572 = (_3570 < _3571) ? -1 : (_3570 > _3571);
                }
                else{
                    _3572 = compare(_3570, _3571);
                }
                _3570 = NOVALUE;
                _3571 = NOVALUE;
                if (_3572 <= 0)
                goto L22; // [645] 685

                /** sequence.e:1817								if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3574 = (object)*(((s1_ptr)_2)->base + _a_6895);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3575 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3574) && IS_ATOM_INT(_3575)){
                    _3576 = (_3574 < _3575) ? -1 : (_3574 > _3575);
                }
                else{
                    _3576 = compare(_3574, _3575);
                }
                _3574 = NOVALUE;
                _3575 = NOVALUE;
                if (_3576 > 0)
                goto L23; // [663] 684

                /** sequence.e:1818									idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1819									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3579 = (object)*(((s1_ptr)_2)->base + _a_6895);
                Ref(_3579);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3579;
                if( _1 != _3579 ){
                    DeRef(_1);
                }
                _3579 = NOVALUE;
L23: 
L22: 

                /** sequence.e:1822						end for*/
                _a_6895 = _a_6895 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** sequence.e:1823					case "()" then*/
            case 5:

            /** sequence.e:1824						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3580 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3580 = 1;
            }
            {
                object _a_6911;
                _a_6911 = 1;
L24: 
                if (_a_6911 > _3580){
                    goto L25; // [703] 771
                }

                /** sequence.e:1825							if compare(source[a], userdata[1]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3581 = (object)*(((s1_ptr)_2)->base + _a_6911);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3582 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3581) && IS_ATOM_INT(_3582)){
                    _3583 = (_3581 < _3582) ? -1 : (_3581 > _3582);
                }
                else{
                    _3583 = compare(_3581, _3582);
                }
                _3581 = NOVALUE;
                _3582 = NOVALUE;
                if (_3583 <= 0)
                goto L26; // [724] 764

                /** sequence.e:1826								if compare(source[a], userdata[2]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3585 = (object)*(((s1_ptr)_2)->base + _a_6911);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3586 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3585) && IS_ATOM_INT(_3586)){
                    _3587 = (_3585 < _3586) ? -1 : (_3585 > _3586);
                }
                else{
                    _3587 = compare(_3585, _3586);
                }
                _3585 = NOVALUE;
                _3586 = NOVALUE;
                if (_3587 >= 0)
                goto L27; // [742] 763

                /** sequence.e:1827									idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1828									dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3590 = (object)*(((s1_ptr)_2)->base + _a_6911);
                Ref(_3590);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3590;
                if( _1 != _3590 ){
                    DeRef(_1);
                }
                _3590 = NOVALUE;
L27: 
L26: 

                /** sequence.e:1831						end for*/
                _a_6911 = _a_6911 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** sequence.e:1833					case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** sequence.e:1838			case "out" then*/
        case 15:

        /** sequence.e:1839				switch rangetype do*/
        _1 = find(_rangetype_6765, _3592);
        switch ( _1 ){ 

            /** sequence.e:1840					case "" then*/
            case 1:

            /** sequence.e:1841						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3594 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3594 = 1;
            }
            {
                object _a_6932;
                _a_6932 = 1;
L28: 
                if (_a_6932 > _3594){
                    goto L29; // [800] 845
                }

                /** sequence.e:1842							if not find(source[a], userdata)  then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3595 = (object)*(((s1_ptr)_2)->base + _a_6932);
                _3596 = find_from(_3595, _userdata_6764, 1);
                _3595 = NOVALUE;
                if (_3596 != 0)
                goto L2A; // [818] 838
                _3596 = NOVALUE;

                /** sequence.e:1843								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1844								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3599 = (object)*(((s1_ptr)_2)->base + _a_6932);
                Ref(_3599);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3599;
                if( _1 != _3599 ){
                    DeRef(_1);
                }
                _3599 = NOVALUE;
L2A: 

                /** sequence.e:1846						end for*/
                _a_6932 = _a_6932 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** sequence.e:1848					case "[]" then*/
            case 2:

            /** sequence.e:1849						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3600 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3600 = 1;
            }
            {
                object _a_6942;
                _a_6942 = 1;
L2B: 
                if (_a_6942 > _3600){
                    goto L2C; // [856] 943
                }

                /** sequence.e:1850							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3601 = (object)*(((s1_ptr)_2)->base + _a_6942);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3602 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3601) && IS_ATOM_INT(_3602)){
                    _3603 = (_3601 < _3602) ? -1 : (_3601 > _3602);
                }
                else{
                    _3603 = compare(_3601, _3602);
                }
                _3601 = NOVALUE;
                _3602 = NOVALUE;
                if (_3603 >= 0)
                goto L2D; // [877] 900

                /** sequence.e:1851								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1852								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3606 = (object)*(((s1_ptr)_2)->base + _a_6942);
                Ref(_3606);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3606;
                if( _1 != _3606 ){
                    DeRef(_1);
                }
                _3606 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** sequence.e:1853							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3607 = (object)*(((s1_ptr)_2)->base + _a_6942);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3608 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3607) && IS_ATOM_INT(_3608)){
                    _3609 = (_3607 < _3608) ? -1 : (_3607 > _3608);
                }
                else{
                    _3609 = compare(_3607, _3608);
                }
                _3607 = NOVALUE;
                _3608 = NOVALUE;
                if (_3609 <= 0)
                goto L2F; // [914] 935

                /** sequence.e:1854								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1855								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3612 = (object)*(((s1_ptr)_2)->base + _a_6942);
                Ref(_3612);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3612;
                if( _1 != _3612 ){
                    DeRef(_1);
                }
                _3612 = NOVALUE;
L2F: 
L2E: 

                /** sequence.e:1857						end for*/
                _a_6942 = _a_6942 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** sequence.e:1859					case "[)" then*/
            case 3:

            /** sequence.e:1860						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3613 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3613 = 1;
            }
            {
                object _a_6960;
                _a_6960 = 1;
L30: 
                if (_a_6960 > _3613){
                    goto L31; // [954] 1041
                }

                /** sequence.e:1861							if compare(source[a], userdata[1]) < 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3614 = (object)*(((s1_ptr)_2)->base + _a_6960);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3615 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3614) && IS_ATOM_INT(_3615)){
                    _3616 = (_3614 < _3615) ? -1 : (_3614 > _3615);
                }
                else{
                    _3616 = compare(_3614, _3615);
                }
                _3614 = NOVALUE;
                _3615 = NOVALUE;
                if (_3616 >= 0)
                goto L32; // [975] 998

                /** sequence.e:1862								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1863								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3619 = (object)*(((s1_ptr)_2)->base + _a_6960);
                Ref(_3619);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3619;
                if( _1 != _3619 ){
                    DeRef(_1);
                }
                _3619 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** sequence.e:1864							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3620 = (object)*(((s1_ptr)_2)->base + _a_6960);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3621 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3620) && IS_ATOM_INT(_3621)){
                    _3622 = (_3620 < _3621) ? -1 : (_3620 > _3621);
                }
                else{
                    _3622 = compare(_3620, _3621);
                }
                _3620 = NOVALUE;
                _3621 = NOVALUE;
                if (_3622 < 0)
                goto L34; // [1012] 1033

                /** sequence.e:1865								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1866								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3625 = (object)*(((s1_ptr)_2)->base + _a_6960);
                Ref(_3625);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3625;
                if( _1 != _3625 ){
                    DeRef(_1);
                }
                _3625 = NOVALUE;
L34: 
L33: 

                /** sequence.e:1868						end for*/
                _a_6960 = _a_6960 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** sequence.e:1869					case "(]" then*/
            case 4:

            /** sequence.e:1870						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3626 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3626 = 1;
            }
            {
                object _a_6978;
                _a_6978 = 1;
L35: 
                if (_a_6978 > _3626){
                    goto L36; // [1052] 1139
                }

                /** sequence.e:1871							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3627 = (object)*(((s1_ptr)_2)->base + _a_6978);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3628 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3627) && IS_ATOM_INT(_3628)){
                    _3629 = (_3627 < _3628) ? -1 : (_3627 > _3628);
                }
                else{
                    _3629 = compare(_3627, _3628);
                }
                _3627 = NOVALUE;
                _3628 = NOVALUE;
                if (_3629 > 0)
                goto L37; // [1073] 1096

                /** sequence.e:1872								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1873								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3632 = (object)*(((s1_ptr)_2)->base + _a_6978);
                Ref(_3632);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3632;
                if( _1 != _3632 ){
                    DeRef(_1);
                }
                _3632 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** sequence.e:1874							elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3633 = (object)*(((s1_ptr)_2)->base + _a_6978);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3634 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3633) && IS_ATOM_INT(_3634)){
                    _3635 = (_3633 < _3634) ? -1 : (_3633 > _3634);
                }
                else{
                    _3635 = compare(_3633, _3634);
                }
                _3633 = NOVALUE;
                _3634 = NOVALUE;
                if (_3635 <= 0)
                goto L39; // [1110] 1131

                /** sequence.e:1875								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1876								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3638 = (object)*(((s1_ptr)_2)->base + _a_6978);
                Ref(_3638);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3638;
                if( _1 != _3638 ){
                    DeRef(_1);
                }
                _3638 = NOVALUE;
L39: 
L38: 

                /** sequence.e:1878						end for*/
                _a_6978 = _a_6978 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** sequence.e:1879					case "()" then*/
            case 5:

            /** sequence.e:1880						for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_6762)){
                    _3639 = SEQ_PTR(_source_6762)->length;
            }
            else {
                _3639 = 1;
            }
            {
                object _a_6996;
                _a_6996 = 1;
L3A: 
                if (_a_6996 > _3639){
                    goto L3B; // [1150] 1237
                }

                /** sequence.e:1881							if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3640 = (object)*(((s1_ptr)_2)->base + _a_6996);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3641 = (object)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3640) && IS_ATOM_INT(_3641)){
                    _3642 = (_3640 < _3641) ? -1 : (_3640 > _3641);
                }
                else{
                    _3642 = compare(_3640, _3641);
                }
                _3640 = NOVALUE;
                _3641 = NOVALUE;
                if (_3642 > 0)
                goto L3C; // [1171] 1194

                /** sequence.e:1882								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1883								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3645 = (object)*(((s1_ptr)_2)->base + _a_6996);
                Ref(_3645);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3645;
                if( _1 != _3645 ){
                    DeRef(_1);
                }
                _3645 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** sequence.e:1884							elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3646 = (object)*(((s1_ptr)_2)->base + _a_6996);
                _2 = (object)SEQ_PTR(_userdata_6764);
                _3647 = (object)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3646) && IS_ATOM_INT(_3647)){
                    _3648 = (_3646 < _3647) ? -1 : (_3646 > _3647);
                }
                else{
                    _3648 = compare(_3646, _3647);
                }
                _3646 = NOVALUE;
                _3647 = NOVALUE;
                if (_3648 < 0)
                goto L3E; // [1208] 1229

                /** sequence.e:1885								idx += 1*/
                _idx_6767 = _idx_6767 + 1;

                /** sequence.e:1886								dest[idx] = source[a]*/
                _2 = (object)SEQ_PTR(_source_6762);
                _3651 = (object)*(((s1_ptr)_2)->base + _a_6996);
                Ref(_3651);
                _2 = (object)SEQ_PTR(_dest_6766);
                _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _3651;
                if( _1 != _3651 ){
                    DeRef(_1);
                }
                _3651 = NOVALUE;
L3E: 
L3D: 

                /** sequence.e:1888						end for*/
                _a_6996 = _a_6996 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** sequence.e:1889					case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** sequence.e:1894			case else*/
        case 0:

        /** sequence.e:1895				for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_6762)){
                _3652 = SEQ_PTR(_source_6762)->length;
        }
        else {
            _3652 = 1;
        }
        {
            object _a_7015;
            _a_7015 = 1;
L3F: 
            if (_a_7015 > _3652){
                goto L40; // [1255] 1303
            }

            /** sequence.e:1896					if call_func(rid, {source[a], userdata}) then*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3653 = (object)*(((s1_ptr)_2)->base + _a_7015);
            Ref(_userdata_6764);
            Ref(_3653);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _3653;
            ((intptr_t *)_2)[2] = _userdata_6764;
            _3654 = MAKE_SEQ(_1);
            _3653 = NOVALUE;
            _1 = (object)SEQ_PTR(_3654);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_rid_6763].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            _1 = (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1), 
                                *( ((intptr_t *)_2) + 2)
                                 );
            DeRef(_3655);
            _3655 = _1;
            DeRefDS(_3654);
            _3654 = NOVALUE;
            if (_3655 == 0) {
                DeRef(_3655);
                _3655 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_3655) && DBL_PTR(_3655)->dbl == 0.0){
                    DeRef(_3655);
                    _3655 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_3655);
                _3655 = NOVALUE;
            }
            DeRef(_3655);
            _3655 = NOVALUE;

            /** sequence.e:1897						idx += 1*/
            _idx_6767 = _idx_6767 + 1;

            /** sequence.e:1898						dest[idx] = source[a]*/
            _2 = (object)SEQ_PTR(_source_6762);
            _3657 = (object)*(((s1_ptr)_2)->base + _a_7015);
            Ref(_3657);
            _2 = (object)SEQ_PTR(_dest_6766);
            _2 = (object)(((s1_ptr)_2)->base + _idx_6767);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3657;
            if( _1 != _3657 ){
                DeRef(_1);
            }
            _3657 = NOVALUE;
L41: 

            /** sequence.e:1900				end for*/
            _a_7015 = _a_7015 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** sequence.e:1902		return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_3658;
    RHS_Slice(_dest_6766, 1, _idx_6767);
    DeRefDS(_source_6762);
    DeRef(_userdata_6764);
    DeRef(_rangetype_6765);
    DeRefDS(_dest_6766);
    return _3658;
    ;
}


object _24filter_alpha(object _elem_7027, object _ud_7028)
{
    object _3659 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:1907		return t_alpha(elem)*/
    Ref(_elem_7027);
    _3659 = _9t_alpha(_elem_7027);
    DeRef(_elem_7027);
    return _3659;
    ;
}


object _24split(object _st_7072, object _delim_7073, object _no_empty_7074, object _limit_7075)
{
    object _ret_7076 = NOVALUE;
    object _start_7077 = NOVALUE;
    object _pos_7078 = NOVALUE;
    object _k_7130 = NOVALUE;
    object _3727 = NOVALUE;
    object _3725 = NOVALUE;
    object _3724 = NOVALUE;
    object _3720 = NOVALUE;
    object _3719 = NOVALUE;
    object _3718 = NOVALUE;
    object _3715 = NOVALUE;
    object _3714 = NOVALUE;
    object _3709 = NOVALUE;
    object _3708 = NOVALUE;
    object _3704 = NOVALUE;
    object _3700 = NOVALUE;
    object _3698 = NOVALUE;
    object _3697 = NOVALUE;
    object _3693 = NOVALUE;
    object _3691 = NOVALUE;
    object _3690 = NOVALUE;
    object _3689 = NOVALUE;
    object _3688 = NOVALUE;
    object _3685 = NOVALUE;
    object _3684 = NOVALUE;
    object _3683 = NOVALUE;
    object _3682 = NOVALUE;
    object _3681 = NOVALUE;
    object _3679 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2088		sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_7076);
    _ret_7076 = _5;

    /** sequence.e:2092		if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_7072)){
            _3679 = SEQ_PTR(_st_7072)->length;
    }
    else {
        _3679 = 1;
    }
    if (_3679 != 0)
    goto L1; // [19] 30

    /** sequence.e:2093			return ret*/
    DeRefDS(_st_7072);
    DeRefi(_delim_7073);
    return _ret_7076;
L1: 

    /** sequence.e:2097		if sequence(delim) then*/
    _3681 = IS_SEQUENCE(_delim_7073);
    if (_3681 == 0)
    {
        _3681 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _3681 = NOVALUE;
    }

    /** sequence.e:2099			if equal(delim, "") then*/
    if (_delim_7073 == _5)
    _3682 = 1;
    else if (IS_ATOM_INT(_delim_7073) && IS_ATOM_INT(_5))
    _3682 = 0;
    else
    _3682 = (compare(_delim_7073, _5) == 0);
    if (_3682 == 0)
    {
        _3682 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _3682 = NOVALUE;
    }

    /** sequence.e:2100				for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_7072)){
            _3683 = SEQ_PTR(_st_7072)->length;
    }
    else {
        _3683 = 1;
    }
    {
        object _i_7087;
        _i_7087 = 1;
L4: 
        if (_i_7087 > _3683){
            goto L5; // [52] 120
        }

        /** sequence.e:2101					st[i] = {st[i]}*/
        _2 = (object)SEQ_PTR(_st_7072);
        _3684 = (object)*(((s1_ptr)_2)->base + _i_7087);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_3684);
        ((intptr_t*)_2)[1] = _3684;
        _3685 = MAKE_SEQ(_1);
        _3684 = NOVALUE;
        _2 = (object)SEQ_PTR(_st_7072);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _st_7072 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_7087);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3685;
        if( _1 != _3685 ){
            DeRef(_1);
        }
        _3685 = NOVALUE;

        /** sequence.e:2102					limit -= 1*/
        _limit_7075 = _limit_7075 - 1;

        /** sequence.e:2103					if limit = 0 then*/
        if (_limit_7075 != 0)
        goto L6; // [81] 113

        /** sequence.e:2104						st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_3688;
        RHS_Slice(_st_7072, 1, _i_7087);
        _3689 = _i_7087 + 1;
        if (IS_SEQUENCE(_st_7072)){
                _3690 = SEQ_PTR(_st_7072)->length;
        }
        else {
            _3690 = 1;
        }
        rhs_slice_target = (object_ptr)&_3691;
        RHS_Slice(_st_7072, _3689, _3690);
        RefDS(_3691);
        Append(&_st_7072, _3688, _3691);
        DeRefDS(_3688);
        _3688 = NOVALUE;
        DeRefDS(_3691);
        _3691 = NOVALUE;

        /** sequence.e:2105						exit*/
        goto L5; // [110] 120
L6: 

        /** sequence.e:2107				end for*/
        _i_7087 = _i_7087 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** sequence.e:2109				return st*/
    DeRefi(_delim_7073);
    DeRef(_ret_7076);
    DeRef(_3689);
    _3689 = NOVALUE;
    return _st_7072;
L3: 

    /** sequence.e:2112			start = 1*/
    _start_7077 = 1;

    /** sequence.e:2113			while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_7072)){
            _3693 = SEQ_PTR(_st_7072)->length;
    }
    else {
        _3693 = 1;
    }
    if (_start_7077 > _3693)
    goto L8; // [140] 290

    /** sequence.e:2114				pos = match(delim, st, start)*/
    _pos_7078 = e_match_from(_delim_7073, _st_7072, _start_7077);

    /** sequence.e:2116				if pos = 0 then*/
    if (_pos_7078 != 0)
    goto L9; // [153] 162

    /** sequence.e:2117					exit*/
    goto L8; // [159] 290
L9: 

    /** sequence.e:2120				ret = append(ret, st[start..pos-1])*/
    _3697 = _pos_7078 - 1;
    rhs_slice_target = (object_ptr)&_3698;
    RHS_Slice(_st_7072, _start_7077, _3697);
    RefDS(_3698);
    Append(&_ret_7076, _ret_7076, _3698);
    DeRefDS(_3698);
    _3698 = NOVALUE;

    /** sequence.e:2121				start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_7073)){
            _3700 = SEQ_PTR(_delim_7073)->length;
    }
    else {
        _3700 = 1;
    }
    _start_7077 = _pos_7078 + _3700;
    _3700 = NOVALUE;

    /** sequence.e:2122				limit -= 1*/
    _limit_7075 = _limit_7075 - 1;

    /** sequence.e:2123				if limit = 0 then*/
    if (_limit_7075 != 0)
    goto L7; // [194] 137

    /** sequence.e:2124					exit*/
    goto L8; // [200] 290

    /** sequence.e:2126			end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** sequence.e:2128			start = 1*/
    _start_7077 = 1;

    /** sequence.e:2129			while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_7072)){
            _3704 = SEQ_PTR(_st_7072)->length;
    }
    else {
        _3704 = 1;
    }
    if (_start_7077 > _3704)
    goto LB; // [224] 289

    /** sequence.e:2130				pos = find(delim, st, start)*/
    _pos_7078 = find_from(_delim_7073, _st_7072, _start_7077);

    /** sequence.e:2132				if pos = 0 then*/
    if (_pos_7078 != 0)
    goto LC; // [237] 246

    /** sequence.e:2133					exit*/
    goto LB; // [243] 289
LC: 

    /** sequence.e:2136				ret = append(ret, st[start..pos-1])*/
    _3708 = _pos_7078 - 1;
    rhs_slice_target = (object_ptr)&_3709;
    RHS_Slice(_st_7072, _start_7077, _3708);
    RefDS(_3709);
    Append(&_ret_7076, _ret_7076, _3709);
    DeRefDS(_3709);
    _3709 = NOVALUE;

    /** sequence.e:2137				start = pos + 1*/
    _start_7077 = _pos_7078 + 1;

    /** sequence.e:2138				limit -= 1*/
    _limit_7075 = _limit_7075 - 1;

    /** sequence.e:2139				if limit = 0 then*/
    if (_limit_7075 != 0)
    goto LA; // [275] 221

    /** sequence.e:2140					exit*/
    goto LB; // [281] 289

    /** sequence.e:2142			end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** sequence.e:2145		ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_7072)){
            _3714 = SEQ_PTR(_st_7072)->length;
    }
    else {
        _3714 = 1;
    }
    rhs_slice_target = (object_ptr)&_3715;
    RHS_Slice(_st_7072, _start_7077, _3714);
    RefDS(_3715);
    Append(&_ret_7076, _ret_7076, _3715);
    DeRefDS(_3715);
    _3715 = NOVALUE;

    /** sequence.e:2147		integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_7076)){
            _k_7130 = SEQ_PTR(_ret_7076)->length;
    }
    else {
        _k_7130 = 1;
    }

    /** sequence.e:2148		if no_empty then*/
    if (_no_empty_7074 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** sequence.e:2149			k = 0*/
    _k_7130 = 0;

    /** sequence.e:2150			for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_7076)){
            _3718 = SEQ_PTR(_ret_7076)->length;
    }
    else {
        _3718 = 1;
    }
    {
        object _i_7134;
        _i_7134 = 1;
LE: 
        if (_i_7134 > _3718){
            goto LF; // [326] 377
        }

        /** sequence.e:2151				if length(ret[i]) != 0 then*/
        _2 = (object)SEQ_PTR(_ret_7076);
        _3719 = (object)*(((s1_ptr)_2)->base + _i_7134);
        if (IS_SEQUENCE(_3719)){
                _3720 = SEQ_PTR(_3719)->length;
        }
        else {
            _3720 = 1;
        }
        _3719 = NOVALUE;
        if (_3720 == 0)
        goto L10; // [342] 370

        /** sequence.e:2152					k += 1*/
        _k_7130 = _k_7130 + 1;

        /** sequence.e:2153					if k != i then*/
        if (_k_7130 == _i_7134)
        goto L11; // [354] 369

        /** sequence.e:2154						ret[k] = ret[i]*/
        _2 = (object)SEQ_PTR(_ret_7076);
        _3724 = (object)*(((s1_ptr)_2)->base + _i_7134);
        Ref(_3724);
        _2 = (object)SEQ_PTR(_ret_7076);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _ret_7076 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _k_7130);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3724;
        if( _1 != _3724 ){
            DeRef(_1);
        }
        _3724 = NOVALUE;
L11: 
L10: 

        /** sequence.e:2157			end for*/
        _i_7134 = _i_7134 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** sequence.e:2160		if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_7076)){
            _3725 = SEQ_PTR(_ret_7076)->length;
    }
    else {
        _3725 = 1;
    }
    if (_k_7130 >= _3725)
    goto L12; // [383] 401

    /** sequence.e:2161			return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_3727;
    RHS_Slice(_ret_7076, 1, _k_7130);
    DeRefDS(_st_7072);
    DeRefi(_delim_7073);
    DeRefDS(_ret_7076);
    DeRef(_3697);
    _3697 = NOVALUE;
    DeRef(_3708);
    _3708 = NOVALUE;
    _3719 = NOVALUE;
    DeRef(_3689);
    _3689 = NOVALUE;
    return _3727;
    goto L13; // [398] 408
L12: 

    /** sequence.e:2163			return ret*/
    DeRefDS(_st_7072);
    DeRefi(_delim_7073);
    DeRef(_3697);
    _3697 = NOVALUE;
    DeRef(_3708);
    _3708 = NOVALUE;
    DeRef(_3727);
    _3727 = NOVALUE;
    _3719 = NOVALUE;
    DeRef(_3689);
    _3689 = NOVALUE;
    return _ret_7076;
L13: 
    ;
}


object _24join(object _items_7199, object _delim_7200)
{
    object _ret_7202 = NOVALUE;
    object _3762 = NOVALUE;
    object _3761 = NOVALUE;
    object _3759 = NOVALUE;
    object _3758 = NOVALUE;
    object _3757 = NOVALUE;
    object _3756 = NOVALUE;
    object _3754 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2279		if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_7199)){
            _3754 = SEQ_PTR(_items_7199)->length;
    }
    else {
        _3754 = 1;
    }
    if (_3754 != 0)
    goto L1; // [8] 16
    _3754 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_7199);
    DeRef(_ret_7202);
    return _5;
L1: 

    /** sequence.e:2281		ret = {}*/
    RefDS(_5);
    DeRef(_ret_7202);
    _ret_7202 = _5;

    /** sequence.e:2282		for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_7199)){
            _3756 = SEQ_PTR(_items_7199)->length;
    }
    else {
        _3756 = 1;
    }
    _3757 = _3756 - 1;
    _3756 = NOVALUE;
    {
        object _i_7207;
        _i_7207 = 1;
L2: 
        if (_i_7207 > _3757){
            goto L3; // [30] 58
        }

        /** sequence.e:2283			ret &= items[i] & delim*/
        _2 = (object)SEQ_PTR(_items_7199);
        _3758 = (object)*(((s1_ptr)_2)->base + _i_7207);
        if (IS_SEQUENCE(_3758) && IS_ATOM(_delim_7200)) {
            Append(&_3759, _3758, _delim_7200);
        }
        else if (IS_ATOM(_3758) && IS_SEQUENCE(_delim_7200)) {
        }
        else {
            Concat((object_ptr)&_3759, _3758, _delim_7200);
            _3758 = NOVALUE;
        }
        _3758 = NOVALUE;
        if (IS_SEQUENCE(_ret_7202) && IS_ATOM(_3759)) {
        }
        else if (IS_ATOM(_ret_7202) && IS_SEQUENCE(_3759)) {
            Ref(_ret_7202);
            Prepend(&_ret_7202, _3759, _ret_7202);
        }
        else {
            Concat((object_ptr)&_ret_7202, _ret_7202, _3759);
        }
        DeRefDS(_3759);
        _3759 = NOVALUE;

        /** sequence.e:2284		end for*/
        _i_7207 = _i_7207 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** sequence.e:2286		ret &= items[$]*/
    if (IS_SEQUENCE(_items_7199)){
            _3761 = SEQ_PTR(_items_7199)->length;
    }
    else {
        _3761 = 1;
    }
    _2 = (object)SEQ_PTR(_items_7199);
    _3762 = (object)*(((s1_ptr)_2)->base + _3761);
    if (IS_SEQUENCE(_ret_7202) && IS_ATOM(_3762)) {
        Ref(_3762);
        Append(&_ret_7202, _ret_7202, _3762);
    }
    else if (IS_ATOM(_ret_7202) && IS_SEQUENCE(_3762)) {
        Ref(_ret_7202);
        Prepend(&_ret_7202, _3762, _ret_7202);
    }
    else {
        Concat((object_ptr)&_ret_7202, _ret_7202, _3762);
    }
    _3762 = NOVALUE;

    /** sequence.e:2288		return ret*/
    DeRefDS(_items_7199);
    DeRef(_3757);
    _3757 = NOVALUE;
    return _ret_7202;
    ;
}


object _24flatten(object _s_7309, object _delim_7310)
{
    object _ret_7311 = NOVALUE;
    object _x_7312 = NOVALUE;
    object _len_7313 = NOVALUE;
    object _pos_7314 = NOVALUE;
    object _temp_7332 = NOVALUE;
    object _3848 = NOVALUE;
    object _3847 = NOVALUE;
    object _3846 = NOVALUE;
    object _3844 = NOVALUE;
    object _3843 = NOVALUE;
    object _3842 = NOVALUE;
    object _3840 = NOVALUE;
    object _3838 = NOVALUE;
    object _3837 = NOVALUE;
    object _3836 = NOVALUE;
    object _3834 = NOVALUE;
    object _3833 = NOVALUE;
    object _3832 = NOVALUE;
    object _3831 = NOVALUE;
    object _3830 = NOVALUE;
    object _3829 = NOVALUE;
    object _3827 = NOVALUE;
    object _3826 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:2491		ret = s*/
    RefDS(_s_7309);
    DeRef(_ret_7311);
    _ret_7311 = _s_7309;

    /** sequence.e:2492		pos = 1*/
    _pos_7314 = 1;

    /** sequence.e:2493		len = length(ret)*/
    if (IS_SEQUENCE(_ret_7311)){
            _len_7313 = SEQ_PTR(_ret_7311)->length;
    }
    else {
        _len_7313 = 1;
    }

    /** sequence.e:2494		while pos <= len do*/
L1: 
    if (_pos_7314 > _len_7313)
    goto L2; // [25] 183

    /** sequence.e:2495			x = ret[pos]*/
    DeRef(_x_7312);
    _2 = (object)SEQ_PTR(_ret_7311);
    _x_7312 = (object)*(((s1_ptr)_2)->base + _pos_7314);
    Ref(_x_7312);

    /** sequence.e:2496			if sequence(x) then*/
    _3826 = IS_SEQUENCE(_x_7312);
    if (_3826 == 0)
    {
        _3826 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _3826 = NOVALUE;
    }

    /** sequence.e:2497				if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_7310)){
            _3827 = SEQ_PTR(_delim_7310)->length;
    }
    else {
        _3827 = 1;
    }
    if (_3827 != 0)
    goto L4; // [48] 89

    /** sequence.e:2498					ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _3829 = _pos_7314 - 1;
    rhs_slice_target = (object_ptr)&_3830;
    RHS_Slice(_ret_7311, 1, _3829);
    Ref(_x_7312);
    RefDS(_5);
    _3831 = _24flatten(_x_7312, _5);
    _3832 = _pos_7314 + 1;
    if (_3832 > MAXINT){
        _3832 = NewDouble((eudouble)_3832);
    }
    if (IS_SEQUENCE(_ret_7311)){
            _3833 = SEQ_PTR(_ret_7311)->length;
    }
    else {
        _3833 = 1;
    }
    rhs_slice_target = (object_ptr)&_3834;
    RHS_Slice(_ret_7311, _3832, _3833);
    {
        object concat_list[3];

        concat_list[0] = _3834;
        concat_list[1] = _3831;
        concat_list[2] = _3830;
        Concat_N((object_ptr)&_ret_7311, concat_list, 3);
    }
    DeRefDS(_3834);
    _3834 = NOVALUE;
    DeRef(_3831);
    _3831 = NOVALUE;
    DeRefDS(_3830);
    _3830 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** sequence.e:2500					sequence temp = ret[1..pos-1] & flatten(x)*/
    _3836 = _pos_7314 - 1;
    rhs_slice_target = (object_ptr)&_3837;
    RHS_Slice(_ret_7311, 1, _3836);
    Ref(_x_7312);
    RefDS(_5);
    _3838 = _24flatten(_x_7312, _5);
    if (IS_SEQUENCE(_3837) && IS_ATOM(_3838)) {
        Ref(_3838);
        Append(&_temp_7332, _3837, _3838);
    }
    else if (IS_ATOM(_3837) && IS_SEQUENCE(_3838)) {
    }
    else {
        Concat((object_ptr)&_temp_7332, _3837, _3838);
        DeRefDS(_3837);
        _3837 = NOVALUE;
    }
    DeRef(_3837);
    _3837 = NOVALUE;
    DeRef(_3838);
    _3838 = NOVALUE;

    /** sequence.e:2501					if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_7311)){
            _3840 = SEQ_PTR(_ret_7311)->length;
    }
    else {
        _3840 = 1;
    }
    if (_pos_7314 == _3840)
    goto L6; // [114] 141

    /** sequence.e:2502						ret = temp &  delim & ret[pos+1 .. $]*/
    _3842 = _pos_7314 + 1;
    if (_3842 > MAXINT){
        _3842 = NewDouble((eudouble)_3842);
    }
    if (IS_SEQUENCE(_ret_7311)){
            _3843 = SEQ_PTR(_ret_7311)->length;
    }
    else {
        _3843 = 1;
    }
    rhs_slice_target = (object_ptr)&_3844;
    RHS_Slice(_ret_7311, _3842, _3843);
    {
        object concat_list[3];

        concat_list[0] = _3844;
        concat_list[1] = _delim_7310;
        concat_list[2] = _temp_7332;
        Concat_N((object_ptr)&_ret_7311, concat_list, 3);
    }
    DeRefDS(_3844);
    _3844 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** sequence.e:2504						ret = temp & ret[pos+1 .. $]*/
    _3846 = _pos_7314 + 1;
    if (_3846 > MAXINT){
        _3846 = NewDouble((eudouble)_3846);
    }
    if (IS_SEQUENCE(_ret_7311)){
            _3847 = SEQ_PTR(_ret_7311)->length;
    }
    else {
        _3847 = 1;
    }
    rhs_slice_target = (object_ptr)&_3848;
    RHS_Slice(_ret_7311, _3846, _3847);
    Concat((object_ptr)&_ret_7311, _temp_7332, _3848);
    DeRefDS(_3848);
    _3848 = NOVALUE;
L7: 
    DeRef(_temp_7332);
    _temp_7332 = NOVALUE;
L5: 

    /** sequence.e:2507				len = length(ret)*/
    if (IS_SEQUENCE(_ret_7311)){
            _len_7313 = SEQ_PTR(_ret_7311)->length;
    }
    else {
        _len_7313 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** sequence.e:2509				pos += 1*/
    _pos_7314 = _pos_7314 + 1;

    /** sequence.e:2511		end while*/
    goto L1; // [180] 25
L2: 

    /** sequence.e:2513		return ret*/
    DeRefDS(_s_7309);
    DeRefi(_delim_7310);
    DeRef(_x_7312);
    DeRef(_3836);
    _3836 = NOVALUE;
    DeRef(_3842);
    _3842 = NOVALUE;
    DeRef(_3832);
    _3832 = NOVALUE;
    DeRef(_3846);
    _3846 = NOVALUE;
    DeRef(_3829);
    _3829 = NOVALUE;
    return _ret_7311;
    ;
}


object _24remove_dups(object _source_data_7679, object _proc_option_7680)
{
    object _lTo_7681 = NOVALUE;
    object _lFrom_7682 = NOVALUE;
    object _lResult_7705 = NOVALUE;
    object _4077 = NOVALUE;
    object _4075 = NOVALUE;
    object _4074 = NOVALUE;
    object _4073 = NOVALUE;
    object _4072 = NOVALUE;
    object _4070 = NOVALUE;
    object _4066 = NOVALUE;
    object _4065 = NOVALUE;
    object _4064 = NOVALUE;
    object _4062 = NOVALUE;
    object _4057 = NOVALUE;
    object _0, _1, _2;
    

    /** sequence.e:3111		if length(source_data) < 2 then*/
    if (IS_SEQUENCE(_source_data_7679)){
            _4057 = SEQ_PTR(_source_data_7679)->length;
    }
    else {
        _4057 = 1;
    }
    if (_4057 >= 2)
    goto L1; // [10] 21

    /** sequence.e:3112			return source_data*/
    DeRef(_lResult_7705);
    return _source_data_7679;
L1: 

    /** sequence.e:3115		if proc_option = RD_SORT then*/
    if (_proc_option_7680 != 3)
    goto L2; // [23] 42

    /** sequence.e:3116			source_data = stdsort:sort(source_data)*/
    RefDS(_source_data_7679);
    _0 = _source_data_7679;
    _source_data_7679 = _25sort(_source_data_7679, 1);
    DeRefDS(_0);

    /** sequence.e:3117			proc_option = RD_PRESORTED*/
    _proc_option_7680 = 2;
L2: 

    /** sequence.e:3119		if proc_option = RD_PRESORTED then*/
    if (_proc_option_7680 != 2)
    goto L3; // [44] 134

    /** sequence.e:3120			lTo = 1*/
    _lTo_7681 = 1;

    /** sequence.e:3121			lFrom = 2*/
    _lFrom_7682 = 2;

    /** sequence.e:3123			while lFrom <= length(source_data) do*/
L4: 
    if (IS_SEQUENCE(_source_data_7679)){
            _4062 = SEQ_PTR(_source_data_7679)->length;
    }
    else {
        _4062 = 1;
    }
    if (_lFrom_7682 > _4062)
    goto L5; // [66] 122

    /** sequence.e:3124				if not equal(source_data[lFrom], source_data[lTo]) then*/
    _2 = (object)SEQ_PTR(_source_data_7679);
    _4064 = (object)*(((s1_ptr)_2)->base + _lFrom_7682);
    _2 = (object)SEQ_PTR(_source_data_7679);
    _4065 = (object)*(((s1_ptr)_2)->base + _lTo_7681);
    if (_4064 == _4065)
    _4066 = 1;
    else if (IS_ATOM_INT(_4064) && IS_ATOM_INT(_4065))
    _4066 = 0;
    else
    _4066 = (compare(_4064, _4065) == 0);
    _4064 = NOVALUE;
    _4065 = NOVALUE;
    if (_4066 != 0)
    goto L6; // [84] 111
    _4066 = NOVALUE;

    /** sequence.e:3125					lTo += 1*/
    _lTo_7681 = _lTo_7681 + 1;

    /** sequence.e:3126					if lTo != lFrom then*/
    if (_lTo_7681 == _lFrom_7682)
    goto L7; // [95] 110

    /** sequence.e:3127						source_data[lTo] = source_data[lFrom]*/
    _2 = (object)SEQ_PTR(_source_data_7679);
    _4070 = (object)*(((s1_ptr)_2)->base + _lFrom_7682);
    Ref(_4070);
    _2 = (object)SEQ_PTR(_source_data_7679);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _source_data_7679 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _lTo_7681);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4070;
    if( _1 != _4070 ){
        DeRef(_1);
    }
    _4070 = NOVALUE;
L7: 
L6: 

    /** sequence.e:3130				lFrom += 1*/
    _lFrom_7682 = _lFrom_7682 + 1;

    /** sequence.e:3131			end while*/
    goto L4; // [119] 63
L5: 

    /** sequence.e:3132			return source_data[1 .. lTo]*/
    rhs_slice_target = (object_ptr)&_4072;
    RHS_Slice(_source_data_7679, 1, _lTo_7681);
    DeRefDS(_source_data_7679);
    DeRef(_lResult_7705);
    return _4072;
L3: 

    /** sequence.e:3135		sequence lResult*/

    /** sequence.e:3136		lResult = {}*/
    RefDS(_5);
    DeRef(_lResult_7705);
    _lResult_7705 = _5;

    /** sequence.e:3137		for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_7679)){
            _4073 = SEQ_PTR(_source_data_7679)->length;
    }
    else {
        _4073 = 1;
    }
    {
        object _i_7707;
        _i_7707 = 1;
L8: 
        if (_i_7707 > _4073){
            goto L9; // [148] 187
        }

        /** sequence.e:3138			if not find(source_data[i], lResult) then*/
        _2 = (object)SEQ_PTR(_source_data_7679);
        _4074 = (object)*(((s1_ptr)_2)->base + _i_7707);
        _4075 = find_from(_4074, _lResult_7705, 1);
        _4074 = NOVALUE;
        if (_4075 != 0)
        goto LA; // [166] 180
        _4075 = NOVALUE;

        /** sequence.e:3139				lResult = append(lResult, source_data[i])*/
        _2 = (object)SEQ_PTR(_source_data_7679);
        _4077 = (object)*(((s1_ptr)_2)->base + _i_7707);
        Ref(_4077);
        Append(&_lResult_7705, _lResult_7705, _4077);
        _4077 = NOVALUE;
LA: 

        /** sequence.e:3141		end for*/
        _i_7707 = _i_7707 + 1;
        goto L8; // [182] 155
L9: 
        ;
    }

    /** sequence.e:3142		return lResult*/
    DeRefDS(_source_data_7679);
    DeRef(_4072);
    _4072 = NOVALUE;
    return _lResult_7705;
    ;
}



// 0xDCC2494F
