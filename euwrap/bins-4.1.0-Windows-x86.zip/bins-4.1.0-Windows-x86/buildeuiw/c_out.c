// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _54c_putc(object _c_47034)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_47034)) {
        _1 = (object)(DBL_PTR(_c_47034)->dbl);
        DeRefDS(_c_47034);
        _c_47034 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_54c_code_47024, _c_47034); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _55update_checksum(_c_47034);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _54c_hputs(object _c_source_47039)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_54c_h_47025, _c_source_47039); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_47039);
    return;
    ;
}


void _54c_puts(object _c_source_47043)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_54c_code_47024, _c_source_47043); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_47043);
    _55update_checksum(_c_source_47043);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_47043);
    return;
    ;
}


void _54c_hprintf(object _format_47048, object _value_47049)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_47049)) {
        _1 = (object)(DBL_PTR(_value_47049)->dbl);
        DeRefDS(_value_47049);
        _value_47049 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_54c_h_47025, _format_47048, _value_47049);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_47048);
    return;
    ;
}


void _54c_printf(object _format_47053, object _value_47054)
{
    object _text_47056 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_47056);
    _text_47056 = EPrintf(-9999999, _format_47053, _value_47054);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_54c_code_47024, _text_47056); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_47056);
    _55update_checksum(_text_47056);
L1: 
    DeRefi(_text_47056);
    _text_47056 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_47053);
    DeRef(_value_47054);
    return;
    ;
}


void _54c_printf8(object _value_47067)
{
    object _buff_47068 = NOVALUE;
    object _neg_47069 = NOVALUE;
    object _p_47070 = NOVALUE;
    object _24467 = NOVALUE;
    object _24466 = NOVALUE;
    object _24465 = NOVALUE;
    object _24463 = NOVALUE;
    object _24462 = NOVALUE;
    object _24460 = NOVALUE;
    object _24459 = NOVALUE;
    object _24457 = NOVALUE;
    object _24456 = NOVALUE;
    object _24454 = NOVALUE;
    object _24452 = NOVALUE;
    object _24450 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [5] 217
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_47069 = 0;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_47068);
    _buff_47068 = EPrintf(-9999999, _24448, _value_47067);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_47068)){
            _24450 = SEQ_PTR(_buff_47068)->length;
    }
    else {
        _24450 = 1;
    }
    if (_24450 >= 10)
    goto L2; // [24] 209

    /** c_out.e:120				p = 1*/
    _p_47070 = 1;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_47068)){
            _24452 = SEQ_PTR(_buff_47068)->length;
    }
    else {
        _24452 = 1;
    }
    if (_p_47070 > _24452)
    goto L4; // [41] 208

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_47068);
    _24454 = (object)*(((s1_ptr)_2)->base + _p_47070);
    if (binary_op_a(NOTEQ, _24454, 45)){
        _24454 = NOVALUE;
        goto L5; // [51] 63
    }
    _24454 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_47069 = 1;
    goto L6; // [60] 197
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_47068);
    _24456 = (object)*(((s1_ptr)_2)->base + _p_47070);
    if (IS_ATOM_INT(_24456)) {
        _24457 = (_24456 == 105);
    }
    else {
        _24457 = binary_op(EQUALS, _24456, 105);
    }
    _24456 = NOVALUE;
    if (IS_ATOM_INT(_24457)) {
        if (_24457 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24457)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_47068);
    _24459 = (object)*(((s1_ptr)_2)->base + _p_47070);
    if (IS_ATOM_INT(_24459)) {
        _24460 = (_24459 == 73);
    }
    else {
        _24460 = binary_op(EQUALS, _24459, 73);
    }
    _24459 = NOVALUE;
    if (_24460 == 0) {
        DeRef(_24460);
        _24460 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24460) && DBL_PTR(_24460)->dbl == 0.0){
            DeRef(_24460);
            _24460 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24460);
        _24460 = NOVALUE;
    }
    DeRef(_24460);
    _24460 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_54CREATE_INF_47059);
    DeRef(_buff_47068);
    _buff_47068 = _54CREATE_INF_47059;

    /** c_out.e:128						if neg then*/
    if (_neg_47069 == 0)
    {
        goto L4; // [97] 208
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_47068, _buff_47068, 45);

    /** c_out.e:131						exit*/
    goto L4; // [109] 208
    goto L6; // [111] 197
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_47068);
    _24462 = (object)*(((s1_ptr)_2)->base + _p_47070);
    if (IS_ATOM_INT(_24462)) {
        _24463 = (_24462 == 110);
    }
    else {
        _24463 = binary_op(EQUALS, _24462, 110);
    }
    _24462 = NOVALUE;
    if (IS_ATOM_INT(_24463)) {
        if (_24463 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24463)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_47068);
    _24465 = (object)*(((s1_ptr)_2)->base + _p_47070);
    if (IS_ATOM_INT(_24465)) {
        _24466 = (_24465 == 78);
    }
    else {
        _24466 = binary_op(EQUALS, _24465, 78);
    }
    _24465 = NOVALUE;
    if (_24466 == 0) {
        DeRef(_24466);
        _24466 = NOVALUE;
        goto LA; // [137] 196
    }
    else {
        if (!IS_ATOM_INT(_24466) && DBL_PTR(_24466)->dbl == 0.0){
            DeRef(_24466);
            _24466 = NOVALUE;
            goto LA; // [137] 196
        }
        DeRef(_24466);
        _24466 = NOVALUE;
    }
    DeRef(_24466);
    _24466 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:141							if sequence(wat_path) then*/
    _24467 = 0;
    if (_24467 == 0)
    {
        _24467 = NOVALUE;
        goto LB; // [150] 173
    }
    else{
        _24467 = NOVALUE;
    }

    /** c_out.e:142								buff = CREATE_NAN2*/
    RefDS(_54CREATE_NAN2_47063);
    DeRef(_buff_47068);
    _buff_47068 = _54CREATE_NAN2_47063;

    /** c_out.e:143								if not neg then*/
    if (_neg_47069 != 0)
    goto L4; // [160] 208

    /** c_out.e:144									buff = prepend(buff, '-')*/
    Prepend(&_buff_47068, _buff_47068, 45);
    goto L4; // [170] 208
LB: 

    /** c_out.e:148								buff = CREATE_NAN1*/
    RefDS(_54CREATE_NAN1_47061);
    DeRef(_buff_47068);
    _buff_47068 = _54CREATE_NAN1_47061;

    /** c_out.e:149								if neg then*/
    if (_neg_47069 == 0)
    {
        goto L4; // [180] 208
    }
    else{
    }

    /** c_out.e:150									buff = prepend(buff, '-')*/
    Prepend(&_buff_47068, _buff_47068, 45);

    /** c_out.e:153							exit*/
    goto L4; // [193] 208
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_47070 = _p_47070 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [205] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_54c_code_47024, _buff_47068); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_47067);
    DeRef(_buff_47068);
    DeRef(_24457);
    _24457 = NOVALUE;
    DeRef(_24463);
    _24463 = NOVALUE;
    return;
    ;
}


void _54adjust_indent_before(object _stmt_47113)
{
    object _i_47114 = NOVALUE;
    object _lb_47116 = NOVALUE;
    object _rb_47117 = NOVALUE;
    object _24484 = NOVALUE;
    object _24482 = NOVALUE;
    object _24480 = NOVALUE;
    object _24474 = NOVALUE;
    object _24473 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_47116 = _9FALSE_439;

    /** c_out.e:178		rb = FALSE*/
    _rb_47117 = _9FALSE_439;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47113)){
            _24473 = SEQ_PTR(_stmt_47113)->length;
    }
    else {
        _24473 = 1;
    }
    {
        object _p_47121;
        _p_47121 = 1;
L1: 
        if (_p_47121 > _24473){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47113);
        _24474 = (object)*(((s1_ptr)_2)->base + _p_47121);
        if (IS_SEQUENCE(_24474) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24474)){
            if( (DBL_PTR(_24474)->dbl != (eudouble) ((object) DBL_PTR(_24474)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24474)->dbl;
        }
        else {
            _0 = _24474;
        };
        _24474 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_47117 = _9TRUE_441;

            /** c_out.e:187					if lb then*/
            if (_lb_47116 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_47116 = _9TRUE_441;

            /** c_out.e:193					if rb then */
            if (_rb_47117 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_47121 = _p_47121 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_47117 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_47116 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _54indent_47107 = _54indent_47107 - 4;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_47114 = _54indent_47107 + _54temp_indent_47108;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_54big_blanks_47109)){
            _24480 = SEQ_PTR(_54big_blanks_47109)->length;
    }
    else {
        _24480 = 1;
    }
    if (_i_47114 < _24480)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_54big_blanks_47109);
    _54c_puts(_54big_blanks_47109);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_54big_blanks_47109)){
            _24482 = SEQ_PTR(_54big_blanks_47109)->length;
    }
    else {
        _24482 = 1;
    }
    _i_47114 = _i_47114 - _24482;
    _24482 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24484;
    RHS_Slice(_54big_blanks_47109, 1, _i_47114);
    _54c_puts(_24484);
    _24484 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _54temp_indent_47108 = 0;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_47113);
    return;
    ;
}


void _54adjust_indent_after(object _stmt_47146)
{
    object _24505 = NOVALUE;
    object _24504 = NOVALUE;
    object _24502 = NOVALUE;
    object _24500 = NOVALUE;
    object _24499 = NOVALUE;
    object _24496 = NOVALUE;
    object _24494 = NOVALUE;
    object _24493 = NOVALUE;
    object _24490 = NOVALUE;
    object _24486 = NOVALUE;
    object _24485 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47146)){
            _24485 = SEQ_PTR(_stmt_47146)->length;
    }
    else {
        _24485 = 1;
    }
    {
        object _p_47148;
        _p_47148 = 1;
L1: 
        if (_p_47148 > _24485){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47146);
        _24486 = (object)*(((s1_ptr)_2)->base + _p_47148);
        if (IS_SEQUENCE(_24486) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24486)){
            if( (DBL_PTR(_24486)->dbl != (eudouble) ((object) DBL_PTR(_24486)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24486)->dbl;
        }
        else {
            _0 = _24486;
        };
        _24486 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _54indent_47107 = _54indent_47107 + 4;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_47146);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_47148 = _p_47148 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_47146)){
            _24490 = SEQ_PTR(_stmt_47146)->length;
    }
    else {
        _24490 = 1;
    }
    if (_24490 >= 3)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_47146);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24493;
    RHS_Slice(_stmt_47146, 1, 3);
    if (_24492 == _24493)
    _24494 = 1;
    else if (IS_ATOM_INT(_24492) && IS_ATOM_INT(_24493))
    _24494 = 0;
    else
    _24494 = (compare(_24492, _24493) == 0);
    DeRefDS(_24493);
    _24493 = NOVALUE;
    if (_24494 != 0)
    goto L5; // [87] 96
    _24494 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_47146);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_47146)){
            _24496 = SEQ_PTR(_stmt_47146)->length;
    }
    else {
        _24496 = 1;
    }
    if (_24496 >= 5)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_47146);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24499;
    RHS_Slice(_stmt_47146, 1, 4);
    if (_24498 == _24499)
    _24500 = 1;
    else if (IS_ATOM_INT(_24498) && IS_ATOM_INT(_24499))
    _24500 = 0;
    else
    _24500 = (compare(_24498, _24499) == 0);
    DeRefDS(_24499);
    _24499 = NOVALUE;
    if (_24500 != 0)
    goto L7; // [122] 131
    _24500 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_47146);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_47146);
    _24502 = (object)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24503);
    ((intptr_t*)_2)[1] = _24503;
    _24504 = MAKE_SEQ(_1);
    _24505 = find_from(_24502, _24504, 1);
    _24502 = NOVALUE;
    DeRefDS(_24504);
    _24504 = NOVALUE;
    if (_24505 != 0)
    goto L8; // [146] 155
    _24505 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_47146);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _54temp_indent_47108 = 4;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_47146);
    return;
    ;
}



// 0xC332544D
