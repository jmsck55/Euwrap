// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _19reverse(object _s_3186)
{
    object _lower_3187 = NOVALUE;
    object _n_3188 = NOVALUE;
    object _n2_3189 = NOVALUE;
    object _t_3190 = NOVALUE;
    object _1452 = NOVALUE;
    object _1451 = NOVALUE;
    object _1450 = NOVALUE;
    object _1447 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:87		n = length(s)*/
    if (IS_SEQUENCE(_s_3186)){
            _n_3188 = SEQ_PTR(_s_3186)->length;
    }
    else {
        _n_3188 = 1;
    }

    /** scinot.e:88		n2 = floor(n/2)+1*/
    _1447 = _n_3188 >> 1;
    _n2_3189 = _1447 + 1;
    _1447 = NOVALUE;

    /** scinot.e:89		t = repeat(0, n)*/
    DeRef(_t_3190);
    _t_3190 = Repeat(0, _n_3188);

    /** scinot.e:90		lower = 1*/
    _lower_3187 = 1;

    /** scinot.e:91		for upper = n to n2 by -1 do*/
    _1450 = _n2_3189;
    {
        object _upper_3196;
        _upper_3196 = _n_3188;
L1: 
        if (_upper_3196 < _1450){
            goto L2; // [34] 74
        }

        /** scinot.e:92			t[upper] = s[lower]*/
        _2 = (object)SEQ_PTR(_s_3186);
        _1451 = (object)*(((s1_ptr)_2)->base + _lower_3187);
        Ref(_1451);
        _2 = (object)SEQ_PTR(_t_3190);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_3190 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _upper_3196);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1451;
        if( _1 != _1451 ){
            DeRef(_1);
        }
        _1451 = NOVALUE;

        /** scinot.e:93			t[lower] = s[upper]*/
        _2 = (object)SEQ_PTR(_s_3186);
        _1452 = (object)*(((s1_ptr)_2)->base + _upper_3196);
        Ref(_1452);
        _2 = (object)SEQ_PTR(_t_3190);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_3190 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lower_3187);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1452;
        if( _1 != _1452 ){
            DeRef(_1);
        }
        _1452 = NOVALUE;

        /** scinot.e:94			lower += 1*/
        _lower_3187 = _lower_3187 + 1;

        /** scinot.e:95		end for*/
        _upper_3196 = _upper_3196 + -1;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** scinot.e:96		return t*/
    DeRefDS(_s_3186);
    return _t_3190;
    ;
}


object _19carry(object _a_3203, object _radix_3204)
{
    object _q_3205 = NOVALUE;
    object _r_3206 = NOVALUE;
    object _b_3207 = NOVALUE;
    object _rmax_3208 = NOVALUE;
    object _i_3209 = NOVALUE;
    object _1466 = NOVALUE;
    object _1465 = NOVALUE;
    object _1464 = NOVALUE;
    object _1461 = NOVALUE;
    object _1455 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:102		rmax = radix - 1*/
    DeRef(_rmax_3208);
    _rmax_3208 = _radix_3204 - 1;
    if ((object)((uintptr_t)_rmax_3208 +(uintptr_t) HIGH_BITS) >= 0){
        _rmax_3208 = NewDouble((eudouble)_rmax_3208);
    }

    /** scinot.e:103		i = 1*/
    DeRef(_i_3209);
    _i_3209 = 1;

    /** scinot.e:104		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_3203)){
            _1455 = SEQ_PTR(_a_3203)->length;
    }
    else {
        _1455 = 1;
    }
    if (binary_op_a(GREATER, _i_3209, _1455)){
        _1455 = NOVALUE;
        goto L2; // [24] 104
    }
    _1455 = NOVALUE;

    /** scinot.e:105			b = a[i]*/
    DeRef(_b_3207);
    _2 = (object)SEQ_PTR(_a_3203);
    if (!IS_ATOM_INT(_i_3209)){
        _b_3207 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_3209)->dbl));
    }
    else{
        _b_3207 = (object)*(((s1_ptr)_2)->base + _i_3209);
    }
    Ref(_b_3207);

    /** scinot.e:106			if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_3207, _rmax_3208)){
        goto L3; // [36] 93
    }

    /** scinot.e:107				q = floor( b / radix )*/
    DeRef(_q_3205);
    if (IS_ATOM_INT(_b_3207)) {
        if (_radix_3204 > 0 && _b_3207 >= 0) {
            _q_3205 = _b_3207 / _radix_3204;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_b_3207 / (eudouble)_radix_3204);
            if (_b_3207 != MININT)
            _q_3205 = (object)temp_dbl;
            else
            _q_3205 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_3207, _radix_3204);
        _q_3205 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** scinot.e:108				r = remainder( b, radix )*/
    DeRef(_r_3206);
    if (IS_ATOM_INT(_b_3207)) {
        _r_3206 = (_b_3207 % _radix_3204);
    }
    else {
        temp_d.dbl = (eudouble)_radix_3204;
        _r_3206 = Dremainder(DBL_PTR(_b_3207), &temp_d);
    }

    /** scinot.e:109				a[i] = r*/
    Ref(_r_3206);
    _2 = (object)SEQ_PTR(_a_3203);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_3203 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_3209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_3209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _i_3209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_3206;
    DeRef(_1);

    /** scinot.e:110				if i = length(a) then*/
    if (IS_SEQUENCE(_a_3203)){
            _1461 = SEQ_PTR(_a_3203)->length;
    }
    else {
        _1461 = 1;
    }
    if (binary_op_a(NOTEQ, _i_3209, _1461)){
        _1461 = NOVALUE;
        goto L4; // [63] 74
    }
    _1461 = NOVALUE;

    /** scinot.e:111					a &= 0*/
    Append(&_a_3203, _a_3203, 0);
L4: 

    /** scinot.e:113				a[i+1] += q*/
    if (IS_ATOM_INT(_i_3209)) {
        _1464 = _i_3209 + 1;
    }
    else
    _1464 = binary_op(PLUS, 1, _i_3209);
    _2 = (object)SEQ_PTR(_a_3203);
    if (!IS_ATOM_INT(_1464)){
        _1465 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_1464)->dbl));
    }
    else{
        _1465 = (object)*(((s1_ptr)_2)->base + _1464);
    }
    if (IS_ATOM_INT(_1465) && IS_ATOM_INT(_q_3205)) {
        _1466 = _1465 + _q_3205;
        if ((object)((uintptr_t)_1466 + (uintptr_t)HIGH_BITS) >= 0){
            _1466 = NewDouble((eudouble)_1466);
        }
    }
    else {
        _1466 = binary_op(PLUS, _1465, _q_3205);
    }
    _1465 = NOVALUE;
    _2 = (object)SEQ_PTR(_a_3203);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_3203 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_1464))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_1464)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _1464);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _1466;
    if( _1 != _1466 ){
        DeRef(_1);
    }
    _1466 = NOVALUE;
L3: 

    /** scinot.e:115			i += 1*/
    _0 = _i_3209;
    if (IS_ATOM_INT(_i_3209)) {
        _i_3209 = _i_3209 + 1;
        if (_i_3209 > MAXINT){
            _i_3209 = NewDouble((eudouble)_i_3209);
        }
    }
    else
    _i_3209 = binary_op(PLUS, 1, _i_3209);
    DeRef(_0);

    /** scinot.e:116		end while*/
    goto L1; // [101] 21
L2: 

    /** scinot.e:118		return a*/
    DeRef(_q_3205);
    DeRef(_r_3206);
    DeRef(_b_3207);
    DeRef(_rmax_3208);
    DeRef(_i_3209);
    DeRef(_1464);
    _1464 = NOVALUE;
    return _a_3203;
    ;
}


object _19add(object _a_3229, object _b_3230)
{
    object _1484 = NOVALUE;
    object _1482 = NOVALUE;
    object _1481 = NOVALUE;
    object _1480 = NOVALUE;
    object _1479 = NOVALUE;
    object _1477 = NOVALUE;
    object _1476 = NOVALUE;
    object _1474 = NOVALUE;
    object _1473 = NOVALUE;
    object _1472 = NOVALUE;
    object _1471 = NOVALUE;
    object _1469 = NOVALUE;
    object _1468 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:123		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_3229)){
            _1468 = SEQ_PTR(_a_3229)->length;
    }
    else {
        _1468 = 1;
    }
    if (IS_SEQUENCE(_b_3230)){
            _1469 = SEQ_PTR(_b_3230)->length;
    }
    else {
        _1469 = 1;
    }
    if (_1468 >= _1469)
    goto L1; // [13] 40

    /** scinot.e:124			a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_3230)){
            _1471 = SEQ_PTR(_b_3230)->length;
    }
    else {
        _1471 = 1;
    }
    if (IS_SEQUENCE(_a_3229)){
            _1472 = SEQ_PTR(_a_3229)->length;
    }
    else {
        _1472 = 1;
    }
    _1473 = _1471 - _1472;
    _1471 = NOVALUE;
    _1472 = NOVALUE;
    _1474 = Repeat(0, _1473);
    _1473 = NOVALUE;
    Concat((object_ptr)&_a_3229, _a_3229, _1474);
    DeRefDS(_1474);
    _1474 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** scinot.e:125		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_3230)){
            _1476 = SEQ_PTR(_b_3230)->length;
    }
    else {
        _1476 = 1;
    }
    if (IS_SEQUENCE(_a_3229)){
            _1477 = SEQ_PTR(_a_3229)->length;
    }
    else {
        _1477 = 1;
    }
    if (_1476 >= _1477)
    goto L3; // [48] 73

    /** scinot.e:126			b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_3229)){
            _1479 = SEQ_PTR(_a_3229)->length;
    }
    else {
        _1479 = 1;
    }
    if (IS_SEQUENCE(_b_3230)){
            _1480 = SEQ_PTR(_b_3230)->length;
    }
    else {
        _1480 = 1;
    }
    _1481 = _1479 - _1480;
    _1479 = NOVALUE;
    _1480 = NOVALUE;
    _1482 = Repeat(0, _1481);
    _1481 = NOVALUE;
    Concat((object_ptr)&_b_3230, _b_3230, _1482);
    DeRefDS(_1482);
    _1482 = NOVALUE;
L3: 
L2: 

    /** scinot.e:129		return a + b*/
    _1484 = binary_op(PLUS, _a_3229, _b_3230);
    DeRefDS(_a_3229);
    DeRefDS(_b_3230);
    return _1484;
    ;
}


object _19borrow(object _a_3252, object _radix_3253)
{
    object _1492 = NOVALUE;
    object _1491 = NOVALUE;
    object _1490 = NOVALUE;
    object _1489 = NOVALUE;
    object _1488 = NOVALUE;
    object _1486 = NOVALUE;
    object _1485 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:134		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_3252)){
            _1485 = SEQ_PTR(_a_3252)->length;
    }
    else {
        _1485 = 1;
    }
    {
        object _i_3255;
        _i_3255 = _1485;
L1: 
        if (_i_3255 < 2){
            goto L2; // [10] 67
        }

        /** scinot.e:135			if a[i] < 0 then*/
        _2 = (object)SEQ_PTR(_a_3252);
        _1486 = (object)*(((s1_ptr)_2)->base + _i_3255);
        if (binary_op_a(GREATEREQ, _1486, 0)){
            _1486 = NOVALUE;
            goto L3; // [23] 60
        }
        _1486 = NOVALUE;

        /** scinot.e:136				a[i] += radix*/
        _2 = (object)SEQ_PTR(_a_3252);
        _1488 = (object)*(((s1_ptr)_2)->base + _i_3255);
        if (IS_ATOM_INT(_1488)) {
            _1489 = _1488 + _radix_3253;
            if ((object)((uintptr_t)_1489 + (uintptr_t)HIGH_BITS) >= 0){
                _1489 = NewDouble((eudouble)_1489);
            }
        }
        else {
            _1489 = binary_op(PLUS, _1488, _radix_3253);
        }
        _1488 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_3252);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_3252 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_3255);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1489;
        if( _1 != _1489 ){
            DeRef(_1);
        }
        _1489 = NOVALUE;

        /** scinot.e:137				a[i-1] -= 1*/
        _1490 = _i_3255 - 1;
        _2 = (object)SEQ_PTR(_a_3252);
        _1491 = (object)*(((s1_ptr)_2)->base + _1490);
        if (IS_ATOM_INT(_1491)) {
            _1492 = _1491 - 1;
            if ((object)((uintptr_t)_1492 +(uintptr_t) HIGH_BITS) >= 0){
                _1492 = NewDouble((eudouble)_1492);
            }
        }
        else {
            _1492 = binary_op(MINUS, _1491, 1);
        }
        _1491 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_3252);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_3252 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1490);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1492;
        if( _1 != _1492 ){
            DeRef(_1);
        }
        _1492 = NOVALUE;
L3: 

        /** scinot.e:139		end for*/
        _i_3255 = _i_3255 + -1;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** scinot.e:140		return a*/
    DeRef(_1490);
    _1490 = NOVALUE;
    return _a_3252;
    ;
}


object _19bits_to_bytes(object _bits_3267)
{
    object _bytes_3268 = NOVALUE;
    object _r_3269 = NOVALUE;
    object _1501 = NOVALUE;
    object _1500 = NOVALUE;
    object _1499 = NOVALUE;
    object _1498 = NOVALUE;
    object _1496 = NOVALUE;
    object _1495 = NOVALUE;
    object _1493 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:155		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_3267)){
            _1493 = SEQ_PTR(_bits_3267)->length;
    }
    else {
        _1493 = 1;
    }
    _r_3269 = (_1493 % 8);
    _1493 = NOVALUE;

    /** scinot.e:156		if r  then*/
    if (_r_3269 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** scinot.e:157			bits &= repeat( 0, 8 - r )*/
    _1495 = 8 - _r_3269;
    _1496 = Repeat(0, _1495);
    _1495 = NOVALUE;
    Concat((object_ptr)&_bits_3267, _bits_3267, _1496);
    DeRefDS(_1496);
    _1496 = NOVALUE;
L1: 

    /** scinot.e:160		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_3268);
    _bytes_3268 = _5;

    /** scinot.e:161		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_3267)){
            _1498 = SEQ_PTR(_bits_3267)->length;
    }
    else {
        _1498 = 1;
    }
    {
        object _i_3277;
        _i_3277 = 1;
L2: 
        if (_i_3277 > _1498){
            goto L3; // [44] 77
        }

        /** scinot.e:162			bytes &= bits_to_int( bits[i..i+7] )*/
        _1499 = _i_3277 + 7;
        rhs_slice_target = (object_ptr)&_1500;
        RHS_Slice(_bits_3267, _i_3277, _1499);
        _1501 = _13bits_to_int(_1500);
        _1500 = NOVALUE;
        if (IS_SEQUENCE(_bytes_3268) && IS_ATOM(_1501)) {
            Ref(_1501);
            Append(&_bytes_3268, _bytes_3268, _1501);
        }
        else if (IS_ATOM(_bytes_3268) && IS_SEQUENCE(_1501)) {
        }
        else {
            Concat((object_ptr)&_bytes_3268, _bytes_3268, _1501);
        }
        DeRef(_1501);
        _1501 = NOVALUE;

        /** scinot.e:163		end for*/
        _i_3277 = _i_3277 + 8;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** scinot.e:164		return bytes*/
    DeRefDS(_bits_3267);
    DeRef(_1499);
    _1499 = NOVALUE;
    return _bytes_3268;
    ;
}


object _19bytes_to_bits(object _bytes_3286)
{
    object _bits_3287 = NOVALUE;
    object _1505 = NOVALUE;
    object _1504 = NOVALUE;
    object _1503 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:179		bits = {}*/
    RefDS(_5);
    DeRef(_bits_3287);
    _bits_3287 = _5;

    /** scinot.e:180		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_3286)){
            _1503 = SEQ_PTR(_bytes_3286)->length;
    }
    else {
        _1503 = 1;
    }
    {
        object _i_3289;
        _i_3289 = 1;
L1: 
        if (_i_3289 > _1503){
            goto L2; // [15] 44
        }

        /** scinot.e:181			bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (object)SEQ_PTR(_bytes_3286);
        _1504 = (object)*(((s1_ptr)_2)->base + _i_3289);
        Ref(_1504);
        _1505 = _13int_to_bits(_1504, 8);
        _1504 = NOVALUE;
        if (IS_SEQUENCE(_bits_3287) && IS_ATOM(_1505)) {
            Ref(_1505);
            Append(&_bits_3287, _bits_3287, _1505);
        }
        else if (IS_ATOM(_bits_3287) && IS_SEQUENCE(_1505)) {
        }
        else {
            Concat((object_ptr)&_bits_3287, _bits_3287, _1505);
        }
        DeRef(_1505);
        _1505 = NOVALUE;

        /** scinot.e:182		end for*/
        _i_3289 = _i_3289 + 1;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** scinot.e:184		return bits*/
    DeRefDS(_bytes_3286);
    return _bits_3287;
    ;
}


object _19convert_radix(object _number_3297, object _from_radix_3298, object _to_radix_3299)
{
    object _target_3300 = NOVALUE;
    object _base_3301 = NOVALUE;
    object _1512 = NOVALUE;
    object _1511 = NOVALUE;
    object _1510 = NOVALUE;
    object _1509 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:190		base = {1}*/
    RefDS(_1507);
    DeRef(_base_3301);
    _base_3301 = _1507;

    /** scinot.e:191		target = {0}*/
    _0 = _target_3300;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _target_3300 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scinot.e:192		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_3297)){
            _1509 = SEQ_PTR(_number_3297)->length;
    }
    else {
        _1509 = 1;
    }
    {
        object _i_3305;
        _i_3305 = 1;
L1: 
        if (_i_3305 > _1509){
            goto L2; // [25] 78
        }

        /** scinot.e:193			target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (object)SEQ_PTR(_number_3297);
        _1510 = (object)*(((s1_ptr)_2)->base + _i_3305);
        _1511 = binary_op(MULTIPLY, _base_3301, _1510);
        _1510 = NOVALUE;
        RefDS(_target_3300);
        _1512 = _19add(_1511, _target_3300);
        _1511 = NOVALUE;
        _0 = _target_3300;
        _target_3300 = _19carry(_1512, _to_radix_3299);
        DeRefDS(_0);
        _1512 = NOVALUE;

        /** scinot.e:194			base *= from_radix*/
        _0 = _base_3301;
        _base_3301 = binary_op(MULTIPLY, _base_3301, _from_radix_3298);
        DeRefDS(_0);

        /** scinot.e:195			base = carry( base, to_radix )*/
        RefDS(_base_3301);
        _0 = _base_3301;
        _base_3301 = _19carry(_base_3301, _to_radix_3299);
        DeRefDS(_0);

        /** scinot.e:196		end for*/
        _i_3305 = _i_3305 + 1;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** scinot.e:198		return target*/
    DeRefDS(_number_3297);
    DeRef(_base_3301);
    return _target_3300;
    ;
}


object _19half(object _decimal_3315)
{
    object _quotient_3316 = NOVALUE;
    object _q_3317 = NOVALUE;
    object _Q_3318 = NOVALUE;
    object _1533 = NOVALUE;
    object _1532 = NOVALUE;
    object _1531 = NOVALUE;
    object _1530 = NOVALUE;
    object _1529 = NOVALUE;
    object _1528 = NOVALUE;
    object _1525 = NOVALUE;
    object _1523 = NOVALUE;
    object _1522 = NOVALUE;
    object _1519 = NOVALUE;
    object _1518 = NOVALUE;
    object _1516 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:205		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_3315)){
            _1516 = SEQ_PTR(_decimal_3315)->length;
    }
    else {
        _1516 = 1;
    }
    DeRef(_quotient_3316);
    _quotient_3316 = Repeat(0, _1516);
    _1516 = NOVALUE;

    /** scinot.e:206		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_3315)){
            _1518 = SEQ_PTR(_decimal_3315)->length;
    }
    else {
        _1518 = 1;
    }
    {
        object _i_3322;
        _i_3322 = 1;
L1: 
        if (_i_3322 > _1518){
            goto L2; // [17] 101
        }

        /** scinot.e:207			q = decimal[i] / 2*/
        _2 = (object)SEQ_PTR(_decimal_3315);
        _1519 = (object)*(((s1_ptr)_2)->base + _i_3322);
        DeRef(_q_3317);
        if (IS_ATOM_INT(_1519)) {
            if (_1519 & 1) {
                _q_3317 = NewDouble((_1519 >> 1) + 0.5);
            }
            else
            _q_3317 = _1519 >> 1;
        }
        else {
            _q_3317 = binary_op(DIVIDE, _1519, 2);
        }
        _1519 = NOVALUE;

        /** scinot.e:208			Q = floor( q )*/
        DeRef(_Q_3318);
        if (IS_ATOM_INT(_q_3317))
        _Q_3318 = e_floor(_q_3317);
        else
        _Q_3318 = unary_op(FLOOR, _q_3317);

        /** scinot.e:209			quotient[i] +=  Q*/
        _2 = (object)SEQ_PTR(_quotient_3316);
        _1522 = (object)*(((s1_ptr)_2)->base + _i_3322);
        if (IS_ATOM_INT(_1522) && IS_ATOM_INT(_Q_3318)) {
            _1523 = _1522 + _Q_3318;
            if ((object)((uintptr_t)_1523 + (uintptr_t)HIGH_BITS) >= 0){
                _1523 = NewDouble((eudouble)_1523);
            }
        }
        else {
            _1523 = binary_op(PLUS, _1522, _Q_3318);
        }
        _1522 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_3316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_3316 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_3322);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1523;
        if( _1 != _1523 ){
            DeRef(_1);
        }
        _1523 = NOVALUE;

        /** scinot.e:211			if q != Q then*/
        if (binary_op_a(EQUALS, _q_3317, _Q_3318)){
            goto L3; // [55] 94
        }

        /** scinot.e:212				if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_3316)){
                _1525 = SEQ_PTR(_quotient_3316)->length;
        }
        else {
            _1525 = 1;
        }
        if (_1525 != _i_3322)
        goto L4; // [64] 75

        /** scinot.e:213					quotient &= 0*/
        Append(&_quotient_3316, _quotient_3316, 0);
L4: 

        /** scinot.e:215				quotient[i+1] += 5*/
        _1528 = _i_3322 + 1;
        _2 = (object)SEQ_PTR(_quotient_3316);
        _1529 = (object)*(((s1_ptr)_2)->base + _1528);
        if (IS_ATOM_INT(_1529)) {
            _1530 = _1529 + 5;
            if ((object)((uintptr_t)_1530 + (uintptr_t)HIGH_BITS) >= 0){
                _1530 = NewDouble((eudouble)_1530);
            }
        }
        else {
            _1530 = binary_op(PLUS, _1529, 5);
        }
        _1529 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_3316);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_3316 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1528);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1530;
        if( _1 != _1530 ){
            DeRef(_1);
        }
        _1530 = NOVALUE;
L3: 

        /** scinot.e:217		end for*/
        _i_3322 = _i_3322 + 1;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** scinot.e:218		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_3316);
    _1531 = _19reverse(_quotient_3316);
    _1532 = _19carry(_1531, 10);
    _1531 = NOVALUE;
    _1533 = _19reverse(_1532);
    _1532 = NOVALUE;
    DeRefDS(_decimal_3315);
    DeRefDS(_quotient_3316);
    DeRef(_q_3317);
    DeRef(_Q_3318);
    DeRef(_1528);
    _1528 = NOVALUE;
    return _1533;
    ;
}


object _19decimals_to_bits(object _decimals_3351, object _size_3352)
{
    object _sub_3353 = NOVALUE;
    object _bits_3354 = NOVALUE;
    object _bit_3355 = NOVALUE;
    object _assigned_3356 = NOVALUE;
    object _1561 = NOVALUE;
    object _1557 = NOVALUE;
    object _1556 = NOVALUE;
    object _1555 = NOVALUE;
    object _1554 = NOVALUE;
    object _1552 = NOVALUE;
    object _1551 = NOVALUE;
    object _1550 = NOVALUE;
    object _1548 = NOVALUE;
    object _1546 = NOVALUE;
    object _1545 = NOVALUE;
    object _1544 = NOVALUE;
    object _1543 = NOVALUE;
    object _1542 = NOVALUE;
    object _1540 = NOVALUE;
    object _1538 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:233		sub = {5}*/
    RefDS(_1536);
    DeRef(_sub_3353);
    _sub_3353 = _1536;

    /** scinot.e:234		bits = repeat( 0, size )*/
    DeRef(_bits_3354);
    _bits_3354 = Repeat(0, _size_3352);

    /** scinot.e:235		bit = 1*/
    _bit_3355 = 1;

    /** scinot.e:236		assigned = 0*/
    _assigned_3356 = 0;

    /** scinot.e:240		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_3351) && IS_ATOM_INT(_bits_3354)){
        _1538 = (_decimals_3351 < _bits_3354) ? -1 : (_decimals_3351 > _bits_3354);
    }
    else{
        _1538 = compare(_decimals_3351, _bits_3354);
    }
    if (_1538 <= 0)
    goto L1; // [34] 166

    /** scinot.e:242			while (not assigned) or (bit < find( 1, bits ) + size + 1)  do*/
L2: 
    _1540 = (_assigned_3356 == 0);
    if (_1540 != 0) {
        goto L3; // [46] 72
    }
    _1542 = find_from(1, _bits_3354, 1);
    _1543 = _1542 + _size_3352;
    if ((object)((uintptr_t)_1543 + (uintptr_t)HIGH_BITS) >= 0){
        _1543 = NewDouble((eudouble)_1543);
    }
    _1542 = NOVALUE;
    if (IS_ATOM_INT(_1543)) {
        _1544 = _1543 + 1;
        if (_1544 > MAXINT){
            _1544 = NewDouble((eudouble)_1544);
        }
    }
    else
    _1544 = binary_op(PLUS, 1, _1543);
    DeRef(_1543);
    _1543 = NOVALUE;
    if (IS_ATOM_INT(_1544)) {
        _1545 = (_bit_3355 < _1544);
    }
    else {
        _1545 = ((eudouble)_bit_3355 < DBL_PTR(_1544)->dbl);
    }
    DeRef(_1544);
    _1544 = NOVALUE;
    if (_1545 == 0)
    {
        DeRef(_1545);
        _1545 = NOVALUE;
        goto L4; // [68] 165
    }
    else{
        DeRef(_1545);
        _1545 = NOVALUE;
    }
L3: 

    /** scinot.e:243				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_3353) && IS_ATOM_INT(_decimals_3351)){
        _1546 = (_sub_3353 < _decimals_3351) ? -1 : (_sub_3353 > _decimals_3351);
    }
    else{
        _1546 = compare(_sub_3353, _decimals_3351);
    }
    if (_1546 > 0)
    goto L5; // [78] 146

    /** scinot.e:244					assigned = 1*/
    _assigned_3356 = 1;

    /** scinot.e:245					if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_3354)){
            _1548 = SEQ_PTR(_bits_3354)->length;
    }
    else {
        _1548 = 1;
    }
    if (_1548 >= _bit_3355)
    goto L6; // [92] 114

    /** scinot.e:246						bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_3354)){
            _1550 = SEQ_PTR(_bits_3354)->length;
    }
    else {
        _1550 = 1;
    }
    _1551 = _bit_3355 - _1550;
    _1550 = NOVALUE;
    _1552 = Repeat(0, _1551);
    _1551 = NOVALUE;
    Concat((object_ptr)&_bits_3354, _bits_3354, _1552);
    DeRefDS(_1552);
    _1552 = NOVALUE;
L6: 

    /** scinot.e:249					bits[bit] += 1*/
    _2 = (object)SEQ_PTR(_bits_3354);
    _1554 = (object)*(((s1_ptr)_2)->base + _bit_3355);
    if (IS_ATOM_INT(_1554)) {
        _1555 = _1554 + 1;
        if (_1555 > MAXINT){
            _1555 = NewDouble((eudouble)_1555);
        }
    }
    else
    _1555 = binary_op(PLUS, 1, _1554);
    _1554 = NOVALUE;
    _2 = (object)SEQ_PTR(_bits_3354);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bits_3354 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _bit_3355);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _1555;
    if( _1 != _1555 ){
        DeRef(_1);
    }
    _1555 = NOVALUE;

    /** scinot.e:250					decimals = borrow( add( decimals, -sub ), 10 )*/
    _1556 = unary_op(UMINUS, _sub_3353);
    RefDS(_decimals_3351);
    _1557 = _19add(_decimals_3351, _1556);
    _1556 = NOVALUE;
    _0 = _decimals_3351;
    _decimals_3351 = _19borrow(_1557, 10);
    DeRefDS(_0);
    _1557 = NOVALUE;
L5: 

    /** scinot.e:252				sub = half( sub )*/
    RefDS(_sub_3353);
    _0 = _sub_3353;
    _sub_3353 = _19half(_sub_3353);
    DeRefDS(_0);

    /** scinot.e:254				bit += 1*/
    _bit_3355 = _bit_3355 + 1;

    /** scinot.e:255			end while*/
    goto L2; // [162] 43
L4: 
L1: 

    /** scinot.e:258		return reverse(bits)*/
    RefDS(_bits_3354);
    _1561 = _19reverse(_bits_3354);
    DeRefDS(_decimals_3351);
    DeRef(_sub_3353);
    DeRefDS(_bits_3354);
    DeRef(_1540);
    _1540 = NOVALUE;
    return _1561;
    ;
}


object _19string_to_int(object _s_3389)
{
    object _int_3390 = NOVALUE;
    object _1565 = NOVALUE;
    object _1564 = NOVALUE;
    object _1562 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:263		int = 0*/
    _int_3390 = 0;

    /** scinot.e:264		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_3389)){
            _1562 = SEQ_PTR(_s_3389)->length;
    }
    else {
        _1562 = 1;
    }
    {
        object _i_3392;
        _i_3392 = 1;
L1: 
        if (_i_3392 > _1562){
            goto L2; // [13] 51
        }

        /** scinot.e:265			int *= 10*/
        _int_3390 = _int_3390 * 10;

        /** scinot.e:266			int += s[i] - '0'*/
        _2 = (object)SEQ_PTR(_s_3389);
        _1564 = (object)*(((s1_ptr)_2)->base + _i_3392);
        if (IS_ATOM_INT(_1564)) {
            _1565 = _1564 - 48;
            if ((object)((uintptr_t)_1565 +(uintptr_t) HIGH_BITS) >= 0){
                _1565 = NewDouble((eudouble)_1565);
            }
        }
        else {
            _1565 = binary_op(MINUS, _1564, 48);
        }
        _1564 = NOVALUE;
        if (IS_ATOM_INT(_1565)) {
            _int_3390 = _int_3390 + _1565;
        }
        else {
            _int_3390 = binary_op(PLUS, _int_3390, _1565);
        }
        DeRef(_1565);
        _1565 = NOVALUE;
        if (!IS_ATOM_INT(_int_3390)) {
            _1 = (object)(DBL_PTR(_int_3390)->dbl);
            DeRefDS(_int_3390);
            _int_3390 = _1;
        }

        /** scinot.e:267		end for*/
        _i_3392 = _i_3392 + 1;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** scinot.e:268		return int*/
    DeRefDS(_s_3389);
    return _int_3390;
    ;
}


object _19trim_bits(object _bits_3400)
{
    object _1572 = NOVALUE;
    object _1571 = NOVALUE;
    object _1570 = NOVALUE;
    object _1569 = NOVALUE;
    object _1568 = NOVALUE;
    object _1567 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:272			while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_3400)){
            _1567 = SEQ_PTR(_bits_3400)->length;
    }
    else {
        _1567 = 1;
    }
    if (_1567 == 0) {
        goto L2; // [11] 44
    }
    if (IS_SEQUENCE(_bits_3400)){
            _1569 = SEQ_PTR(_bits_3400)->length;
    }
    else {
        _1569 = 1;
    }
    _2 = (object)SEQ_PTR(_bits_3400);
    _1570 = (object)*(((s1_ptr)_2)->base + _1569);
    if (IS_ATOM_INT(_1570)) {
        _1571 = (_1570 == 0);
    }
    else {
        _1571 = unary_op(NOT, _1570);
    }
    _1570 = NOVALUE;
    if (_1571 <= 0) {
        if (_1571 == 0) {
            DeRef(_1571);
            _1571 = NOVALUE;
            goto L2; // [26] 44
        }
        else {
            if (!IS_ATOM_INT(_1571) && DBL_PTR(_1571)->dbl == 0.0){
                DeRef(_1571);
                _1571 = NOVALUE;
                goto L2; // [26] 44
            }
            DeRef(_1571);
            _1571 = NOVALUE;
        }
    }
    DeRef(_1571);
    _1571 = NOVALUE;

    /** scinot.e:273				bits = remove( bits, length( bits ) )*/
    if (IS_SEQUENCE(_bits_3400)){
            _1572 = SEQ_PTR(_bits_3400)->length;
    }
    else {
        _1572 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_bits_3400);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_1572)) ? _1572 : (object)(DBL_PTR(_1572)->dbl);
        int stop = (IS_ATOM_INT(_1572)) ? _1572 : (object)(DBL_PTR(_1572)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_bits_3400), start, &_bits_3400 );
            }
            else Tail(SEQ_PTR(_bits_3400), stop+1, &_bits_3400);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_bits_3400), start, &_bits_3400);
        }
        else {
            assign_slice_seq = &assign_space;
            _bits_3400 = Remove_elements(start, stop, (SEQ_PTR(_bits_3400)->ref == 1));
        }
    }
    _1572 = NOVALUE;
    _1572 = NOVALUE;

    /** scinot.e:274			end while*/
    goto L1; // [41] 8
L2: 

    /** scinot.e:275			return bits*/
    return _bits_3400;
    ;
}


object _19scientific_to_float(object _s_3423, object _fp_3424)
{
    object _dp_3425 = NOVALUE;
    object _e_3426 = NOVALUE;
    object _exp_3427 = NOVALUE;
    object _int_bits_3428 = NOVALUE;
    object _frac_bits_3429 = NOVALUE;
    object _mbits_3430 = NOVALUE;
    object _ebits_3431 = NOVALUE;
    object _sbits_3432 = NOVALUE;
    object _significand_3433 = NOVALUE;
    object _exponent_3434 = NOVALUE;
    object _min_exp_3435 = NOVALUE;
    object _exp_bias_3436 = NOVALUE;
    object _1731 = NOVALUE;
    object _1730 = NOVALUE;
    object _1728 = NOVALUE;
    object _1726 = NOVALUE;
    object _1725 = NOVALUE;
    object _1723 = NOVALUE;
    object _1722 = NOVALUE;
    object _1721 = NOVALUE;
    object _1720 = NOVALUE;
    object _1719 = NOVALUE;
    object _1718 = NOVALUE;
    object _1717 = NOVALUE;
    object _1715 = NOVALUE;
    object _1714 = NOVALUE;
    object _1712 = NOVALUE;
    object _1711 = NOVALUE;
    object _1710 = NOVALUE;
    object _1709 = NOVALUE;
    object _1706 = NOVALUE;
    object _1705 = NOVALUE;
    object _1704 = NOVALUE;
    object _1703 = NOVALUE;
    object _1702 = NOVALUE;
    object _1701 = NOVALUE;
    object _1700 = NOVALUE;
    object _1699 = NOVALUE;
    object _1696 = NOVALUE;
    object _1695 = NOVALUE;
    object _1692 = NOVALUE;
    object _1691 = NOVALUE;
    object _1690 = NOVALUE;
    object _1689 = NOVALUE;
    object _1686 = NOVALUE;
    object _1685 = NOVALUE;
    object _1683 = NOVALUE;
    object _1682 = NOVALUE;
    object _1680 = NOVALUE;
    object _1678 = NOVALUE;
    object _1677 = NOVALUE;
    object _1676 = NOVALUE;
    object _1675 = NOVALUE;
    object _1674 = NOVALUE;
    object _1673 = NOVALUE;
    object _1672 = NOVALUE;
    object _1671 = NOVALUE;
    object _1670 = NOVALUE;
    object _1669 = NOVALUE;
    object _1667 = NOVALUE;
    object _1666 = NOVALUE;
    object _1665 = NOVALUE;
    object _1664 = NOVALUE;
    object _1662 = NOVALUE;
    object _1661 = NOVALUE;
    object _1660 = NOVALUE;
    object _1659 = NOVALUE;
    object _1656 = NOVALUE;
    object _1654 = NOVALUE;
    object _1653 = NOVALUE;
    object _1652 = NOVALUE;
    object _1651 = NOVALUE;
    object _1650 = NOVALUE;
    object _1648 = NOVALUE;
    object _1647 = NOVALUE;
    object _1646 = NOVALUE;
    object _1645 = NOVALUE;
    object _1644 = NOVALUE;
    object _1643 = NOVALUE;
    object _1641 = NOVALUE;
    object _1640 = NOVALUE;
    object _1639 = NOVALUE;
    object _1638 = NOVALUE;
    object _1637 = NOVALUE;
    object _1635 = NOVALUE;
    object _1634 = NOVALUE;
    object _1632 = NOVALUE;
    object _1631 = NOVALUE;
    object _1630 = NOVALUE;
    object _1629 = NOVALUE;
    object _1628 = NOVALUE;
    object _1626 = NOVALUE;
    object _1624 = NOVALUE;
    object _1621 = NOVALUE;
    object _1620 = NOVALUE;
    object _1618 = NOVALUE;
    object _1617 = NOVALUE;
    object _1615 = NOVALUE;
    object _1611 = NOVALUE;
    object _1610 = NOVALUE;
    object _1609 = NOVALUE;
    object _1608 = NOVALUE;
    object _1606 = NOVALUE;
    object _1605 = NOVALUE;
    object _1604 = NOVALUE;
    object _1603 = NOVALUE;
    object _1601 = NOVALUE;
    object _1600 = NOVALUE;
    object _1598 = NOVALUE;
    object _1597 = NOVALUE;
    object _1596 = NOVALUE;
    object _1595 = NOVALUE;
    object _1593 = NOVALUE;
    object _1592 = NOVALUE;
    object _1585 = NOVALUE;
    object _1581 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:316		if fp = NATIVE then*/
    if (_fp_3424 != 1)
    goto L1; // [5] 17

    /** scinot.e:317			fp = NATIVE_FORMAT*/
    _fp_3424 = _19NATIVE_FORMAT_3178;
L1: 

    /** scinot.e:319		if fp = DOUBLE then*/
    if (_fp_3424 != 2)
    goto L2; // [19] 46

    /** scinot.e:320			significand = DOUBLE_SIGNIFICAND*/
    _significand_3433 = 52;

    /** scinot.e:321			exponent    = DOUBLE_EXPONENT*/
    _exponent_3434 = 11;

    /** scinot.e:322			min_exp     = DOUBLE_MIN_EXP*/
    _min_exp_3435 = -1023;

    /** scinot.e:323			exp_bias    = DOUBLE_EXP_BIAS*/
    _exp_bias_3436 = 1023;
    goto L3; // [43] 74
L2: 

    /** scinot.e:325		elsif fp = EXTENDED then*/
    if (_fp_3424 != 3)
    goto L4; // [48] 73

    /** scinot.e:326			significand = EXTENDED_SIGNIFICAND*/
    _significand_3433 = 64;

    /** scinot.e:327			exponent    = EXTENDED_EXPONENT*/
    _exponent_3434 = 15;

    /** scinot.e:328			min_exp     = EXTENDED_MIN_EXP*/
    _min_exp_3435 = -16383;

    /** scinot.e:329			exp_bias    = EXTENDED_EXP_BIAS*/
    _exp_bias_3436 = 16383;
L4: 
L3: 

    /** scinot.e:333		if s[1] = '-' then*/
    _2 = (object)SEQ_PTR(_s_3423);
    _1581 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _1581, 45)){
        _1581 = NOVALUE;
        goto L5; // [80] 101
    }
    _1581 = NOVALUE;

    /** scinot.e:334			sbits = {1}*/
    RefDS(_1507);
    DeRefi(_sbits_3432);
    _sbits_3432 = _1507;

    /** scinot.e:335			s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_3423);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_3423), start, &_s_3423 );
            }
            else Tail(SEQ_PTR(_s_3423), stop+1, &_s_3423);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_3423), start, &_s_3423);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_3423 = Remove_elements(start, stop, (SEQ_PTR(_s_3423)->ref == 1));
        }
    }
    goto L6; // [98] 126
L5: 

    /** scinot.e:337			sbits = {0}*/
    _0 = _sbits_3432;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _sbits_3432 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** scinot.e:338			if s[1] = '+' then*/
    _2 = (object)SEQ_PTR(_s_3423);
    _1585 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _1585, 43)){
        _1585 = NOVALUE;
        goto L7; // [113] 125
    }
    _1585 = NOVALUE;

    /** scinot.e:339				s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_3423);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_3423), start, &_s_3423 );
            }
            else Tail(SEQ_PTR(_s_3423), stop+1, &_s_3423);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_3423), start, &_s_3423);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_3423 = Remove_elements(start, stop, (SEQ_PTR(_s_3423)->ref == 1));
        }
    }
L7: 
L6: 

    /** scinot.e:344		dp = find('.', s)*/
    _dp_3425 = find_from(46, _s_3423, 1);

    /** scinot.e:345		e = find( 'e', s )*/
    _e_3426 = find_from(101, _s_3423, 1);

    /** scinot.e:346		if not e then*/
    if (_e_3426 != 0)
    goto L8; // [142] 153

    /** scinot.e:347			e = find('E', s )*/
    _e_3426 = find_from(69, _s_3423, 1);
L8: 

    /** scinot.e:351		exp = 0*/
    _exp_3427 = 0;

    /** scinot.e:352		if s[e+1] = '-' then*/
    _1592 = _e_3426 + 1;
    _2 = (object)SEQ_PTR(_s_3423);
    _1593 = (object)*(((s1_ptr)_2)->base + _1592);
    if (binary_op_a(NOTEQ, _1593, 45)){
        _1593 = NOVALUE;
        goto L9; // [168] 199
    }
    _1593 = NOVALUE;

    /** scinot.e:353			exp -= string_to_int( s[e+2..$] )*/
    _1595 = _e_3426 + 2;
    if ((object)((uintptr_t)_1595 + (uintptr_t)HIGH_BITS) >= 0){
        _1595 = NewDouble((eudouble)_1595);
    }
    if (IS_SEQUENCE(_s_3423)){
            _1596 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1596 = 1;
    }
    rhs_slice_target = (object_ptr)&_1597;
    RHS_Slice(_s_3423, _1595, _1596);
    _1598 = _19string_to_int(_1597);
    _1597 = NOVALUE;
    if (IS_ATOM_INT(_1598)) {
        _exp_3427 = _exp_3427 - _1598;
    }
    else {
        _exp_3427 = binary_op(MINUS, _exp_3427, _1598);
    }
    DeRef(_1598);
    _1598 = NOVALUE;
    if (!IS_ATOM_INT(_exp_3427)) {
        _1 = (object)(DBL_PTR(_exp_3427)->dbl);
        DeRefDS(_exp_3427);
        _exp_3427 = _1;
    }
    goto LA; // [196] 266
L9: 

    /** scinot.e:356			if s[e+1] = '+' then*/
    _1600 = _e_3426 + 1;
    _2 = (object)SEQ_PTR(_s_3423);
    _1601 = (object)*(((s1_ptr)_2)->base + _1600);
    if (binary_op_a(NOTEQ, _1601, 43)){
        _1601 = NOVALUE;
        goto LB; // [209] 240
    }
    _1601 = NOVALUE;

    /** scinot.e:357				exp += string_to_int( s[e+2..$] )*/
    _1603 = _e_3426 + 2;
    if ((object)((uintptr_t)_1603 + (uintptr_t)HIGH_BITS) >= 0){
        _1603 = NewDouble((eudouble)_1603);
    }
    if (IS_SEQUENCE(_s_3423)){
            _1604 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1604 = 1;
    }
    rhs_slice_target = (object_ptr)&_1605;
    RHS_Slice(_s_3423, _1603, _1604);
    _1606 = _19string_to_int(_1605);
    _1605 = NOVALUE;
    if (IS_ATOM_INT(_1606)) {
        _exp_3427 = _exp_3427 + _1606;
    }
    else {
        _exp_3427 = binary_op(PLUS, _exp_3427, _1606);
    }
    DeRef(_1606);
    _1606 = NOVALUE;
    if (!IS_ATOM_INT(_exp_3427)) {
        _1 = (object)(DBL_PTR(_exp_3427)->dbl);
        DeRefDS(_exp_3427);
        _exp_3427 = _1;
    }
    goto LC; // [237] 265
LB: 

    /** scinot.e:359				exp += string_to_int( s[e+1..$] )*/
    _1608 = _e_3426 + 1;
    if (_1608 > MAXINT){
        _1608 = NewDouble((eudouble)_1608);
    }
    if (IS_SEQUENCE(_s_3423)){
            _1609 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1609 = 1;
    }
    rhs_slice_target = (object_ptr)&_1610;
    RHS_Slice(_s_3423, _1608, _1609);
    _1611 = _19string_to_int(_1610);
    _1610 = NOVALUE;
    if (IS_ATOM_INT(_1611)) {
        _exp_3427 = _exp_3427 + _1611;
    }
    else {
        _exp_3427 = binary_op(PLUS, _exp_3427, _1611);
    }
    DeRef(_1611);
    _1611 = NOVALUE;
    if (!IS_ATOM_INT(_exp_3427)) {
        _1 = (object)(DBL_PTR(_exp_3427)->dbl);
        DeRefDS(_exp_3427);
        _exp_3427 = _1;
    }
LC: 
LA: 

    /** scinot.e:363		if dp then*/
    if (_dp_3425 == 0)
    {
        goto LD; // [268] 297
    }
    else{
    }

    /** scinot.e:365			s = remove( s, dp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_3423);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_dp_3425)) ? _dp_3425 : (object)(DBL_PTR(_dp_3425)->dbl);
        int stop = (IS_ATOM_INT(_dp_3425)) ? _dp_3425 : (object)(DBL_PTR(_dp_3425)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_3423), start, &_s_3423 );
            }
            else Tail(SEQ_PTR(_s_3423), stop+1, &_s_3423);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_3423), start, &_s_3423);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_3423 = Remove_elements(start, stop, (SEQ_PTR(_s_3423)->ref == 1));
        }
    }

    /** scinot.e:366			e -= 1*/
    _e_3426 = _e_3426 - 1;

    /** scinot.e:369			exp -= e - dp*/
    _1615 = _e_3426 - _dp_3425;
    if ((object)((uintptr_t)_1615 +(uintptr_t) HIGH_BITS) >= 0){
        _1615 = NewDouble((eudouble)_1615);
    }
    if (IS_ATOM_INT(_1615)) {
        _exp_3427 = _exp_3427 - _1615;
    }
    else {
        _exp_3427 = NewDouble((eudouble)_exp_3427 - DBL_PTR(_1615)->dbl);
    }
    DeRef(_1615);
    _1615 = NOVALUE;
    if (!IS_ATOM_INT(_exp_3427)) {
        _1 = (object)(DBL_PTR(_exp_3427)->dbl);
        DeRefDS(_exp_3427);
        _exp_3427 = _1;
    }
LD: 

    /** scinot.e:374		s = s[1..e-1] - '0'*/
    _1617 = _e_3426 - 1;
    rhs_slice_target = (object_ptr)&_1618;
    RHS_Slice(_s_3423, 1, _1617);
    DeRefDS(_s_3423);
    _s_3423 = binary_op(MINUS, _1618, 48);
    DeRefDS(_1618);
    _1618 = NOVALUE;

    /** scinot.e:377		if not find(0, s = 0) then*/
    _1620 = binary_op(EQUALS, _s_3423, 0);
    _1621 = find_from(0, _1620, 1);
    DeRefDS(_1620);
    _1620 = NOVALUE;
    if (_1621 != 0)
    goto LE; // [325] 366
    _1621 = NOVALUE;

    /** scinot.e:378			if fp = DOUBLE then*/
    if (_fp_3424 != 2)
    goto LF; // [330] 347

    /** scinot.e:379				return atom_to_float64(0)*/
    _1624 = _13atom_to_float64(0);
    DeRefDS(_s_3423);
    DeRef(_int_bits_3428);
    DeRef(_frac_bits_3429);
    DeRef(_mbits_3430);
    DeRef(_ebits_3431);
    DeRefi(_sbits_3432);
    DeRef(_1603);
    _1603 = NOVALUE;
    DeRef(_1595);
    _1595 = NOVALUE;
    _1617 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1592);
    _1592 = NOVALUE;
    DeRef(_1608);
    _1608 = NOVALUE;
    return _1624;
    goto L10; // [344] 365
LF: 

    /** scinot.e:380			elsif fp = EXTENDED then*/
    if (_fp_3424 != 3)
    goto L11; // [349] 364

    /** scinot.e:381				return atom_to_float80(0)*/
    _1626 = _13atom_to_float80(0);
    DeRefDS(_s_3423);
    DeRef(_int_bits_3428);
    DeRef(_frac_bits_3429);
    DeRef(_mbits_3430);
    DeRef(_ebits_3431);
    DeRefi(_sbits_3432);
    DeRef(_1624);
    _1624 = NOVALUE;
    DeRef(_1603);
    _1603 = NOVALUE;
    DeRef(_1595);
    _1595 = NOVALUE;
    DeRef(_1617);
    _1617 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1592);
    _1592 = NOVALUE;
    DeRef(_1608);
    _1608 = NOVALUE;
    return _1626;
L11: 
L10: 
LE: 

    /** scinot.e:385		if exp >= 0 then*/
    if (_exp_3427 < 0)
    goto L12; // [368] 412

    /** scinot.e:388			int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _1628 = Repeat(0, _exp_3427);
    RefDS(_s_3423);
    _1629 = _19reverse(_s_3423);
    if (IS_SEQUENCE(_1628) && IS_ATOM(_1629)) {
        Ref(_1629);
        Append(&_1630, _1628, _1629);
    }
    else if (IS_ATOM(_1628) && IS_SEQUENCE(_1629)) {
    }
    else {
        Concat((object_ptr)&_1630, _1628, _1629);
        DeRefDS(_1628);
        _1628 = NOVALUE;
    }
    DeRef(_1628);
    _1628 = NOVALUE;
    DeRef(_1629);
    _1629 = NOVALUE;
    _1631 = _19convert_radix(_1630, 10, 256);
    _1630 = NOVALUE;
    _1632 = _19bytes_to_bits(_1631);
    _1631 = NOVALUE;
    _0 = _int_bits_3428;
    _int_bits_3428 = _19trim_bits(_1632);
    DeRef(_0);
    _1632 = NOVALUE;

    /** scinot.e:389			frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_3429);
    _frac_bits_3429 = _5;
    goto L13; // [409] 529
L12: 

    /** scinot.e:391			if -exp > length(s) then*/
    if ((uintptr_t)_exp_3427 == (uintptr_t)HIGH_BITS){
        _1634 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _1634 = - _exp_3427;
    }
    if (IS_SEQUENCE(_s_3423)){
            _1635 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1635 = 1;
    }
    if (binary_op_a(LESSEQ, _1634, _1635)){
        DeRef(_1634);
        _1634 = NOVALUE;
        _1635 = NOVALUE;
        goto L14; // [420] 463
    }
    DeRef(_1634);
    _1634 = NOVALUE;
    _1635 = NOVALUE;

    /** scinot.e:393				int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_3428);
    _int_bits_3428 = _5;

    /** scinot.e:394				frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s, significand ) */
    if ((uintptr_t)_exp_3427 == (uintptr_t)HIGH_BITS){
        _1637 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _1637 = - _exp_3427;
    }
    if (IS_SEQUENCE(_s_3423)){
            _1638 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1638 = 1;
    }
    if (IS_ATOM_INT(_1637)) {
        _1639 = _1637 - _1638;
    }
    else {
        _1639 = NewDouble(DBL_PTR(_1637)->dbl - (eudouble)_1638);
    }
    DeRef(_1637);
    _1637 = NOVALUE;
    _1638 = NOVALUE;
    _1640 = Repeat(0, _1639);
    DeRef(_1639);
    _1639 = NOVALUE;
    Concat((object_ptr)&_1641, _1640, _s_3423);
    DeRefDS(_1640);
    _1640 = NOVALUE;
    DeRef(_1640);
    _1640 = NOVALUE;
    _0 = _frac_bits_3429;
    _frac_bits_3429 = _19decimals_to_bits(_1641, _significand_3433);
    DeRef(_0);
    _1641 = NOVALUE;
    goto L15; // [460] 528
L14: 

    /** scinot.e:398				int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_3423)){
            _1643 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1643 = 1;
    }
    _1644 = _1643 + _exp_3427;
    _1643 = NOVALUE;
    rhs_slice_target = (object_ptr)&_1645;
    RHS_Slice(_s_3423, 1, _1644);
    _1646 = _19reverse(_1645);
    _1645 = NOVALUE;
    _1647 = _19convert_radix(_1646, 10, 256);
    _1646 = NOVALUE;
    _1648 = _19bytes_to_bits(_1647);
    _1647 = NOVALUE;
    _0 = _int_bits_3428;
    _int_bits_3428 = _19trim_bits(_1648);
    DeRef(_0);
    _1648 = NOVALUE;

    /** scinot.e:399				frac_bits =  decimals_to_bits( s[$+exp+1..$], significand )*/
    if (IS_SEQUENCE(_s_3423)){
            _1650 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1650 = 1;
    }
    _1651 = _1650 + _exp_3427;
    if ((object)((uintptr_t)_1651 + (uintptr_t)HIGH_BITS) >= 0){
        _1651 = NewDouble((eudouble)_1651);
    }
    _1650 = NOVALUE;
    if (IS_ATOM_INT(_1651)) {
        _1652 = _1651 + 1;
        if (_1652 > MAXINT){
            _1652 = NewDouble((eudouble)_1652);
        }
    }
    else
    _1652 = binary_op(PLUS, 1, _1651);
    DeRef(_1651);
    _1651 = NOVALUE;
    if (IS_SEQUENCE(_s_3423)){
            _1653 = SEQ_PTR(_s_3423)->length;
    }
    else {
        _1653 = 1;
    }
    rhs_slice_target = (object_ptr)&_1654;
    RHS_Slice(_s_3423, _1652, _1653);
    _0 = _frac_bits_3429;
    _frac_bits_3429 = _19decimals_to_bits(_1654, _significand_3433);
    DeRef(_0);
    _1654 = NOVALUE;
L15: 
L13: 

    /** scinot.e:403		if length(int_bits) > significand then*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1656 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1656 = 1;
    }
    if (_1656 <= _significand_3433)
    goto L16; // [538] 668

    /** scinot.e:406			if fp = DOUBLE then*/
    if (_fp_3424 != 2)
    goto L17; // [544] 572

    /** scinot.e:408				mbits = int_bits[$-significand..$-1]*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1659 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1659 = 1;
    }
    _1660 = _1659 - _significand_3433;
    if ((object)((uintptr_t)_1660 +(uintptr_t) HIGH_BITS) >= 0){
        _1660 = NewDouble((eudouble)_1660);
    }
    _1659 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_3428)){
            _1661 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1661 = 1;
    }
    _1662 = _1661 - 1;
    _1661 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_3430;
    RHS_Slice(_int_bits_3428, _1660, _1662);
    goto L18; // [569] 594
L17: 

    /** scinot.e:411				mbits = int_bits[$-significand+1..$]*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1664 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1664 = 1;
    }
    _1665 = _1664 - _significand_3433;
    if ((object)((uintptr_t)_1665 +(uintptr_t) HIGH_BITS) >= 0){
        _1665 = NewDouble((eudouble)_1665);
    }
    _1664 = NOVALUE;
    if (IS_ATOM_INT(_1665)) {
        _1666 = _1665 + 1;
        if (_1666 > MAXINT){
            _1666 = NewDouble((eudouble)_1666);
        }
    }
    else
    _1666 = binary_op(PLUS, 1, _1665);
    DeRef(_1665);
    _1665 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_3428)){
            _1667 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1667 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_3430;
    RHS_Slice(_int_bits_3428, _1666, _1667);
L18: 

    /** scinot.e:414			if length(int_bits) > significand + 1 and int_bits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1669 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1669 = 1;
    }
    _1670 = _significand_3433 + 1;
    if (_1670 > MAXINT){
        _1670 = NewDouble((eudouble)_1670);
    }
    if (IS_ATOM_INT(_1670)) {
        _1671 = (_1669 > _1670);
    }
    else {
        _1671 = ((eudouble)_1669 > DBL_PTR(_1670)->dbl);
    }
    _1669 = NOVALUE;
    DeRef(_1670);
    _1670 = NOVALUE;
    if (_1671 == 0) {
        goto L19; // [607] 656
    }
    if (IS_SEQUENCE(_int_bits_3428)){
            _1673 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1673 = 1;
    }
    _1674 = _significand_3433 + 1;
    if (_1674 > MAXINT){
        _1674 = NewDouble((eudouble)_1674);
    }
    if (IS_ATOM_INT(_1674)) {
        _1675 = _1673 - _1674;
    }
    else {
        _1675 = NewDouble((eudouble)_1673 - DBL_PTR(_1674)->dbl);
    }
    _1673 = NOVALUE;
    DeRef(_1674);
    _1674 = NOVALUE;
    _2 = (object)SEQ_PTR(_int_bits_3428);
    if (!IS_ATOM_INT(_1675)){
        _1676 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_1675)->dbl));
    }
    else{
        _1676 = (object)*(((s1_ptr)_2)->base + _1675);
    }
    if (_1676 == 0) {
        _1676 = NOVALUE;
        goto L19; // [627] 656
    }
    else {
        if (!IS_ATOM_INT(_1676) && DBL_PTR(_1676)->dbl == 0.0){
            _1676 = NOVALUE;
            goto L19; // [627] 656
        }
        _1676 = NOVALUE;
    }
    _1676 = NOVALUE;

    /** scinot.e:416				mbits[1] += 1*/
    _2 = (object)SEQ_PTR(_mbits_3430);
    _1677 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1677)) {
        _1678 = _1677 + 1;
        if (_1678 > MAXINT){
            _1678 = NewDouble((eudouble)_1678);
        }
    }
    else
    _1678 = binary_op(PLUS, 1, _1677);
    _1677 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_3430 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _1678;
    if( _1 != _1678 ){
        DeRef(_1);
    }
    _1678 = NOVALUE;

    /** scinot.e:417				mbits = carry( mbits, 2 )*/
    RefDS(_mbits_3430);
    _0 = _mbits_3430;
    _mbits_3430 = _19carry(_mbits_3430, 2);
    DeRefDS(_0);
L19: 

    /** scinot.e:419			exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1680 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1680 = 1;
    }
    _exp_3427 = _1680 - 1;
    _1680 = NOVALUE;
    goto L1A; // [665] 940
L16: 

    /** scinot.e:422			if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1682 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1682 = 1;
    }
    if (_1682 == 0)
    {
        _1682 = NOVALUE;
        goto L1B; // [673] 688
    }
    else{
        _1682 = NOVALUE;
    }

    /** scinot.e:424				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_3428)){
            _1683 = SEQ_PTR(_int_bits_3428)->length;
    }
    else {
        _1683 = 1;
    }
    _exp_3427 = _1683 - 1;
    _1683 = NOVALUE;
    goto L1C; // [685] 748
L1B: 

    /** scinot.e:428				exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_3429);
    _1685 = _19reverse(_frac_bits_3429);
    _1686 = find_from(1, _1685, 1);
    DeRef(_1685);
    _1685 = NOVALUE;
    _exp_3427 = - _1686;

    /** scinot.e:429				if exp < min_exp then*/
    if (_exp_3427 >= _min_exp_3435)
    goto L1D; // [710] 720

    /** scinot.e:432					exp = min_exp*/
    _exp_3427 = _min_exp_3435;
L1D: 

    /** scinot.e:435				if exp then*/
    if (_exp_3427 == 0)
    {
        goto L1E; // [722] 747
    }
    else{
    }

    /** scinot.e:437					frac_bits = remove( frac_bits, length(frac_bits) + exp + 2, length( frac_bits ) )*/
    if (IS_SEQUENCE(_frac_bits_3429)){
            _1689 = SEQ_PTR(_frac_bits_3429)->length;
    }
    else {
        _1689 = 1;
    }
    _1690 = _1689 + _exp_3427;
    if ((object)((uintptr_t)_1690 + (uintptr_t)HIGH_BITS) >= 0){
        _1690 = NewDouble((eudouble)_1690);
    }
    _1689 = NOVALUE;
    if (IS_ATOM_INT(_1690)) {
        _1691 = _1690 + 2;
        if ((object)((uintptr_t)_1691 + (uintptr_t)HIGH_BITS) >= 0){
            _1691 = NewDouble((eudouble)_1691);
        }
    }
    else {
        _1691 = NewDouble(DBL_PTR(_1690)->dbl + (eudouble)2);
    }
    DeRef(_1690);
    _1690 = NOVALUE;
    if (IS_SEQUENCE(_frac_bits_3429)){
            _1692 = SEQ_PTR(_frac_bits_3429)->length;
    }
    else {
        _1692 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_frac_bits_3429);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_1691)) ? _1691 : (object)(DBL_PTR(_1691)->dbl);
        int stop = (IS_ATOM_INT(_1692)) ? _1692 : (object)(DBL_PTR(_1692)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_frac_bits_3429), start, &_frac_bits_3429 );
            }
            else Tail(SEQ_PTR(_frac_bits_3429), stop+1, &_frac_bits_3429);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_frac_bits_3429), start, &_frac_bits_3429);
        }
        else {
            assign_slice_seq = &assign_space;
            _frac_bits_3429 = Remove_elements(start, stop, (SEQ_PTR(_frac_bits_3429)->ref == 1));
        }
    }
    DeRef(_1691);
    _1691 = NOVALUE;
    _1692 = NOVALUE;
L1E: 
L1C: 

    /** scinot.e:444			mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_3430, _frac_bits_3429, _int_bits_3428);

    /** scinot.e:445			mbits = repeat( 0, significand + 1 ) & mbits*/
    _1695 = _significand_3433 + 1;
    _1696 = Repeat(0, _1695);
    _1695 = NOVALUE;
    Concat((object_ptr)&_mbits_3430, _1696, _mbits_3430);
    DeRefDS(_1696);
    _1696 = NOVALUE;
    DeRef(_1696);
    _1696 = NOVALUE;

    /** scinot.e:447			if exp > min_exp then*/
    if (_exp_3427 <= _min_exp_3435)
    goto L1F; // [774] 877

    /** scinot.e:449				if mbits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1699 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1699 = 1;
    }
    _1700 = _significand_3433 + 1;
    if (_1700 > MAXINT){
        _1700 = NewDouble((eudouble)_1700);
    }
    if (IS_ATOM_INT(_1700)) {
        _1701 = _1699 - _1700;
    }
    else {
        _1701 = NewDouble((eudouble)_1699 - DBL_PTR(_1700)->dbl);
    }
    _1699 = NOVALUE;
    DeRef(_1700);
    _1700 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    if (!IS_ATOM_INT(_1701)){
        _1702 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_1701)->dbl));
    }
    else{
        _1702 = (object)*(((s1_ptr)_2)->base + _1701);
    }
    if (_1702 == 0) {
        _1702 = NOVALUE;
        goto L20; // [795] 829
    }
    else {
        if (!IS_ATOM_INT(_1702) && DBL_PTR(_1702)->dbl == 0.0){
            _1702 = NOVALUE;
            goto L20; // [795] 829
        }
        _1702 = NOVALUE;
    }
    _1702 = NOVALUE;

    /** scinot.e:451					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1703 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1703 = 1;
    }
    _1704 = _1703 - _significand_3433;
    _1703 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    _1705 = (object)*(((s1_ptr)_2)->base + _1704);
    if (IS_ATOM_INT(_1705)) {
        _1706 = _1705 + 1;
        if (_1706 > MAXINT){
            _1706 = NewDouble((eudouble)_1706);
        }
    }
    else
    _1706 = binary_op(PLUS, 1, _1705);
    _1705 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_3430 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _1704);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _1706;
    if( _1 != _1706 ){
        DeRef(_1);
    }
    _1706 = NOVALUE;

    /** scinot.e:452					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_3430);
    _0 = _mbits_3430;
    _mbits_3430 = _19carry(_mbits_3430, 2);
    DeRefDS(_0);
L20: 

    /** scinot.e:454				if fp = DOUBLE then*/
    if (_fp_3424 != 2)
    goto L21; // [831] 859

    /** scinot.e:456					mbits = mbits[$-significand..$-1]*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1709 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1709 = 1;
    }
    _1710 = _1709 - _significand_3433;
    if ((object)((uintptr_t)_1710 +(uintptr_t) HIGH_BITS) >= 0){
        _1710 = NewDouble((eudouble)_1710);
    }
    _1709 = NOVALUE;
    if (IS_SEQUENCE(_mbits_3430)){
            _1711 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1711 = 1;
    }
    _1712 = _1711 - 1;
    _1711 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_3430;
    RHS_Slice(_mbits_3430, _1710, _1712);
    goto L22; // [856] 939
L21: 

    /** scinot.e:459					mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1714 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1714 = 1;
    }
    _1715 = _1714 - _significand_3433;
    if ((object)((uintptr_t)_1715 +(uintptr_t) HIGH_BITS) >= 0){
        _1715 = NewDouble((eudouble)_1715);
    }
    _1714 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_3430);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(_1715)) ? _1715 : (object)(DBL_PTR(_1715)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_3430), start, &_mbits_3430 );
            }
            else Tail(SEQ_PTR(_mbits_3430), stop+1, &_mbits_3430);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_3430), start, &_mbits_3430);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_3430 = Remove_elements(start, stop, (SEQ_PTR(_mbits_3430)->ref == 1));
        }
    }
    DeRef(_1715);
    _1715 = NOVALUE;
    goto L22; // [874] 939
L1F: 

    /** scinot.e:463				if mbits[$-significand] then*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1717 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1717 = 1;
    }
    _1718 = _1717 - _significand_3433;
    _1717 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    _1719 = (object)*(((s1_ptr)_2)->base + _1718);
    if (_1719 == 0) {
        _1719 = NOVALUE;
        goto L23; // [890] 924
    }
    else {
        if (!IS_ATOM_INT(_1719) && DBL_PTR(_1719)->dbl == 0.0){
            _1719 = NOVALUE;
            goto L23; // [890] 924
        }
        _1719 = NOVALUE;
    }
    _1719 = NOVALUE;

    /** scinot.e:465					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1720 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1720 = 1;
    }
    _1721 = _1720 - _significand_3433;
    _1720 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    _1722 = (object)*(((s1_ptr)_2)->base + _1721);
    if (IS_ATOM_INT(_1722)) {
        _1723 = _1722 + 1;
        if (_1723 > MAXINT){
            _1723 = NewDouble((eudouble)_1723);
        }
    }
    else
    _1723 = binary_op(PLUS, 1, _1722);
    _1722 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_3430);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_3430 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _1721);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _1723;
    if( _1 != _1723 ){
        DeRef(_1);
    }
    _1723 = NOVALUE;

    /** scinot.e:466					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_3430);
    _0 = _mbits_3430;
    _mbits_3430 = _19carry(_mbits_3430, 2);
    DeRefDS(_0);
L23: 

    /** scinot.e:468				mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_3430)){
            _1725 = SEQ_PTR(_mbits_3430)->length;
    }
    else {
        _1725 = 1;
    }
    _1726 = _1725 - _significand_3433;
    if ((object)((uintptr_t)_1726 +(uintptr_t) HIGH_BITS) >= 0){
        _1726 = NewDouble((eudouble)_1726);
    }
    _1725 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_3430);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(_1726)) ? _1726 : (object)(DBL_PTR(_1726)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_3430), start, &_mbits_3430 );
            }
            else Tail(SEQ_PTR(_mbits_3430), stop+1, &_mbits_3430);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_3430), start, &_mbits_3430);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_3430 = Remove_elements(start, stop, (SEQ_PTR(_mbits_3430)->ref == 1));
        }
    }
    DeRef(_1726);
    _1726 = NOVALUE;
L22: 
L1A: 

    /** scinot.e:474		ebits = int_to_bits( exp + exp_bias, exponent )*/
    _1728 = _exp_3427 + _exp_bias_3436;
    if ((object)((uintptr_t)_1728 + (uintptr_t)HIGH_BITS) >= 0){
        _1728 = NewDouble((eudouble)_1728);
    }
    _0 = _ebits_3431;
    _ebits_3431 = _13int_to_bits(_1728, _exponent_3434);
    DeRef(_0);
    _1728 = NOVALUE;

    /** scinot.e:477		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        object concat_list[3];

        concat_list[0] = _sbits_3432;
        concat_list[1] = _ebits_3431;
        concat_list[2] = _mbits_3430;
        Concat_N((object_ptr)&_1730, concat_list, 3);
    }
    _1731 = _19bits_to_bytes(_1730);
    _1730 = NOVALUE;
    DeRefDS(_s_3423);
    DeRef(_int_bits_3428);
    DeRef(_frac_bits_3429);
    DeRefDS(_mbits_3430);
    DeRefDS(_ebits_3431);
    DeRefDSi(_sbits_3432);
    DeRef(_1704);
    _1704 = NOVALUE;
    DeRef(_1701);
    _1701 = NOVALUE;
    DeRef(_1666);
    _1666 = NOVALUE;
    DeRef(_1624);
    _1624 = NOVALUE;
    DeRef(_1710);
    _1710 = NOVALUE;
    DeRef(_1603);
    _1603 = NOVALUE;
    DeRef(_1595);
    _1595 = NOVALUE;
    DeRef(_1617);
    _1617 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1671);
    _1671 = NOVALUE;
    DeRef(_1660);
    _1660 = NOVALUE;
    DeRef(_1652);
    _1652 = NOVALUE;
    DeRef(_1662);
    _1662 = NOVALUE;
    DeRef(_1721);
    _1721 = NOVALUE;
    DeRef(_1592);
    _1592 = NOVALUE;
    DeRef(_1644);
    _1644 = NOVALUE;
    DeRef(_1675);
    _1675 = NOVALUE;
    DeRef(_1626);
    _1626 = NOVALUE;
    DeRef(_1608);
    _1608 = NOVALUE;
    DeRef(_1712);
    _1712 = NOVALUE;
    DeRef(_1718);
    _1718 = NOVALUE;
    return _1731;
    ;
}


object _19scientific_to_atom(object _s_3630, object _fp_3631)
{
    object _float_3634 = NOVALUE;
    object _1737 = NOVALUE;
    object _1735 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:495		if fp = NATIVE then*/
    if (_fp_3631 != 1)
    goto L1; // [5] 17

    /** scinot.e:496			fp = NATIVE_FORMAT*/
    _fp_3631 = _19NATIVE_FORMAT_3178;
L1: 

    /** scinot.e:498		sequence float = scientific_to_float( s, fp )*/
    RefDS(_s_3630);
    _0 = _float_3634;
    _float_3634 = _19scientific_to_float(_s_3630, _fp_3631);
    DeRef(_0);

    /** scinot.e:499		if fp = DOUBLE then*/
    if (_fp_3631 != 2)
    goto L2; // [28] 45

    /** scinot.e:500			return float64_to_atom( float )*/
    RefDS(_float_3634);
    _1735 = _13float64_to_atom(_float_3634);
    DeRefDS(_s_3630);
    DeRefDS(_float_3634);
    return _1735;
    goto L3; // [42] 63
L2: 

    /** scinot.e:501		elsif fp = EXTENDED then*/
    if (_fp_3631 != 3)
    goto L4; // [47] 62

    /** scinot.e:502			return float80_to_atom( float )*/
    RefDS(_float_3634);
    _1737 = _13float80_to_atom(_float_3634);
    DeRefDS(_s_3630);
    DeRefDS(_float_3634);
    DeRef(_1735);
    _1735 = NOVALUE;
    return _1737;
L4: 
L3: 
    ;
}



// 0xE31865A4
