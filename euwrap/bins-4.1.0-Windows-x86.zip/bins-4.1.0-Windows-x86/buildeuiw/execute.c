// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67new_arg_assign()
{
    object _0, _1, _2;
    

    /** execute.e:81		arg_assign += 1*/
    _0 = _67arg_assign_65199;
    if (IS_ATOM_INT(_67arg_assign_65199)) {
        _67arg_assign_65199 = _67arg_assign_65199 + 1;
        if (_67arg_assign_65199 > MAXINT){
            _67arg_assign_65199 = NewDouble((eudouble)_67arg_assign_65199);
        }
    }
    else
    _67arg_assign_65199 = binary_op(PLUS, 1, _67arg_assign_65199);
    DeRef(_0);

    /** execute.e:82		return arg_assign*/
    Ref(_67arg_assign_65199);
    return _67arg_assign_65199;
    ;
}


void _67open_err_file()
{
    object _32101 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:187		err_file = open(err_file_name, "w")*/
    _67err_file_65304 = EOpen(_67err_file_name_65305, _22345, 0);

    /** execute.e:188		if err_file = -1 then*/
    if (_67err_file_65304 != -1)
    goto L1; // [14] 36

    /** execute.e:189			puts(2, "Can't open " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_65305;
        concat_list[2] = _32100;
        Concat_N((object_ptr)&_32101, concat_list, 3);
    }
    EPuts(2, _32101); // DJP 
    DeRefDS(_32101);
    _32101 = NOVALUE;

    /** execute.e:190			abort(1)*/
    UserCleanup(1);
L1: 

    /** execute.e:192	end procedure*/
    return;
    ;
}


void _67both_puts(object _s_65318)
{
    object _0, _1, _2;
    

    /** execute.e:198		if screen_err_out then*/
    if (_67screen_err_out_65315 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** execute.e:199			puts(2, s)*/
    EPuts(2, _s_65318); // DJP 
L1: 

    /** execute.e:201		puts(err_file, s)*/
    EPuts(_67err_file_65304, _s_65318); // DJP 

    /** execute.e:202	end procedure*/
    DeRef(_s_65318);
    return;
    ;
}


void _67both_printf(object _format_65322, object _items_65323)
{
    object _0, _1, _2;
    

    /** execute.e:206		if screen_err_out then*/
    if (_67screen_err_out_65315 == 0)
    {
        goto L1; // [9] 19
    }
    else{
    }

    /** execute.e:207			printf(2, format, items)*/
    EPrintf(2, _format_65322, _items_65323);
L1: 

    /** execute.e:209		printf(err_file, format, items)*/
    EPrintf(_67err_file_65304, _format_65322, _items_65323);

    /** execute.e:210	end procedure*/
    DeRefDSi(_format_65322);
    DeRefDS(_items_65323);
    return;
    ;
}


object _67find_line(object _sub_65328, object _pc_65329)
{
    object _linetab_65330 = NOVALUE;
    object _line_65331 = NOVALUE;
    object _gline_65332 = NOVALUE;
    object _32125 = NOVALUE;
    object _32124 = NOVALUE;
    object _32123 = NOVALUE;
    object _32122 = NOVALUE;
    object _32121 = NOVALUE;
    object _32120 = NOVALUE;
    object _32118 = NOVALUE;
    object _32117 = NOVALUE;
    object _32116 = NOVALUE;
    object _32114 = NOVALUE;
    object _32113 = NOVALUE;
    object _32112 = NOVALUE;
    object _32111 = NOVALUE;
    object _32109 = NOVALUE;
    object _32108 = NOVALUE;
    object _32106 = NOVALUE;
    object _32105 = NOVALUE;
    object _32104 = NOVALUE;
    object _32102 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:217		linetab = SymTab[sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32102 = (object)*(((s1_ptr)_2)->base + _sub_65328);
    DeRef(_linetab_65330);
    _2 = (object)SEQ_PTR(_32102);
    if (!IS_ATOM_INT(_27S_LINETAB_20244)){
        _linetab_65330 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    }
    else{
        _linetab_65330 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    }
    Ref(_linetab_65330);
    _32102 = NOVALUE;

    /** execute.e:218		line = 1*/
    _line_65331 = 1;

    /** execute.e:219		for i = 1 to length(linetab) do*/
    if (IS_SEQUENCE(_linetab_65330)){
            _32104 = SEQ_PTR(_linetab_65330)->length;
    }
    else {
        _32104 = 1;
    }
    {
        object _i_65338;
        _i_65338 = 1;
L1: 
        if (_i_65338 > _32104){
            goto L2; // [31] 119
        }

        /** execute.e:220			if linetab[i] >= pc or linetab[i] = -2 then*/
        _2 = (object)SEQ_PTR(_linetab_65330);
        _32105 = (object)*(((s1_ptr)_2)->base + _i_65338);
        if (IS_ATOM_INT(_32105)) {
            _32106 = (_32105 >= _pc_65329);
        }
        else {
            _32106 = binary_op(GREATEREQ, _32105, _pc_65329);
        }
        _32105 = NOVALUE;
        if (IS_ATOM_INT(_32106)) {
            if (_32106 != 0) {
                goto L3; // [48] 65
            }
        }
        else {
            if (DBL_PTR(_32106)->dbl != 0.0) {
                goto L3; // [48] 65
            }
        }
        _2 = (object)SEQ_PTR(_linetab_65330);
        _32108 = (object)*(((s1_ptr)_2)->base + _i_65338);
        if (IS_ATOM_INT(_32108)) {
            _32109 = (_32108 == -2);
        }
        else {
            _32109 = binary_op(EQUALS, _32108, -2);
        }
        _32108 = NOVALUE;
        if (_32109 == 0) {
            DeRef(_32109);
            _32109 = NOVALUE;
            goto L4; // [61] 112
        }
        else {
            if (!IS_ATOM_INT(_32109) && DBL_PTR(_32109)->dbl == 0.0){
                DeRef(_32109);
                _32109 = NOVALUE;
                goto L4; // [61] 112
            }
            DeRef(_32109);
            _32109 = NOVALUE;
        }
        DeRef(_32109);
        _32109 = NOVALUE;
L3: 

        /** execute.e:221				line = i-1*/
        _line_65331 = _i_65338 - 1;

        /** execute.e:222				while line > 1 and linetab[line] = -1 do*/
L5: 
        _32111 = (_line_65331 > 1);
        if (_32111 == 0) {
            goto L2; // [80] 119
        }
        _2 = (object)SEQ_PTR(_linetab_65330);
        _32113 = (object)*(((s1_ptr)_2)->base + _line_65331);
        if (IS_ATOM_INT(_32113)) {
            _32114 = (_32113 == -1);
        }
        else {
            _32114 = binary_op(EQUALS, _32113, -1);
        }
        _32113 = NOVALUE;
        if (_32114 <= 0) {
            if (_32114 == 0) {
                DeRef(_32114);
                _32114 = NOVALUE;
                goto L2; // [93] 119
            }
            else {
                if (!IS_ATOM_INT(_32114) && DBL_PTR(_32114)->dbl == 0.0){
                    DeRef(_32114);
                    _32114 = NOVALUE;
                    goto L2; // [93] 119
                }
                DeRef(_32114);
                _32114 = NOVALUE;
            }
        }
        DeRef(_32114);
        _32114 = NOVALUE;

        /** execute.e:223					line -= 1*/
        _line_65331 = _line_65331 - 1;

        /** execute.e:224				end while*/
        goto L5; // [104] 76

        /** execute.e:225				exit*/
        goto L2; // [109] 119
L4: 

        /** execute.e:227		end for*/
        _i_65338 = _i_65338 + 1;
        goto L1; // [114] 38
L2: 
        ;
    }

    /** execute.e:228		gline = SymTab[sub][S_FIRSTLINE] + line - 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32116 = (object)*(((s1_ptr)_2)->base + _sub_65328);
    _2 = (object)SEQ_PTR(_32116);
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249)){
        _32117 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    }
    else{
        _32117 = (object)*(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    }
    _32116 = NOVALUE;
    if (IS_ATOM_INT(_32117)) {
        _32118 = _32117 + _line_65331;
        if ((object)((uintptr_t)_32118 + (uintptr_t)HIGH_BITS) >= 0){
            _32118 = NewDouble((eudouble)_32118);
        }
    }
    else {
        _32118 = binary_op(PLUS, _32117, _line_65331);
    }
    _32117 = NOVALUE;
    if (IS_ATOM_INT(_32118)) {
        _gline_65332 = _32118 - 1;
    }
    else {
        _gline_65332 = binary_op(MINUS, _32118, 1);
    }
    DeRef(_32118);
    _32118 = NOVALUE;
    if (!IS_ATOM_INT(_gline_65332)) {
        _1 = (object)(DBL_PTR(_gline_65332)->dbl);
        DeRefDS(_gline_65332);
        _gline_65332 = _1;
    }

    /** execute.e:229		return {known_files[slist[gline][LOCAL_FILE_NO]], slist[gline][LINE]}*/
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32120 = (object)*(((s1_ptr)_2)->base + _gline_65332);
    _2 = (object)SEQ_PTR(_32120);
    _32121 = (object)*(((s1_ptr)_2)->base + 3);
    _32120 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!IS_ATOM_INT(_32121)){
        _32122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32121)->dbl));
    }
    else{
        _32122 = (object)*(((s1_ptr)_2)->base + _32121);
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32123 = (object)*(((s1_ptr)_2)->base + _gline_65332);
    _2 = (object)SEQ_PTR(_32123);
    _32124 = (object)*(((s1_ptr)_2)->base + 2);
    _32123 = NOVALUE;
    Ref(_32124);
    Ref(_32122);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32122;
    ((intptr_t *)_2)[2] = _32124;
    _32125 = MAKE_SEQ(_1);
    _32124 = NOVALUE;
    _32122 = NOVALUE;
    DeRef(_linetab_65330);
    DeRef(_32106);
    _32106 = NOVALUE;
    DeRef(_32111);
    _32111 = NOVALUE;
    _32121 = NOVALUE;
    return _32125;
    ;
}


void _67show_var(object _x_65373)
{
    object _32139 = NOVALUE;
    object _32136 = NOVALUE;
    object _32135 = NOVALUE;
    object _32134 = NOVALUE;
    object _32133 = NOVALUE;
    object _32132 = NOVALUE;
    object _32130 = NOVALUE;
    object _32129 = NOVALUE;
    object _32128 = NOVALUE;
    object _32127 = NOVALUE;
    object _32126 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:235		puts(err_file, "    " & SymTab[x][S_NAME] & " = ")*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32126 = (object)*(((s1_ptr)_2)->base + _x_65373);
    _2 = (object)SEQ_PTR(_32126);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32127 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32127 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32126 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _29701;
        concat_list[1] = _32127;
        concat_list[2] = _25115;
        Concat_N((object_ptr)&_32128, concat_list, 3);
    }
    _32127 = NOVALUE;
    EPuts(_67err_file_65304, _32128); // DJP 
    DeRefDS(_32128);
    _32128 = NOVALUE;

    /** execute.e:236		if equal(val[x], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32129 = (object)*(((s1_ptr)_2)->base + _x_65373);
    if (_32129 == _27NOVALUE_20426)
    _32130 = 1;
    else if (IS_ATOM_INT(_32129) && IS_ATOM_INT(_27NOVALUE_20426))
    _32130 = 0;
    else
    _32130 = (compare(_32129, _27NOVALUE_20426) == 0);
    _32129 = NOVALUE;
    if (_32130 == 0)
    {
        _32130 = NOVALUE;
        goto L1; // [42] 55
    }
    else{
        _32130 = NOVALUE;
    }

    /** execute.e:237			puts(err_file, "<no value>")*/
    EPuts(_67err_file_65304, _32131); // DJP 
    goto L2; // [52] 102
L1: 

    /** execute.e:239			pretty_print(err_file, val[x],*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32132 = (object)*(((s1_ptr)_2)->base + _x_65373);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32133 = (object)*(((s1_ptr)_2)->base + _x_65373);
    _2 = (object)SEQ_PTR(_32133);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32134 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32134 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32133 = NOVALUE;
    if (IS_SEQUENCE(_32134)){
            _32135 = SEQ_PTR(_32134)->length;
    }
    else {
        _32135 = 1;
    }
    _32134 = NOVALUE;
    _32136 = _32135 + 7;
    _32135 = NOVALUE;
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1;
    ((intptr_t*)_2)[2] = 2;
    ((intptr_t*)_2)[3] = _32136;
    ((intptr_t*)_2)[4] = 78;
    RefDS(_32137);
    ((intptr_t*)_2)[5] = _32137;
    RefDS(_32138);
    ((intptr_t*)_2)[6] = _32138;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 500;
    _32139 = MAKE_SEQ(_1);
    _32136 = NOVALUE;
    Ref(_32132);
    _10pretty_print(_67err_file_65304, _32132, _32139);
    _32132 = NOVALUE;
    _32139 = NOVALUE;
L2: 

    /** execute.e:242		puts(err_file, '\n')*/
    EPuts(_67err_file_65304, 10); // DJP 

    /** execute.e:243	end procedure*/
    _32134 = NOVALUE;
    return;
    ;
}


void _67save_private_block(object _rtn_idx_65403, object _block_65404)
{
    object _saved_65405 = NOVALUE;
    object _saved_list_65406 = NOVALUE;
    object _eentry_65407 = NOVALUE;
    object _task_65408 = NOVALUE;
    object _spot_65409 = NOVALUE;
    object _tn_65410 = NOVALUE;
    object _32166 = NOVALUE;
    object _32162 = NOVALUE;
    object _32161 = NOVALUE;
    object _32160 = NOVALUE;
    object _32159 = NOVALUE;
    object _32158 = NOVALUE;
    object _32157 = NOVALUE;
    object _32155 = NOVALUE;
    object _32153 = NOVALUE;
    object _32152 = NOVALUE;
    object _32149 = NOVALUE;
    object _32147 = NOVALUE;
    object _32145 = NOVALUE;
    object _32143 = NOVALUE;
    object _32142 = NOVALUE;
    object _32140 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:259		task = SymTab[rtn_idx][S_RESIDENT_TASK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32140 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65403);
    _2 = (object)SEQ_PTR(_32140);
    _task_65408 = (object)*(((s1_ptr)_2)->base + 25);
    if (!IS_ATOM_INT(_task_65408)){
        _task_65408 = (object)DBL_PTR(_task_65408)->dbl;
    }
    _32140 = NOVALUE;

    /** execute.e:261		eentry = {task, tcb[task][TASK_TID], block, 0}*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32142 = (object)*(((s1_ptr)_2)->base + _task_65408);
    _2 = (object)SEQ_PTR(_32142);
    _32143 = (object)*(((s1_ptr)_2)->base + 2);
    _32142 = NOVALUE;
    _0 = _eentry_65407;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _task_65408;
    Ref(_32143);
    ((intptr_t*)_2)[2] = _32143;
    RefDS(_block_65404);
    ((intptr_t*)_2)[3] = _block_65404;
    ((intptr_t*)_2)[4] = 0;
    _eentry_65407 = MAKE_SEQ(_1);
    DeRef(_0);
    _32143 = NOVALUE;

    /** execute.e:262		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32145 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65403);
    DeRef(_saved_65405);
    _2 = (object)SEQ_PTR(_32145);
    _saved_65405 = (object)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_65405);
    _32145 = NOVALUE;

    /** execute.e:264		if length(saved) = 0 then*/
    if (IS_SEQUENCE(_saved_65405)){
            _32147 = SEQ_PTR(_saved_65405)->length;
    }
    else {
        _32147 = 1;
    }
    if (_32147 != 0)
    goto L1; // [61] 78

    /** execute.e:266			saved = {1, -- index of first item*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_eentry_65407);
    ((intptr_t*)_2)[1] = _eentry_65407;
    _32149 = MAKE_SEQ(_1);
    DeRefDS(_saved_65405);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _32149;
    _saved_65405 = MAKE_SEQ(_1);
    _32149 = NOVALUE;
    goto L2; // [75] 219
L1: 

    /** execute.e:270			saved_list = saved[2]*/
    DeRef(_saved_list_65406);
    _2 = (object)SEQ_PTR(_saved_65405);
    _saved_list_65406 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_65406);

    /** execute.e:271			spot = 0*/
    _spot_65409 = 0;

    /** execute.e:272			for i = 1 to length(saved_list) do*/
    if (IS_SEQUENCE(_saved_list_65406)){
            _32152 = SEQ_PTR(_saved_list_65406)->length;
    }
    else {
        _32152 = 1;
    }
    {
        object _i_65430;
        _i_65430 = 1;
L3: 
        if (_i_65430 > _32152){
            goto L4; // [96] 169
        }

        /** execute.e:273				tn = saved_list[i][SP_TASK_NUMBER]*/
        _2 = (object)SEQ_PTR(_saved_list_65406);
        _32153 = (object)*(((s1_ptr)_2)->base + _i_65430);
        _2 = (object)SEQ_PTR(_32153);
        _tn_65410 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_tn_65410)){
            _tn_65410 = (object)DBL_PTR(_tn_65410)->dbl;
        }
        _32153 = NOVALUE;

        /** execute.e:274				if tn = -1 or*/
        _32155 = (_tn_65410 == -1);
        if (_32155 != 0) {
            goto L5; // [121] 152
        }
        _2 = (object)SEQ_PTR(_saved_list_65406);
        _32157 = (object)*(((s1_ptr)_2)->base + _i_65430);
        _2 = (object)SEQ_PTR(_32157);
        _32158 = (object)*(((s1_ptr)_2)->base + 2);
        _32157 = NOVALUE;
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32159 = (object)*(((s1_ptr)_2)->base + _tn_65410);
        _2 = (object)SEQ_PTR(_32159);
        _32160 = (object)*(((s1_ptr)_2)->base + 2);
        _32159 = NOVALUE;
        if (IS_ATOM_INT(_32158) && IS_ATOM_INT(_32160)) {
            _32161 = (_32158 != _32160);
        }
        else {
            _32161 = binary_op(NOTEQ, _32158, _32160);
        }
        _32158 = NOVALUE;
        _32160 = NOVALUE;
        if (_32161 == 0) {
            DeRef(_32161);
            _32161 = NOVALUE;
            goto L6; // [148] 162
        }
        else {
            if (!IS_ATOM_INT(_32161) && DBL_PTR(_32161)->dbl == 0.0){
                DeRef(_32161);
                _32161 = NOVALUE;
                goto L6; // [148] 162
            }
            DeRef(_32161);
            _32161 = NOVALUE;
        }
        DeRef(_32161);
        _32161 = NOVALUE;
L5: 

        /** execute.e:277					spot = i*/
        _spot_65409 = _i_65430;

        /** execute.e:278					exit*/
        goto L4; // [159] 169
L6: 

        /** execute.e:280			end for*/
        _i_65430 = _i_65430 + 1;
        goto L3; // [164] 103
L4: 
        ;
    }

    /** execute.e:282			eentry[SP_NEXT] = saved[1] -- new eentry points to previous first*/
    _2 = (object)SEQ_PTR(_saved_65405);
    _32162 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32162);
    _2 = (object)SEQ_PTR(_eentry_65407);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _eentry_65407 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32162;
    if( _1 != _32162 ){
        DeRef(_1);
    }
    _32162 = NOVALUE;

    /** execute.e:283			if spot = 0 then*/
    if (_spot_65409 != 0)
    goto L7; // [181] 199

    /** execute.e:285				saved_list = append(saved_list, eentry)*/
    RefDS(_eentry_65407);
    Append(&_saved_list_65406, _saved_list_65406, _eentry_65407);

    /** execute.e:286				spot = length(saved_list)*/
    if (IS_SEQUENCE(_saved_list_65406)){
            _spot_65409 = SEQ_PTR(_saved_list_65406)->length;
    }
    else {
        _spot_65409 = 1;
    }
    goto L8; // [196] 206
L7: 

    /** execute.e:288				saved_list[spot] = eentry*/
    RefDS(_eentry_65407);
    _2 = (object)SEQ_PTR(_saved_list_65406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65406 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _spot_65409);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _eentry_65407;
    DeRef(_1);
L8: 

    /** execute.e:291			saved[1] = spot -- it becomes the first on the list*/
    _2 = (object)SEQ_PTR(_saved_65405);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65405 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _spot_65409;
    DeRef(_1);

    /** execute.e:292			saved[2] = saved_list*/
    RefDS(_saved_list_65406);
    _2 = (object)SEQ_PTR(_saved_65405);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65405 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65406;
    DeRef(_1);
L2: 

    /** execute.e:295		SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65403 + ((s1_ptr)_2)->base);
    RefDS(_saved_65405);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65405;
    DeRef(_1);
    _32166 = NOVALUE;

    /** execute.e:296	end procedure*/
    DeRefDS(_block_65404);
    DeRefDS(_saved_65405);
    DeRef(_saved_list_65406);
    DeRef(_eentry_65407);
    DeRef(_32155);
    _32155 = NOVALUE;
    return;
    ;
}


object _67load_private_block(object _rtn_idx_65455, object _task_65456)
{
    object _saved_65457 = NOVALUE;
    object _saved_list_65458 = NOVALUE;
    object _block_65459 = NOVALUE;
    object _p_65460 = NOVALUE;
    object _prev_p_65461 = NOVALUE;
    object _first_65462 = NOVALUE;
    object _32190 = NOVALUE;
    object _32188 = NOVALUE;
    object _32187 = NOVALUE;
    object _32186 = NOVALUE;
    object _32184 = NOVALUE;
    object _32182 = NOVALUE;
    object _32179 = NOVALUE;
    object _32177 = NOVALUE;
    object _32175 = NOVALUE;
    object _32173 = NOVALUE;
    object _32172 = NOVALUE;
    object _32168 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:304		saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32168 = (object)*(((s1_ptr)_2)->base + _rtn_idx_65455);
    DeRef(_saved_65457);
    _2 = (object)SEQ_PTR(_32168);
    _saved_65457 = (object)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_65457);
    _32168 = NOVALUE;

    /** execute.e:305		first = saved[1]*/
    _2 = (object)SEQ_PTR(_saved_65457);
    _first_65462 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_first_65462))
    _first_65462 = (object)DBL_PTR(_first_65462)->dbl;

    /** execute.e:306		p = first -- won't be 0*/
    _p_65460 = _first_65462;

    /** execute.e:307		prev_p = -1*/
    _prev_p_65461 = -1;

    /** execute.e:308		saved_list = saved[2]*/
    DeRef(_saved_list_65458);
    _2 = (object)SEQ_PTR(_saved_65457);
    _saved_list_65458 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_65458);

    /** execute.e:309		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [52] 200
    }
    else{
    }

    /** execute.e:310			if saved_list[p][SP_TASK_NUMBER] = task then*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    _32172 = (object)*(((s1_ptr)_2)->base + _p_65460);
    _2 = (object)SEQ_PTR(_32172);
    _32173 = (object)*(((s1_ptr)_2)->base + 1);
    _32172 = NOVALUE;
    if (binary_op_a(NOTEQ, _32173, _task_65456)){
        _32173 = NOVALUE;
        goto L3; // [65] 178
    }
    _32173 = NOVALUE;

    /** execute.e:312				block = saved_list[p][SP_BLOCK]*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    _32175 = (object)*(((s1_ptr)_2)->base + _p_65460);
    DeRef(_block_65459);
    _2 = (object)SEQ_PTR(_32175);
    _block_65459 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_block_65459);
    _32175 = NOVALUE;

    /** execute.e:313				saved_list[p][SP_TASK_NUMBER] = -1 -- mark it as deleted*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65458 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65460 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);
    _32177 = NOVALUE;

    /** execute.e:314				saved_list[p][SP_BLOCK] = {}*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65458 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_65460 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _32179 = NOVALUE;

    /** execute.e:315				if prev_p = -1 then*/
    if (_prev_p_65461 != -1)
    goto L4; // [105] 124

    /** execute.e:316					first = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    _32182 = (object)*(((s1_ptr)_2)->base + _p_65460);
    _2 = (object)SEQ_PTR(_32182);
    _first_65462 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_first_65462)){
        _first_65462 = (object)DBL_PTR(_first_65462)->dbl;
    }
    _32182 = NOVALUE;
    goto L5; // [121] 144
L4: 

    /** execute.e:318					saved_list[prev_p][SP_NEXT] = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_list_65458 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_65461 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_saved_list_65458);
    _32186 = (object)*(((s1_ptr)_2)->base + _p_65460);
    _2 = (object)SEQ_PTR(_32186);
    _32187 = (object)*(((s1_ptr)_2)->base + 4);
    _32186 = NOVALUE;
    Ref(_32187);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32187;
    if( _1 != _32187 ){
        DeRef(_1);
    }
    _32187 = NOVALUE;
    _32184 = NOVALUE;
L5: 

    /** execute.e:320				saved[1] = first*/
    _2 = (object)SEQ_PTR(_saved_65457);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65457 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_65462;
    DeRef(_1);

    /** execute.e:321				saved[2] = saved_list*/
    RefDS(_saved_list_65458);
    _2 = (object)SEQ_PTR(_saved_65457);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _saved_65457 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_list_65458;
    DeRef(_1);

    /** execute.e:322				SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_rtn_idx_65455 + ((s1_ptr)_2)->base);
    RefDS(_saved_65457);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _saved_65457;
    DeRef(_1);
    _32188 = NOVALUE;

    /** execute.e:323				return block*/
    DeRefDS(_saved_65457);
    DeRefDS(_saved_list_65458);
    return _block_65459;
L3: 

    /** execute.e:325			prev_p = p*/
    _prev_p_65461 = _p_65460;

    /** execute.e:326			p = saved_list[p][SP_NEXT]*/
    _2 = (object)SEQ_PTR(_saved_list_65458);
    _32190 = (object)*(((s1_ptr)_2)->base + _p_65460);
    _2 = (object)SEQ_PTR(_32190);
    _p_65460 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_p_65460)){
        _p_65460 = (object)DBL_PTR(_p_65460)->dbl;
    }
    _32190 = NOVALUE;

    /** execute.e:327		end while*/
    goto L1; // [197] 50
L2: 
    ;
}


void _67restore_privates(object _this_routine_65499)
{
    object _arg_65501 = NOVALUE;
    object _private_block_65502 = NOVALUE;
    object _base_65503 = NOVALUE;
    object _32257 = NOVALUE;
    object _32255 = NOVALUE;
    object _32253 = NOVALUE;
    object _32250 = NOVALUE;
    object _32248 = NOVALUE;
    object _32246 = NOVALUE;
    object _32244 = NOVALUE;
    object _32243 = NOVALUE;
    object _32242 = NOVALUE;
    object _32241 = NOVALUE;
    object _32240 = NOVALUE;
    object _32239 = NOVALUE;
    object _32238 = NOVALUE;
    object _32237 = NOVALUE;
    object _32236 = NOVALUE;
    object _32235 = NOVALUE;
    object _32234 = NOVALUE;
    object _32233 = NOVALUE;
    object _32232 = NOVALUE;
    object _32231 = NOVALUE;
    object _32230 = NOVALUE;
    object _32228 = NOVALUE;
    object _32225 = NOVALUE;
    object _32223 = NOVALUE;
    object _32220 = NOVALUE;
    object _32218 = NOVALUE;
    object _32216 = NOVALUE;
    object _32214 = NOVALUE;
    object _32213 = NOVALUE;
    object _32212 = NOVALUE;
    object _32211 = NOVALUE;
    object _32210 = NOVALUE;
    object _32209 = NOVALUE;
    object _32208 = NOVALUE;
    object _32207 = NOVALUE;
    object _32206 = NOVALUE;
    object _32205 = NOVALUE;
    object _32204 = NOVALUE;
    object _32203 = NOVALUE;
    object _32202 = NOVALUE;
    object _32201 = NOVALUE;
    object _32200 = NOVALUE;
    object _32198 = NOVALUE;
    object _32196 = NOVALUE;
    object _32195 = NOVALUE;
    object _32193 = NOVALUE;
    object _32192 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_this_routine_65499)) {
        _1 = (object)(DBL_PTR(_this_routine_65499)->dbl);
        DeRefDS(_this_routine_65499);
        _this_routine_65499 = _1;
    }

    /** execute.e:334		sequence private_block*/

    /** execute.e:335		integer base*/

    /** execute.e:337		if SymTab[this_routine][S_RESIDENT_TASK] != current_task then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32192 = (object)*(((s1_ptr)_2)->base + _this_routine_65499);
    _2 = (object)SEQ_PTR(_32192);
    _32193 = (object)*(((s1_ptr)_2)->base + 25);
    _32192 = NOVALUE;
    if (binary_op_a(EQUALS, _32193, _67current_task_65272)){
        _32193 = NOVALUE;
        goto L1; // [23] 535
    }
    _32193 = NOVALUE;

    /** execute.e:340			if SymTab[this_routine][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32195 = (object)*(((s1_ptr)_2)->base + _this_routine_65499);
    _2 = (object)SEQ_PTR(_32195);
    _32196 = (object)*(((s1_ptr)_2)->base + 25);
    _32195 = NOVALUE;
    if (binary_op_a(EQUALS, _32196, 0)){
        _32196 = NOVALUE;
        goto L2; // [41] 274
    }
    _32196 = NOVALUE;

    /** execute.e:346				arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32198 = (object)*(((s1_ptr)_2)->base + _this_routine_65499);
    _2 = (object)SEQ_PTR(_32198);
    _arg_65501 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32198 = NOVALUE;

    /** execute.e:347				private_block = {}*/
    RefDS(_22209);
    DeRef(_private_block_65502);
    _private_block_65502 = _22209;

    /** execute.e:349				while arg != 0 */
L3: 
    _32200 = (_arg_65501 != 0);
    if (_32200 == 0) {
        goto L4; // [77] 209
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32202 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32202);
    _32203 = (object)*(((s1_ptr)_2)->base + 4);
    _32202 = NOVALUE;
    if (IS_ATOM_INT(_32203)) {
        _32204 = (_32203 <= 3);
    }
    else {
        _32204 = binary_op(LESSEQ, _32203, 3);
    }
    _32203 = NOVALUE;
    if (IS_ATOM_INT(_32204)) {
        if (_32204 != 0) {
            DeRef(_32205);
            _32205 = 1;
            goto L5; // [99] 125
        }
    }
    else {
        if (DBL_PTR(_32204)->dbl != 0.0) {
            DeRef(_32205);
            _32205 = 1;
            goto L5; // [99] 125
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32206 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32206);
    _32207 = (object)*(((s1_ptr)_2)->base + 4);
    _32206 = NOVALUE;
    if (IS_ATOM_INT(_32207)) {
        _32208 = (_32207 == 2);
    }
    else {
        _32208 = binary_op(EQUALS, _32207, 2);
    }
    _32207 = NOVALUE;
    DeRef(_32205);
    if (IS_ATOM_INT(_32208))
    _32205 = (_32208 != 0);
    else
    _32205 = DBL_PTR(_32208)->dbl != 0.0;
L5: 
    if (_32205 != 0) {
        DeRef(_32209);
        _32209 = 1;
        goto L6; // [125] 151
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32210 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32210);
    _32211 = (object)*(((s1_ptr)_2)->base + 4);
    _32210 = NOVALUE;
    if (IS_ATOM_INT(_32211)) {
        _32212 = (_32211 == 9);
    }
    else {
        _32212 = binary_op(EQUALS, _32211, 9);
    }
    _32211 = NOVALUE;
    if (IS_ATOM_INT(_32212))
    _32209 = (_32212 != 0);
    else
    _32209 = DBL_PTR(_32212)->dbl != 0.0;
L6: 
    if (_32209 == 0)
    {
        _32209 = NOVALUE;
        goto L4; // [152] 209
    }
    else{
        _32209 = NOVALUE;
    }

    /** execute.e:354					if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32213 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32213);
    _32214 = (object)*(((s1_ptr)_2)->base + 4);
    _32213 = NOVALUE;
    if (binary_op_a(EQUALS, _32214, 9)){
        _32214 = NOVALUE;
        goto L7; // [171] 188
    }
    _32214 = NOVALUE;

    /** execute.e:355						private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32216 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    Ref(_32216);
    Append(&_private_block_65502, _private_block_65502, _32216);
    _32216 = NOVALUE;
L7: 

    /** execute.e:357					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32218 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32218);
    _arg_65501 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32218 = NOVALUE;

    /** execute.e:358				end while*/
    goto L3; // [206] 73
L4: 

    /** execute.e:361				arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32220 = (object)*(((s1_ptr)_2)->base + _this_routine_65499);
    _2 = (object)SEQ_PTR(_32220);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_65501 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_65501 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32220 = NOVALUE;

    /** execute.e:362				while arg != 0 do*/
L8: 
    if (_arg_65501 == 0)
    goto L9; // [230] 267

    /** execute.e:363					private_block = append(private_block, val[arg])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32223 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    Ref(_32223);
    Append(&_private_block_65502, _private_block_65502, _32223);
    _32223 = NOVALUE;

    /** execute.e:364					arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32225 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32225);
    _arg_65501 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32225 = NOVALUE;

    /** execute.e:365				end while*/
    goto L8; // [264] 230
L9: 

    /** execute.e:367				save_private_block(this_routine, private_block)*/
    RefDS(_private_block_65502);
    _67save_private_block(_this_routine_65499, _private_block_65502);
L2: 

    /** execute.e:371			private_block = load_private_block(this_routine, current_task)*/
    _0 = _private_block_65502;
    _private_block_65502 = _67load_private_block(_this_routine_65499, _67current_task_65272);
    DeRef(_0);

    /** execute.e:374			base = 1*/
    _base_65503 = 1;

    /** execute.e:375			arg = SymTab[this_routine][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32228 = (object)*(((s1_ptr)_2)->base + _this_routine_65499);
    _2 = (object)SEQ_PTR(_32228);
    _arg_65501 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32228 = NOVALUE;

    /** execute.e:376			while arg != 0 */
LA: 
    _32230 = (_arg_65501 != 0);
    if (_32230 == 0) {
        goto LB; // [315] 453
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32232 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32232);
    _32233 = (object)*(((s1_ptr)_2)->base + 4);
    _32232 = NOVALUE;
    if (IS_ATOM_INT(_32233)) {
        _32234 = (_32233 <= 3);
    }
    else {
        _32234 = binary_op(LESSEQ, _32233, 3);
    }
    _32233 = NOVALUE;
    if (IS_ATOM_INT(_32234)) {
        if (_32234 != 0) {
            DeRef(_32235);
            _32235 = 1;
            goto LC; // [337] 363
        }
    }
    else {
        if (DBL_PTR(_32234)->dbl != 0.0) {
            DeRef(_32235);
            _32235 = 1;
            goto LC; // [337] 363
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32236 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32236);
    _32237 = (object)*(((s1_ptr)_2)->base + 4);
    _32236 = NOVALUE;
    if (IS_ATOM_INT(_32237)) {
        _32238 = (_32237 == 2);
    }
    else {
        _32238 = binary_op(EQUALS, _32237, 2);
    }
    _32237 = NOVALUE;
    DeRef(_32235);
    if (IS_ATOM_INT(_32238))
    _32235 = (_32238 != 0);
    else
    _32235 = DBL_PTR(_32238)->dbl != 0.0;
LC: 
    if (_32235 != 0) {
        DeRef(_32239);
        _32239 = 1;
        goto LD; // [363] 389
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32240 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32240);
    _32241 = (object)*(((s1_ptr)_2)->base + 4);
    _32240 = NOVALUE;
    if (IS_ATOM_INT(_32241)) {
        _32242 = (_32241 == 9);
    }
    else {
        _32242 = binary_op(EQUALS, _32241, 9);
    }
    _32241 = NOVALUE;
    if (IS_ATOM_INT(_32242))
    _32239 = (_32242 != 0);
    else
    _32239 = DBL_PTR(_32242)->dbl != 0.0;
LD: 
    if (_32239 == 0)
    {
        _32239 = NOVALUE;
        goto LB; // [390] 453
    }
    else{
        _32239 = NOVALUE;
    }

    /** execute.e:381				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32243 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32243);
    _32244 = (object)*(((s1_ptr)_2)->base + 4);
    _32243 = NOVALUE;
    if (binary_op_a(EQUALS, _32244, 9)){
        _32244 = NOVALUE;
        goto LE; // [409] 432
    }
    _32244 = NOVALUE;

    /** execute.e:382					val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65502);
    _32246 = (object)*(((s1_ptr)_2)->base + _base_65503);
    Ref(_32246);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65501);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32246;
    if( _1 != _32246 ){
        DeRef(_1);
    }
    _32246 = NOVALUE;

    /** execute.e:383					base += 1*/
    _base_65503 = _base_65503 + 1;
LE: 

    /** execute.e:385				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32248 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32248);
    _arg_65501 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32248 = NOVALUE;

    /** execute.e:386			end while*/
    goto LA; // [450] 311
LB: 

    /** execute.e:389			arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32250 = (object)*(((s1_ptr)_2)->base + _this_routine_65499);
    _2 = (object)SEQ_PTR(_32250);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_65501 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_65501 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32250 = NOVALUE;

    /** execute.e:390			while arg != 0 do*/
LF: 
    if (_arg_65501 == 0)
    goto L10; // [474] 517

    /** execute.e:391				val[arg] = private_block[base]*/
    _2 = (object)SEQ_PTR(_private_block_65502);
    _32253 = (object)*(((s1_ptr)_2)->base + _base_65503);
    Ref(_32253);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_65501);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32253;
    if( _1 != _32253 ){
        DeRef(_1);
    }
    _32253 = NOVALUE;

    /** execute.e:392				base += 1*/
    _base_65503 = _base_65503 + 1;

    /** execute.e:393				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32255 = (object)*(((s1_ptr)_2)->base + _arg_65501);
    _2 = (object)SEQ_PTR(_32255);
    _arg_65501 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_65501)){
        _arg_65501 = (object)DBL_PTR(_arg_65501)->dbl;
    }
    _32255 = NOVALUE;

    /** execute.e:394			end while*/
    goto LF; // [514] 474
L10: 

    /** execute.e:396			SymTab[this_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_this_routine_65499 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65272;
    DeRef(_1);
    _32257 = NOVALUE;
L1: 

    /** execute.e:398	end procedure*/
    DeRef(_private_block_65502);
    DeRef(_32230);
    _32230 = NOVALUE;
    DeRef(_32204);
    _32204 = NOVALUE;
    DeRef(_32208);
    _32208 = NOVALUE;
    DeRef(_32242);
    _32242 = NOVALUE;
    DeRef(_32234);
    _32234 = NOVALUE;
    DeRef(_32200);
    _32200 = NOVALUE;
    DeRef(_32238);
    _32238 = NOVALUE;
    DeRef(_32212);
    _32212 = NOVALUE;
    return;
    ;
}


object _67is_slice(object _op_65648)
{
    object _32261 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:426		return find( op, SLICE_OPS )*/
    _32261 = find_from(_op_65648, _67SLICE_OPS_65639, 1);
    return _32261;
    ;
}


object _67is_subs(object _op_65652)
{
    object _32263 = NOVALUE;
    object _32262 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:430		if find( op, SUB_OPS ) then*/
    _32262 = find_from(_op_65652, _67SUB_OPS_65625, 1);
    if (_32262 == 0)
    {
        _32262 = NOVALUE;
        goto L1; // [12] 24
    }
    else{
        _32262 = NOVALUE;
    }

    /** execute.e:431			return 1*/
    return 1;
    goto L2; // [21] 35
L1: 

    /** execute.e:433			return is_slice( op )*/
    _32263 = _67is_slice(_op_65652);
    return _32263;
L2: 
    ;
}


object _67subs_opsize(object _op_65659)
{
    object _32295 = NOVALUE;
    object _32293 = NOVALUE;
    object _32292 = NOVALUE;
    object _32291 = NOVALUE;
    object _32290 = NOVALUE;
    object _32289 = NOVALUE;
    object _32288 = NOVALUE;
    object _32287 = NOVALUE;
    object _32286 = NOVALUE;
    object _32285 = NOVALUE;
    object _32284 = NOVALUE;
    object _32283 = NOVALUE;
    object _32282 = NOVALUE;
    object _32281 = NOVALUE;
    object _32280 = NOVALUE;
    object _32279 = NOVALUE;
    object _32278 = NOVALUE;
    object _32276 = NOVALUE;
    object _32275 = NOVALUE;
    object _32274 = NOVALUE;
    object _32273 = NOVALUE;
    object _32272 = NOVALUE;
    object _32271 = NOVALUE;
    object _32270 = NOVALUE;
    object _32269 = NOVALUE;
    object _32268 = NOVALUE;
    object _32267 = NOVALUE;
    object _32266 = NOVALUE;
    object _32265 = NOVALUE;
    object _32264 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:438		if op = RHS_SUBS or op = RHS_SUBS_CHECK or op = PASSIGN_SUBS or op = ASSIGN_SUBS*/
    _32264 = (_op_65659 == 25);
    if (_32264 != 0) {
        _32265 = 1;
        goto L1; // [11] 25
    }
    _32266 = (_op_65659 == 92);
    _32265 = (_32266 != 0);
L1: 
    if (_32265 != 0) {
        _32267 = 1;
        goto L2; // [25] 39
    }
    _32268 = (_op_65659 == 162);
    _32267 = (_32268 != 0);
L2: 
    if (_32267 != 0) {
        _32269 = 1;
        goto L3; // [39] 53
    }
    _32270 = (_op_65659 == 16);
    _32269 = (_32270 != 0);
L3: 
    if (_32269 != 0) {
        _32271 = 1;
        goto L4; // [53] 67
    }
    _32272 = (_op_65659 == 149);
    _32271 = (_32272 != 0);
L4: 
    if (_32271 != 0) {
        _32273 = 1;
        goto L5; // [67] 81
    }
    _32274 = (_op_65659 == 84);
    _32273 = (_32274 != 0);
L5: 
    if (_32273 != 0) {
        _32275 = 1;
        goto L6; // [81] 95
    }
    _32276 = (_op_65659 == 118);
    _32275 = (_32276 != 0);
L6: 
    if (_32275 != 0) {
        goto L7; // [95] 110
    }
    _32278 = (_op_65659 == 164);
    if (_32278 == 0)
    {
        DeRef(_32278);
        _32278 = NOVALUE;
        goto L8; // [106] 119
    }
    else{
        DeRef(_32278);
        _32278 = NOVALUE;
    }
L7: 

    /** execute.e:442			return 4*/
    DeRef(_32274);
    _32274 = NOVALUE;
    DeRef(_32270);
    _32270 = NOVALUE;
    DeRef(_32266);
    _32266 = NOVALUE;
    DeRef(_32268);
    _32268 = NOVALUE;
    DeRef(_32272);
    _32272 = NOVALUE;
    DeRef(_32276);
    _32276 = NOVALUE;
    DeRef(_32264);
    _32264 = NOVALUE;
    return 4;
    goto L9; // [116] 256
L8: 

    /** execute.e:443		elsif op = LHS_SUBS1 or op = LHS_SUBS or op = LHS_SUBS1_COPY*/
    _32279 = (_op_65659 == 161);
    if (_32279 != 0) {
        _32280 = 1;
        goto LA; // [127] 141
    }
    _32281 = (_op_65659 == 95);
    _32280 = (_32281 != 0);
LA: 
    if (_32280 != 0) {
        _32282 = 1;
        goto LB; // [141] 155
    }
    _32283 = (_op_65659 == 166);
    _32282 = (_32283 != 0);
LB: 
    if (_32282 != 0) {
        _32284 = 1;
        goto LC; // [155] 169
    }
    _32285 = (_op_65659 == 45);
    _32284 = (_32285 != 0);
LC: 
    if (_32284 != 0) {
        _32286 = 1;
        goto LD; // [169] 183
    }
    _32287 = (_op_65659 == 163);
    _32286 = (_32287 != 0);
LD: 
    if (_32286 != 0) {
        _32288 = 1;
        goto LE; // [183] 197
    }
    _32289 = (_op_65659 == 46);
    _32288 = (_32289 != 0);
LE: 
    if (_32288 != 0) {
        _32290 = 1;
        goto LF; // [197] 211
    }
    _32291 = (_op_65659 == 150);
    _32290 = (_32291 != 0);
LF: 
    if (_32290 != 0) {
        _32292 = 1;
        goto L10; // [211] 225
    }
    _32293 = (_op_65659 == 165);
    _32292 = (_32293 != 0);
L10: 
    if (_32292 != 0) {
        goto L11; // [225] 240
    }
    _32295 = (_op_65659 == 163);
    if (_32295 == 0)
    {
        DeRef(_32295);
        _32295 = NOVALUE;
        goto L12; // [236] 249
    }
    else{
        DeRef(_32295);
        _32295 = NOVALUE;
    }
L11: 

    /** execute.e:448			return 5*/
    DeRef(_32291);
    _32291 = NOVALUE;
    DeRef(_32274);
    _32274 = NOVALUE;
    DeRef(_32283);
    _32283 = NOVALUE;
    DeRef(_32287);
    _32287 = NOVALUE;
    DeRef(_32270);
    _32270 = NOVALUE;
    DeRef(_32266);
    _32266 = NOVALUE;
    DeRef(_32285);
    _32285 = NOVALUE;
    DeRef(_32268);
    _32268 = NOVALUE;
    DeRef(_32289);
    _32289 = NOVALUE;
    DeRef(_32293);
    _32293 = NOVALUE;
    DeRef(_32272);
    _32272 = NOVALUE;
    DeRef(_32276);
    _32276 = NOVALUE;
    DeRef(_32264);
    _32264 = NOVALUE;
    DeRef(_32279);
    _32279 = NOVALUE;
    DeRef(_32281);
    _32281 = NOVALUE;
    return 5;
    goto L9; // [246] 256
L12: 

    /** execute.e:450			return 1*/
    DeRef(_32291);
    _32291 = NOVALUE;
    DeRef(_32274);
    _32274 = NOVALUE;
    DeRef(_32283);
    _32283 = NOVALUE;
    DeRef(_32287);
    _32287 = NOVALUE;
    DeRef(_32270);
    _32270 = NOVALUE;
    DeRef(_32266);
    _32266 = NOVALUE;
    DeRef(_32285);
    _32285 = NOVALUE;
    DeRef(_32268);
    _32268 = NOVALUE;
    DeRef(_32289);
    _32289 = NOVALUE;
    DeRef(_32293);
    _32293 = NOVALUE;
    DeRef(_32272);
    _32272 = NOVALUE;
    DeRef(_32276);
    _32276 = NOVALUE;
    DeRef(_32264);
    _32264 = NOVALUE;
    DeRef(_32279);
    _32279 = NOVALUE;
    DeRef(_32281);
    _32281 = NOVALUE;
    return 1;
L9: 
    ;
}


object _67sub_dest_offset(object _op_65714)
{
    object _offset_65715 = NOVALUE;
    object _32300 = NOVALUE;
    object _32298 = NOVALUE;
    object _32296 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:455		integer offset = subs_opsize( op ) - 1*/
    _32296 = _67subs_opsize(_op_65714);
    if (IS_ATOM_INT(_32296)) {
        _offset_65715 = _32296 - 1;
    }
    else {
        _offset_65715 = binary_op(MINUS, _32296, 1);
    }
    DeRef(_32296);
    _32296 = NOVALUE;
    if (!IS_ATOM_INT(_offset_65715)) {
        _1 = (object)(DBL_PTR(_offset_65715)->dbl);
        DeRefDS(_offset_65715);
        _offset_65715 = _1;
    }

    /** execute.e:456		if op = LHS_SUBS1_COPY or op = LHS_SUBS1 then*/
    _32298 = (_op_65714 == 166);
    if (_32298 != 0) {
        goto L1; // [23] 38
    }
    _32300 = (_op_65714 == 161);
    if (_32300 == 0)
    {
        DeRef(_32300);
        _32300 = NOVALUE;
        goto L2; // [34] 45
    }
    else{
        DeRef(_32300);
        _32300 = NOVALUE;
    }
L1: 

    /** execute.e:457			offset -= 1*/
    _offset_65715 = _offset_65715 - 1;
L2: 

    /** execute.e:459		return offset*/
    DeRef(_32298);
    _32298 = NOVALUE;
    return _offset_65715;
    ;
}


void _67LookBackForSubscriptSymbol(object _pc_65727, object _sublevel_65728, object _has_slice_65729)
{
    object _op_65730 = NOVALUE;
    object _start_pc_65733 = NOVALUE;
    object _sym_65735 = NOVALUE;
    object _subtext_65751 = NOVALUE;
    object _32341 = NOVALUE;
    object _32340 = NOVALUE;
    object _32339 = NOVALUE;
    object _32338 = NOVALUE;
    object _32337 = NOVALUE;
    object _32336 = NOVALUE;
    object _32335 = NOVALUE;
    object _32334 = NOVALUE;
    object _32333 = NOVALUE;
    object _32330 = NOVALUE;
    object _32329 = NOVALUE;
    object _32328 = NOVALUE;
    object _32327 = NOVALUE;
    object _32326 = NOVALUE;
    object _32325 = NOVALUE;
    object _32324 = NOVALUE;
    object _32323 = NOVALUE;
    object _32322 = NOVALUE;
    object _32321 = NOVALUE;
    object _32320 = NOVALUE;
    object _32319 = NOVALUE;
    object _32318 = NOVALUE;
    object _32317 = NOVALUE;
    object _32316 = NOVALUE;
    object _32312 = NOVALUE;
    object _32311 = NOVALUE;
    object _32310 = NOVALUE;
    object _32309 = NOVALUE;
    object _32308 = NOVALUE;
    object _32307 = NOVALUE;
    object _32305 = NOVALUE;
    object _32303 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sublevel_65728)) {
        _1 = (object)(DBL_PTR(_sublevel_65728)->dbl);
        DeRefDS(_sublevel_65728);
        _sublevel_65728 = _1;
    }

    /** execute.e:464		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_65730 = (object)*(((s1_ptr)_2)->base + _pc_65727);
    if (!IS_ATOM_INT(_op_65730)){
        _op_65730 = (object)DBL_PTR(_op_65730)->dbl;
    }

    /** execute.e:465		integer start_pc = pc*/
    _start_pc_65733 = _pc_65727;

    /** execute.e:466		symtab_pointer sym = Code[pc+1]*/
    _32303 = _pc_65727 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sym_65735 = (object)*(((s1_ptr)_2)->base + _32303);
    if (!IS_ATOM_INT(_sym_65735)){
        _sym_65735 = (object)DBL_PTR(_sym_65735)->dbl;
    }

    /** execute.e:467		has_slice = has_slice or is_slice( op )*/
    _32305 = _67is_slice(_op_65730);
    if (IS_ATOM_INT(_32305)) {
        _has_slice_65729 = (_has_slice_65729 != 0 || _32305 != 0);
    }
    else {
        _has_slice_65729 = binary_op(OR, _has_slice_65729, _32305);
    }
    DeRef(_32305);
    _32305 = NOVALUE;
    if (!IS_ATOM_INT(_has_slice_65729)) {
        _1 = (object)(DBL_PTR(_has_slice_65729)->dbl);
        DeRefDS(_has_slice_65729);
        _has_slice_65729 = _1;
    }

    /** execute.e:469		if length( SymTab[sym] ) >= S_NAME and length( sym_name( sym ) ) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32307 = (object)*(((s1_ptr)_2)->base + _sym_65735);
    if (IS_SEQUENCE(_32307)){
            _32308 = SEQ_PTR(_32307)->length;
    }
    else {
        _32308 = 1;
    }
    _32307 = NOVALUE;
    if (IS_ATOM_INT(_27S_NAME_20209)) {
        _32309 = (_32308 >= _27S_NAME_20209);
    }
    else {
        _32309 = binary_op(GREATEREQ, _32308, _27S_NAME_20209);
    }
    _32308 = NOVALUE;
    if (IS_ATOM_INT(_32309)) {
        if (_32309 == 0) {
            goto L1; // [65] 204
        }
    }
    else {
        if (DBL_PTR(_32309)->dbl == 0.0) {
            goto L1; // [65] 204
        }
    }
    _32311 = _53sym_name(_sym_65735);
    if (IS_SEQUENCE(_32311)){
            _32312 = SEQ_PTR(_32311)->length;
    }
    else {
        _32312 = 1;
    }
    DeRef(_32311);
    _32311 = NOVALUE;
    if (_32312 == 0)
    {
        _32312 = NOVALUE;
        goto L1; // [77] 204
    }
    else{
        _32312 = NOVALUE;
    }

    /** execute.e:470			sequence subtext*/

    /** execute.e:471			if has_slice then*/
    if (_has_slice_65729 == 0)
    {
        goto L2; // [84] 97
    }
    else{
    }

    /** execute.e:472				subtext = "slice/subscript"*/
    RefDS(_32313);
    DeRefi(_subtext_65751);
    _subtext_65751 = _32313;
    goto L3; // [94] 105
L2: 

    /** execute.e:474				subtext = "subscript"*/
    RefDS(_32314);
    DeRefi(_subtext_65751);
    _subtext_65751 = _32314;
L3: 

    /** execute.e:476			both_printf(" - in %s #%d of '%s'", { subtext, sublevel, sym_name( sym ) } )*/
    _32316 = _53sym_name(_sym_65735);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_subtext_65751);
    ((intptr_t*)_2)[1] = _subtext_65751;
    ((intptr_t*)_2)[2] = _sublevel_65728;
    ((intptr_t*)_2)[3] = _32316;
    _32317 = MAKE_SEQ(_1);
    _32316 = NOVALUE;
    RefDS(_32315);
    _67both_printf(_32315, _32317);
    _32317 = NOVALUE;
    DeRefDSi(_subtext_65751);
    _subtext_65751 = NOVALUE;
    goto L4; // [125] 276

    /** execute.e:480			while pc > 1*/
    goto L1; // [130] 204
L5: 
    _32318 = (_pc_65727 > 1);
    if (_32318 == 0) {
        DeRef(_32319);
        _32319 = 0;
        goto L6; // [137] 198
    }
    _32320 = _67is_subs(_op_65730);
    if (IS_ATOM_INT(_32320)) {
        if (_32320 == 0) {
            DeRef(_32321);
            _32321 = 0;
            goto L7; // [145] 171
        }
    }
    else {
        if (DBL_PTR(_32320)->dbl == 0.0) {
            DeRef(_32321);
            _32321 = 0;
            goto L7; // [145] 171
        }
    }
    _32322 = _67sub_dest_offset(_op_65730);
    if (IS_ATOM_INT(_32322)) {
        _32323 = _pc_65727 + _32322;
    }
    else {
        _32323 = binary_op(PLUS, _pc_65727, _32322);
    }
    DeRef(_32322);
    _32322 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_32323)){
        _32324 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32323)->dbl));
    }
    else{
        _32324 = (object)*(((s1_ptr)_2)->base + _32323);
    }
    if (IS_ATOM_INT(_32324)) {
        _32325 = (_32324 == _sym_65735);
    }
    else {
        _32325 = binary_op(EQUALS, _32324, _sym_65735);
    }
    _32324 = NOVALUE;
    DeRef(_32321);
    if (IS_ATOM_INT(_32325))
    _32321 = (_32325 != 0);
    else
    _32321 = DBL_PTR(_32325)->dbl != 0.0;
L7: 
    _32326 = (_32321 == 0);
    _32321 = NOVALUE;
    if (_32326 != 0) {
        _32327 = 1;
        goto L8; // [174] 194
    }
    _32328 = _67subs_opsize(_op_65730);
    if (IS_ATOM_INT(_32328)) {
        _32329 = _pc_65727 + _32328;
        if ((object)((uintptr_t)_32329 + (uintptr_t)HIGH_BITS) >= 0){
            _32329 = NewDouble((eudouble)_32329);
        }
    }
    else {
        _32329 = binary_op(PLUS, _pc_65727, _32328);
    }
    DeRef(_32328);
    _32328 = NOVALUE;
    if (IS_ATOM_INT(_32329)) {
        _32330 = (_start_pc_65733 <= _32329);
    }
    else {
        _32330 = binary_op(LESSEQ, _start_pc_65733, _32329);
    }
    DeRef(_32329);
    _32329 = NOVALUE;
    if (IS_ATOM_INT(_32330))
    _32327 = (_32330 != 0);
    else
    _32327 = DBL_PTR(_32330)->dbl != 0.0;
L8: 
    DeRef(_32319);
    _32319 = (_32327 != 0);
L6: 
    if (_32319 == 0)
    {
        _32319 = NOVALUE;
        goto L9; // [198] 225
    }
    else{
        _32319 = NOVALUE;
    }

    /** execute.e:487			entry*/
L1: 

    /** execute.e:488				pc -= 1*/
    _pc_65727 = _pc_65727 - 1;

    /** execute.e:489				op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_65730 = (object)*(((s1_ptr)_2)->base + _pc_65727);
    if (!IS_ATOM_INT(_op_65730)){
        _op_65730 = (object)DBL_PTR(_op_65730)->dbl;
    }

    /** execute.e:490			end while*/
    goto L5; // [222] 133
L9: 

    /** execute.e:492			if is_subs( op ) and (Code[pc + sub_dest_offset( op )] = sym) then*/
    _32333 = _67is_subs(_op_65730);
    if (IS_ATOM_INT(_32333)) {
        if (_32333 == 0) {
            goto LA; // [231] 275
        }
    }
    else {
        if (DBL_PTR(_32333)->dbl == 0.0) {
            goto LA; // [231] 275
        }
    }
    _32335 = _67sub_dest_offset(_op_65730);
    if (IS_ATOM_INT(_32335)) {
        _32336 = _pc_65727 + _32335;
    }
    else {
        _32336 = binary_op(PLUS, _pc_65727, _32335);
    }
    DeRef(_32335);
    _32335 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_32336)){
        _32337 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32336)->dbl));
    }
    else{
        _32337 = (object)*(((s1_ptr)_2)->base + _32336);
    }
    if (IS_ATOM_INT(_32337)) {
        _32338 = (_32337 == _sym_65735);
    }
    else {
        _32338 = binary_op(EQUALS, _32337, _sym_65735);
    }
    _32337 = NOVALUE;
    if (_32338 == 0) {
        DeRef(_32338);
        _32338 = NOVALUE;
        goto LA; // [254] 275
    }
    else {
        if (!IS_ATOM_INT(_32338) && DBL_PTR(_32338)->dbl == 0.0){
            DeRef(_32338);
            _32338 = NOVALUE;
            goto LA; // [254] 275
        }
        DeRef(_32338);
        _32338 = NOVALUE;
    }
    DeRef(_32338);
    _32338 = NOVALUE;

    /** execute.e:493				LookBackForSubscriptSymbol( pc, sublevel + 1, has_slice )*/
    _32339 = _sublevel_65728 + 1;
    if (_32339 > MAXINT){
        _32339 = NewDouble((eudouble)_32339);
    }
    DeRef(_32340);
    _32340 = _pc_65727;
    DeRef(_32341);
    _32341 = _has_slice_65729;
    _67LookBackForSubscriptSymbol(_32340, _32339, _32341);
    _32340 = NOVALUE;
    _32339 = NOVALUE;
    _32341 = NOVALUE;
LA: 
L4: 

    /** execute.e:496	end procedure*/
    DeRef(_32330);
    _32330 = NOVALUE;
    DeRef(_32318);
    _32318 = NOVALUE;
    DeRef(_32326);
    _32326 = NOVALUE;
    DeRef(_32320);
    _32320 = NOVALUE;
    DeRef(_32309);
    _32309 = NOVALUE;
    _32307 = NOVALUE;
    _32311 = NOVALUE;
    DeRef(_32325);
    _32325 = NOVALUE;
    DeRef(_32323);
    _32323 = NOVALUE;
    DeRef(_32336);
    _32336 = NOVALUE;
    DeRef(_32303);
    _32303 = NOVALUE;
    DeRef(_32333);
    _32333 = NOVALUE;
    return;
    ;
}


void _67CheckSubsError()
{
    object _op_65792 = NOVALUE;
    object _32343 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:499		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_65792 = (object)*(((s1_ptr)_2)->base + _67pc_65255);
    if (!IS_ATOM_INT(_op_65792)){
        _op_65792 = (object)DBL_PTR(_op_65792)->dbl;
    }

    /** execute.e:500		if is_subs( op ) then*/
    _32343 = _67is_subs(_op_65792);
    if (_32343 == 0) {
        DeRef(_32343);
        _32343 = NOVALUE;
        goto L1; // [19] 32
    }
    else {
        if (!IS_ATOM_INT(_32343) && DBL_PTR(_32343)->dbl == 0.0){
            DeRef(_32343);
            _32343 = NOVALUE;
            goto L1; // [19] 32
        }
        DeRef(_32343);
        _32343 = NOVALUE;
    }
    DeRef(_32343);
    _32343 = NOVALUE;

    /** execute.e:501			LookBackForSubscriptSymbol( pc, 1, 0 )*/
    _67LookBackForSubscriptSymbol(_67pc_65255, 1, 0);
L1: 

    /** execute.e:503	end procedure*/
    return;
    ;
}


void _67trace_back(object _msg_65799)
{
    object _sub_65801 = NOVALUE;
    object _v_65802 = NOVALUE;
    object _levels_65803 = NOVALUE;
    object _prev_file_no_65804 = NOVALUE;
    object _task_65805 = NOVALUE;
    object _dash_count_65806 = NOVALUE;
    object _routine_name_65807 = NOVALUE;
    object _title_65808 = NOVALUE;
    object _show_message_65810 = NOVALUE;
    object _32493 = NOVALUE;
    object _32492 = NOVALUE;
    object _32490 = NOVALUE;
    object _32487 = NOVALUE;
    object _32485 = NOVALUE;
    object _32484 = NOVALUE;
    object _32483 = NOVALUE;
    object _32482 = NOVALUE;
    object _32481 = NOVALUE;
    object _32480 = NOVALUE;
    object _32479 = NOVALUE;
    object _32478 = NOVALUE;
    object _32477 = NOVALUE;
    object _32476 = NOVALUE;
    object _32475 = NOVALUE;
    object _32474 = NOVALUE;
    object _32473 = NOVALUE;
    object _32472 = NOVALUE;
    object _32470 = NOVALUE;
    object _32468 = NOVALUE;
    object _32464 = NOVALUE;
    object _32462 = NOVALUE;
    object _32460 = NOVALUE;
    object _32459 = NOVALUE;
    object _32458 = NOVALUE;
    object _32457 = NOVALUE;
    object _32456 = NOVALUE;
    object _32455 = NOVALUE;
    object _32454 = NOVALUE;
    object _32453 = NOVALUE;
    object _32452 = NOVALUE;
    object _32451 = NOVALUE;
    object _32449 = NOVALUE;
    object _32446 = NOVALUE;
    object _32445 = NOVALUE;
    object _32443 = NOVALUE;
    object _32442 = NOVALUE;
    object _32441 = NOVALUE;
    object _32439 = NOVALUE;
    object _32438 = NOVALUE;
    object _32437 = NOVALUE;
    object _32436 = NOVALUE;
    object _32435 = NOVALUE;
    object _32434 = NOVALUE;
    object _32433 = NOVALUE;
    object _32432 = NOVALUE;
    object _32431 = NOVALUE;
    object _32430 = NOVALUE;
    object _32428 = NOVALUE;
    object _32426 = NOVALUE;
    object _32425 = NOVALUE;
    object _32424 = NOVALUE;
    object _32423 = NOVALUE;
    object _32422 = NOVALUE;
    object _32421 = NOVALUE;
    object _32420 = NOVALUE;
    object _32419 = NOVALUE;
    object _32418 = NOVALUE;
    object _32417 = NOVALUE;
    object _32416 = NOVALUE;
    object _32415 = NOVALUE;
    object _32414 = NOVALUE;
    object _32413 = NOVALUE;
    object _32412 = NOVALUE;
    object _32410 = NOVALUE;
    object _32408 = NOVALUE;
    object _32407 = NOVALUE;
    object _32406 = NOVALUE;
    object _32405 = NOVALUE;
    object _32404 = NOVALUE;
    object _32396 = NOVALUE;
    object _32395 = NOVALUE;
    object _32393 = NOVALUE;
    object _32392 = NOVALUE;
    object _32391 = NOVALUE;
    object _32390 = NOVALUE;
    object _32379 = NOVALUE;
    object _32378 = NOVALUE;
    object _32377 = NOVALUE;
    object _32374 = NOVALUE;
    object _32372 = NOVALUE;
    object _32371 = NOVALUE;
    object _32370 = NOVALUE;
    object _32369 = NOVALUE;
    object _32366 = NOVALUE;
    object _32364 = NOVALUE;
    object _32362 = NOVALUE;
    object _32361 = NOVALUE;
    object _32360 = NOVALUE;
    object _32357 = NOVALUE;
    object _32356 = NOVALUE;
    object _32355 = NOVALUE;
    object _32354 = NOVALUE;
    object _32353 = NOVALUE;
    object _32349 = NOVALUE;
    object _32346 = NOVALUE;
    object _32345 = NOVALUE;
    object _32344 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:508		integer levels, prev_file_no, task, dash_count*/

    /** execute.e:509		sequence routine_name, title*/

    /** execute.e:512		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _32344 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _32344 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32345 = (object)*(((s1_ptr)_2)->base + _32344);
    _32346 = IS_ATOM(_32345);
    _32345 = NOVALUE;
    if (_32346 == 0)
    {
        _32346 = NOVALUE;
        goto L1; // [21] 35
    }
    else{
        _32346 = NOVALUE;
    }

    /** execute.e:513			slist = s_expand(slist)*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L1: 

    /** execute.e:518		show_message = TRUE*/
    _show_message_65810 = _9TRUE_441;

    /** execute.e:520		screen_err_out = atom(crash_msg)*/
    _67screen_err_out_65315 = IS_ATOM(_67crash_msg_65181);

    /** execute.e:522		while TRUE do*/
L2: 
    if (_9TRUE_441 == 0)
    {
        goto L3; // [56] 978
    }
    else{
    }

    /** execute.e:523			if length(tcb) > 1 then*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32349 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32349 = 1;
    }
    if (_32349 <= 1)
    goto L4; // [66] 208

    /** execute.e:526				if current_task = 1 then*/
    if (_67current_task_65272 != 1)
    goto L5; // [74] 88

    /** execute.e:527					routine_name = "initial task"*/
    RefDS(_32352);
    DeRef(_routine_name_65807);
    _routine_name_65807 = _32352;
    goto L6; // [85] 127
L5: 

    /** execute.e:529					routine_name = SymTab[e_routine[1+tcb[current_task][TASK_RID]]][S_NAME]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32353 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32353);
    _32354 = (object)*(((s1_ptr)_2)->base + 1);
    _32353 = NOVALUE;
    if (IS_ATOM_INT(_32354)) {
        _32355 = _32354 + 1;
    }
    else
    _32355 = binary_op(PLUS, 1, _32354);
    _32354 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_65303);
    if (!IS_ATOM_INT(_32355)){
        _32356 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32355)->dbl));
    }
    else{
        _32356 = (object)*(((s1_ptr)_2)->base + _32355);
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32357 = (object)*(((s1_ptr)_2)->base + _32356);
    DeRef(_routine_name_65807);
    _2 = (object)SEQ_PTR(_32357);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _routine_name_65807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _routine_name_65807 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_routine_name_65807);
    _32357 = NOVALUE;
L6: 

    /** execute.e:532				title = sprintf(" TASK ID %d: %s ",*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32360 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32360);
    _32361 = (object)*(((s1_ptr)_2)->base + 2);
    _32360 = NOVALUE;
    RefDS(_routine_name_65807);
    Ref(_32361);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _32361;
    ((intptr_t *)_2)[2] = _routine_name_65807;
    _32362 = MAKE_SEQ(_1);
    _32361 = NOVALUE;
    DeRefi(_title_65808);
    _title_65808 = EPrintf(-9999999, _32359, _32362);
    DeRefDS(_32362);
    _32362 = NOVALUE;

    /** execute.e:534				dash_count = 60*/
    _dash_count_65806 = 60;

    /** execute.e:535				if length(title) < dash_count then*/
    if (IS_SEQUENCE(_title_65808)){
            _32364 = SEQ_PTR(_title_65808)->length;
    }
    else {
        _32364 = 1;
    }
    if (_32364 >= 60)
    goto L7; // [161] 175

    /** execute.e:536					dash_count = 52 - length(title)*/
    if (IS_SEQUENCE(_title_65808)){
            _32366 = SEQ_PTR(_title_65808)->length;
    }
    else {
        _32366 = 1;
    }
    _dash_count_65806 = 52 - _32366;
    _32366 = NOVALUE;
L7: 

    /** execute.e:538				if dash_count < 1 then*/
    if (_dash_count_65806 >= 1)
    goto L8; // [177] 187

    /** execute.e:539					dash_count = 1*/
    _dash_count_65806 = 1;
L8: 

    /** execute.e:541				both_puts(repeat('-', 22) & title & repeat('-', dash_count) & "\n")*/
    _32369 = Repeat(45, 22);
    _32370 = Repeat(45, _dash_count_65806);
    {
        object concat_list[4];

        concat_list[0] = _22404;
        concat_list[1] = _32370;
        concat_list[2] = _title_65808;
        concat_list[3] = _32369;
        Concat_N((object_ptr)&_32371, concat_list, 4);
    }
    DeRefDS(_32370);
    _32370 = NOVALUE;
    DeRefDS(_32369);
    _32369 = NOVALUE;
    _67both_puts(_32371);
    _32371 = NOVALUE;
L4: 

    /** execute.e:544			levels = 1*/
    _levels_65803 = 1;

    /** execute.e:546			while length(call_stack) > 0 do*/
L9: 
    if (IS_SEQUENCE(_67call_stack_65273)){
            _32372 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _32372 = 1;
    }
    if (_32372 <= 0)
    goto LA; // [223] 812

    /** execute.e:547				sub = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _32374 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _32374 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _sub_65801 = (object)*(((s1_ptr)_2)->base + _32374);
    if (!IS_ATOM_INT(_sub_65801)){
        _sub_65801 = (object)DBL_PTR(_sub_65801)->dbl;
    }

    /** execute.e:548				if levels = 1 then*/
    if (_levels_65803 != 1)
    goto LB; // [242] 254

    /** execute.e:549					puts(2, '\n')*/
    EPuts(2, 10); // DJP 
    goto LC; // [251] 283
LB: 

    /** execute.e:551				elsif sub != call_back_routine and sub != delete_code_routine then*/
    _32377 = (_sub_65801 != _67call_back_routine_65189);
    if (_32377 == 0) {
        goto LD; // [262] 282
    }
    _32379 = (_sub_65801 != _67delete_code_routine_65190);
    if (_32379 == 0)
    {
        DeRef(_32379);
        _32379 = NOVALUE;
        goto LD; // [273] 282
    }
    else{
        DeRef(_32379);
        _32379 = NOVALUE;
    }

    /** execute.e:552					both_puts("... called from ")*/
    RefDS(_32380);
    _67both_puts(_32380);
LD: 
LC: 

    /** execute.e:556				if sub = call_back_routine then*/
    if (_sub_65801 != _67call_back_routine_65189)
    goto LE; // [287] 327

    /** execute.e:557					if crash_count > 0 then*/
    if (_67crash_count_65192 <= 0)
    goto LF; // [295] 311

    /** execute.e:558						both_puts("^^^ called to handle run-time crash\n")*/
    RefDS(_32383);
    _67both_puts(_32383);

    /** execute.e:559						exit*/
    goto LA; // [306] 812
    goto L10; // [308] 757
LF: 

    /** execute.e:561						both_puts("^^^ call-back from ")*/
    RefDS(_32384);
    _67both_puts(_32384);

    /** execute.e:562						ifdef WINDOWS then*/

    /** execute.e:563							both_puts("Windows\n")*/
    RefDS(_32385);
    _67both_puts(_32385);
    goto L10; // [324] 757
LE: 

    /** execute.e:568				elsif sub = delete_code_routine then*/
    if (_sub_65801 != _67delete_code_routine_65190)
    goto L11; // [331] 343

    /** execute.e:569					both_puts("^^^ delete routine\n")*/
    RefDS(_32388);
    _67both_puts(_32388);
    goto L10; // [340] 757
L11: 

    /** execute.e:572					both_printf("%s:%d", find_line(sub, pc))*/
    _32390 = _67find_line(_sub_65801, _67pc_65255);
    RefDS(_32389);
    _67both_printf(_32389, _32390);
    _32390 = NOVALUE;

    /** execute.e:574					if not equal(SymTab[sub][S_NAME], "<TopLevel>") then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32391 = (object)*(((s1_ptr)_2)->base + _sub_65801);
    _2 = (object)SEQ_PTR(_32391);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32392 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32392 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32391 = NOVALUE;
    if (_32392 == _24796)
    _32393 = 1;
    else if (IS_ATOM_INT(_32392) && IS_ATOM_INT(_24796))
    _32393 = 0;
    else
    _32393 = (compare(_32392, _24796) == 0);
    _32392 = NOVALUE;
    if (_32393 != 0)
    goto L12; // [374] 462
    _32393 = NOVALUE;

    /** execute.e:575						switch SymTab[sub][S_TOKEN] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32395 = (object)*(((s1_ptr)_2)->base + _sub_65801);
    _2 = (object)SEQ_PTR(_32395);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _32396 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _32396 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _32395 = NOVALUE;
    if (IS_SEQUENCE(_32396) ){
        goto L13; // [391] 431
    }
    if(!IS_ATOM_INT(_32396)){
        if( (DBL_PTR(_32396)->dbl != (eudouble) ((object) DBL_PTR(_32396)->dbl) ) ){
            goto L13; // [391] 431
        }
        _0 = (object) DBL_PTR(_32396)->dbl;
    }
    else {
        _0 = _32396;
    };
    _32396 = NOVALUE;
    switch ( _0 ){ 

        /** execute.e:576							case PROC then*/
        case 27:

        /** execute.e:577								both_puts(" in procedure ")*/
        RefDS(_32399);
        _67both_puts(_32399);
        goto L14; // [405] 439

        /** execute.e:579							case FUNC then*/
        case 501:

        /** execute.e:580								both_puts(" in function ")*/
        RefDS(_32400);
        _67both_puts(_32400);
        goto L14; // [416] 439

        /** execute.e:582							case TYPE then*/
        case 504:

        /** execute.e:583								both_puts(" in type ")*/
        RefDS(_32401);
        _67both_puts(_32401);
        goto L14; // [427] 439

        /** execute.e:585							case else*/
        default:
L13: 

        /** execute.e:586								RTInternal("SymTab[sub][S_TOKEN] is not a routine")*/
        RefDS(_32402);
        _67RTInternal(_32402);
    ;}L14: 

    /** execute.e:590						both_printf("%s()", {SymTab[sub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32404 = (object)*(((s1_ptr)_2)->base + _sub_65801);
    _2 = (object)SEQ_PTR(_32404);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _32405 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _32405 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _32404 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32405);
    ((intptr_t*)_2)[1] = _32405;
    _32406 = MAKE_SEQ(_1);
    _32405 = NOVALUE;
    RefDS(_32403);
    _67both_printf(_32403, _32406);
    _32406 = NOVALUE;
L12: 

    /** execute.e:593					both_puts("\n")*/
    RefDS(_22404);
    _67both_puts(_22404);

    /** execute.e:595					if show_message then*/
    if (_show_message_65810 == 0)
    {
        goto L15; // [469] 515
    }
    else{
    }

    /** execute.e:596						if sequence(crash_msg) then*/
    _32407 = IS_SEQUENCE(_67crash_msg_65181);
    if (_32407 == 0)
    {
        _32407 = NOVALUE;
        goto L16; // [479] 493
    }
    else{
        _32407 = NOVALUE;
    }

    /** execute.e:597							clear_screen()*/
    ClearScreen();

    /** execute.e:598							puts(2, crash_msg)*/
    EPuts(2, _67crash_msg_65181); // DJP 
L16: 

    /** execute.e:600						both_puts(msg)*/
    RefDS(_msg_65799);
    _67both_puts(_msg_65799);

    /** execute.e:601						CheckSubsError()*/
    _67CheckSubsError();

    /** execute.e:602						both_puts(" \n")*/
    RefDS(_24503);
    _67both_puts(_24503);

    /** execute.e:603						show_message = FALSE*/
    _show_message_65810 = _9FALSE_439;
L15: 

    /** execute.e:606					if length(call_stack) < 2 then*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _32408 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _32408 = 1;
    }
    if (_32408 >= 2)
    goto L17; // [522] 536

    /** execute.e:607						both_puts('\n')*/
    _67both_puts(10);

    /** execute.e:608						exit*/
    goto LA; // [533] 812
L17: 

    /** execute.e:612					v = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32410 = (object)*(((s1_ptr)_2)->base + _sub_65801);
    _2 = (object)SEQ_PTR(_32410);
    _v_65802 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65802)){
        _v_65802 = (object)DBL_PTR(_v_65802)->dbl;
    }
    _32410 = NOVALUE;

    /** execute.e:614					while v != 0 and*/
L18: 
    _32412 = (_v_65802 != 0);
    if (_32412 == 0) {
        goto L19; // [561] 686
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32414 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32414);
    _32415 = (object)*(((s1_ptr)_2)->base + 4);
    _32414 = NOVALUE;
    if (IS_ATOM_INT(_32415)) {
        _32416 = (_32415 == 3);
    }
    else {
        _32416 = binary_op(EQUALS, _32415, 3);
    }
    _32415 = NOVALUE;
    if (IS_ATOM_INT(_32416)) {
        if (_32416 != 0) {
            DeRef(_32417);
            _32417 = 1;
            goto L1A; // [583] 609
        }
    }
    else {
        if (DBL_PTR(_32416)->dbl != 0.0) {
            DeRef(_32417);
            _32417 = 1;
            goto L1A; // [583] 609
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32418 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32418);
    _32419 = (object)*(((s1_ptr)_2)->base + 4);
    _32418 = NOVALUE;
    if (IS_ATOM_INT(_32419)) {
        _32420 = (_32419 == 2);
    }
    else {
        _32420 = binary_op(EQUALS, _32419, 2);
    }
    _32419 = NOVALUE;
    DeRef(_32417);
    if (IS_ATOM_INT(_32420))
    _32417 = (_32420 != 0);
    else
    _32417 = DBL_PTR(_32420)->dbl != 0.0;
L1A: 
    if (_32417 != 0) {
        DeRef(_32421);
        _32421 = 1;
        goto L1B; // [609] 635
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32422 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32422);
    _32423 = (object)*(((s1_ptr)_2)->base + 4);
    _32422 = NOVALUE;
    if (IS_ATOM_INT(_32423)) {
        _32424 = (_32423 == 9);
    }
    else {
        _32424 = binary_op(EQUALS, _32423, 9);
    }
    _32423 = NOVALUE;
    if (IS_ATOM_INT(_32424))
    _32421 = (_32424 != 0);
    else
    _32421 = DBL_PTR(_32424)->dbl != 0.0;
L1B: 
    if (_32421 == 0)
    {
        _32421 = NOVALUE;
        goto L19; // [636] 686
    }
    else{
        _32421 = NOVALUE;
    }

    /** execute.e:618						if SymTab[v][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32425 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32425);
    _32426 = (object)*(((s1_ptr)_2)->base + 4);
    _32425 = NOVALUE;
    if (binary_op_a(EQUALS, _32426, 9)){
        _32426 = NOVALUE;
        goto L1C; // [655] 665
    }
    _32426 = NOVALUE;

    /** execute.e:619							show_var(v)*/
    _67show_var(_v_65802);
L1C: 

    /** execute.e:622						v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32428 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32428);
    _v_65802 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65802)){
        _v_65802 = (object)DBL_PTR(_v_65802)->dbl;
    }
    _32428 = NOVALUE;

    /** execute.e:623					end while*/
    goto L18; // [683] 557
L19: 

    /** execute.e:625					if length(SymTab[sub][S_SAVED_PRIVATES]) > 0 and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32430 = (object)*(((s1_ptr)_2)->base + _sub_65801);
    _2 = (object)SEQ_PTR(_32430);
    _32431 = (object)*(((s1_ptr)_2)->base + 26);
    _32430 = NOVALUE;
    if (IS_SEQUENCE(_32431)){
            _32432 = SEQ_PTR(_32431)->length;
    }
    else {
        _32432 = 1;
    }
    _32431 = NOVALUE;
    _32433 = (_32432 > 0);
    _32432 = NOVALUE;
    if (_32433 == 0) {
        goto L1D; // [707] 756
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32435 = (object)*(((s1_ptr)_2)->base + _sub_65801);
    _2 = (object)SEQ_PTR(_32435);
    _32436 = (object)*(((s1_ptr)_2)->base + 26);
    _32435 = NOVALUE;
    _2 = (object)SEQ_PTR(_32436);
    _32437 = (object)*(((s1_ptr)_2)->base + 1);
    _32436 = NOVALUE;
    if (IS_ATOM_INT(_32437)) {
        _32438 = (_32437 != 0);
    }
    else {
        _32438 = binary_op(NOTEQ, _32437, 0);
    }
    _32437 = NOVALUE;
    if (_32438 == 0) {
        DeRef(_32438);
        _32438 = NOVALUE;
        goto L1D; // [732] 756
    }
    else {
        if (!IS_ATOM_INT(_32438) && DBL_PTR(_32438)->dbl == 0.0){
            DeRef(_32438);
            _32438 = NOVALUE;
            goto L1D; // [732] 756
        }
        DeRef(_32438);
        _32438 = NOVALUE;
    }
    DeRef(_32438);
    _32438 = NOVALUE;

    /** execute.e:627						SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_65801 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32439 = NOVALUE;

    /** execute.e:628						restore_privates(sub)*/
    _67restore_privates(_sub_65801);
L1D: 
L10: 

    /** execute.e:632				puts(err_file, '\n')*/
    EPuts(_67err_file_65304, 10); // DJP 

    /** execute.e:635				pc = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _32441 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _32441 = 1;
    }
    _32442 = _32441 - 1;
    _32441 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _32443 = (object)*(((s1_ptr)_2)->base + _32442);
    if (IS_ATOM_INT(_32443)) {
        _67pc_65255 = _32443 - 1;
    }
    else {
        _67pc_65255 = binary_op(MINUS, _32443, 1);
    }
    _32443 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65255)) {
        _1 = (object)(DBL_PTR(_67pc_65255)->dbl);
        DeRefDS(_67pc_65255);
        _67pc_65255 = _1;
    }

    /** execute.e:636				call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _32445 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _32445 = 1;
    }
    _32446 = _32445 - 2;
    _32445 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65273;
    RHS_Slice(_67call_stack_65273, 1, _32446);

    /** execute.e:637				levels += 1*/
    _levels_65803 = _levels_65803 + 1;

    /** execute.e:638			end while*/
    goto L9; // [809] 218
LA: 

    /** execute.e:640			tcb[current_task][TASK_STATE] = ST_DEAD -- mark as "deleted"*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _32449 = NOVALUE;

    /** execute.e:643			task = current_task*/
    _task_65805 = _67current_task_65272;

    /** execute.e:644			for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32451 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32451 = 1;
    }
    {
        object _i_65986;
        _i_65986 = 1;
L1E: 
        if (_i_65986 > _32451){
            goto L1F; // [841] 955
        }

        /** execute.e:645				if tcb[i][TASK_STATE] != ST_DEAD and*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32452 = (object)*(((s1_ptr)_2)->base + _i_65986);
        _2 = (object)SEQ_PTR(_32452);
        _32453 = (object)*(((s1_ptr)_2)->base + 4);
        _32452 = NOVALUE;
        if (IS_ATOM_INT(_32453)) {
            _32454 = (_32453 != 2);
        }
        else {
            _32454 = binary_op(NOTEQ, _32453, 2);
        }
        _32453 = NOVALUE;
        if (IS_ATOM_INT(_32454)) {
            if (_32454 == 0) {
                goto L20; // [864] 948
            }
        }
        else {
            if (DBL_PTR(_32454)->dbl == 0.0) {
                goto L20; // [864] 948
            }
        }
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32456 = (object)*(((s1_ptr)_2)->base + _i_65986);
        _2 = (object)SEQ_PTR(_32456);
        _32457 = (object)*(((s1_ptr)_2)->base + 16);
        _32456 = NOVALUE;
        if (IS_SEQUENCE(_32457)){
                _32458 = SEQ_PTR(_32457)->length;
        }
        else {
            _32458 = 1;
        }
        _32457 = NOVALUE;
        _32459 = (_32458 > 0);
        _32458 = NOVALUE;
        if (_32459 == 0)
        {
            DeRef(_32459);
            _32459 = NOVALUE;
            goto L20; // [886] 948
        }
        else{
            DeRef(_32459);
            _32459 = NOVALUE;
        }

        /** execute.e:647					current_task = i*/
        _67current_task_65272 = _i_65986;

        /** execute.e:648					call_stack = tcb[i][TASK_STACK]*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32460 = (object)*(((s1_ptr)_2)->base + _i_65986);
        DeRef(_67call_stack_65273);
        _2 = (object)SEQ_PTR(_32460);
        _67call_stack_65273 = (object)*(((s1_ptr)_2)->base + 16);
        Ref(_67call_stack_65273);
        _32460 = NOVALUE;

        /** execute.e:649					pc = tcb[i][TASK_PC]*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32462 = (object)*(((s1_ptr)_2)->base + _i_65986);
        _2 = (object)SEQ_PTR(_32462);
        _67pc_65255 = (object)*(((s1_ptr)_2)->base + 14);
        if (!IS_ATOM_INT(_67pc_65255)){
            _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
        }
        _32462 = NOVALUE;

        /** execute.e:650					Code = tcb[i][TASK_CODE]*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32464 = (object)*(((s1_ptr)_2)->base + _i_65986);
        DeRef(_27Code_20660);
        _2 = (object)SEQ_PTR(_32464);
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + 15);
        Ref(_27Code_20660);
        _32464 = NOVALUE;

        /** execute.e:651					screen_err_out = FALSE  -- just show offending task on screen*/
        _67screen_err_out_65315 = _9FALSE_439;

        /** execute.e:652					exit*/
        goto L1F; // [945] 955
L20: 

        /** execute.e:654			end for*/
        _i_65986 = _i_65986 + 1;
        goto L1E; // [950] 848
L1F: 
        ;
    }

    /** execute.e:655			if task = current_task then*/
    if (_task_65805 != _67current_task_65272)
    goto L21; // [959] 968

    /** execute.e:656				exit*/
    goto L3; // [965] 978
L21: 

    /** execute.e:658			both_puts("\n")*/
    RefDS(_22404);
    _67both_puts(_22404);

    /** execute.e:659		end while*/
    goto L2; // [975] 54
L3: 

    /** execute.e:661		puts(2, "\n--> see " & err_file_name & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_65305;
        concat_list[2] = _32467;
        Concat_N((object_ptr)&_32468, concat_list, 3);
    }
    EPuts(2, _32468); // DJP 
    DeRefDS(_32468);
    _32468 = NOVALUE;

    /** execute.e:663		puts(err_file, "\n\nGlobal & Local Variables\n")*/
    EPuts(_67err_file_65304, _32469); // DJP 

    /** execute.e:664		prev_file_no = -1*/
    _prev_file_no_65804 = -1;

    /** execute.e:665		v = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32470 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_32470);
    _v_65802 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65802)){
        _v_65802 = (object)DBL_PTR(_v_65802)->dbl;
    }
    _32470 = NOVALUE;

    /** execute.e:666		while v do*/
L22: 
    if (_v_65802 == 0)
    {
        goto L23; // [1026] 1193
    }
    else{
    }

    /** execute.e:667			if SymTab[v][S_TOKEN] = VARIABLE and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32472 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32472);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _32473 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _32473 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _32472 = NOVALUE;
    if (IS_ATOM_INT(_32473)) {
        _32474 = (_32473 == -100);
    }
    else {
        _32474 = binary_op(EQUALS, _32473, -100);
    }
    _32473 = NOVALUE;
    if (IS_ATOM_INT(_32474)) {
        if (_32474 == 0) {
            DeRef(_32475);
            _32475 = 0;
            goto L24; // [1049] 1075
        }
    }
    else {
        if (DBL_PTR(_32474)->dbl == 0.0) {
            DeRef(_32475);
            _32475 = 0;
            goto L24; // [1049] 1075
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32476 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32476);
    _32477 = (object)*(((s1_ptr)_2)->base + 3);
    _32476 = NOVALUE;
    if (IS_ATOM_INT(_32477)) {
        _32478 = (_32477 == 1);
    }
    else {
        _32478 = binary_op(EQUALS, _32477, 1);
    }
    _32477 = NOVALUE;
    DeRef(_32475);
    if (IS_ATOM_INT(_32478))
    _32475 = (_32478 != 0);
    else
    _32475 = DBL_PTR(_32478)->dbl != 0.0;
L24: 
    if (_32475 == 0) {
        goto L25; // [1075] 1172
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32480 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32480);
    _32481 = (object)*(((s1_ptr)_2)->base + 4);
    _32480 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 5;
    ((intptr_t*)_2)[2] = 6;
    ((intptr_t*)_2)[3] = 4;
    _32482 = MAKE_SEQ(_1);
    _32483 = find_from(_32481, _32482, 1);
    _32481 = NOVALUE;
    DeRefDS(_32482);
    _32482 = NOVALUE;
    if (_32483 == 0)
    {
        _32483 = NOVALUE;
        goto L25; // [1109] 1172
    }
    else{
        _32483 = NOVALUE;
    }

    /** execute.e:670				if SymTab[v][S_FILE_NO] != prev_file_no then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32484 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32484);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _32485 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _32485 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _32484 = NOVALUE;
    if (binary_op_a(EQUALS, _32485, _prev_file_no_65804)){
        _32485 = NOVALUE;
        goto L26; // [1126] 1166
    }
    _32485 = NOVALUE;

    /** execute.e:671					prev_file_no = SymTab[v][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32487 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32487);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _prev_file_no_65804 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _prev_file_no_65804 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_prev_file_no_65804)){
        _prev_file_no_65804 = (object)DBL_PTR(_prev_file_no_65804)->dbl;
    }
    _32487 = NOVALUE;

    /** execute.e:672					puts(err_file, "\n " & known_files[prev_file_no] & ":\n")*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _32490 = (object)*(((s1_ptr)_2)->base + _prev_file_no_65804);
    {
        object concat_list[3];

        concat_list[0] = _32491;
        concat_list[1] = _32490;
        concat_list[2] = _32489;
        Concat_N((object_ptr)&_32492, concat_list, 3);
    }
    _32490 = NOVALUE;
    EPuts(_67err_file_65304, _32492); // DJP 
    DeRefDS(_32492);
    _32492 = NOVALUE;
L26: 

    /** execute.e:674				show_var(v)*/
    _67show_var(_v_65802);
L25: 

    /** execute.e:676			v = SymTab[v][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32493 = (object)*(((s1_ptr)_2)->base + _v_65802);
    _2 = (object)SEQ_PTR(_32493);
    _v_65802 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_65802)){
        _v_65802 = (object)DBL_PTR(_v_65802)->dbl;
    }
    _32493 = NOVALUE;

    /** execute.e:677		end while*/
    goto L22; // [1190] 1026
L23: 

    /** execute.e:678		puts(err_file, '\n')*/
    EPuts(_67err_file_65304, 10); // DJP 

    /** execute.e:679		close(err_file)*/
    EClose(_67err_file_65304);

    /** execute.e:680	end procedure*/
    DeRefDS(_msg_65799);
    DeRef(_routine_name_65807);
    DeRefi(_title_65808);
    DeRef(_32454);
    _32454 = NOVALUE;
    DeRef(_32442);
    _32442 = NOVALUE;
    DeRef(_32424);
    _32424 = NOVALUE;
    DeRef(_32474);
    _32474 = NOVALUE;
    _32457 = NOVALUE;
    DeRef(_32433);
    _32433 = NOVALUE;
    DeRef(_32446);
    _32446 = NOVALUE;
    DeRef(_32412);
    _32412 = NOVALUE;
    _32431 = NOVALUE;
    _32356 = NOVALUE;
    DeRef(_32377);
    _32377 = NOVALUE;
    DeRef(_32420);
    _32420 = NOVALUE;
    DeRef(_32355);
    _32355 = NOVALUE;
    DeRef(_32478);
    _32478 = NOVALUE;
    DeRef(_32416);
    _32416 = NOVALUE;
    return;
    ;
}


void _67call_crash_routines()
{
    object _quit_66063 = NOVALUE;
    object _32504 = NOVALUE;
    object _32502 = NOVALUE;
    object _32501 = NOVALUE;
    object _32500 = NOVALUE;
    object _32499 = NOVALUE;
    object _32498 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:688		if crash_count > 0 then*/
    if (_67crash_count_65192 <= 0)
    goto L1; // [5] 15

    /** execute.e:689			return*/
    DeRef(_quit_66063);
    return;
L1: 

    /** execute.e:692		crash_count += 1*/
    _67crash_count_65192 = _67crash_count_65192 + 1;

    /** execute.e:695		err_file_name = "ex_crash.err"*/
    RefDS(_32497);
    DeRef(_67err_file_name_65305);
    _67err_file_name_65305 = _32497;

    /** execute.e:697		for i = length(crash_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_67crash_list_65191)){
            _32498 = SEQ_PTR(_67crash_list_65191)->length;
    }
    else {
        _32498 = 1;
    }
    {
        object _i_66069;
        _i_66069 = _32498;
L2: 
        if (_i_66069 < 1){
            goto L3; // [37] 94
        }

        /** execute.e:699			quit = call_func(forward_general_callback,*/
        _2 = (object)SEQ_PTR(_67crash_list_65191);
        _32499 = (object)*(((s1_ptr)_2)->base + _i_66069);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        Ref(_32499);
        ((intptr_t*)_2)[2] = _32499;
        ((intptr_t*)_2)[3] = 1;
        _32500 = MAKE_SEQ(_1);
        _32499 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        _32501 = MAKE_SEQ(_1);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _32500;
        ((intptr_t *)_2)[2] = _32501;
        _32502 = MAKE_SEQ(_1);
        _32501 = NOVALUE;
        _32500 = NOVALUE;
        _1 = (object)SEQ_PTR(_32502);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_67forward_general_callback_66059].addr;
        Ref( *(( (intptr_t*)_2) + 1) );
        Ref( *(( (intptr_t*)_2) + 2) );
        _1 = (*(intptr_t (*)())_0)(
                            *( ((intptr_t *)_2) + 1), 
                            *( ((intptr_t *)_2) + 2)
                             );
        DeRef(_quit_66063);
        _quit_66063 = _1;
        DeRefDS(_32502);
        _32502 = NOVALUE;

        /** execute.e:701			if not equal(quit, 0) then*/
        if (_quit_66063 == 0)
        _32504 = 1;
        else if (IS_ATOM_INT(_quit_66063) && IS_ATOM_INT(0))
        _32504 = 0;
        else
        _32504 = (compare(_quit_66063, 0) == 0);
        if (_32504 != 0)
        goto L4; // [78] 87
        _32504 = NOVALUE;

        /** execute.e:702				return -- don't call the others*/
        DeRef(_quit_66063);
        return;
L4: 

        /** execute.e:704		end for*/
        _i_66069 = _i_66069 + -1;
        goto L2; // [89] 44
L3: 
        ;
    }

    /** execute.e:705	end procedure*/
    DeRef(_quit_66063);
    return;
    ;
}


void _67quit_after_error()
{
    object _35307 = NOVALUE;
    object _32510 = NOVALUE;
    object _32508 = NOVALUE;
    object _32507 = NOVALUE;
    object _32506 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:709		write_coverage_db()*/
    _35307 = _50write_coverage_db();
    DeRef(_35307);
    _35307 = NOVALUE;

    /** execute.e:711		ifdef WINDOWS then*/

    /** execute.e:712			if not batch_job and not test_only then*/
    _32506 = (_27batch_job_20584 == 0);
    if (_32506 == 0) {
        goto L1; // [17] 41
    }
    _32508 = (_27test_only_20583 == 0);
    if (_32508 == 0)
    {
        DeRef(_32508);
        _32508 = NOVALUE;
        goto L1; // [27] 41
    }
    else{
        DeRef(_32508);
        _32508 = NOVALUE;
    }

    /** execute.e:713				puts(2, "\nPress Enter...\n")*/
    EPuts(2, _32509); // DJP 

    /** execute.e:714				getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _32510 = getKBchar();
        }
        else{
            _32510 = getc(last_r_file_ptr);
        }
    }
    else{
        _32510 = getc(last_r_file_ptr);
    }
L1: 

    /** execute.e:718		abort(1)*/
    UserCleanup(1);

    /** execute.e:719	end procedure*/
    DeRef(_32506);
    _32506 = NOVALUE;
    return;
    ;
}


void _67RTFatalType(object _x_66092)
{
    object _msg_66093 = NOVALUE;
    object _v_66094 = NOVALUE;
    object _vname_66095 = NOVALUE;
    object _32542 = NOVALUE;
    object _32538 = NOVALUE;
    object _32537 = NOVALUE;
    object _32536 = NOVALUE;
    object _32535 = NOVALUE;
    object _32533 = NOVALUE;
    object _32532 = NOVALUE;
    object _32531 = NOVALUE;
    object _32530 = NOVALUE;
    object _32528 = NOVALUE;
    object _32527 = NOVALUE;
    object _32525 = NOVALUE;
    object _32524 = NOVALUE;
    object _32523 = NOVALUE;
    object _32521 = NOVALUE;
    object _32519 = NOVALUE;
    object _32515 = NOVALUE;
    object _32513 = NOVALUE;
    object _32512 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_66092)) {
        _1 = (object)(DBL_PTR(_x_66092)->dbl);
        DeRefDS(_x_66092);
        _x_66092 = _1;
    }

    /** execute.e:726		open_err_file()*/
    _67open_err_file();

    /** execute.e:727		a = Code[x]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _x_66092);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:728		if length(SymTab[a]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32512 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_32512)){
            _32513 = SEQ_PTR(_32512)->length;
    }
    else {
        _32513 = 1;
    }
    _32512 = NOVALUE;
    if (binary_op_a(LESS, _32513, _27S_NAME_20209)){
        _32513 = NOVALUE;
        goto L1; // [32] 57
    }
    _32513 = NOVALUE;

    /** execute.e:729			vname = SymTab[a][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32515 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    DeRef(_vname_66095);
    _2 = (object)SEQ_PTR(_32515);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _vname_66095 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _vname_66095 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_vname_66095);
    _32515 = NOVALUE;
    goto L2; // [54] 65
L1: 

    /** execute.e:732			vname = "inlined variable"*/
    RefDS(_32517);
    DeRef(_vname_66095);
    _vname_66095 = _32517;
L2: 

    /** execute.e:734		msg = sprintf("type_check failure, %s is ", {vname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_vname_66095);
    ((intptr_t*)_2)[1] = _vname_66095;
    _32519 = MAKE_SEQ(_1);
    DeRefi(_msg_66093);
    _msg_66093 = EPrintf(-9999999, _32518, _32519);
    DeRefDS(_32519);
    _32519 = NOVALUE;

    /** execute.e:735		v = sprint(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32521 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_32521);
    _0 = _v_66094;
    _v_66094 = _12sprint(_32521);
    DeRef(_0);
    _32521 = NOVALUE;

    /** execute.e:736		if length(v) > 70 - length(vname) then*/
    if (IS_SEQUENCE(_v_66094)){
            _32523 = SEQ_PTR(_v_66094)->length;
    }
    else {
        _32523 = 1;
    }
    if (IS_SEQUENCE(_vname_66095)){
            _32524 = SEQ_PTR(_vname_66095)->length;
    }
    else {
        _32524 = 1;
    }
    _32525 = 70 - _32524;
    _32524 = NOVALUE;
    if (_32523 <= _32525)
    goto L3; // [105] 180

    /** execute.e:737			v = v[1..70 - length(vname)]*/
    if (IS_SEQUENCE(_vname_66095)){
            _32527 = SEQ_PTR(_vname_66095)->length;
    }
    else {
        _32527 = 1;
    }
    _32528 = 70 - _32527;
    _32527 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_66094;
    RHS_Slice(_v_66094, 1, _32528);

    /** execute.e:738			while length(v) and not find(v[$], ",}")  do*/
L4: 
    if (IS_SEQUENCE(_v_66094)){
            _32530 = SEQ_PTR(_v_66094)->length;
    }
    else {
        _32530 = 1;
    }
    if (_32530 == 0) {
        goto L5; // [131] 173
    }
    if (IS_SEQUENCE(_v_66094)){
            _32532 = SEQ_PTR(_v_66094)->length;
    }
    else {
        _32532 = 1;
    }
    _2 = (object)SEQ_PTR(_v_66094);
    _32533 = (object)*(((s1_ptr)_2)->base + _32532);
    _32535 = find_from(_32533, _32534, 1);
    _32533 = NOVALUE;
    _32536 = (_32535 == 0);
    _32535 = NOVALUE;
    if (_32536 == 0)
    {
        DeRef(_32536);
        _32536 = NOVALUE;
        goto L5; // [151] 173
    }
    else{
        DeRef(_32536);
        _32536 = NOVALUE;
    }

    /** execute.e:739				v = v[1..$-1]*/
    if (IS_SEQUENCE(_v_66094)){
            _32537 = SEQ_PTR(_v_66094)->length;
    }
    else {
        _32537 = 1;
    }
    _32538 = _32537 - 1;
    _32537 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_66094;
    RHS_Slice(_v_66094, 1, _32538);

    /** execute.e:740			end while*/
    goto L4; // [170] 128
L5: 

    /** execute.e:741			v = v & " ..."*/
    Concat((object_ptr)&_v_66094, _v_66094, _32540);
L3: 

    /** execute.e:743		trace_back(msg & v)*/
    Concat((object_ptr)&_32542, _msg_66093, _v_66094);
    _67trace_back(_32542);
    _32542 = NOVALUE;

    /** execute.e:744		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:745		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:746	end procedure*/
    DeRefDSi(_msg_66093);
    DeRefDS(_v_66094);
    DeRef(_vname_66095);
    DeRef(_32538);
    _32538 = NOVALUE;
    _32512 = NOVALUE;
    DeRef(_32528);
    _32528 = NOVALUE;
    DeRef(_32525);
    _32525 = NOVALUE;
    return;
    ;
}


void _67RTFatal(object _msg_66140)
{
    object _0, _1, _2;
    

    /** execute.e:750		open_err_file()*/
    _67open_err_file();

    /** execute.e:751		trace_back(msg)*/
    RefDS(_msg_66140);
    _67trace_back(_msg_66140);

    /** execute.e:752		call_crash_routines()*/
    _67call_crash_routines();

    /** execute.e:753		quit_after_error()*/
    _67quit_after_error();

    /** execute.e:754	end procedure*/
    DeRefDS(_msg_66140);
    return;
    ;
}


void _67RTInternal(object _msg_66143)
{
    object _0, _1, _2;
    

    /** execute.e:761		machine_proc(67, msg)*/
    machine(67, _msg_66143);

    /** execute.e:762	end procedure*/
    DeRefDSi(_msg_66143);
    return;
    ;
}


void _67wait(object _t_66146)
{
    object _t1_66147 = NOVALUE;
    object _t2_66148 = NOVALUE;
    object _32548 = NOVALUE;
    object _32546 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:771		t1 = floor(t)*/
    DeRef(_t1_66147);
    if (IS_ATOM_INT(_t_66146))
    _t1_66147 = e_floor(_t_66146);
    else
    _t1_66147 = unary_op(FLOOR, _t_66146);

    /** execute.e:772		if t1 >= 1 then*/
    if (binary_op_a(LESS, _t1_66147, 1)){
        goto L1; // [8] 24
    }

    /** execute.e:773			sleep(t1)*/
    Ref(_t1_66147);
    _3sleep(_t1_66147);

    /** execute.e:774			t -= t1*/
    _0 = _t_66146;
    if (IS_ATOM_INT(_t_66146) && IS_ATOM_INT(_t1_66147)) {
        _t_66146 = _t_66146 - _t1_66147;
        if ((object)((uintptr_t)_t_66146 +(uintptr_t) HIGH_BITS) >= 0){
            _t_66146 = NewDouble((eudouble)_t_66146);
        }
    }
    else {
        if (IS_ATOM_INT(_t_66146)) {
            _t_66146 = NewDouble((eudouble)_t_66146 - DBL_PTR(_t1_66147)->dbl);
        }
        else {
            if (IS_ATOM_INT(_t1_66147)) {
                _t_66146 = NewDouble(DBL_PTR(_t_66146)->dbl - (eudouble)_t1_66147);
            }
            else
            _t_66146 = NewDouble(DBL_PTR(_t_66146)->dbl - DBL_PTR(_t1_66147)->dbl);
        }
    }
    DeRef(_0);
L1: 

    /** execute.e:777		t2 = time() + t*/
    DeRef(_32546);
    _32546 = NewDouble(current_time());
    DeRef(_t2_66148);
    if (IS_ATOM_INT(_t_66146)) {
        _t2_66148 = NewDouble(DBL_PTR(_32546)->dbl + (eudouble)_t_66146);
    }
    else
    _t2_66148 = NewDouble(DBL_PTR(_32546)->dbl + DBL_PTR(_t_66146)->dbl);
    DeRefDS(_32546);
    _32546 = NOVALUE;

    /** execute.e:778		while time() < t2 do*/
L2: 
    DeRef(_32548);
    _32548 = NewDouble(current_time());
    if (binary_op_a(GREATEREQ, _32548, _t2_66148)){
        DeRefDS(_32548);
        _32548 = NOVALUE;
        goto L3; // [39] 48
    }
    DeRef(_32548);
    _32548 = NOVALUE;

    /** execute.e:779		end while*/
    goto L2; // [45] 37
L3: 

    /** execute.e:780	end procedure*/
    DeRef(_t_66146);
    DeRef(_t1_66147);
    DeRef(_t2_66148);
    return;
    ;
}


void _67scheduler()
{
    object _earliest_time_66164 = NOVALUE;
    object _start_time_66165 = NOVALUE;
    object _now_66166 = NOVALUE;
    object _ts_found_66168 = NOVALUE;
    object _tp_66169 = NOVALUE;
    object _p_66170 = NOVALUE;
    object _earliest_task_66171 = NOVALUE;
    object _32625 = NOVALUE;
    object _32624 = NOVALUE;
    object _32621 = NOVALUE;
    object _32620 = NOVALUE;
    object _32619 = NOVALUE;
    object _32618 = NOVALUE;
    object _32617 = NOVALUE;
    object _32615 = NOVALUE;
    object _32614 = NOVALUE;
    object _32612 = NOVALUE;
    object _32610 = NOVALUE;
    object _32608 = NOVALUE;
    object _32606 = NOVALUE;
    object _32604 = NOVALUE;
    object _32602 = NOVALUE;
    object _32599 = NOVALUE;
    object _32597 = NOVALUE;
    object _32596 = NOVALUE;
    object _32594 = NOVALUE;
    object _32593 = NOVALUE;
    object _32590 = NOVALUE;
    object _32588 = NOVALUE;
    object _32582 = NOVALUE;
    object _32578 = NOVALUE;
    object _32577 = NOVALUE;
    object _32575 = NOVALUE;
    object _32573 = NOVALUE;
    object _32571 = NOVALUE;
    object _32570 = NOVALUE;
    object _32569 = NOVALUE;
    object _32568 = NOVALUE;
    object _32567 = NOVALUE;
    object _32566 = NOVALUE;
    object _32565 = NOVALUE;
    object _32563 = NOVALUE;
    object _32558 = NOVALUE;
    object _32554 = NOVALUE;
    object _32552 = NOVALUE;
    object _32551 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:789		sequence tp*/

    /** execute.e:790		integer p, earliest_task*/

    /** execute.e:795		earliest_task = rt_first*/
    _earliest_task_66171 = _67rt_first_65301;

    /** execute.e:797		if clock_stopped or earliest_task = 0 then*/
    if (_67clock_stopped_66160 != 0) {
        goto L1; // [16] 29
    }
    _32551 = (_earliest_task_66171 == 0);
    if (_32551 == 0)
    {
        DeRef(_32551);
        _32551 = NOVALUE;
        goto L2; // [25] 42
    }
    else{
        DeRef(_32551);
        _32551 = NOVALUE;
    }
L1: 

    /** execute.e:799			start_time = 1*/
    DeRef(_start_time_66165);
    _start_time_66165 = 1;

    /** execute.e:800			now = -1*/
    DeRef(_now_66166);
    _now_66166 = -1;
    goto L3; // [39] 232
L2: 

    /** execute.e:804			earliest_time = tcb[earliest_task][TASK_MAX_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32552 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    DeRef(_earliest_time_66164);
    _2 = (object)SEQ_PTR(_32552);
    _earliest_time_66164 = (object)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_66164);
    _32552 = NOVALUE;

    /** execute.e:806			p = tcb[rt_first][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32554 = (object)*(((s1_ptr)_2)->base + _67rt_first_65301);
    _2 = (object)SEQ_PTR(_32554);
    _p_66170 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_66170)){
        _p_66170 = (object)DBL_PTR(_p_66170)->dbl;
    }
    _32554 = NOVALUE;

    /** execute.e:807			while p != 0 do*/
L4: 
    if (_p_66170 == 0)
    goto L5; // [75] 122

    /** execute.e:808				tp = tcb[p]*/
    DeRef(_tp_66169);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _tp_66169 = (object)*(((s1_ptr)_2)->base + _p_66170);
    RefDS(_tp_66169);

    /** execute.e:809				if tp[TASK_MAX_TIME] < earliest_time then*/
    _2 = (object)SEQ_PTR(_tp_66169);
    _32558 = (object)*(((s1_ptr)_2)->base + 9);
    if (binary_op_a(GREATEREQ, _32558, _earliest_time_66164)){
        _32558 = NOVALUE;
        goto L6; // [95] 111
    }
    _32558 = NOVALUE;

    /** execute.e:810					earliest_task = p*/
    _earliest_task_66171 = _p_66170;

    /** execute.e:811					earliest_time = tp[TASK_MAX_TIME]*/
    DeRef(_earliest_time_66164);
    _2 = (object)SEQ_PTR(_tp_66169);
    _earliest_time_66164 = (object)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_66164);
L6: 

    /** execute.e:813				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_66169);
    _p_66170 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_66170))
    _p_66170 = (object)DBL_PTR(_p_66170)->dbl;

    /** execute.e:814			end while*/
    goto L4; // [119] 75
L5: 

    /** execute.e:817			now = time()*/
    DeRef(_now_66166);
    _now_66166 = NewDouble(current_time());

    /** execute.e:819			start_time = tcb[earliest_task][TASK_MIN_TIME]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32563 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    DeRef(_start_time_66165);
    _2 = (object)SEQ_PTR(_32563);
    _start_time_66165 = (object)*(((s1_ptr)_2)->base + 8);
    Ref(_start_time_66165);
    _32563 = NOVALUE;

    /** execute.e:821			if earliest_task = current_task and*/
    _32565 = (_earliest_task_66171 == _67current_task_65272);
    if (_32565 == 0) {
        goto L7; // [146] 173
    }
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32567 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32567);
    _32568 = (object)*(((s1_ptr)_2)->base + 10);
    _32567 = NOVALUE;
    if (IS_ATOM_INT(_32568)) {
        _32569 = (_32568 > 0);
    }
    else {
        _32569 = binary_op(GREATER, _32568, 0);
    }
    _32568 = NOVALUE;
    if (_32569 == 0) {
        DeRef(_32569);
        _32569 = NOVALUE;
        goto L7; // [167] 173
    }
    else {
        if (!IS_ATOM_INT(_32569) && DBL_PTR(_32569)->dbl == 0.0){
            DeRef(_32569);
            _32569 = NOVALUE;
            goto L7; // [167] 173
        }
        DeRef(_32569);
        _32569 = NOVALUE;
    }
    DeRef(_32569);
    _32569 = NOVALUE;
    goto L8; // [170] 231
L7: 

    /** execute.e:825				if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32570 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32570);
    _32571 = (object)*(((s1_ptr)_2)->base + 3);
    _32570 = NOVALUE;
    if (binary_op_a(NOTEQ, _32571, 1)){
        _32571 = NOVALUE;
        goto L9; // [187] 207
    }
    _32571 = NOVALUE;

    /** execute.e:826					tcb[current_task][TASK_RUNS_LEFT] = 0*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32573 = NOVALUE;
L9: 

    /** execute.e:828				tcb[earliest_task][TASK_RUNS_LEFT] = tcb[earliest_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_66171 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32577 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    _2 = (object)SEQ_PTR(_32577);
    _32578 = (object)*(((s1_ptr)_2)->base + 11);
    _32577 = NOVALUE;
    Ref(_32578);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32578;
    if( _1 != _32578 ){
        DeRef(_1);
    }
    _32578 = NOVALUE;
    _32575 = NOVALUE;
L8: 
L3: 

    /** execute.e:832		if start_time > now then*/
    if (binary_op_a(LESSEQ, _start_time_66165, _now_66166)){
        goto LA; // [238] 416
    }

    /** execute.e:836			ts_found = FALSE*/
    _ts_found_66168 = _9FALSE_439;

    /** execute.e:837			p = ts_first*/
    _p_66170 = _67ts_first_65302;

    /** execute.e:838			while p != 0 do*/
LB: 
    if (_p_66170 == 0)
    goto LC; // [261] 313

    /** execute.e:839				tp = tcb[p]*/
    DeRef(_tp_66169);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _tp_66169 = (object)*(((s1_ptr)_2)->base + _p_66170);
    RefDS(_tp_66169);

    /** execute.e:840				if tp[TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_tp_66169);
    _32582 = (object)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(LESSEQ, _32582, 0)){
        _32582 = NOVALUE;
        goto LD; // [281] 302
    }
    _32582 = NOVALUE;

    /** execute.e:841					  earliest_task = p*/
    _earliest_task_66171 = _p_66170;

    /** execute.e:842					  ts_found = TRUE*/
    _ts_found_66168 = _9TRUE_441;

    /** execute.e:843					  exit*/
    goto LC; // [299] 313
LD: 

    /** execute.e:845				p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_66169);
    _p_66170 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_66170))
    _p_66170 = (object)DBL_PTR(_p_66170)->dbl;

    /** execute.e:846			end while*/
    goto LB; // [310] 261
LC: 

    /** execute.e:848			if not ts_found then*/
    if (_ts_found_66168 != 0)
    goto LE; // [315] 378

    /** execute.e:851				p = ts_first*/
    _p_66170 = _67ts_first_65302;

    /** execute.e:852				while p != 0 do*/
LF: 
    if (_p_66170 == 0)
    goto L10; // [330] 377

    /** execute.e:853					tp = tcb[p]*/
    DeRef(_tp_66169);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _tp_66169 = (object)*(((s1_ptr)_2)->base + _p_66170);
    RefDS(_tp_66169);

    /** execute.e:854					earliest_task = p*/
    _earliest_task_66171 = _p_66170;

    /** execute.e:855					tcb[p][TASK_RUNS_LEFT] = tp[TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_66170 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_tp_66169);
    _32590 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_32590);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32590;
    if( _1 != _32590 ){
        DeRef(_1);
    }
    _32590 = NOVALUE;
    _32588 = NOVALUE;

    /** execute.e:856					p = tp[TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_tp_66169);
    _p_66170 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_66170))
    _p_66170 = (object)DBL_PTR(_p_66170)->dbl;

    /** execute.e:857				end while*/
    goto LF; // [374] 330
L10: 
LE: 

    /** execute.e:860			if earliest_task = 0 then*/
    if (_earliest_task_66171 != 0)
    goto L11; // [380] 389

    /** execute.e:863				abort(0)*/
    UserCleanup(0);
L11: 

    /** execute.e:866			if tcb[earliest_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32593 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    _2 = (object)SEQ_PTR(_32593);
    _32594 = (object)*(((s1_ptr)_2)->base + 3);
    _32593 = NOVALUE;
    if (binary_op_a(NOTEQ, _32594, 1)){
        _32594 = NOVALUE;
        goto L12; // [401] 415
    }
    _32594 = NOVALUE;

    /** execute.e:868				wait(start_time - now)*/
    if (IS_ATOM_INT(_start_time_66165) && IS_ATOM_INT(_now_66166)) {
        _32596 = _start_time_66165 - _now_66166;
        if ((object)((uintptr_t)_32596 +(uintptr_t) HIGH_BITS) >= 0){
            _32596 = NewDouble((eudouble)_32596);
        }
    }
    else {
        if (IS_ATOM_INT(_start_time_66165)) {
            _32596 = NewDouble((eudouble)_start_time_66165 - DBL_PTR(_now_66166)->dbl);
        }
        else {
            if (IS_ATOM_INT(_now_66166)) {
                _32596 = NewDouble(DBL_PTR(_start_time_66165)->dbl - (eudouble)_now_66166);
            }
            else
            _32596 = NewDouble(DBL_PTR(_start_time_66165)->dbl - DBL_PTR(_now_66166)->dbl);
        }
    }
    _67wait(_32596);
    _32596 = NOVALUE;
L12: 
LA: 

    /** execute.e:873		tcb[earliest_task][TASK_START] = time()*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_earliest_task_66171 + ((s1_ptr)_2)->base);
    DeRef(_32599);
    _32599 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32599;
    if( _1 != _32599 ){
        DeRef(_1);
    }
    _32599 = NOVALUE;
    _32597 = NOVALUE;

    /** execute.e:875		if earliest_task = current_task then*/
    if (_earliest_task_66171 != _67current_task_65272)
    goto L13; // [435] 450

    /** execute.e:876			pc += 1  -- continue with current task*/
    _67pc_65255 = _67pc_65255 + 1;
    goto L14; // [447] 663
L13: 

    /** execute.e:881			tcb[current_task][TASK_CODE] = Code*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _32602 = NOVALUE;

    /** execute.e:882			tcb[current_task][TASK_PC] = pc*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67pc_65255;
    DeRef(_1);
    _32604 = NOVALUE;

    /** execute.e:883			tcb[current_task][TASK_STACK] = call_stack*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    RefDS(_67call_stack_65273);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67call_stack_65273;
    DeRef(_1);
    _32606 = NOVALUE;

    /** execute.e:886			Code = tcb[earliest_task][TASK_CODE]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32608 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    DeRefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(_32608);
    _27Code_20660 = (object)*(((s1_ptr)_2)->base + 15);
    Ref(_27Code_20660);
    _32608 = NOVALUE;

    /** execute.e:887			pc = tcb[earliest_task][TASK_PC]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32610 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    _2 = (object)SEQ_PTR(_32610);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + 14);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
    _32610 = NOVALUE;

    /** execute.e:888			call_stack = tcb[earliest_task][TASK_STACK]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32612 = (object)*(((s1_ptr)_2)->base + _earliest_task_66171);
    DeRefDS(_67call_stack_65273);
    _2 = (object)SEQ_PTR(_32612);
    _67call_stack_65273 = (object)*(((s1_ptr)_2)->base + 16);
    Ref(_67call_stack_65273);
    _32612 = NOVALUE;

    /** execute.e:890			current_task = earliest_task*/
    _67current_task_65272 = _earliest_task_66171;

    /** execute.e:892			if tcb[current_task][TASK_PC] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32614 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32614);
    _32615 = (object)*(((s1_ptr)_2)->base + 14);
    _32614 = NOVALUE;
    if (binary_op_a(NOTEQ, _32615, 0)){
        _32615 = NOVALUE;
        goto L15; // [562] 639
    }
    _32615 = NOVALUE;

    /** execute.e:895				pc = 1*/
    _67pc_65255 = 1;

    /** execute.e:896				val[t_id] = tcb[current_task][TASK_RID]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32617 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32617);
    _32618 = (object)*(((s1_ptr)_2)->base + 1);
    _32617 = NOVALUE;
    Ref(_32618);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_65186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32618;
    if( _1 != _32618 ){
        DeRef(_1);
    }
    _32618 = NOVALUE;

    /** execute.e:897				val[t_arglist] = tcb[current_task][TASK_ARGS]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32619 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32619);
    _32620 = (object)*(((s1_ptr)_2)->base + 13);
    _32619 = NOVALUE;
    Ref(_32620);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32620;
    if( _1 != _32620 ){
        DeRef(_1);
    }
    _32620 = NOVALUE;

    /** execute.e:898				new_arg_assign()*/
    _32621 = _67new_arg_assign();

    /** execute.e:899				Code = {CALL_PROC, t_id, t_arglist}*/
    _0 = _27Code_20660;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 136;
    ((intptr_t*)_2)[2] = _67t_id_65186;
    ((intptr_t*)_2)[3] = _67t_arglist_65187;
    _27Code_20660 = MAKE_SEQ(_1);
    DeRefDS(_0);
    goto L16; // [636] 662
L15: 

    /** execute.e:902				pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:903				restore_privates(call_stack[$])*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _32624 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _32624 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _32625 = (object)*(((s1_ptr)_2)->base + _32624);
    Ref(_32625);
    _67restore_privates(_32625);
    _32625 = NOVALUE;
L16: 
L14: 

    /** execute.e:906	end procedure*/
    DeRef(_earliest_time_66164);
    DeRef(_start_time_66165);
    DeRef(_now_66166);
    DeRef(_tp_66169);
    DeRef(_32565);
    _32565 = NOVALUE;
    DeRef(_32621);
    _32621 = NOVALUE;
    return;
    ;
}


object _67task_insert(object _first_66274, object _task_66275)
{
    object _32626 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:910		tcb[task][TASK_NEXT] = first*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66275 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _first_66274;
    DeRef(_1);
    _32626 = NOVALUE;

    /** execute.e:911		return task*/
    return _task_66275;
    ;
}


object _67task_delete(object _first_66280, object _task_66281)
{
    object _p_66282 = NOVALUE;
    object _prev_p_66283 = NOVALUE;
    object _32637 = NOVALUE;
    object _32636 = NOVALUE;
    object _32635 = NOVALUE;
    object _32633 = NOVALUE;
    object _32632 = NOVALUE;
    object _32631 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:918		prev_p = -1*/
    _prev_p_66283 = -1;

    /** execute.e:919		p = first*/
    _p_66282 = _first_66280;

    /** execute.e:920		while p != 0 do*/
L1: 
    if (_p_66282 == 0)
    goto L2; // [20] 110

    /** execute.e:921			if p = task then*/
    if (_p_66282 != _task_66281)
    goto L3; // [26] 86

    /** execute.e:922				if prev_p = -1 then*/
    if (_prev_p_66283 != -1)
    goto L4; // [32] 55

    /** execute.e:924					return tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32631 = (object)*(((s1_ptr)_2)->base + _p_66282);
    _2 = (object)SEQ_PTR(_32631);
    _32632 = (object)*(((s1_ptr)_2)->base + 12);
    _32631 = NOVALUE;
    Ref(_32632);
    return _32632;
    goto L5; // [52] 85
L4: 

    /** execute.e:927					tcb[prev_p][TASK_NEXT] = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_p_66283 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32635 = (object)*(((s1_ptr)_2)->base + _p_66282);
    _2 = (object)SEQ_PTR(_32635);
    _32636 = (object)*(((s1_ptr)_2)->base + 12);
    _32635 = NOVALUE;
    Ref(_32636);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32636;
    if( _1 != _32636 ){
        DeRef(_1);
    }
    _32636 = NOVALUE;
    _32633 = NOVALUE;

    /** execute.e:928					return first*/
    _32632 = NOVALUE;
    return _first_66280;
L5: 
L3: 

    /** execute.e:931			prev_p = p*/
    _prev_p_66283 = _p_66282;

    /** execute.e:932			p = tcb[p][TASK_NEXT]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32637 = (object)*(((s1_ptr)_2)->base + _p_66282);
    _2 = (object)SEQ_PTR(_32637);
    _p_66282 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_66282)){
        _p_66282 = (object)DBL_PTR(_p_66282)->dbl;
    }
    _32637 = NOVALUE;

    /** execute.e:933		end while*/
    goto L1; // [107] 20
L2: 

    /** execute.e:935		return first*/
    _32632 = NOVALUE;
    return _first_66280;
    ;
}


void _67opTASK_YIELD()
{
    object _now_66301 = NOVALUE;
    object _32687 = NOVALUE;
    object _32686 = NOVALUE;
    object _32685 = NOVALUE;
    object _32683 = NOVALUE;
    object _32682 = NOVALUE;
    object _32681 = NOVALUE;
    object _32680 = NOVALUE;
    object _32678 = NOVALUE;
    object _32677 = NOVALUE;
    object _32676 = NOVALUE;
    object _32675 = NOVALUE;
    object _32673 = NOVALUE;
    object _32672 = NOVALUE;
    object _32671 = NOVALUE;
    object _32670 = NOVALUE;
    object _32668 = NOVALUE;
    object _32667 = NOVALUE;
    object _32666 = NOVALUE;
    object _32664 = NOVALUE;
    object _32661 = NOVALUE;
    object _32660 = NOVALUE;
    object _32659 = NOVALUE;
    object _32658 = NOVALUE;
    object _32657 = NOVALUE;
    object _32656 = NOVALUE;
    object _32655 = NOVALUE;
    object _32654 = NOVALUE;
    object _32653 = NOVALUE;
    object _32650 = NOVALUE;
    object _32649 = NOVALUE;
    object _32648 = NOVALUE;
    object _32647 = NOVALUE;
    object _32645 = NOVALUE;
    object _32643 = NOVALUE;
    object _32642 = NOVALUE;
    object _32640 = NOVALUE;
    object _32639 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:943		if tcb[current_task][TASK_STATE] = ST_ACTIVE then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32639 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32639);
    _32640 = (object)*(((s1_ptr)_2)->base + 4);
    _32639 = NOVALUE;
    if (binary_op_a(NOTEQ, _32640, 0)){
        _32640 = NOVALUE;
        goto L1; // [15] 312
    }
    _32640 = NOVALUE;

    /** execute.e:944			if tcb[current_task][TASK_RUNS_LEFT] > 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32642 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32642);
    _32643 = (object)*(((s1_ptr)_2)->base + 10);
    _32642 = NOVALUE;
    if (binary_op_a(LESSEQ, _32643, 0)){
        _32643 = NOVALUE;
        goto L2; // [33] 61
    }
    _32643 = NOVALUE;

    /** execute.e:945				tcb[current_task][TASK_RUNS_LEFT] -= 1*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _32647 = (object)*(((s1_ptr)_2)->base + 10);
    _32645 = NOVALUE;
    if (IS_ATOM_INT(_32647)) {
        _32648 = _32647 - 1;
        if ((object)((uintptr_t)_32648 +(uintptr_t) HIGH_BITS) >= 0){
            _32648 = NewDouble((eudouble)_32648);
        }
    }
    else {
        _32648 = binary_op(MINUS, _32647, 1);
    }
    _32647 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32648;
    if( _1 != _32648 ){
        DeRef(_1);
    }
    _32648 = NOVALUE;
    _32645 = NOVALUE;
L2: 

    /** execute.e:947			if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32649 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32649);
    _32650 = (object)*(((s1_ptr)_2)->base + 3);
    _32649 = NOVALUE;
    if (binary_op_a(NOTEQ, _32650, 1)){
        _32650 = NOVALUE;
        goto L3; // [75] 311
    }
    _32650 = NOVALUE;

    /** execute.e:948				now = time()*/
    DeRef(_now_66301);
    _now_66301 = NewDouble(current_time());

    /** execute.e:949				if tcb[current_task][TASK_RUNS_MAX] > 1 and*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32653 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32653);
    _32654 = (object)*(((s1_ptr)_2)->base + 11);
    _32653 = NOVALUE;
    if (IS_ATOM_INT(_32654)) {
        _32655 = (_32654 > 1);
    }
    else {
        _32655 = binary_op(GREATER, _32654, 1);
    }
    _32654 = NOVALUE;
    if (IS_ATOM_INT(_32655)) {
        if (_32655 == 0) {
            goto L4; // [101] 247
        }
    }
    else {
        if (DBL_PTR(_32655)->dbl == 0.0) {
            goto L4; // [101] 247
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32657 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32657);
    _32658 = (object)*(((s1_ptr)_2)->base + 5);
    _32657 = NOVALUE;
    _32659 = binary_op(EQUALS, _32658, _now_66301);
    _32658 = NOVALUE;
    if (_32659 == 0) {
        DeRef(_32659);
        _32659 = NOVALUE;
        goto L4; // [122] 247
    }
    else {
        if (!IS_ATOM_INT(_32659) && DBL_PTR(_32659)->dbl == 0.0){
            DeRef(_32659);
            _32659 = NOVALUE;
            goto L4; // [122] 247
        }
        DeRef(_32659);
        _32659 = NOVALUE;
    }
    DeRef(_32659);
    _32659 = NOVALUE;

    /** execute.e:952					if tcb[current_task][TASK_RUNS_LEFT] = 0 then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32660 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32660);
    _32661 = (object)*(((s1_ptr)_2)->base + 10);
    _32660 = NOVALUE;
    if (binary_op_a(NOTEQ, _32661, 0)){
        _32661 = NOVALUE;
        goto L5; // [139] 310
    }
    _32661 = NOVALUE;

    /** execute.e:954						now += clock_period*/
    _0 = _now_66301;
    if (IS_ATOM_INT(_now_66301)) {
        _now_66301 = NewDouble((eudouble)_now_66301 + DBL_PTR(_67clock_period_65275)->dbl);
    }
    else {
        _now_66301 = NewDouble(DBL_PTR(_now_66301)->dbl + DBL_PTR(_67clock_period_65275)->dbl);
    }
    DeRef(_0);

    /** execute.e:955						tcb[current_task][TASK_RUNS_LEFT] = tcb[current_task][TASK_RUNS_MAX]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32666 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32666);
    _32667 = (object)*(((s1_ptr)_2)->base + 11);
    _32666 = NOVALUE;
    Ref(_32667);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32667;
    if( _1 != _32667 ){
        DeRef(_1);
    }
    _32667 = NOVALUE;
    _32664 = NOVALUE;

    /** execute.e:956						tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32670 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32670);
    _32671 = (object)*(((s1_ptr)_2)->base + 6);
    _32670 = NOVALUE;
    _32672 = binary_op(PLUS, _now_66301, _32671);
    _32671 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32672;
    if( _1 != _32672 ){
        DeRef(_1);
    }
    _32672 = NOVALUE;
    _32668 = NOVALUE;

    /** execute.e:958						tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32675 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32675);
    _32676 = (object)*(((s1_ptr)_2)->base + 7);
    _32675 = NOVALUE;
    _32677 = binary_op(PLUS, _now_66301, _32676);
    _32676 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32677;
    if( _1 != _32677 ){
        DeRef(_1);
    }
    _32677 = NOVALUE;
    _32673 = NOVALUE;
    goto L5; // [240] 310
    goto L5; // [244] 310
L4: 

    /** execute.e:965					tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32680 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32680);
    _32681 = (object)*(((s1_ptr)_2)->base + 6);
    _32680 = NOVALUE;
    if (IS_ATOM_INT(_now_66301) && IS_ATOM_INT(_32681)) {
        _32682 = _now_66301 + _32681;
        if ((object)((uintptr_t)_32682 + (uintptr_t)HIGH_BITS) >= 0){
            _32682 = NewDouble((eudouble)_32682);
        }
    }
    else {
        _32682 = binary_op(PLUS, _now_66301, _32681);
    }
    _32681 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32682;
    if( _1 != _32682 ){
        DeRef(_1);
    }
    _32682 = NOVALUE;
    _32678 = NOVALUE;

    /** execute.e:967					tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67current_task_65272 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32685 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32685);
    _32686 = (object)*(((s1_ptr)_2)->base + 7);
    _32685 = NOVALUE;
    if (IS_ATOM_INT(_now_66301) && IS_ATOM_INT(_32686)) {
        _32687 = _now_66301 + _32686;
        if ((object)((uintptr_t)_32687 + (uintptr_t)HIGH_BITS) >= 0){
            _32687 = NewDouble((eudouble)_32687);
        }
    }
    else {
        _32687 = binary_op(PLUS, _now_66301, _32686);
    }
    _32686 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32687;
    if( _1 != _32687 ){
        DeRef(_1);
    }
    _32687 = NOVALUE;
    _32683 = NOVALUE;
L5: 
L3: 
L1: 

    /** execute.e:972		scheduler()*/
    _67scheduler();

    /** execute.e:973	end procedure*/
    DeRef(_now_66301);
    DeRef(_32655);
    _32655 = NOVALUE;
    return;
    ;
}


void _67kill_task(object _task_66360)
{
    object _32693 = NOVALUE;
    object _32689 = NOVALUE;
    object _32688 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:977		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32688 = (object)*(((s1_ptr)_2)->base + _task_66360);
    _2 = (object)SEQ_PTR(_32688);
    _32689 = (object)*(((s1_ptr)_2)->base + 3);
    _32688 = NOVALUE;
    if (binary_op_a(NOTEQ, _32689, 1)){
        _32689 = NOVALUE;
        goto L1; // [15] 33
    }
    _32689 = NOVALUE;

    /** execute.e:978			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_65301, _task_66360);
    _67rt_first_65301 = _0;
    if (!IS_ATOM_INT(_67rt_first_65301)) {
        _1 = (object)(DBL_PTR(_67rt_first_65301)->dbl);
        DeRefDS(_67rt_first_65301);
        _67rt_first_65301 = _1;
    }
    goto L2; // [30] 45
L1: 

    /** execute.e:980			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_65302, _task_66360);
    _67ts_first_65302 = _0;
    if (!IS_ATOM_INT(_67ts_first_65302)) {
        _1 = (object)(DBL_PTR(_67ts_first_65302)->dbl);
        DeRefDS(_67ts_first_65302);
        _67ts_first_65302 = _1;
    }
L2: 

    /** execute.e:982		tcb[task][TASK_STATE] = ST_DEAD*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66360 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _32693 = NOVALUE;

    /** execute.e:984	end procedure*/
    return;
    ;
}


object _67which_task(object _tid_66372)
{
    object _32697 = NOVALUE;
    object _32696 = NOVALUE;
    object _32695 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:989		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32695 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32695 = 1;
    }
    {
        object _i_66374;
        _i_66374 = 1;
L1: 
        if (_i_66374 > _32695){
            goto L2; // [8] 45
        }

        /** execute.e:990			if tcb[i][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32696 = (object)*(((s1_ptr)_2)->base + _i_66374);
        _2 = (object)SEQ_PTR(_32696);
        _32697 = (object)*(((s1_ptr)_2)->base + 2);
        _32696 = NOVALUE;
        if (binary_op_a(NOTEQ, _32697, _tid_66372)){
            _32697 = NOVALUE;
            goto L3; // [27] 38
        }
        _32697 = NOVALUE;

        /** execute.e:991				return i*/
        DeRef(_tid_66372);
        return _i_66374;
L3: 

        /** execute.e:993		end for*/
        _i_66374 = _i_66374 + 1;
        goto L1; // [40] 15
L2: 
        ;
    }

    /** execute.e:994		RTFatal("invalid task id")*/
    RefDS(_32699);
    _67RTFatal(_32699);
    ;
}


void _67opTASK_STATUS()
{
    object _r_66383 = NOVALUE;
    object _tid_66384 = NOVALUE;
    object _32713 = NOVALUE;
    object _32712 = NOVALUE;
    object _32710 = NOVALUE;
    object _32709 = NOVALUE;
    object _32707 = NOVALUE;
    object _32706 = NOVALUE;
    object _32705 = NOVALUE;
    object _32702 = NOVALUE;
    object _32700 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1003		a = Code[pc+1]*/
    _32700 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _32700);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1004		target = Code[pc+2]*/
    _32702 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _32702);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1005		tid = val[a]*/
    DeRef(_tid_66384);
    _2 = (object)SEQ_PTR(_67val_65265);
    _tid_66384 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_tid_66384);

    /** execute.e:1006		r = -1*/
    _r_66383 = -1;

    /** execute.e:1007		for t = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32705 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32705 = 1;
    }
    {
        object _t_66393;
        _t_66393 = 1;
L1: 
        if (_t_66393 > _32705){
            goto L2; // [55] 137
        }

        /** execute.e:1008			if tcb[t][TASK_TID] = tid then*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32706 = (object)*(((s1_ptr)_2)->base + _t_66393);
        _2 = (object)SEQ_PTR(_32706);
        _32707 = (object)*(((s1_ptr)_2)->base + 2);
        _32706 = NOVALUE;
        if (binary_op_a(NOTEQ, _32707, _tid_66384)){
            _32707 = NOVALUE;
            goto L3; // [74] 130
        }
        _32707 = NOVALUE;

        /** execute.e:1009				if tcb[t][TASK_STATE] = ST_ACTIVE then*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32709 = (object)*(((s1_ptr)_2)->base + _t_66393);
        _2 = (object)SEQ_PTR(_32709);
        _32710 = (object)*(((s1_ptr)_2)->base + 4);
        _32709 = NOVALUE;
        if (binary_op_a(NOTEQ, _32710, 0)){
            _32710 = NOVALUE;
            goto L4; // [90] 102
        }
        _32710 = NOVALUE;

        /** execute.e:1010					r = 1*/
        _r_66383 = 1;
        goto L2; // [99] 137
L4: 

        /** execute.e:1011				elsif tcb[t][TASK_STATE] = ST_SUSPENDED then*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32712 = (object)*(((s1_ptr)_2)->base + _t_66393);
        _2 = (object)SEQ_PTR(_32712);
        _32713 = (object)*(((s1_ptr)_2)->base + 4);
        _32712 = NOVALUE;
        if (binary_op_a(NOTEQ, _32713, 1)){
            _32713 = NOVALUE;
            goto L2; // [114] 137
        }
        _32713 = NOVALUE;

        /** execute.e:1012					r = 0*/
        _r_66383 = 0;

        /** execute.e:1014				exit*/
        goto L2; // [127] 137
L3: 

        /** execute.e:1016		end for*/
        _t_66393 = _t_66393 + 1;
        goto L1; // [132] 62
L2: 
        ;
    }

    /** execute.e:1017		val[target] = r*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_66383;
    DeRef(_1);

    /** execute.e:1018		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:1019	end procedure*/
    DeRef(_tid_66384);
    DeRef(_32700);
    _32700 = NOVALUE;
    DeRef(_32702);
    _32702 = NOVALUE;
    return;
    ;
}


void _67opTASK_LIST()
{
    object _list_66410 = NOVALUE;
    object _32723 = NOVALUE;
    object _32722 = NOVALUE;
    object _32720 = NOVALUE;
    object _32719 = NOVALUE;
    object _32718 = NOVALUE;
    object _32716 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1025		target = Code[pc+1]*/
    _32716 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _32716);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1026		list = {}*/
    RefDS(_22209);
    DeRef(_list_66410);
    _list_66410 = _22209;

    /** execute.e:1027		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32718 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32718 = 1;
    }
    {
        object _i_66415;
        _i_66415 = 1;
L1: 
        if (_i_66415 > _32718){
            goto L2; // [31] 78
        }

        /** execute.e:1028			if tcb[i][TASK_STATE] != ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32719 = (object)*(((s1_ptr)_2)->base + _i_66415);
        _2 = (object)SEQ_PTR(_32719);
        _32720 = (object)*(((s1_ptr)_2)->base + 4);
        _32719 = NOVALUE;
        if (binary_op_a(EQUALS, _32720, 2)){
            _32720 = NOVALUE;
            goto L3; // [50] 71
        }
        _32720 = NOVALUE;

        /** execute.e:1029				list = append(list, tcb[i][TASK_TID])*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32722 = (object)*(((s1_ptr)_2)->base + _i_66415);
        _2 = (object)SEQ_PTR(_32722);
        _32723 = (object)*(((s1_ptr)_2)->base + 2);
        _32722 = NOVALUE;
        Ref(_32723);
        Append(&_list_66410, _list_66410, _32723);
        _32723 = NOVALUE;
L3: 

        /** execute.e:1031		end for*/
        _i_66415 = _i_66415 + 1;
        goto L1; // [73] 38
L2: 
        ;
    }

    /** execute.e:1032		val[target] = list*/
    RefDS(_list_66410);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _list_66410;
    DeRef(_1);

    /** execute.e:1033		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1034	end procedure*/
    DeRefDS(_list_66410);
    DeRef(_32716);
    _32716 = NOVALUE;
    return;
    ;
}


void _67opTASK_SELF()
{
    object _32729 = NOVALUE;
    object _32728 = NOVALUE;
    object _32726 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1038		target = Code[pc+1]*/
    _32726 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _32726);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1039		val[target] = tcb[current_task][TASK_TID]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32728 = (object)*(((s1_ptr)_2)->base + _67current_task_65272);
    _2 = (object)SEQ_PTR(_32728);
    _32729 = (object)*(((s1_ptr)_2)->base + 2);
    _32728 = NOVALUE;
    Ref(_32729);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32729;
    if( _1 != _32729 ){
        DeRef(_1);
    }
    _32729 = NOVALUE;

    /** execute.e:1040		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1041	end procedure*/
    _32726 = NOVALUE;
    return;
    ;
}


void _67opTASK_CLOCK_STOP()
{
    object _0, _1, _2;
    

    /** execute.e:1048		if not clock_stopped then*/
    if (_67clock_stopped_66160 != 0)
    goto L1; // [5] 20

    /** execute.e:1049			save_clock = time()*/
    DeRef(_67save_clock_66433);
    _67save_clock_66433 = NewDouble(current_time());

    /** execute.e:1050			clock_stopped = TRUE*/
    _67clock_stopped_66160 = _9TRUE_441;
L1: 

    /** execute.e:1052		pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:1053	end procedure*/
    return;
    ;
}


void _67opTASK_CLOCK_START()
{
    object _shift_66443 = NOVALUE;
    object _32748 = NOVALUE;
    object _32747 = NOVALUE;
    object _32745 = NOVALUE;
    object _32744 = NOVALUE;
    object _32743 = NOVALUE;
    object _32741 = NOVALUE;
    object _32740 = NOVALUE;
    object _32738 = NOVALUE;
    object _32737 = NOVALUE;
    object _32736 = NOVALUE;
    object _32735 = NOVALUE;
    object _32734 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1059		if clock_stopped then*/
    if (_67clock_stopped_66160 == 0)
    {
        goto L1; // [5] 114
    }
    else{
    }

    /** execute.e:1060			if save_clock >= 0 and save_clock < time() then*/
    if (IS_ATOM_INT(_67save_clock_66433)) {
        _32734 = (_67save_clock_66433 >= 0);
    }
    else {
        _32734 = (DBL_PTR(_67save_clock_66433)->dbl >= (eudouble)0);
    }
    if (_32734 == 0) {
        goto L2; // [16] 106
    }
    _32736 = NewDouble(current_time());
    if (IS_ATOM_INT(_67save_clock_66433)) {
        _32737 = ((eudouble)_67save_clock_66433 < DBL_PTR(_32736)->dbl);
    }
    else {
        _32737 = (DBL_PTR(_67save_clock_66433)->dbl < DBL_PTR(_32736)->dbl);
    }
    DeRefDS(_32736);
    _32736 = NOVALUE;
    if (_32737 == 0)
    {
        DeRef(_32737);
        _32737 = NOVALUE;
        goto L2; // [29] 106
    }
    else{
        DeRef(_32737);
        _32737 = NOVALUE;
    }

    /** execute.e:1061				shift = time() - save_clock*/
    DeRef(_32738);
    _32738 = NewDouble(current_time());
    DeRef(_shift_66443);
    if (IS_ATOM_INT(_67save_clock_66433)) {
        _shift_66443 = NewDouble(DBL_PTR(_32738)->dbl - (eudouble)_67save_clock_66433);
    }
    else
    _shift_66443 = NewDouble(DBL_PTR(_32738)->dbl - DBL_PTR(_67save_clock_66433)->dbl);
    DeRefDS(_32738);
    _32738 = NOVALUE;

    /** execute.e:1062				for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32740 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32740 = 1;
    }
    {
        object _i_66453;
        _i_66453 = 1;
L3: 
        if (_i_66453 > _32740){
            goto L4; // [49] 105
        }

        /** execute.e:1063					tcb[i][TASK_MIN_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_65298 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_66453 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32743 = (object)*(((s1_ptr)_2)->base + 8);
        _32741 = NOVALUE;
        if (IS_ATOM_INT(_32743) && IS_ATOM_INT(_shift_66443)) {
            _32744 = _32743 + _shift_66443;
            if ((object)((uintptr_t)_32744 + (uintptr_t)HIGH_BITS) >= 0){
                _32744 = NewDouble((eudouble)_32744);
            }
        }
        else {
            _32744 = binary_op(PLUS, _32743, _shift_66443);
        }
        _32743 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 8);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32744;
        if( _1 != _32744 ){
            DeRef(_1);
        }
        _32744 = NOVALUE;
        _32741 = NOVALUE;

        /** execute.e:1064					tcb[i][TASK_MAX_TIME] += shift*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67tcb_65298 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_66453 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _32747 = (object)*(((s1_ptr)_2)->base + 9);
        _32745 = NOVALUE;
        if (IS_ATOM_INT(_32747) && IS_ATOM_INT(_shift_66443)) {
            _32748 = _32747 + _shift_66443;
            if ((object)((uintptr_t)_32748 + (uintptr_t)HIGH_BITS) >= 0){
                _32748 = NewDouble((eudouble)_32748);
            }
        }
        else {
            _32748 = binary_op(PLUS, _32747, _shift_66443);
        }
        _32747 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32748;
        if( _1 != _32748 ){
            DeRef(_1);
        }
        _32748 = NOVALUE;
        _32745 = NOVALUE;

        /** execute.e:1065				end for*/
        _i_66453 = _i_66453 + 1;
        goto L3; // [100] 56
L4: 
        ;
    }
L2: 

    /** execute.e:1067			clock_stopped = FALSE*/
    _67clock_stopped_66160 = _9FALSE_439;
L1: 

    /** execute.e:1069		pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:1070	end procedure*/
    DeRef(_shift_66443);
    DeRef(_32734);
    _32734 = NOVALUE;
    return;
    ;
}


void _67opTASK_SUSPEND()
{
    object _task_66467 = NOVALUE;
    object _32759 = NOVALUE;
    object _32758 = NOVALUE;
    object _32756 = NOVALUE;
    object _32754 = NOVALUE;
    object _32752 = NOVALUE;
    object _32750 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1076		a = Code[pc+1]*/
    _32750 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _32750);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1077		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32752 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_32752);
    _task_66467 = _67which_task(_32752);
    _32752 = NOVALUE;
    if (!IS_ATOM_INT(_task_66467)) {
        _1 = (object)(DBL_PTR(_task_66467)->dbl);
        DeRefDS(_task_66467);
        _task_66467 = _1;
    }

    /** execute.e:1078		tcb[task][TASK_STATE] = ST_SUSPENDED*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66467 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _32754 = NOVALUE;

    /** execute.e:1079		tcb[task][TASK_MAX_TIME] = TASK_NEVER*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66467 + ((s1_ptr)_2)->base);
    RefDS(_67TASK_NEVER_65266);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67TASK_NEVER_65266;
    DeRef(_1);
    _32756 = NOVALUE;

    /** execute.e:1080		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32758 = (object)*(((s1_ptr)_2)->base + _task_66467);
    _2 = (object)SEQ_PTR(_32758);
    _32759 = (object)*(((s1_ptr)_2)->base + 3);
    _32758 = NOVALUE;
    if (binary_op_a(NOTEQ, _32759, 1)){
        _32759 = NOVALUE;
        goto L1; // [71] 89
    }
    _32759 = NOVALUE;

    /** execute.e:1081			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_65301, _task_66467);
    _67rt_first_65301 = _0;
    if (!IS_ATOM_INT(_67rt_first_65301)) {
        _1 = (object)(DBL_PTR(_67rt_first_65301)->dbl);
        DeRefDS(_67rt_first_65301);
        _67rt_first_65301 = _1;
    }
    goto L2; // [86] 101
L1: 

    /** execute.e:1083			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_65302, _task_66467);
    _67ts_first_65302 = _0;
    if (!IS_ATOM_INT(_67ts_first_65302)) {
        _1 = (object)(DBL_PTR(_67ts_first_65302)->dbl);
        DeRefDS(_67ts_first_65302);
        _67ts_first_65302 = _1;
    }
L2: 

    /** execute.e:1085		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1086	end procedure*/
    DeRef(_32750);
    _32750 = NOVALUE;
    return;
    ;
}


void _67opTASK_CREATE()
{
    object _sub_66488 = NOVALUE;
    object _new_entry_66489 = NOVALUE;
    object _recycle_66491 = NOVALUE;
    object _32799 = NOVALUE;
    object _32798 = NOVALUE;
    object _32797 = NOVALUE;
    object _32795 = NOVALUE;
    object _32794 = NOVALUE;
    object _32793 = NOVALUE;
    object _32791 = NOVALUE;
    object _32787 = NOVALUE;
    object _32786 = NOVALUE;
    object _32785 = NOVALUE;
    object _32783 = NOVALUE;
    object _32782 = NOVALUE;
    object _32780 = NOVALUE;
    object _32777 = NOVALUE;
    object _32776 = NOVALUE;
    object _32774 = NOVALUE;
    object _32773 = NOVALUE;
    object _32771 = NOVALUE;
    object _32770 = NOVALUE;
    object _32769 = NOVALUE;
    object _32767 = NOVALUE;
    object _32766 = NOVALUE;
    object _32764 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1091		sequence new_entry*/

    /** execute.e:1094		a = Code[pc+1] -- routine id*/
    _32764 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _32764);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1095		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32766 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_32766)) {
        _32767 = (_32766 < 0);
    }
    else {
        _32767 = binary_op(LESS, _32766, 0);
    }
    _32766 = NOVALUE;
    if (IS_ATOM_INT(_32767)) {
        if (_32767 != 0) {
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_32767)->dbl != 0.0) {
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_67val_65265);
    _32769 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_67e_routine_65303)){
            _32770 = SEQ_PTR(_67e_routine_65303)->length;
    }
    else {
        _32770 = 1;
    }
    if (IS_ATOM_INT(_32769)) {
        _32771 = (_32769 >= _32770);
    }
    else {
        _32771 = binary_op(GREATEREQ, _32769, _32770);
    }
    _32769 = NOVALUE;
    _32770 = NOVALUE;
    if (_32771 == 0) {
        DeRef(_32771);
        _32771 = NOVALUE;
        goto L2; // [55] 65
    }
    else {
        if (!IS_ATOM_INT(_32771) && DBL_PTR(_32771)->dbl == 0.0){
            DeRef(_32771);
            _32771 = NOVALUE;
            goto L2; // [55] 65
        }
        DeRef(_32771);
        _32771 = NOVALUE;
    }
    DeRef(_32771);
    _32771 = NOVALUE;
L1: 

    /** execute.e:1096			RTFatal("invalid routine id")*/
    RefDS(_32772);
    _67RTFatal(_32772);
L2: 

    /** execute.e:1098		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32773 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_32773)) {
        _32774 = _32773 + 1;
    }
    else
    _32774 = binary_op(PLUS, 1, _32773);
    _32773 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_65303);
    if (!IS_ATOM_INT(_32774)){
        _sub_66488 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32774)->dbl));
    }
    else{
        _sub_66488 = (object)*(((s1_ptr)_2)->base + _32774);
    }

    /** execute.e:1099		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32776 = (object)*(((s1_ptr)_2)->base + _sub_66488);
    _2 = (object)SEQ_PTR(_32776);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _32777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _32777 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _32776 = NOVALUE;
    if (binary_op_a(EQUALS, _32777, 27)){
        _32777 = NOVALUE;
        goto L3; // [103] 113
    }
    _32777 = NOVALUE;

    /** execute.e:1100			RTFatal("specify the routine id of a procedure, not a function or type")*/
    RefDS(_32779);
    _67RTFatal(_32779);
L3: 

    /** execute.e:1102		b = Code[pc+2] -- args*/
    _32780 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _32780);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1105		new_entry = {val[a], next_task_id, T_REAL_TIME, ST_SUSPENDED, 0,*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32782 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _32783 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _0 = _new_entry_66489;
    _1 = NewS1(16);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_32782);
    ((intptr_t*)_2)[1] = _32782;
    Ref(_67next_task_id_65274);
    ((intptr_t*)_2)[2] = _67next_task_id_65274;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    ((intptr_t*)_2)[7] = 0;
    ((intptr_t*)_2)[8] = 0;
    RefDS(_67TASK_NEVER_65266);
    ((intptr_t*)_2)[9] = _67TASK_NEVER_65266;
    ((intptr_t*)_2)[10] = 1;
    ((intptr_t*)_2)[11] = 1;
    ((intptr_t*)_2)[12] = 0;
    Ref(_32783);
    ((intptr_t*)_2)[13] = _32783;
    ((intptr_t*)_2)[14] = 0;
    RefDSn(_22209, 2);
    ((intptr_t*)_2)[15] = _22209;
    ((intptr_t*)_2)[16] = _22209;
    _new_entry_66489 = MAKE_SEQ(_1);
    DeRef(_0);
    _32783 = NOVALUE;
    _32782 = NOVALUE;

    /** execute.e:1108		recycle = FALSE*/
    _recycle_66491 = _9FALSE_439;

    /** execute.e:1109		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_65298)){
            _32785 = SEQ_PTR(_67tcb_65298)->length;
    }
    else {
        _32785 = 1;
    }
    {
        object _i_66522;
        _i_66522 = 1;
L4: 
        if (_i_66522 > _32785){
            goto L5; // [182] 232
        }

        /** execute.e:1110			if tcb[i][TASK_STATE] = ST_DEAD then*/
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _32786 = (object)*(((s1_ptr)_2)->base + _i_66522);
        _2 = (object)SEQ_PTR(_32786);
        _32787 = (object)*(((s1_ptr)_2)->base + 4);
        _32786 = NOVALUE;
        if (binary_op_a(NOTEQ, _32787, 2)){
            _32787 = NOVALUE;
            goto L6; // [201] 225
        }
        _32787 = NOVALUE;

        /** execute.e:1113				tcb[i] = new_entry*/
        RefDS(_new_entry_66489);
        _2 = (object)SEQ_PTR(_67tcb_65298);
        _2 = (object)(((s1_ptr)_2)->base + _i_66522);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_entry_66489;
        DeRefDS(_1);

        /** execute.e:1114				recycle = TRUE*/
        _recycle_66491 = _9TRUE_441;

        /** execute.e:1115				exit*/
        goto L5; // [222] 232
L6: 

        /** execute.e:1117		end for*/
        _i_66522 = _i_66522 + 1;
        goto L4; // [227] 189
L5: 
        ;
    }

    /** execute.e:1119		if not recycle then*/
    if (_recycle_66491 != 0)
    goto L7; // [234] 246

    /** execute.e:1121			tcb = append(tcb, new_entry)*/
    RefDS(_new_entry_66489);
    Append(&_67tcb_65298, _67tcb_65298, _new_entry_66489);
L7: 

    /** execute.e:1124		target = Code[pc+3]*/
    _32791 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _32791);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1125		val[target] = next_task_id*/
    Ref(_67next_task_id_65274);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67next_task_id_65274;
    DeRef(_1);

    /** execute.e:1126		if not id_wrap and next_task_id < TASK_ID_MAX then*/
    _32793 = (_67id_wrap_65270 == 0);
    if (_32793 == 0) {
        goto L8; // [281] 306
    }
    if (IS_ATOM_INT(_67next_task_id_65274)) {
        _32795 = ((eudouble)_67next_task_id_65274 < DBL_PTR(_67TASK_ID_MAX_65267)->dbl);
    }
    else {
        _32795 = (DBL_PTR(_67next_task_id_65274)->dbl < DBL_PTR(_67TASK_ID_MAX_65267)->dbl);
    }
    if (_32795 == 0)
    {
        DeRef(_32795);
        _32795 = NOVALUE;
        goto L8; // [292] 306
    }
    else{
        DeRef(_32795);
        _32795 = NOVALUE;
    }

    /** execute.e:1127			next_task_id += 1*/
    _0 = _67next_task_id_65274;
    if (IS_ATOM_INT(_67next_task_id_65274)) {
        _67next_task_id_65274 = _67next_task_id_65274 + 1;
        if (_67next_task_id_65274 > MAXINT){
            _67next_task_id_65274 = NewDouble((eudouble)_67next_task_id_65274);
        }
    }
    else
    _67next_task_id_65274 = binary_op(PLUS, 1, _67next_task_id_65274);
    DeRef(_0);
    goto L9; // [303] 396
L8: 

    /** execute.e:1130			id_wrap = TRUE -- id's have wrapped*/
    _67id_wrap_65270 = _9TRUE_441;

    /** execute.e:1131			for i = 1 to TASK_ID_MAX do*/
    {
        object _i_66543;
        _i_66543 = 1;
LA: 
        if (binary_op_a(GREATER, _i_66543, _67TASK_ID_MAX_65267)){
            goto LB; // [315] 395
        }

        /** execute.e:1132				next_task_id = i*/
        Ref(_i_66543);
        DeRef(_67next_task_id_65274);
        _67next_task_id_65274 = _i_66543;

        /** execute.e:1133				for j = 1 to length(tcb) do*/
        if (IS_SEQUENCE(_67tcb_65298)){
                _32797 = SEQ_PTR(_67tcb_65298)->length;
        }
        else {
            _32797 = 1;
        }
        {
            object _j_66545;
            _j_66545 = 1;
LC: 
            if (_j_66545 > _32797){
                goto LD; // [334] 376
            }

            /** execute.e:1134					if next_task_id = tcb[j][TASK_TID] then*/
            _2 = (object)SEQ_PTR(_67tcb_65298);
            _32798 = (object)*(((s1_ptr)_2)->base + _j_66545);
            _2 = (object)SEQ_PTR(_32798);
            _32799 = (object)*(((s1_ptr)_2)->base + 2);
            _32798 = NOVALUE;
            if (binary_op_a(NOTEQ, _67next_task_id_65274, _32799)){
                _32799 = NOVALUE;
                goto LE; // [355] 369
            }
            _32799 = NOVALUE;

            /** execute.e:1135						next_task_id = 0*/
            DeRef(_67next_task_id_65274);
            _67next_task_id_65274 = 0;

            /** execute.e:1136						exit -- this id is still in use*/
            goto LD; // [366] 376
LE: 

            /** execute.e:1138				end for*/
            _j_66545 = _j_66545 + 1;
            goto LC; // [371] 341
LD: 
            ;
        }

        /** execute.e:1139				if next_task_id then*/
        if (_67next_task_id_65274 == 0) {
            goto LF; // [380] 388
        }
        else {
            if (!IS_ATOM_INT(_67next_task_id_65274) && DBL_PTR(_67next_task_id_65274)->dbl == 0.0){
                goto LF; // [380] 388
            }
        }

        /** execute.e:1140					exit -- found unused id for next time*/
        goto LB; // [385] 395
LF: 

        /** execute.e:1142			end for*/
        _0 = _i_66543;
        if (IS_ATOM_INT(_i_66543)) {
            _i_66543 = _i_66543 + 1;
            if ((object)((uintptr_t)_i_66543 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66543 = NewDouble((eudouble)_i_66543);
            }
        }
        else {
            _i_66543 = binary_op_a(PLUS, _i_66543, 1);
        }
        DeRef(_0);
        goto LA; // [390] 322
LB: 
        ;
        DeRef(_i_66543);
    }
L9: 

    /** execute.e:1145		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:1146	end procedure*/
    DeRef(_new_entry_66489);
    DeRef(_32774);
    _32774 = NOVALUE;
    DeRef(_32767);
    _32767 = NOVALUE;
    DeRef(_32780);
    _32780 = NOVALUE;
    DeRef(_32764);
    _32764 = NOVALUE;
    DeRef(_32791);
    _32791 = NOVALUE;
    DeRef(_32793);
    _32793 = NOVALUE;
    return;
    ;
}


void _67opTASK_SCHEDULE()
{
    object _task_66555 = NOVALUE;
    object _now_66556 = NOVALUE;
    object _s_66557 = NOVALUE;
    object _32891 = NOVALUE;
    object _32889 = NOVALUE;
    object _32887 = NOVALUE;
    object _32886 = NOVALUE;
    object _32885 = NOVALUE;
    object _32883 = NOVALUE;
    object _32882 = NOVALUE;
    object _32881 = NOVALUE;
    object _32878 = NOVALUE;
    object _32877 = NOVALUE;
    object _32876 = NOVALUE;
    object _32875 = NOVALUE;
    object _32873 = NOVALUE;
    object _32872 = NOVALUE;
    object _32871 = NOVALUE;
    object _32869 = NOVALUE;
    object _32867 = NOVALUE;
    object _32865 = NOVALUE;
    object _32863 = NOVALUE;
    object _32860 = NOVALUE;
    object _32859 = NOVALUE;
    object _32858 = NOVALUE;
    object _32856 = NOVALUE;
    object _32853 = NOVALUE;
    object _32851 = NOVALUE;
    object _32850 = NOVALUE;
    object _32849 = NOVALUE;
    object _32847 = NOVALUE;
    object _32844 = NOVALUE;
    object _32843 = NOVALUE;
    object _32841 = NOVALUE;
    object _32840 = NOVALUE;
    object _32838 = NOVALUE;
    object _32837 = NOVALUE;
    object _32835 = NOVALUE;
    object _32834 = NOVALUE;
    object _32832 = NOVALUE;
    object _32831 = NOVALUE;
    object _32828 = NOVALUE;
    object _32826 = NOVALUE;
    object _32824 = NOVALUE;
    object _32823 = NOVALUE;
    object _32822 = NOVALUE;
    object _32820 = NOVALUE;
    object _32819 = NOVALUE;
    object _32818 = NOVALUE;
    object _32815 = NOVALUE;
    object _32814 = NOVALUE;
    object _32812 = NOVALUE;
    object _32809 = NOVALUE;
    object _32806 = NOVALUE;
    object _32804 = NOVALUE;
    object _32802 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1156		a = Code[pc+1]*/
    _32802 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _32802);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1157		task = which_task(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32804 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_32804);
    _task_66555 = _67which_task(_32804);
    _32804 = NOVALUE;
    if (!IS_ATOM_INT(_task_66555)) {
        _1 = (object)(DBL_PTR(_task_66555)->dbl);
        DeRefDS(_task_66555);
        _task_66555 = _1;
    }

    /** execute.e:1158		b = Code[pc+2]*/
    _32806 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _32806);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1159		s = val[b]*/
    DeRef(_s_66557);
    _2 = (object)SEQ_PTR(_67val_65265);
    _s_66557 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_s_66557);

    /** execute.e:1161		if atom(s) then*/
    _32809 = IS_ATOM(_s_66557);
    if (_32809 == 0)
    {
        _32809 = NOVALUE;
        goto L1; // [64] 187
    }
    else{
        _32809 = NOVALUE;
    }

    /** execute.e:1163			if s <= 0 then*/
    if (binary_op_a(GREATER, _s_66557, 0)){
        goto L2; // [69] 79
    }

    /** execute.e:1164				RTFatal("number of executions must be greater than 0")*/
    RefDS(_32811);
    _67RTFatal(_32811);
L2: 

    /** execute.e:1167			tcb[task][TASK_RUNS_MAX] = s   -- max execution count*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    Ref(_s_66557);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_66557;
    DeRef(_1);
    _32812 = NOVALUE;

    /** execute.e:1168			if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32814 = (object)*(((s1_ptr)_2)->base + _task_66555);
    _2 = (object)SEQ_PTR(_32814);
    _32815 = (object)*(((s1_ptr)_2)->base + 3);
    _32814 = NOVALUE;
    if (binary_op_a(NOTEQ, _32815, 1)){
        _32815 = NOVALUE;
        goto L3; // [104] 120
    }
    _32815 = NOVALUE;

    /** execute.e:1169				rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_65301, _task_66555);
    _67rt_first_65301 = _0;
    if (!IS_ATOM_INT(_67rt_first_65301)) {
        _1 = (object)(DBL_PTR(_67rt_first_65301)->dbl);
        DeRefDS(_67rt_first_65301);
        _67rt_first_65301 = _1;
    }
L3: 

    /** execute.e:1171			if tcb[task][TASK_TYPE] = T_REAL_TIME or*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32818 = (object)*(((s1_ptr)_2)->base + _task_66555);
    _2 = (object)SEQ_PTR(_32818);
    _32819 = (object)*(((s1_ptr)_2)->base + 3);
    _32818 = NOVALUE;
    if (IS_ATOM_INT(_32819)) {
        _32820 = (_32819 == 1);
    }
    else {
        _32820 = binary_op(EQUALS, _32819, 1);
    }
    _32819 = NOVALUE;
    if (IS_ATOM_INT(_32820)) {
        if (_32820 != 0) {
            goto L4; // [136] 159
        }
    }
    else {
        if (DBL_PTR(_32820)->dbl != 0.0) {
            goto L4; // [136] 159
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32822 = (object)*(((s1_ptr)_2)->base + _task_66555);
    _2 = (object)SEQ_PTR(_32822);
    _32823 = (object)*(((s1_ptr)_2)->base + 4);
    _32822 = NOVALUE;
    if (IS_ATOM_INT(_32823)) {
        _32824 = (_32823 == 1);
    }
    else {
        _32824 = binary_op(EQUALS, _32823, 1);
    }
    _32823 = NOVALUE;
    if (_32824 == 0) {
        DeRef(_32824);
        _32824 = NOVALUE;
        goto L5; // [155] 171
    }
    else {
        if (!IS_ATOM_INT(_32824) && DBL_PTR(_32824)->dbl == 0.0){
            DeRef(_32824);
            _32824 = NOVALUE;
            goto L5; // [155] 171
        }
        DeRef(_32824);
        _32824 = NOVALUE;
    }
    DeRef(_32824);
    _32824 = NOVALUE;
L4: 

    /** execute.e:1173				ts_first = task_insert(ts_first, task)*/
    _0 = _67task_insert(_67ts_first_65302, _task_66555);
    _67ts_first_65302 = _0;
    if (!IS_ATOM_INT(_67ts_first_65302)) {
        _1 = (object)(DBL_PTR(_67ts_first_65302)->dbl);
        DeRefDS(_67ts_first_65302);
        _67ts_first_65302 = _1;
    }
L5: 

    /** execute.e:1175			tcb[task][TASK_TYPE] = T_TIME_SHARE*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _32826 = NOVALUE;
    goto L6; // [184] 542
L1: 

    /** execute.e:1179			if length(s) != 2 then*/
    if (IS_SEQUENCE(_s_66557)){
            _32828 = SEQ_PTR(_s_66557)->length;
    }
    else {
        _32828 = 1;
    }
    if (_32828 == 2)
    goto L7; // [192] 202

    /** execute.e:1180				RTFatal("second argument must be {min-time, max-time}")*/
    RefDS(_32830);
    _67RTFatal(_32830);
L7: 

    /** execute.e:1182			if sequence(s[1]) or sequence(s[2]) then*/
    _2 = (object)SEQ_PTR(_s_66557);
    _32831 = (object)*(((s1_ptr)_2)->base + 1);
    _32832 = IS_SEQUENCE(_32831);
    _32831 = NOVALUE;
    if (_32832 != 0) {
        goto L8; // [211] 227
    }
    _2 = (object)SEQ_PTR(_s_66557);
    _32834 = (object)*(((s1_ptr)_2)->base + 2);
    _32835 = IS_SEQUENCE(_32834);
    _32834 = NOVALUE;
    if (_32835 == 0)
    {
        _32835 = NOVALUE;
        goto L9; // [223] 233
    }
    else{
        _32835 = NOVALUE;
    }
L8: 

    /** execute.e:1183				RTFatal("min and max times must be atoms")*/
    RefDS(_32836);
    _67RTFatal(_32836);
L9: 

    /** execute.e:1185			if s[1] < 0 or s[2] < 0 then*/
    _2 = (object)SEQ_PTR(_s_66557);
    _32837 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_32837)) {
        _32838 = (_32837 < 0);
    }
    else {
        _32838 = binary_op(LESS, _32837, 0);
    }
    _32837 = NOVALUE;
    if (IS_ATOM_INT(_32838)) {
        if (_32838 != 0) {
            goto LA; // [243] 260
        }
    }
    else {
        if (DBL_PTR(_32838)->dbl != 0.0) {
            goto LA; // [243] 260
        }
    }
    _2 = (object)SEQ_PTR(_s_66557);
    _32840 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_32840)) {
        _32841 = (_32840 < 0);
    }
    else {
        _32841 = binary_op(LESS, _32840, 0);
    }
    _32840 = NOVALUE;
    if (_32841 == 0) {
        DeRef(_32841);
        _32841 = NOVALUE;
        goto LB; // [256] 266
    }
    else {
        if (!IS_ATOM_INT(_32841) && DBL_PTR(_32841)->dbl == 0.0){
            DeRef(_32841);
            _32841 = NOVALUE;
            goto LB; // [256] 266
        }
        DeRef(_32841);
        _32841 = NOVALUE;
    }
    DeRef(_32841);
    _32841 = NOVALUE;
LA: 

    /** execute.e:1186				RTFatal("min and max times must be greater than or equal to 0")*/
    RefDS(_32842);
    _67RTFatal(_32842);
LB: 

    /** execute.e:1188			if s[1] > s[2] then*/
    _2 = (object)SEQ_PTR(_s_66557);
    _32843 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_s_66557);
    _32844 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _32843, _32844)){
        _32843 = NOVALUE;
        _32844 = NOVALUE;
        goto LC; // [276] 286
    }
    _32843 = NOVALUE;
    _32844 = NOVALUE;

    /** execute.e:1189				RTFatal("task min time must be <= task max time")*/
    RefDS(_32846);
    _67RTFatal(_32846);
LC: 

    /** execute.e:1191			tcb[task][TASK_MIN_INC] = s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66557);
    _32849 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_32849);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32849;
    if( _1 != _32849 ){
        DeRef(_1);
    }
    _32849 = NOVALUE;
    _32847 = NOVALUE;

    /** execute.e:1193			if s[1] < clock_period/2 then*/
    _2 = (object)SEQ_PTR(_s_66557);
    _32850 = (object)*(((s1_ptr)_2)->base + 1);
    _32851 = binary_op(DIVIDE, _67clock_period_65275, 2);
    if (binary_op_a(GREATEREQ, _32850, _32851)){
        _32850 = NOVALUE;
        DeRefDS(_32851);
        _32851 = NOVALUE;
        goto LD; // [315] 372
    }
    _32850 = NOVALUE;
    DeRef(_32851);
    _32851 = NOVALUE;

    /** execute.e:1195				if s[1] > 1.0e-9 then*/
    _2 = (object)SEQ_PTR(_s_66557);
    _32853 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(LESSEQ, _32853, _32854)){
        _32853 = NOVALUE;
        goto LE; // [325] 355
    }
    _32853 = NOVALUE;

    /** execute.e:1196					tcb[task][TASK_RUNS_MAX] =  floor(clock_period / s[1])*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66557);
    _32858 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = binary_op(DIVIDE, _67clock_period_65275, _32858);
    _32859 = unary_op(FLOOR, _2);
    DeRef(_2);
    _32858 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32859;
    if( _1 != _32859 ){
        DeRef(_1);
    }
    _32859 = NOVALUE;
    _32856 = NOVALUE;
    goto LF; // [352] 386
LE: 

    /** execute.e:1199					tcb[task][TASK_RUNS_MAX] =  1000000000 -- arbitrary, large*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1000000000;
    DeRef(_1);
    _32860 = NOVALUE;
    goto LF; // [369] 386
LD: 

    /** execute.e:1202				tcb[task][TASK_RUNS_MAX] = 1*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _32863 = NOVALUE;
LF: 

    /** execute.e:1204			tcb[task][TASK_MAX_INC] = s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66557);
    _32867 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_32867);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32867;
    if( _1 != _32867 ){
        DeRef(_1);
    }
    _32867 = NOVALUE;
    _32865 = NOVALUE;

    /** execute.e:1205			now = time()*/
    DeRef(_now_66556);
    _now_66556 = NewDouble(current_time());

    /** execute.e:1206			tcb[task][TASK_MIN_TIME] = now + s[1]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66557);
    _32871 = (object)*(((s1_ptr)_2)->base + 1);
    _32872 = binary_op(PLUS, _now_66556, _32871);
    _32871 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32872;
    if( _1 != _32872 ){
        DeRef(_1);
    }
    _32872 = NOVALUE;
    _32869 = NOVALUE;

    /** execute.e:1207			tcb[task][TASK_MAX_TIME] = now + s[2]*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_s_66557);
    _32875 = (object)*(((s1_ptr)_2)->base + 2);
    _32876 = binary_op(PLUS, _now_66556, _32875);
    _32875 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32876;
    if( _1 != _32876 ){
        DeRef(_1);
    }
    _32876 = NOVALUE;
    _32873 = NOVALUE;

    /** execute.e:1209			if tcb[task][TASK_TYPE] = T_TIME_SHARE then*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32877 = (object)*(((s1_ptr)_2)->base + _task_66555);
    _2 = (object)SEQ_PTR(_32877);
    _32878 = (object)*(((s1_ptr)_2)->base + 3);
    _32877 = NOVALUE;
    if (binary_op_a(NOTEQ, _32878, 2)){
        _32878 = NOVALUE;
        goto L10; // [461] 477
    }
    _32878 = NOVALUE;

    /** execute.e:1210				ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_65302, _task_66555);
    _67ts_first_65302 = _0;
    if (!IS_ATOM_INT(_67ts_first_65302)) {
        _1 = (object)(DBL_PTR(_67ts_first_65302)->dbl);
        DeRefDS(_67ts_first_65302);
        _67ts_first_65302 = _1;
    }
L10: 

    /** execute.e:1212			if tcb[task][TASK_TYPE] = T_TIME_SHARE or*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32881 = (object)*(((s1_ptr)_2)->base + _task_66555);
    _2 = (object)SEQ_PTR(_32881);
    _32882 = (object)*(((s1_ptr)_2)->base + 3);
    _32881 = NOVALUE;
    if (IS_ATOM_INT(_32882)) {
        _32883 = (_32882 == 2);
    }
    else {
        _32883 = binary_op(EQUALS, _32882, 2);
    }
    _32882 = NOVALUE;
    if (IS_ATOM_INT(_32883)) {
        if (_32883 != 0) {
            goto L11; // [493] 516
        }
    }
    else {
        if (DBL_PTR(_32883)->dbl != 0.0) {
            goto L11; // [493] 516
        }
    }
    _2 = (object)SEQ_PTR(_67tcb_65298);
    _32885 = (object)*(((s1_ptr)_2)->base + _task_66555);
    _2 = (object)SEQ_PTR(_32885);
    _32886 = (object)*(((s1_ptr)_2)->base + 4);
    _32885 = NOVALUE;
    if (IS_ATOM_INT(_32886)) {
        _32887 = (_32886 == 1);
    }
    else {
        _32887 = binary_op(EQUALS, _32886, 1);
    }
    _32886 = NOVALUE;
    if (_32887 == 0) {
        DeRef(_32887);
        _32887 = NOVALUE;
        goto L12; // [512] 528
    }
    else {
        if (!IS_ATOM_INT(_32887) && DBL_PTR(_32887)->dbl == 0.0){
            DeRef(_32887);
            _32887 = NOVALUE;
            goto L12; // [512] 528
        }
        DeRef(_32887);
        _32887 = NOVALUE;
    }
    DeRef(_32887);
    _32887 = NOVALUE;
L11: 

    /** execute.e:1214				rt_first = task_insert(rt_first, task)*/
    _0 = _67task_insert(_67rt_first_65301, _task_66555);
    _67rt_first_65301 = _0;
    if (!IS_ATOM_INT(_67rt_first_65301)) {
        _1 = (object)(DBL_PTR(_67rt_first_65301)->dbl);
        DeRefDS(_67rt_first_65301);
        _67rt_first_65301 = _1;
    }
L12: 

    /** execute.e:1216			tcb[task][TASK_TYPE] = T_REAL_TIME*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _32889 = NOVALUE;
L6: 

    /** execute.e:1218		tcb[task][TASK_STATE] = ST_ACTIVE*/
    _2 = (object)SEQ_PTR(_67tcb_65298);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67tcb_65298 = MAKE_SEQ(_2);
    }
    _3 = (object)(_task_66555 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _32891 = NOVALUE;

    /** execute.e:1219		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:1220	end procedure*/
    DeRef(_now_66556);
    DeRef(_s_66557);
    DeRef(_32838);
    _32838 = NOVALUE;
    DeRef(_32883);
    _32883 = NOVALUE;
    DeRef(_32802);
    _32802 = NOVALUE;
    DeRef(_32806);
    _32806 = NOVALUE;
    DeRef(_32820);
    _32820 = NOVALUE;
    return;
    ;
}


void _67one_trace_line(object _line_66672)
{
    object _32896 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1231		ifdef UNIX then*/

    /** execute.e:1234			printf(trace_file, "%-77.77s\r\n", {line})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_line_66672);
    ((intptr_t*)_2)[1] = _line_66672;
    _32896 = MAKE_SEQ(_1);
    EPrintf(_67trace_file_66668, _32895, _32896);
    DeRefDS(_32896);
    _32896 = NOVALUE;

    /** execute.e:1236	end procedure*/
    DeRefDS(_line_66672);
    return;
    ;
}


void _67opCOVERAGE_LINE()
{
    object _35306 = NOVALUE;
    object _32898 = NOVALUE;
    object _32897 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1239		cover_line( Code[pc+1] )*/
    _32897 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _32898 = (object)*(((s1_ptr)_2)->base + _32897);
    Ref(_32898);
    _35306 = _50cover_line(_32898);
    _32898 = NOVALUE;
    DeRef(_35306);
    _35306 = NOVALUE;

    /** execute.e:1240		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1241	end procedure*/
    _32897 = NOVALUE;
    return;
    ;
}


void _67opCOVERAGE_ROUTINE()
{
    object _35305 = NOVALUE;
    object _32901 = NOVALUE;
    object _32900 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1244		cover_routine( Code[pc+1] )*/
    _32900 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _32901 = (object)*(((s1_ptr)_2)->base + _32900);
    Ref(_32901);
    _35305 = _50cover_routine(_32901);
    _32901 = NOVALUE;
    DeRef(_35305);
    _35305 = NOVALUE;

    /** execute.e:1245		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1246	end procedure*/
    _32900 = NOVALUE;
    return;
    ;
}


void _67opSTARTLINE()
{
    object _line_66692 = NOVALUE;
    object _w_66693 = NOVALUE;
    object _32934 = NOVALUE;
    object _32933 = NOVALUE;
    object _32932 = NOVALUE;
    object _32929 = NOVALUE;
    object _32924 = NOVALUE;
    object _32923 = NOVALUE;
    object _32922 = NOVALUE;
    object _32921 = NOVALUE;
    object _32920 = NOVALUE;
    object _32919 = NOVALUE;
    object _32918 = NOVALUE;
    object _32915 = NOVALUE;
    object _32914 = NOVALUE;
    object _32912 = NOVALUE;
    object _32911 = NOVALUE;
    object _32910 = NOVALUE;
    object _32908 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1253		if TraceOn then*/
    if (_67TraceOn_65253 == 0)
    {
        goto L1; // [5] 279
    }
    else{
    }

    /** execute.e:1254			if trace_file = -1 then*/
    if (_67trace_file_66668 != -1)
    goto L2; // [12] 40

    /** execute.e:1255				trace_file = open("ctrace.out", "wb")*/
    _67trace_file_66668 = EOpen(_32904, _24055, 0);

    /** execute.e:1256				if trace_file = -1 then*/
    if (_67trace_file_66668 != -1)
    goto L3; // [29] 39

    /** execute.e:1257					RTFatal("Couldn't open ctrace.out")*/
    RefDS(_32907);
    _67RTFatal(_32907);
L3: 
L2: 

    /** execute.e:1261			a = Code[pc+1]*/
    _32908 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _32908);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1263			if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _32910 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _32910 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32911 = (object)*(((s1_ptr)_2)->base + _32910);
    _32912 = IS_ATOM(_32911);
    _32911 = NOVALUE;
    if (_32912 == 0)
    {
        _32912 = NOVALUE;
        goto L4; // [70] 84
    }
    else{
        _32912 = NOVALUE;
    }

    /** execute.e:1264				slist = s_expand(slist)*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L4: 

    /** execute.e:1266			line = fetch_line(slist[a][SRC])*/
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32914 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_32914);
    _32915 = (object)*(((s1_ptr)_2)->base + 1);
    _32914 = NOVALUE;
    Ref(_32915);
    _0 = _line_66692;
    _line_66692 = _61fetch_line(_32915);
    DeRef(_0);
    _32915 = NOVALUE;

    /** execute.e:1267			line = sprintf("%s:%d\t%s",*/
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32918 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_32918);
    _32919 = (object)*(((s1_ptr)_2)->base + 3);
    _32918 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!IS_ATOM_INT(_32919)){
        _32920 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32919)->dbl));
    }
    else{
        _32920 = (object)*(((s1_ptr)_2)->base + _32919);
    }
    Ref(_32920);
    _32921 = _53name_ext(_32920);
    _32920 = NOVALUE;
    _2 = (object)SEQ_PTR(_27slist_20662);
    _32922 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_32922);
    _32923 = (object)*(((s1_ptr)_2)->base + 2);
    _32922 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32921;
    Ref(_32923);
    ((intptr_t*)_2)[2] = _32923;
    RefDS(_line_66692);
    ((intptr_t*)_2)[3] = _line_66692;
    _32924 = MAKE_SEQ(_1);
    _32923 = NOVALUE;
    _32921 = NOVALUE;
    DeRefDS(_line_66692);
    _line_66692 = EPrintf(-9999999, _32917, _32924);
    DeRefDS(_32924);
    _32924 = NOVALUE;

    /** execute.e:1271			trace_line += 1*/
    _67trace_line_66669 = _67trace_line_66669 + 1;

    /** execute.e:1272			if trace_line >= trace_lines then*/
    if (_67trace_line_66669 < _27trace_lines_64988)
    goto L5; // [170] 210

    /** execute.e:1274				trace_line = 0*/
    _67trace_line_66669 = 0;

    /** execute.e:1275				one_trace_line("")*/
    RefDS(_22209);
    _67one_trace_line(_22209);

    /** execute.e:1276				one_trace_line("               ")*/
    RefDS(_32928);
    _67one_trace_line(_32928);

    /** execute.e:1277				flush(trace_file)*/
    _18flush(_67trace_file_66668);

    /** execute.e:1278				if seek(trace_file, 0) then*/
    _32929 = _18seek(_67trace_file_66668, 0);
    if (_32929 == 0) {
        DeRef(_32929);
        _32929 = NOVALUE;
        goto L6; // [205] 209
    }
    else {
        if (!IS_ATOM_INT(_32929) && DBL_PTR(_32929)->dbl == 0.0){
            DeRef(_32929);
            _32929 = NOVALUE;
            goto L6; // [205] 209
        }
        DeRef(_32929);
        _32929 = NOVALUE;
    }
    DeRef(_32929);
    _32929 = NOVALUE;
L6: 
L5: 

    /** execute.e:1282			one_trace_line(line)*/
    RefDS(_line_66692);
    _67one_trace_line(_line_66692);

    /** execute.e:1283			one_trace_line("")*/
    RefDS(_22209);
    _67one_trace_line(_22209);

    /** execute.e:1284			one_trace_line("=== THE END ===")*/
    RefDS(_32930);
    _67one_trace_line(_32930);

    /** execute.e:1285			one_trace_line("")*/
    RefDS(_22209);
    _67one_trace_line(_22209);

    /** execute.e:1286			one_trace_line("")*/
    RefDS(_22209);
    _67one_trace_line(_22209);

    /** execute.e:1287			one_trace_line("")*/
    RefDS(_22209);
    _67one_trace_line(_22209);

    /** execute.e:1288			flush(trace_file)*/
    _18flush(_67trace_file_66668);

    /** execute.e:1289			w = where(trace_file)*/
    _w_66693 = _18where(_67trace_file_66668);
    if (!IS_ATOM_INT(_w_66693)) {
        _1 = (object)(DBL_PTR(_w_66693)->dbl);
        DeRefDS(_w_66693);
        _w_66693 = _1;
    }

    /** execute.e:1290			if seek(trace_file, w-79*5) then -- back up 5 (fixed-width) lines*/
    _32932 = 395;
    _32933 = _w_66693 - 395;
    if ((object)((uintptr_t)_32933 +(uintptr_t) HIGH_BITS) >= 0){
        _32933 = NewDouble((eudouble)_32933);
    }
    _32932 = NOVALUE;
    _32934 = _18seek(_67trace_file_66668, _32933);
    _32933 = NOVALUE;
    if (_32934 == 0) {
        DeRef(_32934);
        _32934 = NOVALUE;
        goto L7; // [274] 278
    }
    else {
        if (!IS_ATOM_INT(_32934) && DBL_PTR(_32934)->dbl == 0.0){
            DeRef(_32934);
            _32934 = NOVALUE;
            goto L7; // [274] 278
        }
        DeRef(_32934);
        _32934 = NOVALUE;
    }
    DeRef(_32934);
    _32934 = NOVALUE;
L7: 
L1: 

    /** execute.e:1293		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1294	end procedure*/
    DeRef(_line_66692);
    DeRef(_32908);
    _32908 = NOVALUE;
    _32919 = NOVALUE;
    return;
    ;
}


void _67opPROC_TAIL()
{
    object _arg_66756 = NOVALUE;
    object _sub_66757 = NOVALUE;
    object _32952 = NOVALUE;
    object _32951 = NOVALUE;
    object _32950 = NOVALUE;
    object _32949 = NOVALUE;
    object _32948 = NOVALUE;
    object _32946 = NOVALUE;
    object _32945 = NOVALUE;
    object _32944 = NOVALUE;
    object _32943 = NOVALUE;
    object _32942 = NOVALUE;
    object _32941 = NOVALUE;
    object _32940 = NOVALUE;
    object _32938 = NOVALUE;
    object _32936 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1299		sub = Code[pc+1] -- subroutine*/
    _32936 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_66757 = (object)*(((s1_ptr)_2)->base + _32936);
    if (!IS_ATOM_INT(_sub_66757)){
        _sub_66757 = (object)DBL_PTR(_sub_66757)->dbl;
    }

    /** execute.e:1300		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32938 = (object)*(((s1_ptr)_2)->base + _sub_66757);
    _2 = (object)SEQ_PTR(_32938);
    _arg_66756 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66756)){
        _arg_66756 = (object)DBL_PTR(_arg_66756)->dbl;
    }
    _32938 = NOVALUE;

    /** execute.e:1303		for i = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32940 = (object)*(((s1_ptr)_2)->base + _sub_66757);
    _2 = (object)SEQ_PTR(_32940);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _32941 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _32941 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _32940 = NOVALUE;
    {
        object _i_66766;
        _i_66766 = 1;
L1: 
        if (binary_op_a(GREATER, _i_66766, _32941)){
            goto L2; // [47] 107
        }

        /** execute.e:1304			val[arg] = val[Code[pc+1+i]]*/
        _32942 = _67pc_65255 + 1;
        if (_32942 > MAXINT){
            _32942 = NewDouble((eudouble)_32942);
        }
        if (IS_ATOM_INT(_32942) && IS_ATOM_INT(_i_66766)) {
            _32943 = _32942 + _i_66766;
        }
        else {
            if (IS_ATOM_INT(_32942)) {
                _32943 = NewDouble((eudouble)_32942 + DBL_PTR(_i_66766)->dbl);
            }
            else {
                if (IS_ATOM_INT(_i_66766)) {
                    _32943 = NewDouble(DBL_PTR(_32942)->dbl + (eudouble)_i_66766);
                }
                else
                _32943 = NewDouble(DBL_PTR(_32942)->dbl + DBL_PTR(_i_66766)->dbl);
            }
        }
        DeRef(_32942);
        _32942 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_32943)){
            _32944 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32943)->dbl));
        }
        else{
            _32944 = (object)*(((s1_ptr)_2)->base + _32943);
        }
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!IS_ATOM_INT(_32944)){
            _32945 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32944)->dbl));
        }
        else{
            _32945 = (object)*(((s1_ptr)_2)->base + _32944);
        }
        Ref(_32945);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66756);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32945;
        if( _1 != _32945 ){
            DeRef(_1);
        }
        _32945 = NOVALUE;

        /** execute.e:1305			arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _32946 = (object)*(((s1_ptr)_2)->base + _arg_66756);
        _2 = (object)SEQ_PTR(_32946);
        _arg_66756 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66756)){
            _arg_66756 = (object)DBL_PTR(_arg_66756)->dbl;
        }
        _32946 = NOVALUE;

        /** execute.e:1306		end for*/
        _0 = _i_66766;
        if (IS_ATOM_INT(_i_66766)) {
            _i_66766 = _i_66766 + 1;
            if ((object)((uintptr_t)_i_66766 +(uintptr_t) HIGH_BITS) >= 0){
                _i_66766 = NewDouble((eudouble)_i_66766);
            }
        }
        else {
            _i_66766 = binary_op_a(PLUS, _i_66766, 1);
        }
        DeRef(_0);
        goto L1; // [102] 54
L2: 
        ;
        DeRef(_i_66766);
    }

    /** execute.e:1309		while arg and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    if (_arg_66756 == 0) {
        goto L4; // [112] 169
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32949 = (object)*(((s1_ptr)_2)->base + _arg_66756);
    _2 = (object)SEQ_PTR(_32949);
    _32950 = (object)*(((s1_ptr)_2)->base + 4);
    _32949 = NOVALUE;
    if (IS_ATOM_INT(_32950)) {
        _32951 = (_32950 <= 3);
    }
    else {
        _32951 = binary_op(LESSEQ, _32950, 3);
    }
    _32950 = NOVALUE;
    if (_32951 <= 0) {
        if (_32951 == 0) {
            DeRef(_32951);
            _32951 = NOVALUE;
            goto L4; // [135] 169
        }
        else {
            if (!IS_ATOM_INT(_32951) && DBL_PTR(_32951)->dbl == 0.0){
                DeRef(_32951);
                _32951 = NOVALUE;
                goto L4; // [135] 169
            }
            DeRef(_32951);
            _32951 = NOVALUE;
        }
    }
    DeRef(_32951);
    _32951 = NOVALUE;

    /** execute.e:1310			val[arg] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66756);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:1311			arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32952 = (object)*(((s1_ptr)_2)->base + _arg_66756);
    _2 = (object)SEQ_PTR(_32952);
    _arg_66756 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66756)){
        _arg_66756 = (object)DBL_PTR(_arg_66756)->dbl;
    }
    _32952 = NOVALUE;

    /** execute.e:1312		end while*/
    goto L3; // [166] 112
L4: 

    /** execute.e:1315		pc = 1*/
    _67pc_65255 = 1;

    /** execute.e:1316	end procedure*/
    DeRef(_32936);
    _32936 = NOVALUE;
    _32941 = NOVALUE;
    _32944 = NOVALUE;
    DeRef(_32943);
    _32943 = NOVALUE;
    return;
    ;
}


void _67opPROC()
{
    object _n_66795 = NOVALUE;
    object _arg_66796 = NOVALUE;
    object _sub_66797 = NOVALUE;
    object _p_66798 = NOVALUE;
    object _private_block_66799 = NOVALUE;
    object _33019 = NOVALUE;
    object _33014 = NOVALUE;
    object _33013 = NOVALUE;
    object _33011 = NOVALUE;
    object _33009 = NOVALUE;
    object _33007 = NOVALUE;
    object _33006 = NOVALUE;
    object _33005 = NOVALUE;
    object _33004 = NOVALUE;
    object _33003 = NOVALUE;
    object _33002 = NOVALUE;
    object _33000 = NOVALUE;
    object _32998 = NOVALUE;
    object _32995 = NOVALUE;
    object _32993 = NOVALUE;
    object _32991 = NOVALUE;
    object _32989 = NOVALUE;
    object _32988 = NOVALUE;
    object _32987 = NOVALUE;
    object _32986 = NOVALUE;
    object _32985 = NOVALUE;
    object _32984 = NOVALUE;
    object _32983 = NOVALUE;
    object _32982 = NOVALUE;
    object _32981 = NOVALUE;
    object _32980 = NOVALUE;
    object _32979 = NOVALUE;
    object _32978 = NOVALUE;
    object _32977 = NOVALUE;
    object _32976 = NOVALUE;
    object _32975 = NOVALUE;
    object _32973 = NOVALUE;
    object _32972 = NOVALUE;
    object _32971 = NOVALUE;
    object _32970 = NOVALUE;
    object _32969 = NOVALUE;
    object _32967 = NOVALUE;
    object _32966 = NOVALUE;
    object _32964 = NOVALUE;
    object _32963 = NOVALUE;
    object _32961 = NOVALUE;
    object _32960 = NOVALUE;
    object _32958 = NOVALUE;
    object _32956 = NOVALUE;
    object _32954 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1324		sub = Code[pc+1] -- subroutine*/
    _32954 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_66797 = (object)*(((s1_ptr)_2)->base + _32954);
    if (!IS_ATOM_INT(_sub_66797)){
        _sub_66797 = (object)DBL_PTR(_sub_66797)->dbl;
    }

    /** execute.e:1325		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32956 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    _2 = (object)SEQ_PTR(_32956);
    _arg_66796 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66796)){
        _arg_66796 = (object)DBL_PTR(_arg_66796)->dbl;
    }
    _32956 = NOVALUE;

    /** execute.e:1327		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32958 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    _2 = (object)SEQ_PTR(_32958);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_66795 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_66795 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_66795)){
        _n_66795 = (object)DBL_PTR(_n_66795)->dbl;
    }
    _32958 = NOVALUE;

    /** execute.e:1329		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32960 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    _2 = (object)SEQ_PTR(_32960);
    _32961 = (object)*(((s1_ptr)_2)->base + 25);
    _32960 = NOVALUE;
    if (binary_op_a(EQUALS, _32961, 0)){
        _32961 = NOVALUE;
        goto L1; // [63] 413
    }
    _32961 = NOVALUE;

    /** execute.e:1333			private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32963 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    _2 = (object)SEQ_PTR(_32963);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _32964 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _32964 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _32963 = NOVALUE;
    DeRef(_private_block_66799);
    _private_block_66799 = Repeat(0, _32964);
    _32964 = NOVALUE;

    /** execute.e:1334			p = 1*/
    _p_66798 = 1;

    /** execute.e:1335			for i = 1 to n do*/
    _32966 = _n_66795;
    {
        object _i_66823;
        _i_66823 = 1;
L2: 
        if (_i_66823 > _32966){
            goto L3; // [95] 173
        }

        /** execute.e:1336				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _32967 = (object)*(((s1_ptr)_2)->base + _arg_66796);
        Ref(_32967);
        _2 = (object)SEQ_PTR(_private_block_66799);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_66799 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_66798);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32967;
        if( _1 != _32967 ){
            DeRef(_1);
        }
        _32967 = NOVALUE;

        /** execute.e:1337				p += 1*/
        _p_66798 = _p_66798 + 1;

        /** execute.e:1338				val[arg] = val[Code[pc+1+i]]*/
        _32969 = _67pc_65255 + 1;
        if (_32969 > MAXINT){
            _32969 = NewDouble((eudouble)_32969);
        }
        if (IS_ATOM_INT(_32969)) {
            _32970 = _32969 + _i_66823;
        }
        else {
            _32970 = NewDouble(DBL_PTR(_32969)->dbl + (eudouble)_i_66823);
        }
        DeRef(_32969);
        _32969 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_32970)){
            _32971 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32970)->dbl));
        }
        else{
            _32971 = (object)*(((s1_ptr)_2)->base + _32970);
        }
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!IS_ATOM_INT(_32971)){
            _32972 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_32971)->dbl));
        }
        else{
            _32972 = (object)*(((s1_ptr)_2)->base + _32971);
        }
        Ref(_32972);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66796);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _32972;
        if( _1 != _32972 ){
            DeRef(_1);
        }
        _32972 = NOVALUE;

        /** execute.e:1339				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _32973 = (object)*(((s1_ptr)_2)->base + _arg_66796);
        _2 = (object)SEQ_PTR(_32973);
        _arg_66796 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66796)){
            _arg_66796 = (object)DBL_PTR(_arg_66796)->dbl;
        }
        _32973 = NOVALUE;

        /** execute.e:1340			end for*/
        _i_66823 = _i_66823 + 1;
        goto L2; // [168] 102
L3: 
        ;
    }

    /** execute.e:1343			while arg != 0 */
L4: 
    _32975 = (_arg_66796 != 0);
    if (_32975 == 0) {
        goto L5; // [182] 330
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32977 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    _2 = (object)SEQ_PTR(_32977);
    _32978 = (object)*(((s1_ptr)_2)->base + 4);
    _32977 = NOVALUE;
    if (IS_ATOM_INT(_32978)) {
        _32979 = (_32978 <= 3);
    }
    else {
        _32979 = binary_op(LESSEQ, _32978, 3);
    }
    _32978 = NOVALUE;
    if (IS_ATOM_INT(_32979)) {
        if (_32979 != 0) {
            DeRef(_32980);
            _32980 = 1;
            goto L6; // [204] 230
        }
    }
    else {
        if (DBL_PTR(_32979)->dbl != 0.0) {
            DeRef(_32980);
            _32980 = 1;
            goto L6; // [204] 230
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32981 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    _2 = (object)SEQ_PTR(_32981);
    _32982 = (object)*(((s1_ptr)_2)->base + 4);
    _32981 = NOVALUE;
    if (IS_ATOM_INT(_32982)) {
        _32983 = (_32982 == 2);
    }
    else {
        _32983 = binary_op(EQUALS, _32982, 2);
    }
    _32982 = NOVALUE;
    DeRef(_32980);
    if (IS_ATOM_INT(_32983))
    _32980 = (_32983 != 0);
    else
    _32980 = DBL_PTR(_32983)->dbl != 0.0;
L6: 
    if (_32980 != 0) {
        DeRef(_32984);
        _32984 = 1;
        goto L7; // [230] 256
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32985 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    _2 = (object)SEQ_PTR(_32985);
    _32986 = (object)*(((s1_ptr)_2)->base + 4);
    _32985 = NOVALUE;
    if (IS_ATOM_INT(_32986)) {
        _32987 = (_32986 == 9);
    }
    else {
        _32987 = binary_op(EQUALS, _32986, 9);
    }
    _32986 = NOVALUE;
    if (IS_ATOM_INT(_32987))
    _32984 = (_32987 != 0);
    else
    _32984 = DBL_PTR(_32987)->dbl != 0.0;
L7: 
    if (_32984 == 0)
    {
        _32984 = NOVALUE;
        goto L5; // [257] 330
    }
    else{
        _32984 = NOVALUE;
    }

    /** execute.e:1348				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32988 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    _2 = (object)SEQ_PTR(_32988);
    _32989 = (object)*(((s1_ptr)_2)->base + 4);
    _32988 = NOVALUE;
    if (binary_op_a(EQUALS, _32989, 9)){
        _32989 = NOVALUE;
        goto L8; // [276] 309
    }
    _32989 = NOVALUE;

    /** execute.e:1349					private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32991 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    Ref(_32991);
    _2 = (object)SEQ_PTR(_private_block_66799);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66799 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66798);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32991;
    if( _1 != _32991 ){
        DeRef(_1);
    }
    _32991 = NOVALUE;

    /** execute.e:1350					p += 1*/
    _p_66798 = _p_66798 + 1;

    /** execute.e:1351					val[arg] = NOVALUE  -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66796);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L8: 

    /** execute.e:1353				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32993 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    _2 = (object)SEQ_PTR(_32993);
    _arg_66796 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66796)){
        _arg_66796 = (object)DBL_PTR(_arg_66796)->dbl;
    }
    _32993 = NOVALUE;

    /** execute.e:1354			end while*/
    goto L4; // [327] 178
L5: 

    /** execute.e:1357			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _32995 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    _2 = (object)SEQ_PTR(_32995);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_66796 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_66796 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_66796)){
        _arg_66796 = (object)DBL_PTR(_arg_66796)->dbl;
    }
    _32995 = NOVALUE;

    /** execute.e:1358			while arg != 0 do*/
L9: 
    if (_arg_66796 == 0)
    goto LA; // [351] 404

    /** execute.e:1359				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _32998 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    Ref(_32998);
    _2 = (object)SEQ_PTR(_private_block_66799);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_66799 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_66798);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32998;
    if( _1 != _32998 ){
        DeRef(_1);
    }
    _32998 = NOVALUE;

    /** execute.e:1360				p += 1*/
    _p_66798 = _p_66798 + 1;

    /** execute.e:1361				val[arg] = NOVALUE -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_66796);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:1362				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33000 = (object)*(((s1_ptr)_2)->base + _arg_66796);
    _2 = (object)SEQ_PTR(_33000);
    _arg_66796 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66796)){
        _arg_66796 = (object)DBL_PTR(_arg_66796)->dbl;
    }
    _33000 = NOVALUE;

    /** execute.e:1363			end while*/
    goto L9; // [401] 351
LA: 

    /** execute.e:1366			save_private_block(sub, private_block)*/
    RefDS(_private_block_66799);
    _67save_private_block(_sub_66797, _private_block_66799);
    goto LB; // [410] 479
L1: 

    /** execute.e:1370			for i = 1 to n do*/
    _33002 = _n_66795;
    {
        object _i_66888;
        _i_66888 = 1;
LC: 
        if (_i_66888 > _33002){
            goto LD; // [418] 478
        }

        /** execute.e:1371				val[arg] = val[Code[pc+1+i]]*/
        _33003 = _67pc_65255 + 1;
        if (_33003 > MAXINT){
            _33003 = NewDouble((eudouble)_33003);
        }
        if (IS_ATOM_INT(_33003)) {
            _33004 = _33003 + _i_66888;
        }
        else {
            _33004 = NewDouble(DBL_PTR(_33003)->dbl + (eudouble)_i_66888);
        }
        DeRef(_33003);
        _33003 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_33004)){
            _33005 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33004)->dbl));
        }
        else{
            _33005 = (object)*(((s1_ptr)_2)->base + _33004);
        }
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!IS_ATOM_INT(_33005)){
            _33006 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33005)->dbl));
        }
        else{
            _33006 = (object)*(((s1_ptr)_2)->base + _33005);
        }
        Ref(_33006);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_66796);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33006;
        if( _1 != _33006 ){
            DeRef(_1);
        }
        _33006 = NOVALUE;

        /** execute.e:1372				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _33007 = (object)*(((s1_ptr)_2)->base + _arg_66796);
        _2 = (object)SEQ_PTR(_33007);
        _arg_66796 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66796)){
            _arg_66796 = (object)DBL_PTR(_arg_66796)->dbl;
        }
        _33007 = NOVALUE;

        /** execute.e:1373			end for*/
        _i_66888 = _i_66888 + 1;
        goto LC; // [473] 425
LD: 
        ;
    }
LB: 

    /** execute.e:1376		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66797 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65272;
    DeRef(_1);
    _33009 = NOVALUE;

    /** execute.e:1378		pc = pc + 2 + n*/
    _33011 = _67pc_65255 + 2;
    if ((object)((uintptr_t)_33011 + (uintptr_t)HIGH_BITS) >= 0){
        _33011 = NewDouble((eudouble)_33011);
    }
    if (IS_ATOM_INT(_33011)) {
        _67pc_65255 = _33011 + _n_66795;
    }
    else {
        _67pc_65255 = NewDouble(DBL_PTR(_33011)->dbl + (eudouble)_n_66795);
    }
    DeRef(_33011);
    _33011 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65255)) {
        _1 = (object)(DBL_PTR(_67pc_65255)->dbl);
        DeRefDS(_67pc_65255);
        _67pc_65255 = _1;
    }

    /** execute.e:1379		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33013 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    _2 = (object)SEQ_PTR(_33013);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _33014 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _33014 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _33013 = NOVALUE;
    if (binary_op_a(EQUALS, _33014, 27)){
        _33014 = NOVALUE;
        goto LE; // [526] 539
    }
    _33014 = NOVALUE;

    /** execute.e:1380			pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;
LE: 

    /** execute.e:1383		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _67pc_65255);

    /** execute.e:1384		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _sub_66797);

    /** execute.e:1386		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33019 = (object)*(((s1_ptr)_2)->base + _sub_66797);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_33019);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _33019 = NOVALUE;

    /** execute.e:1387		pc = 1*/
    _67pc_65255 = 1;

    /** execute.e:1388	end procedure*/
    DeRef(_private_block_66799);
    _33005 = NOVALUE;
    DeRef(_32987);
    _32987 = NOVALUE;
    _32971 = NOVALUE;
    DeRef(_33004);
    _33004 = NOVALUE;
    DeRef(_32975);
    _32975 = NOVALUE;
    DeRef(_32970);
    _32970 = NOVALUE;
    DeRef(_32954);
    _32954 = NOVALUE;
    DeRef(_32979);
    _32979 = NOVALUE;
    DeRef(_32983);
    _32983 = NOVALUE;
    return;
    ;
}


void _67exit_block(object _block_66925)
{
    object _a_66926 = NOVALUE;
    object _33024 = NOVALUE;
    object _33021 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_block_66925)) {
        _1 = (object)(DBL_PTR(_block_66925)->dbl);
        DeRefDS(_block_66925);
        _block_66925 = _1;
    }

    /** execute.e:1395		integer a = SymTab[block][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33021 = (object)*(((s1_ptr)_2)->base + _block_66925);
    _2 = (object)SEQ_PTR(_33021);
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201)){
        _a_66926 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    }
    else{
        _a_66926 = (object)*(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    }
    if (!IS_ATOM_INT(_a_66926)){
        _a_66926 = (object)DBL_PTR(_a_66926)->dbl;
    }
    _33021 = NOVALUE;

    /** execute.e:1396		while a do*/
L1: 
    if (_a_66926 == 0)
    {
        goto L2; // [24] 60
    }
    else{
    }

    /** execute.e:1398			ifdef DEBUG then*/

    /** execute.e:1407			val[a] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_66926);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:1409			a = SymTab[a][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33024 = (object)*(((s1_ptr)_2)->base + _a_66926);
    _2 = (object)SEQ_PTR(_33024);
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201)){
        _a_66926 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    }
    else{
        _a_66926 = (object)*(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    }
    if (!IS_ATOM_INT(_a_66926)){
        _a_66926 = (object)DBL_PTR(_a_66926)->dbl;
    }
    _33024 = NOVALUE;

    /** execute.e:1410		end while*/
    goto L1; // [57] 24
L2: 

    /** execute.e:1411	end procedure*/
    return;
    ;
}


void _67opEXIT_BLOCK()
{
    object _33027 = NOVALUE;
    object _33026 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1414		exit_block( Code[pc+1] )*/
    _33026 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33027 = (object)*(((s1_ptr)_2)->base + _33026);
    Ref(_33027);
    _67exit_block(_33027);
    _33027 = NOVALUE;

    /** execute.e:1415		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1416	end procedure*/
    _33026 = NOVALUE;
    return;
    ;
}


void _67opRETURNP()
{
    object _arg_66947 = NOVALUE;
    object _sub_66948 = NOVALUE;
    object _caller_66949 = NOVALUE;
    object _op_66950 = NOVALUE;
    object _block_66957 = NOVALUE;
    object _sub_block_66962 = NOVALUE;
    object _local_result_66967 = NOVALUE;
    object _local_result_val_66968 = NOVALUE;
    object _33052 = NOVALUE;
    object _33050 = NOVALUE;
    object _33048 = NOVALUE;
    object _33047 = NOVALUE;
    object _33045 = NOVALUE;
    object _33043 = NOVALUE;
    object _33042 = NOVALUE;
    object _33040 = NOVALUE;
    object _33039 = NOVALUE;
    object _33037 = NOVALUE;
    object _33034 = NOVALUE;
    object _33032 = NOVALUE;
    object _33030 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1421		integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_66950 = (object)*(((s1_ptr)_2)->base + _67pc_65255);
    if (!IS_ATOM_INT(_op_66950)){
        _op_66950 = (object)DBL_PTR(_op_66950)->dbl;
    }

    /** execute.e:1422		sub = Code[pc+1]*/
    _33030 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_66948 = (object)*(((s1_ptr)_2)->base + _33030);
    if (!IS_ATOM_INT(_sub_66948)){
        _sub_66948 = (object)DBL_PTR(_sub_66948)->dbl;
    }

    /** execute.e:1425		symtab_index block = Code[pc+2]*/
    _33032 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _block_66957 = (object)*(((s1_ptr)_2)->base + _33032);
    if (!IS_ATOM_INT(_block_66957)){
        _block_66957 = (object)DBL_PTR(_block_66957)->dbl;
    }

    /** execute.e:1426		symtab_index sub_block = SymTab[sub][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33034 = (object)*(((s1_ptr)_2)->base + _sub_66948);
    _2 = (object)SEQ_PTR(_33034);
    if (!IS_ATOM_INT(_27S_BLOCK_20229)){
        _sub_block_66962 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    }
    else{
        _sub_block_66962 = (object)*(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    }
    if (!IS_ATOM_INT(_sub_block_66962)){
        _sub_block_66962 = (object)DBL_PTR(_sub_block_66962)->dbl;
    }
    _33034 = NOVALUE;

    /** execute.e:1428		integer local_result = result*/
    _local_result_66967 = _67result_66920;

    /** execute.e:1429		object local_result_val*/

    /** execute.e:1430		if local_result then*/
    if (_local_result_66967 == 0)
    {
        goto L1; // [72] 95
    }
    else{
    }

    /** execute.e:1431			result = 0*/
    _67result_66920 = 0;

    /** execute.e:1432			local_result_val = result_val*/
    Ref(_67result_val_66921);
    DeRef(_local_result_val_66968);
    _local_result_val_66968 = _67result_val_66921;

    /** execute.e:1433			result_val = NOVALUE*/
    Ref(_27NOVALUE_20426);
    DeRef(_67result_val_66921);
    _67result_val_66921 = _27NOVALUE_20426;
L1: 

    /** execute.e:1436		while block != sub_block do*/
L2: 
    if (_block_66957 == _sub_block_66962)
    goto L3; // [100] 136

    /** execute.e:1437			if local_result then*/
    if (_local_result_66967 == 0)
    {
        goto L4; // [106] 115
    }
    else{
    }

    /** execute.e:1438				exit_block( block )*/
    _67exit_block(_block_66957);
L4: 

    /** execute.e:1440			block = SymTab[block][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33037 = (object)*(((s1_ptr)_2)->base + _block_66957);
    _2 = (object)SEQ_PTR(_33037);
    if (!IS_ATOM_INT(_27S_BLOCK_20229)){
        _block_66957 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    }
    else{
        _block_66957 = (object)*(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    }
    if (!IS_ATOM_INT(_block_66957)){
        _block_66957 = (object)DBL_PTR(_block_66957)->dbl;
    }
    _33037 = NOVALUE;

    /** execute.e:1441		end while*/
    goto L2; // [133] 100
L3: 

    /** execute.e:1443		exit_block( sub_block )*/
    _67exit_block(_sub_block_66962);

    /** execute.e:1451		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33039 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33039 = 1;
    }
    _33040 = _33039 - 1;
    _33039 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33040);
    if (!IS_ATOM_INT(_67pc_65255))
    _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;

    /** execute.e:1452		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33042 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33042 = 1;
    }
    _33043 = _33042 - 2;
    _33042 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65273;
    RHS_Slice(_67call_stack_65273, 1, _33043);

    /** execute.e:1454		SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_66948 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _33045 = NOVALUE;

    /** execute.e:1456		if length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33047 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33047 = 1;
    }
    if (_33047 == 0)
    {
        _33047 = NOVALUE;
        goto L5; // [194] 256
    }
    else{
        _33047 = NOVALUE;
    }

    /** execute.e:1457			caller = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33048 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33048 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _caller_66949 = (object)*(((s1_ptr)_2)->base + _33048);
    if (!IS_ATOM_INT(_caller_66949)){
        _caller_66949 = (object)DBL_PTR(_caller_66949)->dbl;
    }

    /** execute.e:1458			Code = SymTab[caller][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33050 = (object)*(((s1_ptr)_2)->base + _caller_66949);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_33050);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _33050 = NOVALUE;

    /** execute.e:1459			restore_privates(caller)*/
    _67restore_privates(_caller_66949);

    /** execute.e:1460			if local_result then*/
    if (_local_result_66967 == 0)
    {
        goto L6; // [233] 268
    }
    else{
    }

    /** execute.e:1461				val[Code[local_result]] = local_result_val*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33052 = (object)*(((s1_ptr)_2)->base + _local_result_66967);
    Ref(_local_result_val_66968);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33052))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33052)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33052);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _local_result_val_66968;
    DeRef(_1);
    goto L6; // [253] 268
L5: 

    /** execute.e:1464			kill_task(current_task)*/
    _67kill_task(_67current_task_65272);

    /** execute.e:1465			scheduler()*/
    _67scheduler();
L6: 

    /** execute.e:1469	end procedure*/
    DeRef(_local_result_val_66968);
    DeRef(_33032);
    _33032 = NOVALUE;
    DeRef(_33043);
    _33043 = NOVALUE;
    DeRef(_33040);
    _33040 = NOVALUE;
    DeRef(_33030);
    _33030 = NOVALUE;
    _33052 = NOVALUE;
    return;
    ;
}


void _67opRETURNF()
{
    object _33058 = NOVALUE;
    object _33057 = NOVALUE;
    object _33056 = NOVALUE;
    object _33054 = NOVALUE;
    object _33053 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1473		result_val = val[Code[pc+3]]*/
    _33053 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33054 = (object)*(((s1_ptr)_2)->base + _33053);
    DeRef(_67result_val_66921);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33054)){
        _67result_val_66921 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33054)->dbl));
    }
    else{
        _67result_val_66921 = (object)*(((s1_ptr)_2)->base + _33054);
    }
    Ref(_67result_val_66921);

    /** execute.e:1474		result = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33056 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33056 = 1;
    }
    _33057 = _33056 - 1;
    _33056 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _33058 = (object)*(((s1_ptr)_2)->base + _33057);
    if (IS_ATOM_INT(_33058)) {
        _67result_66920 = _33058 - 1;
    }
    else {
        _67result_66920 = binary_op(MINUS, _33058, 1);
    }
    _33058 = NOVALUE;
    if (!IS_ATOM_INT(_67result_66920)) {
        _1 = (object)(DBL_PTR(_67result_66920)->dbl);
        DeRefDS(_67result_66920);
        _67result_66920 = _1;
    }

    /** execute.e:1475		opRETURNP()*/
    _67opRETURNP();

    /** execute.e:1476	end procedure*/
    _33057 = NOVALUE;
    _33054 = NOVALUE;
    _33053 = NOVALUE;
    return;
    ;
}


void _67opCALL_BACK_RETURN()
{
    object _0, _1, _2;
    

    /** execute.e:1480		keep_running = FALSE*/
    _67keep_running_65262 = _9FALSE_439;

    /** execute.e:1481	end procedure*/
    return;
    ;
}


void _67opBADRETURNF()
{
    object _0, _1, _2;
    

    /** execute.e:1485		RTFatal("attempt to exit a function without returning a value")*/
    RefDS(_33060);
    _67RTFatal(_33060);

    /** execute.e:1486	end procedure*/
    return;
    ;
}


void _67opRETURNT()
{
    object _33062 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1490		pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:1491		if pc > length(Code) then*/
    if (IS_SEQUENCE(_27Code_20660)){
            _33062 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _33062 = 1;
    }
    if (_67pc_65255 <= _33062)
    goto L1; // [18] 32

    /** execute.e:1492			keep_running = FALSE  -- we've reached the end of the code*/
    _67keep_running_65262 = _9FALSE_439;
L1: 

    /** execute.e:1494	end procedure*/
    return;
    ;
}


void _67opRHS_SUBS()
{
    object _sub_67027 = NOVALUE;
    object _x_67028 = NOVALUE;
    object _33085 = NOVALUE;
    object _33084 = NOVALUE;
    object _33083 = NOVALUE;
    object _33082 = NOVALUE;
    object _33080 = NOVALUE;
    object _33079 = NOVALUE;
    object _33077 = NOVALUE;
    object _33074 = NOVALUE;
    object _33072 = NOVALUE;
    object _33068 = NOVALUE;
    object _33066 = NOVALUE;
    object _33064 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1501		a = Code[pc+1]*/
    _33064 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33064);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1502		b = Code[pc+2]*/
    _33066 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33066);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1503		target = Code[pc+3]*/
    _33068 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33068);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1504		x = val[a]*/
    DeRef(_x_67028);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67028 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67028);

    /** execute.e:1505		sub = val[b]*/
    DeRef(_sub_67027);
    _2 = (object)SEQ_PTR(_67val_65265);
    _sub_67027 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_sub_67027);

    /** execute.e:1506		if atom(x) then*/
    _33072 = IS_ATOM(_x_67028);
    if (_33072 == 0)
    {
        _33072 = NOVALUE;
        goto L1; // [74] 83
    }
    else{
        _33072 = NOVALUE;
    }

    /** execute.e:1507			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_33073);
    _67RTFatal(_33073);
L1: 

    /** execute.e:1509		if sequence(sub) then*/
    _33074 = IS_SEQUENCE(_sub_67027);
    if (_33074 == 0)
    {
        _33074 = NOVALUE;
        goto L2; // [88] 97
    }
    else{
        _33074 = NOVALUE;
    }

    /** execute.e:1510			RTFatal("subscript must be an atom\n(reading an element of a sequence)")*/
    RefDS(_33075);
    _67RTFatal(_33075);
L2: 

    /** execute.e:1512		sub = floor(sub)*/
    _0 = _sub_67027;
    if (IS_ATOM_INT(_sub_67027))
    _sub_67027 = e_floor(_sub_67027);
    else
    _sub_67027 = unary_op(FLOOR, _sub_67027);
    DeRef(_0);

    /** execute.e:1513		if sub < 1 or sub > length(x) then*/
    if (IS_ATOM_INT(_sub_67027)) {
        _33077 = (_sub_67027 < 1);
    }
    else {
        _33077 = binary_op(LESS, _sub_67027, 1);
    }
    if (IS_ATOM_INT(_33077)) {
        if (_33077 != 0) {
            goto L3; // [108] 124
        }
    }
    else {
        if (DBL_PTR(_33077)->dbl != 0.0) {
            goto L3; // [108] 124
        }
    }
    if (IS_SEQUENCE(_x_67028)){
            _33079 = SEQ_PTR(_x_67028)->length;
    }
    else {
        _33079 = 1;
    }
    if (IS_ATOM_INT(_sub_67027)) {
        _33080 = (_sub_67027 > _33079);
    }
    else {
        _33080 = binary_op(GREATER, _sub_67027, _33079);
    }
    _33079 = NOVALUE;
    if (_33080 == 0) {
        DeRef(_33080);
        _33080 = NOVALUE;
        goto L4; // [120] 141
    }
    else {
        if (!IS_ATOM_INT(_33080) && DBL_PTR(_33080)->dbl == 0.0){
            DeRef(_33080);
            _33080 = NOVALUE;
            goto L4; // [120] 141
        }
        DeRef(_33080);
        _33080 = NOVALUE;
    }
    DeRef(_33080);
    _33080 = NOVALUE;
L3: 

    /** execute.e:1514			RTFatal(*/
    if (IS_SEQUENCE(_x_67028)){
            _33082 = SEQ_PTR(_x_67028)->length;
    }
    else {
        _33082 = 1;
    }
    Ref(_sub_67027);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _sub_67027;
    ((intptr_t *)_2)[2] = _33082;
    _33083 = MAKE_SEQ(_1);
    _33082 = NOVALUE;
    _33084 = EPrintf(-9999999, _33081, _33083);
    DeRefDS(_33083);
    _33083 = NOVALUE;
    _67RTFatal(_33084);
    _33084 = NOVALUE;
L4: 

    /** execute.e:1519		val[target] = x[sub]*/
    _2 = (object)SEQ_PTR(_x_67028);
    if (!IS_ATOM_INT(_sub_67027)){
        _33085 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_sub_67027)->dbl));
    }
    else{
        _33085 = (object)*(((s1_ptr)_2)->base + _sub_67027);
    }
    Ref(_33085);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33085;
    if( _1 != _33085 ){
        DeRef(_1);
    }
    _33085 = NOVALUE;

    /** execute.e:1520		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:1521	end procedure*/
    DeRef(_sub_67027);
    DeRef(_x_67028);
    DeRef(_33068);
    _33068 = NOVALUE;
    DeRef(_33064);
    _33064 = NOVALUE;
    DeRef(_33077);
    _33077 = NOVALUE;
    DeRef(_33066);
    _33066 = NOVALUE;
    return;
    ;
}


void _67opGOTO()
{
    object _33087 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1524		pc = Code[pc+1]*/
    _33087 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33087);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:1525	end procedure*/
    _33087 = NOVALUE;
    return;
    ;
}


void _67opGLABEL()
{
    object _33089 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1527		pc = Code[pc+1]*/
    _33089 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33089);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:1528	end procedure*/
    _33089 = NOVALUE;
    return;
    ;
}


void _67opIF()
{
    object _33095 = NOVALUE;
    object _33093 = NOVALUE;
    object _33091 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1531		a = Code[pc+1]*/
    _33091 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33091);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1532		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33093 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(NOTEQ, _33093, 0)){
        _33093 = NOVALUE;
        goto L1; // [27] 50
    }
    _33093 = NOVALUE;

    /** execute.e:1533			pc = Code[pc+2]*/
    _33095 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33095);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1535			pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;
L2: 

    /** execute.e:1537	end procedure*/
    DeRef(_33091);
    _33091 = NOVALUE;
    DeRef(_33095);
    _33095 = NOVALUE;
    return;
    ;
}


void _67opINTEGER_CHECK()
{
    object _33103 = NOVALUE;
    object _33101 = NOVALUE;
    object _33100 = NOVALUE;
    object _33098 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1540		a = Code[pc+1]*/
    _33098 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33098);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1541		if not integer(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33100 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33100))
    _33101 = 1;
    else if (IS_ATOM_DBL(_33100))
    _33101 = IS_ATOM_INT(DoubleToInt(_33100));
    else
    _33101 = 0;
    _33100 = NOVALUE;
    if (_33101 != 0)
    goto L1; // [30] 45
    _33101 = NOVALUE;

    /** execute.e:1542			RTFatalType(pc+1)*/
    _33103 = _67pc_65255 + 1;
    if (_33103 > MAXINT){
        _33103 = NewDouble((eudouble)_33103);
    }
    _67RTFatalType(_33103);
    _33103 = NOVALUE;
L1: 

    /** execute.e:1544		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1545	end procedure*/
    DeRef(_33098);
    _33098 = NOVALUE;
    return;
    ;
}


void _67opATOM_CHECK()
{
    object _33110 = NOVALUE;
    object _33108 = NOVALUE;
    object _33107 = NOVALUE;
    object _33105 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1548		a = Code[pc+1]*/
    _33105 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33105);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1549		if not atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33107 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33108 = IS_ATOM(_33107);
    _33107 = NOVALUE;
    if (_33108 != 0)
    goto L1; // [30] 45
    _33108 = NOVALUE;

    /** execute.e:1550			RTFatalType(pc+1)*/
    _33110 = _67pc_65255 + 1;
    if (_33110 > MAXINT){
        _33110 = NewDouble((eudouble)_33110);
    }
    _67RTFatalType(_33110);
    _33110 = NOVALUE;
L1: 

    /** execute.e:1552		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1553	end procedure*/
    DeRef(_33105);
    _33105 = NOVALUE;
    return;
    ;
}


void _67opSEQUENCE_CHECK()
{
    object _33117 = NOVALUE;
    object _33115 = NOVALUE;
    object _33114 = NOVALUE;
    object _33112 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1556		a = Code[pc+1]*/
    _33112 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33112);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1557		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33114 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33115 = IS_SEQUENCE(_33114);
    _33114 = NOVALUE;
    if (_33115 != 0)
    goto L1; // [30] 45
    _33115 = NOVALUE;

    /** execute.e:1558			RTFatalType(pc+1)*/
    _33117 = _67pc_65255 + 1;
    if (_33117 > MAXINT){
        _33117 = NewDouble((eudouble)_33117);
    }
    _67RTFatalType(_33117);
    _33117 = NOVALUE;
L1: 

    /** execute.e:1560		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1561	end procedure*/
    DeRef(_33112);
    _33112 = NOVALUE;
    return;
    ;
}


void _67opASSIGN()
{
    object _a_67116 = NOVALUE;
    object _33124 = NOVALUE;
    object _33123 = NOVALUE;
    object _33121 = NOVALUE;
    object _33119 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1565		integer a = Code[pc+1]*/
    _33119 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _a_67116 = (object)*(((s1_ptr)_2)->base + _33119);
    if (!IS_ATOM_INT(_a_67116)){
        _a_67116 = (object)DBL_PTR(_a_67116)->dbl;
    }

    /** execute.e:1566		target = Code[pc+2]*/
    _33121 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33121);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1567		val[target] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33123 = (object)*(((s1_ptr)_2)->base + _a_67116);
    Ref(_33123);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33123;
    if( _1 != _33123 ){
        DeRef(_1);
    }
    _33123 = NOVALUE;

    /** execute.e:1568		if sym_mode( a ) = M_TEMP then*/
    _33124 = _53sym_mode(_a_67116);
    if (binary_op_a(NOTEQ, _33124, 3)){
        DeRef(_33124);
        _33124 = NOVALUE;
        goto L1; // [57] 72
    }
    DeRef(_33124);
    _33124 = NOVALUE;

    /** execute.e:1569			val[a] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _a_67116);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:1571		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:1572	end procedure*/
    DeRef(_33121);
    _33121 = NOVALUE;
    DeRef(_33119);
    _33119 = NOVALUE;
    return;
    ;
}


void _67opELSE()
{
    object _33127 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1576		pc = Code[pc+1]*/
    _33127 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33127);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:1577	end procedure*/
    _33127 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_N()
{
    object _x_67138 = NOVALUE;
    object _33144 = NOVALUE;
    object _33142 = NOVALUE;
    object _33141 = NOVALUE;
    object _33140 = NOVALUE;
    object _33138 = NOVALUE;
    object _33137 = NOVALUE;
    object _33135 = NOVALUE;
    object _33134 = NOVALUE;
    object _33133 = NOVALUE;
    object _33132 = NOVALUE;
    object _33131 = NOVALUE;
    object _33129 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1583		len = Code[pc+1]*/
    _33129 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67len_65261 = (object)*(((s1_ptr)_2)->base + _33129);
    if (!IS_ATOM_INT(_67len_65261)){
        _67len_65261 = (object)DBL_PTR(_67len_65261)->dbl;
    }

    /** execute.e:1584		x = {}*/
    RefDS(_22209);
    DeRef(_x_67138);
    _x_67138 = _22209;

    /** execute.e:1585		for i = pc+len+1 to pc+2 by -1 do*/
    _33131 = _67pc_65255 + _67len_65261;
    if ((object)((uintptr_t)_33131 + (uintptr_t)HIGH_BITS) >= 0){
        _33131 = NewDouble((eudouble)_33131);
    }
    if (IS_ATOM_INT(_33131)) {
        _33132 = _33131 + 1;
        if (_33132 > MAXINT){
            _33132 = NewDouble((eudouble)_33132);
        }
    }
    else
    _33132 = binary_op(PLUS, 1, _33131);
    DeRef(_33131);
    _33131 = NOVALUE;
    _33133 = _67pc_65255 + 2;
    if ((object)((uintptr_t)_33133 + (uintptr_t)HIGH_BITS) >= 0){
        _33133 = NewDouble((eudouble)_33133);
    }
    {
        object _i_67143;
        Ref(_33132);
        _i_67143 = _33132;
L1: 
        if (binary_op_a(LESS, _i_67143, _33133)){
            goto L2; // [44] 111
        }

        /** execute.e:1587			x = append(x, val[Code[i]])*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_67143)){
            _33134 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_67143)->dbl));
        }
        else{
            _33134 = (object)*(((s1_ptr)_2)->base + _i_67143);
        }
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!IS_ATOM_INT(_33134)){
            _33135 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33134)->dbl));
        }
        else{
            _33135 = (object)*(((s1_ptr)_2)->base + _33134);
        }
        Ref(_33135);
        Append(&_x_67138, _x_67138, _33135);
        _33135 = NOVALUE;

        /** execute.e:1588			if sym_mode( Code[i] ) = M_TEMP then*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_67143)){
            _33137 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_67143)->dbl));
        }
        else{
            _33137 = (object)*(((s1_ptr)_2)->base + _i_67143);
        }
        Ref(_33137);
        _33138 = _53sym_mode(_33137);
        _33137 = NOVALUE;
        if (binary_op_a(NOTEQ, _33138, 3)){
            DeRef(_33138);
            _33138 = NOVALUE;
            goto L3; // [83] 104
        }
        DeRef(_33138);
        _33138 = NOVALUE;

        /** execute.e:1589				val[Code[i]] = NOVALUE*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_67143)){
            _33140 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_67143)->dbl));
        }
        else{
            _33140 = (object)*(((s1_ptr)_2)->base + _i_67143);
        }
        Ref(_27NOVALUE_20426);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_33140))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33140)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _33140);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27NOVALUE_20426;
        DeRef(_1);
L3: 

        /** execute.e:1591		end for*/
        _0 = _i_67143;
        if (IS_ATOM_INT(_i_67143)) {
            _i_67143 = _i_67143 + -1;
            if ((object)((uintptr_t)_i_67143 +(uintptr_t) HIGH_BITS) >= 0){
                _i_67143 = NewDouble((eudouble)_i_67143);
            }
        }
        else {
            _i_67143 = binary_op_a(PLUS, _i_67143, -1);
        }
        DeRef(_0);
        goto L1; // [106] 51
L2: 
        ;
        DeRef(_i_67143);
    }

    /** execute.e:1592		target = Code[pc+len+2]*/
    _33141 = _67pc_65255 + _67len_65261;
    if ((object)((uintptr_t)_33141 + (uintptr_t)HIGH_BITS) >= 0){
        _33141 = NewDouble((eudouble)_33141);
    }
    if (IS_ATOM_INT(_33141)) {
        _33142 = _33141 + 2;
    }
    else {
        _33142 = NewDouble(DBL_PTR(_33141)->dbl + (eudouble)2);
    }
    DeRef(_33141);
    _33141 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_33142)){
        _67target_65260 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33142)->dbl));
    }
    else{
        _67target_65260 = (object)*(((s1_ptr)_2)->base + _33142);
    }
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1593		val[target] = x*/
    RefDS(_x_67138);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_67138;
    DeRef(_1);

    /** execute.e:1594		pc += 3 + len*/
    _33144 = 3 + _67len_65261;
    if ((object)((uintptr_t)_33144 + (uintptr_t)HIGH_BITS) >= 0){
        _33144 = NewDouble((eudouble)_33144);
    }
    if (IS_ATOM_INT(_33144)) {
        _67pc_65255 = _67pc_65255 + _33144;
    }
    else {
        _67pc_65255 = NewDouble((eudouble)_67pc_65255 + DBL_PTR(_33144)->dbl);
    }
    DeRef(_33144);
    _33144 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65255)) {
        _1 = (object)(DBL_PTR(_67pc_65255)->dbl);
        DeRefDS(_67pc_65255);
        _67pc_65255 = _1;
    }

    /** execute.e:1595	end procedure*/
    DeRefDS(_x_67138);
    DeRef(_33142);
    _33142 = NOVALUE;
    _33140 = NOVALUE;
    DeRef(_33132);
    _33132 = NOVALUE;
    DeRef(_33133);
    _33133 = NOVALUE;
    DeRef(_33129);
    _33129 = NOVALUE;
    _33134 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_2()
{
    object _33166 = NOVALUE;
    object _33165 = NOVALUE;
    object _33163 = NOVALUE;
    object _33162 = NOVALUE;
    object _33161 = NOVALUE;
    object _33160 = NOVALUE;
    object _33159 = NOVALUE;
    object _33157 = NOVALUE;
    object _33156 = NOVALUE;
    object _33155 = NOVALUE;
    object _33154 = NOVALUE;
    object _33153 = NOVALUE;
    object _33152 = NOVALUE;
    object _33151 = NOVALUE;
    object _33150 = NOVALUE;
    object _33149 = NOVALUE;
    object _33148 = NOVALUE;
    object _33146 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1599		target = Code[pc+3]*/
    _33146 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33146);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1601		val[target] = {val[Code[pc+2]], val[Code[pc+1]]}*/
    _33148 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33149 = (object)*(((s1_ptr)_2)->base + _33148);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33149)){
        _33150 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33149)->dbl));
    }
    else{
        _33150 = (object)*(((s1_ptr)_2)->base + _33149);
    }
    _33151 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33152 = (object)*(((s1_ptr)_2)->base + _33151);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33152)){
        _33153 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33152)->dbl));
    }
    else{
        _33153 = (object)*(((s1_ptr)_2)->base + _33152);
    }
    Ref(_33153);
    Ref(_33150);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _33150;
    ((intptr_t *)_2)[2] = _33153;
    _33154 = MAKE_SEQ(_1);
    _33153 = NOVALUE;
    _33150 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33154;
    if( _1 != _33154 ){
        DeRef(_1);
    }
    _33154 = NOVALUE;

    /** execute.e:1602		if sym_mode( Code[pc+2] ) = M_TEMP then*/
    _33155 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33156 = (object)*(((s1_ptr)_2)->base + _33155);
    Ref(_33156);
    _33157 = _53sym_mode(_33156);
    _33156 = NOVALUE;
    if (binary_op_a(NOTEQ, _33157, 3)){
        DeRef(_33157);
        _33157 = NOVALUE;
        goto L1; // [87] 114
    }
    DeRef(_33157);
    _33157 = NOVALUE;

    /** execute.e:1603			val[Code[pc+2]] = NOVALUE*/
    _33159 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33160 = (object)*(((s1_ptr)_2)->base + _33159);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33160))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33160)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33160);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:1605		if sym_mode( Code[pc+1] ) = M_TEMP then*/
    _33161 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33162 = (object)*(((s1_ptr)_2)->base + _33161);
    Ref(_33162);
    _33163 = _53sym_mode(_33162);
    _33162 = NOVALUE;
    if (binary_op_a(NOTEQ, _33163, 3)){
        DeRef(_33163);
        _33163 = NOVALUE;
        goto L2; // [134] 161
    }
    DeRef(_33163);
    _33163 = NOVALUE;

    /** execute.e:1606			val[Code[pc+1]] = NOVALUE*/
    _33165 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33166 = (object)*(((s1_ptr)_2)->base + _33165);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33166))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33166)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33166);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L2: 

    /** execute.e:1608		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:1609	end procedure*/
    DeRef(_33151);
    _33151 = NOVALUE;
    _33149 = NOVALUE;
    DeRef(_33159);
    _33159 = NOVALUE;
    DeRef(_33161);
    _33161 = NOVALUE;
    DeRef(_33148);
    _33148 = NOVALUE;
    DeRef(_33146);
    _33146 = NOVALUE;
    DeRef(_33165);
    _33165 = NOVALUE;
    _33152 = NOVALUE;
    _33160 = NOVALUE;
    DeRef(_33155);
    _33155 = NOVALUE;
    _33166 = NOVALUE;
    return;
    ;
}


void _67opPLUS1()
{
    object _33173 = NOVALUE;
    object _33172 = NOVALUE;
    object _33170 = NOVALUE;
    object _33168 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1613		a = Code[pc+1]*/
    _33168 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33168);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1615		target = Code[pc+3]*/
    _33170 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33170);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1616		val[target] = val[a] + 1*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33172 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33172)) {
        _33173 = _33172 + 1;
        if (_33173 > MAXINT){
            _33173 = NewDouble((eudouble)_33173);
        }
    }
    else
    _33173 = binary_op(PLUS, 1, _33172);
    _33172 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33173;
    if( _1 != _33173 ){
        DeRef(_1);
    }
    _33173 = NOVALUE;

    /** execute.e:1617		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:1618	end procedure*/
    _33168 = NOVALUE;
    _33170 = NOVALUE;
    return;
    ;
}


void _67opGLOBAL_INIT_CHECK()
{
    object _33183 = NOVALUE;
    object _33181 = NOVALUE;
    object _33180 = NOVALUE;
    object _33178 = NOVALUE;
    object _33177 = NOVALUE;
    object _33175 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1622		a = Code[pc+1]*/
    _33175 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33175);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1623		if equal(val[a], NOVALUE) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33177 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (_33177 == _27NOVALUE_20426)
    _33178 = 1;
    else if (IS_ATOM_INT(_33177) && IS_ATOM_INT(_27NOVALUE_20426))
    _33178 = 0;
    else
    _33178 = (compare(_33177, _27NOVALUE_20426) == 0);
    _33177 = NOVALUE;
    if (_33178 == 0)
    {
        _33178 = NOVALUE;
        goto L1; // [33] 62
    }
    else{
        _33178 = NOVALUE;
    }

    /** execute.e:1624			RTFatal("variable " & SymTab[a][S_NAME] & " has not been assigned a value")*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _33180 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_33180);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _33181 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _33181 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _33180 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _33182;
        concat_list[1] = _33181;
        concat_list[2] = _33179;
        Concat_N((object_ptr)&_33183, concat_list, 3);
    }
    _33181 = NOVALUE;
    _67RTFatal(_33183);
    _33183 = NOVALUE;
L1: 

    /** execute.e:1626		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:1627	end procedure*/
    DeRef(_33175);
    _33175 = NOVALUE;
    return;
    ;
}


void _67opWHILE()
{
    object _33189 = NOVALUE;
    object _33187 = NOVALUE;
    object _33185 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1631		a = Code[pc+1]*/
    _33185 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33185);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1632		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33187 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(NOTEQ, _33187, 0)){
        _33187 = NOVALUE;
        goto L1; // [27] 50
    }
    _33187 = NOVALUE;

    /** execute.e:1633			pc = Code[pc+2]*/
    _33189 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33189);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** execute.e:1635			pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;
L2: 

    /** execute.e:1637	end procedure*/
    DeRef(_33189);
    _33189 = NOVALUE;
    DeRef(_33185);
    _33185 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_SPI()
{
    object _33214 = NOVALUE;
    object _33212 = NOVALUE;
    object _33211 = NOVALUE;
    object _33210 = NOVALUE;
    object _33209 = NOVALUE;
    object _33208 = NOVALUE;
    object _33207 = NOVALUE;
    object _33206 = NOVALUE;
    object _33205 = NOVALUE;
    object _33204 = NOVALUE;
    object _33203 = NOVALUE;
    object _33202 = NOVALUE;
    object _33200 = NOVALUE;
    object _33199 = NOVALUE;
    object _33198 = NOVALUE;
    object _33197 = NOVALUE;
    object _33196 = NOVALUE;
    object _33195 = NOVALUE;
    object _33194 = NOVALUE;
    object _33193 = NOVALUE;
    object _33192 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1645		if integer( val[Code[pc+1]] ) then*/
    _33192 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33193 = (object)*(((s1_ptr)_2)->base + _33192);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33193)){
        _33194 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33193)->dbl));
    }
    else{
        _33194 = (object)*(((s1_ptr)_2)->base + _33193);
    }
    if (IS_ATOM_INT(_33194))
    _33195 = 1;
    else if (IS_ATOM_DBL(_33194))
    _33195 = IS_ATOM_INT(DoubleToInt(_33194));
    else
    _33195 = 0;
    _33194 = NOVALUE;
    if (_33195 == 0)
    {
        _33195 = NOVALUE;
        goto L1; // [24] 149
    }
    else{
        _33195 = NOVALUE;
    }

    /** execute.e:1646			a = val[Code[pc+1]] - Code[pc+2]*/
    _33196 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33197 = (object)*(((s1_ptr)_2)->base + _33196);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33197)){
        _33198 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33197)->dbl));
    }
    else{
        _33198 = (object)*(((s1_ptr)_2)->base + _33197);
    }
    _33199 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33200 = (object)*(((s1_ptr)_2)->base + _33199);
    if (IS_ATOM_INT(_33198) && IS_ATOM_INT(_33200)) {
        _67a_65256 = _33198 - _33200;
    }
    else {
        _67a_65256 = binary_op(MINUS, _33198, _33200);
    }
    _33198 = NOVALUE;
    _33200 = NOVALUE;
    if (!IS_ATOM_INT(_67a_65256)) {
        _1 = (object)(DBL_PTR(_67a_65256)->dbl);
        DeRefDS(_67a_65256);
        _67a_65256 = _1;
    }

    /** execute.e:1647			if a > 0 and a <= length( val[Code[pc+3]] ) then*/
    _33202 = (_67a_65256 > 0);
    if (_33202 == 0) {
        goto L2; // [73] 148
    }
    _33204 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33205 = (object)*(((s1_ptr)_2)->base + _33204);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33205)){
        _33206 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33205)->dbl));
    }
    else{
        _33206 = (object)*(((s1_ptr)_2)->base + _33205);
    }
    if (IS_SEQUENCE(_33206)){
            _33207 = SEQ_PTR(_33206)->length;
    }
    else {
        _33207 = 1;
    }
    _33206 = NOVALUE;
    _33208 = (_67a_65256 <= _33207);
    _33207 = NOVALUE;
    if (_33208 == 0)
    {
        DeRef(_33208);
        _33208 = NOVALUE;
        goto L2; // [105] 148
    }
    else{
        DeRef(_33208);
        _33208 = NOVALUE;
    }

    /** execute.e:1648				pc += val[Code[pc+3]][a]*/
    _33209 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33210 = (object)*(((s1_ptr)_2)->base + _33209);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33210)){
        _33211 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33210)->dbl));
    }
    else{
        _33211 = (object)*(((s1_ptr)_2)->base + _33210);
    }
    _2 = (object)SEQ_PTR(_33211);
    _33212 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33211 = NOVALUE;
    if (IS_ATOM_INT(_33212)) {
        _67pc_65255 = _67pc_65255 + _33212;
    }
    else {
        _67pc_65255 = binary_op(PLUS, _67pc_65255, _33212);
    }
    _33212 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65255)) {
        _1 = (object)(DBL_PTR(_67pc_65255)->dbl);
        DeRefDS(_67pc_65255);
        _67pc_65255 = _1;
    }

    /** execute.e:1649				return*/
    _33205 = NOVALUE;
    _33209 = NOVALUE;
    DeRef(_33199);
    _33199 = NOVALUE;
    DeRef(_33192);
    _33192 = NOVALUE;
    DeRef(_33202);
    _33202 = NOVALUE;
    _33206 = NOVALUE;
    DeRef(_33196);
    _33196 = NOVALUE;
    DeRef(_33204);
    _33204 = NOVALUE;
    _33210 = NOVALUE;
    _33197 = NOVALUE;
    _33193 = NOVALUE;
    return;
L2: 
L1: 

    /** execute.e:1652		pc = Code[pc+4]*/
    _33214 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33214);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:1653	end procedure*/
    _33205 = NOVALUE;
    DeRef(_33209);
    _33209 = NOVALUE;
    _33214 = NOVALUE;
    DeRef(_33199);
    _33199 = NOVALUE;
    DeRef(_33192);
    _33192 = NOVALUE;
    DeRef(_33202);
    _33202 = NOVALUE;
    _33206 = NOVALUE;
    DeRef(_33196);
    _33196 = NOVALUE;
    DeRef(_33204);
    _33204 = NOVALUE;
    _33210 = NOVALUE;
    _33197 = NOVALUE;
    _33193 = NOVALUE;
    return;
    ;
}


void _67opSWITCH()
{
    object _33228 = NOVALUE;
    object _33226 = NOVALUE;
    object _33225 = NOVALUE;
    object _33224 = NOVALUE;
    object _33223 = NOVALUE;
    object _33221 = NOVALUE;
    object _33220 = NOVALUE;
    object _33219 = NOVALUE;
    object _33218 = NOVALUE;
    object _33217 = NOVALUE;
    object _33216 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1660		a = find( val[Code[pc+1]], val[Code[pc+2]] )*/
    _33216 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33217 = (object)*(((s1_ptr)_2)->base + _33216);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33217)){
        _33218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33217)->dbl));
    }
    else{
        _33218 = (object)*(((s1_ptr)_2)->base + _33217);
    }
    _33219 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33220 = (object)*(((s1_ptr)_2)->base + _33219);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33220)){
        _33221 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33220)->dbl));
    }
    else{
        _33221 = (object)*(((s1_ptr)_2)->base + _33220);
    }
    _67a_65256 = find_from(_33218, _33221, 1);
    _33218 = NOVALUE;
    _33221 = NOVALUE;

    /** execute.e:1661		if a then*/
    if (_67a_65256 == 0)
    {
        goto L1; // [48] 88
    }
    else{
    }

    /** execute.e:1662			pc += val[Code[pc+3]][a]*/
    _33223 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33224 = (object)*(((s1_ptr)_2)->base + _33223);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33224)){
        _33225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33224)->dbl));
    }
    else{
        _33225 = (object)*(((s1_ptr)_2)->base + _33224);
    }
    _2 = (object)SEQ_PTR(_33225);
    _33226 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33225 = NOVALUE;
    if (IS_ATOM_INT(_33226)) {
        _67pc_65255 = _67pc_65255 + _33226;
    }
    else {
        _67pc_65255 = binary_op(PLUS, _67pc_65255, _33226);
    }
    _33226 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65255)) {
        _1 = (object)(DBL_PTR(_67pc_65255)->dbl);
        DeRefDS(_67pc_65255);
        _67pc_65255 = _1;
    }
    goto L2; // [85] 105
L1: 

    /** execute.e:1664			pc = Code[pc + 4]*/
    _33228 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33228);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:1666	end procedure*/
    _33217 = NOVALUE;
    DeRef(_33228);
    _33228 = NOVALUE;
    _33224 = NOVALUE;
    DeRef(_33219);
    _33219 = NOVALUE;
    _33220 = NOVALUE;
    DeRef(_33223);
    _33223 = NOVALUE;
    DeRef(_33216);
    _33216 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_RT()
{
    object _values_67305 = NOVALUE;
    object _all_ints_67310 = NOVALUE;
    object _max_67311 = NOVALUE;
    object _min_67313 = NOVALUE;
    object _sym_67318 = NOVALUE;
    object _sign_67320 = NOVALUE;
    object _new_value_67335 = NOVALUE;
    object _jump_67352 = NOVALUE;
    object _switch_table_67357 = NOVALUE;
    object _offset_67365 = NOVALUE;
    object _33280 = NOVALUE;
    object _33279 = NOVALUE;
    object _33278 = NOVALUE;
    object _33277 = NOVALUE;
    object _33276 = NOVALUE;
    object _33273 = NOVALUE;
    object _33272 = NOVALUE;
    object _33271 = NOVALUE;
    object _33270 = NOVALUE;
    object _33269 = NOVALUE;
    object _33267 = NOVALUE;
    object _33266 = NOVALUE;
    object _33265 = NOVALUE;
    object _33264 = NOVALUE;
    object _33263 = NOVALUE;
    object _33260 = NOVALUE;
    object _33259 = NOVALUE;
    object _33258 = NOVALUE;
    object _33257 = NOVALUE;
    object _33256 = NOVALUE;
    object _33254 = NOVALUE;
    object _33253 = NOVALUE;
    object _33252 = NOVALUE;
    object _33251 = NOVALUE;
    object _33250 = NOVALUE;
    object _33246 = NOVALUE;
    object _33244 = NOVALUE;
    object _33243 = NOVALUE;
    object _33242 = NOVALUE;
    object _33241 = NOVALUE;
    object _33240 = NOVALUE;
    object _33238 = NOVALUE;
    object _33237 = NOVALUE;
    object _33233 = NOVALUE;
    object _33231 = NOVALUE;
    object _33230 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1677		sequence values = val[Code[pc+2]]*/
    _33230 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33231 = (object)*(((s1_ptr)_2)->base + _33230);
    DeRef(_values_67305);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33231)){
        _values_67305 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33231)->dbl));
    }
    else{
        _values_67305 = (object)*(((s1_ptr)_2)->base + _33231);
    }
    Ref(_values_67305);

    /** execute.e:1678		integer all_ints = 1*/
    _all_ints_67310 = 1;

    /** execute.e:1679		integer max = MININT*/
    _max_67311 = -1073741824;

    /** execute.e:1680		integer min = MAXINT*/
    _min_67313 = 1073741823;

    /** execute.e:1681		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_67305)){
            _33233 = SEQ_PTR(_values_67305)->length;
    }
    else {
        _33233 = 1;
    }
    {
        object _i_67316;
        _i_67316 = 1;
L1: 
        if (_i_67316 > _33233){
            goto L2; // [51] 209
        }

        /** execute.e:1682			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_67305);
        _sym_67318 = (object)*(((s1_ptr)_2)->base + _i_67316);
        if (!IS_ATOM_INT(_sym_67318))
        _sym_67318 = (object)DBL_PTR(_sym_67318)->dbl;

        /** execute.e:1683			integer sign = 1*/
        _sign_67320 = 1;

        /** execute.e:1684			if sym < 0 then*/
        if (_sym_67318 >= 0)
        goto L3; // [71] 88

        /** execute.e:1685				sign = -1*/
        _sign_67320 = -1;

        /** execute.e:1686				sym = -sym*/
        _sym_67318 = - _sym_67318;
L3: 

        /** execute.e:1688			if equal(val[sym], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _33237 = (object)*(((s1_ptr)_2)->base + _sym_67318);
        if (_33237 == _27NOVALUE_20426)
        _33238 = 1;
        else if (IS_ATOM_INT(_33237) && IS_ATOM_INT(_27NOVALUE_20426))
        _33238 = 0;
        else
        _33238 = (compare(_33237, _27NOVALUE_20426) == 0);
        _33237 = NOVALUE;
        if (_33238 == 0)
        {
            _33238 = NOVALUE;
            goto L4; // [102] 131
        }
        else{
            _33238 = NOVALUE;
        }

        /** execute.e:1689				RTFatal( sprintf( "'%s' has not been assigned a value", {SymTab[sym][S_NAME]} ) )*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _33240 = (object)*(((s1_ptr)_2)->base + _sym_67318);
        _2 = (object)SEQ_PTR(_33240);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _33241 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _33241 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _33240 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_33241);
        ((intptr_t*)_2)[1] = _33241;
        _33242 = MAKE_SEQ(_1);
        _33241 = NOVALUE;
        _33243 = EPrintf(-9999999, _33239, _33242);
        DeRefDS(_33242);
        _33242 = NOVALUE;
        _67RTFatal(_33243);
        _33243 = NOVALUE;
L4: 

        /** execute.e:1691			object new_value = sign * val[sym]*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _33244 = (object)*(((s1_ptr)_2)->base + _sym_67318);
        DeRef(_new_value_67335);
        if (IS_ATOM_INT(_33244)) {
            if (_sign_67320 == (short)_sign_67320 && _33244 <= INT15 && _33244 >= -INT15){
                _new_value_67335 = _sign_67320 * _33244;
            }
            else{
                _new_value_67335 = NewDouble(_sign_67320 * (eudouble)_33244);
            }
        }
        else {
            _new_value_67335 = binary_op(MULTIPLY, _sign_67320, _33244);
        }
        _33244 = NOVALUE;

        /** execute.e:1692			values[i] = new_value*/
        Ref(_new_value_67335);
        _2 = (object)SEQ_PTR(_values_67305);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_67305 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_67316);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _new_value_67335;
        DeRef(_1);

        /** execute.e:1693			if not integer( new_value ) then*/
        if (IS_ATOM_INT(_new_value_67335))
        _33246 = 1;
        else if (IS_ATOM_DBL(_new_value_67335))
        _33246 = IS_ATOM_INT(DoubleToInt(_new_value_67335));
        else
        _33246 = 0;
        if (_33246 != 0)
        goto L5; // [154] 165
        _33246 = NOVALUE;

        /** execute.e:1694				all_ints = 0*/
        _all_ints_67310 = 0;
        goto L6; // [162] 200
L5: 

        /** execute.e:1696			elsif all_ints then*/
        if (_all_ints_67310 == 0)
        {
            goto L7; // [167] 199
        }
        else{
        }

        /** execute.e:1697				if new_value < min then*/
        if (binary_op_a(GREATEREQ, _new_value_67335, _min_67313)){
            goto L8; // [172] 184
        }

        /** execute.e:1698					min = new_value*/
        Ref(_new_value_67335);
        _min_67313 = _new_value_67335;
        if (!IS_ATOM_INT(_min_67313)) {
            _1 = (object)(DBL_PTR(_min_67313)->dbl);
            DeRefDS(_min_67313);
            _min_67313 = _1;
        }
L8: 

        /** execute.e:1701				if new_value > max then*/
        if (binary_op_a(LESSEQ, _new_value_67335, _max_67311)){
            goto L9; // [186] 198
        }

        /** execute.e:1702					max = new_value*/
        Ref(_new_value_67335);
        _max_67311 = _new_value_67335;
        if (!IS_ATOM_INT(_max_67311)) {
            _1 = (object)(DBL_PTR(_max_67311)->dbl);
            DeRefDS(_max_67311);
            _max_67311 = _1;
        }
L9: 
L7: 
L6: 
        DeRef(_new_value_67335);
        _new_value_67335 = NOVALUE;

        /** execute.e:1705		end for*/
        _i_67316 = _i_67316 + 1;
        goto L1; // [204] 58
L2: 
        ;
    }

    /** execute.e:1707		if all_ints and max - min < 1024 then*/
    if (_all_ints_67310 == 0) {
        goto LA; // [211] 412
    }
    _33251 = _max_67311 - _min_67313;
    if ((object)((uintptr_t)_33251 +(uintptr_t) HIGH_BITS) >= 0){
        _33251 = NewDouble((eudouble)_33251);
    }
    if (IS_ATOM_INT(_33251)) {
        _33252 = (_33251 < 1024);
    }
    else {
        _33252 = (DBL_PTR(_33251)->dbl < (eudouble)1024);
    }
    DeRef(_33251);
    _33251 = NOVALUE;
    if (_33252 == 0)
    {
        DeRef(_33252);
        _33252 = NOVALUE;
        goto LA; // [224] 412
    }
    else{
        DeRef(_33252);
        _33252 = NOVALUE;
    }

    /** execute.e:1708			Code[pc] = SWITCH_SPI*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_65255);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 192;
    DeRef(_1);

    /** execute.e:1710			sequence jump = val[Code[pc+3]]*/
    _33253 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33254 = (object)*(((s1_ptr)_2)->base + _33253);
    DeRef(_jump_67352);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33254)){
        _jump_67352 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33254)->dbl));
    }
    else{
        _jump_67352 = (object)*(((s1_ptr)_2)->base + _33254);
    }
    Ref(_jump_67352);

    /** execute.e:1711			sequence switch_table = repeat( Code[pc+4] - pc, max - min + 1 )*/
    _33256 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33257 = (object)*(((s1_ptr)_2)->base + _33256);
    if (IS_ATOM_INT(_33257)) {
        _33258 = _33257 - _67pc_65255;
        if ((object)((uintptr_t)_33258 +(uintptr_t) HIGH_BITS) >= 0){
            _33258 = NewDouble((eudouble)_33258);
        }
    }
    else {
        _33258 = binary_op(MINUS, _33257, _67pc_65255);
    }
    _33257 = NOVALUE;
    _33259 = _max_67311 - _min_67313;
    if ((object)((uintptr_t)_33259 +(uintptr_t) HIGH_BITS) >= 0){
        _33259 = NewDouble((eudouble)_33259);
    }
    if (IS_ATOM_INT(_33259)) {
        _33260 = _33259 + 1;
    }
    else
    _33260 = binary_op(PLUS, 1, _33259);
    DeRef(_33259);
    _33259 = NOVALUE;
    DeRef(_switch_table_67357);
    _switch_table_67357 = Repeat(_33258, _33260);
    DeRef(_33258);
    _33258 = NOVALUE;
    DeRef(_33260);
    _33260 = NOVALUE;

    /** execute.e:1712			integer offset = min - 1*/
    _offset_67365 = _min_67313 - 1;

    /** execute.e:1713			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_67305)){
            _33263 = SEQ_PTR(_values_67305)->length;
    }
    else {
        _33263 = 1;
    }
    {
        object _i_67368;
        _i_67368 = 1;
LB: 
        if (_i_67368 > _33263){
            goto LC; // [304] 336
        }

        /** execute.e:1714				switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_67305);
        _33264 = (object)*(((s1_ptr)_2)->base + _i_67368);
        if (IS_ATOM_INT(_33264)) {
            _33265 = _33264 - _offset_67365;
            if ((object)((uintptr_t)_33265 +(uintptr_t) HIGH_BITS) >= 0){
                _33265 = NewDouble((eudouble)_33265);
            }
        }
        else {
            _33265 = binary_op(MINUS, _33264, _offset_67365);
        }
        _33264 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_67352);
        _33266 = (object)*(((s1_ptr)_2)->base + _i_67368);
        Ref(_33266);
        _2 = (object)SEQ_PTR(_switch_table_67357);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_67357 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_33265))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33265)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _33265);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33266;
        if( _1 != _33266 ){
            DeRef(_1);
        }
        _33266 = NOVALUE;

        /** execute.e:1715			end for*/
        _i_67368 = _i_67368 + 1;
        goto LB; // [331] 311
LC: 
        ;
    }

    /** execute.e:1716			Code[pc+2] = offset*/
    _33267 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _33267);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_67365;
    DeRef(_1);

    /** execute.e:1718			val = append( val, switch_table )*/
    RefDS(_switch_table_67357);
    Append(&_67val_65265, _67val_65265, _switch_table_67357);

    /** execute.e:1719			Code[pc+3] = length(val)*/
    _33269 = _67pc_65255 + 3;
    if ((object)((uintptr_t)_33269 + (uintptr_t)HIGH_BITS) >= 0){
        _33269 = NewDouble((eudouble)_33269);
    }
    if (IS_SEQUENCE(_67val_65265)){
            _33270 = SEQ_PTR(_67val_65265)->length;
    }
    else {
        _33270 = 1;
    }
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33270;
    if( _1 != _33270 ){
        DeRef(_1);
    }
    _33270 = NOVALUE;

    /** execute.e:1721			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33271 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33271 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _33272 = (object)*(((s1_ptr)_2)->base + _33271);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33272))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33272)->dbl));
    else
    _3 = (object)(_33272 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _33273 = NOVALUE;

    /** execute.e:1722			opSWITCH_SPI()*/
    _67opSWITCH_SPI();
    DeRef(_jump_67352);
    _jump_67352 = NOVALUE;
    DeRefDS(_switch_table_67357);
    _switch_table_67357 = NOVALUE;
    goto LD; // [409] 482
LA: 

    /** execute.e:1724			Code[pc] = SWITCH*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67pc_65255);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 185;
    DeRef(_1);

    /** execute.e:1725			val = append( val, values )*/
    RefDS(_values_67305);
    Append(&_67val_65265, _67val_65265, _values_67305);

    /** execute.e:1726			Code[pc+2] = length(val)*/
    _33276 = _67pc_65255 + 2;
    if ((object)((uintptr_t)_33276 + (uintptr_t)HIGH_BITS) >= 0){
        _33276 = NewDouble((eudouble)_33276);
    }
    if (IS_SEQUENCE(_67val_65265)){
            _33277 = SEQ_PTR(_67val_65265)->length;
    }
    else {
        _33277 = 1;
    }
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33276))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33276)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33276);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33277;
    if( _1 != _33277 ){
        DeRef(_1);
    }
    _33277 = NOVALUE;

    /** execute.e:1728			SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _33278 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _33278 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _33279 = (object)*(((s1_ptr)_2)->base + _33278);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33279))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33279)->dbl));
    else
    _3 = (object)(_33279 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _33280 = NOVALUE;

    /** execute.e:1729			opSWITCH()*/
    _67opSWITCH();
LD: 

    /** execute.e:1732	end procedure*/
    DeRef(_values_67305);
    DeRef(_33256);
    _33256 = NOVALUE;
    DeRef(_33267);
    _33267 = NOVALUE;
    _33231 = NOVALUE;
    _33279 = NOVALUE;
    DeRef(_33269);
    _33269 = NOVALUE;
    DeRef(_33265);
    _33265 = NOVALUE;
    _33254 = NOVALUE;
    DeRef(_33253);
    _33253 = NOVALUE;
    _33272 = NOVALUE;
    DeRef(_33230);
    _33230 = NOVALUE;
    DeRef(_33276);
    _33276 = NOVALUE;
    return;
    ;
}


void _67opCASE()
{
    object _0, _1, _2;
    

    /** execute.e:1736	end procedure*/
    return;
    ;
}


void _67opNOPSWITCH()
{
    object _0, _1, _2;
    

    /** execute.e:1740	end procedure*/
    return;
    ;
}


object _67var_subs(object _x_67406, object _subs_67407)
{
    object _si_67408 = NOVALUE;
    object _33295 = NOVALUE;
    object _33294 = NOVALUE;
    object _33293 = NOVALUE;
    object _33292 = NOVALUE;
    object _33291 = NOVALUE;
    object _33289 = NOVALUE;
    object _33288 = NOVALUE;
    object _33285 = NOVALUE;
    object _33283 = NOVALUE;
    object _33282 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1746		if atom(x) then*/
    _33282 = IS_ATOM(_x_67406);
    if (_33282 == 0)
    {
        _33282 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33282 = NOVALUE;
    }

    /** execute.e:1747			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_33073);
    _67RTFatal(_33073);
L1: 

    /** execute.e:1749		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67407)){
            _33283 = SEQ_PTR(_subs_67407)->length;
    }
    else {
        _33283 = 1;
    }
    {
        object _i_67412;
        _i_67412 = 1;
L2: 
        if (_i_67412 > _33283){
            goto L3; // [22] 110
        }

        /** execute.e:1750			si = subs[i]*/
        DeRef(_si_67408);
        _2 = (object)SEQ_PTR(_subs_67407);
        _si_67408 = (object)*(((s1_ptr)_2)->base + _i_67412);
        Ref(_si_67408);

        /** execute.e:1751			if sequence(si) then*/
        _33285 = IS_SEQUENCE(_si_67408);
        if (_33285 == 0)
        {
            _33285 = NOVALUE;
            goto L4; // [40] 49
        }
        else{
            _33285 = NOVALUE;
        }

        /** execute.e:1752				RTFatal("A subscript must be an atom")*/
        RefDS(_33286);
        _67RTFatal(_33286);
L4: 

        /** execute.e:1754			si = floor(si)*/
        _0 = _si_67408;
        if (IS_ATOM_INT(_si_67408))
        _si_67408 = e_floor(_si_67408);
        else
        _si_67408 = unary_op(FLOOR, _si_67408);
        DeRef(_0);

        /** execute.e:1755			if si > length(x) or si < 1 then*/
        if (IS_SEQUENCE(_x_67406)){
                _33288 = SEQ_PTR(_x_67406)->length;
        }
        else {
            _33288 = 1;
        }
        if (IS_ATOM_INT(_si_67408)) {
            _33289 = (_si_67408 > _33288);
        }
        else {
            _33289 = binary_op(GREATER, _si_67408, _33288);
        }
        _33288 = NOVALUE;
        if (IS_ATOM_INT(_33289)) {
            if (_33289 != 0) {
                goto L5; // [63] 76
            }
        }
        else {
            if (DBL_PTR(_33289)->dbl != 0.0) {
                goto L5; // [63] 76
            }
        }
        if (IS_ATOM_INT(_si_67408)) {
            _33291 = (_si_67408 < 1);
        }
        else {
            _33291 = binary_op(LESS, _si_67408, 1);
        }
        if (_33291 == 0) {
            DeRef(_33291);
            _33291 = NOVALUE;
            goto L6; // [72] 93
        }
        else {
            if (!IS_ATOM_INT(_33291) && DBL_PTR(_33291)->dbl == 0.0){
                DeRef(_33291);
                _33291 = NOVALUE;
                goto L6; // [72] 93
            }
            DeRef(_33291);
            _33291 = NOVALUE;
        }
        DeRef(_33291);
        _33291 = NOVALUE;
L5: 

        /** execute.e:1756				RTFatal(*/
        if (IS_SEQUENCE(_x_67406)){
                _33292 = SEQ_PTR(_x_67406)->length;
        }
        else {
            _33292 = 1;
        }
        Ref(_si_67408);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _si_67408;
        ((intptr_t *)_2)[2] = _33292;
        _33293 = MAKE_SEQ(_1);
        _33292 = NOVALUE;
        _33294 = EPrintf(-9999999, _33081, _33293);
        DeRefDS(_33293);
        _33293 = NOVALUE;
        _67RTFatal(_33294);
        _33294 = NOVALUE;
L6: 

        /** execute.e:1760			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67407);
        _33295 = (object)*(((s1_ptr)_2)->base + _i_67412);
        _0 = _x_67406;
        _2 = (object)SEQ_PTR(_x_67406);
        if (!IS_ATOM_INT(_33295)){
            _x_67406 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33295)->dbl));
        }
        else{
            _x_67406 = (object)*(((s1_ptr)_2)->base + _33295);
        }
        Ref(_x_67406);
        DeRef(_0);

        /** execute.e:1761		end for*/
        _i_67412 = _i_67412 + 1;
        goto L2; // [105] 29
L3: 
        ;
    }

    /** execute.e:1762		return x*/
    DeRefDS(_subs_67407);
    DeRef(_si_67408);
    _33295 = NOVALUE;
    DeRef(_33289);
    _33289 = NOVALUE;
    return _x_67406;
    ;
}


void _67opLENGTH()
{
    object _33302 = NOVALUE;
    object _33301 = NOVALUE;
    object _33299 = NOVALUE;
    object _33297 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1767		a = Code[pc+1]*/
    _33297 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33297);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1768		target = Code[pc+2]*/
    _33299 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33299);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1769		val[target] = length(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33301 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_33301)){
            _33302 = SEQ_PTR(_33301)->length;
    }
    else {
        _33302 = 1;
    }
    _33301 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33302;
    if( _1 != _33302 ){
        DeRef(_1);
    }
    _33302 = NOVALUE;

    /** execute.e:1770		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:1771	end procedure*/
    _33299 = NOVALUE;
    _33297 = NOVALUE;
    _33301 = NOVALUE;
    return;
    ;
}


void _67opPLENGTH()
{
    object _33315 = NOVALUE;
    object _33314 = NOVALUE;
    object _33313 = NOVALUE;
    object _33311 = NOVALUE;
    object _33310 = NOVALUE;
    object _33308 = NOVALUE;
    object _33306 = NOVALUE;
    object _33304 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1780		a = Code[pc+1]*/
    _33304 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33304);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1781		target = Code[pc+2]*/
    _33306 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33306);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1782		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33308 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_33308);
    _67lhs_seq_index_65263 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_65263)){
        _67lhs_seq_index_65263 = (object)DBL_PTR(_67lhs_seq_index_65263)->dbl;
    }
    _33308 = NOVALUE;

    /** execute.e:1783		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33310 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_33310)){
            _33311 = SEQ_PTR(_33310)->length;
    }
    else {
        _33311 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65264;
    RHS_Slice(_33310, 2, _33311);
    _33310 = NOVALUE;

    /** execute.e:1784		val[target] = length(var_subs(val[lhs_seq_index], lhs_subs))*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33313 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    Ref(_33313);
    RefDS(_67lhs_subs_65264);
    _33314 = _67var_subs(_33313, _67lhs_subs_65264);
    _33313 = NOVALUE;
    if (IS_SEQUENCE(_33314)){
            _33315 = SEQ_PTR(_33314)->length;
    }
    else {
        _33315 = 1;
    }
    DeRef(_33314);
    _33314 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33315;
    if( _1 != _33315 ){
        DeRef(_1);
    }
    _33315 = NOVALUE;

    /** execute.e:1785		lhs_subs = {}*/
    RefDS(_22209);
    DeRefDS(_67lhs_subs_65264);
    _67lhs_subs_65264 = _22209;

    /** execute.e:1786		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:1787	end procedure*/
    _33314 = NOVALUE;
    _33306 = NOVALUE;
    _33304 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS()
{
    object _33325 = NOVALUE;
    object _33324 = NOVALUE;
    object _33323 = NOVALUE;
    object _33321 = NOVALUE;
    object _33319 = NOVALUE;
    object _33317 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1792		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33317 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33317);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1794		b = Code[pc+2] -- subscript*/
    _33319 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33319);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1795		target = Code[pc+3] -- temp for storing result*/
    _33321 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33321);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1798		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33323 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33324 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_33324);
    Append(&_33325, _33323, _33324);
    _33323 = NOVALUE;
    _33324 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33325;
    if( _1 != _33325 ){
        DeRef(_1);
    }
    _33325 = NOVALUE;

    /** execute.e:1799		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:1800	end procedure*/
    _33319 = NOVALUE;
    _33321 = NOVALUE;
    _33317 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1()
{
    object _33334 = NOVALUE;
    object _33333 = NOVALUE;
    object _33331 = NOVALUE;
    object _33329 = NOVALUE;
    object _33327 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1804		a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _33327 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33327);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1806		b = Code[pc+2] -- subscript*/
    _33329 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33329);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1807		target = Code[pc+3] -- temp for storing result*/
    _33331 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33331);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1810		val[target] = {a, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33333 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_33333);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67a_65256;
    ((intptr_t *)_2)[2] = _33333;
    _33334 = MAKE_SEQ(_1);
    _33333 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33334;
    if( _1 != _33334 ){
        DeRef(_1);
    }
    _33334 = NOVALUE;

    /** execute.e:1811		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:1812	end procedure*/
    _33329 = NOVALUE;
    _33327 = NOVALUE;
    _33331 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1_COPY()
{
    object _33346 = NOVALUE;
    object _33345 = NOVALUE;
    object _33344 = NOVALUE;
    object _33342 = NOVALUE;
    object _33340 = NOVALUE;
    object _33338 = NOVALUE;
    object _33336 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1819		a = Code[pc+1] -- base var sequence*/
    _33336 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33336);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1821		b = Code[pc+2] -- subscript*/
    _33338 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33338);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1823		target = Code[pc+3] -- temp for storing result*/
    _33340 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33340);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:1825		c = Code[pc+4] -- temp to hold base sequence while it's manipulated*/
    _33342 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33342);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:1827		val[c] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33344 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_33344);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67c_65258);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33344;
    if( _1 != _33344 ){
        DeRef(_1);
    }
    _33344 = NOVALUE;

    /** execute.e:1830		val[target] = {c, val[b]}*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33345 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_33345);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _67c_65258;
    ((intptr_t *)_2)[2] = _33345;
    _33346 = MAKE_SEQ(_1);
    _33345 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33346;
    if( _1 != _33346 ){
        DeRef(_1);
    }
    _33346 = NOVALUE;

    /** execute.e:1832		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:1833	end procedure*/
    _33338 = NOVALUE;
    _33336 = NOVALUE;
    _33342 = NOVALUE;
    _33340 = NOVALUE;
    return;
    ;
}


void _67lhs_check_subs(object _seq_67506, object _subs_67507)
{
    object _33362 = NOVALUE;
    object _33361 = NOVALUE;
    object _33360 = NOVALUE;
    object _33358 = NOVALUE;
    object _33357 = NOVALUE;
    object _33355 = NOVALUE;
    object _33353 = NOVALUE;
    object _33352 = NOVALUE;
    object _33350 = NOVALUE;
    object _33348 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1837		if atom(seq) then*/
    _33348 = IS_ATOM(_seq_67506);
    if (_33348 == 0)
    {
        _33348 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33348 = NOVALUE;
    }

    /** execute.e:1838			RTFatal("attempt to subscript an atom\n(assigning to it)")*/
    RefDS(_33349);
    _67RTFatal(_33349);
L1: 

    /** execute.e:1840		if sequence(subs) then*/
    _33350 = IS_SEQUENCE(_subs_67507);
    if (_33350 == 0)
    {
        _33350 = NOVALUE;
        goto L2; // [20] 36
    }
    else{
        _33350 = NOVALUE;
    }

    /** execute.e:1841			RTFatal(*/
    if (IS_SEQUENCE(_seq_67506)){
            _33352 = SEQ_PTR(_seq_67506)->length;
    }
    else {
        _33352 = 1;
    }
    _33353 = EPrintf(-9999999, _33351, _33352);
    _33352 = NOVALUE;
    _67RTFatal(_33353);
    _33353 = NOVALUE;
L2: 

    /** execute.e:1846		subs = floor(subs)*/
    _0 = _subs_67507;
    if (IS_ATOM_INT(_subs_67507))
    _subs_67507 = e_floor(_subs_67507);
    else
    _subs_67507 = unary_op(FLOOR, _subs_67507);
    DeRef(_0);

    /** execute.e:1847		if subs < 1 or subs > length(seq) then*/
    if (IS_ATOM_INT(_subs_67507)) {
        _33355 = (_subs_67507 < 1);
    }
    else {
        _33355 = binary_op(LESS, _subs_67507, 1);
    }
    if (IS_ATOM_INT(_33355)) {
        if (_33355 != 0) {
            goto L3; // [47] 63
        }
    }
    else {
        if (DBL_PTR(_33355)->dbl != 0.0) {
            goto L3; // [47] 63
        }
    }
    if (IS_SEQUENCE(_seq_67506)){
            _33357 = SEQ_PTR(_seq_67506)->length;
    }
    else {
        _33357 = 1;
    }
    if (IS_ATOM_INT(_subs_67507)) {
        _33358 = (_subs_67507 > _33357);
    }
    else {
        _33358 = binary_op(GREATER, _subs_67507, _33357);
    }
    _33357 = NOVALUE;
    if (_33358 == 0) {
        DeRef(_33358);
        _33358 = NOVALUE;
        goto L4; // [59] 80
    }
    else {
        if (!IS_ATOM_INT(_33358) && DBL_PTR(_33358)->dbl == 0.0){
            DeRef(_33358);
            _33358 = NOVALUE;
            goto L4; // [59] 80
        }
        DeRef(_33358);
        _33358 = NOVALUE;
    }
    DeRef(_33358);
    _33358 = NOVALUE;
L3: 

    /** execute.e:1848			RTFatal(*/
    if (IS_SEQUENCE(_seq_67506)){
            _33360 = SEQ_PTR(_seq_67506)->length;
    }
    else {
        _33360 = 1;
    }
    Ref(_subs_67507);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _subs_67507;
    ((intptr_t *)_2)[2] = _33360;
    _33361 = MAKE_SEQ(_1);
    _33360 = NOVALUE;
    _33362 = EPrintf(-9999999, _33359, _33361);
    DeRefDS(_33361);
    _33361 = NOVALUE;
    _67RTFatal(_33362);
    _33362 = NOVALUE;
L4: 

    /** execute.e:1853	end procedure*/
    DeRef(_seq_67506);
    DeRef(_subs_67507);
    DeRef(_33355);
    _33355 = NOVALUE;
    return;
    ;
}


void _67check_slice(object _seq_67528, object _lower_67529, object _upper_67530)
{
    object _len_67531 = NOVALUE;
    object _33393 = NOVALUE;
    object _33391 = NOVALUE;
    object _33390 = NOVALUE;
    object _33389 = NOVALUE;
    object _33388 = NOVALUE;
    object _33386 = NOVALUE;
    object _33385 = NOVALUE;
    object _33384 = NOVALUE;
    object _33380 = NOVALUE;
    object _33378 = NOVALUE;
    object _33377 = NOVALUE;
    object _33368 = NOVALUE;
    object _33363 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1859		if sequence(lower) then*/
    _33363 = IS_SEQUENCE(_lower_67529);
    if (_33363 == 0)
    {
        _33363 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _33363 = NOVALUE;
    }

    /** execute.e:1860			RTFatal("slice lower index is not an atom")*/
    RefDS(_33364);
    _67RTFatal(_33364);
L1: 

    /** execute.e:1862		lower = floor(lower)*/
    _0 = _lower_67529;
    if (IS_ATOM_INT(_lower_67529))
    _lower_67529 = e_floor(_lower_67529);
    else
    _lower_67529 = unary_op(FLOOR, _lower_67529);
    DeRef(_0);

    /** execute.e:1863		if lower < 1 then*/
    if (binary_op_a(GREATEREQ, _lower_67529, 1)){
        goto L2; // [22] 32
    }

    /** execute.e:1864			RTFatal("slice lower index is less than 1")*/
    RefDS(_33367);
    _67RTFatal(_33367);
L2: 

    /** execute.e:1867		if sequence(upper) then*/
    _33368 = IS_SEQUENCE(_upper_67530);
    if (_33368 == 0)
    {
        _33368 = NOVALUE;
        goto L3; // [37] 46
    }
    else{
        _33368 = NOVALUE;
    }

    /** execute.e:1868			RTFatal("slice upper index is not an atom")*/
    RefDS(_33369);
    _67RTFatal(_33369);
L3: 

    /** execute.e:1870		upper = floor(upper)*/
    _0 = _upper_67530;
    if (IS_ATOM_INT(_upper_67530))
    _upper_67530 = e_floor(_upper_67530);
    else
    _upper_67530 = unary_op(FLOOR, _upper_67530);
    DeRef(_0);

    /** execute.e:1871		if upper > #FFFF_FFFF then*/
    if (binary_op_a(LESSEQ, _upper_67530, _33371)){
        goto L4; // [53] 63
    }

    /** execute.e:1872			upper = -2147483645*/
    RefDS(_33374);
    DeRef(_upper_67530);
    _upper_67530 = _33374;
L4: 

    /** execute.e:1874		if upper < 0 then*/
    if (binary_op_a(GREATEREQ, _upper_67530, 0)){
        goto L5; // [65] 79
    }

    /** execute.e:1875			RTFatal(sprintf("slice upper index is less than 0 (%d)", upper ) )*/
    _33377 = EPrintf(-9999999, _33376, _upper_67530);
    _67RTFatal(_33377);
    _33377 = NOVALUE;
L5: 

    /** execute.e:1878		if atom(seq) then*/
    _33378 = IS_ATOM(_seq_67528);
    if (_33378 == 0)
    {
        _33378 = NOVALUE;
        goto L6; // [84] 93
    }
    else{
        _33378 = NOVALUE;
    }

    /** execute.e:1879			RTFatal("attempt to slice an atom")*/
    RefDS(_33379);
    _67RTFatal(_33379);
L6: 

    /** execute.e:1882		len = upper - lower + 1*/
    if (IS_ATOM_INT(_upper_67530) && IS_ATOM_INT(_lower_67529)) {
        _33380 = _upper_67530 - _lower_67529;
        if ((object)((uintptr_t)_33380 +(uintptr_t) HIGH_BITS) >= 0){
            _33380 = NewDouble((eudouble)_33380);
        }
    }
    else {
        _33380 = binary_op(MINUS, _upper_67530, _lower_67529);
    }
    DeRef(_len_67531);
    if (IS_ATOM_INT(_33380)) {
        _len_67531 = _33380 + 1;
        if (_len_67531 > MAXINT){
            _len_67531 = NewDouble((eudouble)_len_67531);
        }
    }
    else
    _len_67531 = binary_op(PLUS, 1, _33380);
    DeRef(_33380);
    _33380 = NOVALUE;

    /** execute.e:1884		if len < 0 then*/
    if (binary_op_a(GREATEREQ, _len_67531, 0)){
        goto L7; // [105] 115
    }

    /** execute.e:1885			RTFatal("slice length is less than 0")*/
    RefDS(_33383);
    _67RTFatal(_33383);
L7: 

    /** execute.e:1888		if lower > length(seq) + 1 or (len > 0 and lower > length(seq)) then*/
    if (IS_SEQUENCE(_seq_67528)){
            _33384 = SEQ_PTR(_seq_67528)->length;
    }
    else {
        _33384 = 1;
    }
    _33385 = _33384 + 1;
    _33384 = NOVALUE;
    if (IS_ATOM_INT(_lower_67529)) {
        _33386 = (_lower_67529 > _33385);
    }
    else {
        _33386 = binary_op(GREATER, _lower_67529, _33385);
    }
    _33385 = NOVALUE;
    if (IS_ATOM_INT(_33386)) {
        if (_33386 != 0) {
            goto L8; // [128] 156
        }
    }
    else {
        if (DBL_PTR(_33386)->dbl != 0.0) {
            goto L8; // [128] 156
        }
    }
    if (IS_ATOM_INT(_len_67531)) {
        _33388 = (_len_67531 > 0);
    }
    else {
        _33388 = (DBL_PTR(_len_67531)->dbl > (eudouble)0);
    }
    if (_33388 == 0) {
        DeRef(_33389);
        _33389 = 0;
        goto L9; // [136] 151
    }
    if (IS_SEQUENCE(_seq_67528)){
            _33390 = SEQ_PTR(_seq_67528)->length;
    }
    else {
        _33390 = 1;
    }
    if (IS_ATOM_INT(_lower_67529)) {
        _33391 = (_lower_67529 > _33390);
    }
    else {
        _33391 = binary_op(GREATER, _lower_67529, _33390);
    }
    _33390 = NOVALUE;
    if (IS_ATOM_INT(_33391))
    _33389 = (_33391 != 0);
    else
    _33389 = DBL_PTR(_33391)->dbl != 0.0;
L9: 
    if (_33389 == 0)
    {
        _33389 = NOVALUE;
        goto LA; // [152] 162
    }
    else{
        _33389 = NOVALUE;
    }
L8: 

    /** execute.e:1889			RTFatal("slice starts past end of sequence")*/
    RefDS(_33392);
    _67RTFatal(_33392);
LA: 

    /** execute.e:1892		if upper > length(seq) then*/
    if (IS_SEQUENCE(_seq_67528)){
            _33393 = SEQ_PTR(_seq_67528)->length;
    }
    else {
        _33393 = 1;
    }
    if (binary_op_a(LESSEQ, _upper_67530, _33393)){
        _33393 = NOVALUE;
        goto LB; // [167] 177
    }
    _33393 = NOVALUE;

    /** execute.e:1893			RTFatal("slice ends past end of sequence")*/
    RefDS(_33395);
    _67RTFatal(_33395);
LB: 

    /** execute.e:1895	end procedure*/
    DeRef(_seq_67528);
    DeRef(_lower_67529);
    DeRef(_upper_67530);
    DeRef(_len_67531);
    DeRef(_33388);
    _33388 = NOVALUE;
    DeRef(_33391);
    _33391 = NOVALUE;
    DeRef(_33386);
    _33386 = NOVALUE;
    return;
    ;
}


void _67lhs_check_slice(object _seq_67576, object _lower_67577, object _upper_67578, object _rhs_67579)
{
    object _len_67580 = NOVALUE;
    object _33403 = NOVALUE;
    object _33402 = NOVALUE;
    object _33401 = NOVALUE;
    object _33400 = NOVALUE;
    object _33398 = NOVALUE;
    object _33397 = NOVALUE;
    object _33396 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1901		check_slice(seq, lower, upper)*/
    Ref(_seq_67576);
    Ref(_lower_67577);
    Ref(_upper_67578);
    _67check_slice(_seq_67576, _lower_67577, _upper_67578);

    /** execute.e:1903		len = floor(upper) - floor(lower) + 1*/
    if (IS_ATOM_INT(_upper_67578))
    _33396 = e_floor(_upper_67578);
    else
    _33396 = unary_op(FLOOR, _upper_67578);
    if (IS_ATOM_INT(_lower_67577))
    _33397 = e_floor(_lower_67577);
    else
    _33397 = unary_op(FLOOR, _lower_67577);
    if (IS_ATOM_INT(_33396) && IS_ATOM_INT(_33397)) {
        _33398 = _33396 - _33397;
        if ((object)((uintptr_t)_33398 +(uintptr_t) HIGH_BITS) >= 0){
            _33398 = NewDouble((eudouble)_33398);
        }
    }
    else {
        _33398 = binary_op(MINUS, _33396, _33397);
    }
    DeRef(_33396);
    _33396 = NOVALUE;
    DeRef(_33397);
    _33397 = NOVALUE;
    DeRef(_len_67580);
    if (IS_ATOM_INT(_33398)) {
        _len_67580 = _33398 + 1;
        if (_len_67580 > MAXINT){
            _len_67580 = NewDouble((eudouble)_len_67580);
        }
    }
    else
    _len_67580 = binary_op(PLUS, 1, _33398);
    DeRef(_33398);
    _33398 = NOVALUE;

    /** execute.e:1905		if sequence(rhs) and length(rhs) != len then*/
    _33400 = IS_SEQUENCE(_rhs_67579);
    if (_33400 == 0) {
        goto L1; // [29] 50
    }
    if (IS_SEQUENCE(_rhs_67579)){
            _33402 = SEQ_PTR(_rhs_67579)->length;
    }
    else {
        _33402 = 1;
    }
    if (IS_ATOM_INT(_len_67580)) {
        _33403 = (_33402 != _len_67580);
    }
    else {
        _33403 = ((eudouble)_33402 != DBL_PTR(_len_67580)->dbl);
    }
    _33402 = NOVALUE;
    if (_33403 == 0)
    {
        DeRef(_33403);
        _33403 = NOVALUE;
        goto L1; // [41] 50
    }
    else{
        DeRef(_33403);
        _33403 = NOVALUE;
    }

    /** execute.e:1906			RTFatal("lengths do not match on assignment to slice")*/
    RefDS(_33404);
    _67RTFatal(_33404);
L1: 

    /** execute.e:1908	end procedure*/
    DeRef(_seq_67576);
    DeRef(_lower_67577);
    DeRef(_upper_67578);
    DeRef(_rhs_67579);
    DeRef(_len_67580);
    return;
    ;
}


object _67var_slice(object _x_67593, object _subs_67594, object _lower_67595, object _upper_67596)
{
    object _33423 = NOVALUE;
    object _33421 = NOVALUE;
    object _33420 = NOVALUE;
    object _33419 = NOVALUE;
    object _33418 = NOVALUE;
    object _33417 = NOVALUE;
    object _33416 = NOVALUE;
    object _33415 = NOVALUE;
    object _33413 = NOVALUE;
    object _33412 = NOVALUE;
    object _33411 = NOVALUE;
    object _33408 = NOVALUE;
    object _33407 = NOVALUE;
    object _33406 = NOVALUE;
    object _33405 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1912		if atom(x) then*/
    _33405 = IS_ATOM(_x_67593);
    if (_33405 == 0)
    {
        _33405 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _33405 = NOVALUE;
    }

    /** execute.e:1913			RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_33073);
    _67RTFatal(_33073);
L1: 

    /** execute.e:1915		for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_67594)){
            _33406 = SEQ_PTR(_subs_67594)->length;
    }
    else {
        _33406 = 1;
    }
    {
        object _i_67600;
        _i_67600 = 1;
L2: 
        if (_i_67600 > _33406){
            goto L3; // [22] 122
        }

        /** execute.e:1916			if sequence(subs[i]) then*/
        _2 = (object)SEQ_PTR(_subs_67594);
        _33407 = (object)*(((s1_ptr)_2)->base + _i_67600);
        _33408 = IS_SEQUENCE(_33407);
        _33407 = NOVALUE;
        if (_33408 == 0)
        {
            _33408 = NOVALUE;
            goto L4; // [38] 47
        }
        else{
            _33408 = NOVALUE;
        }

        /** execute.e:1917				RTFatal("subscript must be an atom")*/
        RefDS(_33409);
        _67RTFatal(_33409);
L4: 

        /** execute.e:1919			subs = floor(subs)*/
        _0 = _subs_67594;
        _subs_67594 = unary_op(FLOOR, _subs_67594);
        DeRefDS(_0);

        /** execute.e:1920			if subs[i] > length(x) or subs[i] < 1 then*/
        _2 = (object)SEQ_PTR(_subs_67594);
        _33411 = (object)*(((s1_ptr)_2)->base + _i_67600);
        if (IS_SEQUENCE(_x_67593)){
                _33412 = SEQ_PTR(_x_67593)->length;
        }
        else {
            _33412 = 1;
        }
        if (IS_ATOM_INT(_33411)) {
            _33413 = (_33411 > _33412);
        }
        else {
            _33413 = binary_op(GREATER, _33411, _33412);
        }
        _33411 = NOVALUE;
        _33412 = NOVALUE;
        if (IS_ATOM_INT(_33413)) {
            if (_33413 != 0) {
                goto L5; // [67] 84
            }
        }
        else {
            if (DBL_PTR(_33413)->dbl != 0.0) {
                goto L5; // [67] 84
            }
        }
        _2 = (object)SEQ_PTR(_subs_67594);
        _33415 = (object)*(((s1_ptr)_2)->base + _i_67600);
        if (IS_ATOM_INT(_33415)) {
            _33416 = (_33415 < 1);
        }
        else {
            _33416 = binary_op(LESS, _33415, 1);
        }
        _33415 = NOVALUE;
        if (_33416 == 0) {
            DeRef(_33416);
            _33416 = NOVALUE;
            goto L6; // [80] 105
        }
        else {
            if (!IS_ATOM_INT(_33416) && DBL_PTR(_33416)->dbl == 0.0){
                DeRef(_33416);
                _33416 = NOVALUE;
                goto L6; // [80] 105
            }
            DeRef(_33416);
            _33416 = NOVALUE;
        }
        DeRef(_33416);
        _33416 = NOVALUE;
L5: 

        /** execute.e:1921				RTFatal(*/
        _2 = (object)SEQ_PTR(_subs_67594);
        _33417 = (object)*(((s1_ptr)_2)->base + _i_67600);
        if (IS_SEQUENCE(_x_67593)){
                _33418 = SEQ_PTR(_x_67593)->length;
        }
        else {
            _33418 = 1;
        }
        Ref(_33417);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _33417;
        ((intptr_t *)_2)[2] = _33418;
        _33419 = MAKE_SEQ(_1);
        _33418 = NOVALUE;
        _33417 = NOVALUE;
        _33420 = EPrintf(-9999999, _33081, _33419);
        DeRefDS(_33419);
        _33419 = NOVALUE;
        _67RTFatal(_33420);
        _33420 = NOVALUE;
L6: 

        /** execute.e:1925			x = x[subs[i]]*/
        _2 = (object)SEQ_PTR(_subs_67594);
        _33421 = (object)*(((s1_ptr)_2)->base + _i_67600);
        _0 = _x_67593;
        _2 = (object)SEQ_PTR(_x_67593);
        if (!IS_ATOM_INT(_33421)){
            _x_67593 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33421)->dbl));
        }
        else{
            _x_67593 = (object)*(((s1_ptr)_2)->base + _33421);
        }
        Ref(_x_67593);
        DeRef(_0);

        /** execute.e:1926		end for*/
        _i_67600 = _i_67600 + 1;
        goto L2; // [117] 29
L3: 
        ;
    }

    /** execute.e:1927		check_slice(x, lower, upper)*/
    Ref(_x_67593);
    Ref(_lower_67595);
    Ref(_upper_67596);
    _67check_slice(_x_67593, _lower_67595, _upper_67596);

    /** execute.e:1928		return x[lower..upper]*/
    rhs_slice_target = (object_ptr)&_33423;
    RHS_Slice(_x_67593, _lower_67595, _upper_67596);
    DeRef(_x_67593);
    DeRefDS(_subs_67594);
    DeRef(_lower_67595);
    DeRef(_upper_67596);
    DeRef(_33413);
    _33413 = NOVALUE;
    _33421 = NOVALUE;
    return _33423;
    ;
}


object _67assign_subs(object _x_67623, object _subs_67624, object _rhs_val_67625)
{
    object _33434 = NOVALUE;
    object _33433 = NOVALUE;
    object _33432 = NOVALUE;
    object _33431 = NOVALUE;
    object _33430 = NOVALUE;
    object _33429 = NOVALUE;
    object _33428 = NOVALUE;
    object _33427 = NOVALUE;
    object _33425 = NOVALUE;
    object _33424 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1933		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67624);
    _33424 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_67623);
    Ref(_33424);
    _67lhs_check_subs(_x_67623, _33424);
    _33424 = NOVALUE;

    /** execute.e:1934		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67624)){
            _33425 = SEQ_PTR(_subs_67624)->length;
    }
    else {
        _33425 = 1;
    }
    if (_33425 != 1)
    goto L1; // [20] 37

    /** execute.e:1935			x[subs[1]] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67624);
    _33427 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_rhs_val_67625);
    _2 = (object)SEQ_PTR(_x_67623);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67623 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33427))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33427)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33427);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rhs_val_67625;
    DeRef(_1);
    goto L2; // [34] 73
L1: 

    /** execute.e:1937			x[subs[1]] = assign_subs(x[subs[1]], subs[2..$], rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67624);
    _33428 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_subs_67624);
    _33429 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67623);
    if (!IS_ATOM_INT(_33429)){
        _33430 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33429)->dbl));
    }
    else{
        _33430 = (object)*(((s1_ptr)_2)->base + _33429);
    }
    if (IS_SEQUENCE(_subs_67624)){
            _33431 = SEQ_PTR(_subs_67624)->length;
    }
    else {
        _33431 = 1;
    }
    rhs_slice_target = (object_ptr)&_33432;
    RHS_Slice(_subs_67624, 2, _33431);
    Ref(_rhs_val_67625);
    DeRef(_33433);
    _33433 = _rhs_val_67625;
    Ref(_33430);
    _33434 = _67assign_subs(_33430, _33432, _33433);
    _33430 = NOVALUE;
    _33432 = NOVALUE;
    _33433 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67623);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67623 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33428))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33428)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33428);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33434;
    if( _1 != _33434 ){
        DeRef(_1);
    }
    _33434 = NOVALUE;
L2: 

    /** execute.e:1939		return x*/
    DeRefDS(_subs_67624);
    DeRef(_rhs_val_67625);
    _33429 = NOVALUE;
    _33427 = NOVALUE;
    _33428 = NOVALUE;
    return _x_67623;
    ;
}


object _67assign_slice(object _x_67641, object _subs_67642, object _lower_67643, object _upper_67644, object _rhs_val_67645)
{
    object _33451 = NOVALUE;
    object _33450 = NOVALUE;
    object _33449 = NOVALUE;
    object _33448 = NOVALUE;
    object _33447 = NOVALUE;
    object _33446 = NOVALUE;
    object _33445 = NOVALUE;
    object _33444 = NOVALUE;
    object _33443 = NOVALUE;
    object _33441 = NOVALUE;
    object _33440 = NOVALUE;
    object _33439 = NOVALUE;
    object _33438 = NOVALUE;
    object _33436 = NOVALUE;
    object _33435 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1946		lhs_check_subs(x, subs[1])*/
    _2 = (object)SEQ_PTR(_subs_67642);
    _33435 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_67641);
    Ref(_33435);
    _67lhs_check_subs(_x_67641, _33435);
    _33435 = NOVALUE;

    /** execute.e:1947		if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_67642)){
            _33436 = SEQ_PTR(_subs_67642)->length;
    }
    else {
        _33436 = 1;
    }
    if (_33436 != 1)
    goto L1; // [20] 59

    /** execute.e:1948			lhs_check_slice(x[subs[1]],lower,upper,rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67642);
    _33438 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67641);
    if (!IS_ATOM_INT(_33438)){
        _33439 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33438)->dbl));
    }
    else{
        _33439 = (object)*(((s1_ptr)_2)->base + _33438);
    }
    Ref(_33439);
    Ref(_lower_67643);
    Ref(_upper_67644);
    Ref(_rhs_val_67645);
    _67lhs_check_slice(_33439, _lower_67643, _upper_67644, _rhs_val_67645);
    _33439 = NOVALUE;

    /** execute.e:1949			x[subs[1]][lower..upper] = rhs_val*/
    _2 = (object)SEQ_PTR(_subs_67642);
    _33440 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67641);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67641 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33440))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33440)->dbl));
    else
    _3 = (object)(_33440 + ((s1_ptr)_2)->base);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_lower_67643, _upper_67644, _rhs_val_67645);
    goto L2; // [56] 103
L1: 

    /** execute.e:1951			x[subs[1]] = assign_slice(x[subs[1]], subs[2..$], lower, upper, rhs_val)*/
    _2 = (object)SEQ_PTR(_subs_67642);
    _33443 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_subs_67642);
    _33444 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_x_67641);
    if (!IS_ATOM_INT(_33444)){
        _33445 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33444)->dbl));
    }
    else{
        _33445 = (object)*(((s1_ptr)_2)->base + _33444);
    }
    if (IS_SEQUENCE(_subs_67642)){
            _33446 = SEQ_PTR(_subs_67642)->length;
    }
    else {
        _33446 = 1;
    }
    rhs_slice_target = (object_ptr)&_33447;
    RHS_Slice(_subs_67642, 2, _33446);
    Ref(_lower_67643);
    DeRef(_33448);
    _33448 = _lower_67643;
    Ref(_upper_67644);
    DeRef(_33449);
    _33449 = _upper_67644;
    Ref(_rhs_val_67645);
    DeRef(_33450);
    _33450 = _rhs_val_67645;
    Ref(_33445);
    _33451 = _67assign_slice(_33445, _33447, _33448, _33449, _33450);
    _33445 = NOVALUE;
    _33447 = NOVALUE;
    _33448 = NOVALUE;
    _33449 = NOVALUE;
    _33450 = NOVALUE;
    _2 = (object)SEQ_PTR(_x_67641);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _x_67641 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33443))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33443)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33443);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33451;
    if( _1 != _33451 ){
        DeRef(_1);
    }
    _33451 = NOVALUE;
L2: 

    /** execute.e:1953		return x*/
    DeRefDS(_subs_67642);
    DeRef(_lower_67643);
    DeRef(_upper_67644);
    DeRef(_rhs_val_67645);
    _33444 = NOVALUE;
    _33440 = NOVALUE;
    DeRef(_33441);
    _33441 = NOVALUE;
    _33438 = NOVALUE;
    _33443 = NOVALUE;
    return _x_67641;
    ;
}


void _67opASSIGN_SUBS()
{
    object _x_67667 = NOVALUE;
    object _subs_67668 = NOVALUE;
    object _33465 = NOVALUE;
    object _33462 = NOVALUE;
    object _33459 = NOVALUE;
    object _33457 = NOVALUE;
    object _33456 = NOVALUE;
    object _33454 = NOVALUE;
    object _33452 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:1960		a = Code[pc+1]  -- the sequence*/
    _33452 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33452);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1961		b = Code[pc+2]  -- the subscript*/
    _33454 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33454);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1962		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33456 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _33457 = IS_SEQUENCE(_33456);
    _33456 = NOVALUE;
    if (_33457 == 0)
    {
        _33457 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33457 = NOVALUE;
    }

    /** execute.e:1963			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33458);
    _67RTFatal(_33458);
L1: 

    /** execute.e:1966		c = Code[pc+3]  -- the RHS value*/
    _33459 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33459);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:1967		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67667);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67667 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67667);

    /** execute.e:1968		lhs_check_subs(x, val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33462 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_x_67667);
    Ref(_33462);
    _67lhs_check_subs(_x_67667, _33462);
    _33462 = NOVALUE;

    /** execute.e:1969		x = val[c]*/
    DeRef(_x_67667);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67667 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    Ref(_x_67667);

    /** execute.e:1970		subs = val[b]*/
    DeRef(_subs_67668);
    _2 = (object)SEQ_PTR(_67val_65265);
    _subs_67668 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_subs_67668);

    /** execute.e:1971		val[a][subs] = x  -- single LHS subscript*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_65256 + ((s1_ptr)_2)->base);
    Ref(_x_67667);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_subs_67668))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_subs_67668)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _subs_67668);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_67667;
    DeRef(_1);
    _33465 = NOVALUE;

    /** execute.e:1972		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:1973	end procedure*/
    DeRef(_x_67667);
    DeRef(_subs_67668);
    _33459 = NOVALUE;
    DeRef(_33452);
    _33452 = NOVALUE;
    DeRef(_33454);
    _33454 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SUBS()
{
    object _33485 = NOVALUE;
    object _33484 = NOVALUE;
    object _33483 = NOVALUE;
    object _33482 = NOVALUE;
    object _33481 = NOVALUE;
    object _33479 = NOVALUE;
    object _33478 = NOVALUE;
    object _33476 = NOVALUE;
    object _33474 = NOVALUE;
    object _33473 = NOVALUE;
    object _33472 = NOVALUE;
    object _33470 = NOVALUE;
    object _33468 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1978		a = Code[pc+1]*/
    _33468 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33468);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:1979		b = Code[pc+2]  -- subscript*/
    _33470 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33470);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:1980		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33472 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _33473 = IS_SEQUENCE(_33472);
    _33472 = NOVALUE;
    if (_33473 == 0)
    {
        _33473 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _33473 = NOVALUE;
    }

    /** execute.e:1981			RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_33458);
    _67RTFatal(_33458);
L1: 

    /** execute.e:1983		c = Code[pc+3]  -- RHS value*/
    _33474 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33474);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:1986		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33476 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_33476);
    _67lhs_seq_index_65263 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_65263)){
        _67lhs_seq_index_65263 = (object)DBL_PTR(_67lhs_seq_index_65263)->dbl;
    }
    _33476 = NOVALUE;

    /** execute.e:1987		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33478 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_33478)){
            _33479 = SEQ_PTR(_33478)->length;
    }
    else {
        _33479 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65264;
    RHS_Slice(_33478, 2, _33479);
    _33478 = NOVALUE;

    /** execute.e:1988		val[lhs_seq_index] = assign_subs(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33481 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33482 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_67lhs_subs_65264) && IS_ATOM(_33482)) {
        Ref(_33482);
        Append(&_33483, _67lhs_subs_65264, _33482);
    }
    else if (IS_ATOM(_67lhs_subs_65264) && IS_SEQUENCE(_33482)) {
    }
    else {
        Concat((object_ptr)&_33483, _67lhs_subs_65264, _33482);
    }
    _33482 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    _33484 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    Ref(_33481);
    Ref(_33484);
    _33485 = _67assign_subs(_33481, _33483, _33484);
    _33481 = NOVALUE;
    _33483 = NOVALUE;
    _33484 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33485;
    if( _1 != _33485 ){
        DeRef(_1);
    }
    _33485 = NOVALUE;

    /** execute.e:1991		lhs_subs = {}*/
    RefDS(_22209);
    DeRefDS(_67lhs_subs_65264);
    _67lhs_subs_65264 = _22209;

    /** execute.e:1992		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:1993	end procedure*/
    _33474 = NOVALUE;
    DeRef(_33470);
    _33470 = NOVALUE;
    DeRef(_33468);
    _33468 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SUBS()
{
    object _x_67716 = NOVALUE;
    object _33496 = NOVALUE;
    object _33495 = NOVALUE;
    object _33494 = NOVALUE;
    object _33491 = NOVALUE;
    object _33489 = NOVALUE;
    object _33487 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:1999		a = Code[pc+1]*/
    _33487 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33487);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2000		b = Code[pc+2]*/
    _33489 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33489);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2001		target = Code[pc+3]*/
    _33491 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33491);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2003		lhs_subs = {}*/
    RefDS(_22209);
    DeRef(_67lhs_subs_65264);
    _67lhs_subs_65264 = _22209;

    /** execute.e:2004		x = val[a]*/
    DeRef(_x_67716);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67716 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67716);

    /** execute.e:2005		val[target] = var_subs(x, lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33494 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_67lhs_subs_65264) && IS_ATOM(_33494)) {
        Ref(_33494);
        Append(&_33495, _67lhs_subs_65264, _33494);
    }
    else if (IS_ATOM(_67lhs_subs_65264) && IS_SEQUENCE(_33494)) {
    }
    else {
        Concat((object_ptr)&_33495, _67lhs_subs_65264, _33494);
    }
    _33494 = NOVALUE;
    Ref(_x_67716);
    _33496 = _67var_subs(_x_67716, _33495);
    _33495 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33496;
    if( _1 != _33496 ){
        DeRef(_1);
    }
    _33496 = NOVALUE;

    /** execute.e:2006		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2007	end procedure*/
    DeRef(_x_67716);
    _33487 = NOVALUE;
    _33491 = NOVALUE;
    _33489 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SUBS()
{
    object _33515 = NOVALUE;
    object _33514 = NOVALUE;
    object _33513 = NOVALUE;
    object _33512 = NOVALUE;
    object _33511 = NOVALUE;
    object _33510 = NOVALUE;
    object _33509 = NOVALUE;
    object _33507 = NOVALUE;
    object _33506 = NOVALUE;
    object _33504 = NOVALUE;
    object _33502 = NOVALUE;
    object _33500 = NOVALUE;
    object _33498 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2011		a = Code[pc+1]*/
    _33498 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33498);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2012		b = Code[pc+2]*/
    _33500 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33500);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2013		target = Code[pc+3]*/
    _33502 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33502);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2015		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33504 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_33504);
    _67lhs_seq_index_65263 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_65263)){
        _67lhs_seq_index_65263 = (object)DBL_PTR(_67lhs_seq_index_65263)->dbl;
    }
    _33504 = NOVALUE;

    /** execute.e:2016		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33506 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_33506)){
            _33507 = SEQ_PTR(_33506)->length;
    }
    else {
        _33507 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65264;
    RHS_Slice(_33506, 2, _33507);
    _33506 = NOVALUE;

    /** execute.e:2017		Code[pc+9] = Code[pc+1] -- patch upcoming op*/
    _33509 = _67pc_65255 + 9;
    if ((object)((uintptr_t)_33509 + (uintptr_t)HIGH_BITS) >= 0){
        _33509 = NewDouble((eudouble)_33509);
    }
    _33510 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33511 = (object)*(((s1_ptr)_2)->base + _33510);
    Ref(_33511);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33509))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33509)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33509);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33511;
    if( _1 != _33511 ){
        DeRef(_1);
    }
    _33511 = NOVALUE;

    /** execute.e:2018		val[target] = var_subs(val[lhs_seq_index], lhs_subs & val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33512 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33513 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_67lhs_subs_65264) && IS_ATOM(_33513)) {
        Ref(_33513);
        Append(&_33514, _67lhs_subs_65264, _33513);
    }
    else if (IS_ATOM(_67lhs_subs_65264) && IS_SEQUENCE(_33513)) {
    }
    else {
        Concat((object_ptr)&_33514, _67lhs_subs_65264, _33513);
    }
    _33513 = NOVALUE;
    Ref(_33512);
    _33515 = _67var_subs(_33512, _33514);
    _33512 = NOVALUE;
    _33514 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33515;
    if( _1 != _33515 ){
        DeRef(_1);
    }
    _33515 = NOVALUE;

    /** execute.e:2019		lhs_subs = {}*/
    RefDS(_22209);
    DeRefDS(_67lhs_subs_65264);
    _67lhs_subs_65264 = _22209;

    /** execute.e:2020		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2021	end procedure*/
    _33502 = NOVALUE;
    DeRef(_33509);
    _33509 = NOVALUE;
    _33500 = NOVALUE;
    _33498 = NOVALUE;
    _33510 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SLICE()
{
    object _x_67759 = NOVALUE;
    object _33540 = NOVALUE;
    object _33539 = NOVALUE;
    object _33538 = NOVALUE;
    object _33536 = NOVALUE;
    object _33534 = NOVALUE;
    object _33533 = NOVALUE;
    object _33532 = NOVALUE;
    object _33531 = NOVALUE;
    object _33530 = NOVALUE;
    object _33529 = NOVALUE;
    object _33528 = NOVALUE;
    object _33527 = NOVALUE;
    object _33525 = NOVALUE;
    object _33524 = NOVALUE;
    object _33523 = NOVALUE;
    object _33522 = NOVALUE;
    object _33520 = NOVALUE;
    object _33517 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2027		a = Code[pc+1]*/
    _33517 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33517);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2028		x = val[a]*/
    DeRef(_x_67759);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67759 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67759);

    /** execute.e:2029		b = Code[pc+2]*/
    _33520 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33520);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2030		if floor(val[b]) > length(x) or floor(val[b]) < 1 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33522 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33522))
    _33523 = e_floor(_33522);
    else
    _33523 = unary_op(FLOOR, _33522);
    _33522 = NOVALUE;
    if (IS_SEQUENCE(_x_67759)){
            _33524 = SEQ_PTR(_x_67759)->length;
    }
    else {
        _33524 = 1;
    }
    if (IS_ATOM_INT(_33523)) {
        _33525 = (_33523 > _33524);
    }
    else {
        _33525 = binary_op(GREATER, _33523, _33524);
    }
    DeRef(_33523);
    _33523 = NOVALUE;
    _33524 = NOVALUE;
    if (IS_ATOM_INT(_33525)) {
        if (_33525 != 0) {
            goto L1; // [63] 87
        }
    }
    else {
        if (DBL_PTR(_33525)->dbl != 0.0) {
            goto L1; // [63] 87
        }
    }
    _2 = (object)SEQ_PTR(_67val_65265);
    _33527 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33527))
    _33528 = e_floor(_33527);
    else
    _33528 = unary_op(FLOOR, _33527);
    _33527 = NOVALUE;
    if (IS_ATOM_INT(_33528)) {
        _33529 = (_33528 < 1);
    }
    else {
        _33529 = binary_op(LESS, _33528, 1);
    }
    DeRef(_33528);
    _33528 = NOVALUE;
    if (_33529 == 0) {
        DeRef(_33529);
        _33529 = NOVALUE;
        goto L2; // [83] 112
    }
    else {
        if (!IS_ATOM_INT(_33529) && DBL_PTR(_33529)->dbl == 0.0){
            DeRef(_33529);
            _33529 = NOVALUE;
            goto L2; // [83] 112
        }
        DeRef(_33529);
        _33529 = NOVALUE;
    }
    DeRef(_33529);
    _33529 = NOVALUE;
L1: 

    /** execute.e:2031			RTFatal(*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33530 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_x_67759)){
            _33531 = SEQ_PTR(_x_67759)->length;
    }
    else {
        _33531 = 1;
    }
    Ref(_33530);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _33530;
    ((intptr_t *)_2)[2] = _33531;
    _33532 = MAKE_SEQ(_1);
    _33531 = NOVALUE;
    _33530 = NOVALUE;
    _33533 = EPrintf(-9999999, _33081, _33532);
    DeRefDS(_33532);
    _33532 = NOVALUE;
    _67RTFatal(_33533);
    _33533 = NOVALUE;
L2: 

    /** execute.e:2035		c = Code[pc+3]*/
    _33534 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33534);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:2036		target = Code[pc+4]*/
    _33536 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33536);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2037		val[target] = var_slice(x, {}, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33538 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33539 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    Ref(_x_67759);
    RefDS(_22209);
    Ref(_33538);
    Ref(_33539);
    _33540 = _67var_slice(_x_67759, _22209, _33538, _33539);
    _33538 = NOVALUE;
    _33539 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33540;
    if( _1 != _33540 ){
        DeRef(_1);
    }
    _33540 = NOVALUE;

    /** execute.e:2038		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:2039	end procedure*/
    DeRef(_x_67759);
    _33534 = NOVALUE;
    _33536 = NOVALUE;
    DeRef(_33525);
    _33525 = NOVALUE;
    DeRef(_33517);
    _33517 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SLICE()
{
    object _x_67792 = NOVALUE;
    object _33560 = NOVALUE;
    object _33559 = NOVALUE;
    object _33558 = NOVALUE;
    object _33557 = NOVALUE;
    object _33556 = NOVALUE;
    object _33555 = NOVALUE;
    object _33554 = NOVALUE;
    object _33552 = NOVALUE;
    object _33549 = NOVALUE;
    object _33547 = NOVALUE;
    object _33545 = NOVALUE;
    object _33542 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2045		a = Code[pc+1]*/
    _33542 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33542);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2046		x = val[a]*/
    DeRef(_x_67792);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67792 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67792);

    /** execute.e:2047		b = Code[pc+2]*/
    _33545 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33545);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2048		c = Code[pc+3]*/
    _33547 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33547);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:2049		target = Code[pc+4]*/
    _33549 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33549);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2050		lhs_seq_index = x[1]*/
    _2 = (object)SEQ_PTR(_x_67792);
    _67lhs_seq_index_65263 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_65263)){
        _67lhs_seq_index_65263 = (object)DBL_PTR(_67lhs_seq_index_65263)->dbl;
    }

    /** execute.e:2051		lhs_subs = x[2..$]*/
    if (IS_SEQUENCE(_x_67792)){
            _33552 = SEQ_PTR(_x_67792)->length;
    }
    else {
        _33552 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65264;
    RHS_Slice(_x_67792, 2, _33552);

    /** execute.e:2052		Code[pc+10] = Code[pc+1]*/
    _33554 = _67pc_65255 + 10;
    if ((object)((uintptr_t)_33554 + (uintptr_t)HIGH_BITS) >= 0){
        _33554 = NewDouble((eudouble)_33554);
    }
    _33555 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33556 = (object)*(((s1_ptr)_2)->base + _33555);
    Ref(_33556);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_33554))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_33554)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _33554);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33556;
    if( _1 != _33556 ){
        DeRef(_1);
    }
    _33556 = NOVALUE;

    /** execute.e:2053		val[target] = var_slice(val[lhs_seq_index], lhs_subs, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33557 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33558 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33559 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    Ref(_33557);
    RefDS(_67lhs_subs_65264);
    Ref(_33558);
    Ref(_33559);
    _33560 = _67var_slice(_33557, _67lhs_subs_65264, _33558, _33559);
    _33557 = NOVALUE;
    _33558 = NOVALUE;
    _33559 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33560;
    if( _1 != _33560 ){
        DeRef(_1);
    }
    _33560 = NOVALUE;

    /** execute.e:2054		lhs_subs = {}*/
    RefDS(_22209);
    DeRefDS(_67lhs_subs_65264);
    _67lhs_subs_65264 = _22209;

    /** execute.e:2055		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:2056	end procedure*/
    DeRef(_x_67792);
    _33555 = NOVALUE;
    _33545 = NOVALUE;
    _33549 = NOVALUE;
    DeRef(_33554);
    _33554 = NOVALUE;
    _33542 = NOVALUE;
    _33547 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_SLICE()
{
    object _x_67821 = NOVALUE;
    object _33578 = NOVALUE;
    object _33577 = NOVALUE;
    object _33575 = NOVALUE;
    object _33573 = NOVALUE;
    object _33572 = NOVALUE;
    object _33571 = NOVALUE;
    object _33568 = NOVALUE;
    object _33566 = NOVALUE;
    object _33564 = NOVALUE;
    object _33562 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:2062		a = Code[pc+1]  -- sequence*/
    _33562 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33562);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2063		b = Code[pc+2]  -- 1st index*/
    _33564 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33564);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2064		c = Code[pc+3]  -- 2nd index*/
    _33566 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33566);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:2065		d = Code[pc+4]  -- rhs value to assign*/
    _33568 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67d_65259 = (object)*(((s1_ptr)_2)->base + _33568);
    if (!IS_ATOM_INT(_67d_65259)){
        _67d_65259 = (object)DBL_PTR(_67d_65259)->dbl;
    }

    /** execute.e:2067		x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_67821);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67821 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67821);

    /** execute.e:2068		lhs_check_slice(x, val[b], val[c], val[d])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33571 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33572 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33573 = (object)*(((s1_ptr)_2)->base + _67d_65259);
    Ref(_x_67821);
    Ref(_33571);
    Ref(_33572);
    Ref(_33573);
    _67lhs_check_slice(_x_67821, _33571, _33572, _33573);
    _33571 = NOVALUE;
    _33572 = NOVALUE;
    _33573 = NOVALUE;

    /** execute.e:2069		x = val[d]*/
    DeRef(_x_67821);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67821 = (object)*(((s1_ptr)_2)->base + _67d_65259);
    Ref(_x_67821);

    /** execute.e:2070		val[a][val[b]..val[c]] = x*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67a_65256 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33577 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33578 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_33577, _33578, _x_67821);
    _33577 = NOVALUE;
    _33578 = NOVALUE;

    /** execute.e:2071		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:2072	end procedure*/
    DeRef(_x_67821);
    _33568 = NOVALUE;
    _33564 = NOVALUE;
    _33562 = NOVALUE;
    _33566 = NOVALUE;
    _33575 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SLICE()
{
    object _33597 = NOVALUE;
    object _33596 = NOVALUE;
    object _33595 = NOVALUE;
    object _33594 = NOVALUE;
    object _33593 = NOVALUE;
    object _33591 = NOVALUE;
    object _33590 = NOVALUE;
    object _33588 = NOVALUE;
    object _33586 = NOVALUE;
    object _33584 = NOVALUE;
    object _33582 = NOVALUE;
    object _33580 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2076		a = Code[pc+1]  -- sequence*/
    _33580 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33580);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2077		b = Code[pc+2]  -- 1st index*/
    _33582 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33582);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2078		c = Code[pc+3]  -- 2nd index*/
    _33584 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33584);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:2079		d = Code[pc+4]  -- rhs value to assign*/
    _33586 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67d_65259 = (object)*(((s1_ptr)_2)->base + _33586);
    if (!IS_ATOM_INT(_67d_65259)){
        _67d_65259 = (object)DBL_PTR(_67d_65259)->dbl;
    }

    /** execute.e:2081		lhs_seq_index = val[a][1]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33588 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_33588);
    _67lhs_seq_index_65263 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_65263)){
        _67lhs_seq_index_65263 = (object)DBL_PTR(_67lhs_seq_index_65263)->dbl;
    }
    _33588 = NOVALUE;

    /** execute.e:2082		lhs_subs = val[a][2..$]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33590 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_33590)){
            _33591 = SEQ_PTR(_33590)->length;
    }
    else {
        _33591 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_65264;
    RHS_Slice(_33590, 2, _33591);
    _33590 = NOVALUE;

    /** execute.e:2083		val[lhs_seq_index] = assign_slice(val[lhs_seq_index],*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33593 = (object)*(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33594 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33595 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33596 = (object)*(((s1_ptr)_2)->base + _67d_65259);
    Ref(_33593);
    RefDS(_67lhs_subs_65264);
    Ref(_33594);
    Ref(_33595);
    Ref(_33596);
    _33597 = _67assign_slice(_33593, _67lhs_subs_65264, _33594, _33595, _33596);
    _33593 = NOVALUE;
    _33594 = NOVALUE;
    _33595 = NOVALUE;
    _33596 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67lhs_seq_index_65263);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33597;
    if( _1 != _33597 ){
        DeRef(_1);
    }
    _33597 = NOVALUE;

    /** execute.e:2086		lhs_subs = {}*/
    RefDS(_22209);
    DeRefDS(_67lhs_subs_65264);
    _67lhs_subs_65264 = _22209;

    /** execute.e:2087		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:2088	end procedure*/
    _33582 = NOVALUE;
    _33586 = NOVALUE;
    _33584 = NOVALUE;
    _33580 = NOVALUE;
    return;
    ;
}


void _67opRHS_SLICE()
{
    object _x_67871 = NOVALUE;
    object _33612 = NOVALUE;
    object _33611 = NOVALUE;
    object _33610 = NOVALUE;
    object _33609 = NOVALUE;
    object _33608 = NOVALUE;
    object _33605 = NOVALUE;
    object _33603 = NOVALUE;
    object _33601 = NOVALUE;
    object _33599 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2094		a = Code[pc+1]  -- sequence*/
    _33599 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33599);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2095		b = Code[pc+2]  -- 1st index*/
    _33601 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33601);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2096		c = Code[pc+3]  -- 2nd index*/
    _33603 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _33603);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:2097		target = Code[pc+4]*/
    _33605 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33605);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2098		x = val[a]*/
    DeRef(_x_67871);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_67871 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_x_67871);

    /** execute.e:2099		check_slice(x, val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33608 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33609 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    Ref(_x_67871);
    Ref(_33608);
    Ref(_33609);
    _67check_slice(_x_67871, _33608, _33609);
    _33608 = NOVALUE;
    _33609 = NOVALUE;

    /** execute.e:2100		val[target] = x[val[b]..val[c]]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33610 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33611 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    rhs_slice_target = (object_ptr)&_33612;
    RHS_Slice(_x_67871, _33610, _33611);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33612;
    if( _1 != _33612 ){
        DeRef(_1);
    }
    _33612 = NOVALUE;

    /** execute.e:2101		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:2102	end procedure*/
    DeRef(_x_67871);
    _33605 = NOVALUE;
    _33610 = NOVALUE;
    _33611 = NOVALUE;
    _33603 = NOVALUE;
    _33599 = NOVALUE;
    _33601 = NOVALUE;
    return;
    ;
}


void _67opTYPE_CHECK()
{
    object _33618 = NOVALUE;
    object _33616 = NOVALUE;
    object _33615 = NOVALUE;
    object _33614 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2107		if val[Code[pc-1]] = 0 then*/
    _33614 = _67pc_65255 - 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _33615 = (object)*(((s1_ptr)_2)->base + _33614);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_33615)){
        _33616 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_33615)->dbl));
    }
    else{
        _33616 = (object)*(((s1_ptr)_2)->base + _33615);
    }
    if (binary_op_a(NOTEQ, _33616, 0)){
        _33616 = NOVALUE;
        goto L1; // [21] 37
    }
    _33616 = NOVALUE;

    /** execute.e:2108			RTFatalType(pc-2)*/
    _33618 = _67pc_65255 - 2;
    if ((object)((uintptr_t)_33618 +(uintptr_t) HIGH_BITS) >= 0){
        _33618 = NewDouble((eudouble)_33618);
    }
    _67RTFatalType(_33618);
    _33618 = NOVALUE;
L1: 

    /** execute.e:2110		pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:2111	end procedure*/
    _33615 = NOVALUE;
    DeRef(_33614);
    _33614 = NOVALUE;
    return;
    ;
}


void _67kill_temp(object _sym_67904)
{
    object _33620 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2114		if sym_mode( sym ) = M_TEMP then*/
    _33620 = _53sym_mode(_sym_67904);
    if (binary_op_a(NOTEQ, _33620, 3)){
        DeRef(_33620);
        _33620 = NOVALUE;
        goto L1; // [11] 26
    }
    DeRef(_33620);
    _33620 = NOVALUE;

    /** execute.e:2115			val[sym] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sym_67904);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:2117	end procedure*/
    return;
    ;
}


void _67opIS_AN_INTEGER()
{
    object _33627 = NOVALUE;
    object _33626 = NOVALUE;
    object _33624 = NOVALUE;
    object _33622 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2120		a = Code[pc+1]*/
    _33622 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33622);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2121		target = Code[pc+2]*/
    _33624 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33624);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2122		val[target] = integer(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33626 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33626))
    _33627 = 1;
    else if (IS_ATOM_DBL(_33626))
    _33627 = IS_ATOM_INT(DoubleToInt(_33626));
    else
    _33627 = 0;
    _33626 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33627;
    if( _1 != _33627 ){
        DeRef(_1);
    }
    _33627 = NOVALUE;

    /** execute.e:2123		kill_temp( a )*/
    _67kill_temp(_67a_65256);

    /** execute.e:2124		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2125	end procedure*/
    _33622 = NOVALUE;
    _33624 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_ATOM()
{
    object _33634 = NOVALUE;
    object _33633 = NOVALUE;
    object _33631 = NOVALUE;
    object _33629 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2128		a = Code[pc+1]*/
    _33629 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33629);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2129		target = Code[pc+2]*/
    _33631 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33631);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2130		val[target] = atom(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33633 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33634 = IS_ATOM(_33633);
    _33633 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33634;
    if( _1 != _33634 ){
        DeRef(_1);
    }
    _33634 = NOVALUE;

    /** execute.e:2131		kill_temp( a )*/
    _67kill_temp(_67a_65256);

    /** execute.e:2132		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2133	end procedure*/
    _33629 = NOVALUE;
    _33631 = NOVALUE;
    return;
    ;
}


void _67opIS_A_SEQUENCE()
{
    object _33641 = NOVALUE;
    object _33640 = NOVALUE;
    object _33638 = NOVALUE;
    object _33636 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2136		a = Code[pc+1]*/
    _33636 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33636);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2137		target = Code[pc+2]*/
    _33638 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33638);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2138		val[target] = sequence(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33640 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33641 = IS_SEQUENCE(_33640);
    _33640 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33641;
    if( _1 != _33641 ){
        DeRef(_1);
    }
    _33641 = NOVALUE;

    /** execute.e:2139		kill_temp( a )*/
    _67kill_temp(_67a_65256);

    /** execute.e:2140		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2141	end procedure*/
    _33636 = NOVALUE;
    _33638 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_OBJECT()
{
    object _33650 = NOVALUE;
    object _33649 = NOVALUE;
    object _33648 = NOVALUE;
    object _33647 = NOVALUE;
    object _33645 = NOVALUE;
    object _33643 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2144		a = Code[pc+1]*/
    _33643 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33643);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2145		target = Code[pc+2]*/
    _33645 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33645);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2146		if equal( val[a], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33647 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (_33647 == _27NOVALUE_20426)
    _33648 = 1;
    else if (IS_ATOM_INT(_33647) && IS_ATOM_INT(_27NOVALUE_20426))
    _33648 = 0;
    else
    _33648 = (compare(_33647, _27NOVALUE_20426) == 0);
    _33647 = NOVALUE;
    if (_33648 == 0)
    {
        _33648 = NOVALUE;
        goto L1; // [49] 65
    }
    else{
        _33648 = NOVALUE;
    }

    /** execute.e:2147			val[target] = 0*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    goto L2; // [62] 87
L1: 

    /** execute.e:2149			val[target] = object( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33649 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if( NOVALUE == _33649 ){
        _33650 = 0;
    }
    else{
        if (IS_ATOM_INT(_33649))
        _33650 = 1;
        else if (IS_ATOM_DBL(_33649)) {
             if (IS_ATOM_INT(DoubleToInt(_33649))) {
                 _33650 = 1;
                 } else {
                     _33650 = 2;
                } } else if (IS_SEQUENCE(_33649))
                _33650 = 3;
                else
                _33650 = 0;
            }
            _33649 = NOVALUE;
            _2 = (object)SEQ_PTR(_67val_65265);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67val_65265 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _33650;
            if( _1 != _33650 ){
                DeRef(_1);
            }
            _33650 = NOVALUE;
L2: 

            /** execute.e:2152		kill_temp( a )*/
            _67kill_temp(_67a_65256);

            /** execute.e:2153		pc += 3*/
            _67pc_65255 = _67pc_65255 + 3;

            /** execute.e:2154	end procedure*/
            DeRef(_33643);
            _33643 = NOVALUE;
            DeRef(_33645);
            _33645 = NOVALUE;
            return;
    ;
}


void _67opSQRT()
{
    object _33657 = NOVALUE;
    object _33656 = NOVALUE;
    object _33654 = NOVALUE;
    object _33652 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2160		a = Code[pc+1]*/
    _33652 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33652);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2161		target = Code[pc+2]*/
    _33654 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33654);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2162		val[target] = sqrt(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33656 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33656))
    _33657 = e_sqrt(_33656);
    else
    _33657 = unary_op(SQRT, _33656);
    _33656 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33657;
    if( _1 != _33657 ){
        DeRef(_1);
    }
    _33657 = NOVALUE;

    /** execute.e:2163		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2164	end procedure*/
    _33652 = NOVALUE;
    _33654 = NOVALUE;
    return;
    ;
}


void _67opSIN()
{
    object _33664 = NOVALUE;
    object _33663 = NOVALUE;
    object _33661 = NOVALUE;
    object _33659 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2167		a = Code[pc+1]*/
    _33659 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33659);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2168		target = Code[pc+2]*/
    _33661 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33661);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2169		val[target] = sin(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33663 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33663))
    _33664 = e_sin(_33663);
    else
    _33664 = unary_op(SIN, _33663);
    _33663 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33664;
    if( _1 != _33664 ){
        DeRef(_1);
    }
    _33664 = NOVALUE;

    /** execute.e:2170		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2171	end procedure*/
    _33661 = NOVALUE;
    _33659 = NOVALUE;
    return;
    ;
}


void _67opCOS()
{
    object _33671 = NOVALUE;
    object _33670 = NOVALUE;
    object _33668 = NOVALUE;
    object _33666 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2174		a = Code[pc+1]*/
    _33666 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33666);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2175		target = Code[pc+2]*/
    _33668 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33668);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2176		val[target] = cos(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33670 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33670))
    _33671 = e_cos(_33670);
    else
    _33671 = unary_op(COS, _33670);
    _33670 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33671;
    if( _1 != _33671 ){
        DeRef(_1);
    }
    _33671 = NOVALUE;

    /** execute.e:2177		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2178	end procedure*/
    _33668 = NOVALUE;
    _33666 = NOVALUE;
    return;
    ;
}


void _67opTAN()
{
    object _33678 = NOVALUE;
    object _33677 = NOVALUE;
    object _33675 = NOVALUE;
    object _33673 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2181		a = Code[pc+1]*/
    _33673 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33673);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2182		target = Code[pc+2]*/
    _33675 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33675);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2183		val[target] = tan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33677 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33677))
    _33678 = e_tan(_33677);
    else
    _33678 = unary_op(TAN, _33677);
    _33677 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33678;
    if( _1 != _33678 ){
        DeRef(_1);
    }
    _33678 = NOVALUE;

    /** execute.e:2184		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2185	end procedure*/
    _33673 = NOVALUE;
    _33675 = NOVALUE;
    return;
    ;
}


void _67opARCTAN()
{
    object _33685 = NOVALUE;
    object _33684 = NOVALUE;
    object _33682 = NOVALUE;
    object _33680 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2188		a = Code[pc+1]*/
    _33680 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33680);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2189		target = Code[pc+2]*/
    _33682 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33682);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2190		val[target] = arctan(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33684 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33684))
    _33685 = e_arctan(_33684);
    else
    _33685 = unary_op(ARCTAN, _33684);
    _33684 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33685;
    if( _1 != _33685 ){
        DeRef(_1);
    }
    _33685 = NOVALUE;

    /** execute.e:2191		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2192	end procedure*/
    _33682 = NOVALUE;
    _33680 = NOVALUE;
    return;
    ;
}


void _67opLOG()
{
    object _33692 = NOVALUE;
    object _33691 = NOVALUE;
    object _33689 = NOVALUE;
    object _33687 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2195		a = Code[pc+1]*/
    _33687 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33687);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2196		target = Code[pc+2]*/
    _33689 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33689);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2197		val[target] = log(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33691 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33691))
    _33692 = e_log(_33691);
    else
    _33692 = unary_op(LOG, _33691);
    _33691 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33692;
    if( _1 != _33692 ){
        DeRef(_1);
    }
    _33692 = NOVALUE;

    /** execute.e:2198		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2199	end procedure*/
    _33687 = NOVALUE;
    _33689 = NOVALUE;
    return;
    ;
}


void _67opNOT_BITS()
{
    object _33699 = NOVALUE;
    object _33698 = NOVALUE;
    object _33696 = NOVALUE;
    object _33694 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2202		a = Code[pc+1]*/
    _33694 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33694);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2203		target = Code[pc+2]*/
    _33696 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33696);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2204		val[target] = not_bits(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33698 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33698))
    _33699 = not_bits(_33698);
    else
    _33699 = unary_op(NOT_BITS, _33698);
    _33698 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33699;
    if( _1 != _33699 ){
        DeRef(_1);
    }
    _33699 = NOVALUE;

    /** execute.e:2205		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2206	end procedure*/
    _33696 = NOVALUE;
    _33694 = NOVALUE;
    return;
    ;
}


void _67opFLOOR()
{
    object _33706 = NOVALUE;
    object _33705 = NOVALUE;
    object _33703 = NOVALUE;
    object _33701 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2209		a = Code[pc+1]*/
    _33701 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33701);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2210		target = Code[pc+2]*/
    _33703 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33703);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2211		val[target] = floor(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33705 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33705))
    _33706 = e_floor(_33705);
    else
    _33706 = unary_op(FLOOR, _33705);
    _33705 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33706;
    if( _1 != _33706 ){
        DeRef(_1);
    }
    _33706 = NOVALUE;

    /** execute.e:2212		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2213	end procedure*/
    _33701 = NOVALUE;
    _33703 = NOVALUE;
    return;
    ;
}


void _67opNOT_IFW()
{
    object _33713 = NOVALUE;
    object _33710 = NOVALUE;
    object _33708 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2216		a = Code[pc+1]*/
    _33708 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33708);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2217		if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33710 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(NOTEQ, _33710, 0)){
        _33710 = NOVALUE;
        goto L1; // [27] 42
    }
    _33710 = NOVALUE;

    /** execute.e:2218			pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;
    goto L2; // [39] 59
L1: 

    /** execute.e:2220			pc = Code[pc+2]*/
    _33713 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33713);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2222	end procedure*/
    DeRef(_33713);
    _33713 = NOVALUE;
    DeRef(_33708);
    _33708 = NOVALUE;
    return;
    ;
}


void _67opNOT()
{
    object _33720 = NOVALUE;
    object _33719 = NOVALUE;
    object _33717 = NOVALUE;
    object _33715 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2225		a = Code[pc+1]*/
    _33715 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33715);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2226		target = Code[pc+2]*/
    _33717 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33717);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2227		val[target] = not val[a]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33719 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33719)) {
        _33720 = (_33719 == 0);
    }
    else {
        _33720 = unary_op(NOT, _33719);
    }
    _33719 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33720;
    if( _1 != _33720 ){
        DeRef(_1);
    }
    _33720 = NOVALUE;

    /** execute.e:2228		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2229	end procedure*/
    _33717 = NOVALUE;
    _33715 = NOVALUE;
    return;
    ;
}


void _67opUMINUS()
{
    object _33727 = NOVALUE;
    object _33726 = NOVALUE;
    object _33724 = NOVALUE;
    object _33722 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2232		a = Code[pc+1]*/
    _33722 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33722);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2233		target = Code[pc+2]*/
    _33724 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33724);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2234		val[target] = -val[a]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33726 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33726)) {
        if ((uintptr_t)_33726 == (uintptr_t)HIGH_BITS){
            _33727 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _33727 = - _33726;
        }
    }
    else {
        _33727 = unary_op(UMINUS, _33726);
    }
    _33726 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33727;
    if( _1 != _33727 ){
        DeRef(_1);
    }
    _33727 = NOVALUE;

    /** execute.e:2235		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2236	end procedure*/
    _33724 = NOVALUE;
    _33722 = NOVALUE;
    return;
    ;
}


void _67opRAND()
{
    object _33734 = NOVALUE;
    object _33733 = NOVALUE;
    object _33731 = NOVALUE;
    object _33729 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2239		a = Code[pc+1]*/
    _33729 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33729);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2240		target = Code[pc+2]*/
    _33731 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33731);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2241		val[target] = rand(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33733 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33733)) {
        _33734 = good_rand() % ((uint32_t)_33733) + 1;
    }
    else {
        _33734 = unary_op(RAND, _33733);
    }
    _33733 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33734;
    if( _1 != _33734 ){
        DeRef(_1);
    }
    _33734 = NOVALUE;

    /** execute.e:2242		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2243	end procedure*/
    _33731 = NOVALUE;
    _33729 = NOVALUE;
    return;
    ;
}


void _67opDIV2()
{
    object _33741 = NOVALUE;
    object _33740 = NOVALUE;
    object _33738 = NOVALUE;
    object _33736 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2247		a = Code[pc+1]*/
    _33736 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33736);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2249		target = Code[pc+3]*/
    _33738 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33738);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2250		val[target] = val[a] / 2*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33740 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33740)) {
        if (_33740 & 1) {
            _33741 = NewDouble((_33740 >> 1) + 0.5);
        }
        else
        _33741 = _33740 >> 1;
    }
    else {
        _33741 = binary_op(DIVIDE, _33740, 2);
    }
    _33740 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33741;
    if( _1 != _33741 ){
        DeRef(_1);
    }
    _33741 = NOVALUE;

    /** execute.e:2251		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2252	end procedure*/
    _33736 = NOVALUE;
    _33738 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV2()
{
    object _33748 = NOVALUE;
    object _33747 = NOVALUE;
    object _33745 = NOVALUE;
    object _33743 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2255		a = Code[pc+1]*/
    _33743 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33743);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2257		target = Code[pc+3]*/
    _33745 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33745);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2258		val[target] = floor(val[a] / 2)*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33747 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_33747)) {
        _33748 = _33747 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _33747, 2);
        _33748 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    _33747 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33748;
    if( _1 != _33748 ){
        DeRef(_1);
    }
    _33748 = NOVALUE;

    /** execute.e:2259		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2260	end procedure*/
    _33743 = NOVALUE;
    _33745 = NOVALUE;
    return;
    ;
}


void _67opGREATER_IFW()
{
    object _33758 = NOVALUE;
    object _33755 = NOVALUE;
    object _33754 = NOVALUE;
    object _33752 = NOVALUE;
    object _33750 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2265		a = Code[pc+1]*/
    _33750 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33750);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2266		b = Code[pc+2]*/
    _33752 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33752);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2267		if val[a] > val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33754 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33755 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(LESSEQ, _33754, _33755)){
        _33754 = NOVALUE;
        _33755 = NOVALUE;
        goto L1; // [51] 66
    }
    _33754 = NOVALUE;
    _33755 = NOVALUE;

    /** execute.e:2268			pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2270			pc = Code[pc+3]*/
    _33758 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33758);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2272	end procedure*/
    DeRef(_33750);
    _33750 = NOVALUE;
    DeRef(_33758);
    _33758 = NOVALUE;
    DeRef(_33752);
    _33752 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ_IFW()
{
    object _33768 = NOVALUE;
    object _33765 = NOVALUE;
    object _33764 = NOVALUE;
    object _33762 = NOVALUE;
    object _33760 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2275		a = Code[pc+1]*/
    _33760 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33760);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2276		b = Code[pc+2]*/
    _33762 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33762);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2277		if val[a] != val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33764 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33765 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(EQUALS, _33764, _33765)){
        _33764 = NOVALUE;
        _33765 = NOVALUE;
        goto L1; // [51] 66
    }
    _33764 = NOVALUE;
    _33765 = NOVALUE;

    /** execute.e:2278			pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2280			pc = Code[pc+3]*/
    _33768 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33768);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2282	end procedure*/
    DeRef(_33768);
    _33768 = NOVALUE;
    DeRef(_33760);
    _33760 = NOVALUE;
    DeRef(_33762);
    _33762 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ_IFW()
{
    object _33778 = NOVALUE;
    object _33775 = NOVALUE;
    object _33774 = NOVALUE;
    object _33772 = NOVALUE;
    object _33770 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2285		a = Code[pc+1]*/
    _33770 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33770);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2286		b = Code[pc+2]*/
    _33772 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33772);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2287		if val[a] <= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33774 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33775 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(GREATER, _33774, _33775)){
        _33774 = NOVALUE;
        _33775 = NOVALUE;
        goto L1; // [51] 66
    }
    _33774 = NOVALUE;
    _33775 = NOVALUE;

    /** execute.e:2288			pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2290			pc = Code[pc+3]*/
    _33778 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33778);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2292	end procedure*/
    DeRef(_33772);
    _33772 = NOVALUE;
    DeRef(_33778);
    _33778 = NOVALUE;
    DeRef(_33770);
    _33770 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ_IFW()
{
    object _33788 = NOVALUE;
    object _33785 = NOVALUE;
    object _33784 = NOVALUE;
    object _33782 = NOVALUE;
    object _33780 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2295		a = Code[pc+1]*/
    _33780 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33780);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2296		b = Code[pc+2]*/
    _33782 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33782);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2297		if val[a] >= val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33784 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33785 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(LESS, _33784, _33785)){
        _33784 = NOVALUE;
        _33785 = NOVALUE;
        goto L1; // [51] 66
    }
    _33784 = NOVALUE;
    _33785 = NOVALUE;

    /** execute.e:2298			pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2300			pc = Code[pc+3]*/
    _33788 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33788);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2302	end procedure*/
    DeRef(_33788);
    _33788 = NOVALUE;
    DeRef(_33780);
    _33780 = NOVALUE;
    DeRef(_33782);
    _33782 = NOVALUE;
    return;
    ;
}


void _67opEQUALS_IFW()
{
    object _33804 = NOVALUE;
    object _33801 = NOVALUE;
    object _33800 = NOVALUE;
    object _33798 = NOVALUE;
    object _33797 = NOVALUE;
    object _33795 = NOVALUE;
    object _33794 = NOVALUE;
    object _33792 = NOVALUE;
    object _33790 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2305		a = Code[pc+1]*/
    _33790 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33790);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2306		b = Code[pc+2]*/
    _33792 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33792);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2308		if sequence( val[a] ) or sequence( val[b] ) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33794 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _33795 = IS_SEQUENCE(_33794);
    _33794 = NOVALUE;
    if (_33795 != 0) {
        goto L1; // [46] 66
    }
    _2 = (object)SEQ_PTR(_67val_65265);
    _33797 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _33798 = IS_SEQUENCE(_33797);
    _33797 = NOVALUE;
    if (_33798 == 0)
    {
        _33798 = NOVALUE;
        goto L2; // [62] 72
    }
    else{
        _33798 = NOVALUE;
    }
L1: 

    /** execute.e:2309			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33799);
    _67RTFatal(_33799);
L2: 

    /** execute.e:2311		if val[a] = val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33800 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33801 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(NOTEQ, _33800, _33801)){
        _33800 = NOVALUE;
        _33801 = NOVALUE;
        goto L3; // [90] 105
    }
    _33800 = NOVALUE;
    _33801 = NOVALUE;

    /** execute.e:2312			pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;
    goto L4; // [102] 122
L3: 

    /** execute.e:2314			pc = Code[pc+3]*/
    _33804 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33804);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L4: 

    /** execute.e:2316	end procedure*/
    DeRef(_33790);
    _33790 = NOVALUE;
    DeRef(_33792);
    _33792 = NOVALUE;
    DeRef(_33804);
    _33804 = NOVALUE;
    return;
    ;
}


void _67opLESS_IFW()
{
    object _33814 = NOVALUE;
    object _33811 = NOVALUE;
    object _33810 = NOVALUE;
    object _33808 = NOVALUE;
    object _33806 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2319		a = Code[pc+1]*/
    _33806 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33806);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2320		b = Code[pc+2]*/
    _33808 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33808);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2321		if val[a] < val[b] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33810 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33811 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(GREATEREQ, _33810, _33811)){
        _33810 = NOVALUE;
        _33811 = NOVALUE;
        goto L1; // [51] 66
    }
    _33810 = NOVALUE;
    _33811 = NOVALUE;

    /** execute.e:2322			pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;
    goto L2; // [63] 83
L1: 

    /** execute.e:2324			pc = Code[pc+3]*/
    _33814 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _33814);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2326	end procedure*/
    DeRef(_33814);
    _33814 = NOVALUE;
    DeRef(_33806);
    _33806 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    return;
    ;
}


void _67opMULTIPLY()
{
    object _33824 = NOVALUE;
    object _33823 = NOVALUE;
    object _33822 = NOVALUE;
    object _33820 = NOVALUE;
    object _33818 = NOVALUE;
    object _33816 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2331		a = Code[pc+1]*/
    _33816 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33816);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2332		b = Code[pc+2]*/
    _33818 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33818);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2333		target = Code[pc+3]*/
    _33820 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33820);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2334		val[target] = val[a] * val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33822 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33823 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33822) && IS_ATOM_INT(_33823)) {
        if (_33822 == (short)_33822 && _33823 <= INT15 && _33823 >= -INT15){
            _33824 = _33822 * _33823;
        }
        else{
            _33824 = NewDouble(_33822 * (eudouble)_33823);
        }
    }
    else {
        _33824 = binary_op(MULTIPLY, _33822, _33823);
    }
    _33822 = NOVALUE;
    _33823 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33824;
    if( _1 != _33824 ){
        DeRef(_1);
    }
    _33824 = NOVALUE;

    /** execute.e:2335		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2336	end procedure*/
    _33818 = NOVALUE;
    _33816 = NOVALUE;
    _33820 = NOVALUE;
    return;
    ;
}


void _67opPLUS()
{
    object _33834 = NOVALUE;
    object _33833 = NOVALUE;
    object _33832 = NOVALUE;
    object _33830 = NOVALUE;
    object _33828 = NOVALUE;
    object _33826 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2340		a = Code[pc+1]*/
    _33826 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33826);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2341		b = Code[pc+2]*/
    _33828 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33828);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2342		target = Code[pc+3]*/
    _33830 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33830);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2343		val[target] = val[a] + val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33832 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33833 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33832) && IS_ATOM_INT(_33833)) {
        _33834 = _33832 + _33833;
        if ((object)((uintptr_t)_33834 + (uintptr_t)HIGH_BITS) >= 0){
            _33834 = NewDouble((eudouble)_33834);
        }
    }
    else {
        _33834 = binary_op(PLUS, _33832, _33833);
    }
    _33832 = NOVALUE;
    _33833 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33834;
    if( _1 != _33834 ){
        DeRef(_1);
    }
    _33834 = NOVALUE;

    /** execute.e:2344		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2345	end procedure*/
    _33828 = NOVALUE;
    _33830 = NOVALUE;
    _33826 = NOVALUE;
    return;
    ;
}


void _67opMINUS()
{
    object _33844 = NOVALUE;
    object _33843 = NOVALUE;
    object _33842 = NOVALUE;
    object _33840 = NOVALUE;
    object _33838 = NOVALUE;
    object _33836 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2349		a = Code[pc+1]*/
    _33836 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33836);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2350		b = Code[pc+2]*/
    _33838 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33838);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2351		target = Code[pc+3]*/
    _33840 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33840);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2352		val[target] = val[a] - val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33842 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33843 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33842) && IS_ATOM_INT(_33843)) {
        _33844 = _33842 - _33843;
        if ((object)((uintptr_t)_33844 +(uintptr_t) HIGH_BITS) >= 0){
            _33844 = NewDouble((eudouble)_33844);
        }
    }
    else {
        _33844 = binary_op(MINUS, _33842, _33843);
    }
    _33842 = NOVALUE;
    _33843 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33844;
    if( _1 != _33844 ){
        DeRef(_1);
    }
    _33844 = NOVALUE;

    /** execute.e:2353		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2354	end procedure*/
    _33836 = NOVALUE;
    _33840 = NOVALUE;
    _33838 = NOVALUE;
    return;
    ;
}


void _67opOR()
{
    object _33854 = NOVALUE;
    object _33853 = NOVALUE;
    object _33852 = NOVALUE;
    object _33850 = NOVALUE;
    object _33848 = NOVALUE;
    object _33846 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2357		a = Code[pc+1]*/
    _33846 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33846);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2358		b = Code[pc+2]*/
    _33848 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33848);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2359		target = Code[pc+3]*/
    _33850 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33850);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2360		val[target] = val[a] or val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33852 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33853 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33852) && IS_ATOM_INT(_33853)) {
        _33854 = (_33852 != 0 || _33853 != 0);
    }
    else {
        _33854 = binary_op(OR, _33852, _33853);
    }
    _33852 = NOVALUE;
    _33853 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33854;
    if( _1 != _33854 ){
        DeRef(_1);
    }
    _33854 = NOVALUE;

    /** execute.e:2361		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2362	end procedure*/
    _33848 = NOVALUE;
    _33846 = NOVALUE;
    _33850 = NOVALUE;
    return;
    ;
}


void _67opXOR()
{
    object _33864 = NOVALUE;
    object _33863 = NOVALUE;
    object _33862 = NOVALUE;
    object _33860 = NOVALUE;
    object _33858 = NOVALUE;
    object _33856 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2365		a = Code[pc+1]*/
    _33856 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33856);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2366		b = Code[pc+2]*/
    _33858 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33858);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2367		target = Code[pc+3]*/
    _33860 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33860);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2368		val[target] = val[a] xor val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33862 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33863 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33862) && IS_ATOM_INT(_33863)) {
        _33864 = ((_33862 != 0) != (_33863 != 0));
    }
    else {
        _33864 = binary_op(XOR, _33862, _33863);
    }
    _33862 = NOVALUE;
    _33863 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33864;
    if( _1 != _33864 ){
        DeRef(_1);
    }
    _33864 = NOVALUE;

    /** execute.e:2369		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2370	end procedure*/
    _33858 = NOVALUE;
    _33856 = NOVALUE;
    _33860 = NOVALUE;
    return;
    ;
}


void _67opAND()
{
    object _33874 = NOVALUE;
    object _33873 = NOVALUE;
    object _33872 = NOVALUE;
    object _33870 = NOVALUE;
    object _33868 = NOVALUE;
    object _33866 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2373		a = Code[pc+1]*/
    _33866 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33866);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2374		b = Code[pc+2]*/
    _33868 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33868);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2375		target = Code[pc+3]*/
    _33870 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33870);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2376		val[target] = val[a] and val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33872 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33873 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33872) && IS_ATOM_INT(_33873)) {
        _33874 = (_33872 != 0 && _33873 != 0);
    }
    else {
        _33874 = binary_op(AND, _33872, _33873);
    }
    _33872 = NOVALUE;
    _33873 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33874;
    if( _1 != _33874 ){
        DeRef(_1);
    }
    _33874 = NOVALUE;

    /** execute.e:2377		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2378	end procedure*/
    _33870 = NOVALUE;
    _33868 = NOVALUE;
    _33866 = NOVALUE;
    return;
    ;
}


void _67opDIVIDE()
{
    object _33887 = NOVALUE;
    object _33886 = NOVALUE;
    object _33885 = NOVALUE;
    object _33883 = NOVALUE;
    object _33882 = NOVALUE;
    object _33880 = NOVALUE;
    object _33878 = NOVALUE;
    object _33876 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2381		a = Code[pc+1]*/
    _33876 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33876);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2382		b = Code[pc+2]*/
    _33878 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33878);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2383		target = Code[pc+3]*/
    _33880 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33880);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2384		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33882 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (_33882 == 0)
    _33883 = 1;
    else if (IS_ATOM_INT(_33882) && IS_ATOM_INT(0))
    _33883 = 0;
    else
    _33883 = (compare(_33882, 0) == 0);
    _33882 = NOVALUE;
    if (_33883 == 0)
    {
        _33883 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33883 = NOVALUE;
    }

    /** execute.e:2385			RTFatal("attempt to divide by 0")*/
    RefDS(_33884);
    _67RTFatal(_33884);
L1: 

    /** execute.e:2387		val[target] = val[a] / val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33885 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33886 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33885) && IS_ATOM_INT(_33886)) {
        _33887 = (_33885 % _33886) ? NewDouble((eudouble)_33885 / _33886) : (_33885 / _33886);
    }
    else {
        _33887 = binary_op(DIVIDE, _33885, _33886);
    }
    _33885 = NOVALUE;
    _33886 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33887;
    if( _1 != _33887 ){
        DeRef(_1);
    }
    _33887 = NOVALUE;

    /** execute.e:2388		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2389	end procedure*/
    DeRef(_33876);
    _33876 = NOVALUE;
    DeRef(_33878);
    _33878 = NOVALUE;
    DeRef(_33880);
    _33880 = NOVALUE;
    return;
    ;
}


void _67opREMAINDER()
{
    object _33900 = NOVALUE;
    object _33899 = NOVALUE;
    object _33898 = NOVALUE;
    object _33896 = NOVALUE;
    object _33895 = NOVALUE;
    object _33893 = NOVALUE;
    object _33891 = NOVALUE;
    object _33889 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2392		a = Code[pc+1]*/
    _33889 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33889);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2393		b = Code[pc+2]*/
    _33891 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33891);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2394		target = Code[pc+3]*/
    _33893 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33893);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2395		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33895 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (_33895 == 0)
    _33896 = 1;
    else if (IS_ATOM_INT(_33895) && IS_ATOM_INT(0))
    _33896 = 0;
    else
    _33896 = (compare(_33895, 0) == 0);
    _33895 = NOVALUE;
    if (_33896 == 0)
    {
        _33896 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33896 = NOVALUE;
    }

    /** execute.e:2396			RTFatal("Can't get remainder of a number divided by 0")*/
    RefDS(_33897);
    _67RTFatal(_33897);
L1: 

    /** execute.e:2398		val[target] = remainder(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33898 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33899 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33898) && IS_ATOM_INT(_33899)) {
        _33900 = (_33898 % _33899);
    }
    else {
        _33900 = binary_op(REMAINDER, _33898, _33899);
    }
    _33898 = NOVALUE;
    _33899 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33900;
    if( _1 != _33900 ){
        DeRef(_1);
    }
    _33900 = NOVALUE;

    /** execute.e:2399		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2400	end procedure*/
    DeRef(_33891);
    _33891 = NOVALUE;
    DeRef(_33889);
    _33889 = NOVALUE;
    DeRef(_33893);
    _33893 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV()
{
    object _33912 = NOVALUE;
    object _33911 = NOVALUE;
    object _33910 = NOVALUE;
    object _33909 = NOVALUE;
    object _33908 = NOVALUE;
    object _33906 = NOVALUE;
    object _33904 = NOVALUE;
    object _33902 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2403		a = Code[pc+1]*/
    _33902 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33902);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2404		b = Code[pc+2]*/
    _33904 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33904);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2405		target = Code[pc+3]*/
    _33906 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33906);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2406		if equal(val[b], 0) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33908 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (_33908 == 0)
    _33909 = 1;
    else if (IS_ATOM_INT(_33908) && IS_ATOM_INT(0))
    _33909 = 0;
    else
    _33909 = (compare(_33908, 0) == 0);
    _33908 = NOVALUE;
    if (_33909 == 0)
    {
        _33909 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33909 = NOVALUE;
    }

    /** execute.e:2407			RTFatal("attempt to divide by 0")*/
    RefDS(_33884);
    _67RTFatal(_33884);
L1: 

    /** execute.e:2409		val[target] = floor(val[a] / val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33910 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33911 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33910) && IS_ATOM_INT(_33911)) {
        if (_33911 > 0 && _33910 >= 0) {
            _33912 = _33910 / _33911;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_33910 / (eudouble)_33911);
            if (_33910 != MININT)
            _33912 = (object)temp_dbl;
            else
            _33912 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _33910, _33911);
        _33912 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _33910 = NOVALUE;
    _33911 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33912;
    if( _1 != _33912 ){
        DeRef(_1);
    }
    _33912 = NOVALUE;

    /** execute.e:2410		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2411	end procedure*/
    DeRef(_33904);
    _33904 = NOVALUE;
    DeRef(_33902);
    _33902 = NOVALUE;
    DeRef(_33906);
    _33906 = NOVALUE;
    return;
    ;
}


void _67opAND_BITS()
{
    object _33922 = NOVALUE;
    object _33921 = NOVALUE;
    object _33920 = NOVALUE;
    object _33918 = NOVALUE;
    object _33916 = NOVALUE;
    object _33914 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2414		a = Code[pc+1]*/
    _33914 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33914);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2415		b = Code[pc+2]*/
    _33916 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33916);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2416		target = Code[pc+3]*/
    _33918 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33918);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2417		val[target] = and_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33920 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33921 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33920) && IS_ATOM_INT(_33921)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33920 & (uintptr_t)_33921;
             _33922 = MAKE_UINT(tu);
        }
    }
    else {
        _33922 = binary_op(AND_BITS, _33920, _33921);
    }
    _33920 = NOVALUE;
    _33921 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33922;
    if( _1 != _33922 ){
        DeRef(_1);
    }
    _33922 = NOVALUE;

    /** execute.e:2418		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2419	end procedure*/
    _33914 = NOVALUE;
    _33918 = NOVALUE;
    _33916 = NOVALUE;
    return;
    ;
}


void _67opOR_BITS()
{
    object _33932 = NOVALUE;
    object _33931 = NOVALUE;
    object _33930 = NOVALUE;
    object _33928 = NOVALUE;
    object _33926 = NOVALUE;
    object _33924 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2422		a = Code[pc+1]*/
    _33924 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33924);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2423		b = Code[pc+2]*/
    _33926 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33926);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2424		target = Code[pc+3]*/
    _33928 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33928);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2425		val[target] = or_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33930 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33931 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33930) && IS_ATOM_INT(_33931)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33930 | (uintptr_t)_33931;
             _33932 = MAKE_UINT(tu);
        }
    }
    else {
        _33932 = binary_op(OR_BITS, _33930, _33931);
    }
    _33930 = NOVALUE;
    _33931 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33932;
    if( _1 != _33932 ){
        DeRef(_1);
    }
    _33932 = NOVALUE;

    /** execute.e:2426		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2427	end procedure*/
    _33924 = NOVALUE;
    _33928 = NOVALUE;
    _33926 = NOVALUE;
    return;
    ;
}


void _67opXOR_BITS()
{
    object _33942 = NOVALUE;
    object _33941 = NOVALUE;
    object _33940 = NOVALUE;
    object _33938 = NOVALUE;
    object _33936 = NOVALUE;
    object _33934 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2430		a = Code[pc+1]*/
    _33934 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33934);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2431		b = Code[pc+2]*/
    _33936 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33936);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2432		target = Code[pc+3]*/
    _33938 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33938);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2433		val[target] = xor_bits(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33940 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33941 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33940) && IS_ATOM_INT(_33941)) {
        {uintptr_t tu;
             tu = (uintptr_t)_33940 ^ (uintptr_t)_33941;
             _33942 = MAKE_UINT(tu);
        }
    }
    else {
        _33942 = binary_op(XOR_BITS, _33940, _33941);
    }
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33942;
    if( _1 != _33942 ){
        DeRef(_1);
    }
    _33942 = NOVALUE;

    /** execute.e:2434		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2435	end procedure*/
    _33936 = NOVALUE;
    _33938 = NOVALUE;
    _33934 = NOVALUE;
    return;
    ;
}


void _67opPOWER()
{
    object _33952 = NOVALUE;
    object _33951 = NOVALUE;
    object _33950 = NOVALUE;
    object _33948 = NOVALUE;
    object _33946 = NOVALUE;
    object _33944 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2438		a = Code[pc+1]*/
    _33944 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33944);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2439		b = Code[pc+2]*/
    _33946 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33946);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2440		target = Code[pc+3]*/
    _33948 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33948);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2441		val[target] = power(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33950 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33951 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33950) && IS_ATOM_INT(_33951)) {
        _33952 = power(_33950, _33951);
    }
    else {
        _33952 = binary_op(POWER, _33950, _33951);
    }
    _33950 = NOVALUE;
    _33951 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33952;
    if( _1 != _33952 ){
        DeRef(_1);
    }
    _33952 = NOVALUE;

    /** execute.e:2442		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2443	end procedure*/
    _33944 = NOVALUE;
    _33948 = NOVALUE;
    _33946 = NOVALUE;
    return;
    ;
}


void _67opLESS()
{
    object _33962 = NOVALUE;
    object _33961 = NOVALUE;
    object _33960 = NOVALUE;
    object _33958 = NOVALUE;
    object _33956 = NOVALUE;
    object _33954 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2446		a = Code[pc+1]*/
    _33954 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33954);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2447		b = Code[pc+2]*/
    _33956 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33956);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2448		target = Code[pc+3]*/
    _33958 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33958);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2449		val[target] = val[a] < val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33960 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33961 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33960) && IS_ATOM_INT(_33961)) {
        _33962 = (_33960 < _33961);
    }
    else {
        _33962 = binary_op(LESS, _33960, _33961);
    }
    _33960 = NOVALUE;
    _33961 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33962;
    if( _1 != _33962 ){
        DeRef(_1);
    }
    _33962 = NOVALUE;

    /** execute.e:2450		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2451	end procedure*/
    _33954 = NOVALUE;
    _33958 = NOVALUE;
    _33956 = NOVALUE;
    return;
    ;
}


void _67opGREATER()
{
    object _33972 = NOVALUE;
    object _33971 = NOVALUE;
    object _33970 = NOVALUE;
    object _33968 = NOVALUE;
    object _33966 = NOVALUE;
    object _33964 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2454		a = Code[pc+1]*/
    _33964 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33964);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2455		b = Code[pc+2]*/
    _33966 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33966);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2456		target = Code[pc+3]*/
    _33968 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33968);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2457		val[target] = val[a] > val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33970 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33971 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33970) && IS_ATOM_INT(_33971)) {
        _33972 = (_33970 > _33971);
    }
    else {
        _33972 = binary_op(GREATER, _33970, _33971);
    }
    _33970 = NOVALUE;
    _33971 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33972;
    if( _1 != _33972 ){
        DeRef(_1);
    }
    _33972 = NOVALUE;

    /** execute.e:2458		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2459	end procedure*/
    _33968 = NOVALUE;
    _33964 = NOVALUE;
    _33966 = NOVALUE;
    return;
    ;
}


void _67opEQUALS()
{
    object _33982 = NOVALUE;
    object _33981 = NOVALUE;
    object _33980 = NOVALUE;
    object _33978 = NOVALUE;
    object _33976 = NOVALUE;
    object _33974 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2462		a = Code[pc+1]*/
    _33974 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33974);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2463		b = Code[pc+2]*/
    _33976 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33976);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2464		target = Code[pc+3]*/
    _33978 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33978);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2465		val[target] = val[a] = val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33980 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33981 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33980) && IS_ATOM_INT(_33981)) {
        _33982 = (_33980 == _33981);
    }
    else {
        _33982 = binary_op(EQUALS, _33980, _33981);
    }
    _33980 = NOVALUE;
    _33981 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33982;
    if( _1 != _33982 ){
        DeRef(_1);
    }
    _33982 = NOVALUE;

    /** execute.e:2466		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2467	end procedure*/
    _33976 = NOVALUE;
    _33978 = NOVALUE;
    _33974 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ()
{
    object _33992 = NOVALUE;
    object _33991 = NOVALUE;
    object _33990 = NOVALUE;
    object _33988 = NOVALUE;
    object _33986 = NOVALUE;
    object _33984 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2470		a = Code[pc+1]*/
    _33984 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33984);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2471		b = Code[pc+2]*/
    _33986 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33986);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2472		target = Code[pc+3]*/
    _33988 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33988);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2473		val[target] = val[a] != val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _33990 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _33991 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_33990) && IS_ATOM_INT(_33991)) {
        _33992 = (_33990 != _33991);
    }
    else {
        _33992 = binary_op(NOTEQ, _33990, _33991);
    }
    _33990 = NOVALUE;
    _33991 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33992;
    if( _1 != _33992 ){
        DeRef(_1);
    }
    _33992 = NOVALUE;

    /** execute.e:2474		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2475	end procedure*/
    _33988 = NOVALUE;
    _33986 = NOVALUE;
    _33984 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ()
{
    object _34002 = NOVALUE;
    object _34001 = NOVALUE;
    object _34000 = NOVALUE;
    object _33998 = NOVALUE;
    object _33996 = NOVALUE;
    object _33994 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2478		a = Code[pc+1]*/
    _33994 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _33994);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2479		b = Code[pc+2]*/
    _33996 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _33996);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2480		target = Code[pc+3]*/
    _33998 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _33998);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2481		val[target] = val[a] <= val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34000 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34001 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34000) && IS_ATOM_INT(_34001)) {
        _34002 = (_34000 <= _34001);
    }
    else {
        _34002 = binary_op(LESSEQ, _34000, _34001);
    }
    _34000 = NOVALUE;
    _34001 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34002;
    if( _1 != _34002 ){
        DeRef(_1);
    }
    _34002 = NOVALUE;

    /** execute.e:2482		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2483	end procedure*/
    _33996 = NOVALUE;
    _33994 = NOVALUE;
    _33998 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ()
{
    object _34012 = NOVALUE;
    object _34011 = NOVALUE;
    object _34010 = NOVALUE;
    object _34008 = NOVALUE;
    object _34006 = NOVALUE;
    object _34004 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2486		a = Code[pc+1]*/
    _34004 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34004);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2487		b = Code[pc+2]*/
    _34006 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34006);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2488		target = Code[pc+3]*/
    _34008 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34008);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2489		val[target] = val[a] >= val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34010 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34011 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34010) && IS_ATOM_INT(_34011)) {
        _34012 = (_34010 >= _34011);
    }
    else {
        _34012 = binary_op(GREATEREQ, _34010, _34011);
    }
    _34010 = NOVALUE;
    _34011 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34012;
    if( _1 != _34012 ){
        DeRef(_1);
    }
    _34012 = NOVALUE;

    /** execute.e:2490		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2491	end procedure*/
    _34004 = NOVALUE;
    _34008 = NOVALUE;
    _34006 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND()
{
    object _34022 = NOVALUE;
    object _34020 = NOVALUE;
    object _34019 = NOVALUE;
    object _34018 = NOVALUE;
    object _34016 = NOVALUE;
    object _34014 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2496		a = Code[pc+1]*/
    _34014 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34014);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2497		b = Code[pc+2]*/
    _34016 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34016);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2498		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34018 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34019 = IS_ATOM(_34018);
    _34018 = NOVALUE;
    if (_34019 == 0)
    {
        _34019 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _34019 = NOVALUE;
    }

    /** execute.e:2499			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34020 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(NOTEQ, _34020, 0)){
        _34020 = NOVALUE;
        goto L2; // [59] 104
    }
    _34020 = NOVALUE;

    /** execute.e:2500				val[b] = 0*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** execute.e:2501				pc = Code[pc+3]*/
    _34022 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34022);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:2502				return*/
    _34014 = NOVALUE;
    _34022 = NOVALUE;
    _34016 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2505			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33799);
    _67RTFatal(_33799);
L2: 

    /** execute.e:2507		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2508	end procedure*/
    DeRef(_34014);
    _34014 = NOVALUE;
    DeRef(_34022);
    _34022 = NOVALUE;
    DeRef(_34016);
    _34016 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND_IF()
{
    object _34033 = NOVALUE;
    object _34031 = NOVALUE;
    object _34030 = NOVALUE;
    object _34029 = NOVALUE;
    object _34027 = NOVALUE;
    object _34025 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2512		a = Code[pc+1]*/
    _34025 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34025);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2513		b = Code[pc+2]*/
    _34027 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34027);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2514		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34029 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34030 = IS_ATOM(_34029);
    _34029 = NOVALUE;
    if (_34030 == 0)
    {
        _34030 = NOVALUE;
        goto L1; // [46] 88
    }
    else{
        _34030 = NOVALUE;
    }

    /** execute.e:2515			if val[a] = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34031 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(NOTEQ, _34031, 0)){
        _34031 = NOVALUE;
        goto L2; // [59] 94
    }
    _34031 = NOVALUE;

    /** execute.e:2516				pc = Code[pc+3]*/
    _34033 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34033);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:2517				return*/
    _34033 = NOVALUE;
    _34027 = NOVALUE;
    _34025 = NOVALUE;
    return;
    goto L2; // [85] 94
L1: 

    /** execute.e:2520			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33799);
    _67RTFatal(_33799);
L2: 

    /** execute.e:2522		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2523	end procedure*/
    DeRef(_34033);
    _34033 = NOVALUE;
    DeRef(_34027);
    _34027 = NOVALUE;
    DeRef(_34025);
    _34025 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR()
{
    object _34044 = NOVALUE;
    object _34042 = NOVALUE;
    object _34041 = NOVALUE;
    object _34040 = NOVALUE;
    object _34038 = NOVALUE;
    object _34036 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2526		a = Code[pc+1]*/
    _34036 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34036);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2527		b = Code[pc+2]*/
    _34038 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34038);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2528		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34040 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34041 = IS_ATOM(_34040);
    _34040 = NOVALUE;
    if (_34041 == 0)
    {
        _34041 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _34041 = NOVALUE;
    }

    /** execute.e:2529			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34042 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(EQUALS, _34042, 0)){
        _34042 = NOVALUE;
        goto L2; // [59] 104
    }
    _34042 = NOVALUE;

    /** execute.e:2530				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** execute.e:2531				pc = Code[pc+3]*/
    _34044 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34044);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:2532				return*/
    _34038 = NOVALUE;
    _34036 = NOVALUE;
    _34044 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2535			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33799);
    _67RTFatal(_33799);
L2: 

    /** execute.e:2537		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2538	end procedure*/
    DeRef(_34038);
    _34038 = NOVALUE;
    DeRef(_34036);
    _34036 = NOVALUE;
    DeRef(_34044);
    _34044 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR_IF()
{
    object _34055 = NOVALUE;
    object _34053 = NOVALUE;
    object _34052 = NOVALUE;
    object _34051 = NOVALUE;
    object _34049 = NOVALUE;
    object _34047 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2542		a = Code[pc+1]*/
    _34047 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34047);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2543		b = Code[pc+2]*/
    _34049 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34049);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2544		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34051 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34052 = IS_ATOM(_34051);
    _34051 = NOVALUE;
    if (_34052 == 0)
    {
        _34052 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _34052 = NOVALUE;
    }

    /** execute.e:2545			if val[a] != 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34053 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(EQUALS, _34053, 0)){
        _34053 = NOVALUE;
        goto L2; // [59] 104
    }
    _34053 = NOVALUE;

    /** execute.e:2546				val[b] = 1*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** execute.e:2547				pc = Code[pc+3]*/
    _34055 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34055);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }

    /** execute.e:2548				return*/
    _34047 = NOVALUE;
    _34049 = NOVALUE;
    _34055 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** execute.e:2551			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33799);
    _67RTFatal(_33799);
L2: 

    /** execute.e:2553		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2554	end procedure*/
    DeRef(_34047);
    _34047 = NOVALUE;
    DeRef(_34049);
    _34049 = NOVALUE;
    DeRef(_34055);
    _34055 = NOVALUE;
    return;
    ;
}


void _67opSC2_OR()
{
    object _34064 = NOVALUE;
    object _34063 = NOVALUE;
    object _34062 = NOVALUE;
    object _34060 = NOVALUE;
    object _34058 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2559		a = Code[pc+1]*/
    _34058 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34058);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2560		b = Code[pc+2]*/
    _34060 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34060);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2561		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34062 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34063 = IS_ATOM(_34062);
    _34062 = NOVALUE;
    if (_34063 == 0)
    {
        _34063 = NOVALUE;
        goto L1; // [46] 70
    }
    else{
        _34063 = NOVALUE;
    }

    /** execute.e:2562			val[b] = val[a]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34064 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_34064);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34064;
    if( _1 != _34064 ){
        DeRef(_1);
    }
    _34064 = NOVALUE;
    goto L2; // [67] 76
L1: 

    /** execute.e:2564			RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33799);
    _67RTFatal(_33799);
L2: 

    /** execute.e:2566		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:2567	end procedure*/
    DeRef(_34058);
    _34058 = NOVALUE;
    DeRef(_34060);
    _34060 = NOVALUE;
    return;
    ;
}


void _67opFOR()
{
    object _increment_68613 = NOVALUE;
    object _limit_68614 = NOVALUE;
    object _initial_68615 = NOVALUE;
    object _loopvar_68616 = NOVALUE;
    object _jump_68617 = NOVALUE;
    object _34094 = NOVALUE;
    object _34092 = NOVALUE;
    object _34091 = NOVALUE;
    object _34089 = NOVALUE;
    object _34088 = NOVALUE;
    object _34086 = NOVALUE;
    object _34083 = NOVALUE;
    object _34082 = NOVALUE;
    object _34080 = NOVALUE;
    object _34079 = NOVALUE;
    object _34077 = NOVALUE;
    object _34076 = NOVALUE;
    object _34074 = NOVALUE;
    object _34072 = NOVALUE;
    object _34070 = NOVALUE;
    object _34068 = NOVALUE;
    object _34066 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2576		increment = Code[pc+1]*/
    _34066 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _increment_68613 = (object)*(((s1_ptr)_2)->base + _34066);
    if (!IS_ATOM_INT(_increment_68613)){
        _increment_68613 = (object)DBL_PTR(_increment_68613)->dbl;
    }

    /** execute.e:2577		limit = Code[pc+2]*/
    _34068 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _limit_68614 = (object)*(((s1_ptr)_2)->base + _34068);
    if (!IS_ATOM_INT(_limit_68614)){
        _limit_68614 = (object)DBL_PTR(_limit_68614)->dbl;
    }

    /** execute.e:2578		initial = Code[pc+3]*/
    _34070 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _initial_68615 = (object)*(((s1_ptr)_2)->base + _34070);
    if (!IS_ATOM_INT(_initial_68615)){
        _initial_68615 = (object)DBL_PTR(_initial_68615)->dbl;
    }

    /** execute.e:2581		loopvar = Code[pc+5]*/
    _34072 = _67pc_65255 + 5;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _loopvar_68616 = (object)*(((s1_ptr)_2)->base + _34072);
    if (!IS_ATOM_INT(_loopvar_68616)){
        _loopvar_68616 = (object)DBL_PTR(_loopvar_68616)->dbl;
    }

    /** execute.e:2582		jump = Code[pc+6]*/
    _34074 = _67pc_65255 + 6;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _jump_68617 = (object)*(((s1_ptr)_2)->base + _34074);
    if (!IS_ATOM_INT(_jump_68617)){
        _jump_68617 = (object)DBL_PTR(_jump_68617)->dbl;
    }

    /** execute.e:2584		if sequence(val[initial]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34076 = (object)*(((s1_ptr)_2)->base + _initial_68615);
    _34077 = IS_SEQUENCE(_34076);
    _34076 = NOVALUE;
    if (_34077 == 0)
    {
        _34077 = NOVALUE;
        goto L1; // [92] 101
    }
    else{
        _34077 = NOVALUE;
    }

    /** execute.e:2585			RTFatal("for-loop variable is not an atom")*/
    RefDS(_34078);
    _67RTFatal(_34078);
L1: 

    /** execute.e:2587		if sequence(val[limit]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34079 = (object)*(((s1_ptr)_2)->base + _limit_68614);
    _34080 = IS_SEQUENCE(_34079);
    _34079 = NOVALUE;
    if (_34080 == 0)
    {
        _34080 = NOVALUE;
        goto L2; // [112] 121
    }
    else{
        _34080 = NOVALUE;
    }

    /** execute.e:2588			RTFatal("for-loop limit is not an atom")*/
    RefDS(_34081);
    _67RTFatal(_34081);
L2: 

    /** execute.e:2590		if sequence(val[increment]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34082 = (object)*(((s1_ptr)_2)->base + _increment_68613);
    _34083 = IS_SEQUENCE(_34082);
    _34082 = NOVALUE;
    if (_34083 == 0)
    {
        _34083 = NOVALUE;
        goto L3; // [132] 141
    }
    else{
        _34083 = NOVALUE;
    }

    /** execute.e:2591			RTFatal("for-loop increment is not an atom")*/
    RefDS(_34084);
    _67RTFatal(_34084);
L3: 

    /** execute.e:2594		pc += 7 -- to enter into the loop*/
    _67pc_65255 = _67pc_65255 + 7;

    /** execute.e:2596		if val[increment] >= 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34086 = (object)*(((s1_ptr)_2)->base + _increment_68613);
    if (binary_op_a(LESS, _34086, 0)){
        _34086 = NOVALUE;
        goto L4; // [157] 188
    }
    _34086 = NOVALUE;

    /** execute.e:2598			if val[initial] > val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34088 = (object)*(((s1_ptr)_2)->base + _initial_68615);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34089 = (object)*(((s1_ptr)_2)->base + _limit_68614);
    if (binary_op_a(LESSEQ, _34088, _34089)){
        _34088 = NOVALUE;
        _34089 = NOVALUE;
        goto L5; // [175] 213
    }
    _34088 = NOVALUE;
    _34089 = NOVALUE;

    /** execute.e:2599				pc = jump -- quit immediately, 0 iterations*/
    _67pc_65255 = _jump_68617;
    goto L5; // [185] 213
L4: 

    /** execute.e:2603			if val[initial] < val[limit] then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34091 = (object)*(((s1_ptr)_2)->base + _initial_68615);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34092 = (object)*(((s1_ptr)_2)->base + _limit_68614);
    if (binary_op_a(GREATEREQ, _34091, _34092)){
        _34091 = NOVALUE;
        _34092 = NOVALUE;
        goto L6; // [202] 212
    }
    _34091 = NOVALUE;
    _34092 = NOVALUE;

    /** execute.e:2604				pc = jump -- quit immediately, 0 iterations*/
    _67pc_65255 = _jump_68617;
L6: 
L5: 

    /** execute.e:2608		val[loopvar] = val[initial] -- initialize loop var*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34094 = (object)*(((s1_ptr)_2)->base + _initial_68615);
    Ref(_34094);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68616);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34094;
    if( _1 != _34094 ){
        DeRef(_1);
    }
    _34094 = NOVALUE;

    /** execute.e:2610	end procedure*/
    DeRef(_34068);
    _34068 = NOVALUE;
    DeRef(_34074);
    _34074 = NOVALUE;
    DeRef(_34072);
    _34072 = NOVALUE;
    DeRef(_34066);
    _34066 = NOVALUE;
    DeRef(_34070);
    _34070 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_GENERAL()
{
    object _loopvar_68661 = NOVALUE;
    object _increment_68662 = NOVALUE;
    object _limit_68663 = NOVALUE;
    object _next_68664 = NOVALUE;
    object _34112 = NOVALUE;
    object _34108 = NOVALUE;
    object _34103 = NOVALUE;
    object _34101 = NOVALUE;
    object _34099 = NOVALUE;
    object _34098 = NOVALUE;
    object _34096 = NOVALUE;
    object _34095 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2619		limit = val[Code[pc+2]]*/
    _34095 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34096 = (object)*(((s1_ptr)_2)->base + _34095);
    DeRef(_limit_68663);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34096)){
        _limit_68663 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34096)->dbl));
    }
    else{
        _limit_68663 = (object)*(((s1_ptr)_2)->base + _34096);
    }
    Ref(_limit_68663);

    /** execute.e:2620		increment = val[Code[pc+4]]*/
    _34098 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34099 = (object)*(((s1_ptr)_2)->base + _34098);
    DeRef(_increment_68662);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34099)){
        _increment_68662 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34099)->dbl));
    }
    else{
        _increment_68662 = (object)*(((s1_ptr)_2)->base + _34099);
    }
    Ref(_increment_68662);

    /** execute.e:2621		loopvar = Code[pc+3]*/
    _34101 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _loopvar_68661 = (object)*(((s1_ptr)_2)->base + _34101);
    if (!IS_ATOM_INT(_loopvar_68661)){
        _loopvar_68661 = (object)DBL_PTR(_loopvar_68661)->dbl;
    }

    /** execute.e:2622		next = val[loopvar] + increment*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34103 = (object)*(((s1_ptr)_2)->base + _loopvar_68661);
    DeRef(_next_68664);
    if (IS_ATOM_INT(_34103) && IS_ATOM_INT(_increment_68662)) {
        _next_68664 = _34103 + _increment_68662;
        if ((object)((uintptr_t)_next_68664 + (uintptr_t)HIGH_BITS) >= 0){
            _next_68664 = NewDouble((eudouble)_next_68664);
        }
    }
    else {
        _next_68664 = binary_op(PLUS, _34103, _increment_68662);
    }
    _34103 = NOVALUE;

    /** execute.e:2624		if increment >= 0 then*/
    if (binary_op_a(LESS, _increment_68662, 0)){
        goto L1; // [71] 120
    }

    /** execute.e:2626			if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68664, _limit_68663)){
        goto L2; // [77] 92
    }

    /** execute.e:2627				pc += 5 -- exit loop*/
    _67pc_65255 = _67pc_65255 + 5;
    goto L3; // [89] 163
L2: 

    /** execute.e:2629				val[loopvar] = next*/
    Ref(_next_68664);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68661);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68664;
    DeRef(_1);

    /** execute.e:2630				pc = Code[pc+1] -- loop again*/
    _34108 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34108);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
    goto L3; // [117] 163
L1: 

    /** execute.e:2634			if next < limit then*/
    if (binary_op_a(GREATEREQ, _next_68664, _limit_68663)){
        goto L4; // [122] 137
    }

    /** execute.e:2635				pc += 5 -- exit loop*/
    _67pc_65255 = _67pc_65255 + 5;
    goto L5; // [134] 162
L4: 

    /** execute.e:2637				val[loopvar] = next*/
    Ref(_next_68664);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68661);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68664;
    DeRef(_1);

    /** execute.e:2638				pc = Code[pc+1] -- loop again*/
    _34112 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34112);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L5: 
L3: 

    /** execute.e:2641	end procedure*/
    DeRef(_increment_68662);
    DeRef(_limit_68663);
    DeRef(_next_68664);
    DeRef(_34108);
    _34108 = NOVALUE;
    DeRef(_34101);
    _34101 = NOVALUE;
    DeRef(_34095);
    _34095 = NOVALUE;
    _34096 = NOVALUE;
    _34099 = NOVALUE;
    DeRef(_34098);
    _34098 = NOVALUE;
    DeRef(_34112);
    _34112 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_INT_UP1()
{
    object _loopvar_68697 = NOVALUE;
    object _limit_68698 = NOVALUE;
    object _next_68699 = NOVALUE;
    object _34123 = NOVALUE;
    object _34119 = NOVALUE;
    object _34117 = NOVALUE;
    object _34115 = NOVALUE;
    object _34114 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2651		limit = val[Code[pc+2]]*/
    _34114 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34115 = (object)*(((s1_ptr)_2)->base + _34114);
    DeRef(_limit_68698);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34115)){
        _limit_68698 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34115)->dbl));
    }
    else{
        _limit_68698 = (object)*(((s1_ptr)_2)->base + _34115);
    }
    Ref(_limit_68698);

    /** execute.e:2652		loopvar = Code[pc+3]*/
    _34117 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _loopvar_68697 = (object)*(((s1_ptr)_2)->base + _34117);
    if (!IS_ATOM_INT(_loopvar_68697)){
        _loopvar_68697 = (object)DBL_PTR(_loopvar_68697)->dbl;
    }

    /** execute.e:2653		next = val[loopvar] + 1*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34119 = (object)*(((s1_ptr)_2)->base + _loopvar_68697);
    DeRef(_next_68699);
    if (IS_ATOM_INT(_34119)) {
        _next_68699 = _34119 + 1;
        if (_next_68699 > MAXINT){
            _next_68699 = NewDouble((eudouble)_next_68699);
        }
    }
    else
    _next_68699 = binary_op(PLUS, 1, _34119);
    _34119 = NOVALUE;

    /** execute.e:2656		if next > limit then*/
    if (binary_op_a(LESSEQ, _next_68699, _limit_68698)){
        goto L1; // [51] 66
    }

    /** execute.e:2657			pc += 5 -- exit loop*/
    _67pc_65255 = _67pc_65255 + 5;
    goto L2; // [63] 91
L1: 

    /** execute.e:2659			val[loopvar] = next*/
    Ref(_next_68699);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _loopvar_68697);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _next_68699;
    DeRef(_1);

    /** execute.e:2660			pc = Code[pc+1] -- loop again*/
    _34123 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34123);
    if (!IS_ATOM_INT(_67pc_65255)){
        _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;
    }
L2: 

    /** execute.e:2662	end procedure*/
    DeRef(_limit_68698);
    DeRef(_next_68699);
    DeRef(_34114);
    _34114 = NOVALUE;
    DeRef(_34117);
    _34117 = NOVALUE;
    _34115 = NOVALUE;
    DeRef(_34123);
    _34123 = NOVALUE;
    return;
    ;
}


object _67RTLookup(object _name_68718, object _file_68719, object _proc_68721, object _stlen_68722)
{
    object _s_68724 = NOVALUE;
    object _global_found_68725 = NOVALUE;
    object _ns_68726 = NOVALUE;
    object _colon_68727 = NOVALUE;
    object _ns_file_68728 = NOVALUE;
    object _found_in_path_68729 = NOVALUE;
    object _found_outside_path_68730 = NOVALUE;
    object _s_in_include_path_68731 = NOVALUE;
    object _scope_68828 = NOVALUE;
    object _34352 = NOVALUE;
    object _34351 = NOVALUE;
    object _34350 = NOVALUE;
    object _34349 = NOVALUE;
    object _34347 = NOVALUE;
    object _34345 = NOVALUE;
    object _34344 = NOVALUE;
    object _34343 = NOVALUE;
    object _34342 = NOVALUE;
    object _34341 = NOVALUE;
    object _34340 = NOVALUE;
    object _34339 = NOVALUE;
    object _34338 = NOVALUE;
    object _34337 = NOVALUE;
    object _34336 = NOVALUE;
    object _34335 = NOVALUE;
    object _34334 = NOVALUE;
    object _34332 = NOVALUE;
    object _34331 = NOVALUE;
    object _34330 = NOVALUE;
    object _34329 = NOVALUE;
    object _34328 = NOVALUE;
    object _34327 = NOVALUE;
    object _34326 = NOVALUE;
    object _34325 = NOVALUE;
    object _34324 = NOVALUE;
    object _34323 = NOVALUE;
    object _34322 = NOVALUE;
    object _34321 = NOVALUE;
    object _34316 = NOVALUE;
    object _34315 = NOVALUE;
    object _34314 = NOVALUE;
    object _34313 = NOVALUE;
    object _34312 = NOVALUE;
    object _34311 = NOVALUE;
    object _34310 = NOVALUE;
    object _34309 = NOVALUE;
    object _34308 = NOVALUE;
    object _34307 = NOVALUE;
    object _34306 = NOVALUE;
    object _34305 = NOVALUE;
    object _34304 = NOVALUE;
    object _34303 = NOVALUE;
    object _34302 = NOVALUE;
    object _34301 = NOVALUE;
    object _34300 = NOVALUE;
    object _34299 = NOVALUE;
    object _34297 = NOVALUE;
    object _34295 = NOVALUE;
    object _34294 = NOVALUE;
    object _34293 = NOVALUE;
    object _34292 = NOVALUE;
    object _34291 = NOVALUE;
    object _34290 = NOVALUE;
    object _34289 = NOVALUE;
    object _34288 = NOVALUE;
    object _34287 = NOVALUE;
    object _34286 = NOVALUE;
    object _34285 = NOVALUE;
    object _34284 = NOVALUE;
    object _34283 = NOVALUE;
    object _34282 = NOVALUE;
    object _34281 = NOVALUE;
    object _34280 = NOVALUE;
    object _34279 = NOVALUE;
    object _34278 = NOVALUE;
    object _34277 = NOVALUE;
    object _34276 = NOVALUE;
    object _34275 = NOVALUE;
    object _34274 = NOVALUE;
    object _34273 = NOVALUE;
    object _34272 = NOVALUE;
    object _34271 = NOVALUE;
    object _34270 = NOVALUE;
    object _34269 = NOVALUE;
    object _34268 = NOVALUE;
    object _34267 = NOVALUE;
    object _34266 = NOVALUE;
    object _34265 = NOVALUE;
    object _34264 = NOVALUE;
    object _34263 = NOVALUE;
    object _34261 = NOVALUE;
    object _34259 = NOVALUE;
    object _34258 = NOVALUE;
    object _34257 = NOVALUE;
    object _34256 = NOVALUE;
    object _34255 = NOVALUE;
    object _34254 = NOVALUE;
    object _34253 = NOVALUE;
    object _34252 = NOVALUE;
    object _34251 = NOVALUE;
    object _34250 = NOVALUE;
    object _34249 = NOVALUE;
    object _34248 = NOVALUE;
    object _34246 = NOVALUE;
    object _34243 = NOVALUE;
    object _34242 = NOVALUE;
    object _34241 = NOVALUE;
    object _34240 = NOVALUE;
    object _34239 = NOVALUE;
    object _34238 = NOVALUE;
    object _34237 = NOVALUE;
    object _34236 = NOVALUE;
    object _34235 = NOVALUE;
    object _34234 = NOVALUE;
    object _34233 = NOVALUE;
    object _34232 = NOVALUE;
    object _34231 = NOVALUE;
    object _34230 = NOVALUE;
    object _34229 = NOVALUE;
    object _34228 = NOVALUE;
    object _34227 = NOVALUE;
    object _34226 = NOVALUE;
    object _34225 = NOVALUE;
    object _34224 = NOVALUE;
    object _34223 = NOVALUE;
    object _34222 = NOVALUE;
    object _34221 = NOVALUE;
    object _34220 = NOVALUE;
    object _34219 = NOVALUE;
    object _34218 = NOVALUE;
    object _34217 = NOVALUE;
    object _34216 = NOVALUE;
    object _34215 = NOVALUE;
    object _34214 = NOVALUE;
    object _34213 = NOVALUE;
    object _34212 = NOVALUE;
    object _34211 = NOVALUE;
    object _34210 = NOVALUE;
    object _34209 = NOVALUE;
    object _34208 = NOVALUE;
    object _34207 = NOVALUE;
    object _34206 = NOVALUE;
    object _34205 = NOVALUE;
    object _34204 = NOVALUE;
    object _34203 = NOVALUE;
    object _34202 = NOVALUE;
    object _34201 = NOVALUE;
    object _34200 = NOVALUE;
    object _34199 = NOVALUE;
    object _34198 = NOVALUE;
    object _34197 = NOVALUE;
    object _34196 = NOVALUE;
    object _34195 = NOVALUE;
    object _34193 = NOVALUE;
    object _34192 = NOVALUE;
    object _34191 = NOVALUE;
    object _34190 = NOVALUE;
    object _34189 = NOVALUE;
    object _34188 = NOVALUE;
    object _34187 = NOVALUE;
    object _34186 = NOVALUE;
    object _34184 = NOVALUE;
    object _34182 = NOVALUE;
    object _34181 = NOVALUE;
    object _34180 = NOVALUE;
    object _34179 = NOVALUE;
    object _34178 = NOVALUE;
    object _34177 = NOVALUE;
    object _34176 = NOVALUE;
    object _34175 = NOVALUE;
    object _34171 = NOVALUE;
    object _34170 = NOVALUE;
    object _34169 = NOVALUE;
    object _34168 = NOVALUE;
    object _34167 = NOVALUE;
    object _34166 = NOVALUE;
    object _34165 = NOVALUE;
    object _34164 = NOVALUE;
    object _34163 = NOVALUE;
    object _34162 = NOVALUE;
    object _34161 = NOVALUE;
    object _34160 = NOVALUE;
    object _34157 = NOVALUE;
    object _34156 = NOVALUE;
    object _34154 = NOVALUE;
    object _34153 = NOVALUE;
    object _34151 = NOVALUE;
    object _34150 = NOVALUE;
    object _34149 = NOVALUE;
    object _34148 = NOVALUE;
    object _34147 = NOVALUE;
    object _34146 = NOVALUE;
    object _34145 = NOVALUE;
    object _34144 = NOVALUE;
    object _34142 = NOVALUE;
    object _34141 = NOVALUE;
    object _34140 = NOVALUE;
    object _34139 = NOVALUE;
    object _34138 = NOVALUE;
    object _34137 = NOVALUE;
    object _34136 = NOVALUE;
    object _34135 = NOVALUE;
    object _34134 = NOVALUE;
    object _34133 = NOVALUE;
    object _34132 = NOVALUE;
    object _34130 = NOVALUE;
    object _34129 = NOVALUE;
    object _34127 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2673		sequence ns*/

    /** execute.e:2674		integer colon*/

    /** execute.e:2675		integer ns_file*/

    /** execute.e:2676		integer found_in_path*/

    /** execute.e:2677		integer found_outside_path*/

    /** execute.e:2678		integer s_in_include_path*/

    /** execute.e:2680		stlen = length( SymTab )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _stlen_68722 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _stlen_68722 = 1;
    }

    /** execute.e:2681		colon = find(':', name)*/
    _colon_68727 = find_from(58, _name_68718, 1);

    /** execute.e:2683		if colon then*/
    if (_colon_68727 == 0)
    {
        goto L1; // [37] 827
    }
    else{
    }

    /** execute.e:2685			ns = name[1..colon-1]*/
    _34127 = _colon_68727 - 1;
    rhs_slice_target = (object_ptr)&_ns_68726;
    RHS_Slice(_name_68718, 1, _34127);

    /** execute.e:2686			name = name[colon+1..$]*/
    _34129 = _colon_68727 + 1;
    if (IS_SEQUENCE(_name_68718)){
            _34130 = SEQ_PTR(_name_68718)->length;
    }
    else {
        _34130 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68718;
    RHS_Slice(_name_68718, _34129, _34130);

    /** execute.e:2689			while length(ns) and (ns[$] = ' ' or ns[$] = '\t') do*/
L2: 
    if (IS_SEQUENCE(_ns_68726)){
            _34132 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34132 = 1;
    }
    if (_34132 == 0) {
        goto L3; // [73] 130
    }
    if (IS_SEQUENCE(_ns_68726)){
            _34134 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34134 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68726);
    _34135 = (object)*(((s1_ptr)_2)->base + _34134);
    if (IS_ATOM_INT(_34135)) {
        _34136 = (_34135 == 32);
    }
    else {
        _34136 = binary_op(EQUALS, _34135, 32);
    }
    _34135 = NOVALUE;
    if (IS_ATOM_INT(_34136)) {
        if (_34136 != 0) {
            DeRef(_34137);
            _34137 = 1;
            goto L4; // [88] 107
        }
    }
    else {
        if (DBL_PTR(_34136)->dbl != 0.0) {
            DeRef(_34137);
            _34137 = 1;
            goto L4; // [88] 107
        }
    }
    if (IS_SEQUENCE(_ns_68726)){
            _34138 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34138 = 1;
    }
    _2 = (object)SEQ_PTR(_ns_68726);
    _34139 = (object)*(((s1_ptr)_2)->base + _34138);
    if (IS_ATOM_INT(_34139)) {
        _34140 = (_34139 == 9);
    }
    else {
        _34140 = binary_op(EQUALS, _34139, 9);
    }
    _34139 = NOVALUE;
    DeRef(_34137);
    if (IS_ATOM_INT(_34140))
    _34137 = (_34140 != 0);
    else
    _34137 = DBL_PTR(_34140)->dbl != 0.0;
L4: 
    if (_34137 == 0)
    {
        _34137 = NOVALUE;
        goto L3; // [108] 130
    }
    else{
        _34137 = NOVALUE;
    }

    /** execute.e:2690				ns = ns[1..$-1]*/
    if (IS_SEQUENCE(_ns_68726)){
            _34141 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34141 = 1;
    }
    _34142 = _34141 - 1;
    _34141 = NOVALUE;
    rhs_slice_target = (object_ptr)&_ns_68726;
    RHS_Slice(_ns_68726, 1, _34142);

    /** execute.e:2691			end while*/
    goto L2; // [127] 70
L3: 

    /** execute.e:2694			while length(ns) and (ns[1] = ' ' or ns[1] = '\t') do*/
L5: 
    if (IS_SEQUENCE(_ns_68726)){
            _34144 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34144 = 1;
    }
    if (_34144 == 0) {
        goto L6; // [138] 185
    }
    _2 = (object)SEQ_PTR(_ns_68726);
    _34146 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_34146)) {
        _34147 = (_34146 == 32);
    }
    else {
        _34147 = binary_op(EQUALS, _34146, 32);
    }
    _34146 = NOVALUE;
    if (IS_ATOM_INT(_34147)) {
        if (_34147 != 0) {
            DeRef(_34148);
            _34148 = 1;
            goto L7; // [150] 166
        }
    }
    else {
        if (DBL_PTR(_34147)->dbl != 0.0) {
            DeRef(_34148);
            _34148 = 1;
            goto L7; // [150] 166
        }
    }
    _2 = (object)SEQ_PTR(_ns_68726);
    _34149 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_34149)) {
        _34150 = (_34149 == 9);
    }
    else {
        _34150 = binary_op(EQUALS, _34149, 9);
    }
    _34149 = NOVALUE;
    DeRef(_34148);
    if (IS_ATOM_INT(_34150))
    _34148 = (_34150 != 0);
    else
    _34148 = DBL_PTR(_34150)->dbl != 0.0;
L7: 
    if (_34148 == 0)
    {
        _34148 = NOVALUE;
        goto L6; // [167] 185
    }
    else{
        _34148 = NOVALUE;
    }

    /** execute.e:2695				ns = ns[2..$]*/
    if (IS_SEQUENCE(_ns_68726)){
            _34151 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34151 = 1;
    }
    rhs_slice_target = (object_ptr)&_ns_68726;
    RHS_Slice(_ns_68726, 2, _34151);

    /** execute.e:2696			end while*/
    goto L5; // [182] 135
L6: 

    /** execute.e:2698			if length(ns) = 0 or equal( ns, "eu") then*/
    if (IS_SEQUENCE(_ns_68726)){
            _34153 = SEQ_PTR(_ns_68726)->length;
    }
    else {
        _34153 = 1;
    }
    _34154 = (_34153 == 0);
    _34153 = NOVALUE;
    if (_34154 != 0) {
        goto L8; // [194] 207
    }
    if (_ns_68726 == _23896)
    _34156 = 1;
    else if (IS_ATOM_INT(_ns_68726) && IS_ATOM_INT(_23896))
    _34156 = 0;
    else
    _34156 = (compare(_ns_68726, _23896) == 0);
    if (_34156 == 0)
    {
        _34156 = NOVALUE;
        goto L9; // [203] 214
    }
    else{
        _34156 = NOVALUE;
    }
L8: 

    /** execute.e:2699				return 0 -- bad syntax*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    return 0;
L9: 

    /** execute.e:2703			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34157 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34157);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34157 = NOVALUE;

    /** execute.e:2704			while s != 0 do*/
LA: 
    if (_s_68724 == 0)
    goto LB; // [237] 335

    /** execute.e:2705				if file = SymTab[s][S_FILE_NO] and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34160 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34160);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34161 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34161 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34160 = NOVALUE;
    if (IS_ATOM_INT(_34161)) {
        _34162 = (_file_68719 == _34161);
    }
    else {
        _34162 = binary_op(EQUALS, _file_68719, _34161);
    }
    _34161 = NOVALUE;
    if (IS_ATOM_INT(_34162)) {
        if (_34162 == 0) {
            DeRef(_34163);
            _34163 = 0;
            goto LC; // [259] 285
        }
    }
    else {
        if (DBL_PTR(_34162)->dbl == 0.0) {
            DeRef(_34163);
            _34163 = 0;
            goto LC; // [259] 285
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34164 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34164);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34165 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34165 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34164 = NOVALUE;
    if (IS_ATOM_INT(_34165)) {
        _34166 = (_34165 == 523);
    }
    else {
        _34166 = binary_op(EQUALS, _34165, 523);
    }
    _34165 = NOVALUE;
    DeRef(_34163);
    if (IS_ATOM_INT(_34166))
    _34163 = (_34166 != 0);
    else
    _34163 = DBL_PTR(_34166)->dbl != 0.0;
LC: 
    if (_34163 == 0) {
        goto LD; // [285] 314
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34168 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34168);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34169 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34169 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34168 = NOVALUE;
    if (_ns_68726 == _34169)
    _34170 = 1;
    else if (IS_ATOM_INT(_ns_68726) && IS_ATOM_INT(_34169))
    _34170 = 0;
    else
    _34170 = (compare(_ns_68726, _34169) == 0);
    _34169 = NOVALUE;
    if (_34170 == 0)
    {
        _34170 = NOVALUE;
        goto LD; // [306] 314
    }
    else{
        _34170 = NOVALUE;
    }

    /** execute.e:2708					exit*/
    goto LB; // [311] 335
LD: 

    /** execute.e:2710				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34171 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34171);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34171 = NOVALUE;

    /** execute.e:2711			end while*/
    goto LA; // [332] 237
LB: 

    /** execute.e:2713			if s = 0 then*/
    if (_s_68724 != 0)
    goto LE; // [337] 348

    /** execute.e:2714				return 0 -- couldn't find ns*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    return 0;
LE: 

    /** execute.e:2717			ns_file = val[s]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _ns_file_68728 = (object)*(((s1_ptr)_2)->base + _s_68724);
    if (!IS_ATOM_INT(_ns_file_68728))
    _ns_file_68728 = (object)DBL_PTR(_ns_file_68728)->dbl;

    /** execute.e:2720			while length(name) and (name[1] = ' ' or name[1] = '\t') do*/
LF: 
    if (IS_SEQUENCE(_name_68718)){
            _34175 = SEQ_PTR(_name_68718)->length;
    }
    else {
        _34175 = 1;
    }
    if (_34175 == 0) {
        goto L10; // [364] 411
    }
    _2 = (object)SEQ_PTR(_name_68718);
    _34177 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_34177)) {
        _34178 = (_34177 == 32);
    }
    else {
        _34178 = binary_op(EQUALS, _34177, 32);
    }
    _34177 = NOVALUE;
    if (IS_ATOM_INT(_34178)) {
        if (_34178 != 0) {
            DeRef(_34179);
            _34179 = 1;
            goto L11; // [376] 392
        }
    }
    else {
        if (DBL_PTR(_34178)->dbl != 0.0) {
            DeRef(_34179);
            _34179 = 1;
            goto L11; // [376] 392
        }
    }
    _2 = (object)SEQ_PTR(_name_68718);
    _34180 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_34180)) {
        _34181 = (_34180 == 9);
    }
    else {
        _34181 = binary_op(EQUALS, _34180, 9);
    }
    _34180 = NOVALUE;
    DeRef(_34179);
    if (IS_ATOM_INT(_34181))
    _34179 = (_34181 != 0);
    else
    _34179 = DBL_PTR(_34181)->dbl != 0.0;
L11: 
    if (_34179 == 0)
    {
        _34179 = NOVALUE;
        goto L10; // [393] 411
    }
    else{
        _34179 = NOVALUE;
    }

    /** execute.e:2721				name = name[2..$]*/
    if (IS_SEQUENCE(_name_68718)){
            _34182 = SEQ_PTR(_name_68718)->length;
    }
    else {
        _34182 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_68718;
    RHS_Slice(_name_68718, 2, _34182);

    /** execute.e:2722			end while*/
    goto LF; // [408] 361
L10: 

    /** execute.e:2725			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34184 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34184);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34184 = NOVALUE;

    /** execute.e:2726			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L12: 
    _34186 = (_s_68724 != 0);
    if (_34186 == 0) {
        goto L13; // [438] 818
    }
    _34188 = (_s_68724 <= _stlen_68722);
    if (_34188 != 0) {
        DeRef(_34189);
        _34189 = 1;
        goto L14; // [446] 472
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34190 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34190);
    _34191 = (object)*(((s1_ptr)_2)->base + 4);
    _34190 = NOVALUE;
    if (IS_ATOM_INT(_34191)) {
        _34192 = (_34191 == 3);
    }
    else {
        _34192 = binary_op(EQUALS, _34191, 3);
    }
    _34191 = NOVALUE;
    if (IS_ATOM_INT(_34192))
    _34189 = (_34192 != 0);
    else
    _34189 = DBL_PTR(_34192)->dbl != 0.0;
L14: 
    if (_34189 == 0)
    {
        _34189 = NOVALUE;
        goto L13; // [473] 818
    }
    else{
        _34189 = NOVALUE;
    }

    /** execute.e:2727				integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34193 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34193);
    _scope_68828 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_68828)){
        _scope_68828 = (object)DBL_PTR(_scope_68828)->dbl;
    }
    _34193 = NOVALUE;

    /** execute.e:2728				if (((scope = SC_PUBLIC) and*/
    _34195 = (_scope_68828 == 13);
    if (_34195 == 0) {
        _34196 = 0;
        goto L15; // [500] 584
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34197 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34197);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34198 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34198 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34197 = NOVALUE;
    if (IS_ATOM_INT(_34198)) {
        _34199 = (_34198 == _ns_file_68728);
    }
    else {
        _34199 = binary_op(EQUALS, _34198, _ns_file_68728);
    }
    _34198 = NOVALUE;
    if (IS_ATOM_INT(_34199)) {
        if (_34199 != 0) {
            DeRef(_34200);
            _34200 = 1;
            goto L16; // [520] 580
        }
    }
    else {
        if (DBL_PTR(_34199)->dbl != 0.0) {
            DeRef(_34200);
            _34200 = 1;
            goto L16; // [520] 580
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34201 = (object)*(((s1_ptr)_2)->base + _ns_file_68728);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34202 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34202);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34203 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34203 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34202 = NOVALUE;
    _2 = (object)SEQ_PTR(_34201);
    if (!IS_ATOM_INT(_34203)){
        _34204 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34203)->dbl));
    }
    else{
        _34204 = (object)*(((s1_ptr)_2)->base + _34203);
    }
    _34201 = NOVALUE;
    if (IS_ATOM_INT(_34204)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 & (uintptr_t)_34204;
             _34205 = MAKE_UINT(tu);
        }
    }
    else {
        _34205 = binary_op(AND_BITS, 4, _34204);
    }
    _34204 = NOVALUE;
    if (IS_ATOM_INT(_34205)) {
        if (_34205 == 0) {
            DeRef(_34206);
            _34206 = 0;
            goto L17; // [552] 576
        }
    }
    else {
        if (DBL_PTR(_34205)->dbl == 0.0) {
            DeRef(_34206);
            _34206 = 0;
            goto L17; // [552] 576
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34207 = (object)*(((s1_ptr)_2)->base + _file_68719);
    _2 = (object)SEQ_PTR(_34207);
    _34208 = (object)*(((s1_ptr)_2)->base + _ns_file_68728);
    _34207 = NOVALUE;
    if (IS_ATOM_INT(_34208)) {
        {uintptr_t tu;
             tu = (uintptr_t)6 & (uintptr_t)_34208;
             _34209 = MAKE_UINT(tu);
        }
    }
    else {
        _34209 = binary_op(AND_BITS, 6, _34208);
    }
    _34208 = NOVALUE;
    DeRef(_34206);
    if (IS_ATOM_INT(_34209))
    _34206 = (_34209 != 0);
    else
    _34206 = DBL_PTR(_34209)->dbl != 0.0;
L17: 
    DeRef(_34200);
    _34200 = (_34206 != 0);
L16: 
    _34196 = (_34200 != 0);
L15: 
    if (_34196 != 0) {
        _34210 = 1;
        goto L18; // [584] 646
    }
    _34211 = (_scope_68828 == 11);
    if (_34211 == 0) {
        _34212 = 0;
        goto L19; // [594] 618
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34213 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34213);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34214 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34214 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34213 = NOVALUE;
    if (IS_ATOM_INT(_34214)) {
        _34215 = (_34214 == _ns_file_68728);
    }
    else {
        _34215 = binary_op(EQUALS, _34214, _ns_file_68728);
    }
    _34214 = NOVALUE;
    if (IS_ATOM_INT(_34215))
    _34212 = (_34215 != 0);
    else
    _34212 = DBL_PTR(_34215)->dbl != 0.0;
L19: 
    if (_34212 == 0) {
        _34216 = 0;
        goto L1A; // [618] 642
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34217 = (object)*(((s1_ptr)_2)->base + _file_68719);
    _2 = (object)SEQ_PTR(_34217);
    _34218 = (object)*(((s1_ptr)_2)->base + _ns_file_68728);
    _34217 = NOVALUE;
    if (IS_ATOM_INT(_34218)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 & (uintptr_t)_34218;
             _34219 = MAKE_UINT(tu);
        }
    }
    else {
        _34219 = binary_op(AND_BITS, 2, _34218);
    }
    _34218 = NOVALUE;
    if (IS_ATOM_INT(_34219))
    _34216 = (_34219 != 0);
    else
    _34216 = DBL_PTR(_34219)->dbl != 0.0;
L1A: 
    _34210 = (_34216 != 0);
L18: 
    if (_34210 != 0) {
        _34220 = 1;
        goto L1B; // [646] 660
    }
    _34221 = (_scope_68828 == 6);
    _34220 = (_34221 != 0);
L1B: 
    if (_34220 == 0) {
        _34222 = 0;
        goto L1C; // [660] 738
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34223 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34223);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34224 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34224 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34223 = NOVALUE;
    if (IS_ATOM_INT(_34224)) {
        _34225 = (_34224 == _ns_file_68728);
    }
    else {
        _34225 = binary_op(EQUALS, _34224, _ns_file_68728);
    }
    _34224 = NOVALUE;
    if (IS_ATOM_INT(_34225)) {
        if (_34225 != 0) {
            DeRef(_34226);
            _34226 = 1;
            goto L1D; // [680] 734
        }
    }
    else {
        if (DBL_PTR(_34225)->dbl != 0.0) {
            DeRef(_34226);
            _34226 = 1;
            goto L1D; // [680] 734
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34227 = (object)*(((s1_ptr)_2)->base + _ns_file_68728);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34228 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34228);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34229 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34229 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34228 = NOVALUE;
    _2 = (object)SEQ_PTR(_34227);
    if (!IS_ATOM_INT(_34229)){
        _34230 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34229)->dbl));
    }
    else{
        _34230 = (object)*(((s1_ptr)_2)->base + _34229);
    }
    _34227 = NOVALUE;
    if (IS_ATOM_INT(_34230)) {
        if (_34230 == 0) {
            DeRef(_34231);
            _34231 = 0;
            goto L1E; // [706] 730
        }
    }
    else {
        if (DBL_PTR(_34230)->dbl == 0.0) {
            DeRef(_34231);
            _34231 = 0;
            goto L1E; // [706] 730
        }
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34232 = (object)*(((s1_ptr)_2)->base + _file_68719);
    _2 = (object)SEQ_PTR(_34232);
    _34233 = (object)*(((s1_ptr)_2)->base + _ns_file_68728);
    _34232 = NOVALUE;
    if (IS_ATOM_INT(_34233)) {
        {uintptr_t tu;
             tu = (uintptr_t)6 & (uintptr_t)_34233;
             _34234 = MAKE_UINT(tu);
        }
    }
    else {
        _34234 = binary_op(AND_BITS, 6, _34233);
    }
    _34233 = NOVALUE;
    DeRef(_34231);
    if (IS_ATOM_INT(_34234))
    _34231 = (_34234 != 0);
    else
    _34231 = DBL_PTR(_34234)->dbl != 0.0;
L1E: 
    DeRef(_34226);
    _34226 = (_34231 != 0);
L1D: 
    _34222 = (_34226 != 0);
L1C: 
    if (_34222 != 0) {
        _34235 = 1;
        goto L1F; // [738] 764
    }
    _34236 = (_scope_68828 == 5);
    if (_34236 == 0) {
        _34237 = 0;
        goto L20; // [748] 760
    }
    _34238 = (_ns_file_68728 == _file_68719);
    _34237 = (_34238 != 0);
L20: 
    _34235 = (_34237 != 0);
L1F: 
    if (_34235 == 0) {
        goto L21; // [764] 795
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34240 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34240);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34241 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34241 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34240 = NOVALUE;
    if (_34241 == _name_68718)
    _34242 = 1;
    else if (IS_ATOM_INT(_34241) && IS_ATOM_INT(_name_68718))
    _34242 = 0;
    else
    _34242 = (compare(_34241, _name_68718) == 0);
    _34241 = NOVALUE;
    if (_34242 == 0)
    {
        _34242 = NOVALUE;
        goto L21; // [785] 795
    }
    else{
        _34242 = NOVALUE;
    }

    /** execute.e:2744					return s*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    DeRef(_34195);
    _34195 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34219);
    _34219 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34205);
    _34205 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    _34203 = NOVALUE;
    DeRef(_34238);
    _34238 = NOVALUE;
    DeRef(_34225);
    _34225 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34199);
    _34199 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    DeRef(_34192);
    _34192 = NOVALUE;
    return _s_68724;
L21: 

    /** execute.e:2746				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34243 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34243);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34243 = NOVALUE;

    /** execute.e:2747			end while*/
    goto L12; // [815] 434
L13: 

    /** execute.e:2749			return 0 -- couldn't find name in ns file*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    DeRef(_34195);
    _34195 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34219);
    _34219 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34205);
    _34205 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    _34203 = NOVALUE;
    DeRef(_34238);
    _34238 = NOVALUE;
    DeRef(_34225);
    _34225 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34199);
    _34199 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    DeRef(_34192);
    _34192 = NOVALUE;
    return 0;
    goto L22; // [824] 1636
L1: 

    /** execute.e:2754			if proc != TopLevelSub then*/
    if (_proc_68721 == _27TopLevelSub_20578)
    goto L23; // [831] 958

    /** execute.e:2756				s = SymTab[proc][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34246 = (object)*(((s1_ptr)_2)->base + _proc_68721);
    _2 = (object)SEQ_PTR(_34246);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34246 = NOVALUE;

    /** execute.e:2757				while s and (SymTab[s][S_SCOPE] = SC_PRIVATE or*/
L24: 
    if (_s_68724 == 0) {
        goto L25; // [856] 957
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34249 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34249);
    _34250 = (object)*(((s1_ptr)_2)->base + 4);
    _34249 = NOVALUE;
    if (IS_ATOM_INT(_34250)) {
        _34251 = (_34250 == 3);
    }
    else {
        _34251 = binary_op(EQUALS, _34250, 3);
    }
    _34250 = NOVALUE;
    if (IS_ATOM_INT(_34251)) {
        if (_34251 != 0) {
            DeRef(_34252);
            _34252 = 1;
            goto L26; // [878] 904
        }
    }
    else {
        if (DBL_PTR(_34251)->dbl != 0.0) {
            DeRef(_34252);
            _34252 = 1;
            goto L26; // [878] 904
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34253 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34253);
    _34254 = (object)*(((s1_ptr)_2)->base + 4);
    _34253 = NOVALUE;
    if (IS_ATOM_INT(_34254)) {
        _34255 = (_34254 == 2);
    }
    else {
        _34255 = binary_op(EQUALS, _34254, 2);
    }
    _34254 = NOVALUE;
    DeRef(_34252);
    if (IS_ATOM_INT(_34255))
    _34252 = (_34255 != 0);
    else
    _34252 = DBL_PTR(_34255)->dbl != 0.0;
L26: 
    if (_34252 == 0)
    {
        _34252 = NOVALUE;
        goto L25; // [905] 957
    }
    else{
        _34252 = NOVALUE;
    }

    /** execute.e:2759					if equal(name, SymTab[s][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34256 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34256);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34257 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34257 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34256 = NOVALUE;
    if (_name_68718 == _34257)
    _34258 = 1;
    else if (IS_ATOM_INT(_name_68718) && IS_ATOM_INT(_34257))
    _34258 = 0;
    else
    _34258 = (compare(_name_68718, _34257) == 0);
    _34257 = NOVALUE;
    if (_34258 == 0)
    {
        _34258 = NOVALUE;
        goto L27; // [926] 936
    }
    else{
        _34258 = NOVALUE;
    }

    /** execute.e:2760						return s*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    DeRef(_34195);
    _34195 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34219);
    _34219 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34205);
    _34205 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    _34203 = NOVALUE;
    DeRef(_34238);
    _34238 = NOVALUE;
    DeRef(_34225);
    _34225 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34199);
    _34199 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34255);
    _34255 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    DeRef(_34251);
    _34251 = NOVALUE;
    DeRef(_34192);
    _34192 = NOVALUE;
    return _s_68724;
L27: 

    /** execute.e:2762					s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34259 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34259);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34259 = NOVALUE;

    /** execute.e:2763				end while*/
    goto L24; // [954] 856
L25: 
L23: 

    /** execute.e:2767			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34261 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34261);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34261 = NOVALUE;

    /** execute.e:2768			found_in_path = 0*/
    _found_in_path_68729 = 0;

    /** execute.e:2769			found_outside_path = 0*/
    _found_outside_path_68730 = 0;

    /** execute.e:2771			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L28: 
    _34263 = (_s_68724 != 0);
    if (_34263 == 0) {
        goto L29; // [995] 1221
    }
    _34265 = (_s_68724 <= _stlen_68722);
    if (_34265 != 0) {
        DeRef(_34266);
        _34266 = 1;
        goto L2A; // [1003] 1029
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34267 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34267);
    _34268 = (object)*(((s1_ptr)_2)->base + 4);
    _34267 = NOVALUE;
    if (IS_ATOM_INT(_34268)) {
        _34269 = (_34268 == 3);
    }
    else {
        _34269 = binary_op(EQUALS, _34268, 3);
    }
    _34268 = NOVALUE;
    if (IS_ATOM_INT(_34269))
    _34266 = (_34269 != 0);
    else
    _34266 = DBL_PTR(_34269)->dbl != 0.0;
L2A: 
    if (_34266 == 0)
    {
        _34266 = NOVALUE;
        goto L29; // [1030] 1221
    }
    else{
        _34266 = NOVALUE;
    }

    /** execute.e:2773				if SymTab[s][S_FILE_NO] = file and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34270 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34270);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34271 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34271 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34270 = NOVALUE;
    if (IS_ATOM_INT(_34271)) {
        _34272 = (_34271 == _file_68719);
    }
    else {
        _34272 = binary_op(EQUALS, _34271, _file_68719);
    }
    _34271 = NOVALUE;
    if (IS_ATOM_INT(_34272)) {
        if (_34272 == 0) {
            DeRef(_34273);
            _34273 = 0;
            goto L2B; // [1051] 1169
        }
    }
    else {
        if (DBL_PTR(_34272)->dbl == 0.0) {
            DeRef(_34273);
            _34273 = 0;
            goto L2B; // [1051] 1169
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34274 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34274);
    _34275 = (object)*(((s1_ptr)_2)->base + 4);
    _34274 = NOVALUE;
    if (IS_ATOM_INT(_34275)) {
        _34276 = (_34275 == 5);
    }
    else {
        _34276 = binary_op(EQUALS, _34275, 5);
    }
    _34275 = NOVALUE;
    if (IS_ATOM_INT(_34276)) {
        if (_34276 != 0) {
            DeRef(_34277);
            _34277 = 1;
            goto L2C; // [1073] 1099
        }
    }
    else {
        if (DBL_PTR(_34276)->dbl != 0.0) {
            DeRef(_34277);
            _34277 = 1;
            goto L2C; // [1073] 1099
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34278 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34278);
    _34279 = (object)*(((s1_ptr)_2)->base + 4);
    _34278 = NOVALUE;
    if (IS_ATOM_INT(_34279)) {
        _34280 = (_34279 == 6);
    }
    else {
        _34280 = binary_op(EQUALS, _34279, 6);
    }
    _34279 = NOVALUE;
    DeRef(_34277);
    if (IS_ATOM_INT(_34280))
    _34277 = (_34280 != 0);
    else
    _34277 = DBL_PTR(_34280)->dbl != 0.0;
L2C: 
    if (_34277 != 0) {
        _34281 = 1;
        goto L2D; // [1099] 1125
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34282 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34282);
    _34283 = (object)*(((s1_ptr)_2)->base + 4);
    _34282 = NOVALUE;
    if (IS_ATOM_INT(_34283)) {
        _34284 = (_34283 == 11);
    }
    else {
        _34284 = binary_op(EQUALS, _34283, 11);
    }
    _34283 = NOVALUE;
    if (IS_ATOM_INT(_34284))
    _34281 = (_34284 != 0);
    else
    _34281 = DBL_PTR(_34284)->dbl != 0.0;
L2D: 
    if (_34281 != 0) {
        _34285 = 1;
        goto L2E; // [1125] 1165
    }
    _34286 = (_proc_68721 == _27TopLevelSub_20578);
    if (_34286 == 0) {
        _34287 = 0;
        goto L2F; // [1135] 1161
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34288 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34288);
    _34289 = (object)*(((s1_ptr)_2)->base + 4);
    _34288 = NOVALUE;
    if (IS_ATOM_INT(_34289)) {
        _34290 = (_34289 == 4);
    }
    else {
        _34290 = binary_op(EQUALS, _34289, 4);
    }
    _34289 = NOVALUE;
    if (IS_ATOM_INT(_34290))
    _34287 = (_34290 != 0);
    else
    _34287 = DBL_PTR(_34290)->dbl != 0.0;
L2F: 
    _34285 = (_34287 != 0);
L2E: 
    DeRef(_34273);
    _34273 = (_34285 != 0);
L2B: 
    if (_34273 == 0) {
        goto L30; // [1169] 1200
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34292 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34292);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34293 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34293 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34292 = NOVALUE;
    if (_name_68718 == _34293)
    _34294 = 1;
    else if (IS_ATOM_INT(_name_68718) && IS_ATOM_INT(_34293))
    _34294 = 0;
    else
    _34294 = (compare(_name_68718, _34293) == 0);
    _34293 = NOVALUE;
    if (_34294 == 0)
    {
        _34294 = NOVALUE;
        goto L30; // [1190] 1200
    }
    else{
        _34294 = NOVALUE;
    }

    /** execute.e:2782					return s*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34263);
    _34263 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    DeRef(_34195);
    _34195 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34276);
    _34276 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34219);
    _34219 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34205);
    _34205 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34290);
    _34290 = NOVALUE;
    DeRef(_34284);
    _34284 = NOVALUE;
    DeRef(_34269);
    _34269 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    _34203 = NOVALUE;
    DeRef(_34238);
    _34238 = NOVALUE;
    DeRef(_34225);
    _34225 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34199);
    _34199 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34255);
    _34255 = NOVALUE;
    DeRef(_34280);
    _34280 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    DeRef(_34251);
    _34251 = NOVALUE;
    DeRef(_34286);
    _34286 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34192);
    _34192 = NOVALUE;
    DeRef(_34265);
    _34265 = NOVALUE;
    return _s_68724;
L30: 

    /** execute.e:2784				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34295 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34295);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34295 = NOVALUE;

    /** execute.e:2785			end while*/
    goto L28; // [1218] 991
L29: 

    /** execute.e:2787			global_found = FALSE*/
    _global_found_68725 = _9FALSE_439;

    /** execute.e:2788			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34297 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_34297);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34297 = NOVALUE;

    /** execute.e:2789			while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L31: 
    _34299 = (_s_68724 != 0);
    if (_34299 == 0) {
        goto L32; // [1257] 1600
    }
    _34301 = (_s_68724 <= _stlen_68722);
    if (_34301 != 0) {
        DeRef(_34302);
        _34302 = 1;
        goto L33; // [1265] 1291
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34303 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34303);
    _34304 = (object)*(((s1_ptr)_2)->base + 4);
    _34303 = NOVALUE;
    if (IS_ATOM_INT(_34304)) {
        _34305 = (_34304 == 3);
    }
    else {
        _34305 = binary_op(EQUALS, _34304, 3);
    }
    _34304 = NOVALUE;
    if (IS_ATOM_INT(_34305))
    _34302 = (_34305 != 0);
    else
    _34302 = DBL_PTR(_34305)->dbl != 0.0;
L33: 
    if (_34302 == 0)
    {
        _34302 = NOVALUE;
        goto L32; // [1292] 1600
    }
    else{
        _34302 = NOVALUE;
    }

    /** execute.e:2790				if SymTab[s][S_SCOPE] = SC_GLOBAL and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34306 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34306);
    _34307 = (object)*(((s1_ptr)_2)->base + 4);
    _34306 = NOVALUE;
    if (IS_ATOM_INT(_34307)) {
        _34308 = (_34307 == 6);
    }
    else {
        _34308 = binary_op(EQUALS, _34307, 6);
    }
    _34307 = NOVALUE;
    if (IS_ATOM_INT(_34308)) {
        if (_34308 == 0) {
            goto L34; // [1315] 1413
        }
    }
    else {
        if (DBL_PTR(_34308)->dbl == 0.0) {
            goto L34; // [1315] 1413
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34310 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34310);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34311 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34311 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34310 = NOVALUE;
    if (_name_68718 == _34311)
    _34312 = 1;
    else if (IS_ATOM_INT(_name_68718) && IS_ATOM_INT(_34311))
    _34312 = 0;
    else
    _34312 = (compare(_name_68718, _34311) == 0);
    _34311 = NOVALUE;
    if (_34312 == 0)
    {
        _34312 = NOVALUE;
        goto L34; // [1336] 1413
    }
    else{
        _34312 = NOVALUE;
    }

    /** execute.e:2793					s_in_include_path = include_matrix[file][SymTab[s][S_FILE_NO]] != 0*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34313 = (object)*(((s1_ptr)_2)->base + _file_68719);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34314 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34314);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34315 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34315 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34314 = NOVALUE;
    _2 = (object)SEQ_PTR(_34313);
    if (!IS_ATOM_INT(_34315)){
        _34316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34315)->dbl));
    }
    else{
        _34316 = (object)*(((s1_ptr)_2)->base + _34315);
    }
    _34313 = NOVALUE;
    if (IS_ATOM_INT(_34316)) {
        _s_in_include_path_68731 = (_34316 != 0);
    }
    else {
        _s_in_include_path_68731 = binary_op(NOTEQ, _34316, 0);
    }
    _34316 = NOVALUE;
    if (!IS_ATOM_INT(_s_in_include_path_68731)) {
        _1 = (object)(DBL_PTR(_s_in_include_path_68731)->dbl);
        DeRefDS(_s_in_include_path_68731);
        _s_in_include_path_68731 = _1;
    }

    /** execute.e:2794					if s_in_include_path then*/
    if (_s_in_include_path_68731 == 0)
    {
        goto L35; // [1371] 1390
    }
    else{
    }

    /** execute.e:2795						global_found = s*/
    _global_found_68725 = _s_68724;

    /** execute.e:2796						found_in_path += 1*/
    _found_in_path_68729 = _found_in_path_68729 + 1;
    goto L36; // [1387] 1579
L35: 

    /** execute.e:2798						if not found_in_path then*/
    if (_found_in_path_68729 != 0)
    goto L37; // [1392] 1403

    /** execute.e:2799							global_found = s*/
    _global_found_68725 = _s_68724;
L37: 

    /** execute.e:2801						found_outside_path += 1*/
    _found_outside_path_68730 = _found_outside_path_68730 + 1;
    goto L36; // [1410] 1579
L34: 

    /** execute.e:2803				elsif (sym_scope( s ) = SC_PUBLIC and equal( name, SymTab[s][S_NAME] ) and*/
    _34321 = _53sym_scope(_s_68724);
    if (IS_ATOM_INT(_34321)) {
        _34322 = (_34321 == 13);
    }
    else {
        _34322 = binary_op(EQUALS, _34321, 13);
    }
    DeRef(_34321);
    _34321 = NOVALUE;
    if (IS_ATOM_INT(_34322)) {
        if (_34322 == 0) {
            DeRef(_34323);
            _34323 = 0;
            goto L38; // [1425] 1449
        }
    }
    else {
        if (DBL_PTR(_34322)->dbl == 0.0) {
            DeRef(_34323);
            _34323 = 0;
            goto L38; // [1425] 1449
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34324 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34324);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34325 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34325 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34324 = NOVALUE;
    if (_name_68718 == _34325)
    _34326 = 1;
    else if (IS_ATOM_INT(_name_68718) && IS_ATOM_INT(_34325))
    _34326 = 0;
    else
    _34326 = (compare(_name_68718, _34325) == 0);
    _34325 = NOVALUE;
    DeRef(_34323);
    _34323 = (_34326 != 0);
L38: 
    if (_34323 == 0) {
        _34327 = 0;
        goto L39; // [1449] 1485
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34328 = (object)*(((s1_ptr)_2)->base + _file_68719);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34329 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34329);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34330 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34330 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34329 = NOVALUE;
    _2 = (object)SEQ_PTR(_34328);
    if (!IS_ATOM_INT(_34330)){
        _34331 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34330)->dbl));
    }
    else{
        _34331 = (object)*(((s1_ptr)_2)->base + _34330);
    }
    _34328 = NOVALUE;
    if (IS_ATOM_INT(_34331)) {
        {uintptr_t tu;
             tu = (uintptr_t)6 & (uintptr_t)_34331;
             _34332 = MAKE_UINT(tu);
        }
    }
    else {
        _34332 = binary_op(AND_BITS, 6, _34331);
    }
    _34331 = NOVALUE;
    if (IS_ATOM_INT(_34332))
    _34327 = (_34332 != 0);
    else
    _34327 = DBL_PTR(_34332)->dbl != 0.0;
L39: 
    if (_34327 != 0) {
        goto L3A; // [1485] 1564
    }
    _34334 = _53sym_scope(_s_68724);
    if (IS_ATOM_INT(_34334)) {
        _34335 = (_34334 == 11);
    }
    else {
        _34335 = binary_op(EQUALS, _34334, 11);
    }
    DeRef(_34334);
    _34334 = NOVALUE;
    if (IS_ATOM_INT(_34335)) {
        if (_34335 == 0) {
            DeRef(_34336);
            _34336 = 0;
            goto L3B; // [1499] 1523
        }
    }
    else {
        if (DBL_PTR(_34335)->dbl == 0.0) {
            DeRef(_34336);
            _34336 = 0;
            goto L3B; // [1499] 1523
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34337 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34337);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34338 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34338 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34337 = NOVALUE;
    if (_name_68718 == _34338)
    _34339 = 1;
    else if (IS_ATOM_INT(_name_68718) && IS_ATOM_INT(_34338))
    _34339 = 0;
    else
    _34339 = (compare(_name_68718, _34338) == 0);
    _34338 = NOVALUE;
    DeRef(_34336);
    _34336 = (_34339 != 0);
L3B: 
    if (_34336 == 0) {
        DeRef(_34340);
        _34340 = 0;
        goto L3C; // [1523] 1559
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _34341 = (object)*(((s1_ptr)_2)->base + _file_68719);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34342 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34342);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _34343 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _34343 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _34342 = NOVALUE;
    _2 = (object)SEQ_PTR(_34341);
    if (!IS_ATOM_INT(_34343)){
        _34344 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34343)->dbl));
    }
    else{
        _34344 = (object)*(((s1_ptr)_2)->base + _34343);
    }
    _34341 = NOVALUE;
    if (IS_ATOM_INT(_34344)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 & (uintptr_t)_34344;
             _34345 = MAKE_UINT(tu);
        }
    }
    else {
        _34345 = binary_op(AND_BITS, 2, _34344);
    }
    _34344 = NOVALUE;
    if (IS_ATOM_INT(_34345))
    _34340 = (_34345 != 0);
    else
    _34340 = DBL_PTR(_34345)->dbl != 0.0;
L3C: 
    if (_34340 == 0)
    {
        _34340 = NOVALUE;
        goto L3D; // [1560] 1578
    }
    else{
        _34340 = NOVALUE;
    }
L3A: 

    /** execute.e:2808					global_found = s*/
    _global_found_68725 = _s_68724;

    /** execute.e:2809					found_in_path += 1*/
    _found_in_path_68729 = _found_in_path_68729 + 1;
L3D: 
L36: 

    /** execute.e:2811				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34347 = (object)*(((s1_ptr)_2)->base + _s_68724);
    _2 = (object)SEQ_PTR(_34347);
    _s_68724 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_68724)){
        _s_68724 = (object)DBL_PTR(_s_68724)->dbl;
    }
    _34347 = NOVALUE;

    /** execute.e:2812			end while*/
    goto L31; // [1597] 1253
L32: 

    /** execute.e:2814			if found_in_path != 1 and (( found_in_path + found_outside_path ) != 1 ) then*/
    _34349 = (_found_in_path_68729 != 1);
    if (_34349 == 0) {
        goto L3E; // [1606] 1629
    }
    _34351 = _found_in_path_68729 + _found_outside_path_68730;
    if ((object)((uintptr_t)_34351 + (uintptr_t)HIGH_BITS) >= 0){
        _34351 = NewDouble((eudouble)_34351);
    }
    if (IS_ATOM_INT(_34351)) {
        _34352 = (_34351 != 1);
    }
    else {
        _34352 = (DBL_PTR(_34351)->dbl != (eudouble)1);
    }
    DeRef(_34351);
    _34351 = NOVALUE;
    if (_34352 == 0)
    {
        DeRef(_34352);
        _34352 = NOVALUE;
        goto L3E; // [1619] 1629
    }
    else{
        DeRef(_34352);
        _34352 = NOVALUE;
    }

    /** execute.e:2815				return 0*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34263);
    _34263 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    _34343 = NOVALUE;
    DeRef(_34195);
    _34195 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34276);
    _34276 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34315 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34219);
    _34219 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    _34330 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    DeRef(_34345);
    _34345 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34205);
    _34205 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34290);
    _34290 = NOVALUE;
    DeRef(_34284);
    _34284 = NOVALUE;
    DeRef(_34269);
    _34269 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    _34203 = NOVALUE;
    DeRef(_34335);
    _34335 = NOVALUE;
    DeRef(_34238);
    _34238 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    DeRef(_34225);
    _34225 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34199);
    _34199 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34255);
    _34255 = NOVALUE;
    DeRef(_34280);
    _34280 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    DeRef(_34332);
    _34332 = NOVALUE;
    DeRef(_34251);
    _34251 = NOVALUE;
    DeRef(_34286);
    _34286 = NOVALUE;
    DeRef(_34349);
    _34349 = NOVALUE;
    DeRef(_34322);
    _34322 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34308);
    _34308 = NOVALUE;
    DeRef(_34192);
    _34192 = NOVALUE;
    DeRef(_34265);
    _34265 = NOVALUE;
    return 0;
L3E: 

    /** execute.e:2817			return global_found*/
    DeRefDS(_name_68718);
    DeRef(_ns_68726);
    DeRef(_34263);
    _34263 = NOVALUE;
    DeRef(_34234);
    _34234 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    _34343 = NOVALUE;
    DeRef(_34195);
    _34195 = NOVALUE;
    DeRef(_34150);
    _34150 = NOVALUE;
    DeRef(_34154);
    _34154 = NOVALUE;
    _34229 = NOVALUE;
    DeRef(_34276);
    _34276 = NOVALUE;
    DeRef(_34305);
    _34305 = NOVALUE;
    _34315 = NOVALUE;
    DeRef(_34221);
    _34221 = NOVALUE;
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34147);
    _34147 = NOVALUE;
    DeRef(_34219);
    _34219 = NOVALUE;
    DeRef(_34129);
    _34129 = NOVALUE;
    _34330 = NOVALUE;
    DeRef(_34127);
    _34127 = NOVALUE;
    DeRef(_34345);
    _34345 = NOVALUE;
    _34230 = NOVALUE;
    DeRef(_34205);
    _34205 = NOVALUE;
    DeRef(_34236);
    _34236 = NOVALUE;
    DeRef(_34215);
    _34215 = NOVALUE;
    DeRef(_34186);
    _34186 = NOVALUE;
    DeRef(_34178);
    _34178 = NOVALUE;
    DeRef(_34290);
    _34290 = NOVALUE;
    DeRef(_34284);
    _34284 = NOVALUE;
    DeRef(_34269);
    _34269 = NOVALUE;
    DeRef(_34166);
    _34166 = NOVALUE;
    DeRef(_34188);
    _34188 = NOVALUE;
    _34203 = NOVALUE;
    DeRef(_34335);
    _34335 = NOVALUE;
    DeRef(_34238);
    _34238 = NOVALUE;
    DeRef(_34299);
    _34299 = NOVALUE;
    DeRef(_34225);
    _34225 = NOVALUE;
    DeRef(_34181);
    _34181 = NOVALUE;
    DeRef(_34199);
    _34199 = NOVALUE;
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34142);
    _34142 = NOVALUE;
    DeRef(_34140);
    _34140 = NOVALUE;
    DeRef(_34255);
    _34255 = NOVALUE;
    DeRef(_34280);
    _34280 = NOVALUE;
    DeRef(_34162);
    _34162 = NOVALUE;
    DeRef(_34136);
    _34136 = NOVALUE;
    DeRef(_34332);
    _34332 = NOVALUE;
    DeRef(_34251);
    _34251 = NOVALUE;
    DeRef(_34286);
    _34286 = NOVALUE;
    DeRef(_34349);
    _34349 = NOVALUE;
    DeRef(_34322);
    _34322 = NOVALUE;
    DeRef(_34272);
    _34272 = NOVALUE;
    DeRef(_34308);
    _34308 = NOVALUE;
    DeRef(_34192);
    _34192 = NOVALUE;
    DeRef(_34265);
    _34265 = NOVALUE;
    return _global_found_68725;
L22: 
    ;
}


void _67do_call_proc(object _sub_69106, object _args_69107, object _advance_69108)
{
    object _n_69109 = NOVALUE;
    object _arg_69110 = NOVALUE;
    object _private_block_69125 = NOVALUE;
    object _p_69131 = NOVALUE;
    object _34394 = NOVALUE;
    object _34389 = NOVALUE;
    object _34387 = NOVALUE;
    object _34386 = NOVALUE;
    object _34385 = NOVALUE;
    object _34383 = NOVALUE;
    object _34381 = NOVALUE;
    object _34378 = NOVALUE;
    object _34376 = NOVALUE;
    object _34374 = NOVALUE;
    object _34373 = NOVALUE;
    object _34372 = NOVALUE;
    object _34371 = NOVALUE;
    object _34370 = NOVALUE;
    object _34369 = NOVALUE;
    object _34367 = NOVALUE;
    object _34366 = NOVALUE;
    object _34364 = NOVALUE;
    object _34363 = NOVALUE;
    object _34361 = NOVALUE;
    object _34360 = NOVALUE;
    object _34358 = NOVALUE;
    object _34357 = NOVALUE;
    object _34355 = NOVALUE;
    object _34353 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_advance_69108)) {
        _1 = (object)(DBL_PTR(_advance_69108)->dbl);
        DeRefDS(_advance_69108);
        _advance_69108 = _1;
    }

    /** execute.e:2825		n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34353 = (object)*(((s1_ptr)_2)->base + _sub_69106);
    _2 = (object)SEQ_PTR(_34353);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_69109 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_69109 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_69109)){
        _n_69109 = (object)DBL_PTR(_n_69109)->dbl;
    }
    _34353 = NOVALUE;

    /** execute.e:2826		arg = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34355 = (object)*(((s1_ptr)_2)->base + _sub_69106);
    _2 = (object)SEQ_PTR(_34355);
    _arg_69110 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_69110)){
        _arg_69110 = (object)DBL_PTR(_arg_69110)->dbl;
    }
    _34355 = NOVALUE;

    /** execute.e:2827		if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34357 = (object)*(((s1_ptr)_2)->base + _sub_69106);
    _2 = (object)SEQ_PTR(_34357);
    _34358 = (object)*(((s1_ptr)_2)->base + 25);
    _34357 = NOVALUE;
    if (binary_op_a(EQUALS, _34358, 0)){
        _34358 = NOVALUE;
        goto L1; // [53] 314
    }
    _34358 = NOVALUE;

    /** execute.e:2831			sequence private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34360 = (object)*(((s1_ptr)_2)->base + _sub_69106);
    _2 = (object)SEQ_PTR(_34360);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _34361 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _34361 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _34360 = NOVALUE;
    DeRef(_private_block_69125);
    _private_block_69125 = Repeat(0, _34361);
    _34361 = NOVALUE;

    /** execute.e:2832			integer p = 1*/
    _p_69131 = 1;

    /** execute.e:2833			for i = 1 to n do*/
    _34363 = _n_69109;
    {
        object _i_69133;
        _i_69133 = 1;
L2: 
        if (_i_69133 > _34363){
            goto L3; // [85] 145
        }

        /** execute.e:2834				private_block[p] = val[arg]*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _34364 = (object)*(((s1_ptr)_2)->base + _arg_69110);
        Ref(_34364);
        _2 = (object)SEQ_PTR(_private_block_69125);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _private_block_69125 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _p_69131);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34364;
        if( _1 != _34364 ){
            DeRef(_1);
        }
        _34364 = NOVALUE;

        /** execute.e:2835				p += 1*/
        _p_69131 = _p_69131 + 1;

        /** execute.e:2836				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_69107);
        _34366 = (object)*(((s1_ptr)_2)->base + _i_69133);
        Ref(_34366);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_69110);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34366;
        if( _1 != _34366 ){
            DeRef(_1);
        }
        _34366 = NOVALUE;

        /** execute.e:2837				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _34367 = (object)*(((s1_ptr)_2)->base + _arg_69110);
        _2 = (object)SEQ_PTR(_34367);
        _arg_69110 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_69110)){
            _arg_69110 = (object)DBL_PTR(_arg_69110)->dbl;
        }
        _34367 = NOVALUE;

        /** execute.e:2838			end for*/
        _i_69133 = _i_69133 + 1;
        goto L2; // [140] 92
L3: 
        ;
    }

    /** execute.e:2841			while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L4: 
    _34369 = (_arg_69110 != 0);
    if (_34369 == 0) {
        goto L5; // [154] 229
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34371 = (object)*(((s1_ptr)_2)->base + _arg_69110);
    _2 = (object)SEQ_PTR(_34371);
    _34372 = (object)*(((s1_ptr)_2)->base + 4);
    _34371 = NOVALUE;
    if (IS_ATOM_INT(_34372)) {
        _34373 = (_34372 <= 3);
    }
    else {
        _34373 = binary_op(LESSEQ, _34372, 3);
    }
    _34372 = NOVALUE;
    if (_34373 <= 0) {
        if (_34373 == 0) {
            DeRef(_34373);
            _34373 = NOVALUE;
            goto L5; // [177] 229
        }
        else {
            if (!IS_ATOM_INT(_34373) && DBL_PTR(_34373)->dbl == 0.0){
                DeRef(_34373);
                _34373 = NOVALUE;
                goto L5; // [177] 229
            }
            DeRef(_34373);
            _34373 = NOVALUE;
        }
    }
    DeRef(_34373);
    _34373 = NOVALUE;

    /** execute.e:2842				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34374 = (object)*(((s1_ptr)_2)->base + _arg_69110);
    Ref(_34374);
    _2 = (object)SEQ_PTR(_private_block_69125);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_69125 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_69131);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34374;
    if( _1 != _34374 ){
        DeRef(_1);
    }
    _34374 = NOVALUE;

    /** execute.e:2843				p += 1*/
    _p_69131 = _p_69131 + 1;

    /** execute.e:2844				val[arg] = NOVALUE -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_69110);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:2845				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34376 = (object)*(((s1_ptr)_2)->base + _arg_69110);
    _2 = (object)SEQ_PTR(_34376);
    _arg_69110 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_69110)){
        _arg_69110 = (object)DBL_PTR(_arg_69110)->dbl;
    }
    _34376 = NOVALUE;

    /** execute.e:2846			end while*/
    goto L4; // [226] 150
L5: 

    /** execute.e:2849			arg = SymTab[sub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34378 = (object)*(((s1_ptr)_2)->base + _sub_69106);
    _2 = (object)SEQ_PTR(_34378);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _arg_69110 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _arg_69110 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_arg_69110)){
        _arg_69110 = (object)DBL_PTR(_arg_69110)->dbl;
    }
    _34378 = NOVALUE;

    /** execute.e:2850			while arg != 0 do*/
L6: 
    if (_arg_69110 == 0)
    goto L7; // [250] 303

    /** execute.e:2851				private_block[p] = val[arg]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34381 = (object)*(((s1_ptr)_2)->base + _arg_69110);
    Ref(_34381);
    _2 = (object)SEQ_PTR(_private_block_69125);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _private_block_69125 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_69131);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34381;
    if( _1 != _34381 ){
        DeRef(_1);
    }
    _34381 = NOVALUE;

    /** execute.e:2852				p += 1*/
    _p_69131 = _p_69131 + 1;

    /** execute.e:2853				val[arg] = NOVALUE -- necessary?*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _arg_69110);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:2854				arg = SymTab[arg][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34383 = (object)*(((s1_ptr)_2)->base + _arg_69110);
    _2 = (object)SEQ_PTR(_34383);
    _arg_69110 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_69110)){
        _arg_69110 = (object)DBL_PTR(_arg_69110)->dbl;
    }
    _34383 = NOVALUE;

    /** execute.e:2855			end while*/
    goto L6; // [300] 250
L7: 

    /** execute.e:2858			save_private_block(sub, private_block)*/
    RefDS(_private_block_69125);
    _67save_private_block(_sub_69106, _private_block_69125);
    DeRefDS(_private_block_69125);
    _private_block_69125 = NOVALUE;
    goto L8; // [311] 362
L1: 

    /** execute.e:2862			for i = 1 to n do*/
    _34385 = _n_69109;
    {
        object _i_69173;
        _i_69173 = 1;
L9: 
        if (_i_69173 > _34385){
            goto LA; // [319] 361
        }

        /** execute.e:2863				val[arg] = args[i]*/
        _2 = (object)SEQ_PTR(_args_69107);
        _34386 = (object)*(((s1_ptr)_2)->base + _i_69173);
        Ref(_34386);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _arg_69110);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34386;
        if( _1 != _34386 ){
            DeRef(_1);
        }
        _34386 = NOVALUE;

        /** execute.e:2864				arg = SymTab[arg][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _34387 = (object)*(((s1_ptr)_2)->base + _arg_69110);
        _2 = (object)SEQ_PTR(_34387);
        _arg_69110 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_69110)){
            _arg_69110 = (object)DBL_PTR(_arg_69110)->dbl;
        }
        _34387 = NOVALUE;

        /** execute.e:2865			end for*/
        _i_69173 = _i_69173 + 1;
        goto L9; // [356] 326
LA: 
        ;
    }
L8: 

    /** execute.e:2868		SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_69106 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65272;
    DeRef(_1);
    _34389 = NOVALUE;

    /** execute.e:2870		pc += advance*/
    _67pc_65255 = _67pc_65255 + _advance_69108;

    /** execute.e:2872		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _67pc_65255);

    /** execute.e:2873		call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _sub_69106);

    /** execute.e:2875		Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34394 = (object)*(((s1_ptr)_2)->base + _sub_69106);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_34394);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _34394 = NOVALUE;

    /** execute.e:2876		pc = 1*/
    _67pc_65255 = 1;

    /** execute.e:2877	end procedure*/
    DeRefDS(_args_69107);
    DeRef(_34369);
    _34369 = NOVALUE;
    return;
    ;
}


void _67opCALL_PROC()
{
    object _cf_69194 = NOVALUE;
    object _sub_69196 = NOVALUE;
    object _34443 = NOVALUE;
    object _34442 = NOVALUE;
    object _34441 = NOVALUE;
    object _34440 = NOVALUE;
    object _34439 = NOVALUE;
    object _34438 = NOVALUE;
    object _34437 = NOVALUE;
    object _34436 = NOVALUE;
    object _34435 = NOVALUE;
    object _34434 = NOVALUE;
    object _34431 = NOVALUE;
    object _34430 = NOVALUE;
    object _34429 = NOVALUE;
    object _34428 = NOVALUE;
    object _34426 = NOVALUE;
    object _34425 = NOVALUE;
    object _34424 = NOVALUE;
    object _34423 = NOVALUE;
    object _34422 = NOVALUE;
    object _34419 = NOVALUE;
    object _34418 = NOVALUE;
    object _34417 = NOVALUE;
    object _34416 = NOVALUE;
    object _34415 = NOVALUE;
    object _34412 = NOVALUE;
    object _34411 = NOVALUE;
    object _34409 = NOVALUE;
    object _34407 = NOVALUE;
    object _34406 = NOVALUE;
    object _34405 = NOVALUE;
    object _34404 = NOVALUE;
    object _34403 = NOVALUE;
    object _34401 = NOVALUE;
    object _34400 = NOVALUE;
    object _34398 = NOVALUE;
    object _34396 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2884		cf = Code[pc] = CALL_FUNC*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34396 = (object)*(((s1_ptr)_2)->base + _67pc_65255);
    if (IS_ATOM_INT(_34396)) {
        _cf_69194 = (_34396 == 137);
    }
    else {
        _cf_69194 = binary_op(EQUALS, _34396, 137);
    }
    _34396 = NOVALUE;
    if (!IS_ATOM_INT(_cf_69194)) {
        _1 = (object)(DBL_PTR(_cf_69194)->dbl);
        DeRefDS(_cf_69194);
        _cf_69194 = _1;
    }

    /** execute.e:2886		a = Code[pc+1]  -- routine id*/
    _34398 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34398);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2887		if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34400 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34400)) {
        _34401 = (_34400 < 0);
    }
    else {
        _34401 = binary_op(LESS, _34400, 0);
    }
    _34400 = NOVALUE;
    if (IS_ATOM_INT(_34401)) {
        if (_34401 != 0) {
            goto L1; // [49] 75
        }
    }
    else {
        if (DBL_PTR(_34401)->dbl != 0.0) {
            goto L1; // [49] 75
        }
    }
    _2 = (object)SEQ_PTR(_67val_65265);
    _34403 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_67e_routine_65303)){
            _34404 = SEQ_PTR(_67e_routine_65303)->length;
    }
    else {
        _34404 = 1;
    }
    if (IS_ATOM_INT(_34403)) {
        _34405 = (_34403 >= _34404);
    }
    else {
        _34405 = binary_op(GREATEREQ, _34403, _34404);
    }
    _34403 = NOVALUE;
    _34404 = NOVALUE;
    if (_34405 == 0) {
        DeRef(_34405);
        _34405 = NOVALUE;
        goto L2; // [71] 81
    }
    else {
        if (!IS_ATOM_INT(_34405) && DBL_PTR(_34405)->dbl == 0.0){
            DeRef(_34405);
            _34405 = NOVALUE;
            goto L2; // [71] 81
        }
        DeRef(_34405);
        _34405 = NOVALUE;
    }
    DeRef(_34405);
    _34405 = NOVALUE;
L1: 

    /** execute.e:2888			RTFatal("invalid routine id")*/
    RefDS(_32772);
    _67RTFatal(_32772);
L2: 

    /** execute.e:2891		sub = e_routine[val[a]+1]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34406 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34406)) {
        _34407 = _34406 + 1;
    }
    else
    _34407 = binary_op(PLUS, 1, _34406);
    _34406 = NOVALUE;
    _2 = (object)SEQ_PTR(_67e_routine_65303);
    if (!IS_ATOM_INT(_34407)){
        _sub_69196 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34407)->dbl));
    }
    else{
        _sub_69196 = (object)*(((s1_ptr)_2)->base + _34407);
    }

    /** execute.e:2892		b = Code[pc+2]  -- argument list*/
    _34409 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34409);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2894		if cf then*/
    if (_cf_69194 == 0)
    {
        goto L3; // [121] 169
    }
    else{
    }

    /** execute.e:2895			if SymTab[sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34411 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34411);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34412 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34412 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34411 = NOVALUE;
    if (binary_op_a(NOTEQ, _34412, 27)){
        _34412 = NOVALUE;
        goto L4; // [140] 212
    }
    _34412 = NOVALUE;

    /** execute.e:2896				RTFatal(sprintf("%s() does not return a value", SymTab[sub][S_NAME]))*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34415 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34415);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34416 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34416 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34415 = NOVALUE;
    _34417 = EPrintf(-9999999, _34414, _34416);
    _34416 = NOVALUE;
    _67RTFatal(_34417);
    _34417 = NOVALUE;
    goto L4; // [166] 212
L3: 

    /** execute.e:2899			if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34418 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34418);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34419 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34419 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34418 = NOVALUE;
    if (binary_op_a(EQUALS, _34419, 27)){
        _34419 = NOVALUE;
        goto L5; // [185] 211
    }
    _34419 = NOVALUE;

    /** execute.e:2900				RTFatal(sprintf("the value returned by %s() must be assigned or used",*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34422 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34422);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34423 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34423 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34422 = NOVALUE;
    _34424 = EPrintf(-9999999, _34421, _34423);
    _34423 = NOVALUE;
    _67RTFatal(_34424);
    _34424 = NOVALUE;
L5: 
L4: 

    /** execute.e:2904		if atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34425 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34426 = IS_ATOM(_34425);
    _34425 = NOVALUE;
    if (_34426 == 0)
    {
        _34426 = NOVALUE;
        goto L6; // [225] 234
    }
    else{
        _34426 = NOVALUE;
    }

    /** execute.e:2905			RTFatal("argument list must be a sequence")*/
    RefDS(_34427);
    _67RTFatal(_34427);
L6: 

    /** execute.e:2908		if SymTab[sub][S_NUM_ARGS] != length(val[b]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34428 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34428);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _34429 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _34429 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _34428 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    _34430 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_34430)){
            _34431 = SEQ_PTR(_34430)->length;
    }
    else {
        _34431 = 1;
    }
    _34430 = NOVALUE;
    if (binary_op_a(EQUALS, _34429, _34431)){
        _34429 = NOVALUE;
        _34431 = NOVALUE;
        goto L7; // [259] 314
    }
    _34429 = NOVALUE;
    _34431 = NOVALUE;

    /** execute.e:2909			RTFatal(sprintf("call to %s() via routine-id should pass %d arguments, not %d",*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34434 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34434);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _34435 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _34435 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _34434 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34436 = (object)*(((s1_ptr)_2)->base + _sub_69196);
    _2 = (object)SEQ_PTR(_34436);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _34437 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _34437 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _34436 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    _34438 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_34438)){
            _34439 = SEQ_PTR(_34438)->length;
    }
    else {
        _34439 = 1;
    }
    _34438 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_34435);
    ((intptr_t*)_2)[1] = _34435;
    Ref(_34437);
    ((intptr_t*)_2)[2] = _34437;
    ((intptr_t*)_2)[3] = _34439;
    _34440 = MAKE_SEQ(_1);
    _34439 = NOVALUE;
    _34437 = NOVALUE;
    _34435 = NOVALUE;
    _34441 = EPrintf(-9999999, _34433, _34440);
    DeRefDS(_34440);
    _34440 = NOVALUE;
    _67RTFatal(_34441);
    _34441 = NOVALUE;
L7: 

    /** execute.e:2914		do_call_proc( sub, val[b], 3 + cf )*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34442 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34443 = 3 + _cf_69194;
    if ((object)((uintptr_t)_34443 + (uintptr_t)HIGH_BITS) >= 0){
        _34443 = NewDouble((eudouble)_34443);
    }
    Ref(_34442);
    _67do_call_proc(_sub_69196, _34442, _34443);
    _34442 = NOVALUE;
    _34443 = NOVALUE;

    /** execute.e:2915	end procedure*/
    DeRef(_34407);
    _34407 = NOVALUE;
    DeRef(_34398);
    _34398 = NOVALUE;
    _34438 = NOVALUE;
    _34430 = NOVALUE;
    DeRef(_34401);
    _34401 = NOVALUE;
    DeRef(_34409);
    _34409 = NOVALUE;
    return;
    ;
}


void _67opROUTINE_ID()
{
    object _sub_69274 = NOVALUE;
    object _fn_69275 = NOVALUE;
    object _p_69276 = NOVALUE;
    object _stlen_69277 = NOVALUE;
    object _name_69278 = NOVALUE;
    object _34470 = NOVALUE;
    object _34469 = NOVALUE;
    object _34467 = NOVALUE;
    object _34465 = NOVALUE;
    object _34464 = NOVALUE;
    object _34463 = NOVALUE;
    object _34462 = NOVALUE;
    object _34461 = NOVALUE;
    object _34460 = NOVALUE;
    object _34458 = NOVALUE;
    object _34456 = NOVALUE;
    object _34453 = NOVALUE;
    object _34451 = NOVALUE;
    object _34449 = NOVALUE;
    object _34448 = NOVALUE;
    object _34446 = NOVALUE;
    object _34444 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2923		sub = Code[pc+1]   -- CurrentSub*/
    _34444 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_69274 = (object)*(((s1_ptr)_2)->base + _34444);
    if (!IS_ATOM_INT(_sub_69274)){
        _sub_69274 = (object)DBL_PTR(_sub_69274)->dbl;
    }

    /** execute.e:2924		stlen = Code[pc+2]  -- s.t. length*/
    _34446 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _stlen_69277 = (object)*(((s1_ptr)_2)->base + _34446);
    if (!IS_ATOM_INT(_stlen_69277)){
        _stlen_69277 = (object)DBL_PTR(_stlen_69277)->dbl;
    }

    /** execute.e:2925		name = val[Code[pc+3]]  -- routine name sequence*/
    _34448 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34449 = (object)*(((s1_ptr)_2)->base + _34448);
    DeRef(_name_69278);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34449)){
        _name_69278 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34449)->dbl));
    }
    else{
        _name_69278 = (object)*(((s1_ptr)_2)->base + _34449);
    }
    Ref(_name_69278);

    /** execute.e:2926		fn = Code[pc+4]    -- file number*/
    _34451 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _fn_69275 = (object)*(((s1_ptr)_2)->base + _34451);
    if (!IS_ATOM_INT(_fn_69275)){
        _fn_69275 = (object)DBL_PTR(_fn_69275)->dbl;
    }

    /** execute.e:2927		target = Code[pc+5]*/
    _34453 = _67pc_65255 + 5;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34453);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2928		pc += 6*/
    _67pc_65255 = _67pc_65255 + 6;

    /** execute.e:2929		if atom(name) then*/
    _34456 = IS_ATOM(_name_69278);
    if (_34456 == 0)
    {
        _34456 = NOVALUE;
        goto L1; // [98] 117
    }
    else{
        _34456 = NOVALUE;
    }

    /** execute.e:2930			val[target] = -1*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** execute.e:2931			return*/
    DeRef(_name_69278);
    _34446 = NOVALUE;
    _34449 = NOVALUE;
    _34448 = NOVALUE;
    _34451 = NOVALUE;
    _34453 = NOVALUE;
    _34444 = NOVALUE;
    return;
L1: 

    /** execute.e:2934		p = RTLookup(name, fn, sub, stlen)*/
    Ref(_name_69278);
    _p_69276 = _67RTLookup(_name_69278, _fn_69275, _sub_69274, _stlen_69277);
    if (!IS_ATOM_INT(_p_69276)) {
        _1 = (object)(DBL_PTR(_p_69276)->dbl);
        DeRefDS(_p_69276);
        _p_69276 = _1;
    }

    /** execute.e:2935		if p = 0 or not find(SymTab[p][S_TOKEN], RTN_TOKS) then*/
    _34458 = (_p_69276 == 0);
    if (_34458 != 0) {
        goto L2; // [134] 165
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _34460 = (object)*(((s1_ptr)_2)->base + _p_69276);
    _2 = (object)SEQ_PTR(_34460);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _34461 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _34461 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _34460 = NOVALUE;
    _34462 = find_from(_34461, _29RTN_TOKS_12277, 1);
    _34461 = NOVALUE;
    _34463 = (_34462 == 0);
    _34462 = NOVALUE;
    if (_34463 == 0)
    {
        DeRef(_34463);
        _34463 = NOVALUE;
        goto L3; // [161] 181
    }
    else{
        DeRef(_34463);
        _34463 = NOVALUE;
    }
L2: 

    /** execute.e:2936			val[target] = -1  -- name is not a routine*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** execute.e:2937			return*/
    DeRef(_name_69278);
    DeRef(_34458);
    _34458 = NOVALUE;
    DeRef(_34446);
    _34446 = NOVALUE;
    _34449 = NOVALUE;
    DeRef(_34448);
    _34448 = NOVALUE;
    DeRef(_34451);
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34444);
    _34444 = NOVALUE;
    return;
L3: 

    /** execute.e:2939		for i = 1 to length(e_routine) do*/
    if (IS_SEQUENCE(_67e_routine_65303)){
            _34464 = SEQ_PTR(_67e_routine_65303)->length;
    }
    else {
        _34464 = 1;
    }
    {
        object _i_69310;
        _i_69310 = 1;
L4: 
        if (_i_69310 > _34464){
            goto L5; // [188] 234
        }

        /** execute.e:2940			if e_routine[i] = p then*/
        _2 = (object)SEQ_PTR(_67e_routine_65303);
        _34465 = (object)*(((s1_ptr)_2)->base + _i_69310);
        if (_34465 != _p_69276)
        goto L6; // [203] 227

        /** execute.e:2941				val[target] = i - 1  -- routine was already assigned an id*/
        _34467 = _i_69310 - 1;
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _34467;
        if( _1 != _34467 ){
            DeRef(_1);
        }
        _34467 = NOVALUE;

        /** execute.e:2942				return*/
        DeRef(_name_69278);
        DeRef(_34458);
        _34458 = NOVALUE;
        DeRef(_34446);
        _34446 = NOVALUE;
        _34449 = NOVALUE;
        DeRef(_34448);
        _34448 = NOVALUE;
        DeRef(_34451);
        _34451 = NOVALUE;
        DeRef(_34453);
        _34453 = NOVALUE;
        DeRef(_34444);
        _34444 = NOVALUE;
        _34465 = NOVALUE;
        return;
L6: 

        /** execute.e:2944		end for*/
        _i_69310 = _i_69310 + 1;
        goto L4; // [229] 195
L5: 
        ;
    }

    /** execute.e:2945		e_routine = append(e_routine, p)*/
    Append(&_67e_routine_65303, _67e_routine_65303, _p_69276);

    /** execute.e:2946		val[target] = length(e_routine) - 1*/
    if (IS_SEQUENCE(_67e_routine_65303)){
            _34469 = SEQ_PTR(_67e_routine_65303)->length;
    }
    else {
        _34469 = 1;
    }
    _34470 = _34469 - 1;
    _34469 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34470;
    if( _1 != _34470 ){
        DeRef(_1);
    }
    _34470 = NOVALUE;

    /** execute.e:2947	end procedure*/
    DeRef(_name_69278);
    DeRef(_34458);
    _34458 = NOVALUE;
    DeRef(_34446);
    _34446 = NOVALUE;
    _34449 = NOVALUE;
    DeRef(_34448);
    _34448 = NOVALUE;
    DeRef(_34451);
    _34451 = NOVALUE;
    DeRef(_34453);
    _34453 = NOVALUE;
    DeRef(_34444);
    _34444 = NOVALUE;
    _34465 = NOVALUE;
    return;
    ;
}


void _67opAPPEND()
{
    object _34479 = NOVALUE;
    object _34478 = NOVALUE;
    object _34477 = NOVALUE;
    object _34475 = NOVALUE;
    object _34473 = NOVALUE;
    object _34471 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2950		a = Code[pc+1]*/
    _34471 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34471);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2951		b = Code[pc+2]*/
    _34473 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34473);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2952		target = Code[pc+3]*/
    _34475 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34475);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2953		val[target] = append(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34477 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34478 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_34478);
    Append(&_34479, _34477, _34478);
    _34477 = NOVALUE;
    _34478 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34479;
    if( _1 != _34479 ){
        DeRef(_1);
    }
    _34479 = NOVALUE;

    /** execute.e:2954		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2955	end procedure*/
    _34475 = NOVALUE;
    _34473 = NOVALUE;
    _34471 = NOVALUE;
    return;
    ;
}


void _67opPREPEND()
{
    object _34489 = NOVALUE;
    object _34488 = NOVALUE;
    object _34487 = NOVALUE;
    object _34485 = NOVALUE;
    object _34483 = NOVALUE;
    object _34481 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2958		a = Code[pc+1]*/
    _34481 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34481);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2959		b = Code[pc+2]*/
    _34483 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34483);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2960		target = Code[pc+3]*/
    _34485 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34485);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2961		val[target] = prepend(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34487 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34488 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Ref(_34488);
    Prepend(&_34489, _34487, _34488);
    _34487 = NOVALUE;
    _34488 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34489;
    if( _1 != _34489 ){
        DeRef(_1);
    }
    _34489 = NOVALUE;

    /** execute.e:2962		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2963	end procedure*/
    _34485 = NOVALUE;
    _34481 = NOVALUE;
    _34483 = NOVALUE;
    return;
    ;
}


void _67opCONCAT()
{
    object _34499 = NOVALUE;
    object _34498 = NOVALUE;
    object _34497 = NOVALUE;
    object _34495 = NOVALUE;
    object _34493 = NOVALUE;
    object _34491 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2966		a = Code[pc+1]*/
    _34491 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34491);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2967		b = Code[pc+2]*/
    _34493 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34493);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2968		target = Code[pc+3]*/
    _34495 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34495);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2969		val[target] = val[a] & val[b]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34497 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34498 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_34497) && IS_ATOM(_34498)) {
        Ref(_34498);
        Append(&_34499, _34497, _34498);
    }
    else if (IS_ATOM(_34497) && IS_SEQUENCE(_34498)) {
        Ref(_34497);
        Prepend(&_34499, _34498, _34497);
    }
    else {
        Concat((object_ptr)&_34499, _34497, _34498);
        _34497 = NOVALUE;
    }
    _34497 = NOVALUE;
    _34498 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34499;
    if( _1 != _34499 ){
        DeRef(_1);
    }
    _34499 = NOVALUE;

    /** execute.e:2970		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:2971	end procedure*/
    _34495 = NOVALUE;
    _34493 = NOVALUE;
    _34491 = NOVALUE;
    return;
    ;
}


void _67opCONCAT_N()
{
    object _n_69366 = NOVALUE;
    object _x_69367 = NOVALUE;
    object _34515 = NOVALUE;
    object _34513 = NOVALUE;
    object _34512 = NOVALUE;
    object _34510 = NOVALUE;
    object _34509 = NOVALUE;
    object _34508 = NOVALUE;
    object _34507 = NOVALUE;
    object _34506 = NOVALUE;
    object _34504 = NOVALUE;
    object _34503 = NOVALUE;
    object _34501 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2978		n = Code[pc+1] -- number of items*/
    _34501 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _n_69366 = (object)*(((s1_ptr)_2)->base + _34501);
    if (!IS_ATOM_INT(_n_69366)){
        _n_69366 = (object)DBL_PTR(_n_69366)->dbl;
    }

    /** execute.e:2980		x = val[Code[pc+2]] -- last one*/
    _34503 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34504 = (object)*(((s1_ptr)_2)->base + _34503);
    DeRef(_x_69367);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34504)){
        _x_69367 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34504)->dbl));
    }
    else{
        _x_69367 = (object)*(((s1_ptr)_2)->base + _34504);
    }
    Ref(_x_69367);

    /** execute.e:2981		for i = pc+3 to pc+n+1 do*/
    _34506 = _67pc_65255 + 3;
    if ((object)((uintptr_t)_34506 + (uintptr_t)HIGH_BITS) >= 0){
        _34506 = NewDouble((eudouble)_34506);
    }
    _34507 = _67pc_65255 + _n_69366;
    if ((object)((uintptr_t)_34507 + (uintptr_t)HIGH_BITS) >= 0){
        _34507 = NewDouble((eudouble)_34507);
    }
    if (IS_ATOM_INT(_34507)) {
        _34508 = _34507 + 1;
        if (_34508 > MAXINT){
            _34508 = NewDouble((eudouble)_34508);
        }
    }
    else
    _34508 = binary_op(PLUS, 1, _34507);
    DeRef(_34507);
    _34507 = NOVALUE;
    {
        object _i_69376;
        Ref(_34506);
        _i_69376 = _34506;
L1: 
        if (binary_op_a(GREATER, _i_69376, _34508)){
            goto L2; // [55] 87
        }

        /** execute.e:2982			x = val[Code[i]] & x*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_i_69376)){
            _34509 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_69376)->dbl));
        }
        else{
            _34509 = (object)*(((s1_ptr)_2)->base + _i_69376);
        }
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!IS_ATOM_INT(_34509)){
            _34510 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34509)->dbl));
        }
        else{
            _34510 = (object)*(((s1_ptr)_2)->base + _34509);
        }
        if (IS_SEQUENCE(_34510) && IS_ATOM(_x_69367)) {
            Ref(_x_69367);
            Append(&_x_69367, _34510, _x_69367);
        }
        else if (IS_ATOM(_34510) && IS_SEQUENCE(_x_69367)) {
            Ref(_34510);
            Prepend(&_x_69367, _x_69367, _34510);
        }
        else {
            Concat((object_ptr)&_x_69367, _34510, _x_69367);
            _34510 = NOVALUE;
        }
        _34510 = NOVALUE;

        /** execute.e:2983		end for*/
        _0 = _i_69376;
        if (IS_ATOM_INT(_i_69376)) {
            _i_69376 = _i_69376 + 1;
            if ((object)((uintptr_t)_i_69376 +(uintptr_t) HIGH_BITS) >= 0){
                _i_69376 = NewDouble((eudouble)_i_69376);
            }
        }
        else {
            _i_69376 = binary_op_a(PLUS, _i_69376, 1);
        }
        DeRef(_0);
        goto L1; // [82] 62
L2: 
        ;
        DeRef(_i_69376);
    }

    /** execute.e:2984		target = Code[pc+n+2]*/
    _34512 = _67pc_65255 + _n_69366;
    if ((object)((uintptr_t)_34512 + (uintptr_t)HIGH_BITS) >= 0){
        _34512 = NewDouble((eudouble)_34512);
    }
    if (IS_ATOM_INT(_34512)) {
        _34513 = _34512 + 2;
    }
    else {
        _34513 = NewDouble(DBL_PTR(_34512)->dbl + (eudouble)2);
    }
    DeRef(_34512);
    _34512 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!IS_ATOM_INT(_34513)){
        _67target_65260 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34513)->dbl));
    }
    else{
        _67target_65260 = (object)*(((s1_ptr)_2)->base + _34513);
    }
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2985		val[target] = x*/
    Ref(_x_69367);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_69367;
    DeRef(_1);

    /** execute.e:2986		pc += n+3*/
    _34515 = _n_69366 + 3;
    if ((object)((uintptr_t)_34515 + (uintptr_t)HIGH_BITS) >= 0){
        _34515 = NewDouble((eudouble)_34515);
    }
    if (IS_ATOM_INT(_34515)) {
        _67pc_65255 = _67pc_65255 + _34515;
    }
    else {
        _67pc_65255 = NewDouble((eudouble)_67pc_65255 + DBL_PTR(_34515)->dbl);
    }
    DeRef(_34515);
    _34515 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_65255)) {
        _1 = (object)(DBL_PTR(_67pc_65255)->dbl);
        DeRefDS(_67pc_65255);
        _67pc_65255 = _1;
    }

    /** execute.e:2987	end procedure*/
    DeRef(_x_69367);
    _34504 = NOVALUE;
    DeRef(_34503);
    _34503 = NOVALUE;
    DeRef(_34506);
    _34506 = NOVALUE;
    DeRef(_34513);
    _34513 = NOVALUE;
    DeRef(_34508);
    _34508 = NOVALUE;
    _34509 = NOVALUE;
    DeRef(_34501);
    _34501 = NOVALUE;
    return;
    ;
}


void _67opREPEAT()
{
    object _34535 = NOVALUE;
    object _34534 = NOVALUE;
    object _34533 = NOVALUE;
    object _34530 = NOVALUE;
    object _34527 = NOVALUE;
    object _34524 = NOVALUE;
    object _34523 = NOVALUE;
    object _34521 = NOVALUE;
    object _34519 = NOVALUE;
    object _34517 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:2990		a = Code[pc+1]*/
    _34517 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34517);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:2991		b = Code[pc+2]*/
    _34519 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34519);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:2992		target = Code[pc+3]*/
    _34521 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34521);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:2993		if not atom(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34523 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34524 = IS_ATOM(_34523);
    _34523 = NOVALUE;
    if (_34524 != 0)
    goto L1; // [62] 71
    _34524 = NOVALUE;

    /** execute.e:2994			RTFatal("repetition count must be an atom")*/
    RefDS(_34526);
    _67RTFatal(_34526);
L1: 

    /** execute.e:2996		if val[b] < 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34527 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(GREATEREQ, _34527, 0)){
        _34527 = NOVALUE;
        goto L2; // [81] 91
    }
    _34527 = NOVALUE;

    /** execute.e:2997			RTFatal("repetition count must not be negative")*/
    RefDS(_34529);
    _67RTFatal(_34529);
L2: 

    /** execute.e:2999		if val[b] > 1073741823 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34530 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (binary_op_a(LESSEQ, _34530, 1073741823)){
        _34530 = NOVALUE;
        goto L3; // [101] 111
    }
    _34530 = NOVALUE;

    /** execute.e:3000			RTFatal("repetition count is too large")*/
    RefDS(_34532);
    _67RTFatal(_34532);
L3: 

    /** execute.e:3002		val[target] = repeat(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34533 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34534 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34535 = Repeat(_34533, _34534);
    _34533 = NOVALUE;
    _34534 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34535;
    if( _1 != _34535 ){
        DeRef(_1);
    }
    _34535 = NOVALUE;

    /** execute.e:3003		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3004	end procedure*/
    DeRef(_34519);
    _34519 = NOVALUE;
    DeRef(_34521);
    _34521 = NOVALUE;
    DeRef(_34517);
    _34517 = NOVALUE;
    return;
    ;
}


void _67opDATE()
{
    object _34539 = NOVALUE;
    object _34537 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3007		target = Code[pc+1]*/
    _34537 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34537);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3008		val[target] = date()*/
    _34539 = Date();
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34539;
    if( _1 != _34539 ){
        DeRef(_1);
    }
    _34539 = NOVALUE;

    /** execute.e:3009		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3010	end procedure*/
    _34537 = NOVALUE;
    return;
    ;
}


void _67opTIME()
{
    object _34543 = NOVALUE;
    object _34541 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3013		target = Code[pc+1]*/
    _34541 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34541);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3014		val[target] = time()*/
    _34543 = NewDouble(current_time());
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34543;
    if( _1 != _34543 ){
        DeRef(_1);
    }
    _34543 = NOVALUE;

    /** execute.e:3015		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3016	end procedure*/
    _34541 = NOVALUE;
    return;
    ;
}


void _67opSPACE_USED()
{
    object _0, _1, _2;
    

    /** execute.e:3019		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3020	end procedure*/
    return;
    ;
}


void _67opNOP2()
{
    object _0, _1, _2;
    

    /** execute.e:3024		pc+= 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3025	end procedure*/
    return;
    ;
}


void _67opPOSITION()
{
    object _34552 = NOVALUE;
    object _34551 = NOVALUE;
    object _34549 = NOVALUE;
    object _34547 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3028		a = Code[pc+1]*/
    _34547 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34547);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3029		b = Code[pc+2]*/
    _34549 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34549);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3030		position(val[a], val[b])  -- error checks*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34551 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34552 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    Position(_34551, _34552);
    _34551 = NOVALUE;
    _34552 = NOVALUE;

    /** execute.e:3031		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3032	end procedure*/
    _34547 = NOVALUE;
    _34549 = NOVALUE;
    return;
    ;
}


void _67opEQUAL()
{
    object _34562 = NOVALUE;
    object _34561 = NOVALUE;
    object _34560 = NOVALUE;
    object _34558 = NOVALUE;
    object _34556 = NOVALUE;
    object _34554 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3035		a = Code[pc+1]*/
    _34554 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34554);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3036		b = Code[pc+2]*/
    _34556 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34556);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3037		target = Code[pc+3]*/
    _34558 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34558);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3038		val[target] = equal(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34560 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34561 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (_34560 == _34561)
    _34562 = 1;
    else if (IS_ATOM_INT(_34560) && IS_ATOM_INT(_34561))
    _34562 = 0;
    else
    _34562 = (compare(_34560, _34561) == 0);
    _34560 = NOVALUE;
    _34561 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34562;
    if( _1 != _34562 ){
        DeRef(_1);
    }
    _34562 = NOVALUE;

    /** execute.e:3039		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3040	end procedure*/
    _34558 = NOVALUE;
    _34554 = NOVALUE;
    _34556 = NOVALUE;
    return;
    ;
}


void _67opHASH()
{
    object _34572 = NOVALUE;
    object _34571 = NOVALUE;
    object _34570 = NOVALUE;
    object _34568 = NOVALUE;
    object _34566 = NOVALUE;
    object _34564 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3043		a = Code[pc+1]*/
    _34564 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34564);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3044		b = Code[pc+2]*/
    _34566 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34566);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3045		target = Code[pc+3]*/
    _34568 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34568);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3046		val[target] = hash(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34570 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34571 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34572 = calc_hash(_34570, _34571);
    _34570 = NOVALUE;
    _34571 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34572;
    if( _1 != _34572 ){
        DeRef(_1);
    }
    _34572 = NOVALUE;

    /** execute.e:3047		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3048	end procedure*/
    _34568 = NOVALUE;
    _34564 = NOVALUE;
    _34566 = NOVALUE;
    return;
    ;
}


void _67opCOMPARE()
{
    object _34582 = NOVALUE;
    object _34581 = NOVALUE;
    object _34580 = NOVALUE;
    object _34578 = NOVALUE;
    object _34576 = NOVALUE;
    object _34574 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3051		a = Code[pc+1]*/
    _34574 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34574);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3052		b = Code[pc+2]*/
    _34576 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34576);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3053		target = Code[pc+3]*/
    _34578 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34578);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3054		val[target] = compare(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34580 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34581 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34580) && IS_ATOM_INT(_34581)){
        _34582 = (_34580 < _34581) ? -1 : (_34580 > _34581);
    }
    else{
        _34582 = compare(_34580, _34581);
    }
    _34580 = NOVALUE;
    _34581 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34582;
    if( _1 != _34582 ){
        DeRef(_1);
    }
    _34582 = NOVALUE;

    /** execute.e:3055		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3056	end procedure*/
    _34576 = NOVALUE;
    _34574 = NOVALUE;
    _34578 = NOVALUE;
    return;
    ;
}


void _67opFIND()
{
    object _34596 = NOVALUE;
    object _34595 = NOVALUE;
    object _34594 = NOVALUE;
    object _34591 = NOVALUE;
    object _34590 = NOVALUE;
    object _34588 = NOVALUE;
    object _34586 = NOVALUE;
    object _34584 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3059		a = Code[pc+1]*/
    _34584 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34584);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3060		b = Code[pc+2]*/
    _34586 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34586);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3061		target = Code[pc+3]*/
    _34588 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34588);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3062		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34590 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34591 = IS_SEQUENCE(_34590);
    _34590 = NOVALUE;
    if (_34591 != 0)
    goto L1; // [62] 71
    _34591 = NOVALUE;

    /** execute.e:3063			RTFatal("second argument of find() must be a sequence")*/
    RefDS(_34593);
    _67RTFatal(_34593);
L1: 

    /** execute.e:3065		val[target] = find(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34594 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34595 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34596 = find_from(_34594, _34595, 1);
    _34594 = NOVALUE;
    _34595 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34596;
    if( _1 != _34596 ){
        DeRef(_1);
    }
    _34596 = NOVALUE;

    /** execute.e:3066		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3067	end procedure*/
    DeRef(_34586);
    _34586 = NOVALUE;
    DeRef(_34588);
    _34588 = NOVALUE;
    DeRef(_34584);
    _34584 = NOVALUE;
    return;
    ;
}


void _67opMATCH()
{
    object _34618 = NOVALUE;
    object _34617 = NOVALUE;
    object _34616 = NOVALUE;
    object _34613 = NOVALUE;
    object _34612 = NOVALUE;
    object _34609 = NOVALUE;
    object _34608 = NOVALUE;
    object _34605 = NOVALUE;
    object _34604 = NOVALUE;
    object _34602 = NOVALUE;
    object _34600 = NOVALUE;
    object _34598 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3070		a = Code[pc+1]*/
    _34598 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34598);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3071		b = Code[pc+2]*/
    _34600 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34600);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3072		target = Code[pc+3]*/
    _34602 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34602);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3073		if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34604 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34605 = IS_SEQUENCE(_34604);
    _34604 = NOVALUE;
    if (_34605 != 0)
    goto L1; // [62] 71
    _34605 = NOVALUE;

    /** execute.e:3074			RTFatal("first argument of match() must be a sequence")*/
    RefDS(_34607);
    _67RTFatal(_34607);
L1: 

    /** execute.e:3076		if not sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34608 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34609 = IS_SEQUENCE(_34608);
    _34608 = NOVALUE;
    if (_34609 != 0)
    goto L2; // [84] 93
    _34609 = NOVALUE;

    /** execute.e:3077			RTFatal("second argument of match() must be a sequence")*/
    RefDS(_34611);
    _67RTFatal(_34611);
L2: 

    /** execute.e:3079		if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34612 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_34612)){
            _34613 = SEQ_PTR(_34612)->length;
    }
    else {
        _34613 = 1;
    }
    _34612 = NOVALUE;
    if (_34613 != 0)
    goto L3; // [106] 116

    /** execute.e:3080			 RTFatal("first argument of match() must be a non-empty sequence")*/
    RefDS(_34615);
    _67RTFatal(_34615);
L3: 

    /** execute.e:3082		val[target] = match(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34616 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34617 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34618 = e_match_from(_34616, _34617, 1);
    _34616 = NOVALUE;
    _34617 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34618;
    if( _1 != _34618 ){
        DeRef(_1);
    }
    _34618 = NOVALUE;

    /** execute.e:3083		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3084	end procedure*/
    _34612 = NOVALUE;
    DeRef(_34602);
    _34602 = NOVALUE;
    DeRef(_34600);
    _34600 = NOVALUE;
    DeRef(_34598);
    _34598 = NOVALUE;
    return;
    ;
}


void _67opFIND_FROM()
{
    object _s_69546 = NOVALUE;
    object _34641 = NOVALUE;
    object _34639 = NOVALUE;
    object _34638 = NOVALUE;
    object _34637 = NOVALUE;
    object _34635 = NOVALUE;
    object _34634 = NOVALUE;
    object _34633 = NOVALUE;
    object _34632 = NOVALUE;
    object _34628 = NOVALUE;
    object _34627 = NOVALUE;
    object _34626 = NOVALUE;
    object _34625 = NOVALUE;
    object _34623 = NOVALUE;
    object _34621 = NOVALUE;
    object _34620 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3089			c = val[Code[pc+3]]*/
    _34620 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34621 = (object)*(((s1_ptr)_2)->base + _34620);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34621)){
        _67c_65258 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34621)->dbl));
    }
    else{
        _67c_65258 = (object)*(((s1_ptr)_2)->base + _34621);
    }
    if (!IS_ATOM_INT(_67c_65258))
    _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;

    /** execute.e:3090			target = Code[pc+4]*/
    _34623 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34623);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3091			if not sequence(val[Code[pc+2]]) then*/
    _34625 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34626 = (object)*(((s1_ptr)_2)->base + _34625);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34626)){
        _34627 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34626)->dbl));
    }
    else{
        _34627 = (object)*(((s1_ptr)_2)->base + _34626);
    }
    _34628 = IS_SEQUENCE(_34627);
    _34627 = NOVALUE;
    if (_34628 != 0)
    goto L1; // [60] 82
    _34628 = NOVALUE;

    /** execute.e:3092					RTFatal("second argument of find_from() must be a sequence")*/
    RefDS(_34630);
    _67RTFatal(_34630);

    /** execute.e:3093					pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3094					return*/
    DeRef(_s_69546);
    _34620 = NOVALUE;
    _34626 = NOVALUE;
    _34621 = NOVALUE;
    _34625 = NOVALUE;
    _34623 = NOVALUE;
    return;
L1: 

    /** execute.e:3096			s = val[Code[pc+2]][c..$]*/
    _34632 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34633 = (object)*(((s1_ptr)_2)->base + _34632);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34633)){
        _34634 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34633)->dbl));
    }
    else{
        _34634 = (object)*(((s1_ptr)_2)->base + _34633);
    }
    if (IS_SEQUENCE(_34634)){
            _34635 = SEQ_PTR(_34634)->length;
    }
    else {
        _34635 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_69546;
    RHS_Slice(_34634, _67c_65258, _34635);
    _34634 = NOVALUE;

    /** execute.e:3097			b = find( val[Code[pc+1]], s )*/
    _34637 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34638 = (object)*(((s1_ptr)_2)->base + _34637);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34638)){
        _34639 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34638)->dbl));
    }
    else{
        _34639 = (object)*(((s1_ptr)_2)->base + _34638);
    }
    _67b_65257 = find_from(_34639, _s_69546, 1);
    _34639 = NOVALUE;

    /** execute.e:3098			if b then*/
    if (_67b_65257 == 0)
    {
        goto L2; // [141] 161
    }
    else{
    }

    /** execute.e:3099					b += c - 1*/
    _34641 = _67c_65258 - 1;
    if ((object)((uintptr_t)_34641 +(uintptr_t) HIGH_BITS) >= 0){
        _34641 = NewDouble((eudouble)_34641);
    }
    if (IS_ATOM_INT(_34641)) {
        _67b_65257 = _67b_65257 + _34641;
    }
    else {
        _67b_65257 = NewDouble((eudouble)_67b_65257 + DBL_PTR(_34641)->dbl);
    }
    DeRef(_34641);
    _34641 = NOVALUE;
    if (!IS_ATOM_INT(_67b_65257)) {
        _1 = (object)(DBL_PTR(_67b_65257)->dbl);
        DeRefDS(_67b_65257);
        _67b_65257 = _1;
    }
L2: 

    /** execute.e:3101			val[target] = b*/
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67b_65257;
    DeRef(_1);

    /** execute.e:3102			pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3103	end procedure*/
    DeRef(_s_69546);
    _34638 = NOVALUE;
    DeRef(_34620);
    _34620 = NOVALUE;
    _34626 = NOVALUE;
    _34621 = NOVALUE;
    DeRef(_34632);
    _34632 = NOVALUE;
    DeRef(_34637);
    _34637 = NOVALUE;
    DeRef(_34625);
    _34625 = NOVALUE;
    _34633 = NOVALUE;
    DeRef(_34623);
    _34623 = NOVALUE;
    return;
    ;
}


void _67opMATCH_FROM()
{
    object _s_69580 = NOVALUE;
    object _34684 = NOVALUE;
    object _34683 = NOVALUE;
    object _34681 = NOVALUE;
    object _34680 = NOVALUE;
    object _34679 = NOVALUE;
    object _34678 = NOVALUE;
    object _34677 = NOVALUE;
    object _34676 = NOVALUE;
    object _34675 = NOVALUE;
    object _34674 = NOVALUE;
    object _34673 = NOVALUE;
    object _34672 = NOVALUE;
    object _34670 = NOVALUE;
    object _34664 = NOVALUE;
    object _34660 = NOVALUE;
    object _34659 = NOVALUE;
    object _34655 = NOVALUE;
    object _34654 = NOVALUE;
    object _34652 = NOVALUE;
    object _34650 = NOVALUE;
    object _34649 = NOVALUE;
    object _34647 = NOVALUE;
    object _34645 = NOVALUE;
    object _34644 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3108			c = val[Code[pc+3]]*/
    _34644 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34645 = (object)*(((s1_ptr)_2)->base + _34644);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34645)){
        _67c_65258 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34645)->dbl));
    }
    else{
        _67c_65258 = (object)*(((s1_ptr)_2)->base + _34645);
    }
    if (!IS_ATOM_INT(_67c_65258))
    _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;

    /** execute.e:3109			target = Code[pc+4]*/
    _34647 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34647);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3110			s = val[Code[pc+2]]*/
    _34649 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34650 = (object)*(((s1_ptr)_2)->base + _34649);
    DeRef(_s_69580);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34650)){
        _s_69580 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34650)->dbl));
    }
    else{
        _s_69580 = (object)*(((s1_ptr)_2)->base + _34650);
    }
    Ref(_s_69580);

    /** execute.e:3111			a = Code[pc+1]*/
    _34652 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34652);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3112			if not sequence(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34654 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34655 = IS_SEQUENCE(_34654);
    _34654 = NOVALUE;
    if (_34655 != 0)
    goto L1; // [86] 108
    _34655 = NOVALUE;

    /** execute.e:3113					RTFatal("first argument of match_from() must be a sequence")*/
    RefDS(_34657);
    _67RTFatal(_34657);

    /** execute.e:3114					pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3115					return*/
    DeRef(_s_69580);
    _34650 = NOVALUE;
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    _34652 = NOVALUE;
    _34647 = NOVALUE;
    _34649 = NOVALUE;
    return;
L1: 

    /** execute.e:3117			if length(val[a]) = 0 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34659 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_SEQUENCE(_34659)){
            _34660 = SEQ_PTR(_34659)->length;
    }
    else {
        _34660 = 1;
    }
    _34659 = NOVALUE;
    if (_34660 != 0)
    goto L2; // [121] 144

    /** execute.e:3118					RTFatal("first argument of match_from() must be a non-empty sequence")*/
    RefDS(_34662);
    _67RTFatal(_34662);

    /** execute.e:3119					pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3120					return*/
    DeRef(_s_69580);
    _34650 = NOVALUE;
    DeRef(_34644);
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    DeRef(_34652);
    _34652 = NOVALUE;
    DeRef(_34647);
    _34647 = NOVALUE;
    _34659 = NOVALUE;
    DeRef(_34649);
    _34649 = NOVALUE;
    return;
L2: 

    /** execute.e:3122			if not sequence(s) then*/
    _34664 = IS_SEQUENCE(_s_69580);
    if (_34664 != 0)
    goto L3; // [149] 171
    _34664 = NOVALUE;

    /** execute.e:3123					RTFatal("second argument of match_from() must be a sequence")*/
    RefDS(_34666);
    _67RTFatal(_34666);

    /** execute.e:3124					pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3125					return*/
    DeRef(_s_69580);
    _34650 = NOVALUE;
    DeRef(_34644);
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    DeRef(_34652);
    _34652 = NOVALUE;
    DeRef(_34647);
    _34647 = NOVALUE;
    _34659 = NOVALUE;
    DeRef(_34649);
    _34649 = NOVALUE;
    return;
L3: 

    /** execute.e:3127			if c < 1 then*/
    if (_67c_65258 >= 1)
    goto L4; // [175] 204

    /** execute.e:3128					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34670 = EPrintf(-9999999, _34669, _67c_65258);
    _67RTFatal(_34670);
    _34670 = NOVALUE;

    /** execute.e:3129					pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3130					return*/
    DeRef(_s_69580);
    _34650 = NOVALUE;
    DeRef(_34644);
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    DeRef(_34652);
    _34652 = NOVALUE;
    DeRef(_34647);
    _34647 = NOVALUE;
    _34659 = NOVALUE;
    DeRef(_34649);
    _34649 = NOVALUE;
    return;
L4: 

    /** execute.e:3132			if not (length(s) = 0 and c = 1) and c > length(s) + 1 then*/
    if (IS_SEQUENCE(_s_69580)){
            _34672 = SEQ_PTR(_s_69580)->length;
    }
    else {
        _34672 = 1;
    }
    _34673 = (_34672 == 0);
    _34672 = NOVALUE;
    if (_34673 == 0) {
        DeRef(_34674);
        _34674 = 0;
        goto L5; // [213] 227
    }
    _34675 = (_67c_65258 == 1);
    _34674 = (_34675 != 0);
L5: 
    _34676 = (_34674 == 0);
    _34674 = NOVALUE;
    if (_34676 == 0) {
        goto L6; // [230] 276
    }
    if (IS_SEQUENCE(_s_69580)){
            _34678 = SEQ_PTR(_s_69580)->length;
    }
    else {
        _34678 = 1;
    }
    _34679 = _34678 + 1;
    _34678 = NOVALUE;
    _34680 = (_67c_65258 > _34679);
    _34679 = NOVALUE;
    if (_34680 == 0)
    {
        DeRef(_34680);
        _34680 = NOVALUE;
        goto L6; // [248] 276
    }
    else{
        DeRef(_34680);
        _34680 = NOVALUE;
    }

    /** execute.e:3133					RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _34681 = EPrintf(-9999999, _34669, _67c_65258);
    _67RTFatal(_34681);
    _34681 = NOVALUE;

    /** execute.e:3134					pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3135					return*/
    DeRef(_s_69580);
    DeRef(_34675);
    _34675 = NOVALUE;
    DeRef(_34673);
    _34673 = NOVALUE;
    _34650 = NOVALUE;
    DeRef(_34644);
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    DeRef(_34652);
    _34652 = NOVALUE;
    DeRef(_34647);
    _34647 = NOVALUE;
    _34659 = NOVALUE;
    DeRef(_34649);
    _34649 = NOVALUE;
    DeRef(_34676);
    _34676 = NOVALUE;
    return;
L6: 

    /** execute.e:3137			val[target] = match( val[a], s, c )*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34683 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34684 = e_match_from(_34683, _s_69580, _67c_65258);
    _34683 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34684;
    if( _1 != _34684 ){
        DeRef(_1);
    }
    _34684 = NOVALUE;

    /** execute.e:3138			pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3139	end procedure*/
    DeRef(_s_69580);
    DeRef(_34675);
    _34675 = NOVALUE;
    DeRef(_34673);
    _34673 = NOVALUE;
    _34650 = NOVALUE;
    DeRef(_34644);
    _34644 = NOVALUE;
    _34645 = NOVALUE;
    DeRef(_34652);
    _34652 = NOVALUE;
    DeRef(_34647);
    _34647 = NOVALUE;
    _34659 = NOVALUE;
    DeRef(_34649);
    _34649 = NOVALUE;
    DeRef(_34676);
    _34676 = NOVALUE;
    return;
    ;
}


void _67opPEEK2U()
{
    object _34691 = NOVALUE;
    object _34690 = NOVALUE;
    object _34688 = NOVALUE;
    object _34686 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3142		a = Code[pc+1]*/
    _34686 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34686);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3143		target = Code[pc+2]*/
    _34688 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34688);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3144		val[target] = peek2u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34690 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34690)) {
        _34691 = *(uint16_t *)_34690;
    }
    else if (IS_ATOM(_34690)) {
        _34691 = *(uint16_t *)(uintptr_t)(DBL_PTR(_34690)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34690);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34691 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek2_addr++;
        }
    }
    _34690 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34691;
    if( _1 != _34691 ){
        DeRef(_1);
    }
    _34691 = NOVALUE;

    /** execute.e:3145		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3146	end procedure*/
    _34686 = NOVALUE;
    _34688 = NOVALUE;
    return;
    ;
}


void _67opPEEK2S()
{
    object _34698 = NOVALUE;
    object _34697 = NOVALUE;
    object _34695 = NOVALUE;
    object _34693 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3149		a = Code[pc+1]*/
    _34693 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34693);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3150		target = Code[pc+2]*/
    _34695 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34695);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3151		val[target] = peek2s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34697 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34697)) {
        _34698 = *(int16_t *)_34697;
    }
    else if (IS_ATOM(_34697)) {
        _34698 = *(int16_t *)(uintptr_t)(DBL_PTR(_34697)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34697);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34698 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int16_t)*peek2_addr++;
        }
    }
    _34697 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34698;
    if( _1 != _34698 ){
        DeRef(_1);
    }
    _34698 = NOVALUE;

    /** execute.e:3152		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3153	end procedure*/
    _34693 = NOVALUE;
    _34695 = NOVALUE;
    return;
    ;
}


void _67opPEEK4U()
{
    object _34705 = NOVALUE;
    object _34704 = NOVALUE;
    object _34702 = NOVALUE;
    object _34700 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3156		a = Code[pc+1]*/
    _34700 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34700);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3157		target = Code[pc+2]*/
    _34702 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34702);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3158		val[target] = peek4u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34704 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34704)) {
        _34705 = (object)*(uint32_t *)_34704;
        if ((uintptr_t)_34705 > (uintptr_t)MAXINT){
            _34705 = NewDouble((eudouble)(uintptr_t)_34705);
        }
    }
    else if (IS_ATOM(_34704)) {
        _34705 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_34704)->dbl);
        if ((uintptr_t)_34705 > (uintptr_t)MAXINT){
            _34705 = NewDouble((eudouble)(uintptr_t)_34705);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34704);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34705 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peek4_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34704 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34705;
    if( _1 != _34705 ){
        DeRef(_1);
    }
    _34705 = NOVALUE;

    /** execute.e:3159		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3160	end procedure*/
    _34702 = NOVALUE;
    _34700 = NOVALUE;
    return;
    ;
}


void _67opPEEK4S()
{
    object _34712 = NOVALUE;
    object _34711 = NOVALUE;
    object _34709 = NOVALUE;
    object _34707 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3163		a = Code[pc+1]*/
    _34707 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34707);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3164		target = Code[pc+2]*/
    _34709 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34709);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3165		val[target] = peek4s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34711 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34711)) {
        _34712 = (object)*(int32_t *)_34711;
        if (_34712 < MININT || _34712 > MAXINT){
            _34712 = NewDouble((eudouble)(object)_34712);
        }
    }
    else if (IS_ATOM(_34711)) {
        _34712 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_34711)->dbl);
        if (_34712 < MININT || _34712 > MAXINT){
            _34712 = NewDouble((eudouble)(object)_34712);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_34711);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34712 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)(int32_t)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT){
                _1 = NewDouble((eudouble)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _34711 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34712;
    if( _1 != _34712 ){
        DeRef(_1);
    }
    _34712 = NOVALUE;

    /** execute.e:3166		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3167	end procedure*/
    _34709 = NOVALUE;
    _34707 = NOVALUE;
    return;
    ;
}


void _67opPEEK8U()
{
    object _34719 = NOVALUE;
    object _34718 = NOVALUE;
    object _34716 = NOVALUE;
    object _34714 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3170		a = Code[pc+1]*/
    _34714 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34714);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3171		target = Code[pc+2]*/
    _34716 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34716);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3172		val[target] = peek8u(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34718 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34718)) {
            peek8_longlong = *(int64_t *)_34718;
            if (peek8_longlong > (uint64_t)MAXINT){
                _34719 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34719 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34718)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34718)->dbl);
            if (peek8_longlong > (uint64_t)MAXINT){
                _34719 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _34719 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34718);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34719 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if ((uint64_t)peek8_longlong > (uint64_t)MAXINT){
                    _1 = NewDouble((eudouble) (uint64_t) peek8_longlong);
                }
                else{
                    _1 = (object)peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34718 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34719;
    if( _1 != _34719 ){
        DeRef(_1);
    }
    _34719 = NOVALUE;

    /** execute.e:3173		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3174	end procedure*/
    _34714 = NOVALUE;
    _34716 = NOVALUE;
    return;
    ;
}


void _67opPEEK8S()
{
    object _34726 = NOVALUE;
    object _34725 = NOVALUE;
    object _34723 = NOVALUE;
    object _34721 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3177		a = Code[pc+1]*/
    _34721 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34721);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3178		target = Code[pc+2]*/
    _34723 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34723);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3179		val[target] = peek8s(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34725 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_34725)) {
            peek8_longlong = *(int64_t *)_34725;
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34726 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34726 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_34725)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_34725)->dbl);
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _34726 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _34726 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_34725);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _34726 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if (peek8_longlong < (int64_t) MININT || peek8_longlong > (int64_t) MAXINT){
                    _1 = NewDouble((eudouble)peek8_longlong);
                }
                else{
                    _1 = (object)(int64_t) peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _34725 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34726;
    if( _1 != _34726 ){
        DeRef(_1);
    }
    _34726 = NOVALUE;

    /** execute.e:3180		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3181	end procedure*/
    _34723 = NOVALUE;
    _34721 = NOVALUE;
    return;
    ;
}


void _67opPEEK_STRING()
{
    object _34733 = NOVALUE;
    object _34732 = NOVALUE;
    object _34730 = NOVALUE;
    object _34728 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3183		a = Code[pc+1]*/
    _34728 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34728);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3184		target = Code[pc+2]*/
    _34730 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34730);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3185		val[target] = peek_string(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34732 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34732)) {
        _34733 =  NewString((char *)_34732);
    }
    else if (IS_ATOM(_34732)) {
        _34733 = NewString((char *)(uintptr_t)(DBL_PTR(_34732)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_34732);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34733 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _34732 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34733;
    if( _1 != _34733 ){
        DeRef(_1);
    }
    _34733 = NOVALUE;

    /** execute.e:3186		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3187	end procedure*/
    _34728 = NOVALUE;
    _34730 = NOVALUE;
    return;
    ;
}


void _67opPEEK()
{
    object _34740 = NOVALUE;
    object _34739 = NOVALUE;
    object _34737 = NOVALUE;
    object _34735 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3190		a = Code[pc+1]*/
    _34735 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34735);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3191		target = Code[pc+2]*/
    _34737 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34737);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3192		val[target] = peek(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34739 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34739)) {
        _34740 = *(uint8_t *)_34739;
    }
    else if (IS_ATOM(_34739)) {
        _34740 = *(uint8_t *)(uintptr_t)(DBL_PTR(_34739)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34739);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34740 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
    }
    _34739 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34740;
    if( _1 != _34740 ){
        DeRef(_1);
    }
    _34740 = NOVALUE;

    /** execute.e:3193		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3194	end procedure*/
    _34737 = NOVALUE;
    _34735 = NOVALUE;
    return;
    ;
}


void _67opPEEKS()
{
    object _34747 = NOVALUE;
    object _34746 = NOVALUE;
    object _34744 = NOVALUE;
    object _34742 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3197		a = Code[pc+1]*/
    _34742 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34742);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3198		target = Code[pc+2]*/
    _34744 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34744);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3199		val[target] = peeks(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34746 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34746)) {
        _34747 = *(int8_t *)_34746;
    }
    else if (IS_ATOM(_34746)) {
        _34747 = *(int8_t *)(uintptr_t)(DBL_PTR(_34746)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_34746);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _34747 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int8_t)*peek_addr++;
        }
    }
    _34746 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34747;
    if( _1 != _34747 ){
        DeRef(_1);
    }
    _34747 = NOVALUE;

    /** execute.e:3200		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3201	end procedure*/
    _34742 = NOVALUE;
    _34744 = NOVALUE;
    return;
    ;
}


void _67opSIZEOF()
{
    object _34754 = NOVALUE;
    object _34753 = NOVALUE;
    object _34751 = NOVALUE;
    object _34749 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3204		a = Code[pc+1]*/
    _34749 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34749);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3205		b = Code[pc+2]*/
    _34751 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34751);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3206		val[b] = sizeof( val[a] )*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34753 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34754 = eu_sizeof( _34753 );
    _34753 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67b_65257);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34754;
    if( _1 != _34754 ){
        DeRef(_1);
    }
    _34754 = NOVALUE;

    /** execute.e:3207		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3208	end procedure*/
    _34751 = NOVALUE;
    _34749 = NOVALUE;
    return;
    ;
}


void _67opPOKE()
{
    object _34761 = NOVALUE;
    object _34760 = NOVALUE;
    object _34758 = NOVALUE;
    object _34756 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3211		a = Code[pc+1]*/
    _34756 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34756);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3212		b = Code[pc+2]*/
    _34758 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34758);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3213		poke(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34760 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34761 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34760)){
        poke_addr = (uint8_t *)_34760;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_34760)->dbl);
    }
    if (IS_ATOM_INT(_34761)) {
        *poke_addr = (uint8_t)_34761;
    }
    else if (IS_ATOM(_34761)) {
        *poke_addr = (uint8_t)DBL_PTR(_34761)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34761);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34760 = NOVALUE;
    _34761 = NOVALUE;

    /** execute.e:3214		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3215	end procedure*/
    _34756 = NOVALUE;
    _34758 = NOVALUE;
    return;
    ;
}


void _67opPOKE4()
{
    object _34768 = NOVALUE;
    object _34767 = NOVALUE;
    object _34765 = NOVALUE;
    object _34763 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3218		a = Code[pc+1]*/
    _34763 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34763);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3219		b = Code[pc+2]*/
    _34765 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34765);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3220		poke4(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34767 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34768 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34767)){
        poke4_addr = (uint32_t *)_34767;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_34767)->dbl);
    }
    if (IS_ATOM_INT(_34768)) {
        *poke4_addr = (uint32_t)_34768;
    }
    else if (IS_ATOM(_34768)) {
        *poke4_addr = (uint32_t)DBL_PTR(_34768)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34768);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34767 = NOVALUE;
    _34768 = NOVALUE;

    /** execute.e:3221		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3222	end procedure*/
    _34763 = NOVALUE;
    _34765 = NOVALUE;
    return;
    ;
}


void _67opPOKE8()
{
    object _34775 = NOVALUE;
    object _34774 = NOVALUE;
    object _34772 = NOVALUE;
    object _34770 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3225		a = Code[pc+1]*/
    _34770 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34770);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3226		b = Code[pc+2]*/
    _34772 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34772);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3227		poke8(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34774 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34775 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34774)){
        poke8_addr = (uint64_t *)_34774;
    }
    else {
        poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_34774)->dbl);
    }
    if (IS_ATOM_INT(_34775)) {
        *poke8_addr = (uint64_t)_34775;
    }
    else if (IS_ATOM(_34775)) {
        *poke8_addr = (uint64_t)DBL_PTR(_34775)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34775);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke8_addr++ = (uint64_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke8_addr++ = (uint64_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34774 = NOVALUE;
    _34775 = NOVALUE;

    /** execute.e:3228		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3229	end procedure*/
    _34770 = NOVALUE;
    _34772 = NOVALUE;
    return;
    ;
}


void _67opPOKE2()
{
    object _34782 = NOVALUE;
    object _34781 = NOVALUE;
    object _34779 = NOVALUE;
    object _34777 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3232		a = Code[pc+1]*/
    _34777 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34777);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3233		b = Code[pc+2]*/
    _34779 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34779);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3234		poke2(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34781 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34782 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_ATOM_INT(_34781)){
        poke2_addr = (uint16_t *)_34781;
    }
    else {
        poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_34781)->dbl);
    }
    if (IS_ATOM_INT(_34782)) {
        *poke2_addr = (uint16_t)_34782;
    }
    else if (IS_ATOM(_34782)) {
        *poke2_addr = (uint16_t)DBL_PTR(_34782)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_34782);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke2_addr++ = (uint16_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke2_addr++ = (uint16_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34781 = NOVALUE;
    _34782 = NOVALUE;

    /** execute.e:3235		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3236	end procedure*/
    _34777 = NOVALUE;
    _34779 = NOVALUE;
    return;
    ;
}


void _67opMEM_COPY()
{
    object _34792 = NOVALUE;
    object _34791 = NOVALUE;
    object _34790 = NOVALUE;
    object _34788 = NOVALUE;
    object _34786 = NOVALUE;
    object _34784 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3240		a = Code[pc+1]*/
    _34784 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34784);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3241		b = Code[pc+2]*/
    _34786 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34786);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3242		c = Code[pc+3]*/
    _34788 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _34788);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3243		mem_copy(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34790 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34791 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34792 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    memory_copy(_34790, _34791, _34792);
    _34790 = NOVALUE;
    _34791 = NOVALUE;
    _34792 = NOVALUE;

    /** execute.e:3244		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3245	end procedure*/
    _34788 = NOVALUE;
    _34784 = NOVALUE;
    _34786 = NOVALUE;
    return;
    ;
}


void _67opMEM_SET()
{
    object _34802 = NOVALUE;
    object _34801 = NOVALUE;
    object _34800 = NOVALUE;
    object _34798 = NOVALUE;
    object _34796 = NOVALUE;
    object _34794 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3248		a = Code[pc+1]*/
    _34794 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34794);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3249		b = Code[pc+2]*/
    _34796 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34796);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3250		c = Code[pc+3]*/
    _34798 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _34798);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3251		mem_set(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34800 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34801 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34802 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    memory_set(_34800, _34801, _34802);
    _34800 = NOVALUE;
    _34801 = NOVALUE;
    _34802 = NOVALUE;

    /** execute.e:3252		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3253	end procedure*/
    _34798 = NOVALUE;
    _34796 = NOVALUE;
    _34794 = NOVALUE;
    return;
    ;
}


void _67opCALL()
{
    object _34806 = NOVALUE;
    object _34804 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3256		a = Code[pc+1]*/
    _34804 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34804);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3257		call(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34806 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34806))
    _0 = (object)_34806;
    else
    _0 = (object)(uintptr_t)(DBL_PTR(_34806)->dbl);
    (*(void(*)())_0)();
    _34806 = NOVALUE;

    /** execute.e:3258		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3259	end procedure*/
    _34804 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM()
{
    object _34819 = NOVALUE;
    object _34818 = NOVALUE;
    object _34816 = NOVALUE;
    object _34815 = NOVALUE;
    object _34813 = NOVALUE;
    object _34812 = NOVALUE;
    object _34810 = NOVALUE;
    object _34808 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3262		a = Code[pc+1]*/
    _34808 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34808);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3263		b = Code[pc+2]*/
    _34810 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34810);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3264		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34812 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34813 = IS_ATOM(_34812);
    _34812 = NOVALUE;
    if (_34813 == 0)
    {
        _34813 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34813 = NOVALUE;
    }

    /** execute.e:3265			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34814);
    _67RTFatal(_34814);
L1: 

    /** execute.e:3267		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34815 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34816 = IS_SEQUENCE(_34815);
    _34815 = NOVALUE;
    if (_34816 == 0)
    {
        _34816 = NOVALUE;
        goto L2; // [68] 77
    }
    else{
        _34816 = NOVALUE;
    }

    /** execute.e:3268			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34817);
    _67RTFatal(_34817);
L2: 

    /** execute.e:3270		system(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34818 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34819 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    system_call(_34818, _34819);
    _34818 = NOVALUE;
    _34819 = NOVALUE;

    /** execute.e:3271		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3272	end procedure*/
    DeRef(_34810);
    _34810 = NOVALUE;
    DeRef(_34808);
    _34808 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM_EXEC()
{
    object _34833 = NOVALUE;
    object _34832 = NOVALUE;
    object _34831 = NOVALUE;
    object _34830 = NOVALUE;
    object _34829 = NOVALUE;
    object _34828 = NOVALUE;
    object _34827 = NOVALUE;
    object _34825 = NOVALUE;
    object _34823 = NOVALUE;
    object _34821 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3275		a = Code[pc+1]*/
    _34821 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34821);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3276		b = Code[pc+2]*/
    _34823 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34823);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3277		target = Code[pc+3]*/
    _34825 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34825);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3278		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34827 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34828 = IS_ATOM(_34827);
    _34827 = NOVALUE;
    if (_34828 == 0)
    {
        _34828 = NOVALUE;
        goto L1; // [62] 71
    }
    else{
        _34828 = NOVALUE;
    }

    /** execute.e:3279			RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34814);
    _67RTFatal(_34814);
L1: 

    /** execute.e:3281		if sequence(val[b]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34829 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34830 = IS_SEQUENCE(_34829);
    _34829 = NOVALUE;
    if (_34830 == 0)
    {
        _34830 = NOVALUE;
        goto L2; // [84] 93
    }
    else{
        _34830 = NOVALUE;
    }

    /** execute.e:3282			RTFatal("second argument of system() must be an atom")*/
    RefDS(_34817);
    _67RTFatal(_34817);
L2: 

    /** execute.e:3284		val[target] = system_exec(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34831 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34832 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34833 = system_exec_call(_34831, _34832);
    _34831 = NOVALUE;
    _34832 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34833;
    if( _1 != _34833 ){
        DeRef(_1);
    }
    _34833 = NOVALUE;

    /** execute.e:3285		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3286	end procedure*/
    DeRef(_34821);
    _34821 = NOVALUE;
    DeRef(_34823);
    _34823 = NOVALUE;
    DeRef(_34825);
    _34825 = NOVALUE;
    return;
    ;
}


void _67opOPEN()
{
    object _34860 = NOVALUE;
    object _34859 = NOVALUE;
    object _34858 = NOVALUE;
    object _34857 = NOVALUE;
    object _34854 = NOVALUE;
    object _34853 = NOVALUE;
    object _34851 = NOVALUE;
    object _34850 = NOVALUE;
    object _34848 = NOVALUE;
    object _34847 = NOVALUE;
    object _34846 = NOVALUE;
    object _34844 = NOVALUE;
    object _34843 = NOVALUE;
    object _34841 = NOVALUE;
    object _34839 = NOVALUE;
    object _34837 = NOVALUE;
    object _34835 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3291		a = Code[pc+1]*/
    _34835 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34835);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3292		b = Code[pc+2]*/
    _34837 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34837);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3293		c = Code[pc+3]*/
    _34839 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _34839);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3294		target = Code[pc+4]*/
    _34841 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34841);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3296		if atom(val[b]) or length(val[b]) > 2 then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34843 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34844 = IS_ATOM(_34843);
    _34843 = NOVALUE;
    if (_34844 != 0) {
        goto L1; // [78] 102
    }
    _2 = (object)SEQ_PTR(_67val_65265);
    _34846 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    if (IS_SEQUENCE(_34846)){
            _34847 = SEQ_PTR(_34846)->length;
    }
    else {
        _34847 = 1;
    }
    _34846 = NOVALUE;
    _34848 = (_34847 > 2);
    _34847 = NOVALUE;
    if (_34848 == 0)
    {
        DeRef(_34848);
        _34848 = NOVALUE;
        goto L2; // [98] 108
    }
    else{
        DeRef(_34848);
        _34848 = NOVALUE;
    }
L1: 

    /** execute.e:3297		   RTFatal("invalid open mode")*/
    RefDS(_34849);
    _67RTFatal(_34849);
L2: 

    /** execute.e:3299		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34850 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34851 = IS_ATOM(_34850);
    _34850 = NOVALUE;
    if (_34851 == 0)
    {
        _34851 = NOVALUE;
        goto L3; // [121] 130
    }
    else{
        _34851 = NOVALUE;
    }

    /** execute.e:3300		   RTFatal("device or file name must be a sequence")*/
    RefDS(_34852);
    _67RTFatal(_34852);
L3: 

    /** execute.e:3302		if not atom(val[c]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34853 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    _34854 = IS_ATOM(_34853);
    _34853 = NOVALUE;
    if (_34854 != 0)
    goto L4; // [143] 152
    _34854 = NOVALUE;

    /** execute.e:3303			RTFatal("cleanup must be an atom")*/
    RefDS(_34856);
    _67RTFatal(_34856);
L4: 

    /** execute.e:3305		val[target] = open(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34857 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34858 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34859 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    _34860 = EOpen(_34857, _34858, _34859);
    _34857 = NOVALUE;
    _34858 = NOVALUE;
    _34859 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34860;
    if( _1 != _34860 ){
        DeRef(_1);
    }
    _34860 = NOVALUE;

    /** execute.e:3306		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3307	end procedure*/
    DeRef(_34839);
    _34839 = NOVALUE;
    DeRef(_34835);
    _34835 = NOVALUE;
    _34846 = NOVALUE;
    DeRef(_34837);
    _34837 = NOVALUE;
    DeRef(_34841);
    _34841 = NOVALUE;
    return;
    ;
}


void _67opCLOSE()
{
    object _34864 = NOVALUE;
    object _34862 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3310		a = Code[pc+1]*/
    _34862 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34862);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3311		close(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34864 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (IS_ATOM_INT(_34864))
    EClose(_34864);
    else
    EClose((object)DBL_PTR(_34864)->dbl);
    _34864 = NOVALUE;

    /** execute.e:3312		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3313	end procedure*/
    _34862 = NOVALUE;
    return;
    ;
}


void _67opABORT()
{
    object _34868 = NOVALUE;
    object _34867 = NOVALUE;
    object _34866 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3316		Cleanup(val[Code[pc+1]])*/
    _34866 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34867 = (object)*(((s1_ptr)_2)->base + _34866);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34867)){
        _34868 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34867)->dbl));
    }
    else{
        _34868 = (object)*(((s1_ptr)_2)->base + _34867);
    }
    Ref(_34868);
    _49Cleanup(_34868);
    _34868 = NOVALUE;

    /** execute.e:3317	end procedure*/
    _34866 = NOVALUE;
    _34867 = NOVALUE;
    return;
    ;
}


void _67opGETC()
{
    object _34874 = NOVALUE;
    object _34873 = NOVALUE;
    object _34871 = NOVALUE;
    object _34869 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3320		a = Code[pc+1]*/
    _34869 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34869);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3321		target = Code[pc+2]*/
    _34871 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34871);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3322		val[target] = getc(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34873 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (_34873 != last_r_file_no) {
        last_r_file_ptr = which_file(_34873, EF_READ);
        if (IS_ATOM_INT(_34873)){
            last_r_file_no = _34873;
        }
        else{
            last_r_file_no = NOVALUE;
        }
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _34874 = getKBchar();
        }
        else{
            _34874 = getc(last_r_file_ptr);
        }
    }
    else{
        _34874 = getc(last_r_file_ptr);
    }
    _34873 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34874;
    if( _1 != _34874 ){
        DeRef(_1);
    }
    _34874 = NOVALUE;

    /** execute.e:3323		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3324	end procedure*/
    _34869 = NOVALUE;
    _34871 = NOVALUE;
    return;
    ;
}


void _67opGETS()
{
    object _34881 = NOVALUE;
    object _34880 = NOVALUE;
    object _34878 = NOVALUE;
    object _34876 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3328		a = Code[pc+1]*/
    _34876 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34876);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3329		target = Code[pc+2]*/
    _34878 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34878);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3330		val[target] = gets(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34880 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34881 = EGets(_34880);
    _34880 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34881;
    if( _1 != _34881 ){
        DeRef(_1);
    }
    _34881 = NOVALUE;

    /** execute.e:3331		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3332	end procedure*/
    _34878 = NOVALUE;
    _34876 = NOVALUE;
    return;
    ;
}


void _67opGET_KEY()
{
    object _34885 = NOVALUE;
    object _34883 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3337		target = Code[pc+1]*/
    _34883 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34883);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3338		val[target] = get_key()*/
    show_console();
    _34885 = get_key(0);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34885;
    if( _1 != _34885 ){
        DeRef(_1);
    }
    _34885 = NOVALUE;

    /** execute.e:3339		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3340	end procedure*/
    _34883 = NOVALUE;
    return;
    ;
}


void _67opCLEAR_SCREEN()
{
    object _0, _1, _2;
    

    /** execute.e:3343		clear_screen()*/
    ClearScreen();

    /** execute.e:3344		pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:3345	end procedure*/
    return;
    ;
}


void _67opPUTS()
{
    object _34893 = NOVALUE;
    object _34892 = NOVALUE;
    object _34890 = NOVALUE;
    object _34888 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3348		a = Code[pc+1]*/
    _34888 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34888);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3349		b = Code[pc+2]*/
    _34890 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34890);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3350		puts(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34892 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34893 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    EPuts(_34892, _34893); // DJP 
    _34892 = NOVALUE;
    _34893 = NOVALUE;

    /** execute.e:3351		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3352	end procedure*/
    _34888 = NOVALUE;
    _34890 = NOVALUE;
    return;
    ;
}


void _67opQPRINT()
{
    object _34897 = NOVALUE;
    object _34895 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3356		a = Code[pc+2]*/
    _34895 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34895);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3357		? val[a]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34897 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    StdPrint(1, _34897, 1);
    _34897 = NOVALUE;

    /** execute.e:3358		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3359	end procedure*/
    _34895 = NOVALUE;
    return;
    ;
}


void _67opPRINT()
{
    object _34904 = NOVALUE;
    object _34903 = NOVALUE;
    object _34901 = NOVALUE;
    object _34899 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3362		a = Code[pc+1]*/
    _34899 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34899);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3363		b = Code[pc+2]*/
    _34901 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34901);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3364		print(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34903 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34904 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    StdPrint(_34903, _34904, 0);
    _34903 = NOVALUE;
    _34904 = NOVALUE;

    /** execute.e:3365		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3366	end procedure*/
    _34901 = NOVALUE;
    _34899 = NOVALUE;
    return;
    ;
}


void _67opPRINTF()
{
    object _34914 = NOVALUE;
    object _34913 = NOVALUE;
    object _34912 = NOVALUE;
    object _34910 = NOVALUE;
    object _34908 = NOVALUE;
    object _34906 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3370		a = Code[pc+1]*/
    _34906 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34906);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3371		b = Code[pc+2]*/
    _34908 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34908);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3372		c = Code[pc+3]*/
    _34910 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _34910);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3373		printf(val[a], val[b], val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34912 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34913 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34914 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    EPrintf(_34912, _34913, _34914);
    _34912 = NOVALUE;
    _34913 = NOVALUE;
    _34914 = NOVALUE;

    /** execute.e:3374		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3375	end procedure*/
    _34910 = NOVALUE;
    _34906 = NOVALUE;
    _34908 = NOVALUE;
    return;
    ;
}


void _67opSPRINTF()
{
    object _34924 = NOVALUE;
    object _34923 = NOVALUE;
    object _34922 = NOVALUE;
    object _34920 = NOVALUE;
    object _34918 = NOVALUE;
    object _34916 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3378		a = Code[pc+1]*/
    _34916 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34916);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3379		b = Code[pc+2]*/
    _34918 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34918);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3380		target = Code[pc+3]*/
    _34920 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34920);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3381		val[target] = sprintf(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34922 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34923 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _34924 = EPrintf(-9999999, _34922, _34923);
    _34922 = NOVALUE;
    _34923 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34924;
    if( _1 != _34924 ){
        DeRef(_1);
    }
    _34924 = NOVALUE;

    /** execute.e:3382		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3383	end procedure*/
    _34920 = NOVALUE;
    _34918 = NOVALUE;
    _34916 = NOVALUE;
    return;
    ;
}


void _67opCOMMAND_LINE()
{
    object _cmd_70006 = NOVALUE;
    object _34934 = NOVALUE;
    object _34933 = NOVALUE;
    object _34932 = NOVALUE;
    object _34931 = NOVALUE;
    object _34929 = NOVALUE;
    object _34926 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3388		target = Code[pc+1]*/
    _34926 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34926);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3389		cmd = command_line()*/
    DeRef(_cmd_70006);
    _cmd_70006 = Command_Line();

    /** execute.e:3391		if length(cmd) > 2 then*/
    if (IS_SEQUENCE(_cmd_70006)){
            _34929 = SEQ_PTR(_cmd_70006)->length;
    }
    else {
        _34929 = 1;
    }
    if (_34929 <= 2)
    goto L1; // [26] 53

    /** execute.e:3392			cmd = {cmd[1]} & cmd[3..$]*/
    _2 = (object)SEQ_PTR(_cmd_70006);
    _34931 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_34931);
    ((intptr_t*)_2)[1] = _34931;
    _34932 = MAKE_SEQ(_1);
    _34931 = NOVALUE;
    if (IS_SEQUENCE(_cmd_70006)){
            _34933 = SEQ_PTR(_cmd_70006)->length;
    }
    else {
        _34933 = 1;
    }
    rhs_slice_target = (object_ptr)&_34934;
    RHS_Slice(_cmd_70006, 3, _34933);
    Concat((object_ptr)&_cmd_70006, _34932, _34934);
    DeRefDS(_34932);
    _34932 = NOVALUE;
    DeRef(_34932);
    _34932 = NOVALUE;
    DeRefDS(_34934);
    _34934 = NOVALUE;
L1: 

    /** execute.e:3394		val[target] = cmd*/
    RefDS(_cmd_70006);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_70006;
    DeRef(_1);

    /** execute.e:3395		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3396	end procedure*/
    DeRefDS(_cmd_70006);
    DeRef(_34926);
    _34926 = NOVALUE;
    return;
    ;
}


void _67opOPTION_SWITCHES()
{
    object _cmd_70022 = NOVALUE;
    object _34937 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3401		target = Code[pc+1]*/
    _34937 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34937);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3402		cmd = option_switches()*/
    DeRef(_cmd_70022);
    RefDS(_0switches);
    _cmd_70022 = _0switches;

    /** execute.e:3403		val[target] = cmd*/
    RefDS(_cmd_70022);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _cmd_70022;
    DeRef(_1);

    /** execute.e:3404		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3405	end procedure*/
    DeRefDS(_cmd_70022);
    _34937 = NOVALUE;
    return;
    ;
}


void _67opGETENV()
{
    object _34949 = NOVALUE;
    object _34948 = NOVALUE;
    object _34946 = NOVALUE;
    object _34945 = NOVALUE;
    object _34943 = NOVALUE;
    object _34941 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3408		a = Code[pc+1]*/
    _34941 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34941);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3409		target = Code[pc+2]*/
    _34943 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _34943);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3410		if atom(val[a]) then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34945 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34946 = IS_ATOM(_34945);
    _34945 = NOVALUE;
    if (_34946 == 0)
    {
        _34946 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34946 = NOVALUE;
    }

    /** execute.e:3411			RTFatal("argument to getenv must be a sequence")*/
    RefDS(_34947);
    _67RTFatal(_34947);
L1: 

    /** execute.e:3413		val[target] = getenv(val[a])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34948 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _34949 = EGetEnv(_34948);
    _34948 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34949;
    if( _1 != _34949 ){
        DeRef(_1);
    }
    _34949 = NOVALUE;

    /** execute.e:3414		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3415	end procedure*/
    DeRef(_34943);
    _34943 = NOVALUE;
    DeRef(_34941);
    _34941 = NOVALUE;
    return;
    ;
}


void _67opC_PROC()
{
    object _sub_70046 = NOVALUE;
    object _34958 = NOVALUE;
    object _34957 = NOVALUE;
    object _34955 = NOVALUE;
    object _34953 = NOVALUE;
    object _34951 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3420		a = Code[pc+1]*/
    _34951 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34951);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3421		b = Code[pc+2]*/
    _34953 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34953);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3422		sub = Code[pc+3]*/
    _34955 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_70046 = (object)*(((s1_ptr)_2)->base + _34955);
    if (!IS_ATOM_INT(_sub_70046)){
        _sub_70046 = (object)DBL_PTR(_sub_70046)->dbl;
    }

    /** execute.e:3423		c_proc(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34957 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34958 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    call_c(0, _34957, _34958);
    _34957 = NOVALUE;
    _34958 = NOVALUE;

    /** execute.e:3424		restore_privates(sub)*/
    _67restore_privates(_sub_70046);

    /** execute.e:3425		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3426	end procedure*/
    _34953 = NOVALUE;
    _34951 = NOVALUE;
    _34955 = NOVALUE;
    return;
    ;
}


void _67opC_FUNC()
{
    object _target_70061 = NOVALUE;
    object _sub_70063 = NOVALUE;
    object _temp_70064 = NOVALUE;
    object _34969 = NOVALUE;
    object _34968 = NOVALUE;
    object _34966 = NOVALUE;
    object _34964 = NOVALUE;
    object _34962 = NOVALUE;
    object _34960 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3431		object temp*/

    /** execute.e:3433		a = Code[pc+1]*/
    _34960 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _34960);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3434		b = Code[pc+2]*/
    _34962 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _34962);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3435		sub = Code[pc+3]*/
    _34964 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _sub_70063 = (object)*(((s1_ptr)_2)->base + _34964);
    if (!IS_ATOM_INT(_sub_70063)){
        _sub_70063 = (object)DBL_PTR(_sub_70063)->dbl;
    }

    /** execute.e:3436		target = Code[pc+4]*/
    _34966 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _target_70061 = (object)*(((s1_ptr)_2)->base + _34966);
    if (!IS_ATOM_INT(_target_70061)){
        _target_70061 = (object)DBL_PTR(_target_70061)->dbl;
    }

    /** execute.e:3437		temp = c_func(val[a], val[b])  -- callback could happen here*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34968 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _34969 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    DeRef(_temp_70064);
    _temp_70064 = call_c(1, _34968, _34969);
    _34968 = NOVALUE;
    _34969 = NOVALUE;

    /** execute.e:3438		restore_privates(sub)*/
    _67restore_privates(_sub_70063);

    /** execute.e:3439		val[target] = temp*/
    Ref(_temp_70064);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _target_70061);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _temp_70064;
    DeRef(_1);

    /** execute.e:3440		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3441	end procedure*/
    DeRef(_temp_70064);
    _34962 = NOVALUE;
    _34966 = NOVALUE;
    _34960 = NOVALUE;
    _34964 = NOVALUE;
    return;
    ;
}


void _67opTRACE()
{
    object _34973 = NOVALUE;
    object _34972 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3444		TraceOn = val[Code[pc+1]]*/
    _34972 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _34973 = (object)*(((s1_ptr)_2)->base + _34972);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_34973)){
        _67TraceOn_65253 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34973)->dbl));
    }
    else{
        _67TraceOn_65253 = (object)*(((s1_ptr)_2)->base + _34973);
    }
    if (!IS_ATOM_INT(_67TraceOn_65253))
    _67TraceOn_65253 = (object)DBL_PTR(_67TraceOn_65253)->dbl;

    /** execute.e:3445		pc += 2  -- turn on/off tracing*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3446	end procedure*/
    _34972 = NOVALUE;
    _34973 = NOVALUE;
    return;
    ;
}


void _67opPROFILE()
{
    object _0, _1, _2;
    

    /** execute.e:3452		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3453	end procedure*/
    return;
    ;
}


void _67opUPDATE_GLOBALS()
{
    object _0, _1, _2;
    

    /** execute.e:3458		pc += 1*/
    _67pc_65255 = _67pc_65255 + 1;

    /** execute.e:3459	end procedure*/
    return;
    ;
}


object _67general_callback(object _rtn_def_70096, object _args_70097)
{
    object _arglist_assign_70099 = NOVALUE;
    object _34995 = NOVALUE;
    object _34993 = NOVALUE;
    object _34992 = NOVALUE;
    object _34991 = NOVALUE;
    object _34988 = NOVALUE;
    object _34987 = NOVALUE;
    object _34985 = NOVALUE;
    object _34984 = NOVALUE;
    object _34980 = NOVALUE;
    object _34978 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3493		val[t_id] = rtn_def[C_USER_ROUTINE]*/
    _2 = (object)SEQ_PTR(_rtn_def_70096);
    _34978 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_34978);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_65186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34978;
    if( _1 != _34978 ){
        DeRef(_1);
    }
    _34978 = NOVALUE;

    /** execute.e:3494		val[t_arglist] = args*/
    RefDS(_args_70097);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _args_70097;
    DeRef(_1);

    /** execute.e:3495		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_70099;
    _arglist_assign_70099 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3497		SymTab[call_back_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67call_back_routine_65189 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65272;
    DeRef(_1);
    _34980 = NOVALUE;

    /** execute.e:3500		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _67pc_65255);

    /** execute.e:3501		call_stack = append(call_stack, call_back_routine)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _67call_back_routine_65189);

    /** execute.e:3503		Code = call_back_code*/
    RefDS(_67call_back_code_65183);
    DeRef(_27Code_20660);
    _27Code_20660 = _67call_back_code_65183;

    /** execute.e:3504		pc = 1*/
    _67pc_65255 = 1;

    /** execute.e:3506		do_exec()*/
    _67do_exec();

    /** execute.e:3509		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _34984 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _34984 = 1;
    }
    _34985 = _34984 - 1;
    _34984 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _34985);
    if (!IS_ATOM_INT(_67pc_65255))
    _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;

    /** execute.e:3510		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _34987 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _34987 = 1;
    }
    _34988 = _34987 - 2;
    _34987 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65273;
    RHS_Slice(_67call_stack_65273, 1, _34988);

    /** execute.e:3512		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_70099, _67arg_assign_65199)){
        goto L1; // [126] 143
    }

    /** execute.e:3513			val[t_arglist] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:3516		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _34991 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _34991 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _34992 = (object)*(((s1_ptr)_2)->base + _34991);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_34992)){
        _34993 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_34992)->dbl));
    }
    else{
        _34993 = (object)*(((s1_ptr)_2)->base + _34992);
    }
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_34993);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _34993 = NOVALUE;

    /** execute.e:3518		return val[t_return_val]*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _34995 = (object)*(((s1_ptr)_2)->base + _67t_return_val_65188);
    Ref(_34995);
    DeRefDS(_rtn_def_70096);
    DeRefDS(_args_70097);
    DeRef(_arglist_assign_70099);
    _34992 = NOVALUE;
    DeRef(_34985);
    _34985 = NOVALUE;
    DeRef(_34988);
    _34988 = NOVALUE;
    return _34995;
    ;
}


object _67machine_callback(object _cbx_70130, object _ptr_70131)
{
    object _rtn_def_70132 = NOVALUE;
    object _args_70133 = NOVALUE;
    object _35003 = NOVALUE;
    object _35001 = NOVALUE;
    object _35000 = NOVALUE;
    object _34999 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3528		rtn_def = call_backs[cbx]*/
    DeRef(_rtn_def_70132);
    _2 = (object)SEQ_PTR(_67call_backs_65182);
    if (!IS_ATOM_INT(_cbx_70130)){
        _rtn_def_70132 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_70130)->dbl));
    }
    else{
        _rtn_def_70132 = (object)*(((s1_ptr)_2)->base + _cbx_70130);
    }
    RefDS(_rtn_def_70132);

    /** execute.e:3529		args = peek4u(ptr & call_backs[cbx][C_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_67call_backs_65182);
    if (!IS_ATOM_INT(_cbx_70130)){
        _34999 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_cbx_70130)->dbl));
    }
    else{
        _34999 = (object)*(((s1_ptr)_2)->base + _cbx_70130);
    }
    _2 = (object)SEQ_PTR(_34999);
    _35000 = (object)*(((s1_ptr)_2)->base + 3);
    _34999 = NOVALUE;
    if (IS_SEQUENCE(_ptr_70131) && IS_ATOM(_35000)) {
    }
    else if (IS_ATOM(_ptr_70131) && IS_SEQUENCE(_35000)) {
        Ref(_ptr_70131);
        Prepend(&_35001, _35000, _ptr_70131);
    }
    else {
        Concat((object_ptr)&_35001, _ptr_70131, _35000);
    }
    _35000 = NOVALUE;
    DeRef(_args_70133);
    _1 = (object)SEQ_PTR(_35001);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _args_70133 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)*peek4_addr++;
        if ((uintptr_t)_1 > (uintptr_t)MAXINT){
            _1 = NewDouble((eudouble)(uintptr_t)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_35001);
    _35001 = NOVALUE;

    /** execute.e:3531		return general_callback(rtn_def, args)*/
    RefDS(_rtn_def_70132);
    RefDS(_args_70133);
    _35003 = _67general_callback(_rtn_def_70132, _args_70133);
    DeRef(_cbx_70130);
    DeRef(_ptr_70131);
    DeRefDS(_rtn_def_70132);
    DeRefDS(_args_70133);
    return _35003;
    ;
}


object _67callback(object _a_70148)
{
    object _35007 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3626		return machine_func(M_CALL_BACK, a)*/
    _35007 = machine(52, _a_70148);
    DeRefi(_a_70148);
    return _35007;
    ;
}


void _67do_callback(object _b_70152)
{
    object _r_70154 = NOVALUE;
    object _asm_70155 = NOVALUE;
    object _id_70156 = NOVALUE;
    object _convention_70157 = NOVALUE;
    object _x_70158 = NOVALUE;
    object _35068 = NOVALUE;
    object _35067 = NOVALUE;
    object _35066 = NOVALUE;
    object _35065 = NOVALUE;
    object _35064 = NOVALUE;
    object _35063 = NOVALUE;
    object _35062 = NOVALUE;
    object _35061 = NOVALUE;
    object _35060 = NOVALUE;
    object _35059 = NOVALUE;
    object _35058 = NOVALUE;
    object _35057 = NOVALUE;
    object _35055 = NOVALUE;
    object _35036 = NOVALUE;
    object _35035 = NOVALUE;
    object _35033 = NOVALUE;
    object _35032 = NOVALUE;
    object _35031 = NOVALUE;
    object _35030 = NOVALUE;
    object _35029 = NOVALUE;
    object _35028 = NOVALUE;
    object _35027 = NOVALUE;
    object _35026 = NOVALUE;
    object _35025 = NOVALUE;
    object _35024 = NOVALUE;
    object _35022 = NOVALUE;
    object _35021 = NOVALUE;
    object _35020 = NOVALUE;
    object _35019 = NOVALUE;
    object _35017 = NOVALUE;
    object _35015 = NOVALUE;
    object _35014 = NOVALUE;
    object _35012 = NOVALUE;
    object _35009 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3631		atom asm*/

    /** execute.e:3632		integer id, convention*/

    /** execute.e:3633		object x*/

    /** execute.e:3636		x = val[b]*/
    DeRef(_x_70158);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_70158 = (object)*(((s1_ptr)_2)->base + _b_70152);
    Ref(_x_70158);

    /** execute.e:3637		if atom(x) then*/
    _35009 = IS_ATOM(_x_70158);
    if (_35009 == 0)
    {
        _35009 = NOVALUE;
        goto L1; // [22] 40
    }
    else{
        _35009 = NOVALUE;
    }

    /** execute.e:3638			id = x*/
    Ref(_x_70158);
    _id_70156 = _x_70158;
    if (!IS_ATOM_INT(_id_70156)) {
        _1 = (object)(DBL_PTR(_id_70156)->dbl);
        DeRefDS(_id_70156);
        _id_70156 = _1;
    }

    /** execute.e:3639			convention = 0*/
    _convention_70157 = 0;
    goto L2; // [37] 57
L1: 

    /** execute.e:3641			id = x[2]*/
    _2 = (object)SEQ_PTR(_x_70158);
    _id_70156 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_id_70156)){
        _id_70156 = (object)DBL_PTR(_id_70156)->dbl;
    }

    /** execute.e:3642			convention = x[1]*/
    _2 = (object)SEQ_PTR(_x_70158);
    _convention_70157 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_convention_70157)){
        _convention_70157 = (object)DBL_PTR(_convention_70157)->dbl;
    }
L2: 

    /** execute.e:3645		if id < 0 or id >= length(e_routine) then*/
    _35012 = (_id_70156 < 0);
    if (_35012 != 0) {
        goto L3; // [65] 83
    }
    if (IS_SEQUENCE(_67e_routine_65303)){
            _35014 = SEQ_PTR(_67e_routine_65303)->length;
    }
    else {
        _35014 = 1;
    }
    _35015 = (_id_70156 >= _35014);
    _35014 = NOVALUE;
    if (_35015 == 0)
    {
        DeRef(_35015);
        _35015 = NOVALUE;
        goto L4; // [79] 89
    }
    else{
        DeRef(_35015);
        _35015 = NOVALUE;
    }
L3: 

    /** execute.e:3646			RTFatal("Invalid routine id")*/
    RefDS(_35016);
    _67RTFatal(_35016);
L4: 

    /** execute.e:3649		r = e_routine[id+1]*/
    _35017 = _id_70156 + 1;
    _2 = (object)SEQ_PTR(_67e_routine_65303);
    _r_70154 = (object)*(((s1_ptr)_2)->base + _35017);

    /** execute.e:3651		if platform() = WIN32 and convention = 0 then*/
    _35019 = (2 == 2);
    if (_35019 == 0) {
        goto L5; // [111] 224
    }
    _35021 = (_convention_70157 == 0);
    if (_35021 == 0)
    {
        DeRef(_35021);
        _35021 = NOVALUE;
        goto L5; // [122] 224
    }
    else{
        DeRef(_35021);
        _35021 = NOVALUE;
    }

    /** execute.e:3653			asm = dep:allocate_protect(length(cb_std), 1, PAGE_EXECUTE_READWRITE)*/
    _35022 = 24;
    _0 = _asm_70155;
    _asm_70155 = _6allocate_protect(24, 1, 64);
    DeRef(_0);
    _35022 = NOVALUE;

    /** execute.e:3654			poke( asm, cb_std )*/
    if (IS_ATOM_INT(_asm_70155)){
        poke_addr = (uint8_t *)_asm_70155;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_70155)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_std_70140);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3655			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35024 = _asm_70155 + 7;
        if ((object)((uintptr_t)_35024 + (uintptr_t)HIGH_BITS) >= 0){
            _35024 = NewDouble((eudouble)_35024);
        }
    }
    else {
        _35024 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)7);
    }
    if (IS_SEQUENCE(_67call_backs_65182)){
            _35025 = SEQ_PTR(_67call_backs_65182)->length;
    }
    else {
        _35025 = 1;
    }
    _35026 = _35025 + 1;
    _35025 = NOVALUE;
    if (IS_ATOM_INT(_35024)){
        poke4_addr = (uint32_t *)_35024;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35024)->dbl);
    }
    *poke4_addr = (uint32_t)_35026;
    DeRef(_35024);
    _35024 = NOVALUE;
    _35026 = NOVALUE;

    /** execute.e:3656			poke4( asm + 13, asm + 20 )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35027 = _asm_70155 + 13;
        if ((object)((uintptr_t)_35027 + (uintptr_t)HIGH_BITS) >= 0){
            _35027 = NewDouble((eudouble)_35027);
        }
    }
    else {
        _35027 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)13);
    }
    if (IS_ATOM_INT(_asm_70155)) {
        _35028 = _asm_70155 + 20;
        if ((object)((uintptr_t)_35028 + (uintptr_t)HIGH_BITS) >= 0){
            _35028 = NewDouble((eudouble)_35028);
        }
    }
    else {
        _35028 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)20);
    }
    if (IS_ATOM_INT(_35027)){
        poke4_addr = (uint32_t *)_35027;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35027)->dbl);
    }
    if (IS_ATOM_INT(_35028)) {
        *poke4_addr = (uint32_t)_35028;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_35028)->dbl;
    }
    DeRef(_35027);
    _35027 = NOVALUE;
    DeRef(_35028);
    _35028 = NOVALUE;

    /** execute.e:3657			poke( asm + 18, SymTab[r][S_NUM_ARGS] * 4 )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35029 = _asm_70155 + 18;
        if ((object)((uintptr_t)_35029 + (uintptr_t)HIGH_BITS) >= 0){
            _35029 = NewDouble((eudouble)_35029);
        }
    }
    else {
        _35029 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)18);
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _35030 = (object)*(((s1_ptr)_2)->base + _r_70154);
    _2 = (object)SEQ_PTR(_35030);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _35031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _35031 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _35030 = NOVALUE;
    if (IS_ATOM_INT(_35031)) {
        if (_35031 == (short)_35031){
            _35032 = _35031 * 4;
        }
        else{
            _35032 = NewDouble(_35031 * (eudouble)4);
        }
    }
    else {
        _35032 = binary_op(MULTIPLY, _35031, 4);
    }
    _35031 = NOVALUE;
    if (IS_ATOM_INT(_35029)){
        poke_addr = (uint8_t *)_35029;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_35029)->dbl);
    }
    if (IS_ATOM_INT(_35032)) {
        *poke_addr = (uint8_t)_35032;
    }
    else if (IS_ATOM(_35032)) {
        *poke_addr = (uint8_t)DBL_PTR(_35032)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_35032);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_35029);
    _35029 = NOVALUE;
    DeRef(_35032);
    _35032 = NOVALUE;

    /** execute.e:3658			poke4( asm + 20, callback( routine_id("machine_callback") ) )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35033 = _asm_70155 + 20;
        if ((object)((uintptr_t)_35033 + (uintptr_t)HIGH_BITS) >= 0){
            _35033 = NewDouble((eudouble)_35033);
        }
    }
    else {
        _35033 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)20);
    }
    _35035 = CRoutineId(1600, 67, _35034);
    _35036 = _67callback(_35035);
    _35035 = NOVALUE;
    if (IS_ATOM_INT(_35033)){
        poke4_addr = (uint32_t *)_35033;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35033)->dbl);
    }
    if (IS_ATOM_INT(_35036)) {
        *poke4_addr = (uint32_t)_35036;
    }
    else if (IS_ATOM(_35036)) {
        *poke4_addr = (uint32_t)DBL_PTR(_35036)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_35036);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_35033);
    _35033 = NOVALUE;
    DeRef(_35036);
    _35036 = NOVALUE;
    goto L6; // [221] 409
L5: 

    /** execute.e:3659		elsif platform() = OSX then*/

    /** execute.e:3675			asm = dep:allocate_protect(length(cb_cdecl), 1, PAGE_EXECUTE_READWRITE)*/
    _35055 = 27;
    _0 = _asm_70155;
    _asm_70155 = _6allocate_protect(27, 1, 64);
    DeRef(_0);
    _35055 = NOVALUE;

    /** execute.e:3676			poke( asm, cb_cdecl )*/
    if (IS_ATOM_INT(_asm_70155)){
        poke_addr = (uint8_t *)_asm_70155;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_asm_70155)->dbl);
    }
    _1 = (object)SEQ_PTR(_67cb_cdecl_70142);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** execute.e:3677			poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35057 = _asm_70155 + 7;
        if ((object)((uintptr_t)_35057 + (uintptr_t)HIGH_BITS) >= 0){
            _35057 = NewDouble((eudouble)_35057);
        }
    }
    else {
        _35057 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)7);
    }
    if (IS_SEQUENCE(_67call_backs_65182)){
            _35058 = SEQ_PTR(_67call_backs_65182)->length;
    }
    else {
        _35058 = 1;
    }
    _35059 = _35058 + 1;
    _35058 = NOVALUE;
    if (IS_ATOM_INT(_35057)){
        poke4_addr = (uint32_t *)_35057;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35057)->dbl);
    }
    *poke4_addr = (uint32_t)_35059;
    DeRef(_35057);
    _35057 = NOVALUE;
    _35059 = NOVALUE;

    /** execute.e:3678			poke4( asm + 13, asm + 23 )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35060 = _asm_70155 + 13;
        if ((object)((uintptr_t)_35060 + (uintptr_t)HIGH_BITS) >= 0){
            _35060 = NewDouble((eudouble)_35060);
        }
    }
    else {
        _35060 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)13);
    }
    if (IS_ATOM_INT(_asm_70155)) {
        _35061 = _asm_70155 + 23;
        if ((object)((uintptr_t)_35061 + (uintptr_t)HIGH_BITS) >= 0){
            _35061 = NewDouble((eudouble)_35061);
        }
    }
    else {
        _35061 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)23);
    }
    if (IS_ATOM_INT(_35060)){
        poke4_addr = (uint32_t *)_35060;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35060)->dbl);
    }
    if (IS_ATOM_INT(_35061)) {
        *poke4_addr = (uint32_t)_35061;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_35061)->dbl;
    }
    DeRef(_35060);
    _35060 = NOVALUE;
    DeRef(_35061);
    _35061 = NOVALUE;

    /** execute.e:3679			poke4( asm + 23, callback( ( '+' & routine_id("machine_callback") ) ) )*/
    if (IS_ATOM_INT(_asm_70155)) {
        _35062 = _asm_70155 + 23;
        if ((object)((uintptr_t)_35062 + (uintptr_t)HIGH_BITS) >= 0){
            _35062 = NewDouble((eudouble)_35062);
        }
    }
    else {
        _35062 = NewDouble(DBL_PTR(_asm_70155)->dbl + (eudouble)23);
    }
    _35063 = CRoutineId(1600, 67, _35034);
    Concat((object_ptr)&_35064, 43, _35063);
    _35063 = NOVALUE;
    _35065 = _67callback(_35064);
    _35064 = NOVALUE;
    if (IS_ATOM_INT(_35062)){
        poke4_addr = (uint32_t *)_35062;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_35062)->dbl);
    }
    if (IS_ATOM_INT(_35065)) {
        *poke4_addr = (uint32_t)_35065;
    }
    else if (IS_ATOM(_35065)) {
        *poke4_addr = (uint32_t)DBL_PTR(_35065)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_35065);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_35062);
    _35062 = NOVALUE;
    DeRef(_35065);
    _35065 = NOVALUE;
L6: 

    /** execute.e:3682		val[target] = asm*/
    Ref(_asm_70155);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _asm_70155;
    DeRef(_1);

    /** execute.e:3683		call_backs = append( call_backs, { r, id, SymTab[r][S_NUM_ARGS] })*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _35066 = (object)*(((s1_ptr)_2)->base + _r_70154);
    _2 = (object)SEQ_PTR(_35066);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _35067 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _35067 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _35066 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _r_70154;
    ((intptr_t*)_2)[2] = _id_70156;
    Ref(_35067);
    ((intptr_t*)_2)[3] = _35067;
    _35068 = MAKE_SEQ(_1);
    _35067 = NOVALUE;
    RefDS(_35068);
    Append(&_67call_backs_65182, _67call_backs_65182, _35068);
    DeRefDS(_35068);
    _35068 = NOVALUE;

    /** execute.e:3684	end procedure*/
    DeRef(_asm_70155);
    DeRef(_x_70158);
    DeRef(_35017);
    _35017 = NOVALUE;
    DeRef(_35019);
    _35019 = NOVALUE;
    DeRef(_35012);
    _35012 = NOVALUE;
    return;
    ;
}


void _67do_crash_routine(object _b_70240)
{
    object _x_70241 = NOVALUE;
    object _35076 = NOVALUE;
    object _35075 = NOVALUE;
    object _35074 = NOVALUE;
    object _35073 = NOVALUE;
    object _35072 = NOVALUE;
    object _35071 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3690		x = val[b]*/
    DeRef(_x_70241);
    _2 = (object)SEQ_PTR(_67val_65265);
    _x_70241 = (object)*(((s1_ptr)_2)->base + _b_70240);
    Ref(_x_70241);

    /** execute.e:3691		if atom(x) and x >= 0 and x < length(e_routine) then*/
    _35071 = IS_ATOM(_x_70241);
    if (_35071 == 0) {
        _35072 = 0;
        goto L1; // [16] 28
    }
    if (IS_ATOM_INT(_x_70241)) {
        _35073 = (_x_70241 >= 0);
    }
    else {
        _35073 = binary_op(GREATEREQ, _x_70241, 0);
    }
    if (IS_ATOM_INT(_35073))
    _35072 = (_35073 != 0);
    else
    _35072 = DBL_PTR(_35073)->dbl != 0.0;
L1: 
    if (_35072 == 0) {
        goto L2; // [28] 56
    }
    if (IS_SEQUENCE(_67e_routine_65303)){
            _35075 = SEQ_PTR(_67e_routine_65303)->length;
    }
    else {
        _35075 = 1;
    }
    if (IS_ATOM_INT(_x_70241)) {
        _35076 = (_x_70241 < _35075);
    }
    else {
        _35076 = binary_op(LESS, _x_70241, _35075);
    }
    _35075 = NOVALUE;
    if (_35076 == 0) {
        DeRef(_35076);
        _35076 = NOVALUE;
        goto L2; // [42] 56
    }
    else {
        if (!IS_ATOM_INT(_35076) && DBL_PTR(_35076)->dbl == 0.0){
            DeRef(_35076);
            _35076 = NOVALUE;
            goto L2; // [42] 56
        }
        DeRef(_35076);
        _35076 = NOVALUE;
    }
    DeRef(_35076);
    _35076 = NOVALUE;

    /** execute.e:3692			crash_list = append(crash_list, x)*/
    Ref(_x_70241);
    Append(&_67crash_list_65191, _67crash_list_65191, _x_70241);
    goto L3; // [53] 62
L2: 

    /** execute.e:3694			RTFatal("crash routine requires a valid routine id")*/
    RefDS(_35078);
    _67RTFatal(_35078);
L3: 

    /** execute.e:3696	end procedure*/
    DeRef(_x_70241);
    DeRef(_35073);
    _35073 = NOVALUE;
    return;
    ;
}


void _67opREMOVE()
{
    object _35090 = NOVALUE;
    object _35089 = NOVALUE;
    object _35088 = NOVALUE;
    object _35087 = NOVALUE;
    object _35085 = NOVALUE;
    object _35083 = NOVALUE;
    object _35081 = NOVALUE;
    object _35079 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3699	 	a = Code[pc+1]*/
    _35079 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35079);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3700	 	b = Code[pc+2]*/
    _35081 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35081);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3701	 	c = Code[pc+3]*/
    _35083 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _35083);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3702	 	target = Code[pc+4]*/
    _35085 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35085);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3703	 	val[target] = remove(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35087 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35088 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35089 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    {
        s1_ptr assign_space = SEQ_PTR(_35087);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_35088)) ? _35088 : (object)(DBL_PTR(_35088)->dbl);
        int stop = (IS_ATOM_INT(_35089)) ? _35089 : (object)(DBL_PTR(_35089)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_35087);
            DeRef(_35090);
            _35090 = _35087;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_35087), start, &_35090 );
            }
            else Tail(SEQ_PTR(_35087), stop+1, &_35090);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_35087), start, &_35090);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_35090);
            _35090 = _1;
        }
    }
    _35087 = NOVALUE;
    _35088 = NOVALUE;
    _35089 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35090;
    if( _1 != _35090 ){
        DeRef(_1);
    }
    _35090 = NOVALUE;

    /** execute.e:3704	 	pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3705	end procedure*/
    _35079 = NOVALUE;
    _35083 = NOVALUE;
    _35081 = NOVALUE;
    _35085 = NOVALUE;
    return;
    ;
}


void _67opREPLACE()
{
    object _35106 = NOVALUE;
    object _35105 = NOVALUE;
    object _35104 = NOVALUE;
    object _35103 = NOVALUE;
    object _35102 = NOVALUE;
    object _35100 = NOVALUE;
    object _35098 = NOVALUE;
    object _35096 = NOVALUE;
    object _35094 = NOVALUE;
    object _35092 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3708	 	a = Code[pc+1]*/
    _35092 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35092);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3709	 	b = Code[pc+2]*/
    _35094 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35094);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3710	 	c = Code[pc+3]*/
    _35096 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _35096);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3711	 	d = Code[pc+4]*/
    _35098 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67d_65259 = (object)*(((s1_ptr)_2)->base + _35098);
    if (!IS_ATOM_INT(_67d_65259)){
        _67d_65259 = (object)DBL_PTR(_67d_65259)->dbl;
    }

    /** execute.e:3712	 	target = Code[pc+5]*/
    _35100 = _67pc_65255 + 5;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35100);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3713	 	val[target] = replace(val[a],val[b],val[c],val[d])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35102 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35103 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35104 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35105 = (object)*(((s1_ptr)_2)->base + _67d_65259);
    {
        intptr_t p1 = _35102;
        intptr_t p2 = _35103;
        intptr_t p3 = _35104;
        intptr_t p4 = _35105;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_35106;
        Replace( &replace_params );
    }
    _35102 = NOVALUE;
    _35103 = NOVALUE;
    _35104 = NOVALUE;
    _35105 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35106;
    if( _1 != _35106 ){
        DeRef(_1);
    }
    _35106 = NOVALUE;

    /** execute.e:3714	 	pc += 6*/
    _67pc_65255 = _67pc_65255 + 6;

    /** execute.e:3715	end procedure*/
    _35096 = NOVALUE;
    _35100 = NOVALUE;
    _35094 = NOVALUE;
    _35092 = NOVALUE;
    _35098 = NOVALUE;
    return;
    ;
}


void _67opHEAD()
{
    object _35116 = NOVALUE;
    object _35115 = NOVALUE;
    object _35114 = NOVALUE;
    object _35112 = NOVALUE;
    object _35110 = NOVALUE;
    object _35108 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3718		a = Code[pc+1]*/
    _35108 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35108);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3719		b = Code[pc+2]*/
    _35110 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35110);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3720		target = Code[pc+3]*/
    _35112 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35112);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3721		val[target] = head(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35114 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35115 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    {
        int len = SEQ_PTR(_35114)->length;
        int size = (IS_ATOM_INT(_35115)) ? _35115 : (object)(DBL_PTR(_35115)->dbl);
        if (size <= 0){
            DeRef( _35116 );
            _35116 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_35114);
            DeRef(_35116);
            _35116 = _35114;
        }
        else{
            Head(SEQ_PTR(_35114),size+1,&_35116);
        }
    }
    _35114 = NOVALUE;
    _35115 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35116;
    if( _1 != _35116 ){
        DeRef(_1);
    }
    _35116 = NOVALUE;

    /** execute.e:3722		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3723	end procedure*/
    _35108 = NOVALUE;
    _35110 = NOVALUE;
    _35112 = NOVALUE;
    return;
    ;
}


void _67opTAIL()
{
    object _35126 = NOVALUE;
    object _35125 = NOVALUE;
    object _35124 = NOVALUE;
    object _35122 = NOVALUE;
    object _35120 = NOVALUE;
    object _35118 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3726		a = Code[pc+1]*/
    _35118 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35118);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3727		b = Code[pc+2]*/
    _35120 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35120);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3728		target = Code[pc+3]*/
    _35122 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35122);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3729		val[target] = tail(val[a],val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35124 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35125 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    {
        int len = SEQ_PTR(_35124)->length;
        int size = (IS_ATOM_INT(_35125)) ? _35125 : (object)(DBL_PTR(_35125)->dbl);
        if (size <= 0) {
            DeRef(_35126);
            _35126 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_35124);
            DeRef(_35126);
            _35126 = _35124;
        }
        else Tail(SEQ_PTR(_35124), len-size+1, &_35126);
    }
    _35124 = NOVALUE;
    _35125 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35126;
    if( _1 != _35126 ){
        DeRef(_1);
    }
    _35126 = NOVALUE;

    /** execute.e:3730		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3731	end procedure*/
    _35120 = NOVALUE;
    _35118 = NOVALUE;
    _35122 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_FUNC()
{
    object _35139 = NOVALUE;
    object _35138 = NOVALUE;
    object _35137 = NOVALUE;
    object _35135 = NOVALUE;
    object _35132 = NOVALUE;
    object _35130 = NOVALUE;
    object _35128 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3734		a = Code[pc+1]*/
    _35128 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35128);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3735		b = Code[pc+2]*/
    _35130 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35130);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3736		target = Code[pc+3]*/
    _35132 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35132);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3738		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3740		if val[a] = M_CALL_BACK then*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35135 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    if (binary_op_a(NOTEQ, _35135, 52)){
        _35135 = NOVALUE;
        goto L1; // [67] 81
    }
    _35135 = NOVALUE;

    /** execute.e:3742			do_callback(b)*/
    _67do_callback(_67b_65257);
    goto L2; // [78] 112
L1: 

    /** execute.e:3744			val[target] = machine_func(val[a], val[b])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35137 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35138 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _35139 = machine(_35137, _35138);
    _35137 = NOVALUE;
    _35138 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35139;
    if( _1 != _35139 ){
        DeRef(_1);
    }
    _35139 = NOVALUE;
L2: 

    /** execute.e:3746	end procedure*/
    DeRef(_35130);
    _35130 = NOVALUE;
    DeRef(_35128);
    _35128 = NOVALUE;
    DeRef(_35132);
    _35132 = NOVALUE;
    return;
    ;
}


void _67opSPLICE()
{
    object _35151 = NOVALUE;
    object _35150 = NOVALUE;
    object _35149 = NOVALUE;
    object _35148 = NOVALUE;
    object _35146 = NOVALUE;
    object _35144 = NOVALUE;
    object _35142 = NOVALUE;
    object _35140 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3749		a = Code[pc+1]*/
    _35140 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35140);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3750		b = Code[pc+2]*/
    _35142 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35142);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3751		c = Code[pc+3]*/
    _35144 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _35144);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3752		target = Code[pc+4]*/
    _35146 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35146);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3753		val[target] = splice(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35148 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35149 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35150 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_35150) ? _35150 : DBL_PTR(_35150)->dbl;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_35149)) {
                Concat(&_35151,_35149,_35148);
            }
            else{
                Prepend(&_35151,_35148,_35149);
            }
        }
        else if (insert_pos > SEQ_PTR(_35148)->length){
            if (IS_SEQUENCE(_35149)) {
                Concat(&_35151,_35148,_35149);
            }
            else{
                Append(&_35151,_35148,_35149);
            }
        }
        else if (IS_SEQUENCE(_35149)) {
            if( _35151 != _35148 || SEQ_PTR( _35148 )->ref != 1 ){
                DeRef( _35151 );
                RefDS( _35148 );
            }
            assign_space = Add_internal_space( _35148, insert_pos,((s1_ptr)SEQ_PTR(_35149))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_35149), _35148 == _35151 );
            _35151 = MAKE_SEQ( assign_space );
        }
        else {
            if( _35151 == _35148 && SEQ_PTR( _35148 )->ref == 1 ){
                _35151 = Insert( _35148, _35149, insert_pos);
            }
            else {
                DeRef( _35151 );
                RefDS( _35148 );
                _35151 = Insert( _35148, _35149, insert_pos);
            }
        }
    }
    _35148 = NOVALUE;
    _35149 = NOVALUE;
    _35150 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35151;
    if( _1 != _35151 ){
        DeRef(_1);
    }
    _35151 = NOVALUE;

    /** execute.e:3754		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3755	end procedure*/
    _35146 = NOVALUE;
    _35140 = NOVALUE;
    _35142 = NOVALUE;
    _35144 = NOVALUE;
    return;
    ;
}


void _67opINSERT()
{
    object _35164 = NOVALUE;
    object _35163 = NOVALUE;
    object _35162 = NOVALUE;
    object _35161 = NOVALUE;
    object _35159 = NOVALUE;
    object _35157 = NOVALUE;
    object _35155 = NOVALUE;
    object _35153 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3758		a = Code[pc+1]*/
    _35153 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35153);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3759		b = Code[pc+2]*/
    _35155 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35155);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3760		c = Code[pc+3]*/
    _35157 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67c_65258 = (object)*(((s1_ptr)_2)->base + _35157);
    if (!IS_ATOM_INT(_67c_65258)){
        _67c_65258 = (object)DBL_PTR(_67c_65258)->dbl;
    }

    /** execute.e:3761		target = Code[pc+4]*/
    _35159 = _67pc_65255 + 4;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67target_65260 = (object)*(((s1_ptr)_2)->base + _35159);
    if (!IS_ATOM_INT(_67target_65260)){
        _67target_65260 = (object)DBL_PTR(_67target_65260)->dbl;
    }

    /** execute.e:3762		val[target] = insert(val[a],val[b],val[c])*/
    _2 = (object)SEQ_PTR(_67val_65265);
    _35161 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35162 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35163 = (object)*(((s1_ptr)_2)->base + _67c_65258);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_35163) ? _35163 : DBL_PTR(_35163)->dbl;
        if (insert_pos <= 0){
            Prepend(&_35164,_35161,_35162);
        }
        else if (insert_pos > SEQ_PTR(_35161)->length) {
            Ref( _35162 );
            Append(&_35164,_35161,_35162);
        }
        else {
            Ref( _35162 );
            RefDS( _35161 );
            _35164 = Insert(_35161,_35162,insert_pos);
        }
    }
    _35161 = NOVALUE;
    _35162 = NOVALUE;
    _35163 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67target_65260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35164;
    if( _1 != _35164 ){
        DeRef(_1);
    }
    _35164 = NOVALUE;

    /** execute.e:3763		pc += 5*/
    _67pc_65255 = _67pc_65255 + 5;

    /** execute.e:3764	end procedure*/
    _35153 = NOVALUE;
    _35159 = NOVALUE;
    _35157 = NOVALUE;
    _35155 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_PROC()
{
    object _v_70385 = NOVALUE;
    object _35183 = NOVALUE;
    object _35182 = NOVALUE;
    object _35180 = NOVALUE;
    object _35178 = NOVALUE;
    object _35177 = NOVALUE;
    object _35175 = NOVALUE;
    object _35174 = NOVALUE;
    object _35168 = NOVALUE;
    object _35166 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3770		a = Code[pc+1]*/
    _35166 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35166);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3771		b = Code[pc+2]*/
    _35168 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67b_65257 = (object)*(((s1_ptr)_2)->base + _35168);
    if (!IS_ATOM_INT(_67b_65257)){
        _67b_65257 = (object)DBL_PTR(_67b_65257)->dbl;
    }

    /** execute.e:3772		v = val[a]*/
    DeRef(_v_70385);
    _2 = (object)SEQ_PTR(_67val_65265);
    _v_70385 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    Ref(_v_70385);

    /** execute.e:3774		switch v do*/
    if (IS_SEQUENCE(_v_70385) ){
        goto L1; // [45] 201
    }
    if(!IS_ATOM_INT(_v_70385)){
        if( (DBL_PTR(_v_70385)->dbl != (eudouble) ((object) DBL_PTR(_v_70385)->dbl) ) ){
            goto L1; // [45] 201
        }
        _0 = (object) DBL_PTR(_v_70385)->dbl;
    }
    else {
        _0 = _v_70385;
    };
    switch ( _0 ){ 

        /** execute.e:3775			case M_CRASH_ROUTINE then*/
        case 66:

        /** execute.e:3777				do_crash_routine(b)*/
        _67do_crash_routine(_67b_65257);
        goto L2; // [61] 217

        /** execute.e:3779			case M_CRASH_MESSAGE then*/
        case 37:

        /** execute.e:3780				crash_msg = val[b]*/
        DeRef(_67crash_msg_65181);
        _2 = (object)SEQ_PTR(_67val_65265);
        _67crash_msg_65181 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        Ref(_67crash_msg_65181);
        goto L2; // [77] 217

        /** execute.e:3782			case M_CRASH_FILE then*/
        case 57:

        /** execute.e:3783				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _35174 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        _35175 = IS_SEQUENCE(_35174);
        _35174 = NOVALUE;
        if (_35175 == 0)
        {
            _35175 = NOVALUE;
            goto L2; // [96] 217
        }
        else{
            _35175 = NOVALUE;
        }

        /** execute.e:3784					err_file_name = val[b]*/
        DeRef(_67err_file_name_65305);
        _2 = (object)SEQ_PTR(_67val_65265);
        _67err_file_name_65305 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        Ref(_67err_file_name_65305);
        goto L2; // [112] 217

        /** execute.e:3787			case M_WARNING_FILE then*/
        case 72:

        /** execute.e:3788				display_warnings = 1*/
        _49display_warnings_49641 = 1;

        /** execute.e:3789				if sequence(val[b]) then*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _35177 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        _35178 = IS_SEQUENCE(_35177);
        _35177 = NOVALUE;
        if (_35178 == 0)
        {
            _35178 = NOVALUE;
            goto L3; // [138] 154
        }
        else{
            _35178 = NOVALUE;
        }

        /** execute.e:3790					TempWarningName = val[b]*/
        DeRef(_27TempWarningName_20585);
        _2 = (object)SEQ_PTR(_67val_65265);
        _27TempWarningName_20585 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        Ref(_27TempWarningName_20585);
        goto L2; // [151] 217
L3: 

        /** execute.e:3792					TempWarningName = STDERR*/
        DeRef(_27TempWarningName_20585);
        _27TempWarningName_20585 = 2;

        /** execute.e:3793					display_warnings = (val[b] >= 0)*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _35180 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        if (IS_ATOM_INT(_35180)) {
            _49display_warnings_49641 = (_35180 >= 0);
        }
        else {
            _49display_warnings_49641 = binary_op(GREATEREQ, _35180, 0);
        }
        _35180 = NOVALUE;
        if (!IS_ATOM_INT(_49display_warnings_49641)) {
            _1 = (object)(DBL_PTR(_49display_warnings_49641)->dbl);
            DeRefDS(_49display_warnings_49641);
            _49display_warnings_49641 = _1;
        }
        goto L2; // [178] 217

        /** execute.e:3796			case M_CRASH then*/
        case 67:

        /** execute.e:3798				RTFatal( val[b] )*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _35182 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        Ref(_35182);
        _67RTFatal(_35182);
        _35182 = NOVALUE;
        goto L2; // [197] 217

        /** execute.e:3801			case else*/
        default:
L1: 

        /** execute.e:3802				machine_proc(v, val[b])*/
        _2 = (object)SEQ_PTR(_67val_65265);
        _35183 = (object)*(((s1_ptr)_2)->base + _67b_65257);
        machine(_v_70385, _35183);
        _35183 = NOVALUE;
    ;}L2: 

    /** execute.e:3804		pc += 3*/
    _67pc_65255 = _67pc_65255 + 3;

    /** execute.e:3805	end procedure*/
    DeRef(_v_70385);
    DeRef(_35168);
    _35168 = NOVALUE;
    DeRef(_35166);
    _35166 = NOVALUE;
    return;
    ;
}


void _67opDEREF_TEMP()
{
    object _35186 = NOVALUE;
    object _35185 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3808		val[Code[pc+1]] = NOVALUE*/
    _35185 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35186 = (object)*(((s1_ptr)_2)->base + _35185);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35186))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_35186)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _35186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** execute.e:3809		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3810	end procedure*/
    _35186 = NOVALUE;
    _35185 = NOVALUE;
    return;
    ;
}


void _67do_delete_routine(object _dx_70438, object _o_70439)
{
    object _arglist_assign_70442 = NOVALUE;
    object _35208 = NOVALUE;
    object _35207 = NOVALUE;
    object _35206 = NOVALUE;
    object _35205 = NOVALUE;
    object _35204 = NOVALUE;
    object _35202 = NOVALUE;
    object _35201 = NOVALUE;
    object _35199 = NOVALUE;
    object _35198 = NOVALUE;
    object _35193 = NOVALUE;
    object _35191 = NOVALUE;
    object _35190 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:3823		val[t_id] = user_delete_rid[dx]*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_70431);
    _35190 = (object)*(((s1_ptr)_2)->base + _dx_70438);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_id_65186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35190;
    if( _1 != _35190 ){
        DeRef(_1);
    }
    _35190 = NOVALUE;

    /** execute.e:3824		val[t_arglist] = {o}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_o_70439);
    ((intptr_t*)_2)[1] = _o_70439;
    _35191 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35191;
    if( _1 != _35191 ){
        DeRef(_1);
    }
    _35191 = NOVALUE;

    /** execute.e:3825		atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_70442;
    _arglist_assign_70442 = _67new_arg_assign();
    DeRef(_0);

    /** execute.e:3827		SymTab[delete_code_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67delete_code_routine_65190 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _67current_task_65272;
    DeRef(_1);
    _35193 = NOVALUE;

    /** execute.e:3830		call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _67pc_65255);

    /** execute.e:3831		call_stack = append(call_stack, delete_code_routine)*/
    Append(&_67call_stack_65273, _67call_stack_65273, _67delete_code_routine_65190);

    /** execute.e:3833		Code = delete_code*/
    RefDS(_67delete_code_65184);
    DeRef(_27Code_20660);
    _27Code_20660 = _67delete_code_65184;

    /** execute.e:3834		pc = 1*/
    _67pc_65255 = 1;

    /** execute.e:3836		do_exec()*/
    _67do_exec();

    /** execute.e:3838		if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_70442, _67arg_assign_65199)){
        goto L1; // [99] 116
    }

    /** execute.e:3840			val[t_arglist] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67t_arglist_65187);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1: 

    /** execute.e:3842		o = 0*/
    DeRef(_o_70439);
    _o_70439 = 0;

    /** execute.e:3845		pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _35198 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _35198 = 1;
    }
    _35199 = _35198 - 1;
    _35198 = NOVALUE;
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _67pc_65255 = (object)*(((s1_ptr)_2)->base + _35199);
    if (!IS_ATOM_INT(_67pc_65255))
    _67pc_65255 = (object)DBL_PTR(_67pc_65255)->dbl;

    /** execute.e:3846		call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _35201 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _35201 = 1;
    }
    _35202 = _35201 - 2;
    _35201 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_65273;
    RHS_Slice(_67call_stack_65273, 1, _35202);

    /** execute.e:3848		restore_privates( call_stack[$] )*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _35204 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _35204 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _35205 = (object)*(((s1_ptr)_2)->base + _35204);
    Ref(_35205);
    _67restore_privates(_35205);
    _35205 = NOVALUE;

    /** execute.e:3851		Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _35206 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _35206 = 1;
    }
    _2 = (object)SEQ_PTR(_67call_stack_65273);
    _35207 = (object)*(((s1_ptr)_2)->base + _35206);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_35207)){
        _35208 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35207)->dbl));
    }
    else{
        _35208 = (object)*(((s1_ptr)_2)->base + _35207);
    }
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_35208);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _35208 = NOVALUE;

    /** execute.e:3852	end procedure*/
    DeRef(_arglist_assign_70442);
    _35202 = NOVALUE;
    _35199 = NOVALUE;
    _35207 = NOVALUE;
    return;
    ;
}


void _67user_delete_01(object _o_70472)
{
    object _0, _1, _2;
    

    /** execute.e:3855		do_delete_routine( 1, o )*/
    Ref(_o_70472);
    _67do_delete_routine(1, _o_70472);

    /** execute.e:3856	end procedure*/
    DeRef(_o_70472);
    return;
    ;
}


void _67user_delete_02(object _o_70477)
{
    object _0, _1, _2;
    

    /** execute.e:3860		do_delete_routine( 2, o )*/
    Ref(_o_70477);
    _67do_delete_routine(2, _o_70477);

    /** execute.e:3861	end procedure*/
    DeRef(_o_70477);
    return;
    ;
}


void _67user_delete_03(object _o_70482)
{
    object _0, _1, _2;
    

    /** execute.e:3865		do_delete_routine( 3, o )*/
    Ref(_o_70482);
    _67do_delete_routine(3, _o_70482);

    /** execute.e:3866	end procedure*/
    DeRef(_o_70482);
    return;
    ;
}


void _67user_delete_04(object _o_70487)
{
    object _0, _1, _2;
    

    /** execute.e:3870		do_delete_routine( 4, o )*/
    Ref(_o_70487);
    _67do_delete_routine(4, _o_70487);

    /** execute.e:3871	end procedure*/
    DeRef(_o_70487);
    return;
    ;
}


void _67user_delete_05(object _o_70492)
{
    object _0, _1, _2;
    

    /** execute.e:3875		do_delete_routine( 5, o )*/
    Ref(_o_70492);
    _67do_delete_routine(5, _o_70492);

    /** execute.e:3876	end procedure*/
    DeRef(_o_70492);
    return;
    ;
}


void _67user_delete_06(object _o_70497)
{
    object _0, _1, _2;
    

    /** execute.e:3880		do_delete_routine( 6, o )*/
    Ref(_o_70497);
    _67do_delete_routine(6, _o_70497);

    /** execute.e:3881	end procedure*/
    DeRef(_o_70497);
    return;
    ;
}


void _67user_delete_07(object _o_70502)
{
    object _0, _1, _2;
    

    /** execute.e:3885		do_delete_routine( 7, o )*/
    Ref(_o_70502);
    _67do_delete_routine(7, _o_70502);

    /** execute.e:3886	end procedure*/
    DeRef(_o_70502);
    return;
    ;
}


void _67user_delete_08(object _o_70507)
{
    object _0, _1, _2;
    

    /** execute.e:3890		do_delete_routine( 8, o )*/
    Ref(_o_70507);
    _67do_delete_routine(8, _o_70507);

    /** execute.e:3891	end procedure*/
    DeRef(_o_70507);
    return;
    ;
}


void _67user_delete_09(object _o_70512)
{
    object _0, _1, _2;
    

    /** execute.e:3895		do_delete_routine( 9, o )*/
    Ref(_o_70512);
    _67do_delete_routine(9, _o_70512);

    /** execute.e:3896	end procedure*/
    DeRef(_o_70512);
    return;
    ;
}


void _67user_delete_10(object _o_70517)
{
    object _0, _1, _2;
    

    /** execute.e:3900		do_delete_routine( 10, o )*/
    Ref(_o_70517);
    _67do_delete_routine(10, _o_70517);

    /** execute.e:3901	end procedure*/
    DeRef(_o_70517);
    return;
    ;
}


void _67user_delete_11(object _o_70522)
{
    object _0, _1, _2;
    

    /** execute.e:3905		do_delete_routine( 11, o )*/
    Ref(_o_70522);
    _67do_delete_routine(11, _o_70522);

    /** execute.e:3906	end procedure*/
    DeRef(_o_70522);
    return;
    ;
}


void _67user_delete_12(object _o_70527)
{
    object _0, _1, _2;
    

    /** execute.e:3910		do_delete_routine( 12, o )*/
    Ref(_o_70527);
    _67do_delete_routine(12, _o_70527);

    /** execute.e:3911	end procedure*/
    DeRef(_o_70527);
    return;
    ;
}


void _67user_delete_13(object _o_70532)
{
    object _0, _1, _2;
    

    /** execute.e:3915		do_delete_routine( 13, o )*/
    Ref(_o_70532);
    _67do_delete_routine(13, _o_70532);

    /** execute.e:3916	end procedure*/
    DeRef(_o_70532);
    return;
    ;
}


void _67user_delete_14(object _o_70537)
{
    object _0, _1, _2;
    

    /** execute.e:3920		do_delete_routine( 14, o )*/
    Ref(_o_70537);
    _67do_delete_routine(14, _o_70537);

    /** execute.e:3921	end procedure*/
    DeRef(_o_70537);
    return;
    ;
}


void _67user_delete_15(object _o_70542)
{
    object _0, _1, _2;
    

    /** execute.e:3925		do_delete_routine( 15, o )*/
    Ref(_o_70542);
    _67do_delete_routine(15, _o_70542);

    /** execute.e:3926	end procedure*/
    DeRef(_o_70542);
    return;
    ;
}


void _67user_delete_16(object _o_70547)
{
    object _0, _1, _2;
    

    /** execute.e:3930		do_delete_routine( 16, o )*/
    Ref(_o_70547);
    _67do_delete_routine(16, _o_70547);

    /** execute.e:3931	end procedure*/
    DeRef(_o_70547);
    return;
    ;
}


void _67user_delete_17(object _o_70552)
{
    object _0, _1, _2;
    

    /** execute.e:3935		do_delete_routine( 17, o )*/
    Ref(_o_70552);
    _67do_delete_routine(17, _o_70552);

    /** execute.e:3936	end procedure*/
    DeRef(_o_70552);
    return;
    ;
}


void _67user_delete_18(object _o_70557)
{
    object _0, _1, _2;
    

    /** execute.e:3940		do_delete_routine( 18, o )*/
    Ref(_o_70557);
    _67do_delete_routine(18, _o_70557);

    /** execute.e:3941	end procedure*/
    DeRef(_o_70557);
    return;
    ;
}


void _67user_delete_19(object _o_70562)
{
    object _0, _1, _2;
    

    /** execute.e:3945		do_delete_routine( 19, o )*/
    Ref(_o_70562);
    _67do_delete_routine(19, _o_70562);

    /** execute.e:3946	end procedure*/
    DeRef(_o_70562);
    return;
    ;
}


void _67user_delete_20(object _o_70567)
{
    object _0, _1, _2;
    

    /** execute.e:3950		do_delete_routine( 20, o )*/
    Ref(_o_70567);
    _67do_delete_routine(20, _o_70567);

    /** execute.e:3951	end procedure*/
    DeRef(_o_70567);
    return;
    ;
}


void _67opDELETE_ROUTINE()
{
    object _rid_70575 = NOVALUE;
    object _35265 = NOVALUE;
    object _35264 = NOVALUE;
    object _35263 = NOVALUE;
    object _35262 = NOVALUE;
    object _35261 = NOVALUE;
    object _35260 = NOVALUE;
    object _35253 = NOVALUE;
    object _35252 = NOVALUE;
    object _35250 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3956		a = Code[pc+1]*/
    _35250 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _67a_65256 = (object)*(((s1_ptr)_2)->base + _35250);
    if (!IS_ATOM_INT(_67a_65256)){
        _67a_65256 = (object)DBL_PTR(_67a_65256)->dbl;
    }

    /** execute.e:3958		integer rid = val[Code[pc+2]]*/
    _35252 = _67pc_65255 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35253 = (object)*(((s1_ptr)_2)->base + _35252);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_35253)){
        _rid_70575 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35253)->dbl));
    }
    else{
        _rid_70575 = (object)*(((s1_ptr)_2)->base + _35253);
    }
    if (!IS_ATOM_INT(_rid_70575))
    _rid_70575 = (object)DBL_PTR(_rid_70575)->dbl;

    /** execute.e:3959		b = find( rid, user_delete_rid )*/
    _67b_65257 = find_from(_rid_70575, _67user_delete_rid_70431, 1);

    /** execute.e:3960		if not b then*/
    if (_67b_65257 != 0)
    goto L1; // [50] 86

    /** execute.e:3961			b = find( -1, user_delete_rid )*/
    _67b_65257 = find_from(-1, _67user_delete_rid_70431, 1);

    /** execute.e:3962			if not b then*/
    if (_67b_65257 != 0)
    goto L2; // [66] 75

    /** execute.e:3963				RTFatal("Maximum of 20 user defined delete routines exceeded.")*/
    RefDS(_35259);
    _67RTFatal(_35259);
L2: 

    /** execute.e:3965			user_delete_rid[b] = rid*/
    _2 = (object)SEQ_PTR(_67user_delete_rid_70431);
    _2 = (object)(((s1_ptr)_2)->base + _67b_65257);
    *(intptr_t *)_2 = _rid_70575;
L1: 

    /** execute.e:3967		val[Code[pc+3]] = delete_routine( val[a], eu_delete_rid[b] )*/
    _35260 = _67pc_65255 + 3;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35261 = (object)*(((s1_ptr)_2)->base + _35260);
    _2 = (object)SEQ_PTR(_67val_65265);
    _35262 = (object)*(((s1_ptr)_2)->base + _67a_65256);
    _2 = (object)SEQ_PTR(_67eu_delete_rid_70429);
    _35263 = (object)*(((s1_ptr)_2)->base + _67b_65257);
    DeRef(_35264);
    if( IS_ATOM_INT(_35262) ){
        _35264 = NewDouble( (eudouble) _35262 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_35262)) ){
            if( IS_ATOM_DBL( _35262 ) ){
                _35264 = NewDouble( DBL_PTR(_35262)->dbl );
            }
            else {
                RefDS(_35262);
                _35264 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_35262) ));
            }
        }
        else {
            _35264 = _35262;
        }
    }
    _1 = (object) _00[_35263].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_35263].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _35263;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_35264) ){
        if( IS_ATOM_INT(_35264) ){
            _35264 = NewDouble( (eudouble) _35262 );
        }
        if(DBL_PTR(_35264)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_35264)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_35264)) ){
            DeRefDS(_35264);
            _35264 = NewDouble( DBL_PTR(_35264)->dbl );
        }
        DBL_PTR(_35264)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_35264)->cleanup != 0 ){
            _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_35264)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_35264)) ){
            _35264 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_35264) ));
        }
        SEQ_PTR(_35264)->cleanup = (cleanup_ptr)_1;
    }
    _35262 = NOVALUE;
    _35263 = NOVALUE;
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35261))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_35261)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _35261);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _35264;
    if( _1 != _35264 ){
        DeRef(_1);
    }
    _35264 = NOVALUE;

    /** execute.e:3968		if sym_mode( a ) = M_TEMP then*/
    _35265 = _53sym_mode(_67a_65256);
    if (binary_op_a(NOTEQ, _35265, 3)){
        DeRef(_35265);
        _35265 = NOVALUE;
        goto L3; // [136] 153
    }
    DeRef(_35265);
    _35265 = NOVALUE;

    /** execute.e:3969			val[a] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67val_65265 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _67a_65256);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L3: 

    /** execute.e:3972		pc += 4*/
    _67pc_65255 = _67pc_65255 + 4;

    /** execute.e:3973	end procedure*/
    _35253 = NOVALUE;
    DeRef(_35260);
    _35260 = NOVALUE;
    _35261 = NOVALUE;
    DeRef(_35252);
    _35252 = NOVALUE;
    DeRef(_35250);
    _35250 = NOVALUE;
    return;
    ;
}


void _67opDELETE_OBJECT()
{
    object _35270 = NOVALUE;
    object _35269 = NOVALUE;
    object _35268 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3976		delete( val[Code[pc+1]] )*/
    _35268 = _67pc_65255 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _35269 = (object)*(((s1_ptr)_2)->base + _35268);
    _2 = (object)SEQ_PTR(_67val_65265);
    if (!IS_ATOM_INT(_35269)){
        _35270 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_35269)->dbl));
    }
    else{
        _35270 = (object)*(((s1_ptr)_2)->base + _35269);
    }
    if( IS_SEQUENCE(_35270) ){
        cleanup_sequence(SEQ_PTR(_35270));
    }
    if( IS_ATOM_DBL(_35270)){
        cleanup_double(DBL_PTR(_35270));
    }
    _35270 = NOVALUE;

    /** execute.e:3977		pc += 2*/
    _67pc_65255 = _67pc_65255 + 2;

    /** execute.e:3978	end procedure*/
    _35268 = NOVALUE;
    _35269 = NOVALUE;
    return;
    ;
}


void _67do_exec()
{
    object _op_70611 = NOVALUE;
    object _35279 = NOVALUE;
    object _0, _1, _2;
    

    /** execute.e:3982		keep_running = TRUE*/
    _67keep_running_65262 = _9TRUE_441;

    /** execute.e:3983		while keep_running do*/
L1: 
    if (_67keep_running_65262 == 0)
    {
        goto L2; // [17] 1910
    }
    else{
    }

    /** execute.e:3984			integer op = Code[pc]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _op_70611 = (object)*(((s1_ptr)_2)->base + _67pc_65255);
    if (!IS_ATOM_INT(_op_70611)){
        _op_70611 = (object)DBL_PTR(_op_70611)->dbl;
    }

    /** execute.e:3985			ifdef DEBUG then*/

    /** execute.e:3992			switch op do*/
    _0 = _op_70611;
    switch ( _0 ){ 

        /** execute.e:3993				case ABORT then*/
        case 126:

        /** execute.e:3994					opABORT()*/
        _67opABORT();
        goto L3; // [49] 1903

        /** execute.e:3996				case AND then*/
        case 8:

        /** execute.e:3997					opAND()*/
        _67opAND();
        goto L3; // [59] 1903

        /** execute.e:3999				case AND_BITS then*/
        case 56:

        /** execute.e:4000					opAND_BITS()*/
        _67opAND_BITS();
        goto L3; // [69] 1903

        /** execute.e:4002				case APPEND then*/
        case 35:

        /** execute.e:4003					opAPPEND()*/
        _67opAPPEND();
        goto L3; // [79] 1903

        /** execute.e:4005				case ARCTAN then*/
        case 73:

        /** execute.e:4006					opARCTAN()*/
        _67opARCTAN();
        goto L3; // [89] 1903

        /** execute.e:4008				case ASSIGN, ASSIGN_I then*/
        case 18:
        case 113:

        /** execute.e:4009					opASSIGN()*/
        _67opASSIGN();
        goto L3; // [101] 1903

        /** execute.e:4011				case ASSIGN_OP_SLICE then*/
        case 150:

        /** execute.e:4012					opASSIGN_OP_SLICE()*/
        _67opASSIGN_OP_SLICE();
        goto L3; // [111] 1903

        /** execute.e:4014				case ASSIGN_OP_SUBS then*/
        case 149:

        /** execute.e:4015					opASSIGN_OP_SUBS()*/
        _67opASSIGN_OP_SUBS();
        goto L3; // [121] 1903

        /** execute.e:4017				case ASSIGN_SLICE then*/
        case 45:

        /** execute.e:4018					opASSIGN_SLICE()*/
        _67opASSIGN_SLICE();
        goto L3; // [131] 1903

        /** execute.e:4020				case ASSIGN_SUBS, ASSIGN_SUBS_CHECK, ASSIGN_SUBS_I then*/
        case 16:
        case 84:
        case 118:

        /** execute.e:4021					opASSIGN_SUBS()*/
        _67opASSIGN_SUBS();
        goto L3; // [145] 1903

        /** execute.e:4023				case ATOM_CHECK then*/
        case 101:

        /** execute.e:4024					opATOM_CHECK()*/
        _67opATOM_CHECK();
        goto L3; // [155] 1903

        /** execute.e:4026				case BADRETURNF then*/
        case 43:

        /** execute.e:4027					opBADRETURNF()*/
        _67opBADRETURNF();
        goto L3; // [165] 1903

        /** execute.e:4029				case C_FUNC then*/
        case 133:

        /** execute.e:4030					opC_FUNC()*/
        _67opC_FUNC();
        goto L3; // [175] 1903

        /** execute.e:4032				case C_PROC then*/
        case 132:

        /** execute.e:4033					opC_PROC()*/
        _67opC_PROC();
        goto L3; // [185] 1903

        /** execute.e:4035				case CALL then*/
        case 129:

        /** execute.e:4036					opCALL()*/
        _67opCALL();
        goto L3; // [195] 1903

        /** execute.e:4038				case CALL_BACK_RETURN then*/
        case 135:

        /** execute.e:4039					opCALL_BACK_RETURN()*/
        _67opCALL_BACK_RETURN();
        goto L3; // [205] 1903

        /** execute.e:4041				case CALL_PROC, CALL_FUNC then*/
        case 136:
        case 137:

        /** execute.e:4042					opCALL_PROC()*/
        _67opCALL_PROC();
        goto L3; // [217] 1903

        /** execute.e:4044				case CASE then*/
        case 186:

        /** execute.e:4045					opCASE()*/
        _67opCASE();
        goto L3; // [227] 1903

        /** execute.e:4047				case CLEAR_SCREEN then*/
        case 59:

        /** execute.e:4048					opCLEAR_SCREEN()*/
        _67opCLEAR_SCREEN();
        goto L3; // [237] 1903

        /** execute.e:4050				case CLOSE then*/
        case 86:

        /** execute.e:4051					opCLOSE()*/
        _67opCLOSE();
        goto L3; // [247] 1903

        /** execute.e:4053				case COMMAND_LINE then*/
        case 100:

        /** execute.e:4054					opCOMMAND_LINE()*/
        _67opCOMMAND_LINE();
        goto L3; // [257] 1903

        /** execute.e:4056				case COMPARE then*/
        case 76:

        /** execute.e:4057					opCOMPARE()*/
        _67opCOMPARE();
        goto L3; // [267] 1903

        /** execute.e:4059				case CONCAT then*/
        case 15:

        /** execute.e:4060					opCONCAT()*/
        _67opCONCAT();
        goto L3; // [277] 1903

        /** execute.e:4062				case CONCAT_N then*/
        case 157:

        /** execute.e:4063					opCONCAT_N()*/
        _67opCONCAT_N();
        goto L3; // [287] 1903

        /** execute.e:4065				case COS then*/
        case 81:

        /** execute.e:4066					opCOS()*/
        _67opCOS();
        goto L3; // [297] 1903

        /** execute.e:4068				case DATE then*/
        case 69:

        /** execute.e:4069					opDATE()*/
        _67opDATE();
        goto L3; // [307] 1903

        /** execute.e:4071				case DIV2 then*/
        case 98:

        /** execute.e:4072					opDIV2()*/
        _67opDIV2();
        goto L3; // [317] 1903

        /** execute.e:4074				case DIVIDE then*/
        case 14:

        /** execute.e:4075					opDIVIDE()*/
        _67opDIVIDE();
        goto L3; // [327] 1903

        /** execute.e:4077				case ELSE, EXIT, ENDWHILE, RETRY then*/
        case 23:
        case 61:
        case 22:
        case 184:

        /** execute.e:4078					opELSE()*/
        _67opELSE();
        goto L3; // [343] 1903

        /** execute.e:4080				case ENDFOR_GENERAL, ENDFOR_UP, ENDFOR_DOWN, ENDFOR_INT_UP,*/
        case 39:
        case 49:
        case 50:
        case 48:
        case 52:
        case 55:

        /** execute.e:4082					opENDFOR_GENERAL()*/
        _67opENDFOR_GENERAL();
        goto L3; // [363] 1903

        /** execute.e:4084				case ENDFOR_INT_UP1 then*/
        case 54:

        /** execute.e:4085					opENDFOR_INT_UP1()*/
        _67opENDFOR_INT_UP1();
        goto L3; // [373] 1903

        /** execute.e:4087				case EQUAL then*/
        case 153:

        /** execute.e:4088					opEQUAL()*/
        _67opEQUAL();
        goto L3; // [383] 1903

        /** execute.e:4090				case EQUALS then*/
        case 3:

        /** execute.e:4091					opEQUALS()*/
        _67opEQUALS();
        goto L3; // [393] 1903

        /** execute.e:4093				case EQUALS_IFW, EQUALS_IFW_I then*/
        case 104:
        case 121:

        /** execute.e:4094					opEQUALS_IFW()*/
        _67opEQUALS_IFW();
        goto L3; // [405] 1903

        /** execute.e:4096				case EXIT_BLOCK then*/
        case 206:

        /** execute.e:4097					opEXIT_BLOCK()*/
        _67opEXIT_BLOCK();
        goto L3; // [415] 1903

        /** execute.e:4099				case FIND then*/
        case 77:

        /** execute.e:4100					opFIND()*/
        _67opFIND();
        goto L3; // [425] 1903

        /** execute.e:4102				case FIND_FROM then*/
        case 176:

        /** execute.e:4103					opFIND_FROM()*/
        _67opFIND_FROM();
        goto L3; // [435] 1903

        /** execute.e:4105				case FLOOR then*/
        case 83:

        /** execute.e:4106					opFLOOR()*/
        _67opFLOOR();
        goto L3; // [445] 1903

        /** execute.e:4108				case FLOOR_DIV then*/
        case 63:

        /** execute.e:4109					opFLOOR_DIV()*/
        _67opFLOOR_DIV();
        goto L3; // [455] 1903

        /** execute.e:4111				case FLOOR_DIV2 then*/
        case 66:

        /** execute.e:4112					opFLOOR_DIV2()*/
        _67opFLOOR_DIV2();
        goto L3; // [465] 1903

        /** execute.e:4114				case FOR, FOR_I then*/
        case 21:
        case 125:

        /** execute.e:4115					opFOR()*/
        _67opFOR();
        goto L3; // [477] 1903

        /** execute.e:4117				case GET_KEY then*/
        case 79:

        /** execute.e:4118					opGET_KEY()*/
        _67opGET_KEY();
        goto L3; // [487] 1903

        /** execute.e:4120				case GETC then*/
        case 33:

        /** execute.e:4121					opGETC()*/
        _67opGETC();
        goto L3; // [497] 1903

        /** execute.e:4123				case GETENV then*/
        case 91:

        /** execute.e:4124					opGETENV()*/
        _67opGETENV();
        goto L3; // [507] 1903

        /** execute.e:4126				case GETS then*/
        case 17:

        /** execute.e:4127					opGETS()*/
        _67opGETS();
        goto L3; // [517] 1903

        /** execute.e:4129				case GLABEL then*/
        case 189:

        /** execute.e:4130					opGLABEL()*/
        _67opGLABEL();
        goto L3; // [527] 1903

        /** execute.e:4132				case GLOBAL_INIT_CHECK, PRIVATE_INIT_CHECK then*/
        case 109:
        case 30:

        /** execute.e:4133					opGLOBAL_INIT_CHECK()*/
        _67opGLOBAL_INIT_CHECK();
        goto L3; // [539] 1903

        /** execute.e:4135				case GOTO then*/
        case 188:

        /** execute.e:4136					opGOTO()*/
        _67opGOTO();
        goto L3; // [549] 1903

        /** execute.e:4138				case GREATER then*/
        case 6:

        /** execute.e:4139					opGREATER()*/
        _67opGREATER();
        goto L3; // [559] 1903

        /** execute.e:4141				case GREATER_IFW, GREATER_IFW_I then*/
        case 107:
        case 124:

        /** execute.e:4142					opGREATER_IFW()*/
        _67opGREATER_IFW();
        goto L3; // [571] 1903

        /** execute.e:4144				case GREATEREQ then*/
        case 2:

        /** execute.e:4145					opGREATEREQ()*/
        _67opGREATEREQ();
        goto L3; // [581] 1903

        /** execute.e:4147				case GREATEREQ_IFW, GREATEREQ_IFW_I then*/
        case 103:
        case 120:

        /** execute.e:4148					opGREATEREQ_IFW()*/
        _67opGREATEREQ_IFW();
        goto L3; // [593] 1903

        /** execute.e:4150				case HASH then*/
        case 194:

        /** execute.e:4151					opHASH()*/
        _67opHASH();
        goto L3; // [603] 1903

        /** execute.e:4153				case HEAD then*/
        case 198:

        /** execute.e:4154					opHEAD()*/
        _67opHEAD();
        goto L3; // [613] 1903

        /** execute.e:4156				case IF then*/
        case 20:

        /** execute.e:4157					opIF()*/
        _67opIF();
        goto L3; // [623] 1903

        /** execute.e:4159				case INSERT then*/
        case 191:

        /** execute.e:4160					opINSERT()*/
        _67opINSERT();
        goto L3; // [633] 1903

        /** execute.e:4162				case INTEGER_CHECK then*/
        case 96:

        /** execute.e:4163					opINTEGER_CHECK()*/
        _67opINTEGER_CHECK();
        goto L3; // [643] 1903

        /** execute.e:4165				case IS_A_SEQUENCE then*/
        case 68:

        /** execute.e:4166					opIS_A_SEQUENCE()*/
        _67opIS_A_SEQUENCE();
        goto L3; // [653] 1903

        /** execute.e:4168				case IS_AN_ATOM then*/
        case 67:

        /** execute.e:4169					opIS_AN_ATOM()*/
        _67opIS_AN_ATOM();
        goto L3; // [663] 1903

        /** execute.e:4171				case IS_AN_INTEGER then*/
        case 94:

        /** execute.e:4172					opIS_AN_INTEGER()*/
        _67opIS_AN_INTEGER();
        goto L3; // [673] 1903

        /** execute.e:4174				case IS_AN_OBJECT then*/
        case 40:

        /** execute.e:4175					opIS_AN_OBJECT()*/
        _67opIS_AN_OBJECT();
        goto L3; // [683] 1903

        /** execute.e:4177				case LENGTH then*/
        case 42:

        /** execute.e:4178					opLENGTH()*/
        _67opLENGTH();
        goto L3; // [693] 1903

        /** execute.e:4180				case LESS then*/
        case 1:

        /** execute.e:4181					opLESS()*/
        _67opLESS();
        goto L3; // [703] 1903

        /** execute.e:4183				case LESS_IFW_I, LESS_IFW then*/
        case 119:
        case 102:

        /** execute.e:4184					opLESS_IFW()*/
        _67opLESS_IFW();
        goto L3; // [715] 1903

        /** execute.e:4186				case LESSEQ then*/
        case 5:

        /** execute.e:4187					opLESSEQ()*/
        _67opLESSEQ();
        goto L3; // [725] 1903

        /** execute.e:4189				case LESSEQ_IFW, LESSEQ_IFW_I then*/
        case 106:
        case 123:

        /** execute.e:4190					opLESSEQ_IFW()*/
        _67opLESSEQ_IFW();
        goto L3; // [737] 1903

        /** execute.e:4192				case LHS_SUBS then*/
        case 95:

        /** execute.e:4193					opLHS_SUBS()*/
        _67opLHS_SUBS();
        goto L3; // [747] 1903

        /** execute.e:4195				case LHS_SUBS1 then*/
        case 161:

        /** execute.e:4196					opLHS_SUBS1()*/
        _67opLHS_SUBS1();
        goto L3; // [757] 1903

        /** execute.e:4198				case LHS_SUBS1_COPY then*/
        case 166:

        /** execute.e:4199					opLHS_SUBS1_COPY()*/
        _67opLHS_SUBS1_COPY();
        goto L3; // [767] 1903

        /** execute.e:4201				case LOG then*/
        case 74:

        /** execute.e:4202					opLOG()*/
        _67opLOG();
        goto L3; // [777] 1903

        /** execute.e:4204				case MACHINE_FUNC then*/
        case 111:

        /** execute.e:4205					opMACHINE_FUNC()*/
        _67opMACHINE_FUNC();
        goto L3; // [787] 1903

        /** execute.e:4207				case MACHINE_PROC then*/
        case 112:

        /** execute.e:4208					opMACHINE_PROC()*/
        _67opMACHINE_PROC();
        goto L3; // [797] 1903

        /** execute.e:4210				case MATCH then*/
        case 78:

        /** execute.e:4211					opMATCH()*/
        _67opMATCH();
        goto L3; // [807] 1903

        /** execute.e:4213				case MATCH_FROM then*/
        case 177:

        /** execute.e:4214					opMATCH_FROM()*/
        _67opMATCH_FROM();
        goto L3; // [817] 1903

        /** execute.e:4216				case MEM_COPY then*/
        case 130:

        /** execute.e:4217					opMEM_COPY()*/
        _67opMEM_COPY();
        goto L3; // [827] 1903

        /** execute.e:4219				case MEM_SET then*/
        case 131:

        /** execute.e:4220					opMEM_SET()*/
        _67opMEM_SET();
        goto L3; // [837] 1903

        /** execute.e:4222				case MINUS, MINUS_I then*/
        case 10:
        case 116:

        /** execute.e:4223					opMINUS()*/
        _67opMINUS();
        goto L3; // [849] 1903

        /** execute.e:4225				case MULTIPLY then*/
        case 13:

        /** execute.e:4226					opMULTIPLY()*/
        _67opMULTIPLY();
        goto L3; // [859] 1903

        /** execute.e:4228				case NOP2, SC2_NULL, ASSIGN_SUBS2, PLATFORM, END_PARAM_CHECK,*/
        case 110:
        case 145:
        case 148:
        case 155:
        case 156:
        case 158:
        case 159:

        /** execute.e:4230					opNOP2()*/
        _67opNOP2();
        goto L3; // [881] 1903

        /** execute.e:4232				case NOPSWITCH then*/
        case 187:

        /** execute.e:4233					opNOPSWITCH()*/
        _67opNOPSWITCH();
        goto L3; // [891] 1903

        /** execute.e:4235				case NOT then*/
        case 7:

        /** execute.e:4236					opNOT()*/
        _67opNOT();
        goto L3; // [901] 1903

        /** execute.e:4238				case NOT_BITS then*/
        case 51:

        /** execute.e:4239					opNOT_BITS()*/
        _67opNOT_BITS();
        goto L3; // [911] 1903

        /** execute.e:4241				case NOT_IFW then*/
        case 108:

        /** execute.e:4242					opNOT_IFW()*/
        _67opNOT_IFW();
        goto L3; // [921] 1903

        /** execute.e:4244				case NOTEQ then*/
        case 4:

        /** execute.e:4245					opNOTEQ()*/
        _67opNOTEQ();
        goto L3; // [931] 1903

        /** execute.e:4247				case NOTEQ_IFW, NOTEQ_IFW_I then*/
        case 105:
        case 122:

        /** execute.e:4248					opNOTEQ_IFW()*/
        _67opNOTEQ_IFW();
        goto L3; // [943] 1903

        /** execute.e:4250				case OPEN then*/
        case 37:

        /** execute.e:4251					opOPEN()*/
        _67opOPEN();
        goto L3; // [953] 1903

        /** execute.e:4253				case OPTION_SWITCHES then*/
        case 183:

        /** execute.e:4254					opOPTION_SWITCHES()*/
        _67opOPTION_SWITCHES();
        goto L3; // [963] 1903

        /** execute.e:4256				case OR then*/
        case 9:

        /** execute.e:4257					opOR()*/
        _67opOR();
        goto L3; // [973] 1903

        /** execute.e:4259				case OR_BITS then*/
        case 24:

        /** execute.e:4260					opOR_BITS()*/
        _67opOR_BITS();
        goto L3; // [983] 1903

        /** execute.e:4262				case PASSIGN_OP_SLICE then*/
        case 165:

        /** execute.e:4263					opPASSIGN_OP_SLICE()*/
        _67opPASSIGN_OP_SLICE();
        goto L3; // [993] 1903

        /** execute.e:4265				case PASSIGN_OP_SUBS then*/
        case 164:

        /** execute.e:4266					opPASSIGN_OP_SUBS()*/
        _67opPASSIGN_OP_SUBS();
        goto L3; // [1003] 1903

        /** execute.e:4268				case PASSIGN_SLICE then*/
        case 163:

        /** execute.e:4269					opPASSIGN_SLICE()*/
        _67opPASSIGN_SLICE();
        goto L3; // [1013] 1903

        /** execute.e:4271				case PASSIGN_SUBS then*/
        case 162:

        /** execute.e:4272					opPASSIGN_SUBS()*/
        _67opPASSIGN_SUBS();
        goto L3; // [1023] 1903

        /** execute.e:4274				case PEEK then*/
        case 127:

        /** execute.e:4275					opPEEK()*/
        _67opPEEK();
        goto L3; // [1033] 1903

        /** execute.e:4277				case PEEK_STRING then*/
        case 182:

        /** execute.e:4278					opPEEK_STRING()*/
        _67opPEEK_STRING();
        goto L3; // [1043] 1903

        /** execute.e:4280				case PEEK2S then*/
        case 179:

        /** execute.e:4281					opPEEK2S()*/
        _67opPEEK2S();
        goto L3; // [1053] 1903

        /** execute.e:4283				case PEEK2U then*/
        case 180:

        /** execute.e:4284					opPEEK2U()*/
        _67opPEEK2U();
        goto L3; // [1063] 1903

        /** execute.e:4286				case PEEK4S then*/
        case 139:

        /** execute.e:4287					opPEEK4S()*/
        _67opPEEK4S();
        goto L3; // [1073] 1903

        /** execute.e:4289				case PEEK4U then*/
        case 140:

        /** execute.e:4290					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1083] 1903

        /** execute.e:4292				case PEEK8S then*/
        case 213:

        /** execute.e:4293					opPEEK8S()*/
        _67opPEEK8S();
        goto L3; // [1093] 1903

        /** execute.e:4295				case PEEK8U then*/
        case 214:

        /** execute.e:4296					opPEEK8U()*/
        _67opPEEK8U();
        goto L3; // [1103] 1903

        /** execute.e:4298				case PEEKS then*/
        case 181:

        /** execute.e:4299					opPEEKS()*/
        _67opPEEKS();
        goto L3; // [1113] 1903

        /** execute.e:4301				case PLENGTH then*/
        case 160:

        /** execute.e:4302					opPLENGTH()*/
        _67opPLENGTH();
        goto L3; // [1123] 1903

        /** execute.e:4304				case PLUS, PLUS_I then*/
        case 11:
        case 115:

        /** execute.e:4305					opPLUS()*/
        _67opPLUS();
        goto L3; // [1135] 1903

        /** execute.e:4307				case PLUS1, PLUS1_I then*/
        case 93:
        case 117:

        /** execute.e:4308					opPLUS1()*/
        _67opPLUS1();
        goto L3; // [1147] 1903

        /** execute.e:4310				case POKE then*/
        case 128:

        /** execute.e:4311					opPOKE()*/
        _67opPOKE();
        goto L3; // [1157] 1903

        /** execute.e:4313				case POKE2 then*/
        case 178:

        /** execute.e:4314					opPOKE2()*/
        _67opPOKE2();
        goto L3; // [1167] 1903

        /** execute.e:4316				case POKE4 then*/
        case 138:

        /** execute.e:4317					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1177] 1903

        /** execute.e:4319				case POKE8 then*/
        case 212:

        /** execute.e:4320					opPOKE8()*/
        _67opPOKE8();
        goto L3; // [1187] 1903

        /** execute.e:4322				case POKE_POINTER then*/
        case 215:

        /** execute.e:4323					opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1197] 1903

        /** execute.e:4325				case PEEK_POINTER then*/
        case 216:

        /** execute.e:4326					opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1207] 1903

        /** execute.e:4328				case POSITION then*/
        case 60:

        /** execute.e:4329					opPOSITION()*/
        _67opPOSITION();
        goto L3; // [1217] 1903

        /** execute.e:4331				case POWER then*/
        case 72:

        /** execute.e:4332					opPOWER()*/
        _67opPOWER();
        goto L3; // [1227] 1903

        /** execute.e:4334				case PREPEND then*/
        case 57:

        /** execute.e:4335					opPREPEND()*/
        _67opPREPEND();
        goto L3; // [1237] 1903

        /** execute.e:4337				case PRINT then*/
        case 19:

        /** execute.e:4338					opPRINT()*/
        _67opPRINT();
        goto L3; // [1247] 1903

        /** execute.e:4340				case PRINTF then*/
        case 38:

        /** execute.e:4341					opPRINTF()*/
        _67opPRINTF();
        goto L3; // [1257] 1903

        /** execute.e:4343				case PROC_TAIL then*/
        case 203:

        /** execute.e:4344					opPROC_TAIL()*/
        _67opPROC_TAIL();
        goto L3; // [1267] 1903

        /** execute.e:4346				case PROC then*/
        case 27:

        /** execute.e:4347					opPROC()*/
        _67opPROC();
        goto L3; // [1277] 1903

        /** execute.e:4349				case PROFILE, DISPLAY_VAR, ERASE_PRIVATE_NAMES, ERASE_SYMBOL then*/
        case 151:
        case 87:
        case 88:
        case 90:

        /** execute.e:4350					opPROFILE()*/
        _67opPROFILE();
        goto L3; // [1293] 1903

        /** execute.e:4352				case PUTS then*/
        case 44:

        /** execute.e:4353					opPUTS()*/
        _67opPUTS();
        goto L3; // [1303] 1903

        /** execute.e:4355				case QPRINT then*/
        case 36:

        /** execute.e:4356					opQPRINT()*/
        _67opQPRINT();
        goto L3; // [1313] 1903

        /** execute.e:4358				case RAND then*/
        case 62:

        /** execute.e:4359					opRAND()*/
        _67opRAND();
        goto L3; // [1323] 1903

        /** execute.e:4361				case REMAINDER then*/
        case 71:

        /** execute.e:4362					opREMAINDER()*/
        _67opREMAINDER();
        goto L3; // [1333] 1903

        /** execute.e:4364				case REMOVE then*/
        case 200:

        /** execute.e:4365					opREMOVE()*/
        _67opREMOVE();
        goto L3; // [1343] 1903

        /** execute.e:4367				case REPEAT then*/
        case 32:

        /** execute.e:4368					opREPEAT()*/
        _67opREPEAT();
        goto L3; // [1353] 1903

        /** execute.e:4370				case REPLACE then*/
        case 201:

        /** execute.e:4371					opREPLACE()*/
        _67opREPLACE();
        goto L3; // [1363] 1903

        /** execute.e:4373				case RETURNF then*/
        case 28:

        /** execute.e:4374					opRETURNF()*/
        _67opRETURNF();
        goto L3; // [1373] 1903

        /** execute.e:4376				case RETURNP then*/
        case 29:

        /** execute.e:4377					opRETURNP()*/
        _67opRETURNP();
        goto L3; // [1383] 1903

        /** execute.e:4379				case RETURNT then*/
        case 34:

        /** execute.e:4380					opRETURNT()*/
        _67opRETURNT();
        goto L3; // [1393] 1903

        /** execute.e:4382				case RHS_SLICE then*/
        case 46:

        /** execute.e:4383					opRHS_SLICE()*/
        _67opRHS_SLICE();
        goto L3; // [1403] 1903

        /** execute.e:4385				case RHS_SUBS, RHS_SUBS_CHECK, RHS_SUBS_I then*/
        case 25:
        case 92:
        case 114:

        /** execute.e:4386					opRHS_SUBS()*/
        _67opRHS_SUBS();
        goto L3; // [1417] 1903

        /** execute.e:4388				case RIGHT_BRACE_2 then*/
        case 85:

        /** execute.e:4389					opRIGHT_BRACE_2()*/
        _67opRIGHT_BRACE_2();
        goto L3; // [1427] 1903

        /** execute.e:4391				case RIGHT_BRACE_N then*/
        case 31:

        /** execute.e:4392					opRIGHT_BRACE_N()*/
        _67opRIGHT_BRACE_N();
        goto L3; // [1437] 1903

        /** execute.e:4394				case ROUTINE_ID then*/
        case 134:

        /** execute.e:4395					opROUTINE_ID()*/
        _67opROUTINE_ID();
        goto L3; // [1447] 1903

        /** execute.e:4397				case SC1_AND then*/
        case 141:

        /** execute.e:4398					opSC1_AND()*/
        _67opSC1_AND();
        goto L3; // [1457] 1903

        /** execute.e:4400				case SC1_AND_IF then*/
        case 146:

        /** execute.e:4401					opSC1_AND_IF()*/
        _67opSC1_AND_IF();
        goto L3; // [1467] 1903

        /** execute.e:4403				case SC1_OR then*/
        case 143:

        /** execute.e:4404					opSC1_OR()*/
        _67opSC1_OR();
        goto L3; // [1477] 1903

        /** execute.e:4406				case SC1_OR_IF then*/
        case 147:

        /** execute.e:4407					opSC1_OR_IF()*/
        _67opSC1_OR_IF();
        goto L3; // [1487] 1903

        /** execute.e:4409				case SC2_OR, SC2_AND then*/
        case 144:
        case 142:

        /** execute.e:4410					opSC2_OR()*/
        _67opSC2_OR();
        goto L3; // [1499] 1903

        /** execute.e:4412				case SEQUENCE_CHECK then*/
        case 97:

        /** execute.e:4413					opSEQUENCE_CHECK()*/
        _67opSEQUENCE_CHECK();
        goto L3; // [1509] 1903

        /** execute.e:4415				case SIN then*/
        case 80:

        /** execute.e:4416					opSIN()*/
        _67opSIN();
        goto L3; // [1519] 1903

        /** execute.e:4418				case SPACE_USED then*/
        case 75:

        /** execute.e:4419					opSPACE_USED()*/
        _67opSPACE_USED();
        goto L3; // [1529] 1903

        /** execute.e:4421				case SPLICE then*/
        case 190:

        /** execute.e:4422					opSPLICE()*/
        _67opSPLICE();
        goto L3; // [1539] 1903

        /** execute.e:4424				case SPRINTF then*/
        case 53:

        /** execute.e:4425					opSPRINTF()*/
        _67opSPRINTF();
        goto L3; // [1549] 1903

        /** execute.e:4427				case SQRT then*/
        case 41:

        /** execute.e:4428					opSQRT()*/
        _67opSQRT();
        goto L3; // [1559] 1903

        /** execute.e:4430				case STARTLINE then*/
        case 58:

        /** execute.e:4431					opSTARTLINE()*/
        _67opSTARTLINE();
        goto L3; // [1569] 1903

        /** execute.e:4433				case SWITCH, SWITCH_I then*/
        case 185:
        case 193:

        /** execute.e:4434					opSWITCH()*/
        _67opSWITCH();
        goto L3; // [1581] 1903

        /** execute.e:4436				case SWITCH_SPI then*/
        case 192:

        /** execute.e:4437					opSWITCH_SPI()*/
        _67opSWITCH_SPI();
        goto L3; // [1591] 1903

        /** execute.e:4439				case SWITCH_RT then*/
        case 202:

        /** execute.e:4440					opSWITCH_RT()*/
        _67opSWITCH_RT();
        goto L3; // [1601] 1903

        /** execute.e:4442				case SYSTEM then*/
        case 99:

        /** execute.e:4443					opSYSTEM()*/
        _67opSYSTEM();
        goto L3; // [1611] 1903

        /** execute.e:4445				case SYSTEM_EXEC then*/
        case 154:

        /** execute.e:4446					opSYSTEM_EXEC()*/
        _67opSYSTEM_EXEC();
        goto L3; // [1621] 1903

        /** execute.e:4448				case TAIL then*/
        case 199:

        /** execute.e:4449					opTAIL()*/
        _67opTAIL();
        goto L3; // [1631] 1903

        /** execute.e:4451				case TAN then*/
        case 82:

        /** execute.e:4452					opTAN()*/
        _67opTAN();
        goto L3; // [1641] 1903

        /** execute.e:4454				case TASK_CLOCK_START then*/
        case 175:

        /** execute.e:4455					opTASK_CLOCK_START()*/
        _67opTASK_CLOCK_START();
        goto L3; // [1651] 1903

        /** execute.e:4457				case TASK_CLOCK_STOP then*/
        case 174:

        /** execute.e:4458					opTASK_CLOCK_STOP()*/
        _67opTASK_CLOCK_STOP();
        goto L3; // [1661] 1903

        /** execute.e:4460				case TASK_CREATE then*/
        case 167:

        /** execute.e:4461					opTASK_CREATE()*/
        _67opTASK_CREATE();
        goto L3; // [1671] 1903

        /** execute.e:4463				case TASK_LIST then*/
        case 172:

        /** execute.e:4464					opTASK_LIST()*/
        _67opTASK_LIST();
        goto L3; // [1681] 1903

        /** execute.e:4466				case TASK_SCHEDULE then*/
        case 168:

        /** execute.e:4467					opTASK_SCHEDULE()*/
        _67opTASK_SCHEDULE();
        goto L3; // [1691] 1903

        /** execute.e:4469				case TASK_SELF then*/
        case 170:

        /** execute.e:4470					opTASK_SELF()*/
        _67opTASK_SELF();
        goto L3; // [1701] 1903

        /** execute.e:4472				case TASK_STATUS then*/
        case 173:

        /** execute.e:4473					opTASK_STATUS()*/
        _67opTASK_STATUS();
        goto L3; // [1711] 1903

        /** execute.e:4475				case TASK_SUSPEND then*/
        case 171:

        /** execute.e:4476					opTASK_SUSPEND()*/
        _67opTASK_SUSPEND();
        goto L3; // [1721] 1903

        /** execute.e:4478				case TASK_YIELD then*/
        case 169:

        /** execute.e:4479					opTASK_YIELD()*/
        _67opTASK_YIELD();
        goto L3; // [1731] 1903

        /** execute.e:4481				case TIME then*/
        case 70:

        /** execute.e:4482					opTIME()*/
        _67opTIME();
        goto L3; // [1741] 1903

        /** execute.e:4484				case TRACE then*/
        case 64:

        /** execute.e:4485					opTRACE()*/
        _67opTRACE();
        goto L3; // [1751] 1903

        /** execute.e:4487				case TYPE_CHECK then*/
        case 65:

        /** execute.e:4488					opTYPE_CHECK()*/
        _67opTYPE_CHECK();
        goto L3; // [1761] 1903

        /** execute.e:4490				case UMINUS then*/
        case 12:

        /** execute.e:4491					opUMINUS()*/
        _67opUMINUS();
        goto L3; // [1771] 1903

        /** execute.e:4493				case UPDATE_GLOBALS then*/
        case 89:

        /** execute.e:4494					opUPDATE_GLOBALS()*/
        _67opUPDATE_GLOBALS();
        goto L3; // [1781] 1903

        /** execute.e:4496				case WHILE then*/
        case 47:

        /** execute.e:4497					opWHILE()*/
        _67opWHILE();
        goto L3; // [1791] 1903

        /** execute.e:4499				case XOR then*/
        case 152:

        /** execute.e:4500					opXOR()*/
        _67opXOR();
        goto L3; // [1801] 1903

        /** execute.e:4502				case XOR_BITS then*/
        case 26:

        /** execute.e:4503					opXOR_BITS()*/
        _67opXOR_BITS();
        goto L3; // [1811] 1903

        /** execute.e:4505				case DELETE_ROUTINE then*/
        case 204:

        /** execute.e:4506					opDELETE_ROUTINE()*/
        _67opDELETE_ROUTINE();
        goto L3; // [1821] 1903

        /** execute.e:4508				case DELETE_OBJECT then*/
        case 205:

        /** execute.e:4509					opDELETE_OBJECT()*/
        _67opDELETE_OBJECT();
        goto L3; // [1831] 1903

        /** execute.e:4511				case REF_TEMP then*/
        case 207:

        /** execute.e:4512					pc += 2*/
        _67pc_65255 = _67pc_65255 + 2;
        goto L3; // [1845] 1903

        /** execute.e:4513				case DEREF_TEMP, NOVALUE_TEMP then*/
        case 208:
        case 209:

        /** execute.e:4514					opDEREF_TEMP()*/
        _67opDEREF_TEMP();
        goto L3; // [1857] 1903

        /** execute.e:4516				case COVERAGE_LINE then*/
        case 210:

        /** execute.e:4517					opCOVERAGE_LINE()*/
        _67opCOVERAGE_LINE();
        goto L3; // [1867] 1903

        /** execute.e:4519				case COVERAGE_ROUTINE then*/
        case 211:

        /** execute.e:4520					opCOVERAGE_ROUTINE()*/
        _67opCOVERAGE_ROUTINE();
        goto L3; // [1877] 1903

        /** execute.e:4522				case SIZEOF then*/
        case 217:

        /** execute.e:4523					opSIZEOF()*/
        _67opSIZEOF();
        goto L3; // [1887] 1903

        /** execute.e:4525				case else*/
        default:

        /** execute.e:4526					RTFatal( sprintf("Unknown opcode: %d", op ) )*/
        _35279 = EPrintf(-9999999, _35278, _op_70611);
        _67RTFatal(_35279);
        _35279 = NOVALUE;
    ;}L3: 

    /** execute.e:4528		end while*/
    goto L1; // [1907] 15
L2: 

    /** execute.e:4529		keep_running = TRUE -- so higher-level do_exec() will keep running*/
    _67keep_running_65262 = _9TRUE_441;

    /** execute.e:4530	end procedure*/
    return;
    ;
}


void _67InitBackEnd()
{
    object _name_71016 = NOVALUE;
    object _len_71017 = NOVALUE;
    object _35290 = NOVALUE;
    object _35289 = NOVALUE;
    object _35288 = NOVALUE;
    object _35287 = NOVALUE;
    object _35286 = NOVALUE;
    object _35284 = NOVALUE;
    object _35283 = NOVALUE;
    object _35282 = NOVALUE;
    object _35281 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** execute.e:4540		integer len = length(val)*/
    if (IS_SEQUENCE(_67val_65265)){
            _len_71017 = SEQ_PTR(_67val_65265)->length;
    }
    else {
        _len_71017 = 1;
    }

    /** execute.e:4541		val = val & repeat(0, length(SymTab)-length(val))*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _35281 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _35281 = 1;
    }
    if (IS_SEQUENCE(_67val_65265)){
            _35282 = SEQ_PTR(_67val_65265)->length;
    }
    else {
        _35282 = 1;
    }
    _35283 = _35281 - _35282;
    _35281 = NOVALUE;
    _35282 = NOVALUE;
    _35284 = Repeat(0, _35283);
    _35283 = NOVALUE;
    Concat((object_ptr)&_67val_65265, _67val_65265, _35284);
    DeRefDS(_35284);
    _35284 = NOVALUE;

    /** execute.e:4542		for i = len + 1 to length(SymTab) do*/
    _35286 = _len_71017 + 1;
    if (IS_SEQUENCE(_28SymTab_11572)){
            _35287 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _35287 = 1;
    }
    {
        object _i_71026;
        _i_71026 = _35286;
L1: 
        if (_i_71026 > _35287){
            goto L2; // [45] 94
        }

        /** execute.e:4543			val[i] = SymTab[i][S_OBJ] -- might be NOVALUE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _35288 = (object)*(((s1_ptr)_2)->base + _i_71026);
        _2 = (object)SEQ_PTR(_35288);
        _35289 = (object)*(((s1_ptr)_2)->base + 1);
        _35288 = NOVALUE;
        Ref(_35289);
        _2 = (object)SEQ_PTR(_67val_65265);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67val_65265 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_71026);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _35289;
        if( _1 != _35289 ){
            DeRef(_1);
        }
        _35289 = NOVALUE;

        /** execute.e:4544			SymTab[i][S_OBJ] = 0*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_71026 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _35290 = NOVALUE;

        /** execute.e:4545		end for*/
        _i_71026 = _i_71026 + 1;
        goto L1; // [89] 52
L2: 
        ;
    }

    /** execute.e:4546	end procedure*/
    DeRef(_35286);
    _35286 = NOVALUE;
    return;
    ;
}


void _67fake_init(object _ignore_71040)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ignore_71040)) {
        _1 = (object)(DBL_PTR(_ignore_71040)->dbl);
        DeRefDS(_ignore_71040);
        _ignore_71040 = _1;
    }

    /** execute.e:4549		intoptions()*/
    _68intoptions();

    /** execute.e:4550	end procedure*/
    return;
    ;
}


void _67Execute(object _proc_71049, object _start_index_71050)
{
    object _35299 = NOVALUE;
    object _35295 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_71049)) {
        _1 = (object)(DBL_PTR(_proc_71049)->dbl);
        DeRefDS(_proc_71049);
        _proc_71049 = _1;
    }
    if (!IS_ATOM_INT(_start_index_71050)) {
        _1 = (object)(DBL_PTR(_start_index_71050)->dbl);
        DeRefDS(_start_index_71050);
        _start_index_71050 = _1;
    }

    /** execute.e:4555		InitBackEnd()*/
    _67InitBackEnd();

    /** execute.e:4556		if current_task = -1 then*/
    if (_67current_task_65272 != -1)
    goto L1; // [13] 23

    /** execute.e:4557		current_task = 1*/
    _67current_task_65272 = 1;
L1: 

    /** execute.e:4559		if not length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_65273)){
            _35295 = SEQ_PTR(_67call_stack_65273)->length;
    }
    else {
        _35295 = 1;
    }
    if (_35295 != 0)
    goto L2; // [30] 40
    _35295 = NOVALUE;

    /** execute.e:4560		call_stack = {proc}*/
    _0 = _67call_stack_65273;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _proc_71049;
    _67call_stack_65273 = MAKE_SEQ(_1);
    DeRefDS(_0);
L2: 

    /** execute.e:4562		if pc = -1 then*/
    if (_67pc_65255 != -1)
    goto L3; // [44] 54

    /** execute.e:4563		pc = start_index*/
    _67pc_65255 = _start_index_71050;
L3: 

    /** execute.e:4565		Code = SymTab[proc][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _35299 = (object)*(((s1_ptr)_2)->base + _proc_71049);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_35299);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _35299 = NOVALUE;

    /** execute.e:4566		do_exec()*/
    _67do_exec();

    /** execute.e:4567		if repl then*/

    /** execute.e:4570	end procedure*/
    return;
    ;
}


void _67BackEnd(object _ignore_71072)
{
    object _0, _1, _2;
    

    /** execute.e:4577		Execute(TopLevelSub, 1)*/
    _67Execute(_27TopLevelSub_20578, 1);

    /** execute.e:4578	end procedure*/
    return;
    ;
}



// 0xF922DC7C
