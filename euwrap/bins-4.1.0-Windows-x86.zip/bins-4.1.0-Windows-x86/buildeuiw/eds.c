// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _41fatal(object _errcode_16074, object _msg_16075, object _routine_name_16076, object _parms_16077)
{
    object _9145 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:231		vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _errcode_16074;
    RefDS(_msg_16075);
    ((intptr_t*)_2)[2] = _msg_16075;
    RefDS(_routine_name_16076);
    ((intptr_t*)_2)[3] = _routine_name_16076;
    RefDS(_parms_16077);
    ((intptr_t*)_2)[4] = _parms_16077;
    _9145 = MAKE_SEQ(_1);
    RefDS(_9145);
    Append(&_41vLastErrors_16071, _41vLastErrors_16071, _9145);
    DeRefDS(_9145);
    _9145 = NOVALUE;

    /** eds.e:232		if db_fatal_id >= 0 then*/

    /** eds.e:235	end procedure*/
    DeRefDSi(_msg_16075);
    DeRefDSi(_routine_name_16076);
    DeRefDS(_parms_16077);
    return;
    ;
}


object _41get4()
{
    object _9161 = NOVALUE;
    object _9160 = NOVALUE;
    object _9159 = NOVALUE;
    object _9158 = NOVALUE;
    object _9157 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:250		poke(mem0, getc(current_db))*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9157 = getKBchar();
        }
        else{
            _9157 = getc(last_r_file_ptr);
        }
    }
    else{
        _9157 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem0_16089)){
        poke_addr = (uint8_t *)_41mem0_16089;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke_addr = (uint8_t)_9157;
    _9157 = NOVALUE;

    /** eds.e:251		poke(mem1, getc(current_db))*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9158 = getKBchar();
        }
        else{
            _9158 = getc(last_r_file_ptr);
        }
    }
    else{
        _9158 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem1_16090)){
        poke_addr = (uint8_t *)_41mem1_16090;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem1_16090)->dbl);
    }
    *poke_addr = (uint8_t)_9158;
    _9158 = NOVALUE;

    /** eds.e:252		poke(mem2, getc(current_db))*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9159 = getKBchar();
        }
        else{
            _9159 = getc(last_r_file_ptr);
        }
    }
    else{
        _9159 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem2_16091)){
        poke_addr = (uint8_t *)_41mem2_16091;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem2_16091)->dbl);
    }
    *poke_addr = (uint8_t)_9159;
    _9159 = NOVALUE;

    /** eds.e:253		poke(mem3, getc(current_db))*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9160 = getKBchar();
        }
        else{
            _9160 = getc(last_r_file_ptr);
        }
    }
    else{
        _9160 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem3_16092)){
        poke_addr = (uint8_t *)_41mem3_16092;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem3_16092)->dbl);
    }
    *poke_addr = (uint8_t)_9160;
    _9160 = NOVALUE;

    /** eds.e:254		return peek4u(mem0)*/
    if (IS_ATOM_INT(_41mem0_16089)) {
        _9161 = (object)*(uint32_t *)_41mem0_16089;
        if ((uintptr_t)_9161 > (uintptr_t)MAXINT){
            _9161 = NewDouble((eudouble)(uintptr_t)_9161);
        }
    }
    else {
        _9161 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        if ((uintptr_t)_9161 > (uintptr_t)MAXINT){
            _9161 = NewDouble((eudouble)(uintptr_t)_9161);
        }
    }
    return _9161;
    ;
}


object _41get_string()
{
    object _where_inlined_where_at_31_16117 = NOVALUE;
    object _s_16106 = NOVALUE;
    object _c_16107 = NOVALUE;
    object _i_16108 = NOVALUE;
    object _9174 = NOVALUE;
    object _9171 = NOVALUE;
    object _9169 = NOVALUE;
    object _9167 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:263		s = repeat(0, 256)*/
    DeRefi(_s_16106);
    _s_16106 = Repeat(0, 256);

    /** eds.e:264		i = 0*/
    _i_16108 = 0;

    /** eds.e:265		while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_16107 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** eds.e:266			if c = -1 then*/
    if (_c_16107 != -1)
    goto L4; // [24] 54

    /** eds.e:267				fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_16117);
    _where_inlined_where_at_31_16117 = machine(20, _41current_db_16047);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_16117);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_31_16117;
    _9167 = MAKE_SEQ(_1);
    RefDS(_9165);
    RefDS(_9166);
    _41fatal(900, _9165, _9166, _9167);
    _9167 = NOVALUE;

    /** eds.e:268				exit*/
    goto L3; // [51] 101
L4: 

    /** eds.e:270			i += 1*/
    _i_16108 = _i_16108 + 1;

    /** eds.e:271			if i > length(s) then*/
    if (IS_SEQUENCE(_s_16106)){
            _9169 = SEQ_PTR(_s_16106)->length;
    }
    else {
        _9169 = 1;
    }
    if (_i_16108 <= _9169)
    goto L5; // [65] 80

    /** eds.e:272				s &= repeat(0, 256)*/
    _9171 = Repeat(0, 256);
    Concat((object_ptr)&_s_16106, _s_16106, _9171);
    DeRefDS(_9171);
    _9171 = NOVALUE;
L5: 

    /** eds.e:274			s[i] = c*/
    _2 = (object)SEQ_PTR(_s_16106);
    _2 = (object)(((s1_ptr)_2)->base + _i_16108);
    *(intptr_t *)_2 = _c_16107;

    /** eds.e:275		  entry*/
L1: 

    /** eds.e:276			c = getc(current_db)*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16107 = getKBchar();
        }
        else{
            _c_16107 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16107 = getc(last_r_file_ptr);
    }

    /** eds.e:277		end while*/
    goto L2; // [98] 17
L3: 

    /** eds.e:278		return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9174;
    RHS_Slice(_s_16106, 1, _i_16108);
    DeRefDSi(_s_16106);
    return _9174;
    ;
}


object _41equal_string(object _target_16129)
{
    object _c_16130 = NOVALUE;
    object _i_16131 = NOVALUE;
    object _where_inlined_where_at_27_16137 = NOVALUE;
    object _9185 = NOVALUE;
    object _9184 = NOVALUE;
    object _9181 = NOVALUE;
    object _9179 = NOVALUE;
    object _9177 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:286		i = 0*/
    _i_16131 = 0;

    /** eds.e:287		while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_16130 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** eds.e:288			if c = -1 then*/
    if (_c_16130 != -1)
    goto L4; // [20] 52

    /** eds.e:289				fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_16137);
    _where_inlined_where_at_27_16137 = machine(20, _41current_db_16047);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_16137);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_27_16137;
    _9177 = MAKE_SEQ(_1);
    RefDS(_9165);
    RefDS(_9176);
    _41fatal(900, _9165, _9176, _9177);
    _9177 = NOVALUE;

    /** eds.e:290				return DB_FATAL_FAIL*/
    DeRefDS(_target_16129);
    return -404;
L4: 

    /** eds.e:292			i += 1*/
    _i_16131 = _i_16131 + 1;

    /** eds.e:293			if i > length(target) then*/
    if (IS_SEQUENCE(_target_16129)){
            _9179 = SEQ_PTR(_target_16129)->length;
    }
    else {
        _9179 = 1;
    }
    if (_i_16131 <= _9179)
    goto L5; // [63] 74

    /** eds.e:294				return 0*/
    DeRefDS(_target_16129);
    return 0;
L5: 

    /** eds.e:296			if target[i] != c then*/
    _2 = (object)SEQ_PTR(_target_16129);
    _9181 = (object)*(((s1_ptr)_2)->base + _i_16131);
    if (binary_op_a(EQUALS, _9181, _c_16130)){
        _9181 = NOVALUE;
        goto L6; // [80] 91
    }
    _9181 = NOVALUE;

    /** eds.e:297				return 0*/
    DeRefDS(_target_16129);
    return 0;
L6: 

    /** eds.e:299		  entry*/
L1: 

    /** eds.e:300			c = getc(current_db)*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16130 = getKBchar();
        }
        else{
            _c_16130 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16130 = getc(last_r_file_ptr);
    }

    /** eds.e:301		end while*/
    goto L2; // [103] 13
L3: 

    /** eds.e:302		return (i = length(target))*/
    if (IS_SEQUENCE(_target_16129)){
            _9184 = SEQ_PTR(_target_16129)->length;
    }
    else {
        _9184 = 1;
    }
    _9185 = (_i_16131 == _9184);
    _9184 = NOVALUE;
    DeRefDS(_target_16129);
    return _9185;
    ;
}


object _41decompress(object _c_16177)
{
    object _s_16178 = NOVALUE;
    object _len_16179 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_176_16215 = NOVALUE;
    object _ieee32_inlined_float32_to_atom_at_173_16214 = NOVALUE;
    object _float64_to_atom_inlined_float64_to_atom_at_251_16228 = NOVALUE;
    object _ieee64_inlined_float64_to_atom_at_248_16227 = NOVALUE;
    object _9243 = NOVALUE;
    object _9242 = NOVALUE;
    object _9241 = NOVALUE;
    object _9238 = NOVALUE;
    object _9233 = NOVALUE;
    object _9232 = NOVALUE;
    object _9231 = NOVALUE;
    object _9230 = NOVALUE;
    object _9229 = NOVALUE;
    object _9228 = NOVALUE;
    object _9227 = NOVALUE;
    object _9226 = NOVALUE;
    object _9225 = NOVALUE;
    object _9224 = NOVALUE;
    object _9223 = NOVALUE;
    object _9222 = NOVALUE;
    object _9221 = NOVALUE;
    object _9220 = NOVALUE;
    object _9219 = NOVALUE;
    object _9218 = NOVALUE;
    object _9217 = NOVALUE;
    object _9216 = NOVALUE;
    object _9215 = NOVALUE;
    object _9214 = NOVALUE;
    object _9212 = NOVALUE;
    object _9211 = NOVALUE;
    object _9210 = NOVALUE;
    object _9209 = NOVALUE;
    object _9208 = NOVALUE;
    object _9207 = NOVALUE;
    object _9206 = NOVALUE;
    object _9205 = NOVALUE;
    object _9204 = NOVALUE;
    object _9201 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:332		if c = 0 then*/
    if (_c_16177 != 0)
    goto L1; // [5] 34

    /** eds.e:333			c = getc(current_db)*/
    if (_41current_db_16047 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
        last_r_file_no = _41current_db_16047;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16177 = getKBchar();
        }
        else{
            _c_16177 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16177 = getc(last_r_file_ptr);
    }

    /** eds.e:334			if c < I2B then*/
    if (_c_16177 >= 249)
    goto L2; // [18] 33

    /** eds.e:335				return c + MIN1B*/
    _9201 = _c_16177 + -9;
    DeRef(_s_16178);
    return _9201;
L2: 
L1: 

    /** eds.e:339		switch c with fallthru do*/
    _0 = _c_16177;
    switch ( _0 ){ 

        /** eds.e:340			case I2B then*/
        case 249:

        /** eds.e:341				return getc(current_db) +*/
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9204 = getKBchar();
            }
            else{
                _9204 = getc(last_r_file_ptr);
            }
        }
        else{
            _9204 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9205 = getKBchar();
            }
            else{
                _9205 = getc(last_r_file_ptr);
            }
        }
        else{
            _9205 = getc(last_r_file_ptr);
        }
        _9206 = 256 * _9205;
        _9205 = NOVALUE;
        _9207 = _9204 + _9206;
        _9204 = NOVALUE;
        _9206 = NOVALUE;
        _9208 = _9207 + _41MIN2B_16160;
        if ((object)((uintptr_t)_9208 + (uintptr_t)HIGH_BITS) >= 0){
            _9208 = NewDouble((eudouble)_9208);
        }
        _9207 = NOVALUE;
        DeRef(_s_16178);
        DeRef(_9201);
        _9201 = NOVALUE;
        return _9208;

        /** eds.e:345			case I3B then*/
        case 250:

        /** eds.e:346				return getc(current_db) +*/
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9209 = getKBchar();
            }
            else{
                _9209 = getc(last_r_file_ptr);
            }
        }
        else{
            _9209 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9210 = getKBchar();
            }
            else{
                _9210 = getc(last_r_file_ptr);
            }
        }
        else{
            _9210 = getc(last_r_file_ptr);
        }
        _9211 = 256 * _9210;
        _9210 = NOVALUE;
        _9212 = _9209 + _9211;
        _9209 = NOVALUE;
        _9211 = NOVALUE;
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9214 = getKBchar();
            }
            else{
                _9214 = getc(last_r_file_ptr);
            }
        }
        else{
            _9214 = getc(last_r_file_ptr);
        }
        _9215 = 65536 * _9214;
        _9214 = NOVALUE;
        _9216 = _9212 + _9215;
        _9212 = NOVALUE;
        _9215 = NOVALUE;
        _9217 = _9216 + _41MIN3B_16166;
        if ((object)((uintptr_t)_9217 + (uintptr_t)HIGH_BITS) >= 0){
            _9217 = NewDouble((eudouble)_9217);
        }
        _9216 = NOVALUE;
        DeRef(_s_16178);
        DeRef(_9201);
        _9201 = NOVALUE;
        DeRef(_9208);
        _9208 = NOVALUE;
        return _9217;

        /** eds.e:351			case I4B then*/
        case 251:

        /** eds.e:352				return get4() + MIN4B*/
        _9218 = _41get4();
        if (IS_ATOM_INT(_9218) && IS_ATOM_INT(_41MIN4B_16172)) {
            _9219 = _9218 + _41MIN4B_16172;
            if ((object)((uintptr_t)_9219 + (uintptr_t)HIGH_BITS) >= 0){
                _9219 = NewDouble((eudouble)_9219);
            }
        }
        else {
            _9219 = binary_op(PLUS, _9218, _41MIN4B_16172);
        }
        DeRef(_9218);
        _9218 = NOVALUE;
        DeRef(_s_16178);
        DeRef(_9201);
        _9201 = NOVALUE;
        DeRef(_9208);
        _9208 = NOVALUE;
        DeRef(_9217);
        _9217 = NOVALUE;
        return _9219;

        /** eds.e:354			case F4B then*/
        case 252:

        /** eds.e:355				return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9220 = getKBchar();
            }
            else{
                _9220 = getc(last_r_file_ptr);
            }
        }
        else{
            _9220 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9221 = getKBchar();
            }
            else{
                _9221 = getc(last_r_file_ptr);
            }
        }
        else{
            _9221 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9222 = getKBchar();
            }
            else{
                _9222 = getc(last_r_file_ptr);
            }
        }
        else{
            _9222 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9223 = getKBchar();
            }
            else{
                _9223 = getc(last_r_file_ptr);
            }
        }
        else{
            _9223 = getc(last_r_file_ptr);
        }
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9220;
        ((intptr_t*)_2)[2] = _9221;
        ((intptr_t*)_2)[3] = _9222;
        ((intptr_t*)_2)[4] = _9223;
        _9224 = MAKE_SEQ(_1);
        _9223 = NOVALUE;
        _9222 = NOVALUE;
        _9221 = NOVALUE;
        _9220 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16214);
        _ieee32_inlined_float32_to_atom_at_173_16214 = _9224;
        _9224 = NOVALUE;

        /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_16215);
        _float32_to_atom_inlined_float32_to_atom_at_176_16215 = machine(49, _ieee32_inlined_float32_to_atom_at_173_16214);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16214);
        _ieee32_inlined_float32_to_atom_at_173_16214 = NOVALUE;
        DeRef(_s_16178);
        DeRef(_9201);
        _9201 = NOVALUE;
        DeRef(_9208);
        _9208 = NOVALUE;
        DeRef(_9219);
        _9219 = NOVALUE;
        DeRef(_9217);
        _9217 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_16215;

        /** eds.e:358			case F8B then*/
        case 253:

        /** eds.e:359				return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9225 = getKBchar();
            }
            else{
                _9225 = getc(last_r_file_ptr);
            }
        }
        else{
            _9225 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9226 = getKBchar();
            }
            else{
                _9226 = getc(last_r_file_ptr);
            }
        }
        else{
            _9226 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9227 = getKBchar();
            }
            else{
                _9227 = getc(last_r_file_ptr);
            }
        }
        else{
            _9227 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9228 = getKBchar();
            }
            else{
                _9228 = getc(last_r_file_ptr);
            }
        }
        else{
            _9228 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9229 = getKBchar();
            }
            else{
                _9229 = getc(last_r_file_ptr);
            }
        }
        else{
            _9229 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9230 = getKBchar();
            }
            else{
                _9230 = getc(last_r_file_ptr);
            }
        }
        else{
            _9230 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9231 = getKBchar();
            }
            else{
                _9231 = getc(last_r_file_ptr);
            }
        }
        else{
            _9231 = getc(last_r_file_ptr);
        }
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9232 = getKBchar();
            }
            else{
                _9232 = getc(last_r_file_ptr);
            }
        }
        else{
            _9232 = getc(last_r_file_ptr);
        }
        _1 = NewS1(8);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9225;
        ((intptr_t*)_2)[2] = _9226;
        ((intptr_t*)_2)[3] = _9227;
        ((intptr_t*)_2)[4] = _9228;
        ((intptr_t*)_2)[5] = _9229;
        ((intptr_t*)_2)[6] = _9230;
        ((intptr_t*)_2)[7] = _9231;
        ((intptr_t*)_2)[8] = _9232;
        _9233 = MAKE_SEQ(_1);
        _9232 = NOVALUE;
        _9231 = NOVALUE;
        _9230 = NOVALUE;
        _9229 = NOVALUE;
        _9228 = NOVALUE;
        _9227 = NOVALUE;
        _9226 = NOVALUE;
        _9225 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16227);
        _ieee64_inlined_float64_to_atom_at_248_16227 = _9233;
        _9233 = NOVALUE;

        /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_16228);
        _float64_to_atom_inlined_float64_to_atom_at_251_16228 = machine(47, _ieee64_inlined_float64_to_atom_at_248_16227);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16227);
        _ieee64_inlined_float64_to_atom_at_248_16227 = NOVALUE;
        DeRef(_s_16178);
        DeRef(_9201);
        _9201 = NOVALUE;
        DeRef(_9208);
        _9208 = NOVALUE;
        DeRef(_9219);
        _9219 = NOVALUE;
        DeRef(_9217);
        _9217 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_16228;

        /** eds.e:364			case else*/
        default:

        /** eds.e:366				if c = S1B then*/
        if (_c_16177 != 254)
        goto L3; // [273] 287

        /** eds.e:367					len = getc(current_db)*/
        if (_41current_db_16047 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
            last_r_file_no = _41current_db_16047;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_16179 = getKBchar();
            }
            else{
                _len_16179 = getc(last_r_file_ptr);
            }
        }
        else{
            _len_16179 = getc(last_r_file_ptr);
        }
        goto L4; // [284] 295
L3: 

        /** eds.e:369					len = get4()*/
        _len_16179 = _41get4();
        if (!IS_ATOM_INT(_len_16179)) {
            _1 = (object)(DBL_PTR(_len_16179)->dbl);
            DeRefDS(_len_16179);
            _len_16179 = _1;
        }
L4: 

        /** eds.e:371				s = repeat(0, len)*/
        DeRef(_s_16178);
        _s_16178 = Repeat(0, _len_16179);

        /** eds.e:372				for i = 1 to len do*/
        _9238 = _len_16179;
        {
            object _i_16237;
            _i_16237 = 1;
L5: 
            if (_i_16237 > _9238){
                goto L6; // [308] 362
            }

            /** eds.e:374					c = getc(current_db)*/
            if (_41current_db_16047 != last_r_file_no) {
                last_r_file_ptr = which_file(_41current_db_16047, EF_READ);
                last_r_file_no = _41current_db_16047;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_16177 = getKBchar();
                }
                else{
                    _c_16177 = getc(last_r_file_ptr);
                }
            }
            else{
                _c_16177 = getc(last_r_file_ptr);
            }

            /** eds.e:375					if c < I2B then*/
            if (_c_16177 >= 249)
            goto L7; // [324] 341

            /** eds.e:376						s[i] = c + MIN1B*/
            _9241 = _c_16177 + -9;
            _2 = (object)SEQ_PTR(_s_16178);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_16178 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_16237);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9241;
            if( _1 != _9241 ){
                DeRef(_1);
            }
            _9241 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** eds.e:378						s[i] = decompress(c)*/
            DeRef(_9242);
            _9242 = _c_16177;
            _9243 = _41decompress(_9242);
            _9242 = NOVALUE;
            _2 = (object)SEQ_PTR(_s_16178);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_16178 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_16237);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9243;
            if( _1 != _9243 ){
                DeRef(_1);
            }
            _9243 = NOVALUE;
L8: 

            /** eds.e:380				end for*/
            _i_16237 = _i_16237 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** eds.e:381				return s*/
        DeRef(_9201);
        _9201 = NOVALUE;
        DeRef(_9208);
        _9208 = NOVALUE;
        DeRef(_9219);
        _9219 = NOVALUE;
        DeRef(_9217);
        _9217 = NOVALUE;
        return _s_16178;
    ;}    ;
}


object _41compress(object _x_16248)
{
    object _x4_16249 = NOVALUE;
    object _s_16250 = NOVALUE;
    object _atom_to_float32_inlined_atom_to_float32_at_193_16284 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_204_16287 = NOVALUE;
    object _atom_to_float64_inlined_atom_to_float64_at_230_16292 = NOVALUE;
    object _9282 = NOVALUE;
    object _9281 = NOVALUE;
    object _9280 = NOVALUE;
    object _9278 = NOVALUE;
    object _9277 = NOVALUE;
    object _9275 = NOVALUE;
    object _9273 = NOVALUE;
    object _9272 = NOVALUE;
    object _9271 = NOVALUE;
    object _9269 = NOVALUE;
    object _9268 = NOVALUE;
    object _9267 = NOVALUE;
    object _9266 = NOVALUE;
    object _9265 = NOVALUE;
    object _9264 = NOVALUE;
    object _9263 = NOVALUE;
    object _9262 = NOVALUE;
    object _9261 = NOVALUE;
    object _9259 = NOVALUE;
    object _9258 = NOVALUE;
    object _9257 = NOVALUE;
    object _9256 = NOVALUE;
    object _9255 = NOVALUE;
    object _9254 = NOVALUE;
    object _9252 = NOVALUE;
    object _9251 = NOVALUE;
    object _9250 = NOVALUE;
    object _9249 = NOVALUE;
    object _9248 = NOVALUE;
    object _9247 = NOVALUE;
    object _9246 = NOVALUE;
    object _9245 = NOVALUE;
    object _9244 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:390		if integer(x) then*/
    if (IS_ATOM_INT(_x_16248))
    _9244 = 1;
    else if (IS_ATOM_DBL(_x_16248))
    _9244 = IS_ATOM_INT(DoubleToInt(_x_16248));
    else
    _9244 = 0;
    if (_9244 == 0)
    {
        _9244 = NOVALUE;
        goto L1; // [6] 184
    }
    else{
        _9244 = NOVALUE;
    }

    /** eds.e:391			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_16248)) {
        _9245 = (_x_16248 >= -9);
    }
    else {
        _9245 = binary_op(GREATEREQ, _x_16248, -9);
    }
    if (IS_ATOM_INT(_9245)) {
        if (_9245 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9245)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_16248)) {
        _9247 = (_x_16248 <= 239);
    }
    else {
        _9247 = binary_op(LESSEQ, _x_16248, 239);
    }
    if (_9247 == 0) {
        DeRef(_9247);
        _9247 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9247) && DBL_PTR(_9247)->dbl == 0.0){
            DeRef(_9247);
            _9247 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9247);
        _9247 = NOVALUE;
    }
    DeRef(_9247);
    _9247 = NOVALUE;

    /** eds.e:392				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_16248)) {
        _9248 = _x_16248 - -9;
        if ((object)((uintptr_t)_9248 +(uintptr_t) HIGH_BITS) >= 0){
            _9248 = NewDouble((eudouble)_9248);
        }
    }
    else {
        _9248 = binary_op(MINUS, _x_16248, -9);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _9248;
    _9249 = MAKE_SEQ(_1);
    _9248 = NOVALUE;
    DeRef(_x_16248);
    DeRefi(_x4_16249);
    DeRef(_s_16250);
    DeRef(_9245);
    _9245 = NOVALUE;
    return _9249;
    goto L3; // [41] 330
L2: 

    /** eds.e:394			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_16248)) {
        _9250 = (_x_16248 >= _41MIN2B_16160);
    }
    else {
        _9250 = binary_op(GREATEREQ, _x_16248, _41MIN2B_16160);
    }
    if (IS_ATOM_INT(_9250)) {
        if (_9250 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9250)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_16248)) {
        _9252 = (_x_16248 <= 32767);
    }
    else {
        _9252 = binary_op(LESSEQ, _x_16248, 32767);
    }
    if (_9252 == 0) {
        DeRef(_9252);
        _9252 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9252) && DBL_PTR(_9252)->dbl == 0.0){
            DeRef(_9252);
            _9252 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9252);
        _9252 = NOVALUE;
    }
    DeRef(_9252);
    _9252 = NOVALUE;

    /** eds.e:395				x -= MIN2B*/
    _0 = _x_16248;
    if (IS_ATOM_INT(_x_16248)) {
        _x_16248 = _x_16248 - _41MIN2B_16160;
        if ((object)((uintptr_t)_x_16248 +(uintptr_t) HIGH_BITS) >= 0){
            _x_16248 = NewDouble((eudouble)_x_16248);
        }
    }
    else {
        _x_16248 = binary_op(MINUS, _x_16248, _41MIN2B_16160);
    }
    DeRef(_0);

    /** eds.e:396				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_16248)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_16248 & (uintptr_t)255;
             _9254 = MAKE_UINT(tu);
        }
    }
    else {
        _9254 = binary_op(AND_BITS, _x_16248, 255);
    }
    if (IS_ATOM_INT(_x_16248)) {
        if (256 > 0 && _x_16248 >= 0) {
            _9255 = _x_16248 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_16248 / (eudouble)256);
            if (_x_16248 != MININT)
            _9255 = (object)temp_dbl;
            else
            _9255 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16248, 256);
        _9255 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 249;
    ((intptr_t*)_2)[2] = _9254;
    ((intptr_t*)_2)[3] = _9255;
    _9256 = MAKE_SEQ(_1);
    _9255 = NOVALUE;
    _9254 = NOVALUE;
    DeRef(_x_16248);
    DeRefi(_x4_16249);
    DeRef(_s_16250);
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    DeRef(_9245);
    _9245 = NOVALUE;
    return _9256;
    goto L3; // [94] 330
L4: 

    /** eds.e:398			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_16248)) {
        _9257 = (_x_16248 >= _41MIN3B_16166);
    }
    else {
        _9257 = binary_op(GREATEREQ, _x_16248, _41MIN3B_16166);
    }
    if (IS_ATOM_INT(_9257)) {
        if (_9257 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9257)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_16248)) {
        _9259 = (_x_16248 <= 8388607);
    }
    else {
        _9259 = binary_op(LESSEQ, _x_16248, 8388607);
    }
    if (_9259 == 0) {
        DeRef(_9259);
        _9259 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9259) && DBL_PTR(_9259)->dbl == 0.0){
            DeRef(_9259);
            _9259 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9259);
        _9259 = NOVALUE;
    }
    DeRef(_9259);
    _9259 = NOVALUE;

    /** eds.e:399				x -= MIN3B*/
    _0 = _x_16248;
    if (IS_ATOM_INT(_x_16248)) {
        _x_16248 = _x_16248 - _41MIN3B_16166;
        if ((object)((uintptr_t)_x_16248 +(uintptr_t) HIGH_BITS) >= 0){
            _x_16248 = NewDouble((eudouble)_x_16248);
        }
    }
    else {
        _x_16248 = binary_op(MINUS, _x_16248, _41MIN3B_16166);
    }
    DeRef(_0);

    /** eds.e:400				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_16248)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_16248 & (uintptr_t)255;
             _9261 = MAKE_UINT(tu);
        }
    }
    else {
        _9261 = binary_op(AND_BITS, _x_16248, 255);
    }
    if (IS_ATOM_INT(_x_16248)) {
        if (256 > 0 && _x_16248 >= 0) {
            _9262 = _x_16248 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_16248 / (eudouble)256);
            if (_x_16248 != MININT)
            _9262 = (object)temp_dbl;
            else
            _9262 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16248, 256);
        _9262 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9262)) {
        {uintptr_t tu;
             tu = (uintptr_t)_9262 & (uintptr_t)255;
             _9263 = MAKE_UINT(tu);
        }
    }
    else {
        _9263 = binary_op(AND_BITS, _9262, 255);
    }
    DeRef(_9262);
    _9262 = NOVALUE;
    if (IS_ATOM_INT(_x_16248)) {
        if (65536 > 0 && _x_16248 >= 0) {
            _9264 = _x_16248 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_16248 / (eudouble)65536);
            if (_x_16248 != MININT)
            _9264 = (object)temp_dbl;
            else
            _9264 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16248, 65536);
        _9264 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 250;
    ((intptr_t*)_2)[2] = _9261;
    ((intptr_t*)_2)[3] = _9263;
    ((intptr_t*)_2)[4] = _9264;
    _9265 = MAKE_SEQ(_1);
    _9264 = NOVALUE;
    _9263 = NOVALUE;
    _9261 = NOVALUE;
    DeRef(_x_16248);
    DeRefi(_x4_16249);
    DeRef(_s_16250);
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9257);
    _9257 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    DeRef(_9256);
    _9256 = NOVALUE;
    DeRef(_9245);
    _9245 = NOVALUE;
    return _9265;
    goto L3; // [156] 330
L5: 

    /** eds.e:403				return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_16248) && IS_ATOM_INT(_41MIN4B_16172)) {
        _9266 = _x_16248 - _41MIN4B_16172;
        if ((object)((uintptr_t)_9266 +(uintptr_t) HIGH_BITS) >= 0){
            _9266 = NewDouble((eudouble)_9266);
        }
    }
    else {
        _9266 = binary_op(MINUS, _x_16248, _41MIN4B_16172);
    }
    _9267 = _13int_to_bytes(_9266, 4);
    _9266 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_9267)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_9267)) {
        Prepend(&_9268, _9267, 251);
    }
    else {
        Concat((object_ptr)&_9268, 251, _9267);
    }
    DeRef(_9267);
    _9267 = NOVALUE;
    DeRef(_x_16248);
    DeRefi(_x4_16249);
    DeRef(_s_16250);
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9257);
    _9257 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    DeRef(_9256);
    _9256 = NOVALUE;
    DeRef(_9245);
    _9245 = NOVALUE;
    DeRef(_9265);
    _9265 = NOVALUE;
    return _9268;
    goto L3; // [181] 330
L1: 

    /** eds.e:407		elsif atom(x) then*/
    _9269 = IS_ATOM(_x_16248);
    if (_9269 == 0)
    {
        _9269 = NOVALUE;
        goto L6; // [189] 250
    }
    else{
        _9269 = NOVALUE;
    }

    /** eds.e:409			x4 = convert:atom_to_float32(x)*/

    /** convert.e:312		return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_16249);
    _x4_16249 = machine(48, _x_16248);

    /** eds.e:410			if x = convert:float32_to_atom(x4) then*/

    /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_204_16287);
    _float32_to_atom_inlined_float32_to_atom_at_204_16287 = machine(49, _x4_16249);
    if (binary_op_a(NOTEQ, _x_16248, _float32_to_atom_inlined_float32_to_atom_at_204_16287)){
        goto L7; // [212] 229
    }

    /** eds.e:412				return F4B & x4*/
    Prepend(&_9271, _x4_16249, 252);
    DeRef(_x_16248);
    DeRefDSi(_x4_16249);
    DeRef(_s_16250);
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9257);
    _9257 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    DeRef(_9256);
    _9256 = NOVALUE;
    DeRef(_9245);
    _9245 = NOVALUE;
    DeRef(_9265);
    _9265 = NOVALUE;
    DeRef(_9268);
    _9268 = NOVALUE;
    return _9271;
    goto L3; // [226] 330
L7: 

    /** eds.e:414				return F8B & convert:atom_to_float64(x)*/

    /** convert.e:262		return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_230_16292);
    _atom_to_float64_inlined_atom_to_float64_at_230_16292 = machine(46, _x_16248);
    Prepend(&_9272, _atom_to_float64_inlined_atom_to_float64_at_230_16292, 253);
    DeRef(_x_16248);
    DeRefi(_x4_16249);
    DeRef(_s_16250);
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9257);
    _9257 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    DeRef(_9271);
    _9271 = NOVALUE;
    DeRef(_9256);
    _9256 = NOVALUE;
    DeRef(_9245);
    _9245 = NOVALUE;
    DeRef(_9265);
    _9265 = NOVALUE;
    DeRef(_9268);
    _9268 = NOVALUE;
    return _9272;
    goto L3; // [247] 330
L6: 

    /** eds.e:419			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_16248)){
            _9273 = SEQ_PTR(_x_16248)->length;
    }
    else {
        _9273 = 1;
    }
    if (_9273 > 255)
    goto L8; // [255] 271

    /** eds.e:420				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_16248)){
            _9275 = SEQ_PTR(_x_16248)->length;
    }
    else {
        _9275 = 1;
    }
    DeRef(_s_16250);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254;
    ((intptr_t *)_2)[2] = _9275;
    _s_16250 = MAKE_SEQ(_1);
    _9275 = NOVALUE;
    goto L9; // [268] 286
L8: 

    /** eds.e:422				s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_16248)){
            _9277 = SEQ_PTR(_x_16248)->length;
    }
    else {
        _9277 = 1;
    }
    _9278 = _13int_to_bytes(_9277, 4);
    _9277 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_9278)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_9278)) {
        Prepend(&_s_16250, _9278, 255);
    }
    else {
        Concat((object_ptr)&_s_16250, 255, _9278);
    }
    DeRef(_9278);
    _9278 = NOVALUE;
L9: 

    /** eds.e:424			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_16248)){
            _9280 = SEQ_PTR(_x_16248)->length;
    }
    else {
        _9280 = 1;
    }
    {
        object _i_16305;
        _i_16305 = 1;
LA: 
        if (_i_16305 > _9280){
            goto LB; // [291] 321
        }

        /** eds.e:425				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_16248);
        _9281 = (object)*(((s1_ptr)_2)->base + _i_16305);
        Ref(_9281);
        _9282 = _41compress(_9281);
        _9281 = NOVALUE;
        if (IS_SEQUENCE(_s_16250) && IS_ATOM(_9282)) {
            Ref(_9282);
            Append(&_s_16250, _s_16250, _9282);
        }
        else if (IS_ATOM(_s_16250) && IS_SEQUENCE(_9282)) {
        }
        else {
            Concat((object_ptr)&_s_16250, _s_16250, _9282);
        }
        DeRef(_9282);
        _9282 = NOVALUE;

        /** eds.e:426			end for*/
        _i_16305 = _i_16305 + 1;
        goto LA; // [316] 298
LB: 
        ;
    }

    /** eds.e:427			return s*/
    DeRef(_x_16248);
    DeRefi(_x4_16249);
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9257);
    _9257 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    DeRef(_9271);
    _9271 = NOVALUE;
    DeRef(_9256);
    _9256 = NOVALUE;
    DeRef(_9245);
    _9245 = NOVALUE;
    DeRef(_9265);
    _9265 = NOVALUE;
    DeRef(_9268);
    _9268 = NOVALUE;
    DeRef(_9272);
    _9272 = NOVALUE;
    return _s_16250;
L3: 
    ;
}


object _41db_allocate(object _n_16676)
{
    object _free_list_16677 = NOVALUE;
    object _size_16678 = NOVALUE;
    object _size_ptr_16679 = NOVALUE;
    object _addr_16680 = NOVALUE;
    object _free_count_16681 = NOVALUE;
    object _remaining_16682 = NOVALUE;
    object _seek_1__tmp_at4_16685 = NOVALUE;
    object _seek_inlined_seek_at_4_16684 = NOVALUE;
    object _seek_1__tmp_at39_16692 = NOVALUE;
    object _seek_inlined_seek_at_39_16691 = NOVALUE;
    object _seek_1__tmp_at111_16709 = NOVALUE;
    object _seek_inlined_seek_at_111_16708 = NOVALUE;
    object _pos_inlined_seek_at_108_16707 = NOVALUE;
    object _put4_1__tmp_at137_16714 = NOVALUE;
    object _x_inlined_put4_at_134_16713 = NOVALUE;
    object _seek_1__tmp_at167_16717 = NOVALUE;
    object _seek_inlined_seek_at_167_16716 = NOVALUE;
    object _put4_1__tmp_at193_16722 = NOVALUE;
    object _x_inlined_put4_at_190_16721 = NOVALUE;
    object _seek_1__tmp_at244_16730 = NOVALUE;
    object _seek_inlined_seek_at_244_16729 = NOVALUE;
    object _pos_inlined_seek_at_241_16728 = NOVALUE;
    object _put4_1__tmp_at266_16734 = NOVALUE;
    object _x_inlined_put4_at_263_16733 = NOVALUE;
    object _seek_1__tmp_at333_16745 = NOVALUE;
    object _seek_inlined_seek_at_333_16744 = NOVALUE;
    object _pos_inlined_seek_at_330_16743 = NOVALUE;
    object _seek_1__tmp_at364_16749 = NOVALUE;
    object _seek_inlined_seek_at_364_16748 = NOVALUE;
    object _put4_1__tmp_at386_16753 = NOVALUE;
    object _x_inlined_put4_at_383_16752 = NOVALUE;
    object _seek_1__tmp_at423_16758 = NOVALUE;
    object _seek_inlined_seek_at_423_16757 = NOVALUE;
    object _pos_inlined_seek_at_420_16756 = NOVALUE;
    object _put4_1__tmp_at438_16760 = NOVALUE;
    object _seek_1__tmp_at490_16764 = NOVALUE;
    object _seek_inlined_seek_at_490_16763 = NOVALUE;
    object _put4_1__tmp_at512_16768 = NOVALUE;
    object _x_inlined_put4_at_509_16767 = NOVALUE;
    object _where_inlined_where_at_542_16770 = NOVALUE;
    object _9481 = NOVALUE;
    object _9479 = NOVALUE;
    object _9478 = NOVALUE;
    object _9477 = NOVALUE;
    object _9476 = NOVALUE;
    object _9475 = NOVALUE;
    object _9473 = NOVALUE;
    object _9472 = NOVALUE;
    object _9471 = NOVALUE;
    object _9470 = NOVALUE;
    object _9468 = NOVALUE;
    object _9467 = NOVALUE;
    object _9466 = NOVALUE;
    object _9465 = NOVALUE;
    object _9464 = NOVALUE;
    object _9463 = NOVALUE;
    object _9462 = NOVALUE;
    object _9460 = NOVALUE;
    object _9458 = NOVALUE;
    object _9455 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:795		io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_16685);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at4_16685 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_16684 = machine(19, _seek_1__tmp_at4_16685);
    DeRefi(_seek_1__tmp_at4_16685);
    _seek_1__tmp_at4_16685 = NOVALUE;

    /** eds.e:796		free_count = get4()*/
    _free_count_16681 = _41get4();
    if (!IS_ATOM_INT(_free_count_16681)) {
        _1 = (object)(DBL_PTR(_free_count_16681)->dbl);
        DeRefDS(_free_count_16681);
        _free_count_16681 = _1;
    }

    /** eds.e:797		if free_count > 0 then*/
    if (_free_count_16681 <= 0)
    goto L1; // [27] 487

    /** eds.e:798			free_list = get4()*/
    _0 = _free_list_16677;
    _free_list_16677 = _41get4();
    DeRef(_0);

    /** eds.e:799			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16677);
    DeRef(_seek_1__tmp_at39_16692);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _free_list_16677;
    _seek_1__tmp_at39_16692 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_16691 = machine(19, _seek_1__tmp_at39_16692);
    DeRef(_seek_1__tmp_at39_16692);
    _seek_1__tmp_at39_16692 = NOVALUE;

    /** eds.e:800			size_ptr = free_list + 4*/
    DeRef(_size_ptr_16679);
    if (IS_ATOM_INT(_free_list_16677)) {
        _size_ptr_16679 = _free_list_16677 + 4;
        if ((object)((uintptr_t)_size_ptr_16679 + (uintptr_t)HIGH_BITS) >= 0){
            _size_ptr_16679 = NewDouble((eudouble)_size_ptr_16679);
        }
    }
    else {
        _size_ptr_16679 = NewDouble(DBL_PTR(_free_list_16677)->dbl + (eudouble)4);
    }

    /** eds.e:801			for i = 1 to free_count do*/
    _9455 = _free_count_16681;
    {
        object _i_16695;
        _i_16695 = 1;
L2: 
        if (_i_16695 > _9455){
            goto L3; // [64] 486
        }

        /** eds.e:802				addr = get4()*/
        _0 = _addr_16680;
        _addr_16680 = _41get4();
        DeRef(_0);

        /** eds.e:803				size = get4()*/
        _0 = _size_16678;
        _size_16678 = _41get4();
        DeRef(_0);

        /** eds.e:804				if size >= n+4 then*/
        if (IS_ATOM_INT(_n_16676)) {
            _9458 = _n_16676 + 4;
            if ((object)((uintptr_t)_9458 + (uintptr_t)HIGH_BITS) >= 0){
                _9458 = NewDouble((eudouble)_9458);
            }
        }
        else {
            _9458 = NewDouble(DBL_PTR(_n_16676)->dbl + (eudouble)4);
        }
        if (binary_op_a(LESS, _size_16678, _9458)){
            DeRef(_9458);
            _9458 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_9458);
        _9458 = NOVALUE;

        /** eds.e:806					if size >= n+16 then*/
        if (IS_ATOM_INT(_n_16676)) {
            _9460 = _n_16676 + 16;
            if ((object)((uintptr_t)_9460 + (uintptr_t)HIGH_BITS) >= 0){
                _9460 = NewDouble((eudouble)_9460);
            }
        }
        else {
            _9460 = NewDouble(DBL_PTR(_n_16676)->dbl + (eudouble)16);
        }
        if (binary_op_a(LESS, _size_16678, _9460)){
            DeRef(_9460);
            _9460 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_9460);
        _9460 = NOVALUE;

        /** eds.e:808						io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_16680)) {
            _9462 = _addr_16680 - 4;
            if ((object)((uintptr_t)_9462 +(uintptr_t) HIGH_BITS) >= 0){
                _9462 = NewDouble((eudouble)_9462);
            }
        }
        else {
            _9462 = NewDouble(DBL_PTR(_addr_16680)->dbl - (eudouble)4);
        }
        DeRef(_pos_inlined_seek_at_108_16707);
        _pos_inlined_seek_at_108_16707 = _9462;
        _9462 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_16707);
        DeRef(_seek_1__tmp_at111_16709);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_108_16707;
        _seek_1__tmp_at111_16709 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_16708 = machine(19, _seek_1__tmp_at111_16709);
        DeRef(_pos_inlined_seek_at_108_16707);
        _pos_inlined_seek_at_108_16707 = NOVALUE;
        DeRef(_seek_1__tmp_at111_16709);
        _seek_1__tmp_at111_16709 = NOVALUE;

        /** eds.e:809						put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_16678) && IS_ATOM_INT(_n_16676)) {
            _9463 = _size_16678 - _n_16676;
            if ((object)((uintptr_t)_9463 +(uintptr_t) HIGH_BITS) >= 0){
                _9463 = NewDouble((eudouble)_9463);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16678)) {
                _9463 = NewDouble((eudouble)_size_16678 - DBL_PTR(_n_16676)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16676)) {
                    _9463 = NewDouble(DBL_PTR(_size_16678)->dbl - (eudouble)_n_16676);
                }
                else
                _9463 = NewDouble(DBL_PTR(_size_16678)->dbl - DBL_PTR(_n_16676)->dbl);
            }
        }
        if (IS_ATOM_INT(_9463)) {
            _9464 = _9463 - 4;
            if ((object)((uintptr_t)_9464 +(uintptr_t) HIGH_BITS) >= 0){
                _9464 = NewDouble((eudouble)_9464);
            }
        }
        else {
            _9464 = NewDouble(DBL_PTR(_9463)->dbl - (eudouble)4);
        }
        DeRef(_9463);
        _9463 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_16713);
        _x_inlined_put4_at_134_16713 = _9464;
        _9464 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16089)){
            poke4_addr = (uint32_t *)_41mem0_16089;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_16713)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_134_16713;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_134_16713)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_16714);
        _1 = (object)SEQ_PTR(_41memseq_16313);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at137_16714 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16047, _put4_1__tmp_at137_16714); // DJP 

        /** eds.e:444	end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_16713);
        _x_inlined_put4_at_134_16713 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_16714);
        _put4_1__tmp_at137_16714 = NOVALUE;

        /** eds.e:810						io:seek(current_db, size_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_16679);
        DeRef(_seek_1__tmp_at167_16717);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _size_ptr_16679;
        _seek_1__tmp_at167_16717 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_16716 = machine(19, _seek_1__tmp_at167_16717);
        DeRef(_seek_1__tmp_at167_16717);
        _seek_1__tmp_at167_16717 = NOVALUE;

        /** eds.e:811						put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_16678) && IS_ATOM_INT(_n_16676)) {
            _9465 = _size_16678 - _n_16676;
            if ((object)((uintptr_t)_9465 +(uintptr_t) HIGH_BITS) >= 0){
                _9465 = NewDouble((eudouble)_9465);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16678)) {
                _9465 = NewDouble((eudouble)_size_16678 - DBL_PTR(_n_16676)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16676)) {
                    _9465 = NewDouble(DBL_PTR(_size_16678)->dbl - (eudouble)_n_16676);
                }
                else
                _9465 = NewDouble(DBL_PTR(_size_16678)->dbl - DBL_PTR(_n_16676)->dbl);
            }
        }
        if (IS_ATOM_INT(_9465)) {
            _9466 = _9465 - 4;
            if ((object)((uintptr_t)_9466 +(uintptr_t) HIGH_BITS) >= 0){
                _9466 = NewDouble((eudouble)_9466);
            }
        }
        else {
            _9466 = NewDouble(DBL_PTR(_9465)->dbl - (eudouble)4);
        }
        DeRef(_9465);
        _9465 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_16721);
        _x_inlined_put4_at_190_16721 = _9466;
        _9466 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16089)){
            poke4_addr = (uint32_t *)_41mem0_16089;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_16721)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_190_16721;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_190_16721)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_16722);
        _1 = (object)SEQ_PTR(_41memseq_16313);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at193_16722 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16047, _put4_1__tmp_at193_16722); // DJP 

        /** eds.e:444	end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_16721);
        _x_inlined_put4_at_190_16721 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_16722);
        _put4_1__tmp_at193_16722 = NOVALUE;

        /** eds.e:812						addr += size-n-4*/
        if (IS_ATOM_INT(_size_16678) && IS_ATOM_INT(_n_16676)) {
            _9467 = _size_16678 - _n_16676;
            if ((object)((uintptr_t)_9467 +(uintptr_t) HIGH_BITS) >= 0){
                _9467 = NewDouble((eudouble)_9467);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16678)) {
                _9467 = NewDouble((eudouble)_size_16678 - DBL_PTR(_n_16676)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16676)) {
                    _9467 = NewDouble(DBL_PTR(_size_16678)->dbl - (eudouble)_n_16676);
                }
                else
                _9467 = NewDouble(DBL_PTR(_size_16678)->dbl - DBL_PTR(_n_16676)->dbl);
            }
        }
        if (IS_ATOM_INT(_9467)) {
            _9468 = _9467 - 4;
            if ((object)((uintptr_t)_9468 +(uintptr_t) HIGH_BITS) >= 0){
                _9468 = NewDouble((eudouble)_9468);
            }
        }
        else {
            _9468 = NewDouble(DBL_PTR(_9467)->dbl - (eudouble)4);
        }
        DeRef(_9467);
        _9467 = NOVALUE;
        _0 = _addr_16680;
        if (IS_ATOM_INT(_addr_16680) && IS_ATOM_INT(_9468)) {
            _addr_16680 = _addr_16680 + _9468;
            if ((object)((uintptr_t)_addr_16680 + (uintptr_t)HIGH_BITS) >= 0){
                _addr_16680 = NewDouble((eudouble)_addr_16680);
            }
        }
        else {
            if (IS_ATOM_INT(_addr_16680)) {
                _addr_16680 = NewDouble((eudouble)_addr_16680 + DBL_PTR(_9468)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9468)) {
                    _addr_16680 = NewDouble(DBL_PTR(_addr_16680)->dbl + (eudouble)_9468);
                }
                else
                _addr_16680 = NewDouble(DBL_PTR(_addr_16680)->dbl + DBL_PTR(_9468)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_9468);
        _9468 = NOVALUE;

        /** eds.e:813						io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_16680)) {
            _9470 = _addr_16680 - 4;
            if ((object)((uintptr_t)_9470 +(uintptr_t) HIGH_BITS) >= 0){
                _9470 = NewDouble((eudouble)_9470);
            }
        }
        else {
            _9470 = NewDouble(DBL_PTR(_addr_16680)->dbl - (eudouble)4);
        }
        DeRef(_pos_inlined_seek_at_241_16728);
        _pos_inlined_seek_at_241_16728 = _9470;
        _9470 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_16728);
        DeRef(_seek_1__tmp_at244_16730);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_241_16728;
        _seek_1__tmp_at244_16730 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_16729 = machine(19, _seek_1__tmp_at244_16730);
        DeRef(_pos_inlined_seek_at_241_16728);
        _pos_inlined_seek_at_241_16728 = NOVALUE;
        DeRef(_seek_1__tmp_at244_16730);
        _seek_1__tmp_at244_16730 = NOVALUE;

        /** eds.e:814						put4(n+4)*/
        if (IS_ATOM_INT(_n_16676)) {
            _9471 = _n_16676 + 4;
            if ((object)((uintptr_t)_9471 + (uintptr_t)HIGH_BITS) >= 0){
                _9471 = NewDouble((eudouble)_9471);
            }
        }
        else {
            _9471 = NewDouble(DBL_PTR(_n_16676)->dbl + (eudouble)4);
        }
        DeRef(_x_inlined_put4_at_263_16733);
        _x_inlined_put4_at_263_16733 = _9471;
        _9471 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16089)){
            poke4_addr = (uint32_t *)_41mem0_16089;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_16733)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_263_16733;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_263_16733)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_16734);
        _1 = (object)SEQ_PTR(_41memseq_16313);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at266_16734 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16047, _put4_1__tmp_at266_16734); // DJP 

        /** eds.e:444	end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_16733);
        _x_inlined_put4_at_263_16733 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_16734);
        _put4_1__tmp_at266_16734 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** eds.e:817						remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _9472 = _free_count_16681 - _i_16695;
        if ((object)((uintptr_t)_9472 +(uintptr_t) HIGH_BITS) >= 0){
            _9472 = NewDouble((eudouble)_9472);
        }
        if (IS_ATOM_INT(_9472)) {
            if (_9472 == (short)_9472){
                _9473 = _9472 * 8;
            }
            else{
                _9473 = NewDouble(_9472 * (eudouble)8);
            }
        }
        else {
            _9473 = NewDouble(DBL_PTR(_9472)->dbl * (eudouble)8);
        }
        DeRef(_9472);
        _9472 = NOVALUE;
        _0 = _remaining_16682;
        _remaining_16682 = _18get_bytes(_41current_db_16047, _9473);
        DeRef(_0);
        _9473 = NOVALUE;

        /** eds.e:818						io:seek(current_db, free_list+8*(i-1))*/
        _9475 = _i_16695 - 1;
        if (_9475 <= INT15){
            _9476 = 8 * _9475;
        }
        else{
            _9476 = NewDouble(8 * (eudouble)_9475);
        }
        _9475 = NOVALUE;
        if (IS_ATOM_INT(_free_list_16677) && IS_ATOM_INT(_9476)) {
            _9477 = _free_list_16677 + _9476;
            if ((object)((uintptr_t)_9477 + (uintptr_t)HIGH_BITS) >= 0){
                _9477 = NewDouble((eudouble)_9477);
            }
        }
        else {
            if (IS_ATOM_INT(_free_list_16677)) {
                _9477 = NewDouble((eudouble)_free_list_16677 + DBL_PTR(_9476)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9476)) {
                    _9477 = NewDouble(DBL_PTR(_free_list_16677)->dbl + (eudouble)_9476);
                }
                else
                _9477 = NewDouble(DBL_PTR(_free_list_16677)->dbl + DBL_PTR(_9476)->dbl);
            }
        }
        DeRef(_9476);
        _9476 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_16743);
        _pos_inlined_seek_at_330_16743 = _9477;
        _9477 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_16743);
        DeRef(_seek_1__tmp_at333_16745);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_330_16743;
        _seek_1__tmp_at333_16745 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_16744 = machine(19, _seek_1__tmp_at333_16745);
        DeRef(_pos_inlined_seek_at_330_16743);
        _pos_inlined_seek_at_330_16743 = NOVALUE;
        DeRef(_seek_1__tmp_at333_16745);
        _seek_1__tmp_at333_16745 = NOVALUE;

        /** eds.e:819						putn(remaining)*/

        /** eds.e:448		puts(current_db, s)*/
        EPuts(_41current_db_16047, _remaining_16682); // DJP 

        /** eds.e:449	end procedure*/
        goto LA; // [358] 361
LA: 

        /** eds.e:820						io:seek(current_db, FREE_COUNT)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_16749);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = 7;
        _seek_1__tmp_at364_16749 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_16748 = machine(19, _seek_1__tmp_at364_16749);
        DeRefi(_seek_1__tmp_at364_16749);
        _seek_1__tmp_at364_16749 = NOVALUE;

        /** eds.e:821						put4(free_count-1)*/
        _9478 = _free_count_16681 - 1;
        if ((object)((uintptr_t)_9478 +(uintptr_t) HIGH_BITS) >= 0){
            _9478 = NewDouble((eudouble)_9478);
        }
        DeRef(_x_inlined_put4_at_383_16752);
        _x_inlined_put4_at_383_16752 = _9478;
        _9478 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16089)){
            poke4_addr = (uint32_t *)_41mem0_16089;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_16752)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_383_16752;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_383_16752)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_16753);
        _1 = (object)SEQ_PTR(_41memseq_16313);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at386_16753 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16047, _put4_1__tmp_at386_16753); // DJP 

        /** eds.e:444	end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_16752);
        _x_inlined_put4_at_383_16752 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_16753);
        _put4_1__tmp_at386_16753 = NOVALUE;

        /** eds.e:822						io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_16680)) {
            _9479 = _addr_16680 - 4;
            if ((object)((uintptr_t)_9479 +(uintptr_t) HIGH_BITS) >= 0){
                _9479 = NewDouble((eudouble)_9479);
            }
        }
        else {
            _9479 = NewDouble(DBL_PTR(_addr_16680)->dbl - (eudouble)4);
        }
        DeRef(_pos_inlined_seek_at_420_16756);
        _pos_inlined_seek_at_420_16756 = _9479;
        _9479 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_16756);
        DeRef(_seek_1__tmp_at423_16758);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_420_16756;
        _seek_1__tmp_at423_16758 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_16757 = machine(19, _seek_1__tmp_at423_16758);
        DeRef(_pos_inlined_seek_at_420_16756);
        _pos_inlined_seek_at_420_16756 = NOVALUE;
        DeRef(_seek_1__tmp_at423_16758);
        _seek_1__tmp_at423_16758 = NOVALUE;

        /** eds.e:823						put4(size) -- in case size was not updated by db_free()*/

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16089)){
            poke4_addr = (uint32_t *)_41mem0_16089;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        }
        if (IS_ATOM_INT(_size_16678)) {
            *poke4_addr = (uint32_t)_size_16678;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_size_16678)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_16760);
        _1 = (object)SEQ_PTR(_41memseq_16313);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at438_16760 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16047, _put4_1__tmp_at438_16760); // DJP 

        /** eds.e:444	end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_16760);
        _put4_1__tmp_at438_16760 = NOVALUE;
L9: 

        /** eds.e:825					return addr*/
        DeRef(_n_16676);
        DeRef(_free_list_16677);
        DeRef(_size_16678);
        DeRef(_size_ptr_16679);
        DeRef(_remaining_16682);
        return _addr_16680;
L4: 

        /** eds.e:827				size_ptr += 8*/
        _0 = _size_ptr_16679;
        if (IS_ATOM_INT(_size_ptr_16679)) {
            _size_ptr_16679 = _size_ptr_16679 + 8;
            if ((object)((uintptr_t)_size_ptr_16679 + (uintptr_t)HIGH_BITS) >= 0){
                _size_ptr_16679 = NewDouble((eudouble)_size_ptr_16679);
            }
        }
        else {
            _size_ptr_16679 = NewDouble(DBL_PTR(_size_ptr_16679)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** eds.e:828			end for*/
        _i_16695 = _i_16695 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** eds.e:831		io:seek(current_db, -1)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_16764);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = -1;
    _seek_1__tmp_at490_16764 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_16763 = machine(19, _seek_1__tmp_at490_16764);
    DeRefi(_seek_1__tmp_at490_16764);
    _seek_1__tmp_at490_16764 = NOVALUE;

    /** eds.e:832		put4(n+4)*/
    if (IS_ATOM_INT(_n_16676)) {
        _9481 = _n_16676 + 4;
        if ((object)((uintptr_t)_9481 + (uintptr_t)HIGH_BITS) >= 0){
            _9481 = NewDouble((eudouble)_9481);
        }
    }
    else {
        _9481 = NewDouble(DBL_PTR(_n_16676)->dbl + (eudouble)4);
    }
    DeRef(_x_inlined_put4_at_509_16767);
    _x_inlined_put4_at_509_16767 = _9481;
    _9481 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_16767)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_509_16767;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_509_16767)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_16768);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at512_16768 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at512_16768); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_16767);
    _x_inlined_put4_at_509_16767 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_16768);
    _put4_1__tmp_at512_16768 = NOVALUE;

    /** eds.e:833		return io:where(current_db)*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_16770);
    _where_inlined_where_at_542_16770 = machine(20, _41current_db_16047);
    DeRef(_n_16676);
    DeRef(_free_list_16677);
    DeRef(_size_16678);
    DeRef(_size_ptr_16679);
    DeRef(_addr_16680);
    DeRef(_remaining_16682);
    return _where_inlined_where_at_542_16770;
    ;
}


void _41db_free(object _p_16773)
{
    object _psize_16774 = NOVALUE;
    object _i_16775 = NOVALUE;
    object _size_16776 = NOVALUE;
    object _addr_16777 = NOVALUE;
    object _free_list_16778 = NOVALUE;
    object _free_list_space_16779 = NOVALUE;
    object _new_space_16780 = NOVALUE;
    object _to_be_freed_16781 = NOVALUE;
    object _prev_addr_16782 = NOVALUE;
    object _prev_size_16783 = NOVALUE;
    object _free_count_16784 = NOVALUE;
    object _remaining_16785 = NOVALUE;
    object _seek_1__tmp_at11_16790 = NOVALUE;
    object _seek_inlined_seek_at_11_16789 = NOVALUE;
    object _pos_inlined_seek_at_8_16788 = NOVALUE;
    object _seek_1__tmp_at33_16794 = NOVALUE;
    object _seek_inlined_seek_at_33_16793 = NOVALUE;
    object _seek_1__tmp_at69_16801 = NOVALUE;
    object _seek_inlined_seek_at_69_16800 = NOVALUE;
    object _pos_inlined_seek_at_66_16799 = NOVALUE;
    object _seek_1__tmp_at133_16814 = NOVALUE;
    object _seek_inlined_seek_at_133_16813 = NOVALUE;
    object _seek_1__tmp_at157_16818 = NOVALUE;
    object _seek_inlined_seek_at_157_16817 = NOVALUE;
    object _put4_1__tmp_at172_16820 = NOVALUE;
    object _seek_1__tmp_at202_16823 = NOVALUE;
    object _seek_inlined_seek_at_202_16822 = NOVALUE;
    object _seek_1__tmp_at234_16828 = NOVALUE;
    object _seek_inlined_seek_at_234_16827 = NOVALUE;
    object _s_inlined_putn_at_274_16834 = NOVALUE;
    object _seek_1__tmp_at297_16837 = NOVALUE;
    object _seek_inlined_seek_at_297_16836 = NOVALUE;
    object _seek_1__tmp_at430_16858 = NOVALUE;
    object _seek_inlined_seek_at_430_16857 = NOVALUE;
    object _pos_inlined_seek_at_427_16856 = NOVALUE;
    object _put4_1__tmp_at482_16868 = NOVALUE;
    object _x_inlined_put4_at_479_16867 = NOVALUE;
    object _seek_1__tmp_at523_16874 = NOVALUE;
    object _seek_inlined_seek_at_523_16873 = NOVALUE;
    object _pos_inlined_seek_at_520_16872 = NOVALUE;
    object _seek_1__tmp_at574_16884 = NOVALUE;
    object _seek_inlined_seek_at_574_16883 = NOVALUE;
    object _pos_inlined_seek_at_571_16882 = NOVALUE;
    object _seek_1__tmp_at611_16889 = NOVALUE;
    object _seek_inlined_seek_at_611_16888 = NOVALUE;
    object _put4_1__tmp_at626_16891 = NOVALUE;
    object _put4_1__tmp_at664_16896 = NOVALUE;
    object _x_inlined_put4_at_661_16895 = NOVALUE;
    object _seek_1__tmp_at737_16908 = NOVALUE;
    object _seek_inlined_seek_at_737_16907 = NOVALUE;
    object _pos_inlined_seek_at_734_16906 = NOVALUE;
    object _put4_1__tmp_at752_16910 = NOVALUE;
    object _put4_1__tmp_at789_16914 = NOVALUE;
    object _x_inlined_put4_at_786_16913 = NOVALUE;
    object _seek_1__tmp_at837_16922 = NOVALUE;
    object _seek_inlined_seek_at_837_16921 = NOVALUE;
    object _pos_inlined_seek_at_834_16920 = NOVALUE;
    object _seek_1__tmp_at883_16930 = NOVALUE;
    object _seek_inlined_seek_at_883_16929 = NOVALUE;
    object _put4_1__tmp_at898_16932 = NOVALUE;
    object _seek_1__tmp_at943_16939 = NOVALUE;
    object _seek_inlined_seek_at_943_16938 = NOVALUE;
    object _pos_inlined_seek_at_940_16937 = NOVALUE;
    object _put4_1__tmp_at958_16941 = NOVALUE;
    object _put4_1__tmp_at986_16943 = NOVALUE;
    object _9549 = NOVALUE;
    object _9548 = NOVALUE;
    object _9547 = NOVALUE;
    object _9544 = NOVALUE;
    object _9543 = NOVALUE;
    object _9542 = NOVALUE;
    object _9541 = NOVALUE;
    object _9540 = NOVALUE;
    object _9539 = NOVALUE;
    object _9538 = NOVALUE;
    object _9537 = NOVALUE;
    object _9536 = NOVALUE;
    object _9535 = NOVALUE;
    object _9534 = NOVALUE;
    object _9533 = NOVALUE;
    object _9532 = NOVALUE;
    object _9531 = NOVALUE;
    object _9530 = NOVALUE;
    object _9528 = NOVALUE;
    object _9527 = NOVALUE;
    object _9526 = NOVALUE;
    object _9524 = NOVALUE;
    object _9523 = NOVALUE;
    object _9522 = NOVALUE;
    object _9521 = NOVALUE;
    object _9520 = NOVALUE;
    object _9519 = NOVALUE;
    object _9518 = NOVALUE;
    object _9517 = NOVALUE;
    object _9516 = NOVALUE;
    object _9515 = NOVALUE;
    object _9514 = NOVALUE;
    object _9513 = NOVALUE;
    object _9512 = NOVALUE;
    object _9511 = NOVALUE;
    object _9510 = NOVALUE;
    object _9509 = NOVALUE;
    object _9508 = NOVALUE;
    object _9507 = NOVALUE;
    object _9501 = NOVALUE;
    object _9500 = NOVALUE;
    object _9499 = NOVALUE;
    object _9497 = NOVALUE;
    object _9493 = NOVALUE;
    object _9492 = NOVALUE;
    object _9490 = NOVALUE;
    object _9489 = NOVALUE;
    object _9487 = NOVALUE;
    object _9486 = NOVALUE;
    object _9482 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:844		io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_16773)) {
        _9482 = _p_16773 - 4;
        if ((object)((uintptr_t)_9482 +(uintptr_t) HIGH_BITS) >= 0){
            _9482 = NewDouble((eudouble)_9482);
        }
    }
    else {
        _9482 = NewDouble(DBL_PTR(_p_16773)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_8_16788);
    _pos_inlined_seek_at_8_16788 = _9482;
    _9482 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_16788);
    DeRef(_seek_1__tmp_at11_16790);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_16788;
    _seek_1__tmp_at11_16790 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_16789 = machine(19, _seek_1__tmp_at11_16790);
    DeRef(_pos_inlined_seek_at_8_16788);
    _pos_inlined_seek_at_8_16788 = NOVALUE;
    DeRef(_seek_1__tmp_at11_16790);
    _seek_1__tmp_at11_16790 = NOVALUE;

    /** eds.e:845		psize = get4()*/
    _0 = _psize_16774;
    _psize_16774 = _41get4();
    DeRef(_0);

    /** eds.e:847		io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_16794);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at33_16794 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_16793 = machine(19, _seek_1__tmp_at33_16794);
    DeRefi(_seek_1__tmp_at33_16794);
    _seek_1__tmp_at33_16794 = NOVALUE;

    /** eds.e:848		free_count = get4()*/
    _free_count_16784 = _41get4();
    if (!IS_ATOM_INT(_free_count_16784)) {
        _1 = (object)(DBL_PTR(_free_count_16784)->dbl);
        DeRefDS(_free_count_16784);
        _free_count_16784 = _1;
    }

    /** eds.e:849		free_list = get4()*/
    _0 = _free_list_16778;
    _free_list_16778 = _41get4();
    DeRef(_0);

    /** eds.e:850		io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_16778)) {
        _9486 = _free_list_16778 - 4;
        if ((object)((uintptr_t)_9486 +(uintptr_t) HIGH_BITS) >= 0){
            _9486 = NewDouble((eudouble)_9486);
        }
    }
    else {
        _9486 = NewDouble(DBL_PTR(_free_list_16778)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_66_16799);
    _pos_inlined_seek_at_66_16799 = _9486;
    _9486 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_16799);
    DeRef(_seek_1__tmp_at69_16801);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_66_16799;
    _seek_1__tmp_at69_16801 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_16800 = machine(19, _seek_1__tmp_at69_16801);
    DeRef(_pos_inlined_seek_at_66_16799);
    _pos_inlined_seek_at_66_16799 = NOVALUE;
    DeRef(_seek_1__tmp_at69_16801);
    _seek_1__tmp_at69_16801 = NOVALUE;

    /** eds.e:851		free_list_space = get4()-4*/
    _9487 = _41get4();
    DeRef(_free_list_space_16779);
    if (IS_ATOM_INT(_9487)) {
        _free_list_space_16779 = _9487 - 4;
        if ((object)((uintptr_t)_free_list_space_16779 +(uintptr_t) HIGH_BITS) >= 0){
            _free_list_space_16779 = NewDouble((eudouble)_free_list_space_16779);
        }
    }
    else {
        _free_list_space_16779 = binary_op(MINUS, _9487, 4);
    }
    DeRef(_9487);
    _9487 = NOVALUE;

    /** eds.e:852		if free_list_space < 8 * (free_count+1) then*/
    _9489 = _free_count_16784 + 1;
    if (_9489 > MAXINT){
        _9489 = NewDouble((eudouble)_9489);
    }
    if (IS_ATOM_INT(_9489)) {
        if (_9489 <= INT15 && _9489 >= -INT15){
            _9490 = 8 * _9489;
        }
        else{
            _9490 = NewDouble(8 * (eudouble)_9489);
        }
    }
    else {
        _9490 = NewDouble((eudouble)8 * DBL_PTR(_9489)->dbl);
    }
    DeRef(_9489);
    _9489 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_16779, _9490)){
        DeRef(_9490);
        _9490 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_9490);
    _9490 = NOVALUE;

    /** eds.e:854			new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_16779)) {
        if (_free_list_space_16779 & 1) {
            _9492 = NewDouble((_free_list_space_16779 >> 1) + 0.5);
        }
        else
        _9492 = _free_list_space_16779 >> 1;
    }
    else {
        _9492 = binary_op(DIVIDE, _free_list_space_16779, 2);
    }
    if (IS_ATOM_INT(_free_list_space_16779) && IS_ATOM_INT(_9492)) {
        _9493 = _free_list_space_16779 + _9492;
        if ((object)((uintptr_t)_9493 + (uintptr_t)HIGH_BITS) >= 0){
            _9493 = NewDouble((eudouble)_9493);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_space_16779)) {
            _9493 = NewDouble((eudouble)_free_list_space_16779 + DBL_PTR(_9492)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9492)) {
                _9493 = NewDouble(DBL_PTR(_free_list_space_16779)->dbl + (eudouble)_9492);
            }
            else
            _9493 = NewDouble(DBL_PTR(_free_list_space_16779)->dbl + DBL_PTR(_9492)->dbl);
        }
    }
    DeRef(_9492);
    _9492 = NOVALUE;
    DeRef(_new_space_16780);
    if (IS_ATOM_INT(_9493))
    _new_space_16780 = e_floor(_9493);
    else
    _new_space_16780 = unary_op(FLOOR, _9493);
    DeRef(_9493);
    _9493 = NOVALUE;

    /** eds.e:855			to_be_freed = free_list*/
    Ref(_free_list_16778);
    DeRef(_to_be_freed_16781);
    _to_be_freed_16781 = _free_list_16778;

    /** eds.e:856			free_list = db_allocate(new_space)*/
    Ref(_new_space_16780);
    _0 = _free_list_16778;
    _free_list_16778 = _41db_allocate(_new_space_16780);
    DeRef(_0);

    /** eds.e:857			io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_16814);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at133_16814 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_16813 = machine(19, _seek_1__tmp_at133_16814);
    DeRefi(_seek_1__tmp_at133_16814);
    _seek_1__tmp_at133_16814 = NOVALUE;

    /** eds.e:858			free_count = get4() -- db_allocate may have changed it*/
    _free_count_16784 = _41get4();
    if (!IS_ATOM_INT(_free_count_16784)) {
        _1 = (object)(DBL_PTR(_free_count_16784)->dbl);
        DeRefDS(_free_count_16784);
        _free_count_16784 = _1;
    }

    /** eds.e:859			io:seek(current_db, FREE_LIST)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_16818);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 11;
    _seek_1__tmp_at157_16818 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_16817 = machine(19, _seek_1__tmp_at157_16818);
    DeRefi(_seek_1__tmp_at157_16818);
    _seek_1__tmp_at157_16818 = NOVALUE;

    /** eds.e:860			put4(free_list)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_free_list_16778)) {
        *poke4_addr = (uint32_t)_free_list_16778;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_free_list_16778)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_16820);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at172_16820 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at172_16820); // DJP 

    /** eds.e:444	end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_16820);
    _put4_1__tmp_at172_16820 = NOVALUE;

    /** eds.e:861			io:seek(current_db, to_be_freed)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_16781);
    DeRef(_seek_1__tmp_at202_16823);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _to_be_freed_16781;
    _seek_1__tmp_at202_16823 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_16822 = machine(19, _seek_1__tmp_at202_16823);
    DeRef(_seek_1__tmp_at202_16823);
    _seek_1__tmp_at202_16823 = NOVALUE;

    /** eds.e:862			remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_16784 <= INT15 && _free_count_16784 >= -INT15){
        _9497 = 8 * _free_count_16784;
    }
    else{
        _9497 = NewDouble(8 * (eudouble)_free_count_16784);
    }
    _0 = _remaining_16785;
    _remaining_16785 = _18get_bytes(_41current_db_16047, _9497);
    DeRef(_0);
    _9497 = NOVALUE;

    /** eds.e:863			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16778);
    DeRef(_seek_1__tmp_at234_16828);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _free_list_16778;
    _seek_1__tmp_at234_16828 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_16827 = machine(19, _seek_1__tmp_at234_16828);
    DeRef(_seek_1__tmp_at234_16828);
    _seek_1__tmp_at234_16828 = NOVALUE;

    /** eds.e:864			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _remaining_16785); // DJP 

    /** eds.e:449	end procedure*/
    goto L3; // [259] 262
L3: 

    /** eds.e:865			putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_16785)){
            _9499 = SEQ_PTR(_remaining_16785)->length;
    }
    else {
        _9499 = 1;
    }
    if (IS_ATOM_INT(_new_space_16780)) {
        _9500 = _new_space_16780 - _9499;
    }
    else {
        _9500 = NewDouble(DBL_PTR(_new_space_16780)->dbl - (eudouble)_9499);
    }
    _9499 = NOVALUE;
    _9501 = Repeat(0, _9500);
    DeRef(_9500);
    _9500 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_16834);
    _s_inlined_putn_at_274_16834 = _9501;
    _9501 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_274_16834); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_16834);
    _s_inlined_putn_at_274_16834 = NOVALUE;

    /** eds.e:866			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16778);
    DeRef(_seek_1__tmp_at297_16837);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _free_list_16778;
    _seek_1__tmp_at297_16837 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_16836 = machine(19, _seek_1__tmp_at297_16837);
    DeRef(_seek_1__tmp_at297_16837);
    _seek_1__tmp_at297_16837 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** eds.e:868			new_space = 0*/
    DeRef(_new_space_16780);
    _new_space_16780 = 0;
L5: 

    /** eds.e:871		i = 1*/
    DeRef(_i_16775);
    _i_16775 = 1;

    /** eds.e:872		prev_addr = 0*/
    DeRef(_prev_addr_16782);
    _prev_addr_16782 = 0;

    /** eds.e:873		prev_size = 0*/
    DeRef(_prev_size_16783);
    _prev_size_16783 = 0;

    /** eds.e:874		while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_16775, _free_count_16784)){
        goto L7; // [340] 386
    }

    /** eds.e:875			addr = get4()*/
    _0 = _addr_16777;
    _addr_16777 = _41get4();
    DeRef(_0);

    /** eds.e:876			size = get4()*/
    _0 = _size_16776;
    _size_16776 = _41get4();
    DeRef(_0);

    /** eds.e:877			if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_16773, _addr_16777)){
        goto L8; // [356] 365
    }

    /** eds.e:878				exit*/
    goto L7; // [362] 386
L8: 

    /** eds.e:880			prev_addr = addr*/
    Ref(_addr_16777);
    DeRef(_prev_addr_16782);
    _prev_addr_16782 = _addr_16777;

    /** eds.e:881			prev_size = size*/
    Ref(_size_16776);
    DeRef(_prev_size_16783);
    _prev_size_16783 = _size_16776;

    /** eds.e:882			i += 1*/
    _0 = _i_16775;
    if (IS_ATOM_INT(_i_16775)) {
        _i_16775 = _i_16775 + 1;
        if (_i_16775 > MAXINT){
            _i_16775 = NewDouble((eudouble)_i_16775);
        }
    }
    else
    _i_16775 = binary_op(PLUS, 1, _i_16775);
    DeRef(_0);

    /** eds.e:883		end while*/
    goto L6; // [383] 340
L7: 

    /** eds.e:885		if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_16775)) {
        _9507 = (_i_16775 > 1);
    }
    else {
        _9507 = (DBL_PTR(_i_16775)->dbl > (eudouble)1);
    }
    if (_9507 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_16782) && IS_ATOM_INT(_prev_size_16783)) {
        _9509 = _prev_addr_16782 + _prev_size_16783;
        if ((object)((uintptr_t)_9509 + (uintptr_t)HIGH_BITS) >= 0){
            _9509 = NewDouble((eudouble)_9509);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_addr_16782)) {
            _9509 = NewDouble((eudouble)_prev_addr_16782 + DBL_PTR(_prev_size_16783)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_16783)) {
                _9509 = NewDouble(DBL_PTR(_prev_addr_16782)->dbl + (eudouble)_prev_size_16783);
            }
            else
            _9509 = NewDouble(DBL_PTR(_prev_addr_16782)->dbl + DBL_PTR(_prev_size_16783)->dbl);
        }
    }
    if (IS_ATOM_INT(_9509) && IS_ATOM_INT(_p_16773)) {
        _9510 = (_9509 == _p_16773);
    }
    else {
        if (IS_ATOM_INT(_9509)) {
            _9510 = ((eudouble)_9509 == DBL_PTR(_p_16773)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_16773)) {
                _9510 = (DBL_PTR(_9509)->dbl == (eudouble)_p_16773);
            }
            else
            _9510 = (DBL_PTR(_9509)->dbl == DBL_PTR(_p_16773)->dbl);
        }
    }
    DeRef(_9509);
    _9509 = NOVALUE;
    if (_9510 == 0)
    {
        DeRef(_9510);
        _9510 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_9510);
        _9510 = NOVALUE;
    }

    /** eds.e:887			io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9511 = _i_16775 - 2;
        if ((object)((uintptr_t)_9511 +(uintptr_t) HIGH_BITS) >= 0){
            _9511 = NewDouble((eudouble)_9511);
        }
    }
    else {
        _9511 = NewDouble(DBL_PTR(_i_16775)->dbl - (eudouble)2);
    }
    if (IS_ATOM_INT(_9511)) {
        if (_9511 == (short)_9511){
            _9512 = _9511 * 8;
        }
        else{
            _9512 = NewDouble(_9511 * (eudouble)8);
        }
    }
    else {
        _9512 = NewDouble(DBL_PTR(_9511)->dbl * (eudouble)8);
    }
    DeRef(_9511);
    _9511 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16778) && IS_ATOM_INT(_9512)) {
        _9513 = _free_list_16778 + _9512;
        if ((object)((uintptr_t)_9513 + (uintptr_t)HIGH_BITS) >= 0){
            _9513 = NewDouble((eudouble)_9513);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16778)) {
            _9513 = NewDouble((eudouble)_free_list_16778 + DBL_PTR(_9512)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9512)) {
                _9513 = NewDouble(DBL_PTR(_free_list_16778)->dbl + (eudouble)_9512);
            }
            else
            _9513 = NewDouble(DBL_PTR(_free_list_16778)->dbl + DBL_PTR(_9512)->dbl);
        }
    }
    DeRef(_9512);
    _9512 = NOVALUE;
    if (IS_ATOM_INT(_9513)) {
        _9514 = _9513 + 4;
        if ((object)((uintptr_t)_9514 + (uintptr_t)HIGH_BITS) >= 0){
            _9514 = NewDouble((eudouble)_9514);
        }
    }
    else {
        _9514 = NewDouble(DBL_PTR(_9513)->dbl + (eudouble)4);
    }
    DeRef(_9513);
    _9513 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_16856);
    _pos_inlined_seek_at_427_16856 = _9514;
    _9514 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_16856);
    DeRef(_seek_1__tmp_at430_16858);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_427_16856;
    _seek_1__tmp_at430_16858 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_16857 = machine(19, _seek_1__tmp_at430_16858);
    DeRef(_pos_inlined_seek_at_427_16856);
    _pos_inlined_seek_at_427_16856 = NOVALUE;
    DeRef(_seek_1__tmp_at430_16858);
    _seek_1__tmp_at430_16858 = NOVALUE;

    /** eds.e:888			if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_16775)) {
        _9515 = (_i_16775 < _free_count_16784);
    }
    else {
        _9515 = (DBL_PTR(_i_16775)->dbl < (eudouble)_free_count_16784);
    }
    if (_9515 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_16773) && IS_ATOM_INT(_psize_16774)) {
        _9517 = _p_16773 + _psize_16774;
        if ((object)((uintptr_t)_9517 + (uintptr_t)HIGH_BITS) >= 0){
            _9517 = NewDouble((eudouble)_9517);
        }
    }
    else {
        if (IS_ATOM_INT(_p_16773)) {
            _9517 = NewDouble((eudouble)_p_16773 + DBL_PTR(_psize_16774)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16774)) {
                _9517 = NewDouble(DBL_PTR(_p_16773)->dbl + (eudouble)_psize_16774);
            }
            else
            _9517 = NewDouble(DBL_PTR(_p_16773)->dbl + DBL_PTR(_psize_16774)->dbl);
        }
    }
    if (IS_ATOM_INT(_9517) && IS_ATOM_INT(_addr_16777)) {
        _9518 = (_9517 == _addr_16777);
    }
    else {
        if (IS_ATOM_INT(_9517)) {
            _9518 = ((eudouble)_9517 == DBL_PTR(_addr_16777)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_16777)) {
                _9518 = (DBL_PTR(_9517)->dbl == (eudouble)_addr_16777);
            }
            else
            _9518 = (DBL_PTR(_9517)->dbl == DBL_PTR(_addr_16777)->dbl);
        }
    }
    DeRef(_9517);
    _9517 = NOVALUE;
    if (_9518 == 0)
    {
        DeRef(_9518);
        _9518 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_9518);
        _9518 = NOVALUE;
    }

    /** eds.e:890				put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_16783) && IS_ATOM_INT(_psize_16774)) {
        _9519 = _prev_size_16783 + _psize_16774;
        if ((object)((uintptr_t)_9519 + (uintptr_t)HIGH_BITS) >= 0){
            _9519 = NewDouble((eudouble)_9519);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_size_16783)) {
            _9519 = NewDouble((eudouble)_prev_size_16783 + DBL_PTR(_psize_16774)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16774)) {
                _9519 = NewDouble(DBL_PTR(_prev_size_16783)->dbl + (eudouble)_psize_16774);
            }
            else
            _9519 = NewDouble(DBL_PTR(_prev_size_16783)->dbl + DBL_PTR(_psize_16774)->dbl);
        }
    }
    if (IS_ATOM_INT(_9519) && IS_ATOM_INT(_size_16776)) {
        _9520 = _9519 + _size_16776;
        if ((object)((uintptr_t)_9520 + (uintptr_t)HIGH_BITS) >= 0){
            _9520 = NewDouble((eudouble)_9520);
        }
    }
    else {
        if (IS_ATOM_INT(_9519)) {
            _9520 = NewDouble((eudouble)_9519 + DBL_PTR(_size_16776)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_16776)) {
                _9520 = NewDouble(DBL_PTR(_9519)->dbl + (eudouble)_size_16776);
            }
            else
            _9520 = NewDouble(DBL_PTR(_9519)->dbl + DBL_PTR(_size_16776)->dbl);
        }
    }
    DeRef(_9519);
    _9519 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_16867);
    _x_inlined_put4_at_479_16867 = _9520;
    _9520 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_16867)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_479_16867;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_479_16867)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_16868);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at482_16868 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at482_16868); // DJP 

    /** eds.e:444	end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_16867);
    _x_inlined_put4_at_479_16867 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_16868);
    _put4_1__tmp_at482_16868 = NOVALUE;

    /** eds.e:891				io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        if (_i_16775 == (short)_i_16775){
            _9521 = _i_16775 * 8;
        }
        else{
            _9521 = NewDouble(_i_16775 * (eudouble)8);
        }
    }
    else {
        _9521 = NewDouble(DBL_PTR(_i_16775)->dbl * (eudouble)8);
    }
    if (IS_ATOM_INT(_free_list_16778) && IS_ATOM_INT(_9521)) {
        _9522 = _free_list_16778 + _9521;
        if ((object)((uintptr_t)_9522 + (uintptr_t)HIGH_BITS) >= 0){
            _9522 = NewDouble((eudouble)_9522);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16778)) {
            _9522 = NewDouble((eudouble)_free_list_16778 + DBL_PTR(_9521)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9521)) {
                _9522 = NewDouble(DBL_PTR(_free_list_16778)->dbl + (eudouble)_9521);
            }
            else
            _9522 = NewDouble(DBL_PTR(_free_list_16778)->dbl + DBL_PTR(_9521)->dbl);
        }
    }
    DeRef(_9521);
    _9521 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_16872);
    _pos_inlined_seek_at_520_16872 = _9522;
    _9522 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_16872);
    DeRef(_seek_1__tmp_at523_16874);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_520_16872;
    _seek_1__tmp_at523_16874 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_16873 = machine(19, _seek_1__tmp_at523_16874);
    DeRef(_pos_inlined_seek_at_520_16872);
    _pos_inlined_seek_at_520_16872 = NOVALUE;
    DeRef(_seek_1__tmp_at523_16874);
    _seek_1__tmp_at523_16874 = NOVALUE;

    /** eds.e:892				remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9523 = _free_count_16784 - _i_16775;
        if ((object)((uintptr_t)_9523 +(uintptr_t) HIGH_BITS) >= 0){
            _9523 = NewDouble((eudouble)_9523);
        }
    }
    else {
        _9523 = NewDouble((eudouble)_free_count_16784 - DBL_PTR(_i_16775)->dbl);
    }
    if (IS_ATOM_INT(_9523)) {
        if (_9523 == (short)_9523){
            _9524 = _9523 * 8;
        }
        else{
            _9524 = NewDouble(_9523 * (eudouble)8);
        }
    }
    else {
        _9524 = NewDouble(DBL_PTR(_9523)->dbl * (eudouble)8);
    }
    DeRef(_9523);
    _9523 = NOVALUE;
    _0 = _remaining_16785;
    _remaining_16785 = _18get_bytes(_41current_db_16047, _9524);
    DeRef(_0);
    _9524 = NOVALUE;

    /** eds.e:893				io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9526 = _i_16775 - 1;
        if ((object)((uintptr_t)_9526 +(uintptr_t) HIGH_BITS) >= 0){
            _9526 = NewDouble((eudouble)_9526);
        }
    }
    else {
        _9526 = NewDouble(DBL_PTR(_i_16775)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9526)) {
        if (_9526 == (short)_9526){
            _9527 = _9526 * 8;
        }
        else{
            _9527 = NewDouble(_9526 * (eudouble)8);
        }
    }
    else {
        _9527 = NewDouble(DBL_PTR(_9526)->dbl * (eudouble)8);
    }
    DeRef(_9526);
    _9526 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16778) && IS_ATOM_INT(_9527)) {
        _9528 = _free_list_16778 + _9527;
        if ((object)((uintptr_t)_9528 + (uintptr_t)HIGH_BITS) >= 0){
            _9528 = NewDouble((eudouble)_9528);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16778)) {
            _9528 = NewDouble((eudouble)_free_list_16778 + DBL_PTR(_9527)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9527)) {
                _9528 = NewDouble(DBL_PTR(_free_list_16778)->dbl + (eudouble)_9527);
            }
            else
            _9528 = NewDouble(DBL_PTR(_free_list_16778)->dbl + DBL_PTR(_9527)->dbl);
        }
    }
    DeRef(_9527);
    _9527 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_16882);
    _pos_inlined_seek_at_571_16882 = _9528;
    _9528 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_16882);
    DeRef(_seek_1__tmp_at574_16884);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_571_16882;
    _seek_1__tmp_at574_16884 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_16883 = machine(19, _seek_1__tmp_at574_16884);
    DeRef(_pos_inlined_seek_at_571_16882);
    _pos_inlined_seek_at_571_16882 = NOVALUE;
    DeRef(_seek_1__tmp_at574_16884);
    _seek_1__tmp_at574_16884 = NOVALUE;

    /** eds.e:894				putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _remaining_16785); // DJP 

    /** eds.e:449	end procedure*/
    goto LC; // [599] 602
LC: 

    /** eds.e:895				free_count -= 1*/
    _free_count_16784 = _free_count_16784 - 1;

    /** eds.e:896				io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_16889);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at611_16889 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_16888 = machine(19, _seek_1__tmp_at611_16889);
    DeRefi(_seek_1__tmp_at611_16889);
    _seek_1__tmp_at611_16889 = NOVALUE;

    /** eds.e:897				put4(free_count)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)_free_count_16784;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_16891);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at626_16891 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at626_16891); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_16891);
    _put4_1__tmp_at626_16891 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** eds.e:899				put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_16783) && IS_ATOM_INT(_psize_16774)) {
        _9530 = _prev_size_16783 + _psize_16774;
        if ((object)((uintptr_t)_9530 + (uintptr_t)HIGH_BITS) >= 0){
            _9530 = NewDouble((eudouble)_9530);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_size_16783)) {
            _9530 = NewDouble((eudouble)_prev_size_16783 + DBL_PTR(_psize_16774)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16774)) {
                _9530 = NewDouble(DBL_PTR(_prev_size_16783)->dbl + (eudouble)_psize_16774);
            }
            else
            _9530 = NewDouble(DBL_PTR(_prev_size_16783)->dbl + DBL_PTR(_psize_16774)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_16895);
    _x_inlined_put4_at_661_16895 = _9530;
    _9530 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_16895)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_661_16895;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_661_16895)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_16896);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at664_16896 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at664_16896); // DJP 

    /** eds.e:444	end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_16895);
    _x_inlined_put4_at_661_16895 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_16896);
    _put4_1__tmp_at664_16896 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** eds.e:901		elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_16775)) {
        _9531 = (_i_16775 < _free_count_16784);
    }
    else {
        _9531 = (DBL_PTR(_i_16775)->dbl < (eudouble)_free_count_16784);
    }
    if (_9531 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_16773) && IS_ATOM_INT(_psize_16774)) {
        _9533 = _p_16773 + _psize_16774;
        if ((object)((uintptr_t)_9533 + (uintptr_t)HIGH_BITS) >= 0){
            _9533 = NewDouble((eudouble)_9533);
        }
    }
    else {
        if (IS_ATOM_INT(_p_16773)) {
            _9533 = NewDouble((eudouble)_p_16773 + DBL_PTR(_psize_16774)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16774)) {
                _9533 = NewDouble(DBL_PTR(_p_16773)->dbl + (eudouble)_psize_16774);
            }
            else
            _9533 = NewDouble(DBL_PTR(_p_16773)->dbl + DBL_PTR(_psize_16774)->dbl);
        }
    }
    if (IS_ATOM_INT(_9533) && IS_ATOM_INT(_addr_16777)) {
        _9534 = (_9533 == _addr_16777);
    }
    else {
        if (IS_ATOM_INT(_9533)) {
            _9534 = ((eudouble)_9533 == DBL_PTR(_addr_16777)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_16777)) {
                _9534 = (DBL_PTR(_9533)->dbl == (eudouble)_addr_16777);
            }
            else
            _9534 = (DBL_PTR(_9533)->dbl == DBL_PTR(_addr_16777)->dbl);
        }
    }
    DeRef(_9533);
    _9533 = NOVALUE;
    if (_9534 == 0)
    {
        DeRef(_9534);
        _9534 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_9534);
        _9534 = NOVALUE;
    }

    /** eds.e:903			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9535 = _i_16775 - 1;
        if ((object)((uintptr_t)_9535 +(uintptr_t) HIGH_BITS) >= 0){
            _9535 = NewDouble((eudouble)_9535);
        }
    }
    else {
        _9535 = NewDouble(DBL_PTR(_i_16775)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9535)) {
        if (_9535 == (short)_9535){
            _9536 = _9535 * 8;
        }
        else{
            _9536 = NewDouble(_9535 * (eudouble)8);
        }
    }
    else {
        _9536 = NewDouble(DBL_PTR(_9535)->dbl * (eudouble)8);
    }
    DeRef(_9535);
    _9535 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16778) && IS_ATOM_INT(_9536)) {
        _9537 = _free_list_16778 + _9536;
        if ((object)((uintptr_t)_9537 + (uintptr_t)HIGH_BITS) >= 0){
            _9537 = NewDouble((eudouble)_9537);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16778)) {
            _9537 = NewDouble((eudouble)_free_list_16778 + DBL_PTR(_9536)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9536)) {
                _9537 = NewDouble(DBL_PTR(_free_list_16778)->dbl + (eudouble)_9536);
            }
            else
            _9537 = NewDouble(DBL_PTR(_free_list_16778)->dbl + DBL_PTR(_9536)->dbl);
        }
    }
    DeRef(_9536);
    _9536 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_16906);
    _pos_inlined_seek_at_734_16906 = _9537;
    _9537 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_16906);
    DeRef(_seek_1__tmp_at737_16908);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_734_16906;
    _seek_1__tmp_at737_16908 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_16907 = machine(19, _seek_1__tmp_at737_16908);
    DeRef(_pos_inlined_seek_at_734_16906);
    _pos_inlined_seek_at_734_16906 = NOVALUE;
    DeRef(_seek_1__tmp_at737_16908);
    _seek_1__tmp_at737_16908 = NOVALUE;

    /** eds.e:904			put4(p)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_p_16773)) {
        *poke4_addr = (uint32_t)_p_16773;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_p_16773)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_16910);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at752_16910 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at752_16910); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_16910);
    _put4_1__tmp_at752_16910 = NOVALUE;

    /** eds.e:905			put4(psize+size)*/
    if (IS_ATOM_INT(_psize_16774) && IS_ATOM_INT(_size_16776)) {
        _9538 = _psize_16774 + _size_16776;
        if ((object)((uintptr_t)_9538 + (uintptr_t)HIGH_BITS) >= 0){
            _9538 = NewDouble((eudouble)_9538);
        }
    }
    else {
        if (IS_ATOM_INT(_psize_16774)) {
            _9538 = NewDouble((eudouble)_psize_16774 + DBL_PTR(_size_16776)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_16776)) {
                _9538 = NewDouble(DBL_PTR(_psize_16774)->dbl + (eudouble)_size_16776);
            }
            else
            _9538 = NewDouble(DBL_PTR(_psize_16774)->dbl + DBL_PTR(_size_16776)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_16913);
    _x_inlined_put4_at_786_16913 = _9538;
    _9538 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_16913)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_786_16913;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_786_16913)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_16914);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at789_16914 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at789_16914); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_16913);
    _x_inlined_put4_at_786_16913 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_16914);
    _put4_1__tmp_at789_16914 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** eds.e:908			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9539 = _i_16775 - 1;
        if ((object)((uintptr_t)_9539 +(uintptr_t) HIGH_BITS) >= 0){
            _9539 = NewDouble((eudouble)_9539);
        }
    }
    else {
        _9539 = NewDouble(DBL_PTR(_i_16775)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9539)) {
        if (_9539 == (short)_9539){
            _9540 = _9539 * 8;
        }
        else{
            _9540 = NewDouble(_9539 * (eudouble)8);
        }
    }
    else {
        _9540 = NewDouble(DBL_PTR(_9539)->dbl * (eudouble)8);
    }
    DeRef(_9539);
    _9539 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16778) && IS_ATOM_INT(_9540)) {
        _9541 = _free_list_16778 + _9540;
        if ((object)((uintptr_t)_9541 + (uintptr_t)HIGH_BITS) >= 0){
            _9541 = NewDouble((eudouble)_9541);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16778)) {
            _9541 = NewDouble((eudouble)_free_list_16778 + DBL_PTR(_9540)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9540)) {
                _9541 = NewDouble(DBL_PTR(_free_list_16778)->dbl + (eudouble)_9540);
            }
            else
            _9541 = NewDouble(DBL_PTR(_free_list_16778)->dbl + DBL_PTR(_9540)->dbl);
        }
    }
    DeRef(_9540);
    _9540 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_16920);
    _pos_inlined_seek_at_834_16920 = _9541;
    _9541 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_16920);
    DeRef(_seek_1__tmp_at837_16922);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_834_16920;
    _seek_1__tmp_at837_16922 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_16921 = machine(19, _seek_1__tmp_at837_16922);
    DeRef(_pos_inlined_seek_at_834_16920);
    _pos_inlined_seek_at_834_16920 = NOVALUE;
    DeRef(_seek_1__tmp_at837_16922);
    _seek_1__tmp_at837_16922 = NOVALUE;

    /** eds.e:909			remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9542 = _free_count_16784 - _i_16775;
        if ((object)((uintptr_t)_9542 +(uintptr_t) HIGH_BITS) >= 0){
            _9542 = NewDouble((eudouble)_9542);
        }
    }
    else {
        _9542 = NewDouble((eudouble)_free_count_16784 - DBL_PTR(_i_16775)->dbl);
    }
    if (IS_ATOM_INT(_9542)) {
        _9543 = _9542 + 1;
        if (_9543 > MAXINT){
            _9543 = NewDouble((eudouble)_9543);
        }
    }
    else
    _9543 = binary_op(PLUS, 1, _9542);
    DeRef(_9542);
    _9542 = NOVALUE;
    if (IS_ATOM_INT(_9543)) {
        if (_9543 == (short)_9543){
            _9544 = _9543 * 8;
        }
        else{
            _9544 = NewDouble(_9543 * (eudouble)8);
        }
    }
    else {
        _9544 = NewDouble(DBL_PTR(_9543)->dbl * (eudouble)8);
    }
    DeRef(_9543);
    _9543 = NOVALUE;
    _0 = _remaining_16785;
    _remaining_16785 = _18get_bytes(_41current_db_16047, _9544);
    DeRef(_0);
    _9544 = NOVALUE;

    /** eds.e:910			free_count += 1*/
    _free_count_16784 = _free_count_16784 + 1;

    /** eds.e:911			io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_16930);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 7;
    _seek_1__tmp_at883_16930 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_16929 = machine(19, _seek_1__tmp_at883_16930);
    DeRefi(_seek_1__tmp_at883_16930);
    _seek_1__tmp_at883_16930 = NOVALUE;

    /** eds.e:912			put4(free_count)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)_free_count_16784;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_16932);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at898_16932 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at898_16932); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_16932);
    _put4_1__tmp_at898_16932 = NOVALUE;

    /** eds.e:913			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16775)) {
        _9547 = _i_16775 - 1;
        if ((object)((uintptr_t)_9547 +(uintptr_t) HIGH_BITS) >= 0){
            _9547 = NewDouble((eudouble)_9547);
        }
    }
    else {
        _9547 = NewDouble(DBL_PTR(_i_16775)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9547)) {
        if (_9547 == (short)_9547){
            _9548 = _9547 * 8;
        }
        else{
            _9548 = NewDouble(_9547 * (eudouble)8);
        }
    }
    else {
        _9548 = NewDouble(DBL_PTR(_9547)->dbl * (eudouble)8);
    }
    DeRef(_9547);
    _9547 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16778) && IS_ATOM_INT(_9548)) {
        _9549 = _free_list_16778 + _9548;
        if ((object)((uintptr_t)_9549 + (uintptr_t)HIGH_BITS) >= 0){
            _9549 = NewDouble((eudouble)_9549);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16778)) {
            _9549 = NewDouble((eudouble)_free_list_16778 + DBL_PTR(_9548)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9548)) {
                _9549 = NewDouble(DBL_PTR(_free_list_16778)->dbl + (eudouble)_9548);
            }
            else
            _9549 = NewDouble(DBL_PTR(_free_list_16778)->dbl + DBL_PTR(_9548)->dbl);
        }
    }
    DeRef(_9548);
    _9548 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_16937);
    _pos_inlined_seek_at_940_16937 = _9549;
    _9549 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_16937);
    DeRef(_seek_1__tmp_at943_16939);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_940_16937;
    _seek_1__tmp_at943_16939 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_16938 = machine(19, _seek_1__tmp_at943_16939);
    DeRef(_pos_inlined_seek_at_940_16937);
    _pos_inlined_seek_at_940_16937 = NOVALUE;
    DeRef(_seek_1__tmp_at943_16939);
    _seek_1__tmp_at943_16939 = NOVALUE;

    /** eds.e:914			put4(p)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_p_16773)) {
        *poke4_addr = (uint32_t)_p_16773;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_p_16773)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_16941);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at958_16941 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at958_16941); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_16941);
    _put4_1__tmp_at958_16941 = NOVALUE;

    /** eds.e:915			put4(psize)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_psize_16774)) {
        *poke4_addr = (uint32_t)_psize_16774;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_psize_16774)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_16943);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at986_16943 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at986_16943); // DJP 

    /** eds.e:444	end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_16943);
    _put4_1__tmp_at986_16943 = NOVALUE;

    /** eds.e:916			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _remaining_16785); // DJP 

    /** eds.e:449	end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** eds.e:919		if new_space then*/
    if (_new_space_16780 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_16780) && DBL_PTR(_new_space_16780)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** eds.e:920			db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_16781);
    _41db_free(_to_be_freed_16781);
L17: 

    /** eds.e:922	end procedure*/
    DeRef(_p_16773);
    DeRef(_psize_16774);
    DeRef(_i_16775);
    DeRef(_size_16776);
    DeRef(_addr_16777);
    DeRef(_free_list_16778);
    DeRef(_free_list_space_16779);
    DeRef(_new_space_16780);
    DeRef(_to_be_freed_16781);
    DeRef(_prev_addr_16782);
    DeRef(_prev_size_16783);
    DeRef(_remaining_16785);
    DeRef(_9507);
    _9507 = NOVALUE;
    DeRef(_9531);
    _9531 = NOVALUE;
    DeRef(_9515);
    _9515 = NOVALUE;
    return;
    ;
}


void _41save_keys()
{
    object _k_16948 = NOVALUE;
    object _9556 = NOVALUE;
    object _9552 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:926		if caching_option = 1 then*/

    /** eds.e:927			if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _41current_table_pos_16048, 0)){
        goto L1; // [13] 81
    }

    /** eds.e:928				k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_41current_table_pos_16048);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _41current_table_pos_16048;
    _9552 = MAKE_SEQ(_1);
    _k_16948 = find_from(_9552, _41cache_index_16056, 1);
    DeRefDS(_9552);
    _9552 = NOVALUE;

    /** eds.e:929				if k != 0 then*/
    if (_k_16948 == 0)
    goto L2; // [36] 53

    /** eds.e:930					key_cache[k] = key_pointers*/
    RefDS(_41key_pointers_16054);
    _2 = (object)SEQ_PTR(_41key_cache_16055);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _41key_cache_16055 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _k_16948);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _41key_pointers_16054;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** eds.e:932					key_cache = append(key_cache, key_pointers)*/
    RefDS(_41key_pointers_16054);
    Append(&_41key_cache_16055, _41key_cache_16055, _41key_pointers_16054);

    /** eds.e:933					cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_41current_table_pos_16048);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _41current_table_pos_16048;
    _9556 = MAKE_SEQ(_1);
    RefDS(_9556);
    Append(&_41cache_index_16056, _41cache_index_16056, _9556);
    DeRefDS(_9556);
    _9556 = NOVALUE;
L3: 
L1: 

    /** eds.e:937	end procedure*/
    return;
    ;
}


object _41db_create(object _path_17045, object _lock_method_17046, object _init_tables_17047, object _init_free_17048)
{
    object _db_17049 = NOVALUE;
    object _lock_file_1__tmp_at222_17088 = NOVALUE;
    object _lock_file_inlined_lock_file_at_222_17087 = NOVALUE;
    object _put4_1__tmp_at342_17097 = NOVALUE;
    object _put4_1__tmp_at370_17099 = NOVALUE;
    object _put4_1__tmp_at413_17105 = NOVALUE;
    object _x_inlined_put4_at_410_17104 = NOVALUE;
    object _put4_1__tmp_at452_17110 = NOVALUE;
    object _x_inlined_put4_at_449_17109 = NOVALUE;
    object _put4_1__tmp_at480_17112 = NOVALUE;
    object _s_inlined_putn_at_516_17116 = NOVALUE;
    object _put4_1__tmp_at548_17121 = NOVALUE;
    object _x_inlined_put4_at_545_17120 = NOVALUE;
    object _s_inlined_putn_at_584_17125 = NOVALUE;
    object _9654 = NOVALUE;
    object _9653 = NOVALUE;
    object _9652 = NOVALUE;
    object _9651 = NOVALUE;
    object _9650 = NOVALUE;
    object _9649 = NOVALUE;
    object _9648 = NOVALUE;
    object _9647 = NOVALUE;
    object _9646 = NOVALUE;
    object _9645 = NOVALUE;
    object _9644 = NOVALUE;
    object _9627 = NOVALUE;
    object _9625 = NOVALUE;
    object _9624 = NOVALUE;
    object _9622 = NOVALUE;
    object _9621 = NOVALUE;
    object _9619 = NOVALUE;
    object _9618 = NOVALUE;
    object _9616 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1133		db = find(path, Known_Aliases)*/
    _db_17049 = find_from(_path_17045, _41Known_Aliases_16068, 1);

    /** eds.e:1134		if db then*/
    if (_db_17049 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** eds.e:1136			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9616 = (object)*(((s1_ptr)_2)->base + _db_17049);
    DeRefDS(_path_17045);
    _2 = (object)SEQ_PTR(_9616);
    _path_17045 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17045);
    _9616 = NOVALUE;

    /** eds.e:1137			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9618 = (object)*(((s1_ptr)_2)->base + _db_17049);
    _2 = (object)SEQ_PTR(_9618);
    _9619 = (object)*(((s1_ptr)_2)->base + 2);
    _9618 = NOVALUE;
    _2 = (object)SEQ_PTR(_9619);
    _lock_method_17046 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17046)){
        _lock_method_17046 = (object)DBL_PTR(_lock_method_17046)->dbl;
    }
    _9619 = NOVALUE;

    /** eds.e:1138			init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9621 = (object)*(((s1_ptr)_2)->base + _db_17049);
    _2 = (object)SEQ_PTR(_9621);
    _9622 = (object)*(((s1_ptr)_2)->base + 2);
    _9621 = NOVALUE;
    _2 = (object)SEQ_PTR(_9622);
    _init_tables_17047 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_17047)){
        _init_tables_17047 = (object)DBL_PTR(_init_tables_17047)->dbl;
    }
    _9622 = NOVALUE;

    /** eds.e:1139			init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9624 = (object)*(((s1_ptr)_2)->base + _db_17049);
    _2 = (object)SEQ_PTR(_9624);
    _9625 = (object)*(((s1_ptr)_2)->base + 2);
    _9624 = NOVALUE;
    _2 = (object)SEQ_PTR(_9625);
    _init_free_17048 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_17048)){
        _init_free_17048 = (object)DBL_PTR(_init_free_17048)->dbl;
    }
    _9625 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** eds.e:1141			path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_17045);
    RefDS(_9610);
    _9627 = _15defaultext(_path_17045, _9610);
    _0 = _path_17045;
    _path_17045 = _15canonical_path(_9627, 0, 0);
    DeRefDS(_0);
    _9627 = NOVALUE;

    /** eds.e:1143			if init_tables < 1 then*/
    if (_init_tables_17047 >= 1)
    goto L3; // [111] 121

    /** eds.e:1144				init_tables = 1*/
    _init_tables_17047 = 1;
L3: 

    /** eds.e:1147			if init_free < 0 then*/
    if (_init_free_17048 >= 0)
    goto L4; // [123] 133

    /** eds.e:1148				init_free = 0*/
    _init_free_17048 = 0;
L4: 
L2: 

    /** eds.e:1154		db = open(path, "rb")*/
    _db_17049 = EOpen(_path_17045, _8907, 0);

    /** eds.e:1155		if db != -1 then*/
    if (_db_17049 == -1)
    goto L5; // [143] 158

    /** eds.e:1157			close(db)*/
    EClose(_db_17049);

    /** eds.e:1158			return DB_EXISTS_ALREADY*/
    DeRefDS(_path_17045);
    return -2;
L5: 

    /** eds.e:1162		db = open(path, "wb")*/
    _db_17049 = EOpen(_path_17045, _9036, 0);

    /** eds.e:1163		if db = -1 then*/
    if (_db_17049 != -1)
    goto L6; // [167] 178

    /** eds.e:1164			return DB_OPEN_FAIL*/
    DeRefDS(_path_17045);
    return -1;
L6: 

    /** eds.e:1166		close(db)*/
    EClose(_db_17049);

    /** eds.e:1169		db = open(path, "ub")*/
    _db_17049 = EOpen(_path_17045, _9635, 0);

    /** eds.e:1170		if db = -1 then*/
    if (_db_17049 != -1)
    goto L7; // [191] 202

    /** eds.e:1171			return DB_OPEN_FAIL*/
    DeRefDS(_path_17045);
    return -1;
L7: 

    /** eds.e:1173		if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17046 != 1)
    goto L8; // [204] 214

    /** eds.e:1175			lock_method = DB_LOCK_NO*/
    _lock_method_17046 = 0;
L8: 

    /** eds.e:1177		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17046 != 2)
    goto L9; // [216] 248

    /** eds.e:1178			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_17088;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17049;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at222_17088 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_17087 = machine(61, _lock_file_1__tmp_at222_17088);
    DeRef(_lock_file_1__tmp_at222_17088);
    _lock_file_1__tmp_at222_17088 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_17087 != 0)
    goto LA; // [237] 247

    /** eds.e:1179				return DB_LOCK_FAIL*/
    DeRefDS(_path_17045);
    return -3;
LA: 
L9: 

    /** eds.e:1182		save_keys()*/
    _41save_keys();

    /** eds.e:1183		current_db = db*/
    _41current_db_16047 = _db_17049;

    /** eds.e:1184		current_lock = lock_method*/
    _41current_lock_16053 = _lock_method_17046;

    /** eds.e:1185		current_table_pos = -1*/
    DeRef(_41current_table_pos_16048);
    _41current_table_pos_16048 = -1;

    /** eds.e:1186		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_16049);
    _41current_table_name_16049 = _5;

    /** eds.e:1187		db_names = append(db_names, path)*/
    RefDS(_path_17045);
    Append(&_41db_names_16050, _41db_names_16050, _path_17045);

    /** eds.e:1188		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_41db_lock_methods_16052, _41db_lock_methods_16052, _lock_method_17046);

    /** eds.e:1189		db_file_nums = append(db_file_nums, db)*/
    Append(&_41db_file_nums_16051, _41db_file_nums_16051, _db_17049);

    /** eds.e:1192		put1(DB_MAGIC) -- so we know what type of file it is*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_16047, 77); // DJP 

    /** eds.e:434	end procedure*/
    goto LB; // [309] 312
LB: 

    /** eds.e:1193		put1(DB_MAJOR) -- major version*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_16047, 4); // DJP 

    /** eds.e:434	end procedure*/
    goto LC; // [323] 326
LC: 

    /** eds.e:1194		put1(DB_MINOR) -- minor version*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_16047, 0); // DJP 

    /** eds.e:434	end procedure*/
    goto LD; // [337] 340
LD: 

    /** eds.e:1196		put4(19)  -- pointer to tables*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)19;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_17097);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at342_17097 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at342_17097); // DJP 

    /** eds.e:444	end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_17097);
    _put4_1__tmp_at342_17097 = NOVALUE;

    /** eds.e:1198		put4(0)   -- number of free blocks*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_17099);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at370_17099 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at370_17099); // DJP 

    /** eds.e:444	end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_17099);
    _put4_1__tmp_at370_17099 = NOVALUE;

    /** eds.e:1200		put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_17047 == (short)_init_tables_17047){
        _9644 = _init_tables_17047 * 16;
    }
    else{
        _9644 = NewDouble(_init_tables_17047 * (eudouble)16);
    }
    if (IS_ATOM_INT(_9644)) {
        _9645 = 23 + _9644;
        if ((object)((uintptr_t)_9645 + (uintptr_t)HIGH_BITS) >= 0){
            _9645 = NewDouble((eudouble)_9645);
        }
    }
    else {
        _9645 = NewDouble((eudouble)23 + DBL_PTR(_9644)->dbl);
    }
    DeRef(_9644);
    _9644 = NOVALUE;
    if (IS_ATOM_INT(_9645)) {
        _9646 = _9645 + 4;
        if ((object)((uintptr_t)_9646 + (uintptr_t)HIGH_BITS) >= 0){
            _9646 = NewDouble((eudouble)_9646);
        }
    }
    else {
        _9646 = NewDouble(DBL_PTR(_9645)->dbl + (eudouble)4);
    }
    DeRef(_9645);
    _9645 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_17104);
    _x_inlined_put4_at_410_17104 = _9646;
    _9646 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_17104)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_410_17104;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_410_17104)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_17105);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at413_17105 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at413_17105); // DJP 

    /** eds.e:444	end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_17104);
    _x_inlined_put4_at_410_17104 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_17105);
    _put4_1__tmp_at413_17105 = NOVALUE;

    /** eds.e:1202		put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_17047 == (short)_init_tables_17047){
        _9647 = _init_tables_17047 * 16;
    }
    else{
        _9647 = NewDouble(_init_tables_17047 * (eudouble)16);
    }
    if (IS_ATOM_INT(_9647)) {
        _9648 = 8 + _9647;
        if ((object)((uintptr_t)_9648 + (uintptr_t)HIGH_BITS) >= 0){
            _9648 = NewDouble((eudouble)_9648);
        }
    }
    else {
        _9648 = NewDouble((eudouble)8 + DBL_PTR(_9647)->dbl);
    }
    DeRef(_9647);
    _9647 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_17109);
    _x_inlined_put4_at_449_17109 = _9648;
    _9648 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_17109)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_449_17109;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_449_17109)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_17110);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at452_17110 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at452_17110); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_17109);
    _x_inlined_put4_at_449_17109 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_17110);
    _put4_1__tmp_at452_17110 = NOVALUE;

    /** eds.e:1204		put4(0)   -- number of tables that currently exist*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_17112);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at480_17112 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at480_17112); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_17112);
    _put4_1__tmp_at480_17112 = NOVALUE;

    /** eds.e:1206		putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _9649 = _init_tables_17047 * 16;
    _9650 = Repeat(0, _9649);
    _9649 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_17116);
    _s_inlined_putn_at_516_17116 = _9650;
    _9650 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_516_17116); // DJP 

    /** eds.e:449	end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_17116);
    _s_inlined_putn_at_516_17116 = NOVALUE;

    /** eds.e:1208		put4(4+init_free*8)   -- allocated size*/
    if (_init_free_17048 == (short)_init_free_17048){
        _9651 = _init_free_17048 * 8;
    }
    else{
        _9651 = NewDouble(_init_free_17048 * (eudouble)8);
    }
    if (IS_ATOM_INT(_9651)) {
        _9652 = 4 + _9651;
        if ((object)((uintptr_t)_9652 + (uintptr_t)HIGH_BITS) >= 0){
            _9652 = NewDouble((eudouble)_9652);
        }
    }
    else {
        _9652 = NewDouble((eudouble)4 + DBL_PTR(_9651)->dbl);
    }
    DeRef(_9651);
    _9651 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_17120);
    _x_inlined_put4_at_545_17120 = _9652;
    _9652 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_17120)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_545_17120;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_545_17120)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_17121);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at548_17121 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at548_17121); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_17120);
    _x_inlined_put4_at_545_17120 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_17121);
    _put4_1__tmp_at548_17121 = NOVALUE;

    /** eds.e:1209		putn(repeat(0, init_free * 8))*/
    _9653 = _init_free_17048 * 8;
    _9654 = Repeat(0, _9653);
    _9653 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_17125);
    _s_inlined_putn_at_584_17125 = _9654;
    _9654 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_584_17125); // DJP 

    /** eds.e:449	end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_17125);
    _s_inlined_putn_at_584_17125 = NOVALUE;

    /** eds.e:1210		return DB_OK*/
    DeRefDS(_path_17045);
    return 0;
    ;
}


object _41db_open(object _path_17128, object _lock_method_17129)
{
    object _db_17130 = NOVALUE;
    object _magic_17131 = NOVALUE;
    object _lock_file_1__tmp_at141_17158 = NOVALUE;
    object _lock_file_inlined_lock_file_at_141_17157 = NOVALUE;
    object _lock_file_1__tmp_at181_17165 = NOVALUE;
    object _lock_file_inlined_lock_file_at_181_17164 = NOVALUE;
    object _9665 = NOVALUE;
    object _9663 = NOVALUE;
    object _9661 = NOVALUE;
    object _9659 = NOVALUE;
    object _9658 = NOVALUE;
    object _9656 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1273		db = find(path, Known_Aliases)*/
    _db_17130 = find_from(_path_17128, _41Known_Aliases_16068, 1);

    /** eds.e:1274		if db then*/
    if (_db_17130 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1276			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9656 = (object)*(((s1_ptr)_2)->base + _db_17130);
    DeRefDS(_path_17128);
    _2 = (object)SEQ_PTR(_9656);
    _path_17128 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17128);
    _9656 = NOVALUE;

    /** eds.e:1277			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9658 = (object)*(((s1_ptr)_2)->base + _db_17130);
    _2 = (object)SEQ_PTR(_9658);
    _9659 = (object)*(((s1_ptr)_2)->base + 2);
    _9658 = NOVALUE;
    _2 = (object)SEQ_PTR(_9659);
    _lock_method_17129 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17129)){
        _lock_method_17129 = (object)DBL_PTR(_lock_method_17129)->dbl;
    }
    _9659 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1279			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17128);
    RefDS(_9610);
    _9661 = _15defaultext(_path_17128, _9610);
    _0 = _path_17128;
    _path_17128 = _15canonical_path(_9661, 0, 0);
    DeRefDS(_0);
    _9661 = NOVALUE;
L2: 

    /** eds.e:1282		if lock_method = DB_LOCK_NO or*/
    _9663 = (_lock_method_17129 == 0);
    if (_9663 != 0) {
        goto L3; // [76] 89
    }
    _9665 = (_lock_method_17129 == 2);
    if (_9665 == 0)
    {
        DeRef(_9665);
        _9665 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_9665);
        _9665 = NOVALUE;
    }
L3: 

    /** eds.e:1285			db = open(path, "ub")*/
    _db_17130 = EOpen(_path_17128, _9635, 0);
    goto L5; // [96] 107
L4: 

    /** eds.e:1288			db = open(path, "rb")*/
    _db_17130 = EOpen(_path_17128, _8907, 0);
L5: 

    /** eds.e:1291	ifdef WINDOWS then*/

    /** eds.e:1292		if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17129 != 1)
    goto L6; // [111] 121

    /** eds.e:1293			lock_method = DB_LOCK_EXCLUSIVE*/
    _lock_method_17129 = 2;
L6: 

    /** eds.e:1298		if db = -1 then*/
    if (_db_17130 != -1)
    goto L7; // [123] 134

    /** eds.e:1299			return DB_OPEN_FAIL*/
    DeRefDS(_path_17128);
    DeRef(_9663);
    _9663 = NOVALUE;
    return -1;
L7: 

    /** eds.e:1301		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17129 != 2)
    goto L8; // [136] 174

    /** eds.e:1302			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at141_17158;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17130;
    ((intptr_t*)_2)[2] = 2;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at141_17158 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_141_17157 = machine(61, _lock_file_1__tmp_at141_17158);
    DeRef(_lock_file_1__tmp_at141_17158);
    _lock_file_1__tmp_at141_17158 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_141_17157 != 0)
    goto L9; // [157] 213

    /** eds.e:1303				close(db)*/
    EClose(_db_17130);

    /** eds.e:1304				return DB_LOCK_FAIL*/
    DeRefDS(_path_17128);
    DeRef(_9663);
    _9663 = NOVALUE;
    return -3;
    goto L9; // [171] 213
L8: 

    /** eds.e:1306		elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17129 != 1)
    goto LA; // [176] 212

    /** eds.e:1307			if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at181_17165;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17130;
    ((intptr_t*)_2)[2] = 1;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at181_17165 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_181_17164 = machine(61, _lock_file_1__tmp_at181_17165);
    DeRef(_lock_file_1__tmp_at181_17165);
    _lock_file_1__tmp_at181_17165 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_181_17164 != 0)
    goto LB; // [197] 211

    /** eds.e:1308				close(db)*/
    EClose(_db_17130);

    /** eds.e:1309				return DB_LOCK_FAIL*/
    DeRefDS(_path_17128);
    DeRef(_9663);
    _9663 = NOVALUE;
    return -3;
LB: 
LA: 
L9: 

    /** eds.e:1312		magic = getc(db)*/
    if (_db_17130 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_17130, EF_READ);
        last_r_file_no = _db_17130;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_17131 = getKBchar();
        }
        else{
            _magic_17131 = getc(last_r_file_ptr);
        }
    }
    else{
        _magic_17131 = getc(last_r_file_ptr);
    }

    /** eds.e:1313		if magic != DB_MAGIC then*/
    if (_magic_17131 == 77)
    goto LC; // [220] 235

    /** eds.e:1314			close(db)*/
    EClose(_db_17130);

    /** eds.e:1315			return DB_OPEN_FAIL*/
    DeRefDS(_path_17128);
    DeRef(_9663);
    _9663 = NOVALUE;
    return -1;
LC: 

    /** eds.e:1317		save_keys()*/
    _41save_keys();

    /** eds.e:1318		current_db = db */
    _41current_db_16047 = _db_17130;

    /** eds.e:1319		current_table_pos = -1*/
    DeRef(_41current_table_pos_16048);
    _41current_table_pos_16048 = -1;

    /** eds.e:1320		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_16049);
    _41current_table_name_16049 = _5;

    /** eds.e:1321		current_lock = lock_method*/
    _41current_lock_16053 = _lock_method_17129;

    /** eds.e:1322		db_names = append(db_names, path)*/
    RefDS(_path_17128);
    Append(&_41db_names_16050, _41db_names_16050, _path_17128);

    /** eds.e:1323		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_41db_lock_methods_16052, _41db_lock_methods_16052, _lock_method_17129);

    /** eds.e:1324		db_file_nums = append(db_file_nums, db)*/
    Append(&_41db_file_nums_16051, _41db_file_nums_16051, _db_17130);

    /** eds.e:1325		return DB_OK*/
    DeRefDS(_path_17128);
    DeRef(_9663);
    _9663 = NOVALUE;
    return 0;
    ;
}


object _41db_select(object _path_17175, object _lock_method_17176)
{
    object _index_17177 = NOVALUE;
    object _9685 = NOVALUE;
    object _9683 = NOVALUE;
    object _9682 = NOVALUE;
    object _9680 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1372		index = find(path, Known_Aliases)*/
    _index_17177 = find_from(_path_17175, _41Known_Aliases_16068, 1);

    /** eds.e:1373		if index then*/
    if (_index_17177 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1375			path = Alias_Details[index][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9680 = (object)*(((s1_ptr)_2)->base + _index_17177);
    DeRefDS(_path_17175);
    _2 = (object)SEQ_PTR(_9680);
    _path_17175 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_path_17175);
    _9680 = NOVALUE;

    /** eds.e:1376			lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16069);
    _9682 = (object)*(((s1_ptr)_2)->base + _index_17177);
    _2 = (object)SEQ_PTR(_9682);
    _9683 = (object)*(((s1_ptr)_2)->base + 2);
    _9682 = NOVALUE;
    _2 = (object)SEQ_PTR(_9683);
    _lock_method_17176 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_17176)){
        _lock_method_17176 = (object)DBL_PTR(_lock_method_17176)->dbl;
    }
    _9683 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1378			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17175);
    RefDS(_9610);
    _9685 = _15defaultext(_path_17175, _9610);
    _0 = _path_17175;
    _path_17175 = _15canonical_path(_9685, 0, 0);
    DeRefDS(_0);
    _9685 = NOVALUE;
L2: 

    /** eds.e:1381		index = eu:find(path, db_names)*/
    _index_17177 = find_from(_path_17175, _41db_names_16050, 1);

    /** eds.e:1382		if index = 0 then*/
    if (_index_17177 != 0)
    goto L3; // [81] 130

    /** eds.e:1383			if lock_method = -1 then*/
    if (_lock_method_17176 != -1)
    goto L4; // [87] 98

    /** eds.e:1384				return DB_OPEN_FAIL*/
    DeRefDS(_path_17175);
    return -1;
L4: 

    /** eds.e:1386			index = db_open(path, lock_method)*/
    RefDS(_path_17175);
    _index_17177 = _41db_open(_path_17175, _lock_method_17176);
    if (!IS_ATOM_INT(_index_17177)) {
        _1 = (object)(DBL_PTR(_index_17177)->dbl);
        DeRefDS(_index_17177);
        _index_17177 = _1;
    }

    /** eds.e:1387			if index != DB_OK then*/
    if (_index_17177 == 0)
    goto L5; // [109] 120

    /** eds.e:1388				return index*/
    DeRefDS(_path_17175);
    return _index_17177;
L5: 

    /** eds.e:1390			index = eu:find(path, db_names)*/
    _index_17177 = find_from(_path_17175, _41db_names_16050, 1);
L3: 

    /** eds.e:1392		save_keys()*/
    _41save_keys();

    /** eds.e:1393		current_db = db_file_nums[index]*/
    _2 = (object)SEQ_PTR(_41db_file_nums_16051);
    _41current_db_16047 = (object)*(((s1_ptr)_2)->base + _index_17177);
    if (!IS_ATOM_INT(_41current_db_16047))
    _41current_db_16047 = (object)DBL_PTR(_41current_db_16047)->dbl;

    /** eds.e:1394		current_lock = db_lock_methods[index]*/
    _2 = (object)SEQ_PTR(_41db_lock_methods_16052);
    _41current_lock_16053 = (object)*(((s1_ptr)_2)->base + _index_17177);
    if (!IS_ATOM_INT(_41current_lock_16053))
    _41current_lock_16053 = (object)DBL_PTR(_41current_lock_16053)->dbl;

    /** eds.e:1395		current_table_pos = -1*/
    DeRef(_41current_table_pos_16048);
    _41current_table_pos_16048 = -1;

    /** eds.e:1396		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_16049);
    _41current_table_name_16049 = _5;

    /** eds.e:1397		key_pointers = {}*/
    RefDS(_5);
    DeRef(_41key_pointers_16054);
    _41key_pointers_16054 = _5;

    /** eds.e:1398		return DB_OK*/
    DeRefDS(_path_17175);
    return 0;
    ;
}


void _41db_close()
{
    object _unlock_file_1__tmp_at25_17206 = NOVALUE;
    object _index_17201 = NOVALUE;
    object _9702 = NOVALUE;
    object _9701 = NOVALUE;
    object _9700 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1413		if current_db = -1 then*/
    if (_41current_db_16047 != -1)
    goto L1; // [5] 15

    /** eds.e:1414			return*/
    return;
L1: 

    /** eds.e:1417		if current_lock then*/
    if (_41current_lock_16053 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** eds.e:1418			io:unlock_file(current_db, {})*/

    /** io.e:1086		machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_17206);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_17206 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_17206);

    /** io.e:1087	end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_17206);
    _unlock_file_1__tmp_at25_17206 = NOVALUE;
L2: 

    /** eds.e:1420		close(current_db)*/
    EClose(_41current_db_16047);

    /** eds.e:1422		index = eu:find(current_db, db_file_nums)*/
    _index_17201 = find_from(_41current_db_16047, _41db_file_nums_16051, 1);

    /** eds.e:1423		db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_names_16050);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17201)) ? _index_17201 : (object)(DBL_PTR(_index_17201)->dbl);
        int stop = (IS_ATOM_INT(_index_17201)) ? _index_17201 : (object)(DBL_PTR(_index_17201)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_names_16050), start, &_41db_names_16050 );
            }
            else Tail(SEQ_PTR(_41db_names_16050), stop+1, &_41db_names_16050);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_names_16050), start, &_41db_names_16050);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_names_16050 = Remove_elements(start, stop, (SEQ_PTR(_41db_names_16050)->ref == 1));
        }
    }

    /** eds.e:1424		db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_file_nums_16051);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17201)) ? _index_17201 : (object)(DBL_PTR(_index_17201)->dbl);
        int stop = (IS_ATOM_INT(_index_17201)) ? _index_17201 : (object)(DBL_PTR(_index_17201)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_file_nums_16051), start, &_41db_file_nums_16051 );
            }
            else Tail(SEQ_PTR(_41db_file_nums_16051), stop+1, &_41db_file_nums_16051);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_file_nums_16051), start, &_41db_file_nums_16051);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_file_nums_16051 = Remove_elements(start, stop, (SEQ_PTR(_41db_file_nums_16051)->ref == 1));
        }
    }

    /** eds.e:1425		db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_lock_methods_16052);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17201)) ? _index_17201 : (object)(DBL_PTR(_index_17201)->dbl);
        int stop = (IS_ATOM_INT(_index_17201)) ? _index_17201 : (object)(DBL_PTR(_index_17201)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_lock_methods_16052), start, &_41db_lock_methods_16052 );
            }
            else Tail(SEQ_PTR(_41db_lock_methods_16052), stop+1, &_41db_lock_methods_16052);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_lock_methods_16052), start, &_41db_lock_methods_16052);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_lock_methods_16052 = Remove_elements(start, stop, (SEQ_PTR(_41db_lock_methods_16052)->ref == 1));
        }
    }

    /** eds.e:1427		for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_41cache_index_16056)){
            _9700 = SEQ_PTR(_41cache_index_16056)->length;
    }
    else {
        _9700 = 1;
    }
    {
        object _i_17212;
        _i_17212 = _9700;
L4: 
        if (_i_17212 < 1){
            goto L5; // [94] 145
        }

        /** eds.e:1428			if cache_index[i][1] = current_db then*/
        _2 = (object)SEQ_PTR(_41cache_index_16056);
        _9701 = (object)*(((s1_ptr)_2)->base + _i_17212);
        _2 = (object)SEQ_PTR(_9701);
        _9702 = (object)*(((s1_ptr)_2)->base + 1);
        _9701 = NOVALUE;
        if (binary_op_a(NOTEQ, _9702, _41current_db_16047)){
            _9702 = NOVALUE;
            goto L6; // [115] 138
        }
        _9702 = NOVALUE;

        /** eds.e:1429				cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_41cache_index_16056);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17212)) ? _i_17212 : (object)(DBL_PTR(_i_17212)->dbl);
            int stop = (IS_ATOM_INT(_i_17212)) ? _i_17212 : (object)(DBL_PTR(_i_17212)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_41cache_index_16056), start, &_41cache_index_16056 );
                }
                else Tail(SEQ_PTR(_41cache_index_16056), stop+1, &_41cache_index_16056);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_41cache_index_16056), start, &_41cache_index_16056);
            }
            else {
                assign_slice_seq = &assign_space;
                _41cache_index_16056 = Remove_elements(start, stop, (SEQ_PTR(_41cache_index_16056)->ref == 1));
            }
        }

        /** eds.e:1430				key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_41key_cache_16055);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17212)) ? _i_17212 : (object)(DBL_PTR(_i_17212)->dbl);
            int stop = (IS_ATOM_INT(_i_17212)) ? _i_17212 : (object)(DBL_PTR(_i_17212)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_41key_cache_16055), start, &_41key_cache_16055 );
                }
                else Tail(SEQ_PTR(_41key_cache_16055), stop+1, &_41key_cache_16055);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_41key_cache_16055), start, &_41key_cache_16055);
            }
            else {
                assign_slice_seq = &assign_space;
                _41key_cache_16055 = Remove_elements(start, stop, (SEQ_PTR(_41key_cache_16055)->ref == 1));
            }
        }
L6: 

        /** eds.e:1432		end for*/
        _i_17212 = _i_17212 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** eds.e:1433		current_table_pos = -1*/
    DeRef(_41current_table_pos_16048);
    _41current_table_pos_16048 = -1;

    /** eds.e:1434		current_table_name = ""	*/
    RefDS(_5);
    DeRef(_41current_table_name_16049);
    _41current_table_name_16049 = _5;

    /** eds.e:1435		current_db = -1*/
    _41current_db_16047 = -1;

    /** eds.e:1436		key_pointers = {}*/
    RefDS(_5);
    DeRef(_41key_pointers_16054);
    _41key_pointers_16054 = _5;

    /** eds.e:1437	end procedure*/
    return;
    ;
}


object _41table_find(object _name_17222)
{
    object _tables_17223 = NOVALUE;
    object _nt_17224 = NOVALUE;
    object _t_header_17225 = NOVALUE;
    object _name_ptr_17226 = NOVALUE;
    object _seek_1__tmp_at6_17229 = NOVALUE;
    object _seek_inlined_seek_at_6_17228 = NOVALUE;
    object _seek_1__tmp_at44_17236 = NOVALUE;
    object _seek_inlined_seek_at_44_17235 = NOVALUE;
    object _seek_1__tmp_at84_17244 = NOVALUE;
    object _seek_inlined_seek_at_84_17243 = NOVALUE;
    object _seek_1__tmp_at106_17248 = NOVALUE;
    object _seek_inlined_seek_at_106_17247 = NOVALUE;
    object _9713 = NOVALUE;
    object _9711 = NOVALUE;
    object _9706 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1446		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_17229);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at6_17229 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_17228 = machine(19, _seek_1__tmp_at6_17229);
    DeRefi(_seek_1__tmp_at6_17229);
    _seek_1__tmp_at6_17229 = NOVALUE;

    /** eds.e:1447		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_41vLastErrors_16071)){
            _9706 = SEQ_PTR(_41vLastErrors_16071)->length;
    }
    else {
        _9706 = 1;
    }
    if (_9706 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_17222);
    DeRef(_tables_17223);
    DeRef(_nt_17224);
    DeRef(_t_header_17225);
    DeRef(_name_ptr_17226);
    return -1;
L1: 

    /** eds.e:1448		tables = get4()*/
    _0 = _tables_17223;
    _tables_17223 = _41get4();
    DeRef(_0);

    /** eds.e:1449		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17223);
    DeRef(_seek_1__tmp_at44_17236);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _tables_17223;
    _seek_1__tmp_at44_17236 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_17235 = machine(19, _seek_1__tmp_at44_17236);
    DeRef(_seek_1__tmp_at44_17236);
    _seek_1__tmp_at44_17236 = NOVALUE;

    /** eds.e:1450		nt = get4()*/
    _0 = _nt_17224;
    _nt_17224 = _41get4();
    DeRef(_0);

    /** eds.e:1451		t_header = tables+4*/
    DeRef(_t_header_17225);
    if (IS_ATOM_INT(_tables_17223)) {
        _t_header_17225 = _tables_17223 + 4;
        if ((object)((uintptr_t)_t_header_17225 + (uintptr_t)HIGH_BITS) >= 0){
            _t_header_17225 = NewDouble((eudouble)_t_header_17225);
        }
    }
    else {
        _t_header_17225 = NewDouble(DBL_PTR(_tables_17223)->dbl + (eudouble)4);
    }

    /** eds.e:1452		for i = 1 to nt do*/
    Ref(_nt_17224);
    DeRef(_9711);
    _9711 = _nt_17224;
    {
        object _i_17240;
        _i_17240 = 1;
L2: 
        if (binary_op_a(GREATER, _i_17240, _9711)){
            goto L3; // [74] 150
        }

        /** eds.e:1453			io:seek(current_db, t_header)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_17225);
        DeRef(_seek_1__tmp_at84_17244);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _t_header_17225;
        _seek_1__tmp_at84_17244 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_17243 = machine(19, _seek_1__tmp_at84_17244);
        DeRef(_seek_1__tmp_at84_17244);
        _seek_1__tmp_at84_17244 = NOVALUE;

        /** eds.e:1454			name_ptr = get4()*/
        _0 = _name_ptr_17226;
        _name_ptr_17226 = _41get4();
        DeRef(_0);

        /** eds.e:1455			io:seek(current_db, name_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_17226);
        DeRef(_seek_1__tmp_at106_17248);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _name_ptr_17226;
        _seek_1__tmp_at106_17248 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_17247 = machine(19, _seek_1__tmp_at106_17248);
        DeRef(_seek_1__tmp_at106_17248);
        _seek_1__tmp_at106_17248 = NOVALUE;

        /** eds.e:1456			if equal_string(name) > 0 then*/
        RefDS(_name_17222);
        _9713 = _41equal_string(_name_17222);
        if (binary_op_a(LESSEQ, _9713, 0)){
            DeRef(_9713);
            _9713 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_9713);
        _9713 = NOVALUE;

        /** eds.e:1458				return t_header*/
        DeRef(_i_17240);
        DeRefDS(_name_17222);
        DeRef(_tables_17223);
        DeRef(_nt_17224);
        DeRef(_name_ptr_17226);
        return _t_header_17225;
L4: 

        /** eds.e:1460			t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_17225;
        if (IS_ATOM_INT(_t_header_17225)) {
            _t_header_17225 = _t_header_17225 + 16;
            if ((object)((uintptr_t)_t_header_17225 + (uintptr_t)HIGH_BITS) >= 0){
                _t_header_17225 = NewDouble((eudouble)_t_header_17225);
            }
        }
        else {
            _t_header_17225 = NewDouble(DBL_PTR(_t_header_17225)->dbl + (eudouble)16);
        }
        DeRef(_0);

        /** eds.e:1461		end for*/
        _0 = _i_17240;
        if (IS_ATOM_INT(_i_17240)) {
            _i_17240 = _i_17240 + 1;
            if ((object)((uintptr_t)_i_17240 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17240 = NewDouble((eudouble)_i_17240);
            }
        }
        else {
            _i_17240 = binary_op_a(PLUS, _i_17240, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_17240);
    }

    /** eds.e:1462		return -1*/
    DeRefDS(_name_17222);
    DeRef(_tables_17223);
    DeRef(_nt_17224);
    DeRef(_t_header_17225);
    DeRef(_name_ptr_17226);
    return -1;
    ;
}


object _41db_select_table(object _name_17255)
{
    object _table_17256 = NOVALUE;
    object _nkeys_17257 = NOVALUE;
    object _index_17258 = NOVALUE;
    object _block_ptr_17259 = NOVALUE;
    object _block_size_17260 = NOVALUE;
    object _blocks_17261 = NOVALUE;
    object _k_17262 = NOVALUE;
    object _seek_1__tmp_at120_17281 = NOVALUE;
    object _seek_inlined_seek_at_120_17280 = NOVALUE;
    object _pos_inlined_seek_at_117_17279 = NOVALUE;
    object _seek_1__tmp_at178_17291 = NOVALUE;
    object _seek_inlined_seek_at_178_17290 = NOVALUE;
    object _seek_1__tmp_at205_17296 = NOVALUE;
    object _seek_inlined_seek_at_205_17295 = NOVALUE;
    object _9734 = NOVALUE;
    object _9733 = NOVALUE;
    object _9730 = NOVALUE;
    object _9725 = NOVALUE;
    object _9720 = NOVALUE;
    object _9716 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1501		if equal(current_table_name, name) then*/
    if (_41current_table_name_16049 == _name_17255)
    _9716 = 1;
    else if (IS_ATOM_INT(_41current_table_name_16049) && IS_ATOM_INT(_name_17255))
    _9716 = 0;
    else
    _9716 = (compare(_41current_table_name_16049, _name_17255) == 0);
    if (_9716 == 0)
    {
        _9716 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _9716 = NOVALUE;
    }

    /** eds.e:1502			return DB_OK*/
    DeRefDS(_name_17255);
    DeRef(_table_17256);
    DeRef(_nkeys_17257);
    DeRef(_index_17258);
    DeRef(_block_ptr_17259);
    DeRef(_block_size_17260);
    return 0;
L1: 

    /** eds.e:1504		table = table_find(name)*/
    RefDS(_name_17255);
    _0 = _table_17256;
    _table_17256 = _41table_find(_name_17255);
    DeRef(_0);

    /** eds.e:1505		if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17256, -1)){
        goto L2; // [29] 40
    }

    /** eds.e:1506			return DB_OPEN_FAIL*/
    DeRefDS(_name_17255);
    DeRef(_table_17256);
    DeRef(_nkeys_17257);
    DeRef(_index_17258);
    DeRef(_block_ptr_17259);
    DeRef(_block_size_17260);
    return -1;
L2: 

    /** eds.e:1509		save_keys()*/
    _41save_keys();

    /** eds.e:1511		current_table_pos = table*/
    Ref(_table_17256);
    DeRef(_41current_table_pos_16048);
    _41current_table_pos_16048 = _table_17256;

    /** eds.e:1512		current_table_name = name*/
    RefDS(_name_17255);
    DeRef(_41current_table_name_16049);
    _41current_table_name_16049 = _name_17255;

    /** eds.e:1514		k = 0*/
    _k_17262 = 0;

    /** eds.e:1515		if caching_option = 1 then*/

    /** eds.e:1516			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_41current_table_pos_16048);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _41current_table_pos_16048;
    _9720 = MAKE_SEQ(_1);
    _k_17262 = find_from(_9720, _41cache_index_16056, 1);
    DeRefDS(_9720);
    _9720 = NOVALUE;

    /** eds.e:1517			if k != 0 then*/
    if (_k_17262 == 0)
    goto L3; // [88] 103

    /** eds.e:1518				key_pointers = key_cache[k]*/
    DeRef(_41key_pointers_16054);
    _2 = (object)SEQ_PTR(_41key_cache_16055);
    _41key_pointers_16054 = (object)*(((s1_ptr)_2)->base + _k_17262);
    Ref(_41key_pointers_16054);
L3: 

    /** eds.e:1521		if k = 0 then*/
    if (_k_17262 != 0)
    goto L4; // [106] 269

    /** eds.e:1523			io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_17256)) {
        _9725 = _table_17256 + 4;
        if ((object)((uintptr_t)_9725 + (uintptr_t)HIGH_BITS) >= 0){
            _9725 = NewDouble((eudouble)_9725);
        }
    }
    else {
        _9725 = NewDouble(DBL_PTR(_table_17256)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_117_17279);
    _pos_inlined_seek_at_117_17279 = _9725;
    _9725 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_17279);
    DeRef(_seek_1__tmp_at120_17281);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_117_17279;
    _seek_1__tmp_at120_17281 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_17280 = machine(19, _seek_1__tmp_at120_17281);
    DeRef(_pos_inlined_seek_at_117_17279);
    _pos_inlined_seek_at_117_17279 = NOVALUE;
    DeRef(_seek_1__tmp_at120_17281);
    _seek_1__tmp_at120_17281 = NOVALUE;

    /** eds.e:1524			nkeys = get4()*/
    _0 = _nkeys_17257;
    _nkeys_17257 = _41get4();
    DeRef(_0);

    /** eds.e:1525			blocks = get4()*/
    _blocks_17261 = _41get4();
    if (!IS_ATOM_INT(_blocks_17261)) {
        _1 = (object)(DBL_PTR(_blocks_17261)->dbl);
        DeRefDS(_blocks_17261);
        _blocks_17261 = _1;
    }

    /** eds.e:1526			index = get4()*/
    _0 = _index_17258;
    _index_17258 = _41get4();
    DeRef(_0);

    /** eds.e:1527			key_pointers = repeat(0, nkeys)*/
    DeRef(_41key_pointers_16054);
    _41key_pointers_16054 = Repeat(0, _nkeys_17257);

    /** eds.e:1528			k = 1*/
    _k_17262 = 1;

    /** eds.e:1529			for b = 0 to blocks-1 do*/
    _9730 = _blocks_17261 - 1;
    if ((object)((uintptr_t)_9730 +(uintptr_t) HIGH_BITS) >= 0){
        _9730 = NewDouble((eudouble)_9730);
    }
    {
        object _b_17287;
        _b_17287 = 0;
L5: 
        if (binary_op_a(GREATER, _b_17287, _9730)){
            goto L6; // [168] 268
        }

        /** eds.e:1530				io:seek(current_db, index)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_17258);
        DeRef(_seek_1__tmp_at178_17291);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _index_17258;
        _seek_1__tmp_at178_17291 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_17290 = machine(19, _seek_1__tmp_at178_17291);
        DeRef(_seek_1__tmp_at178_17291);
        _seek_1__tmp_at178_17291 = NOVALUE;

        /** eds.e:1531				block_size = get4()*/
        _0 = _block_size_17260;
        _block_size_17260 = _41get4();
        DeRef(_0);

        /** eds.e:1532				block_ptr = get4()*/
        _0 = _block_ptr_17259;
        _block_ptr_17259 = _41get4();
        DeRef(_0);

        /** eds.e:1533				io:seek(current_db, block_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_17259);
        DeRef(_seek_1__tmp_at205_17296);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _block_ptr_17259;
        _seek_1__tmp_at205_17296 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_17295 = machine(19, _seek_1__tmp_at205_17296);
        DeRef(_seek_1__tmp_at205_17296);
        _seek_1__tmp_at205_17296 = NOVALUE;

        /** eds.e:1534				for j = 1 to block_size do*/
        Ref(_block_size_17260);
        DeRef(_9733);
        _9733 = _block_size_17260;
        {
            object _j_17298;
            _j_17298 = 1;
L7: 
            if (binary_op_a(GREATER, _j_17298, _9733)){
                goto L8; // [224] 255
            }

            /** eds.e:1535					key_pointers[k] = get4()*/
            _9734 = _41get4();
            _2 = (object)SEQ_PTR(_41key_pointers_16054);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _41key_pointers_16054 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _k_17262);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9734;
            if( _1 != _9734 ){
                DeRef(_1);
            }
            _9734 = NOVALUE;

            /** eds.e:1536					k += 1*/
            _k_17262 = _k_17262 + 1;

            /** eds.e:1537				end for*/
            _0 = _j_17298;
            if (IS_ATOM_INT(_j_17298)) {
                _j_17298 = _j_17298 + 1;
                if ((object)((uintptr_t)_j_17298 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_17298 = NewDouble((eudouble)_j_17298);
                }
            }
            else {
                _j_17298 = binary_op_a(PLUS, _j_17298, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_17298);
        }

        /** eds.e:1538				index += 8*/
        _0 = _index_17258;
        if (IS_ATOM_INT(_index_17258)) {
            _index_17258 = _index_17258 + 8;
            if ((object)((uintptr_t)_index_17258 + (uintptr_t)HIGH_BITS) >= 0){
                _index_17258 = NewDouble((eudouble)_index_17258);
            }
        }
        else {
            _index_17258 = NewDouble(DBL_PTR(_index_17258)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** eds.e:1539			end for*/
        _0 = _b_17287;
        if (IS_ATOM_INT(_b_17287)) {
            _b_17287 = _b_17287 + 1;
            if ((object)((uintptr_t)_b_17287 +(uintptr_t) HIGH_BITS) >= 0){
                _b_17287 = NewDouble((eudouble)_b_17287);
            }
        }
        else {
            _b_17287 = binary_op_a(PLUS, _b_17287, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_17287);
    }
L4: 

    /** eds.e:1541		return DB_OK*/
    DeRefDS(_name_17255);
    DeRef(_table_17256);
    DeRef(_nkeys_17257);
    DeRef(_index_17258);
    DeRef(_block_ptr_17259);
    DeRef(_block_size_17260);
    DeRef(_9730);
    _9730 = NOVALUE;
    return 0;
    ;
}


object _41db_create_table(object _name_17307, object _init_records_17308)
{
    object _name_ptr_17309 = NOVALUE;
    object _nt_17310 = NOVALUE;
    object _tables_17311 = NOVALUE;
    object _newtables_17312 = NOVALUE;
    object _table_17313 = NOVALUE;
    object _records_ptr_17314 = NOVALUE;
    object _size_17315 = NOVALUE;
    object _newsize_17316 = NOVALUE;
    object _index_ptr_17317 = NOVALUE;
    object _remaining_17318 = NOVALUE;
    object _init_index_17319 = NOVALUE;
    object _seek_1__tmp_at61_17331 = NOVALUE;
    object _seek_inlined_seek_at_61_17330 = NOVALUE;
    object _seek_1__tmp_at90_17337 = NOVALUE;
    object _seek_inlined_seek_at_90_17336 = NOVALUE;
    object _pos_inlined_seek_at_87_17335 = NOVALUE;
    object _put4_1__tmp_at152_17350 = NOVALUE;
    object _seek_1__tmp_at189_17355 = NOVALUE;
    object _seek_inlined_seek_at_189_17354 = NOVALUE;
    object _pos_inlined_seek_at_186_17353 = NOVALUE;
    object _seek_1__tmp_at232_17363 = NOVALUE;
    object _seek_inlined_seek_at_232_17362 = NOVALUE;
    object _pos_inlined_seek_at_229_17361 = NOVALUE;
    object _s_inlined_putn_at_281_17371 = NOVALUE;
    object _seek_1__tmp_at309_17374 = NOVALUE;
    object _seek_inlined_seek_at_309_17373 = NOVALUE;
    object _put4_1__tmp_at324_17376 = NOVALUE;
    object _seek_1__tmp_at362_17380 = NOVALUE;
    object _seek_inlined_seek_at_362_17379 = NOVALUE;
    object _put4_1__tmp_at377_17382 = NOVALUE;
    object _s_inlined_putn_at_424_17388 = NOVALUE;
    object _put4_1__tmp_at455_17392 = NOVALUE;
    object _put4_1__tmp_at483_17394 = NOVALUE;
    object _s_inlined_putn_at_523_17399 = NOVALUE;
    object _s_inlined_putn_at_561_17405 = NOVALUE;
    object _seek_1__tmp_at603_17413 = NOVALUE;
    object _seek_inlined_seek_at_603_17412 = NOVALUE;
    object _pos_inlined_seek_at_600_17411 = NOVALUE;
    object _put4_1__tmp_at618_17415 = NOVALUE;
    object _put4_1__tmp_at646_17417 = NOVALUE;
    object _put4_1__tmp_at674_17419 = NOVALUE;
    object _put4_1__tmp_at702_17421 = NOVALUE;
    object _9781 = NOVALUE;
    object _9780 = NOVALUE;
    object _9779 = NOVALUE;
    object _9778 = NOVALUE;
    object _9777 = NOVALUE;
    object _9776 = NOVALUE;
    object _9774 = NOVALUE;
    object _9773 = NOVALUE;
    object _9772 = NOVALUE;
    object _9771 = NOVALUE;
    object _9770 = NOVALUE;
    object _9768 = NOVALUE;
    object _9767 = NOVALUE;
    object _9766 = NOVALUE;
    object _9764 = NOVALUE;
    object _9763 = NOVALUE;
    object _9762 = NOVALUE;
    object _9761 = NOVALUE;
    object _9760 = NOVALUE;
    object _9759 = NOVALUE;
    object _9758 = NOVALUE;
    object _9756 = NOVALUE;
    object _9755 = NOVALUE;
    object _9754 = NOVALUE;
    object _9751 = NOVALUE;
    object _9750 = NOVALUE;
    object _9748 = NOVALUE;
    object _9747 = NOVALUE;
    object _9745 = NOVALUE;
    object _9743 = NOVALUE;
    object _9737 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1603		if not cstring(name) then*/
    RefDS(_name_17307);
    _9737 = _9cstring(_name_17307);
    if (IS_ATOM_INT(_9737)) {
        if (_9737 != 0){
            DeRef(_9737);
            _9737 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_9737)->dbl != 0.0){
            DeRef(_9737);
            _9737 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_9737);
    _9737 = NOVALUE;

    /** eds.e:1604			return DB_BAD_NAME*/
    DeRefDS(_name_17307);
    DeRef(_name_ptr_17309);
    DeRef(_nt_17310);
    DeRef(_tables_17311);
    DeRef(_newtables_17312);
    DeRef(_table_17313);
    DeRef(_records_ptr_17314);
    DeRef(_size_17315);
    DeRef(_newsize_17316);
    DeRef(_index_ptr_17317);
    DeRef(_remaining_17318);
    return -4;
L1: 

    /** eds.e:1607		table = table_find(name)*/
    RefDS(_name_17307);
    _0 = _table_17313;
    _table_17313 = _41table_find(_name_17307);
    DeRef(_0);

    /** eds.e:1608		if table != -1 then*/
    if (binary_op_a(EQUALS, _table_17313, -1)){
        goto L2; // [29] 40
    }

    /** eds.e:1609			return DB_EXISTS_ALREADY*/
    DeRefDS(_name_17307);
    DeRef(_name_ptr_17309);
    DeRef(_nt_17310);
    DeRef(_tables_17311);
    DeRef(_newtables_17312);
    DeRef(_table_17313);
    DeRef(_records_ptr_17314);
    DeRef(_size_17315);
    DeRef(_newsize_17316);
    DeRef(_index_ptr_17317);
    DeRef(_remaining_17318);
    return -2;
L2: 

    /** eds.e:1612		if init_records < MAX_INDEX then*/
    if (_init_records_17308 >= 10)
    goto L3; // [42] 52

    /** eds.e:1613			init_records = MAX_INDEX*/
    _init_records_17308 = 10;
L3: 

    /** eds.e:1615		init_index = MAX_INDEX*/
    _init_index_17319 = 10;

    /** eds.e:1618		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at61_17331);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at61_17331 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_61_17330 = machine(19, _seek_1__tmp_at61_17331);
    DeRefi(_seek_1__tmp_at61_17331);
    _seek_1__tmp_at61_17331 = NOVALUE;

    /** eds.e:1619		tables = get4()*/
    _0 = _tables_17311;
    _tables_17311 = _41get4();
    DeRef(_0);

    /** eds.e:1620		io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_17311)) {
        _9743 = _tables_17311 - 4;
        if ((object)((uintptr_t)_9743 +(uintptr_t) HIGH_BITS) >= 0){
            _9743 = NewDouble((eudouble)_9743);
        }
    }
    else {
        _9743 = NewDouble(DBL_PTR(_tables_17311)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_87_17335);
    _pos_inlined_seek_at_87_17335 = _9743;
    _9743 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_17335);
    DeRef(_seek_1__tmp_at90_17337);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_87_17335;
    _seek_1__tmp_at90_17337 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_17336 = machine(19, _seek_1__tmp_at90_17337);
    DeRef(_pos_inlined_seek_at_87_17335);
    _pos_inlined_seek_at_87_17335 = NOVALUE;
    DeRef(_seek_1__tmp_at90_17337);
    _seek_1__tmp_at90_17337 = NOVALUE;

    /** eds.e:1621		size = get4()*/
    _0 = _size_17315;
    _size_17315 = _41get4();
    DeRef(_0);

    /** eds.e:1622		nt = get4()+1*/
    _9745 = _41get4();
    DeRef(_nt_17310);
    if (IS_ATOM_INT(_9745)) {
        _nt_17310 = _9745 + 1;
        if (_nt_17310 > MAXINT){
            _nt_17310 = NewDouble((eudouble)_nt_17310);
        }
    }
    else
    _nt_17310 = binary_op(PLUS, 1, _9745);
    DeRef(_9745);
    _9745 = NOVALUE;

    /** eds.e:1623		if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_17310)) {
        if (_nt_17310 == (short)_nt_17310){
            _9747 = _nt_17310 * 16;
        }
        else{
            _9747 = NewDouble(_nt_17310 * (eudouble)16);
        }
    }
    else {
        _9747 = NewDouble(DBL_PTR(_nt_17310)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_9747)) {
        _9748 = _9747 + 8;
        if ((object)((uintptr_t)_9748 + (uintptr_t)HIGH_BITS) >= 0){
            _9748 = NewDouble((eudouble)_9748);
        }
    }
    else {
        _9748 = NewDouble(DBL_PTR(_9747)->dbl + (eudouble)8);
    }
    DeRef(_9747);
    _9747 = NOVALUE;
    if (binary_op_a(LESSEQ, _9748, _size_17315)){
        DeRef(_9748);
        _9748 = NOVALUE;
        goto L4; // [127] 358
    }
    DeRef(_9748);
    _9748 = NOVALUE;

    /** eds.e:1625			newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_17315)) {
        if (_size_17315 & 1) {
            _9750 = NewDouble((_size_17315 >> 1) + 0.5);
        }
        else
        _9750 = _size_17315 >> 1;
    }
    else {
        _9750 = binary_op(DIVIDE, _size_17315, 2);
    }
    if (IS_ATOM_INT(_size_17315) && IS_ATOM_INT(_9750)) {
        _9751 = _size_17315 + _9750;
        if ((object)((uintptr_t)_9751 + (uintptr_t)HIGH_BITS) >= 0){
            _9751 = NewDouble((eudouble)_9751);
        }
    }
    else {
        if (IS_ATOM_INT(_size_17315)) {
            _9751 = NewDouble((eudouble)_size_17315 + DBL_PTR(_9750)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9750)) {
                _9751 = NewDouble(DBL_PTR(_size_17315)->dbl + (eudouble)_9750);
            }
            else
            _9751 = NewDouble(DBL_PTR(_size_17315)->dbl + DBL_PTR(_9750)->dbl);
        }
    }
    DeRef(_9750);
    _9750 = NOVALUE;
    DeRef(_newsize_17316);
    if (IS_ATOM_INT(_9751))
    _newsize_17316 = e_floor(_9751);
    else
    _newsize_17316 = unary_op(FLOOR, _9751);
    DeRef(_9751);
    _9751 = NOVALUE;

    /** eds.e:1626			newtables = db_allocate(newsize)*/
    Ref(_newsize_17316);
    _0 = _newtables_17312;
    _newtables_17312 = _41db_allocate(_newsize_17316);
    DeRef(_0);

    /** eds.e:1627			put4(nt)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_nt_17310)) {
        *poke4_addr = (uint32_t)_nt_17310;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nt_17310)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at152_17350);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at152_17350 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at152_17350); // DJP 

    /** eds.e:444	end procedure*/
    goto L5; // [173] 176
L5: 
    DeRefi(_put4_1__tmp_at152_17350);
    _put4_1__tmp_at152_17350 = NOVALUE;

    /** eds.e:1629			io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_17311)) {
        _9754 = _tables_17311 + 4;
        if ((object)((uintptr_t)_9754 + (uintptr_t)HIGH_BITS) >= 0){
            _9754 = NewDouble((eudouble)_9754);
        }
    }
    else {
        _9754 = NewDouble(DBL_PTR(_tables_17311)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_186_17353);
    _pos_inlined_seek_at_186_17353 = _9754;
    _9754 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_186_17353);
    DeRef(_seek_1__tmp_at189_17355);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_186_17353;
    _seek_1__tmp_at189_17355 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_189_17354 = machine(19, _seek_1__tmp_at189_17355);
    DeRef(_pos_inlined_seek_at_186_17353);
    _pos_inlined_seek_at_186_17353 = NOVALUE;
    DeRef(_seek_1__tmp_at189_17355);
    _seek_1__tmp_at189_17355 = NOVALUE;

    /** eds.e:1630			remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_17310)) {
        _9755 = _nt_17310 - 1;
        if ((object)((uintptr_t)_9755 +(uintptr_t) HIGH_BITS) >= 0){
            _9755 = NewDouble((eudouble)_9755);
        }
    }
    else {
        _9755 = NewDouble(DBL_PTR(_nt_17310)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9755)) {
        if (_9755 == (short)_9755){
            _9756 = _9755 * 16;
        }
        else{
            _9756 = NewDouble(_9755 * (eudouble)16);
        }
    }
    else {
        _9756 = NewDouble(DBL_PTR(_9755)->dbl * (eudouble)16);
    }
    DeRef(_9755);
    _9755 = NOVALUE;
    _0 = _remaining_17318;
    _remaining_17318 = _18get_bytes(_41current_db_16047, _9756);
    DeRef(_0);
    _9756 = NOVALUE;

    /** eds.e:1631			io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_17312)) {
        _9758 = _newtables_17312 + 4;
        if ((object)((uintptr_t)_9758 + (uintptr_t)HIGH_BITS) >= 0){
            _9758 = NewDouble((eudouble)_9758);
        }
    }
    else {
        _9758 = NewDouble(DBL_PTR(_newtables_17312)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_229_17361);
    _pos_inlined_seek_at_229_17361 = _9758;
    _9758 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_229_17361);
    DeRef(_seek_1__tmp_at232_17363);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_229_17361;
    _seek_1__tmp_at232_17363 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_232_17362 = machine(19, _seek_1__tmp_at232_17363);
    DeRef(_pos_inlined_seek_at_229_17361);
    _pos_inlined_seek_at_229_17361 = NOVALUE;
    DeRef(_seek_1__tmp_at232_17363);
    _seek_1__tmp_at232_17363 = NOVALUE;

    /** eds.e:1632			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _remaining_17318); // DJP 

    /** eds.e:449	end procedure*/
    goto L6; // [256] 259
L6: 

    /** eds.e:1634			putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_17316)) {
        _9759 = _newsize_17316 - 4;
        if ((object)((uintptr_t)_9759 +(uintptr_t) HIGH_BITS) >= 0){
            _9759 = NewDouble((eudouble)_9759);
        }
    }
    else {
        _9759 = NewDouble(DBL_PTR(_newsize_17316)->dbl - (eudouble)4);
    }
    if (IS_ATOM_INT(_nt_17310)) {
        _9760 = _nt_17310 - 1;
        if ((object)((uintptr_t)_9760 +(uintptr_t) HIGH_BITS) >= 0){
            _9760 = NewDouble((eudouble)_9760);
        }
    }
    else {
        _9760 = NewDouble(DBL_PTR(_nt_17310)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9760)) {
        if (_9760 == (short)_9760){
            _9761 = _9760 * 16;
        }
        else{
            _9761 = NewDouble(_9760 * (eudouble)16);
        }
    }
    else {
        _9761 = NewDouble(DBL_PTR(_9760)->dbl * (eudouble)16);
    }
    DeRef(_9760);
    _9760 = NOVALUE;
    if (IS_ATOM_INT(_9759) && IS_ATOM_INT(_9761)) {
        _9762 = _9759 - _9761;
    }
    else {
        if (IS_ATOM_INT(_9759)) {
            _9762 = NewDouble((eudouble)_9759 - DBL_PTR(_9761)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9761)) {
                _9762 = NewDouble(DBL_PTR(_9759)->dbl - (eudouble)_9761);
            }
            else
            _9762 = NewDouble(DBL_PTR(_9759)->dbl - DBL_PTR(_9761)->dbl);
        }
    }
    DeRef(_9759);
    _9759 = NOVALUE;
    DeRef(_9761);
    _9761 = NOVALUE;
    _9763 = Repeat(0, _9762);
    DeRef(_9762);
    _9762 = NOVALUE;
    DeRefi(_s_inlined_putn_at_281_17371);
    _s_inlined_putn_at_281_17371 = _9763;
    _9763 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_281_17371); // DJP 

    /** eds.e:449	end procedure*/
    goto L7; // [295] 298
L7: 
    DeRefi(_s_inlined_putn_at_281_17371);
    _s_inlined_putn_at_281_17371 = NOVALUE;

    /** eds.e:1635			db_free(tables)*/
    Ref(_tables_17311);
    _41db_free(_tables_17311);

    /** eds.e:1636			io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at309_17374);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at309_17374 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_309_17373 = machine(19, _seek_1__tmp_at309_17374);
    DeRefi(_seek_1__tmp_at309_17374);
    _seek_1__tmp_at309_17374 = NOVALUE;

    /** eds.e:1637			put4(newtables)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_newtables_17312)) {
        *poke4_addr = (uint32_t)_newtables_17312;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_newtables_17312)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at324_17376);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at324_17376 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at324_17376); // DJP 

    /** eds.e:444	end procedure*/
    goto L8; // [345] 348
L8: 
    DeRefi(_put4_1__tmp_at324_17376);
    _put4_1__tmp_at324_17376 = NOVALUE;

    /** eds.e:1638			tables = newtables*/
    Ref(_newtables_17312);
    DeRef(_tables_17311);
    _tables_17311 = _newtables_17312;
    goto L9; // [355] 404
L4: 

    /** eds.e:1640			io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17311);
    DeRef(_seek_1__tmp_at362_17380);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _tables_17311;
    _seek_1__tmp_at362_17380 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_362_17379 = machine(19, _seek_1__tmp_at362_17380);
    DeRef(_seek_1__tmp_at362_17380);
    _seek_1__tmp_at362_17380 = NOVALUE;

    /** eds.e:1641			put4(nt)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_nt_17310)) {
        *poke4_addr = (uint32_t)_nt_17310;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nt_17310)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at377_17382);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at377_17382 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at377_17382); // DJP 

    /** eds.e:444	end procedure*/
    goto LA; // [398] 401
LA: 
    DeRefi(_put4_1__tmp_at377_17382);
    _put4_1__tmp_at377_17382 = NOVALUE;
L9: 

    /** eds.e:1645		records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_17308 == (short)_init_records_17308){
        _9764 = _init_records_17308 * 4;
    }
    else{
        _9764 = NewDouble(_init_records_17308 * (eudouble)4);
    }
    _0 = _records_ptr_17314;
    _records_ptr_17314 = _41db_allocate(_9764);
    DeRef(_0);
    _9764 = NOVALUE;

    /** eds.e:1646		putn(repeat(0, init_records * 4))*/
    _9766 = _init_records_17308 * 4;
    _9767 = Repeat(0, _9766);
    _9766 = NOVALUE;
    DeRefi(_s_inlined_putn_at_424_17388);
    _s_inlined_putn_at_424_17388 = _9767;
    _9767 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_424_17388); // DJP 

    /** eds.e:449	end procedure*/
    goto LB; // [438] 441
LB: 
    DeRefi(_s_inlined_putn_at_424_17388);
    _s_inlined_putn_at_424_17388 = NOVALUE;

    /** eds.e:1649		index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_17319 == (short)_init_index_17319){
        _9768 = _init_index_17319 * 8;
    }
    else{
        _9768 = NewDouble(_init_index_17319 * (eudouble)8);
    }
    _0 = _index_ptr_17317;
    _index_ptr_17317 = _41db_allocate(_9768);
    DeRef(_0);
    _9768 = NOVALUE;

    /** eds.e:1650		put4(0)  -- 0 records*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at455_17392);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at455_17392 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at455_17392); // DJP 

    /** eds.e:444	end procedure*/
    goto LC; // [476] 479
LC: 
    DeRefi(_put4_1__tmp_at455_17392);
    _put4_1__tmp_at455_17392 = NOVALUE;

    /** eds.e:1651		put4(records_ptr) -- point to 1st block*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_17314)) {
        *poke4_addr = (uint32_t)_records_ptr_17314;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_records_ptr_17314)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at483_17394);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at483_17394 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at483_17394); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [504] 507
LD: 
    DeRefi(_put4_1__tmp_at483_17394);
    _put4_1__tmp_at483_17394 = NOVALUE;

    /** eds.e:1652		putn(repeat(0, (init_index-1) * 8))*/
    _9770 = _init_index_17319 - 1;
    if ((object)((uintptr_t)_9770 +(uintptr_t) HIGH_BITS) >= 0){
        _9770 = NewDouble((eudouble)_9770);
    }
    if (IS_ATOM_INT(_9770)) {
        _9771 = _9770 * 8;
    }
    else {
        _9771 = NewDouble(DBL_PTR(_9770)->dbl * (eudouble)8);
    }
    DeRef(_9770);
    _9770 = NOVALUE;
    _9772 = Repeat(0, _9771);
    DeRef(_9771);
    _9771 = NOVALUE;
    DeRefi(_s_inlined_putn_at_523_17399);
    _s_inlined_putn_at_523_17399 = _9772;
    _9772 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_523_17399); // DJP 

    /** eds.e:449	end procedure*/
    goto LE; // [537] 540
LE: 
    DeRefi(_s_inlined_putn_at_523_17399);
    _s_inlined_putn_at_523_17399 = NOVALUE;

    /** eds.e:1655		name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_17307)){
            _9773 = SEQ_PTR(_name_17307)->length;
    }
    else {
        _9773 = 1;
    }
    _9774 = _9773 + 1;
    _9773 = NOVALUE;
    _0 = _name_ptr_17309;
    _name_ptr_17309 = _41db_allocate(_9774);
    DeRef(_0);
    _9774 = NOVALUE;

    /** eds.e:1656		putn(name & 0)*/
    Append(&_9776, _name_17307, 0);
    DeRef(_s_inlined_putn_at_561_17405);
    _s_inlined_putn_at_561_17405 = _9776;
    _9776 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_561_17405); // DJP 

    /** eds.e:449	end procedure*/
    goto LF; // [575] 578
LF: 
    DeRef(_s_inlined_putn_at_561_17405);
    _s_inlined_putn_at_561_17405 = NOVALUE;

    /** eds.e:1658		io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_17311)) {
        _9777 = _tables_17311 + 4;
        if ((object)((uintptr_t)_9777 + (uintptr_t)HIGH_BITS) >= 0){
            _9777 = NewDouble((eudouble)_9777);
        }
    }
    else {
        _9777 = NewDouble(DBL_PTR(_tables_17311)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_nt_17310)) {
        _9778 = _nt_17310 - 1;
        if ((object)((uintptr_t)_9778 +(uintptr_t) HIGH_BITS) >= 0){
            _9778 = NewDouble((eudouble)_9778);
        }
    }
    else {
        _9778 = NewDouble(DBL_PTR(_nt_17310)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9778)) {
        if (_9778 == (short)_9778){
            _9779 = _9778 * 16;
        }
        else{
            _9779 = NewDouble(_9778 * (eudouble)16);
        }
    }
    else {
        _9779 = NewDouble(DBL_PTR(_9778)->dbl * (eudouble)16);
    }
    DeRef(_9778);
    _9778 = NOVALUE;
    if (IS_ATOM_INT(_9777) && IS_ATOM_INT(_9779)) {
        _9780 = _9777 + _9779;
        if ((object)((uintptr_t)_9780 + (uintptr_t)HIGH_BITS) >= 0){
            _9780 = NewDouble((eudouble)_9780);
        }
    }
    else {
        if (IS_ATOM_INT(_9777)) {
            _9780 = NewDouble((eudouble)_9777 + DBL_PTR(_9779)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9779)) {
                _9780 = NewDouble(DBL_PTR(_9777)->dbl + (eudouble)_9779);
            }
            else
            _9780 = NewDouble(DBL_PTR(_9777)->dbl + DBL_PTR(_9779)->dbl);
        }
    }
    DeRef(_9777);
    _9777 = NOVALUE;
    DeRef(_9779);
    _9779 = NOVALUE;
    DeRef(_pos_inlined_seek_at_600_17411);
    _pos_inlined_seek_at_600_17411 = _9780;
    _9780 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_600_17411);
    DeRef(_seek_1__tmp_at603_17413);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_600_17411;
    _seek_1__tmp_at603_17413 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_603_17412 = machine(19, _seek_1__tmp_at603_17413);
    DeRef(_pos_inlined_seek_at_600_17411);
    _pos_inlined_seek_at_600_17411 = NOVALUE;
    DeRef(_seek_1__tmp_at603_17413);
    _seek_1__tmp_at603_17413 = NOVALUE;

    /** eds.e:1659		put4(name_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_17309)) {
        *poke4_addr = (uint32_t)_name_ptr_17309;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_name_ptr_17309)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at618_17415);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at618_17415 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at618_17415); // DJP 

    /** eds.e:444	end procedure*/
    goto L10; // [639] 642
L10: 
    DeRefi(_put4_1__tmp_at618_17415);
    _put4_1__tmp_at618_17415 = NOVALUE;

    /** eds.e:1660		put4(0)  -- start with 0 records total*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)0;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at646_17417);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at646_17417 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at646_17417); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [667] 670
L11: 
    DeRefi(_put4_1__tmp_at646_17417);
    _put4_1__tmp_at646_17417 = NOVALUE;

    /** eds.e:1661		put4(1)  -- start with 1 block of records in index*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)1;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at674_17419);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at674_17419 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at674_17419); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [695] 698
L12: 
    DeRefi(_put4_1__tmp_at674_17419);
    _put4_1__tmp_at674_17419 = NOVALUE;

    /** eds.e:1662		put4(index_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_17317)) {
        *poke4_addr = (uint32_t)_index_ptr_17317;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_index_ptr_17317)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at702_17421);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at702_17421 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at702_17421); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [723] 726
L13: 
    DeRefi(_put4_1__tmp_at702_17421);
    _put4_1__tmp_at702_17421 = NOVALUE;

    /** eds.e:1663		if db_select_table(name) then*/
    RefDS(_name_17307);
    _9781 = _41db_select_table(_name_17307);
    if (_9781 == 0) {
        DeRef(_9781);
        _9781 = NOVALUE;
        goto L14; // [734] 738
    }
    else {
        if (!IS_ATOM_INT(_9781) && DBL_PTR(_9781)->dbl == 0.0){
            DeRef(_9781);
            _9781 = NOVALUE;
            goto L14; // [734] 738
        }
        DeRef(_9781);
        _9781 = NOVALUE;
    }
    DeRef(_9781);
    _9781 = NOVALUE;
L14: 

    /** eds.e:1665		return DB_OK*/
    DeRefDS(_name_17307);
    DeRef(_name_ptr_17309);
    DeRef(_nt_17310);
    DeRef(_tables_17311);
    DeRef(_newtables_17312);
    DeRef(_table_17313);
    DeRef(_records_ptr_17314);
    DeRef(_size_17315);
    DeRef(_newsize_17316);
    DeRef(_index_ptr_17317);
    DeRef(_remaining_17318);
    return 0;
    ;
}


object _41db_table_list()
{
    object _seek_1__tmp_at120_17678 = NOVALUE;
    object _seek_inlined_seek_at_120_17677 = NOVALUE;
    object _seek_1__tmp_at98_17674 = NOVALUE;
    object _seek_inlined_seek_at_98_17673 = NOVALUE;
    object _pos_inlined_seek_at_95_17672 = NOVALUE;
    object _seek_1__tmp_at42_17662 = NOVALUE;
    object _seek_inlined_seek_at_42_17661 = NOVALUE;
    object _seek_1__tmp_at4_17655 = NOVALUE;
    object _seek_inlined_seek_at_4_17654 = NOVALUE;
    object _table_names_17649 = NOVALUE;
    object _tables_17650 = NOVALUE;
    object _nt_17651 = NOVALUE;
    object _name_17652 = NOVALUE;
    object _9878 = NOVALUE;
    object _9877 = NOVALUE;
    object _9875 = NOVALUE;
    object _9874 = NOVALUE;
    object _9873 = NOVALUE;
    object _9872 = NOVALUE;
    object _9867 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1923		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17655);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = 3;
    _seek_1__tmp_at4_17655 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17654 = machine(19, _seek_1__tmp_at4_17655);
    DeRefi(_seek_1__tmp_at4_17655);
    _seek_1__tmp_at4_17655 = NOVALUE;

    /** eds.e:1924		if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_41vLastErrors_16071)){
            _9867 = SEQ_PTR(_41vLastErrors_16071)->length;
    }
    else {
        _9867 = 1;
    }
    if (_9867 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_17649);
    DeRef(_tables_17650);
    DeRef(_nt_17651);
    DeRef(_name_17652);
    return _5;
L1: 

    /** eds.e:1925		tables = get4()*/
    _0 = _tables_17650;
    _tables_17650 = _41get4();
    DeRef(_0);

    /** eds.e:1926		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17650);
    DeRef(_seek_1__tmp_at42_17662);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _tables_17650;
    _seek_1__tmp_at42_17662 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_17661 = machine(19, _seek_1__tmp_at42_17662);
    DeRef(_seek_1__tmp_at42_17662);
    _seek_1__tmp_at42_17662 = NOVALUE;

    /** eds.e:1927		nt = get4()*/
    _0 = _nt_17651;
    _nt_17651 = _41get4();
    DeRef(_0);

    /** eds.e:1928		table_names = repeat(0, nt)*/
    DeRef(_table_names_17649);
    _table_names_17649 = Repeat(0, _nt_17651);

    /** eds.e:1929		for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_17651)) {
        _9872 = _nt_17651 - 1;
        if ((object)((uintptr_t)_9872 +(uintptr_t) HIGH_BITS) >= 0){
            _9872 = NewDouble((eudouble)_9872);
        }
    }
    else {
        _9872 = NewDouble(DBL_PTR(_nt_17651)->dbl - (eudouble)1);
    }
    {
        object _i_17666;
        _i_17666 = 0;
L2: 
        if (binary_op_a(GREATER, _i_17666, _9872)){
            goto L3; // [73] 154
        }

        /** eds.e:1930			io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_17650)) {
            _9873 = _tables_17650 + 4;
            if ((object)((uintptr_t)_9873 + (uintptr_t)HIGH_BITS) >= 0){
                _9873 = NewDouble((eudouble)_9873);
            }
        }
        else {
            _9873 = NewDouble(DBL_PTR(_tables_17650)->dbl + (eudouble)4);
        }
        if (IS_ATOM_INT(_i_17666)) {
            if (_i_17666 == (short)_i_17666){
                _9874 = _i_17666 * 16;
            }
            else{
                _9874 = NewDouble(_i_17666 * (eudouble)16);
            }
        }
        else {
            _9874 = NewDouble(DBL_PTR(_i_17666)->dbl * (eudouble)16);
        }
        if (IS_ATOM_INT(_9873) && IS_ATOM_INT(_9874)) {
            _9875 = _9873 + _9874;
            if ((object)((uintptr_t)_9875 + (uintptr_t)HIGH_BITS) >= 0){
                _9875 = NewDouble((eudouble)_9875);
            }
        }
        else {
            if (IS_ATOM_INT(_9873)) {
                _9875 = NewDouble((eudouble)_9873 + DBL_PTR(_9874)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9874)) {
                    _9875 = NewDouble(DBL_PTR(_9873)->dbl + (eudouble)_9874);
                }
                else
                _9875 = NewDouble(DBL_PTR(_9873)->dbl + DBL_PTR(_9874)->dbl);
            }
        }
        DeRef(_9873);
        _9873 = NOVALUE;
        DeRef(_9874);
        _9874 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_17672);
        _pos_inlined_seek_at_95_17672 = _9875;
        _9875 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_17672);
        DeRef(_seek_1__tmp_at98_17674);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_95_17672;
        _seek_1__tmp_at98_17674 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_17673 = machine(19, _seek_1__tmp_at98_17674);
        DeRef(_pos_inlined_seek_at_95_17672);
        _pos_inlined_seek_at_95_17672 = NOVALUE;
        DeRef(_seek_1__tmp_at98_17674);
        _seek_1__tmp_at98_17674 = NOVALUE;

        /** eds.e:1931			name = get4()*/
        _0 = _name_17652;
        _name_17652 = _41get4();
        DeRef(_0);

        /** eds.e:1932			io:seek(current_db, name)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_17652);
        DeRef(_seek_1__tmp_at120_17678);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16047;
        ((intptr_t *)_2)[2] = _name_17652;
        _seek_1__tmp_at120_17678 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_17677 = machine(19, _seek_1__tmp_at120_17678);
        DeRef(_seek_1__tmp_at120_17678);
        _seek_1__tmp_at120_17678 = NOVALUE;

        /** eds.e:1933			table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_17666)) {
            _9877 = _i_17666 + 1;
            if (_9877 > MAXINT){
                _9877 = NewDouble((eudouble)_9877);
            }
        }
        else
        _9877 = binary_op(PLUS, 1, _i_17666);
        _9878 = _41get_string();
        _2 = (object)SEQ_PTR(_table_names_17649);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _table_names_17649 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_9877))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_9877)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _9877);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _9878;
        if( _1 != _9878 ){
            DeRef(_1);
        }
        _9878 = NOVALUE;

        /** eds.e:1934		end for*/
        _0 = _i_17666;
        if (IS_ATOM_INT(_i_17666)) {
            _i_17666 = _i_17666 + 1;
            if ((object)((uintptr_t)_i_17666 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17666 = NewDouble((eudouble)_i_17666);
            }
        }
        else {
            _i_17666 = binary_op_a(PLUS, _i_17666, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_17666);
    }

    /** eds.e:1935		return table_names*/
    DeRef(_tables_17650);
    DeRef(_nt_17651);
    DeRef(_name_17652);
    DeRef(_9872);
    _9872 = NOVALUE;
    DeRef(_9877);
    _9877 = NOVALUE;
    return _table_names_17649;
    ;
}


object _41key_value(object _ptr_17683)
{
    object _seek_1__tmp_at11_17688 = NOVALUE;
    object _seek_inlined_seek_at_11_17687 = NOVALUE;
    object _pos_inlined_seek_at_8_17686 = NOVALUE;
    object _9880 = NOVALUE;
    object _9879 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1941		io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_17683)) {
        _9879 = _ptr_17683 + 4;
        if ((object)((uintptr_t)_9879 + (uintptr_t)HIGH_BITS) >= 0){
            _9879 = NewDouble((eudouble)_9879);
        }
    }
    else {
        _9879 = NewDouble(DBL_PTR(_ptr_17683)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_8_17686);
    _pos_inlined_seek_at_8_17686 = _9879;
    _9879 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17686);
    DeRef(_seek_1__tmp_at11_17688);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_17686;
    _seek_1__tmp_at11_17688 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17687 = machine(19, _seek_1__tmp_at11_17688);
    DeRef(_pos_inlined_seek_at_8_17686);
    _pos_inlined_seek_at_8_17686 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17688);
    _seek_1__tmp_at11_17688 = NOVALUE;

    /** eds.e:1942		return decompress(0)*/
    _9880 = _41decompress(0);
    DeRef(_ptr_17683);
    return _9880;
    ;
}


object _41db_find_key(object _key_17692, object _table_name_17693)
{
    object _lo_17694 = NOVALUE;
    object _hi_17695 = NOVALUE;
    object _mid_17696 = NOVALUE;
    object _c_17697 = NOVALUE;
    object _9904 = NOVALUE;
    object _9896 = NOVALUE;
    object _9895 = NOVALUE;
    object _9893 = NOVALUE;
    object _9890 = NOVALUE;
    object _9887 = NOVALUE;
    object _9883 = NOVALUE;
    object _9881 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2003		if not equal(table_name, current_table_name) then*/
    if (_table_name_17693 == _41current_table_name_16049)
    _9881 = 1;
    else if (IS_ATOM_INT(_table_name_17693) && IS_ATOM_INT(_41current_table_name_16049))
    _9881 = 0;
    else
    _9881 = (compare(_table_name_17693, _41current_table_name_16049) == 0);
    if (_9881 != 0)
    goto L1; // [9] 42
    _9881 = NOVALUE;

    /** eds.e:2004			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17693);
    _9883 = _41db_select_table(_table_name_17693);
    if (binary_op_a(EQUALS, _9883, 0)){
        DeRef(_9883);
        _9883 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_9883);
    _9883 = NOVALUE;

    /** eds.e:2005				fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_17693);
    Ref(_key_17692);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_17692;
    ((intptr_t *)_2)[2] = _table_name_17693;
    _9887 = MAKE_SEQ(_1);
    RefDS(_9885);
    RefDS(_9886);
    _41fatal(903, _9885, _9886, _9887);
    _9887 = NOVALUE;

    /** eds.e:2006				return 0*/
    DeRef(_key_17692);
    DeRefDS(_table_name_17693);
    return 0;
L2: 
L1: 

    /** eds.e:2010		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16048, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2011			fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_17693);
    Ref(_key_17692);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_17692;
    ((intptr_t *)_2)[2] = _table_name_17693;
    _9890 = MAKE_SEQ(_1);
    RefDS(_9889);
    RefDS(_9886);
    _41fatal(903, _9889, _9886, _9890);
    _9890 = NOVALUE;

    /** eds.e:2012			return 0*/
    DeRef(_key_17692);
    DeRef(_table_name_17693);
    return 0;
L3: 

    /** eds.e:2015		lo = 1*/
    _lo_17694 = 1;

    /** eds.e:2016		hi = length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_16054)){
            _hi_17695 = SEQ_PTR(_41key_pointers_16054)->length;
    }
    else {
        _hi_17695 = 1;
    }

    /** eds.e:2017		mid = 1*/
    _mid_17696 = 1;

    /** eds.e:2018		c = 0*/
    _c_17697 = 0;

    /** eds.e:2019		while lo <= hi do*/
L4: 
    if (_lo_17694 > _hi_17695)
    goto L5; // [96] 170

    /** eds.e:2020			mid = floor((lo + hi) / 2)*/
    _9893 = _lo_17694 + _hi_17695;
    if ((object)((uintptr_t)_9893 + (uintptr_t)HIGH_BITS) >= 0){
        _9893 = NewDouble((eudouble)_9893);
    }
    if (IS_ATOM_INT(_9893)) {
        _mid_17696 = _9893 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _9893, 2);
        _mid_17696 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_9893);
    _9893 = NOVALUE;
    if (!IS_ATOM_INT(_mid_17696)) {
        _1 = (object)(DBL_PTR(_mid_17696)->dbl);
        DeRefDS(_mid_17696);
        _mid_17696 = _1;
    }

    /** eds.e:2021			c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (object)SEQ_PTR(_41key_pointers_16054);
    _9895 = (object)*(((s1_ptr)_2)->base + _mid_17696);
    Ref(_9895);
    _9896 = _41key_value(_9895);
    _9895 = NOVALUE;
    if (IS_ATOM_INT(_key_17692) && IS_ATOM_INT(_9896)){
        _c_17697 = (_key_17692 < _9896) ? -1 : (_key_17692 > _9896);
    }
    else{
        _c_17697 = compare(_key_17692, _9896);
    }
    DeRef(_9896);
    _9896 = NOVALUE;

    /** eds.e:2022			if c < 0 then*/
    if (_c_17697 >= 0)
    goto L6; // [130] 143

    /** eds.e:2023				hi = mid - 1*/
    _hi_17695 = _mid_17696 - 1;
    goto L4; // [140] 96
L6: 

    /** eds.e:2024			elsif c > 0 then*/
    if (_c_17697 <= 0)
    goto L7; // [145] 158

    /** eds.e:2025				lo = mid + 1*/
    _lo_17694 = _mid_17696 + 1;
    goto L4; // [155] 96
L7: 

    /** eds.e:2027				return mid*/
    DeRef(_key_17692);
    DeRef(_table_name_17693);
    return _mid_17696;

    /** eds.e:2029		end while*/
    goto L4; // [167] 96
L5: 

    /** eds.e:2031		if c > 0 then*/
    if (_c_17697 <= 0)
    goto L8; // [172] 183

    /** eds.e:2032			mid += 1*/
    _mid_17696 = _mid_17696 + 1;
L8: 

    /** eds.e:2034		return -mid*/
    if ((uintptr_t)_mid_17696 == (uintptr_t)HIGH_BITS){
        _9904 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _9904 = - _mid_17696;
    }
    DeRef(_key_17692);
    DeRef(_table_name_17693);
    return _9904;
    ;
}


object _41db_insert(object _key_17732, object _data_17733, object _table_name_17734)
{
    object _key_string_17735 = NOVALUE;
    object _data_string_17736 = NOVALUE;
    object _last_part_17737 = NOVALUE;
    object _remaining_17738 = NOVALUE;
    object _key_ptr_17739 = NOVALUE;
    object _data_ptr_17740 = NOVALUE;
    object _records_ptr_17741 = NOVALUE;
    object _nrecs_17742 = NOVALUE;
    object _current_block_17743 = NOVALUE;
    object _size_17744 = NOVALUE;
    object _new_size_17745 = NOVALUE;
    object _key_location_17746 = NOVALUE;
    object _new_block_17747 = NOVALUE;
    object _index_ptr_17748 = NOVALUE;
    object _new_index_ptr_17749 = NOVALUE;
    object _total_recs_17750 = NOVALUE;
    object _r_17751 = NOVALUE;
    object _blocks_17752 = NOVALUE;
    object _new_recs_17753 = NOVALUE;
    object _n_17754 = NOVALUE;
    object _put4_1__tmp_at79_17768 = NOVALUE;
    object _seek_1__tmp_at132_17774 = NOVALUE;
    object _seek_inlined_seek_at_132_17773 = NOVALUE;
    object _pos_inlined_seek_at_129_17772 = NOVALUE;
    object _seek_1__tmp_at174_17782 = NOVALUE;
    object _seek_inlined_seek_at_174_17781 = NOVALUE;
    object _pos_inlined_seek_at_171_17780 = NOVALUE;
    object _put4_1__tmp_at189_17784 = NOVALUE;
    object _seek_1__tmp_at317_17801 = NOVALUE;
    object _seek_inlined_seek_at_317_17800 = NOVALUE;
    object _pos_inlined_seek_at_314_17799 = NOVALUE;
    object _seek_1__tmp_at339_17805 = NOVALUE;
    object _seek_inlined_seek_at_339_17804 = NOVALUE;
    object _where_inlined_where_at_404_17814 = NOVALUE;
    object _seek_1__tmp_at448_17824 = NOVALUE;
    object _seek_inlined_seek_at_448_17823 = NOVALUE;
    object _pos_inlined_seek_at_445_17822 = NOVALUE;
    object _put4_1__tmp_at493_17833 = NOVALUE;
    object _x_inlined_put4_at_490_17832 = NOVALUE;
    object _seek_1__tmp_at530_17836 = NOVALUE;
    object _seek_inlined_seek_at_530_17835 = NOVALUE;
    object _put4_1__tmp_at551_17839 = NOVALUE;
    object _seek_1__tmp_at588_17844 = NOVALUE;
    object _seek_inlined_seek_at_588_17843 = NOVALUE;
    object _pos_inlined_seek_at_585_17842 = NOVALUE;
    object _seek_1__tmp_at690_17867 = NOVALUE;
    object _seek_inlined_seek_at_690_17866 = NOVALUE;
    object _pos_inlined_seek_at_687_17865 = NOVALUE;
    object _s_inlined_putn_at_751_17876 = NOVALUE;
    object _seek_1__tmp_at774_17879 = NOVALUE;
    object _seek_inlined_seek_at_774_17878 = NOVALUE;
    object _put4_1__tmp_at796_17883 = NOVALUE;
    object _x_inlined_put4_at_793_17882 = NOVALUE;
    object _seek_1__tmp_at833_17888 = NOVALUE;
    object _seek_inlined_seek_at_833_17887 = NOVALUE;
    object _pos_inlined_seek_at_830_17886 = NOVALUE;
    object _seek_1__tmp_at884_17898 = NOVALUE;
    object _seek_inlined_seek_at_884_17897 = NOVALUE;
    object _pos_inlined_seek_at_881_17896 = NOVALUE;
    object _put4_1__tmp_at899_17900 = NOVALUE;
    object _put4_1__tmp_at927_17902 = NOVALUE;
    object _seek_1__tmp_at980_17908 = NOVALUE;
    object _seek_inlined_seek_at_980_17907 = NOVALUE;
    object _pos_inlined_seek_at_977_17906 = NOVALUE;
    object _put4_1__tmp_at1001_17911 = NOVALUE;
    object _seek_1__tmp_at1038_17916 = NOVALUE;
    object _seek_inlined_seek_at_1038_17915 = NOVALUE;
    object _pos_inlined_seek_at_1035_17914 = NOVALUE;
    object _s_inlined_putn_at_1136_17934 = NOVALUE;
    object _seek_1__tmp_at1173_17939 = NOVALUE;
    object _seek_inlined_seek_at_1173_17938 = NOVALUE;
    object _pos_inlined_seek_at_1170_17937 = NOVALUE;
    object _put4_1__tmp_at1188_17941 = NOVALUE;
    object _9997 = NOVALUE;
    object _9996 = NOVALUE;
    object _9995 = NOVALUE;
    object _9994 = NOVALUE;
    object _9991 = NOVALUE;
    object _9990 = NOVALUE;
    object _9988 = NOVALUE;
    object _9986 = NOVALUE;
    object _9985 = NOVALUE;
    object _9983 = NOVALUE;
    object _9982 = NOVALUE;
    object _9980 = NOVALUE;
    object _9979 = NOVALUE;
    object _9977 = NOVALUE;
    object _9976 = NOVALUE;
    object _9975 = NOVALUE;
    object _9974 = NOVALUE;
    object _9973 = NOVALUE;
    object _9972 = NOVALUE;
    object _9971 = NOVALUE;
    object _9970 = NOVALUE;
    object _9969 = NOVALUE;
    object _9966 = NOVALUE;
    object _9965 = NOVALUE;
    object _9964 = NOVALUE;
    object _9963 = NOVALUE;
    object _9960 = NOVALUE;
    object _9957 = NOVALUE;
    object _9956 = NOVALUE;
    object _9955 = NOVALUE;
    object _9954 = NOVALUE;
    object _9952 = NOVALUE;
    object _9951 = NOVALUE;
    object _9949 = NOVALUE;
    object _9948 = NOVALUE;
    object _9946 = NOVALUE;
    object _9945 = NOVALUE;
    object _9944 = NOVALUE;
    object _9943 = NOVALUE;
    object _9942 = NOVALUE;
    object _9941 = NOVALUE;
    object _9940 = NOVALUE;
    object _9938 = NOVALUE;
    object _9935 = NOVALUE;
    object _9930 = NOVALUE;
    object _9929 = NOVALUE;
    object _9928 = NOVALUE;
    object _9926 = NOVALUE;
    object _9925 = NOVALUE;
    object _9924 = NOVALUE;
    object _9921 = NOVALUE;
    object _9919 = NOVALUE;
    object _9916 = NOVALUE;
    object _9915 = NOVALUE;
    object _9913 = NOVALUE;
    object _9912 = NOVALUE;
    object _9910 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2071		key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_17732);
    RefDS(_table_name_17734);
    _0 = _key_location_17746;
    _key_location_17746 = _41db_find_key(_key_17732, _table_name_17734);
    DeRef(_0);

    /** eds.e:2073		if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_17746, 0)){
        goto L1; // [10] 21
    }

    /** eds.e:2075			return DB_EXISTS_ALREADY*/
    DeRef(_key_17732);
    DeRefDS(_table_name_17734);
    DeRef(_key_string_17735);
    DeRef(_data_string_17736);
    DeRef(_last_part_17737);
    DeRef(_remaining_17738);
    DeRef(_key_ptr_17739);
    DeRef(_data_ptr_17740);
    DeRef(_records_ptr_17741);
    DeRef(_nrecs_17742);
    DeRef(_current_block_17743);
    DeRef(_size_17744);
    DeRef(_new_size_17745);
    DeRef(_key_location_17746);
    DeRef(_new_block_17747);
    DeRef(_index_ptr_17748);
    DeRef(_new_index_ptr_17749);
    DeRef(_total_recs_17750);
    return -2;
L1: 

    /** eds.e:2077		key_location = -key_location*/
    _0 = _key_location_17746;
    if (IS_ATOM_INT(_key_location_17746)) {
        if ((uintptr_t)_key_location_17746 == (uintptr_t)HIGH_BITS){
            _key_location_17746 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _key_location_17746 = - _key_location_17746;
        }
    }
    else {
        _key_location_17746 = unary_op(UMINUS, _key_location_17746);
    }
    DeRef(_0);

    /** eds.e:2079		data_string = compress(data)*/
    _0 = _data_string_17736;
    _data_string_17736 = _41compress(_data_17733);
    DeRef(_0);

    /** eds.e:2080		key_string  = compress(key)*/
    Ref(_key_17732);
    _0 = _key_string_17735;
    _key_string_17735 = _41compress(_key_17732);
    DeRef(_0);

    /** eds.e:2082		data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_17736)){
            _9910 = SEQ_PTR(_data_string_17736)->length;
    }
    else {
        _9910 = 1;
    }
    _0 = _data_ptr_17740;
    _data_ptr_17740 = _41db_allocate(_9910);
    DeRef(_0);
    _9910 = NOVALUE;

    /** eds.e:2083		putn(data_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _data_string_17736); // DJP 

    /** eds.e:449	end procedure*/
    goto L2; // [62] 65
L2: 

    /** eds.e:2085		key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_17735)){
            _9912 = SEQ_PTR(_key_string_17735)->length;
    }
    else {
        _9912 = 1;
    }
    _9913 = 4 + _9912;
    _9912 = NOVALUE;
    _0 = _key_ptr_17739;
    _key_ptr_17739 = _41db_allocate(_9913);
    DeRef(_0);
    _9913 = NOVALUE;

    /** eds.e:2086		put4(data_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_17740)) {
        *poke4_addr = (uint32_t)_data_ptr_17740;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_data_ptr_17740)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_17768);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at79_17768 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at79_17768); // DJP 

    /** eds.e:444	end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_17768);
    _put4_1__tmp_at79_17768 = NOVALUE;

    /** eds.e:2087		putn(key_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _key_string_17735); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [117] 120
L4: 

    /** eds.e:2091		io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_41current_table_pos_16048)) {
        _9915 = _41current_table_pos_16048 + 4;
        if ((object)((uintptr_t)_9915 + (uintptr_t)HIGH_BITS) >= 0){
            _9915 = NewDouble((eudouble)_9915);
        }
    }
    else {
        _9915 = NewDouble(DBL_PTR(_41current_table_pos_16048)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_129_17772);
    _pos_inlined_seek_at_129_17772 = _9915;
    _9915 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_17772);
    DeRef(_seek_1__tmp_at132_17774);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_129_17772;
    _seek_1__tmp_at132_17774 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_17773 = machine(19, _seek_1__tmp_at132_17774);
    DeRef(_pos_inlined_seek_at_129_17772);
    _pos_inlined_seek_at_129_17772 = NOVALUE;
    DeRef(_seek_1__tmp_at132_17774);
    _seek_1__tmp_at132_17774 = NOVALUE;

    /** eds.e:2092		total_recs = get4()+1*/
    _9916 = _41get4();
    DeRef(_total_recs_17750);
    if (IS_ATOM_INT(_9916)) {
        _total_recs_17750 = _9916 + 1;
        if (_total_recs_17750 > MAXINT){
            _total_recs_17750 = NewDouble((eudouble)_total_recs_17750);
        }
    }
    else
    _total_recs_17750 = binary_op(PLUS, 1, _9916);
    DeRef(_9916);
    _9916 = NOVALUE;

    /** eds.e:2093		blocks = get4()*/
    _blocks_17752 = _41get4();
    if (!IS_ATOM_INT(_blocks_17752)) {
        _1 = (object)(DBL_PTR(_blocks_17752)->dbl);
        DeRefDS(_blocks_17752);
        _blocks_17752 = _1;
    }

    /** eds.e:2094		io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_41current_table_pos_16048)) {
        _9919 = _41current_table_pos_16048 + 4;
        if ((object)((uintptr_t)_9919 + (uintptr_t)HIGH_BITS) >= 0){
            _9919 = NewDouble((eudouble)_9919);
        }
    }
    else {
        _9919 = NewDouble(DBL_PTR(_41current_table_pos_16048)->dbl + (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_171_17780);
    _pos_inlined_seek_at_171_17780 = _9919;
    _9919 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_17780);
    DeRef(_seek_1__tmp_at174_17782);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_171_17780;
    _seek_1__tmp_at174_17782 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_17781 = machine(19, _seek_1__tmp_at174_17782);
    DeRef(_pos_inlined_seek_at_171_17780);
    _pos_inlined_seek_at_171_17780 = NOVALUE;
    DeRef(_seek_1__tmp_at174_17782);
    _seek_1__tmp_at174_17782 = NOVALUE;

    /** eds.e:2095		put4(total_recs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_17750)) {
        *poke4_addr = (uint32_t)_total_recs_17750;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_total_recs_17750)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_17784);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at189_17784 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at189_17784); // DJP 

    /** eds.e:444	end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_17784);
    _put4_1__tmp_at189_17784 = NOVALUE;

    /** eds.e:2097		n = length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_16054)){
            _n_17754 = SEQ_PTR(_41key_pointers_16054)->length;
    }
    else {
        _n_17754 = 1;
    }

    /** eds.e:2098		if key_location >= floor(n/2) then*/
    _9921 = _n_17754 >> 1;
    if (binary_op_a(LESS, _key_location_17746, _9921)){
        _9921 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_9921);
    _9921 = NOVALUE;

    /** eds.e:2100			key_pointers = append(key_pointers, 0)*/
    Append(&_41key_pointers_16054, _41key_pointers_16054, 0);

    /** eds.e:2102			key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_17746)) {
        _9924 = _key_location_17746 + 1;
        if (_9924 > MAXINT){
            _9924 = NewDouble((eudouble)_9924);
        }
    }
    else
    _9924 = binary_op(PLUS, 1, _key_location_17746);
    _9925 = _n_17754 + 1;
    rhs_slice_target = (object_ptr)&_9926;
    RHS_Slice(_41key_pointers_16054, _key_location_17746, _n_17754);
    assign_slice_seq = (s1_ptr *)&_41key_pointers_16054;
    AssignSlice(_9924, _9925, _9926);
    DeRef(_9924);
    _9924 = NOVALUE;
    _9925 = NOVALUE;
    DeRefDS(_9926);
    _9926 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** eds.e:2105			key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_41key_pointers_16054, _41key_pointers_16054, 0);

    /** eds.e:2107			key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_17746)) {
        _9928 = _key_location_17746 - 1;
        if ((object)((uintptr_t)_9928 +(uintptr_t) HIGH_BITS) >= 0){
            _9928 = NewDouble((eudouble)_9928);
        }
    }
    else {
        _9928 = NewDouble(DBL_PTR(_key_location_17746)->dbl - (eudouble)1);
    }
    rhs_slice_target = (object_ptr)&_9929;
    RHS_Slice(_41key_pointers_16054, 2, _key_location_17746);
    assign_slice_seq = (s1_ptr *)&_41key_pointers_16054;
    AssignSlice(1, _9928, _9929);
    DeRef(_9928);
    _9928 = NOVALUE;
    DeRefDS(_9929);
    _9929 = NOVALUE;
L7: 

    /** eds.e:2109		key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_17739);
    _2 = (object)SEQ_PTR(_41key_pointers_16054);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _41key_pointers_16054 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_17746))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_key_location_17746)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _key_location_17746);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _key_ptr_17739;
    DeRef(_1);

    /** eds.e:2111		io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_41current_table_pos_16048)) {
        _9930 = _41current_table_pos_16048 + 12;
        if ((object)((uintptr_t)_9930 + (uintptr_t)HIGH_BITS) >= 0){
            _9930 = NewDouble((eudouble)_9930);
        }
    }
    else {
        _9930 = NewDouble(DBL_PTR(_41current_table_pos_16048)->dbl + (eudouble)12);
    }
    DeRef(_pos_inlined_seek_at_314_17799);
    _pos_inlined_seek_at_314_17799 = _9930;
    _9930 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_17799);
    DeRef(_seek_1__tmp_at317_17801);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_314_17799;
    _seek_1__tmp_at317_17801 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_17800 = machine(19, _seek_1__tmp_at317_17801);
    DeRef(_pos_inlined_seek_at_314_17799);
    _pos_inlined_seek_at_314_17799 = NOVALUE;
    DeRef(_seek_1__tmp_at317_17801);
    _seek_1__tmp_at317_17801 = NOVALUE;

    /** eds.e:2112		index_ptr = get4()*/
    _0 = _index_ptr_17748;
    _index_ptr_17748 = _41get4();
    DeRef(_0);

    /** eds.e:2114		io:seek(current_db, index_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_17748);
    DeRef(_seek_1__tmp_at339_17805);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _index_ptr_17748;
    _seek_1__tmp_at339_17805 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_17804 = machine(19, _seek_1__tmp_at339_17805);
    DeRef(_seek_1__tmp_at339_17805);
    _seek_1__tmp_at339_17805 = NOVALUE;

    /** eds.e:2115		r = 0*/
    _r_17751 = 0;

    /** eds.e:2116		while TRUE do*/
L8: 

    /** eds.e:2117			nrecs = get4()*/
    _0 = _nrecs_17742;
    _nrecs_17742 = _41get4();
    DeRef(_0);

    /** eds.e:2118			records_ptr = get4()*/
    _0 = _records_ptr_17741;
    _records_ptr_17741 = _41get4();
    DeRef(_0);

    /** eds.e:2119			r += nrecs*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _r_17751 = _r_17751 + _nrecs_17742;
    }
    else {
        _r_17751 = NewDouble((eudouble)_r_17751 + DBL_PTR(_nrecs_17742)->dbl);
    }
    if (!IS_ATOM_INT(_r_17751)) {
        _1 = (object)(DBL_PTR(_r_17751)->dbl);
        DeRefDS(_r_17751);
        _r_17751 = _1;
    }

    /** eds.e:2120			if r + 1 >= key_location then*/
    _9935 = _r_17751 + 1;
    if (_9935 > MAXINT){
        _9935 = NewDouble((eudouble)_9935);
    }
    if (binary_op_a(LESS, _9935, _key_location_17746)){
        DeRef(_9935);
        _9935 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_9935);
    _9935 = NOVALUE;

    /** eds.e:2121				exit*/
    goto L9; // [393] 401

    /** eds.e:2123		end while*/
    goto L8; // [398] 363
L9: 

    /** eds.e:2125		current_block = io:where(current_db)-8*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_17814);
    _where_inlined_where_at_404_17814 = machine(20, _41current_db_16047);
    DeRef(_current_block_17743);
    if (IS_ATOM_INT(_where_inlined_where_at_404_17814)) {
        _current_block_17743 = _where_inlined_where_at_404_17814 - 8;
        if ((object)((uintptr_t)_current_block_17743 +(uintptr_t) HIGH_BITS) >= 0){
            _current_block_17743 = NewDouble((eudouble)_current_block_17743);
        }
    }
    else {
        _current_block_17743 = NewDouble(DBL_PTR(_where_inlined_where_at_404_17814)->dbl - (eudouble)8);
    }

    /** eds.e:2127		key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _9938 = _r_17751 - _nrecs_17742;
        if ((object)((uintptr_t)_9938 +(uintptr_t) HIGH_BITS) >= 0){
            _9938 = NewDouble((eudouble)_9938);
        }
    }
    else {
        _9938 = NewDouble((eudouble)_r_17751 - DBL_PTR(_nrecs_17742)->dbl);
    }
    _0 = _key_location_17746;
    if (IS_ATOM_INT(_key_location_17746) && IS_ATOM_INT(_9938)) {
        _key_location_17746 = _key_location_17746 - _9938;
        if ((object)((uintptr_t)_key_location_17746 +(uintptr_t) HIGH_BITS) >= 0){
            _key_location_17746 = NewDouble((eudouble)_key_location_17746);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_17746)) {
            _key_location_17746 = NewDouble((eudouble)_key_location_17746 - DBL_PTR(_9938)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9938)) {
                _key_location_17746 = NewDouble(DBL_PTR(_key_location_17746)->dbl - (eudouble)_9938);
            }
            else
            _key_location_17746 = NewDouble(DBL_PTR(_key_location_17746)->dbl - DBL_PTR(_9938)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_9938);
    _9938 = NOVALUE;

    /** eds.e:2129		io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_17746)) {
        _9940 = _key_location_17746 - 1;
        if ((object)((uintptr_t)_9940 +(uintptr_t) HIGH_BITS) >= 0){
            _9940 = NewDouble((eudouble)_9940);
        }
    }
    else {
        _9940 = NewDouble(DBL_PTR(_key_location_17746)->dbl - (eudouble)1);
    }
    if (IS_ATOM_INT(_9940)) {
        if (_9940 <= INT15 && _9940 >= -INT15){
            _9941 = 4 * _9940;
        }
        else{
            _9941 = NewDouble(4 * (eudouble)_9940);
        }
    }
    else {
        _9941 = NewDouble((eudouble)4 * DBL_PTR(_9940)->dbl);
    }
    DeRef(_9940);
    _9940 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_17741) && IS_ATOM_INT(_9941)) {
        _9942 = _records_ptr_17741 + _9941;
        if ((object)((uintptr_t)_9942 + (uintptr_t)HIGH_BITS) >= 0){
            _9942 = NewDouble((eudouble)_9942);
        }
    }
    else {
        if (IS_ATOM_INT(_records_ptr_17741)) {
            _9942 = NewDouble((eudouble)_records_ptr_17741 + DBL_PTR(_9941)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9941)) {
                _9942 = NewDouble(DBL_PTR(_records_ptr_17741)->dbl + (eudouble)_9941);
            }
            else
            _9942 = NewDouble(DBL_PTR(_records_ptr_17741)->dbl + DBL_PTR(_9941)->dbl);
        }
    }
    DeRef(_9941);
    _9941 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_17822);
    _pos_inlined_seek_at_445_17822 = _9942;
    _9942 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_17822);
    DeRef(_seek_1__tmp_at448_17824);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_445_17822;
    _seek_1__tmp_at448_17824 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_17823 = machine(19, _seek_1__tmp_at448_17824);
    DeRef(_pos_inlined_seek_at_445_17822);
    _pos_inlined_seek_at_445_17822 = NOVALUE;
    DeRef(_seek_1__tmp_at448_17824);
    _seek_1__tmp_at448_17824 = NOVALUE;

    /** eds.e:2130		for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _9943 = _nrecs_17742 + 1;
        if (_9943 > MAXINT){
            _9943 = NewDouble((eudouble)_9943);
        }
    }
    else
    _9943 = binary_op(PLUS, 1, _nrecs_17742);
    {
        object _i_17826;
        Ref(_key_location_17746);
        _i_17826 = _key_location_17746;
LA: 
        if (binary_op_a(GREATER, _i_17826, _9943)){
            goto LB; // [468] 527
        }

        /** eds.e:2131			put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_17826)) {
            _9944 = _i_17826 + _r_17751;
            if ((object)((uintptr_t)_9944 + (uintptr_t)HIGH_BITS) >= 0){
                _9944 = NewDouble((eudouble)_9944);
            }
        }
        else {
            _9944 = NewDouble(DBL_PTR(_i_17826)->dbl + (eudouble)_r_17751);
        }
        if (IS_ATOM_INT(_9944) && IS_ATOM_INT(_nrecs_17742)) {
            _9945 = _9944 - _nrecs_17742;
        }
        else {
            if (IS_ATOM_INT(_9944)) {
                _9945 = NewDouble((eudouble)_9944 - DBL_PTR(_nrecs_17742)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_17742)) {
                    _9945 = NewDouble(DBL_PTR(_9944)->dbl - (eudouble)_nrecs_17742);
                }
                else
                _9945 = NewDouble(DBL_PTR(_9944)->dbl - DBL_PTR(_nrecs_17742)->dbl);
            }
        }
        DeRef(_9944);
        _9944 = NOVALUE;
        _2 = (object)SEQ_PTR(_41key_pointers_16054);
        if (!IS_ATOM_INT(_9945)){
            _9946 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_9945)->dbl));
        }
        else{
            _9946 = (object)*(((s1_ptr)_2)->base + _9945);
        }
        Ref(_9946);
        DeRef(_x_inlined_put4_at_490_17832);
        _x_inlined_put4_at_490_17832 = _9946;
        _9946 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16089)){
            poke4_addr = (uint32_t *)_41mem0_16089;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_17832)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_490_17832;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_17832)) {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_490_17832)->dbl;
        }
        else {
            _1 = (object)SEQ_PTR(_x_inlined_put4_at_490_17832);
            _1 = (object)((s1_ptr)_1)->base;
            while (1) {
                _1 += sizeof(object);
                _2 = *((object *)_1);
                if (IS_ATOM_INT(_2)) {
                    *poke4_addr++ = (int32_t)_2;
                }
                else if (_2 == NOVALUE) {
                    break;
                }
                else {
                    *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_17833);
        _1 = (object)SEQ_PTR(_41memseq_16313);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at493_17833 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16047, _put4_1__tmp_at493_17833); // DJP 

        /** eds.e:444	end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_17832);
        _x_inlined_put4_at_490_17832 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_17833);
        _put4_1__tmp_at493_17833 = NOVALUE;

        /** eds.e:2132		end for*/
        _0 = _i_17826;
        if (IS_ATOM_INT(_i_17826)) {
            _i_17826 = _i_17826 + 1;
            if ((object)((uintptr_t)_i_17826 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17826 = NewDouble((eudouble)_i_17826);
            }
        }
        else {
            _i_17826 = binary_op_a(PLUS, _i_17826, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_17826);
    }

    /** eds.e:2135		io:seek(current_db, current_block)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_17743);
    DeRef(_seek_1__tmp_at530_17836);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _current_block_17743;
    _seek_1__tmp_at530_17836 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_17835 = machine(19, _seek_1__tmp_at530_17836);
    DeRef(_seek_1__tmp_at530_17836);
    _seek_1__tmp_at530_17836 = NOVALUE;

    /** eds.e:2136		nrecs += 1*/
    _0 = _nrecs_17742;
    if (IS_ATOM_INT(_nrecs_17742)) {
        _nrecs_17742 = _nrecs_17742 + 1;
        if (_nrecs_17742 > MAXINT){
            _nrecs_17742 = NewDouble((eudouble)_nrecs_17742);
        }
    }
    else
    _nrecs_17742 = binary_op(PLUS, 1, _nrecs_17742);
    DeRef(_0);

    /** eds.e:2137		put4(nrecs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_17742)) {
        *poke4_addr = (uint32_t)_nrecs_17742;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nrecs_17742)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_17839);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at551_17839 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at551_17839); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_17839);
    _put4_1__tmp_at551_17839 = NOVALUE;

    /** eds.e:2140		io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_17741)) {
        _9948 = _records_ptr_17741 - 4;
        if ((object)((uintptr_t)_9948 +(uintptr_t) HIGH_BITS) >= 0){
            _9948 = NewDouble((eudouble)_9948);
        }
    }
    else {
        _9948 = NewDouble(DBL_PTR(_records_ptr_17741)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_585_17842);
    _pos_inlined_seek_at_585_17842 = _9948;
    _9948 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_17842);
    DeRef(_seek_1__tmp_at588_17844);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_585_17842;
    _seek_1__tmp_at588_17844 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_17843 = machine(19, _seek_1__tmp_at588_17844);
    DeRef(_pos_inlined_seek_at_585_17842);
    _pos_inlined_seek_at_585_17842 = NOVALUE;
    DeRef(_seek_1__tmp_at588_17844);
    _seek_1__tmp_at588_17844 = NOVALUE;

    /** eds.e:2141		size = get4() - 4*/
    _9949 = _41get4();
    DeRef(_size_17744);
    if (IS_ATOM_INT(_9949)) {
        _size_17744 = _9949 - 4;
        if ((object)((uintptr_t)_size_17744 +(uintptr_t) HIGH_BITS) >= 0){
            _size_17744 = NewDouble((eudouble)_size_17744);
        }
    }
    else {
        _size_17744 = binary_op(MINUS, _9949, 4);
    }
    DeRef(_9949);
    _9949 = NOVALUE;

    /** eds.e:2142		if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        if (_nrecs_17742 == (short)_nrecs_17742){
            _9951 = _nrecs_17742 * 4;
        }
        else{
            _9951 = NewDouble(_nrecs_17742 * (eudouble)4);
        }
    }
    else {
        _9951 = NewDouble(DBL_PTR(_nrecs_17742)->dbl * (eudouble)4);
    }
    if (IS_ATOM_INT(_size_17744)) {
        _9952 = _size_17744 - 4;
        if ((object)((uintptr_t)_9952 +(uintptr_t) HIGH_BITS) >= 0){
            _9952 = NewDouble((eudouble)_9952);
        }
    }
    else {
        _9952 = NewDouble(DBL_PTR(_size_17744)->dbl - (eudouble)4);
    }
    if (binary_op_a(LESSEQ, _9951, _9952)){
        DeRef(_9951);
        _9951 = NOVALUE;
        DeRef(_9952);
        _9952 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_9951);
    _9951 = NOVALUE;
    DeRef(_9952);
    _9952 = NOVALUE;

    /** eds.e:2150			new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_17750)) {
        _9954 = NewDouble(DBL_PTR(_8639)->dbl * (eudouble)_total_recs_17750);
    }
    else
    _9954 = NewDouble(DBL_PTR(_8639)->dbl * DBL_PTR(_total_recs_17750)->dbl);
    _9955 = unary_op(SQRT, _9954);
    DeRefDS(_9954);
    _9954 = NOVALUE;
    _9956 = unary_op(FLOOR, _9955);
    DeRefDS(_9955);
    _9955 = NOVALUE;
    if (IS_ATOM_INT(_9956)) {
        _9957 = 20 + _9956;
        if ((object)((uintptr_t)_9957 + (uintptr_t)HIGH_BITS) >= 0){
            _9957 = NewDouble((eudouble)_9957);
        }
    }
    else {
        _9957 = binary_op(PLUS, 20, _9956);
    }
    DeRef(_9956);
    _9956 = NOVALUE;
    DeRef(_new_size_17745);
    if (IS_ATOM_INT(_9957)) {
        if (_9957 <= INT15 && _9957 >= -INT15){
            _new_size_17745 = 8 * _9957;
        }
        else{
            _new_size_17745 = NewDouble(8 * (eudouble)_9957);
        }
    }
    else {
        _new_size_17745 = binary_op(MULTIPLY, 8, _9957);
    }
    DeRef(_9957);
    _9957 = NOVALUE;

    /** eds.e:2152			new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_17745)) {
        if (8 > 0 && _new_size_17745 >= 0) {
            _new_recs_17753 = _new_size_17745 / 8;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_new_size_17745 / (eudouble)8);
            _new_recs_17753 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_17745, 8);
        _new_recs_17753 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_17753)) {
        _1 = (object)(DBL_PTR(_new_recs_17753)->dbl);
        DeRefDS(_new_recs_17753);
        _new_recs_17753 = _1;
    }

    /** eds.e:2153			if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _9960 = _nrecs_17742 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_17742, 2);
        _9960 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_17753, _9960)){
        DeRef(_9960);
        _9960 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_9960);
    _9960 = NOVALUE;

    /** eds.e:2154				new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _new_recs_17753 = _nrecs_17742 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_17742, 2);
        _new_recs_17753 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_17753)) {
        _1 = (object)(DBL_PTR(_new_recs_17753)->dbl);
        DeRefDS(_new_recs_17753);
        _new_recs_17753 = _1;
    }
LF: 

    /** eds.e:2158			io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _9963 = _nrecs_17742 - _new_recs_17753;
        if ((object)((uintptr_t)_9963 +(uintptr_t) HIGH_BITS) >= 0){
            _9963 = NewDouble((eudouble)_9963);
        }
    }
    else {
        _9963 = NewDouble(DBL_PTR(_nrecs_17742)->dbl - (eudouble)_new_recs_17753);
    }
    if (IS_ATOM_INT(_9963)) {
        if (_9963 == (short)_9963){
            _9964 = _9963 * 4;
        }
        else{
            _9964 = NewDouble(_9963 * (eudouble)4);
        }
    }
    else {
        _9964 = NewDouble(DBL_PTR(_9963)->dbl * (eudouble)4);
    }
    DeRef(_9963);
    _9963 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_17741) && IS_ATOM_INT(_9964)) {
        _9965 = _records_ptr_17741 + _9964;
        if ((object)((uintptr_t)_9965 + (uintptr_t)HIGH_BITS) >= 0){
            _9965 = NewDouble((eudouble)_9965);
        }
    }
    else {
        if (IS_ATOM_INT(_records_ptr_17741)) {
            _9965 = NewDouble((eudouble)_records_ptr_17741 + DBL_PTR(_9964)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9964)) {
                _9965 = NewDouble(DBL_PTR(_records_ptr_17741)->dbl + (eudouble)_9964);
            }
            else
            _9965 = NewDouble(DBL_PTR(_records_ptr_17741)->dbl + DBL_PTR(_9964)->dbl);
        }
    }
    DeRef(_9964);
    _9964 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_17865);
    _pos_inlined_seek_at_687_17865 = _9965;
    _9965 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_17865);
    DeRef(_seek_1__tmp_at690_17867);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_687_17865;
    _seek_1__tmp_at690_17867 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_17866 = machine(19, _seek_1__tmp_at690_17867);
    DeRef(_pos_inlined_seek_at_687_17865);
    _pos_inlined_seek_at_687_17865 = NOVALUE;
    DeRef(_seek_1__tmp_at690_17867);
    _seek_1__tmp_at690_17867 = NOVALUE;

    /** eds.e:2159			last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_17753 == (short)_new_recs_17753){
        _9966 = _new_recs_17753 * 4;
    }
    else{
        _9966 = NewDouble(_new_recs_17753 * (eudouble)4);
    }
    _0 = _last_part_17737;
    _last_part_17737 = _18get_bytes(_41current_db_16047, _9966);
    DeRef(_0);
    _9966 = NOVALUE;

    /** eds.e:2160			new_block = db_allocate(new_size)*/
    Ref(_new_size_17745);
    _0 = _new_block_17747;
    _new_block_17747 = _41db_allocate(_new_size_17745);
    DeRef(_0);

    /** eds.e:2161			putn(last_part)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _last_part_17737); // DJP 

    /** eds.e:449	end procedure*/
    goto L10; // [736] 739
L10: 

    /** eds.e:2163			putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_17737)){
            _9969 = SEQ_PTR(_last_part_17737)->length;
    }
    else {
        _9969 = 1;
    }
    if (IS_ATOM_INT(_new_size_17745)) {
        _9970 = _new_size_17745 - _9969;
    }
    else {
        _9970 = NewDouble(DBL_PTR(_new_size_17745)->dbl - (eudouble)_9969);
    }
    _9969 = NOVALUE;
    _9971 = Repeat(0, _9970);
    DeRef(_9970);
    _9970 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_17876);
    _s_inlined_putn_at_751_17876 = _9971;
    _9971 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_751_17876); // DJP 

    /** eds.e:449	end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_17876);
    _s_inlined_putn_at_751_17876 = NOVALUE;

    /** eds.e:2166			io:seek(current_db, current_block)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_17743);
    DeRef(_seek_1__tmp_at774_17879);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _current_block_17743;
    _seek_1__tmp_at774_17879 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_17878 = machine(19, _seek_1__tmp_at774_17879);
    DeRef(_seek_1__tmp_at774_17879);
    _seek_1__tmp_at774_17879 = NOVALUE;

    /** eds.e:2167			put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_17742)) {
        _9972 = _nrecs_17742 - _new_recs_17753;
        if ((object)((uintptr_t)_9972 +(uintptr_t) HIGH_BITS) >= 0){
            _9972 = NewDouble((eudouble)_9972);
        }
    }
    else {
        _9972 = NewDouble(DBL_PTR(_nrecs_17742)->dbl - (eudouble)_new_recs_17753);
    }
    DeRef(_x_inlined_put4_at_793_17882);
    _x_inlined_put4_at_793_17882 = _9972;
    _9972 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_17882)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_793_17882;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_793_17882)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_17883);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at796_17883 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at796_17883); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_17882);
    _x_inlined_put4_at_793_17882 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_17883);
    _put4_1__tmp_at796_17883 = NOVALUE;

    /** eds.e:2170			io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_17743)) {
        _9973 = _current_block_17743 + 8;
        if ((object)((uintptr_t)_9973 + (uintptr_t)HIGH_BITS) >= 0){
            _9973 = NewDouble((eudouble)_9973);
        }
    }
    else {
        _9973 = NewDouble(DBL_PTR(_current_block_17743)->dbl + (eudouble)8);
    }
    DeRef(_pos_inlined_seek_at_830_17886);
    _pos_inlined_seek_at_830_17886 = _9973;
    _9973 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_17886);
    DeRef(_seek_1__tmp_at833_17888);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_830_17886;
    _seek_1__tmp_at833_17888 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_17887 = machine(19, _seek_1__tmp_at833_17888);
    DeRef(_pos_inlined_seek_at_830_17886);
    _pos_inlined_seek_at_830_17886 = NOVALUE;
    DeRef(_seek_1__tmp_at833_17888);
    _seek_1__tmp_at833_17888 = NOVALUE;

    /** eds.e:2171			remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_17752 == (short)_blocks_17752){
        _9974 = _blocks_17752 * 8;
    }
    else{
        _9974 = NewDouble(_blocks_17752 * (eudouble)8);
    }
    if (IS_ATOM_INT(_index_ptr_17748) && IS_ATOM_INT(_9974)) {
        _9975 = _index_ptr_17748 + _9974;
        if ((object)((uintptr_t)_9975 + (uintptr_t)HIGH_BITS) >= 0){
            _9975 = NewDouble((eudouble)_9975);
        }
    }
    else {
        if (IS_ATOM_INT(_index_ptr_17748)) {
            _9975 = NewDouble((eudouble)_index_ptr_17748 + DBL_PTR(_9974)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9974)) {
                _9975 = NewDouble(DBL_PTR(_index_ptr_17748)->dbl + (eudouble)_9974);
            }
            else
            _9975 = NewDouble(DBL_PTR(_index_ptr_17748)->dbl + DBL_PTR(_9974)->dbl);
        }
    }
    DeRef(_9974);
    _9974 = NOVALUE;
    if (IS_ATOM_INT(_current_block_17743)) {
        _9976 = _current_block_17743 + 8;
        if ((object)((uintptr_t)_9976 + (uintptr_t)HIGH_BITS) >= 0){
            _9976 = NewDouble((eudouble)_9976);
        }
    }
    else {
        _9976 = NewDouble(DBL_PTR(_current_block_17743)->dbl + (eudouble)8);
    }
    if (IS_ATOM_INT(_9975) && IS_ATOM_INT(_9976)) {
        _9977 = _9975 - _9976;
        if ((object)((uintptr_t)_9977 +(uintptr_t) HIGH_BITS) >= 0){
            _9977 = NewDouble((eudouble)_9977);
        }
    }
    else {
        if (IS_ATOM_INT(_9975)) {
            _9977 = NewDouble((eudouble)_9975 - DBL_PTR(_9976)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9976)) {
                _9977 = NewDouble(DBL_PTR(_9975)->dbl - (eudouble)_9976);
            }
            else
            _9977 = NewDouble(DBL_PTR(_9975)->dbl - DBL_PTR(_9976)->dbl);
        }
    }
    DeRef(_9975);
    _9975 = NOVALUE;
    DeRef(_9976);
    _9976 = NOVALUE;
    _0 = _remaining_17738;
    _remaining_17738 = _18get_bytes(_41current_db_16047, _9977);
    DeRef(_0);
    _9977 = NOVALUE;

    /** eds.e:2172			io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_17743)) {
        _9979 = _current_block_17743 + 8;
        if ((object)((uintptr_t)_9979 + (uintptr_t)HIGH_BITS) >= 0){
            _9979 = NewDouble((eudouble)_9979);
        }
    }
    else {
        _9979 = NewDouble(DBL_PTR(_current_block_17743)->dbl + (eudouble)8);
    }
    DeRef(_pos_inlined_seek_at_881_17896);
    _pos_inlined_seek_at_881_17896 = _9979;
    _9979 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_17896);
    DeRef(_seek_1__tmp_at884_17898);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_881_17896;
    _seek_1__tmp_at884_17898 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_17897 = machine(19, _seek_1__tmp_at884_17898);
    DeRef(_pos_inlined_seek_at_881_17896);
    _pos_inlined_seek_at_881_17896 = NOVALUE;
    DeRef(_seek_1__tmp_at884_17898);
    _seek_1__tmp_at884_17898 = NOVALUE;

    /** eds.e:2173			put4(new_recs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)_new_recs_17753;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_17900);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at899_17900 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at899_17900); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_17900);
    _put4_1__tmp_at899_17900 = NOVALUE;

    /** eds.e:2174			put4(new_block)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_new_block_17747)) {
        *poke4_addr = (uint32_t)_new_block_17747;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_new_block_17747)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_17902);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at927_17902 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at927_17902); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_17902);
    _put4_1__tmp_at927_17902 = NOVALUE;

    /** eds.e:2175			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _remaining_17738); // DJP 

    /** eds.e:449	end procedure*/
    goto L15; // [965] 968
L15: 

    /** eds.e:2176			io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_41current_table_pos_16048)) {
        _9980 = _41current_table_pos_16048 + 8;
        if ((object)((uintptr_t)_9980 + (uintptr_t)HIGH_BITS) >= 0){
            _9980 = NewDouble((eudouble)_9980);
        }
    }
    else {
        _9980 = NewDouble(DBL_PTR(_41current_table_pos_16048)->dbl + (eudouble)8);
    }
    DeRef(_pos_inlined_seek_at_977_17906);
    _pos_inlined_seek_at_977_17906 = _9980;
    _9980 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_17906);
    DeRef(_seek_1__tmp_at980_17908);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_977_17906;
    _seek_1__tmp_at980_17908 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_17907 = machine(19, _seek_1__tmp_at980_17908);
    DeRef(_pos_inlined_seek_at_977_17906);
    _pos_inlined_seek_at_977_17906 = NOVALUE;
    DeRef(_seek_1__tmp_at980_17908);
    _seek_1__tmp_at980_17908 = NOVALUE;

    /** eds.e:2177			blocks += 1*/
    _blocks_17752 = _blocks_17752 + 1;

    /** eds.e:2178			put4(blocks)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    *poke4_addr = (uint32_t)_blocks_17752;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_17911);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at1001_17911 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at1001_17911); // DJP 

    /** eds.e:444	end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_17911);
    _put4_1__tmp_at1001_17911 = NOVALUE;

    /** eds.e:2180			io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_17748)) {
        _9982 = _index_ptr_17748 - 4;
        if ((object)((uintptr_t)_9982 +(uintptr_t) HIGH_BITS) >= 0){
            _9982 = NewDouble((eudouble)_9982);
        }
    }
    else {
        _9982 = NewDouble(DBL_PTR(_index_ptr_17748)->dbl - (eudouble)4);
    }
    DeRef(_pos_inlined_seek_at_1035_17914);
    _pos_inlined_seek_at_1035_17914 = _9982;
    _9982 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_17914);
    DeRef(_seek_1__tmp_at1038_17916);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_1035_17914;
    _seek_1__tmp_at1038_17916 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_17915 = machine(19, _seek_1__tmp_at1038_17916);
    DeRef(_pos_inlined_seek_at_1035_17914);
    _pos_inlined_seek_at_1035_17914 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_17916);
    _seek_1__tmp_at1038_17916 = NOVALUE;

    /** eds.e:2181			size = get4() - 4*/
    _9983 = _41get4();
    DeRef(_size_17744);
    if (IS_ATOM_INT(_9983)) {
        _size_17744 = _9983 - 4;
        if ((object)((uintptr_t)_size_17744 +(uintptr_t) HIGH_BITS) >= 0){
            _size_17744 = NewDouble((eudouble)_size_17744);
        }
    }
    else {
        _size_17744 = binary_op(MINUS, _9983, 4);
    }
    DeRef(_9983);
    _9983 = NOVALUE;

    /** eds.e:2182			if blocks*8 > size-8 then*/
    if (_blocks_17752 == (short)_blocks_17752){
        _9985 = _blocks_17752 * 8;
    }
    else{
        _9985 = NewDouble(_blocks_17752 * (eudouble)8);
    }
    if (IS_ATOM_INT(_size_17744)) {
        _9986 = _size_17744 - 8;
        if ((object)((uintptr_t)_9986 +(uintptr_t) HIGH_BITS) >= 0){
            _9986 = NewDouble((eudouble)_9986);
        }
    }
    else {
        _9986 = NewDouble(DBL_PTR(_size_17744)->dbl - (eudouble)8);
    }
    if (binary_op_a(LESSEQ, _9985, _9986)){
        DeRef(_9985);
        _9985 = NOVALUE;
        DeRef(_9986);
        _9986 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_9985);
    _9985 = NOVALUE;
    DeRef(_9986);
    _9986 = NOVALUE;

    /** eds.e:2184				remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_17752 == (short)_blocks_17752){
        _9988 = _blocks_17752 * 8;
    }
    else{
        _9988 = NewDouble(_blocks_17752 * (eudouble)8);
    }
    _0 = _remaining_17738;
    _remaining_17738 = _18get_bytes(_41current_db_16047, _9988);
    DeRef(_0);
    _9988 = NOVALUE;

    /** eds.e:2185				new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_17744)) {
        if (_size_17744 & 1) {
            _9990 = NewDouble((_size_17744 >> 1) + 0.5);
        }
        else
        _9990 = _size_17744 >> 1;
    }
    else {
        _9990 = binary_op(DIVIDE, _size_17744, 2);
    }
    if (IS_ATOM_INT(_size_17744) && IS_ATOM_INT(_9990)) {
        _9991 = _size_17744 + _9990;
        if ((object)((uintptr_t)_9991 + (uintptr_t)HIGH_BITS) >= 0){
            _9991 = NewDouble((eudouble)_9991);
        }
    }
    else {
        if (IS_ATOM_INT(_size_17744)) {
            _9991 = NewDouble((eudouble)_size_17744 + DBL_PTR(_9990)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9990)) {
                _9991 = NewDouble(DBL_PTR(_size_17744)->dbl + (eudouble)_9990);
            }
            else
            _9991 = NewDouble(DBL_PTR(_size_17744)->dbl + DBL_PTR(_9990)->dbl);
        }
    }
    DeRef(_9990);
    _9990 = NOVALUE;
    DeRef(_new_size_17745);
    if (IS_ATOM_INT(_9991))
    _new_size_17745 = e_floor(_9991);
    else
    _new_size_17745 = unary_op(FLOOR, _9991);
    DeRef(_9991);
    _9991 = NOVALUE;

    /** eds.e:2186				new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_17745);
    _0 = _new_index_ptr_17749;
    _new_index_ptr_17749 = _41db_allocate(_new_size_17745);
    DeRef(_0);

    /** eds.e:2187				putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _remaining_17738); // DJP 

    /** eds.e:449	end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** eds.e:2188				putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_17752 == (short)_blocks_17752){
        _9994 = _blocks_17752 * 8;
    }
    else{
        _9994 = NewDouble(_blocks_17752 * (eudouble)8);
    }
    if (IS_ATOM_INT(_new_size_17745) && IS_ATOM_INT(_9994)) {
        _9995 = _new_size_17745 - _9994;
    }
    else {
        if (IS_ATOM_INT(_new_size_17745)) {
            _9995 = NewDouble((eudouble)_new_size_17745 - DBL_PTR(_9994)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9994)) {
                _9995 = NewDouble(DBL_PTR(_new_size_17745)->dbl - (eudouble)_9994);
            }
            else
            _9995 = NewDouble(DBL_PTR(_new_size_17745)->dbl - DBL_PTR(_9994)->dbl);
        }
    }
    DeRef(_9994);
    _9994 = NOVALUE;
    _9996 = Repeat(0, _9995);
    DeRef(_9995);
    _9995 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_17934);
    _s_inlined_putn_at_1136_17934 = _9996;
    _9996 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _s_inlined_putn_at_1136_17934); // DJP 

    /** eds.e:449	end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_17934);
    _s_inlined_putn_at_1136_17934 = NOVALUE;

    /** eds.e:2189				db_free(index_ptr)*/
    Ref(_index_ptr_17748);
    _41db_free(_index_ptr_17748);

    /** eds.e:2190				io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_41current_table_pos_16048)) {
        _9997 = _41current_table_pos_16048 + 12;
        if ((object)((uintptr_t)_9997 + (uintptr_t)HIGH_BITS) >= 0){
            _9997 = NewDouble((eudouble)_9997);
        }
    }
    else {
        _9997 = NewDouble(DBL_PTR(_41current_table_pos_16048)->dbl + (eudouble)12);
    }
    DeRef(_pos_inlined_seek_at_1170_17937);
    _pos_inlined_seek_at_1170_17937 = _9997;
    _9997 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_17937);
    DeRef(_seek_1__tmp_at1173_17939);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_1170_17937;
    _seek_1__tmp_at1173_17939 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_17938 = machine(19, _seek_1__tmp_at1173_17939);
    DeRef(_pos_inlined_seek_at_1170_17937);
    _pos_inlined_seek_at_1170_17937 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_17939);
    _seek_1__tmp_at1173_17939 = NOVALUE;

    /** eds.e:2191				put4(new_index_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_17749)) {
        *poke4_addr = (uint32_t)_new_index_ptr_17749;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_new_index_ptr_17749)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_17941);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at1188_17941 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at1188_17941); // DJP 

    /** eds.e:444	end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_17941);
    _put4_1__tmp_at1188_17941 = NOVALUE;
L17: 
LE: 

    /** eds.e:2194		return DB_OK*/
    DeRef(_key_17732);
    DeRef(_table_name_17734);
    DeRef(_key_string_17735);
    DeRef(_data_string_17736);
    DeRef(_last_part_17737);
    DeRef(_remaining_17738);
    DeRef(_key_ptr_17739);
    DeRef(_data_ptr_17740);
    DeRef(_records_ptr_17741);
    DeRef(_nrecs_17742);
    DeRef(_current_block_17743);
    DeRef(_size_17744);
    DeRef(_new_size_17745);
    DeRef(_key_location_17746);
    DeRef(_new_block_17747);
    DeRef(_index_ptr_17748);
    DeRef(_new_index_ptr_17749);
    DeRef(_total_recs_17750);
    DeRef(_9945);
    _9945 = NOVALUE;
    DeRef(_9943);
    _9943 = NOVALUE;
    return 0;
    ;
}


void _41db_replace_data(object _key_location_18076, object _data_18077, object _table_name_18078)
{
    object _10071 = NOVALUE;
    object _10070 = NOVALUE;
    object _10069 = NOVALUE;
    object _10068 = NOVALUE;
    object _10066 = NOVALUE;
    object _10065 = NOVALUE;
    object _10063 = NOVALUE;
    object _10060 = NOVALUE;
    object _10058 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2323		if not equal(table_name, current_table_name) then*/
    if (_table_name_18078 == _41current_table_name_16049)
    _10058 = 1;
    else if (IS_ATOM_INT(_table_name_18078) && IS_ATOM_INT(_41current_table_name_16049))
    _10058 = 0;
    else
    _10058 = (compare(_table_name_18078, _41current_table_name_16049) == 0);
    if (_10058 != 0)
    goto L1; // [11] 45
    _10058 = NOVALUE;

    /** eds.e:2324			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18078);
    _10060 = _41db_select_table(_table_name_18078);
    if (binary_op_a(EQUALS, _10060, 0)){
        DeRef(_10060);
        _10060 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10060);
    _10060 = NOVALUE;

    /** eds.e:2325				fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_18076;
    ((intptr_t*)_2)[2] = _data_18077;
    RefDS(_table_name_18078);
    ((intptr_t*)_2)[3] = _table_name_18078;
    _10063 = MAKE_SEQ(_1);
    RefDS(_9885);
    RefDS(_10062);
    _41fatal(903, _9885, _10062, _10063);
    _10063 = NOVALUE;

    /** eds.e:2326				return*/
    DeRefDS(_table_name_18078);
    return;
L2: 
L1: 

    /** eds.e:2330		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16048, -1)){
        goto L3; // [49] 73
    }

    /** eds.e:2331			fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_18076;
    ((intptr_t*)_2)[2] = _data_18077;
    Ref(_table_name_18078);
    ((intptr_t*)_2)[3] = _table_name_18078;
    _10065 = MAKE_SEQ(_1);
    RefDS(_9889);
    RefDS(_10062);
    _41fatal(903, _9889, _10062, _10065);
    _10065 = NOVALUE;

    /** eds.e:2332			return*/
    DeRef(_table_name_18078);
    return;
L3: 

    /** eds.e:2334		if key_location < 1 or key_location > length(key_pointers) then*/
    _10066 = (_key_location_18076 < 1);
    if (_10066 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_41key_pointers_16054)){
            _10068 = SEQ_PTR(_41key_pointers_16054)->length;
    }
    else {
        _10068 = 1;
    }
    _10069 = (_key_location_18076 > _10068);
    _10068 = NOVALUE;
    if (_10069 == 0)
    {
        DeRef(_10069);
        _10069 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10069);
        _10069 = NOVALUE;
    }
L4: 

    /** eds.e:2335			fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_18076;
    ((intptr_t*)_2)[2] = _data_18077;
    Ref(_table_name_18078);
    ((intptr_t*)_2)[3] = _table_name_18078;
    _10070 = MAKE_SEQ(_1);
    RefDS(_10010);
    RefDS(_10062);
    _41fatal(905, _10010, _10062, _10070);
    _10070 = NOVALUE;

    /** eds.e:2336			return*/
    DeRef(_table_name_18078);
    DeRef(_10066);
    _10066 = NOVALUE;
    return;
L5: 

    /** eds.e:2338		db_replace_recid(key_pointers[key_location], data)*/
    _2 = (object)SEQ_PTR(_41key_pointers_16054);
    _10071 = (object)*(((s1_ptr)_2)->base + _key_location_18076);
    Ref(_10071);
    _41db_replace_recid(_10071, _data_18077);
    _10071 = NOVALUE;

    /** eds.e:2339	end procedure*/
    DeRef(_table_name_18078);
    DeRef(_10066);
    _10066 = NOVALUE;
    return;
    ;
}


object _41db_table_size(object _table_name_18100)
{
    object _10080 = NOVALUE;
    object _10079 = NOVALUE;
    object _10077 = NOVALUE;
    object _10074 = NOVALUE;
    object _10072 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2369		if not equal(table_name, current_table_name) then*/
    if (_table_name_18100 == _41current_table_name_16049)
    _10072 = 1;
    else if (IS_ATOM_INT(_table_name_18100) && IS_ATOM_INT(_41current_table_name_16049))
    _10072 = 0;
    else
    _10072 = (compare(_table_name_18100, _41current_table_name_16049) == 0);
    if (_10072 != 0)
    goto L1; // [9] 42
    _10072 = NOVALUE;

    /** eds.e:2370			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18100);
    _10074 = _41db_select_table(_table_name_18100);
    if (binary_op_a(EQUALS, _10074, 0)){
        DeRef(_10074);
        _10074 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10074);
    _10074 = NOVALUE;

    /** eds.e:2371				fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_18100);
    ((intptr_t*)_2)[1] = _table_name_18100;
    _10077 = MAKE_SEQ(_1);
    RefDS(_9885);
    RefDS(_10076);
    _41fatal(903, _9885, _10076, _10077);
    _10077 = NOVALUE;

    /** eds.e:2372				return -1*/
    DeRefDS(_table_name_18100);
    return -1;
L2: 
L1: 

    /** eds.e:2376		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16048, -1)){
        goto L3; // [46] 69
    }

    /** eds.e:2377			fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_table_name_18100);
    ((intptr_t*)_2)[1] = _table_name_18100;
    _10079 = MAKE_SEQ(_1);
    RefDS(_9889);
    RefDS(_10076);
    _41fatal(903, _9889, _10076, _10079);
    _10079 = NOVALUE;

    /** eds.e:2378			return -1*/
    DeRef(_table_name_18100);
    return -1;
L3: 

    /** eds.e:2380		return length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_16054)){
            _10080 = SEQ_PTR(_41key_pointers_16054)->length;
    }
    else {
        _10080 = 1;
    }
    DeRef(_table_name_18100);
    return _10080;
    ;
}


object _41db_record_data(object _key_location_18115, object _table_name_18116)
{
    object _data_ptr_18117 = NOVALUE;
    object _data_value_18118 = NOVALUE;
    object _seek_1__tmp_at126_18140 = NOVALUE;
    object _seek_inlined_seek_at_126_18139 = NOVALUE;
    object _pos_inlined_seek_at_123_18138 = NOVALUE;
    object _seek_1__tmp_at164_18147 = NOVALUE;
    object _seek_inlined_seek_at_164_18146 = NOVALUE;
    object _10095 = NOVALUE;
    object _10094 = NOVALUE;
    object _10093 = NOVALUE;
    object _10092 = NOVALUE;
    object _10091 = NOVALUE;
    object _10089 = NOVALUE;
    object _10088 = NOVALUE;
    object _10086 = NOVALUE;
    object _10083 = NOVALUE;
    object _10081 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18115)) {
        _1 = (object)(DBL_PTR(_key_location_18115)->dbl);
        DeRefDS(_key_location_18115);
        _key_location_18115 = _1;
    }

    /** eds.e:2417		if not equal(table_name, current_table_name) then*/
    if (_table_name_18116 == _41current_table_name_16049)
    _10081 = 1;
    else if (IS_ATOM_INT(_table_name_18116) && IS_ATOM_INT(_41current_table_name_16049))
    _10081 = 0;
    else
    _10081 = (compare(_table_name_18116, _41current_table_name_16049) == 0);
    if (_10081 != 0)
    goto L1; // [11] 44
    _10081 = NOVALUE;

    /** eds.e:2418			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18116);
    _10083 = _41db_select_table(_table_name_18116);
    if (binary_op_a(EQUALS, _10083, 0)){
        DeRef(_10083);
        _10083 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10083);
    _10083 = NOVALUE;

    /** eds.e:2419				fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_18116);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18115;
    ((intptr_t *)_2)[2] = _table_name_18116;
    _10086 = MAKE_SEQ(_1);
    RefDS(_9885);
    RefDS(_10085);
    _41fatal(903, _9885, _10085, _10086);
    _10086 = NOVALUE;

    /** eds.e:2420				return -1*/
    DeRefDS(_table_name_18116);
    DeRef(_data_ptr_18117);
    DeRef(_data_value_18118);
    return -1;
L2: 
L1: 

    /** eds.e:2424		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16048, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2425			fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18116);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18115;
    ((intptr_t *)_2)[2] = _table_name_18116;
    _10088 = MAKE_SEQ(_1);
    RefDS(_9889);
    RefDS(_10085);
    _41fatal(903, _9889, _10085, _10088);
    _10088 = NOVALUE;

    /** eds.e:2426			return -1*/
    DeRef(_table_name_18116);
    DeRef(_data_ptr_18117);
    DeRef(_data_value_18118);
    return -1;
L3: 

    /** eds.e:2428		if key_location < 1 or key_location > length(key_pointers) then*/
    _10089 = (_key_location_18115 < 1);
    if (_10089 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_41key_pointers_16054)){
            _10091 = SEQ_PTR(_41key_pointers_16054)->length;
    }
    else {
        _10091 = 1;
    }
    _10092 = (_key_location_18115 > _10091);
    _10091 = NOVALUE;
    if (_10092 == 0)
    {
        DeRef(_10092);
        _10092 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10092);
        _10092 = NOVALUE;
    }
L4: 

    /** eds.e:2429			fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18116);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18115;
    ((intptr_t *)_2)[2] = _table_name_18116;
    _10093 = MAKE_SEQ(_1);
    RefDS(_10010);
    RefDS(_10085);
    _41fatal(905, _10010, _10085, _10093);
    _10093 = NOVALUE;

    /** eds.e:2430			return -1*/
    DeRef(_table_name_18116);
    DeRef(_data_ptr_18117);
    DeRef(_data_value_18118);
    DeRef(_10089);
    _10089 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2433		io:seek(current_db, key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_41key_pointers_16054);
    _10094 = (object)*(((s1_ptr)_2)->base + _key_location_18115);
    Ref(_10094);
    DeRef(_pos_inlined_seek_at_123_18138);
    _pos_inlined_seek_at_123_18138 = _10094;
    _10094 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_18138);
    DeRef(_seek_1__tmp_at126_18140);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_123_18138;
    _seek_1__tmp_at126_18140 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_18139 = machine(19, _seek_1__tmp_at126_18140);
    DeRef(_pos_inlined_seek_at_123_18138);
    _pos_inlined_seek_at_123_18138 = NOVALUE;
    DeRef(_seek_1__tmp_at126_18140);
    _seek_1__tmp_at126_18140 = NOVALUE;

    /** eds.e:2434		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_41vLastErrors_16071)){
            _10095 = SEQ_PTR(_41vLastErrors_16071)->length;
    }
    else {
        _10095 = 1;
    }
    if (_10095 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_18116);
    DeRef(_data_ptr_18117);
    DeRef(_data_value_18118);
    DeRef(_10089);
    _10089 = NOVALUE;
    return -1;
L6: 

    /** eds.e:2435		data_ptr = get4()*/
    _0 = _data_ptr_18117;
    _data_ptr_18117 = _41get4();
    DeRef(_0);

    /** eds.e:2436		io:seek(current_db, data_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_18117);
    DeRef(_seek_1__tmp_at164_18147);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16047;
    ((intptr_t *)_2)[2] = _data_ptr_18117;
    _seek_1__tmp_at164_18147 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_18146 = machine(19, _seek_1__tmp_at164_18147);
    DeRef(_seek_1__tmp_at164_18147);
    _seek_1__tmp_at164_18147 = NOVALUE;

    /** eds.e:2437		data_value = decompress(0)*/
    _0 = _data_value_18118;
    _data_value_18118 = _41decompress(0);
    DeRef(_0);

    /** eds.e:2439		return data_value*/
    DeRef(_table_name_18116);
    DeRef(_data_ptr_18117);
    DeRef(_10089);
    _10089 = NOVALUE;
    return _data_value_18118;
    ;
}


object _41db_fetch_record(object _key_18151, object _table_name_18152)
{
    object _pos_18153 = NOVALUE;
    object _10101 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2481		pos = db_find_key(key, table_name)*/
    Ref(_key_18151);
    RefDS(_table_name_18152);
    _pos_18153 = _41db_find_key(_key_18151, _table_name_18152);
    if (!IS_ATOM_INT(_pos_18153)) {
        _1 = (object)(DBL_PTR(_pos_18153)->dbl);
        DeRefDS(_pos_18153);
        _pos_18153 = _1;
    }

    /** eds.e:2482		if pos > 0 then*/
    if (_pos_18153 <= 0)
    goto L1; // [12] 30

    /** eds.e:2483			return db_record_data(pos, table_name)*/
    RefDS(_table_name_18152);
    _10101 = _41db_record_data(_pos_18153, _table_name_18152);
    DeRef(_key_18151);
    DeRefDS(_table_name_18152);
    return _10101;
    goto L2; // [27] 37
L1: 

    /** eds.e:2485			return pos*/
    DeRef(_key_18151);
    DeRef(_table_name_18152);
    DeRef(_10101);
    _10101 = NOVALUE;
    return _pos_18153;
L2: 
    ;
}


object _41db_record_key(object _key_location_18161, object _table_name_18162)
{
    object _10116 = NOVALUE;
    object _10115 = NOVALUE;
    object _10114 = NOVALUE;
    object _10113 = NOVALUE;
    object _10112 = NOVALUE;
    object _10110 = NOVALUE;
    object _10109 = NOVALUE;
    object _10107 = NOVALUE;
    object _10104 = NOVALUE;
    object _10102 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18161)) {
        _1 = (object)(DBL_PTR(_key_location_18161)->dbl);
        DeRefDS(_key_location_18161);
        _key_location_18161 = _1;
    }

    /** eds.e:2519		if not equal(table_name, current_table_name) then*/
    if (_table_name_18162 == _41current_table_name_16049)
    _10102 = 1;
    else if (IS_ATOM_INT(_table_name_18162) && IS_ATOM_INT(_41current_table_name_16049))
    _10102 = 0;
    else
    _10102 = (compare(_table_name_18162, _41current_table_name_16049) == 0);
    if (_10102 != 0)
    goto L1; // [11] 44
    _10102 = NOVALUE;

    /** eds.e:2520			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18162);
    _10104 = _41db_select_table(_table_name_18162);
    if (binary_op_a(EQUALS, _10104, 0)){
        DeRef(_10104);
        _10104 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10104);
    _10104 = NOVALUE;

    /** eds.e:2521				fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_18162);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18161;
    ((intptr_t *)_2)[2] = _table_name_18162;
    _10107 = MAKE_SEQ(_1);
    RefDS(_9885);
    RefDS(_10106);
    _41fatal(903, _9885, _10106, _10107);
    _10107 = NOVALUE;

    /** eds.e:2522				return -1*/
    DeRefDS(_table_name_18162);
    return -1;
L2: 
L1: 

    /** eds.e:2526		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16048, -1)){
        goto L3; // [48] 71
    }

    /** eds.e:2527			fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18162);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18161;
    ((intptr_t *)_2)[2] = _table_name_18162;
    _10109 = MAKE_SEQ(_1);
    RefDS(_9889);
    RefDS(_10106);
    _41fatal(903, _9889, _10106, _10109);
    _10109 = NOVALUE;

    /** eds.e:2528			return -1*/
    DeRef(_table_name_18162);
    return -1;
L3: 

    /** eds.e:2530		if key_location < 1 or key_location > length(key_pointers) then*/
    _10110 = (_key_location_18161 < 1);
    if (_10110 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_41key_pointers_16054)){
            _10112 = SEQ_PTR(_41key_pointers_16054)->length;
    }
    else {
        _10112 = 1;
    }
    _10113 = (_key_location_18161 > _10112);
    _10112 = NOVALUE;
    if (_10113 == 0)
    {
        DeRef(_10113);
        _10113 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10113);
        _10113 = NOVALUE;
    }
L4: 

    /** eds.e:2531			fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18162);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18161;
    ((intptr_t *)_2)[2] = _table_name_18162;
    _10114 = MAKE_SEQ(_1);
    RefDS(_10010);
    RefDS(_10106);
    _41fatal(905, _10010, _10106, _10114);
    _10114 = NOVALUE;

    /** eds.e:2532			return -1*/
    DeRef(_table_name_18162);
    DeRef(_10110);
    _10110 = NOVALUE;
    return -1;
L5: 

    /** eds.e:2534		return key_value(key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_41key_pointers_16054);
    _10115 = (object)*(((s1_ptr)_2)->base + _key_location_18161);
    Ref(_10115);
    _10116 = _41key_value(_10115);
    _10115 = NOVALUE;
    DeRef(_table_name_18162);
    DeRef(_10110);
    _10110 = NOVALUE;
    return _10116;
    ;
}


void _41db_replace_recid(object _recid_18274, object _data_18275)
{
    object _old_size_18276 = NOVALUE;
    object _new_size_18277 = NOVALUE;
    object _data_ptr_18278 = NOVALUE;
    object _data_string_18279 = NOVALUE;
    object _put4_1__tmp_at111_18299 = NOVALUE;
    object _10214 = NOVALUE;
    object _10213 = NOVALUE;
    object _10212 = NOVALUE;
    object _10211 = NOVALUE;
    object _10210 = NOVALUE;
    object _10182 = NOVALUE;
    object _10180 = NOVALUE;
    object _10179 = NOVALUE;
    object _10178 = NOVALUE;
    object _10177 = NOVALUE;
    object _10176 = NOVALUE;
    object _10172 = NOVALUE;
    object _10171 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_18274)) {
        _1 = (object)(DBL_PTR(_recid_18274)->dbl);
        DeRefDS(_recid_18274);
        _recid_18274 = _1;
    }

    /** eds.e:2760		seek(current_db, recid)*/
    _10214 = _18seek(_41current_db_16047, _recid_18274);
    DeRef(_10214);
    _10214 = NOVALUE;

    /** eds.e:2761		data_ptr = get4()*/
    _0 = _data_ptr_18278;
    _data_ptr_18278 = _41get4();
    DeRef(_0);

    /** eds.e:2762		seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_18278)) {
        _10171 = _data_ptr_18278 - 4;
        if ((object)((uintptr_t)_10171 +(uintptr_t) HIGH_BITS) >= 0){
            _10171 = NewDouble((eudouble)_10171);
        }
    }
    else {
        _10171 = NewDouble(DBL_PTR(_data_ptr_18278)->dbl - (eudouble)4);
    }
    _10213 = _18seek(_41current_db_16047, _10171);
    _10171 = NOVALUE;
    DeRef(_10213);
    _10213 = NOVALUE;

    /** eds.e:2763		old_size = get4()-4*/
    _10172 = _41get4();
    DeRef(_old_size_18276);
    if (IS_ATOM_INT(_10172)) {
        _old_size_18276 = _10172 - 4;
        if ((object)((uintptr_t)_old_size_18276 +(uintptr_t) HIGH_BITS) >= 0){
            _old_size_18276 = NewDouble((eudouble)_old_size_18276);
        }
    }
    else {
        _old_size_18276 = binary_op(MINUS, _10172, 4);
    }
    DeRef(_10172);
    _10172 = NOVALUE;

    /** eds.e:2764		data_string = compress(data)*/
    _0 = _data_string_18279;
    _data_string_18279 = _41compress(_data_18275);
    DeRef(_0);

    /** eds.e:2765		new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_18279)){
            _new_size_18277 = SEQ_PTR(_data_string_18279)->length;
    }
    else {
        _new_size_18277 = 1;
    }

    /** eds.e:2766		if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_18276)) {
        _10176 = (_new_size_18277 <= _old_size_18276);
    }
    else {
        _10176 = ((eudouble)_new_size_18277 <= DBL_PTR(_old_size_18276)->dbl);
    }
    if (_10176 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_18276)) {
        _10178 = _old_size_18276 - 16;
        if ((object)((uintptr_t)_10178 +(uintptr_t) HIGH_BITS) >= 0){
            _10178 = NewDouble((eudouble)_10178);
        }
    }
    else {
        _10178 = NewDouble(DBL_PTR(_old_size_18276)->dbl - (eudouble)16);
    }
    if (IS_ATOM_INT(_10178)) {
        _10179 = (_new_size_18277 >= _10178);
    }
    else {
        _10179 = ((eudouble)_new_size_18277 >= DBL_PTR(_10178)->dbl);
    }
    DeRef(_10178);
    _10178 = NOVALUE;
    if (_10179 == 0)
    {
        DeRef(_10179);
        _10179 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10179);
        _10179 = NOVALUE;
    }

    /** eds.e:2769			seek(current_db, data_ptr)*/
    Ref(_data_ptr_18278);
    _10212 = _18seek(_41current_db_16047, _data_ptr_18278);
    DeRef(_10212);
    _10212 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** eds.e:2772			db_free(data_ptr)*/
    Ref(_data_ptr_18278);
    _41db_free(_data_ptr_18278);

    /** eds.e:2774			data_ptr = db_allocate(new_size + 8)*/
    _10180 = _new_size_18277 + 8;
    if ((object)((uintptr_t)_10180 + (uintptr_t)HIGH_BITS) >= 0){
        _10180 = NewDouble((eudouble)_10180);
    }
    _0 = _data_ptr_18278;
    _data_ptr_18278 = _41db_allocate(_10180);
    DeRef(_0);
    _10180 = NOVALUE;

    /** eds.e:2775			seek(current_db, recid)*/
    _10211 = _18seek(_41current_db_16047, _recid_18274);
    DeRef(_10211);
    _10211 = NOVALUE;

    /** eds.e:2776			put4(data_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16089)){
        poke4_addr = (uint32_t *)_41mem0_16089;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16089)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18278)) {
        *poke4_addr = (uint32_t)_data_ptr_18278;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_data_ptr_18278)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_18299);
    _1 = (object)SEQ_PTR(_41memseq_16313);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at111_18299 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16047, _put4_1__tmp_at111_18299); // DJP 

    /** eds.e:444	end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_18299);
    _put4_1__tmp_at111_18299 = NOVALUE;

    /** eds.e:2777			seek(current_db, data_ptr)*/
    Ref(_data_ptr_18278);
    _10210 = _18seek(_41current_db_16047, _data_ptr_18278);
    DeRef(_10210);
    _10210 = NOVALUE;

    /** eds.e:2781			data_string &= repeat( 0, 8 )*/
    _10182 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_18279, _data_string_18279, _10182);
    DeRefDS(_10182);
    _10182 = NOVALUE;
L2: 

    /** eds.e:2784		putn(data_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16047, _data_string_18279); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [179] 182
L4: 

    /** eds.e:2785	end procedure*/
    DeRef(_old_size_18276);
    DeRef(_data_ptr_18278);
    DeRef(_data_string_18279);
    DeRef(_10176);
    _10176 = NOVALUE;
    return;
    ;
}



// 0xC4AC1228
