// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _48local_abort(object _lvl_20998)
{
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003 = NOVALUE;
    object _11772 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:171		if length(pause_msg) != 0 then*/
    if (IS_SEQUENCE(_48pause_msg_20995)){
            _11772 = SEQ_PTR(_48pause_msg_20995)->length;
    }
    else {
        _11772 = 1;
    }
    if (_11772 == 0)
    goto L1; // [10] 45

    /** cmdline.e:172			console:maybe_any_key(pause_msg, 1)*/

    /** console.e:923		if not has_console() then*/

    /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003)) {
        if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003 != 0){
            goto L2; // [27] 42
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003)->dbl != 0.0){
            goto L2; // [27] 42
        }
    }

    /** console.e:924			any_key(prompt, con)*/
    RefDS(_48pause_msg_20995);
    _38any_key(_48pause_msg_20995, 1);

    /** console.e:926	end procedure*/
    goto L2; // [39] 42
L2: 
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_21003 = NOVALUE;
L1: 

    /** cmdline.e:175		abort(lvl)*/
    UserCleanup(_lvl_20998);

    /** cmdline.e:176	end procedure*/
    return;
    ;
}


void _48check_for_bad_combos(object _opts_21006, object _opt1_21007, object _opt2_21008, object _error_message_21009)
{
    object _msg_inlined_crash_at_38_21017 = NOVALUE;
    object _11777 = NOVALUE;
    object _11776 = NOVALUE;
    object _11775 = NOVALUE;
    object _11774 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:180		if find( opt1, opts[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opts_21006);
    _11774 = (object)*(((s1_ptr)_2)->base + 4);
    _11775 = find_from(_opt1_21007, _11774, 1);
    _11774 = NOVALUE;
    if (_11775 == 0)
    {
        _11775 = NOVALUE;
        goto L1; // [20] 59
    }
    else{
        _11775 = NOVALUE;
    }

    /** cmdline.e:181			if find( opt2, opts[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opts_21006);
    _11776 = (object)*(((s1_ptr)_2)->base + 4);
    _11777 = find_from(_opt2_21008, _11776, 1);
    _11776 = NOVALUE;
    if (_11777 == 0)
    {
        _11777 = NOVALUE;
        goto L2; // [34] 58
    }
    else{
        _11777 = NOVALUE;
    }

    /** cmdline.e:182				error:crash( error_message )*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_38_21017);
    _msg_inlined_crash_at_38_21017 = EPrintf(-9999999, _error_message_21009, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_38_21017);

    /** error.e:53	end procedure*/
    goto L3; // [52] 55
L3: 
    DeRefi(_msg_inlined_crash_at_38_21017);
    _msg_inlined_crash_at_38_21017 = NOVALUE;
L2: 
L1: 

    /** cmdline.e:185	end procedure*/
    DeRefDS(_opts_21006);
    DeRefDSi(_error_message_21009);
    return;
    ;
}


object _48has_duplicate(object _opts_21020, object _opt_21021, object _name_type_21022, object _start_from_21023)
{
    object _opt_name_21027 = NOVALUE;
    object _11785 = NOVALUE;
    object _11784 = NOVALUE;
    object _11783 = NOVALUE;
    object _11782 = NOVALUE;
    object _11781 = NOVALUE;
    object _11779 = NOVALUE;
    object _11778 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:188		if sequence( opt[name_type] ) then*/
    _2 = (object)SEQ_PTR(_opt_21021);
    _11778 = (object)*(((s1_ptr)_2)->base + _name_type_21022);
    _11779 = IS_SEQUENCE(_11778);
    _11778 = NOVALUE;
    if (_11779 == 0)
    {
        _11779 = NOVALUE;
        goto L1; // [18] 77
    }
    else{
        _11779 = NOVALUE;
    }

    /** cmdline.e:189			sequence opt_name = opt[name_type]*/
    DeRef(_opt_name_21027);
    _2 = (object)SEQ_PTR(_opt_21021);
    _opt_name_21027 = (object)*(((s1_ptr)_2)->base + _name_type_21022);
    Ref(_opt_name_21027);

    /** cmdline.e:190			for i = start_from + 1 to length( opts ) do*/
    _11781 = _start_from_21023 + 1;
    if (IS_SEQUENCE(_opts_21020)){
            _11782 = SEQ_PTR(_opts_21020)->length;
    }
    else {
        _11782 = 1;
    }
    {
        object _i_21030;
        _i_21030 = _11781;
L2: 
        if (_i_21030 > _11782){
            goto L3; // [38] 76
        }

        /** cmdline.e:191				if equal( opt_name, opts[i][name_type] ) then*/
        _2 = (object)SEQ_PTR(_opts_21020);
        _11783 = (object)*(((s1_ptr)_2)->base + _i_21030);
        _2 = (object)SEQ_PTR(_11783);
        _11784 = (object)*(((s1_ptr)_2)->base + _name_type_21022);
        _11783 = NOVALUE;
        if (_opt_name_21027 == _11784)
        _11785 = 1;
        else if (IS_ATOM_INT(_opt_name_21027) && IS_ATOM_INT(_11784))
        _11785 = 0;
        else
        _11785 = (compare(_opt_name_21027, _11784) == 0);
        _11784 = NOVALUE;
        if (_11785 == 0)
        {
            _11785 = NOVALUE;
            goto L4; // [59] 69
        }
        else{
            _11785 = NOVALUE;
        }

        /** cmdline.e:192					return 1*/
        DeRefDS(_opt_name_21027);
        DeRefDS(_opts_21020);
        DeRefDS(_opt_21021);
        DeRef(_11781);
        _11781 = NOVALUE;
        return 1;
L4: 

        /** cmdline.e:194			end for*/
        _i_21030 = _i_21030 + 1;
        goto L2; // [71] 45
L3: 
        ;
    }
L1: 
    DeRef(_opt_name_21027);
    _opt_name_21027 = NOVALUE;

    /** cmdline.e:196		return 0*/
    DeRefDS(_opts_21020);
    DeRefDS(_opt_21021);
    DeRef(_11781);
    _11781 = NOVALUE;
    return 0;
    ;
}


void _48check_for_duplicates(object _opts_21039)
{
    object _opt_21043 = NOVALUE;
    object _msg_inlined_crash_at_49_21052 = NOVALUE;
    object _data_inlined_crash_at_46_21051 = NOVALUE;
    object _msg_inlined_crash_at_95_21060 = NOVALUE;
    object _data_inlined_crash_at_92_21059 = NOVALUE;
    object _11795 = NOVALUE;
    object _11794 = NOVALUE;
    object _11792 = NOVALUE;
    object _11791 = NOVALUE;
    object _11790 = NOVALUE;
    object _11788 = NOVALUE;
    object _11786 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:201		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21039)){
            _11786 = SEQ_PTR(_opts_21039)->length;
    }
    else {
        _11786 = 1;
    }
    {
        object _i_21041;
        _i_21041 = 1;
L1: 
        if (_i_21041 > _11786){
            goto L2; // [8] 125
        }

        /** cmdline.e:202			sequence opt*/

        /** cmdline.e:203			opt = opts[i]*/
        DeRef(_opt_21043);
        _2 = (object)SEQ_PTR(_opts_21039);
        _opt_21043 = (object)*(((s1_ptr)_2)->base + _i_21041);
        Ref(_opt_21043);

        /** cmdline.e:204			if has_duplicate( opts, opt, SHORTNAME, i ) then*/
        RefDS(_opts_21039);
        RefDS(_opt_21043);
        _11788 = _48has_duplicate(_opts_21039, _opt_21043, 1, _i_21041);
        if (_11788 == 0) {
            DeRef(_11788);
            _11788 = NOVALUE;
            goto L3; // [34] 71
        }
        else {
            if (!IS_ATOM_INT(_11788) && DBL_PTR(_11788)->dbl == 0.0){
                DeRef(_11788);
                _11788 = NOVALUE;
                goto L3; // [34] 71
            }
            DeRef(_11788);
            _11788 = NOVALUE;
        }
        DeRef(_11788);
        _11788 = NOVALUE;

        /** cmdline.e:206				error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
        _2 = (object)SEQ_PTR(_opt_21043);
        _11790 = (object)*(((s1_ptr)_2)->base + 1);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_11790);
        ((intptr_t*)_2)[1] = _11790;
        _11791 = MAKE_SEQ(_1);
        _11790 = NOVALUE;
        DeRef(_data_inlined_crash_at_46_21051);
        _data_inlined_crash_at_46_21051 = _11791;
        _11791 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_49_21052);
        _msg_inlined_crash_at_49_21052 = EPrintf(-9999999, _11789, _data_inlined_crash_at_46_21051);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_49_21052);

        /** error.e:53	end procedure*/
        goto L4; // [63] 66
L4: 
        DeRef(_data_inlined_crash_at_46_21051);
        _data_inlined_crash_at_46_21051 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_49_21052);
        _msg_inlined_crash_at_49_21052 = NOVALUE;
        goto L5; // [68] 116
L3: 

        /** cmdline.e:209			elsif has_duplicate( opts, opt, LONGNAME, i ) then*/
        RefDS(_opts_21039);
        RefDS(_opt_21043);
        _11792 = _48has_duplicate(_opts_21039, _opt_21043, 2, _i_21041);
        if (_11792 == 0) {
            DeRef(_11792);
            _11792 = NOVALUE;
            goto L6; // [80] 115
        }
        else {
            if (!IS_ATOM_INT(_11792) && DBL_PTR(_11792)->dbl == 0.0){
                DeRef(_11792);
                _11792 = NOVALUE;
                goto L6; // [80] 115
            }
            DeRef(_11792);
            _11792 = NOVALUE;
        }
        DeRef(_11792);
        _11792 = NOVALUE;

        /** cmdline.e:211				error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
        _2 = (object)SEQ_PTR(_opt_21043);
        _11794 = (object)*(((s1_ptr)_2)->base + 2);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_11794);
        ((intptr_t*)_2)[1] = _11794;
        _11795 = MAKE_SEQ(_1);
        _11794 = NOVALUE;
        DeRef(_data_inlined_crash_at_92_21059);
        _data_inlined_crash_at_92_21059 = _11795;
        _11795 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_95_21060);
        _msg_inlined_crash_at_95_21060 = EPrintf(-9999999, _11793, _data_inlined_crash_at_92_21059);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_95_21060);

        /** error.e:53	end procedure*/
        goto L7; // [109] 112
L7: 
        DeRef(_data_inlined_crash_at_92_21059);
        _data_inlined_crash_at_92_21059 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_95_21060);
        _msg_inlined_crash_at_95_21060 = NOVALUE;
L6: 
L5: 
        DeRef(_opt_21043);
        _opt_21043 = NOVALUE;

        /** cmdline.e:214		end for*/
        _i_21041 = _i_21041 + 1;
        goto L1; // [120] 15
L2: 
        ;
    }

    /** cmdline.e:216	end procedure*/
    DeRefDS(_opts_21039);
    return;
    ;
}


object _48update_opts(object _opts_21063)
{
    object _lExtras_21064 = NOVALUE;
    object _opt_21068 = NOVALUE;
    object _msg_inlined_crash_at_162_21101 = NOVALUE;
    object _msg_inlined_crash_at_323_21132 = NOVALUE;
    object _11866 = NOVALUE;
    object _11865 = NOVALUE;
    object _11864 = NOVALUE;
    object _11863 = NOVALUE;
    object _11862 = NOVALUE;
    object _11861 = NOVALUE;
    object _11860 = NOVALUE;
    object _11859 = NOVALUE;
    object _11858 = NOVALUE;
    object _11857 = NOVALUE;
    object _11856 = NOVALUE;
    object _11855 = NOVALUE;
    object _11854 = NOVALUE;
    object _11853 = NOVALUE;
    object _11851 = NOVALUE;
    object _11849 = NOVALUE;
    object _11848 = NOVALUE;
    object _11847 = NOVALUE;
    object _11846 = NOVALUE;
    object _11839 = NOVALUE;
    object _11838 = NOVALUE;
    object _11837 = NOVALUE;
    object _11836 = NOVALUE;
    object _11835 = NOVALUE;
    object _11834 = NOVALUE;
    object _11833 = NOVALUE;
    object _11832 = NOVALUE;
    object _11830 = NOVALUE;
    object _11829 = NOVALUE;
    object _11828 = NOVALUE;
    object _11827 = NOVALUE;
    object _11826 = NOVALUE;
    object _11825 = NOVALUE;
    object _11824 = NOVALUE;
    object _11823 = NOVALUE;
    object _11820 = NOVALUE;
    object _11819 = NOVALUE;
    object _11818 = NOVALUE;
    object _11817 = NOVALUE;
    object _11816 = NOVALUE;
    object _11815 = NOVALUE;
    object _11814 = NOVALUE;
    object _11813 = NOVALUE;
    object _11812 = NOVALUE;
    object _11811 = NOVALUE;
    object _11810 = NOVALUE;
    object _11809 = NOVALUE;
    object _11808 = NOVALUE;
    object _11807 = NOVALUE;
    object _11806 = NOVALUE;
    object _11805 = NOVALUE;
    object _11804 = NOVALUE;
    object _11802 = NOVALUE;
    object _11801 = NOVALUE;
    object _11800 = NOVALUE;
    object _11798 = NOVALUE;
    object _11796 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:223		integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_21064 = 0;

    /** cmdline.e:224		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21063)){
            _11796 = SEQ_PTR(_opts_21063)->length;
    }
    else {
        _11796 = 1;
    }
    {
        object _i_21066;
        _i_21066 = 1;
L1: 
        if (_i_21066 > _11796){
            goto L2; // [13] 565
        }

        /** cmdline.e:225			sequence opt = opts[i]*/
        DeRef(_opt_21068);
        _2 = (object)SEQ_PTR(_opts_21063);
        _opt_21068 = (object)*(((s1_ptr)_2)->base + _i_21066);
        Ref(_opt_21068);

        /** cmdline.e:226			opts[i] = 0*/
        _2 = (object)SEQ_PTR(_opts_21063);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_21063 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_21066);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);

        /** cmdline.e:228			if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_21068)){
                _11798 = SEQ_PTR(_opt_21068)->length;
        }
        else {
            _11798 = 1;
        }
        if (_11798 >= 6)
        goto L3; // [39] 61

        /** cmdline.e:229				opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_21068)){
                _11800 = SEQ_PTR(_opt_21068)->length;
        }
        else {
            _11800 = 1;
        }
        _11801 = 6 - _11800;
        _11800 = NOVALUE;
        _11802 = Repeat(-1, _11801);
        _11801 = NOVALUE;
        Concat((object_ptr)&_opt_21068, _opt_21068, _11802);
        DeRefDS(_11802);
        _11802 = NOVALUE;
L3: 

        /** cmdline.e:232			if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11804 = (object)*(((s1_ptr)_2)->base + 1);
        _11805 = IS_SEQUENCE(_11804);
        _11804 = NOVALUE;
        if (_11805 == 0) {
            goto L4; // [70] 96
        }
        _2 = (object)SEQ_PTR(_opt_21068);
        _11807 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_11807)){
                _11808 = SEQ_PTR(_11807)->length;
        }
        else {
            _11808 = 1;
        }
        _11807 = NOVALUE;
        _11809 = (_11808 == 0);
        _11808 = NOVALUE;
        if (_11809 == 0)
        {
            DeRef(_11809);
            _11809 = NOVALUE;
            goto L4; // [86] 96
        }
        else{
            DeRef(_11809);
            _11809 = NOVALUE;
        }

        /** cmdline.e:233				opt[SHORTNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L4: 

        /** cmdline.e:236			if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11810 = (object)*(((s1_ptr)_2)->base + 2);
        _11811 = IS_SEQUENCE(_11810);
        _11810 = NOVALUE;
        if (_11811 == 0) {
            goto L5; // [105] 131
        }
        _2 = (object)SEQ_PTR(_opt_21068);
        _11813 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_11813)){
                _11814 = SEQ_PTR(_11813)->length;
        }
        else {
            _11814 = 1;
        }
        _11813 = NOVALUE;
        _11815 = (_11814 == 0);
        _11814 = NOVALUE;
        if (_11815 == 0)
        {
            DeRef(_11815);
            _11815 = NOVALUE;
            goto L5; // [121] 131
        }
        else{
            DeRef(_11815);
            _11815 = NOVALUE;
        }

        /** cmdline.e:237				opt[LONGNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L5: 

        /** cmdline.e:240			if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11816 = (object)*(((s1_ptr)_2)->base + 2);
        _11817 = IS_ATOM(_11816);
        _11816 = NOVALUE;
        if (_11817 == 0) {
            goto L6; // [140] 212
        }
        _2 = (object)SEQ_PTR(_opt_21068);
        _11819 = (object)*(((s1_ptr)_2)->base + 1);
        _11820 = IS_ATOM(_11819);
        _11819 = NOVALUE;
        if (_11820 == 0)
        {
            _11820 = NOVALUE;
            goto L6; // [152] 212
        }
        else{
            _11820 = NOVALUE;
        }

        /** cmdline.e:241				if lExtras != 0 then*/
        if (_lExtras_21064 == 0)
        goto L7; // [157] 184

        /** cmdline.e:242					error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_162_21101);
        _msg_inlined_crash_at_162_21101 = EPrintf(-9999999, _11822, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_162_21101);

        /** error.e:53	end procedure*/
        goto L8; // [176] 179
L8: 
        DeRefi(_msg_inlined_crash_at_162_21101);
        _msg_inlined_crash_at_162_21101 = NOVALUE;
        goto L9; // [181] 211
L7: 

        /** cmdline.e:244					lExtras = i*/
        _lExtras_21064 = _i_21066;

        /** cmdline.e:245					if atom(opt[MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11823 = (object)*(((s1_ptr)_2)->base + 6);
        _11824 = IS_ATOM(_11823);
        _11823 = NOVALUE;
        if (_11824 == 0)
        {
            _11824 = NOVALUE;
            goto LA; // [198] 210
        }
        else{
            _11824 = NOVALUE;
        }

        /** cmdline.e:246						opt[MAPNAME] = EXTRAS*/
        RefDS(_48EXTRAS_20984);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _48EXTRAS_20984;
        DeRef(_1);
LA: 
L9: 
L6: 

        /** cmdline.e:251			if atom(opt[DESCRIPTION]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11825 = (object)*(((s1_ptr)_2)->base + 3);
        _11826 = IS_ATOM(_11825);
        _11825 = NOVALUE;
        if (_11826 == 0)
        {
            _11826 = NOVALUE;
            goto LB; // [221] 231
        }
        else{
            _11826 = NOVALUE;
        }

        /** cmdline.e:252				opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 3);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
LB: 

        /** cmdline.e:256			if atom(opt[OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11827 = (object)*(((s1_ptr)_2)->base + 4);
        _11828 = IS_ATOM(_11827);
        _11827 = NOVALUE;
        if (_11828 == 0)
        {
            _11828 = NOVALUE;
            goto LC; // [240] 279
        }
        else{
            _11828 = NOVALUE;
        }

        /** cmdline.e:257				if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11829 = (object)*(((s1_ptr)_2)->base + 4);
        if (_11829 == 112)
        _11830 = 1;
        else if (IS_ATOM_INT(_11829) && IS_ATOM_INT(112))
        _11830 = 0;
        else
        _11830 = (compare(_11829, 112) == 0);
        _11829 = NOVALUE;
        if (_11830 == 0)
        {
            _11830 = NOVALUE;
            goto LD; // [253] 269
        }
        else{
            _11830 = NOVALUE;
        }

        /** cmdline.e:258					opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_11831);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 112;
        ((intptr_t *)_2)[2] = _11831;
        _11832 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11832;
        if( _1 != _11832 ){
            DeRef(_1);
        }
        _11832 = NOVALUE;
        goto LE; // [266] 383
LD: 

        /** cmdline.e:260					opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
        goto LE; // [276] 383
LC: 

        /** cmdline.e:263				for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11833 = (object)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_11833)){
                _11834 = SEQ_PTR(_11833)->length;
        }
        else {
            _11834 = 1;
        }
        _11833 = NOVALUE;
        {
            object _j_21120;
            _j_21120 = 1;
LF: 
            if (_j_21120 > _11834){
                goto L10; // [288] 350
            }

            /** cmdline.e:264					if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (object)SEQ_PTR(_opt_21068);
            _11835 = (object)*(((s1_ptr)_2)->base + 4);
            _2 = (object)SEQ_PTR(_11835);
            _11836 = (object)*(((s1_ptr)_2)->base + _j_21120);
            _11835 = NOVALUE;
            _2 = (object)SEQ_PTR(_opt_21068);
            _11837 = (object)*(((s1_ptr)_2)->base + 4);
            _11838 = _j_21120 + 1;
            _11839 = find_from(_11836, _11837, _11838);
            _11836 = NOVALUE;
            _11837 = NOVALUE;
            _11838 = NOVALUE;
            if (_11839 == 0)
            goto L11; // [318] 343

            /** cmdline.e:265						error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** error.e:51		msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_323_21132);
            _msg_inlined_crash_at_323_21132 = EPrintf(-9999999, _11841, _5);

            /** error.e:52		machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_323_21132);

            /** error.e:53	end procedure*/
            goto L12; // [337] 340
L12: 
            DeRefi(_msg_inlined_crash_at_323_21132);
            _msg_inlined_crash_at_323_21132 = NOVALUE;
L11: 

            /** cmdline.e:267				end for*/
            _j_21120 = _j_21120 + 1;
            goto LF; // [345] 295
L10: 
            ;
        }

        /** cmdline.e:269				check_for_bad_combos( opt, HAS_PARAMETER, NO_PARAMETER, */
        RefDS(_opt_21068);
        RefDS(_11842);
        _48check_for_bad_combos(_opt_21068, 112, 110, _11842);

        /** cmdline.e:272				check_for_bad_combos( opt, HAS_CASE, NO_CASE, */
        RefDS(_opt_21068);
        RefDS(_11843);
        _48check_for_bad_combos(_opt_21068, 99, 105, _11843);

        /** cmdline.e:275				check_for_bad_combos( opt, MANDATORY, OPTIONAL, */
        RefDS(_opt_21068);
        RefDS(_11844);
        _48check_for_bad_combos(_opt_21068, 109, 111, _11844);

        /** cmdline.e:278				check_for_bad_combos( opt, ONCE, MULTIPLE, */
        RefDS(_opt_21068);
        RefDS(_11845);
        _48check_for_bad_combos(_opt_21068, 49, 42, _11845);
LE: 

        /** cmdline.e:283			if sequence(opt[CALLBACK]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11846 = (object)*(((s1_ptr)_2)->base + 5);
        _11847 = IS_SEQUENCE(_11846);
        _11846 = NOVALUE;
        if (_11847 == 0)
        {
            _11847 = NOVALUE;
            goto L13; // [392] 404
        }
        else{
            _11847 = NOVALUE;
        }

        /** cmdline.e:284				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        goto L14; // [401] 443
L13: 

        /** cmdline.e:285			elsif not integer(opt[CALLBACK]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11848 = (object)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_11848))
        _11849 = 1;
        else if (IS_ATOM_DBL(_11848))
        _11849 = IS_ATOM_INT(DoubleToInt(_11848));
        else
        _11849 = 0;
        _11848 = NOVALUE;
        if (_11849 != 0)
        goto L15; // [413] 425
        _11849 = NOVALUE;

        /** cmdline.e:286				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        goto L14; // [422] 443
L15: 

        /** cmdline.e:287			elsif opt[CALLBACK] < 0 then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11851 = (object)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _11851, 0)){
            _11851 = NOVALUE;
            goto L16; // [431] 442
        }
        _11851 = NOVALUE;

        /** cmdline.e:288				opt[CALLBACK] = -1*/
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
L16: 
L14: 

        /** cmdline.e:291			if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11853 = (object)*(((s1_ptr)_2)->base + 6);
        _11854 = IS_SEQUENCE(_11853);
        _11853 = NOVALUE;
        if (_11854 == 0) {
            goto L17; // [452] 478
        }
        _2 = (object)SEQ_PTR(_opt_21068);
        _11856 = (object)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_11856)){
                _11857 = SEQ_PTR(_11856)->length;
        }
        else {
            _11857 = 1;
        }
        _11856 = NOVALUE;
        _11858 = (_11857 == 0);
        _11857 = NOVALUE;
        if (_11858 == 0)
        {
            DeRef(_11858);
            _11858 = NOVALUE;
            goto L17; // [468] 478
        }
        else{
            DeRef(_11858);
            _11858 = NOVALUE;
        }

        /** cmdline.e:292				opt[MAPNAME] = 0*/
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
L17: 

        /** cmdline.e:295			if atom(opt[MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11859 = (object)*(((s1_ptr)_2)->base + 6);
        _11860 = IS_ATOM(_11859);
        _11859 = NOVALUE;
        if (_11860 == 0)
        {
            _11860 = NOVALUE;
            goto L18; // [487] 550
        }
        else{
            _11860 = NOVALUE;
        }

        /** cmdline.e:296				if sequence(opt[LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11861 = (object)*(((s1_ptr)_2)->base + 2);
        _11862 = IS_SEQUENCE(_11861);
        _11861 = NOVALUE;
        if (_11862 == 0)
        {
            _11862 = NOVALUE;
            goto L19; // [499] 515
        }
        else{
            _11862 = NOVALUE;
        }

        /** cmdline.e:297					opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11863 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_11863);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11863;
        if( _1 != _11863 ){
            DeRef(_1);
        }
        _11863 = NOVALUE;
        goto L1A; // [512] 549
L19: 

        /** cmdline.e:298				elsif sequence(opt[SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11864 = (object)*(((s1_ptr)_2)->base + 1);
        _11865 = IS_SEQUENCE(_11864);
        _11864 = NOVALUE;
        if (_11865 == 0)
        {
            _11865 = NOVALUE;
            goto L1B; // [524] 540
        }
        else{
            _11865 = NOVALUE;
        }

        /** cmdline.e:299					opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (object)SEQ_PTR(_opt_21068);
        _11866 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_11866);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11866;
        if( _1 != _11866 ){
            DeRef(_1);
        }
        _11866 = NOVALUE;
        goto L1A; // [537] 549
L1B: 

        /** cmdline.e:301					opt[MAPNAME] = EXTRAS*/
        RefDS(_48EXTRAS_20984);
        _2 = (object)SEQ_PTR(_opt_21068);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_21068 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 6);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _48EXTRAS_20984;
        DeRef(_1);
L1A: 
L18: 

        /** cmdline.e:305			opts[i] = opt*/
        RefDS(_opt_21068);
        _2 = (object)SEQ_PTR(_opts_21063);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_21063 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_21066);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _opt_21068;
        DeRef(_1);
        DeRefDS(_opt_21068);
        _opt_21068 = NOVALUE;

        /** cmdline.e:306		end for*/
        _i_21066 = _i_21066 + 1;
        goto L1; // [560] 20
L2: 
        ;
    }

    /** cmdline.e:307		return opts*/
    _11813 = NOVALUE;
    _11807 = NOVALUE;
    _11833 = NOVALUE;
    _11856 = NOVALUE;
    return _opts_21063;
    ;
}


object _48standardize_help_options(object _opts_21168, object _auto_help_switches_21169)
{
    object _has_h_21170 = NOVALUE;
    object _has_help_21171 = NOVALUE;
    object _has_question_21172 = NOVALUE;
    object _appended_opts_21192 = NOVALUE;
    object _11893 = NOVALUE;
    object _11890 = NOVALUE;
    object _11887 = NOVALUE;
    object _11884 = NOVALUE;
    object _11882 = NOVALUE;
    object _11881 = NOVALUE;
    object _11880 = NOVALUE;
    object _11879 = NOVALUE;
    object _11877 = NOVALUE;
    object _11876 = NOVALUE;
    object _11875 = NOVALUE;
    object _11873 = NOVALUE;
    object _11872 = NOVALUE;
    object _11871 = NOVALUE;
    object _11869 = NOVALUE;
    object _11868 = NOVALUE;
    object _11867 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:313		integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_21170 = 0;
    _has_help_21171 = 0;
    _has_question_21172 = 0;

    /** cmdline.e:314		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21168)){
            _11867 = SEQ_PTR(_opts_21168)->length;
    }
    else {
        _11867 = 1;
    }
    {
        object _i_21174;
        _i_21174 = 1;
L1: 
        if (_i_21174 > _11867){
            goto L2; // [21] 107
        }

        /** cmdline.e:315			if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (object)SEQ_PTR(_opts_21168);
        _11868 = (object)*(((s1_ptr)_2)->base + _i_21174);
        _2 = (object)SEQ_PTR(_11868);
        _11869 = (object)*(((s1_ptr)_2)->base + 1);
        _11868 = NOVALUE;
        if (_11869 == _11870)
        _11871 = 1;
        else if (IS_ATOM_INT(_11869) && IS_ATOM_INT(_11870))
        _11871 = 0;
        else
        _11871 = (compare(_11869, _11870) == 0);
        _11869 = NOVALUE;
        if (_11871 == 0)
        {
            _11871 = NOVALUE;
            goto L3; // [42] 53
        }
        else{
            _11871 = NOVALUE;
        }

        /** cmdline.e:316				has_h = 1*/
        _has_h_21170 = 1;
        goto L4; // [50] 77
L3: 

        /** cmdline.e:317			elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (object)SEQ_PTR(_opts_21168);
        _11872 = (object)*(((s1_ptr)_2)->base + _i_21174);
        _2 = (object)SEQ_PTR(_11872);
        _11873 = (object)*(((s1_ptr)_2)->base + 1);
        _11872 = NOVALUE;
        if (_11873 == _11874)
        _11875 = 1;
        else if (IS_ATOM_INT(_11873) && IS_ATOM_INT(_11874))
        _11875 = 0;
        else
        _11875 = (compare(_11873, _11874) == 0);
        _11873 = NOVALUE;
        if (_11875 == 0)
        {
            _11875 = NOVALUE;
            goto L5; // [67] 76
        }
        else{
            _11875 = NOVALUE;
        }

        /** cmdline.e:318				has_question = 1*/
        _has_question_21172 = 1;
L5: 
L4: 

        /** cmdline.e:321			if equal(opts[i][LONGNAME], "help") then*/
        _2 = (object)SEQ_PTR(_opts_21168);
        _11876 = (object)*(((s1_ptr)_2)->base + _i_21174);
        _2 = (object)SEQ_PTR(_11876);
        _11877 = (object)*(((s1_ptr)_2)->base + 2);
        _11876 = NOVALUE;
        if (_11877 == _11878)
        _11879 = 1;
        else if (IS_ATOM_INT(_11877) && IS_ATOM_INT(_11878))
        _11879 = 0;
        else
        _11879 = (compare(_11877, _11878) == 0);
        _11877 = NOVALUE;
        if (_11879 == 0)
        {
            _11879 = NOVALUE;
            goto L6; // [91] 100
        }
        else{
            _11879 = NOVALUE;
        }

        /** cmdline.e:322				has_help = 1*/
        _has_help_21171 = 1;
L6: 

        /** cmdline.e:324		end for*/
        _i_21174 = _i_21174 + 1;
        goto L1; // [102] 28
L2: 
        ;
    }

    /** cmdline.e:326		if auto_help_switches then*/
    if (_auto_help_switches_21169 == 0)
    {
        goto L7; // [109] 249
    }
    else{
    }

    /** cmdline.e:327			integer appended_opts = 0*/
    _appended_opts_21192 = 0;

    /** cmdline.e:328			if not has_h and not has_help then*/
    _11880 = (_has_h_21170 == 0);
    if (_11880 == 0) {
        goto L8; // [122] 155
    }
    _11882 = (_has_help_21171 == 0);
    if (_11882 == 0)
    {
        DeRef(_11882);
        _11882 = NOVALUE;
        goto L8; // [130] 155
    }
    else{
        DeRef(_11882);
        _11882 = NOVALUE;
    }

    /** cmdline.e:329				opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11870);
    ((intptr_t*)_2)[1] = _11870;
    RefDS(_11878);
    ((intptr_t*)_2)[2] = _11878;
    RefDS(_11883);
    ((intptr_t*)_2)[3] = _11883;
    RefDS(_11870);
    ((intptr_t*)_2)[4] = _11870;
    ((intptr_t*)_2)[5] = -1;
    _11884 = MAKE_SEQ(_1);
    RefDS(_11884);
    Append(&_opts_21168, _opts_21168, _11884);
    DeRefDS(_11884);
    _11884 = NOVALUE;

    /** cmdline.e:330				appended_opts = 1*/
    _appended_opts_21192 = 1;
    goto L9; // [152] 208
L8: 

    /** cmdline.e:332			elsif not has_h then*/
    if (_has_h_21170 != 0)
    goto LA; // [157] 182

    /** cmdline.e:333				opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11870);
    ((intptr_t*)_2)[1] = _11870;
    ((intptr_t*)_2)[2] = 0;
    RefDS(_11883);
    ((intptr_t*)_2)[3] = _11883;
    RefDS(_11870);
    ((intptr_t*)_2)[4] = _11870;
    ((intptr_t*)_2)[5] = -1;
    _11887 = MAKE_SEQ(_1);
    RefDS(_11887);
    Append(&_opts_21168, _opts_21168, _11887);
    DeRefDS(_11887);
    _11887 = NOVALUE;

    /** cmdline.e:334				appended_opts = 1*/
    _appended_opts_21192 = 1;
    goto L9; // [179] 208
LA: 

    /** cmdline.e:336			elsif not has_help then*/
    if (_has_help_21171 != 0)
    goto LB; // [184] 207

    /** cmdline.e:337				opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    RefDS(_11878);
    ((intptr_t*)_2)[2] = _11878;
    RefDS(_11883);
    ((intptr_t*)_2)[3] = _11883;
    RefDS(_11870);
    ((intptr_t*)_2)[4] = _11870;
    ((intptr_t*)_2)[5] = -1;
    _11890 = MAKE_SEQ(_1);
    RefDS(_11890);
    Append(&_opts_21168, _opts_21168, _11890);
    DeRefDS(_11890);
    _11890 = NOVALUE;

    /** cmdline.e:338				appended_opts = 1*/
    _appended_opts_21192 = 1;
LB: 
L9: 

    /** cmdline.e:342			if not has_question then			*/
    if (_has_question_21172 != 0)
    goto LC; // [210] 233

    /** cmdline.e:343				opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_11874);
    ((intptr_t*)_2)[1] = _11874;
    ((intptr_t*)_2)[2] = 0;
    RefDS(_11883);
    ((intptr_t*)_2)[3] = _11883;
    RefDS(_11870);
    ((intptr_t*)_2)[4] = _11870;
    ((intptr_t*)_2)[5] = -1;
    _11893 = MAKE_SEQ(_1);
    RefDS(_11893);
    Append(&_opts_21168, _opts_21168, _11893);
    DeRefDS(_11893);
    _11893 = NOVALUE;

    /** cmdline.e:344				appended_opts = 1*/
    _appended_opts_21192 = 1;
LC: 

    /** cmdline.e:347			if appended_opts then*/
    if (_appended_opts_21192 == 0)
    {
        goto LD; // [235] 248
    }
    else{
    }

    /** cmdline.e:349				opts = standardize_opts(opts, 0)*/
    RefDS(_opts_21168);
    _0 = _opts_21168;
    _opts_21168 = _48standardize_opts(_opts_21168, 0);
    DeRefDS(_0);
LD: 
L7: 

    /** cmdline.e:352		return opts*/
    DeRef(_11880);
    _11880 = NOVALUE;
    return _opts_21168;
    ;
}


object _48standardize_opts(object _opts_21217, object _auto_help_switches_21218)
{
    object _11932 = NOVALUE;
    object _11931 = NOVALUE;
    object _11929 = NOVALUE;
    object _11928 = NOVALUE;
    object _11927 = NOVALUE;
    object _11926 = NOVALUE;
    object _11925 = NOVALUE;
    object _11924 = NOVALUE;
    object _11923 = NOVALUE;
    object _11922 = NOVALUE;
    object _11921 = NOVALUE;
    object _11920 = NOVALUE;
    object _11919 = NOVALUE;
    object _11918 = NOVALUE;
    object _11916 = NOVALUE;
    object _11915 = NOVALUE;
    object _11914 = NOVALUE;
    object _11913 = NOVALUE;
    object _11912 = NOVALUE;
    object _11911 = NOVALUE;
    object _11910 = NOVALUE;
    object _11909 = NOVALUE;
    object _11908 = NOVALUE;
    object _11907 = NOVALUE;
    object _11906 = NOVALUE;
    object _11905 = NOVALUE;
    object _11903 = NOVALUE;
    object _11901 = NOVALUE;
    object _11900 = NOVALUE;
    object _11899 = NOVALUE;
    object _11898 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** cmdline.e:357		opts = update_opts( opts )*/
    RefDS(_opts_21217);
    _0 = _opts_21217;
    _opts_21217 = _48update_opts(_opts_21217);
    DeRefDS(_0);

    /** cmdline.e:359		check_for_duplicates( opts )*/
    RefDS(_opts_21217);
    _48check_for_duplicates(_opts_21217);

    /** cmdline.e:361		opts = standardize_help_options( opts, auto_help_switches )*/
    RefDS(_opts_21217);
    _0 = _opts_21217;
    _opts_21217 = _48standardize_help_options(_opts_21217, _auto_help_switches_21218);
    DeRefDS(_0);

    /** cmdline.e:364		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21217)){
            _11898 = SEQ_PTR(_opts_21217)->length;
    }
    else {
        _11898 = 1;
    }
    {
        object _i_21222;
        _i_21222 = 1;
L1: 
        if (_i_21222 > _11898){
            goto L2; // [32] 208
        }

        /** cmdline.e:365			if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21217);
        _11899 = (object)*(((s1_ptr)_2)->base + _i_21222);
        _2 = (object)SEQ_PTR(_11899);
        _11900 = (object)*(((s1_ptr)_2)->base + 4);
        _11899 = NOVALUE;
        _11901 = find_from(112, _11900, 1);
        _11900 = NOVALUE;
        if (_11901 != 0)
        goto L3; // [54] 77
        _11901 = NOVALUE;

        /** cmdline.e:366				opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (object)SEQ_PTR(_opts_21217);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_21217 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_21222 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _11905 = (object)*(((s1_ptr)_2)->base + 4);
        _11903 = NOVALUE;
        if (IS_SEQUENCE(_11905) && IS_ATOM(110)) {
            Append(&_11906, _11905, 110);
        }
        else if (IS_ATOM(_11905) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_11906, _11905, 110);
            _11905 = NOVALUE;
        }
        _11905 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11906;
        if( _1 != _11906 ){
            DeRef(_1);
        }
        _11906 = NOVALUE;
        _11903 = NOVALUE;
L3: 

        /** cmdline.e:369			if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21217);
        _11907 = (object)*(((s1_ptr)_2)->base + _i_21222);
        _2 = (object)SEQ_PTR(_11907);
        _11908 = (object)*(((s1_ptr)_2)->base + 4);
        _11907 = NOVALUE;
        _11909 = find_from(42, _11908, 1);
        _11908 = NOVALUE;
        _11910 = (_11909 == 0);
        _11909 = NOVALUE;
        if (_11910 == 0) {
            goto L4; // [95] 139
        }
        _2 = (object)SEQ_PTR(_opts_21217);
        _11912 = (object)*(((s1_ptr)_2)->base + _i_21222);
        _2 = (object)SEQ_PTR(_11912);
        _11913 = (object)*(((s1_ptr)_2)->base + 4);
        _11912 = NOVALUE;
        _11914 = find_from(49, _11913, 1);
        _11913 = NOVALUE;
        _11915 = (_11914 == 0);
        _11914 = NOVALUE;
        if (_11915 == 0)
        {
            DeRef(_11915);
            _11915 = NOVALUE;
            goto L4; // [116] 139
        }
        else{
            DeRef(_11915);
            _11915 = NOVALUE;
        }

        /** cmdline.e:370				opts[i][OPTIONS] &= ONCE*/
        _2 = (object)SEQ_PTR(_opts_21217);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_21217 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_21222 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _11918 = (object)*(((s1_ptr)_2)->base + 4);
        _11916 = NOVALUE;
        if (IS_SEQUENCE(_11918) && IS_ATOM(49)) {
            Append(&_11919, _11918, 49);
        }
        else if (IS_ATOM(_11918) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_11919, _11918, 49);
            _11918 = NOVALUE;
        }
        _11918 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11919;
        if( _1 != _11919 ){
            DeRef(_1);
        }
        _11919 = NOVALUE;
        _11916 = NOVALUE;
L4: 

        /** cmdline.e:373			if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21217);
        _11920 = (object)*(((s1_ptr)_2)->base + _i_21222);
        _2 = (object)SEQ_PTR(_11920);
        _11921 = (object)*(((s1_ptr)_2)->base + 4);
        _11920 = NOVALUE;
        _11922 = find_from(99, _11921, 1);
        _11921 = NOVALUE;
        _11923 = (_11922 == 0);
        _11922 = NOVALUE;
        if (_11923 == 0) {
            goto L5; // [157] 201
        }
        _2 = (object)SEQ_PTR(_opts_21217);
        _11925 = (object)*(((s1_ptr)_2)->base + _i_21222);
        _2 = (object)SEQ_PTR(_11925);
        _11926 = (object)*(((s1_ptr)_2)->base + 4);
        _11925 = NOVALUE;
        _11927 = find_from(105, _11926, 1);
        _11926 = NOVALUE;
        _11928 = (_11927 == 0);
        _11927 = NOVALUE;
        if (_11928 == 0)
        {
            DeRef(_11928);
            _11928 = NOVALUE;
            goto L5; // [178] 201
        }
        else{
            DeRef(_11928);
            _11928 = NOVALUE;
        }

        /** cmdline.e:374				opts[i][OPTIONS] &= NO_CASE*/
        _2 = (object)SEQ_PTR(_opts_21217);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opts_21217 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_21222 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _11931 = (object)*(((s1_ptr)_2)->base + 4);
        _11929 = NOVALUE;
        if (IS_SEQUENCE(_11931) && IS_ATOM(105)) {
            Append(&_11932, _11931, 105);
        }
        else if (IS_ATOM(_11931) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_11932, _11931, 105);
            _11931 = NOVALUE;
        }
        _11931 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _11932;
        if( _1 != _11932 ){
            DeRef(_1);
        }
        _11932 = NOVALUE;
        _11929 = NOVALUE;
L5: 

        /** cmdline.e:376		end for*/
        _i_21222 = _i_21222 + 1;
        goto L1; // [203] 39
L2: 
        ;
    }

    /** cmdline.e:378		return opts*/
    DeRef(_11910);
    _11910 = NOVALUE;
    DeRef(_11923);
    _11923 = NOVALUE;
    return _opts_21217;
    ;
}


object _48print_help(object _opts_21263, object _cmds_21264)
{
    object _pad_size_21265 = NOVALUE;
    object _this_size_21266 = NOVALUE;
    object _extras_mandatory_21267 = NOVALUE;
    object _extras_opt_21268 = NOVALUE;
    object _param_name_21269 = NOVALUE;
    object _has_param_21270 = NOVALUE;
    object _12022 = NOVALUE;
    object _12021 = NOVALUE;
    object _12020 = NOVALUE;
    object _12019 = NOVALUE;
    object _12016 = NOVALUE;
    object _12015 = NOVALUE;
    object _12014 = NOVALUE;
    object _12013 = NOVALUE;
    object _12012 = NOVALUE;
    object _12011 = NOVALUE;
    object _12010 = NOVALUE;
    object _12009 = NOVALUE;
    object _12008 = NOVALUE;
    object _12007 = NOVALUE;
    object _12002 = NOVALUE;
    object _12001 = NOVALUE;
    object _11999 = NOVALUE;
    object _11998 = NOVALUE;
    object _11997 = NOVALUE;
    object _11996 = NOVALUE;
    object _11995 = NOVALUE;
    object _11994 = NOVALUE;
    object _11992 = NOVALUE;
    object _11991 = NOVALUE;
    object _11990 = NOVALUE;
    object _11986 = NOVALUE;
    object _11985 = NOVALUE;
    object _11983 = NOVALUE;
    object _11982 = NOVALUE;
    object _11981 = NOVALUE;
    object _11980 = NOVALUE;
    object _11979 = NOVALUE;
    object _11978 = NOVALUE;
    object _11977 = NOVALUE;
    object _11974 = NOVALUE;
    object _11973 = NOVALUE;
    object _11972 = NOVALUE;
    object _11970 = NOVALUE;
    object _11969 = NOVALUE;
    object _11968 = NOVALUE;
    object _11967 = NOVALUE;
    object _11966 = NOVALUE;
    object _11965 = NOVALUE;
    object _11964 = NOVALUE;
    object _11961 = NOVALUE;
    object _11960 = NOVALUE;
    object _11959 = NOVALUE;
    object _11957 = NOVALUE;
    object _11956 = NOVALUE;
    object _11955 = NOVALUE;
    object _11954 = NOVALUE;
    object _11953 = NOVALUE;
    object _11952 = NOVALUE;
    object _11951 = NOVALUE;
    object _11950 = NOVALUE;
    object _11949 = NOVALUE;
    object _11948 = NOVALUE;
    object _11947 = NOVALUE;
    object _11946 = NOVALUE;
    object _11945 = NOVALUE;
    object _11944 = NOVALUE;
    object _11943 = NOVALUE;
    object _11942 = NOVALUE;
    object _11941 = NOVALUE;
    object _11940 = NOVALUE;
    object _11939 = NOVALUE;
    object _11938 = NOVALUE;
    object _11937 = NOVALUE;
    object _11936 = NOVALUE;
    object _11935 = NOVALUE;
    object _11934 = NOVALUE;
    object _11933 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:384		integer pad_size = 0*/
    _pad_size_21265 = 0;

    /** cmdline.e:386		integer extras_mandatory = 0*/
    _extras_mandatory_21267 = 0;

    /** cmdline.e:387		integer extras_opt = 0*/
    _extras_opt_21268 = 0;

    /** cmdline.e:391		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21263)){
            _11933 = SEQ_PTR(_opts_21263)->length;
    }
    else {
        _11933 = 1;
    }
    {
        object _i_21272;
        _i_21272 = 1;
L1: 
        if (_i_21272 > _11933){
            goto L2; // [25] 456
        }

        /** cmdline.e:392			this_size = 0*/
        _this_size_21266 = 0;

        /** cmdline.e:393			param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_21269);
        _param_name_21269 = _5;

        /** cmdline.e:395			if atom(opts[i][SHORTNAME]) and opts[i][SHORTNAME] = HEADER then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11934 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11934);
        _11935 = (object)*(((s1_ptr)_2)->base + 1);
        _11934 = NOVALUE;
        _11936 = IS_ATOM(_11935);
        _11935 = NOVALUE;
        if (_11936 == 0) {
            goto L3; // [57] 82
        }
        _2 = (object)SEQ_PTR(_opts_21263);
        _11938 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11938);
        _11939 = (object)*(((s1_ptr)_2)->base + 1);
        _11938 = NOVALUE;
        if (IS_ATOM_INT(_11939)) {
            _11940 = (_11939 == 72);
        }
        else {
            _11940 = binary_op(EQUALS, _11939, 72);
        }
        _11939 = NOVALUE;
        if (_11940 == 0) {
            DeRef(_11940);
            _11940 = NOVALUE;
            goto L3; // [74] 82
        }
        else {
            if (!IS_ATOM_INT(_11940) && DBL_PTR(_11940)->dbl == 0.0){
                DeRef(_11940);
                _11940 = NOVALUE;
                goto L3; // [74] 82
            }
            DeRef(_11940);
            _11940 = NOVALUE;
        }
        DeRef(_11940);
        _11940 = NOVALUE;

        /** cmdline.e:396				continue*/
        goto L4; // [79] 451
L3: 

        /** cmdline.e:399			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11941 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11941);
        _11942 = (object)*(((s1_ptr)_2)->base + 1);
        _11941 = NOVALUE;
        _11943 = IS_ATOM(_11942);
        _11942 = NOVALUE;
        if (_11943 == 0) {
            goto L5; // [95] 148
        }
        _2 = (object)SEQ_PTR(_opts_21263);
        _11945 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11945);
        _11946 = (object)*(((s1_ptr)_2)->base + 2);
        _11945 = NOVALUE;
        _11947 = IS_ATOM(_11946);
        _11946 = NOVALUE;
        if (_11947 == 0)
        {
            _11947 = NOVALUE;
            goto L5; // [111] 148
        }
        else{
            _11947 = NOVALUE;
        }

        /** cmdline.e:400				extras_opt = i*/
        _extras_opt_21268 = _i_21272;

        /** cmdline.e:401				if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11948 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11948);
        _11949 = (object)*(((s1_ptr)_2)->base + 4);
        _11948 = NOVALUE;
        _11950 = find_from(109, _11949, 1);
        _11949 = NOVALUE;
        if (_11950 == 0)
        {
            _11950 = NOVALUE;
            goto L4; // [134] 451
        }
        else{
            _11950 = NOVALUE;
        }

        /** cmdline.e:402					extras_mandatory = 1*/
        _extras_mandatory_21267 = 1;

        /** cmdline.e:405				continue*/
        goto L4; // [145] 451
L5: 

        /** cmdline.e:408			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11951 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11951);
        _11952 = (object)*(((s1_ptr)_2)->base + 1);
        _11951 = NOVALUE;
        _11953 = IS_SEQUENCE(_11952);
        _11952 = NOVALUE;
        if (_11953 == 0)
        {
            _11953 = NOVALUE;
            goto L6; // [161] 214
        }
        else{
            _11953 = NOVALUE;
        }

        /** cmdline.e:409				this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11954 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11954);
        _11955 = (object)*(((s1_ptr)_2)->base + 1);
        _11954 = NOVALUE;
        if (IS_SEQUENCE(_11955)){
                _11956 = SEQ_PTR(_11955)->length;
        }
        else {
            _11956 = 1;
        }
        _11955 = NOVALUE;
        _11957 = _11956 + 1;
        _11956 = NOVALUE;
        _this_size_21266 = _this_size_21266 + _11957;
        _11957 = NOVALUE;

        /** cmdline.e:410				if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11959 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11959);
        _11960 = (object)*(((s1_ptr)_2)->base + 4);
        _11959 = NOVALUE;
        _11961 = find_from(109, _11960, 1);
        _11960 = NOVALUE;
        if (_11961 != 0)
        goto L7; // [202] 213

        /** cmdline.e:411					this_size += 2 -- Allow for '[' ']'*/
        _this_size_21266 = _this_size_21266 + 2;
L7: 
L6: 

        /** cmdline.e:415			if sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11964 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11964);
        _11965 = (object)*(((s1_ptr)_2)->base + 2);
        _11964 = NOVALUE;
        _11966 = IS_SEQUENCE(_11965);
        _11965 = NOVALUE;
        if (_11966 == 0)
        {
            _11966 = NOVALUE;
            goto L8; // [227] 280
        }
        else{
            _11966 = NOVALUE;
        }

        /** cmdline.e:416				this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11967 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11967);
        _11968 = (object)*(((s1_ptr)_2)->base + 2);
        _11967 = NOVALUE;
        if (IS_SEQUENCE(_11968)){
                _11969 = SEQ_PTR(_11968)->length;
        }
        else {
            _11969 = 1;
        }
        _11968 = NOVALUE;
        _11970 = _11969 + 2;
        _11969 = NOVALUE;
        _this_size_21266 = _this_size_21266 + _11970;
        _11970 = NOVALUE;

        /** cmdline.e:417				if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11972 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11972);
        _11973 = (object)*(((s1_ptr)_2)->base + 4);
        _11972 = NOVALUE;
        _11974 = find_from(109, _11973, 1);
        _11973 = NOVALUE;
        if (_11974 != 0)
        goto L9; // [268] 279

        /** cmdline.e:418					this_size += 2 -- Allow for '[' ']'*/
        _this_size_21266 = _this_size_21266 + 2;
L9: 
L8: 

        /** cmdline.e:422			if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11977 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11977);
        _11978 = (object)*(((s1_ptr)_2)->base + 1);
        _11977 = NOVALUE;
        _11979 = IS_SEQUENCE(_11978);
        _11978 = NOVALUE;
        if (_11979 == 0) {
            goto LA; // [293] 319
        }
        _2 = (object)SEQ_PTR(_opts_21263);
        _11981 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11981);
        _11982 = (object)*(((s1_ptr)_2)->base + 2);
        _11981 = NOVALUE;
        _11983 = IS_SEQUENCE(_11982);
        _11982 = NOVALUE;
        if (_11983 == 0)
        {
            _11983 = NOVALUE;
            goto LA; // [309] 319
        }
        else{
            _11983 = NOVALUE;
        }

        /** cmdline.e:423				this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_21266 = _this_size_21266 + 2;
LA: 

        /** cmdline.e:426			has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11985 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11985);
        _11986 = (object)*(((s1_ptr)_2)->base + 4);
        _11985 = NOVALUE;
        _has_param_21270 = find_from(112, _11986, 1);
        _11986 = NOVALUE;

        /** cmdline.e:427			if has_param != 0 then*/
        if (_has_param_21270 == 0)
        goto LB; // [336] 437

        /** cmdline.e:428				this_size += 1 -- Allow for " "*/
        _this_size_21266 = _this_size_21266 + 1;

        /** cmdline.e:429				if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11990 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11990);
        _11991 = (object)*(((s1_ptr)_2)->base + 4);
        _11990 = NOVALUE;
        if (IS_SEQUENCE(_11991)){
                _11992 = SEQ_PTR(_11991)->length;
        }
        else {
            _11992 = 1;
        }
        _11991 = NOVALUE;
        if (_has_param_21270 >= _11992)
        goto LC; // [359] 413

        /** cmdline.e:431					if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11994 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11994);
        _11995 = (object)*(((s1_ptr)_2)->base + 4);
        _11994 = NOVALUE;
        _2 = (object)SEQ_PTR(_11995);
        _11996 = (object)*(((s1_ptr)_2)->base + _has_param_21270);
        _11995 = NOVALUE;
        _11997 = IS_SEQUENCE(_11996);
        _11996 = NOVALUE;
        if (_11997 == 0)
        {
            _11997 = NOVALUE;
            goto LD; // [380] 402
        }
        else{
            _11997 = NOVALUE;
        }

        /** cmdline.e:432						param_name = opts[i][OPTIONS][has_param]*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _11998 = (object)*(((s1_ptr)_2)->base + _i_21272);
        _2 = (object)SEQ_PTR(_11998);
        _11999 = (object)*(((s1_ptr)_2)->base + 4);
        _11998 = NOVALUE;
        DeRef(_param_name_21269);
        _2 = (object)SEQ_PTR(_11999);
        _param_name_21269 = (object)*(((s1_ptr)_2)->base + _has_param_21270);
        Ref(_param_name_21269);
        _11999 = NOVALUE;
        goto LE; // [399] 421
LD: 

        /** cmdline.e:434						param_name = "x"*/
        RefDS(_11831);
        DeRef(_param_name_21269);
        _param_name_21269 = _11831;
        goto LE; // [410] 421
LC: 

        /** cmdline.e:437					param_name = "x"*/
        RefDS(_11831);
        DeRef(_param_name_21269);
        _param_name_21269 = _11831;
LE: 

        /** cmdline.e:439				this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_21269)){
                _12001 = SEQ_PTR(_param_name_21269)->length;
        }
        else {
            _12001 = 1;
        }
        _12002 = 2 + _12001;
        _12001 = NOVALUE;
        _this_size_21266 = _this_size_21266 + _12002;
        _12002 = NOVALUE;
LB: 

        /** cmdline.e:442			if pad_size < this_size then*/
        if (_pad_size_21265 >= _this_size_21266)
        goto LF; // [439] 449

        /** cmdline.e:443				pad_size = this_size*/
        _pad_size_21265 = _this_size_21266;
LF: 

        /** cmdline.e:445		end for*/
L4: 
        _i_21272 = _i_21272 + 1;
        goto L1; // [451] 32
L2: 
        ;
    }

    /** cmdline.e:446		pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_21265 = _pad_size_21265 + 3;

    /** cmdline.e:448		printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (object)SEQ_PTR(_cmds_21264);
    _12007 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12007);
    ((intptr_t*)_2)[1] = _12007;
    _12008 = MAKE_SEQ(_1);
    _12007 = NOVALUE;
    EPrintf(1, _12006, _12008);
    DeRefDS(_12008);
    _12008 = NOVALUE;

    /** cmdline.e:450		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21263)){
            _12009 = SEQ_PTR(_opts_21263)->length;
    }
    else {
        _12009 = 1;
    }
    {
        object _i_21364;
        _i_21364 = 1;
L10: 
        if (_i_21364 > _12009){
            goto L11; // [481] 574
        }

        /** cmdline.e:451			if atom(opts[i][1]) and opts[i][1] = HEADER then*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _12010 = (object)*(((s1_ptr)_2)->base + _i_21364);
        _2 = (object)SEQ_PTR(_12010);
        _12011 = (object)*(((s1_ptr)_2)->base + 1);
        _12010 = NOVALUE;
        _12012 = IS_ATOM(_12011);
        _12011 = NOVALUE;
        if (_12012 == 0) {
            goto L12; // [501] 557
        }
        _2 = (object)SEQ_PTR(_opts_21263);
        _12014 = (object)*(((s1_ptr)_2)->base + _i_21364);
        _2 = (object)SEQ_PTR(_12014);
        _12015 = (object)*(((s1_ptr)_2)->base + 1);
        _12014 = NOVALUE;
        if (IS_ATOM_INT(_12015)) {
            _12016 = (_12015 == 72);
        }
        else {
            _12016 = binary_op(EQUALS, _12015, 72);
        }
        _12015 = NOVALUE;
        if (_12016 == 0) {
            DeRef(_12016);
            _12016 = NOVALUE;
            goto L12; // [518] 557
        }
        else {
            if (!IS_ATOM_INT(_12016) && DBL_PTR(_12016)->dbl == 0.0){
                DeRef(_12016);
                _12016 = NOVALUE;
                goto L12; // [518] 557
            }
            DeRef(_12016);
            _12016 = NOVALUE;
        }
        DeRef(_12016);
        _12016 = NOVALUE;

        /** cmdline.e:452				if i > 1 then*/
        if (_i_21364 <= 1)
        goto L13; // [523] 534

        /** cmdline.e:453					printf(1, "\n")*/
        EPrintf(1, _8378, _5);
L13: 

        /** cmdline.e:456				printf(1, "%s\n", { opts[i][2] })*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _12019 = (object)*(((s1_ptr)_2)->base + _i_21364);
        _2 = (object)SEQ_PTR(_12019);
        _12020 = (object)*(((s1_ptr)_2)->base + 2);
        _12019 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_12020);
        ((intptr_t*)_2)[1] = _12020;
        _12021 = MAKE_SEQ(_1);
        _12020 = NOVALUE;
        EPrintf(1, _12018, _12021);
        DeRefDS(_12021);
        _12021 = NOVALUE;

        /** cmdline.e:457				continue*/
        goto L14; // [554] 569
L12: 

        /** cmdline.e:460			print_option_help( opts[i], pad_size )*/
        _2 = (object)SEQ_PTR(_opts_21263);
        _12022 = (object)*(((s1_ptr)_2)->base + _i_21364);
        Ref(_12022);
        _48print_option_help(_12022, _pad_size_21265);
        _12022 = NOVALUE;

        /** cmdline.e:461		end for*/
L14: 
        _i_21364 = _i_21364 + 1;
        goto L10; // [569] 488
L11: 
        ;
    }

    /** cmdline.e:463		print_extras_help( opts, extras_mandatory, extras_opt )*/
    RefDS(_opts_21263);
    _48print_extras_help(_opts_21263, _extras_mandatory_21267, _extras_opt_21268);

    /** cmdline.e:465		return pad_size*/
    DeRefDS(_opts_21263);
    DeRefDS(_cmds_21264);
    DeRef(_param_name_21269);
    _11955 = NOVALUE;
    _11968 = NOVALUE;
    _11991 = NOVALUE;
    return _pad_size_21265;
    ;
}


void _48print_extras_help(object _opts_21385, object _extras_mandatory_21386, object _extras_opt_21387)
{
    object _12039 = NOVALUE;
    object _12038 = NOVALUE;
    object _12037 = NOVALUE;
    object _12035 = NOVALUE;
    object _12034 = NOVALUE;
    object _12033 = NOVALUE;
    object _12030 = NOVALUE;
    object _12029 = NOVALUE;
    object _12028 = NOVALUE;
    object _12026 = NOVALUE;
    object _12025 = NOVALUE;
    object _12024 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:470		if extras_mandatory != 0 then*/
    if (_extras_mandatory_21386 == 0)
    goto L1; // [9] 64

    /** cmdline.e:471			if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (object)SEQ_PTR(_opts_21385);
    _12024 = (object)*(((s1_ptr)_2)->base + _extras_opt_21387);
    _2 = (object)SEQ_PTR(_12024);
    _12025 = (object)*(((s1_ptr)_2)->base + 3);
    _12024 = NOVALUE;
    if (IS_SEQUENCE(_12025)){
            _12026 = SEQ_PTR(_12025)->length;
    }
    else {
        _12026 = 1;
    }
    _12025 = NOVALUE;
    if (_12026 <= 0)
    goto L2; // [26] 55

    /** cmdline.e:472				puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (object)SEQ_PTR(_opts_21385);
    _12028 = (object)*(((s1_ptr)_2)->base + _extras_opt_21387);
    _2 = (object)SEQ_PTR(_12028);
    _12029 = (object)*(((s1_ptr)_2)->base + 3);
    _12028 = NOVALUE;
    if (IS_SEQUENCE(_8378) && IS_ATOM(_12029)) {
        Ref(_12029);
        Append(&_12030, _8378, _12029);
    }
    else if (IS_ATOM(_8378) && IS_SEQUENCE(_12029)) {
    }
    else {
        Concat((object_ptr)&_12030, _8378, _12029);
    }
    _12029 = NOVALUE;
    EPuts(1, _12030); // DJP 
    DeRefDS(_12030);
    _12030 = NOVALUE;

    /** cmdline.e:473				puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L3; // [52] 120
L2: 

    /** cmdline.e:475				puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _12031); // DJP 
    goto L3; // [61] 120
L1: 

    /** cmdline.e:477		elsif extras_opt > 0 then*/
    if (_extras_opt_21387 <= 0)
    goto L4; // [66] 119

    /** cmdline.e:478			if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (object)SEQ_PTR(_opts_21385);
    _12033 = (object)*(((s1_ptr)_2)->base + _extras_opt_21387);
    _2 = (object)SEQ_PTR(_12033);
    _12034 = (object)*(((s1_ptr)_2)->base + 3);
    _12033 = NOVALUE;
    if (IS_SEQUENCE(_12034)){
            _12035 = SEQ_PTR(_12034)->length;
    }
    else {
        _12035 = 1;
    }
    _12034 = NOVALUE;
    if (_12035 <= 0)
    goto L5; // [83] 112

    /** cmdline.e:479				puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (object)SEQ_PTR(_opts_21385);
    _12037 = (object)*(((s1_ptr)_2)->base + _extras_opt_21387);
    _2 = (object)SEQ_PTR(_12037);
    _12038 = (object)*(((s1_ptr)_2)->base + 3);
    _12037 = NOVALUE;
    if (IS_SEQUENCE(_8378) && IS_ATOM(_12038)) {
        Ref(_12038);
        Append(&_12039, _8378, _12038);
    }
    else if (IS_ATOM(_8378) && IS_SEQUENCE(_12038)) {
    }
    else {
        Concat((object_ptr)&_12039, _8378, _12038);
    }
    _12038 = NOVALUE;
    EPuts(1, _12039); // DJP 
    DeRefDS(_12039);
    _12039 = NOVALUE;

    /** cmdline.e:480				puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L6; // [109] 118
L5: 

    /** cmdline.e:482				puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _12040); // DJP 
L6: 
L4: 
L3: 

    /** cmdline.e:485	end procedure*/
    DeRefDS(_opts_21385);
    _12025 = NOVALUE;
    _12034 = NOVALUE;
    return;
    ;
}


void _48local_help(object _opts_21414, object _add_help_rid_21415, object _cmds_21416, object _std_21418, object _parse_options_21419)
{
    object _cmd_21420 = NOVALUE;
    object _is_mandatory_21421 = NOVALUE;
    object _extras_mandatory_21422 = NOVALUE;
    object _extras_opt_21423 = NOVALUE;
    object _auto_help_21424 = NOVALUE;
    object _po_21425 = NOVALUE;
    object _msg_inlined_crash_at_94_21444 = NOVALUE;
    object _pad_size_21451 = NOVALUE;
    object _12049 = NOVALUE;
    object _12046 = NOVALUE;
    object _12044 = NOVALUE;
    object _12042 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:492		integer extras_mandatory = 0*/
    _extras_mandatory_21422 = 0;

    /** cmdline.e:493		integer extras_opt = 0*/
    _extras_opt_21423 = 0;

    /** cmdline.e:494		integer auto_help = 1*/
    _auto_help_21424 = 1;

    /** cmdline.e:496		integer po = 1*/
    _po_21425 = 1;

    /** cmdline.e:497		if atom(parse_options) then*/
    _12042 = IS_ATOM(_parse_options_21419);
    if (_12042 == 0)
    {
        _12042 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _12042 = NOVALUE;
    }

    /** cmdline.e:498			parse_options = {parse_options}*/
    _0 = _parse_options_21419;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_parse_options_21419);
    ((intptr_t*)_2)[1] = _parse_options_21419;
    _parse_options_21419 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** cmdline.e:501		while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_21419)){
            _12044 = SEQ_PTR(_parse_options_21419)->length;
    }
    else {
        _12044 = 1;
    }
    if (_po_21425 > _12044)
    goto L3; // [50] 143

    /** cmdline.e:502			switch parse_options[po] do*/
    _2 = (object)SEQ_PTR(_parse_options_21419);
    _12046 = (object)*(((s1_ptr)_2)->base + _po_21425);
    if (IS_SEQUENCE(_12046) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_12046)){
        if( (DBL_PTR(_12046)->dbl != (eudouble) ((object) DBL_PTR(_12046)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (object) DBL_PTR(_12046)->dbl;
    }
    else {
        _0 = _12046;
    };
    _12046 = NOVALUE;
    switch ( _0 ){ 

        /** cmdline.e:503				case HELP_RID then*/
        case 1:

        /** cmdline.e:504					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_21419)){
                _12049 = SEQ_PTR(_parse_options_21419)->length;
        }
        else {
            _12049 = 1;
        }
        if (_po_21425 >= _12049)
        goto L5; // [74] 93

        /** cmdline.e:505						po += 1*/
        _po_21425 = _po_21425 + 1;

        /** cmdline.e:506						add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_21415);
        _2 = (object)SEQ_PTR(_parse_options_21419);
        _add_help_rid_21415 = (object)*(((s1_ptr)_2)->base + _po_21425);
        Ref(_add_help_rid_21415);
        goto L6; // [90] 132
L5: 

        /** cmdline.e:508						error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_21444);
        _msg_inlined_crash_at_94_21444 = EPrintf(-9999999, _12053, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_21444);

        /** error.e:53	end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_21444);
        _msg_inlined_crash_at_94_21444 = NOVALUE;
        goto L6; // [114] 132

        /** cmdline.e:511				case NO_HELP then*/
        case 9:

        /** cmdline.e:512					auto_help = 0*/
        _auto_help_21424 = 0;
        goto L6; // [125] 132

        /** cmdline.e:514				case else*/
        default:
L4: 
    ;}L6: 

    /** cmdline.e:518			po += 1*/
    _po_21425 = _po_21425 + 1;

    /** cmdline.e:519		end while*/
    goto L2; // [140] 47
L3: 

    /** cmdline.e:521		if std = 0 then*/
    if (_std_21418 != 0)
    goto L8; // [145] 159

    /** cmdline.e:522			opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_21414);
    _0 = _opts_21414;
    _opts_21414 = _48standardize_opts(_opts_21414, _auto_help_21424);
    DeRefDS(_0);
L8: 

    /** cmdline.e:525		integer pad_size = print_help( opts, cmds )*/
    RefDS(_opts_21414);
    RefDS(_cmds_21416);
    _pad_size_21451 = _48print_help(_opts_21414, _cmds_21416);
    if (!IS_ATOM_INT(_pad_size_21451)) {
        _1 = (object)(DBL_PTR(_pad_size_21451)->dbl);
        DeRefDS(_pad_size_21451);
        _pad_size_21451 = _1;
    }

    /** cmdline.e:527		call_user_help( add_help_rid )*/
    Ref(_add_help_rid_21415);
    _48call_user_help(_add_help_rid_21415);

    /** cmdline.e:529	end procedure*/
    DeRefDS(_opts_21414);
    DeRef(_add_help_rid_21415);
    DeRefDS(_cmds_21416);
    DeRef(_parse_options_21419);
    return;
    ;
}


void _48call_user_help(object _add_help_rid_21456)
{
    object _12073 = NOVALUE;
    object _12072 = NOVALUE;
    object _12071 = NOVALUE;
    object _12070 = NOVALUE;
    object _12068 = NOVALUE;
    object _12067 = NOVALUE;
    object _12066 = NOVALUE;
    object _12065 = NOVALUE;
    object _12064 = NOVALUE;
    object _12062 = NOVALUE;
    object _12060 = NOVALUE;
    object _12058 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:532		if atom(add_help_rid) then*/
    _12058 = IS_ATOM(_add_help_rid_21456);
    if (_12058 == 0)
    {
        _12058 = NOVALUE;
        goto L1; // [6] 34
    }
    else{
        _12058 = NOVALUE;
    }

    /** cmdline.e:533			if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_21456, 0)){
        goto L2; // [11] 142
    }

    /** cmdline.e:534				puts(1, "\n")*/
    EPuts(1, _8378); // DJP 

    /** cmdline.e:535				call_proc(add_help_rid, {})*/
    _0 = (object)_00[_add_help_rid_21456].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** cmdline.e:536				puts(1, "\n")*/
    EPuts(1, _8378); // DJP 
    goto L2; // [31] 142
L1: 

    /** cmdline.e:539			if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_21456)){
            _12060 = SEQ_PTR(_add_help_rid_21456)->length;
    }
    else {
        _12060 = 1;
    }
    if (_12060 <= 0)
    goto L3; // [39] 141

    /** cmdline.e:540				puts(1, "\n")*/
    EPuts(1, _8378); // DJP 

    /** cmdline.e:541				if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_21456);
    _12062 = _9t_display(_add_help_rid_21456);
    if (_12062 == 0) {
        DeRef(_12062);
        _12062 = NOVALUE;
        goto L4; // [54] 64
    }
    else {
        if (!IS_ATOM_INT(_12062) && DBL_PTR(_12062)->dbl == 0.0){
            DeRef(_12062);
            _12062 = NOVALUE;
            goto L4; // [54] 64
        }
        DeRef(_12062);
        _12062 = NOVALUE;
    }
    DeRef(_12062);
    _12062 = NOVALUE;

    /** cmdline.e:542					add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_21456;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_add_help_rid_21456);
    ((intptr_t*)_2)[1] = _add_help_rid_21456;
    _add_help_rid_21456 = MAKE_SEQ(_1);
    DeRef(_0);
L4: 

    /** cmdline.e:545				for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_21456)){
            _12064 = SEQ_PTR(_add_help_rid_21456)->length;
    }
    else {
        _12064 = 1;
    }
    {
        object _i_21469;
        _i_21469 = 1;
L5: 
        if (_i_21469 > _12064){
            goto L6; // [69] 135
        }

        /** cmdline.e:546					puts(1, add_help_rid[i])*/
        _2 = (object)SEQ_PTR(_add_help_rid_21456);
        _12065 = (object)*(((s1_ptr)_2)->base + _i_21469);
        EPuts(1, _12065); // DJP 
        _12065 = NOVALUE;

        /** cmdline.e:547					if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (object)SEQ_PTR(_add_help_rid_21456);
        _12066 = (object)*(((s1_ptr)_2)->base + _i_21469);
        if (IS_SEQUENCE(_12066)){
                _12067 = SEQ_PTR(_12066)->length;
        }
        else {
            _12067 = 1;
        }
        _12066 = NOVALUE;
        _12068 = (_12067 == 0);
        _12067 = NOVALUE;
        if (_12068 != 0) {
            goto L7; // [98] 122
        }
        _2 = (object)SEQ_PTR(_add_help_rid_21456);
        _12070 = (object)*(((s1_ptr)_2)->base + _i_21469);
        if (IS_SEQUENCE(_12070)){
                _12071 = SEQ_PTR(_12070)->length;
        }
        else {
            _12071 = 1;
        }
        _2 = (object)SEQ_PTR(_12070);
        _12072 = (object)*(((s1_ptr)_2)->base + _12071);
        _12070 = NOVALUE;
        if (IS_ATOM_INT(_12072)) {
            _12073 = (_12072 != 10);
        }
        else {
            _12073 = binary_op(NOTEQ, _12072, 10);
        }
        _12072 = NOVALUE;
        if (_12073 == 0) {
            DeRef(_12073);
            _12073 = NOVALUE;
            goto L8; // [118] 128
        }
        else {
            if (!IS_ATOM_INT(_12073) && DBL_PTR(_12073)->dbl == 0.0){
                DeRef(_12073);
                _12073 = NOVALUE;
                goto L8; // [118] 128
            }
            DeRef(_12073);
            _12073 = NOVALUE;
        }
        DeRef(_12073);
        _12073 = NOVALUE;
L7: 

        /** cmdline.e:548						puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L8: 

        /** cmdline.e:550				end for*/
        _i_21469 = _i_21469 + 1;
        goto L5; // [130] 76
L6: 
        ;
    }

    /** cmdline.e:552				puts(1, "\n")*/
    EPuts(1, _8378); // DJP 
L3: 
L2: 

    /** cmdline.e:555	end procedure*/
    DeRef(_add_help_rid_21456);
    _12066 = NOVALUE;
    DeRef(_12068);
    _12068 = NOVALUE;
    return;
    ;
}


void _48print_option_help(object _opt_21483, object _pad_size_21484)
{
    object _has_param_21491 = NOVALUE;
    object _param_name_21494 = NOVALUE;
    object _is_mandatory_21510 = NOVALUE;
    object _cmd_21514 = NOVALUE;
    object _12132 = NOVALUE;
    object _12131 = NOVALUE;
    object _12130 = NOVALUE;
    object _12129 = NOVALUE;
    object _12128 = NOVALUE;
    object _12127 = NOVALUE;
    object _12126 = NOVALUE;
    object _12123 = NOVALUE;
    object _12119 = NOVALUE;
    object _12116 = NOVALUE;
    object _12115 = NOVALUE;
    object _12108 = NOVALUE;
    object _12107 = NOVALUE;
    object _12106 = NOVALUE;
    object _12102 = NOVALUE;
    object _12099 = NOVALUE;
    object _12098 = NOVALUE;
    object _12095 = NOVALUE;
    object _12094 = NOVALUE;
    object _12092 = NOVALUE;
    object _12091 = NOVALUE;
    object _12089 = NOVALUE;
    object _12088 = NOVALUE;
    object _12087 = NOVALUE;
    object _12086 = NOVALUE;
    object _12083 = NOVALUE;
    object _12082 = NOVALUE;
    object _12079 = NOVALUE;
    object _12078 = NOVALUE;
    object _12077 = NOVALUE;
    object _12076 = NOVALUE;
    object _12075 = NOVALUE;
    object _12074 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:558		if atom(opt[SHORTNAME]) and atom(opt[LONGNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12074 = (object)*(((s1_ptr)_2)->base + 1);
    _12075 = IS_ATOM(_12074);
    _12074 = NOVALUE;
    if (_12075 == 0) {
        goto L1; // [14] 35
    }
    _2 = (object)SEQ_PTR(_opt_21483);
    _12077 = (object)*(((s1_ptr)_2)->base + 2);
    _12078 = IS_ATOM(_12077);
    _12077 = NOVALUE;
    if (_12078 == 0)
    {
        _12078 = NOVALUE;
        goto L1; // [26] 35
    }
    else{
        _12078 = NOVALUE;
    }

    /** cmdline.e:560			return*/
    DeRefDS(_opt_21483);
    DeRef(_param_name_21494);
    DeRef(_cmd_21514);
    return;
L1: 

    /** cmdline.e:563		integer has_param = find(HAS_PARAMETER, opt[OPTIONS])*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12079 = (object)*(((s1_ptr)_2)->base + 4);
    _has_param_21491 = find_from(112, _12079, 1);
    _12079 = NOVALUE;

    /** cmdline.e:564		sequence param_name*/

    /** cmdline.e:565		if has_param != 0 then*/
    if (_has_param_21491 == 0)
    goto L2; // [50] 124

    /** cmdline.e:566			if has_param < length(opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12082 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12082)){
            _12083 = SEQ_PTR(_12082)->length;
    }
    else {
        _12083 = 1;
    }
    _12082 = NOVALUE;
    if (_has_param_21491 >= _12083)
    goto L3; // [63] 115

    /** cmdline.e:567				has_param += 1*/
    _has_param_21491 = _has_param_21491 + 1;

    /** cmdline.e:568				if sequence(opt[OPTIONS][has_param]) then*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12086 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_12086);
    _12087 = (object)*(((s1_ptr)_2)->base + _has_param_21491);
    _12086 = NOVALUE;
    _12088 = IS_SEQUENCE(_12087);
    _12087 = NOVALUE;
    if (_12088 == 0)
    {
        _12088 = NOVALUE;
        goto L4; // [86] 104
    }
    else{
        _12088 = NOVALUE;
    }

    /** cmdline.e:569					param_name = opt[OPTIONS][has_param]*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12089 = (object)*(((s1_ptr)_2)->base + 4);
    DeRef(_param_name_21494);
    _2 = (object)SEQ_PTR(_12089);
    _param_name_21494 = (object)*(((s1_ptr)_2)->base + _has_param_21491);
    Ref(_param_name_21494);
    _12089 = NOVALUE;
    goto L5; // [101] 123
L4: 

    /** cmdline.e:571					param_name = "x"*/
    RefDS(_11831);
    DeRef(_param_name_21494);
    _param_name_21494 = _11831;
    goto L5; // [112] 123
L3: 

    /** cmdline.e:574				param_name = "x"*/
    RefDS(_11831);
    DeRef(_param_name_21494);
    _param_name_21494 = _11831;
L5: 
L2: 

    /** cmdline.e:577		integer is_mandatory = (find(MANDATORY, opt[OPTIONS]) != 0)*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12091 = (object)*(((s1_ptr)_2)->base + 4);
    _12092 = find_from(109, _12091, 1);
    _12091 = NOVALUE;
    _is_mandatory_21510 = (_12092 != 0);
    _12092 = NOVALUE;

    /** cmdline.e:578		sequence cmd = ""*/
    RefDS(_5);
    DeRef(_cmd_21514);
    _cmd_21514 = _5;

    /** cmdline.e:580		if sequence(opt[SHORTNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12094 = (object)*(((s1_ptr)_2)->base + 1);
    _12095 = IS_SEQUENCE(_12094);
    _12094 = NOVALUE;
    if (_12095 == 0)
    {
        _12095 = NOVALUE;
        goto L6; // [155] 216
    }
    else{
        _12095 = NOVALUE;
    }

    /** cmdline.e:581			if not is_mandatory then*/
    if (_is_mandatory_21510 != 0)
    goto L7; // [160] 170

    /** cmdline.e:582				cmd &= '['*/
    Append(&_cmd_21514, _cmd_21514, 91);
L7: 

    /** cmdline.e:584			cmd &= '-' & opt[SHORTNAME]*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12098 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(45) && IS_ATOM(_12098)) {
    }
    else if (IS_ATOM(45) && IS_SEQUENCE(_12098)) {
        Prepend(&_12099, _12098, 45);
    }
    else {
        Concat((object_ptr)&_12099, 45, _12098);
    }
    _12098 = NOVALUE;
    Concat((object_ptr)&_cmd_21514, _cmd_21514, _12099);
    DeRefDS(_12099);
    _12099 = NOVALUE;

    /** cmdline.e:585			if has_param != 0 then*/
    if (_has_param_21491 == 0)
    goto L8; // [186] 203

    /** cmdline.e:586				cmd &= ' ' & param_name*/
    Prepend(&_12102, _param_name_21494, 32);
    Concat((object_ptr)&_cmd_21514, _cmd_21514, _12102);
    DeRefDS(_12102);
    _12102 = NOVALUE;
L8: 

    /** cmdline.e:588			if not is_mandatory then*/
    if (_is_mandatory_21510 != 0)
    goto L9; // [205] 215

    /** cmdline.e:589				cmd &= ']'*/
    Append(&_cmd_21514, _cmd_21514, 93);
L9: 
L6: 

    /** cmdline.e:593		if sequence(opt[LONGNAME]) then*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12106 = (object)*(((s1_ptr)_2)->base + 2);
    _12107 = IS_SEQUENCE(_12106);
    _12106 = NOVALUE;
    if (_12107 == 0)
    {
        _12107 = NOVALUE;
        goto LA; // [225] 300
    }
    else{
        _12107 = NOVALUE;
    }

    /** cmdline.e:594			if length(cmd) > 0 then cmd &= ", " end if*/
    if (IS_SEQUENCE(_cmd_21514)){
            _12108 = SEQ_PTR(_cmd_21514)->length;
    }
    else {
        _12108 = 1;
    }
    if (_12108 <= 0)
    goto LB; // [233] 242
    Concat((object_ptr)&_cmd_21514, _cmd_21514, _12110);
LB: 

    /** cmdline.e:595			if not is_mandatory then*/
    if (_is_mandatory_21510 != 0)
    goto LC; // [244] 254

    /** cmdline.e:596				cmd &= '['*/
    Append(&_cmd_21514, _cmd_21514, 91);
LC: 

    /** cmdline.e:598			cmd &= "--" & opt[LONGNAME]*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12115 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_12114) && IS_ATOM(_12115)) {
        Ref(_12115);
        Append(&_12116, _12114, _12115);
    }
    else if (IS_ATOM(_12114) && IS_SEQUENCE(_12115)) {
    }
    else {
        Concat((object_ptr)&_12116, _12114, _12115);
    }
    _12115 = NOVALUE;
    Concat((object_ptr)&_cmd_21514, _cmd_21514, _12116);
    DeRefDS(_12116);
    _12116 = NOVALUE;

    /** cmdline.e:599			if has_param != 0 then*/
    if (_has_param_21491 == 0)
    goto LD; // [270] 287

    /** cmdline.e:600				cmd &= '=' & param_name*/
    Prepend(&_12119, _param_name_21494, 61);
    Concat((object_ptr)&_cmd_21514, _cmd_21514, _12119);
    DeRefDS(_12119);
    _12119 = NOVALUE;
LD: 

    /** cmdline.e:602			if not is_mandatory then*/
    if (_is_mandatory_21510 != 0)
    goto LE; // [289] 299

    /** cmdline.e:603				cmd &= ']'*/
    Append(&_cmd_21514, _cmd_21514, 93);
LE: 
LA: 

    /** cmdline.e:610		if length(cmd) > pad_size then*/
    if (IS_SEQUENCE(_cmd_21514)){
            _12123 = SEQ_PTR(_cmd_21514)->length;
    }
    else {
        _12123 = 1;
    }
    if (_12123 <= _pad_size_21484)
    goto LF; // [305] 336

    /** cmdline.e:611			puts(1, "   " & cmd & '\n')*/
    {
        object concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _cmd_21514;
        concat_list[2] = _12125;
        Concat_N((object_ptr)&_12126, concat_list, 3);
    }
    EPuts(1, _12126); // DJP 
    DeRefDS(_12126);
    _12126 = NOVALUE;

    /** cmdline.e:612			puts(1, repeat(' ', pad_size + 3))*/
    _12127 = _pad_size_21484 + 3;
    _12128 = Repeat(32, _12127);
    _12127 = NOVALUE;
    EPuts(1, _12128); // DJP 
    DeRefDS(_12128);
    _12128 = NOVALUE;
    goto L10; // [333] 352
LF: 

    /** cmdline.e:614			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
    RefDS(_cmd_21514);
    _12129 = _24pad_tail(_cmd_21514, _pad_size_21484, 32);
    if (IS_SEQUENCE(_12125) && IS_ATOM(_12129)) {
        Ref(_12129);
        Append(&_12130, _12125, _12129);
    }
    else if (IS_ATOM(_12125) && IS_SEQUENCE(_12129)) {
    }
    else {
        Concat((object_ptr)&_12130, _12125, _12129);
    }
    DeRef(_12129);
    _12129 = NOVALUE;
    EPuts(1, _12130); // DJP 
    DeRefDS(_12130);
    _12130 = NOVALUE;
L10: 

    /** cmdline.e:617		puts(1, opt[DESCRIPTION] & '\n')*/
    _2 = (object)SEQ_PTR(_opt_21483);
    _12131 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_12131) && IS_ATOM(10)) {
        Append(&_12132, _12131, 10);
    }
    else if (IS_ATOM(_12131) && IS_SEQUENCE(10)) {
    }
    else {
        Concat((object_ptr)&_12132, _12131, 10);
        _12131 = NOVALUE;
    }
    _12131 = NOVALUE;
    EPuts(1, _12132); // DJP 
    DeRefDS(_12132);
    _12132 = NOVALUE;

    /** cmdline.e:618	end procedure*/
    DeRefDS(_opt_21483);
    DeRef(_param_name_21494);
    DeRef(_cmd_21514);
    _12082 = NOVALUE;
    return;
    ;
}


object _48find_opt(object _opts_21574, object _opt_style_21575, object _cmd_text_21576)
{
    object _opt_name_21577 = NOVALUE;
    object _opt_param_21578 = NOVALUE;
    object _param_found_21579 = NOVALUE;
    object _reversed_21580 = NOVALUE;
    object _12235 = NOVALUE;
    object _12233 = NOVALUE;
    object _12232 = NOVALUE;
    object _12230 = NOVALUE;
    object _12229 = NOVALUE;
    object _12228 = NOVALUE;
    object _12227 = NOVALUE;
    object _12226 = NOVALUE;
    object _12223 = NOVALUE;
    object _12222 = NOVALUE;
    object _12221 = NOVALUE;
    object _12219 = NOVALUE;
    object _12218 = NOVALUE;
    object _12217 = NOVALUE;
    object _12216 = NOVALUE;
    object _12214 = NOVALUE;
    object _12213 = NOVALUE;
    object _12212 = NOVALUE;
    object _12211 = NOVALUE;
    object _12210 = NOVALUE;
    object _12209 = NOVALUE;
    object _12208 = NOVALUE;
    object _12207 = NOVALUE;
    object _12206 = NOVALUE;
    object _12205 = NOVALUE;
    object _12204 = NOVALUE;
    object _12203 = NOVALUE;
    object _12196 = NOVALUE;
    object _12195 = NOVALUE;
    object _12194 = NOVALUE;
    object _12187 = NOVALUE;
    object _12186 = NOVALUE;
    object _12184 = NOVALUE;
    object _12182 = NOVALUE;
    object _12181 = NOVALUE;
    object _12179 = NOVALUE;
    object _12178 = NOVALUE;
    object _12177 = NOVALUE;
    object _12176 = NOVALUE;
    object _12175 = NOVALUE;
    object _12173 = NOVALUE;
    object _12172 = NOVALUE;
    object _12170 = NOVALUE;
    object _12168 = NOVALUE;
    object _12167 = NOVALUE;
    object _12165 = NOVALUE;
    object _12164 = NOVALUE;
    object _12162 = NOVALUE;
    object _12161 = NOVALUE;
    object _12159 = NOVALUE;
    object _12158 = NOVALUE;
    object _12155 = NOVALUE;
    object _12153 = NOVALUE;
    object _12152 = NOVALUE;
    object _12150 = NOVALUE;
    object _12148 = NOVALUE;
    object _12146 = NOVALUE;
    object _12145 = NOVALUE;
    object _12143 = NOVALUE;
    object _12142 = NOVALUE;
    object _12141 = NOVALUE;
    object _12140 = NOVALUE;
    object _12139 = NOVALUE;
    object _12137 = NOVALUE;
    object _12136 = NOVALUE;
    object _12134 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:793		integer param_found = 0*/
    _param_found_21579 = 0;

    /** cmdline.e:794		integer reversed = 0*/
    _reversed_21580 = 0;

    /** cmdline.e:796		if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12134 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12134 = 1;
    }
    if (_12134 < 2)
    goto L1; // [20] 85

    /** cmdline.e:798			if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (object)SEQ_PTR(_cmd_text_21576);
    _12136 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_12136)) {
        _12137 = (_12136 == 39);
    }
    else {
        _12137 = binary_op(EQUALS, _12136, 39);
    }
    _12136 = NOVALUE;
    if (IS_ATOM_INT(_12137)) {
        if (_12137 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_12137)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (object)SEQ_PTR(_cmd_text_21576);
    _12139 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_12139)) {
        _12140 = (_12139 == 34);
    }
    else {
        _12140 = binary_op(EQUALS, _12139, 34);
    }
    _12139 = NOVALUE;
    if (_12140 == 0) {
        DeRef(_12140);
        _12140 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_12140) && DBL_PTR(_12140)->dbl == 0.0){
            DeRef(_12140);
            _12140 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_12140);
        _12140 = NOVALUE;
    }
    DeRef(_12140);
    _12140 = NOVALUE;
L2: 

    /** cmdline.e:799				if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12141 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12141 = 1;
    }
    _2 = (object)SEQ_PTR(_cmd_text_21576);
    _12142 = (object)*(((s1_ptr)_2)->base + _12141);
    _2 = (object)SEQ_PTR(_cmd_text_21576);
    _12143 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12142, _12143)){
        _12142 = NOVALUE;
        _12143 = NOVALUE;
        goto L4; // [64] 83
    }
    _12142 = NOVALUE;
    _12143 = NOVALUE;

    /** cmdline.e:800					cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12145 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12145 = 1;
    }
    _12146 = _12145 - 1;
    _12145 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_21576;
    RHS_Slice(_cmd_text_21576, 2, _12146);
L4: 
L3: 
L1: 

    /** cmdline.e:805		if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12148 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12148 = 1;
    }
    if (_12148 <= 0)
    goto L5; // [90] 125

    /** cmdline.e:806			if find(cmd_text[1], "!-") then*/
    _2 = (object)SEQ_PTR(_cmd_text_21576);
    _12150 = (object)*(((s1_ptr)_2)->base + 1);
    _12152 = find_from(_12150, _12151, 1);
    _12150 = NOVALUE;
    if (_12152 == 0)
    {
        _12152 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _12152 = NOVALUE;
    }

    /** cmdline.e:807				reversed = 1*/
    _reversed_21580 = 1;

    /** cmdline.e:808				cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12153 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12153 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_21576;
    RHS_Slice(_cmd_text_21576, 2, _12153);
L6: 
L5: 

    /** cmdline.e:812		if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12155 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12155 = 1;
    }
    if (_12155 >= 1)
    goto L7; // [130] 145

    /** cmdline.e:813			return {-1, "Empty command text"}*/
    RefDS(_12157);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _12157;
    _12158 = MAKE_SEQ(_1);
    DeRefDS(_opts_21574);
    DeRefDS(_opt_style_21575);
    DeRef(_cmd_text_21576);
    DeRef(_opt_name_21577);
    DeRef(_opt_param_21578);
    DeRef(_12137);
    _12137 = NOVALUE;
    DeRef(_12146);
    _12146 = NOVALUE;
    return _12158;
L7: 

    /** cmdline.e:816		opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12159 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12159 = 1;
    }
    DeRef(_opt_name_21577);
    _opt_name_21577 = Repeat(32, _12159);
    _12159 = NOVALUE;

    /** cmdline.e:817		opt_param = 0*/
    DeRef(_opt_param_21578);
    _opt_param_21578 = 0;

    /** cmdline.e:818		for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_21576)){
            _12161 = SEQ_PTR(_cmd_text_21576)->length;
    }
    else {
        _12161 = 1;
    }
    {
        object _i_21615;
        _i_21615 = 1;
L8: 
        if (_i_21615 > _12161){
            goto L9; // [164] 320
        }

        /** cmdline.e:819			if find(cmd_text[i], ":=") then*/
        _2 = (object)SEQ_PTR(_cmd_text_21576);
        _12162 = (object)*(((s1_ptr)_2)->base + _i_21615);
        _12164 = find_from(_12162, _12163, 1);
        _12162 = NOVALUE;
        if (_12164 == 0)
        {
            _12164 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _12164 = NOVALUE;
        }

        /** cmdline.e:820				opt_name = opt_name[1 .. i - 1]*/
        _12165 = _i_21615 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_21577;
        RHS_Slice(_opt_name_21577, 1, _12165);

        /** cmdline.e:821				opt_param = cmd_text[i + 1 .. $]*/
        _12167 = _i_21615 + 1;
        if (IS_SEQUENCE(_cmd_text_21576)){
                _12168 = SEQ_PTR(_cmd_text_21576)->length;
        }
        else {
            _12168 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_21578;
        RHS_Slice(_cmd_text_21576, _12167, _12168);

        /** cmdline.e:822				if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_21578)){
                _12170 = SEQ_PTR(_opt_param_21578)->length;
        }
        else {
            _12170 = 1;
        }
        if (_12170 < 2)
        goto LB; // [215] 280

        /** cmdline.e:824					if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (object)SEQ_PTR(_opt_param_21578);
        _12172 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_12172)) {
            _12173 = (_12172 == 39);
        }
        else {
            _12173 = binary_op(EQUALS, _12172, 39);
        }
        _12172 = NOVALUE;
        if (IS_ATOM_INT(_12173)) {
            if (_12173 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_12173)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (object)SEQ_PTR(_opt_param_21578);
        _12175 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_12175)) {
            _12176 = (_12175 == 34);
        }
        else {
            _12176 = binary_op(EQUALS, _12175, 34);
        }
        _12175 = NOVALUE;
        if (_12176 == 0) {
            DeRef(_12176);
            _12176 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_12176) && DBL_PTR(_12176)->dbl == 0.0){
                DeRef(_12176);
                _12176 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_12176);
            _12176 = NOVALUE;
        }
        DeRef(_12176);
        _12176 = NOVALUE;
LC: 

        /** cmdline.e:825						if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_21578)){
                _12177 = SEQ_PTR(_opt_param_21578)->length;
        }
        else {
            _12177 = 1;
        }
        _2 = (object)SEQ_PTR(_opt_param_21578);
        _12178 = (object)*(((s1_ptr)_2)->base + _12177);
        _2 = (object)SEQ_PTR(_opt_param_21578);
        _12179 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _12178, _12179)){
            _12178 = NOVALUE;
            _12179 = NOVALUE;
            goto LE; // [259] 278
        }
        _12178 = NOVALUE;
        _12179 = NOVALUE;

        /** cmdline.e:826							opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_21578)){
                _12181 = SEQ_PTR(_opt_param_21578)->length;
        }
        else {
            _12181 = 1;
        }
        _12182 = _12181 - 1;
        _12181 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_21578;
        RHS_Slice(_opt_param_21578, 2, _12182);
LE: 
LD: 
LB: 

        /** cmdline.e:831				if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_21578)){
                _12184 = SEQ_PTR(_opt_param_21578)->length;
        }
        else {
            _12184 = 1;
        }
        if (_12184 <= 0)
        goto L9; // [285] 320

        /** cmdline.e:832					param_found = 1*/
        _param_found_21579 = 1;

        /** cmdline.e:835				exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** cmdline.e:837				opt_name[i] = cmd_text[i]*/
        _2 = (object)SEQ_PTR(_cmd_text_21576);
        _12186 = (object)*(((s1_ptr)_2)->base + _i_21615);
        Ref(_12186);
        _2 = (object)SEQ_PTR(_opt_name_21577);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _opt_name_21577 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_21615);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12186;
        if( _1 != _12186 ){
            DeRef(_1);
        }
        _12186 = NOVALUE;
LF: 

        /** cmdline.e:839		end for*/
        _i_21615 = _i_21615 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** cmdline.e:841		if param_found then*/
    if (_param_found_21579 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** cmdline.e:842			if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_21578);
    _12187 = _12lower(_opt_param_21578);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_10447);
    ((intptr_t*)_2)[1] = _10447;
    RefDS(_12188);
    ((intptr_t*)_2)[2] = _12188;
    RefDS(_12189);
    ((intptr_t*)_2)[3] = _12189;
    RefDS(_12190);
    ((intptr_t*)_2)[4] = _12190;
    RefDS(_12191);
    ((intptr_t*)_2)[5] = _12191;
    RefDS(_12192);
    ((intptr_t*)_2)[6] = _12192;
    RefDS(_12193);
    ((intptr_t*)_2)[7] = _12193;
    _12194 = MAKE_SEQ(_1);
    _12195 = find_from(_12187, _12194, 1);
    DeRef(_12187);
    _12187 = NOVALUE;
    DeRefDS(_12194);
    _12194 = NOVALUE;
    if (_12195 == 0)
    {
        _12195 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _12195 = NOVALUE;
    }

    /** cmdline.e:843				opt_param = 1*/
    DeRef(_opt_param_21578);
    _opt_param_21578 = 1;
    goto L12; // [354] 387
L11: 

    /** cmdline.e:844			elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_21578);
    _12196 = _12lower(_opt_param_21578);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12197);
    ((intptr_t*)_2)[1] = _12197;
    RefDS(_12198);
    ((intptr_t*)_2)[2] = _12198;
    RefDS(_12199);
    ((intptr_t*)_2)[3] = _12199;
    RefDS(_12200);
    ((intptr_t*)_2)[4] = _12200;
    RefDS(_12201);
    ((intptr_t*)_2)[5] = _12201;
    RefDS(_12202);
    ((intptr_t*)_2)[6] = _12202;
    _12203 = MAKE_SEQ(_1);
    _12204 = find_from(_12196, _12203, 1);
    DeRef(_12196);
    _12196 = NOVALUE;
    DeRefDS(_12203);
    _12203 = NOVALUE;
    if (_12204 == 0)
    {
        _12204 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _12204 = NOVALUE;
    }

    /** cmdline.e:845				opt_param = 0*/
    DeRef(_opt_param_21578);
    _opt_param_21578 = 0;
L13: 
L12: 
L10: 

    /** cmdline.e:849		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21574)){
            _12205 = SEQ_PTR(_opts_21574)->length;
    }
    else {
        _12205 = 1;
    }
    {
        object _i_21670;
        _i_21670 = 1;
L14: 
        if (_i_21670 > _12205){
            goto L15; // [393] 592
        }

        /** cmdline.e:850			if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21574);
        _12206 = (object)*(((s1_ptr)_2)->base + _i_21670);
        _2 = (object)SEQ_PTR(_12206);
        _12207 = (object)*(((s1_ptr)_2)->base + 4);
        _12206 = NOVALUE;
        _12208 = find_from(105, _12207, 1);
        _12207 = NOVALUE;
        if (_12208 == 0)
        {
            _12208 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _12208 = NOVALUE;
        }

        /** cmdline.e:851				if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_21577);
        _12209 = _12lower(_opt_name_21577);
        _2 = (object)SEQ_PTR(_opts_21574);
        _12210 = (object)*(((s1_ptr)_2)->base + _i_21670);
        _2 = (object)SEQ_PTR(_opt_style_21575);
        _12211 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_12210);
        if (!IS_ATOM_INT(_12211)){
            _12212 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12211)->dbl));
        }
        else{
            _12212 = (object)*(((s1_ptr)_2)->base + _12211);
        }
        _12210 = NOVALUE;
        Ref(_12212);
        _12213 = _12lower(_12212);
        _12212 = NOVALUE;
        if (_12209 == _12213)
        _12214 = 1;
        else if (IS_ATOM_INT(_12209) && IS_ATOM_INT(_12213))
        _12214 = 0;
        else
        _12214 = (compare(_12209, _12213) == 0);
        DeRef(_12209);
        _12209 = NOVALUE;
        DeRef(_12213);
        _12213 = NOVALUE;
        if (_12214 != 0)
        goto L17; // [444] 482
        _12214 = NOVALUE;

        /** cmdline.e:852					continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** cmdline.e:855				if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (object)SEQ_PTR(_opts_21574);
        _12216 = (object)*(((s1_ptr)_2)->base + _i_21670);
        _2 = (object)SEQ_PTR(_opt_style_21575);
        _12217 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_12216);
        if (!IS_ATOM_INT(_12217)){
            _12218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12217)->dbl));
        }
        else{
            _12218 = (object)*(((s1_ptr)_2)->base + _12217);
        }
        _12216 = NOVALUE;
        if (_opt_name_21577 == _12218)
        _12219 = 1;
        else if (IS_ATOM_INT(_opt_name_21577) && IS_ATOM_INT(_12218))
        _12219 = 0;
        else
        _12219 = (compare(_opt_name_21577, _12218) == 0);
        _12218 = NOVALUE;
        if (_12219 != 0)
        goto L19; // [473] 481
        _12219 = NOVALUE;

        /** cmdline.e:856					continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** cmdline.e:860			if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21574);
        _12221 = (object)*(((s1_ptr)_2)->base + _i_21670);
        _2 = (object)SEQ_PTR(_12221);
        _12222 = (object)*(((s1_ptr)_2)->base + 4);
        _12221 = NOVALUE;
        _12223 = find_from(112, _12222, 1);
        _12222 = NOVALUE;
        if (_12223 != 0)
        goto L1A; // [497] 518

        /** cmdline.e:861				if param_found then*/
        if (_param_found_21579 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** cmdline.e:862					return {0, "Option should not have a parameter"}*/
        RefDS(_12225);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 0;
        ((intptr_t *)_2)[2] = _12225;
        _12226 = MAKE_SEQ(_1);
        DeRefDS(_opts_21574);
        DeRefDS(_opt_style_21575);
        DeRef(_cmd_text_21576);
        DeRef(_opt_name_21577);
        DeRef(_opt_param_21578);
        DeRef(_12158);
        _12158 = NOVALUE;
        DeRef(_12173);
        _12173 = NOVALUE;
        DeRef(_12137);
        _12137 = NOVALUE;
        DeRef(_12146);
        _12146 = NOVALUE;
        DeRef(_12182);
        _12182 = NOVALUE;
        DeRef(_12167);
        _12167 = NOVALUE;
        _12217 = NOVALUE;
        _12211 = NOVALUE;
        DeRef(_12165);
        _12165 = NOVALUE;
        return _12226;
L1B: 
L1A: 

        /** cmdline.e:866			if param_found then*/
        if (_param_found_21579 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** cmdline.e:867				return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_21670;
        RefDS(_opt_name_21577);
        ((intptr_t*)_2)[2] = _opt_name_21577;
        ((intptr_t*)_2)[3] = _reversed_21580;
        Ref(_opt_param_21578);
        ((intptr_t*)_2)[4] = _opt_param_21578;
        _12227 = MAKE_SEQ(_1);
        DeRefDS(_opts_21574);
        DeRefDS(_opt_style_21575);
        DeRef(_cmd_text_21576);
        DeRefDS(_opt_name_21577);
        DeRef(_opt_param_21578);
        DeRef(_12158);
        _12158 = NOVALUE;
        DeRef(_12173);
        _12173 = NOVALUE;
        DeRef(_12137);
        _12137 = NOVALUE;
        DeRef(_12146);
        _12146 = NOVALUE;
        DeRef(_12182);
        _12182 = NOVALUE;
        DeRef(_12167);
        _12167 = NOVALUE;
        DeRef(_12226);
        _12226 = NOVALUE;
        _12217 = NOVALUE;
        _12211 = NOVALUE;
        DeRef(_12165);
        _12165 = NOVALUE;
        return _12227;
        goto L1D; // [536] 585
L1C: 

        /** cmdline.e:869				if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21574);
        _12228 = (object)*(((s1_ptr)_2)->base + _i_21670);
        _2 = (object)SEQ_PTR(_12228);
        _12229 = (object)*(((s1_ptr)_2)->base + 4);
        _12228 = NOVALUE;
        _12230 = find_from(112, _12229, 1);
        _12229 = NOVALUE;
        if (_12230 != 0)
        goto L1E; // [554] 572

        /** cmdline.e:870					return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_21670;
        RefDS(_opt_name_21577);
        ((intptr_t*)_2)[2] = _opt_name_21577;
        ((intptr_t*)_2)[3] = _reversed_21580;
        ((intptr_t*)_2)[4] = 1;
        _12232 = MAKE_SEQ(_1);
        DeRefDS(_opts_21574);
        DeRefDS(_opt_style_21575);
        DeRef(_cmd_text_21576);
        DeRefDS(_opt_name_21577);
        DeRef(_opt_param_21578);
        DeRef(_12158);
        _12158 = NOVALUE;
        DeRef(_12173);
        _12173 = NOVALUE;
        DeRef(_12137);
        _12137 = NOVALUE;
        DeRef(_12146);
        _12146 = NOVALUE;
        DeRef(_12182);
        _12182 = NOVALUE;
        DeRef(_12167);
        _12167 = NOVALUE;
        DeRef(_12226);
        _12226 = NOVALUE;
        _12217 = NOVALUE;
        _12211 = NOVALUE;
        DeRef(_12165);
        _12165 = NOVALUE;
        DeRef(_12227);
        _12227 = NOVALUE;
        return _12232;
L1E: 

        /** cmdline.e:873				return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _i_21670;
        RefDS(_opt_name_21577);
        ((intptr_t*)_2)[2] = _opt_name_21577;
        ((intptr_t*)_2)[3] = _reversed_21580;
        _12233 = MAKE_SEQ(_1);
        DeRefDS(_opts_21574);
        DeRefDS(_opt_style_21575);
        DeRef(_cmd_text_21576);
        DeRefDS(_opt_name_21577);
        DeRef(_opt_param_21578);
        DeRef(_12158);
        _12158 = NOVALUE;
        DeRef(_12232);
        _12232 = NOVALUE;
        DeRef(_12173);
        _12173 = NOVALUE;
        DeRef(_12137);
        _12137 = NOVALUE;
        DeRef(_12146);
        _12146 = NOVALUE;
        DeRef(_12182);
        _12182 = NOVALUE;
        DeRef(_12167);
        _12167 = NOVALUE;
        DeRef(_12226);
        _12226 = NOVALUE;
        _12217 = NOVALUE;
        _12211 = NOVALUE;
        DeRef(_12165);
        _12165 = NOVALUE;
        DeRef(_12227);
        _12227 = NOVALUE;
        return _12233;
L1D: 

        /** cmdline.e:875		end for*/
L18: 
        _i_21670 = _i_21670 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** cmdline.e:877		return {0, "Unrecognised"}*/
    RefDS(_12234);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _12234;
    _12235 = MAKE_SEQ(_1);
    DeRefDS(_opts_21574);
    DeRefDS(_opt_style_21575);
    DeRef(_cmd_text_21576);
    DeRef(_opt_name_21577);
    DeRef(_opt_param_21578);
    DeRef(_12158);
    _12158 = NOVALUE;
    DeRef(_12232);
    _12232 = NOVALUE;
    DeRef(_12173);
    _12173 = NOVALUE;
    DeRef(_12137);
    _12137 = NOVALUE;
    DeRef(_12146);
    _12146 = NOVALUE;
    DeRef(_12182);
    _12182 = NOVALUE;
    DeRef(_12233);
    _12233 = NOVALUE;
    DeRef(_12167);
    _12167 = NOVALUE;
    DeRef(_12226);
    _12226 = NOVALUE;
    _12217 = NOVALUE;
    _12211 = NOVALUE;
    DeRef(_12165);
    _12165 = NOVALUE;
    DeRef(_12227);
    _12227 = NOVALUE;
    return _12235;
    ;
}


object _48get_help_options(object _opts_21713)
{
    object _help_opts_21714 = NOVALUE;
    object _12258 = NOVALUE;
    object _12257 = NOVALUE;
    object _12256 = NOVALUE;
    object _12254 = NOVALUE;
    object _12253 = NOVALUE;
    object _12252 = NOVALUE;
    object _12250 = NOVALUE;
    object _12249 = NOVALUE;
    object _12248 = NOVALUE;
    object _12247 = NOVALUE;
    object _12246 = NOVALUE;
    object _12244 = NOVALUE;
    object _12243 = NOVALUE;
    object _12242 = NOVALUE;
    object _12241 = NOVALUE;
    object _12240 = NOVALUE;
    object _12239 = NOVALUE;
    object _12238 = NOVALUE;
    object _12237 = NOVALUE;
    object _12236 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:881		sequence help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_21714);
    _help_opts_21714 = _5;

    /** cmdline.e:883		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21713)){
            _12236 = SEQ_PTR(_opts_21713)->length;
    }
    else {
        _12236 = 1;
    }
    {
        object _i_21716;
        _i_21716 = 1;
L1: 
        if (_i_21716 > _12236){
            goto L2; // [15] 170
        }

        /** cmdline.e:884			if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21713);
        _12237 = (object)*(((s1_ptr)_2)->base + _i_21716);
        _2 = (object)SEQ_PTR(_12237);
        _12238 = (object)*(((s1_ptr)_2)->base + 4);
        _12237 = NOVALUE;
        _12239 = find_from(104, _12238, 1);
        _12238 = NOVALUE;
        if (_12239 == 0)
        {
            _12239 = NOVALUE;
            goto L3; // [37] 163
        }
        else{
            _12239 = NOVALUE;
        }

        /** cmdline.e:885				if sequence(opts[i][SHORTNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21713);
        _12240 = (object)*(((s1_ptr)_2)->base + _i_21716);
        _2 = (object)SEQ_PTR(_12240);
        _12241 = (object)*(((s1_ptr)_2)->base + 1);
        _12240 = NOVALUE;
        _12242 = IS_SEQUENCE(_12241);
        _12241 = NOVALUE;
        if (_12242 == 0)
        {
            _12242 = NOVALUE;
            goto L4; // [53] 71
        }
        else{
            _12242 = NOVALUE;
        }

        /** cmdline.e:886					help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (object)SEQ_PTR(_opts_21713);
        _12243 = (object)*(((s1_ptr)_2)->base + _i_21716);
        _2 = (object)SEQ_PTR(_12243);
        _12244 = (object)*(((s1_ptr)_2)->base + 1);
        _12243 = NOVALUE;
        Ref(_12244);
        Append(&_help_opts_21714, _help_opts_21714, _12244);
        _12244 = NOVALUE;
L4: 

        /** cmdline.e:889				if sequence(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21713);
        _12246 = (object)*(((s1_ptr)_2)->base + _i_21716);
        _2 = (object)SEQ_PTR(_12246);
        _12247 = (object)*(((s1_ptr)_2)->base + 2);
        _12246 = NOVALUE;
        _12248 = IS_SEQUENCE(_12247);
        _12247 = NOVALUE;
        if (_12248 == 0)
        {
            _12248 = NOVALUE;
            goto L5; // [84] 102
        }
        else{
            _12248 = NOVALUE;
        }

        /** cmdline.e:890					help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (object)SEQ_PTR(_opts_21713);
        _12249 = (object)*(((s1_ptr)_2)->base + _i_21716);
        _2 = (object)SEQ_PTR(_12249);
        _12250 = (object)*(((s1_ptr)_2)->base + 2);
        _12249 = NOVALUE;
        Ref(_12250);
        Append(&_help_opts_21714, _help_opts_21714, _12250);
        _12250 = NOVALUE;
L5: 

        /** cmdline.e:893				if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21713);
        _12252 = (object)*(((s1_ptr)_2)->base + _i_21716);
        _2 = (object)SEQ_PTR(_12252);
        _12253 = (object)*(((s1_ptr)_2)->base + 4);
        _12252 = NOVALUE;
        _12254 = find_from(105, _12253, 1);
        _12253 = NOVALUE;
        if (_12254 == 0)
        {
            _12254 = NOVALUE;
            goto L6; // [117] 162
        }
        else{
            _12254 = NOVALUE;
        }

        /** cmdline.e:894					help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_21714);
        _0 = _help_opts_21714;
        _help_opts_21714 = _12lower(_help_opts_21714);
        DeRefDS(_0);

        /** cmdline.e:895					for j = 1 to length(help_opts) do*/
        if (IS_SEQUENCE(_help_opts_21714)){
                _12256 = SEQ_PTR(_help_opts_21714)->length;
        }
        else {
            _12256 = 1;
        }
        {
            object _j_21742;
            _j_21742 = 1;
L7: 
            if (_j_21742 > _12256){
                goto L8; // [133] 161
            }

            /** cmdline.e:896						help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (object)SEQ_PTR(_help_opts_21714);
            _12257 = (object)*(((s1_ptr)_2)->base + _j_21742);
            Ref(_12257);
            _12258 = _12upper(_12257);
            _12257 = NOVALUE;
            Ref(_12258);
            Append(&_help_opts_21714, _help_opts_21714, _12258);
            DeRef(_12258);
            _12258 = NOVALUE;

            /** cmdline.e:897					end for*/
            _j_21742 = _j_21742 + 1;
            goto L7; // [156] 140
L8: 
            ;
        }
L6: 
L3: 

        /** cmdline.e:900		end for*/
        _i_21716 = _i_21716 + 1;
        goto L1; // [165] 22
L2: 
        ;
    }

    /** cmdline.e:901		return help_opts*/
    DeRefDS(_opts_21713);
    return _help_opts_21714;
    ;
}


object _48parse_at_cmds(object _cmd_21749, object _cmds_21750, object _opts_21751, object _arg_idx_21752, object _add_help_rid_21753, object _parse_options_21754, object _help_on_error_21755, object _auto_help_21756)
{
    object _at_cmds_21757 = NOVALUE;
    object _j_21758 = NOVALUE;
    object _cmdex_21842 = NOVALUE;
    object _12339 = NOVALUE;
    object _12338 = NOVALUE;
    object _12335 = NOVALUE;
    object _12334 = NOVALUE;
    object _12333 = NOVALUE;
    object _12332 = NOVALUE;
    object _12331 = NOVALUE;
    object _12330 = NOVALUE;
    object _12329 = NOVALUE;
    object _12328 = NOVALUE;
    object _12327 = NOVALUE;
    object _12326 = NOVALUE;
    object _12325 = NOVALUE;
    object _12324 = NOVALUE;
    object _12323 = NOVALUE;
    object _12322 = NOVALUE;
    object _12321 = NOVALUE;
    object _12320 = NOVALUE;
    object _12319 = NOVALUE;
    object _12318 = NOVALUE;
    object _12317 = NOVALUE;
    object _12316 = NOVALUE;
    object _12315 = NOVALUE;
    object _12314 = NOVALUE;
    object _12313 = NOVALUE;
    object _12312 = NOVALUE;
    object _12311 = NOVALUE;
    object _12310 = NOVALUE;
    object _12309 = NOVALUE;
    object _12308 = NOVALUE;
    object _12307 = NOVALUE;
    object _12306 = NOVALUE;
    object _12305 = NOVALUE;
    object _12304 = NOVALUE;
    object _12301 = NOVALUE;
    object _12300 = NOVALUE;
    object _12299 = NOVALUE;
    object _12298 = NOVALUE;
    object _12297 = NOVALUE;
    object _12295 = NOVALUE;
    object _12294 = NOVALUE;
    object _12291 = NOVALUE;
    object _12290 = NOVALUE;
    object _12289 = NOVALUE;
    object _12288 = NOVALUE;
    object _12287 = NOVALUE;
    object _12285 = NOVALUE;
    object _12284 = NOVALUE;
    object _12283 = NOVALUE;
    object _12282 = NOVALUE;
    object _12279 = NOVALUE;
    object _12277 = NOVALUE;
    object _12276 = NOVALUE;
    object _12275 = NOVALUE;
    object _12273 = NOVALUE;
    object _12271 = NOVALUE;
    object _12270 = NOVALUE;
    object _12268 = NOVALUE;
    object _12266 = NOVALUE;
    object _12265 = NOVALUE;
    object _12264 = NOVALUE;
    object _12263 = NOVALUE;
    object _12262 = NOVALUE;
    object _12261 = NOVALUE;
    object _12260 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:912		if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_21749)){
            _12260 = SEQ_PTR(_cmd_21749)->length;
    }
    else {
        _12260 = 1;
    }
    _12261 = (_12260 > 2);
    _12260 = NOVALUE;
    if (_12261 == 0) {
        goto L1; // [22] 78
    }
    _2 = (object)SEQ_PTR(_cmd_21749);
    _12263 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_12263)) {
        _12264 = (_12263 == 64);
    }
    else {
        _12264 = binary_op(EQUALS, _12263, 64);
    }
    _12263 = NOVALUE;
    if (_12264 == 0) {
        DeRef(_12264);
        _12264 = NOVALUE;
        goto L1; // [35] 78
    }
    else {
        if (!IS_ATOM_INT(_12264) && DBL_PTR(_12264)->dbl == 0.0){
            DeRef(_12264);
            _12264 = NOVALUE;
            goto L1; // [35] 78
        }
        DeRef(_12264);
        _12264 = NOVALUE;
    }
    DeRef(_12264);
    _12264 = NOVALUE;

    /** cmdline.e:914			at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_21749)){
            _12265 = SEQ_PTR(_cmd_21749)->length;
    }
    else {
        _12265 = 1;
    }
    rhs_slice_target = (object_ptr)&_12266;
    RHS_Slice(_cmd_21749, 3, _12265);
    _0 = _at_cmds_21757;
    _at_cmds_21757 = _18read_lines(_12266);
    DeRef(_0);
    _12266 = NOVALUE;

    /** cmdline.e:915			if equal(at_cmds, -1) then*/
    if (_at_cmds_21757 == -1)
    _12268 = 1;
    else if (IS_ATOM_INT(_at_cmds_21757) && IS_ATOM_INT(-1))
    _12268 = 0;
    else
    _12268 = (compare(_at_cmds_21757, -1) == 0);
    if (_12268 == 0)
    {
        _12268 = NOVALUE;
        goto L2; // [58] 156
    }
    else{
        _12268 = NOVALUE;
    }

    /** cmdline.e:918				cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_21750);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_21752)) ? _arg_idx_21752 : (object)(DBL_PTR(_arg_idx_21752)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_21752)) ? _arg_idx_21752 : (object)(DBL_PTR(_arg_idx_21752)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_21750), start, &_cmds_21750 );
            }
            else Tail(SEQ_PTR(_cmds_21750), stop+1, &_cmds_21750);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_21750), start, &_cmds_21750);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_21750 = Remove_elements(start, stop, (SEQ_PTR(_cmds_21750)->ref == 1));
        }
    }

    /** cmdline.e:919				return cmds*/
    DeRefDS(_cmd_21749);
    DeRefDS(_opts_21751);
    DeRef(_add_help_rid_21753);
    DeRef(_parse_options_21754);
    DeRef(_at_cmds_21757);
    DeRef(_12261);
    _12261 = NOVALUE;
    return _cmds_21750;
    goto L2; // [75] 156
L1: 

    /** cmdline.e:923			at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_21749)){
            _12270 = SEQ_PTR(_cmd_21749)->length;
    }
    else {
        _12270 = 1;
    }
    rhs_slice_target = (object_ptr)&_12271;
    RHS_Slice(_cmd_21749, 2, _12270);
    _0 = _at_cmds_21757;
    _at_cmds_21757 = _18read_lines(_12271);
    DeRef(_0);
    _12271 = NOVALUE;

    /** cmdline.e:924			if equal(at_cmds, -1) then*/
    if (_at_cmds_21757 == -1)
    _12273 = 1;
    else if (IS_ATOM_INT(_at_cmds_21757) && IS_ATOM_INT(-1))
    _12273 = 0;
    else
    _12273 = (compare(_at_cmds_21757, -1) == 0);
    if (_12273 == 0)
    {
        _12273 = NOVALUE;
        goto L3; // [98] 155
    }
    else{
        _12273 = NOVALUE;
    }

    /** cmdline.e:925				printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_21749)){
            _12275 = SEQ_PTR(_cmd_21749)->length;
    }
    else {
        _12275 = 1;
    }
    rhs_slice_target = (object_ptr)&_12276;
    RHS_Slice(_cmd_21749, 2, _12275);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12276;
    _12277 = MAKE_SEQ(_1);
    _12276 = NOVALUE;
    EPrintf(2, _12274, _12277);
    DeRefDS(_12277);
    _12277 = NOVALUE;

    /** cmdline.e:926				if help_on_error then*/
    if (_help_on_error_21755 == 0)
    {
        goto L4; // [121] 136
    }
    else{
    }

    /** cmdline.e:927					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_21751);
    Ref(_add_help_rid_21753);
    RefDS(_cmds_21750);
    Ref(_parse_options_21754);
    _48local_help(_opts_21751, _add_help_rid_21753, _cmds_21750, 1, _parse_options_21754);
    goto L5; // [133] 149
L4: 

    /** cmdline.e:928				elsif auto_help then*/
    if (_auto_help_21756 == 0)
    {
        goto L6; // [138] 148
    }
    else{
    }

    /** cmdline.e:929					printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _12278, _5);
L6: 
L5: 

    /** cmdline.e:931				local_abort(1)*/
    _48local_abort(1);
L3: 
L2: 

    /** cmdline.e:936		j = 0*/
    _j_21758 = 0;

    /** cmdline.e:937		while j < length(at_cmds) do*/
L7: 
    if (IS_SEQUENCE(_at_cmds_21757)){
            _12279 = SEQ_PTR(_at_cmds_21757)->length;
    }
    else {
        _12279 = 1;
    }
    if (_j_21758 >= _12279)
    goto L8; // [171] 492

    /** cmdline.e:938			j += 1*/
    _j_21758 = _j_21758 + 1;

    /** cmdline.e:939			at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12282 = (object)*(((s1_ptr)_2)->base + _j_21758);
    Ref(_12282);
    RefDS(_4905);
    _12283 = _12trim(_12282, _4905, 0);
    _12282 = NOVALUE;
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _at_cmds_21757 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _j_21758);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12283;
    if( _1 != _12283 ){
        DeRef(_1);
    }
    _12283 = NOVALUE;

    /** cmdline.e:940			if length(at_cmds[j]) = 0 then*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12284 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12284)){
            _12285 = SEQ_PTR(_12284)->length;
    }
    else {
        _12285 = 1;
    }
    _12284 = NOVALUE;
    if (_12285 != 0)
    goto L9; // [206] 246

    /** cmdline.e:941				at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _12287 = _j_21758 - 1;
    rhs_slice_target = (object_ptr)&_12288;
    RHS_Slice(_at_cmds_21757, 1, _12287);
    _12289 = _j_21758 + 1;
    if (_12289 > MAXINT){
        _12289 = NewDouble((eudouble)_12289);
    }
    if (IS_SEQUENCE(_at_cmds_21757)){
            _12290 = SEQ_PTR(_at_cmds_21757)->length;
    }
    else {
        _12290 = 1;
    }
    rhs_slice_target = (object_ptr)&_12291;
    RHS_Slice(_at_cmds_21757, _12289, _12290);
    Concat((object_ptr)&_at_cmds_21757, _12288, _12291);
    DeRefDS(_12288);
    _12288 = NOVALUE;
    DeRef(_12288);
    _12288 = NOVALUE;
    DeRefDS(_12291);
    _12291 = NOVALUE;

    /** cmdline.e:942				j -= 1*/
    _j_21758 = _j_21758 - 1;
    goto L7; // [243] 166
L9: 

    /** cmdline.e:944			elsif at_cmds[j][1] = '#' then*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12294 = (object)*(((s1_ptr)_2)->base + _j_21758);
    _2 = (object)SEQ_PTR(_12294);
    _12295 = (object)*(((s1_ptr)_2)->base + 1);
    _12294 = NOVALUE;
    if (binary_op_a(NOTEQ, _12295, 35)){
        _12295 = NOVALUE;
        goto LA; // [256] 296
    }
    _12295 = NOVALUE;

    /** cmdline.e:945				at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _12297 = _j_21758 - 1;
    rhs_slice_target = (object_ptr)&_12298;
    RHS_Slice(_at_cmds_21757, 1, _12297);
    _12299 = _j_21758 + 1;
    if (_12299 > MAXINT){
        _12299 = NewDouble((eudouble)_12299);
    }
    if (IS_SEQUENCE(_at_cmds_21757)){
            _12300 = SEQ_PTR(_at_cmds_21757)->length;
    }
    else {
        _12300 = 1;
    }
    rhs_slice_target = (object_ptr)&_12301;
    RHS_Slice(_at_cmds_21757, _12299, _12300);
    Concat((object_ptr)&_at_cmds_21757, _12298, _12301);
    DeRefDS(_12298);
    _12298 = NOVALUE;
    DeRef(_12298);
    _12298 = NOVALUE;
    DeRefDS(_12301);
    _12301 = NOVALUE;

    /** cmdline.e:946				j -= 1*/
    _j_21758 = _j_21758 - 1;
    goto L7; // [293] 166
LA: 

    /** cmdline.e:948			elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12304 = (object)*(((s1_ptr)_2)->base + _j_21758);
    _2 = (object)SEQ_PTR(_12304);
    _12305 = (object)*(((s1_ptr)_2)->base + 1);
    _12304 = NOVALUE;
    if (IS_ATOM_INT(_12305)) {
        _12306 = (_12305 == 34);
    }
    else {
        _12306 = binary_op(EQUALS, _12305, 34);
    }
    _12305 = NOVALUE;
    if (IS_ATOM_INT(_12306)) {
        if (_12306 == 0) {
            DeRef(_12307);
            _12307 = 0;
            goto LB; // [310] 333
        }
    }
    else {
        if (DBL_PTR(_12306)->dbl == 0.0) {
            DeRef(_12307);
            _12307 = 0;
            goto LB; // [310] 333
        }
    }
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12308 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12308)){
            _12309 = SEQ_PTR(_12308)->length;
    }
    else {
        _12309 = 1;
    }
    _2 = (object)SEQ_PTR(_12308);
    _12310 = (object)*(((s1_ptr)_2)->base + _12309);
    _12308 = NOVALUE;
    if (IS_ATOM_INT(_12310)) {
        _12311 = (_12310 == 34);
    }
    else {
        _12311 = binary_op(EQUALS, _12310, 34);
    }
    _12310 = NOVALUE;
    DeRef(_12307);
    if (IS_ATOM_INT(_12311))
    _12307 = (_12311 != 0);
    else
    _12307 = DBL_PTR(_12311)->dbl != 0.0;
LB: 
    if (_12307 == 0) {
        goto LC; // [333] 377
    }
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12313 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12313)){
            _12314 = SEQ_PTR(_12313)->length;
    }
    else {
        _12314 = 1;
    }
    _12313 = NOVALUE;
    _12315 = (_12314 >= 2);
    _12314 = NOVALUE;
    if (_12315 == 0)
    {
        DeRef(_12315);
        _12315 = NOVALUE;
        goto LC; // [349] 377
    }
    else{
        DeRef(_12315);
        _12315 = NOVALUE;
    }

    /** cmdline.e:949				at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12316 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12316)){
            _12317 = SEQ_PTR(_12316)->length;
    }
    else {
        _12317 = 1;
    }
    _12318 = _12317 - 1;
    _12317 = NOVALUE;
    rhs_slice_target = (object_ptr)&_12319;
    RHS_Slice(_12316, 2, _12318);
    _12316 = NOVALUE;
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _at_cmds_21757 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _j_21758);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12319;
    if( _1 != _12319 ){
        DeRef(_1);
    }
    _12319 = NOVALUE;
    goto L7; // [374] 166
LC: 

    /** cmdline.e:951			elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12320 = (object)*(((s1_ptr)_2)->base + _j_21758);
    _2 = (object)SEQ_PTR(_12320);
    _12321 = (object)*(((s1_ptr)_2)->base + 1);
    _12320 = NOVALUE;
    if (IS_ATOM_INT(_12321)) {
        _12322 = (_12321 == 39);
    }
    else {
        _12322 = binary_op(EQUALS, _12321, 39);
    }
    _12321 = NOVALUE;
    if (IS_ATOM_INT(_12322)) {
        if (_12322 == 0) {
            DeRef(_12323);
            _12323 = 0;
            goto LD; // [391] 414
        }
    }
    else {
        if (DBL_PTR(_12322)->dbl == 0.0) {
            DeRef(_12323);
            _12323 = 0;
            goto LD; // [391] 414
        }
    }
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12324 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12324)){
            _12325 = SEQ_PTR(_12324)->length;
    }
    else {
        _12325 = 1;
    }
    _2 = (object)SEQ_PTR(_12324);
    _12326 = (object)*(((s1_ptr)_2)->base + _12325);
    _12324 = NOVALUE;
    if (IS_ATOM_INT(_12326)) {
        _12327 = (_12326 == 39);
    }
    else {
        _12327 = binary_op(EQUALS, _12326, 39);
    }
    _12326 = NOVALUE;
    DeRef(_12323);
    if (IS_ATOM_INT(_12327))
    _12323 = (_12327 != 0);
    else
    _12323 = DBL_PTR(_12327)->dbl != 0.0;
LD: 
    if (_12323 == 0) {
        goto LE; // [414] 484
    }
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12329 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12329)){
            _12330 = SEQ_PTR(_12329)->length;
    }
    else {
        _12330 = 1;
    }
    _12329 = NOVALUE;
    _12331 = (_12330 >= 2);
    _12330 = NOVALUE;
    if (_12331 == 0)
    {
        DeRef(_12331);
        _12331 = NOVALUE;
        goto LE; // [430] 484
    }
    else{
        DeRef(_12331);
        _12331 = NOVALUE;
    }

    /** cmdline.e:952				sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (object)SEQ_PTR(_at_cmds_21757);
    _12332 = (object)*(((s1_ptr)_2)->base + _j_21758);
    if (IS_SEQUENCE(_12332)){
            _12333 = SEQ_PTR(_12332)->length;
    }
    else {
        _12333 = 1;
    }
    _12334 = _12333 - 1;
    _12333 = NOVALUE;
    rhs_slice_target = (object_ptr)&_12335;
    RHS_Slice(_12332, 2, _12334);
    _12332 = NOVALUE;
    _0 = _cmdex_21842;
    _cmdex_21842 = _24split(_12335, 32, 1, 0);
    DeRef(_0);
    _12335 = NOVALUE;

    /** cmdline.e:954				at_cmds = replace(at_cmds, cmdex, j)*/
    {
        intptr_t p1 = _at_cmds_21757;
        intptr_t p2 = _cmdex_21842;
        intptr_t p3 = _j_21758;
        intptr_t p4 = _j_21758;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_21757;
        Replace( &replace_params );
    }

    /** cmdline.e:955				j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_21842)){
            _12338 = SEQ_PTR(_cmdex_21842)->length;
    }
    else {
        _12338 = 1;
    }
    _12339 = _j_21758 + _12338;
    if ((object)((uintptr_t)_12339 + (uintptr_t)HIGH_BITS) >= 0){
        _12339 = NewDouble((eudouble)_12339);
    }
    _12338 = NOVALUE;
    if (IS_ATOM_INT(_12339)) {
        _j_21758 = _12339 - 1;
    }
    else {
        _j_21758 = NewDouble(DBL_PTR(_12339)->dbl - (eudouble)1);
    }
    DeRef(_12339);
    _12339 = NOVALUE;
    if (!IS_ATOM_INT(_j_21758)) {
        _1 = (object)(DBL_PTR(_j_21758)->dbl);
        DeRefDS(_j_21758);
        _j_21758 = _1;
    }
LE: 
    DeRef(_cmdex_21842);
    _cmdex_21842 = NOVALUE;

    /** cmdline.e:958		end while*/
    goto L7; // [489] 166
L8: 

    /** cmdline.e:961		cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        intptr_t p1 = _cmds_21750;
        intptr_t p2 = _at_cmds_21757;
        intptr_t p3 = _arg_idx_21752;
        intptr_t p4 = _arg_idx_21752;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_21750;
        Replace( &replace_params );
    }

    /** cmdline.e:962		return cmds*/
    DeRefDS(_cmd_21749);
    DeRefDS(_opts_21751);
    DeRef(_add_help_rid_21753);
    DeRef(_parse_options_21754);
    DeRef(_at_cmds_21757);
    DeRef(_12299);
    _12299 = NOVALUE;
    DeRef(_12261);
    _12261 = NOVALUE;
    _12284 = NOVALUE;
    DeRef(_12289);
    _12289 = NOVALUE;
    DeRef(_12297);
    _12297 = NOVALUE;
    _12329 = NOVALUE;
    _12313 = NOVALUE;
    DeRef(_12334);
    _12334 = NOVALUE;
    DeRef(_12322);
    _12322 = NOVALUE;
    DeRef(_12318);
    _12318 = NOVALUE;
    DeRef(_12306);
    _12306 = NOVALUE;
    DeRef(_12311);
    _12311 = NOVALUE;
    DeRef(_12327);
    _12327 = NOVALUE;
    DeRef(_12287);
    _12287 = NOVALUE;
    return _cmds_21750;
    ;
}


void _48check_mandatory(object _opts_21855, object _parsed_opts_21857, object _add_help_rid_21858, object _cmds_21859, object _parse_options_21860, object _help_on_error_21861, object _auto_help_21862)
{
    object _12366 = NOVALUE;
    object _12365 = NOVALUE;
    object _12364 = NOVALUE;
    object _12361 = NOVALUE;
    object _12360 = NOVALUE;
    object _12359 = NOVALUE;
    object _12356 = NOVALUE;
    object _12355 = NOVALUE;
    object _12354 = NOVALUE;
    object _12353 = NOVALUE;
    object _12352 = NOVALUE;
    object _12351 = NOVALUE;
    object _12350 = NOVALUE;
    object _12349 = NOVALUE;
    object _12348 = NOVALUE;
    object _12347 = NOVALUE;
    object _12346 = NOVALUE;
    object _12345 = NOVALUE;
    object _12344 = NOVALUE;
    object _12343 = NOVALUE;
    object _12342 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:969		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_21855)){
            _12342 = SEQ_PTR(_opts_21855)->length;
    }
    else {
        _12342 = 1;
    }
    {
        object _i_21864;
        _i_21864 = 1;
L1: 
        if (_i_21864 > _12342){
            goto L2; // [14] 219
        }

        /** cmdline.e:970			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (object)SEQ_PTR(_opts_21855);
        _12343 = (object)*(((s1_ptr)_2)->base + _i_21864);
        _2 = (object)SEQ_PTR(_12343);
        _12344 = (object)*(((s1_ptr)_2)->base + 4);
        _12343 = NOVALUE;
        _12345 = find_from(109, _12344, 1);
        _12344 = NOVALUE;
        if (_12345 == 0)
        {
            _12345 = NOVALUE;
            goto L3; // [36] 212
        }
        else{
            _12345 = NOVALUE;
        }

        /** cmdline.e:971				if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21855);
        _12346 = (object)*(((s1_ptr)_2)->base + _i_21864);
        _2 = (object)SEQ_PTR(_12346);
        _12347 = (object)*(((s1_ptr)_2)->base + 1);
        _12346 = NOVALUE;
        _12348 = IS_ATOM(_12347);
        _12347 = NOVALUE;
        if (_12348 == 0) {
            goto L4; // [52] 138
        }
        _2 = (object)SEQ_PTR(_opts_21855);
        _12350 = (object)*(((s1_ptr)_2)->base + _i_21864);
        _2 = (object)SEQ_PTR(_12350);
        _12351 = (object)*(((s1_ptr)_2)->base + 2);
        _12350 = NOVALUE;
        _12352 = IS_ATOM(_12351);
        _12351 = NOVALUE;
        if (_12352 == 0)
        {
            _12352 = NOVALUE;
            goto L4; // [68] 138
        }
        else{
            _12352 = NOVALUE;
        }

        /** cmdline.e:972					if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (object)SEQ_PTR(_opts_21855);
        _12353 = (object)*(((s1_ptr)_2)->base + _i_21864);
        _2 = (object)SEQ_PTR(_12353);
        _12354 = (object)*(((s1_ptr)_2)->base + 6);
        _12353 = NOVALUE;
        Ref(_parsed_opts_21857);
        Ref(_12354);
        _12355 = _34get(_parsed_opts_21857, _12354, 0);
        _12354 = NOVALUE;
        if (IS_SEQUENCE(_12355)){
                _12356 = SEQ_PTR(_12355)->length;
        }
        else {
            _12356 = 1;
        }
        DeRef(_12355);
        _12355 = NOVALUE;
        if (_12356 != 0)
        goto L5; // [90] 211

        /** cmdline.e:973						puts(1, "Additional arguments were expected.\n\n")*/
        EPuts(1, _12358); // DJP 

        /** cmdline.e:974						if help_on_error then*/
        if (_help_on_error_21861 == 0)
        {
            goto L6; // [101] 116
        }
        else{
        }

        /** cmdline.e:975							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_21855);
        Ref(_add_help_rid_21858);
        RefDS(_cmds_21859);
        Ref(_parse_options_21860);
        _48local_help(_opts_21855, _add_help_rid_21858, _cmds_21859, 1, _parse_options_21860);
        goto L7; // [113] 129
L6: 

        /** cmdline.e:976						elsif auto_help then*/
        if (_auto_help_21862 == 0)
        {
            goto L8; // [118] 128
        }
        else{
        }

        /** cmdline.e:977							printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _12278, _5);
L8: 
L7: 

        /** cmdline.e:979						local_abort(1)*/
        _48local_abort(1);
        goto L5; // [135] 211
L4: 

        /** cmdline.e:982					if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (object)SEQ_PTR(_opts_21855);
        _12359 = (object)*(((s1_ptr)_2)->base + _i_21864);
        _2 = (object)SEQ_PTR(_12359);
        _12360 = (object)*(((s1_ptr)_2)->base + 6);
        _12359 = NOVALUE;
        Ref(_parsed_opts_21857);
        Ref(_12360);
        _12361 = _34has(_parsed_opts_21857, _12360);
        _12360 = NOVALUE;
        if (IS_ATOM_INT(_12361)) {
            if (_12361 != 0){
                DeRef(_12361);
                _12361 = NOVALUE;
                goto L9; // [153] 210
            }
        }
        else {
            if (DBL_PTR(_12361)->dbl != 0.0){
                DeRef(_12361);
                _12361 = NOVALUE;
                goto L9; // [153] 210
            }
        }
        DeRef(_12361);
        _12361 = NOVALUE;

        /** cmdline.e:983						printf(1, "option '%s' is mandatory but was not supplied.\n\n", {opts[i][MAPNAME]})*/
        _2 = (object)SEQ_PTR(_opts_21855);
        _12364 = (object)*(((s1_ptr)_2)->base + _i_21864);
        _2 = (object)SEQ_PTR(_12364);
        _12365 = (object)*(((s1_ptr)_2)->base + 6);
        _12364 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_12365);
        ((intptr_t*)_2)[1] = _12365;
        _12366 = MAKE_SEQ(_1);
        _12365 = NOVALUE;
        EPrintf(1, _12363, _12366);
        DeRefDS(_12366);
        _12366 = NOVALUE;

        /** cmdline.e:984						if help_on_error then*/
        if (_help_on_error_21861 == 0)
        {
            goto LA; // [176] 191
        }
        else{
        }

        /** cmdline.e:985							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_21855);
        Ref(_add_help_rid_21858);
        RefDS(_cmds_21859);
        Ref(_parse_options_21860);
        _48local_help(_opts_21855, _add_help_rid_21858, _cmds_21859, 1, _parse_options_21860);
        goto LB; // [188] 204
LA: 

        /** cmdline.e:986						elsif auto_help then*/
        if (_auto_help_21862 == 0)
        {
            goto LC; // [193] 203
        }
        else{
        }

        /** cmdline.e:987							printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _12278, _5);
LC: 
LB: 

        /** cmdline.e:989						local_abort(1)*/
        _48local_abort(1);
L9: 
L5: 
L3: 

        /** cmdline.e:993		end for*/
        _i_21864 = _i_21864 + 1;
        goto L1; // [214] 21
L2: 
        ;
    }

    /** cmdline.e:994	end procedure*/
    DeRefDS(_opts_21855);
    DeRef(_parsed_opts_21857);
    DeRef(_add_help_rid_21858);
    DeRefDS(_cmds_21859);
    DeRef(_parse_options_21860);
    _12355 = NOVALUE;
    return;
    ;
}


void _48parse_abort(object _format_msg_21901, object _msg_data_21902, object _opts_21903, object _add_help_rid_21904, object _cmds_21905, object _parse_options_21906, object _help_on_error_21907, object _auto_help_21908)
{
    object _0, _1, _2;
    

    /** cmdline.e:999		printf(1, format_msg, msg_data)*/
    EPrintf(1, _format_msg_21901, _msg_data_21902);

    /** cmdline.e:1000		if help_on_error then*/
    if (_help_on_error_21907 == 0)
    {
        goto L1; // [21] 36
    }
    else{
    }

    /** cmdline.e:1001			local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_21903);
    Ref(_add_help_rid_21904);
    RefDS(_cmds_21905);
    Ref(_parse_options_21906);
    _48local_help(_opts_21903, _add_help_rid_21904, _cmds_21905, 1, _parse_options_21906);
    goto L2; // [33] 49
L1: 

    /** cmdline.e:1002		elsif auto_help then*/
    if (_auto_help_21908 == 0)
    {
        goto L3; // [38] 48
    }
    else{
    }

    /** cmdline.e:1003			printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _12278, _5);
L3: 
L2: 

    /** cmdline.e:1005		local_abort(1)*/
    _48local_abort(1);

    /** cmdline.e:1006	end procedure*/
    DeRefDSi(_format_msg_21901);
    DeRefDS(_msg_data_21902);
    DeRefDS(_opts_21903);
    DeRef(_add_help_rid_21904);
    DeRefDS(_cmds_21905);
    DeRef(_parse_options_21906);
    return;
    ;
}


object _48parse_commands(object _cmds_21913, object _opts_21914, object _parsed_opts_21916, object _help_opts_21917, object _add_help_rid_21918, object _parse_options_21919, object _use_at_21920, object _validation_21921, object _has_extra_21922, object _call_count_21923, object _help_on_error_21924, object _auto_help_21925)
{
    object _arg_idx_21926 = NOVALUE;
    object _opts_done_21927 = NOVALUE;
    object _find_result_21928 = NOVALUE;
    object _type__21929 = NOVALUE;
    object _from__21930 = NOVALUE;
    object _cmd_21931 = NOVALUE;
    object _handle_result_21996 = NOVALUE;
    object _12418 = NOVALUE;
    object _12414 = NOVALUE;
    object _12413 = NOVALUE;
    object _12411 = NOVALUE;
    object _12410 = NOVALUE;
    object _12409 = NOVALUE;
    object _12407 = NOVALUE;
    object _12405 = NOVALUE;
    object _12403 = NOVALUE;
    object _12401 = NOVALUE;
    object _12400 = NOVALUE;
    object _12399 = NOVALUE;
    object _12398 = NOVALUE;
    object _12397 = NOVALUE;
    object _12393 = NOVALUE;
    object _12391 = NOVALUE;
    object _12390 = NOVALUE;
    object _12389 = NOVALUE;
    object _12388 = NOVALUE;
    object _12387 = NOVALUE;
    object _12386 = NOVALUE;
    object _12384 = NOVALUE;
    object _12383 = NOVALUE;
    object _12382 = NOVALUE;
    object _12381 = NOVALUE;
    object _12380 = NOVALUE;
    object _12379 = NOVALUE;
    object _12378 = NOVALUE;
    object _12375 = NOVALUE;
    object _12374 = NOVALUE;
    object _12373 = NOVALUE;
    object _12371 = NOVALUE;
    object _12367 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1016		integer arg_idx = 2*/
    _arg_idx_21926 = 2;

    /** cmdline.e:1017		integer opts_done = 0*/
    _opts_done_21927 = 0;

    /** cmdline.e:1023		while arg_idx < length(cmds) do*/
L1: 
    if (IS_SEQUENCE(_cmds_21913)){
            _12367 = SEQ_PTR(_cmds_21913)->length;
    }
    else {
        _12367 = 1;
    }
    if (_arg_idx_21926 >= _12367)
    goto L2; // [37] 488

    /** cmdline.e:1024			arg_idx += 1*/
    _arg_idx_21926 = _arg_idx_21926 + 1;

    /** cmdline.e:1026			cmd = cmds[arg_idx]*/
    DeRef(_cmd_21931);
    _2 = (object)SEQ_PTR(_cmds_21913);
    _cmd_21931 = (object)*(((s1_ptr)_2)->base + _arg_idx_21926);
    Ref(_cmd_21931);

    /** cmdline.e:1027			if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_21931)){
            _12371 = SEQ_PTR(_cmd_21931)->length;
    }
    else {
        _12371 = 1;
    }
    if (_12371 != 0)
    goto L3; // [60] 69

    /** cmdline.e:1028				continue*/
    goto L1; // [66] 34
L3: 

    /** cmdline.e:1031			if cmd[1] = '@' and use_at then*/
    _2 = (object)SEQ_PTR(_cmd_21931);
    _12373 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_12373)) {
        _12374 = (_12373 == 64);
    }
    else {
        _12374 = binary_op(EQUALS, _12373, 64);
    }
    _12373 = NOVALUE;
    if (IS_ATOM_INT(_12374)) {
        if (_12374 == 0) {
            goto L4; // [79] 113
        }
    }
    else {
        if (DBL_PTR(_12374)->dbl == 0.0) {
            goto L4; // [79] 113
        }
    }
    if (_use_at_21920 == 0)
    {
        goto L4; // [84] 113
    }
    else{
    }

    /** cmdline.e:1032				cmds = parse_at_cmds( cmd, cmds, opts, arg_idx, add_help_rid, parse_options, help_on_error, auto_help )*/
    RefDS(_cmd_21931);
    RefDS(_cmds_21913);
    RefDS(_opts_21914);
    Ref(_add_help_rid_21918);
    Ref(_parse_options_21919);
    _0 = _cmds_21913;
    _cmds_21913 = _48parse_at_cmds(_cmd_21931, _cmds_21913, _opts_21914, _arg_idx_21926, _add_help_rid_21918, _parse_options_21919, _help_on_error_21924, _auto_help_21925);
    DeRefDS(_0);

    /** cmdline.e:1033				arg_idx -= 1*/
    _arg_idx_21926 = _arg_idx_21926 - 1;

    /** cmdline.e:1034				continue*/
    goto L1; // [110] 34
L4: 

    /** cmdline.e:1037			if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_21927 != 0) {
        _12378 = 1;
        goto L5; // [115] 136
    }
    _2 = (object)SEQ_PTR(_cmd_21931);
    _12379 = (object)*(((s1_ptr)_2)->base + 1);
    _12380 = find_from(_12379, _3CMD_SWITCHES_1398, 1);
    _12379 = NOVALUE;
    _12381 = (_12380 == 0);
    _12380 = NOVALUE;
    _12378 = (_12381 != 0);
L5: 
    if (_12378 != 0) {
        DeRef(_12382);
        _12382 = 1;
        goto L6; // [136] 151
    }
    if (IS_SEQUENCE(_cmd_21931)){
            _12383 = SEQ_PTR(_cmd_21931)->length;
    }
    else {
        _12383 = 1;
    }
    _12384 = (_12383 == 1);
    _12383 = NOVALUE;
    _12382 = (_12384 != 0);
L6: 
    if (_12382 == 0)
    {
        _12382 = NOVALUE;
        goto L7; // [151] 227
    }
    else{
        _12382 = NOVALUE;
    }

    /** cmdline.e:1039				map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_21916);
    RefDS(_48EXTRAS_20984);
    RefDS(_cmd_21931);
    _34put(_parsed_opts_21916, _48EXTRAS_20984, _cmd_21931, 6, 0);

    /** cmdline.e:1040				has_extra = 1*/
    _has_extra_21922 = 1;

    /** cmdline.e:1041				if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_21921 != 4)
    goto L1; // [172] 34

    /** cmdline.e:1042					for i = arg_idx + 1 to length(cmds) do*/
    _12386 = _arg_idx_21926 + 1;
    if (_12386 > MAXINT){
        _12386 = NewDouble((eudouble)_12386);
    }
    if (IS_SEQUENCE(_cmds_21913)){
            _12387 = SEQ_PTR(_cmds_21913)->length;
    }
    else {
        _12387 = 1;
    }
    {
        object _i_21957;
        Ref(_12386);
        _i_21957 = _12386;
L8: 
        if (binary_op_a(GREATER, _i_21957, _12387)){
            goto L9; // [185] 214
        }

        /** cmdline.e:1043						map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (object)SEQ_PTR(_cmds_21913);
        if (!IS_ATOM_INT(_i_21957)){
            _12388 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_21957)->dbl));
        }
        else{
            _12388 = (object)*(((s1_ptr)_2)->base + _i_21957);
        }
        Ref(_parsed_opts_21916);
        RefDS(_48EXTRAS_20984);
        Ref(_12388);
        _34put(_parsed_opts_21916, _48EXTRAS_20984, _12388, 6, 0);
        _12388 = NOVALUE;

        /** cmdline.e:1044					end for*/
        _0 = _i_21957;
        if (IS_ATOM_INT(_i_21957)) {
            _i_21957 = _i_21957 + 1;
            if ((object)((uintptr_t)_i_21957 +(uintptr_t) HIGH_BITS) >= 0){
                _i_21957 = NewDouble((eudouble)_i_21957);
            }
        }
        else {
            _i_21957 = binary_op_a(PLUS, _i_21957, 1);
        }
        DeRef(_0);
        goto L8; // [209] 192
L9: 
        ;
        DeRef(_i_21957);
    }

    /** cmdline.e:1046					exit*/
    goto L2; // [216] 488
    goto LA; // [218] 226

    /** cmdline.e:1048					continue*/
    goto L1; // [223] 34
LA: 
L7: 

    /** cmdline.e:1052			if equal(cmd, "--") then*/
    if (_cmd_21931 == _12114)
    _12389 = 1;
    else if (IS_ATOM_INT(_cmd_21931) && IS_ATOM_INT(_12114))
    _12389 = 0;
    else
    _12389 = (compare(_cmd_21931, _12114) == 0);
    if (_12389 == 0)
    {
        _12389 = NOVALUE;
        goto LB; // [233] 246
    }
    else{
        _12389 = NOVALUE;
    }

    /** cmdline.e:1053				opts_done = 1*/
    _opts_done_21927 = 1;

    /** cmdline.e:1054				continue*/
    goto L1; // [243] 34
LB: 

    /** cmdline.e:1057			if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_12390;
    RHS_Slice(_cmd_21931, 1, 2);
    if (_12390 == _12114)
    _12391 = 1;
    else if (IS_ATOM_INT(_12390) && IS_ATOM_INT(_12114))
    _12391 = 0;
    else
    _12391 = (compare(_12390, _12114) == 0);
    DeRefDS(_12390);
    _12390 = NOVALUE;
    if (_12391 == 0)
    {
        _12391 = NOVALUE;
        goto LC; // [257] 274
    }
    else{
        _12391 = NOVALUE;
    }

    /** cmdline.e:1058				type_ = {LONGNAME, "--"}*/
    RefDS(_12114);
    DeRef(_type__21929);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = _12114;
    _type__21929 = MAKE_SEQ(_1);

    /** cmdline.e:1059				from_ = 3*/
    _from__21930 = 3;
    goto LD; // [271] 310
LC: 

    /** cmdline.e:1060			elsif cmd[1] = '-' then -- found -opt*/
    _2 = (object)SEQ_PTR(_cmd_21931);
    _12393 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12393, 45)){
        _12393 = NOVALUE;
        goto LE; // [280] 298
    }
    _12393 = NOVALUE;

    /** cmdline.e:1061				type_ = {SHORTNAME, "-"}*/
    RefDS(_12202);
    DeRef(_type__21929);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _12202;
    _type__21929 = MAKE_SEQ(_1);

    /** cmdline.e:1062				from_ = 2*/
    _from__21930 = 2;
    goto LD; // [295] 310
LE: 

    /** cmdline.e:1064				type_ = {SHORTNAME, "/"}*/
    RefDS(_11621);
    DeRef(_type__21929);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _11621;
    _type__21929 = MAKE_SEQ(_1);

    /** cmdline.e:1065				from_ = 2*/
    _from__21930 = 2;
LD: 

    /** cmdline.e:1068			if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_21931)){
            _12397 = SEQ_PTR(_cmd_21931)->length;
    }
    else {
        _12397 = 1;
    }
    rhs_slice_target = (object_ptr)&_12398;
    RHS_Slice(_cmd_21931, _from__21930, _12397);
    _12399 = find_from(_12398, _help_opts_21917, 1);
    DeRefDS(_12398);
    _12398 = NOVALUE;
    if (_12399 == 0)
    {
        _12399 = NOVALUE;
        goto LF; // [327] 347
    }
    else{
        _12399 = NOVALUE;
    }

    /** cmdline.e:1069				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_21914);
    Ref(_add_help_rid_21918);
    RefDS(_cmds_21913);
    Ref(_parse_options_21919);
    _48local_help(_opts_21914, _add_help_rid_21918, _cmds_21913, 1, _parse_options_21919);

    /** cmdline.e:1070				ifdef UNITTEST then*/

    /** cmdline.e:1073				local_abort(0)*/
    _48local_abort(0);
LF: 

    /** cmdline.e:1076			find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_21931)){
            _12400 = SEQ_PTR(_cmd_21931)->length;
    }
    else {
        _12400 = 1;
    }
    rhs_slice_target = (object_ptr)&_12401;
    RHS_Slice(_cmd_21931, _from__21930, _12400);
    RefDS(_opts_21914);
    RefDS(_type__21929);
    _0 = _find_result_21928;
    _find_result_21928 = _48find_opt(_opts_21914, _type__21929, _12401);
    DeRef(_0);
    _12401 = NOVALUE;

    /** cmdline.e:1078			if find_result[1] < 0 then*/
    _2 = (object)SEQ_PTR(_find_result_21928);
    _12403 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _12403, 0)){
        _12403 = NOVALUE;
        goto L10; // [373] 382
    }
    _12403 = NOVALUE;

    /** cmdline.e:1079				continue -- Couldn't use this command argument for anything.*/
    goto L1; // [379] 34
L10: 

    /** cmdline.e:1082			if find_result[1] = 0 then*/
    _2 = (object)SEQ_PTR(_find_result_21928);
    _12405 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12405, 0)){
        _12405 = NOVALUE;
        goto L11; // [388] 449
    }
    _12405 = NOVALUE;

    /** cmdline.e:1083				if validation = VALIDATE_ALL or*/
    _12407 = (_validation_21921 == 2);
    if (_12407 != 0) {
        goto L12; // [398] 423
    }
    _12409 = (_validation_21921 == 4);
    if (_12409 == 0) {
        DeRef(_12410);
        _12410 = 0;
        goto L13; // [406] 418
    }
    _12411 = (_has_extra_21922 == 0);
    _12410 = (_12411 != 0);
L13: 
    if (_12410 == 0)
    {
        _12410 = NOVALUE;
        goto L1; // [419] 34
    }
    else{
        _12410 = NOVALUE;
    }
L12: 

    /** cmdline.e:1087					parse_abort( "option '%s': %s\n\n", {cmd, find_result[2]}, */
    _2 = (object)SEQ_PTR(_find_result_21928);
    _12413 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_12413);
    RefDS(_cmd_21931);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _cmd_21931;
    ((intptr_t *)_2)[2] = _12413;
    _12414 = MAKE_SEQ(_1);
    _12413 = NOVALUE;
    RefDS(_12412);
    RefDS(_opts_21914);
    Ref(_add_help_rid_21918);
    RefDS(_cmds_21913);
    Ref(_parse_options_21919);
    _48parse_abort(_12412, _12414, _opts_21914, _add_help_rid_21918, _cmds_21913, _parse_options_21919, _help_on_error_21924, _auto_help_21925);
    _12414 = NOVALUE;

    /** cmdline.e:1091				continue*/
    goto L1; // [446] 34
L11: 

    /** cmdline.e:1094			sequence handle_result = handle_opt( find_result, arg_idx, opts, parsed_opts, cmds, add_help_rid,*/
    RefDS(_find_result_21928);
    RefDS(_opts_21914);
    Ref(_parsed_opts_21916);
    RefDS(_cmds_21913);
    Ref(_add_help_rid_21918);
    Ref(_parse_options_21919);
    RefDS(_call_count_21923);
    _0 = _handle_result_21996;
    _handle_result_21996 = _48handle_opt(_find_result_21928, _arg_idx_21926, _opts_21914, _parsed_opts_21916, _cmds_21913, _add_help_rid_21918, _parse_options_21919, _call_count_21923, _validation_21921, _help_on_error_21924, _auto_help_21925);
    DeRef(_0);

    /** cmdline.e:1096			arg_idx     = handle_result[1]*/
    _2 = (object)SEQ_PTR(_handle_result_21996);
    _arg_idx_21926 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_arg_idx_21926))
    _arg_idx_21926 = (object)DBL_PTR(_arg_idx_21926)->dbl;

    /** cmdline.e:1097			call_count = handle_result[2]*/
    DeRefDS(_call_count_21923);
    _2 = (object)SEQ_PTR(_handle_result_21996);
    _call_count_21923 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_call_count_21923);
    DeRefDS(_handle_result_21996);
    _handle_result_21996 = NOVALUE;

    /** cmdline.e:1098		end while*/
    goto L1; // [485] 34
L2: 

    /** cmdline.e:1099		return { cmds, call_count }*/
    RefDS(_call_count_21923);
    RefDS(_cmds_21913);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _cmds_21913;
    ((intptr_t *)_2)[2] = _call_count_21923;
    _12418 = MAKE_SEQ(_1);
    DeRefDS(_cmds_21913);
    DeRefDS(_opts_21914);
    DeRef(_parsed_opts_21916);
    DeRefDS(_help_opts_21917);
    DeRef(_add_help_rid_21918);
    DeRef(_parse_options_21919);
    DeRefDS(_call_count_21923);
    DeRef(_find_result_21928);
    DeRef(_type__21929);
    DeRef(_cmd_21931);
    DeRef(_12409);
    _12409 = NOVALUE;
    DeRef(_12386);
    _12386 = NOVALUE;
    DeRef(_12384);
    _12384 = NOVALUE;
    DeRef(_12374);
    _12374 = NOVALUE;
    DeRef(_12411);
    _12411 = NOVALUE;
    DeRef(_12381);
    _12381 = NOVALUE;
    DeRef(_12407);
    _12407 = NOVALUE;
    return _12418;
    ;
}


object _48handle_opt(object _find_result_22004, object _arg_idx_22005, object _opts_22006, object _parsed_opts_22008, object _cmds_22009, object _add_help_rid_22010, object _parse_options_22011, object _call_count_22012, object _validation_22013, object _help_on_error_22014, object _auto_help_22015)
{
    object _map_add_operation_22016 = NOVALUE;
    object _opt_22017 = NOVALUE;
    object _param_22020 = NOVALUE;
    object _pos_22058 = NOVALUE;
    object _ver_pos_22104 = NOVALUE;
    object _msg_inlined_crash_at_524_22121 = NOVALUE;
    object _fmt_inlined_crash_at_521_22120 = NOVALUE;
    object _12497 = NOVALUE;
    object _12496 = NOVALUE;
    object _12493 = NOVALUE;
    object _12492 = NOVALUE;
    object _12491 = NOVALUE;
    object _12489 = NOVALUE;
    object _12488 = NOVALUE;
    object _12486 = NOVALUE;
    object _12485 = NOVALUE;
    object _12484 = NOVALUE;
    object _12483 = NOVALUE;
    object _12482 = NOVALUE;
    object _12481 = NOVALUE;
    object _12480 = NOVALUE;
    object _12479 = NOVALUE;
    object _12477 = NOVALUE;
    object _12476 = NOVALUE;
    object _12474 = NOVALUE;
    object _12473 = NOVALUE;
    object _12472 = NOVALUE;
    object _12471 = NOVALUE;
    object _12470 = NOVALUE;
    object _12469 = NOVALUE;
    object _12468 = NOVALUE;
    object _12467 = NOVALUE;
    object _12465 = NOVALUE;
    object _12464 = NOVALUE;
    object _12463 = NOVALUE;
    object _12461 = NOVALUE;
    object _12460 = NOVALUE;
    object _12458 = NOVALUE;
    object _12457 = NOVALUE;
    object _12456 = NOVALUE;
    object _12455 = NOVALUE;
    object _12454 = NOVALUE;
    object _12453 = NOVALUE;
    object _12452 = NOVALUE;
    object _12451 = NOVALUE;
    object _12450 = NOVALUE;
    object _12447 = NOVALUE;
    object _12444 = NOVALUE;
    object _12443 = NOVALUE;
    object _12441 = NOVALUE;
    object _12440 = NOVALUE;
    object _12439 = NOVALUE;
    object _12438 = NOVALUE;
    object _12437 = NOVALUE;
    object _12436 = NOVALUE;
    object _12435 = NOVALUE;
    object _12433 = NOVALUE;
    object _12432 = NOVALUE;
    object _12431 = NOVALUE;
    object _12430 = NOVALUE;
    object _12427 = NOVALUE;
    object _12424 = NOVALUE;
    object _12422 = NOVALUE;
    object _12421 = NOVALUE;
    object _12419 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1110		integer map_add_operation = map:ADD*/
    _map_add_operation_22016 = 2;

    /** cmdline.e:1111		sequence opt = opts[find_result[1]]*/
    _2 = (object)SEQ_PTR(_find_result_22004);
    _12419 = (object)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_22017);
    _2 = (object)SEQ_PTR(_opts_22006);
    if (!IS_ATOM_INT(_12419)){
        _opt_22017 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_12419)->dbl));
    }
    else{
        _opt_22017 = (object)*(((s1_ptr)_2)->base + _12419);
    }
    Ref(_opt_22017);

    /** cmdline.e:1114		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12421 = (object)*(((s1_ptr)_2)->base + 4);
    _12422 = find_from(112, _12421, 1);
    _12421 = NOVALUE;
    if (_12422 == 0)
    goto L1; // [45] 194

    /** cmdline.e:1115			map_add_operation = map:APPEND*/
    _map_add_operation_22016 = 6;

    /** cmdline.e:1116			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_22004)){
            _12424 = SEQ_PTR(_find_result_22004)->length;
    }
    else {
        _12424 = 1;
    }
    if (_12424 >= 4)
    goto L2; // [59] 184

    /** cmdline.e:1117				arg_idx += 1*/
    _arg_idx_22005 = _arg_idx_22005 + 1;

    /** cmdline.e:1118				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_22009)){
            _12427 = SEQ_PTR(_cmds_22009)->length;
    }
    else {
        _12427 = 1;
    }
    if (_arg_idx_22005 > _12427)
    goto L3; // [74] 119

    /** cmdline.e:1119					param = cmds[arg_idx]*/
    DeRef(_param_22020);
    _2 = (object)SEQ_PTR(_cmds_22009);
    _param_22020 = (object)*(((s1_ptr)_2)->base + _arg_idx_22005);
    Ref(_param_22020);

    /** cmdline.e:1120					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_22020)){
            _12430 = SEQ_PTR(_param_22020)->length;
    }
    else {
        _12430 = 1;
    }
    _12431 = (_12430 == 2);
    _12430 = NOVALUE;
    if (_12431 == 0) {
        goto L4; // [93] 125
    }
    _2 = (object)SEQ_PTR(_param_22020);
    _12433 = (object)*(((s1_ptr)_2)->base + 1);
    _12435 = find_from(_12433, _12434, 1);
    _12433 = NOVALUE;
    if (_12435 == 0)
    {
        _12435 = NOVALUE;
        goto L4; // [107] 125
    }
    else{
        _12435 = NOVALUE;
    }

    /** cmdline.e:1121						param = ""*/
    RefDS(_5);
    DeRef(_param_22020);
    _param_22020 = _5;
    goto L4; // [116] 125
L3: 

    /** cmdline.e:1124					param = ""*/
    RefDS(_5);
    DeRef(_param_22020);
    _param_22020 = _5;
L4: 

    /** cmdline.e:1127				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_22020)){
            _12436 = SEQ_PTR(_param_22020)->length;
    }
    else {
        _12436 = 1;
    }
    _12437 = (_12436 == 0);
    _12436 = NOVALUE;
    if (_12437 == 0) {
        goto L5; // [136] 201
    }
    _12439 = (_validation_22013 == 2);
    if (_12439 != 0) {
        DeRef(_12440);
        _12440 = 1;
        goto L6; // [144] 156
    }
    _12441 = (_validation_22013 == 4);
    _12440 = (_12441 != 0);
L6: 
    if (_12440 == 0)
    {
        _12440 = NOVALUE;
        goto L5; // [157] 201
    }
    else{
        _12440 = NOVALUE;
    }

    /** cmdline.e:1130					parse_abort( "option '%s' must have a parameter\n\n", {find_result[2]}, */
    _2 = (object)SEQ_PTR(_find_result_22004);
    _12443 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12443);
    ((intptr_t*)_2)[1] = _12443;
    _12444 = MAKE_SEQ(_1);
    _12443 = NOVALUE;
    RefDS(_12442);
    RefDS(_opts_22006);
    Ref(_add_help_rid_22010);
    RefDS(_cmds_22009);
    Ref(_parse_options_22011);
    _48parse_abort(_12442, _12444, _opts_22006, _add_help_rid_22010, _cmds_22009, _parse_options_22011, _help_on_error_22014, _auto_help_22015);
    _12444 = NOVALUE;
    goto L5; // [181] 201
L2: 

    /** cmdline.e:1134				param = find_result[4]*/
    DeRef(_param_22020);
    _2 = (object)SEQ_PTR(_find_result_22004);
    _param_22020 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_param_22020);
    goto L5; // [191] 201
L1: 

    /** cmdline.e:1137			param = find_result[4]*/
    DeRef(_param_22020);
    _2 = (object)SEQ_PTR(_find_result_22004);
    _param_22020 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_param_22020);
L5: 

    /** cmdline.e:1140		if opt[CALLBACK] >= 0 then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12447 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _12447, 0)){
        _12447 = NOVALUE;
        goto L7; // [207] 282
    }
    _12447 = NOVALUE;

    /** cmdline.e:1141			integer pos = find_result[1]*/
    _2 = (object)SEQ_PTR(_find_result_22004);
    _pos_22058 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_22058))
    _pos_22058 = (object)DBL_PTR(_pos_22058)->dbl;

    /** cmdline.e:1142			call_count[pos] += 1*/
    _2 = (object)SEQ_PTR(_call_count_22012);
    _12450 = (object)*(((s1_ptr)_2)->base + _pos_22058);
    if (IS_ATOM_INT(_12450)) {
        _12451 = _12450 + 1;
        if (_12451 > MAXINT){
            _12451 = NewDouble((eudouble)_12451);
        }
    }
    else
    _12451 = binary_op(PLUS, 1, _12450);
    _12450 = NOVALUE;
    _2 = (object)SEQ_PTR(_call_count_22012);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _call_count_22012 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pos_22058);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _12451;
    if( _1 != _12451 ){
        DeRef(_1);
    }
    _12451 = NOVALUE;

    /** cmdline.e:1144			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12452 = (object)*(((s1_ptr)_2)->base + 5);
    _2 = (object)SEQ_PTR(_find_result_22004);
    _12453 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_call_count_22012);
    _12454 = (object)*(((s1_ptr)_2)->base + _pos_22058);
    _2 = (object)SEQ_PTR(_find_result_22004);
    _12455 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12453);
    ((intptr_t*)_2)[1] = _12453;
    Ref(_12454);
    ((intptr_t*)_2)[2] = _12454;
    Ref(_param_22020);
    ((intptr_t*)_2)[3] = _param_22020;
    Ref(_12455);
    ((intptr_t*)_2)[4] = _12455;
    _12456 = MAKE_SEQ(_1);
    _12455 = NOVALUE;
    _12454 = NOVALUE;
    _12453 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12456;
    _12457 = MAKE_SEQ(_1);
    _12456 = NOVALUE;
    _1 = (object)SEQ_PTR(_12457);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_12452].addr;
    Ref( *(( (intptr_t*)_2) + 1) );
    _1 = (*(intptr_t (*)())_0)(
                        *( ((intptr_t *)_2) + 1)
                         );
    DeRef(_12458);
    _12458 = _1;
    DeRefDS(_12457);
    _12457 = NOVALUE;
    if (binary_op_a(NOTEQ, _12458, 0)){
        DeRef(_12458);
        _12458 = NOVALUE;
        goto L8; // [266] 281
    }
    DeRef(_12458);
    _12458 = NOVALUE;

    /** cmdline.e:1145				return { arg_idx, call_count }*/
    RefDS(_call_count_22012);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _arg_idx_22005;
    ((intptr_t *)_2)[2] = _call_count_22012;
    _12460 = MAKE_SEQ(_1);
    DeRefDS(_find_result_22004);
    DeRefDS(_opts_22006);
    DeRef(_parsed_opts_22008);
    DeRefDS(_cmds_22009);
    DeRef(_add_help_rid_22010);
    DeRef(_parse_options_22011);
    DeRefDS(_call_count_22012);
    DeRefDS(_opt_22017);
    DeRef(_param_22020);
    DeRef(_12431);
    _12431 = NOVALUE;
    DeRef(_12441);
    _12441 = NOVALUE;
    _12419 = NOVALUE;
    _12452 = NOVALUE;
    DeRef(_12437);
    _12437 = NOVALUE;
    DeRef(_12439);
    _12439 = NOVALUE;
    return _12460;
L8: 
L7: 

    /** cmdline.e:1149		if find_result[3] = 1 then*/
    _2 = (object)SEQ_PTR(_find_result_22004);
    _12461 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _12461, 1)){
        _12461 = NOVALUE;
        goto L9; // [290] 307
    }
    _12461 = NOVALUE;

    /** cmdline.e:1150			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12463 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_22008);
    Ref(_12463);
    _34remove(_parsed_opts_22008, _12463);
    _12463 = NOVALUE;
    goto LA; // [304] 446
L9: 

    /** cmdline.e:1152			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12464 = (object)*(((s1_ptr)_2)->base + 4);
    _12465 = find_from(42, _12464, 1);
    _12464 = NOVALUE;
    if (_12465 != 0)
    goto LB; // [318] 429

    /** cmdline.e:1153				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12467 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_22008);
    Ref(_12467);
    _12468 = _34has(_parsed_opts_22008, _12467);
    _12467 = NOVALUE;
    if (IS_ATOM_INT(_12468)) {
        if (_12468 == 0) {
            goto LC; // [333] 410
        }
    }
    else {
        if (DBL_PTR(_12468)->dbl == 0.0) {
            goto LC; // [333] 410
        }
    }
    _12470 = (_validation_22013 == 2);
    if (_12470 != 0) {
        DeRef(_12471);
        _12471 = 1;
        goto LD; // [341] 353
    }
    _12472 = (_validation_22013 == 4);
    _12471 = (_12472 != 0);
LD: 
    if (_12471 == 0)
    {
        _12471 = NOVALUE;
        goto LC; // [354] 410
    }
    else{
        _12471 = NOVALUE;
    }

    /** cmdline.e:1156					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12473 = (object)*(((s1_ptr)_2)->base + 4);
    _12474 = find_from(112, _12473, 1);
    _12473 = NOVALUE;
    if (_12474 != 0) {
        goto LE; // [368] 386
    }
    _2 = (object)SEQ_PTR(_opt_22017);
    _12476 = (object)*(((s1_ptr)_2)->base + 4);
    _12477 = find_from(49, _12476, 1);
    _12476 = NOVALUE;
    if (_12477 == 0)
    {
        _12477 = NOVALUE;
        goto LF; // [382] 445
    }
    else{
        _12477 = NOVALUE;
    }
LE: 

    /** cmdline.e:1157						parse_abort( "option '%s' must not occur more than once in the command line.\n\n", */
    _2 = (object)SEQ_PTR(_find_result_22004);
    _12479 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12479);
    ((intptr_t*)_2)[1] = _12479;
    _12480 = MAKE_SEQ(_1);
    _12479 = NOVALUE;
    RefDS(_12478);
    RefDS(_opts_22006);
    Ref(_add_help_rid_22010);
    RefDS(_cmds_22009);
    Ref(_parse_options_22011);
    _48parse_abort(_12478, _12480, _opts_22006, _add_help_rid_22010, _cmds_22009, _parse_options_22011, _help_on_error_22014, _auto_help_22015);
    _12480 = NOVALUE;
    goto LF; // [407] 445
LC: 

    /** cmdline.e:1161					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12481 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_22008);
    Ref(_12481);
    Ref(_param_22020);
    _34put(_parsed_opts_22008, _12481, _param_22020, 1, 0);
    _12481 = NOVALUE;
    goto LF; // [426] 445
LB: 

    /** cmdline.e:1164				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12482 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_22008);
    Ref(_12482);
    Ref(_param_22020);
    _34put(_parsed_opts_22008, _12482, _param_22020, _map_add_operation_22016, 0);
    _12482 = NOVALUE;
LF: 
LA: 

    /** cmdline.e:1168		if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12483 = (object)*(((s1_ptr)_2)->base + 4);
    _12484 = find_from(118, _12483, 1);
    _12483 = NOVALUE;
    if (_12484 == 0)
    {
        _12484 = NOVALUE;
        goto L10; // [457] 544
    }
    else{
        _12484 = NOVALUE;
    }

    /** cmdline.e:1169			integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12485 = (object)*(((s1_ptr)_2)->base + 4);
    _12486 = find_from(118, _12485, 1);
    _12485 = NOVALUE;
    _ver_pos_22104 = _12486 + 1;
    _12486 = NOVALUE;

    /** cmdline.e:1170			if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12488 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_12488)){
            _12489 = SEQ_PTR(_12488)->length;
    }
    else {
        _12489 = 1;
    }
    _12488 = NOVALUE;
    if (_12489 < _ver_pos_22104)
    goto L11; // [484] 513

    /** cmdline.e:1171				printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (object)SEQ_PTR(_opt_22017);
    _12491 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_12491);
    _12492 = (object)*(((s1_ptr)_2)->base + _ver_pos_22104);
    _12491 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_12492);
    ((intptr_t*)_2)[1] = _12492;
    _12493 = MAKE_SEQ(_1);
    _12492 = NOVALUE;
    EPrintf(1, _12018, _12493);
    DeRefDS(_12493);
    _12493 = NOVALUE;

    /** cmdline.e:1172				abort(0)*/
    UserCleanup(0);
    goto L12; // [510] 543
L11: 

    /** cmdline.e:1174				error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_12496, _12494, _12495);
    DeRefi(_fmt_inlined_crash_at_521_22120);
    _fmt_inlined_crash_at_521_22120 = _12496;
    _12496 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_524_22121);
    _msg_inlined_crash_at_524_22121 = EPrintf(-9999999, _fmt_inlined_crash_at_521_22120, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_524_22121);

    /** error.e:53	end procedure*/
    goto L13; // [537] 540
L13: 
    DeRefi(_fmt_inlined_crash_at_521_22120);
    _fmt_inlined_crash_at_521_22120 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_524_22121);
    _msg_inlined_crash_at_524_22121 = NOVALUE;
L12: 
L10: 

    /** cmdline.e:1178		return {arg_idx, call_count}*/
    RefDS(_call_count_22012);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _arg_idx_22005;
    ((intptr_t *)_2)[2] = _call_count_22012;
    _12497 = MAKE_SEQ(_1);
    DeRefDS(_find_result_22004);
    DeRefDS(_opts_22006);
    DeRef(_parsed_opts_22008);
    DeRefDS(_cmds_22009);
    DeRef(_add_help_rid_22010);
    DeRef(_parse_options_22011);
    DeRefDS(_call_count_22012);
    DeRef(_opt_22017);
    DeRef(_param_22020);
    _12488 = NOVALUE;
    DeRef(_12472);
    _12472 = NOVALUE;
    DeRef(_12431);
    _12431 = NOVALUE;
    DeRef(_12441);
    _12441 = NOVALUE;
    _12419 = NOVALUE;
    _12452 = NOVALUE;
    DeRef(_12437);
    _12437 = NOVALUE;
    DeRef(_12460);
    _12460 = NOVALUE;
    DeRef(_12470);
    _12470 = NOVALUE;
    DeRef(_12468);
    _12468 = NOVALUE;
    DeRef(_12439);
    _12439 = NOVALUE;
    return _12497;
    ;
}


object _48cmd_parse(object _opts_22125, object _parse_options_22126, object _cmds_22127)
{
    object _cmd_22129 = NOVALUE;
    object _help_opts_22130 = NOVALUE;
    object _call_count_22131 = NOVALUE;
    object _add_help_rid_22132 = NOVALUE;
    object _validation_22133 = NOVALUE;
    object _has_extra_22134 = NOVALUE;
    object _use_at_22135 = NOVALUE;
    object _auto_help_22136 = NOVALUE;
    object _help_on_error_22137 = NOVALUE;
    object _po_22138 = NOVALUE;
    object _msg_inlined_crash_at_161_22162 = NOVALUE;
    object _msg_inlined_crash_at_225_22173 = NOVALUE;
    object _msg_inlined_crash_at_263_22180 = NOVALUE;
    object _fmt_inlined_crash_at_260_22179 = NOVALUE;
    object _parsed_opts_22185 = NOVALUE;
    object _new_1__tmp_at315_22188 = NOVALUE;
    object _new_inlined_new_at_315_22187 = NOVALUE;
    object _cmds_ok_22190 = NOVALUE;
    object _12524 = NOVALUE;
    object _12520 = NOVALUE;
    object _12517 = NOVALUE;
    object _12516 = NOVALUE;
    object _12510 = NOVALUE;
    object _12506 = NOVALUE;
    object _12503 = NOVALUE;
    object _12501 = NOVALUE;
    object _12499 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1428		object add_help_rid = -1*/
    DeRef(_add_help_rid_22132);
    _add_help_rid_22132 = -1;

    /** cmdline.e:1429		integer validation = VALIDATE_ALL*/
    _validation_22133 = 2;

    /** cmdline.e:1430		integer has_extra = 0*/
    _has_extra_22134 = 0;

    /** cmdline.e:1431		integer use_at = 1*/
    _use_at_22135 = 1;

    /** cmdline.e:1432		integer auto_help = 1*/
    _auto_help_22136 = 1;

    /** cmdline.e:1433		integer help_on_error = 1*/
    _help_on_error_22137 = 1;

    /** cmdline.e:1435		integer po = 1*/
    _po_22138 = 1;

    /** cmdline.e:1436		if atom(parse_options) then*/
    _12499 = 0;
    if (_12499 == 0)
    {
        _12499 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _12499 = NOVALUE;
    }

    /** cmdline.e:1437			parse_options = {parse_options}*/
    _0 = _parse_options_22126;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_parse_options_22126);
    ((intptr_t*)_2)[1] = _parse_options_22126;
    _parse_options_22126 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** cmdline.e:1441		while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_22126)){
            _12501 = SEQ_PTR(_parse_options_22126)->length;
    }
    else {
        _12501 = 1;
    }
    if (_po_22138 > _12501)
    goto L3; // [63] 296

    /** cmdline.e:1442			switch parse_options[po] do*/
    _2 = (object)SEQ_PTR(_parse_options_22126);
    _12503 = (object)*(((s1_ptr)_2)->base + _po_22138);
    if (IS_SEQUENCE(_12503) ){
        goto L4; // [73] 249
    }
    if(!IS_ATOM_INT(_12503)){
        if( (DBL_PTR(_12503)->dbl != (eudouble) ((object) DBL_PTR(_12503)->dbl) ) ){
            goto L4; // [73] 249
        }
        _0 = (object) DBL_PTR(_12503)->dbl;
    }
    else {
        _0 = _12503;
    };
    _12503 = NOVALUE;
    switch ( _0 ){ 

        /** cmdline.e:1444				case NO_HELP then                         auto_help = 0*/
        case 9:
        _auto_help_22136 = 0;
        goto L5; // [85] 285

        /** cmdline.e:1445				case VALIDATE_ALL then                    validation = VALIDATE_ALL*/
        case 2:
        _validation_22133 = 2;
        goto L5; // [94] 285

        /** cmdline.e:1446				case NO_VALIDATION then                   validation = NO_VALIDATION*/
        case 3:
        _validation_22133 = 3;
        goto L5; // [103] 285

        /** cmdline.e:1447				case NO_VALIDATION_AFTER_FIRST_EXTRA then validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        case 4:
        _validation_22133 = 4;
        goto L5; // [112] 285

        /** cmdline.e:1448				case NO_AT_EXPANSION then                 use_at = 0*/
        case 7:
        _use_at_22135 = 0;
        goto L5; // [121] 285

        /** cmdline.e:1449				case AT_EXPANSION then                    use_at = 1*/
        case 6:
        _use_at_22135 = 1;
        goto L5; // [130] 285

        /** cmdline.e:1451				case HELP_RID then*/
        case 1:

        /** cmdline.e:1452					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_22126)){
                _12506 = SEQ_PTR(_parse_options_22126)->length;
        }
        else {
            _12506 = 1;
        }
        if (_po_22138 >= _12506)
        goto L6; // [141] 160

        /** cmdline.e:1453						po += 1*/
        _po_22138 = _po_22138 + 1;

        /** cmdline.e:1454						add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_22132);
        _2 = (object)SEQ_PTR(_parse_options_22126);
        _add_help_rid_22132 = (object)*(((s1_ptr)_2)->base + _po_22138);
        Ref(_add_help_rid_22132);
        goto L5; // [157] 285
L6: 

        /** cmdline.e:1456						error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_161_22162);
        _msg_inlined_crash_at_161_22162 = EPrintf(-9999999, _12053, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_161_22162);

        /** error.e:53	end procedure*/
        goto L7; // [175] 178
L7: 
        DeRefi(_msg_inlined_crash_at_161_22162);
        _msg_inlined_crash_at_161_22162 = NOVALUE;
        goto L5; // [181] 285

        /** cmdline.e:1459				case NO_HELP_ON_ERROR then*/
        case 10:

        /** cmdline.e:1461					help_on_error = 0*/
        _help_on_error_22137 = 0;
        goto L5; // [192] 285

        /** cmdline.e:1463				case PAUSE_MSG then*/
        case 8:

        /** cmdline.e:1464					if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_22126)){
                _12510 = SEQ_PTR(_parse_options_22126)->length;
        }
        else {
            _12510 = 1;
        }
        if (_po_22138 >= _12510)
        goto L8; // [203] 224

        /** cmdline.e:1465						po += 1*/
        _po_22138 = _po_22138 + 1;

        /** cmdline.e:1466						pause_msg = parse_options[po]*/
        DeRef(_48pause_msg_20995);
        _2 = (object)SEQ_PTR(_parse_options_22126);
        _48pause_msg_20995 = (object)*(((s1_ptr)_2)->base + _po_22138);
        Ref(_48pause_msg_20995);
        goto L5; // [221] 285
L8: 

        /** cmdline.e:1468						error:crash("PAUSE_MSG was given to cmd_parse with no actual message text")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_225_22173);
        _msg_inlined_crash_at_225_22173 = EPrintf(-9999999, _12514, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_225_22173);

        /** error.e:53	end procedure*/
        goto L9; // [239] 242
L9: 
        DeRefi(_msg_inlined_crash_at_225_22173);
        _msg_inlined_crash_at_225_22173 = NOVALUE;
        goto L5; // [245] 285

        /** cmdline.e:1471				case else*/
        default:
L4: 

        /** cmdline.e:1472					error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (object)SEQ_PTR(_parse_options_22126);
        _12516 = (object)*(((s1_ptr)_2)->base + _po_22138);
        _12517 = EPrintf(-9999999, _12515, _12516);
        _12516 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_260_22179);
        _fmt_inlined_crash_at_260_22179 = _12517;
        _12517 = NOVALUE;

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_263_22180);
        _msg_inlined_crash_at_263_22180 = EPrintf(-9999999, _fmt_inlined_crash_at_260_22179, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_263_22180);

        /** error.e:53	end procedure*/
        goto LA; // [279] 282
LA: 
        DeRefi(_fmt_inlined_crash_at_260_22179);
        _fmt_inlined_crash_at_260_22179 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_263_22180);
        _msg_inlined_crash_at_263_22180 = NOVALUE;
    ;}L5: 

    /** cmdline.e:1475			po += 1*/
    _po_22138 = _po_22138 + 1;

    /** cmdline.e:1476		end while*/
    goto L2; // [293] 60
L3: 

    /** cmdline.e:1478		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_22125);
    _0 = _opts_22125;
    _opts_22125 = _48standardize_opts(_opts_22125, _auto_help_22136);
    DeRefDS(_0);

    /** cmdline.e:1479		call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_22125)){
            _12520 = SEQ_PTR(_opts_22125)->length;
    }
    else {
        _12520 = 1;
    }
    DeRef(_call_count_22131);
    _call_count_22131 = Repeat(0, _12520);
    _12520 = NOVALUE;

    /** cmdline.e:1481		map:map parsed_opts = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at315_22188;
    _new_1__tmp_at315_22188 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at315_22188);
    _0 = _parsed_opts_22185;
    _parsed_opts_22185 = _35malloc(_new_1__tmp_at315_22188, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at315_22188);
    _new_1__tmp_at315_22188 = NOVALUE;

    /** cmdline.e:1482		map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_22185);
    RefDS(_48EXTRAS_20984);
    RefDS(_5);
    _34put(_parsed_opts_22185, _48EXTRAS_20984, _5, 1, 0);

    /** cmdline.e:1485		help_opts = get_help_options( opts )*/
    RefDS(_opts_22125);
    _0 = _help_opts_22130;
    _help_opts_22130 = _48get_help_options(_opts_22125);
    DeRef(_0);

    /** cmdline.e:1487		object cmds_ok = parse_commands( cmds, opts, parsed_opts, help_opts, add_help_rid, parse_options, */
    RefDS(_cmds_22127);
    RefDS(_opts_22125);
    Ref(_parsed_opts_22185);
    RefDS(_help_opts_22130);
    Ref(_add_help_rid_22132);
    Ref(_parse_options_22126);
    RefDS(_call_count_22131);
    _0 = _cmds_ok_22190;
    _cmds_ok_22190 = _48parse_commands(_cmds_22127, _opts_22125, _parsed_opts_22185, _help_opts_22130, _add_help_rid_22132, _parse_options_22126, _use_at_22135, _validation_22133, _has_extra_22134, _call_count_22131, _help_on_error_22137, _auto_help_22136);
    DeRef(_0);

    /** cmdline.e:1489		if atom( cmds_ok ) then*/
    _12524 = IS_ATOM(_cmds_ok_22190);
    if (_12524 == 0)
    {
        _12524 = NOVALUE;
        goto LB; // [371] 381
    }
    else{
        _12524 = NOVALUE;
    }

    /** cmdline.e:1490			return 0*/
    DeRefDS(_opts_22125);
    DeRef(_parse_options_22126);
    DeRefDS(_cmds_22127);
    DeRefDS(_help_opts_22130);
    DeRefDS(_call_count_22131);
    DeRef(_add_help_rid_22132);
    DeRef(_parsed_opts_22185);
    DeRef(_cmds_ok_22190);
    return 0;
LB: 

    /** cmdline.e:1492		cmds       = cmds_ok[1]*/
    DeRefDS(_cmds_22127);
    _2 = (object)SEQ_PTR(_cmds_ok_22190);
    _cmds_22127 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_cmds_22127);

    /** cmdline.e:1493		call_count = cmds_ok[2]*/
    DeRef(_call_count_22131);
    _2 = (object)SEQ_PTR(_cmds_ok_22190);
    _call_count_22131 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_call_count_22131);

    /** cmdline.e:1496		check_mandatory( opts, parsed_opts, add_help_rid, cmds, parse_options, help_on_error, auto_help )*/
    RefDS(_opts_22125);
    Ref(_parsed_opts_22185);
    Ref(_add_help_rid_22132);
    RefDS(_cmds_22127);
    Ref(_parse_options_22126);
    _48check_mandatory(_opts_22125, _parsed_opts_22185, _add_help_rid_22132, _cmds_22127, _parse_options_22126, _help_on_error_22137, _auto_help_22136);

    /** cmdline.e:1498		return parsed_opts*/
    DeRefDS(_opts_22125);
    DeRef(_parse_options_22126);
    DeRefDS(_cmds_22127);
    DeRef(_help_opts_22130);
    DeRefDS(_call_count_22131);
    DeRef(_add_help_rid_22132);
    DeRef(_cmds_ok_22190);
    return _parsed_opts_22185;
    ;
}


object _48build_commandline(object _cmds_22198)
{
    object _12530 = NOVALUE;
    object _12529 = NOVALUE;
    object _12527 = NOVALUE;
    object _0, _1, _2;
    

    /** cmdline.e:1551		return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_5786);
    RefDS(_5786);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5786;
    ((intptr_t *)_2)[2] = _5786;
    _12527 = MAKE_SEQ(_1);
    RefDS(_cmds_22198);
    RefDS(_12528);
    _12529 = _12quote(_cmds_22198, _12527, 92, _12528);
    _12527 = NOVALUE;
    RefDS(_12528);
    _12530 = _24flatten(_12529, _12528);
    _12529 = NOVALUE;
    DeRefDS(_cmds_22198);
    return _12530;
    ;
}



// 0x2066CBF6
