// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _53hashfn(object _name_47199)
{
    object _len_47200 = NOVALUE;
    object _val_47201 = NOVALUE;
    object _int_47202 = NOVALUE;
    object _24532 = NOVALUE;
    object _24531 = NOVALUE;
    object _24528 = NOVALUE;
    object _24527 = NOVALUE;
    object _24516 = NOVALUE;
    object _24512 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_47199)){
            _len_47200 = SEQ_PTR(_name_47199)->length;
    }
    else {
        _len_47200 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_47199);
    _val_47201 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_47201))
    _val_47201 = (object)DBL_PTR(_val_47201)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_47199)){
            _24512 = SEQ_PTR(_name_47199)->length;
    }
    else {
        _24512 = 1;
    }
    _2 = (object)SEQ_PTR(_name_47199);
    _int_47202 = (object)*(((s1_ptr)_2)->base + _24512);
    if (!IS_ATOM_INT(_int_47202))
    _int_47202 = (object)DBL_PTR(_int_47202)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_47202 = _int_47202 * 256;

    /** symtab.e:54		val *= 2*/
    _val_47201 = _val_47201 + _val_47201;

    /** symtab.e:55		val += int + len*/
    _24516 = _int_47202 + _len_47200;
    if ((object)((uintptr_t)_24516 + (uintptr_t)HIGH_BITS) >= 0){
        _24516 = NewDouble((eudouble)_24516);
    }
    if (IS_ATOM_INT(_24516)) {
        _val_47201 = _val_47201 + _24516;
    }
    else {
        _val_47201 = NewDouble((eudouble)_val_47201 + DBL_PTR(_24516)->dbl);
    }
    DeRef(_24516);
    _24516 = NOVALUE;
    if (!IS_ATOM_INT(_val_47201)) {
        _1 = (object)(DBL_PTR(_val_47201)->dbl);
        DeRefDS(_val_47201);
        _val_47201 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_47200 != 3)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_47201 = _val_47201 * 32;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47199);
    _int_47202 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_47202))
    _int_47202 = (object)DBL_PTR(_int_47202)->dbl;

    /** symtab.e:60			val += int*/
    _val_47201 = _val_47201 + _int_47202;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_47200 <= 3)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_47201 = _val_47201 * 32;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47199);
    _int_47202 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_47202))
    _int_47202 = (object)DBL_PTR(_int_47202)->dbl;

    /** symtab.e:64			val += int*/
    _val_47201 = _val_47201 + _int_47202;

    /** symtab.e:66			val *= 32*/
    _val_47201 = _val_47201 * 32;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_47199)){
            _24527 = SEQ_PTR(_name_47199)->length;
    }
    else {
        _24527 = 1;
    }
    _24528 = _24527 - 1;
    _24527 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_47199);
    _int_47202 = (object)*(((s1_ptr)_2)->base + _24528);
    if (!IS_ATOM_INT(_int_47202))
    _int_47202 = (object)DBL_PTR(_int_47202)->dbl;

    /** symtab.e:68			val += int*/
    _val_47201 = _val_47201 + _int_47202;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24531 = (_val_47201 % 2003);
    _24532 = _24531 + 1;
    _24531 = NOVALUE;
    DeRefDS(_name_47199);
    DeRef(_24528);
    _24528 = NOVALUE;
    return _24532;
    ;
}


void _53remove_symbol(object _sym_47231)
{
    object _hash_47232 = NOVALUE;
    object _st_ptr_47233 = NOVALUE;
    object _24547 = NOVALUE;
    object _24546 = NOVALUE;
    object _24544 = NOVALUE;
    object _24543 = NOVALUE;
    object _24542 = NOVALUE;
    object _24540 = NOVALUE;
    object _24538 = NOVALUE;
    object _24537 = NOVALUE;
    object _24536 = NOVALUE;
    object _24533 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24533 = (object)*(((s1_ptr)_2)->base + _sym_47231);
    _2 = (object)SEQ_PTR(_24533);
    _hash_47232 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_47232)){
        _hash_47232 = (object)DBL_PTR(_hash_47232)->dbl;
    }
    _24533 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _st_ptr_47233 = (object)*(((s1_ptr)_2)->base + _hash_47232);
    if (!IS_ATOM_INT(_st_ptr_47233))
    _st_ptr_47233 = (object)DBL_PTR(_st_ptr_47233)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_47233 == 0) {
        goto L2; // [32] 65
    }
    _24537 = (_st_ptr_47233 != _sym_47231);
    if (_24537 == 0)
    {
        DeRef(_24537);
        _24537 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24537);
        _24537 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24538 = (object)*(((s1_ptr)_2)->base + _st_ptr_47233);
    _2 = (object)SEQ_PTR(_24538);
    _st_ptr_47233 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_47233)){
        _st_ptr_47233 = (object)DBL_PTR(_st_ptr_47233)->dbl;
    }
    _24538 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_47233 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _24540 = (object)*(((s1_ptr)_2)->base + _hash_47232);
    if (binary_op_a(NOTEQ, _st_ptr_47233, _24540)){
        _24540 = NOVALUE;
        goto L4; // [78] 105
    }
    _24540 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24542 = (object)*(((s1_ptr)_2)->base + _st_ptr_47233);
    _2 = (object)SEQ_PTR(_24542);
    _24543 = (object)*(((s1_ptr)_2)->base + 9);
    _24542 = NOVALUE;
    Ref(_24543);
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _2 = (object)(((s1_ptr)_2)->base + _hash_47232);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24543;
    if( _1 != _24543 ){
        DeRef(_1);
    }
    _24543 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_47233 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24546 = (object)*(((s1_ptr)_2)->base + _sym_47231);
    _2 = (object)SEQ_PTR(_24546);
    _24547 = (object)*(((s1_ptr)_2)->base + 9);
    _24546 = NOVALUE;
    Ref(_24547);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24547;
    if( _1 != _24547 ){
        DeRef(_1);
    }
    _24547 = NOVALUE;
    _24544 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _53NewBasicEntry(object _name_47265, object _varnum_47266, object _scope_47267, object _token_47268, object _hashval_47269, object _samehash_47271, object _type_sym_47273)
{
    object _new_47274 = NOVALUE;
    object _24556 = NOVALUE;
    object _24554 = NOVALUE;
    object _24553 = NOVALUE;
    object _24552 = NOVALUE;
    object _24551 = NOVALUE;
    object _24550 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_47274);
    _new_47274 = Repeat(0, _27SIZEOF_ROUTINE_ENTRY_20335);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_47274);
    _new_47274 = Repeat(0, _27SIZEOF_VAR_ENTRY_20338);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_47265);
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NAME_20209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NAME_20209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_47265;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_47267;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24550 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24550 = - _27NOVALUE_20426;
        }
    }
    else {
        _24550 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24550;
    if( _1 != _24550 ){
        DeRef(_1);
    }
    _24550 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24551 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24551 = - _27NOVALUE_20426;
        }
    }
    else {
        _24551 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24551;
    if( _1 != _24551 ){
        DeRef(_1);
    }
    _24551 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24552 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24552 = - _27NOVALUE_20426;
        }
    }
    else {
        _24552 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24552;
    if( _1 != _24552 ){
        DeRef(_1);
    }
    _24552 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _9TRUE_441;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24553 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24553 = - _27NOVALUE_20426;
        }
    }
    else {
        _24553 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24553;
    if( _1 != _24553 ){
        DeRef(_1);
    }
    _24553 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _24554 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24554 = - _27NOVALUE_20426;
        }
    }
    else {
        _24554 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24554;
    if( _1 != _24554 ){
        DeRef(_1);
    }
    _24554 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TOKEN_20214))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_47268;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_47266;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_47273;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_47269;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_47271;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_47274);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47274 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_47274);
    Append(&_28SymTab_11572, _28SymTab_11572, _new_47274);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _24556 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _24556 = 1;
    }
    DeRefDS(_name_47265);
    DeRefDS(_new_47274);
    return _24556;
    ;
}


object _53NewEntry(object _name_47353, object _varnum_47354, object _scope_47355, object _token_47356, object _hashval_47357, object _samehash_47359, object _type_sym_47361)
{
    object _new_47363 = NOVALUE;
    object _24558 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_47355)) {
        _1 = (object)(DBL_PTR(_scope_47355)->dbl);
        DeRefDS(_scope_47355);
        _scope_47355 = _1;
    }
    if (!IS_ATOM_INT(_token_47356)) {
        _1 = (object)(DBL_PTR(_token_47356)->dbl);
        DeRefDS(_token_47356);
        _token_47356 = _1;
    }
    if (!IS_ATOM_INT(_samehash_47359)) {
        _1 = (object)(DBL_PTR(_samehash_47359)->dbl);
        DeRefDS(_samehash_47359);
        _samehash_47359 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_47353);
    _new_47363 = _53NewBasicEntry(_name_47353, _varnum_47354, _scope_47355, _token_47356, _hashval_47357, _samehash_47359, _type_sym_47361);
    if (!IS_ATOM_INT(_new_47363)) {
        _1 = (object)(DBL_PTR(_new_47363)->dbl);
        DeRefDS(_new_47363);
        _new_47363 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_53last_sym_47193 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_47193 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_47363;
    DeRef(_1);
    _24558 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _53last_sym_47193 = _new_47363;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_47361 >= 0)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _42register_forward_type(_53last_sym_47193, _type_sym_47361);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_47353);
    return _53last_sym_47193;
    ;
}


object _53tmp_alloc()
{
    object _new_entry_47378 = NOVALUE;
    object _24572 = NOVALUE;
    object _24570 = NOVALUE;
    object _24567 = NOVALUE;
    object _24564 = NOVALUE;
    object _24563 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_47378);
    _new_entry_47378 = Repeat(0, _27SIZEOF_TEMP_ENTRY_20344);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    *(intptr_t *)_2 = 4;

    /** symtab.e:194		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = 16;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    *(intptr_t *)_2 = -1073741824;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    *(intptr_t *)_2 = 1073741823;

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = _27NOVALUE_20426;

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_27temp_name_type_20654)){
            _24563 = SEQ_PTR(_27temp_name_type_20654)->length;
    }
    else {
        _24563 = 1;
    }
    _24564 = _24563 + 1;
    _24563 = NOVALUE;
    if (_24564 != 8087)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _24567 = MAKE_SEQ(_1);
    RefDS(_24567);
    Append(&_27temp_name_type_20654, _27temp_name_type_20654, _24567);
    DeRefDS(_24567);
    _24567 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_54TYPES_OBNL_47018);
    Append(&_27temp_name_type_20654, _27temp_name_type_20654, _54TYPES_OBNL_47018);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_27temp_name_type_20654)){
            _24570 = SEQ_PTR(_27temp_name_type_20654)->length;
    }
    else {
        _24570 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_47378);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47378 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24570;
    if( _1 != _24570 ){
        DeRef(_1);
    }
    _24570 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_47378);
    Append(&_28SymTab_11572, _28SymTab_11572, _new_entry_47378);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _24572 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _24572 = 1;
    }
    DeRefDS(_new_entry_47378);
    DeRef(_24564);
    _24564 = NOVALUE;
    return _24572;
    ;
}


void _53DefinedYet(object _sym_47447)
{
    object _24592 = NOVALUE;
    object _24591 = NOVALUE;
    object _24590 = NOVALUE;
    object _24588 = NOVALUE;
    object _24587 = NOVALUE;
    object _24585 = NOVALUE;
    object _24584 = NOVALUE;
    object _24583 = NOVALUE;
    object _24582 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24582 = (object)*(((s1_ptr)_2)->base + _sym_47447);
    _2 = (object)SEQ_PTR(_24582);
    _24583 = (object)*(((s1_ptr)_2)->base + 4);
    _24582 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9;
    ((intptr_t*)_2)[2] = 10;
    ((intptr_t*)_2)[3] = 7;
    _24584 = MAKE_SEQ(_1);
    _24585 = find_from(_24583, _24584, 1);
    _24583 = NOVALUE;
    DeRefDS(_24584);
    _24584 = NOVALUE;
    if (_24585 != 0)
    goto L1; // [34] 84
    _24585 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24587 = (object)*(((s1_ptr)_2)->base + _sym_47447);
    _2 = (object)SEQ_PTR(_24587);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _24588 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _24588 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _24587 = NOVALUE;
    if (binary_op_a(NOTEQ, _24588, _27current_file_no_20571)){
        _24588 = NOVALUE;
        goto L2; // [53] 83
    }
    _24588 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24590 = (object)*(((s1_ptr)_2)->base + _sym_47447);
    _2 = (object)SEQ_PTR(_24590);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24591 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24591 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24590 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24591);
    ((intptr_t*)_2)[1] = _24591;
    _24592 = MAKE_SEQ(_1);
    _24591 = NOVALUE;
    _49CompileErr(31, _24592, 0);
    _24592 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _53name_ext(object _s_47475)
{
    object _24599 = NOVALUE;
    object _24598 = NOVALUE;
    object _24597 = NOVALUE;
    object _24596 = NOVALUE;
    object _24594 = NOVALUE;
    object _24593 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47475)){
            _24593 = SEQ_PTR(_s_47475)->length;
    }
    else {
        _24593 = 1;
    }
    {
        object _i_47477;
        _i_47477 = _24593;
L1: 
        if (_i_47477 < 1){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47475);
        _24594 = (object)*(((s1_ptr)_2)->base + _i_47477);
        _24596 = find_from(_24594, _24595, 1);
        _24594 = NOVALUE;
        if (_24596 == 0)
        {
            _24596 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24596 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24597 = _i_47477 + 1;
        if (IS_SEQUENCE(_s_47475)){
                _24598 = SEQ_PTR(_s_47475)->length;
        }
        else {
            _24598 = 1;
        }
        rhs_slice_target = (object_ptr)&_24599;
        RHS_Slice(_s_47475, _24597, _24598);
        DeRefDS(_s_47475);
        _24597 = NOVALUE;
        return _24599;
L3: 

        /** symtab.e:245		end for*/
        _i_47477 = _i_47477 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24599);
    _24599 = NOVALUE;
    DeRef(_24597);
    _24597 = NOVALUE;
    return _s_47475;
    ;
}


object _53NewStringSym(object _s_47494)
{
    object _p_47496 = NOVALUE;
    object _tp_47497 = NOVALUE;
    object _prev_47498 = NOVALUE;
    object _search_count_47499 = NOVALUE;
    object _24643 = NOVALUE;
    object _24641 = NOVALUE;
    object _24640 = NOVALUE;
    object _24639 = NOVALUE;
    object _24637 = NOVALUE;
    object _24636 = NOVALUE;
    object _24633 = NOVALUE;
    object _24631 = NOVALUE;
    object _24629 = NOVALUE;
    object _24628 = NOVALUE;
    object _24627 = NOVALUE;
    object _24625 = NOVALUE;
    object _24623 = NOVALUE;
    object _24621 = NOVALUE;
    object _24619 = NOVALUE;
    object _24616 = NOVALUE;
    object _24614 = NOVALUE;
    object _24613 = NOVALUE;
    object _24612 = NOVALUE;
    object _24610 = NOVALUE;
    object _24608 = NOVALUE;
    object _24607 = NOVALUE;
    object _24606 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47497 = _53literal_init_47192;

    /** symtab.e:259		prev = 0*/
    _prev_47498 = 0;

    /** symtab.e:260		search_count = 0*/
    _search_count_47499 = 0;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47497 == 0)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47499 = _search_count_47499 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47499, _53SEARCH_LIMIT_47486)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24606 = (object)*(((s1_ptr)_2)->base + _tp_47497);
    _2 = (object)SEQ_PTR(_24606);
    _24607 = (object)*(((s1_ptr)_2)->base + 1);
    _24606 = NOVALUE;
    if (_s_47494 == _24607)
    _24608 = 1;
    else if (IS_ATOM_INT(_s_47494) && IS_ATOM_INT(_24607))
    _24608 = 0;
    else
    _24608 = (compare(_s_47494, _24607) == 0);
    _24607 = NOVALUE;
    if (_24608 == 0)
    {
        _24608 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24608 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47497 == _53literal_init_47192)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47498 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24612 = (object)*(((s1_ptr)_2)->base + _tp_47497);
    _2 = (object)SEQ_PTR(_24612);
    _24613 = (object)*(((s1_ptr)_2)->base + 2);
    _24612 = NOVALUE;
    Ref(_24613);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24613;
    if( _1 != _24613 ){
        DeRef(_1);
    }
    _24613 = NOVALUE;
    _24610 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47497 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47192;
    DeRef(_1);
    _24614 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _53literal_init_47192 = _tp_47497;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47494);
    return _tp_47497;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47498 = _tp_47497;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24616 = (object)*(((s1_ptr)_2)->base + _tp_47497);
    _2 = (object)SEQ_PTR(_24616);
    _tp_47497 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47497)){
        _tp_47497 = (object)DBL_PTR(_tp_47497)->dbl;
    }
    _24616 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47496 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47496)) {
        _1 = (object)(DBL_PTR(_p_47496)->dbl);
        DeRefDS(_p_47496);
        _p_47496 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    RefDS(_s_47494);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47494;
    DeRef(_1);
    _24619 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24621 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _24623 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47494)){
            _24627 = SEQ_PTR(_s_47494)->length;
    }
    else {
        _24627 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24627;
    if( _1 != _24627 ){
        DeRef(_1);
    }
    _24627 = NOVALUE;
    _24625 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24628 = (object)*(((s1_ptr)_2)->base + _p_47496);
    _2 = (object)SEQ_PTR(_24628);
    _24629 = (object)*(((s1_ptr)_2)->base + 32);
    _24628 = NOVALUE;
    if (binary_op_a(LESSEQ, _24629, 0)){
        _24629 = NOVALUE;
        goto L7; // [265] 289
    }
    _24629 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24631 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _24633 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24636 = (object)*(((s1_ptr)_2)->base + _p_47496);
    _2 = (object)SEQ_PTR(_24636);
    _24637 = (object)*(((s1_ptr)_2)->base + 34);
    _24636 = NOVALUE;
    RefDS(_24635);
    Ref(_24637);
    _54c_printf(_24635, _24637);
    _24637 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24639 = (object)*(((s1_ptr)_2)->base + _p_47496);
    _2 = (object)SEQ_PTR(_24639);
    _24640 = (object)*(((s1_ptr)_2)->base + 34);
    _24639 = NOVALUE;
    RefDS(_24638);
    Ref(_24640);
    _54c_hprintf(_24638, _24640);
    _24640 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24641 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47496 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47192;
    DeRef(_1);
    _24643 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _53literal_init_47192 = _p_47496;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47494);
    return _p_47496;
    ;
}


object _53NewIntSym(object _int_val_47592)
{
    object _p_47594 = NOVALUE;
    object _x_47595 = NOVALUE;
    object _24667 = NOVALUE;
    object _24665 = NOVALUE;
    object _24661 = NOVALUE;
    object _24659 = NOVALUE;
    object _24657 = NOVALUE;
    object _24655 = NOVALUE;
    object _24653 = NOVALUE;
    object _24651 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47595 = find_from(_int_val_47592, _53lastintval_47194, 1);

    /** symtab.e:311		if x then*/
    if (_x_47595 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_53lastintsym_47195);
    _24651 = (object)*(((s1_ptr)_2)->base + _x_47595);
    DeRef(_int_val_47592);
    return _24651;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47594 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47594)) {
        _1 = (object)(DBL_PTR(_p_47594)->dbl);
        DeRefDS(_p_47594);
        _p_47594 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24653 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    Ref(_int_val_47592);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47592;
    DeRef(_1);
    _24655 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    Ref(_int_val_47592);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47592;
    DeRef(_1);
    _24657 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    Ref(_int_val_47592);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47592;
    DeRef(_1);
    _24659 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24661 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47592);
    Prepend(&_53lastintval_47194, _53lastintval_47194, _int_val_47592);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_53lastintsym_47195, _53lastintsym_47195, _p_47594);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_53lastintval_47194)){
            _24665 = SEQ_PTR(_53lastintval_47194)->length;
    }
    else {
        _24665 = 1;
    }
    if (binary_op_a(LESSEQ, _24665, _53SEARCH_LIMIT_47486)){
        _24665 = NOVALUE;
        goto L5; // [198] 218
    }
    _24665 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_53SEARCH_LIMIT_47486)) {
        _24667 = _53SEARCH_LIMIT_47486 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _53SEARCH_LIMIT_47486, 2);
        _24667 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_53lastintval_47194;
    RHS_Slice(_53lastintval_47194, 1, _24667);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47592);
    _24651 = NOVALUE;
    DeRef(_24667);
    _24667 = NOVALUE;
    return _p_47594;
L2: 
    ;
}


object _53NewDoubleSym(object _d_47644)
{
    object _p_47646 = NOVALUE;
    object _tp_47647 = NOVALUE;
    object _prev_47648 = NOVALUE;
    object _search_count_47649 = NOVALUE;
    object _24697 = NOVALUE;
    object _24696 = NOVALUE;
    object _24695 = NOVALUE;
    object _24694 = NOVALUE;
    object _24693 = NOVALUE;
    object _24691 = NOVALUE;
    object _24689 = NOVALUE;
    object _24687 = NOVALUE;
    object _24685 = NOVALUE;
    object _24682 = NOVALUE;
    object _24680 = NOVALUE;
    object _24679 = NOVALUE;
    object _24678 = NOVALUE;
    object _24676 = NOVALUE;
    object _24674 = NOVALUE;
    object _24673 = NOVALUE;
    object _24672 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47647 = _53literal_init_47192;

    /** symtab.e:347		prev = 0*/
    _prev_47648 = 0;

    /** symtab.e:348		search_count = 0*/
    _search_count_47649 = 0;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47647 == 0)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47649 = _search_count_47649 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47649, _53SEARCH_LIMIT_47486)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24672 = (object)*(((s1_ptr)_2)->base + _tp_47647);
    _2 = (object)SEQ_PTR(_24672);
    _24673 = (object)*(((s1_ptr)_2)->base + 1);
    _24672 = NOVALUE;
    if (_d_47644 == _24673)
    _24674 = 1;
    else if (IS_ATOM_INT(_d_47644) && IS_ATOM_INT(_24673))
    _24674 = 0;
    else
    _24674 = (compare(_d_47644, _24673) == 0);
    _24673 = NOVALUE;
    if (_24674 == 0)
    {
        _24674 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24674 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47647 == _53literal_init_47192)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47648 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24678 = (object)*(((s1_ptr)_2)->base + _tp_47647);
    _2 = (object)SEQ_PTR(_24678);
    _24679 = (object)*(((s1_ptr)_2)->base + 2);
    _24678 = NOVALUE;
    Ref(_24679);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24679;
    if( _1 != _24679 ){
        DeRef(_1);
    }
    _24679 = NOVALUE;
    _24676 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47647 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47192;
    DeRef(_1);
    _24680 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _53literal_init_47192 = _tp_47647;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47644);
    return _tp_47647;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47648 = _tp_47647;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24682 = (object)*(((s1_ptr)_2)->base + _tp_47647);
    _2 = (object)SEQ_PTR(_24682);
    _tp_47647 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_47647)){
        _tp_47647 = (object)DBL_PTR(_tp_47647)->dbl;
    }
    _24682 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47646 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47646)) {
        _1 = (object)(DBL_PTR(_p_47646)->dbl);
        DeRefDS(_p_47646);
        _p_47646 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47646 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24685 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47646 + ((s1_ptr)_2)->base);
    Ref(_d_47644);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47644;
    DeRef(_1);
    _24687 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47646 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24689 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47646 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24691 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24693 = (object)*(((s1_ptr)_2)->base + _p_47646);
    _2 = (object)SEQ_PTR(_24693);
    _24694 = (object)*(((s1_ptr)_2)->base + 34);
    _24693 = NOVALUE;
    RefDS(_24635);
    Ref(_24694);
    _54c_printf(_24635, _24694);
    _24694 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24695 = (object)*(((s1_ptr)_2)->base + _p_47646);
    _2 = (object)SEQ_PTR(_24695);
    _24696 = (object)*(((s1_ptr)_2)->base + 34);
    _24695 = NOVALUE;
    RefDS(_24638);
    Ref(_24696);
    _54c_hprintf(_24638, _24696);
    _24696 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47646 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53literal_init_47192;
    DeRef(_1);
    _24697 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _53literal_init_47192 = _p_47646;

    /** symtab.e:381		return p*/
    DeRef(_d_47644);
    return _p_47646;
    ;
}


object _53NewTempSym(object _inlining_47718)
{
    object _p_47720 = NOVALUE;
    object _q_47721 = NOVALUE;
    object _24746 = NOVALUE;
    object _24744 = NOVALUE;
    object _24742 = NOVALUE;
    object _24740 = NOVALUE;
    object _24738 = NOVALUE;
    object _24736 = NOVALUE;
    object _24735 = NOVALUE;
    object _24734 = NOVALUE;
    object _24732 = NOVALUE;
    object _24731 = NOVALUE;
    object _24730 = NOVALUE;
    object _24728 = NOVALUE;
    object _24726 = NOVALUE;
    object _24723 = NOVALUE;
    object _24722 = NOVALUE;
    object _24721 = NOVALUE;
    object _24719 = NOVALUE;
    object _24717 = NOVALUE;
    object _24716 = NOVALUE;
    object _24715 = NOVALUE;
    object _24713 = NOVALUE;
    object _24711 = NOVALUE;
    object _24706 = NOVALUE;
    object _24705 = NOVALUE;
    object _24704 = NOVALUE;
    object _24703 = NOVALUE;
    object _24702 = NOVALUE;
    object _24701 = NOVALUE;
    object _24699 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47718 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24699 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24699);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _p_47720 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _p_47720 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    if (!IS_ATOM_INT(_p_47720)){
        _p_47720 = (object)DBL_PTR(_p_47720)->dbl;
    }
    _24699 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24701 = (_p_47720 != 0);
    if (_24701 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24703 = (object)*(((s1_ptr)_2)->base + _p_47720);
    _2 = (object)SEQ_PTR(_24703);
    _24704 = (object)*(((s1_ptr)_2)->base + 4);
    _24703 = NOVALUE;
    if (IS_ATOM_INT(_24704)) {
        _24705 = (_24704 != 0);
    }
    else {
        _24705 = binary_op(NOTEQ, _24704, 0);
    }
    _24704 = NOVALUE;
    if (_24705 <= 0) {
        if (_24705 == 0) {
            DeRef(_24705);
            _24705 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24705) && DBL_PTR(_24705)->dbl == 0.0){
                DeRef(_24705);
                _24705 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24705);
            _24705 = NOVALUE;
        }
    }
    DeRef(_24705);
    _24705 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24706 = (object)*(((s1_ptr)_2)->base + _p_47720);
    _2 = (object)SEQ_PTR(_24706);
    _p_47720 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_47720)){
        _p_47720 = (object)DBL_PTR(_p_47720)->dbl;
    }
    _24706 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47720 = 0;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47720 != 0)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _53temps_allocated_47715 = _53temps_allocated_47715 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47720 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_47720)) {
        _1 = (object)(DBL_PTR(_p_47720)->dbl);
        DeRefDS(_p_47720);
        _p_47720 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24711 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24715 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24715);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _24716 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _24716 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    _24715 = NOVALUE;
    Ref(_24716);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24716;
    if( _1 != _24716 ){
        DeRef(_1);
    }
    _24716 = NOVALUE;
    _24713 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47720;
    DeRef(_1);
    _24717 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47718 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _24721 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _24721 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _24719 = NOVALUE;
    if (IS_ATOM_INT(_24721)) {
        _24722 = _24721 + 1;
        if (_24722 > MAXINT){
            _24722 = NewDouble((eudouble)_24722);
        }
    }
    else
    _24722 = binary_op(PLUS, 1, _24721);
    _24721 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24722;
    if( _1 != _24722 ){
        DeRef(_1);
    }
    _24722 = NOVALUE;
    _24719 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _24723 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47721 = _53tmp_alloc();
    if (!IS_ATOM_INT(_q_47721)) {
        _1 = (object)(DBL_PTR(_q_47721)->dbl);
        DeRefDS(_q_47721);
        _q_47721 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47721 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _24726 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47721 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24730 = (object)*(((s1_ptr)_2)->base + _p_47720);
    _2 = (object)SEQ_PTR(_24730);
    _24731 = (object)*(((s1_ptr)_2)->base + 34);
    _24730 = NOVALUE;
    Ref(_24731);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24731;
    if( _1 != _24731 ){
        DeRef(_1);
    }
    _24731 = NOVALUE;
    _24728 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47721 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24734 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24734);
    if (!IS_ATOM_INT(_27S_TEMPS_20254)){
        _24735 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    }
    else{
        _24735 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    }
    _24734 = NOVALUE;
    Ref(_24735);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24735;
    if( _1 != _24735 ){
        DeRef(_1);
    }
    _24735 = NOVALUE;
    _24732 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47721;
    DeRef(_1);
    _24736 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47720 = _q_47721;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24738 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _24740 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    _24742 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _24744 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47720 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _24746 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24701);
    _24701 = NOVALUE;
    return _p_47720;
    ;
}


void _53InitSymTab()
{
    object _hashval_47837 = NOVALUE;
    object _len_47838 = NOVALUE;
    object _s_47840 = NOVALUE;
    object _st_index_47841 = NOVALUE;
    object _kname_47842 = NOVALUE;
    object _fixups_47843 = NOVALUE;
    object _si_47982 = NOVALUE;
    object _sj_47983 = NOVALUE;
    object _25332 = NOVALUE;
    object _25331 = NOVALUE;
    object _24861 = NOVALUE;
    object _24860 = NOVALUE;
    object _24859 = NOVALUE;
    object _24858 = NOVALUE;
    object _24857 = NOVALUE;
    object _24855 = NOVALUE;
    object _24854 = NOVALUE;
    object _24853 = NOVALUE;
    object _24852 = NOVALUE;
    object _24850 = NOVALUE;
    object _24848 = NOVALUE;
    object _24846 = NOVALUE;
    object _24845 = NOVALUE;
    object _24843 = NOVALUE;
    object _24841 = NOVALUE;
    object _24839 = NOVALUE;
    object _24838 = NOVALUE;
    object _24836 = NOVALUE;
    object _24835 = NOVALUE;
    object _24834 = NOVALUE;
    object _24833 = NOVALUE;
    object _24832 = NOVALUE;
    object _24829 = NOVALUE;
    object _24828 = NOVALUE;
    object _24827 = NOVALUE;
    object _24825 = NOVALUE;
    object _24824 = NOVALUE;
    object _24823 = NOVALUE;
    object _24821 = NOVALUE;
    object _24820 = NOVALUE;
    object _24819 = NOVALUE;
    object _24816 = NOVALUE;
    object _24814 = NOVALUE;
    object _24812 = NOVALUE;
    object _24811 = NOVALUE;
    object _24808 = NOVALUE;
    object _24807 = NOVALUE;
    object _24805 = NOVALUE;
    object _24803 = NOVALUE;
    object _24801 = NOVALUE;
    object _24799 = NOVALUE;
    object _24798 = NOVALUE;
    object _24797 = NOVALUE;
    object _24794 = NOVALUE;
    object _24793 = NOVALUE;
    object _24791 = NOVALUE;
    object _24790 = NOVALUE;
    object _24788 = NOVALUE;
    object _24787 = NOVALUE;
    object _24786 = NOVALUE;
    object _24784 = NOVALUE;
    object _24782 = NOVALUE;
    object _24781 = NOVALUE;
    object _24779 = NOVALUE;
    object _24778 = NOVALUE;
    object _24777 = NOVALUE;
    object _24775 = NOVALUE;
    object _24774 = NOVALUE;
    object _24773 = NOVALUE;
    object _24771 = NOVALUE;
    object _24770 = NOVALUE;
    object _24769 = NOVALUE;
    object _24767 = NOVALUE;
    object _24766 = NOVALUE;
    object _24765 = NOVALUE;
    object _24764 = NOVALUE;
    object _24763 = NOVALUE;
    object _24762 = NOVALUE;
    object _24761 = NOVALUE;
    object _24760 = NOVALUE;
    object _24759 = NOVALUE;
    object _24758 = NOVALUE;
    object _24756 = NOVALUE;
    object _24755 = NOVALUE;
    object _24754 = NOVALUE;
    object _24753 = NOVALUE;
    object _24749 = NOVALUE;
    object _24748 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_22209);
    DeRefi(_fixups_47843);
    _fixups_47843 = _22209;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23493)){
            _24748 = SEQ_PTR(_62keylist_23493)->length;
    }
    else {
        _24748 = 1;
    }
    {
        object _k_47845;
        _k_47845 = 1;
L1: 
        if (_k_47845 > _24748){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24749 = (object)*(((s1_ptr)_2)->base + _k_47845);
        DeRef(_kname_47842);
        _2 = (object)SEQ_PTR(_24749);
        _kname_47842 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_47842);
        _24749 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47842)){
                _len_47838 = SEQ_PTR(_kname_47842)->length;
        }
        else {
            _len_47838 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47842);
        _hashval_47837 = _53hashfn(_kname_47842);
        if (!IS_ATOM_INT(_hashval_47837)) {
            _1 = (object)(DBL_PTR(_hashval_47837)->dbl);
            DeRefDS(_hashval_47837);
            _hashval_47837 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24753 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24753);
        _24754 = (object)*(((s1_ptr)_2)->base + 2);
        _24753 = NOVALUE;
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24755 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24755);
        _24756 = (object)*(((s1_ptr)_2)->base + 3);
        _24755 = NOVALUE;
        RefDS(_kname_47842);
        Ref(_24754);
        Ref(_24756);
        _st_index_47841 = _53NewEntry(_kname_47842, 0, _24754, _24756, _hashval_47837, 0, 0);
        _24754 = NOVALUE;
        _24756 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47841)) {
            _1 = (object)(DBL_PTR(_st_index_47841)->dbl);
            DeRefDS(_st_index_47841);
            _st_index_47841 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24758 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24758);
        _24759 = (object)*(((s1_ptr)_2)->base + 3);
        _24758 = NOVALUE;
        _24760 = find_from(_24759, _29RTN_TOKS_12277, 1);
        _24759 = NOVALUE;
        if (_24760 == 0)
        {
            _24760 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24760 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24761 = (object)*(((s1_ptr)_2)->base + _st_index_47841);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24762 = (object)*(((s1_ptr)_2)->base + _st_index_47841);
        if (IS_SEQUENCE(_24762)){
                _24763 = SEQ_PTR(_24762)->length;
        }
        else {
            _24763 = 1;
        }
        _24762 = NOVALUE;
        _24764 = _27SIZEOF_ROUTINE_ENTRY_20335 - _24763;
        _24763 = NOVALUE;
        _24765 = Repeat(0, _24764);
        _24764 = NOVALUE;
        if (IS_SEQUENCE(_24761) && IS_ATOM(_24765)) {
        }
        else if (IS_ATOM(_24761) && IS_SEQUENCE(_24765)) {
            Ref(_24761);
            Prepend(&_24766, _24765, _24761);
        }
        else {
            Concat((object_ptr)&_24766, _24761, _24765);
            _24761 = NOVALUE;
        }
        _24761 = NOVALUE;
        DeRefDS(_24765);
        _24765 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47841);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24766;
        if( _1 != _24766 ){
            DeRef(_1);
        }
        _24766 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24769 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24769);
        _24770 = (object)*(((s1_ptr)_2)->base + 5);
        _24769 = NOVALUE;
        Ref(_24770);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24770;
        if( _1 != _24770 ){
            DeRef(_1);
        }
        _24770 = NOVALUE;
        _24767 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24773 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24773);
        _24774 = (object)*(((s1_ptr)_2)->base + 4);
        _24773 = NOVALUE;
        Ref(_24774);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24774;
        if( _1 != _24774 ){
            DeRef(_1);
        }
        _24774 = NOVALUE;
        _24771 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24777 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24777);
        _24778 = (object)*(((s1_ptr)_2)->base + 6);
        _24777 = NOVALUE;
        Ref(_24778);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24778;
        if( _1 != _24778 ){
            DeRef(_1);
        }
        _24778 = NOVALUE;
        _24775 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
        RefDS(_22209);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22209;
        DeRef(_1);
        _24779 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24781 = (object)*(((s1_ptr)_2)->base + _k_47845);
        if (IS_SEQUENCE(_24781)){
                _24782 = SEQ_PTR(_24781)->length;
        }
        else {
            _24782 = 1;
        }
        _24781 = NOVALUE;
        if (_24782 <= 6)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24786 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24786);
        _24787 = (object)*(((s1_ptr)_2)->base + 7);
        _24786 = NOVALUE;
        Ref(_24787);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_CODE_20221))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24787;
        if( _1 != _24787 ){
            DeRef(_1);
        }
        _24787 = NOVALUE;
        _24784 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24790 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24790);
        _24791 = (object)*(((s1_ptr)_2)->base + 8);
        _24790 = NOVALUE;
        Ref(_24791);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24791;
        if( _1 != _24791 ){
            DeRef(_1);
        }
        _24791 = NOVALUE;
        _24788 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47843, _fixups_47843, _st_index_47841);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24793 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24793);
        _24794 = (object)*(((s1_ptr)_2)->base + 3);
        _24793 = NOVALUE;
        if (binary_op_a(NOTEQ, _24794, 27)){
            _24794 = NOVALUE;
            goto L5; // [341] 365
        }
        _24794 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47842 == _24796)
        _24797 = 1;
        else if (IS_ATOM_INT(_kname_47842) && IS_ATOM_INT(_24796))
        _24797 = 0;
        else
        _24797 = (compare(_kname_47842, _24796) == 0);
        if (_24797 == 0)
        {
            _24797 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24797 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _27TopLevelSub_20578 = _st_index_47841;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _24798 = (object)*(((s1_ptr)_2)->base + _k_47845);
        _2 = (object)SEQ_PTR(_24798);
        _24799 = (object)*(((s1_ptr)_2)->base + 3);
        _24798 = NOVALUE;
        if (binary_op_a(NOTEQ, _24799, 504)){
            _24799 = NOVALUE;
            goto L7; // [381] 461
        }
        _24799 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47842 == _23166)
        _24801 = 1;
        else if (IS_ATOM_INT(_kname_47842) && IS_ATOM_INT(_23166))
        _24801 = 0;
        else
        _24801 = (compare(_kname_47842, _23166) == 0);
        if (_24801 == 0)
        {
            _24801 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24801 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _53object_type_47184 = _st_index_47841;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47842 == _24802)
        _24803 = 1;
        else if (IS_ATOM_INT(_kname_47842) && IS_ATOM_INT(_24802))
        _24803 = 0;
        else
        _24803 = (compare(_kname_47842, _24802) == 0);
        if (_24803 == 0)
        {
            _24803 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24803 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _53atom_type_47186 = _st_index_47841;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47842 == _24804)
        _24805 = 1;
        else if (IS_ATOM_INT(_kname_47842) && IS_ATOM_INT(_24804))
        _24805 = 0;
        else
        _24805 = (compare(_kname_47842, _24804) == 0);
        if (_24805 == 0)
        {
            _24805 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24805 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _53integer_type_47190 = _st_index_47841;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47842 == _24806)
        _24807 = 1;
        else if (IS_ATOM_INT(_kname_47842) && IS_ATOM_INT(_24806))
        _24807 = 0;
        else
        _24807 = (compare(_kname_47842, _24806) == 0);
        if (_24807 == 0)
        {
            _24807 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24807 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _53sequence_type_47188 = _st_index_47841;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _24808 = (object)*(((s1_ptr)_2)->base + _hashval_47837);
        if (binary_op_a(NOTEQ, _24808, 0)){
            _24808 = NOVALUE;
            goto LD; // [470] 485
        }
        _24808 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47837);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47841;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _s_47840 = (object)*(((s1_ptr)_2)->base + _hashval_47837);
        if (!IS_ATOM_INT(_s_47840)){
            _s_47840 = (object)DBL_PTR(_s_47840)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24811 = (object)*(((s1_ptr)_2)->base + _s_47840);
        _2 = (object)SEQ_PTR(_24811);
        _24812 = (object)*(((s1_ptr)_2)->base + 9);
        _24811 = NOVALUE;
        if (binary_op_a(EQUALS, _24812, 0)){
            _24812 = NOVALUE;
            goto L10; // [512] 537
        }
        _24812 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24814 = (object)*(((s1_ptr)_2)->base + _s_47840);
        _2 = (object)SEQ_PTR(_24814);
        _s_47840 = (object)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_47840)){
            _s_47840 = (object)DBL_PTR(_s_47840)->dbl;
        }
        _24814 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47840 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47841;
        DeRef(_1);
        _24816 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47845 = _k_47845 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _27file_start_sym_20577 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _27file_start_sym_20577 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _27CurrentSub_20579 = _27TopLevelSub_20578;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47843)){
            _24819 = SEQ_PTR(_fixups_47843)->length;
    }
    else {
        _24819 = 1;
    }
    {
        object _i_47987;
        _i_47987 = 1;
L11: 
        if (_i_47987 > _24819){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47843);
        _24820 = (object)*(((s1_ptr)_2)->base + _i_47987);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _24821 = (object)*(((s1_ptr)_2)->base + _24820);
        DeRef(_si_47982);
        _2 = (object)SEQ_PTR(_24821);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _si_47982 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _si_47982 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        Ref(_si_47982);
        _24821 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47982)){
                _24823 = SEQ_PTR(_si_47982)->length;
        }
        else {
            _24823 = 1;
        }
        {
            object _j_47995;
            _j_47995 = 1;
L13: 
            if (_j_47995 > _24823){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47982);
            _24824 = (object)*(((s1_ptr)_2)->base + _j_47995);
            _24825 = IS_SEQUENCE(_24824);
            _24824 = NOVALUE;
            if (_24825 == 0)
            {
                _24825 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24825 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47983);
            _2 = (object)SEQ_PTR(_si_47982);
            _sj_47983 = (object)*(((s1_ptr)_2)->base + _j_47995);
            Ref(_sj_47983);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47983)){
                    _24827 = SEQ_PTR(_sj_47983)->length;
            }
            else {
                _24827 = 1;
            }
            {
                object _ij_48002;
                _ij_48002 = 1;
L16: 
                if (_ij_48002 > _24827){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47983);
                _24828 = (object)*(((s1_ptr)_2)->base + _ij_48002);
                _2 = (object)SEQ_PTR(_24828);
                _24829 = (object)*(((s1_ptr)_2)->base + 1);
                _24828 = NOVALUE;
                if (IS_SEQUENCE(_24829) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24829)){
                    if( (DBL_PTR(_24829)->dbl != (eudouble) ((object) DBL_PTR(_24829)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24829)->dbl;
                }
                else {
                    _0 = _24829;
                };
                _24829 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    _24832 = (object)*(((s1_ptr)_2)->base + _ij_48002);
                    _2 = (object)SEQ_PTR(_24832);
                    _24833 = (object)*(((s1_ptr)_2)->base + 2);
                    _24832 = NOVALUE;
                    Ref(_24833);
                    _24834 = _27is_integer(_24833);
                    _24833 = NOVALUE;
                    if (_24834 == 0) {
                        DeRef(_24834);
                        _24834 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24834) && DBL_PTR(_24834)->dbl == 0.0){
                            DeRef(_24834);
                            _24834 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24834);
                        _24834 = NOVALUE;
                    }
                    DeRef(_24834);
                    _24834 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    _24835 = (object)*(((s1_ptr)_2)->base + _ij_48002);
                    _2 = (object)SEQ_PTR(_24835);
                    _24836 = (object)*(((s1_ptr)_2)->base + 2);
                    _24835 = NOVALUE;
                    Ref(_24836);
                    _st_index_47841 = _53NewIntSym(_24836);
                    _24836 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47841)) {
                        _1 = (object)(DBL_PTR(_st_index_47841)->dbl);
                        DeRefDS(_st_index_47841);
                        _st_index_47841 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    _24838 = (object)*(((s1_ptr)_2)->base + _ij_48002);
                    _2 = (object)SEQ_PTR(_24838);
                    _24839 = (object)*(((s1_ptr)_2)->base + 2);
                    _24838 = NOVALUE;
                    Ref(_24839);
                    _st_index_47841 = _53NewDoubleSym(_24839);
                    _24839 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47841)) {
                        _1 = (object)(DBL_PTR(_st_index_47841)->dbl);
                        DeRefDS(_st_index_47841);
                        _st_index_47841 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_28SymTab_11572);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _28SymTab_11572 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24841 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47983 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_48002 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47841;
                    DeRef(_1);
                    _24843 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    _24845 = (object)*(((s1_ptr)_2)->base + _ij_48002);
                    _2 = (object)SEQ_PTR(_24845);
                    _24846 = (object)*(((s1_ptr)_2)->base + 2);
                    _24845 = NOVALUE;
                    Ref(_24846);
                    _st_index_47841 = _53NewStringSym(_24846);
                    _24846 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47841)) {
                        _1 = (object)(DBL_PTR(_st_index_47841)->dbl);
                        DeRefDS(_st_index_47841);
                        _st_index_47841 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_28SymTab_11572);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _28SymTab_11572 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47841 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1;
                    DeRef(_1);
                    _24848 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47983 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_48002 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47841;
                    DeRef(_1);
                    _24850 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    _24852 = (object)*(((s1_ptr)_2)->base + _ij_48002);
                    _2 = (object)SEQ_PTR(_24852);
                    _24853 = (object)*(((s1_ptr)_2)->base + 2);
                    _24852 = NOVALUE;
                    Ref(_24853);
                    DeRef(_25331);
                    _25331 = _24853;
                    _25332 = _53hashfn(_25331);
                    _25331 = NOVALUE;
                    Ref(_24853);
                    _24854 = _53keyfind(_24853, -1, _27current_file_no_20571, 0, _25332);
                    _24853 = NOVALUE;
                    _25332 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47983);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47983 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_48002);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24854;
                    if( _1 != _24854 ){
                        DeRef(_1);
                    }
                    _24854 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47983);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47983 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_48002 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47843);
                    _24857 = (object)*(((s1_ptr)_2)->base + _i_47987);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24858 = (object)*(((s1_ptr)_2)->base + 2);
                    _24855 = NOVALUE;
                    if (IS_SEQUENCE(_24858) && IS_ATOM(_24857)) {
                        Append(&_24859, _24858, _24857);
                    }
                    else if (IS_ATOM(_24858) && IS_SEQUENCE(_24857)) {
                    }
                    else {
                        Concat((object_ptr)&_24859, _24858, _24857);
                        _24858 = NOVALUE;
                    }
                    _24858 = NOVALUE;
                    _24857 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24859;
                    if( _1 != _24859 ){
                        DeRef(_1);
                    }
                    _24859 = NOVALUE;
                    _24855 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_48002 = _ij_48002 + 1;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47983);
            _2 = (object)SEQ_PTR(_si_47982);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47982 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47995);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47983;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47995 = _j_47995 + 1;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47843);
        _24860 = (object)*(((s1_ptr)_2)->base + _i_47987);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24860 + ((s1_ptr)_2)->base);
        RefDS(_si_47982);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27S_CODE_20221))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47982;
        DeRef(_1);
        _24861 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47987 = _i_47987 + 1;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47842);
    DeRefi(_fixups_47843);
    DeRef(_si_47982);
    DeRef(_sj_47983);
    _24781 = NOVALUE;
    _24860 = NOVALUE;
    _24820 = NOVALUE;
    _24762 = NOVALUE;
    return;
    ;
}


void _53add_ref(object _tok_48071)
{
    object _s_48073 = NOVALUE;
    object _24877 = NOVALUE;
    object _24876 = NOVALUE;
    object _24874 = NOVALUE;
    object _24873 = NOVALUE;
    object _24872 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24868 = NOVALUE;
    object _24867 = NOVALUE;
    object _24866 = NOVALUE;
    object _24865 = NOVALUE;
    object _24864 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48071);
    _s_48073 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_48073)){
        _s_48073 = (object)DBL_PTR(_s_48073)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24864 = (_s_48073 != _27CurrentSub_20579);
    if (_24864 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24866 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_24866);
    _24867 = (object)*(((s1_ptr)_2)->base + 24);
    _24866 = NOVALUE;
    _24868 = find_from(_s_48073, _24867, 1);
    _24867 = NOVALUE;
    _24869 = (_24868 == 0);
    _24868 = NOVALUE;
    if (_24869 == 0)
    {
        DeRef(_24869);
        _24869 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24869);
        _24869 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48073 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24872 = (object)*(((s1_ptr)_2)->base + 12);
    _24870 = NOVALUE;
    if (IS_ATOM_INT(_24872)) {
        _24873 = _24872 + 1;
        if (_24873 > MAXINT){
            _24873 = NewDouble((eudouble)_24873);
        }
    }
    else
    _24873 = binary_op(PLUS, 1, _24872);
    _24872 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24873;
    if( _1 != _24873 ){
        DeRef(_1);
    }
    _24873 = NOVALUE;
    _24870 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24876 = (object)*(((s1_ptr)_2)->base + 24);
    _24874 = NOVALUE;
    if (IS_SEQUENCE(_24876) && IS_ATOM(_s_48073)) {
        Append(&_24877, _24876, _s_48073);
    }
    else if (IS_ATOM(_24876) && IS_SEQUENCE(_s_48073)) {
    }
    else {
        Concat((object_ptr)&_24877, _24876, _s_48073);
        _24876 = NOVALUE;
    }
    _24876 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24877;
    if( _1 != _24877 ){
        DeRef(_1);
    }
    _24877 = NOVALUE;
    _24874 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_48071);
    DeRef(_24864);
    _24864 = NOVALUE;
    return;
    ;
}


void _53mark_all(object _attribute_48103)
{
    object _p_48106 = NOVALUE;
    object _sym_file_48113 = NOVALUE;
    object _scope_48130 = NOVALUE;
    object _24909 = NOVALUE;
    object _24908 = NOVALUE;
    object _24907 = NOVALUE;
    object _24905 = NOVALUE;
    object _24903 = NOVALUE;
    object _24902 = NOVALUE;
    object _24901 = NOVALUE;
    object _24900 = NOVALUE;
    object _24899 = NOVALUE;
    object _24897 = NOVALUE;
    object _24896 = NOVALUE;
    object _24895 = NOVALUE;
    object _24894 = NOVALUE;
    object _24890 = NOVALUE;
    object _24889 = NOVALUE;
    object _24888 = NOVALUE;
    object _24886 = NOVALUE;
    object _24885 = NOVALUE;
    object _24883 = NOVALUE;
    object _24881 = NOVALUE;
    object _24878 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_48100 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24878 = (object)*(((s1_ptr)_2)->base + _53just_mark_everything_from_48100);
    _2 = (object)SEQ_PTR(_24878);
    _p_48106 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_48106)){
        _p_48106 = (object)DBL_PTR(_p_48106)->dbl;
    }
    _24878 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_48106 == 0)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24881 = (object)*(((s1_ptr)_2)->base + _p_48106);
    _2 = (object)SEQ_PTR(_24881);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _sym_file_48113 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _sym_file_48113 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_sym_file_48113)){
        _sym_file_48113 = (object)DBL_PTR(_sym_file_48113)->dbl;
    }
    _24881 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _53just_mark_everything_from_48100 = _p_48106;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24883 = (_sym_file_48113 == _27current_file_no_20571);
    if (_24883 != 0) {
        goto L4; // [68] 84
    }
    Ref(_53recheck_routines_48173);
    _24885 = _34has(_53recheck_routines_48173, _sym_file_48113);
    if (_24885 == 0) {
        DeRef(_24885);
        _24885 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24885) && DBL_PTR(_24885)->dbl == 0.0){
            DeRef(_24885);
            _24885 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24885);
        _24885 = NOVALUE;
    }
    DeRef(_24885);
    _24885 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_48106 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24888 = (object)*(((s1_ptr)_2)->base + _attribute_48103);
    _24886 = NOVALUE;
    if (IS_ATOM_INT(_24888)) {
        _24889 = _24888 + 1;
        if (_24889 > MAXINT){
            _24889 = NewDouble((eudouble)_24889);
        }
    }
    else
    _24889 = binary_op(PLUS, 1, _24888);
    _24888 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48103);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24889;
    if( _1 != _24889 ){
        DeRef(_1);
    }
    _24889 = NOVALUE;
    _24886 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24890 = (object)*(((s1_ptr)_2)->base + _p_48106);
    _2 = (object)SEQ_PTR(_24890);
    _scope_48130 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48130)){
        _scope_48130 = (object)DBL_PTR(_scope_48130)->dbl;
    }
    _24890 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_48130;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _24894 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
        _2 = (object)SEQ_PTR(_24894);
        _24895 = (object)*(((s1_ptr)_2)->base + _sym_file_48113);
        _24894 = NOVALUE;
        if (IS_ATOM_INT(_24895)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_24895;
                 _24896 = MAKE_UINT(tu);
            }
        }
        else {
            _24896 = binary_op(AND_BITS, 6, _24895);
        }
        _24895 = NOVALUE;
        if (_24896 == 0) {
            DeRef(_24896);
            _24896 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24896) && DBL_PTR(_24896)->dbl == 0.0){
                DeRef(_24896);
                _24896 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24896);
            _24896 = NOVALUE;
        }
        DeRef(_24896);
        _24896 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48106 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24899 = (object)*(((s1_ptr)_2)->base + _attribute_48103);
        _24897 = NOVALUE;
        if (IS_ATOM_INT(_24899)) {
            _24900 = _24899 + 1;
            if (_24900 > MAXINT){
                _24900 = NewDouble((eudouble)_24900);
            }
        }
        else
        _24900 = binary_op(PLUS, 1, _24899);
        _24899 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48103);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24900;
        if( _1 != _24900 ){
            DeRef(_1);
        }
        _24900 = NOVALUE;
        _24897 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _24901 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
        _2 = (object)SEQ_PTR(_24901);
        _24902 = (object)*(((s1_ptr)_2)->base + _sym_file_48113);
        _24901 = NOVALUE;
        if (IS_ATOM_INT(_24902)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_24902;
                 _24903 = MAKE_UINT(tu);
            }
        }
        else {
            _24903 = binary_op(AND_BITS, 2, _24902);
        }
        _24902 = NOVALUE;
        if (IS_ATOM_INT(_24903)) {
            if (_24903 != 0){
                DeRef(_24903);
                _24903 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24903)->dbl != 0.0){
                DeRef(_24903);
                _24903 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24903);
        _24903 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48106 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24907 = (object)*(((s1_ptr)_2)->base + _attribute_48103);
        _24905 = NOVALUE;
        if (IS_ATOM_INT(_24907)) {
            _24908 = _24907 + 1;
            if (_24908 > MAXINT){
                _24908 = NewDouble((eudouble)_24908);
            }
        }
        else
        _24908 = binary_op(PLUS, 1, _24907);
        _24907 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48103);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24908;
        if( _1 != _24908 ){
            DeRef(_1);
        }
        _24908 = NOVALUE;
        _24905 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24909 = (object)*(((s1_ptr)_2)->base + _p_48106);
    _2 = (object)SEQ_PTR(_24909);
    _p_48106 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_48106)){
        _p_48106 = (object)DBL_PTR(_p_48106)->dbl;
    }
    _24909 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24883);
    _24883 = NOVALUE;
    return;
    ;
}


void _53mark_rechecks(object _file_no_48179)
{
    object _recheck_targets_48182 = NOVALUE;
    object _remaining_48186 = NOVALUE;
    object _marked_48190 = NOVALUE;
    object _24916 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_48179)) {
        _1 = (object)(DBL_PTR(_file_no_48179)->dbl);
        DeRefDS(_file_no_48179);
        _file_no_48179 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_53recheck_routines_48173);
    RefDS(_22209);
    _0 = _recheck_targets_48182;
    _recheck_targets_48182 = _34get(_53recheck_routines_48173, _file_no_48179, _22209);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_48182)){
            _24912 = SEQ_PTR(_recheck_targets_48182)->length;
    }
    else {
        _24912 = 1;
    }
    if (_24912 == 0)
    {
        _24912 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24912 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_22209);
    DeRefi(_remaining_48186);
    _remaining_48186 = _22209;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_48182)){
            _24913 = SEQ_PTR(_recheck_targets_48182)->length;
    }
    else {
        _24913 = 1;
    }
    {
        object _i_48188;
        _i_48188 = _24913;
L2: 
        if (_i_48188 < 1){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_48190 = 0;

        /** symtab.e:589				if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48182);
        _24914 = (object)*(((s1_ptr)_2)->base + _i_48188);
        Ref(_24914);
        _marked_48190 = _53MarkTargets(_24914, 53);
        _24914 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48190)) {
            _1 = (object)(DBL_PTR(_marked_48190)->dbl);
            DeRefDS(_marked_48190);
            _marked_48190 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48182);
        _24916 = (object)*(((s1_ptr)_2)->base + _i_48188);
        Ref(_24916);
        _marked_48190 = _53MarkTargets(_24916, 12);
        _24916 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48190)) {
            _1 = (object)(DBL_PTR(_marked_48190)->dbl);
            DeRefDS(_marked_48190);
            _marked_48190 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_48190 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_48186, _remaining_48186, _file_no_48179);
L7: 

        /** symtab.e:597			end for*/
        _i_48188 = _i_48188 + -1;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_53recheck_routines_48173);
    RefDS(_recheck_targets_48182);
    _34put(_53recheck_routines_48173, _file_no_48179, _recheck_targets_48182, 1, 0);
L1: 
    DeRefi(_remaining_48186);
    _remaining_48186 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_48182);
    return;
    ;
}


void _53mark_final_targets()
{
    object _size_1__tmp_at47_48218 = NOVALUE;
    object _size_inlined_size_at_47_48217 = NOVALUE;
    object _recheck_files_48219 = NOVALUE;
    object _24922 = NOVALUE;
    object _24921 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_53just_mark_everything_from_48100 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _53mark_all(53);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _53mark_all(12);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_48218);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_53recheck_routines_48173)){
        _size_1__tmp_at47_48218 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_53recheck_routines_48173)->dbl));
    }
    else{
        _size_1__tmp_at47_48218 = (object)*(((s1_ptr)_2)->base + _53recheck_routines_48173);
    }
    Ref(_size_1__tmp_at47_48218);
    DeRef(_size_inlined_size_at_47_48217);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_48218);
    _size_inlined_size_at_47_48217 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_size_inlined_size_at_47_48217);
    DeRef(_size_1__tmp_at47_48218);
    _size_1__tmp_at47_48218 = NOVALUE;
    if (_size_inlined_size_at_47_48217 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_48217) && DBL_PTR(_size_inlined_size_at_47_48217)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_53recheck_routines_48173);
    _0 = _recheck_files_48219;
    _recheck_files_48219 = _34keys(_53recheck_routines_48173, 0);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_48219)){
            _24921 = SEQ_PTR(_recheck_files_48219)->length;
    }
    else {
        _24921 = 1;
    }
    {
        object _i_48222;
        _i_48222 = 1;
L5: 
        if (_i_48222 > _24921){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_48219);
        _24922 = (object)*(((s1_ptr)_2)->base + _i_48222);
        Ref(_24922);
        _53mark_rechecks(_24922);
        _24922 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_48222 = _i_48222 + 1;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_48219);
    _recheck_files_48219 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _53is_routine(object _sym_48228)
{
    object _tok_48229 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_48229 = _53sym_token(_sym_48228);
    if (!IS_ATOM_INT(_tok_48229)) {
        _1 = (object)(DBL_PTR(_tok_48229)->dbl);
        DeRefDS(_tok_48229);
        _tok_48229 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_48229;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0;
    ;}L1: 
    ;
}


object _53is_visible(object _sym_48242, object _from_file_48243)
{
    object _scope_48244 = NOVALUE;
    object _sym_file_48247 = NOVALUE;
    object _visible_mask_48252 = NOVALUE;
    object _24934 = NOVALUE;
    object _24933 = NOVALUE;
    object _24932 = NOVALUE;
    object _24931 = NOVALUE;
    object _24927 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_48244 = _53sym_scope(_sym_48242);
    if (!IS_ATOM_INT(_scope_48244)) {
        _1 = (object)(DBL_PTR(_scope_48244)->dbl);
        DeRefDS(_scope_48244);
        _scope_48244 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24927 = (object)*(((s1_ptr)_2)->base + _sym_48242);
    _2 = (object)SEQ_PTR(_24927);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _sym_file_48247 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _sym_file_48247 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_sym_file_48247)){
        _sym_file_48247 = (object)DBL_PTR(_sym_file_48247)->dbl;
    }
    _24927 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_48244;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_48252 = 6;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_48252 = 2;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24931 = (_from_file_48243 == _sym_file_48247);
        return _24931;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _24932 = (object)*(((s1_ptr)_2)->base + _from_file_48243);
    _2 = (object)SEQ_PTR(_24932);
    _24933 = (object)*(((s1_ptr)_2)->base + _sym_file_48247);
    _24932 = NOVALUE;
    if (IS_ATOM_INT(_24933)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_48252 & (uintptr_t)_24933;
             _24934 = MAKE_UINT(tu);
        }
    }
    else {
        _24934 = binary_op(AND_BITS, _visible_mask_48252, _24933);
    }
    _24933 = NOVALUE;
    DeRef(_24931);
    _24931 = NOVALUE;
    return _24934;
    ;
}


object _53MarkTargets(object _s_48272, object _attribute_48273)
{
    object _p_48275 = NOVALUE;
    object _sname_48276 = NOVALUE;
    object _string_48277 = NOVALUE;
    object _colon_48278 = NOVALUE;
    object _h_48279 = NOVALUE;
    object _scope_48280 = NOVALUE;
    object _found_48301 = NOVALUE;
    object _24982 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24975 = NOVALUE;
    object _24974 = NOVALUE;
    object _24973 = NOVALUE;
    object _24972 = NOVALUE;
    object _24971 = NOVALUE;
    object _24969 = NOVALUE;
    object _24968 = NOVALUE;
    object _24967 = NOVALUE;
    object _24965 = NOVALUE;
    object _24963 = NOVALUE;
    object _24961 = NOVALUE;
    object _24960 = NOVALUE;
    object _24959 = NOVALUE;
    object _24958 = NOVALUE;
    object _24956 = NOVALUE;
    object _24955 = NOVALUE;
    object _24954 = NOVALUE;
    object _24953 = NOVALUE;
    object _24951 = NOVALUE;
    object _24950 = NOVALUE;
    object _24946 = NOVALUE;
    object _24945 = NOVALUE;
    object _24944 = NOVALUE;
    object _24943 = NOVALUE;
    object _24942 = NOVALUE;
    object _24941 = NOVALUE;
    object _24940 = NOVALUE;
    object _24939 = NOVALUE;
    object _24938 = NOVALUE;
    object _24937 = NOVALUE;
    object _24936 = NOVALUE;
    object _24935 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48272)) {
        _1 = (object)(DBL_PTR(_s_48272)->dbl);
        DeRefDS(_s_48272);
        _s_48272 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24935 = (object)*(((s1_ptr)_2)->base + _s_48272);
    _2 = (object)SEQ_PTR(_24935);
    _24936 = (object)*(((s1_ptr)_2)->base + 3);
    _24935 = NOVALUE;
    if (IS_ATOM_INT(_24936)) {
        _24937 = (_24936 == 3);
    }
    else {
        _24937 = binary_op(EQUALS, _24936, 3);
    }
    _24936 = NOVALUE;
    if (IS_ATOM_INT(_24937)) {
        if (_24937 != 0) {
            _24938 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24937)->dbl != 0.0) {
            _24938 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24939 = (object)*(((s1_ptr)_2)->base + _s_48272);
    _2 = (object)SEQ_PTR(_24939);
    _24940 = (object)*(((s1_ptr)_2)->base + 3);
    _24939 = NOVALUE;
    if (IS_ATOM_INT(_24940)) {
        _24941 = (_24940 == 2);
    }
    else {
        _24941 = binary_op(EQUALS, _24940, 2);
    }
    _24940 = NOVALUE;
    DeRef(_24938);
    if (IS_ATOM_INT(_24941))
    _24938 = (_24941 != 0);
    else
    _24938 = DBL_PTR(_24941)->dbl != 0.0;
L1: 
    if (_24938 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24943 = (object)*(((s1_ptr)_2)->base + _s_48272);
    _2 = (object)SEQ_PTR(_24943);
    _24944 = (object)*(((s1_ptr)_2)->base + 1);
    _24943 = NOVALUE;
    _24945 = IS_SEQUENCE(_24944);
    _24944 = NOVALUE;
    if (_24945 == 0)
    {
        _24945 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24945 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_48301 = 0;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24946 = (object)*(((s1_ptr)_2)->base + _s_48272);
    DeRef(_string_48277);
    _2 = (object)SEQ_PTR(_24946);
    _string_48277 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_string_48277);
    _24946 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_48278 = find_from(58, _string_48277, 1);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_48278 != 0)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_48277);
    DeRef(_sname_48276);
    _sname_48276 = _string_48277;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24950 = _colon_48278 + 1;
    if (_24950 > MAXINT){
        _24950 = NewDouble((eudouble)_24950);
    }
    if (IS_SEQUENCE(_string_48277)){
            _24951 = SEQ_PTR(_string_48277)->length;
    }
    else {
        _24951 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_48276;
    RHS_Slice(_string_48277, _24950, _24951);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_48276)){
            _24953 = SEQ_PTR(_sname_48276)->length;
    }
    else {
        _24953 = 1;
    }
    if (_24953 == 0) {
        _24954 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_48276);
    _24955 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24955)) {
        _24956 = (_24955 == 32);
    }
    else {
        _24956 = binary_op(EQUALS, _24955, 32);
    }
    _24955 = NOVALUE;
    if (IS_ATOM_INT(_24956))
    _24954 = (_24956 != 0);
    else
    _24954 = DBL_PTR(_24956)->dbl != 0.0;
L6: 
    if (_24954 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_48276);
    _24958 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24958)) {
        _24959 = (_24958 == 9);
    }
    else {
        _24959 = binary_op(EQUALS, _24958, 9);
    }
    _24958 = NOVALUE;
    if (_24959 <= 0) {
        if (_24959 == 0) {
            DeRef(_24959);
            _24959 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24959) && DBL_PTR(_24959)->dbl == 0.0){
                DeRef(_24959);
                _24959 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24959);
            _24959 = NOVALUE;
        }
    }
    DeRef(_24959);
    _24959 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_48276)){
            _24960 = SEQ_PTR(_sname_48276)->length;
    }
    else {
        _24960 = 1;
    }
    _24961 = _24960 - 1;
    _24960 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_48276)->length;
        int size = (IS_ATOM_INT(_24961)) ? _24961 : (object)(DBL_PTR(_24961)->dbl);
        if (size <= 0) {
            DeRef(_sname_48276);
            _sname_48276 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_48276);
            DeRef(_sname_48276);
            _sname_48276 = _sname_48276;
        }
        else Tail(SEQ_PTR(_sname_48276), len-size+1, &_sname_48276);
    }
    _24961 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_48276)){
            _24963 = SEQ_PTR(_sname_48276)->length;
    }
    else {
        _24963 = 1;
    }
    if (_24963 != 0)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_48276);
    DeRef(_string_48277);
    DeRef(_24937);
    _24937 = NOVALUE;
    DeRef(_24950);
    _24950 = NOVALUE;
    DeRef(_24941);
    _24941 = NOVALUE;
    DeRef(_24956);
    _24956 = NOVALUE;
    return 1;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_48276);
    _24965 = _53hashfn(_sname_48276);
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_24965)){
        _h_48279 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24965)->dbl));
    }
    else{
        _h_48279 = (object)*(((s1_ptr)_2)->base + _24965);
    }
    if (!IS_ATOM_INT(_h_48279))
    _h_48279 = (object)DBL_PTR(_h_48279)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_48279 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24967 = (object)*(((s1_ptr)_2)->base + _h_48279);
    _2 = (object)SEQ_PTR(_24967);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24968 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24968 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24967 = NOVALUE;
    if (_sname_48276 == _24968)
    _24969 = 1;
    else if (IS_ATOM_INT(_sname_48276) && IS_ATOM_INT(_24968))
    _24969 = 0;
    else
    _24969 = (compare(_sname_48276, _24968) == 0);
    _24968 = NOVALUE;
    if (_24969 == 0)
    {
        _24969 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24969 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_48273 != 12)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27;
    ((intptr_t *)_2)[2] = _h_48279;
    _24971 = MAKE_SEQ(_1);
    _53add_ref(_24971);
    _24971 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24972 = _53is_routine(_h_48279);
    if (IS_ATOM_INT(_24972)) {
        if (_24972 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24972)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24974 = _53is_visible(_h_48279, _27current_file_no_20571);
    if (_24974 == 0) {
        DeRef(_24974);
        _24974 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24974) && DBL_PTR(_24974)->dbl == 0.0){
            DeRef(_24974);
            _24974 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24974);
        _24974 = NOVALUE;
    }
    DeRef(_24974);
    _24974 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_48279 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24977 = (object)*(((s1_ptr)_2)->base + _attribute_48273);
    _24975 = NOVALUE;
    if (IS_ATOM_INT(_24977)) {
        _24978 = _24977 + 1;
        if (_24978 > MAXINT){
            _24978 = NewDouble((eudouble)_24978);
        }
    }
    else
    _24978 = binary_op(PLUS, 1, _24977);
    _24977 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48273);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24978;
    if( _1 != _24978 ){
        DeRef(_1);
    }
    _24978 = NOVALUE;
    _24975 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24979 = (object)*(((s1_ptr)_2)->base + _h_48279);
    _2 = (object)SEQ_PTR(_24979);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _24980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _24980 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _24979 = NOVALUE;
    if (binary_op_a(NOTEQ, _27current_file_no_20571, _24980)){
        _24980 = NOVALUE;
        goto L10; // [347] 357
    }
    _24980 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_48301 = 1;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24982 = (object)*(((s1_ptr)_2)->base + _h_48279);
    _2 = (object)SEQ_PTR(_24982);
    _h_48279 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_48279)){
        _h_48279 = (object)DBL_PTR(_h_48279)->dbl;
    }
    _24982 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_48301 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_53recheck_routines_48173);
    _34put(_53recheck_routines_48173, _27current_file_no_20571, _s_48272, 6, 0);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_48276);
    DeRef(_string_48277);
    DeRef(_24965);
    _24965 = NOVALUE;
    DeRef(_24937);
    _24937 = NOVALUE;
    DeRef(_24950);
    _24950 = NOVALUE;
    DeRef(_24941);
    _24941 = NOVALUE;
    DeRef(_24956);
    _24956 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    return _found_48301;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_53just_mark_everything_from_48100 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_48100 = _27TopLevelSub_20578;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _53mark_all(_attribute_48273);

    /** symtab.e:700			return 1*/
    DeRef(_sname_48276);
    DeRef(_string_48277);
    DeRef(_24965);
    _24965 = NOVALUE;
    DeRef(_24937);
    _24937 = NOVALUE;
    DeRef(_24950);
    _24950 = NOVALUE;
    DeRef(_24941);
    _24941 = NOVALUE;
    DeRef(_24956);
    _24956 = NOVALUE;
    DeRef(_24972);
    _24972 = NOVALUE;
    return 1;
L12: 
    ;
}


void _53resolve_unincluded_globals(object _ok_48379)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _53Resolve_unincluded_globals_48376 = 1;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _53get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _53Resolve_unincluded_globals_48376;
    ;
}


object _53keyfind(object _word_48385, object _file_no_48386, object _scanning_file_48387, object _namespace_ok_48390, object _hashval_48391)
{
    object _msg_48393 = NOVALUE;
    object _b_name_48394 = NOVALUE;
    object _scope_48395 = NOVALUE;
    object _defined_48396 = NOVALUE;
    object _ix_48397 = NOVALUE;
    object _st_ptr_48399 = NOVALUE;
    object _st_builtin_48400 = NOVALUE;
    object _tok_48402 = NOVALUE;
    object _gtok_48403 = NOVALUE;
    object _any_symbol_48406 = NOVALUE;
    object _tok_file_48574 = NOVALUE;
    object _good_48581 = NOVALUE;
    object _include_type_48591 = NOVALUE;
    object _msg_file_48647 = NOVALUE;
    object _25177 = NOVALUE;
    object _25176 = NOVALUE;
    object _25174 = NOVALUE;
    object _25172 = NOVALUE;
    object _25171 = NOVALUE;
    object _25170 = NOVALUE;
    object _25169 = NOVALUE;
    object _25168 = NOVALUE;
    object _25166 = NOVALUE;
    object _25164 = NOVALUE;
    object _25163 = NOVALUE;
    object _25162 = NOVALUE;
    object _25161 = NOVALUE;
    object _25160 = NOVALUE;
    object _25159 = NOVALUE;
    object _25158 = NOVALUE;
    object _25157 = NOVALUE;
    object _25155 = NOVALUE;
    object _25154 = NOVALUE;
    object _25153 = NOVALUE;
    object _25152 = NOVALUE;
    object _25151 = NOVALUE;
    object _25150 = NOVALUE;
    object _25149 = NOVALUE;
    object _25148 = NOVALUE;
    object _25147 = NOVALUE;
    object _25146 = NOVALUE;
    object _25145 = NOVALUE;
    object _25144 = NOVALUE;
    object _25143 = NOVALUE;
    object _25142 = NOVALUE;
    object _25141 = NOVALUE;
    object _25140 = NOVALUE;
    object _25139 = NOVALUE;
    object _25137 = NOVALUE;
    object _25136 = NOVALUE;
    object _25133 = NOVALUE;
    object _25129 = NOVALUE;
    object _25127 = NOVALUE;
    object _25126 = NOVALUE;
    object _25125 = NOVALUE;
    object _25124 = NOVALUE;
    object _25123 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _25119 = NOVALUE;
    object _25118 = NOVALUE;
    object _25116 = NOVALUE;
    object _25113 = NOVALUE;
    object _25112 = NOVALUE;
    object _25111 = NOVALUE;
    object _25110 = NOVALUE;
    object _25108 = NOVALUE;
    object _25105 = NOVALUE;
    object _25104 = NOVALUE;
    object _25103 = NOVALUE;
    object _25102 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _25099 = NOVALUE;
    object _25096 = NOVALUE;
    object _25095 = NOVALUE;
    object _25093 = NOVALUE;
    object _25091 = NOVALUE;
    object _25089 = NOVALUE;
    object _25088 = NOVALUE;
    object _25087 = NOVALUE;
    object _25083 = NOVALUE;
    object _25082 = NOVALUE;
    object _25077 = NOVALUE;
    object _25075 = NOVALUE;
    object _25073 = NOVALUE;
    object _25072 = NOVALUE;
    object _25068 = NOVALUE;
    object _25067 = NOVALUE;
    object _25065 = NOVALUE;
    object _25064 = NOVALUE;
    object _25062 = NOVALUE;
    object _25061 = NOVALUE;
    object _25060 = NOVALUE;
    object _25059 = NOVALUE;
    object _25058 = NOVALUE;
    object _25056 = NOVALUE;
    object _25055 = NOVALUE;
    object _25054 = NOVALUE;
    object _25053 = NOVALUE;
    object _25052 = NOVALUE;
    object _25051 = NOVALUE;
    object _25050 = NOVALUE;
    object _25049 = NOVALUE;
    object _25048 = NOVALUE;
    object _25047 = NOVALUE;
    object _25046 = NOVALUE;
    object _25045 = NOVALUE;
    object _25044 = NOVALUE;
    object _25043 = NOVALUE;
    object _25042 = NOVALUE;
    object _25041 = NOVALUE;
    object _25040 = NOVALUE;
    object _25039 = NOVALUE;
    object _25038 = NOVALUE;
    object _25037 = NOVALUE;
    object _25036 = NOVALUE;
    object _25035 = NOVALUE;
    object _25033 = NOVALUE;
    object _25032 = NOVALUE;
    object _25030 = NOVALUE;
    object _25029 = NOVALUE;
    object _25028 = NOVALUE;
    object _25027 = NOVALUE;
    object _25026 = NOVALUE;
    object _25024 = NOVALUE;
    object _25023 = NOVALUE;
    object _25022 = NOVALUE;
    object _25020 = NOVALUE;
    object _25019 = NOVALUE;
    object _25018 = NOVALUE;
    object _25017 = NOVALUE;
    object _25016 = NOVALUE;
    object _25015 = NOVALUE;
    object _25014 = NOVALUE;
    object _25012 = NOVALUE;
    object _25011 = NOVALUE;
    object _25006 = NOVALUE;
    object _25003 = NOVALUE;
    object _25002 = NOVALUE;
    object _25001 = NOVALUE;
    object _25000 = NOVALUE;
    object _24999 = NOVALUE;
    object _24998 = NOVALUE;
    object _24997 = NOVALUE;
    object _24996 = NOVALUE;
    object _24995 = NOVALUE;
    object _24994 = NOVALUE;
    object _24993 = NOVALUE;
    object _24992 = NOVALUE;
    object _24991 = NOVALUE;
    object _24990 = NOVALUE;
    object _24989 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_48386)) {
        _1 = (object)(DBL_PTR(_file_no_48386)->dbl);
        DeRefDS(_file_no_48386);
        _file_no_48386 = _1;
    }
    if (!IS_ATOM_INT(_hashval_48391)) {
        _1 = (object)(DBL_PTR(_hashval_48391)->dbl);
        DeRefDS(_hashval_48391);
        _hashval_48391 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_22209);
    DeRef(_53dup_globals_48371);
    _53dup_globals_48371 = _22209;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_22209);
    DeRefi(_53dup_overrides_48372);
    _53dup_overrides_48372 = _22209;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_22209);
    DeRef(_53in_include_path_48373);
    _53in_include_path_48373 = _22209;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_22209);
    DeRef(_27symbol_resolution_warning_20673);
    _27symbol_resolution_warning_20673 = _22209;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_48400 = 0;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _st_ptr_48399 = (object)*(((s1_ptr)_2)->base + _hashval_48391);
    if (!IS_ATOM_INT(_st_ptr_48399)){
        _st_ptr_48399 = (object)DBL_PTR(_st_ptr_48399)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48406 = (_namespace_ok_48390 == -1);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_48399 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24989 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_24989);
    _24990 = (object)*(((s1_ptr)_2)->base + 4);
    _24989 = NOVALUE;
    if (IS_ATOM_INT(_24990)) {
        _24991 = (_24990 != 9);
    }
    else {
        _24991 = binary_op(NOTEQ, _24990, 9);
    }
    _24990 = NOVALUE;
    if (IS_ATOM_INT(_24991)) {
        if (_24991 == 0) {
            DeRef(_24992);
            _24992 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24991)->dbl == 0.0) {
            DeRef(_24992);
            _24992 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24993 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_24993);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24994 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24994 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24993 = NOVALUE;
    if (_word_48385 == _24994)
    _24995 = 1;
    else if (IS_ATOM_INT(_word_48385) && IS_ATOM_INT(_24994))
    _24995 = 0;
    else
    _24995 = (compare(_word_48385, _24994) == 0);
    _24994 = NOVALUE;
    DeRef(_24992);
    _24992 = (_24995 != 0);
L3: 
    if (_24992 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48406 != 0) {
        DeRef(_24997);
        _24997 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24998 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_24998);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _24999 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _24999 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _24998 = NOVALUE;
    if (IS_ATOM_INT(_24999)) {
        _25000 = (_24999 == 523);
    }
    else {
        _25000 = binary_op(EQUALS, _24999, 523);
    }
    _24999 = NOVALUE;
    if (IS_ATOM_INT(_25000)) {
        _25001 = (_namespace_ok_48390 == _25000);
    }
    else {
        _25001 = binary_op(EQUALS, _namespace_ok_48390, _25000);
    }
    DeRef(_25000);
    _25000 = NOVALUE;
    if (IS_ATOM_INT(_25001))
    _24997 = (_25001 != 0);
    else
    _24997 = DBL_PTR(_25001)->dbl != 0.0;
L5: 
    if (_24997 == 0)
    {
        _24997 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24997 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25002 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_25002);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25003 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25003 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25002 = NOVALUE;
    Ref(_25003);
    DeRef(_tok_48402);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25003;
    ((intptr_t *)_2)[2] = _st_ptr_48399;
    _tok_48402 = MAKE_SEQ(_1);
    _25003 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_48386 != -1)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25006 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_25006);
    _scope_48395 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48395)){
        _scope_48395 = (object)DBL_PTR(_scope_48395)->dbl;
    }
    _25006 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_48395;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_53dup_overrides_48372, _53dup_overrides_48372, _st_ptr_48399);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_48400 = _st_ptr_48399;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25011 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25011);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25012 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25012 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25011 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48387, _25012)){
            _25012 = NOVALUE;
            goto L8; // [250] 274
        }
        _25012 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_48402);
        _53add_ref(_tok_48402);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_48385);
        DeRef(_msg_48393);
        DeRef(_b_name_48394);
        DeRef(_gtok_48403);
        DeRef(_25001);
        _25001 = NOVALUE;
        DeRef(_24991);
        _24991 = NOVALUE;
        return _tok_48402;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_53Resolve_unincluded_globals_48376 != 0) {
            _25014 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        _25015 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        if (_25015 == 0) {
            _25016 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25017 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25018 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25018);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25019 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25019 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25018 = NOVALUE;
        _2 = (object)SEQ_PTR(_25017);
        if (!IS_ATOM_INT(_25019)){
            _25020 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25019)->dbl));
        }
        else{
            _25020 = (object)*(((s1_ptr)_2)->base + _25019);
        }
        _25017 = NOVALUE;
        if (IS_ATOM_INT(_25020))
        _25016 = (_25020 != 0);
        else
        _25016 = DBL_PTR(_25020)->dbl != 0.0;
LB: 
        _25014 = (_25016 != 0);
LA: 
        if (_25014 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25022 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25022);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _25023 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _25023 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _25022 = NOVALUE;
        if (IS_ATOM_INT(_25023)) {
            _25024 = (_25023 == 523);
        }
        else {
            _25024 = binary_op(EQUALS, _25023, 523);
        }
        _25023 = NOVALUE;
        if (_25024 == 0) {
            DeRef(_25024);
            _25024 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_25024) && DBL_PTR(_25024)->dbl == 0.0){
                DeRef(_25024);
                _25024 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_25024);
            _25024 = NOVALUE;
        }
        DeRef(_25024);
        _25024 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_48402);
        DeRef(_gtok_48403);
        _gtok_48403 = _tok_48402;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_53dup_globals_48371, _53dup_globals_48371, _st_ptr_48399);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25026 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25027 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25027);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25028 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25028 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25027 = NOVALUE;
        _2 = (object)SEQ_PTR(_25026);
        if (!IS_ATOM_INT(_25028)){
            _25029 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25028)->dbl));
        }
        else{
            _25029 = (object)*(((s1_ptr)_2)->base + _25028);
        }
        _25026 = NOVALUE;
        if (IS_ATOM_INT(_25029)) {
            _25030 = (_25029 != 0);
        }
        else {
            _25030 = binary_op(NOTEQ, _25029, 0);
        }
        _25029 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_48373) && IS_ATOM(_25030)) {
            Ref(_25030);
            Append(&_53in_include_path_48373, _53in_include_path_48373, _25030);
        }
        else if (IS_ATOM(_53in_include_path_48373) && IS_SEQUENCE(_25030)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_48373, _53in_include_path_48373, _25030);
        }
        DeRef(_25030);
        _25030 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25032 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25032);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25033 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25033 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25032 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48387, _25033)){
            _25033 = NOVALUE;
            goto LD; // [421] 445
        }
        _25033 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_48402);
        _53add_ref(_tok_48402);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_48385);
        DeRef(_msg_48393);
        DeRef(_b_name_48394);
        DeRef(_gtok_48403);
        DeRef(_25001);
        _25001 = NOVALUE;
        _25020 = NOVALUE;
        _25028 = NOVALUE;
        _25015 = NOVALUE;
        _25019 = NOVALUE;
        DeRef(_24991);
        _24991 = NOVALUE;
        return _tok_48402;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        _25035 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        if (_25035 != 0) {
            _25036 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_48390 == 0) {
            _25037 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25038 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25038);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _25039 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _25039 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _25038 = NOVALUE;
        if (IS_ATOM_INT(_25039)) {
            _25040 = (_25039 == 523);
        }
        else {
            _25040 = binary_op(EQUALS, _25039, 523);
        }
        _25039 = NOVALUE;
        if (IS_ATOM_INT(_25040))
        _25037 = (_25040 != 0);
        else
        _25037 = DBL_PTR(_25040)->dbl != 0.0;
L10: 
        _25036 = (_25037 != 0);
LF: 
        if (_25036 == 0) {
            goto L7; // [487] 1011
        }
        _25042 = (_scope_48395 == 13);
        if (_25042 == 0) {
            _25043 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25044 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25045 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25045);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25046 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25046 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25045 = NOVALUE;
        _2 = (object)SEQ_PTR(_25044);
        if (!IS_ATOM_INT(_25046)){
            _25047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25046)->dbl));
        }
        else{
            _25047 = (object)*(((s1_ptr)_2)->base + _25046);
        }
        _25044 = NOVALUE;
        if (IS_ATOM_INT(_25047)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6 & (uintptr_t)_25047;
                 _25048 = MAKE_UINT(tu);
            }
        }
        else {
            _25048 = binary_op(AND_BITS, 6, _25047);
        }
        _25047 = NOVALUE;
        if (IS_ATOM_INT(_25048))
        _25043 = (_25048 != 0);
        else
        _25043 = DBL_PTR(_25048)->dbl != 0.0;
L11: 
        if (_25043 != 0) {
            DeRef(_25049);
            _25049 = 1;
            goto L12; // [533] 583
        }
        _25050 = (_scope_48395 == 11);
        if (_25050 == 0) {
            _25051 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25052 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25053 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25053);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25054 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25054 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25053 = NOVALUE;
        _2 = (object)SEQ_PTR(_25052);
        if (!IS_ATOM_INT(_25054)){
            _25055 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25054)->dbl));
        }
        else{
            _25055 = (object)*(((s1_ptr)_2)->base + _25054);
        }
        _25052 = NOVALUE;
        if (IS_ATOM_INT(_25055)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 & (uintptr_t)_25055;
                 _25056 = MAKE_UINT(tu);
            }
        }
        else {
            _25056 = binary_op(AND_BITS, 2, _25055);
        }
        _25055 = NOVALUE;
        if (IS_ATOM_INT(_25056))
        _25051 = (_25056 != 0);
        else
        _25051 = DBL_PTR(_25056)->dbl != 0.0;
L13: 
        DeRef(_25049);
        _25049 = (_25051 != 0);
L12: 
        if (_25049 == 0)
        {
            _25049 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _25049 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_48402);
        DeRef(_gtok_48403);
        _gtok_48403 = _tok_48402;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_53dup_globals_48371, _53dup_globals_48371, _st_ptr_48399);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _25058 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25059 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25059);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25060 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25060 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25059 = NOVALUE;
        _2 = (object)SEQ_PTR(_25058);
        if (!IS_ATOM_INT(_25060)){
            _25061 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25060)->dbl));
        }
        else{
            _25061 = (object)*(((s1_ptr)_2)->base + _25060);
        }
        _25058 = NOVALUE;
        if (IS_ATOM_INT(_25061)) {
            _25062 = (_25061 != 0);
        }
        else {
            _25062 = binary_op(NOTEQ, _25061, 0);
        }
        _25061 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_48373) && IS_ATOM(_25062)) {
            Ref(_25062);
            Append(&_53in_include_path_48373, _53in_include_path_48373, _25062);
        }
        else if (IS_ATOM(_53in_include_path_48373) && IS_SEQUENCE(_25062)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_48373, _53in_include_path_48373, _25062);
        }
        DeRef(_25062);
        _25062 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25064 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
        _2 = (object)SEQ_PTR(_25064);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25065 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25064 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48387, _25065)){
            _25065 = NOVALUE;
            goto L7; // [659] 1011
        }
        _25065 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_48402);
        _53add_ref(_tok_48402);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_48385);
        DeRef(_msg_48393);
        DeRef(_b_name_48394);
        DeRef(_gtok_48403);
        DeRef(_25048);
        _25048 = NOVALUE;
        DeRef(_25056);
        _25056 = NOVALUE;
        _25035 = NOVALUE;
        DeRef(_25001);
        _25001 = NOVALUE;
        _25020 = NOVALUE;
        DeRef(_25042);
        _25042 = NOVALUE;
        _25028 = NOVALUE;
        _25054 = NOVALUE;
        _25015 = NOVALUE;
        _25060 = NOVALUE;
        _25019 = NOVALUE;
        DeRef(_25040);
        _25040 = NOVALUE;
        _25046 = NOVALUE;
        DeRef(_25050);
        _25050 = NOVALUE;
        DeRef(_24991);
        _24991 = NOVALUE;
        return _tok_48402;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_27BIND_20182 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_48402);
        _53add_ref(_tok_48402);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_48385);
        DeRef(_msg_48393);
        DeRef(_b_name_48394);
        DeRef(_gtok_48403);
        DeRef(_25048);
        _25048 = NOVALUE;
        DeRef(_25056);
        _25056 = NOVALUE;
        _25035 = NOVALUE;
        DeRef(_25001);
        _25001 = NOVALUE;
        _25020 = NOVALUE;
        DeRef(_25042);
        _25042 = NOVALUE;
        _25028 = NOVALUE;
        _25054 = NOVALUE;
        _25015 = NOVALUE;
        _25060 = NOVALUE;
        _25019 = NOVALUE;
        DeRef(_25040);
        _25040 = NOVALUE;
        _25046 = NOVALUE;
        DeRef(_25050);
        _25050 = NOVALUE;
        DeRef(_24991);
        _24991 = NOVALUE;
        return _tok_48402;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_48402);
    _25067 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25067)){
        _25068 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25067)->dbl));
    }
    else{
        _25068 = (object)*(((s1_ptr)_2)->base + _25067);
    }
    _2 = (object)SEQ_PTR(_25068);
    _scope_48395 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_48395)){
        _scope_48395 = (object)DBL_PTR(_scope_48395)->dbl;
    }
    _25068 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_48386 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_48395 != 7)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_48402);
    _53add_ref(_tok_48402);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_gtok_48403);
    DeRef(_25048);
    _25048 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _tok_48402;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_48402);
    _25072 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25072)){
        _25073 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25072)->dbl));
    }
    else{
        _25073 = (object)*(((s1_ptr)_2)->base + _25072);
    }
    _2 = (object)SEQ_PTR(_25073);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _tok_file_48574 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _tok_file_48574 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_tok_file_48574)){
        _tok_file_48574 = (object)DBL_PTR(_tok_file_48574)->dbl;
    }
    _25073 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48581 = 0;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _25075 = (_scope_48395 == 3);
    if (_25075 != 0) {
        goto L19; // [807] 940
    }
    _25077 = (_scope_48395 == 7);
    if (_25077 == 0)
    {
        DeRef(_25077);
        _25077 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_25077);
        _25077 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_48386 != _tok_file_48574)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48581 = 1;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48591 = 0;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_48395;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_53Resolve_unincluded_globals_48376 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48591 = 7;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48591 = 6;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48574 == _file_no_48386)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48591 = 4;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48591 = 6;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _25082 = (object)*(((s1_ptr)_2)->base + _file_no_48386);
    _2 = (object)SEQ_PTR(_25082);
    _25083 = (object)*(((s1_ptr)_2)->base + _tok_file_48574);
    _25082 = NOVALUE;
    if (IS_ATOM_INT(_25083)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48591 & (uintptr_t)_25083;
             _good_48581 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48581 = binary_op(AND_BITS, _include_type_48591, _25083);
    }
    _25083 = NOVALUE;
    if (!IS_ATOM_INT(_good_48581)) {
        _1 = (object)(DBL_PTR(_good_48581)->dbl);
        DeRefDS(_good_48581);
        _good_48581 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48581 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_48386 != _tok_file_48574)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_48402);
    _53add_ref(_tok_48402);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_gtok_48403);
    DeRef(_25048);
    _25048 = NOVALUE;
    _25072 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    DeRef(_25075);
    _25075 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _tok_48402;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_48402);
    DeRef(_gtok_48403);
    _gtok_48403 = _tok_48402;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_53dup_globals_48371, _53dup_globals_48371, _st_ptr_48399);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _25087 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
    _2 = (object)SEQ_PTR(_25087);
    _25088 = (object)*(((s1_ptr)_2)->base + _tok_file_48574);
    _25087 = NOVALUE;
    if (IS_ATOM_INT(_25088)) {
        _25089 = (_25088 != 0);
    }
    else {
        _25089 = binary_op(NOTEQ, _25088, 0);
    }
    _25088 = NOVALUE;
    if (IS_SEQUENCE(_53in_include_path_48373) && IS_ATOM(_25089)) {
        Ref(_25089);
        Append(&_53in_include_path_48373, _53in_include_path_48373, _25089);
    }
    else if (IS_ATOM(_53in_include_path_48373) && IS_SEQUENCE(_25089)) {
    }
    else {
        Concat((object_ptr)&_53in_include_path_48373, _53in_include_path_48373, _25089);
    }
    DeRef(_25089);
    _25089 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25091 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_25091);
    _st_ptr_48399 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_48399)){
        _st_ptr_48399 = (object)DBL_PTR(_st_ptr_48399)->dbl;
    }
    _25091 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_48372)){
            _25093 = SEQ_PTR(_53dup_overrides_48372)->length;
    }
    else {
        _25093 = 1;
    }
    if (_25093 == 0)
    {
        _25093 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _25093 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_53dup_overrides_48372);
    _st_ptr_48399 = (object)*(((s1_ptr)_2)->base + 1);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25095 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_25095);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25096 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25096 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25095 = NOVALUE;
    Ref(_25096);
    DeRef(_tok_48402);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25096;
    ((intptr_t *)_2)[2] = _st_ptr_48399;
    _tok_48402 = MAKE_SEQ(_1);
    _25096 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_48402);
    _53add_ref(_tok_48402);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_gtok_48403);
    DeRef(_25048);
    _25048 = NOVALUE;
    _25072 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    DeRef(_25075);
    _25075 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _tok_48402;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_48400 == 0)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25099 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25099 = 1;
    }
    if (_25099 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25101 = (object)*(((s1_ptr)_2)->base + _st_builtin_48400);
    _2 = (object)SEQ_PTR(_25101);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25102 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25102 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25101 = NOVALUE;
    _25103 = find_from(_25102, _53builtin_warnings_48375, 1);
    _25102 = NOVALUE;
    _25104 = (_25103 == 0);
    _25103 = NOVALUE;
    if (_25104 == 0)
    {
        DeRef(_25104);
        _25104 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_25104);
        _25104 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25105 = (object)*(((s1_ptr)_2)->base + _st_builtin_48400);
    DeRef(_b_name_48394);
    _2 = (object)SEQ_PTR(_25105);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _b_name_48394 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _b_name_48394 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_b_name_48394);
    _25105 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_48394);
    Append(&_53builtin_warnings_48375, _53builtin_warnings_48375, _b_name_48394);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25108 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25108 = 1;
    }
    if (_25108 <= 1)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22404);
    DeRef(_msg_48393);
    _msg_48393 = _22404;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_22209);
    DeRef(_msg_48393);
    _msg_48393 = _22209;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25110 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25110 = 1;
    }
    {
        object _i_48658;
        _i_48658 = 1;
L2A: 
        if (_i_48658 > _25110){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_53dup_globals_48371);
        _25111 = (object)*(((s1_ptr)_2)->base + _i_48658);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_25111)){
            _25112 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25111)->dbl));
        }
        else{
            _25112 = (object)*(((s1_ptr)_2)->base + _25111);
        }
        _2 = (object)SEQ_PTR(_25112);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _25113 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _25113 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _25112 = NOVALUE;
        DeRef(_msg_file_48647);
        _2 = (object)SEQ_PTR(_28known_files_11573);
        if (!IS_ATOM_INT(_25113)){
            _msg_file_48647 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25113)->dbl));
        }
        else{
            _msg_file_48647 = (object)*(((s1_ptr)_2)->base + _25113);
        }
        Ref(_msg_file_48647);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22404;
            concat_list[1] = _msg_file_48647;
            concat_list[2] = _25115;
            Concat_N((object_ptr)&_25116, concat_list, 3);
        }
        Concat((object_ptr)&_msg_48393, _msg_48393, _25116);
        DeRefDS(_25116);
        _25116 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48658 = _i_48658 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25118 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_48394);
    ((intptr_t*)_2)[1] = _b_name_48394;
    Ref(_25118);
    ((intptr_t*)_2)[2] = _25118;
    RefDS(_msg_48393);
    ((intptr_t*)_2)[3] = _msg_48393;
    _25119 = MAKE_SEQ(_1);
    _25118 = NOVALUE;
    _49Warning(234, 8, _25119);
    _25119 = NOVALUE;
L27: 
    DeRef(_msg_file_48647);
    _msg_file_48647 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25120 = (object)*(((s1_ptr)_2)->base + _st_builtin_48400);
    _2 = (object)SEQ_PTR(_25120);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25121 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25121 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25120 = NOVALUE;
    Ref(_25121);
    DeRef(_tok_48402);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25121;
    ((intptr_t *)_2)[2] = _st_builtin_48400;
    _tok_48402 = MAKE_SEQ(_1);
    _25121 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_48402);
    _53add_ref(_tok_48402);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_gtok_48403);
    DeRef(_25048);
    _25048 = NOVALUE;
    _25072 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    DeRef(_25075);
    _25075 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25111 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25113 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _tok_48402;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25123 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25123 = 1;
    }
    _25124 = (_25123 > 1);
    _25123 = NOVALUE;
    if (_25124 == 0) {
        goto L2D; // [1333] 1452
    }
    _25126 = find_from(1, _53in_include_path_48373, 1);
    if (_25126 == 0)
    {
        _25126 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _25126 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_48397 = 1;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25127 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25127 = 1;
    }
    if (_ix_48397 > _25127)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_53in_include_path_48373);
    _25129 = (object)*(((s1_ptr)_2)->base + _ix_48397);
    if (_25129 == 0) {
        _25129 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_25129) && DBL_PTR(_25129)->dbl == 0.0){
            _25129 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _25129 = NOVALUE;
    }
    _25129 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_48397 = _ix_48397 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53dup_globals_48371);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48397)) ? _ix_48397 : (object)(DBL_PTR(_ix_48397)->dbl);
        int stop = (IS_ATOM_INT(_ix_48397)) ? _ix_48397 : (object)(DBL_PTR(_ix_48397)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53dup_globals_48371), start, &_53dup_globals_48371 );
            }
            else Tail(SEQ_PTR(_53dup_globals_48371), stop+1, &_53dup_globals_48371);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53dup_globals_48371), start, &_53dup_globals_48371);
        }
        else {
            assign_slice_seq = &assign_space;
            _53dup_globals_48371 = Remove_elements(start, stop, (SEQ_PTR(_53dup_globals_48371)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53in_include_path_48373);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48397)) ? _ix_48397 : (object)(DBL_PTR(_ix_48397)->dbl);
        int stop = (IS_ATOM_INT(_ix_48397)) ? _ix_48397 : (object)(DBL_PTR(_ix_48397)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53in_include_path_48373), start, &_53in_include_path_48373 );
            }
            else Tail(SEQ_PTR(_53in_include_path_48373), stop+1, &_53in_include_path_48373);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53in_include_path_48373), start, &_53in_include_path_48373);
        }
        else {
            assign_slice_seq = &assign_space;
            _53in_include_path_48373 = Remove_elements(start, stop, (SEQ_PTR(_53in_include_path_48373)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25133 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25133 = 1;
    }
    if (_25133 != 1)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_53dup_globals_48371);
    _st_ptr_48399 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_48399)){
        _st_ptr_48399 = (object)DBL_PTR(_st_ptr_48399)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25136 = (object)*(((s1_ptr)_2)->base + _st_ptr_48399);
    _2 = (object)SEQ_PTR(_25136);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25137 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25137 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25136 = NOVALUE;
    Ref(_25137);
    DeRef(_gtok_48403);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25137;
    ((intptr_t *)_2)[2] = _st_ptr_48399;
    _gtok_48403 = MAKE_SEQ(_1);
    _25137 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25139 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25139 = 1;
    }
    _25140 = (_25139 == 1);
    _25139 = NOVALUE;
    if (_25140 == 0) {
        goto L32; // [1465] 1644
    }
    _25142 = (_st_builtin_48400 == 0);
    if (_25142 == 0)
    {
        DeRef(_25142);
        _25142 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_25142);
        _25142 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_48403);
    _53add_ref(_gtok_48403);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_53in_include_path_48373);
    _25143 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25143)) {
        _25144 = (_25143 == 0);
    }
    else {
        _25144 = unary_op(NOT, _25143);
    }
    _25143 = NOVALUE;
    if (IS_ATOM_INT(_25144)) {
        if (_25144 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_25144)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_48403);
    _25146 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25146)){
        _25147 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25146)->dbl));
    }
    else{
        _25147 = (object)*(((s1_ptr)_2)->base + _25146);
    }
    _2 = (object)SEQ_PTR(_25147);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25148 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25148 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25147 = NOVALUE;
    Ref(_25148);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48387;
    ((intptr_t *)_2)[2] = _25148;
    _25149 = MAKE_SEQ(_1);
    _25148 = NOVALUE;
    _25150 = find_from(_25149, _53include_warnings_48374, 1);
    DeRefDS(_25149);
    _25149 = NOVALUE;
    _25151 = (_25150 == 0);
    _25150 = NOVALUE;
    if (_25151 == 0)
    {
        DeRef(_25151);
        _25151 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_25151);
        _25151 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_48403);
    _25152 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25152)){
        _25153 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25152)->dbl));
    }
    else{
        _25153 = (object)*(((s1_ptr)_2)->base + _25152);
    }
    _2 = (object)SEQ_PTR(_25153);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25154 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25154 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25153 = NOVALUE;
    Ref(_25154);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48387;
    ((intptr_t *)_2)[2] = _25154;
    _25155 = MAKE_SEQ(_1);
    _25154 = NOVALUE;
    RefDS(_25155);
    Prepend(&_53include_warnings_48374, _53include_warnings_48374, _25155);
    DeRefDS(_25155);
    _25155 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25157 = (object)*(((s1_ptr)_2)->base + _scanning_file_48387);
    Ref(_25157);
    _25158 = _53name_ext(_25157);
    _25157 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_48403);
    _25159 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_25159)){
        _25160 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25159)->dbl));
    }
    else{
        _25160 = (object)*(((s1_ptr)_2)->base + _25159);
    }
    _2 = (object)SEQ_PTR(_25160);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25161 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25161 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25160 = NOVALUE;
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!IS_ATOM_INT(_25161)){
        _25162 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25161)->dbl));
    }
    else{
        _25162 = (object)*(((s1_ptr)_2)->base + _25161);
    }
    Ref(_25162);
    _25163 = _53name_ext(_25162);
    _25162 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25158;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_word_48385);
    ((intptr_t*)_2)[3] = _word_48385;
    ((intptr_t*)_2)[4] = _25163;
    _25164 = MAKE_SEQ(_1);
    _25163 = NOVALUE;
    _25158 = NOVALUE;
    _0 = _30GetMsgText(233, 0, _25164);
    DeRef(_27symbol_resolution_warning_20673);
    _27symbol_resolution_warning_20673 = _0;
    _25164 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_tok_48402);
    DeRef(_25144);
    _25144 = NOVALUE;
    DeRef(_25048);
    _25048 = NOVALUE;
    _25072 = NOVALUE;
    DeRef(_25124);
    _25124 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25146 = NOVALUE;
    DeRef(_25075);
    _25075 = NOVALUE;
    DeRef(_25140);
    _25140 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25111 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25113 = NOVALUE;
    _25152 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    _25159 = NOVALUE;
    _25161 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _gtok_48403;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25166 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25166 = 1;
    }
    if (_25166 != 0)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_48396 = 9;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_27fwd_line_number_20573 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49643);
    DeRef(_49last_ForwardLine_49645);
    _49last_ForwardLine_49645 = _49ForwardLine_49643;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _49last_forward_bp_49649 = _49forward_bp_49647;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _27last_fwd_line_number_20575 = _27fwd_line_number_20573;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49ForwardLine_49643);
    _49ForwardLine_49643 = _49ThisLine_49642;

    /** symtab.e:1061			forward_bp = bp*/
    _49forward_bp_49647 = _49bp_49646;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _27fwd_line_number_20573 = _27line_number_20572;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _25168 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _25168 = 1;
    }
    if (_25168 == 0)
    {
        _25168 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _25168 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_48396 = 10;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_48372)){
            _25169 = SEQ_PTR(_53dup_overrides_48372)->length;
    }
    else {
        _25169 = 1;
    }
    if (_25169 == 0)
    {
        _25169 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _25169 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_48396 = 12;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_53No_new_entry_48382 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509;
    RefDS(_word_48385);
    ((intptr_t*)_2)[2] = _word_48385;
    ((intptr_t*)_2)[3] = _defined_48396;
    RefDS(_53dup_globals_48371);
    ((intptr_t*)_2)[4] = _53dup_globals_48371;
    _25170 = MAKE_SEQ(_1);
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_tok_48402);
    DeRef(_gtok_48403);
    DeRef(_25144);
    _25144 = NOVALUE;
    DeRef(_25048);
    _25048 = NOVALUE;
    _25072 = NOVALUE;
    DeRef(_25124);
    _25124 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25146 = NOVALUE;
    DeRef(_25075);
    _25075 = NOVALUE;
    DeRef(_25140);
    _25140 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25111 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25113 = NOVALUE;
    _25152 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    _25159 = NOVALUE;
    _25161 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _25170;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _25171 = (object)*(((s1_ptr)_2)->base + _hashval_48391);
    RefDS(_word_48385);
    Ref(_25171);
    _25172 = _53NewEntry(_word_48385, 0, _defined_48396, -100, _hashval_48391, _25171, 0);
    _25171 = NOVALUE;
    DeRef(_tok_48402);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _25172;
    _tok_48402 = MAKE_SEQ(_1);
    _25172 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48402);
    _25174 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_25174);
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_48391);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25174;
    if( _1 != _25174 ){
        DeRef(_1);
    }
    _25174 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_48386 == -1)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_48402);
    _25176 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25176))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25176)->dbl));
    else
    _3 = (object)(_25176 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_48386;
    DeRef(_1);
    _25177 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_48385);
    DeRef(_msg_48393);
    DeRef(_b_name_48394);
    DeRef(_gtok_48403);
    DeRef(_25144);
    _25144 = NOVALUE;
    DeRef(_25048);
    _25048 = NOVALUE;
    _25072 = NOVALUE;
    DeRef(_25124);
    _25124 = NOVALUE;
    DeRef(_25056);
    _25056 = NOVALUE;
    _25146 = NOVALUE;
    DeRef(_25075);
    _25075 = NOVALUE;
    DeRef(_25140);
    _25140 = NOVALUE;
    _25035 = NOVALUE;
    DeRef(_25001);
    _25001 = NOVALUE;
    _25111 = NOVALUE;
    _25020 = NOVALUE;
    _25067 = NOVALUE;
    DeRef(_25170);
    _25170 = NOVALUE;
    DeRef(_25042);
    _25042 = NOVALUE;
    _25028 = NOVALUE;
    _25054 = NOVALUE;
    _25113 = NOVALUE;
    _25152 = NOVALUE;
    _25015 = NOVALUE;
    _25060 = NOVALUE;
    _25019 = NOVALUE;
    DeRef(_25040);
    _25040 = NOVALUE;
    _25176 = NOVALUE;
    _25046 = NOVALUE;
    DeRef(_25050);
    _25050 = NOVALUE;
    _25159 = NOVALUE;
    _25161 = NOVALUE;
    DeRef(_24991);
    _24991 = NOVALUE;
    return _tok_48402;
    ;
}


void _53Hide(object _s_48796)
{
    object _prev_48798 = NOVALUE;
    object _p_48799 = NOVALUE;
    object _25197 = NOVALUE;
    object _25196 = NOVALUE;
    object _25195 = NOVALUE;
    object _25193 = NOVALUE;
    object _25192 = NOVALUE;
    object _25191 = NOVALUE;
    object _25190 = NOVALUE;
    object _25189 = NOVALUE;
    object _25185 = NOVALUE;
    object _25184 = NOVALUE;
    object _25183 = NOVALUE;
    object _25182 = NOVALUE;
    object _25180 = NOVALUE;
    object _25179 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48796)) {
        _1 = (object)(DBL_PTR(_s_48796)->dbl);
        DeRefDS(_s_48796);
        _s_48796 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25179 = (object)*(((s1_ptr)_2)->base + _s_48796);
    _2 = (object)SEQ_PTR(_25179);
    _25180 = (object)*(((s1_ptr)_2)->base + 11);
    _25179 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_25180)){
        _p_48799 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25180)->dbl));
    }
    else{
        _p_48799 = (object)*(((s1_ptr)_2)->base + _25180);
    }
    if (!IS_ATOM_INT(_p_48799)){
        _p_48799 = (object)DBL_PTR(_p_48799)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48798 = 0;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _25182 = (_p_48799 != _s_48796);
    if (_25182 == 0) {
        goto L2; // [41] 81
    }
    _25184 = (_p_48799 != 0);
    if (_25184 == 0)
    {
        DeRef(_25184);
        _25184 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25184);
        _25184 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48798 = _p_48799;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25185 = (object)*(((s1_ptr)_2)->base + _p_48799);
    _2 = (object)SEQ_PTR(_25185);
    _p_48799 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_48799)){
        _p_48799 = (object)DBL_PTR(_p_48799)->dbl;
    }
    _25185 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48799 != 0)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _25180 = NOVALUE;
    DeRef(_25182);
    _25182 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48798 != 0)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25189 = (object)*(((s1_ptr)_2)->base + _s_48796);
    _2 = (object)SEQ_PTR(_25189);
    _25190 = (object)*(((s1_ptr)_2)->base + 11);
    _25189 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25191 = (object)*(((s1_ptr)_2)->base + _s_48796);
    _2 = (object)SEQ_PTR(_25191);
    _25192 = (object)*(((s1_ptr)_2)->base + 9);
    _25191 = NOVALUE;
    Ref(_25192);
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_25190))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25190)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25190);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25192;
    if( _1 != _25192 ){
        DeRef(_1);
    }
    _25192 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48798 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25195 = (object)*(((s1_ptr)_2)->base + _s_48796);
    _2 = (object)SEQ_PTR(_25195);
    _25196 = (object)*(((s1_ptr)_2)->base + 9);
    _25195 = NOVALUE;
    Ref(_25196);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25196;
    if( _1 != _25196 ){
        DeRef(_1);
    }
    _25196 = NOVALUE;
    _25193 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48796 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _25197 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _25180 = NOVALUE;
    DeRef(_25182);
    _25182 = NOVALUE;
    _25190 = NOVALUE;
    return;
    ;
}


void _53Show(object _s_48841)
{
    object _p_48843 = NOVALUE;
    object _25209 = NOVALUE;
    object _25208 = NOVALUE;
    object _25206 = NOVALUE;
    object _25205 = NOVALUE;
    object _25203 = NOVALUE;
    object _25202 = NOVALUE;
    object _25200 = NOVALUE;
    object _25199 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25199 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25199);
    _25200 = (object)*(((s1_ptr)_2)->base + 11);
    _25199 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_25200)){
        _p_48843 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25200)->dbl));
    }
    else{
        _p_48843 = (object)*(((s1_ptr)_2)->base + _25200);
    }
    if (!IS_ATOM_INT(_p_48843)){
        _p_48843 = (object)DBL_PTR(_p_48843)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25202 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25202);
    _25203 = (object)*(((s1_ptr)_2)->base + 9);
    _25202 = NOVALUE;
    if (IS_ATOM_INT(_25203)) {
        if (_25203 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25203)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25205 = (_p_48843 == _s_48841);
    if (_25205 == 0)
    {
        DeRef(_25205);
        _25205 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25205);
        _25205 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _25203 = NOVALUE;
    _25200 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48841 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48843;
    DeRef(_1);
    _25206 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25208 = (object)*(((s1_ptr)_2)->base + _s_48841);
    _2 = (object)SEQ_PTR(_25208);
    _25209 = (object)*(((s1_ptr)_2)->base + 11);
    _25208 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_25209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48841;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _25209 = NOVALUE;
    _25203 = NOVALUE;
    _25200 = NOVALUE;
    return;
    ;
}


void _53hide_params(object _s_48867)
{
    object _param_48869 = NOVALUE;
    object _25212 = NOVALUE;
    object _25211 = NOVALUE;
    object _25210 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48869 = _s_48867;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25210 = (object)*(((s1_ptr)_2)->base + _s_48867);
    _2 = (object)SEQ_PTR(_25210);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _25211 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _25211 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _25210 = NOVALUE;
    {
        object _i_48871;
        _i_48871 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48871, _25211)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25212 = (object)*(((s1_ptr)_2)->base + _s_48867);
        _2 = (object)SEQ_PTR(_25212);
        _param_48869 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48869)){
            _param_48869 = (object)DBL_PTR(_param_48869)->dbl;
        }
        _25212 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _53Hide(_param_48869);

        /** symtab.e:1131		end for*/
        _0 = _i_48871;
        if (IS_ATOM_INT(_i_48871)) {
            _i_48871 = _i_48871 + 1;
            if ((object)((uintptr_t)_i_48871 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48871 = NewDouble((eudouble)_i_48871);
            }
        }
        else {
            _i_48871 = binary_op_a(PLUS, _i_48871, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48871);
    }

    /** symtab.e:1132	end procedure*/
    _25211 = NOVALUE;
    return;
    ;
}


void _53show_params(object _s_48883)
{
    object _param_48885 = NOVALUE;
    object _25216 = NOVALUE;
    object _25215 = NOVALUE;
    object _25214 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48885 = _s_48883;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25214 = (object)*(((s1_ptr)_2)->base + _s_48883);
    _2 = (object)SEQ_PTR(_25214);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _25215 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _25215 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _25214 = NOVALUE;
    {
        object _i_48887;
        _i_48887 = 1;
L1: 
        if (binary_op_a(GREATER, _i_48887, _25215)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25216 = (object)*(((s1_ptr)_2)->base + _s_48883);
        _2 = (object)SEQ_PTR(_25216);
        _param_48885 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_48885)){
            _param_48885 = (object)DBL_PTR(_param_48885)->dbl;
        }
        _25216 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _53Show(_param_48885);

        /** symtab.e:1139		end for*/
        _0 = _i_48887;
        if (IS_ATOM_INT(_i_48887)) {
            _i_48887 = _i_48887 + 1;
            if ((object)((uintptr_t)_i_48887 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48887 = NewDouble((eudouble)_i_48887);
            }
        }
        else {
            _i_48887 = binary_op_a(PLUS, _i_48887, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48887);
    }

    /** symtab.e:1140	end procedure*/
    _25215 = NOVALUE;
    return;
    ;
}


void _53LintCheck(object _s_48899)
{
    object _warn_level_48900 = NOVALUE;
    object _file_48901 = NOVALUE;
    object _vscope_48902 = NOVALUE;
    object _vname_48903 = NOVALUE;
    object _vusage_48904 = NOVALUE;
    object _25277 = NOVALUE;
    object _25276 = NOVALUE;
    object _25275 = NOVALUE;
    object _25274 = NOVALUE;
    object _25273 = NOVALUE;
    object _25272 = NOVALUE;
    object _25270 = NOVALUE;
    object _25269 = NOVALUE;
    object _25268 = NOVALUE;
    object _25267 = NOVALUE;
    object _25266 = NOVALUE;
    object _25265 = NOVALUE;
    object _25262 = NOVALUE;
    object _25261 = NOVALUE;
    object _25260 = NOVALUE;
    object _25259 = NOVALUE;
    object _25258 = NOVALUE;
    object _25257 = NOVALUE;
    object _25255 = NOVALUE;
    object _25253 = NOVALUE;
    object _25252 = NOVALUE;
    object _25250 = NOVALUE;
    object _25249 = NOVALUE;
    object _25247 = NOVALUE;
    object _25246 = NOVALUE;
    object _25245 = NOVALUE;
    object _25244 = NOVALUE;
    object _25242 = NOVALUE;
    object _25241 = NOVALUE;
    object _25237 = NOVALUE;
    object _25234 = NOVALUE;
    object _25233 = NOVALUE;
    object _25232 = NOVALUE;
    object _25231 = NOVALUE;
    object _25228 = NOVALUE;
    object _25227 = NOVALUE;
    object _25222 = NOVALUE;
    object _25220 = NOVALUE;
    object _25218 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48899)) {
        _1 = (object)(DBL_PTR(_s_48899)->dbl);
        DeRefDS(_s_48899);
        _s_48899 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25218 = (object)*(((s1_ptr)_2)->base + _s_48899);
    _2 = (object)SEQ_PTR(_25218);
    _vusage_48904 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_48904)){
        _vusage_48904 = (object)DBL_PTR(_vusage_48904)->dbl;
    }
    _25218 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25220 = (object)*(((s1_ptr)_2)->base + _s_48899);
    _2 = (object)SEQ_PTR(_25220);
    _vscope_48902 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_48902)){
        _vscope_48902 = (object)DBL_PTR(_vscope_48902)->dbl;
    }
    _25220 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25222 = (object)*(((s1_ptr)_2)->base + _s_48899);
    DeRef(_vname_48903);
    _2 = (object)SEQ_PTR(_25222);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _vname_48903 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _vname_48903 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_vname_48903);
    _25222 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48904;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48900 = 1;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48900 = 2;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48902 <= 5)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48900 = 0;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25227 = (object)*(((s1_ptr)_2)->base + _s_48899);
        _2 = (object)SEQ_PTR(_25227);
        _25228 = (object)*(((s1_ptr)_2)->base + 3);
        _25227 = NOVALUE;
        if (binary_op_a(NOTEQ, _25228, 2)){
            _25228 = NOVALUE;
            goto L1; // [110] 193
        }
        _25228 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_27Strict_is_on_20637 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48900 = 0;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25231 = (object)*(((s1_ptr)_2)->base + _s_48899);
        _2 = (object)SEQ_PTR(_25231);
        _25232 = (object)*(((s1_ptr)_2)->base + 16);
        _25231 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _25233 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
        _2 = (object)SEQ_PTR(_25233);
        if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
            _25234 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
        }
        else{
            _25234 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
        }
        _25233 = NOVALUE;
        if (binary_op_a(LESS, _25232, _25234)){
            _25232 = NOVALUE;
            _25234 = NOVALUE;
            goto L3; // [163] 175
        }
        _25232 = NOVALUE;
        _25234 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48900 = 3;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48900 = 0;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48900 = 0;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48900 != 0)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48901);
    DeRef(_vname_48903);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _25237 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_25237);
    RefDS(_22209);
    _0 = _file_48901;
    _file_48901 = _15abbreviate_path(_25237, _22209);
    DeRef(_0);
    _25237 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48900 != 3)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48902 != 5)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25241 = (object)*(((s1_ptr)_2)->base + _s_48899);
    _2 = (object)SEQ_PTR(_25241);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25242 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25242 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25241 = NOVALUE;
    if (binary_op_a(NOTEQ, _27current_file_no_20571, _25242)){
        _25242 = NOVALUE;
        goto L7; // [254] 602
    }
    _25242 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48903);
    RefDS(_file_48901);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48901;
    ((intptr_t *)_2)[2] = _vname_48903;
    _25244 = MAKE_SEQ(_1);
    _49Warning(226, 32, _25244);
    _25244 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25245 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25245);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25246 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25246 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25245 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48901);
    ((intptr_t*)_2)[1] = _file_48901;
    RefDS(_vname_48903);
    ((intptr_t*)_2)[2] = _vname_48903;
    Ref(_25246);
    ((intptr_t*)_2)[3] = _25246;
    _25247 = MAKE_SEQ(_1);
    _25246 = NOVALUE;
    _49Warning(227, 32, _25247);
    _25247 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48902 != 5)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25249 = (object)*(((s1_ptr)_2)->base + _s_48899);
    _2 = (object)SEQ_PTR(_25249);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25250 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25250 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25249 = NOVALUE;
    if (binary_op_a(NOTEQ, _27current_file_no_20571, _25250)){
        _25250 = NOVALUE;
        goto L9; // [332] 601
    }
    _25250 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25252 = (object)*(((s1_ptr)_2)->base + _s_48899);
    _2 = (object)SEQ_PTR(_25252);
    _25253 = (object)*(((s1_ptr)_2)->base + 3);
    _25252 = NOVALUE;
    if (binary_op_a(NOTEQ, _25253, 2)){
        _25253 = NOVALUE;
        goto LA; // [352] 372
    }
    _25253 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48903);
    RefDS(_file_48901);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48901;
    ((intptr_t *)_2)[2] = _vname_48903;
    _25255 = MAKE_SEQ(_1);
    _49Warning(228, 16, _25255);
    _25255 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48900 != 1)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48903);
    RefDS(_file_48901);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48901;
    ((intptr_t *)_2)[2] = _vname_48903;
    _25257 = MAKE_SEQ(_1);
    _49Warning(229, 16, _25257);
    _25257 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48903);
    RefDS(_file_48901);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48901;
    ((intptr_t *)_2)[2] = _vname_48903;
    _25258 = MAKE_SEQ(_1);
    _49Warning(320, 16, _25258);
    _25258 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25259 = (object)*(((s1_ptr)_2)->base + _s_48899);
    _2 = (object)SEQ_PTR(_25259);
    _25260 = (object)*(((s1_ptr)_2)->base + 16);
    _25259 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25261 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25261);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _25262 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _25262 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _25261 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25260, _25262)){
        _25260 = NOVALUE;
        _25262 = NOVALUE;
        goto LC; // [440] 523
    }
    _25260 = NOVALUE;
    _25262 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48900 != 1)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_27Strict_is_on_20637 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25265 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25265);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25266 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25266 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25265 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48901);
    ((intptr_t*)_2)[1] = _file_48901;
    RefDS(_vname_48903);
    ((intptr_t*)_2)[2] = _vname_48903;
    Ref(_25266);
    ((intptr_t*)_2)[3] = _25266;
    _25267 = MAKE_SEQ(_1);
    _25266 = NOVALUE;
    _49Warning(230, 16, _25267);
    _25267 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25268 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25268);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25269 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25269 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25268 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48901);
    ((intptr_t*)_2)[1] = _file_48901;
    RefDS(_vname_48903);
    ((intptr_t*)_2)[2] = _vname_48903;
    Ref(_25269);
    ((intptr_t*)_2)[3] = _25269;
    _25270 = MAKE_SEQ(_1);
    _25269 = NOVALUE;
    _49Warning(321, 16, _25270);
    _25270 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48900 != 1)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_27Strict_is_on_20637 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25272 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25272);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25273 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25273 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25272 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48901);
    ((intptr_t*)_2)[1] = _file_48901;
    RefDS(_vname_48903);
    ((intptr_t*)_2)[2] = _vname_48903;
    Ref(_25273);
    ((intptr_t*)_2)[3] = _25273;
    _25274 = MAKE_SEQ(_1);
    _25273 = NOVALUE;
    _49Warning(231, 16, _25274);
    _25274 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25275 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25275);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25276 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25275 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48901);
    ((intptr_t*)_2)[1] = _file_48901;
    RefDS(_vname_48903);
    ((intptr_t*)_2)[2] = _vname_48903;
    Ref(_25276);
    ((intptr_t*)_2)[3] = _25276;
    _25277 = MAKE_SEQ(_1);
    _25276 = NOVALUE;
    _49Warning(322, 16, _25277);
    _25277 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48901);
    DeRef(_vname_48903);
    return;
    ;
}


void _53HideLocals()
{
    object _s_49070 = NOVALUE;
    object _25290 = NOVALUE;
    object _25288 = NOVALUE;
    object _25287 = NOVALUE;
    object _25286 = NOVALUE;
    object _25285 = NOVALUE;
    object _25284 = NOVALUE;
    object _25283 = NOVALUE;
    object _25282 = NOVALUE;
    object _25281 = NOVALUE;
    object _25280 = NOVALUE;
    object _25279 = NOVALUE;
    object _25278 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _53mark_rechecks(_27current_file_no_20571);

    /** symtab.e:1245		s = file_start_sym*/
    _s_49070 = _27file_start_sym_20577;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_49070 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25278 = (object)*(((s1_ptr)_2)->base + _s_49070);
    _2 = (object)SEQ_PTR(_25278);
    _25279 = (object)*(((s1_ptr)_2)->base + 4);
    _25278 = NOVALUE;
    if (IS_ATOM_INT(_25279)) {
        _25280 = (_25279 == 5);
    }
    else {
        _25280 = binary_op(EQUALS, _25279, 5);
    }
    _25279 = NOVALUE;
    if (IS_ATOM_INT(_25280)) {
        if (_25280 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25280)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25282 = (object)*(((s1_ptr)_2)->base + _s_49070);
    _2 = (object)SEQ_PTR(_25282);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _25283 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _25283 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _25282 = NOVALUE;
    if (IS_ATOM_INT(_25283)) {
        _25284 = (_25283 == _27current_file_no_20571);
    }
    else {
        _25284 = binary_op(EQUALS, _25283, _27current_file_no_20571);
    }
    _25283 = NOVALUE;
    if (_25284 == 0) {
        DeRef(_25284);
        _25284 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25284) && DBL_PTR(_25284)->dbl == 0.0){
            DeRef(_25284);
            _25284 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25284);
        _25284 = NOVALUE;
    }
    DeRef(_25284);
    _25284 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25285 = (_64current_block_25492 == _64top_level_block_25493);
    if (_25285 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _53Hide(_s_49070);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25287 = (object)*(((s1_ptr)_2)->base + _s_49070);
    _2 = (object)SEQ_PTR(_25287);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25288 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25288 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25287 = NOVALUE;
    if (binary_op_a(NOTEQ, _25288, -100)){
        _25288 = NOVALUE;
        goto L6; // [116] 126
    }
    _25288 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _53LintCheck(_s_49070);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25290 = (object)*(((s1_ptr)_2)->base + _s_49070);
    _2 = (object)SEQ_PTR(_25290);
    _s_49070 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_49070)){
        _s_49070 = (object)DBL_PTR(_s_49070)->dbl;
    }
    _25290 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25280);
    _25280 = NOVALUE;
    DeRef(_25285);
    _25285 = NOVALUE;
    return;
    ;
}


object _53sym_name(object _sym_49109)
{
    object _25293 = NOVALUE;
    object _25292 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49109)) {
        _1 = (object)(DBL_PTR(_sym_49109)->dbl);
        DeRefDS(_sym_49109);
        _sym_49109 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25292 = (object)*(((s1_ptr)_2)->base + _sym_49109);
    _2 = (object)SEQ_PTR(_25292);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _25293 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _25293 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _25292 = NOVALUE;
    Ref(_25293);
    return _25293;
    ;
}


object _53sym_token(object _sym_49117)
{
    object _25295 = NOVALUE;
    object _25294 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49117)) {
        _1 = (object)(DBL_PTR(_sym_49117)->dbl);
        DeRefDS(_sym_49117);
        _sym_49117 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25294 = (object)*(((s1_ptr)_2)->base + _sym_49117);
    _2 = (object)SEQ_PTR(_25294);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _25295 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _25295 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _25294 = NOVALUE;
    Ref(_25295);
    return _25295;
    ;
}


object _53sym_scope(object _sym_49125)
{
    object _25297 = NOVALUE;
    object _25296 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49125)) {
        _1 = (object)(DBL_PTR(_sym_49125)->dbl);
        DeRefDS(_sym_49125);
        _sym_49125 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25296 = (object)*(((s1_ptr)_2)->base + _sym_49125);
    _2 = (object)SEQ_PTR(_25296);
    _25297 = (object)*(((s1_ptr)_2)->base + 4);
    _25296 = NOVALUE;
    Ref(_25297);
    return _25297;
    ;
}


object _53sym_mode(object _sym_49133)
{
    object _25299 = NOVALUE;
    object _25298 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49133)) {
        _1 = (object)(DBL_PTR(_sym_49133)->dbl);
        DeRefDS(_sym_49133);
        _sym_49133 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25298 = (object)*(((s1_ptr)_2)->base + _sym_49133);
    _2 = (object)SEQ_PTR(_25298);
    _25299 = (object)*(((s1_ptr)_2)->base + 3);
    _25298 = NOVALUE;
    Ref(_25299);
    return _25299;
    ;
}


object _53sym_obj(object _sym_49141)
{
    object _25301 = NOVALUE;
    object _25300 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49141)) {
        _1 = (object)(DBL_PTR(_sym_49141)->dbl);
        DeRefDS(_sym_49141);
        _sym_49141 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25300 = (object)*(((s1_ptr)_2)->base + _sym_49141);
    _2 = (object)SEQ_PTR(_25300);
    _25301 = (object)*(((s1_ptr)_2)->base + 1);
    _25300 = NOVALUE;
    Ref(_25301);
    return _25301;
    ;
}


object _53sym_next(object _sym_49149)
{
    object _25303 = NOVALUE;
    object _25302 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25302 = (object)*(((s1_ptr)_2)->base + _sym_49149);
    _2 = (object)SEQ_PTR(_25302);
    _25303 = (object)*(((s1_ptr)_2)->base + 2);
    _25302 = NOVALUE;
    Ref(_25303);
    return _25303;
    ;
}


object _53sym_block(object _sym_49157)
{
    object _25305 = NOVALUE;
    object _25304 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25304 = (object)*(((s1_ptr)_2)->base + _sym_49157);
    _2 = (object)SEQ_PTR(_25304);
    if (!IS_ATOM_INT(_27S_BLOCK_20229)){
        _25305 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    }
    else{
        _25305 = (object)*(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    }
    _25304 = NOVALUE;
    Ref(_25305);
    return _25305;
    ;
}


object _53sym_next_in_block(object _sym_49165)
{
    object _25307 = NOVALUE;
    object _25306 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25306 = (object)*(((s1_ptr)_2)->base + _sym_49165);
    _2 = (object)SEQ_PTR(_25306);
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201)){
        _25307 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    }
    else{
        _25307 = (object)*(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    }
    _25306 = NOVALUE;
    Ref(_25307);
    return _25307;
    ;
}


object _53sym_usage(object _sym_49173)
{
    object _25309 = NOVALUE;
    object _25308 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25308 = (object)*(((s1_ptr)_2)->base + _sym_49173);
    _2 = (object)SEQ_PTR(_25308);
    _25309 = (object)*(((s1_ptr)_2)->base + 5);
    _25308 = NOVALUE;
    Ref(_25309);
    return _25309;
    ;
}



// 0x69174848
