// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _69GetSourceName()
{
    object _real_name_72636 = NOVALUE;
    object _fh_72637 = NOVALUE;
    object _has_extension_72639 = NOVALUE;
    object _36250 = NOVALUE;
    object _36248 = NOVALUE;
    object _36247 = NOVALUE;
    object _36244 = NOVALUE;
    object _36243 = NOVALUE;
    object _36242 = NOVALUE;
    object _36241 = NOVALUE;
    object _36240 = NOVALUE;
    object _36239 = NOVALUE;
    object _36236 = NOVALUE;
    object _36235 = NOVALUE;
    object _36233 = NOVALUE;
    object _36232 = NOVALUE;
    object _36231 = NOVALUE;
    object _36230 = NOVALUE;
    object _36229 = NOVALUE;
    object _36228 = NOVALUE;
    object _36225 = NOVALUE;
    object _36224 = NOVALUE;
    object _36222 = NOVALUE;
    object _36221 = NOVALUE;
    object _36217 = NOVALUE;
    object _36216 = NOVALUE;
    object _36213 = NOVALUE;
    object _36212 = NOVALUE;
    object _36211 = NOVALUE;
    object _36209 = NOVALUE;
    object _36208 = NOVALUE;
    object _36207 = NOVALUE;
    object _36206 = NOVALUE;
    object _36205 = NOVALUE;
    object _36204 = NOVALUE;
    object _36203 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_72639 = _9FALSE_439;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_47src_name_50000)){
            _36203 = SEQ_PTR(_47src_name_50000)->length;
    }
    else {
        _36203 = 1;
    }
    _36204 = (_36203 == 0);
    _36203 = NOVALUE;
    if (_36204 == 0) {
        goto L1; // [19] 45
    }
    _36206 = (0 == 0);
    if (_36206 == 0)
    {
        DeRef(_36206);
        _36206 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_36206);
        _36206 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _47show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_72636);
    DeRef(_36204);
    _36204 = NOVALUE;
    return -2;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_47src_name_50000)){
            _36207 = SEQ_PTR(_47src_name_50000)->length;
    }
    else {
        _36207 = 1;
    }
    _36208 = (_36207 == 0);
    _36207 = NOVALUE;
    if (_36208 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_22209);
    Append(&_28known_files_11573, _28known_files_11573, _22209);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36211 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36211 = 1;
    }
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _36212 = (object)*(((s1_ptr)_2)->base + _36211);
    _36213 = calc_hash(_36212, -5);
    _36212 = NOVALUE;
    Ref(_36213);
    Append(&_28known_files_hash_11574, _28known_files_hash_11574, _36213);
    DeRef(_36213);
    _36213 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_22209);
    DeRef(_real_name_72636);
    _real_name_72636 = _22209;

    /** main.e:57			finished_files &= 0*/
    Append(&_28finished_files_11575, _28finished_files_11575, 0);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36216 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36216 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36216;
    _36217 = MAKE_SEQ(_1);
    _36216 = NOVALUE;
    RefDS(_36217);
    Append(&_28file_include_depend_11576, _28file_include_depend_11576, _36217);
    DeRefDS(_36217);
    _36217 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_72636);
    DeRef(_36204);
    _36204 = NOVALUE;
    DeRef(_36208);
    _36208 = NOVALUE;
    return 5555;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:63			src_name = match_replace("/", src_name, "\\")*/
    RefDS(_23785);
    RefDS(_47src_name_50000);
    RefDS(_36219);
    _0 = _14match_replace(_23785, _47src_name_50000, _36219, 0);
    DeRefDS(_47src_name_50000);
    _47src_name_50000 = _0;

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_47src_name_50000)){
            _36221 = SEQ_PTR(_47src_name_50000)->length;
    }
    else {
        _36221 = 1;
    }
    {
        object _p_72679;
        _p_72679 = _36221;
L4: 
        if (_p_72679 < 1){
            goto L5; // [165] 229
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_47src_name_50000);
        _36222 = (object)*(((s1_ptr)_2)->base + _p_72679);
        if (binary_op_a(NOTEQ, _36222, 46)){
            _36222 = NOVALUE;
            goto L6; // [180] 198
        }
        _36222 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_72639 = _9TRUE_441;

        /** main.e:69			   exit*/
        goto L5; // [193] 229
        goto L7; // [195] 222
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_47src_name_50000);
        _36224 = (object)*(((s1_ptr)_2)->base + _p_72679);
        _36225 = find_from(_36224, _44SLASH_CHARS_20736, 1);
        _36224 = NOVALUE;
        if (_36225 == 0)
        {
            _36225 = NOVALUE;
            goto L8; // [213] 221
        }
        else{
            _36225 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [218] 229
L8: 
L7: 

        /** main.e:73		end for*/
        _p_72679 = _p_72679 + -1;
        goto L4; // [224] 172
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_72639 != 0)
    goto L9; // [231] 336

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_22209);
    Append(&_28known_files_11573, _28known_files_11573, _22209);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _36228 = 4;
    {
        object _i_72698;
        _i_72698 = 1;
LA: 
        if (_i_72698 > 4){
            goto LB; // [251] 316
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_28known_files_11573)){
                _36229 = SEQ_PTR(_28known_files_11573)->length;
        }
        else {
            _36229 = 1;
        }
        _2 = (object)SEQ_PTR(_44DEFAULT_EXTS_20710);
        _36230 = (object)*(((s1_ptr)_2)->base + _i_72698);
        Concat((object_ptr)&_36231, _47src_name_50000, _36230);
        _36230 = NOVALUE;
        _2 = (object)SEQ_PTR(_28known_files_11573);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28known_files_11573 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _36229);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36231;
        if( _1 != _36231 ){
            DeRef(_1);
        }
        _36231 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_28known_files_11573)){
                _36232 = SEQ_PTR(_28known_files_11573)->length;
        }
        else {
            _36232 = 1;
        }
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _36233 = (object)*(((s1_ptr)_2)->base + _36232);
        Ref(_36233);
        _0 = _real_name_72636;
        _real_name_72636 = _46e_path_find(_36233);
        DeRef(_0);
        _36233 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _36235 = IS_SEQUENCE(_real_name_72636);
        if (_36235 == 0)
        {
            _36235 = NOVALUE;
            goto LC; // [301] 309
        }
        else{
            _36235 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [306] 316
LC: 

        /** main.e:88			end for*/
        _i_72698 = _i_72698 + 1;
        goto LA; // [311] 258
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _36236 = IS_ATOM(_real_name_72636);
    if (_36236 == 0)
    {
        _36236 = NOVALUE;
        goto LD; // [323] 372
    }
    else{
        _36236 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_72636);
    DeRef(_36204);
    _36204 = NOVALUE;
    DeRef(_36208);
    _36208 = NOVALUE;
    return -1;
    goto LD; // [333] 372
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_47src_name_50000);
    Append(&_28known_files_11573, _28known_files_11573, _47src_name_50000);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_47src_name_50000);
    _0 = _real_name_72636;
    _real_name_72636 = _46e_path_find(_47src_name_50000);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _36239 = IS_ATOM(_real_name_72636);
    if (_36239 == 0)
    {
        _36239 = NOVALUE;
        goto LE; // [361] 371
    }
    else{
        _36239 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_72636);
    DeRef(_36204);
    _36204 = NOVALUE;
    DeRef(_36208);
    _36208 = NOVALUE;
    return -1;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36240 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36240 = 1;
    }
    Ref(_real_name_72636);
    _36241 = _15canonical_path(_real_name_72636, 0, 2);
    _2 = (object)SEQ_PTR(_28known_files_11573);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28known_files_11573 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36240);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36241;
    if( _1 != _36241 ){
        DeRef(_1);
    }
    _36241 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36242 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36242 = 1;
    }
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _36243 = (object)*(((s1_ptr)_2)->base + _36242);
    _36244 = calc_hash(_36243, -5);
    _36243 = NOVALUE;
    Ref(_36244);
    Append(&_28known_files_hash_11574, _28known_files_hash_11574, _36244);
    DeRef(_36244);
    _36244 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_28finished_files_11575, _28finished_files_11575, 0);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36247 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36247 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36247;
    _36248 = MAKE_SEQ(_1);
    _36247 = NOVALUE;
    RefDS(_36248);
    Append(&_28file_include_depend_11576, _28file_include_depend_11576, _36248);
    DeRefDS(_36248);
    _36248 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_72636);
    _36250 = _15file_exists(_real_name_72636);
    if (_36250 == 0) {
        DeRef(_36250);
        _36250 = NOVALUE;
        goto LF; // [451] 475
    }
    else {
        if (!IS_ATOM_INT(_36250) && DBL_PTR(_36250)->dbl == 0.0){
            DeRef(_36250);
            _36250 = NOVALUE;
            goto LF; // [451] 475
        }
        DeRef(_36250);
        _36250 = NOVALUE;
    }
    DeRef(_36250);
    _36250 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_72636);
    _0 = _real_name_72636;
    _real_name_72636 = _63maybe_preprocess(_real_name_72636);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_72636);
    _fh_72637 = _28open_locked(_real_name_72636);
    if (!IS_ATOM_INT(_fh_72637)) {
        _1 = (object)(DBL_PTR(_fh_72637)->dbl);
        DeRefDS(_fh_72637);
        _fh_72637 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_72636);
    DeRef(_36204);
    _36204 = NOVALUE;
    DeRef(_36208);
    _36208 = NOVALUE;
    return _fh_72637;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_72636);
    DeRef(_36204);
    _36204 = NOVALUE;
    DeRef(_36208);
    _36208 = NOVALUE;
    return -1;
    ;
}


void _69main()
{
    object _argc_72767 = NOVALUE;
    object _argv_72768 = NOVALUE;
    object _36280 = NOVALUE;
    object _36279 = NOVALUE;
    object _36276 = NOVALUE;
    object _36274 = NOVALUE;
    object _36272 = NOVALUE;
    object _36271 = NOVALUE;
    object _36270 = NOVALUE;
    object _36269 = NOVALUE;
    object _36268 = NOVALUE;
    object _36267 = NOVALUE;
    object _36266 = NOVALUE;
    object _36265 = NOVALUE;
    object _36261 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_72768);
    _argv_72768 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_72768);
    _0 = _argv_72768;
    _argv_72768 = _2extract_options(_argv_72768);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_72768)){
            _argc_72767 = SEQ_PTR(_argv_72768)->length;
    }
    else {
        _argc_72767 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_72768);
    DeRef(_27Argv_20582);
    _27Argv_20582 = _argv_72768;

    /** main.e:140		Argc = argc*/
    _27Argc_20581 = _argc_72767;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_32097);
    DeRefi(_49TempErrName_49640);
    _49TempErrName_49640 = _32097;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_27TempWarningName_20585);
    _27TempWarningName_20585 = 2;

    /** main.e:144		display_warnings = 1*/
    _49display_warnings_49641 = 1;

    /** main.e:146		InitGlobals()*/
    _43InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_27TRANSLATE_20179 != 0) {
        _36261 = 1;
        goto L2; // [69] 79
    }
    _36261 = (_27BIND_20182 != 0);
L2: 
    if (_36261 != 0) {
        goto L3; // [79] 90
    }
    if (_27INTERPRET_20176 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _69GetSourceName();
    _27src_file_20693 = _0;
    if (!IS_ATOM_INT(_27src_file_20693)) {
        _1 = (object)(DBL_PTR(_27src_file_20693)->dbl);
        DeRefDS(_27src_file_20693);
        _27src_file_20693 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_27src_file_20693 != -1)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36265 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36265 = 1;
    }
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _36266 = (object)*(((s1_ptr)_2)->base + _36265);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36266);
    ((intptr_t*)_2)[1] = _36266;
    _36267 = MAKE_SEQ(_1);
    _36266 = NOVALUE;
    _36268 = _30GetMsgText(51, 0, _36267);
    _36267 = NOVALUE;
    _49screen_output(2, _36268);
    _36268 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _36269 = (_27batch_job_20584 == 0);
    if (_36269 == 0) {
        goto L6; // [147] 177
    }
    _36271 = (_27test_only_20583 == 0);
    if (_36271 == 0)
    {
        DeRef(_36271);
        _36271 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_36271);
        _36271 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_22209);
    _36272 = _30GetMsgText(277, 0, _22209);
    _38maybe_any_key(_36272, 2);
    _36272 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _49Cleanup(1);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_27src_file_20693 < 0)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _36274 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _36274 = 1;
    }
    DeRef(_27main_path_20692);
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _27main_path_20692 = (object)*(((s1_ptr)_2)->base + _36274);
    Ref(_27main_path_20692);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_27main_path_20692)){
            _36276 = SEQ_PTR(_27main_path_20692)->length;
    }
    else {
        _36276 = 1;
    }
    if (_36276 != 0)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_27main_path_20692, 46, 92);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _53InitSymTab();

    /** main.e:178		InitEmit()*/
    _45InitEmit();

    /** main.e:179		InitLex()*/
    _61InitLex();

    /** main.e:180		InitParser()*/
    _43InitParser();

    /** main.e:184		eu_namespace()*/
    _61eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:197		main_file()*/
    _61main_file();

    /** main.e:199		check_coverage()*/
    _50check_coverage();

    /** main.e:201		parser()*/
    _43parser();

    /** main.e:203		init_coverage()*/
    _50init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LB; // [289] 300
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LC; // [297] 387
LB: 

    /** main.e:209		elsif BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto LD; // [304] 314
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LC; // [311] 387
LD: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_27INTERPRET_20176 == 0) {
        goto LE; // [318] 386
    }
    _36280 = (_27test_only_20583 == 0);
    if (_36280 == 0)
    {
        DeRef(_36280);
        _36280 = NOVALUE;
        goto LE; // [328] 386
    }
    else{
        DeRef(_36280);
        _36280 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);

    /** main.e:216			while repl do*/
LE: 
LC: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _49Cleanup(0);

    /** main.e:226	end procedure*/
    DeRef(_argv_72768);
    DeRef(_36269);
    _36269 = NOVALUE;
    return;
    ;
}



// 0xEE81AA7D
