// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _64block_type_name(object _opcode_25496)
{
    object _14256 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_25496)) {
        _1 = (object)(DBL_PTR(_opcode_25496)->dbl);
        DeRefDS(_opcode_25496);
        _opcode_25496 = _1;
    }

    /** block.e:51		switch opcode do*/
    _0 = _opcode_25496;
    switch ( _0 ){ 

        /** block.e:52			case LOOP then*/
        case 422:

        /** block.e:53				return "LOOP"*/
        RefDS(_14254);
        return _14254;
        goto L1; // [20] 63

        /** block.e:54			case PROC then*/
        case 27:

        /** block.e:55				return "PROC"*/
        RefDS(_13161);
        return _13161;
        goto L1; // [32] 63

        /** block.e:56			case FUNC then*/
        case 501:

        /** block.e:57				return "FUNC"*/
        RefDS(_14255);
        return _14255;
        goto L1; // [44] 63

        /** block.e:58			case else*/
        default:

        /** block.e:59				return opnames[opcode]*/
        _2 = (object)SEQ_PTR(_60opnames_23263);
        _14256 = (object)*(((s1_ptr)_2)->base + _opcode_25496);
        RefDS(_14256);
        return _14256;
    ;}L1: 
    ;
}


void _64check_block(object _got_25512)
{
    object _expected_25513 = NOVALUE;
    object _14264 = NOVALUE;
    object _14263 = NOVALUE;
    object _14262 = NOVALUE;
    object _14258 = NOVALUE;
    object _14257 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:64		integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14257 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14257 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14258 = (object)*(((s1_ptr)_2)->base + _14257);
    _2 = (object)SEQ_PTR(_14258);
    _expected_25513 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_25513)){
        _expected_25513 = (object)DBL_PTR(_expected_25513)->dbl;
    }
    _14258 = NOVALUE;

    /** block.e:65		if got = FUNC then*/
    if (_got_25512 != 501)
    goto L1; // [24] 38

    /** block.e:66			got = PROC*/
    _got_25512 = 27;
L1: 

    /** block.e:68		if got != expected then*/
    if (_got_25512 == _expected_25513)
    goto L2; // [40] 66

    /** block.e:69			CompileErr( EXPECTED_END_OF_1_BLOCK_NOT_2, {block_type_name( expected ), block_type_name( got)} )*/
    _14262 = _64block_type_name(_expected_25513);
    _14263 = _64block_type_name(_got_25512);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14262;
    ((intptr_t *)_2)[2] = _14263;
    _14264 = MAKE_SEQ(_1);
    _14263 = NOVALUE;
    _14262 = NOVALUE;
    _49CompileErr(79, _14264, 0);
    _14264 = NOVALUE;
L2: 

    /** block.e:71	end procedure*/
    return;
    ;
}


void _64Block_var(object _sym_25531)
{
    object _block_25532 = NOVALUE;
    object _14285 = NOVALUE;
    object _14284 = NOVALUE;
    object _14283 = NOVALUE;
    object _14281 = NOVALUE;
    object _14280 = NOVALUE;
    object _14278 = NOVALUE;
    object _14277 = NOVALUE;
    object _14276 = NOVALUE;
    object _14275 = NOVALUE;
    object _14274 = NOVALUE;
    object _14273 = NOVALUE;
    object _14272 = NOVALUE;
    object _14270 = NOVALUE;
    object _14268 = NOVALUE;
    object _14267 = NOVALUE;
    object _14265 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_25531)) {
        _1 = (object)(DBL_PTR(_sym_25531)->dbl);
        DeRefDS(_sym_25531);
        _sym_25531 = _1;
    }

    /** block.e:75		sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14265 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14265 = 1;
    }
    DeRef(_block_25532);
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _block_25532 = (object)*(((s1_ptr)_2)->base + _14265);
    Ref(_block_25532);

    /** block.e:76		block_stack[$] = 0*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14267 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14267 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _2 = (object)(((s1_ptr)_2)->base + _14267);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** block.e:77		if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14268 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14268 = 1;
    }
    if (_14268 <= 1)
    goto L1; // [34] 58

    /** block.e:79			SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25531 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_block_25532);
    _14272 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14272);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_BLOCK_20229))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14272;
    if( _1 != _14272 ){
        DeRef(_1);
    }
    _14272 = NOVALUE;
    _14270 = NOVALUE;
L1: 

    /** block.e:82		if length(block[BLOCK_VARS]) then*/
    _2 = (object)SEQ_PTR(_block_25532);
    _14273 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14273)){
            _14274 = SEQ_PTR(_14273)->length;
    }
    else {
        _14274 = 1;
    }
    _14273 = NOVALUE;
    if (_14274 == 0)
    {
        _14274 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _14274 = NOVALUE;
    }

    /** block.e:83			SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25532);
    _14275 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14275)){
            _14276 = SEQ_PTR(_14275)->length;
    }
    else {
        _14276 = 1;
    }
    _2 = (object)SEQ_PTR(_14275);
    _14277 = (object)*(((s1_ptr)_2)->base + _14276);
    _14275 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14277))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14277)->dbl));
    else
    _3 = (object)(_14277 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25531;
    DeRef(_1);
    _14278 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** block.e:85			SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25532);
    _14280 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14280))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14280)->dbl));
    else
    _3 = (object)(_14280 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25531;
    DeRef(_1);
    _14281 = NOVALUE;
L3: 

    /** block.e:88		block[BLOCK_VARS] &= sym*/
    _2 = (object)SEQ_PTR(_block_25532);
    _14283 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_14283) && IS_ATOM(_sym_25531)) {
        Append(&_14284, _14283, _sym_25531);
    }
    else if (IS_ATOM(_14283) && IS_SEQUENCE(_sym_25531)) {
    }
    else {
        Concat((object_ptr)&_14284, _14283, _sym_25531);
        _14283 = NOVALUE;
    }
    _14283 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25532);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25532 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14284;
    if( _1 != _14284 ){
        DeRef(_1);
    }
    _14284 = NOVALUE;

    /** block.e:90		block_stack[$] = block*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14285 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14285 = 1;
    }
    RefDS(_block_25532);
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _2 = (object)(((s1_ptr)_2)->base + _14285);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _block_25532;
    DeRef(_1);

    /** block.e:91		ifdef BDEBUG then*/

    /** block.e:96	end procedure*/
    DeRefDS(_block_25532);
    _14280 = NOVALUE;
    _14277 = NOVALUE;
    _14273 = NOVALUE;
    return;
    ;
}


void _64NewBlock(object _opcode_25566, object _block_label_25567)
{
    object _block_25585 = NOVALUE;
    object _14299 = NOVALUE;
    object _14298 = NOVALUE;
    object _14297 = NOVALUE;
    object _14295 = NOVALUE;
    object _14293 = NOVALUE;
    object _14292 = NOVALUE;
    object _14290 = NOVALUE;
    object _14289 = NOVALUE;
    object _14287 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:101		SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _14287 = Repeat(0, _27SIZEOF_BLOCK_ENTRY_20341);
    RefDS(_14287);
    Append(&_28SymTab_11572, _28SymTab_11572, _14287);
    DeRefDS(_14287);
    _14287 = NOVALUE;

    /** block.e:102		SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _14289 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _14289 = 1;
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14289 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _14290 = NOVALUE;

    /** block.e:103		SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _14292 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _14292 = 1;
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14292 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRST_LINE_20234))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRST_LINE_20234)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRST_LINE_20234);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27gline_number_20576;
    DeRef(_1);
    _14293 = NOVALUE;

    /** block.e:105		sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _14295 = 6;
    DeRef(_block_25585);
    _block_25585 = Repeat(0, 6);
    _14295 = NOVALUE;

    /** block.e:106		block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _14297 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _14297 = 1;
    }
    _2 = (object)SEQ_PTR(_block_25585);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25585 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    *(intptr_t *)_2 = _14297;
    if( _1 != _14297 ){
    }
    _14297 = NOVALUE;

    /** block.e:107		block[BLOCK_OPCODE] = opcode*/
    _2 = (object)SEQ_PTR(_block_25585);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25585 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    *(intptr_t *)_2 = _opcode_25566;

    /** block.e:108		block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_25567);
    _2 = (object)SEQ_PTR(_block_25585);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25585 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    *(intptr_t *)_2 = _block_label_25567;

    /** block.e:109		block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _14298 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _14298 = 1;
    }
    _14299 = _14298 + 1;
    _14298 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25585);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25585 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14299;
    if( _1 != _14299 ){
        DeRef(_1);
    }
    _14299 = NOVALUE;

    /** block.e:110		block[BLOCK_VARS]   = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_block_25585);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25585 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** block.e:112		block_stack = append( block_stack, block )*/
    RefDS(_block_25585);
    Append(&_64block_stack_25485, _64block_stack_25485, _block_25585);

    /** block.e:113		current_block = length(SymTab)*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _64current_block_25492 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _64current_block_25492 = 1;
    }

    /** block.e:114	end procedure*/
    DeRefi(_block_label_25567);
    DeRefDS(_block_25585);
    return;
    ;
}


void _64Start_block(object _opcode_25598, object _block_label_25599)
{
    object _last_block_25601 = NOVALUE;
    object _label_name_25629 = NOVALUE;
    object _14321 = NOVALUE;
    object _14320 = NOVALUE;
    object _14319 = NOVALUE;
    object _14316 = NOVALUE;
    object _14315 = NOVALUE;
    object _14313 = NOVALUE;
    object _14312 = NOVALUE;
    object _14311 = NOVALUE;
    object _14310 = NOVALUE;
    object _14309 = NOVALUE;
    object _14306 = NOVALUE;
    object _14304 = NOVALUE;
    object _14303 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:120		symtab_index last_block = current_block*/
    _last_block_25601 = _64current_block_25492;

    /** block.e:121		if opcode = FUNC then*/
    if (_opcode_25598 != 501)
    goto L1; // [16] 30

    /** block.e:122			opcode = PROC*/
    _opcode_25598 = 27;
L1: 

    /** block.e:124		NewBlock( opcode, block_label )*/
    Ref(_block_label_25599);
    _64NewBlock(_opcode_25598, _block_label_25599);

    /** block.e:126		if find(opcode, RTN_TOKS) then*/
    _14303 = find_from(_opcode_25598, _29RTN_TOKS_12277, 1);
    if (_14303 == 0)
    {
        _14303 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _14303 = NOVALUE;
    }

    /** block.e:127			SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_25599))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25599)->dbl));
    else
    _3 = (object)(_block_label_25599 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_BLOCK_20229))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _64current_block_25492;
    DeRef(_1);
    _14304 = NOVALUE;

    /** block.e:128			SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25492 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_block_label_25599)){
        _14309 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25599)->dbl));
    }
    else{
        _14309 = (object)*(((s1_ptr)_2)->base + _block_label_25599);
    }
    _2 = (object)SEQ_PTR(_14309);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _14310 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _14310 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _14309 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_14310);
    ((intptr_t*)_2)[1] = _14310;
    _14311 = MAKE_SEQ(_1);
    _14310 = NOVALUE;
    _14312 = EPrintf(-9999999, _14308, _14311);
    DeRefDS(_14311);
    _14311 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NAME_20209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NAME_20209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14312;
    if( _1 != _14312 ){
        DeRef(_1);
    }
    _14312 = NOVALUE;
    _14306 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** block.e:129		elsif current_block then*/
    if (_64current_block_25492 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** block.e:135			SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25492 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_BLOCK_20229))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_BLOCK_20229)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_BLOCK_20229);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _last_block_25601;
    DeRef(_1);
    _14313 = NOVALUE;

    /** block.e:136			sequence label_name = ""*/
    RefDS(_5);
    DeRefi(_label_name_25629);
    _label_name_25629 = _5;

    /** block.e:137			if sequence(block_label) then*/
    _14315 = IS_SEQUENCE(_block_label_25599);
    if (_14315 == 0)
    {
        _14315 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _14315 = NOVALUE;
    }

    /** block.e:138				label_name = block_label*/
    Ref(_block_label_25599);
    DeRefDSi(_label_name_25629);
    _label_name_25629 = _block_label_25599;
L5: 

    /** block.e:141			SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25492 + ((s1_ptr)_2)->base);
    _14319 = _64block_type_name(_opcode_25598);
    RefDS(_label_name_25629);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14319;
    ((intptr_t *)_2)[2] = _label_name_25629;
    _14320 = MAKE_SEQ(_1);
    _14319 = NOVALUE;
    _14321 = EPrintf(-9999999, _14318, _14320);
    DeRefDS(_14320);
    _14320 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NAME_20209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NAME_20209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14321;
    if( _1 != _14321 ){
        DeRef(_1);
    }
    _14321 = NOVALUE;
    _14316 = NOVALUE;
L4: 
    DeRefi(_label_name_25629);
    _label_name_25629 = NOVALUE;
L3: 

    /** block.e:144		ifdef BDEBUG then*/

    /** block.e:153	end procedure*/
    DeRefi(_block_label_25599);
    return;
    ;
}


void _64block_label(object _label_name_25645)
{
    object _14335 = NOVALUE;
    object _14334 = NOVALUE;
    object _14333 = NOVALUE;
    object _14332 = NOVALUE;
    object _14331 = NOVALUE;
    object _14330 = NOVALUE;
    object _14328 = NOVALUE;
    object _14326 = NOVALUE;
    object _14325 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:157		block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14325 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14325 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _64block_stack_25485 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14325 + ((s1_ptr)_2)->base);
    RefDS(_label_name_25645);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _label_name_25645;
    DeRef(_1);
    _14326 = NOVALUE;

    /** block.e:158		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_64current_block_25492 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14330 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14330 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14331 = (object)*(((s1_ptr)_2)->base + _14330);
    _2 = (object)SEQ_PTR(_14331);
    _14332 = (object)*(((s1_ptr)_2)->base + 2);
    _14331 = NOVALUE;
    Ref(_14332);
    _14333 = _64block_type_name(_14332);
    _14332 = NOVALUE;
    RefDS(_label_name_25645);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14333;
    ((intptr_t *)_2)[2] = _label_name_25645;
    _14334 = MAKE_SEQ(_1);
    _14333 = NOVALUE;
    _14335 = EPrintf(-9999999, _14318, _14334);
    DeRefDS(_14334);
    _14334 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NAME_20209))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NAME_20209);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14335;
    if( _1 != _14335 ){
        DeRef(_1);
    }
    _14335 = NOVALUE;
    _14328 = NOVALUE;

    /** block.e:160	end procedure*/
    DeRefDS(_label_name_25645);
    return;
    ;
}


object _64pop_block()
{
    object _block_25664 = NOVALUE;
    object _block_vars_25677 = NOVALUE;
    object _14364 = NOVALUE;
    object _14362 = NOVALUE;
    object _14361 = NOVALUE;
    object _14360 = NOVALUE;
    object _14359 = NOVALUE;
    object _14357 = NOVALUE;
    object _14356 = NOVALUE;
    object _14355 = NOVALUE;
    object _14354 = NOVALUE;
    object _14353 = NOVALUE;
    object _14352 = NOVALUE;
    object _14351 = NOVALUE;
    object _14350 = NOVALUE;
    object _14349 = NOVALUE;
    object _14348 = NOVALUE;
    object _14344 = NOVALUE;
    object _14343 = NOVALUE;
    object _14341 = NOVALUE;
    object _14340 = NOVALUE;
    object _14338 = NOVALUE;
    object _14336 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:164		if not length(block_stack) then*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14336 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14336 = 1;
    }
    if (_14336 != 0)
    goto L1; // [8] 18
    _14336 = NOVALUE;

    /** block.e:165			return 0*/
    DeRef(_block_25664);
    DeRef(_block_vars_25677);
    return 0;
L1: 

    /** block.e:168		sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14338 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14338 = 1;
    }
    DeRef(_block_25664);
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _block_25664 = (object)*(((s1_ptr)_2)->base + _14338);
    Ref(_block_25664);

    /** block.e:169		block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14340 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14340 = 1;
    }
    _14341 = _14340 - 1;
    _14340 = NOVALUE;
    rhs_slice_target = (object_ptr)&_64block_stack_25485;
    RHS_Slice(_64block_stack_25485, 1, _14341);

    /** block.e:170		SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (object)SEQ_PTR(_block_25664);
    _14343 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14343))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14343)->dbl));
    else
    _3 = (object)(_14343 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LAST_LINE_20239))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LAST_LINE_20239)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LAST_LINE_20239);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27gline_number_20576;
    DeRef(_1);
    _14344 = NOVALUE;

    /** block.e:172		ifdef BDEBUG then*/

    /** block.e:177		sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_25677);
    _2 = (object)SEQ_PTR(_block_25664);
    _block_vars_25677 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_25677);

    /** block.e:178		for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_25677)){
            _14348 = SEQ_PTR(_block_vars_25677)->length;
    }
    else {
        _14348 = 1;
    }
    {
        object _sx_25680;
        _sx_25680 = 1;
L2: 
        if (_sx_25680 > _14348){
            goto L3; // [83] 172
        }

        /** block.e:180			if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (object)SEQ_PTR(_block_vars_25677);
        _14349 = (object)*(((s1_ptr)_2)->base + _sx_25680);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_14349)){
            _14350 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14349)->dbl));
        }
        else{
            _14350 = (object)*(((s1_ptr)_2)->base + _14349);
        }
        _2 = (object)SEQ_PTR(_14350);
        _14351 = (object)*(((s1_ptr)_2)->base + 3);
        _14350 = NOVALUE;
        if (IS_ATOM_INT(_14351)) {
            _14352 = (_14351 == 1);
        }
        else {
            _14352 = binary_op(EQUALS, _14351, 1);
        }
        _14351 = NOVALUE;
        if (IS_ATOM_INT(_14352)) {
            if (_14352 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_14352)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (object)SEQ_PTR(_block_vars_25677);
        _14354 = (object)*(((s1_ptr)_2)->base + _sx_25680);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_14354)){
            _14355 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14354)->dbl));
        }
        else{
            _14355 = (object)*(((s1_ptr)_2)->base + _14354);
        }
        _2 = (object)SEQ_PTR(_14355);
        _14356 = (object)*(((s1_ptr)_2)->base + 4);
        _14355 = NOVALUE;
        if (IS_ATOM_INT(_14356)) {
            _14357 = (_14356 <= 5);
        }
        else {
            _14357 = binary_op(LESSEQ, _14356, 5);
        }
        _14356 = NOVALUE;
        if (_14357 == 0) {
            DeRef(_14357);
            _14357 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_14357) && DBL_PTR(_14357)->dbl == 0.0){
                DeRef(_14357);
                _14357 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_14357);
            _14357 = NOVALUE;
        }
        DeRef(_14357);
        _14357 = NOVALUE;

        /** block.e:182				ifdef BDEBUG then*/

        /** block.e:187				Hide( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25677);
        _14359 = (object)*(((s1_ptr)_2)->base + _sx_25680);
        Ref(_14359);
        _53Hide(_14359);
        _14359 = NOVALUE;

        /** block.e:188				LintCheck( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25677);
        _14360 = (object)*(((s1_ptr)_2)->base + _sx_25680);
        Ref(_14360);
        _53LintCheck(_14360);
        _14360 = NOVALUE;
L4: 

        /** block.e:191		end for*/
        _sx_25680 = _sx_25680 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** block.e:213		current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14361 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14361 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14362 = (object)*(((s1_ptr)_2)->base + _14361);
    _2 = (object)SEQ_PTR(_14362);
    _64current_block_25492 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_64current_block_25492)){
        _64current_block_25492 = (object)DBL_PTR(_64current_block_25492)->dbl;
    }
    _14362 = NOVALUE;

    /** block.e:214		return block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_block_25664);
    _14364 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14364);
    DeRefDS(_block_25664);
    DeRef(_block_vars_25677);
    _14343 = NOVALUE;
    DeRef(_14352);
    _14352 = NOVALUE;
    DeRef(_14341);
    _14341 = NOVALUE;
    _14354 = NOVALUE;
    _14349 = NOVALUE;
    return _14364;
    ;
}


object _64top_block(object _offset_25709)
{
    object _14372 = NOVALUE;
    object _14371 = NOVALUE;
    object _14370 = NOVALUE;
    object _14369 = NOVALUE;
    object _14368 = NOVALUE;
    object _14367 = NOVALUE;
    object _14365 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:219		if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14365 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14365 = 1;
    }
    if (_offset_25709 < _14365)
    goto L1; // [10] 35

    /** block.e:220			CompileErr(LEAVING_TOO_MANY_BLOCKS_1__2, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14367 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14367 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _offset_25709;
    ((intptr_t *)_2)[2] = _14367;
    _14368 = MAKE_SEQ(_1);
    _14367 = NOVALUE;
    _49CompileErr(107, _14368, 0);
    _14368 = NOVALUE;
    goto L2; // [32] 59
L1: 

    /** block.e:222			return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14369 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14369 = 1;
    }
    _14370 = _14369 - _offset_25709;
    _14369 = NOVALUE;
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14371 = (object)*(((s1_ptr)_2)->base + _14370);
    _2 = (object)SEQ_PTR(_14371);
    _14372 = (object)*(((s1_ptr)_2)->base + 1);
    _14371 = NOVALUE;
    Ref(_14372);
    _14370 = NOVALUE;
    return _14372;
L2: 
    ;
}


void _64End_block(object _opcode_25724)
{
    object _ix_25735 = NOVALUE;
    object _14380 = NOVALUE;
    object _14377 = NOVALUE;
    object _14376 = NOVALUE;
    object _14375 = NOVALUE;
    object _14374 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:229		if opcode = FUNC then*/

    /** block.e:232		check_block( opcode )*/
    _64check_block(_opcode_25724);

    /** block.e:233		if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14374 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14374 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14375 = (object)*(((s1_ptr)_2)->base + _14374);
    _2 = (object)SEQ_PTR(_14375);
    _14376 = (object)*(((s1_ptr)_2)->base + 6);
    _14375 = NOVALUE;
    if (IS_SEQUENCE(_14376)){
            _14377 = SEQ_PTR(_14376)->length;
    }
    else {
        _14377 = 1;
    }
    _14376 = NOVALUE;
    if (_14377 != 0)
    goto L1; // [44] 64
    _14377 = NOVALUE;

    /** block.e:234			integer ix = 1*/
    _ix_25735 = 1;

    /** block.e:235			ix = pop_block()*/
    _ix_25735 = _64pop_block();
    if (!IS_ATOM_INT(_ix_25735)) {
        _1 = (object)(DBL_PTR(_ix_25735)->dbl);
        DeRefDS(_ix_25735);
        _ix_25735 = _1;
    }
    goto L2; // [61] 80
L1: 

    /** block.e:237			Push( pop_block() )*/
    _14380 = _64pop_block();
    _45Push(_14380);
    _14380 = NOVALUE;

    /** block.e:238			emit_op( EXIT_BLOCK )*/
    _45emit_op(206);
L2: 

    /** block.e:241	end procedure*/
    _14376 = NOVALUE;
    return;
    ;
}


object _64End_inline_block(object _opcode_25744)
{
    object _14387 = NOVALUE;
    object _14386 = NOVALUE;
    object _14385 = NOVALUE;
    object _14384 = NOVALUE;
    object _14383 = NOVALUE;
    object _14382 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:246		if opcode = FUNC then*/

    /** block.e:249		if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14382 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14382 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14383 = (object)*(((s1_ptr)_2)->base + _14382);
    _2 = (object)SEQ_PTR(_14383);
    _14384 = (object)*(((s1_ptr)_2)->base + 6);
    _14383 = NOVALUE;
    if (IS_SEQUENCE(_14384)){
            _14385 = SEQ_PTR(_14384)->length;
    }
    else {
        _14385 = 1;
    }
    _14384 = NOVALUE;
    if (_14385 == 0)
    {
        _14385 = NOVALUE;
        goto L1; // [39] 60
    }
    else{
        _14385 = NOVALUE;
    }

    /** block.e:250			return { EXIT_BLOCK, pop_block() }*/
    _14386 = _64pop_block();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206;
    ((intptr_t *)_2)[2] = _14386;
    _14387 = MAKE_SEQ(_1);
    _14386 = NOVALUE;
    _14384 = NOVALUE;
    return _14387;
    goto L2; // [57] 72
L1: 

    /** block.e:252			Drop_block( opcode )*/
    _64Drop_block(_opcode_25744);

    /** block.e:253			return {}*/
    RefDS(_5);
    _14384 = NOVALUE;
    DeRef(_14387);
    _14387 = NOVALUE;
    return _5;
L2: 
    ;
}


void _64Sibling_block(object _opcode_25761)
{
    object _0, _1, _2;
    

    /** block.e:261		End_block( opcode )*/
    _64End_block(_opcode_25761);

    /** block.e:262		Start_block( opcode )*/
    _64Start_block(_opcode_25761, 0);

    /** block.e:263	end procedure*/
    return;
    ;
}


void _64Leave_block(object _offset_25764)
{
    object _14393 = NOVALUE;
    object _14392 = NOVALUE;
    object _14391 = NOVALUE;
    object _14390 = NOVALUE;
    object _14389 = NOVALUE;
    object _14388 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_25764)) {
        _1 = (object)(DBL_PTR(_offset_25764)->dbl);
        DeRefDS(_offset_25764);
        _offset_25764 = _1;
    }

    /** block.e:268		if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14388 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14388 = 1;
    }
    _14389 = _14388 - _offset_25764;
    _14388 = NOVALUE;
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14390 = (object)*(((s1_ptr)_2)->base + _14389);
    _2 = (object)SEQ_PTR(_14390);
    _14391 = (object)*(((s1_ptr)_2)->base + 6);
    _14390 = NOVALUE;
    if (IS_SEQUENCE(_14391)){
            _14392 = SEQ_PTR(_14391)->length;
    }
    else {
        _14392 = 1;
    }
    _14391 = NOVALUE;
    if (_14392 == 0)
    {
        _14392 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _14392 = NOVALUE;
    }

    /** block.e:269			Push( top_block( offset ) )*/
    _14393 = _64top_block(_offset_25764);
    _45Push(_14393);
    _14393 = NOVALUE;

    /** block.e:270			emit_op( EXIT_BLOCK )*/
    _45emit_op(206);
L1: 

    /** block.e:272	end procedure*/
    DeRef(_14389);
    _14389 = NOVALUE;
    _14391 = NOVALUE;
    return;
    ;
}


void _64Leave_blocks(object _blocks_25784, object _block_type_25785)
{
    object _bx_25786 = NOVALUE;
    object _Block_opcode_3__tmp_at29_25793 = NOVALUE;
    object _Block_opcode_2__tmp_at29_25792 = NOVALUE;
    object _Block_opcode_1__tmp_at29_25791 = NOVALUE;
    object _Block_opcode_inlined_Block_opcode_at_29_25790 = NOVALUE;
    object _14406 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_25784)) {
        _1 = (object)(DBL_PTR(_blocks_25784)->dbl);
        DeRefDS(_blocks_25784);
        _blocks_25784 = _1;
    }

    /** block.e:284		integer bx = 0*/
    _bx_25786 = 0;

    /** block.e:285		while blocks do*/
L1: 
    if (_blocks_25784 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** block.e:286			Leave_block( bx )*/
    _64Leave_block(_bx_25786);

    /** block.e:288			if block_type then*/
    if (_block_type_25785 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** block.e:289				switch Block_opcode( bx ) do*/

    /** block.e:276		return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _Block_opcode_1__tmp_at29_25791 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_25791 = 1;
    }
    _Block_opcode_2__tmp_at29_25792 = _Block_opcode_1__tmp_at29_25791 - _bx_25786;
    DeRef(_Block_opcode_3__tmp_at29_25793);
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _Block_opcode_3__tmp_at29_25793 = (object)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_25792);
    Ref(_Block_opcode_3__tmp_at29_25793);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_25790);
    _2 = (object)SEQ_PTR(_Block_opcode_3__tmp_at29_25793);
    _Block_opcode_inlined_Block_opcode_at_29_25790 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_25790);
    DeRef(_Block_opcode_3__tmp_at29_25793);
    _Block_opcode_3__tmp_at29_25793 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_25790) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_25790)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25790)->dbl != (eudouble) ((object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25790)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25790)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_25790;
    };
    switch ( _0 ){ 

        /** block.e:290					case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** block.e:291						if block_type = LOOP_BLOCK then*/
        if (_block_type_25785 != 1)
        goto L5; // [67] 108

        /** block.e:292							blocks -= 1*/
        _blocks_25784 = _blocks_25784 - 1;
        goto L5; // [78] 108

        /** block.e:294					case else*/
        default:
L4: 

        /** block.e:295						if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_25785 != 2)
        goto L6; // [86] 97

        /** block.e:296							blocks -= 1*/
        _blocks_25784 = _blocks_25784 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** block.e:300				blocks -= 1*/
    _blocks_25784 = _blocks_25784 - 1;
L5: 

    /** block.e:302			bx += 1*/
    _bx_25786 = _bx_25786 + 1;

    /** block.e:303		end while*/
    goto L1; // [116] 15
L2: 

    /** block.e:304		for i = 0 to blocks - 1 do*/
    _14406 = _blocks_25784 - 1;
    if ((object)((uintptr_t)_14406 +(uintptr_t) HIGH_BITS) >= 0){
        _14406 = NewDouble((eudouble)_14406);
    }
    {
        object _i_25811;
        _i_25811 = 0;
L7: 
        if (binary_op_a(GREATER, _i_25811, _14406)){
            goto L8; // [125] 144
        }

        /** block.e:305			Leave_block( i )*/
        Ref(_i_25811);
        _64Leave_block(_i_25811);

        /** block.e:306		end for*/
        _0 = _i_25811;
        if (IS_ATOM_INT(_i_25811)) {
            _i_25811 = _i_25811 + 1;
            if ((object)((uintptr_t)_i_25811 +(uintptr_t) HIGH_BITS) >= 0){
                _i_25811 = NewDouble((eudouble)_i_25811);
            }
        }
        else {
            _i_25811 = binary_op_a(PLUS, _i_25811, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_25811);
    }

    /** block.e:307	end procedure*/
    DeRef(_14406);
    _14406 = NOVALUE;
    return;
    ;
}


void _64Drop_block(object _opcode_25815)
{
    object _x_25817 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:311		check_block( opcode )*/
    _64check_block(_opcode_25815);

    /** block.e:312		symtab_index x = pop_block()*/
    _x_25817 = _64pop_block();
    if (!IS_ATOM_INT(_x_25817)) {
        _1 = (object)(DBL_PTR(_x_25817)->dbl);
        DeRefDS(_x_25817);
        _x_25817 = _1;
    }

    /** block.e:313	end procedure*/
    return;
    ;
}


void _64Pop_block_var()
{
    object _sym_25822 = NOVALUE;
    object _block_sym_25829 = NOVALUE;
    object _14434 = NOVALUE;
    object _14433 = NOVALUE;
    object _14432 = NOVALUE;
    object _14431 = NOVALUE;
    object _14430 = NOVALUE;
    object _14429 = NOVALUE;
    object _14428 = NOVALUE;
    object _14427 = NOVALUE;
    object _14425 = NOVALUE;
    object _14424 = NOVALUE;
    object _14422 = NOVALUE;
    object _14421 = NOVALUE;
    object _14419 = NOVALUE;
    object _14416 = NOVALUE;
    object _14414 = NOVALUE;
    object _14413 = NOVALUE;
    object _14411 = NOVALUE;
    object _14410 = NOVALUE;
    object _14409 = NOVALUE;
    object _14408 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:316		symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14408 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14408 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14409 = (object)*(((s1_ptr)_2)->base + _14408);
    _2 = (object)SEQ_PTR(_14409);
    _14410 = (object)*(((s1_ptr)_2)->base + 6);
    _14409 = NOVALUE;
    if (IS_SEQUENCE(_14410)){
            _14411 = SEQ_PTR(_14410)->length;
    }
    else {
        _14411 = 1;
    }
    _2 = (object)SEQ_PTR(_14410);
    _sym_25822 = (object)*(((s1_ptr)_2)->base + _14411);
    if (!IS_ATOM_INT(_sym_25822)){
        _sym_25822 = (object)DBL_PTR(_sym_25822)->dbl;
    }
    _14410 = NOVALUE;

    /** block.e:317		symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14413 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14413 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14414 = (object)*(((s1_ptr)_2)->base + _14413);
    _2 = (object)SEQ_PTR(_14414);
    _block_sym_25829 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_25829)){
        _block_sym_25829 = (object)DBL_PTR(_block_sym_25829)->dbl;
    }
    _14414 = NOVALUE;

    /** block.e:318		while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _14416 = _53sym_next_in_block(_block_sym_25829);
    if (binary_op_a(EQUALS, _14416, _sym_25822)){
        DeRef(_14416);
        _14416 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_14416);
    _14416 = NOVALUE;

    /** block.e:319			block_sym = sym_next_in_block( block_sym )*/
    _block_sym_25829 = _53sym_next_in_block(_block_sym_25829);
    if (!IS_ATOM_INT(_block_sym_25829)) {
        _1 = (object)(DBL_PTR(_block_sym_25829)->dbl);
        DeRefDS(_block_sym_25829);
        _block_sym_25829 = _1;
    }

    /** block.e:320		end while*/
    goto L1; // [65] 47
L2: 

    /** block.e:322		SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_block_sym_25829 + ((s1_ptr)_2)->base);
    _14421 = _53sym_next_in_block(_sym_25822);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14421;
    if( _1 != _14421 ){
        DeRef(_1);
    }
    _14421 = NOVALUE;
    _14419 = NOVALUE;

    /** block.e:323		SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25822 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NEXT_IN_BLOCK_20201))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NEXT_IN_BLOCK_20201)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NEXT_IN_BLOCK_20201);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _14422 = NOVALUE;

    /** block.e:325		block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14424 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14424 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _64block_stack_25485 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14424 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14427 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14427 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14428 = (object)*(((s1_ptr)_2)->base + _14427);
    _2 = (object)SEQ_PTR(_14428);
    _14429 = (object)*(((s1_ptr)_2)->base + 6);
    _14428 = NOVALUE;
    if (IS_SEQUENCE(_64block_stack_25485)){
            _14430 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _14430 = 1;
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14431 = (object)*(((s1_ptr)_2)->base + _14430);
    _2 = (object)SEQ_PTR(_14431);
    _14432 = (object)*(((s1_ptr)_2)->base + 6);
    _14431 = NOVALUE;
    if (IS_SEQUENCE(_14432)){
            _14433 = SEQ_PTR(_14432)->length;
    }
    else {
        _14433 = 1;
    }
    _14432 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_14429);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14433)) ? _14433 : (object)(DBL_PTR(_14433)->dbl);
        int stop = (IS_ATOM_INT(_14433)) ? _14433 : (object)(DBL_PTR(_14433)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_14429);
            DeRef(_14434);
            _14434 = _14429;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_14429), start, &_14434 );
            }
            else Tail(SEQ_PTR(_14429), stop+1, &_14434);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_14429), start, &_14434);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_14434);
            _14434 = _1;
        }
    }
    _14429 = NOVALUE;
    _14433 = NOVALUE;
    _14433 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14434;
    if( _1 != _14434 ){
        DeRef(_1);
    }
    _14434 = NOVALUE;
    _14425 = NOVALUE;

    /** block.e:327	end procedure*/
    _14432 = NOVALUE;
    return;
    ;
}


void _64Goto_block(object _from_block_25863, object _to_block_25865, object _pc_25866)
{
    object _code_25867 = NOVALUE;
    object _next_block_25869 = NOVALUE;
    object _14445 = NOVALUE;
    object _14442 = NOVALUE;
    object _14441 = NOVALUE;
    object _14440 = NOVALUE;
    object _14439 = NOVALUE;
    object _14438 = NOVALUE;
    object _14437 = NOVALUE;
    object _14436 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_25863)) {
        _1 = (object)(DBL_PTR(_from_block_25863)->dbl);
        DeRefDS(_from_block_25863);
        _from_block_25863 = _1;
    }
    if (!IS_ATOM_INT(_to_block_25865)) {
        _1 = (object)(DBL_PTR(_to_block_25865)->dbl);
        DeRefDS(_to_block_25865);
        _to_block_25865 = _1;
    }
    if (!IS_ATOM_INT(_pc_25866)) {
        _1 = (object)(DBL_PTR(_pc_25866)->dbl);
        DeRefDS(_pc_25866);
        _pc_25866 = _1;
    }

    /** block.e:330		sequence code = {}*/
    RefDS(_5);
    DeRefi(_code_25867);
    _code_25867 = _5;

    /** block.e:331		symtab_index next_block = sym_block( from_block )*/
    _next_block_25869 = _53sym_block(_from_block_25863);
    if (!IS_ATOM_INT(_next_block_25869)) {
        _1 = (object)(DBL_PTR(_next_block_25869)->dbl);
        DeRefDS(_next_block_25869);
        _next_block_25869 = _1;
    }

    /** block.e:332		while next_block */
L1: 
    if (_next_block_25869 == 0) {
        _14436 = 0;
        goto L2; // [27] 39
    }
    _14437 = (_from_block_25863 != _to_block_25865);
    _14436 = (_14437 != 0);
L2: 
    if (_14436 == 0) {
        goto L3; // [39] 93
    }
    _14439 = _53sym_token(_next_block_25869);
    _14440 = find_from(_14439, _29RTN_TOKS_12277, 1);
    DeRef(_14439);
    _14439 = NOVALUE;
    _14441 = (_14440 == 0);
    _14440 = NOVALUE;
    if (_14441 == 0)
    {
        DeRef(_14441);
        _14441 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_14441);
        _14441 = NOVALUE;
    }

    /** block.e:335			code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206;
    ((intptr_t *)_2)[2] = _from_block_25863;
    _14442 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_25867, _code_25867, _14442);
    DeRefDS(_14442);
    _14442 = NOVALUE;

    /** block.e:336			from_block = next_block*/
    _from_block_25863 = _next_block_25869;

    /** block.e:337			next_block = sym_block( next_block )*/
    _next_block_25869 = _53sym_block(_next_block_25869);
    if (!IS_ATOM_INT(_next_block_25869)) {
        _1 = (object)(DBL_PTR(_next_block_25869)->dbl);
        DeRefDS(_next_block_25869);
        _next_block_25869 = _1;
    }

    /** block.e:338		end while*/
    goto L1; // [90] 27
L3: 

    /** block.e:340		if length(code) then*/
    if (IS_SEQUENCE(_code_25867)){
            _14445 = SEQ_PTR(_code_25867)->length;
    }
    else {
        _14445 = 1;
    }
    if (_14445 == 0)
    {
        _14445 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _14445 = NOVALUE;
    }

    /** block.e:341			if pc then*/
    if (_pc_25866 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** block.e:342				insert_code( code, pc )*/
    RefDS(_code_25867);
    _65insert_code(_code_25867, _pc_25866);
    goto L6; // [112] 126
L5: 

    /** block.e:344				Code &= code*/
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _code_25867);
L6: 
L4: 

    /** block.e:348	end procedure*/
    DeRefi(_code_25867);
    DeRef(_14437);
    _14437 = NOVALUE;
    return;
    ;
}


object _64Least_block()
{
    object _ix_25897 = NOVALUE;
    object _sub_block_25900 = NOVALUE;
    object _14459 = NOVALUE;
    object _14458 = NOVALUE;
    object _14456 = NOVALUE;
    object _14455 = NOVALUE;
    object _14454 = NOVALUE;
    object _14453 = NOVALUE;
    object _14452 = NOVALUE;
    object _14451 = NOVALUE;
    object _14450 = NOVALUE;
    object _14449 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:358		integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_64block_stack_25485)){
            _ix_25897 = SEQ_PTR(_64block_stack_25485)->length;
    }
    else {
        _ix_25897 = 1;
    }

    /** block.e:359		symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_25900 = _53sym_block(_27CurrentSub_20579);
    if (!IS_ATOM_INT(_sub_block_25900)) {
        _1 = (object)(DBL_PTR(_sub_block_25900)->dbl);
        DeRefDS(_sub_block_25900);
        _sub_block_25900 = _1;
    }

    /** block.e:360		while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14449 = (object)*(((s1_ptr)_2)->base + _ix_25897);
    _2 = (object)SEQ_PTR(_14449);
    _14450 = (object)*(((s1_ptr)_2)->base + 6);
    _14449 = NOVALUE;
    if (IS_SEQUENCE(_14450)){
            _14451 = SEQ_PTR(_14450)->length;
    }
    else {
        _14451 = 1;
    }
    _14450 = NOVALUE;
    _14452 = (_14451 == 0);
    _14451 = NOVALUE;
    if (_14452 == 0) {
        goto L2; // [39] 72
    }
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14454 = (object)*(((s1_ptr)_2)->base + _ix_25897);
    _2 = (object)SEQ_PTR(_14454);
    _14455 = (object)*(((s1_ptr)_2)->base + 1);
    _14454 = NOVALUE;
    if (IS_ATOM_INT(_14455)) {
        _14456 = (_14455 != _sub_block_25900);
    }
    else {
        _14456 = binary_op(NOTEQ, _14455, _sub_block_25900);
    }
    _14455 = NOVALUE;
    if (_14456 <= 0) {
        if (_14456 == 0) {
            DeRef(_14456);
            _14456 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_14456) && DBL_PTR(_14456)->dbl == 0.0){
                DeRef(_14456);
                _14456 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_14456);
            _14456 = NOVALUE;
        }
    }
    DeRef(_14456);
    _14456 = NOVALUE;

    /** block.e:362			ix -= 1	*/
    _ix_25897 = _ix_25897 - 1;

    /** block.e:363		end while*/
    goto L1; // [69] 23
L2: 

    /** block.e:364		return block_stack[ix][BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_64block_stack_25485);
    _14458 = (object)*(((s1_ptr)_2)->base + _ix_25897);
    _2 = (object)SEQ_PTR(_14458);
    _14459 = (object)*(((s1_ptr)_2)->base + 1);
    _14458 = NOVALUE;
    Ref(_14459);
    _14450 = NOVALUE;
    DeRef(_14452);
    _14452 = NOVALUE;
    return _14459;
    ;
}



// 0xF81E31C6
