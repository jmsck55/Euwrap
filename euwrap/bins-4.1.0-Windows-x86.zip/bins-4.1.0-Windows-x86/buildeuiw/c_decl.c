// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _57get_eucompiledir()
{
    object _x_42959 = NOVALUE;
    object _22576 = NOVALUE;
    object _22572 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42959);
    _x_42959 = EGetEnv(_22570);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22572 = _28is_eudir_from_cmdline();
    if (_22572 == 0) {
        DeRef(_22572);
        _22572 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22572) && DBL_PTR(_22572)->dbl == 0.0){
            DeRef(_22572);
            _22572 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22572);
        _22572 = NOVALUE;
    }
    DeRef(_22572);
    _22572 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42959;
    _x_42959 = _28get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42959 == -1)
    _22576 = 1;
    else if (IS_ATOM_INT(_x_42959) && IS_ATOM_INT(-1))
    _22576 = 0;
    else
    _22576 = (compare(_x_42959, -1) == 0);
    if (_22576 == 0)
    {
        _22576 = NOVALUE;
        goto L2; // [28] 37
    }
    else{
        _22576 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42959;
    _x_42959 = _28get_eudir();
    DeRef(_0);
L2: 

    /** c_decl.e:156		return x*/
    return _x_42959;
    ;
}


void _57NewBB(object _a_call_42975, object _mask_42976, object _sub_42978)
{
    object _s_42980 = NOVALUE;
    object _22609 = NOVALUE;
    object _22608 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22603 = NOVALUE;
    object _22602 = NOVALUE;
    object _22601 = NOVALUE;
    object _22600 = NOVALUE;
    object _22599 = NOVALUE;
    object _22598 = NOVALUE;
    object _22597 = NOVALUE;
    object _22596 = NOVALUE;
    object _22595 = NOVALUE;
    object _22594 = NOVALUE;
    object _22593 = NOVALUE;
    object _22592 = NOVALUE;
    object _22591 = NOVALUE;
    object _22590 = NOVALUE;
    object _22589 = NOVALUE;
    object _22588 = NOVALUE;
    object _22587 = NOVALUE;
    object _22586 = NOVALUE;
    object _22585 = NOVALUE;
    object _22584 = NOVALUE;
    object _22583 = NOVALUE;
    object _22582 = NOVALUE;
    object _22581 = NOVALUE;
    object _22579 = NOVALUE;
    object _22578 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42976)) {
        _1 = (object)(DBL_PTR(_mask_42976)->dbl);
        DeRefDS(_mask_42976);
        _mask_42976 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42975 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22578 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22578 = 1;
    }
    {
        object _i_42983;
        _i_42983 = 1;
L2: 
        if (_i_42983 > _22578){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22579 = (object)*(((s1_ptr)_2)->base + _i_42983);
        _2 = (object)SEQ_PTR(_22579);
        _s_42980 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_42980)){
            _s_42980 = (object)DBL_PTR(_s_42980)->dbl;
        }
        _22579 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22581 = (object)*(((s1_ptr)_2)->base + _s_42980);
        _2 = (object)SEQ_PTR(_22581);
        _22582 = (object)*(((s1_ptr)_2)->base + 3);
        _22581 = NOVALUE;
        if (IS_ATOM_INT(_22582)) {
            _22583 = (_22582 == 1);
        }
        else {
            _22583 = binary_op(EQUALS, _22582, 1);
        }
        _22582 = NOVALUE;
        if (IS_ATOM_INT(_22583)) {
            if (_22583 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22583)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22585 = (object)*(((s1_ptr)_2)->base + _s_42980);
        _2 = (object)SEQ_PTR(_22585);
        _22586 = (object)*(((s1_ptr)_2)->base + 4);
        _22585 = NOVALUE;
        if (IS_ATOM_INT(_22586)) {
            _22587 = (_22586 == 6);
        }
        else {
            _22587 = binary_op(EQUALS, _22586, 6);
        }
        _22586 = NOVALUE;
        if (IS_ATOM_INT(_22587)) {
            if (_22587 != 0) {
                DeRef(_22588);
                _22588 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22587)->dbl != 0.0) {
                DeRef(_22588);
                _22588 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22589 = (object)*(((s1_ptr)_2)->base + _s_42980);
        _2 = (object)SEQ_PTR(_22589);
        _22590 = (object)*(((s1_ptr)_2)->base + 4);
        _22589 = NOVALUE;
        if (IS_ATOM_INT(_22590)) {
            _22591 = (_22590 == 5);
        }
        else {
            _22591 = binary_op(EQUALS, _22590, 5);
        }
        _22590 = NOVALUE;
        DeRef(_22588);
        if (IS_ATOM_INT(_22591))
        _22588 = (_22591 != 0);
        else
        _22588 = DBL_PTR(_22591)->dbl != 0.0;
L5: 
        if (_22588 != 0) {
            _22592 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22593 = (object)*(((s1_ptr)_2)->base + _s_42980);
        _2 = (object)SEQ_PTR(_22593);
        _22594 = (object)*(((s1_ptr)_2)->base + 4);
        _22593 = NOVALUE;
        if (IS_ATOM_INT(_22594)) {
            _22595 = (_22594 == 11);
        }
        else {
            _22595 = binary_op(EQUALS, _22594, 11);
        }
        _22594 = NOVALUE;
        if (IS_ATOM_INT(_22595))
        _22592 = (_22595 != 0);
        else
        _22592 = DBL_PTR(_22595)->dbl != 0.0;
L6: 
        if (_22592 != 0) {
            DeRef(_22596);
            _22596 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22597 = (object)*(((s1_ptr)_2)->base + _s_42980);
        _2 = (object)SEQ_PTR(_22597);
        _22598 = (object)*(((s1_ptr)_2)->base + 4);
        _22597 = NOVALUE;
        if (IS_ATOM_INT(_22598)) {
            _22599 = (_22598 == 13);
        }
        else {
            _22599 = binary_op(EQUALS, _22598, 13);
        }
        _22598 = NOVALUE;
        if (IS_ATOM_INT(_22599))
        _22596 = (_22599 != 0);
        else
        _22596 = DBL_PTR(_22599)->dbl != 0.0;
L7: 
        if (_22596 == 0)
        {
            _22596 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22596 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22600 = (_s_42980 % 29);
        _22601 = power(2, _22600);
        _22600 = NOVALUE;
        if (IS_ATOM_INT(_22601)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42976 & (uintptr_t)_22601;
                 _22602 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42976;
            _22602 = Dand_bits(&temp_d, DBL_PTR(_22601));
        }
        DeRef(_22601);
        _22601 = NOVALUE;
        if (_22602 == 0) {
            DeRef(_22602);
            _22602 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22602) && DBL_PTR(_22602)->dbl == 0.0){
                DeRef(_22602);
                _22602 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22602);
            _22602 = NOVALUE;
        }
        DeRef(_22602);
        _22602 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22603 = (_mask_42976 == 1073741823);
        if (_22603 != 0) {
            goto L9; // [191] 204
        }
        _22605 = (_s_42980 < _sub_42978);
        if (_22605 == 0)
        {
            DeRef(_22605);
            _22605 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22605);
            _22605 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _57BB_info_42937 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_42983 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -1073741824;
        ((intptr_t *)_2)[2] = 1073741823;
        _22608 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        ((intptr_t*)_2)[2] = 0;
        Ref(_27NOVALUE_20426);
        ((intptr_t*)_2)[3] = _27NOVALUE_20426;
        ((intptr_t*)_2)[4] = _22608;
        _22609 = MAKE_SEQ(_1);
        _22608 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22609);
        DeRefDS(_22609);
        _22609 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_42983 = _i_42983 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_22209);
    DeRef(_57BB_info_42937);
    _57BB_info_42937 = _22209;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22583);
    _22583 = NOVALUE;
    DeRef(_22599);
    _22599 = NOVALUE;
    DeRef(_22591);
    _22591 = NOVALUE;
    DeRef(_22595);
    _22595 = NOVALUE;
    DeRef(_22603);
    _22603 = NOVALUE;
    DeRef(_22587);
    _22587 = NOVALUE;
    DeRef(_22606);
    _22606 = NOVALUE;
    return;
    ;
}


object _57BB_var_obj(object _var_43048)
{
    object _bbi_43049 = NOVALUE;
    object _22620 = NOVALUE;
    object _22618 = NOVALUE;
    object _22616 = NOVALUE;
    object _22615 = NOVALUE;
    object _22613 = NOVALUE;
    object _22611 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22611 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22611 = 1;
    }
    {
        object _i_43051;
        _i_43051 = _22611;
L1: 
        if (_i_43051 < 1){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_43049);
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _bbi_43049 = (object)*(((s1_ptr)_2)->base + _i_43051);
        Ref(_bbi_43049);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_43049);
        _22613 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22613, _var_43048)){
            _22613 = NOVALUE;
            goto L3; // [31] 40
        }
        _22613 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _22615 = (object)*(((s1_ptr)_2)->base + _var_43048);
        _2 = (object)SEQ_PTR(_22615);
        _22616 = (object)*(((s1_ptr)_2)->base + 3);
        _22615 = NOVALUE;
        if (binary_op_a(EQUALS, _22616, 1)){
            _22616 = NOVALUE;
            goto L5; // [56] 65
        }
        _22616 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_43049);
        _22618 = (object)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22618, 1)){
            _22618 = NOVALUE;
            goto L6; // [73] 82
        }
        _22618 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_43049);
        _22620 = (object)*(((s1_ptr)_2)->base + 5);
        Ref(_22620);
        DeRef(_bbi_43049);
        return _22620;

        /** c_decl.e:211		end for*/
L4: 
        _i_43051 = _i_43051 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_57BB_def_values_43042);
    DeRef(_bbi_43049);
    _22620 = NOVALUE;
    return _57BB_def_values_43042;
    ;
}


object _57BB_var_type(object _var_43071)
{
    object _22635 = NOVALUE;
    object _22634 = NOVALUE;
    object _22632 = NOVALUE;
    object _22631 = NOVALUE;
    object _22630 = NOVALUE;
    object _22629 = NOVALUE;
    object _22628 = NOVALUE;
    object _22627 = NOVALUE;
    object _22626 = NOVALUE;
    object _22625 = NOVALUE;
    object _22624 = NOVALUE;
    object _22623 = NOVALUE;
    object _22622 = NOVALUE;
    object _22621 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22621 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22621 = 1;
    }
    {
        object _i_43073;
        _i_43073 = _22621;
L1: 
        if (_i_43073 < 1){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22622 = (object)*(((s1_ptr)_2)->base + _i_43073);
        _2 = (object)SEQ_PTR(_22622);
        _22623 = (object)*(((s1_ptr)_2)->base + 1);
        _22622 = NOVALUE;
        if (IS_ATOM_INT(_22623)) {
            _22624 = (_22623 == _var_43071);
        }
        else {
            _22624 = binary_op(EQUALS, _22623, _var_43071);
        }
        _22623 = NOVALUE;
        if (IS_ATOM_INT(_22624)) {
            if (_22624 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22624)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22626 = (object)*(((s1_ptr)_2)->base + _i_43073);
        _2 = (object)SEQ_PTR(_22626);
        _22627 = (object)*(((s1_ptr)_2)->base + 1);
        _22626 = NOVALUE;
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_22627)){
            _22628 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22627)->dbl));
        }
        else{
            _22628 = (object)*(((s1_ptr)_2)->base + _22627);
        }
        _2 = (object)SEQ_PTR(_22628);
        _22629 = (object)*(((s1_ptr)_2)->base + 3);
        _22628 = NOVALUE;
        if (IS_ATOM_INT(_22629)) {
            _22630 = (_22629 == 1);
        }
        else {
            _22630 = binary_op(EQUALS, _22629, 1);
        }
        _22629 = NOVALUE;
        if (_22630 == 0) {
            DeRef(_22630);
            _22630 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22630) && DBL_PTR(_22630)->dbl == 0.0){
                DeRef(_22630);
                _22630 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22630);
            _22630 = NOVALUE;
        }
        DeRef(_22630);
        _22630 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22631 = (object)*(((s1_ptr)_2)->base + _i_43073);
        _2 = (object)SEQ_PTR(_22631);
        _22632 = (object)*(((s1_ptr)_2)->base + 2);
        _22631 = NOVALUE;
        if (binary_op_a(NOTEQ, _22632, 0)){
            _22632 = NOVALUE;
            goto L4; // [85] 100
        }
        _22632 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        _22627 = NOVALUE;
        DeRef(_22624);
        _22624 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22634 = (object)*(((s1_ptr)_2)->base + _i_43073);
        _2 = (object)SEQ_PTR(_22634);
        _22635 = (object)*(((s1_ptr)_2)->base + 2);
        _22634 = NOVALUE;
        Ref(_22635);
        _22627 = NOVALUE;
        DeRef(_22624);
        _22624 = NOVALUE;
        return _22635;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_43073 = _i_43073 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    _22627 = NOVALUE;
    DeRef(_22624);
    _22624 = NOVALUE;
    _22635 = NOVALUE;
    return 16;
    ;
}


object _57GType(object _s_43101)
{
    object _t_43102 = NOVALUE;
    object _local_t_43103 = NOVALUE;
    object _22639 = NOVALUE;
    object _22638 = NOVALUE;
    object _22636 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43101)) {
        _1 = (object)(DBL_PTR(_s_43101)->dbl);
        DeRefDS(_s_43101);
        _s_43101 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22636 = (object)*(((s1_ptr)_2)->base + _s_43101);
    _2 = (object)SEQ_PTR(_22636);
    _t_43102 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_43102)){
        _t_43102 = (object)DBL_PTR(_t_43102)->dbl;
    }
    _22636 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22638 = (object)*(((s1_ptr)_2)->base + _s_43101);
    _2 = (object)SEQ_PTR(_22638);
    _22639 = (object)*(((s1_ptr)_2)->base + 3);
    _22638 = NOVALUE;
    if (binary_op_a(EQUALS, _22639, 1)){
        _22639 = NOVALUE;
        goto L1; // [37] 48
    }
    _22639 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_43102;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_43103 = _57BB_var_type(_s_43101);
    if (!IS_ATOM_INT(_local_t_43103)) {
        _1 = (object)(DBL_PTR(_local_t_43103)->dbl);
        DeRefDS(_local_t_43103);
        _local_t_43103 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_43103 != 16)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_43102;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_43102 != 1)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_43103;
    ;
}


object _57GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _57g_has_delete_43123;
    ;
}


object _57HasDelete(object _s_43130)
{
    object _22654 = NOVALUE;
    object _22653 = NOVALUE;
    object _22651 = NOVALUE;
    object _22650 = NOVALUE;
    object _22649 = NOVALUE;
    object _22648 = NOVALUE;
    object _22646 = NOVALUE;
    object _22645 = NOVALUE;
    object _22644 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43130)) {
        _1 = (object)(DBL_PTR(_s_43130)->dbl);
        DeRefDS(_s_43130);
        _s_43130 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22644 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22644 = 1;
    }
    {
        object _i_43132;
        _i_43132 = _22644;
L1: 
        if (_i_43132 < 1){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22645 = (object)*(((s1_ptr)_2)->base + _i_43132);
        _2 = (object)SEQ_PTR(_22645);
        _22646 = (object)*(((s1_ptr)_2)->base + 1);
        _22645 = NOVALUE;
        if (binary_op_a(NOTEQ, _22646, _s_43130)){
            _22646 = NOVALUE;
            goto L3; // [29] 50
        }
        _22646 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22648 = (object)*(((s1_ptr)_2)->base + _i_43132);
        _2 = (object)SEQ_PTR(_22648);
        _22649 = (object)*(((s1_ptr)_2)->base + 6);
        _22648 = NOVALUE;
        Ref(_22649);
        return _22649;
L3: 

        /** c_decl.e:278		end for*/
        _i_43132 = _i_43132 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22650 = (object)*(((s1_ptr)_2)->base + _s_43130);
    if (IS_SEQUENCE(_22650)){
            _22651 = SEQ_PTR(_22650)->length;
    }
    else {
        _22651 = 1;
    }
    _22650 = NOVALUE;
    if (_22651 >= 54)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22649 = NOVALUE;
    _22650 = NOVALUE;
    return 0;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22653 = (object)*(((s1_ptr)_2)->base + _s_43130);
    _2 = (object)SEQ_PTR(_22653);
    _22654 = (object)*(((s1_ptr)_2)->base + 54);
    _22653 = NOVALUE;
    Ref(_22654);
    _22649 = NOVALUE;
    _22650 = NOVALUE;
    return _22654;
    ;
}


object _57ObjValue(object _s_43153)
{
    object _local_t_43154 = NOVALUE;
    object _st_43155 = NOVALUE;
    object _tmin_43156 = NOVALUE;
    object _tmax_43157 = NOVALUE;
    object _22667 = NOVALUE;
    object _22665 = NOVALUE;
    object _22664 = NOVALUE;
    object _22662 = NOVALUE;
    object _22659 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43153)) {
        _1 = (object)(DBL_PTR(_s_43153)->dbl);
        DeRefDS(_s_43153);
        _s_43153 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_43155);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _st_43155 = (object)*(((s1_ptr)_2)->base + _s_43153);
    Ref(_st_43155);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_43156);
    _2 = (object)SEQ_PTR(_st_43155);
    _tmin_43156 = (object)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_43156);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_43157);
    _2 = (object)SEQ_PTR(_st_43155);
    _tmax_43157 = (object)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_43157);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_43156, _tmax_43157)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_27NOVALUE_20426);
    DeRef(_tmin_43156);
    _tmin_43156 = _27NOVALUE_20426;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_43155);
    _22659 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22659, 1)){
        _22659 = NOVALUE;
        goto L2; // [51] 62
    }
    _22659 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_43154);
    DeRef(_st_43155);
    DeRef(_tmax_43157);
    return _tmin_43156;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_43154;
    _local_t_43154 = _57BB_var_obj(_s_43153);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_43154);
    _22662 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22662, _27NOVALUE_20426)){
        _22662 = NOVALUE;
        goto L3; // [80] 91
    }
    _22662 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_43154);
    DeRef(_st_43155);
    DeRef(_tmax_43157);
    return _tmin_43156;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_43154);
    _22664 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_local_t_43154);
    _22665 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22664, _22665)){
        _22664 = NOVALUE;
        _22665 = NOVALUE;
        goto L4; // [105] 116
    }
    _22664 = NOVALUE;
    _22665 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_43154);
    DeRef(_st_43155);
    DeRef(_tmax_43157);
    return _tmin_43156;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_43154);
    _22667 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22667);
    DeRefDS(_local_t_43154);
    DeRef(_st_43155);
    DeRef(_tmin_43156);
    DeRef(_tmax_43157);
    return _22667;
    ;
}


object _57TypeIs(object _x_43188, object _typei_43189)
{
    object _22669 = NOVALUE;
    object _22668 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43188)) {
        _1 = (object)(DBL_PTR(_x_43188)->dbl);
        DeRefDS(_x_43188);
        _x_43188 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22668 = _57GType(_x_43188);
    if (IS_ATOM_INT(_22668)) {
        _22669 = (_22668 == _typei_43189);
    }
    else {
        _22669 = binary_op(EQUALS, _22668, _typei_43189);
    }
    DeRef(_22668);
    _22668 = NOVALUE;
    return _22669;
    ;
}


object _57TypeIsIn(object _x_43194, object _types_43195)
{
    object _22671 = NOVALUE;
    object _22670 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43194)) {
        _1 = (object)(DBL_PTR(_x_43194)->dbl);
        DeRefDS(_x_43194);
        _x_43194 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22670 = _57GType(_x_43194);
    _22671 = find_from(_22670, _types_43195, 1);
    DeRef(_22670);
    _22670 = NOVALUE;
    DeRefDS(_types_43195);
    return _22671;
    ;
}


object _57TypeIsNot(object _x_43200, object _typei_43201)
{
    object _22673 = NOVALUE;
    object _22672 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43200)) {
        _1 = (object)(DBL_PTR(_x_43200)->dbl);
        DeRefDS(_x_43200);
        _x_43200 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22672 = _57GType(_x_43200);
    if (IS_ATOM_INT(_22672)) {
        _22673 = (_22672 != _typei_43201);
    }
    else {
        _22673 = binary_op(NOTEQ, _22672, _typei_43201);
    }
    DeRef(_22672);
    _22672 = NOVALUE;
    return _22673;
    ;
}


object _57TypeIsNotIn(object _x_43206, object _types_43207)
{
    object _22676 = NOVALUE;
    object _22675 = NOVALUE;
    object _22674 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43206)) {
        _1 = (object)(DBL_PTR(_x_43206)->dbl);
        DeRefDS(_x_43206);
        _x_43206 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22674 = _57GType(_x_43206);
    _22675 = find_from(_22674, _types_43207, 1);
    DeRef(_22674);
    _22674 = NOVALUE;
    _22676 = (_22675 == 0);
    _22675 = NOVALUE;
    DeRefDS(_types_43207);
    return _22676;
    ;
}


object _57or_type(object _t1_43213, object _t2_43214)
{
    object _22696 = NOVALUE;
    object _22695 = NOVALUE;
    object _22694 = NOVALUE;
    object _22693 = NOVALUE;
    object _22688 = NOVALUE;
    object _22686 = NOVALUE;
    object _22681 = NOVALUE;
    object _22679 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_43213)) {
        _1 = (object)(DBL_PTR(_t1_43213)->dbl);
        DeRefDS(_t1_43213);
        _t1_43213 = _1;
    }
    if (!IS_ATOM_INT(_t2_43214)) {
        _1 = (object)(DBL_PTR(_t2_43214)->dbl);
        DeRefDS(_t2_43214);
        _t2_43214 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_43213 != 0)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_43214;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_43214 != 0)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_43213;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22679 = (_t1_43213 == 16);
    if (_22679 != 0) {
        goto L4; // [47] 62
    }
    _22681 = (_t2_43214 == 16);
    if (_22681 == 0)
    {
        DeRef(_22681);
        _22681 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22681);
        _22681 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22679);
    _22679 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_43213 != 8)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_43214 != 8)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22679);
    _22679 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22679);
    _22679 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_43214 != 8)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_43213 != 8)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22679);
    _22679 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22679);
    _22679 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22686 = (_t1_43213 == 4);
    if (_22686 != 0) {
        goto LA; // [159] 174
    }
    _22688 = (_t2_43214 == 4);
    if (_22688 == 0)
    {
        DeRef(_22688);
        _22688 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22688);
        _22688 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_43213 != 2)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_43214 != 1)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_43214 != 2)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_43213 != 1)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22693 = (_t1_43213 == 1);
    if (_22693 == 0) {
        goto L10; // [271] 296
    }
    _22695 = (_t2_43214 == 1);
    if (_22695 == 0)
    {
        DeRef(_22695);
        _22695 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22695);
        _22695 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22679);
    _22679 = NOVALUE;
    DeRef(_22686);
    _22686 = NOVALUE;
    DeRef(_22693);
    _22693 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_43213;
    ((intptr_t *)_2)[2] = _t2_43214;
    _22696 = MAKE_SEQ(_1);
    _49InternalErr(258, _22696);
    _22696 = NOVALUE;
L2: 
    ;
}


void _57RemoveFromBB(object _s_43284)
{
    object _int_43285 = NOVALUE;
    object _22698 = NOVALUE;
    object _22697 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22697 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22697 = 1;
    }
    {
        object _i_43287;
        _i_43287 = 1;
L1: 
        if (_i_43287 > _22697){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_57BB_info_42937);
        _22698 = (object)*(((s1_ptr)_2)->base + _i_43287);
        _2 = (object)SEQ_PTR(_22698);
        _int_43285 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_43285)){
            _int_43285 = (object)DBL_PTR(_int_43285)->dbl;
        }
        _22698 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_43285 != _s_43284)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_57BB_info_42937);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_43285)) ? _int_43285 : (object)(DBL_PTR(_int_43285)->dbl);
            int stop = (IS_ATOM_INT(_int_43285)) ? _int_43285 : (object)(DBL_PTR(_int_43285)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_57BB_info_42937), start, &_57BB_info_42937 );
                }
                else Tail(SEQ_PTR(_57BB_info_42937), stop+1, &_57BB_info_42937);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_57BB_info_42937), start, &_57BB_info_42937);
            }
            else {
                assign_slice_seq = &assign_space;
                _57BB_info_42937 = Remove_elements(start, stop, (SEQ_PTR(_57BB_info_42937)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_43287 = _i_43287 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _57SetBBType(object _s_43305, object _t_43306, object _val_43307, object _etype_43308, object _has_delete_43309)
{
    object _found_43310 = NOVALUE;
    object _i_43311 = NOVALUE;
    object _tn_43312 = NOVALUE;
    object _int_43313 = NOVALUE;
    object _sym_43314 = NOVALUE;
    object _mode_43319 = NOVALUE;
    object _gtype_43334 = NOVALUE;
    object _new_type_43371 = NOVALUE;
    object _bbsym_43394 = NOVALUE;
    object _bbi_43530 = NOVALUE;
    object _22817 = NOVALUE;
    object _22816 = NOVALUE;
    object _22815 = NOVALUE;
    object _22813 = NOVALUE;
    object _22812 = NOVALUE;
    object _22811 = NOVALUE;
    object _22809 = NOVALUE;
    object _22808 = NOVALUE;
    object _22806 = NOVALUE;
    object _22804 = NOVALUE;
    object _22803 = NOVALUE;
    object _22801 = NOVALUE;
    object _22799 = NOVALUE;
    object _22798 = NOVALUE;
    object _22797 = NOVALUE;
    object _22796 = NOVALUE;
    object _22795 = NOVALUE;
    object _22794 = NOVALUE;
    object _22793 = NOVALUE;
    object _22792 = NOVALUE;
    object _22791 = NOVALUE;
    object _22788 = NOVALUE;
    object _22784 = NOVALUE;
    object _22779 = NOVALUE;
    object _22777 = NOVALUE;
    object _22776 = NOVALUE;
    object _22775 = NOVALUE;
    object _22773 = NOVALUE;
    object _22771 = NOVALUE;
    object _22770 = NOVALUE;
    object _22769 = NOVALUE;
    object _22767 = NOVALUE;
    object _22766 = NOVALUE;
    object _22764 = NOVALUE;
    object _22763 = NOVALUE;
    object _22762 = NOVALUE;
    object _22760 = NOVALUE;
    object _22759 = NOVALUE;
    object _22756 = NOVALUE;
    object _22755 = NOVALUE;
    object _22754 = NOVALUE;
    object _22752 = NOVALUE;
    object _22750 = NOVALUE;
    object _22749 = NOVALUE;
    object _22747 = NOVALUE;
    object _22746 = NOVALUE;
    object _22745 = NOVALUE;
    object _22743 = NOVALUE;
    object _22742 = NOVALUE;
    object _22731 = NOVALUE;
    object _22729 = NOVALUE;
    object _22726 = NOVALUE;
    object _22725 = NOVALUE;
    object _22722 = NOVALUE;
    object _22721 = NOVALUE;
    object _22720 = NOVALUE;
    object _22718 = NOVALUE;
    object _22717 = NOVALUE;
    object _22716 = NOVALUE;
    object _22714 = NOVALUE;
    object _22713 = NOVALUE;
    object _22711 = NOVALUE;
    object _22708 = NOVALUE;
    object _22706 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43305)) {
        _1 = (object)(DBL_PTR(_s_43305)->dbl);
        DeRefDS(_s_43305);
        _s_43305 = _1;
    }
    if (!IS_ATOM_INT(_t_43306)) {
        _1 = (object)(DBL_PTR(_t_43306)->dbl);
        DeRefDS(_t_43306);
        _t_43306 = _1;
    }
    if (!IS_ATOM_INT(_etype_43308)) {
        _1 = (object)(DBL_PTR(_etype_43308)->dbl);
        DeRefDS(_etype_43308);
        _etype_43308 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_43309)) {
        _1 = (object)(DBL_PTR(_has_delete_43309)->dbl);
        DeRefDS(_has_delete_43309);
        _has_delete_43309 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_43309 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _57p_has_delete_43124 = 1;

    /** c_decl.e:418			g_has_delete = 1*/
    _57g_has_delete_43123 = 1;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_43314);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _sym_43314 = (object)*(((s1_ptr)_2)->base + _s_43305);
    Ref(_sym_43314);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43305);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _mode_43319 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_43319))
    _mode_43319 = (object)DBL_PTR(_mode_43319)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22706 = (_mode_43319 == 1);
    if (_22706 != 0) {
        goto L2; // [61] 76
    }
    _22708 = (_mode_43319 == 3);
    if (_22708 == 0)
    {
        DeRef(_22708);
        _22708 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22708);
        _22708 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_43310 = _9FALSE_439;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_43319 != 3)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43306;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43308;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _gtype_43334 = (object)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_43334))
    _gtype_43334 = (object)DBL_PTR(_gtype_43334)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22711 = (_gtype_43334 == 16);
    if (_22711 != 0) {
        goto L5; // [125] 140
    }
    _22713 = (_gtype_43334 == 8);
    if (_22713 == 0)
    {
        DeRef(_22713);
        _22713 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22713);
        _22713 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22714 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22714, 0)){
        _22714 = NOVALUE;
        goto L7; // [148] 165
    }
    _22714 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22716 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22716);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22716;
    if( _1 != _22716 ){
        DeRef(_1);
    }
    _22716 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22717 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22717);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22717;
    if( _1 != _22717 ){
        DeRef(_1);
    }
    _22717 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22718 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22718);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22718;
    if( _1 != _22718 ){
        DeRef(_1);
    }
    _22718 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_27Initializing_20652 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22720 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_27temp_name_type_20654);
    if (!IS_ATOM_INT(_22720)){
        _22721 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22720)->dbl));
    }
    else{
        _22721 = (object)*(((s1_ptr)_2)->base + _22720);
    }
    _2 = (object)SEQ_PTR(_22721);
    _22722 = (object)*(((s1_ptr)_2)->base + 2);
    _22721 = NOVALUE;
    Ref(_22722);
    _new_type_43371 = _57or_type(_22722, _t_43306);
    _22722 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43371)) {
        _1 = (object)(DBL_PTR(_new_type_43371)->dbl);
        DeRefDS(_new_type_43371);
        _new_type_43371 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43371 != 0)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43371 = 16;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22725 = (object)*(((s1_ptr)_2)->base + 34);
    _2 = (object)SEQ_PTR(_27temp_name_type_20654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27temp_name_type_20654 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22725))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22725)->dbl));
    else
    _3 = (object)(_22725 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43371;
    DeRef(_1);
    _22726 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _tn_43312 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_43312))
    _tn_43312 = (object)DBL_PTR(_tn_43312)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_43311 = 1;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22729 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22729 = 1;
    }
    if (_i_43311 > _22729)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    _22731 = (object)*(((s1_ptr)_2)->base + _i_43311);
    _2 = (object)SEQ_PTR(_22731);
    _int_43313 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_43313)){
        _int_43313 = (object)DBL_PTR(_int_43313)->dbl;
    }
    _22731 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_43313 != _s_43305)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_43314);
    DeRef(_bbsym_43394);
    _bbsym_43394 = _sym_43314;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43394);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _bbsym_43394 = (object)*(((s1_ptr)_2)->base + _int_43313);
    Ref(_bbsym_43394);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43394);
    _int_43313 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_43313))
    _int_43313 = (object)DBL_PTR(_int_43313)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_43313 != 3)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43394);
    _int_43313 = (object)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_43313))
    _int_43313 = (object)DBL_PTR(_int_43313)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_43313 != _tn_43312)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_43310 = _9TRUE_441;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43394);
    _bbsym_43394 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_43311 = _i_43311 + 1;
    DeRef(_bbsym_43394);
    _bbsym_43394 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_43306 == 0)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_27Initializing_20652 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22742 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_22742);
    _22743 = _57or_type(_22742, _t_43306);
    _22742 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22743;
    if( _1 != _22743 ){
        DeRef(_1);
    }
    _22743 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_43306 != 8)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22745 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22745);
    _22746 = _57or_type(_22745, _etype_43308);
    _22745 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22746;
    if( _1 != _22746 ){
        DeRef(_1);
    }
    _22746 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22747 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22747, -1)){
        _22747 = NOVALUE;
        goto L16; // [535] 823
    }
    _22747 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22749 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _22750 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22750 = - _27NOVALUE_20426;
        }
    }
    else {
        _22750 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _22749, _22750)){
        _22749 = NOVALUE;
        DeRef(_22750);
        _22750 = NOVALUE;
        goto L17; // [552] 599
    }
    _22749 = NOVALUE;
    DeRef(_22750);
    _22750 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22752 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22752, 0)){
        _22752 = NOVALUE;
        goto L18; // [564] 581
    }
    _22752 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22754 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22754);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22754;
    if( _1 != _22754 ){
        DeRef(_1);
    }
    _22754 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22755 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_43314);
    _22756 = (object)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22755, _22756)){
        _22755 = NOVALUE;
        _22756 = NOVALUE;
        goto L16; // [613] 823
    }
    _22755 = NOVALUE;
    _22756 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_43306 != 1)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22759 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _22760 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22760 = - _27NOVALUE_20426;
        }
    }
    else {
        _22760 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _22759, _22760)){
        _22759 = NOVALUE;
        DeRef(_22760);
        _22760 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22759 = NOVALUE;
    DeRef(_22760);
    _22760 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22762 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22762);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22762;
    if( _1 != _22762 ){
        DeRef(_1);
    }
    _22762 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22763 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22763);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22763;
    if( _1 != _22763 ){
        DeRef(_1);
    }
    _22763 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22764 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22764, _27NOVALUE_20426)){
        _22764 = NOVALUE;
        goto L16; // [699] 823
    }
    _22764 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22766 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_sym_43314);
    _22767 = (object)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22766, _22767)){
        _22766 = NOVALUE;
        _22767 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22766 = NOVALUE;
    _22767 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22769 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22769);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22769;
    if( _1 != _22769 ){
        DeRef(_1);
    }
    _22769 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22770 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_sym_43314);
    _22771 = (object)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22770, _22771)){
        _22770 = NOVALUE;
        _22771 = NOVALUE;
        goto L16; // [750] 823
    }
    _22770 = NOVALUE;
    _22771 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22773 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22773);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22773;
    if( _1 != _22773 ){
        DeRef(_1);
    }
    _22773 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_43306 != 16)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22775 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_22775);
    _22776 = _57or_type(_22775, _etype_43308);
    _22775 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22776;
    if( _1 != _22776 ){
        DeRef(_1);
    }
    _22776 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_43311 = 1;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_57BB_info_42937)){
            _22777 = SEQ_PTR(_57BB_info_42937)->length;
    }
    else {
        _22777 = 1;
    }
    if (_i_43311 > _22777)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    _22779 = (object)*(((s1_ptr)_2)->base + _i_43311);
    _2 = (object)SEQ_PTR(_22779);
    _int_43313 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_43313)){
        _int_43313 = (object)DBL_PTR(_int_43313)->dbl;
    }
    _22779 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_43313 != _s_43305)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_43310 = _9TRUE_441;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_43311 = _i_43311 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_43310 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22784 = Repeat(0, 6);
    RefDS(_22784);
    Append(&_57BB_info_42937, _57BB_info_42937, _22784);
    DeRefDS(_22784);
    _22784 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_43306 != 0)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_43310 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_57dummy_bb_43294);
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42937 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43311);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _57dummy_bb_43294;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42937 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_43311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43305;
    DeRef(_1);
    _22788 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43530);
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    _bbi_43530 = (object)*(((s1_ptr)_2)->base + _i_43311);
    Ref(_bbi_43530);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42937 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43311);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43305;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43306;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43309;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22791 = (_t_43306 == 8);
    if (_22791 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_43307);
    _22793 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22793)) {
        _22794 = (_22793 == -1);
    }
    else {
        _22794 = binary_op(EQUALS, _22793, -1);
    }
    _22793 = NOVALUE;
    if (_22794 == 0) {
        DeRef(_22794);
        _22794 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22794) && DBL_PTR(_22794)->dbl == 0.0){
            DeRef(_22794);
            _22794 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22794);
        _22794 = NOVALUE;
    }
    DeRef(_22794);
    _22794 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_43310 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43530);
    _22796 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22796)) {
        _22797 = (_22796 != 0);
    }
    else {
        _22797 = binary_op(NOTEQ, _22796, 0);
    }
    _22796 = NOVALUE;
    if (_22797 == 0) {
        DeRef(_22797);
        _22797 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22797) && DBL_PTR(_22797)->dbl == 0.0){
            DeRef(_22797);
            _22797 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22797);
        _22797 = NOVALUE;
    }
    DeRef(_22797);
    _22797 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43530);
    _22798 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_22798);
    _22799 = _57or_type(_22798, _etype_43308);
    _22798 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22799;
    if( _1 != _22799 ){
        DeRef(_1);
    }
    _22799 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_43310 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43308;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22801 = (_t_43306 == 8);
    if (_22801 != 0) {
        goto L27; // [1091] 1106
    }
    _22803 = (_t_43306 == 16);
    if (_22803 == 0)
    {
        DeRef(_22803);
        _22803 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22803);
        _22803 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22804 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22804, 0)){
        _22804 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22804 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22806 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22806);
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22806;
    if( _1 != _22806 ){
        DeRef(_1);
    }
    _22806 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_43307);
    _2 = (object)SEQ_PTR(_bbi_43530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_43307;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43530);
    _2 = (object)SEQ_PTR(_57BB_info_42937);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57BB_info_42937 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43311);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43530;
    DeRef(_1);
    DeRefDS(_bbi_43530);
    _bbi_43530 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_43319 != 2)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43306;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43308;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_43314);
    _22808 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22808)) {
        _22809 = (_22808 == 8);
    }
    else {
        _22809 = binary_op(EQUALS, _22808, 8);
    }
    _22808 = NOVALUE;
    if (IS_ATOM_INT(_22809)) {
        if (_22809 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22809)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43314);
    _22811 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22811)) {
        _22812 = (_22811 == 16);
    }
    else {
        _22812 = binary_op(EQUALS, _22811, 16);
    }
    _22811 = NOVALUE;
    if (_22812 == 0) {
        DeRef(_22812);
        _22812 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22812) && DBL_PTR(_22812)->dbl == 0.0){
            DeRef(_22812);
            _22812 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22812);
        _22812 = NOVALUE;
    }
    DeRef(_22812);
    _22812 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22813 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22813, 0)){
        _22813 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22813 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22815 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22815);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22815;
    if( _1 != _22815 ){
        DeRef(_1);
    }
    _22815 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22816 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22816);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22816;
    if( _1 != _22816 ){
        DeRef(_1);
    }
    _22816 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43307);
    _22817 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_22817);
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22817;
    if( _1 != _22817 ){
        DeRef(_1);
    }
    _22817 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_43314);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43314 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43309;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_43314);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43305);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43314;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_43307);
    DeRefDS(_sym_43314);
    _22720 = NOVALUE;
    DeRef(_22791);
    _22791 = NOVALUE;
    DeRef(_22706);
    _22706 = NOVALUE;
    _22725 = NOVALUE;
    DeRef(_22711);
    _22711 = NOVALUE;
    DeRef(_22809);
    _22809 = NOVALUE;
    DeRef(_22801);
    _22801 = NOVALUE;
    return;
    ;
}


void _57CName(object _s_43604)
{
    object _v_43605 = NOVALUE;
    object _mode_43607 = NOVALUE;
    object _22882 = NOVALUE;
    object _22881 = NOVALUE;
    object _22879 = NOVALUE;
    object _22878 = NOVALUE;
    object _22877 = NOVALUE;
    object _22876 = NOVALUE;
    object _22875 = NOVALUE;
    object _22874 = NOVALUE;
    object _22873 = NOVALUE;
    object _22872 = NOVALUE;
    object _22870 = NOVALUE;
    object _22868 = NOVALUE;
    object _22867 = NOVALUE;
    object _22866 = NOVALUE;
    object _22865 = NOVALUE;
    object _22864 = NOVALUE;
    object _22863 = NOVALUE;
    object _22861 = NOVALUE;
    object _22860 = NOVALUE;
    object _22859 = NOVALUE;
    object _22858 = NOVALUE;
    object _22857 = NOVALUE;
    object _22855 = NOVALUE;
    object _22854 = NOVALUE;
    object _22853 = NOVALUE;
    object _22852 = NOVALUE;
    object _22851 = NOVALUE;
    object _22850 = NOVALUE;
    object _22848 = NOVALUE;
    object _22847 = NOVALUE;
    object _22845 = NOVALUE;
    object _22844 = NOVALUE;
    object _22843 = NOVALUE;
    object _22842 = NOVALUE;
    object _22841 = NOVALUE;
    object _22840 = NOVALUE;
    object _22839 = NOVALUE;
    object _22838 = NOVALUE;
    object _22837 = NOVALUE;
    object _22836 = NOVALUE;
    object _22835 = NOVALUE;
    object _22834 = NOVALUE;
    object _22832 = NOVALUE;
    object _22831 = NOVALUE;
    object _22827 = NOVALUE;
    object _22826 = NOVALUE;
    object _22825 = NOVALUE;
    object _22824 = NOVALUE;
    object _22823 = NOVALUE;
    object _22822 = NOVALUE;
    object _22819 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43604)) {
        _1 = (object)(DBL_PTR(_s_43604)->dbl);
        DeRefDS(_s_43604);
        _s_43604 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43605;
    _v_43605 = _57ObjValue(_s_43604);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22819 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22819);
    _mode_43607 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_43607)){
        _mode_43607 = (object)DBL_PTR(_mode_43607)->dbl;
    }
    _22819 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43607 != 1)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22822 = (_57LeftSym_42938 == _9FALSE_439);
    if (_22822 == 0) {
        _22823 = 0;
        goto L2; // [43] 61
    }
    _22824 = _57GType(_s_43604);
    if (IS_ATOM_INT(_22824)) {
        _22825 = (_22824 == 1);
    }
    else {
        _22825 = binary_op(EQUALS, _22824, 1);
    }
    DeRef(_22824);
    _22824 = NOVALUE;
    if (IS_ATOM_INT(_22825))
    _22823 = (_22825 != 0);
    else
    _22823 = DBL_PTR(_22825)->dbl != 0.0;
L2: 
    if (_22823 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43605) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _22827 = (_v_43605 != _27NOVALUE_20426);
    }
    else {
        _22827 = binary_op(NOTEQ, _v_43605, _27NOVALUE_20426);
    }
    if (_22827 == 0) {
        DeRef(_22827);
        _22827 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22827) && DBL_PTR(_22827)->dbl == 0.0){
            DeRef(_22827);
            _22827 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22827);
        _22827 = NOVALUE;
    }
    DeRef(_22827);
    _22827 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22828);
    Ref(_v_43605);
    _54c_printf(_22828, _v_43605);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22831 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22831);
    _22832 = (object)*(((s1_ptr)_2)->base + 4);
    _22831 = NOVALUE;
    if (binary_op_a(LESSEQ, _22832, 3)){
        _22832 = NOVALUE;
        goto L5; // [114] 156
    }
    _22832 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22834 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22834);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _22835 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _22835 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _22834 = NOVALUE;
    RefDS(_22332);
    Ref(_22835);
    _54c_printf(_22332, _22835);
    _22835 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22836 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22836);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22837 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22837 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _22836 = NOVALUE;
    Ref(_22837);
    _54c_puts(_22837);
    _22837 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22281);
    _54c_puts(_22281);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22838 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22838);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22839 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22839 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _22838 = NOVALUE;
    Ref(_22839);
    _54c_puts(_22839);
    _22839 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22840 = (_s_43604 != _27CurrentSub_20579);
    if (_22840 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22842 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22842);
    _22843 = (object)*(((s1_ptr)_2)->base + 12);
    _22842 = NOVALUE;
    if (IS_ATOM_INT(_22843)) {
        _22844 = (_22843 < 2);
    }
    else {
        _22844 = binary_op(LESS, _22843, 2);
    }
    _22843 = NOVALUE;
    if (_22844 == 0) {
        DeRef(_22844);
        _22844 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22844) && DBL_PTR(_22844)->dbl == 0.0){
            DeRef(_22844);
            _22844 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22844);
        _22844 = NOVALUE;
    }
    DeRef(_22844);
    _22844 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22847 = (object)*(((s1_ptr)_2)->base + 12);
    _22845 = NOVALUE;
    if (IS_ATOM_INT(_22847)) {
        _22848 = _22847 + 1;
        if (_22848 > MAXINT){
            _22848 = NewDouble((eudouble)_22848);
        }
    }
    else
    _22848 = binary_op(PLUS, 1, _22847);
    _22847 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22848;
    if( _1 != _22848 ){
        DeRef(_1);
    }
    _22848 = NOVALUE;
    _22845 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_54novalue_47028);
    _57SetBBType(_s_43604, 0, _54novalue_47028, 16, 0);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43607 != 2)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22850 = _53sym_obj(_s_43604);
    _22851 = _27is_integer(_22850);
    _22850 = NOVALUE;
    if (IS_ATOM_INT(_22851)) {
        if (_22851 == 0) {
            DeRef(_22852);
            _22852 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22851)->dbl == 0.0) {
            DeRef(_22852);
            _22852 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22853 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22853);
    _22854 = (object)*(((s1_ptr)_2)->base + 36);
    _22853 = NOVALUE;
    if (IS_ATOM_INT(_22854)) {
        _22855 = (_22854 != 2);
    }
    else {
        _22855 = binary_op(NOTEQ, _22854, 2);
    }
    _22854 = NOVALUE;
    DeRef(_22852);
    if (IS_ATOM_INT(_22855))
    _22852 = (_22855 != 0);
    else
    _22852 = DBL_PTR(_22855)->dbl != 0.0;
LA: 
    if (_22852 != 0) {
        goto LB; // [298] 344
    }
    _22857 = (_57LeftSym_42938 == _9FALSE_439);
    if (_22857 == 0) {
        _22858 = 0;
        goto LC; // [310] 325
    }
    _22859 = _57TypeIs(_s_43604, 1);
    if (IS_ATOM_INT(_22859))
    _22858 = (_22859 != 0);
    else
    _22858 = DBL_PTR(_22859)->dbl != 0.0;
LC: 
    if (_22858 == 0) {
        DeRef(_22860);
        _22860 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43605) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _22861 = (_v_43605 != _27NOVALUE_20426);
    }
    else {
        _22861 = binary_op(NOTEQ, _v_43605, _27NOVALUE_20426);
    }
    if (IS_ATOM_INT(_22861))
    _22860 = (_22861 != 0);
    else
    _22860 = DBL_PTR(_22861)->dbl != 0.0;
LD: 
    if (_22860 == 0)
    {
        _22860 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22860 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22828);
    Ref(_v_43605);
    _54c_printf(_22828, _v_43605);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22863 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22863);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _22864 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _22864 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _22863 = NOVALUE;
    RefDS(_22332);
    Ref(_22864);
    _54c_printf(_22332, _22864);
    _22864 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22865 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22865);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22866 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _22865 = NOVALUE;
    Ref(_22866);
    _54c_puts(_22866);
    _22866 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22867 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22867);
    _22868 = (object)*(((s1_ptr)_2)->base + 12);
    _22867 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22868, 2)){
        _22868 = NOVALUE;
        goto L8; // [416] 533
    }
    _22868 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43604 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22872 = (object)*(((s1_ptr)_2)->base + 12);
    _22870 = NOVALUE;
    if (IS_ATOM_INT(_22872)) {
        _22873 = _22872 + 1;
        if (_22873 > MAXINT){
            _22873 = NewDouble((eudouble)_22873);
        }
    }
    else
    _22873 = binary_op(PLUS, 1, _22872);
    _22872 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22873;
    if( _1 != _22873 ){
        DeRef(_1);
    }
    _22873 = NOVALUE;
    _22870 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22874 = (_57LeftSym_42938 == _9FALSE_439);
    if (_22874 == 0) {
        _22875 = 0;
        goto LF; // [458] 476
    }
    _22876 = _57GType(_s_43604);
    if (IS_ATOM_INT(_22876)) {
        _22877 = (_22876 == 1);
    }
    else {
        _22877 = binary_op(EQUALS, _22876, 1);
    }
    DeRef(_22876);
    _22876 = NOVALUE;
    if (IS_ATOM_INT(_22877))
    _22875 = (_22877 != 0);
    else
    _22875 = DBL_PTR(_22877)->dbl != 0.0;
LF: 
    if (_22875 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43605) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _22879 = (_v_43605 != _27NOVALUE_20426);
    }
    else {
        _22879 = binary_op(NOTEQ, _v_43605, _27NOVALUE_20426);
    }
    if (_22879 == 0) {
        DeRef(_22879);
        _22879 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22879) && DBL_PTR(_22879)->dbl == 0.0){
            DeRef(_22879);
            _22879 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22879);
        _22879 = NOVALUE;
    }
    DeRef(_22879);
    _22879 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22828);
    Ref(_v_43605);
    _54c_printf(_22828, _v_43605);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22881 = (object)*(((s1_ptr)_2)->base + _s_43604);
    _2 = (object)SEQ_PTR(_22881);
    _22882 = (object)*(((s1_ptr)_2)->base + 34);
    _22881 = NOVALUE;
    RefDS(_22332);
    Ref(_22882);
    _54c_printf(_22332, _22882);
    _22882 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _57LeftSym_42938 = _9FALSE_439;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43605);
    DeRef(_22877);
    _22877 = NOVALUE;
    DeRef(_22857);
    _22857 = NOVALUE;
    DeRef(_22822);
    _22822 = NOVALUE;
    DeRef(_22855);
    _22855 = NOVALUE;
    DeRef(_22874);
    _22874 = NOVALUE;
    DeRef(_22861);
    _22861 = NOVALUE;
    DeRef(_22859);
    _22859 = NOVALUE;
    DeRef(_22851);
    _22851 = NOVALUE;
    DeRef(_22840);
    _22840 = NOVALUE;
    DeRef(_22825);
    _22825 = NOVALUE;
    return;
    ;
}


void _57c_stmt(object _stmt_43752, object _arg_43753, object _lhs_arg_43755)
{
    object _argcount_43756 = NOVALUE;
    object _i_43757 = NOVALUE;
    object _22937 = NOVALUE;
    object _22936 = NOVALUE;
    object _22935 = NOVALUE;
    object _22934 = NOVALUE;
    object _22933 = NOVALUE;
    object _22932 = NOVALUE;
    object _22931 = NOVALUE;
    object _22930 = NOVALUE;
    object _22929 = NOVALUE;
    object _22928 = NOVALUE;
    object _22927 = NOVALUE;
    object _22926 = NOVALUE;
    object _22925 = NOVALUE;
    object _22924 = NOVALUE;
    object _22923 = NOVALUE;
    object _22922 = NOVALUE;
    object _22921 = NOVALUE;
    object _22919 = NOVALUE;
    object _22917 = NOVALUE;
    object _22915 = NOVALUE;
    object _22914 = NOVALUE;
    object _22913 = NOVALUE;
    object _22912 = NOVALUE;
    object _22910 = NOVALUE;
    object _22909 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22906 = NOVALUE;
    object _22905 = NOVALUE;
    object _22904 = NOVALUE;
    object _22903 = NOVALUE;
    object _22902 = NOVALUE;
    object _22901 = NOVALUE;
    object _22900 = NOVALUE;
    object _22899 = NOVALUE;
    object _22898 = NOVALUE;
    object _22897 = NOVALUE;
    object _22894 = NOVALUE;
    object _22893 = NOVALUE;
    object _22892 = NOVALUE;
    object _22891 = NOVALUE;
    object _22890 = NOVALUE;
    object _22889 = NOVALUE;
    object _22887 = NOVALUE;
    object _22885 = NOVALUE;
    object _22884 = NOVALUE;
    object _22883 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43755)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43755)->dbl);
        DeRefDS(_lhs_arg_43755);
        _lhs_arg_43755 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22883 = (_57LAST_PASS_42928 == _9TRUE_441);
    if (_22883 == 0) {
        goto L1; // [15] 47
    }
    _22885 = (_27Initializing_20652 == _9FALSE_439);
    if (_22885 == 0)
    {
        DeRef(_22885);
        _22885 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22885);
        _22885 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _27cfile_size_20651 = _27cfile_size_20651 + 1;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43752);
    _55update_checksum(_stmt_43752);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43752);
    _54adjust_indent_before(_stmt_43752);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22887 = IS_ATOM(_arg_43753);
    if (_22887 == 0)
    {
        _22887 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22887 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43753;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43753);
    ((intptr_t*)_2)[1] = _arg_43753;
    _arg_43753 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43756 = 1;

    /** c_decl.e:690		i = 1*/
    _i_43757 = 1;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43752)){
            _22889 = SEQ_PTR(_stmt_43752)->length;
    }
    else {
        _22889 = 1;
    }
    _22890 = (_i_43757 <= _22889);
    _22889 = NOVALUE;
    if (_22890 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43752)){
            _22892 = SEQ_PTR(_stmt_43752)->length;
    }
    else {
        _22892 = 1;
    }
    _22893 = (_22892 > 0);
    _22892 = NOVALUE;
    if (_22893 == 0)
    {
        DeRef(_22893);
        _22893 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22893);
        _22893 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22894 = (object)*(((s1_ptr)_2)->base + _i_43757);
    if (binary_op_a(NOTEQ, _22894, 64)){
        _22894 = NOVALUE;
        goto L6; // [118] 288
    }
    _22894 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43757 != 1)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _57LeftSym_42938 = _9TRUE_441;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43752)){
            _22897 = SEQ_PTR(_stmt_43752)->length;
    }
    else {
        _22897 = 1;
    }
    _22898 = (_i_43757 < _22897);
    _22897 = NOVALUE;
    if (_22898 == 0) {
        _22899 = 0;
        goto L8; // [147] 167
    }
    _22900 = _i_43757 + 1;
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22901 = (object)*(((s1_ptr)_2)->base + _22900);
    if (IS_ATOM_INT(_22901)) {
        _22902 = (_22901 > 48);
    }
    else {
        _22902 = binary_op(GREATER, _22901, 48);
    }
    _22901 = NOVALUE;
    if (IS_ATOM_INT(_22902))
    _22899 = (_22902 != 0);
    else
    _22899 = DBL_PTR(_22902)->dbl != 0.0;
L8: 
    if (_22899 == 0) {
        goto L9; // [167] 249
    }
    _22904 = _i_43757 + 1;
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22905 = (object)*(((s1_ptr)_2)->base + _22904);
    if (IS_ATOM_INT(_22905)) {
        _22906 = (_22905 <= 57);
    }
    else {
        _22906 = binary_op(LESSEQ, _22905, 57);
    }
    _22905 = NOVALUE;
    if (_22906 == 0) {
        DeRef(_22906);
        _22906 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22906) && DBL_PTR(_22906)->dbl == 0.0){
            DeRef(_22906);
            _22906 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22906);
        _22906 = NOVALUE;
    }
    DeRef(_22906);
    _22906 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22907 = _i_43757 + 1;
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22908 = (object)*(((s1_ptr)_2)->base + _22907);
    if (IS_ATOM_INT(_22908)) {
        _22909 = _22908 - 48;
    }
    else {
        _22909 = binary_op(MINUS, _22908, 48);
    }
    _22908 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43753);
    if (!IS_ATOM_INT(_22909)){
        _22910 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22909)->dbl));
    }
    else{
        _22910 = (object)*(((s1_ptr)_2)->base + _22909);
    }
    if (binary_op_a(NOTEQ, _22910, _lhs_arg_43755)){
        _22910 = NOVALUE;
        goto LA; // [205] 219
    }
    _22910 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _57LeftSym_42938 = _9TRUE_441;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22912 = _i_43757 + 1;
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22913 = (object)*(((s1_ptr)_2)->base + _22912);
    if (IS_ATOM_INT(_22913)) {
        _22914 = _22913 - 48;
    }
    else {
        _22914 = binary_op(MINUS, _22913, 48);
    }
    _22913 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43753);
    if (!IS_ATOM_INT(_22914)){
        _22915 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22914)->dbl));
    }
    else{
        _22915 = (object)*(((s1_ptr)_2)->base + _22914);
    }
    Ref(_22915);
    _57CName(_22915);
    _22915 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43757 = _i_43757 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43753);
    _22917 = (object)*(((s1_ptr)_2)->base + _argcount_43756);
    if (binary_op_a(NOTEQ, _22917, _lhs_arg_43755)){
        _22917 = NOVALUE;
        goto LC; // [255] 269
    }
    _22917 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _57LeftSym_42938 = _9TRUE_441;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43753);
    _22919 = (object)*(((s1_ptr)_2)->base + _argcount_43756);
    Ref(_22919);
    _57CName(_22919);
    _22919 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43756 = _argcount_43756 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22921 = (object)*(((s1_ptr)_2)->base + _i_43757);
    Ref(_22921);
    _54c_putc(_22921);
    _22921 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22922 = (object)*(((s1_ptr)_2)->base + _i_43757);
    if (IS_ATOM_INT(_22922)) {
        _22923 = (_22922 == 38);
    }
    else {
        _22923 = binary_op(EQUALS, _22922, 38);
    }
    _22922 = NOVALUE;
    if (IS_ATOM_INT(_22923)) {
        if (_22923 == 0) {
            DeRef(_22924);
            _22924 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22923)->dbl == 0.0) {
            DeRef(_22924);
            _22924 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43752)){
            _22925 = SEQ_PTR(_stmt_43752)->length;
    }
    else {
        _22925 = 1;
    }
    _22926 = (_i_43757 < _22925);
    _22925 = NOVALUE;
    DeRef(_22924);
    _22924 = (_22926 != 0);
LE: 
    if (_22924 == 0) {
        goto LF; // [322] 352
    }
    _22928 = _i_43757 + 1;
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22929 = (object)*(((s1_ptr)_2)->base + _22928);
    if (IS_ATOM_INT(_22929)) {
        _22930 = (_22929 == 64);
    }
    else {
        _22930 = binary_op(EQUALS, _22929, 64);
    }
    _22929 = NOVALUE;
    if (_22930 == 0) {
        DeRef(_22930);
        _22930 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22930) && DBL_PTR(_22930)->dbl == 0.0){
            DeRef(_22930);
            _22930 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22930);
        _22930 = NOVALUE;
    }
    DeRef(_22930);
    _22930 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _57LeftSym_42938 = _9TRUE_441;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43752);
    _22931 = (object)*(((s1_ptr)_2)->base + _i_43757);
    if (IS_ATOM_INT(_22931)) {
        _22932 = (_22931 == 10);
    }
    else {
        _22932 = binary_op(EQUALS, _22931, 10);
    }
    _22931 = NOVALUE;
    if (IS_ATOM_INT(_22932)) {
        if (_22932 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22932)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43752)){
            _22934 = SEQ_PTR(_stmt_43752)->length;
    }
    else {
        _22934 = 1;
    }
    _22935 = (_i_43757 < _22934);
    _22934 = NOVALUE;
    if (_22935 == 0)
    {
        DeRef(_22935);
        _22935 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22935);
        _22935 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43752);
    _54adjust_indent_after(_stmt_43752);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22936 = _i_43757 + 1;
    if (_22936 > MAXINT){
        _22936 = NewDouble((eudouble)_22936);
    }
    if (IS_SEQUENCE(_stmt_43752)){
            _22937 = SEQ_PTR(_stmt_43752)->length;
    }
    else {
        _22937 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43752;
    RHS_Slice(_stmt_43752, _22936, _22937);

    /** c_decl.e:728				i = 0*/
    _i_43757 = 0;

    /** c_decl.e:729				if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43752);
    _54adjust_indent_before(_stmt_43752);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43757 = _i_43757 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43752);
    _54adjust_indent_after(_stmt_43752);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43752);
    DeRef(_arg_43753);
    DeRef(_22914);
    _22914 = NOVALUE;
    DeRef(_22904);
    _22904 = NOVALUE;
    DeRef(_22902);
    _22902 = NOVALUE;
    DeRef(_22926);
    _22926 = NOVALUE;
    DeRef(_22923);
    _22923 = NOVALUE;
    DeRef(_22898);
    _22898 = NOVALUE;
    DeRef(_22907);
    _22907 = NOVALUE;
    DeRef(_22909);
    _22909 = NOVALUE;
    DeRef(_22890);
    _22890 = NOVALUE;
    DeRef(_22912);
    _22912 = NOVALUE;
    DeRef(_22883);
    _22883 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22932);
    _22932 = NOVALUE;
    DeRef(_22936);
    _22936 = NOVALUE;
    DeRef(_22928);
    _22928 = NOVALUE;
    return;
    ;
}


void _57c_stmt0(object _stmt_43851)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_54emit_c_output_47021 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43851);
    RefDS(_22209);
    _57c_stmt(_stmt_43851, _22209, 0);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDS(_stmt_43851);
    return;
    ;
}


object _57needs_uninit(object _eentry_43856)
{
    object _22960 = NOVALUE;
    object _22959 = NOVALUE;
    object _22958 = NOVALUE;
    object _22957 = NOVALUE;
    object _22956 = NOVALUE;
    object _22955 = NOVALUE;
    object _22954 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22951 = NOVALUE;
    object _22950 = NOVALUE;
    object _22949 = NOVALUE;
    object _22948 = NOVALUE;
    object _22947 = NOVALUE;
    object _22946 = NOVALUE;
    object _22945 = NOVALUE;
    object _22944 = NOVALUE;
    object _22943 = NOVALUE;
    object _22942 = NOVALUE;
    object _22941 = NOVALUE;
    object _22940 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43856);
    _22940 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22940)) {
        _22941 = (_22940 >= 5);
    }
    else {
        _22941 = binary_op(GREATEREQ, _22940, 5);
    }
    _22940 = NOVALUE;
    if (IS_ATOM_INT(_22941)) {
        if (_22941 == 0) {
            _22942 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22941)->dbl == 0.0) {
            _22942 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43856);
    _22943 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22943)) {
        _22944 = (_22943 <= 6);
    }
    else {
        _22944 = binary_op(LESSEQ, _22943, 6);
    }
    _22943 = NOVALUE;
    if (IS_ATOM_INT(_22944)) {
        if (_22944 != 0) {
            _22945 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22944)->dbl != 0.0) {
            _22945 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43856);
    _22946 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22946)) {
        _22947 = (_22946 == 11);
    }
    else {
        _22947 = binary_op(EQUALS, _22946, 11);
    }
    _22946 = NOVALUE;
    DeRef(_22945);
    if (IS_ATOM_INT(_22947))
    _22945 = (_22947 != 0);
    else
    _22945 = DBL_PTR(_22947)->dbl != 0.0;
L2: 
    if (_22945 != 0) {
        _22948 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43856);
    _22949 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22949)) {
        _22950 = (_22949 == 13);
    }
    else {
        _22950 = binary_op(EQUALS, _22949, 13);
    }
    _22949 = NOVALUE;
    if (IS_ATOM_INT(_22950))
    _22948 = (_22950 != 0);
    else
    _22948 = DBL_PTR(_22950)->dbl != 0.0;
L3: 
    DeRef(_22942);
    _22942 = (_22948 != 0);
L1: 
    if (_22942 == 0) {
        _22951 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43856);
    _22952 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22952)) {
        _22953 = (_22952 != 0);
    }
    else {
        _22953 = binary_op(NOTEQ, _22952, 0);
    }
    _22952 = NOVALUE;
    if (IS_ATOM_INT(_22953))
    _22951 = (_22953 != 0);
    else
    _22951 = DBL_PTR(_22953)->dbl != 0.0;
L4: 
    if (_22951 == 0) {
        _22954 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43856);
    _22955 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22955)) {
        _22956 = (_22955 != 99);
    }
    else {
        _22956 = binary_op(NOTEQ, _22955, 99);
    }
    _22955 = NOVALUE;
    if (IS_ATOM_INT(_22956))
    _22954 = (_22956 != 0);
    else
    _22954 = DBL_PTR(_22956)->dbl != 0.0;
L5: 
    if (_22954 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43856);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _22958 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _22958 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _22959 = find_from(_22958, _29RTN_TOKS_12277, 1);
    _22958 = NOVALUE;
    _22960 = (_22959 == 0);
    _22959 = NOVALUE;
    if (_22960 == 0)
    {
        DeRef(_22960);
        _22960 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22960);
        _22960 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43856);
    DeRef(_22956);
    _22956 = NOVALUE;
    DeRef(_22944);
    _22944 = NOVALUE;
    DeRef(_22950);
    _22950 = NOVALUE;
    DeRef(_22947);
    _22947 = NOVALUE;
    DeRef(_22953);
    _22953 = NOVALUE;
    DeRef(_22941);
    _22941 = NOVALUE;
    return 1;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43856);
    DeRef(_22956);
    _22956 = NOVALUE;
    DeRef(_22944);
    _22944 = NOVALUE;
    DeRef(_22950);
    _22950 = NOVALUE;
    DeRef(_22947);
    _22947 = NOVALUE;
    DeRef(_22953);
    _22953 = NOVALUE;
    DeRef(_22941);
    _22941 = NOVALUE;
    return 0;
L7: 
    ;
}


void _57DeclareFileVars()
{
    object _s_43897 = NOVALUE;
    object _eentry_43899 = NOVALUE;
    object _cleanup_vars_43993 = NOVALUE;
    object _23043 = NOVALUE;
    object _23036 = NOVALUE;
    object _23031 = NOVALUE;
    object _23028 = NOVALUE;
    object _23027 = NOVALUE;
    object _23026 = NOVALUE;
    object _23024 = NOVALUE;
    object _23020 = NOVALUE;
    object _23016 = NOVALUE;
    object _23013 = NOVALUE;
    object _23012 = NOVALUE;
    object _23011 = NOVALUE;
    object _23009 = NOVALUE;
    object _23005 = NOVALUE;
    object _23001 = NOVALUE;
    object _23000 = NOVALUE;
    object _22999 = NOVALUE;
    object _22996 = NOVALUE;
    object _22995 = NOVALUE;
    object _22993 = NOVALUE;
    object _22992 = NOVALUE;
    object _22991 = NOVALUE;
    object _22990 = NOVALUE;
    object _22986 = NOVALUE;
    object _22985 = NOVALUE;
    object _22984 = NOVALUE;
    object _22983 = NOVALUE;
    object _22982 = NOVALUE;
    object _22981 = NOVALUE;
    object _22980 = NOVALUE;
    object _22979 = NOVALUE;
    object _22978 = NOVALUE;
    object _22977 = NOVALUE;
    object _22976 = NOVALUE;
    object _22975 = NOVALUE;
    object _22974 = NOVALUE;
    object _22973 = NOVALUE;
    object _22972 = NOVALUE;
    object _22971 = NOVALUE;
    object _22970 = NOVALUE;
    object _22969 = NOVALUE;
    object _22968 = NOVALUE;
    object _22967 = NOVALUE;
    object _22966 = NOVALUE;
    object _22965 = NOVALUE;
    object _22962 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22961);
    _54c_puts(_22961);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _22962 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_22962);
    _s_43897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43897)){
        _s_43897 = (object)DBL_PTR(_s_43897)->dbl;
    }
    _22962 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43897 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43899);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_43899 = (object)*(((s1_ptr)_2)->base + _s_43897);
    Ref(_eentry_43899);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22965 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22965)) {
        _22966 = (_22965 >= 5);
    }
    else {
        _22966 = binary_op(GREATEREQ, _22965, 5);
    }
    _22965 = NOVALUE;
    if (IS_ATOM_INT(_22966)) {
        if (_22966 == 0) {
            DeRef(_22967);
            _22967 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22966)->dbl == 0.0) {
            DeRef(_22967);
            _22967 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22968 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22968)) {
        _22969 = (_22968 <= 6);
    }
    else {
        _22969 = binary_op(LESSEQ, _22968, 6);
    }
    _22968 = NOVALUE;
    if (IS_ATOM_INT(_22969)) {
        if (_22969 != 0) {
            DeRef(_22970);
            _22970 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22969)->dbl != 0.0) {
            DeRef(_22970);
            _22970 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22971 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22971)) {
        _22972 = (_22971 == 11);
    }
    else {
        _22972 = binary_op(EQUALS, _22971, 11);
    }
    _22971 = NOVALUE;
    DeRef(_22970);
    if (IS_ATOM_INT(_22972))
    _22970 = (_22972 != 0);
    else
    _22970 = DBL_PTR(_22972)->dbl != 0.0;
L4: 
    if (_22970 != 0) {
        _22973 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22974 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22974)) {
        _22975 = (_22974 == 13);
    }
    else {
        _22975 = binary_op(EQUALS, _22974, 13);
    }
    _22974 = NOVALUE;
    if (IS_ATOM_INT(_22975))
    _22973 = (_22975 != 0);
    else
    _22973 = DBL_PTR(_22975)->dbl != 0.0;
L5: 
    DeRef(_22967);
    _22967 = (_22973 != 0);
L3: 
    if (_22967 == 0) {
        _22976 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22977 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22977)) {
        _22978 = (_22977 != 0);
    }
    else {
        _22978 = binary_op(NOTEQ, _22977, 0);
    }
    _22977 = NOVALUE;
    if (IS_ATOM_INT(_22978))
    _22976 = (_22978 != 0);
    else
    _22976 = DBL_PTR(_22978)->dbl != 0.0;
L6: 
    if (_22976 == 0) {
        _22979 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22980 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22980)) {
        _22981 = (_22980 != 99);
    }
    else {
        _22981 = binary_op(NOTEQ, _22980, 99);
    }
    _22980 = NOVALUE;
    if (IS_ATOM_INT(_22981))
    _22979 = (_22981 != 0);
    else
    _22979 = DBL_PTR(_22981)->dbl != 0.0;
L7: 
    if (_22979 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _22983 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _22983 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _22984 = find_from(_22983, _29RTN_TOKS_12277, 1);
    _22983 = NOVALUE;
    _22985 = (_22984 == 0);
    _22984 = NOVALUE;
    if (_22985 == 0)
    {
        DeRef(_22985);
        _22985 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_22985);
        _22985 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _22986 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _22986 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (binary_op_a(NOTEQ, _22986, 27)){
        _22986 = NOVALUE;
        goto L9; // [190] 202
    }
    _22986 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_22988);
    _54c_puts(_22988);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_22989);
    _54c_puts(_22989);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _22990 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _22990 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    RefDS(_22332);
    Ref(_22990);
    _54c_printf(_22332, _22990);
    _22990 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _22991 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _22991 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_22991);
    _54c_puts(_22991);
    _22991 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22992 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_22992);
    _22993 = _27is_integer(_22992);
    _22992 = NOVALUE;
    if (_22993 == 0) {
        DeRef(_22993);
        _22993 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_22993) && DBL_PTR(_22993)->dbl == 0.0){
            DeRef(_22993);
            _22993 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_22993);
        _22993 = NOVALUE;
    }
    DeRef(_22993);
    _22993 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    _22995 = (object)*(((s1_ptr)_2)->base + 1);
    RefDS(_58LL_suffix_30383);
    Ref(_22995);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _22995;
    ((intptr_t *)_2)[2] = _58LL_suffix_30383;
    _22996 = MAKE_SEQ(_1);
    _22995 = NOVALUE;
    RefDS(_22994);
    _54c_printf(_22994, _22996);
    _22996 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_22997);
    _54c_puts(_22997);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_22998);
    _54c_hputs(_22998);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _22999 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _22999 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    RefDS(_22332);
    Ref(_22999);
    _54c_hprintf(_22332, _22999);
    _22999 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23000 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23000 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23000);
    _54c_hputs(_23000);
    _23000 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22485);
    _54c_hputs(_22485);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23001 = (object)*(((s1_ptr)_2)->base + _s_43897);
    _2 = (object)SEQ_PTR(_23001);
    _s_43897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43897)){
        _s_43897 = (object)DBL_PTR(_s_43897)->dbl;
    }
    _23001 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22404);
    _54c_puts(_22404);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22404);
    _54c_hputs(_22404);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_57dll_option_42941 != 0) {
        goto LD; // [342] 353
    }
    if (_57debug_option_42951 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_43993 = 0;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_23004);
    _54c_puts(_23004);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23005 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23005);
    _s_43897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43897)){
        _s_43897 = (object)DBL_PTR(_s_43897)->dbl;
    }
    _23005 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_23007);
    _57c_stmt0(_23007);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43897 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43899);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_43899 = (object)*(((s1_ptr)_2)->base + _s_43897);
    Ref(_eentry_43899);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43899);
    _23009 = _57needs_uninit(_eentry_43899);
    if (_23009 == 0) {
        DeRef(_23009);
        _23009 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_23009) && DBL_PTR(_23009)->dbl == 0.0){
            DeRef(_23009);
            _23009 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_23009);
        _23009 = NOVALUE;
    }
    DeRef(_23009);
    _23009 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23011 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23011 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23012 = EPrintf(-9999999, _23010, _23011);
    _23011 = NOVALUE;
    _57c_stmt0(_23012);
    _23012 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23013 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23013 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23013);
    _54c_puts(_23013);
    _23013 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_23014);
    _54c_printf(_23014, _cleanup_vars_43993);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_43993 = _cleanup_vars_43993 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23016 = (object)*(((s1_ptr)_2)->base + _s_43897);
    _2 = (object)SEQ_PTR(_23016);
    _s_43897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43897)){
        _s_43897 = (object)DBL_PTR(_s_43897)->dbl;
    }
    _23016 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_23018);
    _57c_stmt0(_23018);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_23019);
    _57c_stmt0(_23019);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23020 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23020);
    _s_43897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43897)){
        _s_43897 = (object)DBL_PTR(_s_43897)->dbl;
    }
    _23020 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_23022);
    _57c_stmt0(_23022);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_43993 = 0;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43897 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43899);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_43899 = (object)*(((s1_ptr)_2)->base + _s_43897);
    Ref(_eentry_43899);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43899);
    _23024 = _57needs_uninit(_eentry_43899);
    if (_23024 == 0) {
        DeRef(_23024);
        _23024 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_23024) && DBL_PTR(_23024)->dbl == 0.0){
            DeRef(_23024);
            _23024 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_23024);
        _23024 = NOVALUE;
    }
    DeRef(_23024);
    _23024 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23026 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23026 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23027 = EPrintf(-9999999, _23025, _23026);
    _23026 = NOVALUE;
    _57c_stmt0(_23027);
    _23027 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43899);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23028 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23028 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_23028);
    _54c_puts(_23028);
    _23028 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_23029);
    _54c_printf(_23029, _cleanup_vars_43993);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_43993 = _cleanup_vars_43993 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23031 = (object)*(((s1_ptr)_2)->base + _s_43897);
    _2 = (object)SEQ_PTR(_23031);
    _s_43897 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43897)){
        _s_43897 = (object)DBL_PTR(_s_43897)->dbl;
    }
    _23031 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_23018);
    _57c_stmt0(_23018);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_23019);
    _57c_stmt0(_23019);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_23033);
    _57c_stmt0(_23033);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22293);
    _57c_stmt0(_22293);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_23034);
    _57c_stmt0(_23034);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23036 = EPrintf(-9999999, _23035, _cleanup_vars_43993);
    _57c_stmt0(_23036);
    _23036 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_23037);
    _57c_stmt0(_23037);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_23038);
    _57c_stmt0(_23038);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_23039);
    _57c_stmt0(_23039);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_23040);
    _57c_stmt0(_23040);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_23041);
    _57c_stmt0(_23041);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_23042);
    _57c_stmt0(_23042);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23043 = EPrintf(-9999999, _23035, _cleanup_vars_43993);
    _57c_stmt0(_23043);
    _23043 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_23044);
    _57c_stmt0(_23044);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_23045);
    _57c_stmt0(_23045);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_16189);
    _57c_stmt0(_16189);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43899);
    DeRef(_22978);
    _22978 = NOVALUE;
    DeRef(_22969);
    _22969 = NOVALUE;
    DeRef(_22966);
    _22966 = NOVALUE;
    DeRef(_22972);
    _22972 = NOVALUE;
    DeRef(_22975);
    _22975 = NOVALUE;
    DeRef(_22981);
    _22981 = NOVALUE;
    return;
    ;
}


object _57PromoteTypeInfo()
{
    object _updsym_44064 = NOVALUE;
    object _s_44066 = NOVALUE;
    object _sym_44067 = NOVALUE;
    object _symo_44068 = NOVALUE;
    object _upd_44297 = NOVALUE;
    object _23144 = NOVALUE;
    object _23142 = NOVALUE;
    object _23141 = NOVALUE;
    object _23140 = NOVALUE;
    object _23139 = NOVALUE;
    object _23137 = NOVALUE;
    object _23135 = NOVALUE;
    object _23134 = NOVALUE;
    object _23133 = NOVALUE;
    object _23132 = NOVALUE;
    object _23131 = NOVALUE;
    object _23127 = NOVALUE;
    object _23124 = NOVALUE;
    object _23123 = NOVALUE;
    object _23122 = NOVALUE;
    object _23121 = NOVALUE;
    object _23120 = NOVALUE;
    object _23119 = NOVALUE;
    object _23118 = NOVALUE;
    object _23117 = NOVALUE;
    object _23116 = NOVALUE;
    object _23115 = NOVALUE;
    object _23114 = NOVALUE;
    object _23112 = NOVALUE;
    object _23111 = NOVALUE;
    object _23110 = NOVALUE;
    object _23109 = NOVALUE;
    object _23108 = NOVALUE;
    object _23107 = NOVALUE;
    object _23106 = NOVALUE;
    object _23105 = NOVALUE;
    object _23104 = NOVALUE;
    object _23103 = NOVALUE;
    object _23101 = NOVALUE;
    object _23100 = NOVALUE;
    object _23099 = NOVALUE;
    object _23097 = NOVALUE;
    object _23096 = NOVALUE;
    object _23095 = NOVALUE;
    object _23093 = NOVALUE;
    object _23092 = NOVALUE;
    object _23091 = NOVALUE;
    object _23090 = NOVALUE;
    object _23089 = NOVALUE;
    object _23088 = NOVALUE;
    object _23087 = NOVALUE;
    object _23085 = NOVALUE;
    object _23084 = NOVALUE;
    object _23083 = NOVALUE;
    object _23082 = NOVALUE;
    object _23080 = NOVALUE;
    object _23079 = NOVALUE;
    object _23077 = NOVALUE;
    object _23076 = NOVALUE;
    object _23075 = NOVALUE;
    object _23074 = NOVALUE;
    object _23073 = NOVALUE;
    object _23072 = NOVALUE;
    object _23071 = NOVALUE;
    object _23069 = NOVALUE;
    object _23068 = NOVALUE;
    object _23067 = NOVALUE;
    object _23066 = NOVALUE;
    object _23065 = NOVALUE;
    object _23064 = NOVALUE;
    object _23063 = NOVALUE;
    object _23062 = NOVALUE;
    object _23061 = NOVALUE;
    object _23060 = NOVALUE;
    object _23059 = NOVALUE;
    object _23058 = NOVALUE;
    object _23057 = NOVALUE;
    object _23056 = NOVALUE;
    object _23054 = NOVALUE;
    object _23053 = NOVALUE;
    object _23052 = NOVALUE;
    object _23050 = NOVALUE;
    object _23049 = NOVALUE;
    object _23046 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_44064 = 0;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _57g_has_delete_43123 = _57p_has_delete_43124;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23046 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23046);
    _s_44066 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44066)){
        _s_44066 = (object)DBL_PTR(_s_44066)->dbl;
    }
    _23046 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_44066 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_44067);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _sym_44067 = (object)*(((s1_ptr)_2)->base + _s_44066);
    Ref(_sym_44067);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_44067);
    DeRef(_symo_44068);
    _symo_44068 = _sym_44067;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23049 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23049 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (IS_ATOM_INT(_23049)) {
        _23050 = (_23049 == 501);
    }
    else {
        _23050 = binary_op(EQUALS, _23049, 501);
    }
    _23049 = NOVALUE;
    if (IS_ATOM_INT(_23050)) {
        if (_23050 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_23050)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23052 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23052 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (IS_ATOM_INT(_23052)) {
        _23053 = (_23052 == 504);
    }
    else {
        _23053 = binary_op(EQUALS, _23052, 504);
    }
    _23052 = NOVALUE;
    if (_23053 == 0) {
        DeRef(_23053);
        _23053 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_23053) && DBL_PTR(_23053)->dbl == 0.0){
            DeRef(_23053);
            _23053 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_23053);
        _23053 = NOVALUE;
    }
    DeRef(_23053);
    _23053 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23054 = (object)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _23054, 0)){
        _23054 = NOVALUE;
        goto L5; // [103] 120
    }
    _23054 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23056 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_23056);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23056;
    if( _1 != _23056 ){
        DeRef(_1);
    }
    _23056 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23057 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_23057)) {
        _23058 = (_23057 != 1);
    }
    else {
        _23058 = binary_op(NOTEQ, _23057, 1);
    }
    _23057 = NOVALUE;
    if (IS_ATOM_INT(_23058)) {
        if (_23058 == 0) {
            DeRef(_23059);
            _23059 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_23058)->dbl == 0.0) {
            DeRef(_23059);
            _23059 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23060 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23060)) {
        _23061 = (_23060 != 16);
    }
    else {
        _23061 = binary_op(NOTEQ, _23060, 16);
    }
    _23060 = NOVALUE;
    DeRef(_23059);
    if (IS_ATOM_INT(_23061))
    _23059 = (_23061 != 0);
    else
    _23059 = DBL_PTR(_23061)->dbl != 0.0;
L7: 
    if (_23059 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23063 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23063)) {
        _23064 = (_23063 != 0);
    }
    else {
        _23064 = binary_op(NOTEQ, _23063, 0);
    }
    _23063 = NOVALUE;
    if (_23064 == 0) {
        DeRef(_23064);
        _23064 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_23064) && DBL_PTR(_23064)->dbl == 0.0){
            DeRef(_23064);
            _23064 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_23064);
        _23064 = NOVALUE;
    }
    DeRef(_23064);
    _23064 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23065 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23065)) {
        _23066 = (_23065 == 1);
    }
    else {
        _23066 = binary_op(EQUALS, _23065, 1);
    }
    _23065 = NOVALUE;
    if (IS_ATOM_INT(_23066)) {
        if (_23066 != 0) {
            DeRef(_23067);
            _23067 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_23066)->dbl != 0.0) {
            DeRef(_23067);
            _23067 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23068 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_23068)) {
        _23069 = (_23068 == 16);
    }
    else {
        _23069 = binary_op(EQUALS, _23068, 16);
    }
    _23068 = NOVALUE;
    DeRef(_23067);
    if (IS_ATOM_INT(_23069))
    _23067 = (_23069 != 0);
    else
    _23067 = DBL_PTR(_23069)->dbl != 0.0;
L9: 
    if (_23067 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23071 = (object)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_23071)) {
        _23072 = (_23071 == 4);
    }
    else {
        _23072 = binary_op(EQUALS, _23071, 4);
    }
    _23071 = NOVALUE;
    if (IS_ATOM_INT(_23072)) {
        if (_23072 == 0) {
            DeRef(_23073);
            _23073 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_23072)->dbl == 0.0) {
            DeRef(_23073);
            _23073 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23074 = (object)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_23074)) {
        _23075 = (_23074 == 2);
    }
    else {
        _23075 = binary_op(EQUALS, _23074, 2);
    }
    _23074 = NOVALUE;
    DeRef(_23073);
    if (IS_ATOM_INT(_23075))
    _23073 = (_23075 != 0);
    else
    _23073 = DBL_PTR(_23075)->dbl != 0.0;
LB: 
    if (_23073 == 0)
    {
        _23073 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _23073 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23076 = (object)*(((s1_ptr)_2)->base + 38);
    Ref(_23076);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23076;
    if( _1 != _23076 ){
        DeRef(_1);
    }
    _23076 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23077 = (object)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _23077, 0)){
        _23077 = NOVALUE;
        goto LD; // [293] 310
    }
    _23077 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23079 = (object)*(((s1_ptr)_2)->base + 44);
    Ref(_23079);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23079;
    if( _1 != _23079 ){
        DeRef(_1);
    }
    _23079 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23080 = (object)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _23080, 0)){
        _23080 = NOVALUE;
        goto LF; // [345] 362
    }
    _23080 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23082 = (object)*(((s1_ptr)_2)->base + 46);
    Ref(_23082);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23082;
    if( _1 != _23082 ){
        DeRef(_1);
    }
    _23082 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23083 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23084 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23084 = - _27NOVALUE_20426;
        }
    }
    else {
        _23084 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (IS_ATOM_INT(_23083) && IS_ATOM_INT(_23084)) {
        _23085 = (_23083 == _23084);
    }
    else {
        _23085 = binary_op(EQUALS, _23083, _23084);
    }
    _23083 = NOVALUE;
    DeRef(_23084);
    _23084 = NOVALUE;
    if (IS_ATOM_INT(_23085)) {
        if (_23085 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_23085)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23087 = (object)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_23087) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _23088 = (_23087 == _27NOVALUE_20426);
    }
    else {
        _23088 = binary_op(EQUALS, _23087, _27NOVALUE_20426);
    }
    _23087 = NOVALUE;
    if (_23088 == 0) {
        DeRef(_23088);
        _23088 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_23088) && DBL_PTR(_23088)->dbl == 0.0){
            DeRef(_23088);
            _23088 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_23088);
        _23088 = NOVALUE;
    }
    DeRef(_23088);
    _23088 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23089 = (object)*(((s1_ptr)_2)->base + 49);
    Ref(_23089);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23089;
    if( _1 != _23089 ){
        DeRef(_1);
    }
    _23089 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23090 = (object)*(((s1_ptr)_2)->base + 50);
    Ref(_23090);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23090;
    if( _1 != _23090 ){
        DeRef(_1);
    }
    _23090 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23091 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23091 = - _27NOVALUE_20426;
        }
    }
    else {
        _23091 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23091;
    if( _1 != _23091 ){
        DeRef(_1);
    }
    _23091 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23092 = (object)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23093 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23093 = - _27NOVALUE_20426;
        }
    }
    else {
        _23093 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _23092, _23093)){
        _23092 = NOVALUE;
        DeRef(_23093);
        _23093 = NOVALUE;
        goto L14; // [503] 520
    }
    _23092 = NOVALUE;
    DeRef(_23093);
    _23093 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23095 = (object)*(((s1_ptr)_2)->base + 52);
    Ref(_23095);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23095;
    if( _1 != _23095 ){
        DeRef(_1);
    }
    _23095 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23096 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23096 = - _27NOVALUE_20426;
        }
    }
    else {
        _23096 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23096;
    if( _1 != _23096 ){
        DeRef(_1);
    }
    _23096 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23097 = (object)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _23097, 0)){
        _23097 = NOVALUE;
        goto L16; // [569] 586
    }
    _23097 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23099 = (object)*(((s1_ptr)_2)->base + 40);
    Ref(_23099);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23099;
    if( _1 != _23099 ){
        DeRef(_1);
    }
    _23099 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23100 = (object)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23101 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23101 = - _27NOVALUE_20426;
        }
    }
    else {
        _23101 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (binary_op_a(NOTEQ, _23100, _23101)){
        _23100 = NOVALUE;
        DeRef(_23101);
        _23101 = NOVALUE;
        goto L18; // [624] 641
    }
    _23100 = NOVALUE;
    DeRef(_23101);
    _23101 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23103 = (object)*(((s1_ptr)_2)->base + 39);
    Ref(_23103);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23103;
    if( _1 != _23103 ){
        DeRef(_1);
    }
    _23103 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23104 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23104 = - _27NOVALUE_20426;
        }
    }
    else {
        _23104 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23104;
    if( _1 != _23104 ){
        DeRef(_1);
    }
    _23104 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23105 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23105 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    if (IS_ATOM_INT(_23105)) {
        _23106 = (_23105 != 523);
    }
    else {
        _23106 = binary_op(NOTEQ, _23105, 523);
    }
    _23105 = NOVALUE;
    if (IS_ATOM_INT(_23106)) {
        if (_23106 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_23106)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23108 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_23108)) {
        _23109 = (_23108 != 2);
    }
    else {
        _23109 = binary_op(NOTEQ, _23108, 2);
    }
    _23108 = NOVALUE;
    if (_23109 == 0) {
        DeRef(_23109);
        _23109 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_23109) && DBL_PTR(_23109)->dbl == 0.0){
            DeRef(_23109);
            _23109 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_23109);
        _23109 = NOVALUE;
    }
    DeRef(_23109);
    _23109 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23110 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23111 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23111 = - _27NOVALUE_20426;
        }
    }
    else {
        _23111 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    if (IS_ATOM_INT(_23110) && IS_ATOM_INT(_23111)) {
        _23112 = (_23110 == _23111);
    }
    else {
        _23112 = binary_op(EQUALS, _23110, _23111);
    }
    _23110 = NOVALUE;
    DeRef(_23111);
    _23111 = NOVALUE;
    if (IS_ATOM_INT(_23112)) {
        if (_23112 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_23112)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    _23114 = (object)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_23114) && IS_ATOM_INT(_27NOVALUE_20426)) {
        _23115 = (_23114 == _27NOVALUE_20426);
    }
    else {
        _23115 = binary_op(EQUALS, _23114, _27NOVALUE_20426);
    }
    _23114 = NOVALUE;
    if (_23115 == 0) {
        DeRef(_23115);
        _23115 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_23115) && DBL_PTR(_23115)->dbl == 0.0){
            DeRef(_23115);
            _23115 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_23115);
        _23115 = NOVALUE;
    }
    DeRef(_23115);
    _23115 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1073741824;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23116 = (object)*(((s1_ptr)_2)->base + 41);
    Ref(_23116);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23116;
    if( _1 != _23116 ){
        DeRef(_1);
    }
    _23116 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23117 = (object)*(((s1_ptr)_2)->base + 42);
    Ref(_23117);
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23117;
    if( _1 != _23117 ){
        DeRef(_1);
    }
    _23117 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_27NOVALUE_20426)) {
        if ((uintptr_t)_27NOVALUE_20426 == (uintptr_t)HIGH_BITS){
            _23118 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23118 = - _27NOVALUE_20426;
        }
    }
    else {
        _23118 = unary_op(UMINUS, _27NOVALUE_20426);
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23118;
    if( _1 != _23118 ){
        DeRef(_1);
    }
    _23118 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23119 = (object)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_23119)) {
        _23120 = (_23119 == 1);
    }
    else {
        _23120 = binary_op(EQUALS, _23119, 1);
    }
    _23119 = NOVALUE;
    if (IS_ATOM_INT(_23120)) {
        if (_23120 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_23120)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23122 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23122 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23123 = find_from(_23122, _29RTN_TOKS_12277, 1);
    _23122 = NOVALUE;
    if (_23123 == 0)
    {
        _23123 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _23123 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _23124 = (object)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _23124, 99)){
        _23124 = NOVALUE;
        goto L1F; // [850] 873
    }
    _23124 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _57deleted_routines_44061 = _57deleted_routines_44061 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_44067);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44067 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_44068 == _sym_44067)
    _23127 = 1;
    else if (IS_ATOM_INT(_symo_44068) && IS_ATOM_INT(_sym_44067))
    _23127 = 0;
    else
    _23127 = (compare(_symo_44068, _sym_44067) == 0);
    if (_23127 != 0)
    goto L20; // [888] 906
    _23127 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_44067);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_44066);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_44067;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_44064 = _updsym_44064 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_44067);
    _s_44066 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44066)){
        _s_44066 = (object)DBL_PTR(_s_44066)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_27temp_name_type_20654)){
            _23131 = SEQ_PTR(_27temp_name_type_20654)->length;
    }
    else {
        _23131 = 1;
    }
    {
        object _i_44294;
        _i_44294 = 1;
L21: 
        if (_i_44294 > _23131){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_44297 = 0;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23132 = (object)*(((s1_ptr)_2)->base + _i_44294);
        _2 = (object)SEQ_PTR(_23132);
        _23133 = (object)*(((s1_ptr)_2)->base + 1);
        _23132 = NOVALUE;
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23134 = (object)*(((s1_ptr)_2)->base + _i_44294);
        _2 = (object)SEQ_PTR(_23134);
        _23135 = (object)*(((s1_ptr)_2)->base + 2);
        _23134 = NOVALUE;
        if (binary_op_a(EQUALS, _23133, _23135)){
            _23133 = NOVALUE;
            _23135 = NOVALUE;
            goto L23; // [966] 1003
        }
        _23133 = NOVALUE;
        _23135 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _27temp_name_type_20654 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44294 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23139 = (object)*(((s1_ptr)_2)->base + _i_44294);
        _2 = (object)SEQ_PTR(_23139);
        _23140 = (object)*(((s1_ptr)_2)->base + 2);
        _23139 = NOVALUE;
        Ref(_23140);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23140;
        if( _1 != _23140 ){
            DeRef(_1);
        }
        _23140 = NOVALUE;
        _23137 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_44297 = 1;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        _23141 = (object)*(((s1_ptr)_2)->base + _i_44294);
        _2 = (object)SEQ_PTR(_23141);
        _23142 = (object)*(((s1_ptr)_2)->base + 2);
        _23141 = NOVALUE;
        if (binary_op_a(EQUALS, _23142, 0)){
            _23142 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _23142 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_27temp_name_type_20654);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _27temp_name_type_20654 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44294 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0;
        DeRef(_1);
        _23144 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_44297 = 1;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_44064 = _updsym_44064 + _upd_44297;

        /** c_decl.e:983		end for*/
        _i_44294 = _i_44294 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_44067);
    DeRef(_symo_44068);
    DeRef(_23106);
    _23106 = NOVALUE;
    DeRef(_23058);
    _23058 = NOVALUE;
    DeRef(_23069);
    _23069 = NOVALUE;
    DeRef(_23120);
    _23120 = NOVALUE;
    DeRef(_23075);
    _23075 = NOVALUE;
    DeRef(_23050);
    _23050 = NOVALUE;
    DeRef(_23085);
    _23085 = NOVALUE;
    DeRef(_23066);
    _23066 = NOVALUE;
    DeRef(_23072);
    _23072 = NOVALUE;
    DeRef(_23061);
    _23061 = NOVALUE;
    DeRef(_23112);
    _23112 = NOVALUE;
    return _updsym_44064;
    ;
}


void _57declare_prototype(object _s_44332)
{
    object _ret_type_44333 = NOVALUE;
    object _scope_44344 = NOVALUE;
    object _23164 = NOVALUE;
    object _23163 = NOVALUE;
    object _23161 = NOVALUE;
    object _23160 = NOVALUE;
    object _23159 = NOVALUE;
    object _23158 = NOVALUE;
    object _23156 = NOVALUE;
    object _23155 = NOVALUE;
    object _23154 = NOVALUE;
    object _23153 = NOVALUE;
    object _23152 = NOVALUE;
    object _23150 = NOVALUE;
    object _23149 = NOVALUE;
    object _23147 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _23147 = _53sym_token(_s_44332);
    if (binary_op_a(NOTEQ, _23147, 27)){
        DeRef(_23147);
        _23147 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_23147);
    _23147 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_22988);
    DeRefi(_ret_type_44333);
    _ret_type_44333 = _22988;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_22989);
    DeRefi(_ret_type_44333);
    _ret_type_44333 = _22989;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_44333);
    _54c_hputs(_ret_type_44333);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_57dll_option_42941 == 0) {
        goto L3; // [44] 116
    }
    if (_44TWINDOWS_20715 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23150 = (object)*(((s1_ptr)_2)->base + _s_44332);
    _2 = (object)SEQ_PTR(_23150);
    _scope_44344 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44344)){
        _scope_44344 = (object)DBL_PTR(_scope_44344)->dbl;
    }
    _23150 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _23152 = (_scope_44344 == 13);
    if (_23152 != 0) {
        _23153 = 1;
        goto L4; // [78] 92
    }
    _23154 = (_scope_44344 == 11);
    _23153 = (_23154 != 0);
L4: 
    if (_23153 != 0) {
        DeRef(_23155);
        _23155 = 1;
        goto L5; // [92] 106
    }
    _23156 = (_scope_44344 == 6);
    _23155 = (_23156 != 0);
L5: 
    if (_23155 == 0)
    {
        _23155 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _23155 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_23157);
    _54c_hputs(_23157);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23158 = (object)*(((s1_ptr)_2)->base + _s_44332);
    _2 = (object)SEQ_PTR(_23158);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23159 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23159 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23158 = NOVALUE;
    RefDS(_22332);
    Ref(_23159);
    _54c_hprintf(_22332, _23159);
    _23159 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23160 = (object)*(((s1_ptr)_2)->base + _s_44332);
    _2 = (object)SEQ_PTR(_23160);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23161 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23161 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23160 = NOVALUE;
    Ref(_23161);
    _54c_hputs(_23161);
    _23161 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_23162);
    _54c_hputs(_23162);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23163 = (object)*(((s1_ptr)_2)->base + _s_44332);
    _2 = (object)SEQ_PTR(_23163);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _23164 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _23164 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _23163 = NOVALUE;
    {
        object _i_44373;
        _i_44373 = 1;
L7: 
        if (binary_op_a(GREATER, _i_44373, _23164)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44373, 1)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_23166);
        _54c_hputs(_23166);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_23167);
        _54c_hputs(_23167);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44373;
        if (IS_ATOM_INT(_i_44373)) {
            _i_44373 = _i_44373 + 1;
            if ((object)((uintptr_t)_i_44373 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44373 = NewDouble((eudouble)_i_44373);
            }
        }
        else {
            _i_44373 = binary_op_a(PLUS, _i_44373, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44373);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22513);
    _54c_hputs(_22513);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_44333);
    _23164 = NOVALUE;
    DeRef(_23156);
    _23156 = NOVALUE;
    DeRef(_23154);
    _23154 = NOVALUE;
    DeRef(_23152);
    _23152 = NOVALUE;
    return;
    ;
}


void _57add_to_routine_list(object _s_44389, object _seq_num_44390, object _first_44391)
{
    object _p_44466 = NOVALUE;
    object _23213 = NOVALUE;
    object _23211 = NOVALUE;
    object _23209 = NOVALUE;
    object _23207 = NOVALUE;
    object _23205 = NOVALUE;
    object _23204 = NOVALUE;
    object _23203 = NOVALUE;
    object _23201 = NOVALUE;
    object _23199 = NOVALUE;
    object _23197 = NOVALUE;
    object _23196 = NOVALUE;
    object _23194 = NOVALUE;
    object _23193 = NOVALUE;
    object _23189 = NOVALUE;
    object _23188 = NOVALUE;
    object _23187 = NOVALUE;
    object _23186 = NOVALUE;
    object _23185 = NOVALUE;
    object _23184 = NOVALUE;
    object _23183 = NOVALUE;
    object _23182 = NOVALUE;
    object _23181 = NOVALUE;
    object _23180 = NOVALUE;
    object _23178 = NOVALUE;
    object _23177 = NOVALUE;
    object _23176 = NOVALUE;
    object _23175 = NOVALUE;
    object _23172 = NOVALUE;
    object _23171 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44391 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_23169);
    _54c_puts(_23169);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_23170);
    _54c_puts(_23170);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23171 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23171);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23172 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23172 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23171 = NOVALUE;
    Ref(_23172);
    _54c_puts(_23172);
    _23172 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_23173);
    _54c_puts(_23173);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_23174);
    _54c_puts(_23174);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23175 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23175);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23176 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23176 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23175 = NOVALUE;
    RefDS(_22332);
    Ref(_23176);
    _54c_printf(_22332, _23176);
    _23176 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23177 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23177);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23178 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23178 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23177 = NOVALUE;
    Ref(_23178);
    _54c_puts(_23178);
    _23178 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_23179);
    _54c_printf(_23179, _seq_num_44390);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23180 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23180);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23181 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23181 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23180 = NOVALUE;
    RefDS(_23179);
    Ref(_23181);
    _54c_printf(_23179, _23181);
    _23181 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23182 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23182);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _23183 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _23183 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _23182 = NOVALUE;
    RefDS(_23179);
    Ref(_23183);
    _54c_printf(_23179, _23183);
    _23183 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_44TWINDOWS_20715 == 0) {
        _23184 = 0;
        goto L2; // [131] 141
    }
    _23184 = (_57dll_option_42941 != 0);
L2: 
    if (_23184 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23186 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23186);
    _23187 = (object)*(((s1_ptr)_2)->base + 4);
    _23186 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 11;
    ((intptr_t*)_2)[3] = 13;
    _23188 = MAKE_SEQ(_1);
    _23189 = find_from(_23187, _23188, 1);
    _23187 = NOVALUE;
    DeRefDS(_23188);
    _23188 = NOVALUE;
    if (_23189 == 0)
    {
        _23189 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _23189 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_23190);
    _54c_puts(_23190);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_23191);
    _54c_puts(_23191);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23193 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23193);
    _23194 = (object)*(((s1_ptr)_2)->base + 4);
    _23193 = NOVALUE;
    RefDS(_23192);
    Ref(_23194);
    _54c_printf(_23192, _23194);
    _23194 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_23195);
    _54c_puts(_23195);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23196 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23196);
    _23197 = (object)*(((s1_ptr)_2)->base + 12);
    _23196 = NOVALUE;
    if (binary_op_a(GREATEREQ, _23197, 2)){
        _23197 = NOVALUE;
        goto L5; // [229] 249
    }
    _23197 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44389 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _23199 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23201 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23201);
    _p_44466 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_44466)){
        _p_44466 = (object)DBL_PTR(_p_44466)->dbl;
    }
    _23201 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23203 = (object)*(((s1_ptr)_2)->base + _s_44389);
    _2 = (object)SEQ_PTR(_23203);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _23204 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _23204 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _23203 = NOVALUE;
    {
        object _i_44472;
        _i_44472 = 1;
L6: 
        if (binary_op_a(GREATER, _i_44472, _23204)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44466 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23205 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44466 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16;
        DeRef(_1);
        _23207 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44466 + ((s1_ptr)_2)->base);
        Ref(_27NOVALUE_20426);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27NOVALUE_20426;
        DeRef(_1);
        _23209 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44466 + ((s1_ptr)_2)->base);
        Ref(_27NOVALUE_20426);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27NOVALUE_20426;
        DeRef(_1);
        _23211 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23213 = (object)*(((s1_ptr)_2)->base + _p_44466);
        _2 = (object)SEQ_PTR(_23213);
        _p_44466 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_44466)){
            _p_44466 = (object)DBL_PTR(_p_44466)->dbl;
        }
        _23213 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44472;
        if (IS_ATOM_INT(_i_44472)) {
            _i_44472 = _i_44472 + 1;
            if ((object)((uintptr_t)_i_44472 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44472 = NewDouble((eudouble)_i_44472);
            }
        }
        else {
            _i_44472 = binary_op_a(PLUS, _i_44472, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44472);
    }

    /** c_decl.e:1063	end procedure*/
    _23204 = NOVALUE;
    return;
    ;
}


void _57DeclareRoutineList()
{
    object _s_44504 = NOVALUE;
    object _first_44505 = NOVALUE;
    object _seq_num_44506 = NOVALUE;
    object _these_routines_44514 = NOVALUE;
    object _these_routines_44536 = NOVALUE;
    object _23229 = NOVALUE;
    object _23228 = NOVALUE;
    object _23226 = NOVALUE;
    object _23224 = NOVALUE;
    object _23221 = NOVALUE;
    object _23220 = NOVALUE;
    object _23218 = NOVALUE;
    object _23216 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23215);
    _54c_hputs(_23215);

    /** c_decl.e:1073		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_45093)){
            _23216 = SEQ_PTR(_57file_routines_45093)->length;
    }
    else {
        _23216 = 1;
    }
    {
        object _f_44511;
        _f_44511 = 1;
L1: 
        if (_f_44511 > _23216){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44514);
        _2 = (object)SEQ_PTR(_57file_routines_45093);
        _these_routines_44514 = (object)*(((s1_ptr)_2)->base + _f_44511);
        Ref(_these_routines_44514);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44514)){
                _23218 = SEQ_PTR(_these_routines_44514)->length;
        }
        else {
            _23218 = 1;
        }
        {
            object _r_44518;
            _r_44518 = 1;
L3: 
            if (_r_44518 > _23218){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44514);
            _s_44504 = (object)*(((s1_ptr)_2)->base + _r_44518);
            if (!IS_ATOM_INT(_s_44504)){
                _s_44504 = (object)DBL_PTR(_s_44504)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23220 = (object)*(((s1_ptr)_2)->base + _s_44504);
            _2 = (object)SEQ_PTR(_23220);
            _23221 = (object)*(((s1_ptr)_2)->base + 5);
            _23220 = NOVALUE;
            if (binary_op_a(EQUALS, _23221, 99)){
                _23221 = NOVALUE;
                goto L5; // [72] 82
            }
            _23221 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _57declare_prototype(_s_44504);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44518 = _r_44518 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44514);
        _these_routines_44514 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44511 = _f_44511 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22404);
    _54c_puts(_22404);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44506 = 0;

    /** c_decl.e:1089		first = TRUE*/
    _first_44505 = _9TRUE_441;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23223);
    _54c_puts(_23223);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_45093)){
            _23224 = SEQ_PTR(_57file_routines_45093)->length;
    }
    else {
        _23224 = 1;
    }
    {
        object _f_44533;
        _f_44533 = 1;
L6: 
        if (_f_44533 > _23224){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44536);
        _2 = (object)SEQ_PTR(_57file_routines_45093);
        _these_routines_44536 = (object)*(((s1_ptr)_2)->base + _f_44533);
        Ref(_these_routines_44536);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44536)){
                _23226 = SEQ_PTR(_these_routines_44536)->length;
        }
        else {
            _23226 = 1;
        }
        {
            object _r_44540;
            _r_44540 = 1;
L8: 
            if (_r_44540 > _23226){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44536);
            _s_44504 = (object)*(((s1_ptr)_2)->base + _r_44540);
            if (!IS_ATOM_INT(_s_44504)){
                _s_44504 = (object)DBL_PTR(_s_44504)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23228 = (object)*(((s1_ptr)_2)->base + _s_44504);
            _2 = (object)SEQ_PTR(_23228);
            _23229 = (object)*(((s1_ptr)_2)->base + 53);
            _23228 = NOVALUE;
            if (_23229 == 0) {
                _23229 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23229) && DBL_PTR(_23229)->dbl == 0.0){
                    _23229 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23229 = NOVALUE;
            }
            _23229 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _57add_to_routine_list(_s_44504, _seq_num_44506, _first_44505);

            /** c_decl.e:1099					first = FALSE*/
            _first_44505 = _9FALSE_439;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44506 = _seq_num_44506 + 1;

            /** c_decl.e:1103			end for*/
            _r_44540 = _r_44540 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44536);
        _these_routines_44536 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44533 = _f_44533 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44505 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_23169);
    _54c_puts(_23169);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23232);
    _54c_puts(_23232);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23233);
    _54c_hputs(_23233);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23234);
    _54c_puts(_23234);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23235);
    _54c_hputs(_23235);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23236);
    _54c_puts(_23236);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _57DeclareNameSpaceList()
{
    object _s_44566 = NOVALUE;
    object _first_44567 = NOVALUE;
    object _seq_num_44568 = NOVALUE;
    object _23256 = NOVALUE;
    object _23254 = NOVALUE;
    object _23253 = NOVALUE;
    object _23252 = NOVALUE;
    object _23251 = NOVALUE;
    object _23249 = NOVALUE;
    object _23248 = NOVALUE;
    object _23245 = NOVALUE;
    object _23244 = NOVALUE;
    object _23243 = NOVALUE;
    object _23242 = NOVALUE;
    object _23241 = NOVALUE;
    object _23239 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23237);
    _54c_hputs(_23237);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23238);
    _54c_puts(_23238);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44568 = 0;

    /** c_decl.e:1127		first = TRUE*/
    _first_44567 = _9TRUE_441;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23239 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23239);
    _s_44566 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44566)){
        _s_44566 = (object)DBL_PTR(_s_44566)->dbl;
    }
    _23239 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44566 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23241 = (object)*(((s1_ptr)_2)->base + _s_44566);
    _2 = (object)SEQ_PTR(_23241);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23242 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23242 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23241 = NOVALUE;
    _23243 = find_from(_23242, _29NAMED_TOKS_12279, 1);
    _23242 = NOVALUE;
    if (_23243 == 0)
    {
        _23243 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23243 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23244 = (object)*(((s1_ptr)_2)->base + _s_44566);
    _2 = (object)SEQ_PTR(_23244);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23245 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23245 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23244 = NOVALUE;
    if (binary_op_a(NOTEQ, _23245, 523)){
        _23245 = NOVALUE;
        goto L4; // [93] 187
    }
    _23245 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44567 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_23169);
    _54c_puts(_23169);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44567 = _9FALSE_439;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_23170);
    _54c_puts(_23170);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23248 = (object)*(((s1_ptr)_2)->base + _s_44566);
    _2 = (object)SEQ_PTR(_23248);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _23249 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _23249 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _23248 = NOVALUE;
    Ref(_23249);
    _54c_puts(_23249);
    _23249 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23251 = (object)*(((s1_ptr)_2)->base + _s_44566);
    _2 = (object)SEQ_PTR(_23251);
    _23252 = (object)*(((s1_ptr)_2)->base + 1);
    _23251 = NOVALUE;
    RefDS(_23250);
    Ref(_23252);
    _54c_printf(_23250, _23252);
    _23252 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_23179);
    _54c_printf(_23179, _seq_num_44568);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23253 = (object)*(((s1_ptr)_2)->base + _s_44566);
    _2 = (object)SEQ_PTR(_23253);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23254 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23254 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23253 = NOVALUE;
    RefDS(_23179);
    Ref(_23254);
    _54c_printf(_23179, _23254);
    _23254 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_23195);
    _54c_puts(_23195);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44568 = _seq_num_44568 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23256 = (object)*(((s1_ptr)_2)->base + _s_44566);
    _2 = (object)SEQ_PTR(_23256);
    _s_44566 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_44566)){
        _s_44566 = (object)DBL_PTR(_s_44566)->dbl;
    }
    _23256 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44567 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_23169);
    _54c_puts(_23169);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23259);
    _54c_puts(_23259);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _57is_exported(object _s_44630)
{
    object _eentry_44631 = NOVALUE;
    object _scope_44634 = NOVALUE;
    object _23274 = NOVALUE;
    object _23273 = NOVALUE;
    object _23272 = NOVALUE;
    object _23271 = NOVALUE;
    object _23270 = NOVALUE;
    object _23269 = NOVALUE;
    object _23268 = NOVALUE;
    object _23267 = NOVALUE;
    object _23266 = NOVALUE;
    object _23265 = NOVALUE;
    object _23264 = NOVALUE;
    object _23262 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44630)) {
        _1 = (object)(DBL_PTR(_s_44630)->dbl);
        DeRefDS(_s_44630);
        _s_44630 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44631);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_44631 = (object)*(((s1_ptr)_2)->base + _s_44630);
    Ref(_eentry_44631);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44631);
    _scope_44634 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_44634))
    _scope_44634 = (object)DBL_PTR(_scope_44634)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44631);
    _23262 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _23262, 1)){
        _23262 = NOVALUE;
        goto L1; // [31] 125
    }
    _23262 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44631);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23264 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23264 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (IS_ATOM_INT(_23264)) {
        _23265 = (_23264 == 1);
    }
    else {
        _23265 = binary_op(EQUALS, _23264, 1);
    }
    _23264 = NOVALUE;
    if (IS_ATOM_INT(_23265)) {
        if (_23265 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23265)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 6;
    _23267 = MAKE_SEQ(_1);
    _23268 = find_from(_scope_44634, _23267, 1);
    DeRefDS(_23267);
    _23267 = NOVALUE;
    if (_23268 == 0)
    {
        _23268 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23268 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44631);
    DeRef(_23265);
    _23265 = NOVALUE;
    return 1;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23269 = (_scope_44634 == 13);
    if (_23269 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _23271 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_eentry_44631);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23272 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23272 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _2 = (object)SEQ_PTR(_23271);
    if (!IS_ATOM_INT(_23272)){
        _23273 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23272)->dbl));
    }
    else{
        _23273 = (object)*(((s1_ptr)_2)->base + _23272);
    }
    _23271 = NOVALUE;
    if (IS_ATOM_INT(_23273)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23273 & (uintptr_t)4;
             _23274 = MAKE_UINT(tu);
        }
    }
    else {
        _23274 = binary_op(AND_BITS, _23273, 4);
    }
    _23273 = NOVALUE;
    if (_23274 == 0) {
        DeRef(_23274);
        _23274 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23274) && DBL_PTR(_23274)->dbl == 0.0){
            DeRef(_23274);
            _23274 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23274);
        _23274 = NOVALUE;
    }
    DeRef(_23274);
    _23274 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44631);
    _23272 = NOVALUE;
    DeRef(_23269);
    _23269 = NOVALUE;
    DeRef(_23265);
    _23265 = NOVALUE;
    return 1;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44631);
    _23272 = NOVALUE;
    DeRef(_23269);
    _23269 = NOVALUE;
    DeRef(_23265);
    _23265 = NOVALUE;
    return 0;
    ;
}


void _57version()
{
    object _23308 = NOVALUE;
    object _23307 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23307 = _40version_string(0);
    {
        object concat_list[3];

        concat_list[0] = _22404;
        concat_list[1] = _23307;
        concat_list[2] = _23306;
        Concat_N((object_ptr)&_23308, concat_list, 3);
    }
    DeRef(_23307);
    _23307 = NOVALUE;
    _54c_puts(_23308);
    _23308 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _57new_c_file(object _name_44738)
{
    object _23311 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _27cfile_size_20651 = 0;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_57LAST_PASS_42928 != _9FALSE_439)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44738);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _55write_checksum(_54c_code_47024);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_54c_code_47024);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23310;
        concat_list[1] = _name_44738;
        concat_list[2] = _57output_dir_42955;
        Concat_N((object_ptr)&_23311, concat_list, 3);
    }
    _54c_code_47024 = EOpen(_23311, _22345, 0);
    DeRefDS(_23311);
    _23311 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_54c_code_47024 != -1)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_22209);
    _49CompileErr(57, _22209, 0);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _27cfile_count_20650 = _27cfile_count_20650 + 1;

    /** c_decl.e:1229		version()*/
    _57version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22350);
    _54c_puts(_22350);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22351);
    _54c_puts(_22351);

    /** c_decl.e:1235		if not TUNIX then*/

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44738);
    _0 = _name_44738;
    _name_44738 = _12lower(_name_44738);
    DeRefDS(_0);

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44738);
    return;
    ;
}


object _57unique_c_name(object _name_44768)
{
    object _i_44769 = NOVALUE;
    object _compare_name_44770 = NOVALUE;
    object _next_fc_44771 = NOVALUE;
    object _23327 = NOVALUE;
    object _23325 = NOVALUE;
    object _23324 = NOVALUE;
    object _23323 = NOVALUE;
    object _23321 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44770, _name_44768, _23310);

    /** c_decl.e:1254		if not TUNIX then*/

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44770);
    _0 = _compare_name_44770;
    _compare_name_44770 = _12lower(_compare_name_44770);
    DeRefDS(_0);

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44771 = 1;

    /** c_decl.e:1259		i = 1*/
    _i_44769 = 1;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L1: 
    if (IS_SEQUENCE(_57generated_files_42945)){
            _23321 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _23321 = 1;
    }
    if (_i_44769 > _23321)
    goto L2; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_57generated_files_42945);
    _23323 = (object)*(((s1_ptr)_2)->base + _i_44769);
    if (_23323 == _compare_name_44770)
    _23324 = 1;
    else if (IS_ATOM_INT(_23323) && IS_ATOM_INT(_compare_name_44770))
    _23324 = 0;
    else
    _23324 = (compare(_23323, _compare_name_44770) == 0);
    _23323 = NOVALUE;
    if (_23324 == 0)
    {
        _23324 = NOVALUE;
        goto L3; // [61] 129
    }
    else{
        _23324 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_57file_chars_44764)){
            _23325 = SEQ_PTR(_57file_chars_44764)->length;
    }
    else {
        _23325 = 1;
    }
    if (_next_fc_44771 <= _23325)
    goto L4; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_22209);
    _49CompileErr(140, _22209, 0);
L4: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_57file_chars_44764);
    _23327 = (object)*(((s1_ptr)_2)->base + _next_fc_44771);
    Ref(_23327);
    _2 = (object)SEQ_PTR(_name_44768);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44768 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23327;
    if( _1 != _23327 ){
        DeRef(_1);
    }
    _23327 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44770, _name_44768, _23310);

    /** c_decl.e:1271				if not TUNIX then*/

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44770);
    _0 = _compare_name_44770;
    _compare_name_44770 = _12lower(_compare_name_44770);
    DeRefDS(_0);

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44771 = _next_fc_44771 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44769 = 1;
    goto L1; // [126] 40
L3: 

    /** c_decl.e:1279				i += 1*/
    _i_44769 = _i_44769 + 1;

    /** c_decl.e:1281		end while*/
    goto L1; // [138] 40
L2: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44770);
    return _name_44768;
    ;
}


object _57is_file_newer(object _f1_44801, object _f2_44802)
{
    object _d1_44803 = NOVALUE;
    object _d2_44806 = NOVALUE;
    object _diff_2__tmp_at42_44817 = NOVALUE;
    object _diff_1__tmp_at42_44816 = NOVALUE;
    object _diff_inlined_diff_at_42_44815 = NOVALUE;
    object _23337 = NOVALUE;
    object _23335 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44801);
    _0 = _d1_44803;
    _d1_44803 = _15file_timestamp(_f1_44801);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44802);
    _0 = _d2_44806;
    _d2_44806 = _15file_timestamp(_f2_44802);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23335 = IS_ATOM(_d1_44803);
    if (_23335 != 0) {
        goto L1; // [22] 34
    }
    _23337 = IS_ATOM(_d2_44806);
    if (_23337 == 0)
    {
        _23337 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23337 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44801);
    DeRefDS(_f2_44802);
    DeRef(_d1_44803);
    DeRef(_d2_44806);
    return 1;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44806);
    _0 = _diff_1__tmp_at42_44816;
    _diff_1__tmp_at42_44816 = _16datetimeToSeconds(_d2_44806);
    DeRef(_0);
    Ref(_d1_44803);
    _0 = _diff_2__tmp_at42_44817;
    _diff_2__tmp_at42_44817 = _16datetimeToSeconds(_d1_44803);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44815);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44816) && IS_ATOM_INT(_diff_2__tmp_at42_44817)) {
        _diff_inlined_diff_at_42_44815 = _diff_1__tmp_at42_44816 - _diff_2__tmp_at42_44817;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44815 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44815 = NewDouble((eudouble)_diff_inlined_diff_at_42_44815);
        }
    }
    else {
        _diff_inlined_diff_at_42_44815 = binary_op(MINUS, _diff_1__tmp_at42_44816, _diff_2__tmp_at42_44817);
    }
    DeRef(_diff_1__tmp_at42_44816);
    _diff_1__tmp_at42_44816 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44817);
    _diff_2__tmp_at42_44817 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44815, 0)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44801);
    DeRefDS(_f2_44802);
    DeRef(_d1_44803);
    DeRef(_d2_44806);
    return 1;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44801);
    DeRefDS(_f2_44802);
    DeRef(_d1_44803);
    DeRef(_d2_44806);
    return 0;
    ;
}


void _57add_file(object _filename_44821, object _eu_filename_44822)
{
    object _obj_fname_44842 = NOVALUE;
    object _src_fname_44843 = NOVALUE;
    object _23361 = NOVALUE;
    object _23360 = NOVALUE;
    object _23347 = NOVALUE;
    object _23346 = NOVALUE;
    object _23343 = NOVALUE;
    object _23342 = NOVALUE;
    object _23341 = NOVALUE;
    object _23340 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44821);
    _23340 = _15fileext(_filename_44821);
    if (_23339 == _23340)
    _23341 = 1;
    else if (IS_ATOM_INT(_23339) && IS_ATOM_INT(_23340))
    _23341 = 0;
    else
    _23341 = (compare(_23339, _23340) == 0);
    DeRef(_23340);
    _23340 = NOVALUE;
    if (_23341 == 0)
    {
        _23341 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23341 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44821)){
            _23342 = SEQ_PTR(_filename_44821)->length;
    }
    else {
        _23342 = 1;
    }
    _23343 = _23342 - 2;
    _23342 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44821;
    RHS_Slice(_filename_44821, 1, _23343);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44821);
    _23346 = _15fileext(_filename_44821);
    if (_23345 == _23346)
    _23347 = 1;
    else if (IS_ATOM_INT(_23345) && IS_ATOM_INT(_23346))
    _23347 = 0;
    else
    _23347 = (compare(_23345, _23346) == 0);
    DeRef(_23346);
    _23346 = NOVALUE;
    if (_23347 == 0)
    {
        _23347 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23347 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44821);
    Append(&_57generated_files_42945, _57generated_files_42945, _filename_44821);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_42946, _57outdated_files_42946, 0);

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44821);
    DeRefDS(_eu_filename_44822);
    DeRef(_obj_fname_44842);
    DeRef(_src_fname_44843);
    DeRef(_23343);
    _23343 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44821);
    DeRef(_obj_fname_44842);
    _obj_fname_44842 = _filename_44821;
    Concat((object_ptr)&_src_fname_44843, _filename_44821, _23310);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44842, _obj_fname_44842, _23355);

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44843);
    Append(&_57generated_files_42945, _57generated_files_42945, _src_fname_44843);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44842);
    Append(&_57generated_files_42945, _57generated_files_42945, _obj_fname_44842);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23360, _57output_dir_42955, _src_fname_44843);
    RefDS(_eu_filename_44822);
    _23361 = _57is_file_newer(_eu_filename_44822, _23360);
    _23360 = NOVALUE;
    Ref(_23361);
    Append(&_57outdated_files_42946, _57outdated_files_42946, _23361);
    DeRef(_23361);
    _23361 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_42946, _57outdated_files_42946, 0);

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44821);
    DeRefDS(_eu_filename_44822);
    DeRef(_obj_fname_44842);
    DeRef(_src_fname_44843);
    DeRef(_23343);
    _23343 = NOVALUE;
    return;
    ;
}


object _57any_code(object _file_no_44866)
{
    object _these_routines_44868 = NOVALUE;
    object _s_44875 = NOVALUE;
    object _23377 = NOVALUE;
    object _23376 = NOVALUE;
    object _23375 = NOVALUE;
    object _23374 = NOVALUE;
    object _23373 = NOVALUE;
    object _23372 = NOVALUE;
    object _23371 = NOVALUE;
    object _23370 = NOVALUE;
    object _23369 = NOVALUE;
    object _23368 = NOVALUE;
    object _23367 = NOVALUE;
    object _23365 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44868);
    _2 = (object)SEQ_PTR(_57file_routines_45093);
    _these_routines_44868 = (object)*(((s1_ptr)_2)->base + _file_no_44866);
    Ref(_these_routines_44868);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44868)){
            _23365 = SEQ_PTR(_these_routines_44868)->length;
    }
    else {
        _23365 = 1;
    }
    {
        object _i_44872;
        _i_44872 = 1;
L1: 
        if (_i_44872 > _23365){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44868);
        _s_44875 = (object)*(((s1_ptr)_2)->base + _i_44872);
        if (!IS_ATOM_INT(_s_44875)){
            _s_44875 = (object)DBL_PTR(_s_44875)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23367 = (object)*(((s1_ptr)_2)->base + _s_44875);
        _2 = (object)SEQ_PTR(_23367);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _23368 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _23368 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _23367 = NOVALUE;
        if (IS_ATOM_INT(_23368)) {
            _23369 = (_23368 == _file_no_44866);
        }
        else {
            _23369 = binary_op(EQUALS, _23368, _file_no_44866);
        }
        _23368 = NOVALUE;
        if (IS_ATOM_INT(_23369)) {
            if (_23369 == 0) {
                DeRef(_23370);
                _23370 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23369)->dbl == 0.0) {
                DeRef(_23370);
                _23370 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23371 = (object)*(((s1_ptr)_2)->base + _s_44875);
        _2 = (object)SEQ_PTR(_23371);
        _23372 = (object)*(((s1_ptr)_2)->base + 5);
        _23371 = NOVALUE;
        if (IS_ATOM_INT(_23372)) {
            _23373 = (_23372 != 99);
        }
        else {
            _23373 = binary_op(NOTEQ, _23372, 99);
        }
        _23372 = NOVALUE;
        DeRef(_23370);
        if (IS_ATOM_INT(_23373))
        _23370 = (_23373 != 0);
        else
        _23370 = DBL_PTR(_23373)->dbl != 0.0;
L3: 
        if (_23370 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23375 = (object)*(((s1_ptr)_2)->base + _s_44875);
        _2 = (object)SEQ_PTR(_23375);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _23376 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _23376 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _23375 = NOVALUE;
        _23377 = find_from(_23376, _29RTN_TOKS_12277, 1);
        _23376 = NOVALUE;
        if (_23377 == 0)
        {
            _23377 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23377 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44868);
        DeRef(_23369);
        _23369 = NOVALUE;
        DeRef(_23373);
        _23373 = NOVALUE;
        return _9TRUE_441;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44872 = _i_44872 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44868);
    DeRef(_23369);
    _23369 = NOVALUE;
    DeRef(_23373);
    _23373 = NOVALUE;
    return _9FALSE_439;
    ;
}


void _57check_file_routines()
{
    object _s_45102 = NOVALUE;
    object _23539 = NOVALUE;
    object _23538 = NOVALUE;
    object _23537 = NOVALUE;
    object _23536 = NOVALUE;
    object _23535 = NOVALUE;
    object _23534 = NOVALUE;
    object _23533 = NOVALUE;
    object _23532 = NOVALUE;
    object _23531 = NOVALUE;
    object _23530 = NOVALUE;
    object _23529 = NOVALUE;
    object _23528 = NOVALUE;
    object _23526 = NOVALUE;
    object _23524 = NOVALUE;
    object _23522 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_57file_routines_45093)){
            _23522 = SEQ_PTR(_57file_routines_45093)->length;
    }
    else {
        _23522 = 1;
    }
    if (_23522 != 0)
    goto L1; // [8] 146
    _23522 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _23524 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _23524 = 1;
    }
    DeRefDS(_57file_routines_45093);
    _57file_routines_45093 = Repeat(_22209, _23524);
    _23524 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23526 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    _2 = (object)SEQ_PTR(_23526);
    _s_45102 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_45102)){
        _s_45102 = (object)DBL_PTR(_s_45102)->dbl;
    }
    _23526 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_45102 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23528 = (object)*(((s1_ptr)_2)->base + _s_45102);
    _2 = (object)SEQ_PTR(_23528);
    _23529 = (object)*(((s1_ptr)_2)->base + 5);
    _23528 = NOVALUE;
    if (IS_ATOM_INT(_23529)) {
        _23530 = (_23529 != 99);
    }
    else {
        _23530 = binary_op(NOTEQ, _23529, 99);
    }
    _23529 = NOVALUE;
    if (IS_ATOM_INT(_23530)) {
        if (_23530 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23530)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23532 = (object)*(((s1_ptr)_2)->base + _s_45102);
    _2 = (object)SEQ_PTR(_23532);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _23533 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _23533 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _23532 = NOVALUE;
    _23534 = find_from(_23533, _29RTN_TOKS_12277, 1);
    _23533 = NOVALUE;
    if (_23534 == 0)
    {
        _23534 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23534 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23535 = (object)*(((s1_ptr)_2)->base + _s_45102);
    _2 = (object)SEQ_PTR(_23535);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _23536 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _23536 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _23535 = NOVALUE;
    _2 = (object)SEQ_PTR(_57file_routines_45093);
    if (!IS_ATOM_INT(_23536)){
        _23537 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23536)->dbl));
    }
    else{
        _23537 = (object)*(((s1_ptr)_2)->base + _23536);
    }
    if (IS_SEQUENCE(_23537) && IS_ATOM(_s_45102)) {
        Append(&_23538, _23537, _s_45102);
    }
    else if (IS_ATOM(_23537) && IS_SEQUENCE(_s_45102)) {
    }
    else {
        Concat((object_ptr)&_23538, _23537, _s_45102);
        _23537 = NOVALUE;
    }
    _23537 = NOVALUE;
    _2 = (object)SEQ_PTR(_57file_routines_45093);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _57file_routines_45093 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23536))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23536)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23536);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23538;
    if( _1 != _23538 ){
        DeRef(_1);
    }
    _23538 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _23539 = (object)*(((s1_ptr)_2)->base + _s_45102);
    _2 = (object)SEQ_PTR(_23539);
    _s_45102 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_45102)){
        _s_45102 = (object)DBL_PTR(_s_45102)->dbl;
    }
    _23539 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    DeRef(_23530);
    _23530 = NOVALUE;
    _23536 = NOVALUE;
    return;
    ;
}


void _57GenerateUserRoutines()
{
    object _s_45136 = NOVALUE;
    object _sp_45137 = NOVALUE;
    object _next_c_char_45138 = NOVALUE;
    object _q_45139 = NOVALUE;
    object _temps_45140 = NOVALUE;
    object _buff_45141 = NOVALUE;
    object _base_name_45142 = NOVALUE;
    object _long_c_file_45143 = NOVALUE;
    object _c_file_45144 = NOVALUE;
    object _these_routines_45215 = NOVALUE;
    object _ret_type_45273 = NOVALUE;
    object _s_scope_45282 = NOVALUE;
    object _s_file_45285 = NOVALUE;
    object _scope_45362 = NOVALUE;
    object _names_45396 = NOVALUE;
    object _name_45406 = NOVALUE;
    object _23775 = NOVALUE;
    object _23773 = NOVALUE;
    object _23772 = NOVALUE;
    object _23771 = NOVALUE;
    object _23770 = NOVALUE;
    object _23769 = NOVALUE;
    object _23768 = NOVALUE;
    object _23766 = NOVALUE;
    object _23764 = NOVALUE;
    object _23763 = NOVALUE;
    object _23732 = NOVALUE;
    object _23731 = NOVALUE;
    object _23729 = NOVALUE;
    object _23727 = NOVALUE;
    object _23726 = NOVALUE;
    object _23725 = NOVALUE;
    object _23724 = NOVALUE;
    object _23723 = NOVALUE;
    object _23722 = NOVALUE;
    object _23721 = NOVALUE;
    object _23719 = NOVALUE;
    object _23718 = NOVALUE;
    object _23717 = NOVALUE;
    object _23716 = NOVALUE;
    object _23715 = NOVALUE;
    object _23714 = NOVALUE;
    object _23713 = NOVALUE;
    object _23712 = NOVALUE;
    object _23710 = NOVALUE;
    object _23709 = NOVALUE;
    object _23707 = NOVALUE;
    object _23706 = NOVALUE;
    object _23705 = NOVALUE;
    object _23704 = NOVALUE;
    object _23703 = NOVALUE;
    object _23702 = NOVALUE;
    object _23701 = NOVALUE;
    object _23700 = NOVALUE;
    object _23698 = NOVALUE;
    object _23697 = NOVALUE;
    object _23695 = NOVALUE;
    object _23694 = NOVALUE;
    object _23693 = NOVALUE;
    object _23691 = NOVALUE;
    object _23686 = NOVALUE;
    object _23685 = NOVALUE;
    object _23683 = NOVALUE;
    object _23681 = NOVALUE;
    object _23675 = NOVALUE;
    object _23674 = NOVALUE;
    object _23673 = NOVALUE;
    object _23672 = NOVALUE;
    object _23671 = NOVALUE;
    object _23670 = NOVALUE;
    object _23669 = NOVALUE;
    object _23668 = NOVALUE;
    object _23666 = NOVALUE;
    object _23665 = NOVALUE;
    object _23663 = NOVALUE;
    object _23662 = NOVALUE;
    object _23659 = NOVALUE;
    object _23657 = NOVALUE;
    object _23656 = NOVALUE;
    object _23655 = NOVALUE;
    object _23651 = NOVALUE;
    object _23648 = NOVALUE;
    object _23645 = NOVALUE;
    object _23644 = NOVALUE;
    object _23643 = NOVALUE;
    object _23642 = NOVALUE;
    object _23640 = NOVALUE;
    object _23639 = NOVALUE;
    object _23637 = NOVALUE;
    object _23636 = NOVALUE;
    object _23635 = NOVALUE;
    object _23633 = NOVALUE;
    object _23630 = NOVALUE;
    object _23629 = NOVALUE;
    object _23628 = NOVALUE;
    object _23627 = NOVALUE;
    object _23626 = NOVALUE;
    object _23625 = NOVALUE;
    object _23624 = NOVALUE;
    object _23623 = NOVALUE;
    object _23622 = NOVALUE;
    object _23621 = NOVALUE;
    object _23620 = NOVALUE;
    object _23619 = NOVALUE;
    object _23618 = NOVALUE;
    object _23617 = NOVALUE;
    object _23616 = NOVALUE;
    object _23614 = NOVALUE;
    object _23611 = NOVALUE;
    object _23610 = NOVALUE;
    object _23608 = NOVALUE;
    object _23605 = NOVALUE;
    object _23604 = NOVALUE;
    object _23600 = NOVALUE;
    object _23599 = NOVALUE;
    object _23597 = NOVALUE;
    object _23593 = NOVALUE;
    object _23592 = NOVALUE;
    object _23591 = NOVALUE;
    object _23590 = NOVALUE;
    object _23589 = NOVALUE;
    object _23588 = NOVALUE;
    object _23587 = NOVALUE;
    object _23586 = NOVALUE;
    object _23585 = NOVALUE;
    object _23584 = NOVALUE;
    object _23583 = NOVALUE;
    object _23582 = NOVALUE;
    object _23581 = NOVALUE;
    object _23580 = NOVALUE;
    object _23578 = NOVALUE;
    object _23577 = NOVALUE;
    object _23575 = NOVALUE;
    object _23572 = NOVALUE;
    object _23569 = NOVALUE;
    object _23566 = NOVALUE;
    object _23563 = NOVALUE;
    object _23562 = NOVALUE;
    object _23561 = NOVALUE;
    object _23558 = NOVALUE;
    object _23555 = NOVALUE;
    object _23553 = NOVALUE;
    object _23549 = NOVALUE;
    object _23548 = NOVALUE;
    object _23546 = NOVALUE;
    object _23545 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_27silent_20687 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_57Pass_42930 != 1)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_22209);
    _30ShowMsg(1, 239, _22209, 0);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_57LAST_PASS_42928 != _9TRUE_441)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_22209);
    _30ShowMsg(1, 240, _22209, 1);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _30ShowMsg(1, 241, _57Pass_42930, 0);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _57check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23544);
    _54c_puts(_23544);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _23545 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _23545 = 1;
    }
    {
        object _file_no_45163;
        _file_no_45163 = 1;
L5: 
        if (_file_no_45163 > _23545){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23546 = (_file_no_45163 == 1);
        if (_23546 != 0) {
            goto L7; // [97] 110
        }
        _23548 = _57any_code(_file_no_45163);
        if (_23548 == 0) {
            DeRef(_23548);
            _23548 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23548) && DBL_PTR(_23548)->dbl == 0.0){
                DeRef(_23548);
                _23548 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23548);
            _23548 = NOVALUE;
        }
        DeRef(_23548);
        _23548 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_45138 = 1;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _23549 = (object)*(((s1_ptr)_2)->base + _file_no_45163);
        Ref(_23549);
        _0 = _base_name_45142;
        _base_name_45142 = _53name_ext(_23549);
        DeRef(_0);
        _23549 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_45142);
        DeRef(_c_file_45144);
        _c_file_45144 = _base_name_45142;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_45144)){
                _q_45139 = SEQ_PTR(_c_file_45144)->length;
        }
        else {
            _q_45139 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_45139 < 1)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_45144);
        _23553 = (object)*(((s1_ptr)_2)->base + _q_45139);
        if (binary_op_a(NOTEQ, _23553, 46)){
            _23553 = NOVALUE;
            goto LB; // [156] 176
        }
        _23553 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23555 = _q_45139 - 1;
        rhs_slice_target = (object_ptr)&_c_file_45144;
        RHS_Slice(_c_file_45144, 1, _23555);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_45139 = _q_45139 - 1;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_45144);
        _23558 = _12lower(_c_file_45144);
        RefDS(_23560);
        RefDS(_23559);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23559;
        ((intptr_t *)_2)[2] = _23560;
        _23561 = MAKE_SEQ(_1);
        _23562 = find_from(_23558, _23561, 1);
        DeRef(_23558);
        _23558 = NOVALUE;
        DeRefDS(_23561);
        _23561 = NOVALUE;
        if (_23562 == 0)
        {
            _23562 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23562 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_45142);
        ((intptr_t*)_2)[1] = _base_name_45142;
        _23563 = MAKE_SEQ(_1);
        _49CompileErr(12, _23563, 0);
        _23563 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_45144);
        DeRef(_long_c_file_45143);
        _long_c_file_45143 = _c_file_45144;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_42928 != _9TRUE_441)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_45144);
        _0 = _c_file_45144;
        _c_file_45144 = _57unique_c_name(_c_file_45144);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _23566 = (object)*(((s1_ptr)_2)->base + _file_no_45163);
        RefDS(_c_file_45144);
        Ref(_23566);
        _57add_file(_c_file_45144, _23566);
        _23566 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_45163 != 1)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_42928 != _9TRUE_441)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23559);
        RefDS(_22209);
        _57add_file(_23559, _22209);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23569 = _54main_name_num_47026 - 1;
        if ((object)((uintptr_t)_23569 +(uintptr_t) HIGH_BITS) >= 0){
            _23569 = NewDouble((eudouble)_23569);
        }
        {
            object _i_45205;
            _i_45205 = 0;
L10: 
            if (binary_op_a(GREATER, _i_45205, _23569)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_45141);
            _buff_45141 = EPrintf(-9999999, _23570, _i_45205);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_45141);
            RefDS(_22209);
            _57add_file(_buff_45141, _22209);

            /** c_decl.e:1520						end for*/
            _0 = _i_45205;
            if (IS_ATOM_INT(_i_45205)) {
                _i_45205 = _i_45205 + 1;
                if ((object)((uintptr_t)_i_45205 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_45205 = NewDouble((eudouble)_i_45205);
                }
            }
            else {
                _i_45205 = binary_op_a(PLUS, _i_45205, 1);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_45205);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_45143);
        DeRef(_57file0_44899);
        _57file0_44899 = _long_c_file_45143;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_45144);
        _57new_c_file(_c_file_45144);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _23572 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
        _2 = (object)SEQ_PTR(_23572);
        _s_45136 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_45136)){
            _s_45136 = (object)DBL_PTR(_s_45136)->dbl;
        }
        _23572 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_45215);
        _2 = (object)SEQ_PTR(_57file_routines_45093);
        _these_routines_45215 = (object)*(((s1_ptr)_2)->base + _file_no_45163);
        Ref(_these_routines_45215);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_45215)){
                _23575 = SEQ_PTR(_these_routines_45215)->length;
        }
        else {
            _23575 = 1;
        }
        {
            object _routine_no_45218;
            _routine_no_45218 = 1;
L12: 
            if (_routine_no_45218 > _23575){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_45215);
            _s_45136 = (object)*(((s1_ptr)_2)->base + _routine_no_45218);
            if (!IS_ATOM_INT(_s_45136)){
                _s_45136 = (object)DBL_PTR(_s_45136)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23577 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23577);
            _23578 = (object)*(((s1_ptr)_2)->base + 5);
            _23577 = NOVALUE;
            if (binary_op_a(EQUALS, _23578, 99)){
                _23578 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23578 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23580 = (_57LAST_PASS_42928 == _9TRUE_441);
            if (_23580 == 0) {
                goto L15; // [405] 601
            }
            _23582 = (_27cfile_size_20651 > 100000);
            if (_23582 != 0) {
                DeRef(_23583);
                _23583 = 1;
                goto L16; // [417] 480
            }
            _23584 = (_s_45136 != _27TopLevelSub_20578);
            if (_23584 == 0) {
                _23585 = 0;
                goto L17; // [427] 447
            }
            _23586 = (100000 % 4) ? NewDouble((eudouble)100000 / 4) : (100000 / 4);
            if (IS_ATOM_INT(_23586)) {
                _23587 = (_27cfile_size_20651 > _23586);
            }
            else {
                _23587 = ((eudouble)_27cfile_size_20651 > DBL_PTR(_23586)->dbl);
            }
            DeRef(_23586);
            _23586 = NOVALUE;
            _23585 = (_23587 != 0);
L17: 
            if (_23585 == 0) {
                _23588 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23589 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23589);
            if (!IS_ATOM_INT(_27S_CODE_20221)){
                _23590 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
            }
            else{
                _23590 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
            }
            _23589 = NOVALUE;
            if (IS_SEQUENCE(_23590)){
                    _23591 = SEQ_PTR(_23590)->length;
            }
            else {
                _23591 = 1;
            }
            _23590 = NOVALUE;
            _23592 = (_23591 > 100000);
            _23591 = NOVALUE;
            _23588 = (_23592 != 0);
L18: 
            DeRef(_23583);
            _23583 = (_23588 != 0);
L16: 
            if (_23583 == 0)
            {
                _23583 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23583 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_45144)){
                    _23593 = SEQ_PTR(_c_file_45144)->length;
            }
            else {
                _23593 = 1;
            }
            if (_23593 != 7)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_45144, _c_file_45144, _23595);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_45144)){
                    _23597 = SEQ_PTR(_c_file_45144)->length;
            }
            else {
                _23597 = 1;
            }
            if (_23597 < 8)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_45144);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45144 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_57file_chars_44764);
            _23599 = (object)*(((s1_ptr)_2)->base + _next_c_char_45138);
            Ref(_23599);
            _2 = (object)SEQ_PTR(_c_file_45144);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45144 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23599;
            if( _1 != _23599 ){
                DeRef(_1);
            }
            _23599 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23600 = find_from(95, _c_file_45144, 1);
            if (_23600 != 0)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_45144, _c_file_45144, _23602);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_45144)){
                    _23604 = SEQ_PTR(_c_file_45144)->length;
            }
            else {
                _23604 = 1;
            }
            _2 = (object)SEQ_PTR(_57file_chars_44764);
            _23605 = (object)*(((s1_ptr)_2)->base + _next_c_char_45138);
            Ref(_23605);
            _2 = (object)SEQ_PTR(_c_file_45144);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45144 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23604);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23605;
            if( _1 != _23605 ){
                DeRef(_1);
            }
            _23605 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_45144);
            _0 = _c_file_45144;
            _c_file_45144 = _57unique_c_name(_c_file_45144);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_45144);
            _57new_c_file(_c_file_45144);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_45138 = _next_c_char_45138 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_57file_chars_44764)){
                    _23608 = SEQ_PTR(_57file_chars_44764)->length;
            }
            else {
                _23608 = 1;
            }
            if (_next_c_char_45138 <= _23608)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_45138 = 1;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_45144);
            RefDS(_22209);
            _57add_file(_c_file_45144, _22209);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23610 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23610);
            if (!IS_ATOM_INT(_27S_TOKEN_20214)){
                _23611 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
            }
            else{
                _23611 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
            }
            _23610 = NOVALUE;
            if (binary_op_a(NOTEQ, _23611, 27)){
                _23611 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23611 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_22988);
            DeRefi(_ret_type_45273);
            _ret_type_45273 = _22988;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_22989);
            DeRefi(_ret_type_45273);
            _ret_type_45273 = _22989;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_45282 = _53sym_scope(_s_45136);
            if (!IS_ATOM_INT(_s_scope_45282)) {
                _1 = (object)(DBL_PTR(_s_scope_45282)->dbl);
                DeRefDS(_s_scope_45282);
                _s_scope_45282 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23614 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23614);
            if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
                _s_file_45285 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
            }
            else{
                _s_file_45285 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
            }
            if (!IS_ATOM_INT(_s_file_45285)){
                _s_file_45285 = (object)DBL_PTR(_s_file_45285)->dbl;
            }
            _23614 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_57dll_option_42941 == 0) {
                goto L20; // [669] 827
            }
            _23617 = (_s_scope_45282 == 6);
            if (_23617 != 0) {
                DeRef(_23618);
                _23618 = 1;
                goto L21; // [679] 757
            }
            _23619 = (_s_file_45285 == 1);
            if (_23619 == 0) {
                _23620 = 0;
                goto L22; // [687] 715
            }
            _23621 = (_s_scope_45282 == 13);
            if (_23621 != 0) {
                _23622 = 1;
                goto L23; // [697] 711
            }
            _23623 = (_s_scope_45282 == 11);
            _23622 = (_23623 != 0);
L23: 
            _23620 = (_23622 != 0);
L22: 
            if (_23620 != 0) {
                _23624 = 1;
                goto L24; // [715] 753
            }
            _23625 = (_s_scope_45282 == 13);
            if (_23625 == 0) {
                _23626 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_28include_matrix_11579);
            _23627 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_23627);
            _23628 = (object)*(((s1_ptr)_2)->base + _s_file_45285);
            _23627 = NOVALUE;
            if (IS_ATOM_INT(_23628)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23628 & (uintptr_t)4;
                     _23629 = MAKE_UINT(tu);
                }
            }
            else {
                _23629 = binary_op(AND_BITS, _23628, 4);
            }
            _23628 = NOVALUE;
            if (IS_ATOM_INT(_23629))
            _23626 = (_23629 != 0);
            else
            _23626 = DBL_PTR(_23629)->dbl != 0.0;
L25: 
            _23624 = (_23626 != 0);
L24: 
            DeRef(_23618);
            _23618 = (_23624 != 0);
L21: 
            if (_23618 == 0)
            {
                _23618 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23618 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_45136 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9TRUE_441;
            DeRef(_1);
            _23630 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _57LeftSym_42938 = _9TRUE_441;

            /** c_decl.e:1593							if TWINDOWS then*/
            if (_44TWINDOWS_20715 == 0)
            {
                goto L26; // [791] 810
            }
            else{
            }

            /** c_decl.e:1594								c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23633, _ret_type_45273, _23632);
            _57c_stmt(_23633, _s_45136, 0);
            _23633 = NOVALUE;
            goto L27; // [807] 850
L26: 

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23635, _ret_type_45273, _23634);
            _57c_stmt(_23635, _s_45136, 0);
            _23635 = NOVALUE;
            goto L27; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _57LeftSym_42938 = _9TRUE_441;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23636, _ret_type_45273, _23634);
            _57c_stmt(_23636, _s_45136, 0);
            _23636 = NOVALUE;
L27: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23637 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23637);
            _sp_45137 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45137)){
                _sp_45137 = (object)DBL_PTR(_sp_45137)->dbl;
            }
            _23637 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23639 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23639);
            if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                _23640 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
            }
            else{
                _23640 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
            }
            _23639 = NOVALUE;
            {
                object _p_45332;
                _p_45332 = 1;
L28: 
                if (binary_op_a(GREATER, _p_45332, _23640)){
                    goto L29; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23641);
                _54c_puts(_23641);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23642 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23642);
                if (!IS_ATOM_INT(_27S_NAME_20209)){
                    _23643 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
                }
                else{
                    _23643 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
                }
                _23642 = NOVALUE;
                Ref(_23643);
                _54c_puts(_23643);
                _23643 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23644 = (object)*(((s1_ptr)_2)->base + _s_45136);
                _2 = (object)SEQ_PTR(_23644);
                if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                    _23645 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
                }
                else{
                    _23645 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
                }
                _23644 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45332, _23645)){
                    _23645 = NOVALUE;
                    goto L2A; // [923] 933
                }
                _23645 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23647);
                _54c_puts(_23647);
L2A: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23648 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23648);
                _sp_45137 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_45137)){
                    _sp_45137 = (object)DBL_PTR(_sp_45137)->dbl;
                }
                _23648 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_45332;
                if (IS_ATOM_INT(_p_45332)) {
                    _p_45332 = _p_45332 + 1;
                    if ((object)((uintptr_t)_p_45332 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45332 = NewDouble((eudouble)_p_45332);
                    }
                }
                else {
                    _p_45332 = binary_op_a(PLUS, _p_45332, 1);
                }
                DeRef(_0);
                goto L28; // [951] 887
L29: 
                ;
                DeRef(_p_45332);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23650);
            _54c_puts(_23650);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22313);
            _57c_stmt0(_22313);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _57NewBB(0, 1073741823, 0);

            /** c_decl.e:1619						Initializing = TRUE*/
            _27Initializing_20652 = _9TRUE_441;

            /** c_decl.e:1622						while sp do*/
L2B: 
            if (_sp_45137 == 0)
            {
                goto L2C; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23651 = (object)*(((s1_ptr)_2)->base + _sp_45137);
            _2 = (object)SEQ_PTR(_23651);
            _scope_45362 = (object)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_45362)){
                _scope_45362 = (object)DBL_PTR(_scope_45362)->dbl;
            }
            _23651 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_45362;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2D; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_22989);
                _57c_stmt0(_22989);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22281);
                _54c_puts(_22281);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23655 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23655);
                if (!IS_ATOM_INT(_27S_NAME_20209)){
                    _23656 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
                }
                else{
                    _23656 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
                }
                _23655 = NOVALUE;
                Ref(_23656);
                _54c_puts(_23656);
                _23656 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_22997);
                _54c_puts(_22997);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_27NOVALUE_20426);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _27NOVALUE_20426;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_27NOVALUE_20426);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _27NOVALUE_20426;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _57RemoveFromBB(_sp_45137);

                /** c_decl.e:1640									break*/
                goto L2D; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2C; // [1102] 1128
            ;}L2D: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23657 = (object)*(((s1_ptr)_2)->base + _sp_45137);
            _2 = (object)SEQ_PTR(_23657);
            _sp_45137 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45137)){
                _sp_45137 = (object)DBL_PTR(_sp_45137)->dbl;
            }
            _23657 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2B; // [1125] 989
L2C: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23659 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23659);
            if (!IS_ATOM_INT(_27S_TEMPS_20254)){
                _temps_45140 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
            }
            else{
                _temps_45140 = (object)*(((s1_ptr)_2)->base + _27S_TEMPS_20254);
            }
            if (!IS_ATOM_INT(_temps_45140)){
                _temps_45140 = (object)DBL_PTR(_temps_45140)->dbl;
            }
            _23659 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_22209);
            DeRef(_names_45396);
            _names_45396 = _22209;

            /** c_decl.e:1651						while temps != 0 do*/
L2E: 
            if (_temps_45140 == 0)
            goto L2F; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23662 = (object)*(((s1_ptr)_2)->base + _temps_45140);
            _2 = (object)SEQ_PTR(_23662);
            _23663 = (object)*(((s1_ptr)_2)->base + 4);
            _23662 = NOVALUE;
            if (binary_op_a(EQUALS, _23663, 2)){
                _23663 = NOVALUE;
                goto L30; // [1176] 1308
            }
            _23663 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23665 = (object)*(((s1_ptr)_2)->base + _temps_45140);
            _2 = (object)SEQ_PTR(_23665);
            _23666 = (object)*(((s1_ptr)_2)->base + 34);
            _23665 = NOVALUE;
            DeRefi(_name_45406);
            _name_45406 = EPrintf(-9999999, _22332, _23666);
            _23666 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23668 = (object)*(((s1_ptr)_2)->base + _temps_45140);
            _2 = (object)SEQ_PTR(_23668);
            _23669 = (object)*(((s1_ptr)_2)->base + 34);
            _23668 = NOVALUE;
            _2 = (object)SEQ_PTR(_27temp_name_type_20654);
            if (!IS_ATOM_INT(_23669)){
                _23670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23669)->dbl));
            }
            else{
                _23670 = (object)*(((s1_ptr)_2)->base + _23669);
            }
            _2 = (object)SEQ_PTR(_23670);
            _23671 = (object)*(((s1_ptr)_2)->base + 1);
            _23670 = NOVALUE;
            if (IS_ATOM_INT(_23671)) {
                _23672 = (_23671 != 0);
            }
            else {
                _23672 = binary_op(NOTEQ, _23671, 0);
            }
            _23671 = NOVALUE;
            if (IS_ATOM_INT(_23672)) {
                if (_23672 == 0) {
                    goto L31; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23672)->dbl == 0.0) {
                    goto L31; // [1230] 1304
                }
            }
            _23674 = find_from(_name_45406, _names_45396, 1);
            _23675 = (_23674 == 0);
            _23674 = NOVALUE;
            if (_23675 == 0)
            {
                DeRef(_23675);
                _23675 = NOVALUE;
                goto L31; // [1243] 1304
            }
            else{
                DeRef(_23675);
                _23675 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_22989);
            _57c_stmt0(_22989);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45406);
            _54c_puts(_name_45406);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23676);
            _54c_puts(_23676);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_27NOVALUE_20426);
            Ref(_27NOVALUE_20426);
            DeRef(_58target_28771);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _27NOVALUE_20426;
            ((intptr_t *)_2)[2] = _27NOVALUE_20426;
            _58target_28771 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_58target_28771);
            _57SetBBType(_temps_45140, 1, _58target_28771, 16, 0);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22485);
            _54c_puts(_22485);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45406);
            Prepend(&_names_45396, _names_45396, _name_45406);
            goto L32; // [1301] 1307
L31: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L32: 
L30: 
            DeRefi(_name_45406);
            _name_45406 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _28SymTab_11572 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_45140 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16;
            DeRef(_1);
            _23681 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23683 = (object)*(((s1_ptr)_2)->base + _temps_45140);
            _2 = (object)SEQ_PTR(_23683);
            _temps_45140 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_45140)){
                _temps_45140 = (object)DBL_PTR(_temps_45140)->dbl;
            }
            _23683 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2E; // [1345] 1156
L2F: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _27Initializing_20652 = _9FALSE_439;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23685 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23685);
            _23686 = (object)*(((s1_ptr)_2)->base + 37);
            _23685 = NOVALUE;
            if (_23686 == 0) {
                _23686 = NOVALUE;
                goto L33; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23686) && DBL_PTR(_23686)->dbl == 0.0){
                    _23686 = NOVALUE;
                    goto L33; // [1371] 1384
                }
                _23686 = NOVALUE;
            }
            _23686 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23687);
            _57c_stmt0(_23687);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L34; // [1381] 1392
L33: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23689);
            _57c_stmt0(_23689);

            /** c_decl.e:1689							ifdef DEBUG then*/
L34: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23691 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23691);
            _sp_45137 = (object)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_45137)){
                _sp_45137 = (object)DBL_PTR(_sp_45137)->dbl;
            }
            _23691 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23693 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23693);
            if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                _23694 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
            }
            else{
                _23694 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
            }
            _23693 = NOVALUE;
            {
                object _p_45467;
                _p_45467 = 1;
L35: 
                if (binary_op_a(GREATER, _p_45467, _23694)){
                    goto L36; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _28SymTab_11572 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_45137 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _9FALSE_439;
                DeRef(_1);
                _23695 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23697 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23697);
                _23698 = (object)*(((s1_ptr)_2)->base + 43);
                _23697 = NOVALUE;
                if (binary_op_a(NOTEQ, _23698, 8)){
                    _23698 = NOVALUE;
                    goto L37; // [1462] 1526
                }
                _23698 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23700 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23700);
                _23701 = (object)*(((s1_ptr)_2)->base + 51);
                _23700 = NOVALUE;
                Ref(_23701);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23701;
                if( _1 != _23701 ){
                    DeRef(_1);
                }
                _23701 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23702 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23702);
                _23703 = (object)*(((s1_ptr)_2)->base + 43);
                _23702 = NOVALUE;
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23704 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23704);
                _23705 = (object)*(((s1_ptr)_2)->base + 45);
                _23704 = NOVALUE;
                Ref(_23703);
                RefDS(_58target_28771);
                Ref(_23705);
                _57SetBBType(_sp_45137, _23703, _58target_28771, _23705, 0);
                _23703 = NOVALUE;
                _23705 = NOVALUE;
                goto L38; // [1523] 1750
L37: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23706 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23706);
                _23707 = (object)*(((s1_ptr)_2)->base + 43);
                _23706 = NOVALUE;
                if (binary_op_a(NOTEQ, _23707, 1)){
                    _23707 = NOVALUE;
                    goto L39; // [1542] 1666
                }
                _23707 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23709 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23709);
                _23710 = (object)*(((s1_ptr)_2)->base + 47);
                _23709 = NOVALUE;
                if (binary_op_a(NOTEQ, _23710, _27NOVALUE_20426)){
                    _23710 = NOVALUE;
                    goto L3A; // [1562] 1593
                }
                _23710 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = -1073741824;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = 1073741823;
                DeRef(_1);
                goto L3B; // [1590] 1638
L3A: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23712 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23712);
                _23713 = (object)*(((s1_ptr)_2)->base + 47);
                _23712 = NOVALUE;
                Ref(_23713);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23713;
                if( _1 != _23713 ){
                    DeRef(_1);
                }
                _23713 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23714 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23714);
                _23715 = (object)*(((s1_ptr)_2)->base + 48);
                _23714 = NOVALUE;
                Ref(_23715);
                _2 = (object)SEQ_PTR(_58target_28771);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _58target_28771 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23715;
                if( _1 != _23715 ){
                    DeRef(_1);
                }
                _23715 = NOVALUE;
L3B: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23716 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23716);
                _23717 = (object)*(((s1_ptr)_2)->base + 43);
                _23716 = NOVALUE;
                Ref(_23717);
                RefDS(_58target_28771);
                _57SetBBType(_sp_45137, _23717, _58target_28771, 16, 0);
                _23717 = NOVALUE;
                goto L38; // [1663] 1750
L39: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23718 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23718);
                _23719 = (object)*(((s1_ptr)_2)->base + 43);
                _23718 = NOVALUE;
                if (binary_op_a(NOTEQ, _23719, 16)){
                    _23719 = NOVALUE;
                    goto L3C; // [1682] 1724
                }
                _23719 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23721 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23721);
                _23722 = (object)*(((s1_ptr)_2)->base + 43);
                _23721 = NOVALUE;
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23723 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23723);
                _23724 = (object)*(((s1_ptr)_2)->base + 45);
                _23723 = NOVALUE;
                Ref(_23722);
                RefDS(_54novalue_47028);
                Ref(_23724);
                _57SetBBType(_sp_45137, _23722, _54novalue_47028, _23724, 0);
                _23722 = NOVALUE;
                _23724 = NOVALUE;
                goto L38; // [1721] 1750
L3C: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23725 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23725);
                _23726 = (object)*(((s1_ptr)_2)->base + 43);
                _23725 = NOVALUE;
                Ref(_23726);
                RefDS(_54novalue_47028);
                _57SetBBType(_sp_45137, _23726, _54novalue_47028, 16, 0);
                _23726 = NOVALUE;
L38: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_28SymTab_11572);
                _23727 = (object)*(((s1_ptr)_2)->base + _sp_45137);
                _2 = (object)SEQ_PTR(_23727);
                _sp_45137 = (object)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_45137)){
                    _sp_45137 = (object)DBL_PTR(_sp_45137)->dbl;
                }
                _23727 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45467;
                if (IS_ATOM_INT(_p_45467)) {
                    _p_45467 = _p_45467 + 1;
                    if ((object)((uintptr_t)_p_45467 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45467 = NewDouble((eudouble)_p_45467);
                    }
                }
                else {
                    _p_45467 = binary_op_a(PLUS, _p_45467, 1);
                }
                DeRef(_0);
                goto L35; // [1768] 1429
L36: 
                ;
                DeRef(_p_45467);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_45136;
            _23729 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23729);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_27Execute_id_20659].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23729);
            _23729 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23730);
            _54c_puts(_23730);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_57dll_option_42941 == 0) {
                goto L3D; // [1793] 2183
            }
            _23732 = _57is_exported(_s_45136);
            if (_23732 == 0) {
                DeRef(_23732);
                _23732 = NOVALUE;
                goto L3D; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23732) && DBL_PTR(_23732)->dbl == 0.0){
                    DeRef(_23732);
                    _23732 = NOVALUE;
                    goto L3D; // [1802] 2183
                }
                DeRef(_23732);
                _23732 = NOVALUE;
            }
            DeRef(_23732);
            _23732 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _57LeftSym_42938 = _9TRUE_441;

            /** c_decl.e:1733							if TOSX then*/

            /** c_decl.e:1762							elsif TWINDOWS then*/
            if (_44TWINDOWS_20715 == 0)
            {
                goto L3E; // [2082] 2145
            }
            else{
            }

            /** c_decl.e:1766								c_stmt0( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"" )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23763 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23763);
            if (!IS_ATOM_INT(_27S_NAME_20209)){
                _23764 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
            }
            else{
                _23764 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
            }
            _23763 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23765;
                concat_list[1] = _23764;
                concat_list[2] = _ret_type_45273;
                Concat_N((object_ptr)&_23766, concat_list, 3);
            }
            _23764 = NOVALUE;
            _57c_stmt0(_23766);
            _23766 = NOVALUE;

            /** c_decl.e:1767								CName( s )*/
            _57CName(_s_45136);

            /** c_decl.e:1768								c_puts( sprintf( "@%d\")));\n", SymTab[s][S_NUM_ARGS] * TARGET_SIZEOF_POINTER ) )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23768 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23768);
            if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
                _23769 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
            }
            else{
                _23769 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
            }
            _23768 = NOVALUE;
            if (IS_ATOM_INT(_23769)) {
                if (_23769 == (short)_23769){
                    _23770 = _23769 * 4;
                }
                else{
                    _23770 = NewDouble(_23769 * (eudouble)4);
                }
            }
            else {
                _23770 = binary_op(MULTIPLY, _23769, 4);
            }
            _23769 = NOVALUE;
            _23771 = EPrintf(-9999999, _23767, _23770);
            DeRef(_23770);
            _23770 = NOVALUE;
            _54c_puts(_23771);
            _23771 = NOVALUE;
            goto L3F; // [2142] 2173
L3E: 

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_28SymTab_11572);
            _23772 = (object)*(((s1_ptr)_2)->base + _s_45136);
            _2 = (object)SEQ_PTR(_23772);
            if (!IS_ATOM_INT(_27S_NAME_20209)){
                _23773 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
            }
            else{
                _23773 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
            }
            _23772 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23774;
                concat_list[1] = _23773;
                concat_list[2] = _ret_type_45273;
                Concat_N((object_ptr)&_23775, concat_list, 3);
            }
            _23773 = NOVALUE;
            _57c_stmt(_23775, _s_45136, 0);
            _23775 = NOVALUE;
L3F: 

            /** c_decl.e:1772							LeftSym = FALSE*/
            _57LeftSym_42938 = _9FALSE_439;
L3D: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22353);
            _54c_puts(_22353);
L14: 
            DeRefi(_ret_type_45273);
            _ret_type_45273 = NOVALUE;
            DeRef(_names_45396);
            _names_45396 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_45218 = _routine_no_45218 + 1;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_45215);
        _these_routines_45215 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_45163 = _file_no_45163 + 1;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_45141);
    DeRef(_base_name_45142);
    DeRef(_long_c_file_45143);
    DeRef(_c_file_45144);
    DeRef(_23621);
    _23621 = NOVALUE;
    _23669 = NOVALUE;
    DeRef(_23623);
    _23623 = NOVALUE;
    DeRef(_23555);
    _23555 = NOVALUE;
    DeRef(_23629);
    _23629 = NOVALUE;
    DeRef(_23584);
    _23584 = NOVALUE;
    DeRef(_23582);
    _23582 = NOVALUE;
    DeRef(_23580);
    _23580 = NOVALUE;
    _23590 = NOVALUE;
    DeRef(_23617);
    _23617 = NOVALUE;
    DeRef(_23625);
    _23625 = NOVALUE;
    DeRef(_23587);
    _23587 = NOVALUE;
    DeRef(_23672);
    _23672 = NOVALUE;
    DeRef(_23592);
    _23592 = NOVALUE;
    _23694 = NOVALUE;
    _23640 = NOVALUE;
    DeRef(_23619);
    _23619 = NOVALUE;
    DeRef(_23546);
    _23546 = NOVALUE;
    DeRef(_23569);
    _23569 = NOVALUE;
    return;
    ;
}



// 0x06E1A8BF
