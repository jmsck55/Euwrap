// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _15find_first_wildcard(object _name_7847, object _from_7848)
{
    object _asterisk_at_7849 = NOVALUE;
    object _question_at_7851 = NOVALUE;
    object _first_wildcard_at_7853 = NOVALUE;
    object _4155 = NOVALUE;
    object _4154 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:247		integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_7849 = find_from(42, _name_7847, 1);

    /** filesys.e:248		integer question_at = eu:find('?', name, from)*/
    _question_at_7851 = find_from(63, _name_7847, 1);

    /** filesys.e:249		integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_7853 = _asterisk_at_7849;

    /** filesys.e:250		if asterisk_at or question_at then*/
    if (_asterisk_at_7849 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_7851 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** filesys.e:253			if question_at and question_at < asterisk_at then*/
    if (_question_at_7851 == 0) {
        goto L3; // [37] 55
    }
    _4155 = (_question_at_7851 < _asterisk_at_7849);
    if (_4155 == 0)
    {
        DeRef(_4155);
        _4155 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_4155);
        _4155 = NOVALUE;
    }

    /** filesys.e:254				first_wildcard_at = question_at*/
    _first_wildcard_at_7853 = _question_at_7851;
L3: 
L2: 

    /** filesys.e:257		return first_wildcard_at*/
    DeRefDS(_name_7847);
    return _first_wildcard_at_7853;
    ;
}


object _15dir(object _name_7861)
{
    object _4156 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    _4156 = machine(22, _name_7861);
    DeRefDS(_name_7861);
    return _4156;
    ;
}


object _15current_dir()
{
    object _4158 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    _4158 = machine(23, 0);
    return _4158;
    ;
}


object _15chdir(object _newdir_7869)
{
    object _4159 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _4159 = machine(63, _newdir_7869);
    DeRefDS(_newdir_7869);
    return _4159;
    ;
}


object _15delete_file(object _name_8004)
{
    object _pfilename_8005 = NOVALUE;
    object _success_8007 = NOVALUE;
    object _4235 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:802		atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_8004);
    _0 = _pfilename_8005;
    _pfilename_8005 = _6allocate_string(_name_8004, 0);
    DeRef(_0);

    /** filesys.e:803		integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pfilename_8005);
    ((intptr_t*)_2)[1] = _pfilename_8005;
    _4235 = MAKE_SEQ(_1);
    _success_8007 = call_c(1, _15xDeleteFile_7793, _4235);
    DeRefDS(_4235);
    _4235 = NOVALUE;
    if (!IS_ATOM_INT(_success_8007)) {
        _1 = (object)(DBL_PTR(_success_8007)->dbl);
        DeRefDS(_success_8007);
        _success_8007 = _1;
    }

    /** filesys.e:805		ifdef UNIX then*/

    /** filesys.e:809		machine:free(pfilename)*/
    Ref(_pfilename_8005);
    _6free(_pfilename_8005);

    /** filesys.e:811		return success*/
    DeRefDS(_name_8004);
    DeRef(_pfilename_8005);
    return _success_8007;
    ;
}


object _15curdir(object _drive_id_8012)
{
    object _lCurDir_8013 = NOVALUE;
    object _lOrigDir_8014 = NOVALUE;
    object _lDrive_8015 = NOVALUE;
    object _current_dir_inlined_current_dir_at_25_8020 = NOVALUE;
    object _chdir_inlined_chdir_at_55_8023 = NOVALUE;
    object _current_dir_inlined_current_dir_at_77_8026 = NOVALUE;
    object _chdir_inlined_chdir_at_109_8033 = NOVALUE;
    object _newdir_inlined_chdir_at_106_8032 = NOVALUE;
    object _4243 = NOVALUE;
    object _4242 = NOVALUE;
    object _4241 = NOVALUE;
    object _4239 = NOVALUE;
    object _4237 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_drive_id_8012)) {
        _1 = (object)(DBL_PTR(_drive_id_8012)->dbl);
        DeRefDS(_drive_id_8012);
        _drive_id_8012 = _1;
    }

    /** filesys.e:847		ifdef not LINUX then*/

    /** filesys.e:848		    sequence lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_8014);
    _lOrigDir_8014 = _5;

    /** filesys.e:849		    sequence lDrive*/

    /** filesys.e:851		    if t_alpha(drive_id) then*/
    _4237 = _9t_alpha(_drive_id_8012);
    if (_4237 == 0) {
        DeRef(_4237);
        _4237 = NOVALUE;
        goto L1; // [20] 75
    }
    else {
        if (!IS_ATOM_INT(_4237) && DBL_PTR(_4237)->dbl == 0.0){
            DeRef(_4237);
            _4237 = NOVALUE;
            goto L1; // [20] 75
        }
        DeRef(_4237);
        _4237 = NOVALUE;
    }
    DeRef(_4237);
    _4237 = NOVALUE;

    /** filesys.e:852			    lOrigDir =  current_dir()*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefDSi(_lOrigDir_8014);
    _lOrigDir_8014 = machine(23, 0);

    /** filesys.e:853			    lDrive = "  "*/
    RefDS(_150);
    DeRefi(_lDrive_8015);
    _lDrive_8015 = _150;

    /** filesys.e:854			    lDrive[1] = drive_id*/
    _2 = (object)SEQ_PTR(_lDrive_8015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _lDrive_8015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    *(intptr_t *)_2 = _drive_id_8012;

    /** filesys.e:855			    lDrive[2] = ':'*/
    _2 = (object)SEQ_PTR(_lDrive_8015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _lDrive_8015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    *(intptr_t *)_2 = 58;

    /** filesys.e:856			    if chdir(lDrive) = 0 then*/

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_55_8023 = machine(63, _lDrive_8015);
    if (_chdir_inlined_chdir_at_55_8023 != 0)
    goto L2; // [62] 74

    /** filesys.e:857			    	lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_8014);
    _lOrigDir_8014 = _5;
L2: 
L1: 

    /** filesys.e:862	    lCurDir = current_dir()*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_8013);
    _lCurDir_8013 = machine(23, 0);

    /** filesys.e:863		ifdef not LINUX then*/

    /** filesys.e:864			if length(lOrigDir) > 0 then*/
    if (IS_SEQUENCE(_lOrigDir_8014)){
            _4239 = SEQ_PTR(_lOrigDir_8014)->length;
    }
    else {
        _4239 = 1;
    }
    if (_4239 <= 0)
    goto L3; // [95] 121

    /** filesys.e:865		    	chdir(lOrigDir[1..2])*/
    rhs_slice_target = (object_ptr)&_4241;
    RHS_Slice(_lOrigDir_8014, 1, 2);
    DeRefi(_newdir_inlined_chdir_at_106_8032);
    _newdir_inlined_chdir_at_106_8032 = _4241;
    _4241 = NOVALUE;

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_109_8033 = machine(63, _newdir_inlined_chdir_at_106_8032);
    DeRefi(_newdir_inlined_chdir_at_106_8032);
    _newdir_inlined_chdir_at_106_8032 = NOVALUE;
L3: 

    /** filesys.e:870		if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_8013)){
            _4242 = SEQ_PTR(_lCurDir_8013)->length;
    }
    else {
        _4242 = 1;
    }
    _2 = (object)SEQ_PTR(_lCurDir_8013);
    _4243 = (object)*(((s1_ptr)_2)->base + _4242);
    if (_4243 == 92)
    goto L4; // [130] 141

    /** filesys.e:871			lCurDir &= SLASH*/
    Append(&_lCurDir_8013, _lCurDir_8013, 92);
L4: 

    /** filesys.e:874		return lCurDir*/
    DeRefi(_lOrigDir_8014);
    DeRefi(_lDrive_8015);
    _4243 = NOVALUE;
    return _lCurDir_8013;
    ;
}


object _15pathinfo(object _path_8192, object _std_slash_8193)
{
    object _slash_8194 = NOVALUE;
    object _period_8195 = NOVALUE;
    object _ch_8196 = NOVALUE;
    object _dir_name_8197 = NOVALUE;
    object _file_name_8198 = NOVALUE;
    object _file_ext_8199 = NOVALUE;
    object _file_full_8200 = NOVALUE;
    object _drive_id_8201 = NOVALUE;
    object _from_slash_8241 = NOVALUE;
    object _4368 = NOVALUE;
    object _4361 = NOVALUE;
    object _4360 = NOVALUE;
    object _4357 = NOVALUE;
    object _4356 = NOVALUE;
    object _4354 = NOVALUE;
    object _4353 = NOVALUE;
    object _4350 = NOVALUE;
    object _4349 = NOVALUE;
    object _4347 = NOVALUE;
    object _4343 = NOVALUE;
    object _4341 = NOVALUE;
    object _4340 = NOVALUE;
    object _4339 = NOVALUE;
    object _4338 = NOVALUE;
    object _4336 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1196		dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_8197);
    _dir_name_8197 = _5;

    /** filesys.e:1197		file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_8198);
    _file_name_8198 = _5;

    /** filesys.e:1198		file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_8199);
    _file_ext_8199 = _5;

    /** filesys.e:1199		file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_8200);
    _file_full_8200 = _5;

    /** filesys.e:1200		drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_8201);
    _drive_id_8201 = _5;

    /** filesys.e:1202		slash = 0*/
    _slash_8194 = 0;

    /** filesys.e:1203		period = 0*/
    _period_8195 = 0;

    /** filesys.e:1205		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_8192)){
            _4336 = SEQ_PTR(_path_8192)->length;
    }
    else {
        _4336 = 1;
    }
    {
        object _i_8203;
        _i_8203 = _4336;
L1: 
        if (_i_8203 < 1){
            goto L2; // [55] 122
        }

        /** filesys.e:1206			ch = path[i]*/
        _2 = (object)SEQ_PTR(_path_8192);
        _ch_8196 = (object)*(((s1_ptr)_2)->base + _i_8203);
        if (!IS_ATOM_INT(_ch_8196))
        _ch_8196 = (object)DBL_PTR(_ch_8196)->dbl;

        /** filesys.e:1207			if period = 0 and ch = '.' then*/
        _4338 = (_period_8195 == 0);
        if (_4338 == 0) {
            goto L3; // [74] 94
        }
        _4340 = (_ch_8196 == 46);
        if (_4340 == 0)
        {
            DeRef(_4340);
            _4340 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_4340);
            _4340 = NOVALUE;
        }

        /** filesys.e:1208				period = i*/
        _period_8195 = _i_8203;
        goto L4; // [91] 115
L3: 

        /** filesys.e:1209			elsif eu:find(ch, SLASHES) then*/
        _4341 = find_from(_ch_8196, _15SLASHES_7821, 1);
        if (_4341 == 0)
        {
            _4341 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _4341 = NOVALUE;
        }

        /** filesys.e:1210				slash = i*/
        _slash_8194 = _i_8203;

        /** filesys.e:1211				exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** filesys.e:1213		end for*/
        _i_8203 = _i_8203 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** filesys.e:1215		if slash > 0 then*/
    if (_slash_8194 <= 0)
    goto L6; // [124] 181

    /** filesys.e:1216			dir_name = path[1..slash-1]*/
    _4343 = _slash_8194 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_8197;
    RHS_Slice(_path_8192, 1, _4343);

    /** filesys.e:1218			ifdef not UNIX then*/

    /** filesys.e:1219				ch = eu:find(':', dir_name)*/
    _ch_8196 = find_from(58, _dir_name_8197, 1);

    /** filesys.e:1220				if ch != 0 then*/
    if (_ch_8196 == 0)
    goto L7; // [150] 180

    /** filesys.e:1221					drive_id = dir_name[1..ch-1]*/
    _4347 = _ch_8196 - 1;
    rhs_slice_target = (object_ptr)&_drive_id_8201;
    RHS_Slice(_dir_name_8197, 1, _4347);

    /** filesys.e:1222					dir_name = dir_name[ch+1..$]*/
    _4349 = _ch_8196 + 1;
    if (IS_SEQUENCE(_dir_name_8197)){
            _4350 = SEQ_PTR(_dir_name_8197)->length;
    }
    else {
        _4350 = 1;
    }
    rhs_slice_target = (object_ptr)&_dir_name_8197;
    RHS_Slice(_dir_name_8197, _4349, _4350);
L7: 
L6: 

    /** filesys.e:1226		if period > 0 then*/
    if (_period_8195 <= 0)
    goto L8; // [183] 227

    /** filesys.e:1227			file_name = path[slash+1..period-1]*/
    _4353 = _slash_8194 + 1;
    if (_4353 > MAXINT){
        _4353 = NewDouble((eudouble)_4353);
    }
    _4354 = _period_8195 - 1;
    rhs_slice_target = (object_ptr)&_file_name_8198;
    RHS_Slice(_path_8192, _4353, _4354);

    /** filesys.e:1228			file_ext = path[period+1..$]*/
    _4356 = _period_8195 + 1;
    if (_4356 > MAXINT){
        _4356 = NewDouble((eudouble)_4356);
    }
    if (IS_SEQUENCE(_path_8192)){
            _4357 = SEQ_PTR(_path_8192)->length;
    }
    else {
        _4357 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_8199;
    RHS_Slice(_path_8192, _4356, _4357);

    /** filesys.e:1229			file_full = file_name & '.' & file_ext*/
    {
        object concat_list[3];

        concat_list[0] = _file_ext_8199;
        concat_list[1] = 46;
        concat_list[2] = _file_name_8198;
        Concat_N((object_ptr)&_file_full_8200, concat_list, 3);
    }
    goto L9; // [224] 249
L8: 

    /** filesys.e:1231			file_name = path[slash+1..$]*/
    _4360 = _slash_8194 + 1;
    if (_4360 > MAXINT){
        _4360 = NewDouble((eudouble)_4360);
    }
    if (IS_SEQUENCE(_path_8192)){
            _4361 = SEQ_PTR(_path_8192)->length;
    }
    else {
        _4361 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_8198;
    RHS_Slice(_path_8192, _4360, _4361);

    /** filesys.e:1232			file_full = file_name*/
    RefDS(_file_name_8198);
    DeRef(_file_full_8200);
    _file_full_8200 = _file_name_8198;
L9: 

    /** filesys.e:1235		if std_slash != 0 then*/
    if (_std_slash_8193 == 0)
    goto LA; // [251] 317

    /** filesys.e:1236			if std_slash < 0 then*/
    if (_std_slash_8193 >= 0)
    goto LB; // [257] 293

    /** filesys.e:1237				std_slash = SLASH*/
    _std_slash_8193 = 92;

    /** filesys.e:1238				ifdef UNIX then*/

    /** filesys.e:1241				sequence from_slash = "/"*/
    RefDS(_4142);
    DeRefi(_from_slash_8241);
    _from_slash_8241 = _4142;

    /** filesys.e:1243				dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_8241);
    RefDS(_dir_name_8197);
    _0 = _dir_name_8197;
    _dir_name_8197 = _14match_replace(_from_slash_8241, _dir_name_8197, 92, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_8241);
    _from_slash_8241 = NOVALUE;
    goto LC; // [290] 316
LB: 

    /** filesys.e:1245				dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_1202);
    RefDS(_dir_name_8197);
    _0 = _dir_name_8197;
    _dir_name_8197 = _14match_replace(_1202, _dir_name_8197, _std_slash_8193, 0);
    DeRefDS(_0);

    /** filesys.e:1246				dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_4142);
    RefDS(_dir_name_8197);
    _0 = _dir_name_8197;
    _dir_name_8197 = _14match_replace(_4142, _dir_name_8197, _std_slash_8193, 0);
    DeRefDS(_0);
LC: 
LA: 

    /** filesys.e:1250		return {dir_name, file_full, file_name, file_ext, drive_id }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_dir_name_8197);
    ((intptr_t*)_2)[1] = _dir_name_8197;
    RefDS(_file_full_8200);
    ((intptr_t*)_2)[2] = _file_full_8200;
    RefDS(_file_name_8198);
    ((intptr_t*)_2)[3] = _file_name_8198;
    RefDS(_file_ext_8199);
    ((intptr_t*)_2)[4] = _file_ext_8199;
    RefDS(_drive_id_8201);
    ((intptr_t*)_2)[5] = _drive_id_8201;
    _4368 = MAKE_SEQ(_1);
    DeRefDS(_path_8192);
    DeRefDS(_dir_name_8197);
    DeRefDS(_file_name_8198);
    DeRefDS(_file_ext_8199);
    DeRefDS(_file_full_8200);
    DeRefDS(_drive_id_8201);
    DeRef(_4338);
    _4338 = NOVALUE;
    DeRef(_4360);
    _4360 = NOVALUE;
    DeRef(_4354);
    _4354 = NOVALUE;
    DeRef(_4353);
    _4353 = NOVALUE;
    DeRef(_4349);
    _4349 = NOVALUE;
    DeRef(_4356);
    _4356 = NOVALUE;
    DeRef(_4343);
    _4343 = NOVALUE;
    DeRef(_4347);
    _4347 = NOVALUE;
    return _4368;
    ;
}


object _15dirname(object _path_8249, object _pcd_8250)
{
    object _data_8251 = NOVALUE;
    object _4373 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1279		data = pathinfo(path)*/
    RefDS(_path_8249);
    _0 = _data_8251;
    _data_8251 = _15pathinfo(_path_8249, 0);
    DeRef(_0);

    /** filesys.e:1280		if pcd then*/

    /** filesys.e:1285		return data[1]*/
    _2 = (object)SEQ_PTR(_data_8251);
    _4373 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_4373);
    DeRefDS(_path_8249);
    DeRefDS(_data_8251);
    return _4373;
    ;
}


object _15filebase(object _path_8278)
{
    object _data_8279 = NOVALUE;
    object _4382 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1375		data = pathinfo(path)*/
    RefDS(_path_8278);
    _0 = _data_8279;
    _data_8279 = _15pathinfo(_path_8278, 0);
    DeRef(_0);

    /** filesys.e:1377		return data[3]*/
    _2 = (object)SEQ_PTR(_data_8279);
    _4382 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_4382);
    DeRefDS(_path_8278);
    DeRefDS(_data_8279);
    return _4382;
    ;
}


object _15fileext(object _path_8284)
{
    object _data_8285 = NOVALUE;
    object _4384 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1403		data = pathinfo(path)*/
    RefDS(_path_8284);
    _0 = _data_8285;
    _data_8285 = _15pathinfo(_path_8284, 0);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    _2 = (object)SEQ_PTR(_data_8285);
    _4384 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_4384);
    DeRefDS(_path_8284);
    DeRefDS(_data_8285);
    return _4384;
    ;
}


object _15defaultext(object _path_8296, object _defext_8297)
{
    object _4399 = NOVALUE;
    object _4396 = NOVALUE;
    object _4394 = NOVALUE;
    object _4393 = NOVALUE;
    object _4392 = NOVALUE;
    object _4390 = NOVALUE;
    object _4389 = NOVALUE;
    object _4387 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1455		if length(defext) = 0 then*/
    _4387 = 3;

    /** filesys.e:1459		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_8296)){
            _4389 = SEQ_PTR(_path_8296)->length;
    }
    else {
        _4389 = 1;
    }
    {
        object _i_8302;
        _i_8302 = _4389;
L1: 
        if (_i_8302 < 1){
            goto L2; // [26] 95
        }

        /** filesys.e:1460			if path[i] = '.' then*/
        _2 = (object)SEQ_PTR(_path_8296);
        _4390 = (object)*(((s1_ptr)_2)->base + _i_8302);
        if (binary_op_a(NOTEQ, _4390, 46)){
            _4390 = NOVALUE;
            goto L3; // [39] 50
        }
        _4390 = NOVALUE;

        /** filesys.e:1462				return path*/
        DeRefDSi(_defext_8297);
        return _path_8296;
L3: 

        /** filesys.e:1464			if find(path[i], SLASHES) then*/
        _2 = (object)SEQ_PTR(_path_8296);
        _4392 = (object)*(((s1_ptr)_2)->base + _i_8302);
        _4393 = find_from(_4392, _15SLASHES_7821, 1);
        _4392 = NOVALUE;
        if (_4393 == 0)
        {
            _4393 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _4393 = NOVALUE;
        }

        /** filesys.e:1465				if i = length(path) then*/
        if (IS_SEQUENCE(_path_8296)){
                _4394 = SEQ_PTR(_path_8296)->length;
        }
        else {
            _4394 = 1;
        }
        if (_i_8302 != _4394)
        goto L2; // [69] 95

        /** filesys.e:1467					return path*/
        DeRefDSi(_defext_8297);
        return _path_8296;
        goto L5; // [79] 87

        /** filesys.e:1470					exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** filesys.e:1473		end for*/
        _i_8302 = _i_8302 + -1;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** filesys.e:1475		if defext[1] != '.' then*/
    _2 = (object)SEQ_PTR(_defext_8297);
    _4396 = (object)*(((s1_ptr)_2)->base + 1);
    if (_4396 == 46)
    goto L6; // [101] 112

    /** filesys.e:1476			path &= '.'*/
    Append(&_path_8296, _path_8296, 46);
L6: 

    /** filesys.e:1479		return path & defext*/
    Concat((object_ptr)&_4399, _path_8296, _defext_8297);
    DeRefDS(_path_8296);
    DeRefDSi(_defext_8297);
    _4396 = NOVALUE;
    return _4399;
    ;
}


object _15absolute_path(object _filename_8321)
{
    object _4411 = NOVALUE;
    object _4410 = NOVALUE;
    object _4408 = NOVALUE;
    object _4406 = NOVALUE;
    object _4404 = NOVALUE;
    object _4403 = NOVALUE;
    object _4402 = NOVALUE;
    object _4400 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1514		if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_8321)){
            _4400 = SEQ_PTR(_filename_8321)->length;
    }
    else {
        _4400 = 1;
    }
    if (_4400 != 0)
    goto L1; // [8] 19

    /** filesys.e:1515			return 0*/
    DeRefDS(_filename_8321);
    return 0;
L1: 

    /** filesys.e:1518		if eu:find(filename[1], SLASHES) then*/
    _2 = (object)SEQ_PTR(_filename_8321);
    _4402 = (object)*(((s1_ptr)_2)->base + 1);
    _4403 = find_from(_4402, _15SLASHES_7821, 1);
    _4402 = NOVALUE;
    if (_4403 == 0)
    {
        _4403 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _4403 = NOVALUE;
    }

    /** filesys.e:1519			return 1*/
    DeRefDS(_filename_8321);
    return 1;
L2: 

    /** filesys.e:1522		ifdef WINDOWS then*/

    /** filesys.e:1523			if length(filename) = 1 then*/
    if (IS_SEQUENCE(_filename_8321)){
            _4404 = SEQ_PTR(_filename_8321)->length;
    }
    else {
        _4404 = 1;
    }
    if (_4404 != 1)
    goto L3; // [47] 58

    /** filesys.e:1524				return 0*/
    DeRefDS(_filename_8321);
    return 0;
L3: 

    /** filesys.e:1527			if filename[2] != ':' then*/
    _2 = (object)SEQ_PTR(_filename_8321);
    _4406 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _4406, 58)){
        _4406 = NOVALUE;
        goto L4; // [64] 75
    }
    _4406 = NOVALUE;

    /** filesys.e:1528				return 0*/
    DeRefDS(_filename_8321);
    return 0;
L4: 

    /** filesys.e:1531			if length(filename) < 3 then*/
    if (IS_SEQUENCE(_filename_8321)){
            _4408 = SEQ_PTR(_filename_8321)->length;
    }
    else {
        _4408 = 1;
    }
    if (_4408 >= 3)
    goto L5; // [80] 91

    /** filesys.e:1532				return 0*/
    DeRefDS(_filename_8321);
    return 0;
L5: 

    /** filesys.e:1535			if eu:find(filename[3], SLASHES) then*/
    _2 = (object)SEQ_PTR(_filename_8321);
    _4410 = (object)*(((s1_ptr)_2)->base + 3);
    _4411 = find_from(_4410, _15SLASHES_7821, 1);
    _4410 = NOVALUE;
    if (_4411 == 0)
    {
        _4411 = NOVALUE;
        goto L6; // [102] 112
    }
    else{
        _4411 = NOVALUE;
    }

    /** filesys.e:1536				return 1*/
    DeRefDS(_filename_8321);
    return 1;
L6: 

    /** filesys.e:1539		return 0*/
    DeRefDS(_filename_8321);
    return 0;
    ;
}


object _15canonical_path(object _path_in_8360, object _directory_given_8361, object _case_flags_8362)
{
    object _lPath_8363 = NOVALUE;
    object _lPosA_8364 = NOVALUE;
    object _lPosB_8365 = NOVALUE;
    object _lLevel_8366 = NOVALUE;
    object _lHome_8367 = NOVALUE;
    object _lDrive_8368 = NOVALUE;
    object _current_dir_inlined_current_dir_at_300_8428 = NOVALUE;
    object _driveid_inlined_driveid_at_307_8431 = NOVALUE;
    object _data_inlined_driveid_at_307_8430 = NOVALUE;
    object _wildcard_suffix_8433 = NOVALUE;
    object _first_wildcard_at_8434 = NOVALUE;
    object _last_slash_8437 = NOVALUE;
    object _sl_8509 = NOVALUE;
    object _short_name_8512 = NOVALUE;
    object _correct_name_8515 = NOVALUE;
    object _lower_name_8518 = NOVALUE;
    object _part_8534 = NOVALUE;
    object _list_8539 = NOVALUE;
    object _dir_inlined_dir_at_877_8543 = NOVALUE;
    object _name_inlined_dir_at_874_8542 = NOVALUE;
    object _supplied_name_8544 = NOVALUE;
    object _read_name_8563 = NOVALUE;
    object _read_name_8588 = NOVALUE;
    object _4633 = NOVALUE;
    object _4630 = NOVALUE;
    object _4626 = NOVALUE;
    object _4625 = NOVALUE;
    object _4623 = NOVALUE;
    object _4622 = NOVALUE;
    object _4621 = NOVALUE;
    object _4620 = NOVALUE;
    object _4619 = NOVALUE;
    object _4617 = NOVALUE;
    object _4616 = NOVALUE;
    object _4615 = NOVALUE;
    object _4614 = NOVALUE;
    object _4613 = NOVALUE;
    object _4612 = NOVALUE;
    object _4611 = NOVALUE;
    object _4610 = NOVALUE;
    object _4608 = NOVALUE;
    object _4607 = NOVALUE;
    object _4606 = NOVALUE;
    object _4605 = NOVALUE;
    object _4604 = NOVALUE;
    object _4603 = NOVALUE;
    object _4602 = NOVALUE;
    object _4601 = NOVALUE;
    object _4600 = NOVALUE;
    object _4598 = NOVALUE;
    object _4597 = NOVALUE;
    object _4596 = NOVALUE;
    object _4595 = NOVALUE;
    object _4594 = NOVALUE;
    object _4593 = NOVALUE;
    object _4592 = NOVALUE;
    object _4591 = NOVALUE;
    object _4590 = NOVALUE;
    object _4589 = NOVALUE;
    object _4588 = NOVALUE;
    object _4587 = NOVALUE;
    object _4586 = NOVALUE;
    object _4585 = NOVALUE;
    object _4584 = NOVALUE;
    object _4582 = NOVALUE;
    object _4581 = NOVALUE;
    object _4580 = NOVALUE;
    object _4579 = NOVALUE;
    object _4578 = NOVALUE;
    object _4576 = NOVALUE;
    object _4575 = NOVALUE;
    object _4574 = NOVALUE;
    object _4573 = NOVALUE;
    object _4572 = NOVALUE;
    object _4571 = NOVALUE;
    object _4570 = NOVALUE;
    object _4569 = NOVALUE;
    object _4568 = NOVALUE;
    object _4567 = NOVALUE;
    object _4566 = NOVALUE;
    object _4565 = NOVALUE;
    object _4564 = NOVALUE;
    object _4562 = NOVALUE;
    object _4561 = NOVALUE;
    object _4559 = NOVALUE;
    object _4558 = NOVALUE;
    object _4557 = NOVALUE;
    object _4556 = NOVALUE;
    object _4555 = NOVALUE;
    object _4553 = NOVALUE;
    object _4552 = NOVALUE;
    object _4551 = NOVALUE;
    object _4550 = NOVALUE;
    object _4549 = NOVALUE;
    object _4548 = NOVALUE;
    object _4546 = NOVALUE;
    object _4545 = NOVALUE;
    object _4544 = NOVALUE;
    object _4542 = NOVALUE;
    object _4541 = NOVALUE;
    object _4539 = NOVALUE;
    object _4538 = NOVALUE;
    object _4537 = NOVALUE;
    object _4535 = NOVALUE;
    object _4534 = NOVALUE;
    object _4532 = NOVALUE;
    object _4530 = NOVALUE;
    object _4528 = NOVALUE;
    object _4521 = NOVALUE;
    object _4518 = NOVALUE;
    object _4517 = NOVALUE;
    object _4516 = NOVALUE;
    object _4515 = NOVALUE;
    object _4509 = NOVALUE;
    object _4505 = NOVALUE;
    object _4504 = NOVALUE;
    object _4503 = NOVALUE;
    object _4502 = NOVALUE;
    object _4501 = NOVALUE;
    object _4499 = NOVALUE;
    object _4496 = NOVALUE;
    object _4495 = NOVALUE;
    object _4494 = NOVALUE;
    object _4493 = NOVALUE;
    object _4492 = NOVALUE;
    object _4491 = NOVALUE;
    object _4489 = NOVALUE;
    object _4488 = NOVALUE;
    object _4486 = NOVALUE;
    object _4484 = NOVALUE;
    object _4483 = NOVALUE;
    object _4482 = NOVALUE;
    object _4480 = NOVALUE;
    object _4479 = NOVALUE;
    object _4478 = NOVALUE;
    object _4477 = NOVALUE;
    object _4475 = NOVALUE;
    object _4473 = NOVALUE;
    object _4468 = NOVALUE;
    object _4466 = NOVALUE;
    object _4465 = NOVALUE;
    object _4464 = NOVALUE;
    object _4463 = NOVALUE;
    object _4462 = NOVALUE;
    object _4460 = NOVALUE;
    object _4459 = NOVALUE;
    object _4457 = NOVALUE;
    object _4456 = NOVALUE;
    object _4455 = NOVALUE;
    object _4454 = NOVALUE;
    object _4453 = NOVALUE;
    object _4452 = NOVALUE;
    object _4451 = NOVALUE;
    object _4448 = NOVALUE;
    object _4447 = NOVALUE;
    object _4445 = NOVALUE;
    object _4443 = NOVALUE;
    object _4441 = NOVALUE;
    object _4438 = NOVALUE;
    object _4437 = NOVALUE;
    object _4436 = NOVALUE;
    object _4435 = NOVALUE;
    object _4434 = NOVALUE;
    object _4432 = NOVALUE;
    object _4431 = NOVALUE;
    object _4430 = NOVALUE;
    object _4429 = NOVALUE;
    object _4428 = NOVALUE;
    object _4427 = NOVALUE;
    object _4426 = NOVALUE;
    object _4425 = NOVALUE;
    object _4424 = NOVALUE;
    object _4423 = NOVALUE;
    object _4422 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1607	    sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_8363);
    _lPath_8363 = _5;

    /** filesys.e:1608	    integer lPosA = -1*/
    _lPosA_8364 = -1;

    /** filesys.e:1609	    integer lPosB = -1*/
    _lPosB_8365 = -1;

    /** filesys.e:1610	    sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_8366);
    _lLevel_8366 = _5;

    /** filesys.e:1612	    path_in = path_in*/
    RefDS(_path_in_8360);
    DeRefDS(_path_in_8360);
    _path_in_8360 = _path_in_8360;

    /** filesys.e:1614		ifdef UNIX then*/

    /** filesys.e:1617		    sequence lDrive*/

    /** filesys.e:1619		    lPath = match_replace("/", path_in, SLASH)*/
    RefDS(_4142);
    RefDS(_path_in_8360);
    _0 = _lPath_8363;
    _lPath_8363 = _14match_replace(_4142, _path_in_8360, 92, 0);
    DeRefDS(_0);

    /** filesys.e:1623	    if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4422 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4422 = 1;
    }
    _4423 = (_4422 > 2);
    _4422 = NOVALUE;
    if (_4423 == 0) {
        _4424 = 0;
        goto L1; // [62] 78
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4425 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4425)) {
        _4426 = (_4425 == 34);
    }
    else {
        _4426 = binary_op(EQUALS, _4425, 34);
    }
    _4425 = NOVALUE;
    if (IS_ATOM_INT(_4426))
    _4424 = (_4426 != 0);
    else
    _4424 = DBL_PTR(_4426)->dbl != 0.0;
L1: 
    if (_4424 == 0) {
        DeRef(_4427);
        _4427 = 0;
        goto L2; // [78] 97
    }
    if (IS_SEQUENCE(_lPath_8363)){
            _4428 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4428 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4429 = (object)*(((s1_ptr)_2)->base + _4428);
    if (IS_ATOM_INT(_4429)) {
        _4430 = (_4429 == 34);
    }
    else {
        _4430 = binary_op(EQUALS, _4429, 34);
    }
    _4429 = NOVALUE;
    if (IS_ATOM_INT(_4430))
    _4427 = (_4430 != 0);
    else
    _4427 = DBL_PTR(_4430)->dbl != 0.0;
L2: 
    if (_4427 == 0)
    {
        _4427 = NOVALUE;
        goto L3; // [97] 115
    }
    else{
        _4427 = NOVALUE;
    }

    /** filesys.e:1624	        lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4431 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4431 = 1;
    }
    _4432 = _4431 - 1;
    _4431 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_8363;
    RHS_Slice(_lPath_8363, 2, _4432);
L3: 

    /** filesys.e:1628	    if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4434 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4434 = 1;
    }
    _4435 = (_4434 > 0);
    _4434 = NOVALUE;
    if (_4435 == 0) {
        DeRef(_4436);
        _4436 = 0;
        goto L4; // [124] 140
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4437 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4437)) {
        _4438 = (_4437 == 126);
    }
    else {
        _4438 = binary_op(EQUALS, _4437, 126);
    }
    _4437 = NOVALUE;
    if (IS_ATOM_INT(_4438))
    _4436 = (_4438 != 0);
    else
    _4436 = DBL_PTR(_4438)->dbl != 0.0;
L4: 
    if (_4436 == 0)
    {
        _4436 = NOVALUE;
        goto L5; // [140] 249
    }
    else{
        _4436 = NOVALUE;
    }

    /** filesys.e:1630			lHome = getenv("HOME")*/
    DeRef(_lHome_8367);
    _lHome_8367 = EGetEnv(_4439);

    /** filesys.e:1631			ifdef WINDOWS then*/

    /** filesys.e:1632				if atom(lHome) then*/
    _4441 = IS_ATOM(_lHome_8367);
    if (_4441 == 0)
    {
        _4441 = NOVALUE;
        goto L6; // [155] 171
    }
    else{
        _4441 = NOVALUE;
    }

    /** filesys.e:1633					lHome = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _4443 = EGetEnv(_4442);
    _4445 = EGetEnv(_4444);
    if (IS_SEQUENCE(_4443) && IS_ATOM(_4445)) {
        Ref(_4445);
        Append(&_lHome_8367, _4443, _4445);
    }
    else if (IS_ATOM(_4443) && IS_SEQUENCE(_4445)) {
        Ref(_4443);
        Prepend(&_lHome_8367, _4445, _4443);
    }
    else {
        Concat((object_ptr)&_lHome_8367, _4443, _4445);
        DeRef(_4443);
        _4443 = NOVALUE;
    }
    DeRef(_4443);
    _4443 = NOVALUE;
    DeRef(_4445);
    _4445 = NOVALUE;
L6: 

    /** filesys.e:1637			if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_8367)){
            _4447 = SEQ_PTR(_lHome_8367)->length;
    }
    else {
        _4447 = 1;
    }
    _2 = (object)SEQ_PTR(_lHome_8367);
    _4448 = (object)*(((s1_ptr)_2)->base + _4447);
    if (binary_op_a(EQUALS, _4448, 92)){
        _4448 = NOVALUE;
        goto L7; // [180] 191
    }
    _4448 = NOVALUE;

    /** filesys.e:1638				lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_8367) && IS_ATOM(92)) {
        Append(&_lHome_8367, _lHome_8367, 92);
    }
    else if (IS_ATOM(_lHome_8367) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_lHome_8367, _lHome_8367, 92);
    }
L7: 

    /** filesys.e:1641			if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4451 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4451 = 1;
    }
    _4452 = (_4451 > 1);
    _4451 = NOVALUE;
    if (_4452 == 0) {
        goto L8; // [200] 233
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4454 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4454)) {
        _4455 = (_4454 == 92);
    }
    else {
        _4455 = binary_op(EQUALS, _4454, 92);
    }
    _4454 = NOVALUE;
    if (_4455 == 0) {
        DeRef(_4455);
        _4455 = NOVALUE;
        goto L8; // [213] 233
    }
    else {
        if (!IS_ATOM_INT(_4455) && DBL_PTR(_4455)->dbl == 0.0){
            DeRef(_4455);
            _4455 = NOVALUE;
            goto L8; // [213] 233
        }
        DeRef(_4455);
        _4455 = NOVALUE;
    }
    DeRef(_4455);
    _4455 = NOVALUE;

    /** filesys.e:1642				lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4456 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4456 = 1;
    }
    rhs_slice_target = (object_ptr)&_4457;
    RHS_Slice(_lPath_8363, 3, _4456);
    if (IS_SEQUENCE(_lHome_8367) && IS_ATOM(_4457)) {
    }
    else if (IS_ATOM(_lHome_8367) && IS_SEQUENCE(_4457)) {
        Ref(_lHome_8367);
        Prepend(&_lPath_8363, _4457, _lHome_8367);
    }
    else {
        Concat((object_ptr)&_lPath_8363, _lHome_8367, _4457);
    }
    DeRefDS(_4457);
    _4457 = NOVALUE;
    goto L9; // [230] 248
L8: 

    /** filesys.e:1644				lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4459 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4459 = 1;
    }
    rhs_slice_target = (object_ptr)&_4460;
    RHS_Slice(_lPath_8363, 2, _4459);
    if (IS_SEQUENCE(_lHome_8367) && IS_ATOM(_4460)) {
    }
    else if (IS_ATOM(_lHome_8367) && IS_SEQUENCE(_4460)) {
        Ref(_lHome_8367);
        Prepend(&_lPath_8363, _4460, _lHome_8367);
    }
    else {
        Concat((object_ptr)&_lPath_8363, _lHome_8367, _4460);
    }
    DeRefDS(_4460);
    _4460 = NOVALUE;
L9: 
L5: 

    /** filesys.e:1648		ifdef WINDOWS then*/

    /** filesys.e:1650		    if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4462 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4462 = 1;
    }
    _4463 = (_4462 > 1);
    _4462 = NOVALUE;
    if (_4463 == 0) {
        DeRef(_4464);
        _4464 = 0;
        goto LA; // [260] 276
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4465 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4465)) {
        _4466 = (_4465 == 58);
    }
    else {
        _4466 = binary_op(EQUALS, _4465, 58);
    }
    _4465 = NOVALUE;
    if (IS_ATOM_INT(_4466))
    _4464 = (_4466 != 0);
    else
    _4464 = DBL_PTR(_4466)->dbl != 0.0;
LA: 
    if (_4464 == 0)
    {
        _4464 = NOVALUE;
        goto LB; // [276] 299
    }
    else{
        _4464 = NOVALUE;
    }

    /** filesys.e:1651				lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_8368;
    RHS_Slice(_lPath_8363, 1, 2);

    /** filesys.e:1652				lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4468 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4468 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_8363;
    RHS_Slice(_lPath_8363, 3, _4468);
    goto LC; // [296] 333
LB: 

    /** filesys.e:1654				lDrive = driveid(current_dir()) & ':'*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_current_dir_inlined_current_dir_at_300_8428);
    _current_dir_inlined_current_dir_at_300_8428 = machine(23, 0);

    /** filesys.e:1429		data = pathinfo(path)*/
    RefDS(_current_dir_inlined_current_dir_at_300_8428);
    _0 = _data_inlined_driveid_at_307_8430;
    _data_inlined_driveid_at_307_8430 = _15pathinfo(_current_dir_inlined_current_dir_at_300_8428, 0);
    DeRef(_0);

    /** filesys.e:1430		return data[5]*/
    DeRef(_driveid_inlined_driveid_at_307_8431);
    _2 = (object)SEQ_PTR(_data_inlined_driveid_at_307_8430);
    _driveid_inlined_driveid_at_307_8431 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_driveid_inlined_driveid_at_307_8431);
    DeRef(_data_inlined_driveid_at_307_8430);
    _data_inlined_driveid_at_307_8430 = NOVALUE;
    if (IS_SEQUENCE(_driveid_inlined_driveid_at_307_8431) && IS_ATOM(58)) {
        Append(&_lDrive_8368, _driveid_inlined_driveid_at_307_8431, 58);
    }
    else if (IS_ATOM(_driveid_inlined_driveid_at_307_8431) && IS_SEQUENCE(58)) {
    }
    else {
        Concat((object_ptr)&_lDrive_8368, _driveid_inlined_driveid_at_307_8431, 58);
    }
LC: 

    /** filesys.e:1658		sequence wildcard_suffix*/

    /** filesys.e:1659		integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_8363);
    _first_wildcard_at_8434 = _15find_first_wildcard(_lPath_8363, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_8434)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_8434)->dbl);
        DeRefDS(_first_wildcard_at_8434);
        _first_wildcard_at_8434 = _1;
    }

    /** filesys.e:1660		if first_wildcard_at then*/
    if (_first_wildcard_at_8434 == 0)
    {
        goto LD; // [346] 407
    }
    else{
    }

    /** filesys.e:1661			integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_8363);
    _last_slash_8437 = _14rfind(92, _lPath_8363, _first_wildcard_at_8434);
    if (!IS_ATOM_INT(_last_slash_8437)) {
        _1 = (object)(DBL_PTR(_last_slash_8437)->dbl);
        DeRefDS(_last_slash_8437);
        _last_slash_8437 = _1;
    }

    /** filesys.e:1662			if last_slash then*/
    if (_last_slash_8437 == 0)
    {
        goto LE; // [361] 387
    }
    else{
    }

    /** filesys.e:1663				wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4473 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4473 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_8433;
    RHS_Slice(_lPath_8363, _last_slash_8437, _4473);

    /** filesys.e:1664				lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4475 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4475 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_8363);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_8437)) ? _last_slash_8437 : (object)(DBL_PTR(_last_slash_8437)->dbl);
        int stop = (IS_ATOM_INT(_4475)) ? _4475 : (object)(DBL_PTR(_4475)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_8363), start, &_lPath_8363 );
            }
            else Tail(SEQ_PTR(_lPath_8363), stop+1, &_lPath_8363);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_8363), start, &_lPath_8363);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_8363 = Remove_elements(start, stop, (SEQ_PTR(_lPath_8363)->ref == 1));
        }
    }
    _4475 = NOVALUE;
    goto LF; // [384] 402
LE: 

    /** filesys.e:1666				wildcard_suffix = lPath*/
    RefDS(_lPath_8363);
    DeRef(_wildcard_suffix_8433);
    _wildcard_suffix_8433 = _lPath_8363;

    /** filesys.e:1667				lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_8363);
    _lPath_8363 = _5;
LF: 
    goto L10; // [404] 415
LD: 

    /** filesys.e:1670			wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_8433);
    _wildcard_suffix_8433 = _5;
L10: 

    /** filesys.e:1674		if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4477 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4477 = 1;
    }
    _4478 = (_4477 == 0);
    _4477 = NOVALUE;
    if (_4478 != 0) {
        DeRef(_4479);
        _4479 = 1;
        goto L11; // [424] 444
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4480 = (object)*(((s1_ptr)_2)->base + 1);
    _4482 = find_from(_4480, _4481, 1);
    _4480 = NOVALUE;
    _4483 = (_4482 == 0);
    _4482 = NOVALUE;
    _4479 = (_4483 != 0);
L11: 
    if (_4479 == 0)
    {
        _4479 = NOVALUE;
        goto L12; // [444] 545
    }
    else{
        _4479 = NOVALUE;
    }

    /** filesys.e:1675			ifdef UNIX then*/

    /** filesys.e:1678				if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_8368)){
            _4484 = SEQ_PTR(_lDrive_8368)->length;
    }
    else {
        _4484 = 1;
    }
    if (_4484 != 0)
    goto L13; // [456] 473

    /** filesys.e:1679					lPath = curdir() & lPath*/
    _4486 = _15curdir(0);
    if (IS_SEQUENCE(_4486) && IS_ATOM(_lPath_8363)) {
    }
    else if (IS_ATOM(_4486) && IS_SEQUENCE(_lPath_8363)) {
        Ref(_4486);
        Prepend(&_lPath_8363, _lPath_8363, _4486);
    }
    else {
        Concat((object_ptr)&_lPath_8363, _4486, _lPath_8363);
        DeRef(_4486);
        _4486 = NOVALUE;
    }
    DeRef(_4486);
    _4486 = NOVALUE;
    goto L14; // [470] 488
L13: 

    /** filesys.e:1681					lPath = curdir(lDrive[1]) & lPath*/
    _2 = (object)SEQ_PTR(_lDrive_8368);
    _4488 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_4488);
    _4489 = _15curdir(_4488);
    _4488 = NOVALUE;
    if (IS_SEQUENCE(_4489) && IS_ATOM(_lPath_8363)) {
    }
    else if (IS_ATOM(_4489) && IS_SEQUENCE(_lPath_8363)) {
        Ref(_4489);
        Prepend(&_lPath_8363, _lPath_8363, _4489);
    }
    else {
        Concat((object_ptr)&_lPath_8363, _4489, _lPath_8363);
        DeRef(_4489);
        _4489 = NOVALUE;
    }
    DeRef(_4489);
    _4489 = NOVALUE;
L14: 

    /** filesys.e:1684				if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4491 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4491 = 1;
    }
    _4492 = (_4491 > 1);
    _4491 = NOVALUE;
    if (_4492 == 0) {
        DeRef(_4493);
        _4493 = 0;
        goto L15; // [497] 513
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4494 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4494)) {
        _4495 = (_4494 == 58);
    }
    else {
        _4495 = binary_op(EQUALS, _4494, 58);
    }
    _4494 = NOVALUE;
    if (IS_ATOM_INT(_4495))
    _4493 = (_4495 != 0);
    else
    _4493 = DBL_PTR(_4495)->dbl != 0.0;
L15: 
    if (_4493 == 0)
    {
        _4493 = NOVALUE;
        goto L16; // [513] 544
    }
    else{
        _4493 = NOVALUE;
    }

    /** filesys.e:1685					if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_8368)){
            _4496 = SEQ_PTR(_lDrive_8368)->length;
    }
    else {
        _4496 = 1;
    }
    if (_4496 != 0)
    goto L17; // [521] 533

    /** filesys.e:1686						lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_8368;
    RHS_Slice(_lPath_8363, 1, 2);
L17: 

    /** filesys.e:1688					lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4499 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4499 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_8363;
    RHS_Slice(_lPath_8363, 3, _4499);
L16: 
L12: 

    /** filesys.e:1694		if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _4501 = (_directory_given_8361 != 0);
    if (_4501 == 0) {
        DeRef(_4502);
        _4502 = 0;
        goto L18; // [551] 570
    }
    if (IS_SEQUENCE(_lPath_8363)){
            _4503 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4503 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4504 = (object)*(((s1_ptr)_2)->base + _4503);
    if (IS_ATOM_INT(_4504)) {
        _4505 = (_4504 != 92);
    }
    else {
        _4505 = binary_op(NOTEQ, _4504, 92);
    }
    _4504 = NOVALUE;
    if (IS_ATOM_INT(_4505))
    _4502 = (_4505 != 0);
    else
    _4502 = DBL_PTR(_4505)->dbl != 0.0;
L18: 
    if (_4502 == 0)
    {
        _4502 = NOVALUE;
        goto L19; // [570] 580
    }
    else{
        _4502 = NOVALUE;
    }

    /** filesys.e:1695			lPath &= SLASH*/
    Append(&_lPath_8363, _lPath_8363, 92);
L19: 

    /** filesys.e:1699		lLevel = SLASH & '.' & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = 46;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_8366, concat_list, 3);
    }

    /** filesys.e:1700		lPosA = 1*/
    _lPosA_8364 = 1;

    /** filesys.e:1701		while( lPosA != 0 ) with entry do*/
    goto L1A; // [595] 616
L1B: 
    if (_lPosA_8364 == 0)
    goto L1C; // [598] 628

    /** filesys.e:1702			lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _4509 = _lPosA_8364 + 1;
    if (_4509 > MAXINT){
        _4509 = NewDouble((eudouble)_4509);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_8363);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_8364)) ? _lPosA_8364 : (object)(DBL_PTR(_lPosA_8364)->dbl);
        int stop = (IS_ATOM_INT(_4509)) ? _4509 : (object)(DBL_PTR(_4509)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_8363), start, &_lPath_8363 );
            }
            else Tail(SEQ_PTR(_lPath_8363), stop+1, &_lPath_8363);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_8363), start, &_lPath_8363);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_8363 = Remove_elements(start, stop, (SEQ_PTR(_lPath_8363)->ref == 1));
        }
    }
    DeRef(_4509);
    _4509 = NOVALUE;

    /** filesys.e:1704		  entry*/
L1A: 

    /** filesys.e:1705			lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_8364 = e_match_from(_lLevel_8366, _lPath_8363, _lPosA_8364);

    /** filesys.e:1706		end while*/
    goto L1B; // [625] 598
L1C: 

    /** filesys.e:1709		lLevel = SLASH & ".." & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 92;
        concat_list[1] = _4188;
        concat_list[2] = 92;
        Concat_N((object_ptr)&_lLevel_8366, concat_list, 3);
    }

    /** filesys.e:1711		lPosB = 1*/
    _lPosB_8365 = 1;

    /** filesys.e:1712		while( lPosA != 0 ) with entry do*/
    goto L1D; // [643] 721
L1E: 
    if (_lPosA_8364 == 0)
    goto L1F; // [646] 733

    /** filesys.e:1714			lPosB = lPosA-1*/
    _lPosB_8365 = _lPosA_8364 - 1;

    /** filesys.e:1715			while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L20: 
    _4515 = (_lPosB_8365 > 0);
    if (_4515 == 0) {
        DeRef(_4516);
        _4516 = 0;
        goto L21; // [665] 681
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4517 = (object)*(((s1_ptr)_2)->base + _lPosB_8365);
    if (IS_ATOM_INT(_4517)) {
        _4518 = (_4517 != 92);
    }
    else {
        _4518 = binary_op(NOTEQ, _4517, 92);
    }
    _4517 = NOVALUE;
    if (IS_ATOM_INT(_4518))
    _4516 = (_4518 != 0);
    else
    _4516 = DBL_PTR(_4518)->dbl != 0.0;
L21: 
    if (_4516 == 0)
    {
        _4516 = NOVALUE;
        goto L22; // [681] 695
    }
    else{
        _4516 = NOVALUE;
    }

    /** filesys.e:1716				lPosB -= 1*/
    _lPosB_8365 = _lPosB_8365 - 1;

    /** filesys.e:1717			end while*/
    goto L20; // [692] 661
L22: 

    /** filesys.e:1718			if (lPosB <= 0) then*/
    if (_lPosB_8365 > 0)
    goto L23; // [697] 707

    /** filesys.e:1719				lPosB = 1*/
    _lPosB_8365 = 1;
L23: 

    /** filesys.e:1721			lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _4521 = _lPosA_8364 + 2;
    if ((object)((uintptr_t)_4521 + (uintptr_t)HIGH_BITS) >= 0){
        _4521 = NewDouble((eudouble)_4521);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_8363);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_8365)) ? _lPosB_8365 : (object)(DBL_PTR(_lPosB_8365)->dbl);
        int stop = (IS_ATOM_INT(_4521)) ? _4521 : (object)(DBL_PTR(_4521)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_8363), start, &_lPath_8363 );
            }
            else Tail(SEQ_PTR(_lPath_8363), stop+1, &_lPath_8363);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_8363), start, &_lPath_8363);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_8363 = Remove_elements(start, stop, (SEQ_PTR(_lPath_8363)->ref == 1));
        }
    }
    DeRef(_4521);
    _4521 = NOVALUE;

    /** filesys.e:1723		  entry*/
L1D: 

    /** filesys.e:1724			lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_8364 = e_match_from(_lLevel_8366, _lPath_8363, _lPosB_8365);

    /** filesys.e:1725		end while*/
    goto L1E; // [730] 646
L1F: 

    /** filesys.e:1727		if case_flags = TO_LOWER then*/
    if (_case_flags_8362 != 1)
    goto L24; // [735] 750

    /** filesys.e:1728			lPath = lower( lPath )*/
    RefDS(_lPath_8363);
    _0 = _lPath_8363;
    _lPath_8363 = _12lower(_lPath_8363);
    DeRefDS(_0);
    goto L25; // [747] 1365
L24: 

    /** filesys.e:1730		elsif case_flags != AS_IS then*/
    if (_case_flags_8362 == 0)
    goto L26; // [752] 1362

    /** filesys.e:1731			sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_8363);
    _0 = _sl_8509;
    _sl_8509 = _14find_all(92, _lPath_8363, 1);
    DeRef(_0);

    /** filesys.e:1732			integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {uintptr_t tu;
         tu = (uintptr_t)4 & (uintptr_t)_case_flags_8362;
         _4528 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4528)) {
        _short_name_8512 = (_4528 == 4);
    }
    else {
        _short_name_8512 = (DBL_PTR(_4528)->dbl == (eudouble)4);
    }
    DeRef(_4528);
    _4528 = NOVALUE;

    /** filesys.e:1733			integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {uintptr_t tu;
         tu = (uintptr_t)_case_flags_8362 & (uintptr_t)2;
         _4530 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4530)) {
        _correct_name_8515 = (_4530 == 2);
    }
    else {
        _correct_name_8515 = (DBL_PTR(_4530)->dbl == (eudouble)2);
    }
    DeRef(_4530);
    _4530 = NOVALUE;

    /** filesys.e:1734			integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {uintptr_t tu;
         tu = (uintptr_t)1 & (uintptr_t)_case_flags_8362;
         _4532 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4532)) {
        _lower_name_8518 = (_4532 == 1);
    }
    else {
        _lower_name_8518 = (DBL_PTR(_4532)->dbl == (eudouble)1);
    }
    DeRef(_4532);
    _4532 = NOVALUE;

    /** filesys.e:1735			if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4534 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4534 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_8363);
    _4535 = (object)*(((s1_ptr)_2)->base + _4534);
    if (binary_op_a(EQUALS, _4535, 92)){
        _4535 = NOVALUE;
        goto L27; // [805] 827
    }
    _4535 = NOVALUE;

    /** filesys.e:1736				sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_8363)){
            _4537 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4537 = 1;
    }
    _4538 = _4537 + 1;
    _4537 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _4538;
    _4539 = MAKE_SEQ(_1);
    _4538 = NOVALUE;
    Concat((object_ptr)&_sl_8509, _sl_8509, _4539);
    DeRefDS(_4539);
    _4539 = NOVALUE;
L27: 

    /** filesys.e:1739			for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_8509)){
            _4541 = SEQ_PTR(_sl_8509)->length;
    }
    else {
        _4541 = 1;
    }
    _4542 = _4541 - 1;
    _4541 = NOVALUE;
    {
        object _i_8530;
        _i_8530 = _4542;
L28: 
        if (_i_8530 < 1){
            goto L29; // [836] 1327
        }

        /** filesys.e:1740				ifdef WINDOWS then*/

        /** filesys.e:1741					sequence part = lDrive & lPath[1..sl[i]-1]*/
        _2 = (object)SEQ_PTR(_sl_8509);
        _4544 = (object)*(((s1_ptr)_2)->base + _i_8530);
        if (IS_ATOM_INT(_4544)) {
            _4545 = _4544 - 1;
        }
        else {
            _4545 = binary_op(MINUS, _4544, 1);
        }
        _4544 = NOVALUE;
        rhs_slice_target = (object_ptr)&_4546;
        RHS_Slice(_lPath_8363, 1, _4545);
        Concat((object_ptr)&_part_8534, _lDrive_8368, _4546);
        DeRefDS(_4546);
        _4546 = NOVALUE;

        /** filesys.e:1746				object list = dir( part & SLASH )*/
        Append(&_4548, _part_8534, 92);
        DeRef(_name_inlined_dir_at_874_8542);
        _name_inlined_dir_at_874_8542 = _4548;
        _4548 = NOVALUE;

        /** filesys.e:358		ifdef WINDOWS then*/

        /** filesys.e:359			return machine_func(M_DIR, name)*/
        DeRef(_list_8539);
        _list_8539 = machine(22, _name_inlined_dir_at_874_8542);
        DeRef(_name_inlined_dir_at_874_8542);
        _name_inlined_dir_at_874_8542 = NOVALUE;

        /** filesys.e:1747				sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (object)SEQ_PTR(_sl_8509);
        _4549 = (object)*(((s1_ptr)_2)->base + _i_8530);
        if (IS_ATOM_INT(_4549)) {
            _4550 = _4549 + 1;
            if (_4550 > MAXINT){
                _4550 = NewDouble((eudouble)_4550);
            }
        }
        else
        _4550 = binary_op(PLUS, 1, _4549);
        _4549 = NOVALUE;
        _4551 = _i_8530 + 1;
        _2 = (object)SEQ_PTR(_sl_8509);
        _4552 = (object)*(((s1_ptr)_2)->base + _4551);
        if (IS_ATOM_INT(_4552)) {
            _4553 = _4552 - 1;
        }
        else {
            _4553 = binary_op(MINUS, _4552, 1);
        }
        _4552 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_8544;
        RHS_Slice(_lPath_8363, _4550, _4553);

        /** filesys.e:1749				if atom(list) then*/
        _4555 = IS_ATOM(_list_8539);
        if (_4555 == 0)
        {
            _4555 = NOVALUE;
            goto L2A; // [922] 960
        }
        else{
            _4555 = NOVALUE;
        }

        /** filesys.e:1750					if lower_name then*/
        if (_lower_name_8518 == 0)
        {
            goto L2B; // [927] 953
        }
        else{
        }

        /** filesys.e:1751						lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_8509);
        _4556 = (object)*(((s1_ptr)_2)->base + _i_8530);
        if (IS_SEQUENCE(_lPath_8363)){
                _4557 = SEQ_PTR(_lPath_8363)->length;
        }
        else {
            _4557 = 1;
        }
        rhs_slice_target = (object_ptr)&_4558;
        RHS_Slice(_lPath_8363, _4556, _4557);
        _4559 = _12lower(_4558);
        _4558 = NOVALUE;
        if (IS_SEQUENCE(_part_8534) && IS_ATOM(_4559)) {
            Ref(_4559);
            Append(&_lPath_8363, _part_8534, _4559);
        }
        else if (IS_ATOM(_part_8534) && IS_SEQUENCE(_4559)) {
        }
        else {
            Concat((object_ptr)&_lPath_8363, _part_8534, _4559);
        }
        DeRef(_4559);
        _4559 = NOVALUE;
L2B: 

        /** filesys.e:1753					continue*/
        DeRef(_part_8534);
        _part_8534 = NOVALUE;
        DeRef(_list_8539);
        _list_8539 = NOVALUE;
        DeRef(_supplied_name_8544);
        _supplied_name_8544 = NOVALUE;
        goto L2C; // [957] 1322
L2A: 

        /** filesys.e:1757				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_8539)){
                _4561 = SEQ_PTR(_list_8539)->length;
        }
        else {
            _4561 = 1;
        }
        {
            object _j_8561;
            _j_8561 = 1;
L2D: 
            if (_j_8561 > _4561){
                goto L2E; // [965] 1090
            }

            /** filesys.e:1758					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_8539);
            _4562 = (object)*(((s1_ptr)_2)->base + _j_8561);
            DeRef(_read_name_8563);
            _2 = (object)SEQ_PTR(_4562);
            _read_name_8563 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_8563);
            _4562 = NOVALUE;

            /** filesys.e:1759					if equal(read_name, supplied_name) then*/
            if (_read_name_8563 == _supplied_name_8544)
            _4564 = 1;
            else if (IS_ATOM_INT(_read_name_8563) && IS_ATOM_INT(_supplied_name_8544))
            _4564 = 0;
            else
            _4564 = (compare(_read_name_8563, _supplied_name_8544) == 0);
            if (_4564 == 0)
            {
                _4564 = NOVALUE;
                goto L2F; // [990] 1081
            }
            else{
                _4564 = NOVALUE;
            }

            /** filesys.e:1760						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_8512 == 0) {
                goto L30; // [995] 1072
            }
            _2 = (object)SEQ_PTR(_list_8539);
            _4566 = (object)*(((s1_ptr)_2)->base + _j_8561);
            _2 = (object)SEQ_PTR(_4566);
            _4567 = (object)*(((s1_ptr)_2)->base + 11);
            _4566 = NOVALUE;
            _4568 = IS_SEQUENCE(_4567);
            _4567 = NOVALUE;
            if (_4568 == 0)
            {
                _4568 = NOVALUE;
                goto L30; // [1011] 1072
            }
            else{
                _4568 = NOVALUE;
            }

            /** filesys.e:1761							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_8509);
            _4569 = (object)*(((s1_ptr)_2)->base + _i_8530);
            rhs_slice_target = (object_ptr)&_4570;
            RHS_Slice(_lPath_8363, 1, _4569);
            _2 = (object)SEQ_PTR(_list_8539);
            _4571 = (object)*(((s1_ptr)_2)->base + _j_8561);
            _2 = (object)SEQ_PTR(_4571);
            _4572 = (object)*(((s1_ptr)_2)->base + 11);
            _4571 = NOVALUE;
            _4573 = _i_8530 + 1;
            _2 = (object)SEQ_PTR(_sl_8509);
            _4574 = (object)*(((s1_ptr)_2)->base + _4573);
            if (IS_SEQUENCE(_lPath_8363)){
                    _4575 = SEQ_PTR(_lPath_8363)->length;
            }
            else {
                _4575 = 1;
            }
            rhs_slice_target = (object_ptr)&_4576;
            RHS_Slice(_lPath_8363, _4574, _4575);
            {
                object concat_list[3];

                concat_list[0] = _4576;
                concat_list[1] = _4572;
                concat_list[2] = _4570;
                Concat_N((object_ptr)&_lPath_8363, concat_list, 3);
            }
            DeRefDS(_4576);
            _4576 = NOVALUE;
            _4572 = NOVALUE;
            DeRefDS(_4570);
            _4570 = NOVALUE;

            /** filesys.e:1762							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_8509)){
                    _4578 = SEQ_PTR(_sl_8509)->length;
            }
            else {
                _4578 = 1;
            }
            if (IS_SEQUENCE(_lPath_8363)){
                    _4579 = SEQ_PTR(_lPath_8363)->length;
            }
            else {
                _4579 = 1;
            }
            _4580 = _4579 + 1;
            _4579 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_8509);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_8509 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _4578);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _4580;
            if( _1 != _4580 ){
                DeRef(_1);
            }
            _4580 = NOVALUE;
L30: 

            /** filesys.e:1764						continue "partloop"*/
            DeRef(_read_name_8563);
            _read_name_8563 = NOVALUE;
            DeRef(_part_8534);
            _part_8534 = NOVALUE;
            DeRef(_list_8539);
            _list_8539 = NOVALUE;
            DeRef(_supplied_name_8544);
            _supplied_name_8544 = NOVALUE;
            goto L2C; // [1078] 1322
L2F: 
            DeRef(_read_name_8563);
            _read_name_8563 = NOVALUE;

            /** filesys.e:1766				end for*/
            _j_8561 = _j_8561 + 1;
            goto L2D; // [1085] 972
L2E: 
            ;
        }

        /** filesys.e:1770				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_8539)){
                _4581 = SEQ_PTR(_list_8539)->length;
        }
        else {
            _4581 = 1;
        }
        {
            object _j_8586;
            _j_8586 = 1;
L31: 
            if (_j_8586 > _4581){
                goto L32; // [1095] 1267
            }

            /** filesys.e:1771					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_8539);
            _4582 = (object)*(((s1_ptr)_2)->base + _j_8586);
            DeRef(_read_name_8588);
            _2 = (object)SEQ_PTR(_4582);
            _read_name_8588 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_8588);
            _4582 = NOVALUE;

            /** filesys.e:1772					if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_8588);
            _4584 = _12lower(_read_name_8588);
            RefDS(_supplied_name_8544);
            _4585 = _12lower(_supplied_name_8544);
            if (_4584 == _4585)
            _4586 = 1;
            else if (IS_ATOM_INT(_4584) && IS_ATOM_INT(_4585))
            _4586 = 0;
            else
            _4586 = (compare(_4584, _4585) == 0);
            DeRef(_4584);
            _4584 = NOVALUE;
            DeRef(_4585);
            _4585 = NOVALUE;
            if (_4586 == 0)
            {
                _4586 = NOVALUE;
                goto L33; // [1128] 1258
            }
            else{
                _4586 = NOVALUE;
            }

            /** filesys.e:1773						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_8512 == 0) {
                goto L34; // [1133] 1210
            }
            _2 = (object)SEQ_PTR(_list_8539);
            _4588 = (object)*(((s1_ptr)_2)->base + _j_8586);
            _2 = (object)SEQ_PTR(_4588);
            _4589 = (object)*(((s1_ptr)_2)->base + 11);
            _4588 = NOVALUE;
            _4590 = IS_SEQUENCE(_4589);
            _4589 = NOVALUE;
            if (_4590 == 0)
            {
                _4590 = NOVALUE;
                goto L34; // [1149] 1210
            }
            else{
                _4590 = NOVALUE;
            }

            /** filesys.e:1774							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_8509);
            _4591 = (object)*(((s1_ptr)_2)->base + _i_8530);
            rhs_slice_target = (object_ptr)&_4592;
            RHS_Slice(_lPath_8363, 1, _4591);
            _2 = (object)SEQ_PTR(_list_8539);
            _4593 = (object)*(((s1_ptr)_2)->base + _j_8586);
            _2 = (object)SEQ_PTR(_4593);
            _4594 = (object)*(((s1_ptr)_2)->base + 11);
            _4593 = NOVALUE;
            _4595 = _i_8530 + 1;
            _2 = (object)SEQ_PTR(_sl_8509);
            _4596 = (object)*(((s1_ptr)_2)->base + _4595);
            if (IS_SEQUENCE(_lPath_8363)){
                    _4597 = SEQ_PTR(_lPath_8363)->length;
            }
            else {
                _4597 = 1;
            }
            rhs_slice_target = (object_ptr)&_4598;
            RHS_Slice(_lPath_8363, _4596, _4597);
            {
                object concat_list[3];

                concat_list[0] = _4598;
                concat_list[1] = _4594;
                concat_list[2] = _4592;
                Concat_N((object_ptr)&_lPath_8363, concat_list, 3);
            }
            DeRefDS(_4598);
            _4598 = NOVALUE;
            _4594 = NOVALUE;
            DeRefDS(_4592);
            _4592 = NOVALUE;

            /** filesys.e:1775							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_8509)){
                    _4600 = SEQ_PTR(_sl_8509)->length;
            }
            else {
                _4600 = 1;
            }
            if (IS_SEQUENCE(_lPath_8363)){
                    _4601 = SEQ_PTR(_lPath_8363)->length;
            }
            else {
                _4601 = 1;
            }
            _4602 = _4601 + 1;
            _4601 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_8509);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_8509 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _4600);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _4602;
            if( _1 != _4602 ){
                DeRef(_1);
            }
            _4602 = NOVALUE;
L34: 

            /** filesys.e:1777						if correct_name then*/
            if (_correct_name_8515 == 0)
            {
                goto L35; // [1212] 1249
            }
            else{
            }

            /** filesys.e:1778							lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_8509);
            _4603 = (object)*(((s1_ptr)_2)->base + _i_8530);
            rhs_slice_target = (object_ptr)&_4604;
            RHS_Slice(_lPath_8363, 1, _4603);
            _4605 = _i_8530 + 1;
            _2 = (object)SEQ_PTR(_sl_8509);
            _4606 = (object)*(((s1_ptr)_2)->base + _4605);
            if (IS_SEQUENCE(_lPath_8363)){
                    _4607 = SEQ_PTR(_lPath_8363)->length;
            }
            else {
                _4607 = 1;
            }
            rhs_slice_target = (object_ptr)&_4608;
            RHS_Slice(_lPath_8363, _4606, _4607);
            {
                object concat_list[3];

                concat_list[0] = _4608;
                concat_list[1] = _read_name_8588;
                concat_list[2] = _4604;
                Concat_N((object_ptr)&_lPath_8363, concat_list, 3);
            }
            DeRefDS(_4608);
            _4608 = NOVALUE;
            DeRefDS(_4604);
            _4604 = NOVALUE;
L35: 

            /** filesys.e:1780						continue "partloop"*/
            DeRef(_read_name_8588);
            _read_name_8588 = NOVALUE;
            DeRef(_part_8534);
            _part_8534 = NOVALUE;
            DeRef(_list_8539);
            _list_8539 = NOVALUE;
            DeRef(_supplied_name_8544);
            _supplied_name_8544 = NOVALUE;
            goto L2C; // [1255] 1322
L33: 
            DeRef(_read_name_8588);
            _read_name_8588 = NOVALUE;

            /** filesys.e:1782				end for*/
            _j_8586 = _j_8586 + 1;
            goto L31; // [1262] 1102
L32: 
            ;
        }

        /** filesys.e:1786				if and_bits(TO_LOWER,case_flags) then*/
        {uintptr_t tu;
             tu = (uintptr_t)1 & (uintptr_t)_case_flags_8362;
             _4610 = MAKE_UINT(tu);
        }
        if (_4610 == 0) {
            DeRef(_4610);
            _4610 = NOVALUE;
            goto L36; // [1273] 1312
        }
        else {
            if (!IS_ATOM_INT(_4610) && DBL_PTR(_4610)->dbl == 0.0){
                DeRef(_4610);
                _4610 = NOVALUE;
                goto L36; // [1273] 1312
            }
            DeRef(_4610);
            _4610 = NOVALUE;
        }
        DeRef(_4610);
        _4610 = NOVALUE;

        /** filesys.e:1787					lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_8509);
        _4611 = (object)*(((s1_ptr)_2)->base + _i_8530);
        if (IS_ATOM_INT(_4611)) {
            _4612 = _4611 - 1;
        }
        else {
            _4612 = binary_op(MINUS, _4611, 1);
        }
        _4611 = NOVALUE;
        rhs_slice_target = (object_ptr)&_4613;
        RHS_Slice(_lPath_8363, 1, _4612);
        _2 = (object)SEQ_PTR(_sl_8509);
        _4614 = (object)*(((s1_ptr)_2)->base + _i_8530);
        if (IS_SEQUENCE(_lPath_8363)){
                _4615 = SEQ_PTR(_lPath_8363)->length;
        }
        else {
            _4615 = 1;
        }
        rhs_slice_target = (object_ptr)&_4616;
        RHS_Slice(_lPath_8363, _4614, _4615);
        _4617 = _12lower(_4616);
        _4616 = NOVALUE;
        if (IS_SEQUENCE(_4613) && IS_ATOM(_4617)) {
            Ref(_4617);
            Append(&_lPath_8363, _4613, _4617);
        }
        else if (IS_ATOM(_4613) && IS_SEQUENCE(_4617)) {
        }
        else {
            Concat((object_ptr)&_lPath_8363, _4613, _4617);
            DeRefDS(_4613);
            _4613 = NOVALUE;
        }
        DeRef(_4613);
        _4613 = NOVALUE;
        DeRef(_4617);
        _4617 = NOVALUE;
L36: 

        /** filesys.e:1789				exit*/
        DeRef(_part_8534);
        _part_8534 = NOVALUE;
        DeRef(_list_8539);
        _list_8539 = NOVALUE;
        DeRef(_supplied_name_8544);
        _supplied_name_8544 = NOVALUE;
        goto L29; // [1316] 1327

        /** filesys.e:1790			end for*/
L2C: 
        _i_8530 = _i_8530 + -1;
        goto L28; // [1322] 843
L29: 
        ;
    }

    /** filesys.e:1791			if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {uintptr_t tu;
         tu = (uintptr_t)2 | (uintptr_t)1;
         _4619 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4619)) {
        {uintptr_t tu;
             tu = (uintptr_t)_case_flags_8362 & (uintptr_t)_4619;
             _4620 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_case_flags_8362;
        _4620 = Dand_bits(&temp_d, DBL_PTR(_4619));
    }
    DeRef(_4619);
    _4619 = NOVALUE;
    if (IS_ATOM_INT(_4620)) {
        _4621 = (_4620 == 1);
    }
    else {
        _4621 = (DBL_PTR(_4620)->dbl == (eudouble)1);
    }
    DeRef(_4620);
    _4620 = NOVALUE;
    if (_4621 == 0) {
        goto L37; // [1341] 1361
    }
    if (IS_SEQUENCE(_lPath_8363)){
            _4623 = SEQ_PTR(_lPath_8363)->length;
    }
    else {
        _4623 = 1;
    }
    if (_4623 == 0)
    {
        _4623 = NOVALUE;
        goto L37; // [1349] 1361
    }
    else{
        _4623 = NOVALUE;
    }

    /** filesys.e:1792				lPath = lower(lPath)*/
    RefDS(_lPath_8363);
    _0 = _lPath_8363;
    _lPath_8363 = _12lower(_lPath_8363);
    DeRefDS(_0);
L37: 
L26: 
    DeRef(_sl_8509);
    _sl_8509 = NOVALUE;
L25: 

    /** filesys.e:1796		ifdef WINDOWS then*/

    /** filesys.e:1797			if and_bits(CORRECT,case_flags) then*/
    {uintptr_t tu;
         tu = (uintptr_t)2 & (uintptr_t)_case_flags_8362;
         _4625 = MAKE_UINT(tu);
    }
    if (_4625 == 0) {
        DeRef(_4625);
        _4625 = NOVALUE;
        goto L38; // [1373] 1415
    }
    else {
        if (!IS_ATOM_INT(_4625) && DBL_PTR(_4625)->dbl == 0.0){
            DeRef(_4625);
            _4625 = NOVALUE;
            goto L38; // [1373] 1415
        }
        DeRef(_4625);
        _4625 = NOVALUE;
    }
    DeRef(_4625);
    _4625 = NOVALUE;

    /** filesys.e:1799				if or_bits(system_drive_case,'A') = 'a' then*/
    if (IS_ATOM_INT(_15system_drive_case_8346)) {
        {uintptr_t tu;
             tu = (uintptr_t)_15system_drive_case_8346 | (uintptr_t)65;
             _4626 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)65;
        _4626 = Dor_bits(DBL_PTR(_15system_drive_case_8346), &temp_d);
    }
    if (binary_op_a(NOTEQ, _4626, 97)){
        DeRef(_4626);
        _4626 = NOVALUE;
        goto L39; // [1384] 1401
    }
    DeRef(_4626);
    _4626 = NOVALUE;

    /** filesys.e:1800					lDrive = lower(lDrive)*/
    RefDS(_lDrive_8368);
    _0 = _lDrive_8368;
    _lDrive_8368 = _12lower(_lDrive_8368);
    DeRefDS(_0);
    goto L3A; // [1398] 1436
L39: 

    /** filesys.e:1802					lDrive = upper(lDrive)*/
    RefDS(_lDrive_8368);
    _0 = _lDrive_8368;
    _lDrive_8368 = _12upper(_lDrive_8368);
    DeRefDS(_0);
    goto L3A; // [1412] 1436
L38: 

    /** filesys.e:1804			elsif and_bits(TO_LOWER,case_flags) then*/
    {uintptr_t tu;
         tu = (uintptr_t)1 & (uintptr_t)_case_flags_8362;
         _4630 = MAKE_UINT(tu);
    }
    if (_4630 == 0) {
        DeRef(_4630);
        _4630 = NOVALUE;
        goto L3B; // [1421] 1435
    }
    else {
        if (!IS_ATOM_INT(_4630) && DBL_PTR(_4630)->dbl == 0.0){
            DeRef(_4630);
            _4630 = NOVALUE;
            goto L3B; // [1421] 1435
        }
        DeRef(_4630);
        _4630 = NOVALUE;
    }
    DeRef(_4630);
    _4630 = NOVALUE;

    /** filesys.e:1805				lDrive = lower(lDrive)*/
    RefDS(_lDrive_8368);
    _0 = _lDrive_8368;
    _lDrive_8368 = _12lower(_lDrive_8368);
    DeRefDS(_0);
L3B: 
L3A: 

    /** filesys.e:1807			lPath = lDrive & lPath*/
    Concat((object_ptr)&_lPath_8363, _lDrive_8368, _lPath_8363);

    /** filesys.e:1810		return lPath & wildcard_suffix*/
    Concat((object_ptr)&_4633, _lPath_8363, _wildcard_suffix_8433);
    DeRefDS(_path_in_8360);
    DeRefDS(_lPath_8363);
    DeRefi(_lLevel_8366);
    DeRef(_lHome_8367);
    DeRefDS(_lDrive_8368);
    DeRefDS(_wildcard_suffix_8433);
    _4574 = NOVALUE;
    DeRef(_4492);
    _4492 = NOVALUE;
    DeRef(_4426);
    _4426 = NOVALUE;
    DeRef(_4466);
    _4466 = NOVALUE;
    _4606 = NOVALUE;
    DeRef(_4478);
    _4478 = NOVALUE;
    _4591 = NOVALUE;
    _4556 = NOVALUE;
    DeRef(_4605);
    _4605 = NOVALUE;
    DeRef(_4518);
    _4518 = NOVALUE;
    DeRef(_4430);
    _4430 = NOVALUE;
    _4603 = NOVALUE;
    _4569 = NOVALUE;
    DeRef(_4621);
    _4621 = NOVALUE;
    DeRef(_4495);
    _4495 = NOVALUE;
    DeRef(_4612);
    _4612 = NOVALUE;
    _4596 = NOVALUE;
    _4614 = NOVALUE;
    DeRef(_4573);
    _4573 = NOVALUE;
    DeRef(_4505);
    _4505 = NOVALUE;
    DeRef(_4553);
    _4553 = NOVALUE;
    DeRef(_4551);
    _4551 = NOVALUE;
    DeRef(_4432);
    _4432 = NOVALUE;
    DeRef(_4501);
    _4501 = NOVALUE;
    DeRef(_4515);
    _4515 = NOVALUE;
    DeRef(_4550);
    _4550 = NOVALUE;
    DeRef(_4438);
    _4438 = NOVALUE;
    DeRef(_4595);
    _4595 = NOVALUE;
    DeRef(_4423);
    _4423 = NOVALUE;
    DeRef(_4542);
    _4542 = NOVALUE;
    DeRef(_4435);
    _4435 = NOVALUE;
    DeRef(_4452);
    _4452 = NOVALUE;
    DeRef(_4483);
    _4483 = NOVALUE;
    DeRef(_4463);
    _4463 = NOVALUE;
    DeRef(_4545);
    _4545 = NOVALUE;
    return _4633;
    ;
}


object _15fs_case(object _s_8659)
{
    object _4634 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1825		ifdef WINDOWS then*/

    /** filesys.e:1826			return lower(s)*/
    RefDS(_s_8659);
    _4634 = _12lower(_s_8659);
    DeRefDS(_s_8659);
    return _4634;
    ;
}


object _15abbreviate_path(object _orig_path_8664, object _base_paths_8665)
{
    object _expanded_path_8666 = NOVALUE;
    object _lowered_expanded_path_8676 = NOVALUE;
    object _4679 = NOVALUE;
    object _4678 = NOVALUE;
    object _4675 = NOVALUE;
    object _4674 = NOVALUE;
    object _4673 = NOVALUE;
    object _4672 = NOVALUE;
    object _4671 = NOVALUE;
    object _4669 = NOVALUE;
    object _4668 = NOVALUE;
    object _4667 = NOVALUE;
    object _4666 = NOVALUE;
    object _4665 = NOVALUE;
    object _4664 = NOVALUE;
    object _4663 = NOVALUE;
    object _4662 = NOVALUE;
    object _4661 = NOVALUE;
    object _4658 = NOVALUE;
    object _4657 = NOVALUE;
    object _4655 = NOVALUE;
    object _4654 = NOVALUE;
    object _4653 = NOVALUE;
    object _4652 = NOVALUE;
    object _4651 = NOVALUE;
    object _4650 = NOVALUE;
    object _4649 = NOVALUE;
    object _4648 = NOVALUE;
    object _4647 = NOVALUE;
    object _4646 = NOVALUE;
    object _4645 = NOVALUE;
    object _4644 = NOVALUE;
    object _4643 = NOVALUE;
    object _4640 = NOVALUE;
    object _4639 = NOVALUE;
    object _4638 = NOVALUE;
    object _4636 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1881		expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_8664);
    _0 = _expanded_path_8666;
    _expanded_path_8666 = _15canonical_path(_orig_path_8664, 0, 0);
    DeRef(_0);

    /** filesys.e:1884		base_paths = append(base_paths, curdir())*/
    _4636 = _15curdir(0);
    Ref(_4636);
    Append(&_base_paths_8665, _base_paths_8665, _4636);
    DeRef(_4636);
    _4636 = NOVALUE;

    /** filesys.e:1886		for i = 1 to length(base_paths) do*/
    _4638 = 1;
    {
        object _i_8671;
        _i_8671 = 1;
L1: 
        if (_i_8671 > 1){
            goto L2; // [30] 60
        }

        /** filesys.e:1887			base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (object)SEQ_PTR(_base_paths_8665);
        _4639 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_4639);
        _4640 = _15canonical_path(_4639, 1, 0);
        _4639 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_8665);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _base_paths_8665 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4640;
        if( _1 != _4640 ){
            DeRef(_1);
        }
        _4640 = NOVALUE;

        /** filesys.e:1888		end for*/
        _i_8671 = 1 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** filesys.e:1892		base_paths = fs_case(base_paths)*/
    RefDS(_base_paths_8665);
    _0 = _base_paths_8665;
    _base_paths_8665 = _15fs_case(_base_paths_8665);
    DeRefDS(_0);

    /** filesys.e:1893		sequence lowered_expanded_path = fs_case(expanded_path)*/
    RefDS(_expanded_path_8666);
    _0 = _lowered_expanded_path_8676;
    _lowered_expanded_path_8676 = _15fs_case(_expanded_path_8666);
    DeRef(_0);

    /** filesys.e:1896		for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_8665)){
            _4643 = SEQ_PTR(_base_paths_8665)->length;
    }
    else {
        _4643 = 1;
    }
    {
        object _i_8679;
        _i_8679 = 1;
L3: 
        if (_i_8679 > _4643){
            goto L4; // [81] 135
        }

        /** filesys.e:1897			if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (object)SEQ_PTR(_base_paths_8665);
        _4644 = (object)*(((s1_ptr)_2)->base + _i_8679);
        Ref(_4644);
        RefDS(_lowered_expanded_path_8676);
        _4645 = _14begins(_4644, _lowered_expanded_path_8676);
        _4644 = NOVALUE;
        if (_4645 == 0) {
            DeRef(_4645);
            _4645 = NOVALUE;
            goto L5; // [99] 128
        }
        else {
            if (!IS_ATOM_INT(_4645) && DBL_PTR(_4645)->dbl == 0.0){
                DeRef(_4645);
                _4645 = NOVALUE;
                goto L5; // [99] 128
            }
            DeRef(_4645);
            _4645 = NOVALUE;
        }
        DeRef(_4645);
        _4645 = NOVALUE;

        /** filesys.e:1899				return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (object)SEQ_PTR(_base_paths_8665);
        _4646 = (object)*(((s1_ptr)_2)->base + _i_8679);
        if (IS_SEQUENCE(_4646)){
                _4647 = SEQ_PTR(_4646)->length;
        }
        else {
            _4647 = 1;
        }
        _4646 = NOVALUE;
        _4648 = _4647 + 1;
        _4647 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_8666)){
                _4649 = SEQ_PTR(_expanded_path_8666)->length;
        }
        else {
            _4649 = 1;
        }
        rhs_slice_target = (object_ptr)&_4650;
        RHS_Slice(_expanded_path_8666, _4648, _4649);
        DeRefDS(_orig_path_8664);
        DeRefDS(_base_paths_8665);
        DeRefDS(_expanded_path_8666);
        DeRefDS(_lowered_expanded_path_8676);
        _4646 = NOVALUE;
        _4648 = NOVALUE;
        return _4650;
L5: 

        /** filesys.e:1901		end for*/
        _i_8679 = _i_8679 + 1;
        goto L3; // [130] 88
L4: 
        ;
    }

    /** filesys.e:1904		ifdef WINDOWS then*/

    /** filesys.e:1906			if not equal(base_paths[$][1], lowered_expanded_path[1]) then*/
    if (IS_SEQUENCE(_base_paths_8665)){
            _4651 = SEQ_PTR(_base_paths_8665)->length;
    }
    else {
        _4651 = 1;
    }
    _2 = (object)SEQ_PTR(_base_paths_8665);
    _4652 = (object)*(((s1_ptr)_2)->base + _4651);
    _2 = (object)SEQ_PTR(_4652);
    _4653 = (object)*(((s1_ptr)_2)->base + 1);
    _4652 = NOVALUE;
    _2 = (object)SEQ_PTR(_lowered_expanded_path_8676);
    _4654 = (object)*(((s1_ptr)_2)->base + 1);
    if (_4653 == _4654)
    _4655 = 1;
    else if (IS_ATOM_INT(_4653) && IS_ATOM_INT(_4654))
    _4655 = 0;
    else
    _4655 = (compare(_4653, _4654) == 0);
    _4653 = NOVALUE;
    _4654 = NOVALUE;
    if (_4655 != 0)
    goto L6; // [158] 168
    _4655 = NOVALUE;

    /** filesys.e:1907				return orig_path*/
    DeRefDS(_base_paths_8665);
    DeRef(_expanded_path_8666);
    DeRefDS(_lowered_expanded_path_8676);
    _4646 = NOVALUE;
    DeRef(_4648);
    _4648 = NOVALUE;
    DeRef(_4650);
    _4650 = NOVALUE;
    return _orig_path_8664;
L6: 

    /** filesys.e:1912		base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_8665)){
            _4657 = SEQ_PTR(_base_paths_8665)->length;
    }
    else {
        _4657 = 1;
    }
    _2 = (object)SEQ_PTR(_base_paths_8665);
    _4658 = (object)*(((s1_ptr)_2)->base + _4657);
    Ref(_4658);
    _0 = _base_paths_8665;
    _base_paths_8665 = _24split(_4658, 92, 0, 0);
    DeRefDS(_0);
    _4658 = NOVALUE;

    /** filesys.e:1914		expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_8666);
    _0 = _expanded_path_8666;
    _expanded_path_8666 = _24split(_expanded_path_8666, 92, 0, 0);
    DeRefDS(_0);

    /** filesys.e:1915		lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_8676);
    _lowered_expanded_path_8676 = _5;

    /** filesys.e:1918		for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_8666)){
            _4661 = SEQ_PTR(_expanded_path_8666)->length;
    }
    else {
        _4661 = 1;
    }
    if (IS_SEQUENCE(_base_paths_8665)){
            _4662 = SEQ_PTR(_base_paths_8665)->length;
    }
    else {
        _4662 = 1;
    }
    _4663 = _4662 - 1;
    _4662 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _4661;
    ((intptr_t *)_2)[2] = _4663;
    _4664 = MAKE_SEQ(_1);
    _4663 = NOVALUE;
    _4661 = NOVALUE;
    _4665 = _21min(_4664);
    _4664 = NOVALUE;
    {
        object _i_8701;
        _i_8701 = 1;
L7: 
        if (binary_op_a(GREATER, _i_8701, _4665)){
            goto L8; // [224] 317
        }

        /** filesys.e:1919			if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (object)SEQ_PTR(_expanded_path_8666);
        if (!IS_ATOM_INT(_i_8701)){
            _4666 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_8701)->dbl));
        }
        else{
            _4666 = (object)*(((s1_ptr)_2)->base + _i_8701);
        }
        Ref(_4666);
        _4667 = _15fs_case(_4666);
        _4666 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_8665);
        if (!IS_ATOM_INT(_i_8701)){
            _4668 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_8701)->dbl));
        }
        else{
            _4668 = (object)*(((s1_ptr)_2)->base + _i_8701);
        }
        if (_4667 == _4668)
        _4669 = 1;
        else if (IS_ATOM_INT(_4667) && IS_ATOM_INT(_4668))
        _4669 = 0;
        else
        _4669 = (compare(_4667, _4668) == 0);
        DeRef(_4667);
        _4667 = NOVALUE;
        _4668 = NOVALUE;
        if (_4669 != 0)
        goto L9; // [249] 310
        _4669 = NOVALUE;

        /** filesys.e:1923				expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_8665)){
                _4671 = SEQ_PTR(_base_paths_8665)->length;
        }
        else {
            _4671 = 1;
        }
        if (IS_ATOM_INT(_i_8701)) {
            _4672 = _4671 - _i_8701;
        }
        else {
            _4672 = NewDouble((eudouble)_4671 - DBL_PTR(_i_8701)->dbl);
        }
        _4671 = NOVALUE;
        _4673 = Repeat(_4188, _4672);
        DeRef(_4672);
        _4672 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_8666)){
                _4674 = SEQ_PTR(_expanded_path_8666)->length;
        }
        else {
            _4674 = 1;
        }
        rhs_slice_target = (object_ptr)&_4675;
        RHS_Slice(_expanded_path_8666, _i_8701, _4674);
        Concat((object_ptr)&_expanded_path_8666, _4673, _4675);
        DeRefDS(_4673);
        _4673 = NOVALUE;
        DeRef(_4673);
        _4673 = NOVALUE;
        DeRefDS(_4675);
        _4675 = NOVALUE;

        /** filesys.e:1924				expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_8666);
        _0 = _expanded_path_8666;
        _expanded_path_8666 = _24join(_expanded_path_8666, 92);
        DeRefDS(_0);

        /** filesys.e:1925				if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_8666)){
                _4678 = SEQ_PTR(_expanded_path_8666)->length;
        }
        else {
            _4678 = 1;
        }
        if (IS_SEQUENCE(_orig_path_8664)){
                _4679 = SEQ_PTR(_orig_path_8664)->length;
        }
        else {
            _4679 = 1;
        }
        if (_4678 >= _4679)
        goto L8; // [294] 317

        /** filesys.e:1927			  		return expanded_path*/
        DeRef(_i_8701);
        DeRefDS(_orig_path_8664);
        DeRefDS(_base_paths_8665);
        DeRef(_lowered_expanded_path_8676);
        DeRef(_4665);
        _4665 = NOVALUE;
        _4646 = NOVALUE;
        DeRef(_4648);
        _4648 = NOVALUE;
        DeRef(_4650);
        _4650 = NOVALUE;
        return _expanded_path_8666;

        /** filesys.e:1929				exit*/
        goto L8; // [307] 317
L9: 

        /** filesys.e:1931		end for*/
        _0 = _i_8701;
        if (IS_ATOM_INT(_i_8701)) {
            _i_8701 = _i_8701 + 1;
            if ((object)((uintptr_t)_i_8701 +(uintptr_t) HIGH_BITS) >= 0){
                _i_8701 = NewDouble((eudouble)_i_8701);
            }
        }
        else {
            _i_8701 = binary_op_a(PLUS, _i_8701, 1);
        }
        DeRef(_0);
        goto L7; // [312] 231
L8: 
        ;
        DeRef(_i_8701);
    }

    /** filesys.e:1934		return orig_path*/
    DeRefDS(_base_paths_8665);
    DeRef(_expanded_path_8666);
    DeRef(_lowered_expanded_path_8676);
    DeRef(_4665);
    _4665 = NOVALUE;
    _4646 = NOVALUE;
    DeRef(_4648);
    _4648 = NOVALUE;
    DeRef(_4650);
    _4650 = NOVALUE;
    return _orig_path_8664;
    ;
}


object _15file_type(object _filename_8761)
{
    object _dirfil_8762 = NOVALUE;
    object _dir_inlined_dir_at_64_8775 = NOVALUE;
    object _4720 = NOVALUE;
    object _4719 = NOVALUE;
    object _4718 = NOVALUE;
    object _4717 = NOVALUE;
    object _4716 = NOVALUE;
    object _4714 = NOVALUE;
    object _4713 = NOVALUE;
    object _4712 = NOVALUE;
    object _4711 = NOVALUE;
    object _4710 = NOVALUE;
    object _4709 = NOVALUE;
    object _4708 = NOVALUE;
    object _4706 = NOVALUE;
    object _4705 = NOVALUE;
    object _4704 = NOVALUE;
    object _4703 = NOVALUE;
    object _4702 = NOVALUE;
    object _4701 = NOVALUE;
    object _4699 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2040		if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _4699 = find_from(42, _filename_8761, 1);
    if (_4699 != 0) {
        goto L1; // [10] 24
    }
    _4701 = find_from(63, _filename_8761, 1);
    if (_4701 == 0)
    {
        _4701 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _4701 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_8761);
    DeRef(_dirfil_8762);
    return -1;
L2: 

    /** filesys.e:2042		ifdef WINDOWS then*/

    /** filesys.e:2043			if length(filename) = 2 and filename[2] = ':' then*/
    if (IS_SEQUENCE(_filename_8761)){
            _4702 = SEQ_PTR(_filename_8761)->length;
    }
    else {
        _4702 = 1;
    }
    _4703 = (_4702 == 2);
    _4702 = NOVALUE;
    if (_4703 == 0) {
        goto L3; // [40] 63
    }
    _2 = (object)SEQ_PTR(_filename_8761);
    _4705 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4705)) {
        _4706 = (_4705 == 58);
    }
    else {
        _4706 = binary_op(EQUALS, _4705, 58);
    }
    _4705 = NOVALUE;
    if (_4706 == 0) {
        DeRef(_4706);
        _4706 = NOVALUE;
        goto L3; // [53] 63
    }
    else {
        if (!IS_ATOM_INT(_4706) && DBL_PTR(_4706)->dbl == 0.0){
            DeRef(_4706);
            _4706 = NOVALUE;
            goto L3; // [53] 63
        }
        DeRef(_4706);
        _4706 = NOVALUE;
    }
    DeRef(_4706);
    _4706 = NOVALUE;

    /** filesys.e:2044				filename &= "\\"*/
    Concat((object_ptr)&_filename_8761, _filename_8761, _1202);
L3: 

    /** filesys.e:2048		dirfil = dir(filename)*/

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    DeRef(_dirfil_8762);
    _dirfil_8762 = machine(22, _filename_8761);

    /** filesys.e:2049		if sequence(dirfil) then*/
    _4708 = IS_SEQUENCE(_dirfil_8762);
    if (_4708 == 0)
    {
        _4708 = NOVALUE;
        goto L4; // [79] 163
    }
    else{
        _4708 = NOVALUE;
    }

    /** filesys.e:2050			if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_8762)){
            _4709 = SEQ_PTR(_dirfil_8762)->length;
    }
    else {
        _4709 = 1;
    }
    _4710 = (_4709 > 1);
    _4709 = NOVALUE;
    if (_4710 != 0) {
        _4711 = 1;
        goto L5; // [91] 112
    }
    _2 = (object)SEQ_PTR(_dirfil_8762);
    _4712 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4712);
    _4713 = (object)*(((s1_ptr)_2)->base + 2);
    _4712 = NOVALUE;
    _4714 = find_from(100, _4713, 1);
    _4713 = NOVALUE;
    _4711 = (_4714 != 0);
L5: 
    if (_4711 != 0) {
        goto L6; // [112] 144
    }
    if (IS_SEQUENCE(_filename_8761)){
            _4716 = SEQ_PTR(_filename_8761)->length;
    }
    else {
        _4716 = 1;
    }
    _4717 = (_4716 == 3);
    _4716 = NOVALUE;
    if (_4717 == 0) {
        DeRef(_4718);
        _4718 = 0;
        goto L7; // [123] 139
    }
    _2 = (object)SEQ_PTR(_filename_8761);
    _4719 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4719)) {
        _4720 = (_4719 == 58);
    }
    else {
        _4720 = binary_op(EQUALS, _4719, 58);
    }
    _4719 = NOVALUE;
    if (IS_ATOM_INT(_4720))
    _4718 = (_4720 != 0);
    else
    _4718 = DBL_PTR(_4720)->dbl != 0.0;
L7: 
    if (_4718 == 0)
    {
        _4718 = NOVALUE;
        goto L8; // [140] 153
    }
    else{
        _4718 = NOVALUE;
    }
L6: 

    /** filesys.e:2051				return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_8761);
    DeRef(_dirfil_8762);
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4720);
    _4720 = NOVALUE;
    DeRef(_4703);
    _4703 = NOVALUE;
    DeRef(_4710);
    _4710 = NOVALUE;
    return 2;
    goto L9; // [150] 170
L8: 

    /** filesys.e:2053				return FILETYPE_FILE*/
    DeRefDS(_filename_8761);
    DeRef(_dirfil_8762);
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4720);
    _4720 = NOVALUE;
    DeRef(_4703);
    _4703 = NOVALUE;
    DeRef(_4710);
    _4710 = NOVALUE;
    return 1;
    goto L9; // [160] 170
L4: 

    /** filesys.e:2056			return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_8761);
    DeRef(_dirfil_8762);
    DeRef(_4717);
    _4717 = NOVALUE;
    DeRef(_4720);
    _4720 = NOVALUE;
    DeRef(_4703);
    _4703 = NOVALUE;
    DeRef(_4710);
    _4710 = NOVALUE;
    return 0;
L9: 
    ;
}


object _15file_exists(object _name_8809)
{
    object _pName_8812 = NOVALUE;
    object _r_8815 = NOVALUE;
    object _4725 = NOVALUE;
    object _4723 = NOVALUE;
    object _4721 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2103		if atom(name) then*/
    _4721 = IS_ATOM(_name_8809);
    if (_4721 == 0)
    {
        _4721 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _4721 = NOVALUE;
    }

    /** filesys.e:2104			return 0*/
    DeRef(_name_8809);
    DeRef(_pName_8812);
    DeRef(_r_8815);
    return 0;
L1: 

    /** filesys.e:2107		ifdef WINDOWS then*/

    /** filesys.e:2108			atom pName = allocate_string(name)*/
    Ref(_name_8809);
    _0 = _pName_8812;
    _pName_8812 = _6allocate_string(_name_8809, 0);
    DeRef(_0);

    /** filesys.e:2109			atom r = c_func(xGetFileAttributes, {pName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pName_8812);
    ((intptr_t*)_2)[1] = _pName_8812;
    _4723 = MAKE_SEQ(_1);
    DeRef(_r_8815);
    _r_8815 = call_c(1, _15xGetFileAttributes_7808, _4723);
    DeRefDS(_4723);
    _4723 = NOVALUE;

    /** filesys.e:2110			free(pName)*/
    Ref(_pName_8812);
    _6free(_pName_8812);

    /** filesys.e:2112			return r > 0*/
    if (IS_ATOM_INT(_r_8815)) {
        _4725 = (_r_8815 > 0);
    }
    else {
        _4725 = (DBL_PTR(_r_8815)->dbl > (eudouble)0);
    }
    DeRef(_name_8809);
    DeRef(_pName_8812);
    DeRef(_r_8815);
    return _4725;
    ;
}


object _15file_timestamp(object _fname_8822)
{
    object _d_8823 = NOVALUE;
    object _dir_inlined_dir_at_4_8825 = NOVALUE;
    object _4739 = NOVALUE;
    object _4738 = NOVALUE;
    object _4737 = NOVALUE;
    object _4736 = NOVALUE;
    object _4735 = NOVALUE;
    object _4734 = NOVALUE;
    object _4733 = NOVALUE;
    object _4732 = NOVALUE;
    object _4731 = NOVALUE;
    object _4730 = NOVALUE;
    object _4729 = NOVALUE;
    object _4728 = NOVALUE;
    object _4727 = NOVALUE;
    object _4726 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2139		object d = dir(fname)*/

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    DeRef(_d_8823);
    _d_8823 = machine(22, _fname_8822);

    /** filesys.e:2140		if atom(d) then return -1 end if*/
    _4726 = IS_ATOM(_d_8823);
    if (_4726 == 0)
    {
        _4726 = NOVALUE;
        goto L1; // [19] 27
    }
    else{
        _4726 = NOVALUE;
    }
    DeRefDS(_fname_8822);
    DeRef(_d_8823);
    return -1;
L1: 

    /** filesys.e:2142		return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (object)SEQ_PTR(_d_8823);
    _4727 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4727);
    _4728 = (object)*(((s1_ptr)_2)->base + 4);
    _4727 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_8823);
    _4729 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4729);
    _4730 = (object)*(((s1_ptr)_2)->base + 5);
    _4729 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_8823);
    _4731 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4731);
    _4732 = (object)*(((s1_ptr)_2)->base + 6);
    _4731 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_8823);
    _4733 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4733);
    _4734 = (object)*(((s1_ptr)_2)->base + 7);
    _4733 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_8823);
    _4735 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4735);
    _4736 = (object)*(((s1_ptr)_2)->base + 8);
    _4735 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_8823);
    _4737 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_4737);
    _4738 = (object)*(((s1_ptr)_2)->base + 9);
    _4737 = NOVALUE;
    Ref(_4728);
    Ref(_4730);
    Ref(_4732);
    Ref(_4734);
    Ref(_4736);
    Ref(_4738);
    _4739 = _16new(_4728, _4730, _4732, _4734, _4736, _4738);
    _4728 = NOVALUE;
    _4730 = NOVALUE;
    _4732 = NOVALUE;
    _4734 = NOVALUE;
    _4736 = NOVALUE;
    _4738 = NOVALUE;
    DeRefDS(_fname_8822);
    DeRef(_d_8823);
    return _4739;
    ;
}


object _15locate_file(object _filename_8954, object _search_list_8955, object _subdir_8956)
{
    object _extra_paths_8957 = NOVALUE;
    object _this_path_8958 = NOVALUE;
    object _4874 = NOVALUE;
    object _4873 = NOVALUE;
    object _4871 = NOVALUE;
    object _4869 = NOVALUE;
    object _4867 = NOVALUE;
    object _4866 = NOVALUE;
    object _4865 = NOVALUE;
    object _4863 = NOVALUE;
    object _4862 = NOVALUE;
    object _4861 = NOVALUE;
    object _4859 = NOVALUE;
    object _4858 = NOVALUE;
    object _4857 = NOVALUE;
    object _4854 = NOVALUE;
    object _4853 = NOVALUE;
    object _4851 = NOVALUE;
    object _4849 = NOVALUE;
    object _4848 = NOVALUE;
    object _4845 = NOVALUE;
    object _4840 = NOVALUE;
    object _4836 = NOVALUE;
    object _4830 = NOVALUE;
    object _4827 = NOVALUE;
    object _4824 = NOVALUE;
    object _4823 = NOVALUE;
    object _4819 = NOVALUE;
    object _4816 = NOVALUE;
    object _4814 = NOVALUE;
    object _4810 = NOVALUE;
    object _4808 = NOVALUE;
    object _4807 = NOVALUE;
    object _4805 = NOVALUE;
    object _4804 = NOVALUE;
    object _4801 = NOVALUE;
    object _4800 = NOVALUE;
    object _4797 = NOVALUE;
    object _4795 = NOVALUE;
    object _4794 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2525		if absolute_path(filename) then*/
    RefDS(_filename_8954);
    _4794 = _15absolute_path(_filename_8954);
    if (_4794 == 0) {
        DeRef(_4794);
        _4794 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_4794) && DBL_PTR(_4794)->dbl == 0.0){
            DeRef(_4794);
            _4794 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_4794);
        _4794 = NOVALUE;
    }
    DeRef(_4794);
    _4794 = NOVALUE;

    /** filesys.e:2526			return filename*/
    DeRefDS(_search_list_8955);
    DeRefDS(_subdir_8956);
    DeRef(_extra_paths_8957);
    DeRef(_this_path_8958);
    return _filename_8954;
L1: 

    /** filesys.e:2529		if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_8955)){
            _4795 = SEQ_PTR(_search_list_8955)->length;
    }
    else {
        _4795 = 1;
    }
    if (_4795 != 0)
    goto L2; // [28] 276

    /** filesys.e:2530			search_list = append(search_list, "." & SLASH)*/
    Append(&_4797, _4157, 92);
    RefDS(_4797);
    Append(&_search_list_8955, _search_list_8955, _4797);
    DeRefDS(_4797);
    _4797 = NOVALUE;

    /** filesys.e:2532			extra_paths = command_line()*/
    DeRef(_extra_paths_8957);
    _extra_paths_8957 = Command_Line();

    /** filesys.e:2533			extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (object)SEQ_PTR(_extra_paths_8957);
    _4800 = (object)*(((s1_ptr)_2)->base + 2);
    RefDS(_4800);
    _4801 = _15dirname(_4800, 0);
    _4800 = NOVALUE;
    _0 = _extra_paths_8957;
    _extra_paths_8957 = _15canonical_path(_4801, 1, 0);
    DeRefDS(_0);
    _4801 = NOVALUE;

    /** filesys.e:2534			search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_8957);
    Append(&_search_list_8955, _search_list_8955, _extra_paths_8957);

    /** filesys.e:2536			ifdef UNIX then*/

    /** filesys.e:2540				extra_paths = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _4804 = EGetEnv(_4442);
    _4805 = EGetEnv(_4444);
    if (IS_SEQUENCE(_4804) && IS_ATOM(_4805)) {
        Ref(_4805);
        Append(&_extra_paths_8957, _4804, _4805);
    }
    else if (IS_ATOM(_4804) && IS_SEQUENCE(_4805)) {
        Ref(_4804);
        Prepend(&_extra_paths_8957, _4805, _4804);
    }
    else {
        Concat((object_ptr)&_extra_paths_8957, _4804, _4805);
        DeRef(_4804);
        _4804 = NOVALUE;
    }
    DeRef(_4804);
    _4804 = NOVALUE;
    DeRef(_4805);
    _4805 = NOVALUE;

    /** filesys.e:2543			if sequence(extra_paths) then*/
    _4807 = 1;
    if (_4807 == 0)
    {
        _4807 = NOVALUE;
        goto L3; // [88] 102
    }
    else{
        _4807 = NOVALUE;
    }

    /** filesys.e:2544				search_list = append(search_list, extra_paths & SLASH)*/
    Append(&_4808, _extra_paths_8957, 92);
    RefDS(_4808);
    Append(&_search_list_8955, _search_list_8955, _4808);
    DeRefDS(_4808);
    _4808 = NOVALUE;
L3: 

    /** filesys.e:2547			search_list = append(search_list, ".." & SLASH)*/
    Append(&_4810, _4188, 92);
    RefDS(_4810);
    Append(&_search_list_8955, _search_list_8955, _4810);
    DeRefDS(_4810);
    _4810 = NOVALUE;

    /** filesys.e:2549			extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_8957);
    _extra_paths_8957 = EGetEnv(_4812);

    /** filesys.e:2550			if sequence(extra_paths) then*/
    _4814 = IS_SEQUENCE(_extra_paths_8957);
    if (_4814 == 0)
    {
        _4814 = NOVALUE;
        goto L4; // [122] 152
    }
    else{
        _4814 = NOVALUE;
    }

    /** filesys.e:2551				search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4815;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8957;
        Concat_N((object_ptr)&_4816, concat_list, 4);
    }
    RefDS(_4816);
    Append(&_search_list_8955, _search_list_8955, _4816);
    DeRefDS(_4816);
    _4816 = NOVALUE;

    /** filesys.e:2552				search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4818;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8957;
        Concat_N((object_ptr)&_4819, concat_list, 4);
    }
    RefDS(_4819);
    Append(&_search_list_8955, _search_list_8955, _4819);
    DeRefDS(_4819);
    _4819 = NOVALUE;
L4: 

    /** filesys.e:2555			extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_8957);
    _extra_paths_8957 = EGetEnv(_4821);

    /** filesys.e:2556			if sequence(extra_paths) then*/
    _4823 = IS_SEQUENCE(_extra_paths_8957);
    if (_4823 == 0)
    {
        _4823 = NOVALUE;
        goto L5; // [162] 202
    }
    else{
        _4823 = NOVALUE;
    }

    /** filesys.e:2557				search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_8957) && IS_ATOM(92)) {
        Append(&_4824, _extra_paths_8957, 92);
    }
    else if (IS_ATOM(_extra_paths_8957) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_4824, _extra_paths_8957, 92);
    }
    RefDS(_4824);
    Append(&_search_list_8955, _search_list_8955, _4824);
    DeRefDS(_4824);
    _4824 = NOVALUE;

    /** filesys.e:2558				search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4826;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8957;
        Concat_N((object_ptr)&_4827, concat_list, 4);
    }
    RefDS(_4827);
    Append(&_search_list_8955, _search_list_8955, _4827);
    DeRefDS(_4827);
    _4827 = NOVALUE;

    /** filesys.e:2559				search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92;
        concat_list[1] = _4829;
        concat_list[2] = 92;
        concat_list[3] = _extra_paths_8957;
        Concat_N((object_ptr)&_4830, concat_list, 4);
    }
    RefDS(_4830);
    Append(&_search_list_8955, _search_list_8955, _4830);
    DeRefDS(_4830);
    _4830 = NOVALUE;
L5: 

    /** filesys.e:2562			ifdef UNIX then*/

    /** filesys.e:2568			search_list &= include_paths(1)*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_4835);
    ((intptr_t*)_2)[1] = _4835;
    RefDS(_4834);
    ((intptr_t*)_2)[2] = _4834;
    _4836 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_8955, _search_list_8955, _4836);
    DeRefDS(_4836);
    _4836 = NOVALUE;

    /** filesys.e:2571			extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_8957);
    _extra_paths_8957 = EGetEnv(_4838);

    /** filesys.e:2572			if sequence(extra_paths) then*/
    _4840 = IS_SEQUENCE(_extra_paths_8957);
    if (_4840 == 0)
    {
        _4840 = NOVALUE;
        goto L6; // [225] 244
    }
    else{
        _4840 = NOVALUE;
    }

    /** filesys.e:2573				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8957);
    _0 = _extra_paths_8957;
    _extra_paths_8957 = _24split(_extra_paths_8957, 59, 0, 0);
    DeRefi(_0);

    /** filesys.e:2574				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8955) && IS_ATOM(_extra_paths_8957)) {
        Ref(_extra_paths_8957);
        Append(&_search_list_8955, _search_list_8955, _extra_paths_8957);
    }
    else if (IS_ATOM(_search_list_8955) && IS_SEQUENCE(_extra_paths_8957)) {
    }
    else {
        Concat((object_ptr)&_search_list_8955, _search_list_8955, _extra_paths_8957);
    }
L6: 

    /** filesys.e:2577			extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_8957);
    _extra_paths_8957 = EGetEnv(_4843);

    /** filesys.e:2578			if sequence(extra_paths) then*/
    _4845 = IS_SEQUENCE(_extra_paths_8957);
    if (_4845 == 0)
    {
        _4845 = NOVALUE;
        goto L7; // [254] 301
    }
    else{
        _4845 = NOVALUE;
    }

    /** filesys.e:2579				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8957);
    _0 = _extra_paths_8957;
    _extra_paths_8957 = _24split(_extra_paths_8957, 59, 0, 0);
    DeRefi(_0);

    /** filesys.e:2580				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8955) && IS_ATOM(_extra_paths_8957)) {
        Ref(_extra_paths_8957);
        Append(&_search_list_8955, _search_list_8955, _extra_paths_8957);
    }
    else if (IS_ATOM(_search_list_8955) && IS_SEQUENCE(_extra_paths_8957)) {
    }
    else {
        Concat((object_ptr)&_search_list_8955, _search_list_8955, _extra_paths_8957);
    }
    goto L7; // [273] 301
L2: 

    /** filesys.e:2583			if integer(search_list[1]) then*/
    _2 = (object)SEQ_PTR(_search_list_8955);
    _4848 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4848))
    _4849 = 1;
    else if (IS_ATOM_DBL(_4848))
    _4849 = IS_ATOM_INT(DoubleToInt(_4848));
    else
    _4849 = 0;
    _4848 = NOVALUE;
    if (_4849 == 0)
    {
        _4849 = NOVALUE;
        goto L8; // [285] 300
    }
    else{
        _4849 = NOVALUE;
    }

    /** filesys.e:2584				search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_8955);
    _0 = _search_list_8955;
    _search_list_8955 = _24split(_search_list_8955, 59, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** filesys.e:2588		if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_8956)){
            _4851 = SEQ_PTR(_subdir_8956)->length;
    }
    else {
        _4851 = 1;
    }
    if (_4851 <= 0)
    goto L9; // [306] 331

    /** filesys.e:2589			if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_8956)){
            _4853 = SEQ_PTR(_subdir_8956)->length;
    }
    else {
        _4853 = 1;
    }
    _2 = (object)SEQ_PTR(_subdir_8956);
    _4854 = (object)*(((s1_ptr)_2)->base + _4853);
    if (binary_op_a(EQUALS, _4854, 92)){
        _4854 = NOVALUE;
        goto LA; // [319] 330
    }
    _4854 = NOVALUE;

    /** filesys.e:2590				subdir &= SLASH*/
    Append(&_subdir_8956, _subdir_8956, 92);
LA: 
L9: 

    /** filesys.e:2594		for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_8955)){
            _4857 = SEQ_PTR(_search_list_8955)->length;
    }
    else {
        _4857 = 1;
    }
    {
        object _i_9034;
        _i_9034 = 1;
LB: 
        if (_i_9034 > _4857){
            goto LC; // [336] 459
        }

        /** filesys.e:2595			if length(search_list[i]) = 0 then*/
        _2 = (object)SEQ_PTR(_search_list_8955);
        _4858 = (object)*(((s1_ptr)_2)->base + _i_9034);
        if (IS_SEQUENCE(_4858)){
                _4859 = SEQ_PTR(_4858)->length;
        }
        else {
            _4859 = 1;
        }
        _4858 = NOVALUE;
        if (_4859 != 0)
        goto LD; // [352] 361

        /** filesys.e:2596				continue*/
        goto LE; // [358] 454
LD: 

        /** filesys.e:2599			if search_list[i][$] != SLASH then*/
        _2 = (object)SEQ_PTR(_search_list_8955);
        _4861 = (object)*(((s1_ptr)_2)->base + _i_9034);
        if (IS_SEQUENCE(_4861)){
                _4862 = SEQ_PTR(_4861)->length;
        }
        else {
            _4862 = 1;
        }
        _2 = (object)SEQ_PTR(_4861);
        _4863 = (object)*(((s1_ptr)_2)->base + _4862);
        _4861 = NOVALUE;
        if (binary_op_a(EQUALS, _4863, 92)){
            _4863 = NOVALUE;
            goto LF; // [374] 393
        }
        _4863 = NOVALUE;

        /** filesys.e:2600				search_list[i] &= SLASH*/
        _2 = (object)SEQ_PTR(_search_list_8955);
        _4865 = (object)*(((s1_ptr)_2)->base + _i_9034);
        if (IS_SEQUENCE(_4865) && IS_ATOM(92)) {
            Append(&_4866, _4865, 92);
        }
        else if (IS_ATOM(_4865) && IS_SEQUENCE(92)) {
        }
        else {
            Concat((object_ptr)&_4866, _4865, 92);
            _4865 = NOVALUE;
        }
        _4865 = NOVALUE;
        _2 = (object)SEQ_PTR(_search_list_8955);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _search_list_8955 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_9034);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _4866;
        if( _1 != _4866 ){
            DeRef(_1);
        }
        _4866 = NOVALUE;
LF: 

        /** filesys.e:2604			if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_8956)){
                _4867 = SEQ_PTR(_subdir_8956)->length;
        }
        else {
            _4867 = 1;
        }
        if (_4867 <= 0)
        goto L10; // [398] 417

        /** filesys.e:2605				this_path = search_list[i] & subdir & filename*/
        _2 = (object)SEQ_PTR(_search_list_8955);
        _4869 = (object)*(((s1_ptr)_2)->base + _i_9034);
        {
            object concat_list[3];

            concat_list[0] = _filename_8954;
            concat_list[1] = _subdir_8956;
            concat_list[2] = _4869;
            Concat_N((object_ptr)&_this_path_8958, concat_list, 3);
        }
        _4869 = NOVALUE;
        goto L11; // [414] 428
L10: 

        /** filesys.e:2607				this_path = search_list[i] & filename*/
        _2 = (object)SEQ_PTR(_search_list_8955);
        _4871 = (object)*(((s1_ptr)_2)->base + _i_9034);
        if (IS_SEQUENCE(_4871) && IS_ATOM(_filename_8954)) {
        }
        else if (IS_ATOM(_4871) && IS_SEQUENCE(_filename_8954)) {
            Ref(_4871);
            Prepend(&_this_path_8958, _filename_8954, _4871);
        }
        else {
            Concat((object_ptr)&_this_path_8958, _4871, _filename_8954);
            _4871 = NOVALUE;
        }
        _4871 = NOVALUE;
L11: 

        /** filesys.e:2610			if file_exists(this_path) then*/
        RefDS(_this_path_8958);
        _4873 = _15file_exists(_this_path_8958);
        if (_4873 == 0) {
            DeRef(_4873);
            _4873 = NOVALUE;
            goto L12; // [436] 452
        }
        else {
            if (!IS_ATOM_INT(_4873) && DBL_PTR(_4873)->dbl == 0.0){
                DeRef(_4873);
                _4873 = NOVALUE;
                goto L12; // [436] 452
            }
            DeRef(_4873);
            _4873 = NOVALUE;
        }
        DeRef(_4873);
        _4873 = NOVALUE;

        /** filesys.e:2611				return canonical_path(this_path)*/
        RefDS(_this_path_8958);
        _4874 = _15canonical_path(_this_path_8958, 0, 0);
        DeRefDS(_filename_8954);
        DeRefDS(_search_list_8955);
        DeRefDS(_subdir_8956);
        DeRef(_extra_paths_8957);
        DeRefDS(_this_path_8958);
        _4858 = NOVALUE;
        return _4874;
L12: 

        /** filesys.e:2614		end for*/
LE: 
        _i_9034 = _i_9034 + 1;
        goto LB; // [454] 343
LC: 
        ;
    }

    /** filesys.e:2615		return filename*/
    DeRefDS(_search_list_8955);
    DeRefDS(_subdir_8956);
    DeRef(_extra_paths_8957);
    DeRef(_this_path_8958);
    _4858 = NOVALUE;
    DeRef(_4874);
    _4874 = NOVALUE;
    return _filename_8954;
    ;
}


object _15count_files(object _orig_path_9111, object _dir_info_9112, object _inst_9113)
{
    object _pos_9114 = NOVALUE;
    object _ext_9115 = NOVALUE;
    object _fileext_inlined_fileext_at_223_9158 = NOVALUE;
    object _data_inlined_fileext_at_223_9157 = NOVALUE;
    object _path_inlined_fileext_at_220_9156 = NOVALUE;
    object _4970 = NOVALUE;
    object _4969 = NOVALUE;
    object _4968 = NOVALUE;
    object _4966 = NOVALUE;
    object _4965 = NOVALUE;
    object _4964 = NOVALUE;
    object _4963 = NOVALUE;
    object _4961 = NOVALUE;
    object _4960 = NOVALUE;
    object _4958 = NOVALUE;
    object _4957 = NOVALUE;
    object _4956 = NOVALUE;
    object _4955 = NOVALUE;
    object _4954 = NOVALUE;
    object _4953 = NOVALUE;
    object _4952 = NOVALUE;
    object _4950 = NOVALUE;
    object _4949 = NOVALUE;
    object _4947 = NOVALUE;
    object _4946 = NOVALUE;
    object _4945 = NOVALUE;
    object _4944 = NOVALUE;
    object _4943 = NOVALUE;
    object _4942 = NOVALUE;
    object _4941 = NOVALUE;
    object _4940 = NOVALUE;
    object _4939 = NOVALUE;
    object _4938 = NOVALUE;
    object _4937 = NOVALUE;
    object _4936 = NOVALUE;
    object _4935 = NOVALUE;
    object _4934 = NOVALUE;
    object _4932 = NOVALUE;
    object _4931 = NOVALUE;
    object _4930 = NOVALUE;
    object _4929 = NOVALUE;
    object _4927 = NOVALUE;
    object _4926 = NOVALUE;
    object _4925 = NOVALUE;
    object _4924 = NOVALUE;
    object _4923 = NOVALUE;
    object _4922 = NOVALUE;
    object _4921 = NOVALUE;
    object _4919 = NOVALUE;
    object _4918 = NOVALUE;
    object _4917 = NOVALUE;
    object _4916 = NOVALUE;
    object _4915 = NOVALUE;
    object _4914 = NOVALUE;
    object _4911 = NOVALUE;
    object _4910 = NOVALUE;
    object _4909 = NOVALUE;
    object _4908 = NOVALUE;
    object _4907 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** filesys.e:2777		integer pos = 0*/
    _pos_9114 = 0;

    /** filesys.e:2780		orig_path = orig_path*/
    RefDS(_orig_path_9111);
    DeRefDS(_orig_path_9111);
    _orig_path_9111 = _orig_path_9111;

    /** filesys.e:2781		if equal(dir_info[D_NAME], ".") then*/
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4907 = (object)*(((s1_ptr)_2)->base + 1);
    if (_4907 == _4157)
    _4908 = 1;
    else if (IS_ATOM_INT(_4907) && IS_ATOM_INT(_4157))
    _4908 = 0;
    else
    _4908 = (compare(_4907, _4157) == 0);
    _4907 = NOVALUE;
    if (_4908 == 0)
    {
        _4908 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _4908 = NOVALUE;
    }

    /** filesys.e:2782			return 0*/
    DeRefDS(_orig_path_9111);
    DeRefDS(_dir_info_9112);
    DeRefDS(_inst_9113);
    DeRef(_ext_9115);
    return 0;
L1: 

    /** filesys.e:2784		if equal(dir_info[D_NAME], "..") then*/
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4909 = (object)*(((s1_ptr)_2)->base + 1);
    if (_4909 == _4188)
    _4910 = 1;
    else if (IS_ATOM_INT(_4909) && IS_ATOM_INT(_4188))
    _4910 = 0;
    else
    _4910 = (compare(_4909, _4188) == 0);
    _4909 = NOVALUE;
    if (_4910 == 0)
    {
        _4910 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _4910 = NOVALUE;
    }

    /** filesys.e:2785			return 0*/
    DeRefDS(_orig_path_9111);
    DeRefDS(_dir_info_9112);
    DeRefDS(_inst_9113);
    DeRef(_ext_9115);
    return 0;
L2: 

    /** filesys.e:2789		if inst[1] = 0 then -- count all is false*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4911 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _4911, 0)){
        _4911 = NOVALUE;
        goto L3; // [65] 112
    }
    _4911 = NOVALUE;

    /** filesys.e:2790			if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4914 = (object)*(((s1_ptr)_2)->base + 2);
    _4915 = find_from(104, _4914, 1);
    _4914 = NOVALUE;
    if (_4915 == 0)
    {
        _4915 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _4915 = NOVALUE;
    }

    /** filesys.e:2791				return 0*/
    DeRefDS(_orig_path_9111);
    DeRefDS(_dir_info_9112);
    DeRefDS(_inst_9113);
    DeRef(_ext_9115);
    return 0;
L4: 

    /** filesys.e:2794			if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4916 = (object)*(((s1_ptr)_2)->base + 2);
    _4917 = find_from(115, _4916, 1);
    _4916 = NOVALUE;
    if (_4917 == 0)
    {
        _4917 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _4917 = NOVALUE;
    }

    /** filesys.e:2795				return 0*/
    DeRefDS(_orig_path_9111);
    DeRefDS(_dir_info_9112);
    DeRefDS(_inst_9113);
    DeRef(_ext_9115);
    return 0;
L5: 
L3: 

    /** filesys.e:2799		file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4918 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _15file_counters_9108 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4918))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4918)->dbl));
    else
    _3 = (object)(_4918 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4921 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _4922 = (object)*(((s1_ptr)_2)->base + 3);
    _4919 = NOVALUE;
    if (IS_ATOM_INT(_4922) && IS_ATOM_INT(_4921)) {
        _4923 = _4922 + _4921;
        if ((object)((uintptr_t)_4923 + (uintptr_t)HIGH_BITS) >= 0){
            _4923 = NewDouble((eudouble)_4923);
        }
    }
    else {
        _4923 = binary_op(PLUS, _4922, _4921);
    }
    _4922 = NOVALUE;
    _4921 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4923;
    if( _1 != _4923 ){
        DeRef(_1);
    }
    _4923 = NOVALUE;
    _4919 = NOVALUE;

    /** filesys.e:2800		if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4924 = (object)*(((s1_ptr)_2)->base + 2);
    _4925 = find_from(100, _4924, 1);
    _4924 = NOVALUE;
    if (_4925 == 0)
    {
        _4925 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _4925 = NOVALUE;
    }

    /** filesys.e:2801			file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4926 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _15file_counters_9108 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4926))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4926)->dbl));
    else
    _3 = (object)(_4926 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _4929 = (object)*(((s1_ptr)_2)->base + 1);
    _4927 = NOVALUE;
    if (IS_ATOM_INT(_4929)) {
        _4930 = _4929 + 1;
        if (_4930 > MAXINT){
            _4930 = NewDouble((eudouble)_4930);
        }
    }
    else
    _4930 = binary_op(PLUS, 1, _4929);
    _4929 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4930;
    if( _1 != _4930 ){
        DeRef(_1);
    }
    _4930 = NOVALUE;
    _4927 = NOVALUE;
    goto L7; // [180] 464
L6: 

    /** filesys.e:2803			file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4931 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _15file_counters_9108 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4931))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4931)->dbl));
    else
    _3 = (object)(_4931 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _4934 = (object)*(((s1_ptr)_2)->base + 2);
    _4932 = NOVALUE;
    if (IS_ATOM_INT(_4934)) {
        _4935 = _4934 + 1;
        if (_4935 > MAXINT){
            _4935 = NewDouble((eudouble)_4935);
        }
    }
    else
    _4935 = binary_op(PLUS, 1, _4934);
    _4934 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4935;
    if( _1 != _4935 ){
        DeRef(_1);
    }
    _4935 = NOVALUE;
    _4932 = NOVALUE;

    /** filesys.e:2804			ifdef not UNIX then*/

    /** filesys.e:2805				ext = fileext(lower(dir_info[D_NAME]))*/
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4936 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_4936);
    _4937 = _12lower(_4936);
    _4936 = NOVALUE;
    DeRef(_path_inlined_fileext_at_220_9156);
    _path_inlined_fileext_at_220_9156 = _4937;
    _4937 = NOVALUE;

    /** filesys.e:1403		data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_220_9156);
    _0 = _data_inlined_fileext_at_223_9157;
    _data_inlined_fileext_at_223_9157 = _15pathinfo(_path_inlined_fileext_at_220_9156, 0);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    DeRef(_ext_9115);
    _2 = (object)SEQ_PTR(_data_inlined_fileext_at_223_9157);
    _ext_9115 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_9115);
    DeRef(_path_inlined_fileext_at_220_9156);
    _path_inlined_fileext_at_220_9156 = NOVALUE;
    DeRef(_data_inlined_fileext_at_223_9157);
    _data_inlined_fileext_at_223_9157 = NOVALUE;

    /** filesys.e:2810			pos = 0*/
    _pos_9114 = 0;

    /** filesys.e:2811			for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4938 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!IS_ATOM_INT(_4938)){
        _4939 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_4938)->dbl));
    }
    else{
        _4939 = (object)*(((s1_ptr)_2)->base + _4938);
    }
    _2 = (object)SEQ_PTR(_4939);
    _4940 = (object)*(((s1_ptr)_2)->base + 4);
    _4939 = NOVALUE;
    if (IS_SEQUENCE(_4940)){
            _4941 = SEQ_PTR(_4940)->length;
    }
    else {
        _4941 = 1;
    }
    _4940 = NOVALUE;
    {
        object _i_9160;
        _i_9160 = 1;
L8: 
        if (_i_9160 > _4941){
            goto L9; // [269] 326
        }

        /** filesys.e:2812				if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (object)SEQ_PTR(_inst_9113);
        _4942 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_15file_counters_9108);
        if (!IS_ATOM_INT(_4942)){
            _4943 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_4942)->dbl));
        }
        else{
            _4943 = (object)*(((s1_ptr)_2)->base + _4942);
        }
        _2 = (object)SEQ_PTR(_4943);
        _4944 = (object)*(((s1_ptr)_2)->base + 4);
        _4943 = NOVALUE;
        _2 = (object)SEQ_PTR(_4944);
        _4945 = (object)*(((s1_ptr)_2)->base + _i_9160);
        _4944 = NOVALUE;
        _2 = (object)SEQ_PTR(_4945);
        _4946 = (object)*(((s1_ptr)_2)->base + 1);
        _4945 = NOVALUE;
        if (_4946 == _ext_9115)
        _4947 = 1;
        else if (IS_ATOM_INT(_4946) && IS_ATOM_INT(_ext_9115))
        _4947 = 0;
        else
        _4947 = (compare(_4946, _ext_9115) == 0);
        _4946 = NOVALUE;
        if (_4947 == 0)
        {
            _4947 = NOVALUE;
            goto LA; // [306] 319
        }
        else{
            _4947 = NOVALUE;
        }

        /** filesys.e:2813					pos = i*/
        _pos_9114 = _i_9160;

        /** filesys.e:2814					exit*/
        goto L9; // [316] 326
LA: 

        /** filesys.e:2816			end for*/
        _i_9160 = _i_9160 + 1;
        goto L8; // [321] 276
L9: 
        ;
    }

    /** filesys.e:2818			if pos = 0 then*/
    if (_pos_9114 != 0)
    goto LB; // [328] 389

    /** filesys.e:2819				file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4949 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _15file_counters_9108 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4949))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4949)->dbl));
    else
    _3 = (object)(_4949 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_ext_9115);
    ((intptr_t*)_2)[1] = _ext_9115;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    _4952 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _4952;
    _4953 = MAKE_SEQ(_1);
    _4952 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _4954 = (object)*(((s1_ptr)_2)->base + 4);
    _4950 = NOVALUE;
    if (IS_SEQUENCE(_4954) && IS_ATOM(_4953)) {
    }
    else if (IS_ATOM(_4954) && IS_SEQUENCE(_4953)) {
        Ref(_4954);
        Prepend(&_4955, _4953, _4954);
    }
    else {
        Concat((object_ptr)&_4955, _4954, _4953);
        _4954 = NOVALUE;
    }
    _4954 = NOVALUE;
    DeRefDS(_4953);
    _4953 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4955;
    if( _1 != _4955 ){
        DeRef(_1);
    }
    _4955 = NOVALUE;
    _4950 = NOVALUE;

    /** filesys.e:2820				pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4956 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!IS_ATOM_INT(_4956)){
        _4957 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_4956)->dbl));
    }
    else{
        _4957 = (object)*(((s1_ptr)_2)->base + _4956);
    }
    _2 = (object)SEQ_PTR(_4957);
    _4958 = (object)*(((s1_ptr)_2)->base + 4);
    _4957 = NOVALUE;
    if (IS_SEQUENCE(_4958)){
            _pos_9114 = SEQ_PTR(_4958)->length;
    }
    else {
        _pos_9114 = 1;
    }
    _4958 = NOVALUE;
LB: 

    /** filesys.e:2823			file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4960 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _15file_counters_9108 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4960))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4960)->dbl));
    else
    _3 = (object)(_4960 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4 + ((s1_ptr)_2)->base);
    _4961 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_9114 + ((s1_ptr)_2)->base);
    _4961 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _4963 = (object)*(((s1_ptr)_2)->base + 2);
    _4961 = NOVALUE;
    if (IS_ATOM_INT(_4963)) {
        _4964 = _4963 + 1;
        if (_4964 > MAXINT){
            _4964 = NewDouble((eudouble)_4964);
        }
    }
    else
    _4964 = binary_op(PLUS, 1, _4963);
    _4963 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4964;
    if( _1 != _4964 ){
        DeRef(_1);
    }
    _4964 = NOVALUE;
    _4961 = NOVALUE;

    /** filesys.e:2824			file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_9113);
    _4965 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_15file_counters_9108);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _15file_counters_9108 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4965))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_4965)->dbl));
    else
    _3 = (object)(_4965 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4 + ((s1_ptr)_2)->base);
    _4966 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_9114 + ((s1_ptr)_2)->base);
    _4966 = NOVALUE;
    _2 = (object)SEQ_PTR(_dir_info_9112);
    _4968 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _4969 = (object)*(((s1_ptr)_2)->base + 3);
    _4966 = NOVALUE;
    if (IS_ATOM_INT(_4969) && IS_ATOM_INT(_4968)) {
        _4970 = _4969 + _4968;
        if ((object)((uintptr_t)_4970 + (uintptr_t)HIGH_BITS) >= 0){
            _4970 = NewDouble((eudouble)_4970);
        }
    }
    else {
        _4970 = binary_op(PLUS, _4969, _4968);
    }
    _4969 = NOVALUE;
    _4968 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _4970;
    if( _1 != _4970 ){
        DeRef(_1);
    }
    _4970 = NOVALUE;
    _4966 = NOVALUE;
L7: 

    /** filesys.e:2827		return 0*/
    DeRefDS(_orig_path_9111);
    DeRefDS(_dir_info_9112);
    DeRefDS(_inst_9113);
    DeRef(_ext_9115);
    _4965 = NOVALUE;
    _4940 = NOVALUE;
    _4958 = NOVALUE;
    _4918 = NOVALUE;
    _4938 = NOVALUE;
    _4960 = NOVALUE;
    _4926 = NOVALUE;
    _4956 = NOVALUE;
    _4931 = NOVALUE;
    _4949 = NOVALUE;
    _4942 = NOVALUE;
    return 0;
    ;
}



// 0x8619D445
