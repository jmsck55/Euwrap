// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _68intoptions()
{
    object _pause_msg_65099 = NOVALUE;
    object _opts_array_65110 = NOVALUE;
    object _opts_65115 = NOVALUE;
    object _opt_keys_65124 = NOVALUE;
    object _option_w_65126 = NOVALUE;
    object _key_65130 = NOVALUE;
    object _val_65132 = NOVALUE;
    object _32061 = NOVALUE;
    object _32059 = NOVALUE;
    object _32058 = NOVALUE;
    object _32057 = NOVALUE;
    object _32056 = NOVALUE;
    object _32055 = NOVALUE;
    object _32054 = NOVALUE;
    object _32053 = NOVALUE;
    object _32052 = NOVALUE;
    object _32051 = NOVALUE;
    object _32050 = NOVALUE;
    object _32045 = NOVALUE;
    object _32042 = NOVALUE;
    object _32040 = NOVALUE;
    object _0, _1, _2;
    

    /** intinit.e:43		sequence pause_msg = GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE, 0)*/
    RefDS(_22209);
    _0 = _pause_msg_65099;
    _pause_msg_65099 = _30GetMsgText(278, 0, _22209);
    DeRef(_0);

    /** intinit.e:45		Argv = expand_config_options(Argv)*/
    RefDS(_27Argv_20582);
    _0 = _47expand_config_options(_27Argv_20582);
    DeRefDS(_27Argv_20582);
    _27Argv_20582 = _0;

    /** intinit.e:46		Argc = length(Argv)*/
    if (IS_SEQUENCE(_27Argv_20582)){
            _27Argc_20581 = SEQ_PTR(_27Argv_20582)->length;
    }
    else {
        _27Argc_20581 = 1;
    }

    /** intinit.e:48		sequence opts_array = sort( get_options() )*/
    _32040 = _47get_options();
    _0 = _opts_array_65110;
    _opts_array_65110 = _25sort(_32040, 1);
    DeRef(_0);
    _32040 = NOVALUE;

    /** intinit.e:50		m:map opts = cmd_parse( opts_array, */
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 4;
    ((intptr_t*)_2)[3] = 8;
    RefDS(_pause_msg_65099);
    ((intptr_t*)_2)[4] = _pause_msg_65099;
    _32042 = MAKE_SEQ(_1);
    RefDS(_opts_array_65110);
    RefDS(_27Argv_20582);
    _0 = _opts_65115;
    _opts_65115 = _48cmd_parse(_opts_array_65110, _32042, _27Argv_20582);
    DeRef(_0);
    _32042 = NOVALUE;

    /** intinit.e:53		handle_common_options(opts)*/
    Ref(_opts_65115);
    _47handle_common_options(_opts_65115);

    /** intinit.e:55		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_65115);
    _0 = _opt_keys_65124;
    _opt_keys_65124 = _34keys(_opts_65115, 0);
    DeRef(_0);

    /** intinit.e:56		integer option_w = 0*/
    _option_w_65126 = 0;

    /** intinit.e:58		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_65124)){
            _32045 = SEQ_PTR(_opt_keys_65124)->length;
    }
    else {
        _32045 = 1;
    }
    {
        object _idx_65128;
        _idx_65128 = 1;
L1: 
        if (_idx_65128 > _32045){
            goto L2; // [91] 206
        }

        /** intinit.e:59			sequence key = opt_keys[idx]*/
        DeRef(_key_65130);
        _2 = (object)SEQ_PTR(_opt_keys_65124);
        _key_65130 = (object)*(((s1_ptr)_2)->base + _idx_65128);
        Ref(_key_65130);

        /** intinit.e:60			object val = map:get(opts, key)*/
        Ref(_opts_65115);
        RefDS(_key_65130);
        _0 = _val_65132;
        _val_65132 = _34get(_opts_65115, _key_65130, 0);
        DeRef(_0);

        /** intinit.e:62			switch key do*/
        _1 = find(_key_65130, _32048);
        switch ( _1 ){ 

            /** intinit.e:63				case "coverage" then*/
            case 1:

            /** intinit.e:64					for i = 1 to length( val ) do*/
            if (IS_SEQUENCE(_val_65132)){
                    _32050 = SEQ_PTR(_val_65132)->length;
            }
            else {
                _32050 = 1;
            }
            {
                object _i_65138;
                _i_65138 = 1;
L3: 
                if (_i_65138 > _32050){
                    goto L4; // [130] 153
                }

                /** intinit.e:65						add_coverage( val[i] )*/
                _2 = (object)SEQ_PTR(_val_65132);
                _32051 = (object)*(((s1_ptr)_2)->base + _i_65138);
                Ref(_32051);
                _50add_coverage(_32051);
                _32051 = NOVALUE;

                /** intinit.e:66					end for*/
                _i_65138 = _i_65138 + 1;
                goto L3; // [148] 137
L4: 
                ;
            }
            goto L5; // [153] 197

            /** intinit.e:68				case "coverage-db" then*/
            case 2:

            /** intinit.e:69					coverage_db( val )*/
            Ref(_val_65132);
            _50coverage_db(_val_65132);
            goto L5; // [164] 197

            /** intinit.e:71				case "coverage-erase" then*/
            case 3:

            /** intinit.e:72					new_coverage_db()*/
            _50new_coverage_db();
            goto L5; // [174] 197

            /** intinit.e:74				case "coverage-exclude" then*/
            case 4:

            /** intinit.e:75					coverage_exclude( val )*/
            Ref(_val_65132);
            _50coverage_exclude(_val_65132);
            goto L5; // [185] 197

            /** intinit.e:77				case "debugger" then*/
            case 5:

            /** intinit.e:78					external_debugger = val*/
            Ref(_val_65132);
            DeRef(_68external_debugger_65096);
            _68external_debugger_65096 = _val_65132;
        ;}L5: 
        DeRef(_key_65130);
        _key_65130 = NOVALUE;
        DeRef(_val_65132);
        _val_65132 = NOVALUE;

        /** intinit.e:81		end for*/
        _idx_65128 = _idx_65128 + 1;
        goto L1; // [201] 98
L2: 
        ;
    }

    /** intinit.e:83		if length(m:get(opts, cmdline:EXTRAS)) = 0 and not repl then*/
    Ref(_opts_65115);
    RefDS(_48EXTRAS_20984);
    _32052 = _34get(_opts_65115, _48EXTRAS_20984, 0);
    if (IS_SEQUENCE(_32052)){
            _32053 = SEQ_PTR(_32052)->length;
    }
    else {
        _32053 = 1;
    }
    DeRef(_32052);
    _32052 = NOVALUE;
    _32054 = (_32053 == 0);
    _32053 = NOVALUE;
    if (_32054 == 0) {
        goto L6; // [223] 282
    }
    _32056 = (0 == 0);
    if (_32056 == 0)
    {
        DeRef(_32056);
        _32056 = NOVALUE;
        goto L6; // [233] 282
    }
    else{
        DeRef(_32056);
        _32056 = NOVALUE;
    }

    /** intinit.e:84			show_banner()*/
    _47show_banner();

    /** intinit.e:85			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_INTERPRETED_ON_THE_COMMAND_LINE)*/
    RefDS(_22209);
    _30ShowMsg(2, 249, _22209, 1);

    /** intinit.e:87			if not batch_job and not test_only then*/
    _32057 = (_27batch_job_20584 == 0);
    if (_32057 == 0) {
        goto L7; // [257] 277
    }
    _32059 = (_27test_only_20583 == 0);
    if (_32059 == 0)
    {
        DeRef(_32059);
        _32059 = NOVALUE;
        goto L7; // [267] 277
    }
    else{
        DeRef(_32059);
        _32059 = NOVALUE;
    }

    /** intinit.e:88				maybe_any_key(pause_msg)*/
    RefDS(_pause_msg_65099);
    _38maybe_any_key(_pause_msg_65099, 1);
L7: 

    /** intinit.e:91			abort(1)*/
    UserCleanup(1);
L6: 

    /** intinit.e:94		OpDefines &= { "EUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_32060);
    ((intptr_t*)_2)[1] = _32060;
    _32061 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _32061);
    DeRefDS(_32061);
    _32061 = NOVALUE;

    /** intinit.e:96		finalize_command_line(opts)*/
    Ref(_opts_65115);
    _47finalize_command_line(_opts_65115);

    /** intinit.e:97	end procedure*/
    DeRef(_pause_msg_65099);
    DeRef(_opts_array_65110);
    DeRef(_opts_65115);
    DeRef(_opt_keys_65124);
    _32052 = NOVALUE;
    DeRef(_32057);
    _32057 = NOVALUE;
    DeRef(_32054);
    _32054 = NOVALUE;
    return;
    ;
}



// 0x353C2081
