// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _61set_qualified_fwd(object _fwd_25960)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_25960)) {
        _1 = (object)(DBL_PTR(_fwd_25960)->dbl);
        DeRefDS(_fwd_25960);
        _fwd_25960 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25957 = _fwd_25960;

    /** scanner.e:105	end procedure*/
    return;
    ;
}


object _61get_qualified_fwd()
{
    object _fwd_25963 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:108		integer fwd = qualified_fwd*/
    _fwd_25963 = _61qualified_fwd_25957;

    /** scanner.e:109		set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25957 = -1;

    /** scanner.e:105	end procedure*/
    goto L1; // [17] 20
L1: 

    /** scanner.e:110		return fwd*/
    return _fwd_25963;
    ;
}


void _61InitLex()
{
    object _14468 = NOVALUE;
    object _14467 = NOVALUE;
    object _14466 = NOVALUE;
    object _14464 = NOVALUE;
    object _14463 = NOVALUE;
    object _14462 = NOVALUE;
    object _14461 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:117		gline_number = 0*/
    _27gline_number_20576 = 0;

    /** scanner.e:118		line_number = 0*/
    _27line_number_20572 = 0;

    /** scanner.e:119		IncludeStk = {}*/
    RefDS(_5);
    DeRef(_61IncludeStk_25934);
    _61IncludeStk_25934 = _5;

    /** scanner.e:120		char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_61char_class_25932);
    _61char_class_25932 = Repeat(-20, 255);

    /** scanner.e:122		char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_61char_class_25932;
    AssignSlice(48, 57, -7);

    /** scanner.e:123		char_class['_']      = DIGIT*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 95);
    *(intptr_t *)_2 = -7;

    /** scanner.e:124		char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_25932;
    AssignSlice(97, 122, -2);

    /** scanner.e:125		char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_25932;
    AssignSlice(65, 90, -2);

    /** scanner.e:126		char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _14461 = 129;
    _14462 = 152;
    assign_slice_seq = (s1_ptr *)&_61char_class_25932;
    AssignSlice(129, 152, -10);
    _14461 = NOVALUE;
    _14462 = NOVALUE;

    /** scanner.e:127		char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _14463 = 171;
    _14464 = 234;
    assign_slice_seq = (s1_ptr *)&_61char_class_25932;
    AssignSlice(171, 234, -9);
    _14463 = NOVALUE;
    _14464 = NOVALUE;

    /** scanner.e:129		char_class[' '] = BLANK*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 32);
    *(intptr_t *)_2 = -8;

    /** scanner.e:130		char_class['\t'] = BLANK*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 9);
    *(intptr_t *)_2 = -8;

    /** scanner.e:131		char_class['+'] = PLUS*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 43);
    *(intptr_t *)_2 = 11;

    /** scanner.e:132		char_class['-'] = MINUS*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 45);
    *(intptr_t *)_2 = 10;

    /** scanner.e:133		char_class['*'] = res:MULTIPLY*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 42);
    *(intptr_t *)_2 = 13;

    /** scanner.e:134		char_class['/'] = res:DIVIDE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 47);
    *(intptr_t *)_2 = 14;

    /** scanner.e:135		char_class['='] = EQUALS*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 61);
    *(intptr_t *)_2 = 3;

    /** scanner.e:136		char_class['<'] = LESS*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 60);
    *(intptr_t *)_2 = 1;

    /** scanner.e:137		char_class['>'] = GREATER*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 62);
    *(intptr_t *)_2 = 6;

    /** scanner.e:138		char_class['\''] = SINGLE_QUOTE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 39);
    *(intptr_t *)_2 = -5;

    /** scanner.e:139		char_class['"'] = DOUBLE_QUOTE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 34);
    *(intptr_t *)_2 = -4;

    /** scanner.e:140		char_class['`'] = BACK_QUOTE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 96);
    *(intptr_t *)_2 = -12;

    /** scanner.e:141		char_class['.'] = DOT*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 46);
    *(intptr_t *)_2 = -3;

    /** scanner.e:142		char_class[':'] = COLON*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 58);
    *(intptr_t *)_2 = -23;

    /** scanner.e:143		char_class['\r'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 13);
    *(intptr_t *)_2 = -6;

    /** scanner.e:144		char_class['\n'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 10);
    *(intptr_t *)_2 = -6;

    /** scanner.e:145		char_class['!'] = BANG*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 33);
    *(intptr_t *)_2 = -1;

    /** scanner.e:146		char_class['{'] = LEFT_BRACE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 123);
    *(intptr_t *)_2 = -24;

    /** scanner.e:147		char_class['}'] = RIGHT_BRACE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 125);
    *(intptr_t *)_2 = -25;

    /** scanner.e:148		char_class['('] = LEFT_ROUND*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 40);
    *(intptr_t *)_2 = -26;

    /** scanner.e:149		char_class[')'] = RIGHT_ROUND*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 41);
    *(intptr_t *)_2 = -27;

    /** scanner.e:150		char_class['['] = LEFT_SQUARE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 91);
    *(intptr_t *)_2 = -28;

    /** scanner.e:151		char_class[']'] = RIGHT_SQUARE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 93);
    *(intptr_t *)_2 = -29;

    /** scanner.e:152		char_class['$'] = DOLLAR*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 36);
    *(intptr_t *)_2 = -22;

    /** scanner.e:153		char_class[','] = COMMA*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 44);
    *(intptr_t *)_2 = -30;

    /** scanner.e:154		char_class['&'] = res:CONCAT*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 38);
    *(intptr_t *)_2 = 15;

    /** scanner.e:155		char_class['?'] = QUESTION_MARK*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 63);
    *(intptr_t *)_2 = -31;

    /** scanner.e:156		char_class['#'] = NUMBER_SIGN*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 35);
    *(intptr_t *)_2 = -11;

    /** scanner.e:159		char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _2 = (object)(((s1_ptr)_2)->base + 26);
    *(intptr_t *)_2 = -21;

    /** scanner.e:162		id_char = repeat(FALSE, 255)*/
    DeRefi(_61id_char_25933);
    _61id_char_25933 = Repeat(_9FALSE_439, 255);

    /** scanner.e:163		for i = 1 to 255 do*/
    {
        object _i_26011;
        _i_26011 = 1;
L1: 
        if (_i_26011 > 255){
            goto L2; // [407] 456
        }

        /** scanner.e:164			if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (object)SEQ_PTR(_61char_class_25932);
        _14466 = (object)*(((s1_ptr)_2)->base + _i_26011);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2;
        ((intptr_t *)_2)[2] = -7;
        _14467 = MAKE_SEQ(_1);
        _14468 = find_from(_14466, _14467, 1);
        _14466 = NOVALUE;
        DeRefDS(_14467);
        _14467 = NOVALUE;
        if (_14468 == 0)
        {
            _14468 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _14468 = NOVALUE;
        }

        /** scanner.e:165				id_char[i] = TRUE*/
        _2 = (object)SEQ_PTR(_61id_char_25933);
        _2 = (object)(((s1_ptr)_2)->base + _i_26011);
        *(intptr_t *)_2 = _9TRUE_441;
L3: 

        /** scanner.e:167		end for*/
        _i_26011 = _i_26011 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** scanner.e:169		default_namespaces = {0}*/
    _0 = _61default_namespaces_25931;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    _61default_namespaces_25931 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:170	end procedure*/
    return;
    ;
}


void _61ResetTP()
{
    object _0, _1, _2;
    

    /** scanner.e:174		OpTrace = FALSE*/
    _27OpTrace_20641 = _9FALSE_439;

    /** scanner.e:175		OpProfileStatement = FALSE*/
    _27OpProfileStatement_20643 = _9FALSE_439;

    /** scanner.e:176		OpProfileTime = FALSE*/
    _27OpProfileTime_20644 = _9FALSE_439;

    /** scanner.e:177		AnyStatementProfile = FALSE*/
    _28AnyStatementProfile_11596 = _9FALSE_439;

    /** scanner.e:178		AnyTimeProfile = FALSE*/
    _28AnyTimeProfile_11595 = _9FALSE_439;

    /** scanner.e:179	end procedure*/
    return;
    ;
}


object _61pack_source(object _src_26040)
{
    object _start_26041 = NOVALUE;
    object _14491 = NOVALUE;
    object _14490 = NOVALUE;
    object _14489 = NOVALUE;
    object _14488 = NOVALUE;
    object _14486 = NOVALUE;
    object _14484 = NOVALUE;
    object _14483 = NOVALUE;
    object _14482 = NOVALUE;
    object _14478 = NOVALUE;
    object _14476 = NOVALUE;
    object _14475 = NOVALUE;
    object _14472 = NOVALUE;
    object _14471 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:197		if equal(src, 0) then*/
    if (_src_26040 == 0)
    _14471 = 1;
    else if (IS_ATOM_INT(_src_26040) && IS_ATOM_INT(0))
    _14471 = 0;
    else
    _14471 = (compare(_src_26040, 0) == 0);
    if (_14471 == 0)
    {
        _14471 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _14471 = NOVALUE;
    }

    /** scanner.e:198			return 0*/
    DeRef(_src_26040);
    return 0;
L1: 

    /** scanner.e:201		if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_26040)){
            _14472 = SEQ_PTR(_src_26040)->length;
    }
    else {
        _14472 = 1;
    }
    if (_14472 < 10000)
    goto L2; // [22] 34

    /** scanner.e:202			src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_26040;
    RHS_Slice(_src_26040, 1, 100);
L2: 

    /** scanner.e:205		if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_26040)){
            _14475 = SEQ_PTR(_src_26040)->length;
    }
    else {
        _14475 = 1;
    }
    _14476 = _61current_source_next_26036 + _14475;
    if ((object)((uintptr_t)_14476 + (uintptr_t)HIGH_BITS) >= 0){
        _14476 = NewDouble((eudouble)_14476);
    }
    _14475 = NOVALUE;
    if (binary_op_a(LESS, _14476, 10000)){
        DeRef(_14476);
        _14476 = NOVALUE;
        goto L3; // [45] 96
    }
    DeRef(_14476);
    _14476 = NOVALUE;

    /** scanner.e:207			current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _14478 = 10400;
    _0 = _6allocate(10400, 0);
    DeRef(_61current_source_26035);
    _61current_source_26035 = _0;
    _14478 = NOVALUE;

    /** scanner.e:208			if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _61current_source_26035, 0)){
        goto L4; // [64] 78
    }

    /** scanner.e:209				CompileErr(OUT_OF_MEMORY__TURN_OFF_TRACE_AND_PROFILE)*/
    RefDS(_22209);
    _49CompileErr(123, _22209, 0);
L4: 

    /** scanner.e:211			all_source = append(all_source, current_source)*/
    Ref(_61current_source_26035);
    Append(&_28all_source_11597, _28all_source_11597, _61current_source_26035);

    /** scanner.e:213			current_source_next = 1*/
    _61current_source_next_26036 = 1;
L3: 

    /** scanner.e:216		start = current_source_next*/
    _start_26041 = _61current_source_next_26036;

    /** scanner.e:217		poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_61current_source_26035)) {
        _14482 = _61current_source_26035 + _61current_source_next_26036;
        if ((object)((uintptr_t)_14482 + (uintptr_t)HIGH_BITS) >= 0){
            _14482 = NewDouble((eudouble)_14482);
        }
    }
    else {
        _14482 = NewDouble(DBL_PTR(_61current_source_26035)->dbl + (eudouble)_61current_source_next_26036);
    }
    if (IS_ATOM_INT(_14482)){
        poke_addr = (uint8_t *)_14482;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14482)->dbl);
    }
    if (IS_ATOM_INT(_src_26040)) {
        *poke_addr = (uint8_t)_src_26040;
    }
    else if (IS_ATOM(_src_26040)) {
        *poke_addr = (uint8_t)DBL_PTR(_src_26040)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_src_26040);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_14482);
    _14482 = NOVALUE;

    /** scanner.e:218		current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_26040)){
            _14483 = SEQ_PTR(_src_26040)->length;
    }
    else {
        _14483 = 1;
    }
    _14484 = _14483 - 1;
    _14483 = NOVALUE;
    _61current_source_next_26036 = _61current_source_next_26036 + _14484;
    _14484 = NOVALUE;

    /** scanner.e:219		poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_61current_source_26035)) {
        _14486 = _61current_source_26035 + _61current_source_next_26036;
        if ((object)((uintptr_t)_14486 + (uintptr_t)HIGH_BITS) >= 0){
            _14486 = NewDouble((eudouble)_14486);
        }
    }
    else {
        _14486 = NewDouble(DBL_PTR(_61current_source_26035)->dbl + (eudouble)_61current_source_next_26036);
    }
    if (IS_ATOM_INT(_14486)){
        poke_addr = (uint8_t *)_14486;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14486)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_14486);
    _14486 = NOVALUE;

    /** scanner.e:220		current_source_next += 1*/
    _61current_source_next_26036 = _61current_source_next_26036 + 1;

    /** scanner.e:221		return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_28all_source_11597)){
            _14488 = SEQ_PTR(_28all_source_11597)->length;
    }
    else {
        _14488 = 1;
    }
    _14489 = _14488 - 1;
    _14488 = NOVALUE;
    if (_14489 <= INT15){
        _14490 = 10000 * _14489;
    }
    else{
        _14490 = NewDouble(10000 * (eudouble)_14489);
    }
    _14489 = NOVALUE;
    if (IS_ATOM_INT(_14490)) {
        _14491 = _start_26041 + _14490;
        if ((object)((uintptr_t)_14491 + (uintptr_t)HIGH_BITS) >= 0){
            _14491 = NewDouble((eudouble)_14491);
        }
    }
    else {
        _14491 = NewDouble((eudouble)_start_26041 + DBL_PTR(_14490)->dbl);
    }
    DeRef(_14490);
    _14490 = NOVALUE;
    DeRef(_src_26040);
    return _14491;
    ;
}


object _61fetch_line(object _start_26075)
{
    object _line_26076 = NOVALUE;
    object _memdata_26077 = NOVALUE;
    object _c_26078 = NOVALUE;
    object _chunk_26079 = NOVALUE;
    object _p_26080 = NOVALUE;
    object _n_26081 = NOVALUE;
    object _m_26082 = NOVALUE;
    object _14516 = NOVALUE;
    object _14515 = NOVALUE;
    object _14513 = NOVALUE;
    object _14511 = NOVALUE;
    object _14505 = NOVALUE;
    object _14503 = NOVALUE;
    object _14499 = NOVALUE;
    object _14497 = NOVALUE;
    object _14494 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_26075)) {
        _1 = (object)(DBL_PTR(_start_26075)->dbl);
        DeRefDS(_start_26075);
        _start_26075 = _1;
    }

    /** scanner.e:234		if start = 0 then*/
    if (_start_26075 != 0)
    goto L1; // [5] 16

    /** scanner.e:235			return ""*/
    RefDS(_5);
    DeRef(_line_26076);
    DeRefi(_memdata_26077);
    DeRef(_p_26080);
    return _5;
L1: 

    /** scanner.e:237		line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_26076);
    _line_26076 = Repeat(0, 400);

    /** scanner.e:238		n = 0*/
    _n_26081 = 0;

    /** scanner.e:239		chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_26075 >= 0) {
        _14494 = _start_26075 / 10000;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_start_26075 / (eudouble)10000);
        _14494 = (object)temp_dbl;
    }
    _chunk_26079 = _14494 + 1;
    _14494 = NOVALUE;

    /** scanner.e:240		start = remainder(start, SOURCE_CHUNK)*/
    _start_26075 = (_start_26075 % 10000);

    /** scanner.e:241		p = all_source[chunk] + start*/
    _2 = (object)SEQ_PTR(_28all_source_11597);
    _14497 = (object)*(((s1_ptr)_2)->base + _chunk_26079);
    DeRef(_p_26080);
    if (IS_ATOM_INT(_14497)) {
        _p_26080 = _14497 + _start_26075;
        if ((object)((uintptr_t)_p_26080 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26080 = NewDouble((eudouble)_p_26080);
        }
    }
    else {
        _p_26080 = NewDouble(DBL_PTR(_14497)->dbl + (eudouble)_start_26075);
    }
    _14497 = NOVALUE;

    /** scanner.e:242		memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_26080);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_26080;
    ((intptr_t *)_2)[2] = 400;
    _14499 = MAKE_SEQ(_1);
    DeRefi(_memdata_26077);
    _1 = (object)SEQ_PTR(_14499);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_26077 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14499);
    _14499 = NOVALUE;

    /** scanner.e:243		p += LINE_BUFLEN*/
    _0 = _p_26080;
    if (IS_ATOM_INT(_p_26080)) {
        _p_26080 = _p_26080 + 400;
        if ((object)((uintptr_t)_p_26080 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26080 = NewDouble((eudouble)_p_26080);
        }
    }
    else {
        _p_26080 = NewDouble(DBL_PTR(_p_26080)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:244		m = 0*/
    _m_26082 = 0;

    /** scanner.e:245		while TRUE do*/
L2: 
    if (_9TRUE_441 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** scanner.e:246			m += 1*/
    _m_26082 = _m_26082 + 1;

    /** scanner.e:247			if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_26077)){
            _14503 = SEQ_PTR(_memdata_26077)->length;
    }
    else {
        _14503 = 1;
    }
    if (_m_26082 <= _14503)
    goto L4; // [98] 125

    /** scanner.e:248				memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_26080);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_26080;
    ((intptr_t *)_2)[2] = 400;
    _14505 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_26077);
    _1 = (object)SEQ_PTR(_14505);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_26077 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14505);
    _14505 = NOVALUE;

    /** scanner.e:249				p += LINE_BUFLEN*/
    _0 = _p_26080;
    if (IS_ATOM_INT(_p_26080)) {
        _p_26080 = _p_26080 + 400;
        if ((object)((uintptr_t)_p_26080 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26080 = NewDouble((eudouble)_p_26080);
        }
    }
    else {
        _p_26080 = NewDouble(DBL_PTR(_p_26080)->dbl + (eudouble)400);
    }
    DeRef(_0);

    /** scanner.e:250				m = 1*/
    _m_26082 = 1;
L4: 

    /** scanner.e:252			c = memdata[m]*/
    _2 = (object)SEQ_PTR(_memdata_26077);
    _c_26078 = (object)*(((s1_ptr)_2)->base + _m_26082);

    /** scanner.e:253			if c = 0 then*/
    if (_c_26078 != 0)
    goto L5; // [133] 142

    /** scanner.e:254				exit*/
    goto L3; // [139] 179
L5: 

    /** scanner.e:256			n += 1*/
    _n_26081 = _n_26081 + 1;

    /** scanner.e:257			if n > length(line) then*/
    if (IS_SEQUENCE(_line_26076)){
            _14511 = SEQ_PTR(_line_26076)->length;
    }
    else {
        _14511 = 1;
    }
    if (_n_26081 <= _14511)
    goto L6; // [153] 168

    /** scanner.e:258				line &= repeat(0, LINE_BUFLEN)*/
    _14513 = Repeat(0, 400);
    Concat((object_ptr)&_line_26076, _line_26076, _14513);
    DeRefDS(_14513);
    _14513 = NOVALUE;
L6: 

    /** scanner.e:260			line[n] = c*/
    _2 = (object)SEQ_PTR(_line_26076);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _line_26076 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_26081);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _c_26078;
    DeRef(_1);

    /** scanner.e:261		end while*/
    goto L2; // [176] 82
L3: 

    /** scanner.e:262		line = remove( line, n+1, length( line ) )*/
    _14515 = _n_26081 + 1;
    if (_14515 > MAXINT){
        _14515 = NewDouble((eudouble)_14515);
    }
    if (IS_SEQUENCE(_line_26076)){
            _14516 = SEQ_PTR(_line_26076)->length;
    }
    else {
        _14516 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_26076);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14515)) ? _14515 : (object)(DBL_PTR(_14515)->dbl);
        int stop = (IS_ATOM_INT(_14516)) ? _14516 : (object)(DBL_PTR(_14516)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_26076), start, &_line_26076 );
            }
            else Tail(SEQ_PTR(_line_26076), stop+1, &_line_26076);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_26076), start, &_line_26076);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_26076 = Remove_elements(start, stop, (SEQ_PTR(_line_26076)->ref == 1));
        }
    }
    DeRef(_14515);
    _14515 = NOVALUE;
    _14516 = NOVALUE;

    /** scanner.e:263		return line*/
    DeRefi(_memdata_26077);
    DeRef(_p_26080);
    return _line_26076;
    ;
}


void _61AppendSourceLine()
{
    object _new_26118 = NOVALUE;
    object _old_26119 = NOVALUE;
    object _options_26120 = NOVALUE;
    object _src_26121 = NOVALUE;
    object _14557 = NOVALUE;
    object _14553 = NOVALUE;
    object _14551 = NOVALUE;
    object _14550 = NOVALUE;
    object _14547 = NOVALUE;
    object _14546 = NOVALUE;
    object _14545 = NOVALUE;
    object _14544 = NOVALUE;
    object _14543 = NOVALUE;
    object _14542 = NOVALUE;
    object _14541 = NOVALUE;
    object _14540 = NOVALUE;
    object _14539 = NOVALUE;
    object _14538 = NOVALUE;
    object _14537 = NOVALUE;
    object _14536 = NOVALUE;
    object _14535 = NOVALUE;
    object _14534 = NOVALUE;
    object _14533 = NOVALUE;
    object _14532 = NOVALUE;
    object _14531 = NOVALUE;
    object _14530 = NOVALUE;
    object _14528 = NOVALUE;
    object _14527 = NOVALUE;
    object _14526 = NOVALUE;
    object _14524 = NOVALUE;
    object _14519 = NOVALUE;
    object _14518 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:272		src = 0*/
    DeRef(_src_26121);
    _src_26121 = 0;

    /** scanner.e:273		options = 0*/
    _options_26120 = 0;

    /** scanner.e:275		if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_27TRANSLATE_20179 != 0) {
        _14518 = 1;
        goto L1; // [15] 25
    }
    _14518 = (_27OpTrace_20641 != 0);
L1: 
    if (_14518 != 0) {
        _14519 = 1;
        goto L2; // [25] 35
    }
    _14519 = (_27OpProfileStatement_20643 != 0);
L2: 
    if (_14519 != 0) {
        goto L3; // [35] 46
    }
    if (_27OpProfileTime_20644 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** scanner.e:277			src = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_src_26121);
    _src_26121 = _49ThisLine_49642;

    /** scanner.e:279			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** scanner.e:280				options = SOP_TRACE*/
    _options_26120 = 1;
L5: 

    /** scanner.e:282			if OpProfileTime then*/
    if (_27OpProfileTime_20644 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** scanner.e:283				options = or_bits(options, SOP_PROFILE_TIME)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_26120 | (uintptr_t)2;
         _options_26120 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_26120)) {
        _1 = (object)(DBL_PTR(_options_26120)->dbl);
        DeRefDS(_options_26120);
        _options_26120 = _1;
    }
L6: 

    /** scanner.e:285			if OpProfileStatement then*/
    if (_27OpProfileStatement_20643 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** scanner.e:286				options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_26120 | (uintptr_t)4;
         _options_26120 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_26120)) {
        _1 = (object)(DBL_PTR(_options_26120)->dbl);
        DeRefDS(_options_26120);
        _options_26120 = _1;
    }
L7: 

    /** scanner.e:288			if OpProfileStatement or OpProfileTime then*/
    if (_27OpProfileStatement_20643 != 0) {
        goto L8; // [110] 121
    }
    if (_27OpProfileTime_20644 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** scanner.e:289				src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    _14524 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_14524) && IS_ATOM(_src_26121)) {
        Ref(_src_26121);
        Append(&_src_26121, _14524, _src_26121);
    }
    else if (IS_ATOM(_14524) && IS_SEQUENCE(_src_26121)) {
    }
    else {
        Concat((object_ptr)&_src_26121, _14524, _src_26121);
        DeRefDS(_14524);
        _14524 = NOVALUE;
    }
    DeRef(_14524);
    _14524 = NOVALUE;
L9: 
L4: 

    /** scanner.e:293		if length(slist) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _14526 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _14526 = 1;
    }
    if (_14526 == 0)
    {
        _14526 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _14526 = NOVALUE;
    }

    /** scanner.e:294			old = slist[$-1]*/
    if (IS_SEQUENCE(_27slist_20662)){
            _14527 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _14527 = 1;
    }
    _14528 = _14527 - 1;
    _14527 = NOVALUE;
    DeRef(_old_26119);
    _2 = (object)SEQ_PTR(_27slist_20662);
    _old_26119 = (object)*(((s1_ptr)_2)->base + _14528);
    Ref(_old_26119);

    /** scanner.e:296			if equal(src, old[SRC]) and*/
    _2 = (object)SEQ_PTR(_old_26119);
    _14530 = (object)*(((s1_ptr)_2)->base + 1);
    if (_src_26121 == _14530)
    _14531 = 1;
    else if (IS_ATOM_INT(_src_26121) && IS_ATOM_INT(_14530))
    _14531 = 0;
    else
    _14531 = (compare(_src_26121, _14530) == 0);
    _14530 = NOVALUE;
    if (_14531 == 0) {
        _14532 = 0;
        goto LB; // [175] 195
    }
    _2 = (object)SEQ_PTR(_old_26119);
    _14533 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_14533)) {
        _14534 = (_27current_file_no_20571 == _14533);
    }
    else {
        _14534 = binary_op(EQUALS, _27current_file_no_20571, _14533);
    }
    _14533 = NOVALUE;
    if (IS_ATOM_INT(_14534))
    _14532 = (_14534 != 0);
    else
    _14532 = DBL_PTR(_14534)->dbl != 0.0;
LB: 
    if (_14532 == 0) {
        _14535 = 0;
        goto LC; // [195] 232
    }
    _2 = (object)SEQ_PTR(_old_26119);
    _14536 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14536)) {
        _14537 = _14536 + 1;
        if (_14537 > MAXINT){
            _14537 = NewDouble((eudouble)_14537);
        }
    }
    else
    _14537 = binary_op(PLUS, 1, _14536);
    _14536 = NOVALUE;
    if (IS_SEQUENCE(_27slist_20662)){
            _14538 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _14538 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _14539 = (object)*(((s1_ptr)_2)->base + _14538);
    if (IS_ATOM_INT(_14537) && IS_ATOM_INT(_14539)) {
        _14540 = _14537 + _14539;
        if ((object)((uintptr_t)_14540 + (uintptr_t)HIGH_BITS) >= 0){
            _14540 = NewDouble((eudouble)_14540);
        }
    }
    else {
        _14540 = binary_op(PLUS, _14537, _14539);
    }
    DeRef(_14537);
    _14537 = NOVALUE;
    _14539 = NOVALUE;
    if (IS_ATOM_INT(_14540)) {
        _14541 = (_27line_number_20572 == _14540);
    }
    else {
        _14541 = binary_op(EQUALS, _27line_number_20572, _14540);
    }
    DeRef(_14540);
    _14540 = NOVALUE;
    if (IS_ATOM_INT(_14541))
    _14535 = (_14541 != 0);
    else
    _14535 = DBL_PTR(_14541)->dbl != 0.0;
LC: 
    if (_14535 == 0) {
        goto LD; // [232] 272
    }
    _2 = (object)SEQ_PTR(_old_26119);
    _14543 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_14543)) {
        _14544 = (_options_26120 == _14543);
    }
    else {
        _14544 = binary_op(EQUALS, _options_26120, _14543);
    }
    _14543 = NOVALUE;
    if (_14544 == 0) {
        DeRef(_14544);
        _14544 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_14544) && DBL_PTR(_14544)->dbl == 0.0){
            DeRef(_14544);
            _14544 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_14544);
        _14544 = NOVALUE;
    }
    DeRef(_14544);
    _14544 = NOVALUE;

    /** scanner.e:302				slist[$] += 1*/
    if (IS_SEQUENCE(_27slist_20662)){
            _14545 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _14545 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _14546 = (object)*(((s1_ptr)_2)->base + _14545);
    if (IS_ATOM_INT(_14546)) {
        _14547 = _14546 + 1;
        if (_14547 > MAXINT){
            _14547 = NewDouble((eudouble)_14547);
        }
    }
    else
    _14547 = binary_op(PLUS, 1, _14546);
    _14546 = NOVALUE;
    _2 = (object)SEQ_PTR(_27slist_20662);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27slist_20662 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14545);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14547;
    if( _1 != _14547 ){
        DeRef(_1);
    }
    _14547 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** scanner.e:304				src = pack_source(src)*/
    Ref(_src_26121);
    _0 = _src_26121;
    _src_26121 = _61pack_source(_src_26121);
    DeRef(_0);

    /** scanner.e:305				new = {src, line_number, current_file_no, options}*/
    _0 = _new_26118;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_26121);
    ((intptr_t*)_2)[1] = _src_26121;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    ((intptr_t*)_2)[3] = _27current_file_no_20571;
    ((intptr_t*)_2)[4] = _options_26120;
    _new_26118 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:306				if slist[$] = 0 then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _14550 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _14550 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _14551 = (object)*(((s1_ptr)_2)->base + _14550);
    if (binary_op_a(NOTEQ, _14551, 0)){
        _14551 = NOVALUE;
        goto LF; // [302] 320
    }
    _14551 = NOVALUE;

    /** scanner.e:307					slist[$] = new*/
    if (IS_SEQUENCE(_27slist_20662)){
            _14553 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _14553 = 1;
    }
    RefDS(_new_26118);
    _2 = (object)SEQ_PTR(_27slist_20662);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27slist_20662 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14553);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_26118;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** scanner.e:309					slist = append(slist, new)*/
    RefDS(_new_26118);
    Append(&_27slist_20662, _27slist_20662, _new_26118);
L10: 

    /** scanner.e:311				slist = append(slist, 0)*/
    Append(&_27slist_20662, _27slist_20662, 0);
    goto LE; // [342] 371
LA: 

    /** scanner.e:314			src = pack_source(src)*/
    Ref(_src_26121);
    _0 = _src_26121;
    _src_26121 = _61pack_source(_src_26121);
    DeRef(_0);

    /** scanner.e:315			slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_26121);
    ((intptr_t*)_2)[1] = _src_26121;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    ((intptr_t*)_2)[3] = _27current_file_no_20571;
    ((intptr_t*)_2)[4] = _options_26120;
    _14557 = MAKE_SEQ(_1);
    DeRef(_27slist_20662);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14557;
    ((intptr_t *)_2)[2] = 0;
    _27slist_20662 = MAKE_SEQ(_1);
    _14557 = NOVALUE;
LE: 

    /** scanner.e:317	end procedure*/
    DeRef(_new_26118);
    DeRef(_old_26119);
    DeRef(_src_26121);
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14541);
    _14541 = NOVALUE;
    DeRef(_14528);
    _14528 = NOVALUE;
    return;
    ;
}


object _61s_expand(object _slist_26210)
{
    object _new_slist_26211 = NOVALUE;
    object _14571 = NOVALUE;
    object _14570 = NOVALUE;
    object _14569 = NOVALUE;
    object _14568 = NOVALUE;
    object _14566 = NOVALUE;
    object _14565 = NOVALUE;
    object _14564 = NOVALUE;
    object _14562 = NOVALUE;
    object _14561 = NOVALUE;
    object _14560 = NOVALUE;
    object _14559 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:323		new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_26211);
    _new_slist_26211 = _5;

    /** scanner.e:325		for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_26210)){
            _14559 = SEQ_PTR(_slist_26210)->length;
    }
    else {
        _14559 = 1;
    }
    {
        object _i_26213;
        _i_26213 = 1;
L1: 
        if (_i_26213 > _14559){
            goto L2; // [15] 114
        }

        /** scanner.e:326			if sequence(slist[i]) then*/
        _2 = (object)SEQ_PTR(_slist_26210);
        _14560 = (object)*(((s1_ptr)_2)->base + _i_26213);
        _14561 = IS_SEQUENCE(_14560);
        _14560 = NOVALUE;
        if (_14561 == 0)
        {
            _14561 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _14561 = NOVALUE;
        }

        /** scanner.e:327				new_slist = append(new_slist, slist[i])*/
        _2 = (object)SEQ_PTR(_slist_26210);
        _14562 = (object)*(((s1_ptr)_2)->base + _i_26213);
        Ref(_14562);
        Append(&_new_slist_26211, _new_slist_26211, _14562);
        _14562 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** scanner.e:329				for j = 1 to slist[i] do*/
        _2 = (object)SEQ_PTR(_slist_26210);
        _14564 = (object)*(((s1_ptr)_2)->base + _i_26213);
        {
            object _j_26222;
            _j_26222 = 1;
L5: 
            if (binary_op_a(GREATER, _j_26222, _14564)){
                goto L6; // [53] 106
            }

            /** scanner.e:330					slist[i-1][LINE] += 1*/
            _14565 = _i_26213 - 1;
            _2 = (object)SEQ_PTR(_slist_26210);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _slist_26210 = MAKE_SEQ(_2);
            }
            _3 = (object)(_14565 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            _14568 = (object)*(((s1_ptr)_2)->base + 2);
            _14566 = NOVALUE;
            if (IS_ATOM_INT(_14568)) {
                _14569 = _14568 + 1;
                if (_14569 > MAXINT){
                    _14569 = NewDouble((eudouble)_14569);
                }
            }
            else
            _14569 = binary_op(PLUS, 1, _14568);
            _14568 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 2);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14569;
            if( _1 != _14569 ){
                DeRef(_1);
            }
            _14569 = NOVALUE;
            _14566 = NOVALUE;

            /** scanner.e:331					new_slist = append(new_slist, slist[i-1])*/
            _14570 = _i_26213 - 1;
            _2 = (object)SEQ_PTR(_slist_26210);
            _14571 = (object)*(((s1_ptr)_2)->base + _14570);
            Ref(_14571);
            Append(&_new_slist_26211, _new_slist_26211, _14571);
            _14571 = NOVALUE;

            /** scanner.e:332				end for*/
            _0 = _j_26222;
            if (IS_ATOM_INT(_j_26222)) {
                _j_26222 = _j_26222 + 1;
                if ((object)((uintptr_t)_j_26222 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_26222 = NewDouble((eudouble)_j_26222);
                }
            }
            else {
                _j_26222 = binary_op_a(PLUS, _j_26222, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_26222);
        }
L4: 

        /** scanner.e:334		end for*/
        _i_26213 = _i_26213 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** scanner.e:335		return new_slist*/
    DeRefDS(_slist_26210);
    DeRef(_14565);
    _14565 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    _14564 = NOVALUE;
    return _new_slist_26211;
    ;
}


void _61set_dont_read(object _read_26237)
{
    object _0, _1, _2;
    

    /** scanner.e:357		dont_read = read*/
    _61dont_read_26234 = _read_26237;

    /** scanner.e:358	end procedure*/
    return;
    ;
}


void _61read_line()
{
    object _n_26243 = NOVALUE;
    object _14602 = NOVALUE;
    object _14601 = NOVALUE;
    object _14600 = NOVALUE;
    object _14599 = NOVALUE;
    object _14598 = NOVALUE;
    object _14596 = NOVALUE;
    object _14595 = NOVALUE;
    object _14593 = NOVALUE;
    object _14592 = NOVALUE;
    object _14590 = NOVALUE;
    object _14589 = NOVALUE;
    object _14581 = NOVALUE;
    object _14579 = NOVALUE;
    object _14578 = NOVALUE;
    object _14577 = NOVALUE;
    object _14576 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:367		line_number += 1*/
    _27line_number_20572 = _27line_number_20572 + 1;

    /** scanner.e:368		gline_number += 1*/
    _27gline_number_20576 = _27gline_number_20576 + 1;

    /** scanner.e:370		if dont_read then*/
    if (_61dont_read_26234 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** scanner.e:371			ThisLine = -1*/
    DeRef(_49ThisLine_49642);
    _49ThisLine_49642 = -1;
    goto L2; // [33] 216
L1: 

    /** scanner.e:372		elsif repl and src_file = repl_file then*/
    if (0 == 0) {
        goto L3; // [40] 144
    }
    _14577 = (_27src_file_20693 == 5555);
    if (_14577 == 0)
    {
        DeRef(_14577);
        _14577 = NOVALUE;
        goto L3; // [53] 144
    }
    else{
        DeRef(_14577);
        _14577 = NOVALUE;
    }

    /** scanner.e:373			if repl_line_was_read and current_block = top_level_block then*/
    if (_61repl_line_was_read_26238 == 0) {
        goto L4; // [60] 118
    }
    _14579 = (_64current_block_25492 == _64top_level_block_25493);
    if (_14579 == 0)
    {
        DeRef(_14579);
        _14579 = NOVALUE;
        goto L4; // [73] 118
    }
    else{
        DeRef(_14579);
        _14579 = NOVALUE;
    }

    /** scanner.e:374				if repl_line_was_read > 1 then*/
    if (_61repl_line_was_read_26238 <= 1)
    goto L5; // [80] 110

    /** scanner.e:375					if not match("end", ThisLine) then*/
    _14581 = e_match_from(_13356, _49ThisLine_49642, 1);
    if (_14581 != 0)
    goto L6; // [93] 109
    _14581 = NOVALUE;

    /** scanner.e:376						goto "lol"*/
    goto G7;
L6: 
L5: 

    /** scanner.e:379				ThisLine = -1*/
    DeRef(_49ThisLine_49642);
    _49ThisLine_49642 = -1;
    goto L2; // [115] 216
L4: 

    /** scanner.e:381				label "lol"*/
G7:

    /** scanner.e:382				puts(1, "Enter line:\n")*/
    EPuts(1, _14584); // DJP 

    /** scanner.e:383				repl_line_was_read += 1*/
    _61repl_line_was_read_26238 = _61repl_line_was_read_26238 + 1;

    /** scanner.e:384				ThisLine = gets(0)*/
    DeRef(_49ThisLine_49642);
    _49ThisLine_49642 = EGets(0);
    goto L2; // [141] 216
L3: 

    /** scanner.e:386		elsif src_file < 0 then*/
    if (_27src_file_20693 >= 0)
    goto L8; // [148] 160

    /** scanner.e:387			ThisLine = -1*/
    DeRef(_49ThisLine_49642);
    _49ThisLine_49642 = -1;
    goto L2; // [157] 216
L8: 

    /** scanner.e:389			ThisLine = gets(src_file)*/
    DeRef(_49ThisLine_49642);
    _49ThisLine_49642 = EGets(_27src_file_20693);

    /** scanner.e:390			if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _14589 = IS_SEQUENCE(_49ThisLine_49642);
    if (_14589 == 0) {
        goto L9; // [174] 215
    }
    RefDS(_14591);
    Ref(_49ThisLine_49642);
    _14592 = _14ends(_14591, _49ThisLine_49642);
    if (_14592 == 0) {
        DeRef(_14592);
        _14592 = NOVALUE;
        goto L9; // [186] 215
    }
    else {
        if (!IS_ATOM_INT(_14592) && DBL_PTR(_14592)->dbl == 0.0){
            DeRef(_14592);
            _14592 = NOVALUE;
            goto L9; // [186] 215
        }
        DeRef(_14592);
        _14592 = NOVALUE;
    }
    DeRef(_14592);
    _14592 = NOVALUE;

    /** scanner.e:391				ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_49ThisLine_49642)){
            _14593 = SEQ_PTR(_49ThisLine_49642)->length;
    }
    else {
        _14593 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_49ThisLine_49642);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14593)) ? _14593 : (object)(DBL_PTR(_14593)->dbl);
        int stop = (IS_ATOM_INT(_14593)) ? _14593 : (object)(DBL_PTR(_14593)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49ThisLine_49642), start, &_49ThisLine_49642 );
            }
            else Tail(SEQ_PTR(_49ThisLine_49642), stop+1, &_49ThisLine_49642);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49ThisLine_49642), start, &_49ThisLine_49642);
        }
        else {
            assign_slice_seq = &assign_space;
            _49ThisLine_49642 = Remove_elements(start, stop, (SEQ_PTR(_49ThisLine_49642)->ref == 1));
        }
    }
    _14593 = NOVALUE;
    _14593 = NOVALUE;

    /** scanner.e:392				ThisLine[$] = 10*/
    if (IS_SEQUENCE(_49ThisLine_49642)){
            _14595 = SEQ_PTR(_49ThisLine_49642)->length;
    }
    else {
        _14595 = 1;
    }
    _2 = (object)SEQ_PTR(_49ThisLine_49642);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _49ThisLine_49642 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14595);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 10;
    DeRef(_1);
L9: 
L2: 

    /** scanner.e:395		if atom(ThisLine) then*/
    _14596 = IS_ATOM(_49ThisLine_49642);
    if (_14596 == 0)
    {
        _14596 = NOVALUE;
        goto LA; // [223] 286
    }
    else{
        _14596 = NOVALUE;
    }

    /** scanner.e:396			ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _49ThisLine_49642;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 26;
    _49ThisLine_49642 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:397			if src_file >= 0 and (src_file != repl_file or not repl) then*/
    _14598 = (_27src_file_20693 >= 0);
    if (_14598 == 0) {
        goto LB; // [242] 278
    }
    _14600 = (_27src_file_20693 != 5555);
    if (_14600 != 0) {
        DeRef(_14601);
        _14601 = 1;
        goto LC; // [254] 267
    }
    _14602 = (0 == 0);
    _14601 = (_14602 != 0);
LC: 
    if (_14601 == 0)
    {
        _14601 = NOVALUE;
        goto LB; // [268] 278
    }
    else{
        _14601 = NOVALUE;
    }

    /** scanner.e:398				close(src_file)*/
    EClose(_27src_file_20693);
LB: 

    /** scanner.e:400			src_file = -1*/
    _27src_file_20693 = -1;
LA: 

    /** scanner.e:403		bp = 1*/
    _49bp_49646 = 1;

    /** scanner.e:411		AppendSourceLine()*/
    _61AppendSourceLine();

    /** scanner.e:412	end procedure*/
    DeRef(_14598);
    _14598 = NOVALUE;
    DeRef(_14600);
    _14600 = NOVALUE;
    DeRef(_14602);
    _14602 = NOVALUE;
    return;
    ;
}


object _61getch()
{
    object _c_26318 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:417		c = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_49ThisLine_49642);
    _c_26318 = (object)*(((s1_ptr)_2)->base + _49bp_49646);
    if (!IS_ATOM_INT(_c_26318)){
        _c_26318 = (object)DBL_PTR(_c_26318)->dbl;
    }

    /** scanner.e:418		bp += 1*/
    _49bp_49646 = _49bp_49646 + 1;

    /** scanner.e:419		return c*/
    return _c_26318;
    ;
}


void _61ungetch()
{
    object _0, _1, _2;
    

    /** scanner.e:424		bp -= 1*/
    _49bp_49646 = _49bp_49646 - 1;

    /** scanner.e:425	end procedure*/
    return;
    ;
}


object _61get_file_path(object _s_26330)
{
    object _14611 = NOVALUE;
    object _14609 = NOVALUE;
    object _14608 = NOVALUE;
    object _14607 = NOVALUE;
    object _14606 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:429			for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_26330)){
            _14606 = SEQ_PTR(_s_26330)->length;
    }
    else {
        _14606 = 1;
    }
    {
        object _t_26332;
        _t_26332 = _14606;
L1: 
        if (_t_26332 < 1){
            goto L2; // [8] 50
        }

        /** scanner.e:430					if find(s[t],SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_s_26330);
        _14607 = (object)*(((s1_ptr)_2)->base + _t_26332);
        _14608 = find_from(_14607, _44SLASH_CHARS_20736, 1);
        _14607 = NOVALUE;
        if (_14608 == 0)
        {
            _14608 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _14608 = NOVALUE;
        }

        /** scanner.e:431							return s[1..t]*/
        rhs_slice_target = (object_ptr)&_14609;
        RHS_Slice(_s_26330, 1, _t_26332);
        DeRefDS(_s_26330);
        return _14609;
L3: 

        /** scanner.e:433			end for*/
        _t_26332 = _t_26332 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** scanner.e:435			return "." & SLASH*/
    Append(&_14611, _14610, 92);
    DeRefDS(_s_26330);
    DeRef(_14609);
    _14609 = NOVALUE;
    return _14611;
    ;
}


object _61find_file(object _fname_26344)
{
    object _try_26345 = NOVALUE;
    object _full_path_26346 = NOVALUE;
    object _errbuff_26347 = NOVALUE;
    object _currdir_26348 = NOVALUE;
    object _conf_path_26349 = NOVALUE;
    object _scan_result_26350 = NOVALUE;
    object _inc_path_26351 = NOVALUE;
    object _mainpath_26371 = NOVALUE;
    object _32012 = NOVALUE;
    object _32011 = NOVALUE;
    object _14708 = NOVALUE;
    object _14706 = NOVALUE;
    object _14705 = NOVALUE;
    object _14704 = NOVALUE;
    object _14702 = NOVALUE;
    object _14700 = NOVALUE;
    object _14698 = NOVALUE;
    object _14697 = NOVALUE;
    object _14695 = NOVALUE;
    object _14694 = NOVALUE;
    object _14691 = NOVALUE;
    object _14688 = NOVALUE;
    object _14687 = NOVALUE;
    object _14686 = NOVALUE;
    object _14685 = NOVALUE;
    object _14684 = NOVALUE;
    object _14683 = NOVALUE;
    object _14682 = NOVALUE;
    object _14681 = NOVALUE;
    object _14678 = NOVALUE;
    object _14677 = NOVALUE;
    object _14673 = NOVALUE;
    object _14670 = NOVALUE;
    object _14669 = NOVALUE;
    object _14668 = NOVALUE;
    object _14667 = NOVALUE;
    object _14666 = NOVALUE;
    object _14665 = NOVALUE;
    object _14664 = NOVALUE;
    object _14663 = NOVALUE;
    object _14660 = NOVALUE;
    object _14656 = NOVALUE;
    object _14654 = NOVALUE;
    object _14653 = NOVALUE;
    object _14652 = NOVALUE;
    object _14651 = NOVALUE;
    object _14650 = NOVALUE;
    object _14647 = NOVALUE;
    object _14646 = NOVALUE;
    object _14645 = NOVALUE;
    object _14644 = NOVALUE;
    object _14643 = NOVALUE;
    object _14642 = NOVALUE;
    object _14640 = NOVALUE;
    object _14639 = NOVALUE;
    object _14638 = NOVALUE;
    object _14637 = NOVALUE;
    object _14636 = NOVALUE;
    object _14634 = NOVALUE;
    object _14633 = NOVALUE;
    object _14630 = NOVALUE;
    object _14627 = NOVALUE;
    object _14625 = NOVALUE;
    object _14622 = NOVALUE;
    object _14620 = NOVALUE;
    object _14619 = NOVALUE;
    object _14616 = NOVALUE;
    object _14615 = NOVALUE;
    object _14613 = NOVALUE;
    object _14612 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:449		if absolute_path(fname) then*/
    RefDS(_fname_26344);
    _14612 = _15absolute_path(_fname_26344);
    if (_14612 == 0) {
        DeRef(_14612);
        _14612 = NOVALUE;
        goto L1; // [9] 44
    }
    else {
        if (!IS_ATOM_INT(_14612) && DBL_PTR(_14612)->dbl == 0.0){
            DeRef(_14612);
            _14612 = NOVALUE;
            goto L1; // [9] 44
        }
        DeRef(_14612);
        _14612 = NOVALUE;
    }
    DeRef(_14612);
    _14612 = NOVALUE;

    /** scanner.e:451			if not file_exists(fname) then*/
    RefDS(_fname_26344);
    _14613 = _15file_exists(_fname_26344);
    if (IS_ATOM_INT(_14613)) {
        if (_14613 != 0){
            DeRef(_14613);
            _14613 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    else {
        if (DBL_PTR(_14613)->dbl != 0.0){
            DeRef(_14613);
            _14613 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    DeRef(_14613);
    _14613 = NOVALUE;

    /** scanner.e:452				CompileErr(CANT_OPEN_1, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_27new_include_name_20694);
    ((intptr_t*)_2)[1] = _27new_include_name_20694;
    _14615 = MAKE_SEQ(_1);
    _49CompileErr(51, _14615, 0);
    _14615 = NOVALUE;
L2: 

    /** scanner.e:455			return fname*/
    DeRef(_full_path_26346);
    DeRef(_errbuff_26347);
    DeRef(_currdir_26348);
    DeRef(_conf_path_26349);
    DeRef(_scan_result_26350);
    DeRef(_inc_path_26351);
    DeRef(_mainpath_26371);
    return _fname_26344;
L1: 

    /** scanner.e:460		currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _14616 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_14616);
    _0 = _currdir_26348;
    _currdir_26348 = _61get_file_path(_14616);
    DeRef(_0);
    _14616 = NOVALUE;

    /** scanner.e:461		full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_26346, _currdir_26348, _fname_26344);

    /** scanner.e:462		if file_exists(full_path) then*/
    RefDS(_full_path_26346);
    _14619 = _15file_exists(_full_path_26346);
    if (_14619 == 0) {
        DeRef(_14619);
        _14619 = NOVALUE;
        goto L3; // [72] 82
    }
    else {
        if (!IS_ATOM_INT(_14619) && DBL_PTR(_14619)->dbl == 0.0){
            DeRef(_14619);
            _14619 = NOVALUE;
            goto L3; // [72] 82
        }
        DeRef(_14619);
        _14619 = NOVALUE;
    }
    DeRef(_14619);
    _14619 = NOVALUE;

    /** scanner.e:463			return full_path*/
    DeRefDS(_fname_26344);
    DeRef(_errbuff_26347);
    DeRefDS(_currdir_26348);
    DeRef(_conf_path_26349);
    DeRef(_scan_result_26350);
    DeRef(_inc_path_26351);
    DeRef(_mainpath_26371);
    return _full_path_26346;
L3: 

    /** scanner.e:467		sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_27main_path_20692);
    DeRef(_32011);
    _32011 = _27main_path_20692;
    if (IS_SEQUENCE(_32011)){
            _32012 = SEQ_PTR(_32011)->length;
    }
    else {
        _32012 = 1;
    }
    _32011 = NOVALUE;
    RefDS(_27main_path_20692);
    _14620 = _14rfind(92, _27main_path_20692, _32012);
    _32012 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_26371;
    RHS_Slice(_27main_path_20692, 1, _14620);

    /** scanner.e:468		if not equal(mainpath, currdir) then*/
    if (_mainpath_26371 == _currdir_26348)
    _14622 = 1;
    else if (IS_ATOM_INT(_mainpath_26371) && IS_ATOM_INT(_currdir_26348))
    _14622 = 0;
    else
    _14622 = (compare(_mainpath_26371, _currdir_26348) == 0);
    if (_14622 != 0)
    goto L4; // [113] 141
    _14622 = NOVALUE;

    /** scanner.e:469			full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_26346, _mainpath_26371, _27new_include_name_20694);

    /** scanner.e:470			if file_exists(full_path) then*/
    RefDS(_full_path_26346);
    _14625 = _15file_exists(_full_path_26346);
    if (_14625 == 0) {
        DeRef(_14625);
        _14625 = NOVALUE;
        goto L5; // [130] 140
    }
    else {
        if (!IS_ATOM_INT(_14625) && DBL_PTR(_14625)->dbl == 0.0){
            DeRef(_14625);
            _14625 = NOVALUE;
            goto L5; // [130] 140
        }
        DeRef(_14625);
        _14625 = NOVALUE;
    }
    DeRef(_14625);
    _14625 = NOVALUE;

    /** scanner.e:471				return full_path*/
    DeRefDS(_fname_26344);
    DeRef(_errbuff_26347);
    DeRefDS(_currdir_26348);
    DeRef(_conf_path_26349);
    DeRef(_scan_result_26350);
    DeRef(_inc_path_26351);
    DeRefDS(_mainpath_26371);
    _32011 = NOVALUE;
    DeRef(_14620);
    _14620 = NOVALUE;
    return _full_path_26346;
L5: 
L4: 

    /** scanner.e:475		scan_result = ConfPath(new_include_name)*/
    RefDS(_27new_include_name_20694);
    _0 = _scan_result_26350;
    _scan_result_26350 = _46ConfPath(_27new_include_name_20694);
    DeRef(_0);

    /** scanner.e:477		if atom(scan_result) then*/
    _14627 = IS_ATOM(_scan_result_26350);
    if (_14627 == 0)
    {
        _14627 = NOVALUE;
        goto L6; // [154] 166
    }
    else{
        _14627 = NOVALUE;
    }

    /** scanner.e:478			scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_26344);
    RefDS(_14628);
    _0 = _scan_result_26350;
    _scan_result_26350 = _46ScanPath(_fname_26344, _14628, 0);
    DeRef(_0);
L6: 

    /** scanner.e:481		if atom(scan_result) then*/
    _14630 = IS_ATOM(_scan_result_26350);
    if (_14630 == 0)
    {
        _14630 = NOVALUE;
        goto L7; // [171] 183
    }
    else{
        _14630 = NOVALUE;
    }

    /** scanner.e:482			scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_26344);
    RefDS(_14631);
    _0 = _scan_result_26350;
    _scan_result_26350 = _46ScanPath(_fname_26344, _14631, 1);
    DeRef(_0);
L7: 

    /** scanner.e:485		if atom(scan_result) then*/
    _14633 = IS_ATOM(_scan_result_26350);
    if (_14633 == 0)
    {
        _14633 = NOVALUE;
        goto L8; // [188] 225
    }
    else{
        _14633 = NOVALUE;
    }

    /** scanner.e:487			full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _14634 = _28get_eudir();
    {
        object concat_list[5];

        concat_list[0] = _fname_26344;
        concat_list[1] = 92;
        concat_list[2] = _13394;
        concat_list[3] = 92;
        concat_list[4] = _14634;
        Concat_N((object_ptr)&_full_path_26346, concat_list, 5);
    }
    DeRef(_14634);
    _14634 = NOVALUE;

    /** scanner.e:488			if file_exists(full_path) then*/
    RefDS(_full_path_26346);
    _14636 = _15file_exists(_full_path_26346);
    if (_14636 == 0) {
        DeRef(_14636);
        _14636 = NOVALUE;
        goto L9; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_14636) && DBL_PTR(_14636)->dbl == 0.0){
            DeRef(_14636);
            _14636 = NOVALUE;
            goto L9; // [214] 224
        }
        DeRef(_14636);
        _14636 = NOVALUE;
    }
    DeRef(_14636);
    _14636 = NOVALUE;

    /** scanner.e:489				return full_path*/
    DeRefDS(_fname_26344);
    DeRef(_errbuff_26347);
    DeRef(_currdir_26348);
    DeRef(_conf_path_26349);
    DeRef(_scan_result_26350);
    DeRef(_inc_path_26351);
    DeRef(_mainpath_26371);
    _32011 = NOVALUE;
    DeRef(_14620);
    _14620 = NOVALUE;
    return _full_path_26346;
L9: 
L8: 

    /** scanner.e:493		if sequence(scan_result) then*/
    _14637 = IS_SEQUENCE(_scan_result_26350);
    if (_14637 == 0)
    {
        _14637 = NOVALUE;
        goto LA; // [230] 252
    }
    else{
        _14637 = NOVALUE;
    }

    /** scanner.e:495			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_26350);
    _14638 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_14638))
    EClose(_14638);
    else
    EClose((object)DBL_PTR(_14638)->dbl);
    _14638 = NOVALUE;

    /** scanner.e:496			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_26350);
    _14639 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_14639);
    DeRefDS(_fname_26344);
    DeRef(_full_path_26346);
    DeRef(_errbuff_26347);
    DeRef(_currdir_26348);
    DeRef(_conf_path_26349);
    DeRef(_scan_result_26350);
    DeRef(_inc_path_26351);
    DeRef(_mainpath_26371);
    _32011 = NOVALUE;
    DeRef(_14620);
    _14620 = NOVALUE;
    return _14639;
LA: 

    /** scanner.e:500		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26347);
    _errbuff_26347 = _5;

    /** scanner.e:501		full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_26346);
    _full_path_26346 = _5;

    /** scanner.e:502		if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_26348)){
            _14640 = SEQ_PTR(_currdir_26348)->length;
    }
    else {
        _14640 = 1;
    }
    if (_14640 <= 0)
    goto LB; // [271] 323

    /** scanner.e:503			if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_26348)){
            _14642 = SEQ_PTR(_currdir_26348)->length;
    }
    else {
        _14642 = 1;
    }
    _2 = (object)SEQ_PTR(_currdir_26348);
    _14643 = (object)*(((s1_ptr)_2)->base + _14642);
    _14644 = find_from(_14643, _44SLASH_CHARS_20736, 1);
    _14643 = NOVALUE;
    if (_14644 == 0)
    {
        _14644 = NOVALUE;
        goto LC; // [291] 315
    }
    else{
        _14644 = NOVALUE;
    }

    /** scanner.e:504				full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_26348)){
            _14645 = SEQ_PTR(_currdir_26348)->length;
    }
    else {
        _14645 = 1;
    }
    _14646 = _14645 - 1;
    _14645 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14647;
    RHS_Slice(_currdir_26348, 1, _14646);
    RefDS(_14647);
    Append(&_full_path_26346, _full_path_26346, _14647);
    DeRefDS(_14647);
    _14647 = NOVALUE;
    goto LD; // [312] 322
LC: 

    /** scanner.e:506				full_path = append(full_path, currdir)*/
    RefDS(_currdir_26348);
    Append(&_full_path_26346, _full_path_26346, _currdir_26348);
LD: 
LB: 

    /** scanner.e:511		if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_27main_path_20692)){
            _14650 = SEQ_PTR(_27main_path_20692)->length;
    }
    else {
        _14650 = 1;
    }
    _2 = (object)SEQ_PTR(_27main_path_20692);
    _14651 = (object)*(((s1_ptr)_2)->base + _14650);
    _14652 = find_from(_14651, _44SLASH_CHARS_20736, 1);
    _14651 = NOVALUE;
    if (_14652 == 0)
    {
        _14652 = NOVALUE;
        goto LE; // [341] 363
    }
    else{
        _14652 = NOVALUE;
    }

    /** scanner.e:512			errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_27main_path_20692)){
            _14653 = SEQ_PTR(_27main_path_20692)->length;
    }
    else {
        _14653 = 1;
    }
    _14654 = _14653 - 1;
    _14653 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_26347;
    RHS_Slice(_27main_path_20692, 1, _14654);
    goto LF; // [360] 373
LE: 

    /** scanner.e:514			errbuff = main_path*/
    RefDS(_27main_path_20692);
    DeRef(_errbuff_26347);
    _errbuff_26347 = _27main_path_20692;
LF: 

    /** scanner.e:516		if not find(errbuff, full_path) then*/
    _14656 = find_from(_errbuff_26347, _full_path_26346, 1);
    if (_14656 != 0)
    goto L10; // [380] 390
    _14656 = NOVALUE;

    /** scanner.e:517			full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_26347);
    Append(&_full_path_26346, _full_path_26346, _errbuff_26347);
L10: 

    /** scanner.e:520		conf_path = get_conf_dirs()*/
    _0 = _conf_path_26349;
    _conf_path_26349 = _46get_conf_dirs();
    DeRef(_0);

    /** scanner.e:521		if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_26349)){
            _14660 = SEQ_PTR(_conf_path_26349)->length;
    }
    else {
        _14660 = 1;
    }
    if (_14660 <= 0)
    goto L11; // [402] 509

    /** scanner.e:522			conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_26349);
    _0 = _conf_path_26349;
    _conf_path_26349 = _24split(_conf_path_26349, 59, 0, 0);
    DeRefDS(_0);

    /** scanner.e:523			for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_26349)){
            _14663 = SEQ_PTR(_conf_path_26349)->length;
    }
    else {
        _14663 = 1;
    }
    {
        object _i_26452;
        _i_26452 = 1;
L12: 
        if (_i_26452 > _14663){
            goto L13; // [424] 508
        }

        /** scanner.e:524				if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_conf_path_26349);
        _14664 = (object)*(((s1_ptr)_2)->base + _i_26452);
        if (IS_SEQUENCE(_14664)){
                _14665 = SEQ_PTR(_14664)->length;
        }
        else {
            _14665 = 1;
        }
        _2 = (object)SEQ_PTR(_14664);
        _14666 = (object)*(((s1_ptr)_2)->base + _14665);
        _14664 = NOVALUE;
        _14667 = find_from(_14666, _44SLASH_CHARS_20736, 1);
        _14666 = NOVALUE;
        if (_14667 == 0)
        {
            _14667 = NOVALUE;
            goto L14; // [451] 475
        }
        else{
            _14667 = NOVALUE;
        }

        /** scanner.e:525					errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_conf_path_26349);
        _14668 = (object)*(((s1_ptr)_2)->base + _i_26452);
        if (IS_SEQUENCE(_14668)){
                _14669 = SEQ_PTR(_14668)->length;
        }
        else {
            _14669 = 1;
        }
        _14670 = _14669 - 1;
        _14669 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26347;
        RHS_Slice(_14668, 1, _14670);
        _14668 = NOVALUE;
        goto L15; // [472] 484
L14: 

        /** scanner.e:527					errbuff = conf_path[i]*/
        DeRef(_errbuff_26347);
        _2 = (object)SEQ_PTR(_conf_path_26349);
        _errbuff_26347 = (object)*(((s1_ptr)_2)->base + _i_26452);
        Ref(_errbuff_26347);
L15: 

        /** scanner.e:529				if not find(errbuff, full_path) then*/
        _14673 = find_from(_errbuff_26347, _full_path_26346, 1);
        if (_14673 != 0)
        goto L16; // [491] 501
        _14673 = NOVALUE;

        /** scanner.e:530					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26347);
        Append(&_full_path_26346, _full_path_26346, _errbuff_26347);
L16: 

        /** scanner.e:532			end for*/
        _i_26452 = _i_26452 + 1;
        goto L12; // [503] 431
L13: 
        ;
    }
L11: 

    /** scanner.e:535		inc_path = getenv("EUINC")*/
    DeRef(_inc_path_26351);
    _inc_path_26351 = EGetEnv(_14628);

    /** scanner.e:536		if sequence(inc_path) then*/
    _14677 = IS_SEQUENCE(_inc_path_26351);
    if (_14677 == 0)
    {
        _14677 = NOVALUE;
        goto L17; // [519] 633
    }
    else{
        _14677 = NOVALUE;
    }

    /** scanner.e:537			if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_26351)){
            _14678 = SEQ_PTR(_inc_path_26351)->length;
    }
    else {
        _14678 = 1;
    }
    if (_14678 <= 0)
    goto L18; // [527] 632

    /** scanner.e:538				inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_26351);
    _0 = _inc_path_26351;
    _inc_path_26351 = _24split(_inc_path_26351, 59, 0, 0);
    DeRefi(_0);

    /** scanner.e:539				for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_26351)){
            _14681 = SEQ_PTR(_inc_path_26351)->length;
    }
    else {
        _14681 = 1;
    }
    {
        object _i_26480;
        _i_26480 = 1;
L19: 
        if (_i_26480 > _14681){
            goto L1A; // [547] 631
        }

        /** scanner.e:540					if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_inc_path_26351);
        _14682 = (object)*(((s1_ptr)_2)->base + _i_26480);
        if (IS_SEQUENCE(_14682)){
                _14683 = SEQ_PTR(_14682)->length;
        }
        else {
            _14683 = 1;
        }
        _2 = (object)SEQ_PTR(_14682);
        _14684 = (object)*(((s1_ptr)_2)->base + _14683);
        _14682 = NOVALUE;
        _14685 = find_from(_14684, _44SLASH_CHARS_20736, 1);
        _14684 = NOVALUE;
        if (_14685 == 0)
        {
            _14685 = NOVALUE;
            goto L1B; // [574] 598
        }
        else{
            _14685 = NOVALUE;
        }

        /** scanner.e:541						errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_inc_path_26351);
        _14686 = (object)*(((s1_ptr)_2)->base + _i_26480);
        if (IS_SEQUENCE(_14686)){
                _14687 = SEQ_PTR(_14686)->length;
        }
        else {
            _14687 = 1;
        }
        _14688 = _14687 - 1;
        _14687 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26347;
        RHS_Slice(_14686, 1, _14688);
        _14686 = NOVALUE;
        goto L1C; // [595] 607
L1B: 

        /** scanner.e:543						errbuff = inc_path[i]*/
        DeRef(_errbuff_26347);
        _2 = (object)SEQ_PTR(_inc_path_26351);
        _errbuff_26347 = (object)*(((s1_ptr)_2)->base + _i_26480);
        Ref(_errbuff_26347);
L1C: 

        /** scanner.e:545					if not find(errbuff, full_path) then*/
        _14691 = find_from(_errbuff_26347, _full_path_26346, 1);
        if (_14691 != 0)
        goto L1D; // [614] 624
        _14691 = NOVALUE;

        /** scanner.e:546						full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26347);
        Append(&_full_path_26346, _full_path_26346, _errbuff_26347);
L1D: 

        /** scanner.e:548				end for*/
        _i_26480 = _i_26480 + 1;
        goto L19; // [626] 554
L1A: 
        ;
    }
L18: 
L17: 

    /** scanner.e:552		if length(get_eudir()) > 0 then*/
    _14694 = _28get_eudir();
    if (IS_SEQUENCE(_14694)){
            _14695 = SEQ_PTR(_14694)->length;
    }
    else {
        _14695 = 1;
    }
    DeRef(_14694);
    _14694 = NOVALUE;
    if (_14695 <= 0)
    goto L1E; // [641] 669

    /** scanner.e:553			if not find(get_eudir(), full_path) then*/
    _14697 = _28get_eudir();
    _14698 = find_from(_14697, _full_path_26346, 1);
    DeRef(_14697);
    _14697 = NOVALUE;
    if (_14698 != 0)
    goto L1F; // [655] 668
    _14698 = NOVALUE;

    /** scanner.e:554				full_path = append(full_path, get_eudir())*/
    _14700 = _28get_eudir();
    Ref(_14700);
    Append(&_full_path_26346, _full_path_26346, _14700);
    DeRef(_14700);
    _14700 = NOVALUE;
L1F: 
L1E: 

    /** scanner.e:558		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26347);
    _errbuff_26347 = _5;

    /** scanner.e:559		for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_26346)){
            _14702 = SEQ_PTR(_full_path_26346)->length;
    }
    else {
        _14702 = 1;
    }
    {
        object _i_26512;
        _i_26512 = 1;
L20: 
        if (_i_26512 > _14702){
            goto L21; // [681] 713
        }

        /** scanner.e:560			errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (object)SEQ_PTR(_full_path_26346);
        _14704 = (object)*(((s1_ptr)_2)->base + _i_26512);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_14704);
        ((intptr_t*)_2)[1] = _14704;
        _14705 = MAKE_SEQ(_1);
        _14704 = NOVALUE;
        _14706 = EPrintf(-9999999, _14703, _14705);
        DeRefDS(_14705);
        _14705 = NOVALUE;
        Concat((object_ptr)&_errbuff_26347, _errbuff_26347, _14706);
        DeRefDS(_14706);
        _14706 = NOVALUE;

        /** scanner.e:561		end for*/
        _i_26512 = _i_26512 + 1;
        goto L20; // [708] 688
L21: 
        ;
    }

    /** scanner.e:563		CompileErr(CANT_FIND_1_IN_ANY_OF_2, {new_include_name, errbuff})*/
    RefDS(_errbuff_26347);
    RefDS(_27new_include_name_20694);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27new_include_name_20694;
    ((intptr_t *)_2)[2] = _errbuff_26347;
    _14708 = MAKE_SEQ(_1);
    _49CompileErr(52, _14708, 0);
    _14708 = NOVALUE;
    ;
}


object _61path_open()
{
    object _fh_26525 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:569		new_include_name = find_file(new_include_name)*/
    RefDS(_27new_include_name_20694);
    _0 = _61find_file(_27new_include_name_20694);
    DeRefDS(_27new_include_name_20694);
    _27new_include_name_20694 = _0;

    /** scanner.e:570		new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_27new_include_name_20694);
    _0 = _63maybe_preprocess(_27new_include_name_20694);
    DeRefDS(_27new_include_name_20694);
    _27new_include_name_20694 = _0;

    /** scanner.e:572		fh = open_locked(new_include_name)*/
    RefDS(_27new_include_name_20694);
    _fh_26525 = _28open_locked(_27new_include_name_20694);
    if (!IS_ATOM_INT(_fh_26525)) {
        _1 = (object)(DBL_PTR(_fh_26525)->dbl);
        DeRefDS(_fh_26525);
        _fh_26525 = _1;
    }

    /** scanner.e:573		return fh*/
    return _fh_26525;
    ;
}


object _61NameSpace_declaration(object _sym_26553)
{
    object _h_26554 = NOVALUE;
    object _14732 = NOVALUE;
    object _14730 = NOVALUE;
    object _14728 = NOVALUE;
    object _14726 = NOVALUE;
    object _14725 = NOVALUE;
    object _14724 = NOVALUE;
    object _14722 = NOVALUE;
    object _14721 = NOVALUE;
    object _14720 = NOVALUE;
    object _14719 = NOVALUE;
    object _14718 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_26553)) {
        _1 = (object)(DBL_PTR(_sym_26553)->dbl);
        DeRefDS(_sym_26553);
        _sym_26553 = _1;
    }

    /** scanner.e:594		DefinedYet(sym)*/
    _53DefinedYet(_sym_26553);

    /** scanner.e:595		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _14718 = (object)*(((s1_ptr)_2)->base + _sym_26553);
    _2 = (object)SEQ_PTR(_14718);
    _14719 = (object)*(((s1_ptr)_2)->base + 4);
    _14718 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 11;
    ((intptr_t*)_2)[4] = 7;
    _14720 = MAKE_SEQ(_1);
    _14721 = find_from(_14719, _14720, 1);
    _14719 = NOVALUE;
    DeRefDS(_14720);
    _14720 = NOVALUE;
    if (_14721 == 0)
    {
        _14721 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14721 = NOVALUE;
    }

    /** scanner.e:597			h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _14722 = (object)*(((s1_ptr)_2)->base + _sym_26553);
    _2 = (object)SEQ_PTR(_14722);
    _h_26554 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_26554)){
        _h_26554 = (object)DBL_PTR(_h_26554)->dbl;
    }
    _14722 = NOVALUE;

    /** scanner.e:599			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _14724 = (object)*(((s1_ptr)_2)->base + _sym_26553);
    _2 = (object)SEQ_PTR(_14724);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _14725 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _14725 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _14724 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _14726 = (object)*(((s1_ptr)_2)->base + _h_26554);
    Ref(_14725);
    Ref(_14726);
    _sym_26553 = _53NewEntry(_14725, 0, 0, -100, _h_26554, _14726, 0);
    _14725 = NOVALUE;
    _14726 = NOVALUE;
    if (!IS_ATOM_INT(_sym_26553)) {
        _1 = (object)(DBL_PTR(_sym_26553)->dbl);
        DeRefDS(_sym_26553);
        _sym_26553 = _1;
    }

    /** scanner.e:600			buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _2 = (object)(((s1_ptr)_2)->base + _h_26554);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_26553;
    DeRef(_1);
L1: 

    /** scanner.e:602		SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26553 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 5;
    DeRef(_1);
    _14728 = NOVALUE;

    /** scanner.e:603		SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26553 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14730 = NOVALUE;

    /** scanner.e:604		SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26553 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TOKEN_20214))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 523;
    DeRef(_1);
    _14732 = NOVALUE;

    /** scanner.e:605		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** scanner.e:606			num_routines += 1 -- order of ns declaration relative to routines*/
    _27num_routines_20580 = _27num_routines_20580 + 1;
L2: 

    /** scanner.e:609		return sym*/
    return _sym_26553;
    ;
}


void _61default_namespace()
{
    object _tok_26604 = NOVALUE;
    object _sym_26606 = NOVALUE;
    object _14756 = NOVALUE;
    object _14755 = NOVALUE;
    object _14753 = NOVALUE;
    object _14751 = NOVALUE;
    object _14748 = NOVALUE;
    object _14745 = NOVALUE;
    object _14743 = NOVALUE;
    object _14741 = NOVALUE;
    object _14740 = NOVALUE;
    object _14739 = NOVALUE;
    object _14738 = NOVALUE;
    object _14737 = NOVALUE;
    object _14736 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:618		tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_61scanner_rid_26600].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26604);
    _tok_26604 = _1;

    /** scanner.e:619		if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (object)SEQ_PTR(_tok_26604);
    _14736 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14736)) {
        _14737 = (_14736 == -100);
    }
    else {
        _14737 = binary_op(EQUALS, _14736, -100);
    }
    _14736 = NOVALUE;
    if (IS_ATOM_INT(_14737)) {
        if (_14737 == 0) {
            goto L1; // [23] 179
        }
    }
    else {
        if (DBL_PTR(_14737)->dbl == 0.0) {
            goto L1; // [23] 179
        }
    }
    _2 = (object)SEQ_PTR(_tok_26604);
    _14739 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_14739)){
        _14740 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14739)->dbl));
    }
    else{
        _14740 = (object)*(((s1_ptr)_2)->base + _14739);
    }
    _2 = (object)SEQ_PTR(_14740);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _14741 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _14741 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _14740 = NOVALUE;
    if (_14741 == _14742)
    _14743 = 1;
    else if (IS_ATOM_INT(_14741) && IS_ATOM_INT(_14742))
    _14743 = 0;
    else
    _14743 = (compare(_14741, _14742) == 0);
    _14741 = NOVALUE;
    if (_14743 == 0)
    {
        _14743 = NOVALUE;
        goto L1; // [50] 179
    }
    else{
        _14743 = NOVALUE;
    }

    /** scanner.e:621			tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_61scanner_rid_26600].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26604);
    _tok_26604 = _1;

    /** scanner.e:622			if tok[T_ID] != VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_26604);
    _14745 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _14745, -100)){
        _14745 = NOVALUE;
        goto L2; // [71] 85
    }
    _14745 = NOVALUE;

    /** scanner.e:623				CompileErr(MISSING_DEFAULT_NAMESPACE_QUALIFIER)*/
    RefDS(_22209);
    _49CompileErr(114, _22209, 0);
L2: 

    /** scanner.e:626			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_26604);
    _sym_26606 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_26606)){
        _sym_26606 = (object)DBL_PTR(_sym_26606)->dbl;
    }

    /** scanner.e:628			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26606 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _14748 = NOVALUE;

    /** scanner.e:629			sym  = NameSpace_declaration( sym )*/
    _sym_26606 = _61NameSpace_declaration(_sym_26606);
    if (!IS_ATOM_INT(_sym_26606)) {
        _1 = (object)(DBL_PTR(_sym_26606)->dbl);
        DeRefDS(_sym_26606);
        _sym_26606 = _1;
    }

    /** scanner.e:630			SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26606 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _14751 = NOVALUE;

    /** scanner.e:631			SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26606 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 13;
    DeRef(_1);
    _14753 = NOVALUE;

    /** scanner.e:633			default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _14755 = (object)*(((s1_ptr)_2)->base + _sym_26606);
    _2 = (object)SEQ_PTR(_14755);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _14756 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _14756 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _14755 = NOVALUE;
    Ref(_14756);
    _2 = (object)SEQ_PTR(_61default_namespaces_25931);
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14756;
    if( _1 != _14756 ){
        DeRef(_1);
    }
    _14756 = NOVALUE;
    goto L3; // [176] 187
L1: 

    /** scanner.e:637			bp = 1*/
    _49bp_49646 = 1;
L3: 

    /** scanner.e:640	end procedure*/
    DeRef(_tok_26604);
    DeRef(_14737);
    _14737 = NOVALUE;
    _14739 = NOVALUE;
    return;
    ;
}


void _61add_exports(object _from_file_26657, object _to_file_26658)
{
    object _exports_26659 = NOVALUE;
    object _direct_26660 = NOVALUE;
    object _14776 = NOVALUE;
    object _14775 = NOVALUE;
    object _14774 = NOVALUE;
    object _14773 = NOVALUE;
    object _14772 = NOVALUE;
    object _14770 = NOVALUE;
    object _14768 = NOVALUE;
    object _14767 = NOVALUE;
    object _14765 = NOVALUE;
    object _14764 = NOVALUE;
    object _14763 = NOVALUE;
    object _14761 = NOVALUE;
    object _14760 = NOVALUE;
    object _14759 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:645		direct = file_include[to_file]*/
    DeRef(_direct_26660);
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _direct_26660 = (object)*(((s1_ptr)_2)->base + _to_file_26658);
    Ref(_direct_26660);

    /** scanner.e:646		exports = file_public[from_file]*/
    DeRef(_exports_26659);
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _exports_26659 = (object)*(((s1_ptr)_2)->base + _from_file_26657);
    Ref(_exports_26659);

    /** scanner.e:647		for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_26659)){
            _14759 = SEQ_PTR(_exports_26659)->length;
    }
    else {
        _14759 = 1;
    }
    {
        object _i_26666;
        _i_26666 = 1;
L1: 
        if (_i_26666 > _14759){
            goto L2; // [30] 127
        }

        /** scanner.e:648			if not find( exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26659);
        _14760 = (object)*(((s1_ptr)_2)->base + _i_26666);
        _14761 = find_from(_14760, _direct_26660, 1);
        _14760 = NOVALUE;
        if (_14761 != 0)
        goto L3; // [48] 120
        _14761 = NOVALUE;

        /** scanner.e:649				if not find( -exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26659);
        _14763 = (object)*(((s1_ptr)_2)->base + _i_26666);
        if (IS_ATOM_INT(_14763)) {
            if ((uintptr_t)_14763 == (uintptr_t)HIGH_BITS){
                _14764 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14764 = - _14763;
            }
        }
        else {
            _14764 = unary_op(UMINUS, _14763);
        }
        _14763 = NOVALUE;
        _14765 = find_from(_14764, _direct_26660, 1);
        DeRef(_14764);
        _14764 = NOVALUE;
        if (_14765 != 0)
        goto L4; // [65] 82
        _14765 = NOVALUE;

        /** scanner.e:650					direct &= -exports[i]*/
        _2 = (object)SEQ_PTR(_exports_26659);
        _14767 = (object)*(((s1_ptr)_2)->base + _i_26666);
        if (IS_ATOM_INT(_14767)) {
            if ((uintptr_t)_14767 == (uintptr_t)HIGH_BITS){
                _14768 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14768 = - _14767;
            }
        }
        else {
            _14768 = unary_op(UMINUS, _14767);
        }
        _14767 = NOVALUE;
        if (IS_SEQUENCE(_direct_26660) && IS_ATOM(_14768)) {
            Ref(_14768);
            Append(&_direct_26660, _direct_26660, _14768);
        }
        else if (IS_ATOM(_direct_26660) && IS_SEQUENCE(_14768)) {
        }
        else {
            Concat((object_ptr)&_direct_26660, _direct_26660, _14768);
        }
        DeRef(_14768);
        _14768 = NOVALUE;
L4: 

        /** scanner.e:654				include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28include_matrix_11579 = MAKE_SEQ(_2);
        }
        _3 = (object)(_to_file_26658 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_exports_26659);
        _14772 = (object)*(((s1_ptr)_2)->base + _i_26666);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _14773 = (object)*(((s1_ptr)_2)->base + _to_file_26658);
        _2 = (object)SEQ_PTR(_exports_26659);
        _14774 = (object)*(((s1_ptr)_2)->base + _i_26666);
        _2 = (object)SEQ_PTR(_14773);
        if (!IS_ATOM_INT(_14774)){
            _14775 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14774)->dbl));
        }
        else{
            _14775 = (object)*(((s1_ptr)_2)->base + _14774);
        }
        _14773 = NOVALUE;
        if (IS_ATOM_INT(_14775)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14775;
                 _14776 = MAKE_UINT(tu);
            }
        }
        else {
            _14776 = binary_op(OR_BITS, 4, _14775);
        }
        _14775 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14772))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14772)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _14772);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14776;
        if( _1 != _14776 ){
            DeRef(_1);
        }
        _14776 = NOVALUE;
        _14770 = NOVALUE;
L3: 

        /** scanner.e:656		end for*/
        _i_26666 = _i_26666 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** scanner.e:657		file_include[to_file] = direct*/
    RefDS(_direct_26660);
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _2 = (object)(((s1_ptr)_2)->base + _to_file_26658);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _direct_26660;
    DeRef(_1);

    /** scanner.e:658	end procedure*/
    DeRef(_exports_26659);
    DeRefDS(_direct_26660);
    _14774 = NOVALUE;
    _14772 = NOVALUE;
    return;
    ;
}


void _61patch_exports(object _for_file_26693)
{
    object _export_len_26694 = NOVALUE;
    object _14787 = NOVALUE;
    object _14786 = NOVALUE;
    object _14784 = NOVALUE;
    object _14783 = NOVALUE;
    object _14782 = NOVALUE;
    object _14781 = NOVALUE;
    object _14779 = NOVALUE;
    object _14778 = NOVALUE;
    object _14777 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:663		for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_28file_include_11577)){
            _14777 = SEQ_PTR(_28file_include_11577)->length;
    }
    else {
        _14777 = 1;
    }
    {
        object _i_26696;
        _i_26696 = 1;
L1: 
        if (_i_26696 > _14777){
            goto L2; // [10] 99
        }

        /** scanner.e:664			if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (object)SEQ_PTR(_28file_include_11577);
        _14778 = (object)*(((s1_ptr)_2)->base + _i_26696);
        _14779 = find_from(_for_file_26693, _14778, 1);
        _14778 = NOVALUE;
        if (_14779 != 0) {
            goto L3; // [30] 53
        }
        if ((uintptr_t)_for_file_26693 == (uintptr_t)HIGH_BITS){
            _14781 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _14781 = - _for_file_26693;
        }
        _2 = (object)SEQ_PTR(_28file_include_11577);
        _14782 = (object)*(((s1_ptr)_2)->base + _i_26696);
        _14783 = find_from(_14781, _14782, 1);
        DeRef(_14781);
        _14781 = NOVALUE;
        _14782 = NOVALUE;
        if (_14783 == 0)
        {
            _14783 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14783 = NOVALUE;
        }
L3: 

        /** scanner.e:665				export_len = length( file_include[i] )*/
        _2 = (object)SEQ_PTR(_28file_include_11577);
        _14784 = (object)*(((s1_ptr)_2)->base + _i_26696);
        if (IS_SEQUENCE(_14784)){
                _export_len_26694 = SEQ_PTR(_14784)->length;
        }
        else {
            _export_len_26694 = 1;
        }
        _14784 = NOVALUE;

        /** scanner.e:666				add_exports( for_file, i )*/
        _61add_exports(_for_file_26693, _i_26696);

        /** scanner.e:667				if length( file_include[i] ) != export_len then*/
        _2 = (object)SEQ_PTR(_28file_include_11577);
        _14786 = (object)*(((s1_ptr)_2)->base + _i_26696);
        if (IS_SEQUENCE(_14786)){
                _14787 = SEQ_PTR(_14786)->length;
        }
        else {
            _14787 = 1;
        }
        _14786 = NOVALUE;
        if (_14787 == _export_len_26694)
        goto L5; // [81] 91

        /** scanner.e:669					patch_exports( i )*/
        _61patch_exports(_i_26696);
L5: 
L4: 

        /** scanner.e:672		end for*/
        _i_26696 = _i_26696 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** scanner.e:673	end procedure*/
    _14786 = NOVALUE;
    _14784 = NOVALUE;
    return;
    ;
}


void _61update_include_matrix(object _included_file_26718, object _from_file_26719)
{
    object _add_public_26729 = NOVALUE;
    object _px_26747 = NOVALUE;
    object _indirect_26806 = NOVALUE;
    object _mask_26809 = NOVALUE;
    object _ix_26820 = NOVALUE;
    object _indirect_file_26824 = NOVALUE;
    object _14863 = NOVALUE;
    object _14862 = NOVALUE;
    object _14860 = NOVALUE;
    object _14859 = NOVALUE;
    object _14858 = NOVALUE;
    object _14857 = NOVALUE;
    object _14856 = NOVALUE;
    object _14855 = NOVALUE;
    object _14854 = NOVALUE;
    object _14853 = NOVALUE;
    object _14852 = NOVALUE;
    object _14849 = NOVALUE;
    object _14847 = NOVALUE;
    object _14846 = NOVALUE;
    object _14845 = NOVALUE;
    object _14843 = NOVALUE;
    object _14841 = NOVALUE;
    object _14840 = NOVALUE;
    object _14838 = NOVALUE;
    object _14837 = NOVALUE;
    object _14836 = NOVALUE;
    object _14835 = NOVALUE;
    object _14834 = NOVALUE;
    object _14832 = NOVALUE;
    object _14831 = NOVALUE;
    object _14830 = NOVALUE;
    object _14829 = NOVALUE;
    object _14828 = NOVALUE;
    object _14827 = NOVALUE;
    object _14825 = NOVALUE;
    object _14824 = NOVALUE;
    object _14823 = NOVALUE;
    object _14821 = NOVALUE;
    object _14820 = NOVALUE;
    object _14819 = NOVALUE;
    object _14818 = NOVALUE;
    object _14817 = NOVALUE;
    object _14816 = NOVALUE;
    object _14815 = NOVALUE;
    object _14814 = NOVALUE;
    object _14813 = NOVALUE;
    object _14812 = NOVALUE;
    object _14811 = NOVALUE;
    object _14809 = NOVALUE;
    object _14808 = NOVALUE;
    object _14806 = NOVALUE;
    object _14804 = NOVALUE;
    object _14802 = NOVALUE;
    object _14801 = NOVALUE;
    object _14800 = NOVALUE;
    object _14799 = NOVALUE;
    object _14797 = NOVALUE;
    object _14796 = NOVALUE;
    object _14795 = NOVALUE;
    object _14793 = NOVALUE;
    object _14792 = NOVALUE;
    object _14791 = NOVALUE;
    object _14789 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:684		include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28include_matrix_11579 = MAKE_SEQ(_2);
    }
    _3 = (object)(_from_file_26719 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14791 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    _2 = (object)SEQ_PTR(_14791);
    _14792 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
    _14791 = NOVALUE;
    if (IS_ATOM_INT(_14792)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14792;
             _14793 = MAKE_UINT(tu);
        }
    }
    else {
        _14793 = binary_op(OR_BITS, 2, _14792);
    }
    _14792 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26718);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14793;
    if( _1 != _14793 ){
        DeRef(_1);
    }
    _14793 = NOVALUE;
    _14789 = NOVALUE;

    /** scanner.e:686		if public_include then*/
    if (_61public_include_25928 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** scanner.e:689			sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_26729);
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    _add_public_26729 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    Ref(_add_public_26729);

    /** scanner.e:690			for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_26729)){
            _14795 = SEQ_PTR(_add_public_26729)->length;
    }
    else {
        _14795 = 1;
    }
    {
        object _i_26733;
        _i_26733 = 1;
L2: 
        if (_i_26733 > _14795){
            goto L3; // [56] 107
        }

        /** scanner.e:692				include_matrix[add_public[i]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26729);
        _14796 = (object)*(((s1_ptr)_2)->base + _i_26733);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28include_matrix_11579 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14796))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14796)->dbl));
        else
        _3 = (object)(_14796 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26729);
        _14799 = (object)*(((s1_ptr)_2)->base + _i_26733);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!IS_ATOM_INT(_14799)){
            _14800 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14799)->dbl));
        }
        else{
            _14800 = (object)*(((s1_ptr)_2)->base + _14799);
        }
        _2 = (object)SEQ_PTR(_14800);
        _14801 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
        _14800 = NOVALUE;
        if (IS_ATOM_INT(_14801)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14801;
                 _14802 = MAKE_UINT(tu);
            }
        }
        else {
            _14802 = binary_op(OR_BITS, 4, _14801);
        }
        _14801 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14802;
        if( _1 != _14802 ){
            DeRef(_1);
        }
        _14802 = NOVALUE;
        _14797 = NOVALUE;

        /** scanner.e:695			end for*/
        _i_26733 = _i_26733 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** scanner.e:698			add_public = file_public_by[from_file]*/
    DeRef(_add_public_26729);
    _2 = (object)SEQ_PTR(_28file_public_by_11588);
    _add_public_26729 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    Ref(_add_public_26729);

    /** scanner.e:699			integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_26729)){
            _14804 = SEQ_PTR(_add_public_26729)->length;
    }
    else {
        _14804 = 1;
    }
    _px_26747 = _14804 + 1;
    _14804 = NOVALUE;

    /** scanner.e:700			while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_26729)){
            _14806 = SEQ_PTR(_add_public_26729)->length;
    }
    else {
        _14806 = 1;
    }
    if (_px_26747 > _14806)
    goto L5; // [134] 338

    /** scanner.e:701				include_matrix[add_public[px]][included_file] =*/
    _2 = (object)SEQ_PTR(_add_public_26729);
    _14808 = (object)*(((s1_ptr)_2)->base + _px_26747);
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28include_matrix_11579 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14808))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14808)->dbl));
    else
    _3 = (object)(_14808 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_add_public_26729);
    _14811 = (object)*(((s1_ptr)_2)->base + _px_26747);
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!IS_ATOM_INT(_14811)){
        _14812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14811)->dbl));
    }
    else{
        _14812 = (object)*(((s1_ptr)_2)->base + _14811);
    }
    _2 = (object)SEQ_PTR(_14812);
    _14813 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
    _14812 = NOVALUE;
    if (IS_ATOM_INT(_14813)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14813;
             _14814 = MAKE_UINT(tu);
        }
    }
    else {
        _14814 = binary_op(OR_BITS, 4, _14813);
    }
    _14813 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26718);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14814;
    if( _1 != _14814 ){
        DeRef(_1);
    }
    _14814 = NOVALUE;
    _14809 = NOVALUE;

    /** scanner.e:704				for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26729);
    _14815 = (object)*(((s1_ptr)_2)->base + _px_26747);
    _2 = (object)SEQ_PTR(_28file_public_by_11588);
    if (!IS_ATOM_INT(_14815)){
        _14816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14815)->dbl));
    }
    else{
        _14816 = (object)*(((s1_ptr)_2)->base + _14815);
    }
    if (IS_SEQUENCE(_14816)){
            _14817 = SEQ_PTR(_14816)->length;
    }
    else {
        _14817 = 1;
    }
    _14816 = NOVALUE;
    {
        object _i_26764;
        _i_26764 = 1;
L6: 
        if (_i_26764 > _14817){
            goto L7; // [190] 249
        }

        /** scanner.e:705					if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (object)SEQ_PTR(_add_public_26729);
        _14818 = (object)*(((s1_ptr)_2)->base + _px_26747);
        _2 = (object)SEQ_PTR(_28file_public_11584);
        if (!IS_ATOM_INT(_14818)){
            _14819 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14818)->dbl));
        }
        else{
            _14819 = (object)*(((s1_ptr)_2)->base + _14818);
        }
        _2 = (object)SEQ_PTR(_14819);
        _14820 = (object)*(((s1_ptr)_2)->base + _i_26764);
        _14819 = NOVALUE;
        _14821 = find_from(_14820, _add_public_26729, 1);
        _14820 = NOVALUE;
        if (_14821 != 0)
        goto L8; // [218] 242
        _14821 = NOVALUE;

        /** scanner.e:706						add_public &= file_public[add_public[px]][i]*/
        _2 = (object)SEQ_PTR(_add_public_26729);
        _14823 = (object)*(((s1_ptr)_2)->base + _px_26747);
        _2 = (object)SEQ_PTR(_28file_public_11584);
        if (!IS_ATOM_INT(_14823)){
            _14824 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14823)->dbl));
        }
        else{
            _14824 = (object)*(((s1_ptr)_2)->base + _14823);
        }
        _2 = (object)SEQ_PTR(_14824);
        _14825 = (object)*(((s1_ptr)_2)->base + _i_26764);
        _14824 = NOVALUE;
        if (IS_SEQUENCE(_add_public_26729) && IS_ATOM(_14825)) {
            Ref(_14825);
            Append(&_add_public_26729, _add_public_26729, _14825);
        }
        else if (IS_ATOM(_add_public_26729) && IS_SEQUENCE(_14825)) {
        }
        else {
            Concat((object_ptr)&_add_public_26729, _add_public_26729, _14825);
        }
        _14825 = NOVALUE;
L8: 

        /** scanner.e:708				end for*/
        _i_26764 = _i_26764 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** scanner.e:710				for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26729);
    _14827 = (object)*(((s1_ptr)_2)->base + _px_26747);
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    if (!IS_ATOM_INT(_14827)){
        _14828 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14827)->dbl));
    }
    else{
        _14828 = (object)*(((s1_ptr)_2)->base + _14827);
    }
    if (IS_SEQUENCE(_14828)){
            _14829 = SEQ_PTR(_14828)->length;
    }
    else {
        _14829 = 1;
    }
    _14828 = NOVALUE;
    {
        object _i_26782;
        _i_26782 = 1;
L9: 
        if (_i_26782 > _14829){
            goto LA; // [264] 327
        }

        /** scanner.e:711					include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26729);
        _14830 = (object)*(((s1_ptr)_2)->base + _px_26747);
        _2 = (object)SEQ_PTR(_28file_include_by_11586);
        if (!IS_ATOM_INT(_14830)){
            _14831 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14830)->dbl));
        }
        else{
            _14831 = (object)*(((s1_ptr)_2)->base + _14830);
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28include_matrix_11579 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14831))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14831)->dbl));
        else
        _3 = (object)(_14831 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26729);
        _14834 = (object)*(((s1_ptr)_2)->base + _px_26747);
        _2 = (object)SEQ_PTR(_28file_include_by_11586);
        if (!IS_ATOM_INT(_14834)){
            _14835 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14834)->dbl));
        }
        else{
            _14835 = (object)*(((s1_ptr)_2)->base + _14834);
        }
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!IS_ATOM_INT(_14835)){
            _14836 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14835)->dbl));
        }
        else{
            _14836 = (object)*(((s1_ptr)_2)->base + _14835);
        }
        _2 = (object)SEQ_PTR(_14836);
        _14837 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
        _14836 = NOVALUE;
        if (IS_ATOM_INT(_14837)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14837;
                 _14838 = MAKE_UINT(tu);
            }
        }
        else {
            _14838 = binary_op(OR_BITS, 4, _14837);
        }
        _14837 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26718);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14838;
        if( _1 != _14838 ){
            DeRef(_1);
        }
        _14838 = NOVALUE;
        _14832 = NOVALUE;

        /** scanner.e:713				end for*/
        _i_26782 = _i_26782 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** scanner.e:715				px += 1*/
    _px_26747 = _px_26747 + 1;

    /** scanner.e:716			end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_26729);
    _add_public_26729 = NOVALUE;

    /** scanner.e:721		if indirect_include[from_file][included_file] then*/
    _2 = (object)SEQ_PTR(_28indirect_include_11582);
    _14840 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    _2 = (object)SEQ_PTR(_14840);
    _14841 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
    _14840 = NOVALUE;
    if (_14841 == 0) {
        _14841 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14841) && DBL_PTR(_14841)->dbl == 0.0){
            _14841 = NOVALUE;
            goto LB; // [353] 545
        }
        _14841 = NOVALUE;
    }
    _14841 = NOVALUE;

    /** scanner.e:723			sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_26806);
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    _indirect_26806 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    Ref(_indirect_26806);

    /** scanner.e:725			sequence mask = include_matrix[included_file] != 0*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14843 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
    DeRef(_mask_26809);
    if (IS_ATOM_INT(_14843)) {
        _mask_26809 = (_14843 != 0);
    }
    else {
        _mask_26809 = binary_op(NOTEQ, _14843, 0);
    }
    _14843 = NOVALUE;

    /** scanner.e:726			include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14845 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    _14846 = binary_op(OR_BITS, _14845, _mask_26809);
    _14845 = NOVALUE;
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _2 = (object)(((s1_ptr)_2)->base + _from_file_26719);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14846;
    if( _1 != _14846 ){
        DeRef(_1);
    }
    _14846 = NOVALUE;

    /** scanner.e:727			mask = include_matrix[from_file] != 0*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14847 = (object)*(((s1_ptr)_2)->base + _from_file_26719);
    DeRefDS(_mask_26809);
    if (IS_ATOM_INT(_14847)) {
        _mask_26809 = (_14847 != 0);
    }
    else {
        _mask_26809 = binary_op(NOTEQ, _14847, 0);
    }
    _14847 = NOVALUE;

    /** scanner.e:728			integer ix = 1*/
    _ix_26820 = 1;

    /** scanner.e:729			while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_26806)){
            _14849 = SEQ_PTR(_indirect_26806)->length;
    }
    else {
        _14849 = 1;
    }
    if (_ix_26820 > _14849)
    goto LD; // [425] 544

    /** scanner.e:730				integer indirect_file = indirect[ix]*/
    _2 = (object)SEQ_PTR(_indirect_26806);
    _indirect_file_26824 = (object)*(((s1_ptr)_2)->base + _ix_26820);
    if (!IS_ATOM_INT(_indirect_file_26824))
    _indirect_file_26824 = (object)DBL_PTR(_indirect_file_26824)->dbl;

    /** scanner.e:731				if indirect_include[indirect_file][included_file] then*/
    _2 = (object)SEQ_PTR(_28indirect_include_11582);
    _14852 = (object)*(((s1_ptr)_2)->base + _indirect_file_26824);
    _2 = (object)SEQ_PTR(_14852);
    _14853 = (object)*(((s1_ptr)_2)->base + _included_file_26718);
    _14852 = NOVALUE;
    if (_14853 == 0) {
        _14853 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14853) && DBL_PTR(_14853)->dbl == 0.0){
            _14853 = NOVALUE;
            goto LE; // [447] 531
        }
        _14853 = NOVALUE;
    }
    _14853 = NOVALUE;

    /** scanner.e:732					include_matrix[indirect_file] =*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14854 = (object)*(((s1_ptr)_2)->base + _indirect_file_26824);
    _14855 = binary_op(OR_BITS, _mask_26809, _14854);
    _14854 = NOVALUE;
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _2 = (object)(((s1_ptr)_2)->base + _indirect_file_26824);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14855;
    if( _1 != _14855 ){
        DeRef(_1);
    }
    _14855 = NOVALUE;

    /** scanner.e:734					for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    _14856 = (object)*(((s1_ptr)_2)->base + _indirect_file_26824);
    if (IS_SEQUENCE(_14856)){
            _14857 = SEQ_PTR(_14856)->length;
    }
    else {
        _14857 = 1;
    }
    _14856 = NOVALUE;
    {
        object _i_26835;
        _i_26835 = 1;
LF: 
        if (_i_26835 > _14857){
            goto L10; // [479] 530
        }

        /** scanner.e:736						if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (object)SEQ_PTR(_28file_include_by_11586);
        _14858 = (object)*(((s1_ptr)_2)->base + _indirect_file_26824);
        _2 = (object)SEQ_PTR(_14858);
        _14859 = (object)*(((s1_ptr)_2)->base + _i_26835);
        _14858 = NOVALUE;
        _14860 = find_from(_14859, _indirect_26806, 1);
        _14859 = NOVALUE;
        if (_14860 != 0)
        goto L11; // [503] 523
        _14860 = NOVALUE;

        /** scanner.e:737							indirect &= file_include_by[indirect_file][i]*/
        _2 = (object)SEQ_PTR(_28file_include_by_11586);
        _14862 = (object)*(((s1_ptr)_2)->base + _indirect_file_26824);
        _2 = (object)SEQ_PTR(_14862);
        _14863 = (object)*(((s1_ptr)_2)->base + _i_26835);
        _14862 = NOVALUE;
        if (IS_SEQUENCE(_indirect_26806) && IS_ATOM(_14863)) {
            Ref(_14863);
            Append(&_indirect_26806, _indirect_26806, _14863);
        }
        else if (IS_ATOM(_indirect_26806) && IS_SEQUENCE(_14863)) {
        }
        else {
            Concat((object_ptr)&_indirect_26806, _indirect_26806, _14863);
        }
        _14863 = NOVALUE;
L11: 

        /** scanner.e:740					end for*/
        _i_26835 = _i_26835 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** scanner.e:742				ix += 1*/
    _ix_26820 = _ix_26820 + 1;

    /** scanner.e:743			end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_26806);
    _indirect_26806 = NOVALUE;
    DeRef(_mask_26809);
    _mask_26809 = NOVALUE;

    /** scanner.e:746		public_include = FALSE*/
    _61public_include_25928 = _9FALSE_439;

    /** scanner.e:747	end procedure*/
    _14856 = NOVALUE;
    _14828 = NOVALUE;
    _14834 = NOVALUE;
    _14816 = NOVALUE;
    _14815 = NOVALUE;
    _14823 = NOVALUE;
    _14811 = NOVALUE;
    _14818 = NOVALUE;
    _14827 = NOVALUE;
    _14799 = NOVALUE;
    _14831 = NOVALUE;
    _14835 = NOVALUE;
    _14830 = NOVALUE;
    _14808 = NOVALUE;
    _14796 = NOVALUE;
    return;
    ;
}


void _61add_include_by(object _by_file_26853, object _included_file_26854, object _is_public_26855)
{
    object _14910 = NOVALUE;
    object _14909 = NOVALUE;
    object _14908 = NOVALUE;
    object _14906 = NOVALUE;
    object _14905 = NOVALUE;
    object _14904 = NOVALUE;
    object _14903 = NOVALUE;
    object _14901 = NOVALUE;
    object _14900 = NOVALUE;
    object _14899 = NOVALUE;
    object _14898 = NOVALUE;
    object _14897 = NOVALUE;
    object _14896 = NOVALUE;
    object _14895 = NOVALUE;
    object _14894 = NOVALUE;
    object _14892 = NOVALUE;
    object _14891 = NOVALUE;
    object _14890 = NOVALUE;
    object _14889 = NOVALUE;
    object _14887 = NOVALUE;
    object _14886 = NOVALUE;
    object _14885 = NOVALUE;
    object _14884 = NOVALUE;
    object _14882 = NOVALUE;
    object _14881 = NOVALUE;
    object _14880 = NOVALUE;
    object _14879 = NOVALUE;
    object _14877 = NOVALUE;
    object _14876 = NOVALUE;
    object _14875 = NOVALUE;
    object _14874 = NOVALUE;
    object _14873 = NOVALUE;
    object _14871 = NOVALUE;
    object _14870 = NOVALUE;
    object _14869 = NOVALUE;
    object _14868 = NOVALUE;
    object _14866 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:750		include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28include_matrix_11579 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26853 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14868 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
    _2 = (object)SEQ_PTR(_14868);
    _14869 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    _14868 = NOVALUE;
    if (IS_ATOM_INT(_14869)) {
        {uintptr_t tu;
             tu = (uintptr_t)2 | (uintptr_t)_14869;
             _14870 = MAKE_UINT(tu);
        }
    }
    else {
        _14870 = binary_op(OR_BITS, 2, _14869);
    }
    _14869 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26854);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14870;
    if( _1 != _14870 ){
        DeRef(_1);
    }
    _14870 = NOVALUE;
    _14866 = NOVALUE;

    /** scanner.e:751		if is_public then*/
    if (_is_public_26855 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** scanner.e:752			include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28include_matrix_11579 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26853 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14873 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
    _2 = (object)SEQ_PTR(_14873);
    _14874 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    _14873 = NOVALUE;
    if (IS_ATOM_INT(_14874)) {
        {uintptr_t tu;
             tu = (uintptr_t)4 | (uintptr_t)_14874;
             _14875 = MAKE_UINT(tu);
        }
    }
    else {
        _14875 = binary_op(OR_BITS, 4, _14874);
    }
    _14874 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26854);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14875;
    if( _1 != _14875 ){
        DeRef(_1);
    }
    _14875 = NOVALUE;
    _14871 = NOVALUE;
L1: 

    /** scanner.e:754		if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    _14876 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    _14877 = find_from(_by_file_26853, _14876, 1);
    _14876 = NOVALUE;
    if (_14877 != 0)
    goto L2; // [84] 104
    _14877 = NOVALUE;

    /** scanner.e:755			file_include_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    _14879 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    if (IS_SEQUENCE(_14879) && IS_ATOM(_by_file_26853)) {
        Append(&_14880, _14879, _by_file_26853);
    }
    else if (IS_ATOM(_14879) && IS_SEQUENCE(_by_file_26853)) {
    }
    else {
        Concat((object_ptr)&_14880, _14879, _by_file_26853);
        _14879 = NOVALUE;
    }
    _14879 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_include_by_11586);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26854);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14880;
    if( _1 != _14880 ){
        DeRef(_1);
    }
    _14880 = NOVALUE;
L2: 

    /** scanner.e:758		if not find( included_file, file_include[by_file] ) then*/
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14881 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
    _14882 = find_from(_included_file_26854, _14881, 1);
    _14881 = NOVALUE;
    if (_14882 != 0)
    goto L3; // [117] 137
    _14882 = NOVALUE;

    /** scanner.e:759			file_include[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14884 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
    if (IS_SEQUENCE(_14884) && IS_ATOM(_included_file_26854)) {
        Append(&_14885, _14884, _included_file_26854);
    }
    else if (IS_ATOM(_14884) && IS_SEQUENCE(_included_file_26854)) {
    }
    else {
        Concat((object_ptr)&_14885, _14884, _included_file_26854);
        _14884 = NOVALUE;
    }
    _14884 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26853);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14885;
    if( _1 != _14885 ){
        DeRef(_1);
    }
    _14885 = NOVALUE;
L3: 

    /** scanner.e:762		if is_public then*/
    if (_is_public_26855 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** scanner.e:763			if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_28file_public_by_11588);
    _14886 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    _14887 = find_from(_by_file_26853, _14886, 1);
    _14886 = NOVALUE;
    if (_14887 != 0)
    goto L5; // [155] 175
    _14887 = NOVALUE;

    /** scanner.e:764				file_public_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_28file_public_by_11588);
    _14889 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    if (IS_SEQUENCE(_14889) && IS_ATOM(_by_file_26853)) {
        Append(&_14890, _14889, _by_file_26853);
    }
    else if (IS_ATOM(_14889) && IS_SEQUENCE(_by_file_26853)) {
    }
    else {
        Concat((object_ptr)&_14890, _14889, _by_file_26853);
        _14889 = NOVALUE;
    }
    _14889 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_public_by_11588);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26854);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14890;
    if( _1 != _14890 ){
        DeRef(_1);
    }
    _14890 = NOVALUE;
L5: 

    /** scanner.e:767			if not find( included_file, file_public[by_file] ) then*/
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _14891 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
    _14892 = find_from(_included_file_26854, _14891, 1);
    _14891 = NOVALUE;
    if (_14892 != 0)
    goto L6; // [188] 208
    _14892 = NOVALUE;

    /** scanner.e:768				file_public[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _14894 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
    if (IS_SEQUENCE(_14894) && IS_ATOM(_included_file_26854)) {
        Append(&_14895, _14894, _included_file_26854);
    }
    else if (IS_ATOM(_14894) && IS_SEQUENCE(_included_file_26854)) {
    }
    else {
        Concat((object_ptr)&_14895, _14894, _included_file_26854);
        _14894 = NOVALUE;
    }
    _14894 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26853);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14895;
    if( _1 != _14895 ){
        DeRef(_1);
    }
    _14895 = NOVALUE;
L6: 
L4: 

    /** scanner.e:772		for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    _14896 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
    if (IS_SEQUENCE(_14896)){
            _14897 = SEQ_PTR(_14896)->length;
    }
    else {
        _14897 = 1;
    }
    _14896 = NOVALUE;
    {
        object _propagate_26907;
        _propagate_26907 = 1;
L7: 
        if (_propagate_26907 > _14897){
            goto L8; // [220] 320
        }

        /** scanner.e:773			if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _14898 = (object)*(((s1_ptr)_2)->base + _included_file_26854);
        _2 = (object)SEQ_PTR(_14898);
        _14899 = (object)*(((s1_ptr)_2)->base + _propagate_26907);
        _14898 = NOVALUE;
        if (IS_ATOM_INT(_14899)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 & (uintptr_t)_14899;
                 _14900 = MAKE_UINT(tu);
            }
        }
        else {
            _14900 = binary_op(AND_BITS, 4, _14899);
        }
        _14899 = NOVALUE;
        if (_14900 == 0) {
            DeRef(_14900);
            _14900 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14900) && DBL_PTR(_14900)->dbl == 0.0){
                DeRef(_14900);
                _14900 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14900);
            _14900 = NOVALUE;
        }
        DeRef(_14900);
        _14900 = NOVALUE;

        /** scanner.e:774				include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28include_matrix_11579 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26853 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _14903 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
        _2 = (object)SEQ_PTR(_14903);
        _14904 = (object)*(((s1_ptr)_2)->base + _propagate_26907);
        _14903 = NOVALUE;
        if (IS_ATOM_INT(_14904)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2 | (uintptr_t)_14904;
                 _14905 = MAKE_UINT(tu);
            }
        }
        else {
            _14905 = binary_op(OR_BITS, 2, _14904);
        }
        _14904 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26907);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14905;
        if( _1 != _14905 ){
            DeRef(_1);
        }
        _14905 = NOVALUE;
        _14901 = NOVALUE;

        /** scanner.e:775				if is_public then*/
        if (_is_public_26855 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** scanner.e:776					include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28include_matrix_11579 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26853 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _14908 = (object)*(((s1_ptr)_2)->base + _by_file_26853);
        _2 = (object)SEQ_PTR(_14908);
        _14909 = (object)*(((s1_ptr)_2)->base + _propagate_26907);
        _14908 = NOVALUE;
        if (IS_ATOM_INT(_14909)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4 | (uintptr_t)_14909;
                 _14910 = MAKE_UINT(tu);
            }
        }
        else {
            _14910 = binary_op(OR_BITS, 4, _14909);
        }
        _14909 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26907);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14910;
        if( _1 != _14910 ){
            DeRef(_1);
        }
        _14910 = NOVALUE;
        _14906 = NOVALUE;
LA: 
L9: 

        /** scanner.e:779		end for*/
        _propagate_26907 = _propagate_26907 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** scanner.e:780	end procedure*/
    _14896 = NOVALUE;
    return;
    ;
}


void _61IncludePush()
{
    object _new_file_handle_26936 = NOVALUE;
    object _old_file_no_26937 = NOVALUE;
    object _new_hash_26938 = NOVALUE;
    object _idx_26939 = NOVALUE;
    object _14997 = NOVALUE;
    object _14994 = NOVALUE;
    object _14992 = NOVALUE;
    object _14991 = NOVALUE;
    object _14990 = NOVALUE;
    object _14988 = NOVALUE;
    object _14987 = NOVALUE;
    object _14981 = NOVALUE;
    object _14980 = NOVALUE;
    object _14979 = NOVALUE;
    object _14978 = NOVALUE;
    object _14977 = NOVALUE;
    object _14976 = NOVALUE;
    object _14975 = NOVALUE;
    object _14972 = NOVALUE;
    object _14970 = NOVALUE;
    object _14968 = NOVALUE;
    object _14967 = NOVALUE;
    object _14966 = NOVALUE;
    object _14964 = NOVALUE;
    object _14963 = NOVALUE;
    object _14961 = NOVALUE;
    object _14960 = NOVALUE;
    object _14958 = NOVALUE;
    object _14957 = NOVALUE;
    object _14956 = NOVALUE;
    object _14955 = NOVALUE;
    object _14954 = NOVALUE;
    object _14953 = NOVALUE;
    object _14952 = NOVALUE;
    object _14948 = NOVALUE;
    object _14946 = NOVALUE;
    object _14945 = NOVALUE;
    object _14944 = NOVALUE;
    object _14943 = NOVALUE;
    object _14942 = NOVALUE;
    object _14941 = NOVALUE;
    object _14940 = NOVALUE;
    object _14939 = NOVALUE;
    object _14938 = NOVALUE;
    object _14936 = NOVALUE;
    object _14935 = NOVALUE;
    object _14934 = NOVALUE;
    object _14932 = NOVALUE;
    object _14931 = NOVALUE;
    object _14930 = NOVALUE;
    object _14929 = NOVALUE;
    object _14927 = NOVALUE;
    object _14926 = NOVALUE;
    object _14925 = NOVALUE;
    object _14924 = NOVALUE;
    object _14923 = NOVALUE;
    object _14921 = NOVALUE;
    object _14920 = NOVALUE;
    object _14919 = NOVALUE;
    object _14918 = NOVALUE;
    object _14916 = NOVALUE;
    object _14912 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:788		start_include = FALSE*/
    _61start_include_25925 = _9FALSE_439;

    /** scanner.e:790		new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_26936 = _61path_open();
    if (!IS_ATOM_INT(_new_file_handle_26936)) {
        _1 = (object)(DBL_PTR(_new_file_handle_26936)->dbl);
        DeRefDS(_new_file_handle_26936);
        _new_file_handle_26936 = _1;
    }

    /** scanner.e:792		new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_27new_include_name_20694);
    _14912 = _15canonical_path(_27new_include_name_20694, 0, 2);
    DeRef(_new_hash_26938);
    _new_hash_26938 = calc_hash(_14912, -5);
    DeRef(_14912);
    _14912 = NOVALUE;

    /** scanner.e:794		idx = find(new_hash, known_files_hash)*/
    _idx_26939 = find_from(_new_hash_26938, _28known_files_hash_11574, 1);

    /** scanner.e:795		if idx then*/
    if (_idx_26939 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** scanner.e:797			if new_include_space != 0 then*/
    if (_61new_include_space_25923 == 0)
    goto L2; // [49] 71

    /** scanner.e:798				SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_61new_include_space_25923 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26939;
    DeRef(_1);
    _14916 = NOVALUE;
L2: 

    /** scanner.e:801			close(new_file_handle)*/
    EClose(_new_file_handle_26936);

    /** scanner.e:803			if find( -idx, file_include[current_file_no] ) then*/
    if ((uintptr_t)_idx_26939 == (uintptr_t)HIGH_BITS){
        _14918 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14918 = - _idx_26939;
    }
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14919 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _14920 = find_from(_14918, _14919, 1);
    DeRef(_14918);
    _14918 = NOVALUE;
    _14919 = NOVALUE;
    if (_14920 == 0)
    {
        _14920 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14920 = NOVALUE;
    }

    /** scanner.e:805				file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (object)SEQ_PTR(_28file_include_11577);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28file_include_11577 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27current_file_no_20571 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_idx_26939 == (uintptr_t)HIGH_BITS){
        _14923 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14923 = - _idx_26939;
    }
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14924 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _14925 = find_from(_14923, _14924, 1);
    DeRef(_14923);
    _14923 = NOVALUE;
    _14924 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14925);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26939;
    DeRef(_1);
    _14921 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** scanner.e:809			elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14926 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _14927 = find_from(_idx_26939, _14926, 1);
    _14926 = NOVALUE;
    if (_14927 != 0)
    goto L5; // [145] 227
    _14927 = NOVALUE;

    /** scanner.e:811				file_include[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14929 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_14929) && IS_ATOM(_idx_26939)) {
        Append(&_14930, _14929, _idx_26939);
    }
    else if (IS_ATOM(_14929) && IS_SEQUENCE(_idx_26939)) {
    }
    else {
        Concat((object_ptr)&_14930, _14929, _idx_26939);
        _14929 = NOVALUE;
    }
    _14929 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14930;
    if( _1 != _14930 ){
        DeRef(_1);
    }
    _14930 = NOVALUE;

    /** scanner.e:814				add_exports( idx, current_file_no )*/
    _61add_exports(_idx_26939, _27current_file_no_20571);

    /** scanner.e:816				if public_include then*/
    if (_61public_include_25928 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** scanner.e:818					if not find( idx, file_public[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _14931 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _14932 = find_from(_idx_26939, _14931, 1);
    _14931 = NOVALUE;
    if (_14932 != 0)
    goto L7; // [196] 225
    _14932 = NOVALUE;

    /** scanner.e:819						file_public[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _14934 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_14934) && IS_ATOM(_idx_26939)) {
        Append(&_14935, _14934, _idx_26939);
    }
    else if (IS_ATOM(_14934) && IS_SEQUENCE(_idx_26939)) {
    }
    else {
        Concat((object_ptr)&_14935, _14934, _idx_26939);
        _14934 = NOVALUE;
    }
    _14934 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14935;
    if( _1 != _14935 ){
        DeRef(_1);
    }
    _14935 = NOVALUE;

    /** scanner.e:820						patch_exports( current_file_no )*/
    _61patch_exports(_27current_file_no_20571);
L7: 
L6: 
L5: 
L4: 

    /** scanner.e:825			indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_28indirect_include_11582);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28indirect_include_11582 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27current_file_no_20571 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _idx_26939);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27OpIndirectInclude_20647;
    DeRef(_1);
    _14936 = NOVALUE;

    /** scanner.e:826			add_include_by( current_file_no, idx, public_include )*/
    _61add_include_by(_27current_file_no_20571, _idx_26939, _61public_include_25928);

    /** scanner.e:827			update_include_matrix( idx, current_file_no )*/
    _61update_include_matrix(_idx_26939, _27current_file_no_20571);

    /** scanner.e:828			public_include = FALSE*/
    _61public_include_25928 = _9FALSE_439;

    /** scanner.e:829			read_line() -- we can't return without reading a line first*/
    _61read_line();

    /** scanner.e:830			if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (object)SEQ_PTR(_28file_include_depend_11576);
    _14938 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _14939 = find_from(_idx_26939, _14938, 1);
    _14938 = NOVALUE;
    _14940 = (_14939 == 0);
    _14939 = NOVALUE;
    if (_14940 == 0) {
        goto L8; // [293] 329
    }
    _2 = (object)SEQ_PTR(_28finished_files_11575);
    _14942 = (object)*(((s1_ptr)_2)->base + _idx_26939);
    _14943 = (_14942 == 0);
    _14942 = NOVALUE;
    if (_14943 == 0)
    {
        DeRef(_14943);
        _14943 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14943);
        _14943 = NOVALUE;
    }

    /** scanner.e:831				file_include_depend[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_28file_include_depend_11576);
    _14944 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_14944) && IS_ATOM(_idx_26939)) {
        Append(&_14945, _14944, _idx_26939);
    }
    else if (IS_ATOM(_14944) && IS_SEQUENCE(_idx_26939)) {
    }
    else {
        Concat((object_ptr)&_14945, _14944, _idx_26939);
        _14944 = NOVALUE;
    }
    _14944 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_include_depend_11576);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28file_include_depend_11576 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14945;
    if( _1 != _14945 ){
        DeRef(_1);
    }
    _14945 = NOVALUE;
L8: 

    /** scanner.e:833			return -- ignore it*/
    DeRef(_new_hash_26938);
    DeRef(_14940);
    _14940 = NOVALUE;
    return;
L1: 

    /** scanner.e:836		if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_61IncludeStk_25934)){
            _14946 = SEQ_PTR(_61IncludeStk_25934)->length;
    }
    else {
        _14946 = 1;
    }
    if (_14946 < 30)
    goto L9; // [342] 356

    /** scanner.e:837			CompileErr(INCLUDES_ARE_NESTED_TOO_DEEPLY)*/
    RefDS(_22209);
    _49CompileErr(104, _22209, 0);
L9: 

    /** scanner.e:840		IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27current_file_no_20571;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    ((intptr_t*)_2)[3] = _27src_file_20693;
    ((intptr_t*)_2)[4] = _27file_start_sym_20577;
    ((intptr_t*)_2)[5] = _27OpWarning_20639;
    ((intptr_t*)_2)[6] = _27OpTrace_20641;
    ((intptr_t*)_2)[7] = _27OpTypeCheck_20642;
    ((intptr_t*)_2)[8] = _27OpProfileTime_20644;
    ((intptr_t*)_2)[9] = _27OpProfileStatement_20643;
    RefDS(_27OpDefines_20645);
    ((intptr_t*)_2)[10] = _27OpDefines_20645;
    ((intptr_t*)_2)[11] = _27prev_OpWarning_20640;
    ((intptr_t*)_2)[12] = _27OpInline_20646;
    ((intptr_t*)_2)[13] = _27OpIndirectInclude_20647;
    ((intptr_t*)_2)[14] = _27putback_fwd_line_number_20574;
    Ref(_49putback_ForwardLine_49644);
    ((intptr_t*)_2)[15] = _49putback_ForwardLine_49644;
    ((intptr_t*)_2)[16] = _49putback_forward_bp_49648;
    ((intptr_t*)_2)[17] = _27last_fwd_line_number_20575;
    Ref(_49last_ForwardLine_49645);
    ((intptr_t*)_2)[18] = _49last_ForwardLine_49645;
    ((intptr_t*)_2)[19] = _49last_forward_bp_49649;
    Ref(_49ThisLine_49642);
    ((intptr_t*)_2)[20] = _49ThisLine_49642;
    ((intptr_t*)_2)[21] = _27fwd_line_number_20573;
    ((intptr_t*)_2)[22] = _49forward_bp_49647;
    _14948 = MAKE_SEQ(_1);
    RefDS(_14948);
    Append(&_61IncludeStk_25934, _61IncludeStk_25934, _14948);
    DeRefDS(_14948);
    _14948 = NOVALUE;

    /** scanner.e:864		file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_28file_include_11577, _28file_include_11577, _5);

    /** scanner.e:865		file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_28file_include_by_11586, _28file_include_by_11586, _5);

    /** scanner.e:866		for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_28include_matrix_11579)){
            _14952 = SEQ_PTR(_28include_matrix_11579)->length;
    }
    else {
        _14952 = 1;
    }
    {
        object _i_27052;
        _i_27052 = 1;
LA: 
        if (_i_27052 > _14952){
            goto LB; // [460] 506
        }

        /** scanner.e:867			include_matrix[i]   &= 0*/
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _14953 = (object)*(((s1_ptr)_2)->base + _i_27052);
        if (IS_SEQUENCE(_14953) && IS_ATOM(0)) {
            Append(&_14954, _14953, 0);
        }
        else if (IS_ATOM(_14953) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14954, _14953, 0);
            _14953 = NOVALUE;
        }
        _14953 = NOVALUE;
        _2 = (object)SEQ_PTR(_28include_matrix_11579);
        _2 = (object)(((s1_ptr)_2)->base + _i_27052);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14954;
        if( _1 != _14954 ){
            DeRef(_1);
        }
        _14954 = NOVALUE;

        /** scanner.e:868			indirect_include[i] &= 0*/
        _2 = (object)SEQ_PTR(_28indirect_include_11582);
        _14955 = (object)*(((s1_ptr)_2)->base + _i_27052);
        if (IS_SEQUENCE(_14955) && IS_ATOM(0)) {
            Append(&_14956, _14955, 0);
        }
        else if (IS_ATOM(_14955) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14956, _14955, 0);
            _14955 = NOVALUE;
        }
        _14955 = NOVALUE;
        _2 = (object)SEQ_PTR(_28indirect_include_11582);
        _2 = (object)(((s1_ptr)_2)->base + _i_27052);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14956;
        if( _1 != _14956 ){
            DeRef(_1);
        }
        _14956 = NOVALUE;

        /** scanner.e:869		end for*/
        _i_27052 = _i_27052 + 1;
        goto LA; // [501] 467
LB: 
        ;
    }

    /** scanner.e:870		include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_28file_include_11577)){
            _14957 = SEQ_PTR(_28file_include_11577)->length;
    }
    else {
        _14957 = 1;
    }
    _14958 = Repeat(0, _14957);
    _14957 = NOVALUE;
    RefDS(_14958);
    Append(&_28include_matrix_11579, _28include_matrix_11579, _14958);
    DeRefDS(_14958);
    _14958 = NOVALUE;

    /** scanner.e:871		include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_28include_matrix_11579)){
            _14960 = SEQ_PTR(_28include_matrix_11579)->length;
    }
    else {
        _14960 = 1;
    }
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28include_matrix_11579 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14960 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14963 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14963 = 1;
    }
    _14961 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14963);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14961 = NOVALUE;

    /** scanner.e:872		include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (object)SEQ_PTR(_28include_matrix_11579);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28include_matrix_11579 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27current_file_no_20571 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14966 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14966 = 1;
    }
    _14964 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14966);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _14964 = NOVALUE;

    /** scanner.e:874		indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_28file_include_11577)){
            _14967 = SEQ_PTR(_28file_include_11577)->length;
    }
    else {
        _14967 = 1;
    }
    _14968 = Repeat(0, _14967);
    _14967 = NOVALUE;
    RefDS(_14968);
    Append(&_28indirect_include_11582, _28indirect_include_11582, _14968);
    DeRefDS(_14968);
    _14968 = NOVALUE;

    /** scanner.e:875		indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_28indirect_include_11582);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28indirect_include_11582 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27current_file_no_20571 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14972 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14972 = 1;
    }
    _14970 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14972);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27OpIndirectInclude_20647;
    DeRef(_1);
    _14970 = NOVALUE;

    /** scanner.e:876		OpIndirectInclude = 1*/
    _27OpIndirectInclude_20647 = 1;

    /** scanner.e:878		file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_28file_public_11584, _28file_public_11584, _5);

    /** scanner.e:879		file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_28file_public_by_11588, _28file_public_by_11588, _5);

    /** scanner.e:880		file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_28file_include_11577)){
            _14975 = SEQ_PTR(_28file_include_11577)->length;
    }
    else {
        _14975 = 1;
    }
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _14976 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_14976) && IS_ATOM(_14975)) {
        Append(&_14977, _14976, _14975);
    }
    else if (IS_ATOM(_14976) && IS_SEQUENCE(_14975)) {
    }
    else {
        Concat((object_ptr)&_14977, _14976, _14975);
        _14976 = NOVALUE;
    }
    _14976 = NOVALUE;
    _14975 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_include_11577);
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14977;
    if( _1 != _14977 ){
        DeRef(_1);
    }
    _14977 = NOVALUE;

    /** scanner.e:881		add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_28file_include_11577)){
            _14978 = SEQ_PTR(_28file_include_11577)->length;
    }
    else {
        _14978 = 1;
    }
    _61add_include_by(_27current_file_no_20571, _14978, _61public_include_25928);
    _14978 = NOVALUE;

    /** scanner.e:882		if public_include then*/
    if (_61public_include_25928 == 0)
    {
        goto LC; // [675] 709
    }
    else{
    }

    /** scanner.e:883			file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_28file_public_11584)){
            _14979 = SEQ_PTR(_28file_public_11584)->length;
    }
    else {
        _14979 = 1;
    }
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _14980 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_14980) && IS_ATOM(_14979)) {
        Append(&_14981, _14980, _14979);
    }
    else if (IS_ATOM(_14980) && IS_SEQUENCE(_14979)) {
    }
    else {
        Concat((object_ptr)&_14981, _14980, _14979);
        _14980 = NOVALUE;
    }
    _14980 = NOVALUE;
    _14979 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_public_11584);
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14981;
    if( _1 != _14981 ){
        DeRef(_1);
    }
    _14981 = NOVALUE;

    /** scanner.e:884			patch_exports( current_file_no )*/
    _61patch_exports(_27current_file_no_20571);
LC: 

    /** scanner.e:887	ifdef STDDEBUG then*/

    /** scanner.e:893		src_file = new_file_handle*/
    _27src_file_20693 = _new_file_handle_26936;

    /** scanner.e:894		file_start_sym = last_sym*/
    _27file_start_sym_20577 = _53last_sym_47193;

    /** scanner.e:895		if current_file_no >= MAX_FILE then*/
    if (_27current_file_no_20571 < 256)
    goto LD; // [731] 745

    /** scanner.e:896			CompileErr(PROGRAM_INCLUDES_TOO_MANY_FILES)*/
    RefDS(_22209);
    _49CompileErr(126, _22209, 0);
LD: 

    /** scanner.e:898		known_files = append(known_files, new_include_name)*/
    RefDS(_27new_include_name_20694);
    Append(&_28known_files_11573, _28known_files_11573, _27new_include_name_20694);

    /** scanner.e:899		known_files_hash &= new_hash*/
    Ref(_new_hash_26938);
    Append(&_28known_files_hash_11574, _28known_files_hash_11574, _new_hash_26938);

    /** scanner.e:900		finished_files &= 0*/
    Append(&_28finished_files_11575, _28finished_files_11575, 0);

    /** scanner.e:901		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _14987 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _14987 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14987;
    _14988 = MAKE_SEQ(_1);
    _14987 = NOVALUE;
    RefDS(_14988);
    Append(&_28file_include_depend_11576, _28file_include_depend_11576, _14988);
    DeRefDS(_14988);
    _14988 = NOVALUE;

    /** scanner.e:902		file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _14990 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _14990 = 1;
    }
    _2 = (object)SEQ_PTR(_28file_include_depend_11576);
    _14991 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    if (IS_SEQUENCE(_14991) && IS_ATOM(_14990)) {
        Append(&_14992, _14991, _14990);
    }
    else if (IS_ATOM(_14991) && IS_SEQUENCE(_14990)) {
    }
    else {
        Concat((object_ptr)&_14992, _14991, _14990);
        _14991 = NOVALUE;
    }
    _14991 = NOVALUE;
    _14990 = NOVALUE;
    _2 = (object)SEQ_PTR(_28file_include_depend_11576);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28file_include_depend_11576 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14992;
    if( _1 != _14992 ){
        DeRef(_1);
    }
    _14992 = NOVALUE;

    /** scanner.e:903		check_coverage()*/
    _50check_coverage();

    /** scanner.e:904		default_namespaces &= 0*/
    Append(&_61default_namespaces_25931, _61default_namespaces_25931, 0);

    /** scanner.e:906		update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_28file_include_11577)){
            _14994 = SEQ_PTR(_28file_include_11577)->length;
    }
    else {
        _14994 = 1;
    }
    _61update_include_matrix(_14994, _27current_file_no_20571);
    _14994 = NOVALUE;

    /** scanner.e:907		old_file_no = current_file_no*/
    _old_file_no_26937 = _27current_file_no_20571;

    /** scanner.e:908		current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_28known_files_11573)){
            _27current_file_no_20571 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _27current_file_no_20571 = 1;
    }

    /** scanner.e:909		line_number = 0*/
    _27line_number_20572 = 0;

    /** scanner.e:910		read_line()*/
    _61read_line();

    /** scanner.e:912		if new_include_space != 0 then*/
    if (_61new_include_space_25923 == 0)
    goto LE; // [877] 901

    /** scanner.e:913			SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_61new_include_space_25923 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _14997 = NOVALUE;
LE: 

    /** scanner.e:915		default_namespace( )*/
    _61default_namespace();

    /** scanner.e:916	end procedure*/
    DeRef(_new_hash_26938);
    DeRef(_14940);
    _14940 = NOVALUE;
    return;
    ;
}


void _61update_include_completion(object _file_no_27163)
{
    object _fx_27172 = NOVALUE;
    object _15007 = NOVALUE;
    object _15006 = NOVALUE;
    object _15005 = NOVALUE;
    object _15004 = NOVALUE;
    object _15002 = NOVALUE;
    object _15001 = NOVALUE;
    object _15000 = NOVALUE;
    object _14999 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:919		for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_28file_include_depend_11576)){
            _14999 = SEQ_PTR(_28file_include_depend_11576)->length;
    }
    else {
        _14999 = 1;
    }
    {
        object _i_27165;
        _i_27165 = 1;
L1: 
        if (_i_27165 > _14999){
            goto L2; // [10] 114
        }

        /** scanner.e:920			if length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_28file_include_depend_11576);
        _15000 = (object)*(((s1_ptr)_2)->base + _i_27165);
        if (IS_SEQUENCE(_15000)){
                _15001 = SEQ_PTR(_15000)->length;
        }
        else {
            _15001 = 1;
        }
        _15000 = NOVALUE;
        if (_15001 == 0)
        {
            _15001 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _15001 = NOVALUE;
        }

        /** scanner.e:921				integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (object)SEQ_PTR(_28file_include_depend_11576);
        _15002 = (object)*(((s1_ptr)_2)->base + _i_27165);
        _fx_27172 = find_from(_file_no_27163, _15002, 1);
        _15002 = NOVALUE;

        /** scanner.e:922				if fx then*/
        if (_fx_27172 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** scanner.e:923					file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (object)SEQ_PTR(_28file_include_depend_11576);
        _15004 = (object)*(((s1_ptr)_2)->base + _i_27165);
        {
            s1_ptr assign_space = SEQ_PTR(_15004);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_27172)) ? _fx_27172 : (object)(DBL_PTR(_fx_27172)->dbl);
            int stop = (IS_ATOM_INT(_fx_27172)) ? _fx_27172 : (object)(DBL_PTR(_fx_27172)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
                RefDS(_15004);
                DeRef(_15005);
                _15005 = _15004;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_15004), start, &_15005 );
                }
                else Tail(SEQ_PTR(_15004), stop+1, &_15005);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_15004), start, &_15005);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_15005);
                _15005 = _1;
            }
        }
        _15004 = NOVALUE;
        _2 = (object)SEQ_PTR(_28file_include_depend_11576);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28file_include_depend_11576 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_27165);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _15005;
        if( _1 != _15005 ){
            DeRef(_1);
        }
        _15005 = NOVALUE;

        /** scanner.e:924					if not length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_28file_include_depend_11576);
        _15006 = (object)*(((s1_ptr)_2)->base + _i_27165);
        if (IS_SEQUENCE(_15006)){
                _15007 = SEQ_PTR(_15006)->length;
        }
        else {
            _15007 = 1;
        }
        _15006 = NOVALUE;
        if (_15007 != 0)
        goto L5; // [79] 103
        _15007 = NOVALUE;

        /** scanner.e:925						finished_files[i] = 1*/
        _2 = (object)SEQ_PTR(_28finished_files_11575);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28finished_files_11575 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_27165);
        *(intptr_t *)_2 = 1;

        /** scanner.e:926						if i != file_no then*/
        if (_i_27165 == _file_no_27163)
        goto L6; // [92] 102

        /** scanner.e:927							update_include_completion( i )*/
        _61update_include_completion(_i_27165);
L6: 
L5: 
L4: 
L3: 

        /** scanner.e:932		end for*/
        _i_27165 = _i_27165 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** scanner.e:933	end procedure*/
    _15006 = NOVALUE;
    _15000 = NOVALUE;
    return;
    ;
}


object _61IncludePop()
{
    object _top_27203 = NOVALUE;
    object _15038 = NOVALUE;
    object _15036 = NOVALUE;
    object _15035 = NOVALUE;
    object _15013 = NOVALUE;
    object _15011 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:940		update_include_completion( current_file_no )*/
    _61update_include_completion(_27current_file_no_20571);

    /** scanner.e:941		Resolve_forward_references()*/
    _42Resolve_forward_references(0);

    /** scanner.e:942		HideLocals()*/
    _53HideLocals();

    /** scanner.e:944		if src_file >= 0 then*/
    if (_27src_file_20693 < 0)
    goto L1; // [21] 39

    /** scanner.e:945			close(src_file)*/
    EClose(_27src_file_20693);

    /** scanner.e:946			src_file = -1*/
    _27src_file_20693 = -1;
L1: 

    /** scanner.e:949		if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_61IncludeStk_25934)){
            _15011 = SEQ_PTR(_61IncludeStk_25934)->length;
    }
    else {
        _15011 = 1;
    }
    if (_15011 != 0)
    goto L2; // [46] 59

    /** scanner.e:950			return FALSE  -- the end*/
    DeRef(_top_27203);
    return _9FALSE_439;
L2: 

    /** scanner.e:953		sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_61IncludeStk_25934)){
            _15013 = SEQ_PTR(_61IncludeStk_25934)->length;
    }
    else {
        _15013 = 1;
    }
    DeRef(_top_27203);
    _2 = (object)SEQ_PTR(_61IncludeStk_25934);
    _top_27203 = (object)*(((s1_ptr)_2)->base + _15013);
    RefDS(_top_27203);

    /** scanner.e:955		current_file_no    = top[FILE_NO]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_27current_file_no_20571)){
        _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
    }

    /** scanner.e:956		line_number        = top[LINE_NO]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_27line_number_20572)){
        _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
    }

    /** scanner.e:957		src_file           = top[FILE_PTR]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27src_file_20693 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_27src_file_20693)){
        _27src_file_20693 = (object)DBL_PTR(_27src_file_20693)->dbl;
    }

    /** scanner.e:958		file_start_sym     = top[FILE_START_SYM]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27file_start_sym_20577 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_27file_start_sym_20577)){
        _27file_start_sym_20577 = (object)DBL_PTR(_27file_start_sym_20577)->dbl;
    }

    /** scanner.e:959		OpWarning          = top[OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpWarning_20639 = (object)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_27OpWarning_20639)){
        _27OpWarning_20639 = (object)DBL_PTR(_27OpWarning_20639)->dbl;
    }

    /** scanner.e:960		OpTrace            = top[OP_TRACE]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpTrace_20641 = (object)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_27OpTrace_20641)){
        _27OpTrace_20641 = (object)DBL_PTR(_27OpTrace_20641)->dbl;
    }

    /** scanner.e:961		OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpTypeCheck_20642 = (object)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_27OpTypeCheck_20642)){
        _27OpTypeCheck_20642 = (object)DBL_PTR(_27OpTypeCheck_20642)->dbl;
    }

    /** scanner.e:962		OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpProfileTime_20644 = (object)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_27OpProfileTime_20644)){
        _27OpProfileTime_20644 = (object)DBL_PTR(_27OpProfileTime_20644)->dbl;
    }

    /** scanner.e:963		OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpProfileStatement_20643 = (object)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_27OpProfileStatement_20643)){
        _27OpProfileStatement_20643 = (object)DBL_PTR(_27OpProfileStatement_20643)->dbl;
    }

    /** scanner.e:964		OpDefines          = top[OP_DEFINES]*/
    DeRef(_27OpDefines_20645);
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpDefines_20645 = (object)*(((s1_ptr)_2)->base + 10);
    Ref(_27OpDefines_20645);

    /** scanner.e:965		prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27prev_OpWarning_20640 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_27prev_OpWarning_20640)){
        _27prev_OpWarning_20640 = (object)DBL_PTR(_27prev_OpWarning_20640)->dbl;
    }

    /** scanner.e:966		OpInline           = top[OP_INLINE]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpInline_20646 = (object)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_27OpInline_20646)){
        _27OpInline_20646 = (object)DBL_PTR(_27OpInline_20646)->dbl;
    }

    /** scanner.e:967		OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27OpIndirectInclude_20647 = (object)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_27OpIndirectInclude_20647)){
        _27OpIndirectInclude_20647 = (object)DBL_PTR(_27OpIndirectInclude_20647)->dbl;
    }

    /** scanner.e:968		putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _27putback_fwd_line_number_20574 = _27line_number_20572;

    /** scanner.e:969		putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_49putback_ForwardLine_49644);
    _2 = (object)SEQ_PTR(_top_27203);
    _49putback_ForwardLine_49644 = (object)*(((s1_ptr)_2)->base + 15);
    Ref(_49putback_ForwardLine_49644);

    /** scanner.e:970		putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _49putback_forward_bp_49648 = (object)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_49putback_forward_bp_49648)){
        _49putback_forward_bp_49648 = (object)DBL_PTR(_49putback_forward_bp_49648)->dbl;
    }

    /** scanner.e:971		last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _27last_fwd_line_number_20575 = (object)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_27last_fwd_line_number_20575)){
        _27last_fwd_line_number_20575 = (object)DBL_PTR(_27last_fwd_line_number_20575)->dbl;
    }

    /** scanner.e:972		last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_49last_ForwardLine_49645);
    _2 = (object)SEQ_PTR(_top_27203);
    _49last_ForwardLine_49645 = (object)*(((s1_ptr)_2)->base + 18);
    Ref(_49last_ForwardLine_49645);

    /** scanner.e:973		last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _49last_forward_bp_49649 = (object)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_49last_forward_bp_49649)){
        _49last_forward_bp_49649 = (object)DBL_PTR(_49last_forward_bp_49649)->dbl;
    }

    /** scanner.e:974		ThisLine = top[THISLINE]*/
    DeRef(_49ThisLine_49642);
    _2 = (object)SEQ_PTR(_top_27203);
    _49ThisLine_49642 = (object)*(((s1_ptr)_2)->base + 20);
    Ref(_49ThisLine_49642);

    /** scanner.e:976		fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _27fwd_line_number_20573 = _27line_number_20572;

    /** scanner.e:977		forward_bp = top[FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27203);
    _49forward_bp_49647 = (object)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_49forward_bp_49647)){
        _49forward_bp_49647 = (object)DBL_PTR(_49forward_bp_49647)->dbl;
    }

    /** scanner.e:978		ForwardLine = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49ForwardLine_49643);
    _49ForwardLine_49643 = _49ThisLine_49642;

    /** scanner.e:980		putback_ForwardLine = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49putback_ForwardLine_49644);
    _49putback_ForwardLine_49644 = _49ThisLine_49642;

    /** scanner.e:981		last_ForwardLine = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49last_ForwardLine_49645);
    _49last_ForwardLine_49645 = _49ThisLine_49642;

    /** scanner.e:983		IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_61IncludeStk_25934)){
            _15035 = SEQ_PTR(_61IncludeStk_25934)->length;
    }
    else {
        _15035 = 1;
    }
    _15036 = _15035 - 1;
    _15035 = NOVALUE;
    rhs_slice_target = (object_ptr)&_61IncludeStk_25934;
    RHS_Slice(_61IncludeStk_25934, 1, _15036);

    /** scanner.e:984		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _15038 = NOVALUE;

    /** scanner.e:987		return TRUE*/
    DeRefDS(_top_27203);
    _15036 = NOVALUE;
    return _9TRUE_441;
    ;
}


object _61MakeInt(object _text_27301, object _nBase_27302)
{
    object _num_27303 = NOVALUE;
    object _maxchk_27304 = NOVALUE;
    object _fnum_27305 = NOVALUE;
    object _digit_27306 = NOVALUE;
    object _15085 = NOVALUE;
    object _15083 = NOVALUE;
    object _15081 = NOVALUE;
    object _15078 = NOVALUE;
    object _15077 = NOVALUE;
    object _15076 = NOVALUE;
    object _15074 = NOVALUE;
    object _15072 = NOVALUE;
    object _15071 = NOVALUE;
    object _15070 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_27302)) {
        _1 = (object)(DBL_PTR(_nBase_27302)->dbl);
        DeRefDS(_nBase_27302);
        _nBase_27302 = _1;
    }

    /** scanner.e:1012		ifdef BITS32 then*/

    /** scanner.e:1013			atom num, maxchk*/

    /** scanner.e:1017		atom fnum*/

    /** scanner.e:1018		integer digit*/

    /** scanner.e:1021		switch nBase do*/
    _0 = _nBase_27302;
    switch ( _0 ){ 

        /** scanner.e:1022			case 2 then*/
        case 2:

        /** scanner.e:1023				maxchk = MAXCHK2*/
        _maxchk_27304 = 536870911;
        goto L1; // [29] 90

        /** scanner.e:1025			case 8 then*/
        case 8:

        /** scanner.e:1026				maxchk = MAXCHK8*/
        _maxchk_27304 = 134217727;
        goto L1; // [40] 90

        /** scanner.e:1028			case 10 then*/
        case 10:

        /** scanner.e:1030				num = find(text, common_int_text)*/
        DeRef(_num_27303);
        _num_27303 = find_from(_text_27301, _61common_int_text_27279, 1);

        /** scanner.e:1031				if num then*/
        if (_num_27303 == 0)
        {
            goto L2; // [57] 73
        }
        else{
        }

        /** scanner.e:1032					return common_ints[num]*/
        _2 = (object)SEQ_PTR(_61common_ints_27297);
        _15070 = (object)*(((s1_ptr)_2)->base + _num_27303);
        DeRefDS(_text_27301);
        DeRef(_fnum_27305);
        return _15070;
L2: 

        /** scanner.e:1035				maxchk = MAXCHK10*/
        _maxchk_27304 = 107374181;
        goto L1; // [78] 90

        /** scanner.e:1037			case 16 then*/
        case 16:

        /** scanner.e:1038				maxchk = MAXCHK16*/
        _maxchk_27304 = 67108863;
    ;}L1: 

    /** scanner.e:1042		num = 0*/
    DeRef(_num_27303);
    _num_27303 = 0;

    /** scanner.e:1043		fnum = 0*/
    DeRef(_fnum_27305);
    _fnum_27305 = 0;

    /** scanner.e:1044		for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_27301)){
            _15071 = SEQ_PTR(_text_27301)->length;
    }
    else {
        _15071 = 1;
    }
    {
        object _i_27317;
        _i_27317 = 1;
L3: 
        if (_i_27317 > _15071){
            goto L4; // [105] 220
        }

        /** scanner.e:1045			digit = (text[i] - '0')*/
        _2 = (object)SEQ_PTR(_text_27301);
        _15072 = (object)*(((s1_ptr)_2)->base + _i_27317);
        if (IS_ATOM_INT(_15072)) {
            _digit_27306 = _15072 - 48;
        }
        else {
            _digit_27306 = binary_op(MINUS, _15072, 48);
        }
        _15072 = NOVALUE;
        if (!IS_ATOM_INT(_digit_27306)) {
            _1 = (object)(DBL_PTR(_digit_27306)->dbl);
            DeRefDS(_digit_27306);
            _digit_27306 = _1;
        }

        /** scanner.e:1046			if digit >= nBase or digit < 0 then*/
        _15074 = (_digit_27306 >= _nBase_27302);
        if (_15074 != 0) {
            goto L5; // [130] 143
        }
        _15076 = (_digit_27306 < 0);
        if (_15076 == 0)
        {
            DeRef(_15076);
            _15076 = NOVALUE;
            goto L6; // [139] 161
        }
        else{
            DeRef(_15076);
            _15076 = NOVALUE;
        }
L5: 

        /** scanner.e:1047				CompileErr(DIGIT_1_AT_POSITION_2_IS_OUTSIDE_OF_NUMBER_BASE, {text[i],i})*/
        _2 = (object)SEQ_PTR(_text_27301);
        _15077 = (object)*(((s1_ptr)_2)->base + _i_27317);
        Ref(_15077);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _15077;
        ((intptr_t *)_2)[2] = _i_27317;
        _15078 = MAKE_SEQ(_1);
        _15077 = NOVALUE;
        _49CompileErr(62, _15078, 0);
        _15078 = NOVALUE;
L6: 

        /** scanner.e:1049			if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_27305, 0)){
            goto L7; // [163] 202
        }

        /** scanner.e:1050				if num <= maxchk then*/
        if (binary_op_a(GREATER, _num_27303, _maxchk_27304)){
            goto L8; // [171] 188
        }

        /** scanner.e:1051					num = num * nBase + digit*/
        if (IS_ATOM_INT(_num_27303)) {
            if (_num_27303 == (short)_num_27303 && _nBase_27302 <= INT15 && _nBase_27302 >= -INT15){
                _15081 = _num_27303 * _nBase_27302;
            }
            else{
                _15081 = NewDouble(_num_27303 * (eudouble)_nBase_27302);
            }
        }
        else {
            _15081 = NewDouble(DBL_PTR(_num_27303)->dbl * (eudouble)_nBase_27302);
        }
        DeRef(_num_27303);
        if (IS_ATOM_INT(_15081)) {
            _num_27303 = _15081 + _digit_27306;
            if ((object)((uintptr_t)_num_27303 + (uintptr_t)HIGH_BITS) >= 0){
                _num_27303 = NewDouble((eudouble)_num_27303);
            }
        }
        else {
            _num_27303 = NewDouble(DBL_PTR(_15081)->dbl + (eudouble)_digit_27306);
        }
        DeRef(_15081);
        _15081 = NOVALUE;
        goto L9; // [185] 213
L8: 

        /** scanner.e:1053					fnum = num * nBase + digit*/
        if (IS_ATOM_INT(_num_27303)) {
            if (_num_27303 == (short)_num_27303 && _nBase_27302 <= INT15 && _nBase_27302 >= -INT15){
                _15083 = _num_27303 * _nBase_27302;
            }
            else{
                _15083 = NewDouble(_num_27303 * (eudouble)_nBase_27302);
            }
        }
        else {
            _15083 = NewDouble(DBL_PTR(_num_27303)->dbl * (eudouble)_nBase_27302);
        }
        DeRef(_fnum_27305);
        if (IS_ATOM_INT(_15083)) {
            _fnum_27305 = _15083 + _digit_27306;
            if ((object)((uintptr_t)_fnum_27305 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_27305 = NewDouble((eudouble)_fnum_27305);
            }
        }
        else {
            _fnum_27305 = NewDouble(DBL_PTR(_15083)->dbl + (eudouble)_digit_27306);
        }
        DeRef(_15083);
        _15083 = NOVALUE;
        goto L9; // [199] 213
L7: 

        /** scanner.e:1056				fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_27305)) {
            if (_fnum_27305 == (short)_fnum_27305 && _nBase_27302 <= INT15 && _nBase_27302 >= -INT15){
                _15085 = _fnum_27305 * _nBase_27302;
            }
            else{
                _15085 = NewDouble(_fnum_27305 * (eudouble)_nBase_27302);
            }
        }
        else {
            _15085 = NewDouble(DBL_PTR(_fnum_27305)->dbl * (eudouble)_nBase_27302);
        }
        DeRef(_fnum_27305);
        if (IS_ATOM_INT(_15085)) {
            _fnum_27305 = _15085 + _digit_27306;
            if ((object)((uintptr_t)_fnum_27305 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_27305 = NewDouble((eudouble)_fnum_27305);
            }
        }
        else {
            _fnum_27305 = NewDouble(DBL_PTR(_15085)->dbl + (eudouble)_digit_27306);
        }
        DeRef(_15085);
        _15085 = NOVALUE;
L9: 

        /** scanner.e:1058		end for*/
        _i_27317 = _i_27317 + 1;
        goto L3; // [215] 112
L4: 
        ;
    }

    /** scanner.e:1060		if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_27305, 0)){
        goto LA; // [222] 235
    }

    /** scanner.e:1061			return num*/
    DeRefDS(_text_27301);
    DeRef(_fnum_27305);
    _15070 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    return _num_27303;
    goto LB; // [232] 242
LA: 

    /** scanner.e:1063			return fnum*/
    DeRefDS(_text_27301);
    DeRef(_num_27303);
    _15070 = NOVALUE;
    DeRef(_15074);
    _15074 = NOVALUE;
    return _fnum_27305;
LB: 
    ;
}


object _61GetHexChar(object _cnt_27346, object _errno_27347)
{
    object _val_27348 = NOVALUE;
    object _d_27349 = NOVALUE;
    object _15095 = NOVALUE;
    object _15094 = NOVALUE;
    object _15089 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1070		val = 0*/
    DeRef(_val_27348);
    _val_27348 = 0;

    /** scanner.e:1072		while cnt > 0 do*/
L1: 
    if (_cnt_27346 <= 0)
    goto L2; // [15] 88

    /** scanner.e:1073			d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _15089 = _61getch();
    _d_27349 = find_from(_15089, _15090, 1);
    DeRef(_15089);
    _15089 = NOVALUE;

    /** scanner.e:1074			if d = 0 then*/
    if (_d_27349 != 0)
    goto L3; // [31] 43

    /** scanner.e:1075				CompileErr( errno )*/
    RefDS(_22209);
    _49CompileErr(_errno_27347, _22209, 0);
L3: 

    /** scanner.e:1077			if d != 23 then*/
    if (_d_27349 == 23)
    goto L1; // [45] 15

    /** scanner.e:1078				val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_27348)) {
        if (_val_27348 == (short)_val_27348){
            _15094 = _val_27348 * 16;
        }
        else{
            _15094 = NewDouble(_val_27348 * (eudouble)16);
        }
    }
    else {
        _15094 = NewDouble(DBL_PTR(_val_27348)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15094)) {
        _15095 = _15094 + _d_27349;
        if ((object)((uintptr_t)_15095 + (uintptr_t)HIGH_BITS) >= 0){
            _15095 = NewDouble((eudouble)_15095);
        }
    }
    else {
        _15095 = NewDouble(DBL_PTR(_15094)->dbl + (eudouble)_d_27349);
    }
    DeRef(_15094);
    _15094 = NOVALUE;
    DeRef(_val_27348);
    if (IS_ATOM_INT(_15095)) {
        _val_27348 = _15095 - 1;
        if ((object)((uintptr_t)_val_27348 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27348 = NewDouble((eudouble)_val_27348);
        }
    }
    else {
        _val_27348 = NewDouble(DBL_PTR(_15095)->dbl - (eudouble)1);
    }
    DeRef(_15095);
    _15095 = NOVALUE;

    /** scanner.e:1079				if d > 16 then*/
    if (_d_27349 <= 16)
    goto L4; // [65] 76

    /** scanner.e:1080					val -= 6*/
    _0 = _val_27348;
    if (IS_ATOM_INT(_val_27348)) {
        _val_27348 = _val_27348 - 6;
        if ((object)((uintptr_t)_val_27348 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27348 = NewDouble((eudouble)_val_27348);
        }
    }
    else {
        _val_27348 = NewDouble(DBL_PTR(_val_27348)->dbl - (eudouble)6);
    }
    DeRef(_0);
L4: 

    /** scanner.e:1082				cnt -= 1*/
    _cnt_27346 = _cnt_27346 - 1;

    /** scanner.e:1084		end while*/
    goto L1; // [85] 15
L2: 

    /** scanner.e:1086		return val*/
    return _val_27348;
    ;
}


object _61GetBinaryChar(object _delim_27369)
{
    object _val_27370 = NOVALUE;
    object _d_27371 = NOVALUE;
    object _vchars_27372 = NOVALUE;
    object _cnt_27375 = NOVALUE;
    object _15109 = NOVALUE;
    object _15108 = NOVALUE;
    object _15102 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1092		sequence vchars = "01_ " & delim*/
    Append(&_vchars_27372, _15100, _delim_27369);

    /** scanner.e:1093		integer cnt = 0*/
    _cnt_27375 = 0;

    /** scanner.e:1094		val = 0*/
    DeRef(_val_27370);
    _val_27370 = 0;

    /** scanner.e:1095		while 1 do*/
L1: 

    /** scanner.e:1096			d = find(getch(), vchars)*/
    _15102 = _61getch();
    _d_27371 = find_from(_15102, _vchars_27372, 1);
    DeRef(_15102);
    _15102 = NOVALUE;

    /** scanner.e:1097			if d = 0 then*/
    if (_d_27371 != 0)
    goto L2; // [36] 50

    /** scanner.e:1098				CompileErr( EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22209);
    _49CompileErr(343, _22209, 0);
L2: 

    /** scanner.e:1100			if d = 5 then*/
    if (_d_27371 != 5)
    goto L3; // [52] 65

    /** scanner.e:1101				ungetch()*/
    _61ungetch();

    /** scanner.e:1102				exit*/
    goto L4; // [62] 108
L3: 

    /** scanner.e:1104			if d = 4 then*/
    if (_d_27371 != 4)
    goto L5; // [67] 76

    /** scanner.e:1105				exit*/
    goto L4; // [73] 108
L5: 

    /** scanner.e:1107			if d != 3 then*/
    if (_d_27371 == 3)
    goto L1; // [78] 24

    /** scanner.e:1108				val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_27370) && IS_ATOM_INT(_val_27370)) {
        _15108 = _val_27370 + _val_27370;
        if ((object)((uintptr_t)_15108 + (uintptr_t)HIGH_BITS) >= 0){
            _15108 = NewDouble((eudouble)_15108);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27370)) {
            _15108 = NewDouble((eudouble)_val_27370 + DBL_PTR(_val_27370)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27370)) {
                _15108 = NewDouble(DBL_PTR(_val_27370)->dbl + (eudouble)_val_27370);
            }
            else
            _15108 = NewDouble(DBL_PTR(_val_27370)->dbl + DBL_PTR(_val_27370)->dbl);
        }
    }
    if (IS_ATOM_INT(_15108)) {
        _15109 = _15108 + _d_27371;
        if ((object)((uintptr_t)_15109 + (uintptr_t)HIGH_BITS) >= 0){
            _15109 = NewDouble((eudouble)_15109);
        }
    }
    else {
        _15109 = NewDouble(DBL_PTR(_15108)->dbl + (eudouble)_d_27371);
    }
    DeRef(_15108);
    _15108 = NOVALUE;
    DeRef(_val_27370);
    if (IS_ATOM_INT(_15109)) {
        _val_27370 = _15109 - 1;
        if ((object)((uintptr_t)_val_27370 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27370 = NewDouble((eudouble)_val_27370);
        }
    }
    else {
        _val_27370 = NewDouble(DBL_PTR(_15109)->dbl - (eudouble)1);
    }
    DeRef(_15109);
    _15109 = NOVALUE;

    /** scanner.e:1109				cnt += 1*/
    _cnt_27375 = _cnt_27375 + 1;

    /** scanner.e:1111		end while*/
    goto L1; // [105] 24
L4: 

    /** scanner.e:1113		if cnt = 0 then*/
    if (_cnt_27375 != 0)
    goto L6; // [110] 124

    /** scanner.e:1114			CompileErr(EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22209);
    _49CompileErr(343, _22209, 0);
L6: 

    /** scanner.e:1116		return val*/
    DeRefi(_vchars_27372);
    return _val_27370;
    ;
}


object _61EscapeChar(object _delim_27399)
{
    object _c_27400 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1124		c = getch()*/
    _0 = _c_27400;
    _c_27400 = _61getch();
    DeRef(_0);

    /** scanner.e:1125		switch c do*/
    if (IS_SEQUENCE(_c_27400) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_27400)){
        if( (DBL_PTR(_c_27400)->dbl != (eudouble) ((object) DBL_PTR(_c_27400)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (object) DBL_PTR(_c_27400)->dbl;
    }
    else {
        _0 = _c_27400;
    };
    switch ( _0 ){ 

        /** scanner.e:1126			case 'n' then*/
        case 110:

        /** scanner.e:1127				c = 10 -- Newline*/
        DeRef(_c_27400);
        _c_27400 = 10;
        goto L2; // [24] 147

        /** scanner.e:1129			case 't' then*/
        case 116:

        /** scanner.e:1130				c = 9 -- Tabulator*/
        DeRef(_c_27400);
        _c_27400 = 9;
        goto L2; // [35] 147

        /** scanner.e:1132			case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** scanner.e:1137			case 'r' then*/
        goto L2; // [47] 147
        case 114:

        /** scanner.e:1138				c = 13 -- Carriage Return*/
        DeRef(_c_27400);
        _c_27400 = 13;
        goto L2; // [56] 147

        /** scanner.e:1140			case '0' then*/
        case 48:

        /** scanner.e:1141				c = 0 -- Null*/
        DeRef(_c_27400);
        _c_27400 = 0;
        goto L2; // [67] 147

        /** scanner.e:1143			case 'e', 'E' then*/
        case 101:
        case 69:

        /** scanner.e:1144				c = 27 -- escape char.*/
        DeRef(_c_27400);
        _c_27400 = 27;
        goto L2; // [80] 147

        /** scanner.e:1146			case 'x' then*/
        case 120:

        /** scanner.e:1148				c = GetHexChar(2, 340)*/
        _0 = _c_27400;
        _c_27400 = _61GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 147

        /** scanner.e:1150			case 'u' then*/
        case 117:

        /** scanner.e:1152				c = GetHexChar(4, 341)*/
        _0 = _c_27400;
        _c_27400 = _61GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 147

        /** scanner.e:1154			case 'U' then*/
        case 85:

        /** scanner.e:1156				c = GetHexChar(8, 342)*/
        _0 = _c_27400;
        _c_27400 = _61GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 147

        /** scanner.e:1158			case 'b' then*/
        case 98:

        /** scanner.e:1160				c = GetBinaryChar(delim)*/
        _0 = _c_27400;
        _c_27400 = _61GetBinaryChar(_delim_27399);
        DeRef(_0);
        goto L2; // [131] 147

        /** scanner.e:1162			case else*/
        default:
L1: 

        /** scanner.e:1163				CompileErr(UNKNOWN_ESCAPE_CHARACTER)*/
        RefDS(_22209);
        _49CompileErr(155, _22209, 0);
    ;}L2: 

    /** scanner.e:1166		return c*/
    return _c_27400;
    ;
}


object _61my_sscanf(object _yytext_27423)
{
    object _e_sign_27424 = NOVALUE;
    object _ndigits_27425 = NOVALUE;
    object _e_mag_27426 = NOVALUE;
    object _mantissa_27427 = NOVALUE;
    object _c_27428 = NOVALUE;
    object _i_27429 = NOVALUE;
    object _dec_27430 = NOVALUE;
    object _frac_27463 = NOVALUE;
    object _15154 = NOVALUE;
    object _15149 = NOVALUE;
    object _15148 = NOVALUE;
    object _15146 = NOVALUE;
    object _15145 = NOVALUE;
    object _15144 = NOVALUE;
    object _15136 = NOVALUE;
    object _15135 = NOVALUE;
    object _15132 = NOVALUE;
    object _15131 = NOVALUE;
    object _15130 = NOVALUE;
    object _15125 = NOVALUE;
    object _15124 = NOVALUE;
    object _15122 = NOVALUE;
    object _15120 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1179		if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_27423)){
            _15120 = SEQ_PTR(_yytext_27423)->length;
    }
    else {
        _15120 = 1;
    }
    if (_15120 >= 2)
    goto L1; // [8] 22

    /** scanner.e:1180			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22209);
    _49CompileErr(121, _22209, 0);
L1: 

    /** scanner.e:1184		if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _15122 = find_from(101, _yytext_27423, 1);
    if (_15122 != 0) {
        goto L2; // [29] 43
    }
    _15124 = find_from(69, _yytext_27423, 1);
    if (_15124 == 0)
    {
        _15124 = NOVALUE;
        goto L3; // [39] 59
    }
    else{
        _15124 = NOVALUE;
    }
L2: 

    /** scanner.e:1185			ifdef BITS32 then*/

    /** scanner.e:1186				return scientific_to_atom( yytext, DOUBLE )*/
    RefDS(_yytext_27423);
    _15125 = _19scientific_to_atom(_yytext_27423, 2);
    DeRefDS(_yytext_27423);
    DeRef(_mantissa_27427);
    DeRef(_dec_27430);
    return _15125;
L3: 

    /** scanner.e:1193		mantissa = 0.0*/
    RefDS(_15127);
    DeRef(_mantissa_27427);
    _mantissa_27427 = _15127;

    /** scanner.e:1194		ndigits = 0*/
    _ndigits_27425 = 0;

    /** scanner.e:1198		yytext &= 0 -- end marker*/
    Append(&_yytext_27423, _yytext_27423, 0);

    /** scanner.e:1199		c = yytext[1]*/
    _2 = (object)SEQ_PTR(_yytext_27423);
    _c_27428 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_27428))
    _c_27428 = (object)DBL_PTR(_c_27428)->dbl;

    /** scanner.e:1200		i = 2*/
    _i_27429 = 2;

    /** scanner.e:1201		while c >= '0' and c <= '9' do*/
L4: 
    _15130 = (_c_27428 >= 48);
    if (_15130 == 0) {
        goto L5; // [95] 144
    }
    _15132 = (_c_27428 <= 57);
    if (_15132 == 0)
    {
        DeRef(_15132);
        _15132 = NOVALUE;
        goto L5; // [104] 144
    }
    else{
        DeRef(_15132);
        _15132 = NOVALUE;
    }

    /** scanner.e:1202			ndigits += 1*/
    _ndigits_27425 = _ndigits_27425 + 1;

    /** scanner.e:1203			mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_27427)) {
        _15135 = NewDouble((eudouble)_mantissa_27427 * DBL_PTR(_15134)->dbl);
    }
    else {
        _15135 = NewDouble(DBL_PTR(_mantissa_27427)->dbl * DBL_PTR(_15134)->dbl);
    }
    _15136 = _c_27428 - 48;
    if ((object)((uintptr_t)_15136 +(uintptr_t) HIGH_BITS) >= 0){
        _15136 = NewDouble((eudouble)_15136);
    }
    DeRef(_mantissa_27427);
    if (IS_ATOM_INT(_15136)) {
        _mantissa_27427 = NewDouble(DBL_PTR(_15135)->dbl + (eudouble)_15136);
    }
    else
    _mantissa_27427 = NewDouble(DBL_PTR(_15135)->dbl + DBL_PTR(_15136)->dbl);
    DeRefDS(_15135);
    _15135 = NOVALUE;
    DeRef(_15136);
    _15136 = NOVALUE;

    /** scanner.e:1204			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27423);
    _c_27428 = (object)*(((s1_ptr)_2)->base + _i_27429);
    if (!IS_ATOM_INT(_c_27428))
    _c_27428 = (object)DBL_PTR(_c_27428)->dbl;

    /** scanner.e:1205			i += 1*/
    _i_27429 = _i_27429 + 1;

    /** scanner.e:1206		end while*/
    goto L4; // [141] 91
L5: 

    /** scanner.e:1208		if c = '.' then*/
    if (_c_27428 != 46)
    goto L6; // [146] 247

    /** scanner.e:1210			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27423);
    _c_27428 = (object)*(((s1_ptr)_2)->base + _i_27429);
    if (!IS_ATOM_INT(_c_27428))
    _c_27428 = (object)DBL_PTR(_c_27428)->dbl;

    /** scanner.e:1211			i += 1*/
    _i_27429 = _i_27429 + 1;

    /** scanner.e:1212			dec = 1.0*/
    RefDS(_15143);
    DeRef(_dec_27430);
    _dec_27430 = _15143;

    /** scanner.e:1213			atom frac = 0*/
    DeRef(_frac_27463);
    _frac_27463 = 0;

    /** scanner.e:1214			while c >= '0' and c <= '9' do*/
L7: 
    _15144 = (_c_27428 >= 48);
    if (_15144 == 0) {
        goto L8; // [181] 236
    }
    _15146 = (_c_27428 <= 57);
    if (_15146 == 0)
    {
        DeRef(_15146);
        _15146 = NOVALUE;
        goto L8; // [190] 236
    }
    else{
        DeRef(_15146);
        _15146 = NOVALUE;
    }

    /** scanner.e:1215				ndigits += 1*/
    _ndigits_27425 = _ndigits_27425 + 1;

    /** scanner.e:1216				frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_27463)) {
        if (_frac_27463 == (short)_frac_27463){
            _15148 = _frac_27463 * 10;
        }
        else{
            _15148 = NewDouble(_frac_27463 * (eudouble)10);
        }
    }
    else {
        _15148 = NewDouble(DBL_PTR(_frac_27463)->dbl * (eudouble)10);
    }
    _15149 = _c_27428 - 48;
    if ((object)((uintptr_t)_15149 +(uintptr_t) HIGH_BITS) >= 0){
        _15149 = NewDouble((eudouble)_15149);
    }
    DeRef(_frac_27463);
    if (IS_ATOM_INT(_15148) && IS_ATOM_INT(_15149)) {
        _frac_27463 = _15148 + _15149;
        if ((object)((uintptr_t)_frac_27463 + (uintptr_t)HIGH_BITS) >= 0){
            _frac_27463 = NewDouble((eudouble)_frac_27463);
        }
    }
    else {
        if (IS_ATOM_INT(_15148)) {
            _frac_27463 = NewDouble((eudouble)_15148 + DBL_PTR(_15149)->dbl);
        }
        else {
            if (IS_ATOM_INT(_15149)) {
                _frac_27463 = NewDouble(DBL_PTR(_15148)->dbl + (eudouble)_15149);
            }
            else
            _frac_27463 = NewDouble(DBL_PTR(_15148)->dbl + DBL_PTR(_15149)->dbl);
        }
    }
    DeRef(_15148);
    _15148 = NOVALUE;
    DeRef(_15149);
    _15149 = NOVALUE;

    /** scanner.e:1217				dec *= 10.0*/
    _0 = _dec_27430;
    if (IS_ATOM_INT(_dec_27430)) {
        _dec_27430 = NewDouble((eudouble)_dec_27430 * DBL_PTR(_15134)->dbl);
    }
    else {
        _dec_27430 = NewDouble(DBL_PTR(_dec_27430)->dbl * DBL_PTR(_15134)->dbl);
    }
    DeRef(_0);

    /** scanner.e:1218				c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27423);
    _c_27428 = (object)*(((s1_ptr)_2)->base + _i_27429);
    if (!IS_ATOM_INT(_c_27428))
    _c_27428 = (object)DBL_PTR(_c_27428)->dbl;

    /** scanner.e:1219				i += 1*/
    _i_27429 = _i_27429 + 1;

    /** scanner.e:1220			end while*/
    goto L7; // [233] 177
L8: 

    /** scanner.e:1221			mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_27463) && IS_ATOM_INT(_dec_27430)) {
        _15154 = (_frac_27463 % _dec_27430) ? NewDouble((eudouble)_frac_27463 / _dec_27430) : (_frac_27463 / _dec_27430);
    }
    else {
        if (IS_ATOM_INT(_frac_27463)) {
            _15154 = NewDouble((eudouble)_frac_27463 / DBL_PTR(_dec_27430)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_27430)) {
                _15154 = NewDouble(DBL_PTR(_frac_27463)->dbl / (eudouble)_dec_27430);
            }
            else
            _15154 = NewDouble(DBL_PTR(_frac_27463)->dbl / DBL_PTR(_dec_27430)->dbl);
        }
    }
    _0 = _mantissa_27427;
    if (IS_ATOM_INT(_mantissa_27427) && IS_ATOM_INT(_15154)) {
        _mantissa_27427 = _mantissa_27427 + _15154;
        if ((object)((uintptr_t)_mantissa_27427 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_27427 = NewDouble((eudouble)_mantissa_27427);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_27427)) {
            _mantissa_27427 = NewDouble((eudouble)_mantissa_27427 + DBL_PTR(_15154)->dbl);
        }
        else {
            if (IS_ATOM_INT(_15154)) {
                _mantissa_27427 = NewDouble(DBL_PTR(_mantissa_27427)->dbl + (eudouble)_15154);
            }
            else
            _mantissa_27427 = NewDouble(DBL_PTR(_mantissa_27427)->dbl + DBL_PTR(_15154)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_15154);
    _15154 = NOVALUE;
L6: 
    DeRef(_frac_27463);
    _frac_27463 = NOVALUE;

    /** scanner.e:1224		if ndigits = 0 then*/
    if (_ndigits_27425 != 0)
    goto L9; // [251] 265

    /** scanner.e:1225			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)  -- no digits*/
    RefDS(_22209);
    _49CompileErr(121, _22209, 0);
L9: 

    /** scanner.e:1271		return mantissa*/
    DeRefDS(_yytext_27423);
    DeRef(_dec_27430);
    DeRef(_15125);
    _15125 = NOVALUE;
    DeRef(_15130);
    _15130 = NOVALUE;
    DeRef(_15144);
    _15144 = NOVALUE;
    return _mantissa_27427;
    ;
}


void _61maybe_namespace()
{
    object _0, _1, _2;
    

    /** scanner.e:1276		might_be_namespace = 1*/
    _61might_be_namespace_27481 = 1;

    /** scanner.e:1277	end procedure*/
    return;
    ;
}


object _61ExtendedString(object _ech_27491)
{
    object _ch_27492 = NOVALUE;
    object _fch_27493 = NOVALUE;
    object _cline_27494 = NOVALUE;
    object _string_text_27495 = NOVALUE;
    object _trimming_27496 = NOVALUE;
    object _15207 = NOVALUE;
    object _15206 = NOVALUE;
    object _15204 = NOVALUE;
    object _15203 = NOVALUE;
    object _15202 = NOVALUE;
    object _15201 = NOVALUE;
    object _15200 = NOVALUE;
    object _15199 = NOVALUE;
    object _15198 = NOVALUE;
    object _15197 = NOVALUE;
    object _15195 = NOVALUE;
    object _15194 = NOVALUE;
    object _15193 = NOVALUE;
    object _15192 = NOVALUE;
    object _15191 = NOVALUE;
    object _15190 = NOVALUE;
    object _15187 = NOVALUE;
    object _15186 = NOVALUE;
    object _15185 = NOVALUE;
    object _15183 = NOVALUE;
    object _15182 = NOVALUE;
    object _15181 = NOVALUE;
    object _15180 = NOVALUE;
    object _15177 = NOVALUE;
    object _15162 = NOVALUE;
    object _15160 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1290		cline = line_number*/
    _cline_27494 = _27line_number_20572;

    /** scanner.e:1291		string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_27495);
    _string_text_27495 = _5;

    /** scanner.e:1292		trimming = 0*/
    _trimming_27496 = 0;

    /** scanner.e:1293		ch = getch()*/
    _ch_27492 = _61getch();
    if (!IS_ATOM_INT(_ch_27492)) {
        _1 = (object)(DBL_PTR(_ch_27492)->dbl);
        DeRefDS(_ch_27492);
        _ch_27492 = _1;
    }

    /** scanner.e:1294		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_49ThisLine_49642)){
            _15160 = SEQ_PTR(_49ThisLine_49642)->length;
    }
    else {
        _15160 = 1;
    }
    if (_49bp_49646 <= _15160)
    goto L1; // [40] 101

    /** scanner.e:1296			read_line()*/
    _61read_line();

    /** scanner.e:1297			while ThisLine[bp] = '_' do*/
L2: 
    _2 = (object)SEQ_PTR(_49ThisLine_49642);
    _15162 = (object)*(((s1_ptr)_2)->base + _49bp_49646);
    if (binary_op_a(NOTEQ, _15162, 95)){
        _15162 = NOVALUE;
        goto L3; // [61] 86
    }
    _15162 = NOVALUE;

    /** scanner.e:1298				trimming += 1*/
    _trimming_27496 = _trimming_27496 + 1;

    /** scanner.e:1299				bp += 1*/
    _49bp_49646 = _49bp_49646 + 1;

    /** scanner.e:1300			end while*/
    goto L2; // [83] 53
L3: 

    /** scanner.e:1301			if trimming > 0 then*/
    if (_trimming_27496 <= 0)
    goto L4; // [88] 100

    /** scanner.e:1302				ch = getch()*/
    _ch_27492 = _61getch();
    if (!IS_ATOM_INT(_ch_27492)) {
        _1 = (object)(DBL_PTR(_ch_27492)->dbl);
        DeRefDS(_ch_27492);
        _ch_27492 = _1;
    }
L4: 
L1: 

    /** scanner.e:1306		while 1 do*/
L5: 

    /** scanner.e:1307			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27492 != 26)
    goto L6; // [110] 124

    /** scanner.e:1308				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(129, _cline_27494, 0);
L6: 

    /** scanner.e:1311			if ch = ech then*/
    if (_ch_27492 != _ech_27491)
    goto L7; // [126] 182

    /** scanner.e:1312				if ech != '"' then*/
    if (_ech_27491 == 34)
    goto L8; // [132] 141

    /** scanner.e:1313					exit*/
    goto L9; // [138] 312
L8: 

    /** scanner.e:1315				fch = getch()*/
    _fch_27493 = _61getch();
    if (!IS_ATOM_INT(_fch_27493)) {
        _1 = (object)(DBL_PTR(_fch_27493)->dbl);
        DeRefDS(_fch_27493);
        _fch_27493 = _1;
    }

    /** scanner.e:1316				if fch = '"' then*/
    if (_fch_27493 != 34)
    goto LA; // [150] 177

    /** scanner.e:1317					fch = getch()*/
    _fch_27493 = _61getch();
    if (!IS_ATOM_INT(_fch_27493)) {
        _1 = (object)(DBL_PTR(_fch_27493)->dbl);
        DeRefDS(_fch_27493);
        _fch_27493 = _1;
    }

    /** scanner.e:1318					if fch = '"' then*/
    if (_fch_27493 != 34)
    goto LB; // [163] 172

    /** scanner.e:1319						exit*/
    goto L9; // [169] 312
LB: 

    /** scanner.e:1321					ungetch()*/
    _61ungetch();
LA: 

    /** scanner.e:1323				ungetch()*/
    _61ungetch();
L7: 

    /** scanner.e:1326			if ch != '\r' then*/
    if (_ch_27492 == 13)
    goto LC; // [184] 195

    /** scanner.e:1329				string_text &= ch*/
    Append(&_string_text_27495, _string_text_27495, _ch_27492);
LC: 

    /** scanner.e:1332			if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_49ThisLine_49642)){
            _15177 = SEQ_PTR(_49ThisLine_49642)->length;
    }
    else {
        _15177 = 1;
    }
    if (_49bp_49646 <= _15177)
    goto LD; // [204] 300

    /** scanner.e:1333				read_line() -- sets bp to 1, btw.*/
    _61read_line();

    /** scanner.e:1334				if trimming > 0 then*/
    if (_trimming_27496 <= 0)
    goto LE; // [214] 299

    /** scanner.e:1335					while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _15180 = (_49bp_49646 <= _trimming_27496);
    if (_15180 == 0) {
        goto L10; // [229] 298
    }
    if (IS_SEQUENCE(_49ThisLine_49642)){
            _15182 = SEQ_PTR(_49ThisLine_49642)->length;
    }
    else {
        _15182 = 1;
    }
    _15183 = (_49bp_49646 <= _15182);
    _15182 = NOVALUE;
    if (_15183 == 0)
    {
        DeRef(_15183);
        _15183 = NOVALUE;
        goto L10; // [245] 298
    }
    else{
        DeRef(_15183);
        _15183 = NOVALUE;
    }

    /** scanner.e:1336						ch = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_49ThisLine_49642);
    _ch_27492 = (object)*(((s1_ptr)_2)->base + _49bp_49646);
    if (!IS_ATOM_INT(_ch_27492)){
        _ch_27492 = (object)DBL_PTR(_ch_27492)->dbl;
    }

    /** scanner.e:1337						if ch != ' ' and ch != '\t' then*/
    _15185 = (_ch_27492 != 32);
    if (_15185 == 0) {
        goto L11; // [266] 283
    }
    _15187 = (_ch_27492 != 9);
    if (_15187 == 0)
    {
        DeRef(_15187);
        _15187 = NOVALUE;
        goto L11; // [275] 283
    }
    else{
        DeRef(_15187);
        _15187 = NOVALUE;
    }

    /** scanner.e:1338							exit*/
    goto L10; // [280] 298
L11: 

    /** scanner.e:1340						bp += 1*/
    _49bp_49646 = _49bp_49646 + 1;

    /** scanner.e:1341					end while*/
    goto LF; // [295] 223
L10: 
LE: 
LD: 

    /** scanner.e:1344			ch = getch()*/
    _ch_27492 = _61getch();
    if (!IS_ATOM_INT(_ch_27492)) {
        _1 = (object)(DBL_PTR(_ch_27492)->dbl);
        DeRefDS(_ch_27492);
        _ch_27492 = _1;
    }

    /** scanner.e:1345		end while*/
    goto L5; // [309] 106
L9: 

    /** scanner.e:1346		if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27495)){
            _15190 = SEQ_PTR(_string_text_27495)->length;
    }
    else {
        _15190 = 1;
    }
    _15191 = (_15190 > 0);
    _15190 = NOVALUE;
    if (_15191 == 0) {
        goto L12; // [321] 391
    }
    _2 = (object)SEQ_PTR(_string_text_27495);
    _15193 = (object)*(((s1_ptr)_2)->base + 1);
    _15194 = (_15193 == 10);
    _15193 = NOVALUE;
    if (_15194 == 0)
    {
        DeRef(_15194);
        _15194 = NOVALUE;
        goto L12; // [334] 391
    }
    else{
        DeRef(_15194);
        _15194 = NOVALUE;
    }

    /** scanner.e:1347			string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_27495)){
            _15195 = SEQ_PTR(_string_text_27495)->length;
    }
    else {
        _15195 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_27495;
    RHS_Slice(_string_text_27495, 2, _15195);

    /** scanner.e:1348			if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27495)){
            _15197 = SEQ_PTR(_string_text_27495)->length;
    }
    else {
        _15197 = 1;
    }
    _15198 = (_15197 > 0);
    _15197 = NOVALUE;
    if (_15198 == 0) {
        goto L13; // [356] 390
    }
    if (IS_SEQUENCE(_string_text_27495)){
            _15200 = SEQ_PTR(_string_text_27495)->length;
    }
    else {
        _15200 = 1;
    }
    _2 = (object)SEQ_PTR(_string_text_27495);
    _15201 = (object)*(((s1_ptr)_2)->base + _15200);
    _15202 = (_15201 == 10);
    _15201 = NOVALUE;
    if (_15202 == 0)
    {
        DeRef(_15202);
        _15202 = NOVALUE;
        goto L13; // [372] 390
    }
    else{
        DeRef(_15202);
        _15202 = NOVALUE;
    }

    /** scanner.e:1349				string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_27495)){
            _15203 = SEQ_PTR(_string_text_27495)->length;
    }
    else {
        _15203 = 1;
    }
    _15204 = _15203 - 1;
    _15203 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_27495;
    RHS_Slice(_string_text_27495, 1, _15204);
L13: 
L12: 

    /** scanner.e:1352		return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_27495);
    _15206 = _53NewStringSym(_string_text_27495);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15206;
    _15207 = MAKE_SEQ(_1);
    _15206 = NOVALUE;
    DeRefDSi(_string_text_27495);
    DeRef(_15180);
    _15180 = NOVALUE;
    DeRef(_15185);
    _15185 = NOVALUE;
    DeRef(_15198);
    _15198 = NOVALUE;
    DeRef(_15191);
    _15191 = NOVALUE;
    DeRef(_15204);
    _15204 = NOVALUE;
    return _15207;
    ;
}


object _61GetHexString(object _maxnibbles_27583)
{
    object _ch_27584 = NOVALUE;
    object _digit_27585 = NOVALUE;
    object _val_27586 = NOVALUE;
    object _cline_27587 = NOVALUE;
    object _nibble_27588 = NOVALUE;
    object _string_text_27589 = NOVALUE;
    object _15221 = NOVALUE;
    object _15220 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1363		cline = line_number*/
    _cline_27587 = _27line_number_20572;

    /** scanner.e:1364		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27589);
    _string_text_27589 = _5;

    /** scanner.e:1365		nibble = 1*/
    _nibble_27588 = 1;

    /** scanner.e:1366		val = -1*/
    DeRef(_val_27586);
    _val_27586 = -1;

    /** scanner.e:1367		ch = getch()*/
    _ch_27584 = _61getch();
    if (!IS_ATOM_INT(_ch_27584)) {
        _1 = (object)(DBL_PTR(_ch_27584)->dbl);
        DeRefDS(_ch_27584);
        _ch_27584 = _1;
    }

    /** scanner.e:1368		while 1 do*/
L1: 

    /** scanner.e:1369			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27584 != 26)
    goto L2; // [45] 59

    /** scanner.e:1370				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(129, _cline_27587, 0);
L2: 

    /** scanner.e:1373			if ch = '"' then*/
    if (_ch_27584 != 34)
    goto L3; // [61] 70

    /** scanner.e:1374				exit*/
    goto L4; // [67] 228
L3: 

    /** scanner.e:1377			digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_27585 = find_from(_ch_27584, _15211, 1);

    /** scanner.e:1378			if digit = 0 then*/
    if (_digit_27585 != 0)
    goto L5; // [79] 93

    /** scanner.e:1379				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22209);
    _49CompileErr(329, _22209, 0);
L5: 

    /** scanner.e:1381			if digit <= 23 then*/
    if (_digit_27585 > 23)
    goto L6; // [95] 181

    /** scanner.e:1382				if digit != 23 then*/
    if (_digit_27585 == 23)
    goto L7; // [101] 216

    /** scanner.e:1383					if digit > 16 then*/
    if (_digit_27585 <= 16)
    goto L8; // [107] 118

    /** scanner.e:1384						digit -= 6*/
    _digit_27585 = _digit_27585 - 6;
L8: 

    /** scanner.e:1386					if nibble = 1 then*/
    if (_nibble_27588 != 1)
    goto L9; // [120] 133

    /** scanner.e:1387						val = digit - 1*/
    DeRef(_val_27586);
    _val_27586 = _digit_27585 - 1;
    if ((object)((uintptr_t)_val_27586 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27586 = NewDouble((eudouble)_val_27586);
    }
    goto LA; // [130] 171
L9: 

    /** scanner.e:1389						val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_27586)) {
        if (_val_27586 == (short)_val_27586){
            _15220 = _val_27586 * 16;
        }
        else{
            _15220 = NewDouble(_val_27586 * (eudouble)16);
        }
    }
    else {
        _15220 = NewDouble(DBL_PTR(_val_27586)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15220)) {
        _15221 = _15220 + _digit_27585;
        if ((object)((uintptr_t)_15221 + (uintptr_t)HIGH_BITS) >= 0){
            _15221 = NewDouble((eudouble)_15221);
        }
    }
    else {
        _15221 = NewDouble(DBL_PTR(_15220)->dbl + (eudouble)_digit_27585);
    }
    DeRef(_15220);
    _15220 = NOVALUE;
    DeRef(_val_27586);
    if (IS_ATOM_INT(_15221)) {
        _val_27586 = _15221 - 1;
        if ((object)((uintptr_t)_val_27586 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27586 = NewDouble((eudouble)_val_27586);
        }
    }
    else {
        _val_27586 = NewDouble(DBL_PTR(_15221)->dbl - (eudouble)1);
    }
    DeRef(_15221);
    _15221 = NOVALUE;

    /** scanner.e:1390						if nibble = maxnibbles then*/
    if (_nibble_27588 != _maxnibbles_27583)
    goto LB; // [149] 170

    /** scanner.e:1391							string_text &= val*/
    Ref(_val_27586);
    Append(&_string_text_27589, _string_text_27589, _val_27586);

    /** scanner.e:1392							val = -1*/
    DeRef(_val_27586);
    _val_27586 = -1;

    /** scanner.e:1393							nibble = 0*/
    _nibble_27588 = 0;
LB: 
LA: 

    /** scanner.e:1396					nibble += 1*/
    _nibble_27588 = _nibble_27588 + 1;
    goto L7; // [178] 216
L6: 

    /** scanner.e:1399				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27586, 0)){
        goto LC; // [183] 199
    }

    /** scanner.e:1401					string_text &= val*/
    Ref(_val_27586);
    Append(&_string_text_27589, _string_text_27589, _val_27586);

    /** scanner.e:1402					val = -1*/
    DeRef(_val_27586);
    _val_27586 = -1;
LC: 

    /** scanner.e:1404				nibble = 1*/
    _nibble_27588 = 1;

    /** scanner.e:1405				if ch = '\n' then*/
    if (_ch_27584 != 10)
    goto LD; // [206] 215

    /** scanner.e:1406					read_line()*/
    _61read_line();
LD: 
L7: 

    /** scanner.e:1409			ch = getch()*/
    _ch_27584 = _61getch();
    if (!IS_ATOM_INT(_ch_27584)) {
        _1 = (object)(DBL_PTR(_ch_27584)->dbl);
        DeRefDS(_ch_27584);
        _ch_27584 = _1;
    }

    /** scanner.e:1410		end while*/
    goto L1; // [225] 41
L4: 

    /** scanner.e:1412		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27586, 0)){
        goto LE; // [230] 241
    }

    /** scanner.e:1414			string_text &= val*/
    Ref(_val_27586);
    Append(&_string_text_27589, _string_text_27589, _val_27586);
LE: 

    /** scanner.e:1417		return string_text*/
    DeRef(_val_27586);
    return _string_text_27589;
    ;
}


object _61GetBitString()
{
    object _ch_27636 = NOVALUE;
    object _digit_27637 = NOVALUE;
    object _val_27638 = NOVALUE;
    object _cline_27639 = NOVALUE;
    object _bitcnt_27640 = NOVALUE;
    object _string_text_27641 = NOVALUE;
    object _15243 = NOVALUE;
    object _15242 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1428		cline = line_number*/
    _cline_27639 = _27line_number_20572;

    /** scanner.e:1429		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27641);
    _string_text_27641 = _5;

    /** scanner.e:1430		bitcnt = 1*/
    _bitcnt_27640 = 1;

    /** scanner.e:1431		val = -1*/
    DeRef(_val_27638);
    _val_27638 = -1;

    /** scanner.e:1432		ch = getch()*/
    _ch_27636 = _61getch();
    if (!IS_ATOM_INT(_ch_27636)) {
        _1 = (object)(DBL_PTR(_ch_27636)->dbl);
        DeRefDS(_ch_27636);
        _ch_27636 = _1;
    }

    /** scanner.e:1433		while 1 do*/
L1: 

    /** scanner.e:1434			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27636 != 26)
    goto L2; // [43] 57

    /** scanner.e:1435				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(129, _cline_27639, 0);
L2: 

    /** scanner.e:1438			if ch = '"' then*/
    if (_ch_27636 != 34)
    goto L3; // [59] 68

    /** scanner.e:1439				exit*/
    goto L4; // [65] 190
L3: 

    /** scanner.e:1442			digit = find(ch, "01_ \t\n\r")*/
    _digit_27637 = find_from(_ch_27636, _15235, 1);

    /** scanner.e:1443			if digit = 0 then*/
    if (_digit_27637 != 0)
    goto L5; // [77] 91

    /** scanner.e:1444				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22209);
    _49CompileErr(329, _22209, 0);
L5: 

    /** scanner.e:1446			if digit <= 3 then*/
    if (_digit_27637 > 3)
    goto L6; // [93] 143

    /** scanner.e:1447				if digit != 3 then*/
    if (_digit_27637 == 3)
    goto L7; // [99] 178

    /** scanner.e:1448					if bitcnt = 1 then*/
    if (_bitcnt_27640 != 1)
    goto L8; // [105] 118

    /** scanner.e:1449						val = digit - 1*/
    DeRef(_val_27638);
    _val_27638 = _digit_27637 - 1;
    if ((object)((uintptr_t)_val_27638 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27638 = NewDouble((eudouble)_val_27638);
    }
    goto L9; // [115] 133
L8: 

    /** scanner.e:1451						val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_27638) && IS_ATOM_INT(_val_27638)) {
        _15242 = _val_27638 + _val_27638;
        if ((object)((uintptr_t)_15242 + (uintptr_t)HIGH_BITS) >= 0){
            _15242 = NewDouble((eudouble)_15242);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27638)) {
            _15242 = NewDouble((eudouble)_val_27638 + DBL_PTR(_val_27638)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27638)) {
                _15242 = NewDouble(DBL_PTR(_val_27638)->dbl + (eudouble)_val_27638);
            }
            else
            _15242 = NewDouble(DBL_PTR(_val_27638)->dbl + DBL_PTR(_val_27638)->dbl);
        }
    }
    if (IS_ATOM_INT(_15242)) {
        _15243 = _15242 + _digit_27637;
        if ((object)((uintptr_t)_15243 + (uintptr_t)HIGH_BITS) >= 0){
            _15243 = NewDouble((eudouble)_15243);
        }
    }
    else {
        _15243 = NewDouble(DBL_PTR(_15242)->dbl + (eudouble)_digit_27637);
    }
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_val_27638);
    if (IS_ATOM_INT(_15243)) {
        _val_27638 = _15243 - 1;
        if ((object)((uintptr_t)_val_27638 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27638 = NewDouble((eudouble)_val_27638);
        }
    }
    else {
        _val_27638 = NewDouble(DBL_PTR(_15243)->dbl - (eudouble)1);
    }
    DeRef(_15243);
    _15243 = NOVALUE;
L9: 

    /** scanner.e:1453					bitcnt += 1*/
    _bitcnt_27640 = _bitcnt_27640 + 1;
    goto L7; // [140] 178
L6: 

    /** scanner.e:1456				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27638, 0)){
        goto LA; // [145] 161
    }

    /** scanner.e:1458					string_text &= val*/
    Ref(_val_27638);
    Append(&_string_text_27641, _string_text_27641, _val_27638);

    /** scanner.e:1459					val = -1*/
    DeRef(_val_27638);
    _val_27638 = -1;
LA: 

    /** scanner.e:1461				bitcnt = 1*/
    _bitcnt_27640 = 1;

    /** scanner.e:1462				if ch = '\n' then*/
    if (_ch_27636 != 10)
    goto LB; // [168] 177

    /** scanner.e:1463					read_line()*/
    _61read_line();
LB: 
L7: 

    /** scanner.e:1466			ch = getch()*/
    _ch_27636 = _61getch();
    if (!IS_ATOM_INT(_ch_27636)) {
        _1 = (object)(DBL_PTR(_ch_27636)->dbl);
        DeRefDS(_ch_27636);
        _ch_27636 = _1;
    }

    /** scanner.e:1467		end while*/
    goto L1; // [187] 39
L4: 

    /** scanner.e:1469		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27638, 0)){
        goto LC; // [192] 203
    }

    /** scanner.e:1471			string_text &= val*/
    Ref(_val_27638);
    Append(&_string_text_27641, _string_text_27641, _val_27638);
LC: 

    /** scanner.e:1474		return string_text*/
    DeRef(_val_27638);
    return _string_text_27641;
    ;
}


object _61Scanner()
{
    object _fwd_inlined_set_qualified_fwd_at_441_27781 = NOVALUE;
    object _ch_27682 = NOVALUE;
    object _sp_27683 = NOVALUE;
    object _prev_Nne_27684 = NOVALUE;
    object _i_27685 = NOVALUE;
    object _pch_27686 = NOVALUE;
    object _cline_27687 = NOVALUE;
    object _yytext_27688 = NOVALUE;
    object _namespaces_27689 = NOVALUE;
    object _d_27690 = NOVALUE;
    object _tok_27692 = NOVALUE;
    object _is_int_27693 = NOVALUE;
    object _class_27694 = NOVALUE;
    object _name_27695 = NOVALUE;
    object _is_namespace_27754 = NOVALUE;
    object _basetype_27990 = NOVALUE;
    object _hdigit_28031 = NOVALUE;
    object _fch_28171 = NOVALUE;
    object _cnest_28355 = NOVALUE;
    object _ach_28385 = NOVALUE;
    object _32010 = NOVALUE;
    object _32009 = NOVALUE;
    object _32008 = NOVALUE;
    object _32007 = NOVALUE;
    object _32006 = NOVALUE;
    object _32005 = NOVALUE;
    object _32004 = NOVALUE;
    object _15636 = NOVALUE;
    object _15635 = NOVALUE;
    object _15633 = NOVALUE;
    object _15631 = NOVALUE;
    object _15630 = NOVALUE;
    object _15629 = NOVALUE;
    object _15627 = NOVALUE;
    object _15626 = NOVALUE;
    object _15625 = NOVALUE;
    object _15624 = NOVALUE;
    object _15622 = NOVALUE;
    object _15621 = NOVALUE;
    object _15619 = NOVALUE;
    object _15617 = NOVALUE;
    object _15616 = NOVALUE;
    object _15614 = NOVALUE;
    object _15612 = NOVALUE;
    object _15611 = NOVALUE;
    object _15609 = NOVALUE;
    object _15607 = NOVALUE;
    object _15606 = NOVALUE;
    object _15605 = NOVALUE;
    object _15604 = NOVALUE;
    object _15603 = NOVALUE;
    object _15601 = NOVALUE;
    object _15600 = NOVALUE;
    object _15590 = NOVALUE;
    object _15577 = NOVALUE;
    object _15573 = NOVALUE;
    object _15572 = NOVALUE;
    object _15568 = NOVALUE;
    object _15567 = NOVALUE;
    object _15566 = NOVALUE;
    object _15565 = NOVALUE;
    object _15563 = NOVALUE;
    object _15562 = NOVALUE;
    object _15561 = NOVALUE;
    object _15560 = NOVALUE;
    object _15557 = NOVALUE;
    object _15556 = NOVALUE;
    object _15555 = NOVALUE;
    object _15554 = NOVALUE;
    object _15553 = NOVALUE;
    object _15552 = NOVALUE;
    object _15550 = NOVALUE;
    object _15549 = NOVALUE;
    object _15548 = NOVALUE;
    object _15547 = NOVALUE;
    object _15546 = NOVALUE;
    object _15545 = NOVALUE;
    object _15543 = NOVALUE;
    object _15542 = NOVALUE;
    object _15539 = NOVALUE;
    object _15536 = NOVALUE;
    object _15531 = NOVALUE;
    object _15530 = NOVALUE;
    object _15529 = NOVALUE;
    object _15528 = NOVALUE;
    object _15527 = NOVALUE;
    object _15526 = NOVALUE;
    object _15524 = NOVALUE;
    object _15523 = NOVALUE;
    object _15522 = NOVALUE;
    object _15521 = NOVALUE;
    object _15520 = NOVALUE;
    object _15519 = NOVALUE;
    object _15517 = NOVALUE;
    object _15516 = NOVALUE;
    object _15513 = NOVALUE;
    object _15510 = NOVALUE;
    object _15508 = NOVALUE;
    object _15507 = NOVALUE;
    object _15503 = NOVALUE;
    object _15502 = NOVALUE;
    object _15498 = NOVALUE;
    object _15497 = NOVALUE;
    object _15496 = NOVALUE;
    object _15494 = NOVALUE;
    object _15489 = NOVALUE;
    object _15486 = NOVALUE;
    object _15485 = NOVALUE;
    object _15484 = NOVALUE;
    object _15483 = NOVALUE;
    object _15477 = NOVALUE;
    object _15475 = NOVALUE;
    object _15470 = NOVALUE;
    object _15469 = NOVALUE;
    object _15468 = NOVALUE;
    object _15467 = NOVALUE;
    object _15466 = NOVALUE;
    object _15465 = NOVALUE;
    object _15464 = NOVALUE;
    object _15462 = NOVALUE;
    object _15460 = NOVALUE;
    object _15459 = NOVALUE;
    object _15458 = NOVALUE;
    object _15457 = NOVALUE;
    object _15456 = NOVALUE;
    object _15454 = NOVALUE;
    object _15449 = NOVALUE;
    object _15448 = NOVALUE;
    object _15446 = NOVALUE;
    object _15442 = NOVALUE;
    object _15439 = NOVALUE;
    object _15438 = NOVALUE;
    object _15436 = NOVALUE;
    object _15435 = NOVALUE;
    object _15434 = NOVALUE;
    object _15431 = NOVALUE;
    object _15429 = NOVALUE;
    object _15428 = NOVALUE;
    object _15424 = NOVALUE;
    object _15420 = NOVALUE;
    object _15417 = NOVALUE;
    object _15411 = NOVALUE;
    object _15403 = NOVALUE;
    object _15402 = NOVALUE;
    object _15401 = NOVALUE;
    object _15399 = NOVALUE;
    object _15396 = NOVALUE;
    object _15394 = NOVALUE;
    object _15392 = NOVALUE;
    object _15389 = NOVALUE;
    object _15386 = NOVALUE;
    object _15384 = NOVALUE;
    object _15382 = NOVALUE;
    object _15380 = NOVALUE;
    object _15379 = NOVALUE;
    object _15375 = NOVALUE;
    object _15372 = NOVALUE;
    object _15370 = NOVALUE;
    object _15367 = NOVALUE;
    object _15360 = NOVALUE;
    object _15358 = NOVALUE;
    object _15355 = NOVALUE;
    object _15349 = NOVALUE;
    object _15348 = NOVALUE;
    object _15347 = NOVALUE;
    object _15346 = NOVALUE;
    object _15345 = NOVALUE;
    object _15344 = NOVALUE;
    object _15343 = NOVALUE;
    object _15341 = NOVALUE;
    object _15339 = NOVALUE;
    object _15337 = NOVALUE;
    object _15335 = NOVALUE;
    object _15333 = NOVALUE;
    object _15332 = NOVALUE;
    object _15331 = NOVALUE;
    object _15330 = NOVALUE;
    object _15329 = NOVALUE;
    object _15327 = NOVALUE;
    object _15324 = NOVALUE;
    object _15322 = NOVALUE;
    object _15321 = NOVALUE;
    object _15320 = NOVALUE;
    object _15318 = NOVALUE;
    object _15313 = NOVALUE;
    object _15309 = NOVALUE;
    object _15306 = NOVALUE;
    object _15304 = NOVALUE;
    object _15303 = NOVALUE;
    object _15301 = NOVALUE;
    object _15299 = NOVALUE;
    object _15297 = NOVALUE;
    object _15296 = NOVALUE;
    object _15295 = NOVALUE;
    object _15293 = NOVALUE;
    object _15288 = NOVALUE;
    object _15285 = NOVALUE;
    object _15283 = NOVALUE;
    object _15280 = NOVALUE;
    object _15279 = NOVALUE;
    object _15277 = NOVALUE;
    object _15276 = NOVALUE;
    object _15275 = NOVALUE;
    object _15274 = NOVALUE;
    object _15273 = NOVALUE;
    object _15272 = NOVALUE;
    object _15271 = NOVALUE;
    object _15270 = NOVALUE;
    object _15269 = NOVALUE;
    object _15268 = NOVALUE;
    object _15267 = NOVALUE;
    object _15266 = NOVALUE;
    object _15265 = NOVALUE;
    object _15260 = NOVALUE;
    object _15258 = NOVALUE;
    object _15255 = NOVALUE;
    object _15253 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1486		integer is_int, class*/

    /** scanner.e:1487		sequence name*/

    /** scanner.e:1489		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [12] 3821
    }
    else{
    }

    /** scanner.e:1490			ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1491			while ch = ' ' or ch = '\t' do*/
L3: 
    _15253 = (_ch_27682 == 32);
    if (_15253 != 0) {
        goto L4; // [31] 44
    }
    _15255 = (_ch_27682 == 9);
    if (_15255 == 0)
    {
        DeRef(_15255);
        _15255 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_15255);
        _15255 = NOVALUE;
    }
L4: 

    /** scanner.e:1492				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1493			end while*/
    goto L3; // [53] 27
L5: 

    /** scanner.e:1495			class = char_class[ch]*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _class_27694 = (object)*(((s1_ptr)_2)->base + _ch_27682);

    /** scanner.e:1498			if class = LETTER or ch = '_' then*/
    _15258 = (_class_27694 == -2);
    if (_15258 != 0) {
        goto L6; // [72] 85
    }
    _15260 = (_ch_27682 == 95);
    if (_15260 == 0)
    {
        DeRef(_15260);
        _15260 = NOVALUE;
        goto L7; // [81] 1284
    }
    else{
        DeRef(_15260);
        _15260 = NOVALUE;
    }
L6: 

    /** scanner.e:1499				sp = bp*/
    _sp_27683 = _49bp_49646;

    /** scanner.e:1500				pch = ch*/
    _pch_27686 = _ch_27682;

    /** scanner.e:1501				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1502				if ch = '"' then*/
    if (_ch_27682 != 34)
    goto L8; // [108] 222

    /** scanner.e:1503					switch pch do*/
    _0 = _pch_27686;
    switch ( _0 ){ 

        /** scanner.e:1504						case 'x' then*/
        case 120:

        /** scanner.e:1505							return {STRING, NewStringSym(GetHexString(2))}*/
        _15265 = _61GetHexString(2);
        _15266 = _53NewStringSym(_15265);
        _15265 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15266;
        _15267 = MAKE_SEQ(_1);
        _15266 = NOVALUE;
        DeRef(_i_27685);
        DeRef(_yytext_27688);
        DeRef(_namespaces_27689);
        DeRef(_d_27690);
        DeRef(_tok_27692);
        DeRef(_name_27695);
        DeRef(_15253);
        _15253 = NOVALUE;
        DeRef(_15258);
        _15258 = NOVALUE;
        return _15267;
        goto L9; // [143] 221

        /** scanner.e:1507						case 'u' then*/
        case 117:

        /** scanner.e:1508							return {STRING, NewStringSym(GetHexString(4))}*/
        _15268 = _61GetHexString(4);
        _15269 = _53NewStringSym(_15268);
        _15268 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15269;
        _15270 = MAKE_SEQ(_1);
        _15269 = NOVALUE;
        DeRef(_i_27685);
        DeRef(_yytext_27688);
        DeRef(_namespaces_27689);
        DeRef(_d_27690);
        DeRef(_tok_27692);
        DeRef(_name_27695);
        DeRef(_15267);
        _15267 = NOVALUE;
        DeRef(_15253);
        _15253 = NOVALUE;
        DeRef(_15258);
        _15258 = NOVALUE;
        return _15270;
        goto L9; // [169] 221

        /** scanner.e:1510						case 'U' then*/
        case 85:

        /** scanner.e:1511							return {STRING, NewStringSym(GetHexString(8))}*/
        _15271 = _61GetHexString(8);
        _15272 = _53NewStringSym(_15271);
        _15271 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15272;
        _15273 = MAKE_SEQ(_1);
        _15272 = NOVALUE;
        DeRef(_i_27685);
        DeRef(_yytext_27688);
        DeRef(_namespaces_27689);
        DeRef(_d_27690);
        DeRef(_tok_27692);
        DeRef(_name_27695);
        DeRef(_15267);
        _15267 = NOVALUE;
        DeRef(_15253);
        _15253 = NOVALUE;
        DeRef(_15270);
        _15270 = NOVALUE;
        DeRef(_15258);
        _15258 = NOVALUE;
        return _15273;
        goto L9; // [195] 221

        /** scanner.e:1513						case 'b' then*/
        case 98:

        /** scanner.e:1514							return {STRING, NewStringSym(GetBitString())}*/
        _15274 = _61GetBitString();
        _15275 = _53NewStringSym(_15274);
        _15274 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503;
        ((intptr_t *)_2)[2] = _15275;
        _15276 = MAKE_SEQ(_1);
        _15275 = NOVALUE;
        DeRef(_i_27685);
        DeRef(_yytext_27688);
        DeRef(_namespaces_27689);
        DeRef(_d_27690);
        DeRef(_tok_27692);
        DeRef(_name_27695);
        DeRef(_15267);
        _15267 = NOVALUE;
        DeRef(_15253);
        _15253 = NOVALUE;
        DeRef(_15270);
        _15270 = NOVALUE;
        DeRef(_15258);
        _15258 = NOVALUE;
        DeRef(_15273);
        _15273 = NOVALUE;
        return _15276;
    ;}L9: 
L8: 

    /** scanner.e:1519				while id_char[ch] do*/
LA: 
    _2 = (object)SEQ_PTR(_61id_char_25933);
    _15277 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15277 == 0)
    {
        _15277 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _15277 = NOVALUE;
    }

    /** scanner.e:1520					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1521				end while*/
    goto LA; // [245] 227
LB: 

    /** scanner.e:1522				yytext = ThisLine[sp-1..bp-2]*/
    _15279 = _sp_27683 - 1;
    if ((object)((uintptr_t)_15279 +(uintptr_t) HIGH_BITS) >= 0){
        _15279 = NewDouble((eudouble)_15279);
    }
    _15280 = _49bp_49646 - 2;
    rhs_slice_target = (object_ptr)&_yytext_27688;
    RHS_Slice(_49ThisLine_49642, _15279, _15280);

    /** scanner.e:1523				ungetch()*/
    _61ungetch();

    /** scanner.e:1525				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1526				while ch = ' ' or ch = '\t' do*/
LC: 
    _15283 = (_ch_27682 == 32);
    if (_15283 != 0) {
        goto LD; // [287] 300
    }
    _15285 = (_ch_27682 == 9);
    if (_15285 == 0)
    {
        DeRef(_15285);
        _15285 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_15285);
        _15285 = NOVALUE;
    }
LD: 

    /** scanner.e:1527					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1528				end while*/
    goto LC; // [309] 283
LE: 

    /** scanner.e:1529				integer is_namespace*/

    /** scanner.e:1531				if might_be_namespace then*/
    if (_61might_be_namespace_27481 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** scanner.e:1532					tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_27688);
    _32010 = _53hashfn(_yytext_27688);
    RefDS(_yytext_27688);
    _0 = _tok_27692;
    _tok_27692 = _53keyfind(_yytext_27688, -1, _27current_file_no_20571, -1, _32010);
    DeRef(_0);
    _32010 = NOVALUE;

    /** scanner.e:1533					is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15288 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_15288)) {
        _is_namespace_27754 = (_15288 == 523);
    }
    else {
        _is_namespace_27754 = binary_op(EQUALS, _15288, 523);
    }
    _15288 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_27754)) {
        _1 = (object)(DBL_PTR(_is_namespace_27754)->dbl);
        DeRefDS(_is_namespace_27754);
        _is_namespace_27754 = _1;
    }

    /** scanner.e:1534					might_be_namespace = 0*/
    _61might_be_namespace_27481 = 0;
    goto L10; // [358] 384
LF: 

    /** scanner.e:1536					is_namespace = ch = ':'*/
    _is_namespace_27754 = (_ch_27682 == 58);

    /** scanner.e:1537					tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_27688);
    _32009 = _53hashfn(_yytext_27688);
    RefDS(_yytext_27688);
    _0 = _tok_27692;
    _tok_27692 = _53keyfind(_yytext_27688, -1, _27current_file_no_20571, _is_namespace_27754, _32009);
    DeRef(_0);
    _32009 = NOVALUE;
L10: 

    /** scanner.e:1541				if not is_namespace then*/
    if (_is_namespace_27754 != 0)
    goto L11; // [388] 396

    /** scanner.e:1542					ungetch()*/
    _61ungetch();
L11: 

    /** scanner.e:1545				if is_namespace then*/
    if (_is_namespace_27754 == 0)
    {
        goto L12; // [398] 1121
    }
    else{
    }

    /** scanner.e:1547					namespaces = yytext*/
    RefDS(_yytext_27688);
    DeRef(_namespaces_27689);
    _namespaces_27689 = _yytext_27688;

    /** scanner.e:1550					if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15293 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15293, 523)){
        _15293 = NOVALUE;
        goto L13; // [420] 976
    }
    _15293 = NOVALUE;

    /** scanner.e:1551						set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15295 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_15295)){
        _15296 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15295)->dbl));
    }
    else{
        _15296 = (object)*(((s1_ptr)_2)->base + _15295);
    }
    _2 = (object)SEQ_PTR(_15296);
    _15297 = (object)*(((s1_ptr)_2)->base + 1);
    _15296 = NOVALUE;
    Ref(_15297);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27781);
    _fwd_inlined_set_qualified_fwd_at_441_27781 = _15297;
    _15297 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_27781)) {
        _1 = (object)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_27781)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_27781);
        _fwd_inlined_set_qualified_fwd_at_441_27781 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25957 = _fwd_inlined_set_qualified_fwd_at_441_27781;

    /** scanner.e:105	end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27781);
    _fwd_inlined_set_qualified_fwd_at_441_27781 = NOVALUE;

    /** scanner.e:1554						ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1555						while ch = ' ' or ch = '\t' do*/
L15: 
    _15299 = (_ch_27682 == 32);
    if (_15299 != 0) {
        goto L16; // [477] 490
    }
    _15301 = (_ch_27682 == 9);
    if (_15301 == 0)
    {
        DeRef(_15301);
        _15301 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_15301);
        _15301 = NOVALUE;
    }
L16: 

    /** scanner.e:1556							ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1557						end while*/
    goto L15; // [499] 473
L17: 

    /** scanner.e:1558						yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27688);
    _yytext_27688 = _5;

    /** scanner.e:1559						if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15303 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    _15304 = (_15303 == -2);
    _15303 = NOVALUE;
    if (_15304 != 0) {
        goto L18; // [523] 536
    }
    _15306 = (_ch_27682 == 95);
    if (_15306 == 0)
    {
        DeRef(_15306);
        _15306 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_15306);
        _15306 = NOVALUE;
    }
L18: 

    /** scanner.e:1560							yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);

    /** scanner.e:1561							ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1562							while id_char[ch] = TRUE do*/
L1A: 
    _2 = (object)SEQ_PTR(_61id_char_25933);
    _15309 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15309 != _9TRUE_441)
    goto L1B; // [562] 584

    /** scanner.e:1563								yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);

    /** scanner.e:1564								ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1565							end while*/
    goto L1A; // [581] 554
L1B: 

    /** scanner.e:1566							ungetch()*/
    _61ungetch();
L19: 

    /** scanner.e:1569						if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_27688)){
            _15313 = SEQ_PTR(_yytext_27688)->length;
    }
    else {
        _15313 = 1;
    }
    if (_15313 != 0)
    goto L1C; // [594] 608

    /** scanner.e:1570							CompileErr(AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(32, _22209, 0);
L1C: 

    /** scanner.e:1576					    if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1)
    goto L1D; // [614] 775

    /** scanner.e:1577			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27688);
    Append(&_27Recorded_20678, _27Recorded_20678, _yytext_27688);

    /** scanner.e:1578			                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_27689);
    Append(&_27Ns_recorded_20679, _27Ns_recorded_20679, _namespaces_27689);

    /** scanner.e:1579			                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15318 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_27Ns_recorded_sym_20681) && IS_ATOM(_15318)) {
        Ref(_15318);
        Append(&_27Ns_recorded_sym_20681, _27Ns_recorded_sym_20681, _15318);
    }
    else if (IS_ATOM(_27Ns_recorded_sym_20681) && IS_SEQUENCE(_15318)) {
    }
    else {
        Concat((object_ptr)&_27Ns_recorded_sym_20681, _27Ns_recorded_sym_20681, _15318);
    }
    _15318 = NOVALUE;

    /** scanner.e:1580			                prev_Nne = No_new_entry*/
    _prev_Nne_27684 = _53No_new_entry_48382;

    /** scanner.e:1581							No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** scanner.e:1582							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15320 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_15320)){
        _15321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15320)->dbl));
    }
    else{
        _15321 = (object)*(((s1_ptr)_2)->base + _15320);
    }
    _2 = (object)SEQ_PTR(_15321);
    _15322 = (object)*(((s1_ptr)_2)->base + 1);
    _15321 = NOVALUE;
    RefDS(_yytext_27688);
    _32008 = _53hashfn(_yytext_27688);
    RefDS(_yytext_27688);
    Ref(_15322);
    _0 = _tok_27692;
    _tok_27692 = _53keyfind(_yytext_27688, _15322, _27current_file_no_20571, 0, _32008);
    DeRef(_0);
    _15322 = NOVALUE;
    _32008 = NOVALUE;

    /** scanner.e:1583							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15324 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15324, 509)){
        _15324 = NOVALUE;
        goto L1E; // [714] 731
    }
    _15324 = NOVALUE;

    /** scanner.e:1584								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_27Recorded_sym_20680, _27Recorded_sym_20680, 0);
    goto L1F; // [728] 748
L1E: 

    /** scanner.e:1586								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15327 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_27Recorded_sym_20680) && IS_ATOM(_15327)) {
        Ref(_15327);
        Append(&_27Recorded_sym_20680, _27Recorded_sym_20680, _15327);
    }
    else if (IS_ATOM(_27Recorded_sym_20680) && IS_SEQUENCE(_15327)) {
    }
    else {
        Concat((object_ptr)&_27Recorded_sym_20680, _27Recorded_sym_20680, _15327);
    }
    _15327 = NOVALUE;
L1F: 

    /** scanner.e:1588			                No_new_entry = prev_Nne*/
    _53No_new_entry_48382 = _prev_Nne_27684;

    /** scanner.e:1589			                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_27Recorded_20678)){
            _15329 = SEQ_PTR(_27Recorded_20678)->length;
    }
    else {
        _15329 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15329;
    _15330 = MAKE_SEQ(_1);
    _15329 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15295 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    return _15330;
    goto L20; // [772] 917
L1D: 

    /** scanner.e:1591							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15331 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_15331)){
        _15332 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15331)->dbl));
    }
    else{
        _15332 = (object)*(((s1_ptr)_2)->base + _15331);
    }
    _2 = (object)SEQ_PTR(_15332);
    _15333 = (object)*(((s1_ptr)_2)->base + 1);
    _15332 = NOVALUE;
    RefDS(_yytext_27688);
    _32007 = _53hashfn(_yytext_27688);
    RefDS(_yytext_27688);
    Ref(_15333);
    _0 = _tok_27692;
    _tok_27692 = _53keyfind(_yytext_27688, _15333, _27current_file_no_20571, 0, _32007);
    DeRef(_0);
    _15333 = NOVALUE;
    _32007 = NOVALUE;

    /** scanner.e:1593							if tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15335 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15335, -100)){
        _15335 = NOVALUE;
        goto L21; // [819] 836
    }
    _15335 = NOVALUE;

    /** scanner.e:1594								tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (object)SEQ_PTR(_tok_27692);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27692 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 512;
    DeRef(_1);
    goto L22; // [833] 916
L21: 

    /** scanner.e:1595							elsif tok[T_ID] = FUNC then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15337 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15337, 501)){
        _15337 = NOVALUE;
        goto L23; // [846] 863
    }
    _15337 = NOVALUE;

    /** scanner.e:1596								tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (object)SEQ_PTR(_tok_27692);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27692 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 520;
    DeRef(_1);
    goto L22; // [860] 916
L23: 

    /** scanner.e:1597							elsif tok[T_ID] = PROC then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15339 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15339, 27)){
        _15339 = NOVALUE;
        goto L24; // [873] 890
    }
    _15339 = NOVALUE;

    /** scanner.e:1598								tok[T_ID] = QUALIFIED_PROC*/
    _2 = (object)SEQ_PTR(_tok_27692);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27692 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 521;
    DeRef(_1);
    goto L22; // [887] 916
L24: 

    /** scanner.e:1599							elsif tok[T_ID] = TYPE then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15341 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15341, 504)){
        _15341 = NOVALUE;
        goto L25; // [900] 915
    }
    _15341 = NOVALUE;

    /** scanner.e:1600								tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (object)SEQ_PTR(_tok_27692);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27692 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** scanner.e:1605						if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15343 = (object)*(((s1_ptr)_2)->base + 2);
    _15344 = IS_ATOM(_15343);
    _15343 = NOVALUE;
    if (_15344 == 0) {
        goto L26; // [928] 1271
    }
    _2 = (object)SEQ_PTR(_tok_27692);
    _15346 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_15346)){
        _15347 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15346)->dbl));
    }
    else{
        _15347 = (object)*(((s1_ptr)_2)->base + _15346);
    }
    _2 = (object)SEQ_PTR(_15347);
    _15348 = (object)*(((s1_ptr)_2)->base + 4);
    _15347 = NOVALUE;
    if (IS_ATOM_INT(_15348)) {
        _15349 = (_15348 != 9);
    }
    else {
        _15349 = binary_op(NOTEQ, _15348, 9);
    }
    _15348 = NOVALUE;
    if (_15349 == 0) {
        DeRef(_15349);
        _15349 = NOVALUE;
        goto L26; // [957] 1271
    }
    else {
        if (!IS_ATOM_INT(_15349) && DBL_PTR(_15349)->dbl == 0.0){
            DeRef(_15349);
            _15349 = NOVALUE;
            goto L26; // [957] 1271
        }
        DeRef(_15349);
        _15349 = NOVALUE;
    }
    DeRef(_15349);
    _15349 = NOVALUE;

    /** scanner.e:1606							set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25957 = -1;

    /** scanner.e:105	end procedure*/
    goto L26; // [969] 1271
    goto L26; // [973] 1271
L13: 

    /** scanner.e:1610						ungetch()*/
    _61ungetch();

    /** scanner.e:1611					    if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1)
    goto L26; // [986] 1271

    /** scanner.e:1612			                Ns_recorded &= 0*/
    Append(&_27Ns_recorded_20679, _27Ns_recorded_20679, 0);

    /** scanner.e:1613			                Ns_recorded_sym &= 0*/
    Append(&_27Ns_recorded_sym_20681, _27Ns_recorded_sym_20681, 0);

    /** scanner.e:1614			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27688);
    Append(&_27Recorded_20678, _27Recorded_20678, _yytext_27688);

    /** scanner.e:1615			                prev_Nne = No_new_entry*/
    _prev_Nne_27684 = _53No_new_entry_48382;

    /** scanner.e:1616							No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** scanner.e:1617							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27688);
    _32006 = _53hashfn(_yytext_27688);
    RefDS(_yytext_27688);
    _0 = _tok_27692;
    _tok_27692 = _53keyfind(_yytext_27688, -1, _27current_file_no_20571, 0, _32006);
    DeRef(_0);
    _32006 = NOVALUE;

    /** scanner.e:1618							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15355 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15355, 509)){
        _15355 = NOVALUE;
        goto L27; // [1062] 1079
    }
    _15355 = NOVALUE;

    /** scanner.e:1619								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_27Recorded_sym_20680, _27Recorded_sym_20680, 0);
    goto L28; // [1076] 1096
L27: 

    /** scanner.e:1621								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15358 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_27Recorded_sym_20680) && IS_ATOM(_15358)) {
        Ref(_15358);
        Append(&_27Recorded_sym_20680, _27Recorded_sym_20680, _15358);
    }
    else if (IS_ATOM(_27Recorded_sym_20680) && IS_SEQUENCE(_15358)) {
    }
    else {
        Concat((object_ptr)&_27Recorded_sym_20680, _27Recorded_sym_20680, _15358);
    }
    _15358 = NOVALUE;
L28: 

    /** scanner.e:1623			                No_new_entry = prev_Nne*/
    _53No_new_entry_48382 = _prev_Nne_27684;

    /** scanner.e:1624			                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_27Recorded_20678)){
            _15360 = SEQ_PTR(_27Recorded_20678)->length;
    }
    else {
        _15360 = 1;
    }
    DeRef(_tok_27692);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15360;
    _tok_27692 = MAKE_SEQ(_1);
    _15360 = NOVALUE;
    goto L26; // [1118] 1271
L12: 

    /** scanner.e:1628					set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _61qualified_fwd_25957 = -1;

    /** scanner.e:105	end procedure*/
    goto L29; // [1130] 1133
L29: 

    /** scanner.e:1629				    if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1)
    goto L2A; // [1139] 1270

    /** scanner.e:1630		                Ns_recorded_sym &= 0*/
    Append(&_27Ns_recorded_sym_20681, _27Ns_recorded_sym_20681, 0);

    /** scanner.e:1631							Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_27688);
    Append(&_27Recorded_20678, _27Recorded_20678, _yytext_27688);

    /** scanner.e:1632			                Ns_recorded &= 0*/
    Append(&_27Ns_recorded_20679, _27Ns_recorded_20679, 0);

    /** scanner.e:1633			                prev_Nne = No_new_entry*/
    _prev_Nne_27684 = _53No_new_entry_48382;

    /** scanner.e:1634							No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** scanner.e:1635							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27688);
    _32005 = _53hashfn(_yytext_27688);
    RefDS(_yytext_27688);
    _0 = _tok_27692;
    _tok_27692 = _53keyfind(_yytext_27688, -1, _27current_file_no_20571, 0, _32005);
    DeRef(_0);
    _32005 = NOVALUE;

    /** scanner.e:1636							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15367 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15367, 509)){
        _15367 = NOVALUE;
        goto L2B; // [1215] 1232
    }
    _15367 = NOVALUE;

    /** scanner.e:1637								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_27Recorded_sym_20680, _27Recorded_sym_20680, 0);
    goto L2C; // [1229] 1249
L2B: 

    /** scanner.e:1639								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27692);
    _15370 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_27Recorded_sym_20680) && IS_ATOM(_15370)) {
        Ref(_15370);
        Append(&_27Recorded_sym_20680, _27Recorded_sym_20680, _15370);
    }
    else if (IS_ATOM(_27Recorded_sym_20680) && IS_SEQUENCE(_15370)) {
    }
    else {
        Concat((object_ptr)&_27Recorded_sym_20680, _27Recorded_sym_20680, _15370);
    }
    _15370 = NOVALUE;
L2C: 

    /** scanner.e:1641			                No_new_entry = prev_Nne*/
    _53No_new_entry_48382 = _prev_Nne_27684;

    /** scanner.e:1642		                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_27Recorded_20678)){
            _15372 = SEQ_PTR(_27Recorded_20678)->length;
    }
    else {
        _15372 = 1;
    }
    DeRef(_tok_27692);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508;
    ((intptr_t *)_2)[2] = _15372;
    _tok_27692 = MAKE_SEQ(_1);
    _15372 = NOVALUE;
L2A: 
L26: 

    /** scanner.e:1646				return tok*/
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    return _tok_27692;
    goto L1; // [1281] 10
L7: 

    /** scanner.e:1648			elsif class < ILLEGAL_CHAR then*/
    if (_class_27694 >= -20)
    goto L2D; // [1288] 1305

    /** scanner.e:1649				return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27694;
    ((intptr_t *)_2)[2] = 0;
    _15375 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    return _15375;
    goto L1; // [1302] 10
L2D: 

    /** scanner.e:1651			elsif class = ILLEGAL_CHAR then*/
    if (_class_27694 != -20)
    goto L2E; // [1309] 1325

    /** scanner.e:1652				CompileErr(ILLEGAL_CHARACTER_IN_SOURCE)*/
    RefDS(_22209);
    _49CompileErr(101, _22209, 0);
    goto L1; // [1322] 10
L2E: 

    /** scanner.e:1654			elsif class = NEWLINE then*/
    if (_class_27694 != -6)
    goto L2F; // [1329] 1355

    /** scanner.e:1655				if start_include then*/
    if (_61start_include_25925 == 0)
    {
        goto L30; // [1337] 1347
    }
    else{
    }

    /** scanner.e:1656					IncludePush()*/
    _61IncludePush();
    goto L1; // [1344] 10
L30: 

    /** scanner.e:1658					read_line()*/
    _61read_line();
    goto L1; // [1352] 10
L2F: 

    /** scanner.e:1662			elsif class = EQUALS then*/
    if (_class_27694 != 3)
    goto L31; // [1359] 1376

    /** scanner.e:1663				return {class, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27694;
    ((intptr_t *)_2)[2] = 0;
    _15379 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    return _15379;
    goto L1; // [1373] 10
L31: 

    /** scanner.e:1665			elsif class = DOT or class = DIGIT then*/
    _15380 = (_class_27694 == -3);
    if (_15380 != 0) {
        goto L32; // [1384] 1399
    }
    _15382 = (_class_27694 == -7);
    if (_15382 == 0)
    {
        DeRef(_15382);
        _15382 = NOVALUE;
        goto L33; // [1395] 2195
    }
    else{
        DeRef(_15382);
        _15382 = NOVALUE;
    }
L32: 

    /** scanner.e:1666				integer basetype*/

    /** scanner.e:1667				if class = DOT then*/
    if (_class_27694 != -3)
    goto L34; // [1405] 1439

    /** scanner.e:1668					if getch() = '.' then*/
    _15384 = _61getch();
    if (binary_op_a(NOTEQ, _15384, 46)){
        DeRef(_15384);
        _15384 = NOVALUE;
        goto L35; // [1414] 1433
    }
    DeRef(_15384);
    _15384 = NOVALUE;

    /** scanner.e:1669						return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 513;
    ((intptr_t *)_2)[2] = 0;
    _15386 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    return _15386;
    goto L36; // [1430] 1438
L35: 

    /** scanner.e:1671						ungetch()*/
    _61ungetch();
L36: 
L34: 

    /** scanner.e:1675				yytext = {ch}*/
    _0 = _yytext_27688;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27682;
    _yytext_27688 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:1676				is_int = (ch != '.')*/
    _is_int_27693 = (_ch_27682 != 46);

    /** scanner.e:1677				basetype = -1 -- default is decimal*/
    _basetype_27990 = -1;

    /** scanner.e:1678				while 1 with entry do*/
    goto L37; // [1458] 1651
L38: 

    /** scanner.e:1679					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15389 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15389 != -7)
    goto L39; // [1471] 1484

    /** scanner.e:1680						yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);
    goto L3A; // [1481] 1648
L39: 

    /** scanner.e:1682					elsif equal(yytext, "0") then*/
    if (_yytext_27688 == _12197)
    _15392 = 1;
    else if (IS_ATOM_INT(_yytext_27688) && IS_ATOM_INT(_12197))
    _15392 = 0;
    else
    _15392 = (compare(_yytext_27688, _12197) == 0);
    if (_15392 == 0)
    {
        _15392 = NOVALUE;
        goto L3B; // [1490] 1587
    }
    else{
        _15392 = NOVALUE;
    }

    /** scanner.e:1683						basetype = find(ch, nbasecode)*/
    _basetype_27990 = find_from(_ch_27682, _61nbasecode_27485, 1);

    /** scanner.e:1684						if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_61nbase_27484)){
            _15394 = SEQ_PTR(_61nbase_27484)->length;
    }
    else {
        _15394 = 1;
    }
    if (_basetype_27990 <= _15394)
    goto L3C; // [1505] 1519

    /** scanner.e:1685							basetype -= length(nbase)*/
    if (IS_SEQUENCE(_61nbase_27484)){
            _15396 = SEQ_PTR(_61nbase_27484)->length;
    }
    else {
        _15396 = 1;
    }
    _basetype_27990 = _basetype_27990 - _15396;
    _15396 = NOVALUE;
L3C: 

    /** scanner.e:1688						if basetype = 0 then*/
    if (_basetype_27990 != 0)
    goto L3D; // [1521] 1578

    /** scanner.e:1689							if char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15399 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15399 != -2)
    goto L3E; // [1535] 1568

    /** scanner.e:1690								if ch != 'e' and ch != 'E' then*/
    _15401 = (_ch_27682 != 101);
    if (_15401 == 0) {
        goto L3F; // [1545] 1567
    }
    _15403 = (_ch_27682 != 69);
    if (_15403 == 0)
    {
        DeRef(_15403);
        _15403 = NOVALUE;
        goto L3F; // [1554] 1567
    }
    else{
        DeRef(_15403);
        _15403 = NOVALUE;
    }

    /** scanner.e:1691									CompileErr(INVALID_NUMBER_BASE_SPECIFIER_1, ch)*/
    _49CompileErr(105, _ch_27682, 0);
L3F: 
L3E: 

    /** scanner.e:1695							basetype = -1 -- decimal*/
    _basetype_27990 = -1;

    /** scanner.e:1696							exit*/
    goto L40; // [1575] 1663
L3D: 

    /** scanner.e:1698						yytext &= '0'*/
    Append(&_yytext_27688, _yytext_27688, 48);
    goto L3A; // [1584] 1648
L3B: 

    /** scanner.e:1700					elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_27990 != 4)
    goto L40; // [1589] 1663

    /** scanner.e:1701						integer hdigit*/

    /** scanner.e:1702						hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_28031 = find_from(_ch_27682, _15406, 1);

    /** scanner.e:1703						if hdigit = 0 then*/
    if (_hdigit_28031 != 0)
    goto L41; // [1604] 1615

    /** scanner.e:1704							exit*/
    goto L40; // [1612] 1663
L41: 

    /** scanner.e:1706						if hdigit > 6 then*/
    if (_hdigit_28031 <= 6)
    goto L42; // [1617] 1628

    /** scanner.e:1707							hdigit -= 6*/
    _hdigit_28031 = _hdigit_28031 - 6;
L42: 

    /** scanner.e:1709						yytext &= hexasc[hdigit]*/
    _2 = (object)SEQ_PTR(_61hexasc_27487);
    _15411 = (object)*(((s1_ptr)_2)->base + _hdigit_28031);
    if (IS_SEQUENCE(_yytext_27688) && IS_ATOM(_15411)) {
        Ref(_15411);
        Append(&_yytext_27688, _yytext_27688, _15411);
    }
    else if (IS_ATOM(_yytext_27688) && IS_SEQUENCE(_15411)) {
    }
    else {
        Concat((object_ptr)&_yytext_27688, _yytext_27688, _15411);
    }
    _15411 = NOVALUE;
    goto L3A; // [1640] 1648

    /** scanner.e:1712						exit*/
    goto L40; // [1645] 1663
L3A: 

    /** scanner.e:1714				entry*/
L37: 

    /** scanner.e:1715					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1716				end while*/
    goto L38; // [1660] 1461
L40: 

    /** scanner.e:1718				if ch = '.' then*/
    if (_ch_27682 != 46)
    goto L43; // [1665] 1804

    /** scanner.e:1719					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1720					if ch = '.' then*/
    if (_ch_27682 != 46)
    goto L44; // [1678] 1689

    /** scanner.e:1722						ungetch()*/
    _61ungetch();
    goto L45; // [1686] 1803
L44: 

    /** scanner.e:1724						is_int = FALSE*/
    _is_int_27693 = _9FALSE_439;

    /** scanner.e:1725						if yytext[1] = '.' then*/
    _2 = (object)SEQ_PTR(_yytext_27688);
    _15417 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15417, 46)){
        _15417 = NOVALUE;
        goto L46; // [1704] 1720
    }
    _15417 = NOVALUE;

    /** scanner.e:1726							CompileErr(ONLY_ONE_DECIMAL_POINT_ALLOWED)*/
    RefDS(_22209);
    _49CompileErr(124, _22209, 0);
    goto L47; // [1717] 1727
L46: 

    /** scanner.e:1728							yytext &= '.'*/
    Append(&_yytext_27688, _yytext_27688, 46);
L47: 

    /** scanner.e:1730						if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15420 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15420 != -7)
    goto L48; // [1737] 1792

    /** scanner.e:1731							yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);

    /** scanner.e:1732							ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1733							while char_class[ch] = DIGIT do*/
L49: 
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15424 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15424 != -7)
    goto L4A; // [1767] 1802

    /** scanner.e:1734								yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);

    /** scanner.e:1735								ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1736							end while*/
    goto L49; // [1786] 1759
    goto L4A; // [1789] 1802
L48: 

    /** scanner.e:1738							CompileErr(FRACTIONAL_PART_OF_NUMBER_IS_MISSING)*/
    RefDS(_22209);
    _49CompileErr(94, _22209, 0);
L4A: 
L45: 
L43: 

    /** scanner.e:1743				if basetype = -1 and find(ch, "eE") then*/
    _15428 = (_basetype_27990 == -1);
    if (_15428 == 0) {
        goto L4B; // [1810] 1948
    }
    _15431 = find_from(_ch_27682, _15430, 1);
    if (_15431 == 0)
    {
        _15431 = NOVALUE;
        goto L4B; // [1820] 1948
    }
    else{
        _15431 = NOVALUE;
    }

    /** scanner.e:1744					is_int = FALSE*/
    _is_int_27693 = _9FALSE_439;

    /** scanner.e:1745					yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);

    /** scanner.e:1746					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1747					if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _15434 = (_ch_27682 == 45);
    if (_15434 != 0) {
        _15435 = 1;
        goto L4C; // [1851] 1863
    }
    _15436 = (_ch_27682 == 43);
    _15435 = (_15436 != 0);
L4C: 
    if (_15435 != 0) {
        goto L4D; // [1863] 1884
    }
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15438 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    _15439 = (_15438 == -7);
    _15438 = NOVALUE;
    if (_15439 == 0)
    {
        DeRef(_15439);
        _15439 = NOVALUE;
        goto L4E; // [1880] 1893
    }
    else{
        DeRef(_15439);
        _15439 = NOVALUE;
    }
L4D: 

    /** scanner.e:1748						yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);
    goto L4F; // [1890] 1903
L4E: 

    /** scanner.e:1750						CompileErr(EXPONENT_NOT_FORMED_CORRECTLY)*/
    RefDS(_22209);
    _49CompileErr(86, _22209, 0);
L4F: 

    /** scanner.e:1752					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1753					while char_class[ch] = DIGIT do*/
L50: 
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15442 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15442 != -7)
    goto L51; // [1923] 1981

    /** scanner.e:1754						yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);

    /** scanner.e:1755						ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1756					end while*/
    goto L50; // [1942] 1915
    goto L51; // [1945] 1981
L4B: 

    /** scanner.e:1757				elsif char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15446 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15446 != -2)
    goto L52; // [1958] 1980

    /** scanner.e:1758					CompileErr(PUNCTUATION_MISSING_IN_BETWEEN_NUMBER_AND_1, {{ch}})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27682;
    _15448 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _15448;
    _15449 = MAKE_SEQ(_1);
    _15448 = NOVALUE;
    _49CompileErr(127, _15449, 0);
    _15449 = NOVALUE;
L52: 
L51: 

    /** scanner.e:1761				ungetch()*/
    _61ungetch();

    /** scanner.e:1763				while i != 0 with entry do*/
    goto L53; // [1987] 2006
L54: 
    if (binary_op_a(EQUALS, _i_27685, 0)){
        goto L55; // [1992] 2018
    }

    /** scanner.e:1764					yytext = remove( yytext, i )*/
    {
        s1_ptr assign_space = SEQ_PTR(_yytext_27688);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_27685)) ? _i_27685 : (object)(DBL_PTR(_i_27685)->dbl);
        int stop = (IS_ATOM_INT(_i_27685)) ? _i_27685 : (object)(DBL_PTR(_i_27685)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_yytext_27688), start, &_yytext_27688 );
            }
            else Tail(SEQ_PTR(_yytext_27688), stop+1, &_yytext_27688);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_yytext_27688), start, &_yytext_27688);
        }
        else {
            assign_slice_seq = &assign_space;
            _yytext_27688 = Remove_elements(start, stop, (SEQ_PTR(_yytext_27688)->ref == 1));
        }
    }

    /** scanner.e:1765				  entry*/
L53: 

    /** scanner.e:1766				    i = find('_', yytext)*/
    DeRef(_i_27685);
    _i_27685 = find_from(95, _yytext_27688, 1);

    /** scanner.e:1767				end while*/
    goto L54; // [2015] 1990
L55: 

    /** scanner.e:1769				if is_int then*/
    if (_is_int_27693 == 0)
    {
        goto L56; // [2020] 2092
    }
    else{
    }

    /** scanner.e:1770					if basetype = -1 then*/
    if (_basetype_27990 != -1)
    goto L57; // [2025] 2035

    /** scanner.e:1771						basetype = 3 -- decimal*/
    _basetype_27990 = 3;
L57: 

    /** scanner.e:1773					d = MakeInt(yytext, nbase[basetype])*/
    _2 = (object)SEQ_PTR(_61nbase_27484);
    _15454 = (object)*(((s1_ptr)_2)->base + _basetype_27990);
    RefDS(_yytext_27688);
    Ref(_15454);
    _0 = _d_27690;
    _d_27690 = _61MakeInt(_yytext_27688, _15454);
    DeRef(_0);
    _15454 = NOVALUE;

    /** scanner.e:1774					if is_integer(d) then*/
    Ref(_d_27690);
    _15456 = _27is_integer(_d_27690);
    if (_15456 == 0) {
        DeRef(_15456);
        _15456 = NOVALUE;
        goto L58; // [2052] 2074
    }
    else {
        if (!IS_ATOM_INT(_15456) && DBL_PTR(_15456)->dbl == 0.0){
            DeRef(_15456);
            _15456 = NOVALUE;
            goto L58; // [2052] 2074
        }
        DeRef(_15456);
        _15456 = NOVALUE;
    }
    DeRef(_15456);
    _15456 = NOVALUE;

    /** scanner.e:1775						return {ATOM, NewIntSym(d)}*/
    Ref(_d_27690);
    _15457 = _53NewIntSym(_d_27690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15457;
    _15458 = MAKE_SEQ(_1);
    _15457 = NOVALUE;
    DeRef(_i_27685);
    DeRefDS(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    return _15458;
    goto L59; // [2071] 2091
L58: 

    /** scanner.e:1777						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27690);
    _15459 = _53NewDoubleSym(_d_27690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15459;
    _15460 = MAKE_SEQ(_1);
    _15459 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    return _15460;
L59: 
L56: 

    /** scanner.e:1782				if basetype != -1 then*/
    if (_basetype_27990 == -1)
    goto L5A; // [2094] 2112

    /** scanner.e:1783					CompileErr(ONLY_INTEGER_LITERALS_CAN_USE_THE_01_FORMAT, nbasecode[basetype])*/
    _2 = (object)SEQ_PTR(_61nbasecode_27485);
    _15462 = (object)*(((s1_ptr)_2)->base + _basetype_27990);
    Ref(_15462);
    _49CompileErr(125, _15462, 0);
    _15462 = NOVALUE;
L5A: 

    /** scanner.e:1787				d = my_sscanf(yytext)*/
    RefDS(_yytext_27688);
    _0 = _d_27690;
    _d_27690 = _61my_sscanf(_yytext_27688);
    DeRef(_0);

    /** scanner.e:1788				if sequence(d) then*/
    _15464 = IS_SEQUENCE(_d_27690);
    if (_15464 == 0)
    {
        _15464 = NOVALUE;
        goto L5B; // [2123] 2138
    }
    else{
        _15464 = NOVALUE;
    }

    /** scanner.e:1789					CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22209);
    _49CompileErr(121, _22209, 0);
    goto L5C; // [2135] 2190
L5B: 

    /** scanner.e:1790				elsif is_int and d <= TMAXINT_DBL then*/
    if (_is_int_27693 == 0) {
        goto L5D; // [2140] 2173
    }
    if (IS_ATOM_INT(_d_27690) && IS_ATOM_INT(_27TMAXINT_DBL_20404)) {
        _15466 = (_d_27690 <= _27TMAXINT_DBL_20404);
    }
    else {
        _15466 = binary_op(LESSEQ, _d_27690, _27TMAXINT_DBL_20404);
    }
    if (_15466 == 0) {
        DeRef(_15466);
        _15466 = NOVALUE;
        goto L5D; // [2151] 2173
    }
    else {
        if (!IS_ATOM_INT(_15466) && DBL_PTR(_15466)->dbl == 0.0){
            DeRef(_15466);
            _15466 = NOVALUE;
            goto L5D; // [2151] 2173
        }
        DeRef(_15466);
        _15466 = NOVALUE;
    }
    DeRef(_15466);
    _15466 = NOVALUE;

    /** scanner.e:1791					return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_27690);
    _15467 = _53NewIntSym(_d_27690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15467;
    _15468 = MAKE_SEQ(_1);
    _15467 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    return _15468;
    goto L5C; // [2170] 2190
L5D: 

    /** scanner.e:1793					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27690);
    _15469 = _53NewDoubleSym(_d_27690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15469;
    _15470 = MAKE_SEQ(_1);
    _15469 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15470;
L5C: 
    goto L1; // [2192] 10
L33: 

    /** scanner.e:1797			elsif class = MINUS then*/
    if (_class_27694 != 10)
    goto L5E; // [2199] 2285

    /** scanner.e:1798				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1799				if ch = '-' then*/
    if (_ch_27682 != 45)
    goto L5F; // [2212] 2238

    /** scanner.e:1801					if start_include then*/
    if (_61start_include_25925 == 0)
    {
        goto L60; // [2220] 2230
    }
    else{
    }

    /** scanner.e:1802						IncludePush()*/
    _61IncludePush();
    goto L1; // [2227] 10
L60: 

    /** scanner.e:1804						read_line()*/
    _61read_line();
    goto L1; // [2235] 10
L5F: 

    /** scanner.e:1806				elsif ch = '=' then*/
    if (_ch_27682 != 61)
    goto L61; // [2240] 2259

    /** scanner.e:1807					return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 516;
    ((intptr_t *)_2)[2] = 0;
    _15475 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15475;
    goto L1; // [2256] 10
L61: 

    /** scanner.e:1809					bp -= 1*/
    _49bp_49646 = _49bp_49646 - 1;

    /** scanner.e:1810					return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 0;
    _15477 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15477;
    goto L1; // [2282] 10
L5E: 

    /** scanner.e:1812			elsif class = DOUBLE_QUOTE then*/
    if (_class_27694 != -4)
    goto L62; // [2289] 2487

    /** scanner.e:1813				integer fch*/

    /** scanner.e:1814				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1815				if ch = '"' then*/
    if (_ch_27682 != 34)
    goto L63; // [2304] 2340

    /** scanner.e:1816					fch = getch()*/
    _fch_28171 = _61getch();
    if (!IS_ATOM_INT(_fch_28171)) {
        _1 = (object)(DBL_PTR(_fch_28171)->dbl);
        DeRefDS(_fch_28171);
        _fch_28171 = _1;
    }

    /** scanner.e:1817					if fch = '"' then*/
    if (_fch_28171 != 34)
    goto L64; // [2317] 2334

    /** scanner.e:1819						return ExtendedString( fch )*/
    _15483 = _61ExtendedString(_fch_28171);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15483;
    goto L65; // [2331] 2339
L64: 

    /** scanner.e:1821						ungetch()*/
    _61ungetch();
L65: 
L63: 

    /** scanner.e:1824				yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27688);
    _yytext_27688 = _5;

    /** scanner.e:1825				while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _15484 = (_ch_27682 != 10);
    if (_15484 == 0) {
        goto L67; // [2356] 2437
    }
    _15486 = (_ch_27682 != 13);
    if (_15486 == 0)
    {
        DeRef(_15486);
        _15486 = NOVALUE;
        goto L67; // [2365] 2437
    }
    else{
        DeRef(_15486);
        _15486 = NOVALUE;
    }

    /** scanner.e:1826					if ch = '"' then*/
    if (_ch_27682 != 34)
    goto L68; // [2370] 2381

    /** scanner.e:1827						exit*/
    goto L67; // [2376] 2437
    goto L69; // [2378] 2425
L68: 

    /** scanner.e:1828					elsif ch = '\\' then*/
    if (_ch_27682 != 92)
    goto L6A; // [2383] 2400

    /** scanner.e:1829						yytext &= EscapeChar('"')*/
    _15489 = _61EscapeChar(34);
    if (IS_SEQUENCE(_yytext_27688) && IS_ATOM(_15489)) {
        Ref(_15489);
        Append(&_yytext_27688, _yytext_27688, _15489);
    }
    else if (IS_ATOM(_yytext_27688) && IS_SEQUENCE(_15489)) {
    }
    else {
        Concat((object_ptr)&_yytext_27688, _yytext_27688, _15489);
    }
    DeRef(_15489);
    _15489 = NOVALUE;
    goto L69; // [2397] 2425
L6A: 

    /** scanner.e:1830					elsif ch = '\t' then*/
    if (_ch_27682 != 9)
    goto L6B; // [2402] 2418

    /** scanner.e:1831						CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22209);
    _49CompileErr(145, _22209, 0);
    goto L69; // [2415] 2425
L6B: 

    /** scanner.e:1833						yytext &= ch*/
    Append(&_yytext_27688, _yytext_27688, _ch_27682);
L69: 

    /** scanner.e:1835					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1836				end while*/
    goto L66; // [2434] 2352
L67: 

    /** scanner.e:1837				if ch = '\n' or ch = '\r' then*/
    _15494 = (_ch_27682 == 10);
    if (_15494 != 0) {
        goto L6C; // [2443] 2456
    }
    _15496 = (_ch_27682 == 13);
    if (_15496 == 0)
    {
        DeRef(_15496);
        _15496 = NOVALUE;
        goto L6D; // [2452] 2466
    }
    else{
        DeRef(_15496);
        _15496 = NOVALUE;
    }
L6C: 

    /** scanner.e:1838					CompileErr(END_OF_LINE_REACHED_WITH_NO_CLOSING)*/
    RefDS(_22209);
    _49CompileErr(67, _22209, 0);
L6D: 

    /** scanner.e:1840				return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_27688);
    _15497 = _53NewStringSym(_yytext_27688);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503;
    ((intptr_t *)_2)[2] = _15497;
    _15498 = MAKE_SEQ(_1);
    _15497 = NOVALUE;
    DeRef(_i_27685);
    DeRefDS(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15498;
    goto L1; // [2484] 10
L62: 

    /** scanner.e:1842			elsif class = PLUS then*/
    if (_class_27694 != 11)
    goto L6E; // [2491] 2543

    /** scanner.e:1843				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1844				if ch = '=' then*/
    if (_ch_27682 != 61)
    goto L6F; // [2504] 2523

    /** scanner.e:1845					return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 515;
    ((intptr_t *)_2)[2] = 0;
    _15502 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15502;
    goto L1; // [2520] 10
L6F: 

    /** scanner.e:1847					ungetch()*/
    _61ungetch();

    /** scanner.e:1848					return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 11;
    ((intptr_t *)_2)[2] = 0;
    _15503 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15503;
    goto L1; // [2540] 10
L6E: 

    /** scanner.e:1851			elsif class = res:CONCAT then*/
    if (_class_27694 != 15)
    goto L70; // [2545] 2595

    /** scanner.e:1852				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1853				if ch = '=' then*/
    if (_ch_27682 != 61)
    goto L71; // [2558] 2577

    /** scanner.e:1854					return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 0;
    _15507 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15507;
    goto L1; // [2574] 10
L71: 

    /** scanner.e:1856					ungetch()*/
    _61ungetch();

    /** scanner.e:1857					return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 15;
    ((intptr_t *)_2)[2] = 0;
    _15508 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15508;
    goto L1; // [2592] 10
L70: 

    /** scanner.e:1860			elsif class = NUMBER_SIGN then*/
    if (_class_27694 != -11)
    goto L72; // [2599] 3122

    /** scanner.e:1861				i = 0*/
    DeRef(_i_27685);
    _i_27685 = 0;

    /** scanner.e:1862				is_int = -1*/
    _is_int_27693 = -1;

    /** scanner.e:1863				while i < TMAXINT/32 do*/
L73: 
    if (IS_ATOM_INT(_27TMAXINT_20401)) {
        _15510 = (_27TMAXINT_20401 % 32) ? NewDouble((eudouble)_27TMAXINT_20401 / 32) : (_27TMAXINT_20401 / 32);
    }
    else {
        _15510 = NewDouble(DBL_PTR(_27TMAXINT_20401)->dbl / (eudouble)32);
    }
    if (binary_op_a(GREATEREQ, _i_27685, _15510)){
        DeRef(_15510);
        _15510 = NOVALUE;
        goto L74; // [2624] 2788
    }
    DeRef(_15510);
    _15510 = NOVALUE;

    /** scanner.e:1864					ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1865					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15513 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15513 != -7)
    goto L75; // [2645] 2682

    /** scanner.e:1866						if ch != '_' then*/
    if (_ch_27682 == 95)
    goto L73; // [2651] 2618

    /** scanner.e:1867							i = i * 16 + ch - '0'*/
    if (IS_ATOM_INT(_i_27685)) {
        if (_i_27685 == (short)_i_27685){
            _15516 = _i_27685 * 16;
        }
        else{
            _15516 = NewDouble(_i_27685 * (eudouble)16);
        }
    }
    else {
        _15516 = NewDouble(DBL_PTR(_i_27685)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15516)) {
        _15517 = _15516 + _ch_27682;
        if ((object)((uintptr_t)_15517 + (uintptr_t)HIGH_BITS) >= 0){
            _15517 = NewDouble((eudouble)_15517);
        }
    }
    else {
        _15517 = NewDouble(DBL_PTR(_15516)->dbl + (eudouble)_ch_27682);
    }
    DeRef(_15516);
    _15516 = NOVALUE;
    DeRef(_i_27685);
    if (IS_ATOM_INT(_15517)) {
        _i_27685 = _15517 - 48;
        if ((object)((uintptr_t)_i_27685 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27685 = NewDouble((eudouble)_i_27685);
        }
    }
    else {
        _i_27685 = NewDouble(DBL_PTR(_15517)->dbl - (eudouble)48);
    }
    DeRef(_15517);
    _15517 = NOVALUE;

    /** scanner.e:1868							is_int = TRUE*/
    _is_int_27693 = _9TRUE_441;
    goto L73; // [2679] 2618
L75: 

    /** scanner.e:1870					elsif ch >= 'A' and ch <= 'F' then*/
    _15519 = (_ch_27682 >= 65);
    if (_15519 == 0) {
        goto L76; // [2688] 2730
    }
    _15521 = (_ch_27682 <= 70);
    if (_15521 == 0)
    {
        DeRef(_15521);
        _15521 = NOVALUE;
        goto L76; // [2697] 2730
    }
    else{
        DeRef(_15521);
        _15521 = NOVALUE;
    }

    /** scanner.e:1871						i = (i * 16) + ch - ('A'-10)*/
    if (IS_ATOM_INT(_i_27685)) {
        if (_i_27685 == (short)_i_27685){
            _15522 = _i_27685 * 16;
        }
        else{
            _15522 = NewDouble(_i_27685 * (eudouble)16);
        }
    }
    else {
        _15522 = NewDouble(DBL_PTR(_i_27685)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15522)) {
        _15523 = _15522 + _ch_27682;
        if ((object)((uintptr_t)_15523 + (uintptr_t)HIGH_BITS) >= 0){
            _15523 = NewDouble((eudouble)_15523);
        }
    }
    else {
        _15523 = NewDouble(DBL_PTR(_15522)->dbl + (eudouble)_ch_27682);
    }
    DeRef(_15522);
    _15522 = NOVALUE;
    _15524 = 55;
    DeRef(_i_27685);
    if (IS_ATOM_INT(_15523)) {
        _i_27685 = _15523 - 55;
        if ((object)((uintptr_t)_i_27685 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27685 = NewDouble((eudouble)_i_27685);
        }
    }
    else {
        _i_27685 = NewDouble(DBL_PTR(_15523)->dbl - (eudouble)55);
    }
    DeRef(_15523);
    _15523 = NOVALUE;
    _15524 = NOVALUE;

    /** scanner.e:1872						is_int = TRUE*/
    _is_int_27693 = _9TRUE_441;
    goto L73; // [2727] 2618
L76: 

    /** scanner.e:1873					elsif ch >= 'a' and ch <= 'f' then*/
    _15526 = (_ch_27682 >= 97);
    if (_15526 == 0) {
        goto L74; // [2736] 2788
    }
    _15528 = (_ch_27682 <= 102);
    if (_15528 == 0)
    {
        DeRef(_15528);
        _15528 = NOVALUE;
        goto L74; // [2745] 2788
    }
    else{
        DeRef(_15528);
        _15528 = NOVALUE;
    }

    /** scanner.e:1874						i = (i * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_i_27685)) {
        if (_i_27685 == (short)_i_27685){
            _15529 = _i_27685 * 16;
        }
        else{
            _15529 = NewDouble(_i_27685 * (eudouble)16);
        }
    }
    else {
        _15529 = NewDouble(DBL_PTR(_i_27685)->dbl * (eudouble)16);
    }
    if (IS_ATOM_INT(_15529)) {
        _15530 = _15529 + _ch_27682;
        if ((object)((uintptr_t)_15530 + (uintptr_t)HIGH_BITS) >= 0){
            _15530 = NewDouble((eudouble)_15530);
        }
    }
    else {
        _15530 = NewDouble(DBL_PTR(_15529)->dbl + (eudouble)_ch_27682);
    }
    DeRef(_15529);
    _15529 = NOVALUE;
    _15531 = 87;
    DeRef(_i_27685);
    if (IS_ATOM_INT(_15530)) {
        _i_27685 = _15530 - 87;
        if ((object)((uintptr_t)_i_27685 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27685 = NewDouble((eudouble)_i_27685);
        }
    }
    else {
        _i_27685 = NewDouble(DBL_PTR(_15530)->dbl - (eudouble)87);
    }
    DeRef(_15530);
    _15530 = NOVALUE;
    _15531 = NOVALUE;

    /** scanner.e:1875						is_int = TRUE*/
    _is_int_27693 = _9TRUE_441;
    goto L73; // [2775] 2618

    /** scanner.e:1877						exit*/
    goto L74; // [2780] 2788

    /** scanner.e:1879				end while*/
    goto L73; // [2785] 2618
L74: 

    /** scanner.e:1881				if is_int = -1 then*/
    if (_is_int_27693 != -1)
    goto L77; // [2790] 2857

    /** scanner.e:1882					if ch = '!' then*/
    if (_ch_27682 != 33)
    goto L78; // [2796] 2844

    /** scanner.e:1883						if line_number > 1 then*/
    if (_27line_number_20572 <= 1)
    goto L79; // [2804] 2818

    /** scanner.e:1884							CompileErr(MSG__MAY_ONLY_BE_ON_THE_FIRST_LINE_OF_A_PROGRAM)*/
    RefDS(_22209);
    _49CompileErr(161, _22209, 0);
L79: 

    /** scanner.e:1887						shebang = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_61shebang_25930);
    _61shebang_25930 = _49ThisLine_49642;

    /** scanner.e:1888						if start_include then*/
    if (_61start_include_25925 == 0)
    {
        goto L7A; // [2829] 2837
    }
    else{
    }

    /** scanner.e:1889							IncludePush()*/
    _61IncludePush();
L7A: 

    /** scanner.e:1891						read_line()*/
    _61read_line();
    goto L1; // [2841] 10
L78: 

    /** scanner.e:1893						CompileErr(HEX_NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22209);
    _49CompileErr(97, _22209, 0);
    goto L1; // [2854] 10
L77: 

    /** scanner.e:1896					d = i*/
    Ref(_i_27685);
    DeRef(_d_27690);
    _d_27690 = _i_27685;

    /** scanner.e:1897					if i >= TMAXINT/32 then*/
    if (IS_ATOM_INT(_27TMAXINT_20401)) {
        _15536 = (_27TMAXINT_20401 % 32) ? NewDouble((eudouble)_27TMAXINT_20401 / 32) : (_27TMAXINT_20401 / 32);
    }
    else {
        _15536 = NewDouble(DBL_PTR(_27TMAXINT_20401)->dbl / (eudouble)32);
    }
    if (binary_op_a(LESS, _i_27685, _15536)){
        DeRef(_15536);
        _15536 = NOVALUE;
        goto L7B; // [2870] 3036
    }
    DeRef(_15536);
    _15536 = NOVALUE;

    /** scanner.e:1898						is_int = FALSE*/
    _is_int_27693 = _9FALSE_439;

    /** scanner.e:1899						while TRUE do*/
L7C: 
    if (_9TRUE_441 == 0)
    {
        goto L7D; // [2890] 3035
    }
    else{
    }

    /** scanner.e:1900							ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1901							if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15539 = (object)*(((s1_ptr)_2)->base + _ch_27682);
    if (_15539 != -7)
    goto L7E; // [2910] 2938

    /** scanner.e:1902								if ch != '_' then*/
    if (_ch_27682 == 95)
    goto L7C; // [2916] 2888

    /** scanner.e:1903									d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_27690)) {
        if (_d_27690 == (short)_d_27690){
            _15542 = _d_27690 * 16;
        }
        else{
            _15542 = NewDouble(_d_27690 * (eudouble)16);
        }
    }
    else {
        _15542 = binary_op(MULTIPLY, _d_27690, 16);
    }
    if (IS_ATOM_INT(_15542)) {
        _15543 = _15542 + _ch_27682;
        if ((object)((uintptr_t)_15543 + (uintptr_t)HIGH_BITS) >= 0){
            _15543 = NewDouble((eudouble)_15543);
        }
    }
    else {
        _15543 = binary_op(PLUS, _15542, _ch_27682);
    }
    DeRef(_15542);
    _15542 = NOVALUE;
    DeRef(_d_27690);
    if (IS_ATOM_INT(_15543)) {
        _d_27690 = _15543 - 48;
        if ((object)((uintptr_t)_d_27690 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27690 = NewDouble((eudouble)_d_27690);
        }
    }
    else {
        _d_27690 = binary_op(MINUS, _15543, 48);
    }
    DeRef(_15543);
    _15543 = NOVALUE;
    goto L7C; // [2935] 2888
L7E: 

    /** scanner.e:1905							elsif ch >= 'A' and ch <= 'F' then*/
    _15545 = (_ch_27682 >= 65);
    if (_15545 == 0) {
        goto L7F; // [2944] 2977
    }
    _15547 = (_ch_27682 <= 70);
    if (_15547 == 0)
    {
        DeRef(_15547);
        _15547 = NOVALUE;
        goto L7F; // [2953] 2977
    }
    else{
        DeRef(_15547);
        _15547 = NOVALUE;
    }

    /** scanner.e:1906								d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_27690)) {
        if (_d_27690 == (short)_d_27690){
            _15548 = _d_27690 * 16;
        }
        else{
            _15548 = NewDouble(_d_27690 * (eudouble)16);
        }
    }
    else {
        _15548 = binary_op(MULTIPLY, _d_27690, 16);
    }
    if (IS_ATOM_INT(_15548)) {
        _15549 = _15548 + _ch_27682;
        if ((object)((uintptr_t)_15549 + (uintptr_t)HIGH_BITS) >= 0){
            _15549 = NewDouble((eudouble)_15549);
        }
    }
    else {
        _15549 = binary_op(PLUS, _15548, _ch_27682);
    }
    DeRef(_15548);
    _15548 = NOVALUE;
    _15550 = 55;
    DeRef(_d_27690);
    if (IS_ATOM_INT(_15549)) {
        _d_27690 = _15549 - 55;
        if ((object)((uintptr_t)_d_27690 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27690 = NewDouble((eudouble)_d_27690);
        }
    }
    else {
        _d_27690 = binary_op(MINUS, _15549, 55);
    }
    DeRef(_15549);
    _15549 = NOVALUE;
    _15550 = NOVALUE;
    goto L7C; // [2974] 2888
L7F: 

    /** scanner.e:1907							elsif ch >= 'a' and ch <= 'f' then*/
    _15552 = (_ch_27682 >= 97);
    if (_15552 == 0) {
        goto L80; // [2983] 3016
    }
    _15554 = (_ch_27682 <= 102);
    if (_15554 == 0)
    {
        DeRef(_15554);
        _15554 = NOVALUE;
        goto L80; // [2992] 3016
    }
    else{
        DeRef(_15554);
        _15554 = NOVALUE;
    }

    /** scanner.e:1908								d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_27690)) {
        if (_d_27690 == (short)_d_27690){
            _15555 = _d_27690 * 16;
        }
        else{
            _15555 = NewDouble(_d_27690 * (eudouble)16);
        }
    }
    else {
        _15555 = binary_op(MULTIPLY, _d_27690, 16);
    }
    if (IS_ATOM_INT(_15555)) {
        _15556 = _15555 + _ch_27682;
        if ((object)((uintptr_t)_15556 + (uintptr_t)HIGH_BITS) >= 0){
            _15556 = NewDouble((eudouble)_15556);
        }
    }
    else {
        _15556 = binary_op(PLUS, _15555, _ch_27682);
    }
    DeRef(_15555);
    _15555 = NOVALUE;
    _15557 = 87;
    DeRef(_d_27690);
    if (IS_ATOM_INT(_15556)) {
        _d_27690 = _15556 - 87;
        if ((object)((uintptr_t)_d_27690 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27690 = NewDouble((eudouble)_d_27690);
        }
    }
    else {
        _d_27690 = binary_op(MINUS, _15556, 87);
    }
    DeRef(_15556);
    _15556 = NOVALUE;
    _15557 = NOVALUE;
    goto L7C; // [3013] 2888
L80: 

    /** scanner.e:1909							elsif ch = '_' then*/
    if (_ch_27682 != 95)
    goto L7D; // [3018] 3035
    goto L7C; // [3022] 2888

    /** scanner.e:1912								exit*/
    goto L7D; // [3027] 3035

    /** scanner.e:1914						end while*/
    goto L7C; // [3032] 2888
L7D: 
L7B: 

    /** scanner.e:1917					ungetch()*/
    _61ungetch();

    /** scanner.e:1918					if is_int and is_integer(i) then*/
    if (_is_int_27693 == 0) {
        goto L81; // [3042] 3073
    }
    Ref(_i_27685);
    _15561 = _27is_integer(_i_27685);
    if (_15561 == 0) {
        DeRef(_15561);
        _15561 = NOVALUE;
        goto L81; // [3051] 3073
    }
    else {
        if (!IS_ATOM_INT(_15561) && DBL_PTR(_15561)->dbl == 0.0){
            DeRef(_15561);
            _15561 = NOVALUE;
            goto L81; // [3051] 3073
        }
        DeRef(_15561);
        _15561 = NOVALUE;
    }
    DeRef(_15561);
    _15561 = NOVALUE;

    /** scanner.e:1919						return {ATOM, NewIntSym(i)}*/
    Ref(_i_27685);
    _15562 = _53NewIntSym(_i_27685);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15562;
    _15563 = MAKE_SEQ(_1);
    _15562 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15563;
    goto L1; // [3070] 10
L81: 

    /** scanner.e:1921						if d <= TMAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_27690, _27TMAXINT_DBL_20404)){
        goto L82; // [3077] 3100
    }

    /** scanner.e:1922							return {ATOM, NewIntSym(d)}*/
    Ref(_d_27690);
    _15565 = _53NewIntSym(_d_27690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15565;
    _15566 = MAKE_SEQ(_1);
    _15565 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15566;
    goto L1; // [3097] 10
L82: 

    /** scanner.e:1924							return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27690);
    _15567 = _53NewDoubleSym(_d_27690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15567;
    _15568 = MAKE_SEQ(_1);
    _15567 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15568;
    goto L1; // [3119] 10
L72: 

    /** scanner.e:1929			elsif class = res:MULTIPLY then*/
    if (_class_27694 != 13)
    goto L83; // [3124] 3174

    /** scanner.e:1930				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1931				if ch = '=' then*/
    if (_ch_27682 != 61)
    goto L84; // [3137] 3156

    /** scanner.e:1932					return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 517;
    ((intptr_t *)_2)[2] = 0;
    _15572 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15572;
    goto L1; // [3153] 10
L84: 

    /** scanner.e:1934					ungetch()*/
    _61ungetch();

    /** scanner.e:1935					return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 13;
    ((intptr_t *)_2)[2] = 0;
    _15573 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15573;
    goto L1; // [3171] 10
L83: 

    /** scanner.e:1938			elsif class = res:DIVIDE then*/
    if (_class_27694 != 14)
    goto L85; // [3176] 3380

    /** scanner.e:1939				ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1940				if ch = '=' then*/
    if (_ch_27682 != 61)
    goto L86; // [3189] 3208

    /** scanner.e:1941					return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 518;
    ((intptr_t *)_2)[2] = 0;
    _15577 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15577;
    goto L1; // [3205] 10
L86: 

    /** scanner.e:1942				elsif ch = '*' then*/
    if (_ch_27682 != 42)
    goto L87; // [3210] 3362

    /** scanner.e:1944					cline = line_number*/
    _cline_27687 = _27line_number_20572;

    /** scanner.e:1945					integer cnest = 1*/
    _cnest_28355 = 1;

    /** scanner.e:1946					while cnest > 0 do*/
L88: 
    if (_cnest_28355 <= 0)
    goto L89; // [3233] 3341

    /** scanner.e:1947						ch = getch()*/
    _ch_27682 = _61getch();
    if (!IS_ATOM_INT(_ch_27682)) {
        _1 = (object)(DBL_PTR(_ch_27682)->dbl);
        DeRefDS(_ch_27682);
        _ch_27682 = _1;
    }

    /** scanner.e:1948						switch ch do*/
    _0 = _ch_27682;
    switch ( _0 ){ 

        /** scanner.e:1949							case  END_OF_FILE_CHAR then*/
        case 26:

        /** scanner.e:1950								exit*/
        goto L89; // [3257] 3341
        goto L88; // [3259] 3233

        /** scanner.e:1952							case '\n' then*/
        case 10:

        /** scanner.e:1953								read_line()*/
        _61read_line();
        goto L88; // [3269] 3233

        /** scanner.e:1955							case '*' then*/
        case 42:

        /** scanner.e:1956								ch = getch()*/
        _ch_27682 = _61getch();
        if (!IS_ATOM_INT(_ch_27682)) {
            _1 = (object)(DBL_PTR(_ch_27682)->dbl);
            DeRefDS(_ch_27682);
            _ch_27682 = _1;
        }

        /** scanner.e:1957								if ch = '/' then*/
        if (_ch_27682 != 47)
        goto L8A; // [3284] 3297

        /** scanner.e:1958									cnest -= 1*/
        _cnest_28355 = _cnest_28355 - 1;
        goto L88; // [3294] 3233
L8A: 

        /** scanner.e:1960									ungetch()*/
        _61ungetch();
        goto L88; // [3302] 3233

        /** scanner.e:1963							case '/' then*/
        case 47:

        /** scanner.e:1964								ch = getch()*/
        _ch_27682 = _61getch();
        if (!IS_ATOM_INT(_ch_27682)) {
            _1 = (object)(DBL_PTR(_ch_27682)->dbl);
            DeRefDS(_ch_27682);
            _ch_27682 = _1;
        }

        /** scanner.e:1965								if ch = '*' then*/
        if (_ch_27682 != 42)
        goto L8B; // [3317] 3330

        /** scanner.e:1966									cnest += 1*/
        _cnest_28355 = _cnest_28355 + 1;
        goto L8C; // [3327] 3335
L8B: 

        /** scanner.e:1968									ungetch()*/
        _61ungetch();
L8C: 
    ;}
    /** scanner.e:1972					end while*/
    goto L88; // [3338] 3233
L89: 

    /** scanner.e:1974					if cnest > 0 then*/
    if (_cnest_28355 <= 0)
    goto L8D; // [3343] 3357

    /** scanner.e:1975						CompileErr(BLOCK_COMMENT_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _49CompileErr(42, _cline_27687, 0);
L8D: 
    goto L1; // [3359] 10
L87: 

    /** scanner.e:1978					ungetch()*/
    _61ungetch();

    /** scanner.e:1979					return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 14;
    ((intptr_t *)_2)[2] = 0;
    _15590 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15590;
    goto L1; // [3377] 10
L85: 

    /** scanner.e:1981			elsif class = SINGLE_QUOTE then*/
    if (_class_27694 != -5)
    goto L8E; // [3384] 3534

    /** scanner.e:1982				atom ach = getch()*/
    _0 = _ach_28385;
    _ach_28385 = _61getch();
    DeRef(_0);

    /** scanner.e:1983				if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_28385, 92)){
        goto L8F; // [3395] 3408
    }

    /** scanner.e:1984					ach = EscapeChar('\'')*/
    _0 = _ach_28385;
    _ach_28385 = _61EscapeChar(39);
    DeRef(_0);
    goto L90; // [3405] 3465
L8F: 

    /** scanner.e:1985				elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_28385, 9)){
        goto L91; // [3410] 3426
    }

    /** scanner.e:1986					CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22209);
    _49CompileErr(145, _22209, 0);
    goto L90; // [3423] 3465
L91: 

    /** scanner.e:1987				elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_28385, 39)){
        goto L92; // [3428] 3444
    }

    /** scanner.e:1988					CompileErr(SINGLEQUOTE_CHARACTER_IS_EMPTY)*/
    RefDS(_22209);
    _49CompileErr(137, _22209, 0);
    goto L90; // [3441] 3465
L92: 

    /** scanner.e:1989				elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_28385, 10)){
        goto L93; // [3446] 3464
    }

    /** scanner.e:1990					CompileErr(EXPECTED_1_NOT_2, {"character", "end of line"})*/
    RefDS(_15599);
    RefDS(_15598);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15598;
    ((intptr_t *)_2)[2] = _15599;
    _15600 = MAKE_SEQ(_1);
    _49CompileErr(68, _15600, 0);
    _15600 = NOVALUE;
L93: 
L90: 

    /** scanner.e:1992				if getch() != '\'' then*/
    _15601 = _61getch();
    if (binary_op_a(EQUALS, _15601, 39)){
        DeRef(_15601);
        _15601 = NOVALUE;
        goto L94; // [3470] 3484
    }
    DeRef(_15601);
    _15601 = NOVALUE;

    /** scanner.e:1993					CompileErr(CHARACTER_CONSTANT_IS_MISSING_A_CLOSING)*/
    RefDS(_22209);
    _49CompileErr(56, _22209, 0);
L94: 

    /** scanner.e:1995				if is_integer(ach) then*/
    Ref(_ach_28385);
    _15603 = _27is_integer(_ach_28385);
    if (_15603 == 0) {
        DeRef(_15603);
        _15603 = NOVALUE;
        goto L95; // [3490] 3512
    }
    else {
        if (!IS_ATOM_INT(_15603) && DBL_PTR(_15603)->dbl == 0.0){
            DeRef(_15603);
            _15603 = NOVALUE;
            goto L95; // [3490] 3512
        }
        DeRef(_15603);
        _15603 = NOVALUE;
    }
    DeRef(_15603);
    _15603 = NOVALUE;

    /** scanner.e:1996					return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_28385);
    _15604 = _53NewIntSym(_ach_28385);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15604;
    _15605 = MAKE_SEQ(_1);
    _15604 = NOVALUE;
    DeRef(_ach_28385);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15605;
    goto L96; // [3509] 3529
L95: 

    /** scanner.e:1998					return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_28385);
    _15606 = _53NewDoubleSym(_ach_28385);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502;
    ((intptr_t *)_2)[2] = _15606;
    _15607 = MAKE_SEQ(_1);
    _15606 = NOVALUE;
    DeRef(_ach_28385);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15607;
L96: 
    DeRef(_ach_28385);
    _ach_28385 = NOVALUE;
    goto L1; // [3531] 10
L8E: 

    /** scanner.e:2001			elsif class = LESS then*/
    if (_class_27694 != 1)
    goto L97; // [3538] 3586

    /** scanner.e:2002				if getch() = '=' then*/
    _15609 = _61getch();
    if (binary_op_a(NOTEQ, _15609, 61)){
        DeRef(_15609);
        _15609 = NOVALUE;
        goto L98; // [3547] 3566
    }
    DeRef(_15609);
    _15609 = NOVALUE;

    /** scanner.e:2003					return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 5;
    ((intptr_t *)_2)[2] = 0;
    _15611 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15611;
    goto L1; // [3563] 10
L98: 

    /** scanner.e:2005					ungetch()*/
    _61ungetch();

    /** scanner.e:2006					return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = 0;
    _15612 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15612;
    goto L1; // [3583] 10
L97: 

    /** scanner.e:2009			elsif class = GREATER then*/
    if (_class_27694 != 6)
    goto L99; // [3590] 3638

    /** scanner.e:2010				if getch() = '=' then*/
    _15614 = _61getch();
    if (binary_op_a(NOTEQ, _15614, 61)){
        DeRef(_15614);
        _15614 = NOVALUE;
        goto L9A; // [3599] 3618
    }
    DeRef(_15614);
    _15614 = NOVALUE;

    /** scanner.e:2011					return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2;
    ((intptr_t *)_2)[2] = 0;
    _15616 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15616;
    goto L1; // [3615] 10
L9A: 

    /** scanner.e:2013					ungetch()*/
    _61ungetch();

    /** scanner.e:2014					return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 6;
    ((intptr_t *)_2)[2] = 0;
    _15617 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15616);
    _15616 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15617;
    goto L1; // [3635] 10
L99: 

    /** scanner.e:2017			elsif class = BANG then*/
    if (_class_27694 != -1)
    goto L9B; // [3642] 3690

    /** scanner.e:2018				if getch() = '=' then*/
    _15619 = _61getch();
    if (binary_op_a(NOTEQ, _15619, 61)){
        DeRef(_15619);
        _15619 = NOVALUE;
        goto L9C; // [3651] 3670
    }
    DeRef(_15619);
    _15619 = NOVALUE;

    /** scanner.e:2019					return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4;
    ((intptr_t *)_2)[2] = 0;
    _15621 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15617);
    _15617 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15616);
    _15616 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15621;
    goto L1; // [3667] 10
L9C: 

    /** scanner.e:2021					ungetch()*/
    _61ungetch();

    /** scanner.e:2022					return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = 0;
    _15622 = MAKE_SEQ(_1);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15617);
    _15617 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15621);
    _15621 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15616);
    _15616 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15622;
    goto L1; // [3687] 10
L9B: 

    /** scanner.e:2025			elsif class = KEYWORD then*/
    if (_class_27694 != -10)
    goto L9D; // [3694] 3727

    /** scanner.e:2026				return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _15624 = _ch_27682 - 128;
    _2 = (object)SEQ_PTR(_62keylist_23493);
    _15625 = (object)*(((s1_ptr)_2)->base + _15624);
    _2 = (object)SEQ_PTR(_15625);
    _15626 = (object)*(((s1_ptr)_2)->base + 3);
    _15625 = NOVALUE;
    Ref(_15626);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15626;
    ((intptr_t *)_2)[2] = 0;
    _15627 = MAKE_SEQ(_1);
    _15626 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15617);
    _15617 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15621);
    _15621 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15616);
    _15616 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    _15624 = NOVALUE;
    DeRef(_15622);
    _15622 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15627;
    goto L1; // [3724] 10
L9D: 

    /** scanner.e:2028			elsif class = BUILTIN then*/
    if (_class_27694 != -9)
    goto L9E; // [3731] 3784

    /** scanner.e:2029				name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _15629 = _ch_27682 - 170;
    if ((object)((uintptr_t)_15629 +(uintptr_t) HIGH_BITS) >= 0){
        _15629 = NewDouble((eudouble)_15629);
    }
    if (IS_ATOM_INT(_15629)) {
        _15630 = _15629 + 24;
    }
    else {
        _15630 = NewDouble(DBL_PTR(_15629)->dbl + (eudouble)24);
    }
    DeRef(_15629);
    _15629 = NOVALUE;
    _2 = (object)SEQ_PTR(_62keylist_23493);
    if (!IS_ATOM_INT(_15630)){
        _15631 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15630)->dbl));
    }
    else{
        _15631 = (object)*(((s1_ptr)_2)->base + _15630);
    }
    DeRef(_name_27695);
    _2 = (object)SEQ_PTR(_15631);
    _name_27695 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_name_27695);
    _15631 = NOVALUE;

    /** scanner.e:2030				return keyfind(name, -1)*/
    RefDS(_name_27695);
    _32004 = _53hashfn(_name_27695);
    RefDS(_name_27695);
    _15633 = _53keyfind(_name_27695, -1, _27current_file_no_20571, 0, _32004);
    _32004 = NOVALUE;
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRefDS(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15627);
    _15627 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15617);
    _15617 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15621);
    _15621 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15616);
    _15616 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15630);
    _15630 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15624);
    _15624 = NOVALUE;
    DeRef(_15622);
    _15622 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15633;
    goto L1; // [3781] 10
L9E: 

    /** scanner.e:2032			elsif class = BACK_QUOTE then*/
    if (_class_27694 != -12)
    goto L9F; // [3788] 3805

    /** scanner.e:2033				return ExtendedString( '`' )*/
    _15635 = _61ExtendedString(96);
    DeRef(_i_27685);
    DeRef(_yytext_27688);
    DeRef(_namespaces_27689);
    DeRef(_d_27690);
    DeRef(_tok_27692);
    DeRef(_name_27695);
    DeRef(_15519);
    _15519 = NOVALUE;
    DeRef(_15633);
    _15633 = NOVALUE;
    DeRef(_15607);
    _15607 = NOVALUE;
    DeRef(_15299);
    _15299 = NOVALUE;
    _15399 = NOVALUE;
    _15539 = NOVALUE;
    DeRef(_15627);
    _15627 = NOVALUE;
    DeRef(_15267);
    _15267 = NOVALUE;
    DeRef(_15507);
    _15507 = NOVALUE;
    DeRef(_15253);
    _15253 = NOVALUE;
    DeRef(_15526);
    _15526 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15545);
    _15545 = NOVALUE;
    DeRef(_15379);
    _15379 = NOVALUE;
    DeRef(_15434);
    _15434 = NOVALUE;
    DeRef(_15270);
    _15270 = NOVALUE;
    _15424 = NOVALUE;
    DeRef(_15484);
    _15484 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    DeRef(_15375);
    _15375 = NOVALUE;
    DeRef(_15470);
    _15470 = NOVALUE;
    DeRef(_15498);
    _15498 = NOVALUE;
    DeRef(_15475);
    _15475 = NOVALUE;
    DeRef(_15617);
    _15617 = NOVALUE;
    DeRef(_15572);
    _15572 = NOVALUE;
    _15331 = NOVALUE;
    DeRef(_15508);
    _15508 = NOVALUE;
    DeRef(_15611);
    _15611 = NOVALUE;
    DeRef(_15273);
    _15273 = NOVALUE;
    DeRef(_15568);
    _15568 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15276);
    _15276 = NOVALUE;
    _15346 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15503);
    _15503 = NOVALUE;
    DeRef(_15330);
    _15330 = NOVALUE;
    _15420 = NOVALUE;
    _15442 = NOVALUE;
    _15309 = NOVALUE;
    DeRef(_15502);
    _15502 = NOVALUE;
    DeRef(_15621);
    _15621 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15386);
    _15386 = NOVALUE;
    _15446 = NOVALUE;
    DeRef(_15616);
    _15616 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15566);
    _15566 = NOVALUE;
    DeRef(_15380);
    _15380 = NOVALUE;
    _15513 = NOVALUE;
    _15389 = NOVALUE;
    DeRef(_15283);
    _15283 = NOVALUE;
    DeRef(_15460);
    _15460 = NOVALUE;
    DeRef(_15630);
    _15630 = NOVALUE;
    DeRef(_15590);
    _15590 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15436);
    _15436 = NOVALUE;
    DeRef(_15304);
    _15304 = NOVALUE;
    DeRef(_15577);
    _15577 = NOVALUE;
    DeRef(_15563);
    _15563 = NOVALUE;
    _15320 = NOVALUE;
    DeRef(_15428);
    _15428 = NOVALUE;
    DeRef(_15573);
    _15573 = NOVALUE;
    DeRef(_15280);
    _15280 = NOVALUE;
    DeRef(_15401);
    _15401 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15612);
    _15612 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15624);
    _15624 = NOVALUE;
    DeRef(_15622);
    _15622 = NOVALUE;
    DeRef(_15468);
    _15468 = NOVALUE;
    return _15635;
    goto L1; // [3802] 10
L9F: 

    /** scanner.e:2036				InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _class_27694;
    _15636 = MAKE_SEQ(_1);
    _49InternalErr(268, _15636);
    _15636 = NOVALUE;

    /** scanner.e:2039	   end while*/
    goto L1; // [3818] 10
L2: 
    ;
}


void _61eu_namespace()
{
    object _eu_tok_28487 = NOVALUE;
    object _eu_ns_28489 = NOVALUE;
    object _32003 = NOVALUE;
    object _32002 = NOVALUE;
    object _15645 = NOVALUE;
    object _15643 = NOVALUE;
    object _15641 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:2047		eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_15639);
    _32002 = _15639;
    _32003 = _53hashfn(_32002);
    _32002 = NOVALUE;
    RefDS(_15639);
    _0 = _eu_tok_28487;
    _eu_tok_28487 = _53keyfind(_15639, -1, _27current_file_no_20571, 1, _32003);
    DeRef(_0);
    _32003 = NOVALUE;

    /** scanner.e:2050		eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_eu_tok_28487);
    _15641 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15641);
    _eu_ns_28489 = _61NameSpace_declaration(_15641);
    _15641 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_28489)) {
        _1 = (object)(DBL_PTR(_eu_ns_28489)->dbl);
        DeRefDS(_eu_ns_28489);
        _eu_ns_28489 = _1;
    }

    /** scanner.e:2051		SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28489 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _15643 = NOVALUE;

    /** scanner.e:2052		SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28489 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 6;
    DeRef(_1);
    _15645 = NOVALUE;

    /** scanner.e:2053	end procedure*/
    DeRef(_eu_tok_28487);
    return;
    ;
}


object _61StringToken(object _pDelims_28507)
{
    object _ch_28508 = NOVALUE;
    object _m_28509 = NOVALUE;
    object _gtext_28510 = NOVALUE;
    object _level_28541 = NOVALUE;
    object _15684 = NOVALUE;
    object _15682 = NOVALUE;
    object _15680 = NOVALUE;
    object _15661 = NOVALUE;
    object _15660 = NOVALUE;
    object _15654 = NOVALUE;
    object _15652 = NOVALUE;
    object _15650 = NOVALUE;
    object _15648 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2064		ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2065		while ch = ' ' or ch = '\t' do*/
L1: 
    _15648 = (_ch_28508 == 32);
    if (_15648 != 0) {
        goto L2; // [19] 32
    }
    _15650 = (_ch_28508 == 9);
    if (_15650 == 0)
    {
        DeRef(_15650);
        _15650 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15650);
        _15650 = NOVALUE;
    }
L2: 

    /** scanner.e:2066			ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2067		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2069		pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15652 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_28507, _pDelims_28507, _15652);
    DeRefDS(_15652);
    _15652 = NOVALUE;

    /** scanner.e:2070		gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_28510);
    _gtext_28510 = _5;

    /** scanner.e:2071		while not find(ch,  pDelims) label "top" do*/
L4: 
    _15654 = find_from(_ch_28508, _pDelims_28507, 1);
    if (_15654 != 0)
    goto L5; // [77] 391
    _15654 = NOVALUE;

    /** scanner.e:2072			if ch = '-' then*/
    if (_ch_28508 != 45)
    goto L6; // [82] 145

    /** scanner.e:2073				ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2074				if ch = '-' then*/
    if (_ch_28508 != 45)
    goto L7; // [95] 137

    /** scanner.e:2075					while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10;
    ((intptr_t *)_2)[2] = 26;
    _15660 = MAKE_SEQ(_1);
    _15661 = find_from(_ch_28508, _15660, 1);
    DeRefDS(_15660);
    _15660 = NOVALUE;
    if (_15661 != 0)
    goto L5; // [115] 391
    _15661 = NOVALUE;

    /** scanner.e:2076						ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2077					end while*/
    goto L8; // [127] 104

    /** scanner.e:2078					exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** scanner.e:2080					ungetch()*/
    _61ungetch();
    goto L9; // [142] 373
L6: 

    /** scanner.e:2082			elsif ch = '/' then*/
    if (_ch_28508 != 47)
    goto LA; // [147] 372

    /** scanner.e:2083				ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2084				if ch = '*' then*/
    if (_ch_28508 != 42)
    goto LB; // [160] 361

    /** scanner.e:2085					integer level = 1*/
    _level_28541 = 1;

    /** scanner.e:2086					while level > 0 do*/
LC: 
    if (_level_28541 <= 0)
    goto LD; // [174] 293

    /** scanner.e:2087						ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2088						if ch = '/' then*/
    if (_ch_28508 != 47)
    goto LE; // [187] 221

    /** scanner.e:2089							ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2090							if ch = '*' then*/
    if (_ch_28508 != 42)
    goto LF; // [200] 213

    /** scanner.e:2091								level += 1*/
    _level_28541 = _level_28541 + 1;
    goto LC; // [210] 174
LF: 

    /** scanner.e:2093								ungetch()*/
    _61ungetch();
    goto LC; // [218] 174
LE: 

    /** scanner.e:2095						elsif ch = '*' then*/
    if (_ch_28508 != 42)
    goto L10; // [223] 257

    /** scanner.e:2096							ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2097							if ch = '/' then*/
    if (_ch_28508 != 47)
    goto L11; // [236] 249

    /** scanner.e:2098								level -= 1*/
    _level_28541 = _level_28541 - 1;
    goto LC; // [246] 174
L11: 

    /** scanner.e:2100								ungetch()*/
    _61ungetch();
    goto LC; // [254] 174
L10: 

    /** scanner.e:2102						elsif ch = '\n' then*/
    if (_ch_28508 != 10)
    goto L12; // [259] 270

    /** scanner.e:2103							read_line()*/
    _61read_line();
    goto LC; // [267] 174
L12: 

    /** scanner.e:2104						elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_28508 != 26)
    goto LC; // [274] 174

    /** scanner.e:2105							ungetch()*/
    _61ungetch();

    /** scanner.e:2106							exit*/
    goto LD; // [284] 293

    /** scanner.e:2108					end while*/
    goto LC; // [290] 174
LD: 

    /** scanner.e:2109					ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2110					if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28510)){
            _15680 = SEQ_PTR(_gtext_28510)->length;
    }
    else {
        _15680 = 1;
    }
    if (_15680 != 0)
    goto L13; // [305] 350

    /** scanner.e:2111						while ch = ' ' or ch = '\t' do*/
L14: 
    _15682 = (_ch_28508 == 32);
    if (_15682 != 0) {
        goto L15; // [318] 331
    }
    _15684 = (_ch_28508 == 9);
    if (_15684 == 0)
    {
        DeRef(_15684);
        _15684 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_15684);
        _15684 = NOVALUE;
    }
L15: 

    /** scanner.e:2112							ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2113						end while*/
    goto L14; // [340] 314
L16: 

    /** scanner.e:2114						continue "top"*/
    goto L4; // [347] 72
L13: 

    /** scanner.e:2116					exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** scanner.e:2119					ungetch()*/
    _61ungetch();

    /** scanner.e:2120					ch = '/'*/
    _ch_28508 = 47;
L17: 
LA: 
L9: 

    /** scanner.e:2123			gtext &= ch*/
    Append(&_gtext_28510, _gtext_28510, _ch_28508);

    /** scanner.e:2124			ch = getch()*/
    _ch_28508 = _61getch();
    if (!IS_ATOM_INT(_ch_28508)) {
        _1 = (object)(DBL_PTR(_ch_28508)->dbl);
        DeRefDS(_ch_28508);
        _ch_28508 = _1;
    }

    /** scanner.e:2125		end while*/
    goto L4; // [388] 72
L5: 

    /** scanner.e:2127		ungetch() -- put back end-word token.*/
    _61ungetch();

    /** scanner.e:2129		return gtext*/
    DeRefDSi(_pDelims_28507);
    DeRef(_15682);
    _15682 = NOVALUE;
    DeRef(_15648);
    _15648 = NOVALUE;
    return _gtext_28510;
    ;
}


void _61IncludeScan(object _is_public_28578)
{
    object _ch_28579 = NOVALUE;
    object _gtext_28580 = NOVALUE;
    object _s_28582 = NOVALUE;
    object _32001 = NOVALUE;
    object _15748 = NOVALUE;
    object _15747 = NOVALUE;
    object _15745 = NOVALUE;
    object _15743 = NOVALUE;
    object _15742 = NOVALUE;
    object _15737 = NOVALUE;
    object _15734 = NOVALUE;
    object _15732 = NOVALUE;
    object _15731 = NOVALUE;
    object _15729 = NOVALUE;
    object _15727 = NOVALUE;
    object _15725 = NOVALUE;
    object _15723 = NOVALUE;
    object _15717 = NOVALUE;
    object _15715 = NOVALUE;
    object _15709 = NOVALUE;
    object _15705 = NOVALUE;
    object _15704 = NOVALUE;
    object _15699 = NOVALUE;
    object _15696 = NOVALUE;
    object _15695 = NOVALUE;
    object _15691 = NOVALUE;
    object _15689 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2149		ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2150		while ch = ' ' or ch = '\t' do*/
L1: 
    _15689 = (_ch_28579 == 32);
    if (_15689 != 0) {
        goto L2; // [19] 32
    }
    _15691 = (_ch_28579 == 9);
    if (_15691 == 0)
    {
        DeRef(_15691);
        _15691 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15691);
        _15691 = NOVALUE;
    }
L2: 

    /** scanner.e:2151			ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2152		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2155		gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_28580);
    _gtext_28580 = _5;

    /** scanner.e:2157		if ch = '"' then*/
    if (_ch_28579 != 34)
    goto L4; // [53] 143

    /** scanner.e:2159			ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2160			while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 34;
    ((intptr_t*)_2)[4] = 26;
    _15695 = MAKE_SEQ(_1);
    _15696 = find_from(_ch_28579, _15695, 1);
    DeRefDS(_15695);
    _15695 = NOVALUE;
    if (_15696 != 0)
    goto L6; // [83] 124
    _15696 = NOVALUE;

    /** scanner.e:2161				if ch = '\\' then*/
    if (_ch_28579 != 92)
    goto L7; // [88] 105

    /** scanner.e:2162					gtext &= EscapeChar('"')*/
    _15699 = _61EscapeChar(34);
    if (IS_SEQUENCE(_gtext_28580) && IS_ATOM(_15699)) {
        Ref(_15699);
        Append(&_gtext_28580, _gtext_28580, _15699);
    }
    else if (IS_ATOM(_gtext_28580) && IS_SEQUENCE(_15699)) {
    }
    else {
        Concat((object_ptr)&_gtext_28580, _gtext_28580, _15699);
    }
    DeRef(_15699);
    _15699 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** scanner.e:2164					gtext &= ch*/
    Append(&_gtext_28580, _gtext_28580, _ch_28579);
L8: 

    /** scanner.e:2166				ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2167			end while*/
    goto L5; // [121] 69
L6: 

    /** scanner.e:2168			if ch != '"' then*/
    if (_ch_28579 == 34)
    goto L9; // [126] 189

    /** scanner.e:2169				CompileErr(MISSING_CLOSING_QUOTE_ON_FILE_NAME)*/
    RefDS(_22209);
    _49CompileErr(115, _22209, 0);
    goto L9; // [140] 189
L4: 

    /** scanner.e:2173			while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32;
    ((intptr_t*)_2)[2] = 9;
    ((intptr_t*)_2)[3] = 10;
    ((intptr_t*)_2)[4] = 13;
    ((intptr_t*)_2)[5] = 26;
    _15704 = MAKE_SEQ(_1);
    _15705 = find_from(_ch_28579, _15704, 1);
    DeRefDS(_15704);
    _15704 = NOVALUE;
    if (_15705 != 0)
    goto LB; // [163] 184
    _15705 = NOVALUE;

    /** scanner.e:2174				gtext &= ch*/
    Append(&_gtext_28580, _gtext_28580, _ch_28579);

    /** scanner.e:2175				ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2176			end while*/
    goto LA; // [181] 148
LB: 

    /** scanner.e:2177			ungetch()*/
    _61ungetch();
L9: 

    /** scanner.e:2180		if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28580)){
            _15709 = SEQ_PTR(_gtext_28580)->length;
    }
    else {
        _15709 = 1;
    }
    if (_15709 != 0)
    goto LC; // [194] 208

    /** scanner.e:2181			CompileErr(FILE_NAME_IS_MISSING)*/
    RefDS(_22209);
    _49CompileErr(95, _22209, 0);
LC: 

    /** scanner.e:2185		ifdef WINDOWS then*/

    /** scanner.e:2186			new_include_name = match_replace(`/`, gtext, `\`)*/
    RefDS(_15711);
    RefDS(_gtext_28580);
    RefDS(_15712);
    _0 = _14match_replace(_15711, _gtext_28580, _15712, 0);
    DeRef(_27new_include_name_20694);
    _27new_include_name_20694 = _0;

    /** scanner.e:2192		ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2193		while ch = ' ' or ch = '\t' do*/
LD: 
    _15715 = (_ch_28579 == 32);
    if (_15715 != 0) {
        goto LE; // [237] 250
    }
    _15717 = (_ch_28579 == 9);
    if (_15717 == 0)
    {
        DeRef(_15717);
        _15717 = NOVALUE;
        goto LF; // [246] 262
    }
    else{
        DeRef(_15717);
        _15717 = NOVALUE;
    }
LE: 

    /** scanner.e:2194			ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2195		end while*/
    goto LD; // [259] 233
LF: 

    /** scanner.e:2197		new_include_space = 0*/
    _61new_include_space_25923 = 0;

    /** scanner.e:2199		if ch = 'a' then*/
    if (_ch_28579 != 97)
    goto L10; // [271] 536

    /** scanner.e:2201			ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2202			if ch = 's' then*/
    if (_ch_28579 != 115)
    goto L11; // [284] 523

    /** scanner.e:2203				ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2204				if ch = ' ' or ch = '\t' then*/
    _15723 = (_ch_28579 == 32);
    if (_15723 != 0) {
        goto L12; // [301] 314
    }
    _15725 = (_ch_28579 == 9);
    if (_15725 == 0)
    {
        DeRef(_15725);
        _15725 = NOVALUE;
        goto L13; // [310] 510
    }
    else{
        DeRef(_15725);
        _15725 = NOVALUE;
    }
L12: 

    /** scanner.e:2207					ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2208					while ch = ' ' or ch = '\t' do*/
L14: 
    _15727 = (_ch_28579 == 32);
    if (_15727 != 0) {
        goto L15; // [330] 343
    }
    _15729 = (_ch_28579 == 9);
    if (_15729 == 0)
    {
        DeRef(_15729);
        _15729 = NOVALUE;
        goto L16; // [339] 355
    }
    else{
        DeRef(_15729);
        _15729 = NOVALUE;
    }
L15: 

    /** scanner.e:2209						ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2210					end while*/
    goto L14; // [352] 326
L16: 

    /** scanner.e:2213					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_61char_class_25932);
    _15731 = (object)*(((s1_ptr)_2)->base + _ch_28579);
    _15732 = (_15731 == -2);
    _15731 = NOVALUE;
    if (_15732 != 0) {
        goto L17; // [369] 382
    }
    _15734 = (_ch_28579 == 95);
    if (_15734 == 0)
    {
        DeRef(_15734);
        _15734 = NOVALUE;
        goto L18; // [378] 497
    }
    else{
        DeRef(_15734);
        _15734 = NOVALUE;
    }
L17: 

    /** scanner.e:2214						gtext = {ch}*/
    _0 = _gtext_28580;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_28579;
    _gtext_28580 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:2215						ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2216						while id_char[ch] = TRUE do*/
L19: 
    _2 = (object)SEQ_PTR(_61id_char_25933);
    _15737 = (object)*(((s1_ptr)_2)->base + _ch_28579);
    if (_15737 != _9TRUE_441)
    goto L1A; // [408] 430

    /** scanner.e:2217							gtext &= ch*/
    Append(&_gtext_28580, _gtext_28580, _ch_28579);

    /** scanner.e:2218							ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2219						end while*/
    goto L19; // [427] 400
L1A: 

    /** scanner.e:2221						ungetch()*/
    _61ungetch();

    /** scanner.e:2222						s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_28580);
    _32001 = _53hashfn(_gtext_28580);
    RefDS(_gtext_28580);
    _0 = _s_28582;
    _s_28582 = _53keyfind(_gtext_28580, -1, _27current_file_no_20571, 1, _32001);
    DeRef(_0);
    _32001 = NOVALUE;

    /** scanner.e:2223						if not find(s[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_s_28582);
    _15742 = (object)*(((s1_ptr)_2)->base + 1);
    _15743 = find_from(_15742, _29ID_TOKS_12283, 1);
    _15742 = NOVALUE;
    if (_15743 != 0)
    goto L1B; // [467] 480
    _15743 = NOVALUE;

    /** scanner.e:2224							CompileErr(A_NEW_NAMESPACE_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(36, _22209, 0);
L1B: 

    /** scanner.e:2226						new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (object)SEQ_PTR(_s_28582);
    _15745 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_15745);
    _0 = _61NameSpace_declaration(_15745);
    _61new_include_space_25923 = _0;
    _15745 = NOVALUE;
    if (!IS_ATOM_INT(_61new_include_space_25923)) {
        _1 = (object)(DBL_PTR(_61new_include_space_25923)->dbl);
        DeRefDS(_61new_include_space_25923);
        _61new_include_space_25923 = _1;
    }
    goto L1C; // [494] 651
L18: 

    /** scanner.e:2228						CompileErr(MISSING_NAMESPACE_QUALIFIER)*/
    RefDS(_22209);
    _49CompileErr(113, _22209, 0);
    goto L1C; // [507] 651
L13: 

    /** scanner.e:2231					CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22209);
    _49CompileErr(100, _22209, 0);
    goto L1C; // [520] 651
L11: 

    /** scanner.e:2234				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22209);
    _49CompileErr(100, _22209, 0);
    goto L1C; // [533] 651
L10: 

    /** scanner.e:2237		elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10;
    ((intptr_t*)_2)[2] = 13;
    ((intptr_t*)_2)[3] = 26;
    _15747 = MAKE_SEQ(_1);
    _15748 = find_from(_ch_28579, _15747, 1);
    DeRefDS(_15747);
    _15747 = NOVALUE;
    if (_15748 == 0)
    {
        _15748 = NOVALUE;
        goto L1D; // [551] 561
    }
    else{
        _15748 = NOVALUE;
    }

    /** scanner.e:2238			ungetch()*/
    _61ungetch();
    goto L1C; // [558] 651
L1D: 

    /** scanner.e:2240		elsif ch = '-' then*/
    if (_ch_28579 != 45)
    goto L1E; // [563] 601

    /** scanner.e:2241			ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2242			if ch != '-' then*/
    if (_ch_28579 == 45)
    goto L1F; // [576] 590

    /** scanner.e:2243				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22209);
    _49CompileErr(100, _22209, 0);
L1F: 

    /** scanner.e:2245			ungetch()*/
    _61ungetch();

    /** scanner.e:2246			ungetch()*/
    _61ungetch();
    goto L1C; // [598] 651
L1E: 

    /** scanner.e:2248		elsif ch = '/' then*/
    if (_ch_28579 != 47)
    goto L20; // [603] 641

    /** scanner.e:2249			ch = getch()*/
    _ch_28579 = _61getch();
    if (!IS_ATOM_INT(_ch_28579)) {
        _1 = (object)(DBL_PTR(_ch_28579)->dbl);
        DeRefDS(_ch_28579);
        _ch_28579 = _1;
    }

    /** scanner.e:2250			if ch != '*' then*/
    if (_ch_28579 == 42)
    goto L21; // [616] 630

    /** scanner.e:2251				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22209);
    _49CompileErr(100, _22209, 0);
L21: 

    /** scanner.e:2253			ungetch()*/
    _61ungetch();

    /** scanner.e:2254			ungetch()*/
    _61ungetch();
    goto L1C; // [638] 651
L20: 

    /** scanner.e:2257			CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22209);
    _49CompileErr(100, _22209, 0);
L1C: 

    /** scanner.e:2260		start_include = TRUE -- let scanner know*/
    _61start_include_25925 = _9TRUE_441;

    /** scanner.e:2261		public_include = is_public*/
    _61public_include_25928 = _is_public_28578;

    /** scanner.e:2262	end procedure*/
    DeRef(_gtext_28580);
    DeRef(_s_28582);
    DeRef(_15723);
    _15723 = NOVALUE;
    DeRef(_15732);
    _15732 = NOVALUE;
    DeRef(_15715);
    _15715 = NOVALUE;
    DeRef(_15689);
    _15689 = NOVALUE;
    _15737 = NOVALUE;
    DeRef(_15727);
    _15727 = NOVALUE;
    return;
    ;
}


void _61main_file()
{
    object _15757 = NOVALUE;
    object _15756 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2275		if repl and top_level_block = -1 then*/
    if (0 == 0) {
        goto L1; // [5] 29
    }
    _15757 = (_64top_level_block_25493 == -1);
    if (_15757 == 0)
    {
        DeRef(_15757);
        _15757 = NOVALUE;
        goto L1; // [16] 29
    }
    else{
        DeRef(_15757);
        _15757 = NOVALUE;
    }

    /** scanner.e:2276			top_level_block = current_block*/
    _64top_level_block_25493 = _64current_block_25492;
L1: 

    /** scanner.e:2278		ifdef STDDEBUG then*/

    /** scanner.e:2283			read_line()*/
    _61read_line();

    /** scanner.e:2284			default_namespace( )*/
    _61default_namespace();

    /** scanner.e:2286	end procedure*/
    return;
    ;
}


void _61cleanup_open_includes()
{
    object _15760 = NOVALUE;
    object _15759 = NOVALUE;
    object _15758 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2289		for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_61IncludeStk_25934)){
            _15758 = SEQ_PTR(_61IncludeStk_25934)->length;
    }
    else {
        _15758 = 1;
    }
    {
        object _i_28719;
        _i_28719 = 1;
L1: 
        if (_i_28719 > _15758){
            goto L2; // [8] 36
        }

        /** scanner.e:2290			close( IncludeStk[i][FILE_PTR] )*/
        _2 = (object)SEQ_PTR(_61IncludeStk_25934);
        _15759 = (object)*(((s1_ptr)_2)->base + _i_28719);
        _2 = (object)SEQ_PTR(_15759);
        _15760 = (object)*(((s1_ptr)_2)->base + 3);
        _15759 = NOVALUE;
        if (IS_ATOM_INT(_15760))
        EClose(_15760);
        else
        EClose((object)DBL_PTR(_15760)->dbl);
        _15760 = NOVALUE;

        /** scanner.e:2291		end for*/
        _i_28719 = _i_28719 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** scanner.e:2292	end procedure*/
    return;
    ;
}



// 0xFB1FF60C
