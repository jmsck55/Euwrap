// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _40arch_bits()
{
    object _8545 = NOVALUE;
    object _8544 = NOVALUE;
    object _8543 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:72		return sprintf( "%d-bit", 8 * sizeof( C_POINTER ) )*/
    _8543 = eu_sizeof( 50331649 );
    if (_8543 <= INT15){
        _8544 = 8 * _8543;
    }
    else{
        _8544 = NewDouble(8 * (eudouble)_8543);
    }
    _8543 = NOVALUE;
    _8545 = EPrintf(-9999999, _8542, _8544);
    DeRef(_8544);
    _8544 = NOVALUE;
    return _8545;
    ;
}


object _40version_major()
{
    object _8554 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:100		return version_info[MAJ_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8554 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_8554);
    return _8554;
    ;
}


object _40version_minor()
{
    object _8555 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:112		return version_info[MIN_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8555 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_8555);
    return _8555;
    ;
}


object _40version_patch()
{
    object _8556 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:124		return version_info[PAT_VER]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8556 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_8556);
    return _8556;
    ;
}


object _40version_node(object _full_14947)
{
    object _8563 = NOVALUE;
    object _8562 = NOVALUE;
    object _8561 = NOVALUE;
    object _8560 = NOVALUE;
    object _8559 = NOVALUE;
    object _8558 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:141		if full or length(version_info[NODE]) < 12 then*/
    if (0 != 0) {
        goto L1; // [5] 27
    }
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8558 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_8558)){
            _8559 = SEQ_PTR(_8558)->length;
    }
    else {
        _8559 = 1;
    }
    _8558 = NOVALUE;
    _8560 = (_8559 < 12);
    _8559 = NOVALUE;
    if (_8560 == 0)
    {
        DeRef(_8560);
        _8560 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_8560);
        _8560 = NOVALUE;
    }
L1: 

    /** info.e:142			return version_info[NODE]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8561 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_8561);
    _8558 = NOVALUE;
    return _8561;
L2: 

    /** info.e:145		return version_info[NODE][1..12]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8562 = (object)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_8563;
    RHS_Slice(_8562, 1, 12);
    _8562 = NOVALUE;
    _8561 = NOVALUE;
    _8558 = NOVALUE;
    return _8563;
    ;
}


object _40version_date(object _full_14961)
{
    object _8572 = NOVALUE;
    object _8571 = NOVALUE;
    object _8570 = NOVALUE;
    object _8569 = NOVALUE;
    object _8568 = NOVALUE;
    object _8567 = NOVALUE;
    object _8565 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:181		if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_14961 != 0) {
        _8565 = 1;
        goto L1; // [5] 15
    }
    _8565 = (_40is_developmental_14904 != 0);
L1: 
    if (_8565 != 0) {
        goto L2; // [15] 37
    }
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8567 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_8567)){
            _8568 = SEQ_PTR(_8567)->length;
    }
    else {
        _8568 = 1;
    }
    _8567 = NOVALUE;
    _8569 = (_8568 < 10);
    _8568 = NOVALUE;
    if (_8569 == 0)
    {
        DeRef(_8569);
        _8569 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_8569);
        _8569 = NOVALUE;
    }
L2: 

    /** info.e:182			return version_info[REVISION_DATE]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8570 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_8570);
    _8567 = NOVALUE;
    return _8570;
L3: 

    /** info.e:185		return version_info[REVISION_DATE][1..10]*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8571 = (object)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_8572;
    RHS_Slice(_8571, 1, 10);
    _8571 = NOVALUE;
    _8570 = NOVALUE;
    _8567 = NOVALUE;
    return _8572;
    ;
}


object _40version_string(object _full_14976)
{
    object _version_revision_inlined_version_revision_at_41_14985 = NOVALUE;
    object _8592 = NOVALUE;
    object _8591 = NOVALUE;
    object _8590 = NOVALUE;
    object _8589 = NOVALUE;
    object _8588 = NOVALUE;
    object _8587 = NOVALUE;
    object _8586 = NOVALUE;
    object _8585 = NOVALUE;
    object _8583 = NOVALUE;
    object _8582 = NOVALUE;
    object _8581 = NOVALUE;
    object _8580 = NOVALUE;
    object _8579 = NOVALUE;
    object _8578 = NOVALUE;
    object _8577 = NOVALUE;
    object _8576 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:225		if full or is_developmental then*/
    if (0 != 0) {
        goto L1; // [5] 16
    }
    if (_40is_developmental_14904 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** info.e:226			return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8576 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8577 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8578 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8579 = (object)*(((s1_ptr)_2)->base + 4);

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_14985);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _version_revision_inlined_version_revision_at_41_14985 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_14985);
    _8580 = _40version_node(0);
    _8581 = _40version_date(_full_14976);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8576);
    ((intptr_t*)_2)[1] = _8576;
    Ref(_8577);
    ((intptr_t*)_2)[2] = _8577;
    Ref(_8578);
    ((intptr_t*)_2)[3] = _8578;
    Ref(_8579);
    ((intptr_t*)_2)[4] = _8579;
    Ref(_version_revision_inlined_version_revision_at_41_14985);
    ((intptr_t*)_2)[5] = _version_revision_inlined_version_revision_at_41_14985;
    ((intptr_t*)_2)[6] = _8580;
    ((intptr_t*)_2)[7] = _8581;
    _8582 = MAKE_SEQ(_1);
    _8581 = NOVALUE;
    _8580 = NOVALUE;
    _8579 = NOVALUE;
    _8578 = NOVALUE;
    _8577 = NOVALUE;
    _8576 = NOVALUE;
    _8583 = EPrintf(-9999999, _8575, _8582);
    DeRefDS(_8582);
    _8582 = NOVALUE;
    return _8583;
    goto L3; // [77] 132
L2: 

    /** info.e:236			return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8585 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8586 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8587 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _8588 = (object)*(((s1_ptr)_2)->base + 4);
    _8589 = _40version_node(0);
    _8590 = _40version_date(_full_14976);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_8585);
    ((intptr_t*)_2)[1] = _8585;
    Ref(_8586);
    ((intptr_t*)_2)[2] = _8586;
    Ref(_8587);
    ((intptr_t*)_2)[3] = _8587;
    Ref(_8588);
    ((intptr_t*)_2)[4] = _8588;
    ((intptr_t*)_2)[5] = _8589;
    ((intptr_t*)_2)[6] = _8590;
    _8591 = MAKE_SEQ(_1);
    _8590 = NOVALUE;
    _8589 = NOVALUE;
    _8588 = NOVALUE;
    _8587 = NOVALUE;
    _8586 = NOVALUE;
    _8585 = NOVALUE;
    _8592 = EPrintf(-9999999, _8584, _8591);
    DeRefDS(_8591);
    _8591 = NOVALUE;
    DeRef(_8583);
    _8583 = NOVALUE;
    return _8592;
L3: 
    ;
}


object _40version_string_long(object _full_15007)
{
    object _platform_name_inlined_platform_name_at_8_15011 = NOVALUE;
    object _8600 = NOVALUE;
    object _8599 = NOVALUE;
    object _8596 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:284		return version_string(full) & " for " & platform_name() & " " & arch_bits()*/
    _8596 = _40version_string(0);

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_8535);
    DeRefi(_platform_name_inlined_platform_name_at_8_15011);
    _platform_name_inlined_platform_name_at_8_15011 = _8535;
    _8599 = _40arch_bits();
    {
        object concat_list[5];

        concat_list[0] = _8599;
        concat_list[1] = _8598;
        concat_list[2] = _platform_name_inlined_platform_name_at_8_15011;
        concat_list[3] = _8597;
        concat_list[4] = _8596;
        Concat_N((object_ptr)&_8600, concat_list, 5);
    }
    DeRef(_8599);
    _8599 = NOVALUE;
    DeRef(_8596);
    _8596 = NOVALUE;
    return _8600;
    ;
}


object _40all_copyrights()
{
    object _pcre_copyright_inlined_pcre_copyright_at_19_15034 = NOVALUE;
    object _euphoria_copyright_2__tmp_at2_15032 = NOVALUE;
    object _euphoria_copyright_1__tmp_at2_15031 = NOVALUE;
    object _euphoria_copyright_inlined_euphoria_copyright_at_2_15030 = NOVALUE;
    object _8609 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:355		return {*/

    /** info.e:309		return {*/
    _0 = _euphoria_copyright_1__tmp_at2_15031;
    _euphoria_copyright_1__tmp_at2_15031 = _40version_string_long(0);
    DeRef(_0);
    if (IS_SEQUENCE(_8601) && IS_ATOM(_euphoria_copyright_1__tmp_at2_15031)) {
        Ref(_euphoria_copyright_1__tmp_at2_15031);
        Append(&_euphoria_copyright_2__tmp_at2_15032, _8601, _euphoria_copyright_1__tmp_at2_15031);
    }
    else if (IS_ATOM(_8601) && IS_SEQUENCE(_euphoria_copyright_1__tmp_at2_15031)) {
    }
    else {
        Concat((object_ptr)&_euphoria_copyright_2__tmp_at2_15032, _8601, _euphoria_copyright_1__tmp_at2_15031);
    }
    RefDS(_8604);
    RefDS(_euphoria_copyright_2__tmp_at2_15032);
    DeRef(_euphoria_copyright_inlined_euphoria_copyright_at_2_15030);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_2__tmp_at2_15032;
    ((intptr_t *)_2)[2] = _8604;
    _euphoria_copyright_inlined_euphoria_copyright_at_2_15030 = MAKE_SEQ(_1);
    DeRef(_euphoria_copyright_1__tmp_at2_15031);
    _euphoria_copyright_1__tmp_at2_15031 = NOVALUE;
    DeRef(_euphoria_copyright_2__tmp_at2_15032);
    _euphoria_copyright_2__tmp_at2_15032 = NOVALUE;

    /** info.e:331		return {*/
    RefDS(_8607);
    RefDS(_8606);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_19_15034);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _8606;
    ((intptr_t *)_2)[2] = _8607;
    _pcre_copyright_inlined_pcre_copyright_at_19_15034 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_19_15034);
    RefDS(_euphoria_copyright_inlined_euphoria_copyright_at_2_15030);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_inlined_euphoria_copyright_at_2_15030;
    ((intptr_t *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_19_15034;
    _8609 = MAKE_SEQ(_1);
    return _8609;
    ;
}



// 0x83DE0CDA
