// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _16isLeap(object _year_4252)
{
    object _ly_4253 = NOVALUE;
    object _2111 = NOVALUE;
    object _2110 = NOVALUE;
    object _2109 = NOVALUE;
    object _2108 = NOVALUE;
    object _2107 = NOVALUE;
    object _2106 = NOVALUE;
    object _2105 = NOVALUE;
    object _2104 = NOVALUE;
    object _2103 = NOVALUE;
    object _2100 = NOVALUE;
    object _2098 = NOVALUE;
    object _2097 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:89			ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 4;
    ((intptr_t*)_2)[2] = 100;
    ((intptr_t*)_2)[3] = 400;
    ((intptr_t*)_2)[4] = 3200;
    ((intptr_t*)_2)[5] = 80000;
    _2097 = MAKE_SEQ(_1);
    _2098 = binary_op(REMAINDER, _year_4252, _2097);
    DeRefDS(_2097);
    _2097 = NOVALUE;
    DeRefi(_ly_4253);
    _ly_4253 = binary_op(EQUALS, _2098, 0);
    DeRefDS(_2098);
    _2098 = NOVALUE;

    /** datetime.e:91			if not ly[1] then return 0 end if*/
    _2 = (object)SEQ_PTR(_ly_4253);
    _2100 = (object)*(((s1_ptr)_2)->base + 1);
    if (_2100 != 0)
    goto L1; // [29] 37
    _2100 = NOVALUE;
    DeRefDSi(_ly_4253);
    return 0;
L1: 

    /** datetime.e:93			if year <= Gregorian_Reformation then*/
    if (_year_4252 > 1752)
    goto L2; // [39] 52

    /** datetime.e:94					return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_4253);
    return 1;
    goto L3; // [49] 95
L2: 

    /** datetime.e:96					return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (object)SEQ_PTR(_ly_4253);
    _2103 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_ly_4253);
    _2104 = (object)*(((s1_ptr)_2)->base + 2);
    _2105 = _2103 - _2104;
    if ((object)((uintptr_t)_2105 +(uintptr_t) HIGH_BITS) >= 0){
        _2105 = NewDouble((eudouble)_2105);
    }
    _2103 = NOVALUE;
    _2104 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_4253);
    _2106 = (object)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_2105)) {
        _2107 = _2105 + _2106;
        if ((object)((uintptr_t)_2107 + (uintptr_t)HIGH_BITS) >= 0){
            _2107 = NewDouble((eudouble)_2107);
        }
    }
    else {
        _2107 = NewDouble(DBL_PTR(_2105)->dbl + (eudouble)_2106);
    }
    DeRef(_2105);
    _2105 = NOVALUE;
    _2106 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_4253);
    _2108 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_2107)) {
        _2109 = _2107 - _2108;
        if ((object)((uintptr_t)_2109 +(uintptr_t) HIGH_BITS) >= 0){
            _2109 = NewDouble((eudouble)_2109);
        }
    }
    else {
        _2109 = NewDouble(DBL_PTR(_2107)->dbl - (eudouble)_2108);
    }
    DeRef(_2107);
    _2107 = NOVALUE;
    _2108 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_4253);
    _2110 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_2109)) {
        _2111 = _2109 + _2110;
        if ((object)((uintptr_t)_2111 + (uintptr_t)HIGH_BITS) >= 0){
            _2111 = NewDouble((eudouble)_2111);
        }
    }
    else {
        _2111 = NewDouble(DBL_PTR(_2109)->dbl + (eudouble)_2110);
    }
    DeRef(_2109);
    _2109 = NOVALUE;
    _2110 = NOVALUE;
    DeRefDSi(_ly_4253);
    return _2111;
L3: 
    ;
}


object _16daysInMonth(object _year_4277, object _month_4278)
{
    object _2119 = NOVALUE;
    object _2118 = NOVALUE;
    object _2117 = NOVALUE;
    object _2116 = NOVALUE;
    object _2114 = NOVALUE;
    object _2113 = NOVALUE;
    object _2112 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_4278)) {
        _1 = (object)(DBL_PTR(_month_4278)->dbl);
        DeRefDS(_month_4278);
        _month_4278 = _1;
    }

    /** datetime.e:101		if year = Gregorian_Reformation and month = 9 then*/
    _2112 = (_year_4277 == 1752);
    if (_2112 == 0) {
        goto L1; // [11] 32
    }
    _2114 = (_month_4278 == 9);
    if (_2114 == 0)
    {
        DeRef(_2114);
        _2114 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_2114);
        _2114 = NOVALUE;
    }

    /** datetime.e:102			return 19*/
    DeRef(_2112);
    _2112 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** datetime.e:103		elsif month != 2 then*/
    if (_month_4278 == 2)
    goto L3; // [34] 51

    /** datetime.e:104			return DaysPerMonth[month]*/
    _2 = (object)SEQ_PTR(_16DaysPerMonth_4235);
    _2116 = (object)*(((s1_ptr)_2)->base + _month_4278);
    Ref(_2116);
    DeRef(_2112);
    _2112 = NOVALUE;
    return _2116;
    goto L2; // [48] 70
L3: 

    /** datetime.e:106			return DaysPerMonth[month] + isLeap(year)*/
    _2 = (object)SEQ_PTR(_16DaysPerMonth_4235);
    _2117 = (object)*(((s1_ptr)_2)->base + _month_4278);
    _2118 = _16isLeap(_year_4277);
    if (IS_ATOM_INT(_2117) && IS_ATOM_INT(_2118)) {
        _2119 = _2117 + _2118;
        if ((object)((uintptr_t)_2119 + (uintptr_t)HIGH_BITS) >= 0){
            _2119 = NewDouble((eudouble)_2119);
        }
    }
    else {
        _2119 = binary_op(PLUS, _2117, _2118);
    }
    _2117 = NOVALUE;
    DeRef(_2118);
    _2118 = NOVALUE;
    DeRef(_2112);
    _2112 = NOVALUE;
    _2116 = NOVALUE;
    return _2119;
L2: 
    ;
}


object _16julianDayOfYear(object _ymd_4301)
{
    object _year_4302 = NOVALUE;
    object _month_4303 = NOVALUE;
    object _day_4304 = NOVALUE;
    object _d_4305 = NOVALUE;
    object _2135 = NOVALUE;
    object _2134 = NOVALUE;
    object _2133 = NOVALUE;
    object _2130 = NOVALUE;
    object _2129 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:124		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_4301);
    _year_4302 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_4302)){
        _year_4302 = (object)DBL_PTR(_year_4302)->dbl;
    }

    /** datetime.e:125		month = ymd[2]*/
    _2 = (object)SEQ_PTR(_ymd_4301);
    _month_4303 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_4303)){
        _month_4303 = (object)DBL_PTR(_month_4303)->dbl;
    }

    /** datetime.e:126		day = ymd[3]*/
    _2 = (object)SEQ_PTR(_ymd_4301);
    _day_4304 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_4304)){
        _day_4304 = (object)DBL_PTR(_day_4304)->dbl;
    }

    /** datetime.e:128		if month = 1 then return day end if*/
    if (_month_4303 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_4301);
    return _day_4304;
L1: 

    /** datetime.e:130		d = 0*/
    _d_4305 = 0;

    /** datetime.e:131		for i = 1 to month - 1 do*/
    _2129 = _month_4303 - 1;
    if ((object)((uintptr_t)_2129 +(uintptr_t) HIGH_BITS) >= 0){
        _2129 = NewDouble((eudouble)_2129);
    }
    {
        object _i_4312;
        _i_4312 = 1;
L2: 
        if (binary_op_a(GREATER, _i_4312, _2129)){
            goto L3; // [47] 74
        }

        /** datetime.e:132			d += daysInMonth(year, i)*/
        Ref(_i_4312);
        _2130 = _16daysInMonth(_year_4302, _i_4312);
        if (IS_ATOM_INT(_2130)) {
            _d_4305 = _d_4305 + _2130;
        }
        else {
            _d_4305 = binary_op(PLUS, _d_4305, _2130);
        }
        DeRef(_2130);
        _2130 = NOVALUE;
        if (!IS_ATOM_INT(_d_4305)) {
            _1 = (object)(DBL_PTR(_d_4305)->dbl);
            DeRefDS(_d_4305);
            _d_4305 = _1;
        }

        /** datetime.e:133		end for*/
        _0 = _i_4312;
        if (IS_ATOM_INT(_i_4312)) {
            _i_4312 = _i_4312 + 1;
            if ((object)((uintptr_t)_i_4312 +(uintptr_t) HIGH_BITS) >= 0){
                _i_4312 = NewDouble((eudouble)_i_4312);
            }
        }
        else {
            _i_4312 = binary_op_a(PLUS, _i_4312, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_4312);
    }

    /** datetime.e:135		d += day*/
    _d_4305 = _d_4305 + _day_4304;

    /** datetime.e:137		if year = Gregorian_Reformation and month = 9 then*/
    _2133 = (_year_4302 == 1752);
    if (_2133 == 0) {
        goto L4; // [86] 128
    }
    _2135 = (_month_4303 == 9);
    if (_2135 == 0)
    {
        DeRef(_2135);
        _2135 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_2135);
        _2135 = NOVALUE;
    }

    /** datetime.e:138			if day > 13 then*/
    if (_day_4304 <= 13)
    goto L5; // [100] 113

    /** datetime.e:139				d -= 11*/
    _d_4305 = _d_4305 - 11;
    goto L6; // [110] 127
L5: 

    /** datetime.e:140			elsif day > 2 then*/
    if (_day_4304 <= 2)
    goto L7; // [115] 126

    /** datetime.e:141				return 0*/
    DeRef(_ymd_4301);
    DeRef(_2133);
    _2133 = NOVALUE;
    DeRef(_2129);
    _2129 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** datetime.e:145		return d*/
    DeRef(_ymd_4301);
    DeRef(_2133);
    _2133 = NOVALUE;
    DeRef(_2129);
    _2129 = NOVALUE;
    return _d_4305;
    ;
}


object _16julianDay(object _ymd_4328)
{
    object _year_4329 = NOVALUE;
    object _j_4330 = NOVALUE;
    object _greg00_4331 = NOVALUE;
    object _2164 = NOVALUE;
    object _2161 = NOVALUE;
    object _2158 = NOVALUE;
    object _2157 = NOVALUE;
    object _2156 = NOVALUE;
    object _2155 = NOVALUE;
    object _2154 = NOVALUE;
    object _2153 = NOVALUE;
    object _2152 = NOVALUE;
    object _2151 = NOVALUE;
    object _2149 = NOVALUE;
    object _2148 = NOVALUE;
    object _2147 = NOVALUE;
    object _2146 = NOVALUE;
    object _2145 = NOVALUE;
    object _2144 = NOVALUE;
    object _2143 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:152		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_4328);
    _year_4329 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_4329)){
        _year_4329 = (object)DBL_PTR(_year_4329)->dbl;
    }

    /** datetime.e:153		j = julianDayOfYear(ymd)*/
    Ref(_ymd_4328);
    _j_4330 = _16julianDayOfYear(_ymd_4328);
    if (!IS_ATOM_INT(_j_4330)) {
        _1 = (object)(DBL_PTR(_j_4330)->dbl);
        DeRefDS(_j_4330);
        _j_4330 = _1;
    }

    /** datetime.e:155		year  -= 1*/
    _year_4329 = _year_4329 - 1;

    /** datetime.e:156		greg00 = year - Gregorian_Reformation00*/
    _greg00_4331 = _year_4329 - 1700;

    /** datetime.e:158		j += (*/
    if (_year_4329 <= INT15 && _year_4329 >= -INT15){
        _2143 = 365 * _year_4329;
    }
    else{
        _2143 = NewDouble(365 * (eudouble)_year_4329);
    }
    if (4 > 0 && _year_4329 >= 0) {
        _2144 = _year_4329 / 4;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_4329 / (eudouble)4);
        _2144 = (object)temp_dbl;
    }
    if (IS_ATOM_INT(_2143)) {
        _2145 = _2143 + _2144;
        if ((object)((uintptr_t)_2145 + (uintptr_t)HIGH_BITS) >= 0){
            _2145 = NewDouble((eudouble)_2145);
        }
    }
    else {
        _2145 = NewDouble(DBL_PTR(_2143)->dbl + (eudouble)_2144);
    }
    DeRef(_2143);
    _2143 = NOVALUE;
    _2144 = NOVALUE;
    _2146 = (_greg00_4331 > 0);
    if (100 > 0 && _greg00_4331 >= 0) {
        _2147 = _greg00_4331 / 100;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_greg00_4331 / (eudouble)100);
        _2147 = (object)temp_dbl;
    }
    _2148 = - _2147;
    _2149 = (_greg00_4331 % 400) ? NewDouble((eudouble)_greg00_4331 / 400) : (_greg00_4331 / 400);
    if (IS_ATOM_INT(_2149)) {
        _2151 = NewDouble((eudouble)_2149 + DBL_PTR(_2150)->dbl);
    }
    else {
        _2151 = NewDouble(DBL_PTR(_2149)->dbl + DBL_PTR(_2150)->dbl);
    }
    DeRef(_2149);
    _2149 = NOVALUE;
    _2152 = unary_op(FLOOR, _2151);
    DeRefDS(_2151);
    _2151 = NOVALUE;
    if (IS_ATOM_INT(_2152)) {
        _2153 = _2148 + _2152;
        if ((object)((uintptr_t)_2153 + (uintptr_t)HIGH_BITS) >= 0){
            _2153 = NewDouble((eudouble)_2153);
        }
    }
    else {
        _2153 = binary_op(PLUS, _2148, _2152);
    }
    _2148 = NOVALUE;
    DeRef(_2152);
    _2152 = NOVALUE;
    if (IS_ATOM_INT(_2153)) {
        if (_2153 <= INT15 && _2153 >= -INT15){
            _2154 = _2146 * _2153;
        }
        else{
            _2154 = NewDouble(_2146 * (eudouble)_2153);
        }
    }
    else {
        _2154 = binary_op(MULTIPLY, _2146, _2153);
    }
    _2146 = NOVALUE;
    DeRef(_2153);
    _2153 = NOVALUE;
    if (IS_ATOM_INT(_2145) && IS_ATOM_INT(_2154)) {
        _2155 = _2145 + _2154;
        if ((object)((uintptr_t)_2155 + (uintptr_t)HIGH_BITS) >= 0){
            _2155 = NewDouble((eudouble)_2155);
        }
    }
    else {
        _2155 = binary_op(PLUS, _2145, _2154);
    }
    DeRef(_2145);
    _2145 = NOVALUE;
    DeRef(_2154);
    _2154 = NOVALUE;
    _2156 = (_year_4329 >= 1752);
    _2157 = 11 * _2156;
    _2156 = NOVALUE;
    if (IS_ATOM_INT(_2155)) {
        _2158 = _2155 - _2157;
        if ((object)((uintptr_t)_2158 +(uintptr_t) HIGH_BITS) >= 0){
            _2158 = NewDouble((eudouble)_2158);
        }
    }
    else {
        _2158 = binary_op(MINUS, _2155, _2157);
    }
    DeRef(_2155);
    _2155 = NOVALUE;
    _2157 = NOVALUE;
    if (IS_ATOM_INT(_2158)) {
        _j_4330 = _j_4330 + _2158;
    }
    else {
        _j_4330 = binary_op(PLUS, _j_4330, _2158);
    }
    DeRef(_2158);
    _2158 = NOVALUE;
    if (!IS_ATOM_INT(_j_4330)) {
        _1 = (object)(DBL_PTR(_j_4330)->dbl);
        DeRefDS(_j_4330);
        _j_4330 = _1;
    }

    /** datetime.e:169		if year >= 3200 then*/
    if (_year_4329 < 3200)
    goto L1; // [97] 133

    /** datetime.e:170			j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_4329 >= 0) {
        _2161 = _year_4329 / 3200;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_4329 / (eudouble)3200);
        _2161 = (object)temp_dbl;
    }
    _j_4330 = _j_4330 - _2161;
    _2161 = NOVALUE;

    /** datetime.e:171			if year >= 80000 then*/
    if (_year_4329 < 80000)
    goto L2; // [115] 132

    /** datetime.e:172				j += floor(year/80000)*/
    if (80000 > 0 && _year_4329 >= 0) {
        _2164 = _year_4329 / 80000;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_4329 / (eudouble)80000);
        _2164 = (object)temp_dbl;
    }
    _j_4330 = _j_4330 + _2164;
    _2164 = NOVALUE;
L2: 
L1: 

    /** datetime.e:176		return j*/
    DeRef(_ymd_4328);
    DeRef(_2147);
    _2147 = NOVALUE;
    return _j_4330;
    ;
}


object _16datetimeToSeconds(object _dt_4417)
{
    object _2207 = NOVALUE;
    object _2206 = NOVALUE;
    object _2205 = NOVALUE;
    object _2204 = NOVALUE;
    object _2203 = NOVALUE;
    object _2202 = NOVALUE;
    object _2201 = NOVALUE;
    object _2200 = NOVALUE;
    object _2199 = NOVALUE;
    object _2198 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:226		return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_4417);
    _2198 = _16julianDay(_dt_4417);
    if (IS_ATOM_INT(_2198)) {
        _2199 = NewDouble(_2198 * (eudouble)86400);
    }
    else {
        _2199 = binary_op(MULTIPLY, _2198, 86400);
    }
    DeRef(_2198);
    _2198 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_4417);
    _2200 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_2200)) {
        if (_2200 == (short)_2200){
            _2201 = _2200 * 60;
        }
        else{
            _2201 = NewDouble(_2200 * (eudouble)60);
        }
    }
    else {
        _2201 = binary_op(MULTIPLY, _2200, 60);
    }
    _2200 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_4417);
    _2202 = (object)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_2201) && IS_ATOM_INT(_2202)) {
        _2203 = _2201 + _2202;
        if ((object)((uintptr_t)_2203 + (uintptr_t)HIGH_BITS) >= 0){
            _2203 = NewDouble((eudouble)_2203);
        }
    }
    else {
        _2203 = binary_op(PLUS, _2201, _2202);
    }
    DeRef(_2201);
    _2201 = NOVALUE;
    _2202 = NOVALUE;
    if (IS_ATOM_INT(_2203)) {
        if (_2203 == (short)_2203){
            _2204 = _2203 * 60;
        }
        else{
            _2204 = NewDouble(_2203 * (eudouble)60);
        }
    }
    else {
        _2204 = binary_op(MULTIPLY, _2203, 60);
    }
    DeRef(_2203);
    _2203 = NOVALUE;
    if (IS_ATOM_INT(_2199) && IS_ATOM_INT(_2204)) {
        _2205 = _2199 + _2204;
        if ((object)((uintptr_t)_2205 + (uintptr_t)HIGH_BITS) >= 0){
            _2205 = NewDouble((eudouble)_2205);
        }
    }
    else {
        _2205 = binary_op(PLUS, _2199, _2204);
    }
    DeRef(_2199);
    _2199 = NOVALUE;
    DeRef(_2204);
    _2204 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_4417);
    _2206 = (object)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_2205) && IS_ATOM_INT(_2206)) {
        _2207 = _2205 + _2206;
        if ((object)((uintptr_t)_2207 + (uintptr_t)HIGH_BITS) >= 0){
            _2207 = NewDouble((eudouble)_2207);
        }
    }
    else {
        _2207 = binary_op(PLUS, _2205, _2206);
    }
    DeRef(_2205);
    _2205 = NOVALUE;
    _2206 = NOVALUE;
    DeRef(_dt_4417);
    return _2207;
    ;
}


object _16from_date(object _src_4583)
{
    object _2322 = NOVALUE;
    object _2321 = NOVALUE;
    object _2320 = NOVALUE;
    object _2319 = NOVALUE;
    object _2318 = NOVALUE;
    object _2317 = NOVALUE;
    object _2316 = NOVALUE;
    object _2314 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:513		return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (object)SEQ_PTR(_src_4583);
    _2314 = (object)*(((s1_ptr)_2)->base + 1);
    _2316 = _2314 + 1900;
    if ((object)((uintptr_t)_2316 + (uintptr_t)HIGH_BITS) >= 0){
        _2316 = NewDouble((eudouble)_2316);
    }
    _2314 = NOVALUE;
    _2 = (object)SEQ_PTR(_src_4583);
    _2317 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_src_4583);
    _2318 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_src_4583);
    _2319 = (object)*(((s1_ptr)_2)->base + 4);
    _2 = (object)SEQ_PTR(_src_4583);
    _2320 = (object)*(((s1_ptr)_2)->base + 5);
    _2 = (object)SEQ_PTR(_src_4583);
    _2321 = (object)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _2316;
    ((intptr_t*)_2)[2] = _2317;
    ((intptr_t*)_2)[3] = _2318;
    ((intptr_t*)_2)[4] = _2319;
    ((intptr_t*)_2)[5] = _2320;
    ((intptr_t*)_2)[6] = _2321;
    _2322 = MAKE_SEQ(_1);
    _2321 = NOVALUE;
    _2320 = NOVALUE;
    _2319 = NOVALUE;
    _2318 = NOVALUE;
    _2317 = NOVALUE;
    _2316 = NOVALUE;
    DeRefDSi(_src_4583);
    return _2322;
    ;
}


object _16new(object _year_4613, object _month_4614, object _day_4615, object _hour_4616, object _minute_4617, object _second_4618)
{
    object _d_4619 = NOVALUE;
    object _now_1__tmp_at41_4626 = NOVALUE;
    object _now_inlined_now_at_41_4625 = NOVALUE;
    object _2338 = NOVALUE;
    object _2337 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_4613)) {
        _1 = (object)(DBL_PTR(_year_4613)->dbl);
        DeRefDS(_year_4613);
        _year_4613 = _1;
    }
    if (!IS_ATOM_INT(_month_4614)) {
        _1 = (object)(DBL_PTR(_month_4614)->dbl);
        DeRefDS(_month_4614);
        _month_4614 = _1;
    }
    if (!IS_ATOM_INT(_day_4615)) {
        _1 = (object)(DBL_PTR(_day_4615)->dbl);
        DeRefDS(_day_4615);
        _day_4615 = _1;
    }
    if (!IS_ATOM_INT(_hour_4616)) {
        _1 = (object)(DBL_PTR(_hour_4616)->dbl);
        DeRefDS(_hour_4616);
        _hour_4616 = _1;
    }
    if (!IS_ATOM_INT(_minute_4617)) {
        _1 = (object)(DBL_PTR(_minute_4617)->dbl);
        DeRefDS(_minute_4617);
        _minute_4617 = _1;
    }

    /** datetime.e:587		d = {year, month, day, hour, minute, second}*/
    _0 = _d_4619;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _year_4613;
    ((intptr_t*)_2)[2] = _month_4614;
    ((intptr_t*)_2)[3] = _day_4615;
    ((intptr_t*)_2)[4] = _hour_4616;
    ((intptr_t*)_2)[5] = _minute_4617;
    Ref(_second_4618);
    ((intptr_t*)_2)[6] = _second_4618;
    _d_4619 = MAKE_SEQ(_1);
    DeRef(_0);

    /** datetime.e:588		if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    _2337 = MAKE_SEQ(_1);
    if (_d_4619 == _2337)
    _2338 = 1;
    else if (IS_ATOM_INT(_d_4619) && IS_ATOM_INT(_2337))
    _2338 = 0;
    else
    _2338 = (compare(_d_4619, _2337) == 0);
    DeRefDS(_2337);
    _2337 = NOVALUE;
    if (_2338 == 0)
    {
        _2338 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _2338 = NOVALUE;
    }

    /** datetime.e:589			return now()*/

    /** datetime.e:533		return from_date(date())*/
    DeRefi(_now_1__tmp_at41_4626);
    _now_1__tmp_at41_4626 = Date();
    RefDS(_now_1__tmp_at41_4626);
    _0 = _now_inlined_now_at_41_4625;
    _now_inlined_now_at_41_4625 = _16from_date(_now_1__tmp_at41_4626);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_4626);
    _now_1__tmp_at41_4626 = NOVALUE;
    DeRef(_second_4618);
    DeRef(_d_4619);
    return _now_inlined_now_at_41_4625;
    goto L2; // [57] 67
L1: 

    /** datetime.e:591			return d*/
    DeRef(_second_4618);
    return _d_4619;
L2: 
    ;
}



// 0xEB4DCA2B
