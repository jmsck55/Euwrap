// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _34map(object _m_15074)
{
    object _8635 = NOVALUE;
    object _8634 = NOVALUE;
    object _8633 = NOVALUE;
    object _8631 = NOVALUE;
    object _8630 = NOVALUE;
    object _8629 = NOVALUE;
    object _8627 = NOVALUE;
    object _8626 = NOVALUE;
    object _8625 = NOVALUE;
    object _8623 = NOVALUE;
    object _8622 = NOVALUE;
    object _8619 = NOVALUE;
    object _8617 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:126		if not atom( m ) then*/
    _8617 = IS_ATOM(_m_15074);
    if (_8617 != 0)
    goto L1; // [6] 16
    _8617 = NOVALUE;

    /** map.e:127			return 0*/
    DeRef(_m_15074);
    return 0;
L1: 

    /** map.e:129		if length( eumem:ram_space ) < m then*/
    if (IS_SEQUENCE(_35ram_space_13045)){
            _8619 = SEQ_PTR(_35ram_space_13045)->length;
    }
    else {
        _8619 = 1;
    }
    if (binary_op_a(GREATEREQ, _8619, _m_15074)){
        _8619 = NOVALUE;
        goto L2; // [23] 34
    }
    _8619 = NOVALUE;

    /** map.e:130			return 0*/
    DeRef(_m_15074);
    return 0;
L2: 

    /** map.e:132		if m < 1 then*/
    if (binary_op_a(GREATEREQ, _m_15074, 1)){
        goto L3; // [36] 47
    }

    /** map.e:133			return 0*/
    DeRef(_m_15074);
    return 0;
L3: 

    /** map.e:135		if length( eumem:ram_space[m] ) != MAP_MAX then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15074)){
        _8622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15074)->dbl));
    }
    else{
        _8622 = (object)*(((s1_ptr)_2)->base + _m_15074);
    }
    if (IS_SEQUENCE(_8622)){
            _8623 = SEQ_PTR(_8622)->length;
    }
    else {
        _8623 = 1;
    }
    _8622 = NOVALUE;
    if (_8623 == 3)
    goto L4; // [58] 69

    /** map.e:136			return 0*/
    DeRef(_m_15074);
    _8622 = NOVALUE;
    return 0;
L4: 

    /** map.e:138		if not atom( eumem:ram_space[m][MAP_SIZE] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15074)){
        _8625 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15074)->dbl));
    }
    else{
        _8625 = (object)*(((s1_ptr)_2)->base + _m_15074);
    }
    _2 = (object)SEQ_PTR(_8625);
    _8626 = (object)*(((s1_ptr)_2)->base + 1);
    _8625 = NOVALUE;
    _8627 = IS_ATOM(_8626);
    _8626 = NOVALUE;
    if (_8627 != 0)
    goto L5; // [84] 94
    _8627 = NOVALUE;

    /** map.e:139			return 0*/
    DeRef(_m_15074);
    _8622 = NOVALUE;
    return 0;
L5: 

    /** map.e:141		if not sequence( eumem:ram_space[m][MAP_SLOTS] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15074)){
        _8629 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15074)->dbl));
    }
    else{
        _8629 = (object)*(((s1_ptr)_2)->base + _m_15074);
    }
    _2 = (object)SEQ_PTR(_8629);
    _8630 = (object)*(((s1_ptr)_2)->base + 2);
    _8629 = NOVALUE;
    _8631 = IS_SEQUENCE(_8630);
    _8630 = NOVALUE;
    if (_8631 != 0)
    goto L6; // [109] 119
    _8631 = NOVALUE;

    /** map.e:142			return 0*/
    DeRef(_m_15074);
    _8622 = NOVALUE;
    return 0;
L6: 

    /** map.e:144		if not atom( eumem:ram_space[m][MAP_MAX] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15074)){
        _8633 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15074)->dbl));
    }
    else{
        _8633 = (object)*(((s1_ptr)_2)->base + _m_15074);
    }
    _2 = (object)SEQ_PTR(_8633);
    _8634 = (object)*(((s1_ptr)_2)->base + 3);
    _8633 = NOVALUE;
    _8635 = IS_ATOM(_8634);
    _8634 = NOVALUE;
    if (_8635 != 0)
    goto L7; // [134] 144
    _8635 = NOVALUE;

    /** map.e:145			return 0*/
    DeRef(_m_15074);
    _8622 = NOVALUE;
    return 0;
L7: 

    /** map.e:147		return 1*/
    DeRef(_m_15074);
    _8622 = NOVALUE;
    return 1;
    ;
}


object _34new_map_seq(object _size_15105)
{
    object _slots_15106 = NOVALUE;
    object _8647 = NOVALUE;
    object _8646 = NOVALUE;
    object _8645 = NOVALUE;
    object _8644 = NOVALUE;
    object _8640 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:155		integer slots = DEFAULT_SIZE * 2*/
    _slots_15106 = 16;

    /** map.e:156		if size <= DEFAULT_SIZE then*/
    if (_size_15105 > 8)
    goto L1; // [11] 23

    /** map.e:157			size = DEFAULT_SIZE*/
    _size_15105 = 8;
    goto L2; // [20] 55
L1: 

    /** map.e:159			size = floor( size * 1.5 )*/
    _8640 = NewDouble((eudouble)_size_15105 * DBL_PTR(_8639)->dbl);
    _size_15105 = unary_op(FLOOR, _8640);
    DeRefDS(_8640);
    _8640 = NOVALUE;
    if (!IS_ATOM_INT(_size_15105)) {
        _1 = (object)(DBL_PTR(_size_15105)->dbl);
        DeRefDS(_size_15105);
        _size_15105 = _1;
    }

    /** map.e:160			while slots < size do*/
L3: 
    if (_slots_15106 >= _size_15105)
    goto L4; // [39] 54

    /** map.e:162				slots *= 2*/
    _slots_15106 = _slots_15106 + _slots_15106;

    /** map.e:163			end while*/
    goto L3; // [51] 39
L4: 
L2: 

    /** map.e:165		return { 0, repeat( EMPTY_SLOT, slots ), floor( size * 2/3 ) }*/
    _8644 = Repeat(_34EMPTY_SLOT_15062, _slots_15106);
    _8645 = _size_15105 + _size_15105;
    if ((object)((uintptr_t)_8645 + (uintptr_t)HIGH_BITS) >= 0){
        _8645 = NewDouble((eudouble)_8645);
    }
    if (IS_ATOM_INT(_8645)) {
        if (3 > 0 && _8645 >= 0) {
            _8646 = _8645 / 3;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_8645 / (eudouble)3);
            if (_8645 != MININT)
            _8646 = (object)temp_dbl;
            else
            _8646 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _8645, 3);
        _8646 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_8645);
    _8645 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0;
    ((intptr_t*)_2)[2] = _8644;
    ((intptr_t*)_2)[3] = _8646;
    _8647 = MAKE_SEQ(_1);
    _8646 = NOVALUE;
    _8644 = NOVALUE;
    return _8647;
    ;
}


object _34lookup(object _key_15149, object _hashval_15150, object _slots_15152)
{
    object _mask_15153 = NOVALUE;
    object _index_15156 = NOVALUE;
    object _index_hash_15159 = NOVALUE;
    object _slot_15160 = NOVALUE;
    object _perturb_15161 = NOVALUE;
    object _this_hash_15162 = NOVALUE;
    object _this_key_15163 = NOVALUE;
    object _looks_15164 = NOVALUE;
    object _removed_slot_15165 = NOVALUE;
    object _8676 = NOVALUE;
    object _8663 = NOVALUE;
    object _8662 = NOVALUE;
    object _8661 = NOVALUE;
    object _8660 = NOVALUE;
    object _8658 = NOVALUE;
    object _8656 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:275		integer mask = length( slots ) - 1*/
    if (IS_SEQUENCE(_slots_15152)){
            _8656 = SEQ_PTR(_slots_15152)->length;
    }
    else {
        _8656 = 1;
    }
    _mask_15153 = _8656 - 1;
    _8656 = NOVALUE;

    /** map.e:276		integer index = and_bits( hashval, mask ) + 1*/
    {uintptr_t tu;
         tu = (uintptr_t)_hashval_15150 & (uintptr_t)_mask_15153;
         _8658 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_8658)) {
        _index_15156 = _8658 + 1;
    }
    else
    { // coercing _index_15156 to an integer 1
        _index_15156 = 1+(object)(DBL_PTR(_8658)->dbl);
        if( !IS_ATOM_INT(_index_15156) ){
            _index_15156 = (object)DBL_PTR(_index_15156)->dbl;
        }
    }
    DeRef(_8658);
    _8658 = NOVALUE;

    /** map.e:277		ifdef BITS64 then*/

    /** map.e:280			atom index_hash = index*/
    DeRef(_index_hash_15159);
    _index_hash_15159 = _index_15156;

    /** map.e:282		sequence slot*/

    /** map.e:284		integer perturb = hashval*/
    _perturb_15161 = _hashval_15150;

    /** map.e:285		integer this_hash*/

    /** map.e:286		object this_key*/

    /** map.e:287		integer looks = 0*/
    _looks_15164 = 0;

    /** map.e:288		integer removed_slot = 0*/
    _removed_slot_15165 = 0;

    /** map.e:289		while this_hash != hashval or not equal( this_key, key ) with entry do*/
    goto L1; // [54] 140
L2: 
    _8660 = (_this_hash_15162 != _hashval_15150);
    if (_8660 != 0) {
        DeRef(_8661);
        _8661 = 1;
        goto L3; // [63] 80
    }
    if (_this_key_15163 == _key_15149)
    _8662 = 1;
    else if (IS_ATOM_INT(_this_key_15163) && IS_ATOM_INT(_key_15149))
    _8662 = 0;
    else
    _8662 = (compare(_this_key_15163, _key_15149) == 0);
    _8663 = (_8662 == 0);
    _8662 = NOVALUE;
    _8661 = (_8663 != 0);
L3: 
    if (_8661 == 0)
    {
        _8661 = NOVALUE;
        goto L4; // [80] 217
    }
    else{
        _8661 = NOVALUE;
    }

    /** map.e:290			index_hash *= 4*/
    _0 = _index_hash_15159;
    if (IS_ATOM_INT(_index_hash_15159)) {
        if (_index_hash_15159 == (short)_index_hash_15159){
            _index_hash_15159 = _index_hash_15159 * 4;
        }
        else{
            _index_hash_15159 = NewDouble(_index_hash_15159 * (eudouble)4);
        }
    }
    else {
        _index_hash_15159 = NewDouble(DBL_PTR(_index_hash_15159)->dbl * (eudouble)4);
    }
    DeRef(_0);

    /** map.e:291			index_hash += index*/
    _0 = _index_hash_15159;
    if (IS_ATOM_INT(_index_hash_15159)) {
        _index_hash_15159 = _index_hash_15159 + _index_15156;
        if ((object)((uintptr_t)_index_hash_15159 + (uintptr_t)HIGH_BITS) >= 0){
            _index_hash_15159 = NewDouble((eudouble)_index_hash_15159);
        }
    }
    else {
        _index_hash_15159 = NewDouble(DBL_PTR(_index_hash_15159)->dbl + (eudouble)_index_15156);
    }
    DeRef(_0);

    /** map.e:292			index_hash += perturb*/
    _0 = _index_hash_15159;
    if (IS_ATOM_INT(_index_hash_15159)) {
        _index_hash_15159 = _index_hash_15159 + _perturb_15161;
        if ((object)((uintptr_t)_index_hash_15159 + (uintptr_t)HIGH_BITS) >= 0){
            _index_hash_15159 = NewDouble((eudouble)_index_hash_15159);
        }
    }
    else {
        _index_hash_15159 = NewDouble(DBL_PTR(_index_hash_15159)->dbl + (eudouble)_perturb_15161);
    }
    DeRef(_0);

    /** map.e:293			index_hash += 1*/
    _0 = _index_hash_15159;
    if (IS_ATOM_INT(_index_hash_15159)) {
        _index_hash_15159 = _index_hash_15159 + 1;
        if (_index_hash_15159 > MAXINT){
            _index_hash_15159 = NewDouble((eudouble)_index_hash_15159);
        }
    }
    else
    _index_hash_15159 = binary_op(PLUS, 1, _index_hash_15159);
    DeRef(_0);

    /** map.e:294			index_hash = and_bits( 0xffff_ffff, index_hash )*/
    _0 = _index_hash_15159;
    if (IS_ATOM_INT(_index_hash_15159)) {
        temp_d.dbl = (eudouble)_index_hash_15159;
        _index_hash_15159 = Dand_bits(DBL_PTR(_8668), &temp_d);
    }
    else
    _index_hash_15159 = Dand_bits(DBL_PTR(_8668), DBL_PTR(_index_hash_15159));
    DeRef(_0);

    /** map.e:295			index = and_bits( mask, index_hash )*/
    if (IS_ATOM_INT(_index_hash_15159)) {
        {uintptr_t tu;
             tu = (uintptr_t)_mask_15153 & (uintptr_t)_index_hash_15159;
             _index_15156 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_mask_15153;
        _index_15156 = Dand_bits(&temp_d, DBL_PTR(_index_hash_15159));
    }
    if (!IS_ATOM_INT(_index_15156)) {
        _1 = (object)(DBL_PTR(_index_15156)->dbl);
        DeRefDS(_index_15156);
        _index_15156 = _1;
    }

    /** map.e:296			index += 1*/
    _index_15156 = _index_15156 + 1;

    /** map.e:297			perturb = floor( perturb / 32 )*/
    if (32 > 0 && _perturb_15161 >= 0) {
        _perturb_15161 = _perturb_15161 / 32;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_perturb_15161 / (eudouble)32);
        _perturb_15161 = (object)temp_dbl;
    }

    /** map.e:298		entry*/
L1: 

    /** map.e:299			slot = slots[index]*/
    DeRef(_slot_15160);
    _2 = (object)SEQ_PTR(_slots_15152);
    _slot_15160 = (object)*(((s1_ptr)_2)->base + _index_15156);
    Ref(_slot_15160);

    /** map.e:300			this_hash = slot[SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slot_15160);
    _this_hash_15162 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_this_hash_15162))
    _this_hash_15162 = (object)DBL_PTR(_this_hash_15162)->dbl;

    /** map.e:301			if this_hash = EMPTY then*/
    if (_this_hash_15162 != -2)
    goto L5; // [156] 169

    /** map.e:302				return index*/
    DeRef(_key_15149);
    DeRefDS(_slots_15152);
    DeRef(_index_hash_15159);
    DeRefDS(_slot_15160);
    DeRef(_this_key_15163);
    DeRef(_8660);
    _8660 = NOVALUE;
    DeRef(_8663);
    _8663 = NOVALUE;
    return _index_15156;
    goto L6; // [166] 200
L5: 

    /** map.e:303			elsif looks > length( slots ) then*/
    if (IS_SEQUENCE(_slots_15152)){
            _8676 = SEQ_PTR(_slots_15152)->length;
    }
    else {
        _8676 = 1;
    }
    if (_looks_15164 <= _8676)
    goto L7; // [174] 187

    /** map.e:304				return removed_slot*/
    DeRef(_key_15149);
    DeRefDS(_slots_15152);
    DeRef(_index_hash_15159);
    DeRef(_slot_15160);
    DeRef(_this_key_15163);
    DeRef(_8660);
    _8660 = NOVALUE;
    DeRef(_8663);
    _8663 = NOVALUE;
    return _removed_slot_15165;
    goto L6; // [184] 200
L7: 

    /** map.e:305			elsif this_hash = REMOVED then*/
    if (_this_hash_15162 != -1)
    goto L8; // [189] 199

    /** map.e:306				removed_slot = index*/
    _removed_slot_15165 = _index_15156;
L8: 
L6: 

    /** map.e:308			this_key = slot[SLOT_KEY]*/
    DeRef(_this_key_15163);
    _2 = (object)SEQ_PTR(_slot_15160);
    _this_key_15163 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_this_key_15163);

    /** map.e:309			looks += 1*/
    _looks_15164 = _looks_15164 + 1;

    /** map.e:310		end while*/
    goto L2; // [214] 57
L4: 

    /** map.e:311		return index*/
    DeRef(_key_15149);
    DeRefDS(_slots_15152);
    DeRef(_index_hash_15159);
    DeRef(_slot_15160);
    DeRef(_this_key_15163);
    DeRef(_8660);
    _8660 = NOVALUE;
    DeRef(_8663);
    _8663 = NOVALUE;
    return _index_15156;
    ;
}


object _34rehash_seq(object _old_map_15193, object _size_15194)
{
    object _old_size_15195 = NOVALUE;
    object _index_15197 = NOVALUE;
    object _new_map_15210 = NOVALUE;
    object _slots_15212 = NOVALUE;
    object _old_slots_15215 = NOVALUE;
    object _old_slot_15220 = NOVALUE;
    object _old_hash_15222 = NOVALUE;
    object _8697 = NOVALUE;
    object _8693 = NOVALUE;
    object _8691 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:316		integer old_size = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_15193);
    _old_size_15195 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_size_15195))
    _old_size_15195 = (object)DBL_PTR(_old_size_15195)->dbl;

    /** map.e:319		if size = 0 then*/

    /** map.e:320			if old_size > 50_000 then*/
    if (_old_size_15195 <= 50000)
    goto L1; // [19] 32

    /** map.e:321				size = old_size * 2*/
    _size_15194 = _old_size_15195 + _old_size_15195;
    goto L2; // [29] 69
L1: 

    /** map.e:323				size = old_size * 4*/
    _size_15194 = _old_size_15195 * 4;
    goto L2; // [41] 69

    /** map.e:325		elsif size < old_size then*/
    if (_size_15194 >= _old_size_15195)
    goto L3; // [46] 68

    /** map.e:326			size = old_size*/
    _size_15194 = _old_size_15195;

    /** map.e:327			if size < DEFAULT_SIZE then*/
    if (_size_15194 >= 8)
    goto L4; // [57] 67

    /** map.e:328				size = DEFAULT_SIZE*/
    _size_15194 = 8;
L4: 
L3: 
L2: 

    /** map.e:332		sequence new_map = new_map_seq( size )*/
    _0 = _new_map_15210;
    _new_map_15210 = _34new_map_seq(_size_15194);
    DeRef(_0);

    /** map.e:333		sequence slots = new_map[MAP_SLOTS]*/
    DeRef(_slots_15212);
    _2 = (object)SEQ_PTR(_new_map_15210);
    _slots_15212 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15212);

    /** map.e:334		new_map[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_new_map_15210);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_15210 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:335		new_map[MAP_SIZE] = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_15193);
    _8691 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_8691);
    _2 = (object)SEQ_PTR(_new_map_15210);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_15210 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8691;
    if( _1 != _8691 ){
        DeRef(_1);
    }
    _8691 = NOVALUE;

    /** map.e:337		sequence old_slots = old_map[MAP_SLOTS]*/
    DeRef(_old_slots_15215);
    _2 = (object)SEQ_PTR(_old_map_15193);
    _old_slots_15215 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_old_slots_15215);

    /** map.e:338		for i = 1 to length( old_slots ) do*/
    if (IS_SEQUENCE(_old_slots_15215)){
            _8693 = SEQ_PTR(_old_slots_15215)->length;
    }
    else {
        _8693 = 1;
    }
    {
        object _i_15218;
        _i_15218 = 1;
L5: 
        if (_i_15218 > _8693){
            goto L6; // [114] 171
        }

        /** map.e:339			sequence old_slot = old_slots[i]*/
        DeRef(_old_slot_15220);
        _2 = (object)SEQ_PTR(_old_slots_15215);
        _old_slot_15220 = (object)*(((s1_ptr)_2)->base + _i_15218);
        Ref(_old_slot_15220);

        /** map.e:340			integer old_hash = old_slot[SLOT_HASH]*/
        _2 = (object)SEQ_PTR(_old_slot_15220);
        _old_hash_15222 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_old_hash_15222))
        _old_hash_15222 = (object)DBL_PTR(_old_hash_15222)->dbl;

        /** map.e:341			if old_hash != -1 then*/
        if (_old_hash_15222 == -1)
        goto L7; // [137] 162

        /** map.e:342				index = lookup( old_slot[SLOT_KEY], old_hash, slots )*/
        _2 = (object)SEQ_PTR(_old_slot_15220);
        _8697 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_8697);
        RefDS(_slots_15212);
        _index_15197 = _34lookup(_8697, _old_hash_15222, _slots_15212);
        _8697 = NOVALUE;
        if (!IS_ATOM_INT(_index_15197)) {
            _1 = (object)(DBL_PTR(_index_15197)->dbl);
            DeRefDS(_index_15197);
            _index_15197 = _1;
        }

        /** map.e:343				slots[index] = old_slot*/
        RefDS(_old_slot_15220);
        _2 = (object)SEQ_PTR(_slots_15212);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15212 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15197);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _old_slot_15220;
        DeRef(_1);
L7: 
        DeRef(_old_slot_15220);
        _old_slot_15220 = NOVALUE;

        /** map.e:345		end for*/
        _i_15218 = _i_15218 + 1;
        goto L5; // [166] 121
L6: 
        ;
    }

    /** map.e:346		new_map[MAP_SLOTS] = slots*/
    RefDS(_slots_15212);
    _2 = (object)SEQ_PTR(_new_map_15210);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_15210 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_15212;
    DeRef(_1);

    /** map.e:347		return new_map*/
    DeRefDS(_old_map_15193);
    DeRefDS(_slots_15212);
    DeRef(_old_slots_15215);
    return _new_map_15210;
    ;
}


object _34new_extra(object _the_map_p_15230, object _initial_size_p_15231)
{
    object _new_1__tmp_at22_15237 = NOVALUE;
    object _new_inlined_new_at_22_15236 = NOVALUE;
    object _8699 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:376		if map(the_map_p) then*/
    Ref(_the_map_p_15230);
    _8699 = _34map(_the_map_p_15230);
    if (_8699 == 0) {
        DeRef(_8699);
        _8699 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_8699) && DBL_PTR(_8699)->dbl == 0.0){
            DeRef(_8699);
            _8699 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_8699);
        _8699 = NOVALUE;
    }
    DeRef(_8699);
    _8699 = NOVALUE;

    /** map.e:377			return the_map_p*/
    return _the_map_p_15230;
    goto L2; // [18] 42
L1: 

    /** map.e:379			return new(initial_size_p)*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at22_15237;
    _new_1__tmp_at22_15237 = _34new_map_seq(_initial_size_p_15231);
    DeRef(_0);
    Ref(_new_1__tmp_at22_15237);
    _0 = _new_inlined_new_at_22_15236;
    _new_inlined_new_at_22_15236 = _35malloc(_new_1__tmp_at22_15237, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at22_15237);
    _new_1__tmp_at22_15237 = NOVALUE;
    DeRef(_the_map_p_15230);
    return _new_inlined_new_at_22_15236;
L2: 
    ;
}


object _34has(object _the_map_p_15271, object _key_15272)
{
    object _hashval_15273 = NOVALUE;
    object _hash_inlined_hash_at_2_15275 = NOVALUE;
    object _slots_15276 = NOVALUE;
    object _index_15279 = NOVALUE;
    object _8718 = NOVALUE;
    object _8717 = NOVALUE;
    object _8716 = NOVALUE;
    object _8713 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:464		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15273 = calc_hash(_key_15272, -6);

    /** map.e:465		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15271)){
        _8713 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15271)->dbl));
    }
    else{
        _8713 = (object)*(((s1_ptr)_2)->base + _the_map_p_15271);
    }
    DeRef(_slots_15276);
    _2 = (object)SEQ_PTR(_8713);
    _slots_15276 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15276);
    _8713 = NOVALUE;

    /** map.e:466		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15272);
    RefDS(_slots_15276);
    _index_15279 = _34lookup(_key_15272, _hashval_15273, _slots_15276);
    if (!IS_ATOM_INT(_index_15279)) {
        _1 = (object)(DBL_PTR(_index_15279)->dbl);
        DeRefDS(_index_15279);
        _index_15279 = _1;
    }

    /** map.e:468		return hashval = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15276);
    _8716 = (object)*(((s1_ptr)_2)->base + _index_15279);
    _2 = (object)SEQ_PTR(_8716);
    _8717 = (object)*(((s1_ptr)_2)->base + 1);
    _8716 = NOVALUE;
    if (IS_ATOM_INT(_8717)) {
        _8718 = (_hashval_15273 == _8717);
    }
    else {
        _8718 = binary_op(EQUALS, _hashval_15273, _8717);
    }
    _8717 = NOVALUE;
    DeRef(_the_map_p_15271);
    DeRef(_key_15272);
    DeRefDS(_slots_15276);
    return _8718;
    ;
}


object _34get(object _the_map_p_15286, object _key_15287, object _default_15288)
{
    object _hashval_15289 = NOVALUE;
    object _hash_inlined_hash_at_2_15291 = NOVALUE;
    object _slots_15292 = NOVALUE;
    object _index_15295 = NOVALUE;
    object _slot_15297 = NOVALUE;
    object _8725 = NOVALUE;
    object _8723 = NOVALUE;
    object _8719 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:505		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15289 = calc_hash(_key_15287, -6);

    /** map.e:506		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15286)){
        _8719 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15286)->dbl));
    }
    else{
        _8719 = (object)*(((s1_ptr)_2)->base + _the_map_p_15286);
    }
    DeRef(_slots_15292);
    _2 = (object)SEQ_PTR(_8719);
    _slots_15292 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15292);
    _8719 = NOVALUE;

    /** map.e:507		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15287);
    RefDS(_slots_15292);
    _index_15295 = _34lookup(_key_15287, _hashval_15289, _slots_15292);
    if (!IS_ATOM_INT(_index_15295)) {
        _1 = (object)(DBL_PTR(_index_15295)->dbl);
        DeRefDS(_index_15295);
        _index_15295 = _1;
    }

    /** map.e:508		sequence slot = slots[index]*/
    DeRef(_slot_15297);
    _2 = (object)SEQ_PTR(_slots_15292);
    _slot_15297 = (object)*(((s1_ptr)_2)->base + _index_15295);
    Ref(_slot_15297);

    /** map.e:509		if hashval = slot[SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slot_15297);
    _8723 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _hashval_15289, _8723)){
        _8723 = NOVALUE;
        goto L1; // [50] 65
    }
    _8723 = NOVALUE;

    /** map.e:510			return slot[SLOT_VALUE]*/
    _2 = (object)SEQ_PTR(_slot_15297);
    _8725 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_8725);
    DeRef(_the_map_p_15286);
    DeRef(_key_15287);
    DeRef(_default_15288);
    DeRefDS(_slots_15292);
    DeRefDS(_slot_15297);
    return _8725;
L1: 

    /** map.e:512		return default*/
    DeRef(_the_map_p_15286);
    DeRef(_key_15287);
    DeRef(_slots_15292);
    DeRef(_slot_15297);
    _8725 = NOVALUE;
    return _default_15288;
    ;
}


void _34put(object _the_map_p_15325, object _key_15326, object _val_15327, object _op_15328, object _deprecated_15329)
{
    object _hashval_15330 = NOVALUE;
    object _hash_inlined_hash_at_2_15332 = NOVALUE;
    object _the_map_seq_15333 = NOVALUE;
    object _slots_15335 = NOVALUE;
    object _index_15337 = NOVALUE;
    object _old_hash_15339 = NOVALUE;
    object _msg_inlined_crash_at_288_15382 = NOVALUE;
    object _msg_inlined_crash_at_348_15392 = NOVALUE;
    object _msg_inlined_crash_at_535_15424 = NOVALUE;
    object _8792 = NOVALUE;
    object _8790 = NOVALUE;
    object _8789 = NOVALUE;
    object _8788 = NOVALUE;
    object _8787 = NOVALUE;
    object _8786 = NOVALUE;
    object _8784 = NOVALUE;
    object _8783 = NOVALUE;
    object _8782 = NOVALUE;
    object _8781 = NOVALUE;
    object _8780 = NOVALUE;
    object _8779 = NOVALUE;
    object _8777 = NOVALUE;
    object _8776 = NOVALUE;
    object _8775 = NOVALUE;
    object _8774 = NOVALUE;
    object _8772 = NOVALUE;
    object _8771 = NOVALUE;
    object _8770 = NOVALUE;
    object _8769 = NOVALUE;
    object _8766 = NOVALUE;
    object _8765 = NOVALUE;
    object _8764 = NOVALUE;
    object _8763 = NOVALUE;
    object _8762 = NOVALUE;
    object _8760 = NOVALUE;
    object _8759 = NOVALUE;
    object _8758 = NOVALUE;
    object _8757 = NOVALUE;
    object _8756 = NOVALUE;
    object _8754 = NOVALUE;
    object _8751 = NOVALUE;
    object _8750 = NOVALUE;
    object _8748 = NOVALUE;
    object _8743 = NOVALUE;
    object _8742 = NOVALUE;
    object _8739 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:579		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15330 = calc_hash(_key_15326, -6);

    /** map.e:580		sequence the_map_seq = eumem:ram_space[the_map_p]*/
    DeRef(_the_map_seq_15333);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15325)){
        _the_map_seq_15333 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15325)->dbl));
    }
    else{
        _the_map_seq_15333 = (object)*(((s1_ptr)_2)->base + _the_map_p_15325);
    }
    Ref(_the_map_seq_15333);

    /** map.e:581		eumem:ram_space[the_map_p] = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15325))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15325)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15325);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:582		sequence slots = the_map_seq[MAP_SLOTS]*/
    DeRef(_slots_15335);
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    _slots_15335 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15335);

    /** map.e:584		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15326);
    RefDS(_slots_15335);
    _index_15337 = _34lookup(_key_15326, _hashval_15330, _slots_15335);
    if (!IS_ATOM_INT(_index_15337)) {
        _1 = (object)(DBL_PTR(_index_15337)->dbl);
        DeRefDS(_index_15337);
        _index_15337 = _1;
    }

    /** map.e:585		integer old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15335);
    _8739 = (object)*(((s1_ptr)_2)->base + _index_15337);
    _2 = (object)SEQ_PTR(_8739);
    _old_hash_15339 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_hash_15339)){
        _old_hash_15339 = (object)DBL_PTR(_old_hash_15339)->dbl;
    }
    _8739 = NOVALUE;

    /** map.e:587		if old_hash < 0 then*/
    if (_old_hash_15339 >= 0)
    goto L1; // [62] 142

    /** map.e:589			if the_map_seq[MAP_SIZE] > the_map_seq[MAP_MAX] then*/
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    _8742 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    _8743 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(LESSEQ, _8742, _8743)){
        _8742 = NOVALUE;
        _8743 = NOVALUE;
        goto L2; // [76] 127
    }
    _8742 = NOVALUE;
    _8743 = NOVALUE;

    /** map.e:590				slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15335);
    _slots_15335 = _5;

    /** map.e:591				the_map_seq = rehash_seq( the_map_seq )*/
    RefDS(_the_map_seq_15333);
    _0 = _the_map_seq_15333;
    _the_map_seq_15333 = _34rehash_seq(_the_map_seq_15333, 0);
    DeRefDS(_0);

    /** map.e:592				slots = the_map_seq[MAP_SLOTS]*/
    DeRefDS(_slots_15335);
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    _slots_15335 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15335);

    /** map.e:593				index = lookup( key, hashval, slots )*/
    Ref(_key_15326);
    RefDS(_slots_15335);
    _index_15337 = _34lookup(_key_15326, _hashval_15330, _slots_15335);
    if (!IS_ATOM_INT(_index_15337)) {
        _1 = (object)(DBL_PTR(_index_15337)->dbl);
        DeRefDS(_index_15337);
        _index_15337 = _1;
    }

    /** map.e:594				old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15335);
    _8748 = (object)*(((s1_ptr)_2)->base + _index_15337);
    _2 = (object)SEQ_PTR(_8748);
    _old_hash_15339 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_old_hash_15339)){
        _old_hash_15339 = (object)DBL_PTR(_old_hash_15339)->dbl;
    }
    _8748 = NOVALUE;
L2: 

    /** map.e:596			the_map_seq[MAP_SIZE] += 1*/
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    _8750 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8750)) {
        _8751 = _8750 + 1;
        if (_8751 > MAXINT){
            _8751 = NewDouble((eudouble)_8751);
        }
    }
    else
    _8751 = binary_op(PLUS, 1, _8750);
    _8750 = NOVALUE;
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15333 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8751;
    if( _1 != _8751 ){
        DeRef(_1);
    }
    _8751 = NOVALUE;
L1: 

    /** map.e:599		the_map_seq[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15333 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);

    /** map.e:601		switch op do*/
    _0 = _op_15328;
    switch ( _0 ){ 

        /** map.e:602			case PUT then*/
        case 1:

        /** map.e:603				slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        Ref(_val_15327);
        ((intptr_t*)_2)[3] = _val_15327;
        _8754 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8754;
        if( _1 != _8754 ){
            DeRef(_1);
        }
        _8754 = NOVALUE;
        goto L3; // [171] 555

        /** map.e:604			case ADD then*/
        case 2:

        /** map.e:605				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto L4; // [179] 198

        /** map.e:606					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        Ref(_val_15327);
        ((intptr_t*)_2)[3] = _val_15327;
        _8756 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8756;
        if( _1 != _8756 ){
            DeRef(_1);
        }
        _8756 = NOVALUE;
        goto L3; // [195] 555
L4: 

        /** map.e:608					slots[index] = { hashval, key, val + slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15335);
        _8757 = (object)*(((s1_ptr)_2)->base + _index_15337);
        _2 = (object)SEQ_PTR(_8757);
        _8758 = (object)*(((s1_ptr)_2)->base + 3);
        _8757 = NOVALUE;
        if (IS_ATOM_INT(_val_15327) && IS_ATOM_INT(_8758)) {
            _8759 = _val_15327 + _8758;
            if ((object)((uintptr_t)_8759 + (uintptr_t)HIGH_BITS) >= 0){
                _8759 = NewDouble((eudouble)_8759);
            }
        }
        else {
            _8759 = binary_op(PLUS, _val_15327, _8758);
        }
        _8758 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8759;
        _8760 = MAKE_SEQ(_1);
        _8759 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8760;
        if( _1 != _8760 ){
            DeRef(_1);
        }
        _8760 = NOVALUE;
        goto L3; // [223] 555

        /** map.e:610			case SUBTRACT then*/
        case 3:

        /** map.e:611				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto L5; // [231] 250

        /** map.e:612					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        Ref(_val_15327);
        ((intptr_t*)_2)[3] = _val_15327;
        _8762 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8762;
        if( _1 != _8762 ){
            DeRef(_1);
        }
        _8762 = NOVALUE;
        goto L3; // [247] 555
L5: 

        /** map.e:614					slots[index] = { hashval, key, slots[index][SLOT_VALUE] - val }*/
        _2 = (object)SEQ_PTR(_slots_15335);
        _8763 = (object)*(((s1_ptr)_2)->base + _index_15337);
        _2 = (object)SEQ_PTR(_8763);
        _8764 = (object)*(((s1_ptr)_2)->base + 3);
        _8763 = NOVALUE;
        if (IS_ATOM_INT(_8764) && IS_ATOM_INT(_val_15327)) {
            _8765 = _8764 - _val_15327;
            if ((object)((uintptr_t)_8765 +(uintptr_t) HIGH_BITS) >= 0){
                _8765 = NewDouble((eudouble)_8765);
            }
        }
        else {
            _8765 = binary_op(MINUS, _8764, _val_15327);
        }
        _8764 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8765;
        _8766 = MAKE_SEQ(_1);
        _8765 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8766;
        if( _1 != _8766 ){
            DeRef(_1);
        }
        _8766 = NOVALUE;
        goto L3; // [275] 555

        /** map.e:617			case MULTIPLY then*/
        case 4:

        /** map.e:618				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto L6; // [283] 310

        /** map.e:619					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_288_15382);
        _msg_inlined_crash_at_288_15382 = EPrintf(-9999999, _8768, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_288_15382);

        /** error.e:53	end procedure*/
        goto L7; // [302] 305
L7: 
        DeRefi(_msg_inlined_crash_at_288_15382);
        _msg_inlined_crash_at_288_15382 = NOVALUE;
        goto L3; // [307] 555
L6: 

        /** map.e:621					slots[index] = { hashval, key, val * slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15335);
        _8769 = (object)*(((s1_ptr)_2)->base + _index_15337);
        _2 = (object)SEQ_PTR(_8769);
        _8770 = (object)*(((s1_ptr)_2)->base + 3);
        _8769 = NOVALUE;
        if (IS_ATOM_INT(_val_15327) && IS_ATOM_INT(_8770)) {
            if (_val_15327 == (short)_val_15327 && _8770 <= INT15 && _8770 >= -INT15){
                _8771 = _val_15327 * _8770;
            }
            else{
                _8771 = NewDouble(_val_15327 * (eudouble)_8770);
            }
        }
        else {
            _8771 = binary_op(MULTIPLY, _val_15327, _8770);
        }
        _8770 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8771;
        _8772 = MAKE_SEQ(_1);
        _8771 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8772;
        if( _1 != _8772 ){
            DeRef(_1);
        }
        _8772 = NOVALUE;
        goto L3; // [335] 555

        /** map.e:624			case DIVIDE then*/
        case 5:

        /** map.e:625				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto L8; // [343] 370

        /** map.e:626					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_348_15392);
        _msg_inlined_crash_at_348_15392 = EPrintf(-9999999, _8768, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_348_15392);

        /** error.e:53	end procedure*/
        goto L9; // [362] 365
L9: 
        DeRefi(_msg_inlined_crash_at_348_15392);
        _msg_inlined_crash_at_348_15392 = NOVALUE;
        goto L3; // [367] 555
L8: 

        /** map.e:628					slots[index] = { hashval, key, slots[index][SLOT_VALUE] / val }*/
        _2 = (object)SEQ_PTR(_slots_15335);
        _8774 = (object)*(((s1_ptr)_2)->base + _index_15337);
        _2 = (object)SEQ_PTR(_8774);
        _8775 = (object)*(((s1_ptr)_2)->base + 3);
        _8774 = NOVALUE;
        if (IS_ATOM_INT(_8775) && IS_ATOM_INT(_val_15327)) {
            _8776 = (_8775 % _val_15327) ? NewDouble((eudouble)_8775 / _val_15327) : (_8775 / _val_15327);
        }
        else {
            _8776 = binary_op(DIVIDE, _8775, _val_15327);
        }
        _8775 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8776;
        _8777 = MAKE_SEQ(_1);
        _8776 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8777;
        if( _1 != _8777 ){
            DeRef(_1);
        }
        _8777 = NOVALUE;
        goto L3; // [395] 555

        /** map.e:631			case APPEND then*/
        case 6:

        /** map.e:632				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto LA; // [403] 426

        /** map.e:633					slots[index] = { hashval, key, {val} }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_val_15327);
        ((intptr_t*)_2)[1] = _val_15327;
        _8779 = MAKE_SEQ(_1);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8779;
        _8780 = MAKE_SEQ(_1);
        _8779 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8780;
        if( _1 != _8780 ){
            DeRef(_1);
        }
        _8780 = NOVALUE;
        goto L3; // [423] 555
LA: 

        /** map.e:635					slots[index] = { hashval, key, append( slots[index][SLOT_VALUE], val ) }*/
        _2 = (object)SEQ_PTR(_slots_15335);
        _8781 = (object)*(((s1_ptr)_2)->base + _index_15337);
        _2 = (object)SEQ_PTR(_8781);
        _8782 = (object)*(((s1_ptr)_2)->base + 3);
        _8781 = NOVALUE;
        Ref(_val_15327);
        Append(&_8783, _8782, _val_15327);
        _8782 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8783;
        _8784 = MAKE_SEQ(_1);
        _8783 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8784;
        if( _1 != _8784 ){
            DeRef(_1);
        }
        _8784 = NOVALUE;
        goto L3; // [451] 555

        /** map.e:638			case CONCAT then*/
        case 7:

        /** map.e:639				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto LB; // [459] 478

        /** map.e:640					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        Ref(_val_15327);
        ((intptr_t*)_2)[3] = _val_15327;
        _8786 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8786;
        if( _1 != _8786 ){
            DeRef(_1);
        }
        _8786 = NOVALUE;
        goto L3; // [475] 555
LB: 

        /** map.e:642					slots[index] = { hashval, key, slots[index][SLOT_VALUE] & val }*/
        _2 = (object)SEQ_PTR(_slots_15335);
        _8787 = (object)*(((s1_ptr)_2)->base + _index_15337);
        _2 = (object)SEQ_PTR(_8787);
        _8788 = (object)*(((s1_ptr)_2)->base + 3);
        _8787 = NOVALUE;
        if (IS_SEQUENCE(_8788) && IS_ATOM(_val_15327)) {
            Ref(_val_15327);
            Append(&_8789, _8788, _val_15327);
        }
        else if (IS_ATOM(_8788) && IS_SEQUENCE(_val_15327)) {
            Ref(_8788);
            Prepend(&_8789, _val_15327, _8788);
        }
        else {
            Concat((object_ptr)&_8789, _8788, _val_15327);
            _8788 = NOVALUE;
        }
        _8788 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        ((intptr_t*)_2)[3] = _8789;
        _8790 = MAKE_SEQ(_1);
        _8789 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8790;
        if( _1 != _8790 ){
            DeRef(_1);
        }
        _8790 = NOVALUE;
        goto L3; // [503] 555

        /** map.e:645			case LEAVE then*/
        case 8:

        /** map.e:646				if old_hash < 0 then*/
        if (_old_hash_15339 >= 0)
        goto L3; // [511] 555

        /** map.e:647					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15330;
        Ref(_key_15326);
        ((intptr_t*)_2)[2] = _key_15326;
        Ref(_val_15327);
        ((intptr_t*)_2)[3] = _val_15327;
        _8792 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15335);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15335 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15337);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8792;
        if( _1 != _8792 ){
            DeRef(_1);
        }
        _8792 = NOVALUE;
        goto L3; // [528] 555

        /** map.e:649			case else*/
        default:

        /** map.e:650				error:crash("Unknown operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_535_15424);
        _msg_inlined_crash_at_535_15424 = EPrintf(-9999999, _8793, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_535_15424);

        /** error.e:53	end procedure*/
        goto LC; // [549] 552
LC: 
        DeRefi(_msg_inlined_crash_at_535_15424);
        _msg_inlined_crash_at_535_15424 = NOVALUE;
    ;}L3: 

    /** map.e:654		the_map_seq[MAP_SLOTS] = slots*/
    RefDS(_slots_15335);
    _2 = (object)SEQ_PTR(_the_map_seq_15333);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15333 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_15335;
    DeRef(_1);

    /** map.e:655		eumem:ram_space[the_map_p] = the_map_seq*/
    RefDS(_the_map_seq_15333);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15325))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15325)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15325);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _the_map_seq_15333;
    DeRef(_1);

    /** map.e:656	end procedure*/
    DeRef(_the_map_p_15325);
    DeRef(_key_15326);
    DeRef(_val_15327);
    DeRefDS(_the_map_seq_15333);
    DeRefDS(_slots_15335);
    return;
    ;
}


void _34nested_put(object _the_map_p_15427, object _the_keys_p_15428, object _the_value_p_15429, object _operation_p_15430, object _deprecated_trigger_p_15431)
{
    object _temp_map__15432 = NOVALUE;
    object _8804 = NOVALUE;
    object _8803 = NOVALUE;
    object _8802 = NOVALUE;
    object _8801 = NOVALUE;
    object _8800 = NOVALUE;
    object _8798 = NOVALUE;
    object _8797 = NOVALUE;
    object _8796 = NOVALUE;
    object _8794 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:701		if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_15428)){
            _8794 = SEQ_PTR(_the_keys_p_15428)->length;
    }
    else {
        _8794 = 1;
    }
    if (_8794 != 1)
    goto L1; // [10] 30

    /** map.e:702			put( the_map_p, the_keys_p[1], the_value_p, operation_p )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15428);
    _8796 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_15427);
    Ref(_8796);
    Ref(_the_value_p_15429);
    _34put(_the_map_p_15427, _8796, _the_value_p_15429, _operation_p_15430, 0);
    _8796 = NOVALUE;
    goto L2; // [27] 84
L1: 

    /** map.e:704			temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15428);
    _8797 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_15427);
    Ref(_8797);
    _8798 = _34get(_the_map_p_15427, _8797, 0);
    _8797 = NOVALUE;
    _0 = _temp_map__15432;
    _temp_map__15432 = _34new_extra(_8798, 8);
    DeRef(_0);
    _8798 = NOVALUE;

    /** map.e:705			nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p )*/
    if (IS_SEQUENCE(_the_keys_p_15428)){
            _8800 = SEQ_PTR(_the_keys_p_15428)->length;
    }
    else {
        _8800 = 1;
    }
    rhs_slice_target = (object_ptr)&_8801;
    RHS_Slice(_the_keys_p_15428, 2, _8800);
    Ref(_the_value_p_15429);
    DeRef(_8802);
    _8802 = _the_value_p_15429;
    DeRef(_8803);
    _8803 = _operation_p_15430;
    Ref(_temp_map__15432);
    _34nested_put(_temp_map__15432, _8801, _8802, _8803, 0);
    _8801 = NOVALUE;
    _8802 = NOVALUE;
    _8803 = NOVALUE;

    /** map.e:706			put( the_map_p, the_keys_p[1], temp_map_, PUT )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15428);
    _8804 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_15427);
    Ref(_8804);
    Ref(_temp_map__15432);
    _34put(_the_map_p_15427, _8804, _temp_map__15432, 1, 0);
    _8804 = NOVALUE;
L2: 

    /** map.e:708	end procedure*/
    DeRef(_the_map_p_15427);
    DeRefDS(_the_keys_p_15428);
    DeRef(_the_value_p_15429);
    DeRef(_temp_map__15432);
    return;
    ;
}


void _34remove(object _the_map_p_15448, object _key_15449)
{
    object _hashval_15450 = NOVALUE;
    object _hash_inlined_hash_at_2_15452 = NOVALUE;
    object _slots_15453 = NOVALUE;
    object _index_15456 = NOVALUE;
    object _8816 = NOVALUE;
    object _8815 = NOVALUE;
    object _8813 = NOVALUE;
    object _8811 = NOVALUE;
    object _8809 = NOVALUE;
    object _8808 = NOVALUE;
    object _8805 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:733		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15450 = calc_hash(_key_15449, -6);

    /** map.e:734		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15448)){
        _8805 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15448)->dbl));
    }
    else{
        _8805 = (object)*(((s1_ptr)_2)->base + _the_map_p_15448);
    }
    DeRef(_slots_15453);
    _2 = (object)SEQ_PTR(_8805);
    _slots_15453 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15453);
    _8805 = NOVALUE;

    /** map.e:736		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15449);
    RefDS(_slots_15453);
    _index_15456 = _34lookup(_key_15449, _hashval_15450, _slots_15453);
    if (!IS_ATOM_INT(_index_15456)) {
        _1 = (object)(DBL_PTR(_index_15456)->dbl);
        DeRefDS(_index_15456);
        _index_15456 = _1;
    }

    /** map.e:737		if hashval = slots[index][SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slots_15453);
    _8808 = (object)*(((s1_ptr)_2)->base + _index_15456);
    _2 = (object)SEQ_PTR(_8808);
    _8809 = (object)*(((s1_ptr)_2)->base + 1);
    _8808 = NOVALUE;
    if (binary_op_a(NOTEQ, _hashval_15450, _8809)){
        _8809 = NOVALUE;
        goto L1; // [46] 99
    }
    _8809 = NOVALUE;

    /** map.e:738			slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15453);
    _slots_15453 = _5;

    /** map.e:739			eumem:ram_space[the_map_p][MAP_SLOTS][index] = REMOVED_SLOT*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15448))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15448)->dbl));
    else
    _3 = (object)(_the_map_p_15448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(2 + ((s1_ptr)_2)->base);
    _8811 = NOVALUE;
    RefDS(_34REMOVED_SLOT_15064);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_15456);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34REMOVED_SLOT_15064;
    DeRef(_1);
    _8811 = NOVALUE;

    /** map.e:740			eumem:ram_space[the_map_p][MAP_SIZE] -= 1*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15448))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15448)->dbl));
    else
    _3 = (object)(_the_map_p_15448 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _8815 = (object)*(((s1_ptr)_2)->base + 1);
    _8813 = NOVALUE;
    if (IS_ATOM_INT(_8815)) {
        _8816 = _8815 - 1;
        if ((object)((uintptr_t)_8816 +(uintptr_t) HIGH_BITS) >= 0){
            _8816 = NewDouble((eudouble)_8816);
        }
    }
    else {
        _8816 = binary_op(MINUS, _8815, 1);
    }
    _8815 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8816;
    if( _1 != _8816 ){
        DeRef(_1);
    }
    _8816 = NOVALUE;
    _8813 = NOVALUE;
L1: 

    /** map.e:742	end procedure*/
    DeRef(_the_map_p_15448);
    DeRef(_key_15449);
    DeRef(_slots_15453);
    return;
    ;
}


void _34clear(object _the_map_p_15470)
{
    object _8823 = NOVALUE;
    object _8822 = NOVALUE;
    object _8821 = NOVALUE;
    object _8820 = NOVALUE;
    object _8819 = NOVALUE;
    object _8817 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:771		eumem:ram_space[the_map_p][MAP_SLOTS] = repeat( EMPTY_SLOT, length( eumem:ram_space[the_map_p][MAP_SLOTS] ) )*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15470))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15470)->dbl));
    else
    _3 = (object)(_the_map_p_15470 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15470)){
        _8819 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15470)->dbl));
    }
    else{
        _8819 = (object)*(((s1_ptr)_2)->base + _the_map_p_15470);
    }
    _2 = (object)SEQ_PTR(_8819);
    _8820 = (object)*(((s1_ptr)_2)->base + 2);
    _8819 = NOVALUE;
    if (IS_SEQUENCE(_8820)){
            _8821 = SEQ_PTR(_8820)->length;
    }
    else {
        _8821 = 1;
    }
    _8820 = NOVALUE;
    _8822 = Repeat(_34EMPTY_SLOT_15062, _8821);
    _8821 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8822;
    if( _1 != _8822 ){
        DeRef(_1);
    }
    _8822 = NOVALUE;
    _8817 = NOVALUE;

    /** map.e:772		eumem:ram_space[the_map_p][MAP_SIZE]  = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15470))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15470)->dbl));
    else
    _3 = (object)(_the_map_p_15470 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _8823 = NOVALUE;

    /** map.e:773	end procedure*/
    DeRef(_the_map_p_15470);
    _8820 = NOVALUE;
    return;
    ;
}


object _34keys(object _the_map_p_15525, object _sorted_result_15526)
{
    object _slots_15527 = NOVALUE;
    object _keys_15530 = NOVALUE;
    object _kx_15534 = NOVALUE;
    object _8854 = NOVALUE;
    object _8852 = NOVALUE;
    object _8851 = NOVALUE;
    object _8850 = NOVALUE;
    object _8847 = NOVALUE;
    object _8846 = NOVALUE;
    object _8845 = NOVALUE;
    object _8843 = NOVALUE;
    object _8842 = NOVALUE;
    object _8840 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:901		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15525)){
        _8840 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15525)->dbl));
    }
    else{
        _8840 = (object)*(((s1_ptr)_2)->base + _the_map_p_15525);
    }
    DeRef(_slots_15527);
    _2 = (object)SEQ_PTR(_8840);
    _slots_15527 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15527);
    _8840 = NOVALUE;

    /** map.e:902		sequence keys = repeat( 0, eumem:ram_space[the_map_p][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15525)){
        _8842 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15525)->dbl));
    }
    else{
        _8842 = (object)*(((s1_ptr)_2)->base + _the_map_p_15525);
    }
    _2 = (object)SEQ_PTR(_8842);
    _8843 = (object)*(((s1_ptr)_2)->base + 1);
    _8842 = NOVALUE;
    DeRef(_keys_15530);
    _keys_15530 = Repeat(0, _8843);
    _8843 = NOVALUE;

    /** map.e:903		integer kx = 0*/
    _kx_15534 = 0;

    /** map.e:904		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15527)){
            _8845 = SEQ_PTR(_slots_15527)->length;
    }
    else {
        _8845 = 1;
    }
    {
        object _i_15536;
        _i_15536 = 1;
L1: 
        if (_i_15536 > _8845){
            goto L2; // [43] 106
        }

        /** map.e:905			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15527);
        _8846 = (object)*(((s1_ptr)_2)->base + _i_15536);
        _2 = (object)SEQ_PTR(_8846);
        _8847 = (object)*(((s1_ptr)_2)->base + 1);
        _8846 = NOVALUE;
        if (binary_op_a(LESS, _8847, 0)){
            _8847 = NOVALUE;
            goto L3; // [60] 99
        }
        _8847 = NOVALUE;

        /** map.e:906				kx += 1*/
        _kx_15534 = _kx_15534 + 1;

        /** map.e:907				keys[kx] = slots[i][SLOT_KEY]*/
        _2 = (object)SEQ_PTR(_slots_15527);
        _8850 = (object)*(((s1_ptr)_2)->base + _i_15536);
        _2 = (object)SEQ_PTR(_8850);
        _8851 = (object)*(((s1_ptr)_2)->base + 2);
        _8850 = NOVALUE;
        Ref(_8851);
        _2 = (object)SEQ_PTR(_keys_15530);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _keys_15530 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _kx_15534);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8851;
        if( _1 != _8851 ){
            DeRef(_1);
        }
        _8851 = NOVALUE;

        /** map.e:908				if kx = length( keys ) then*/
        if (IS_SEQUENCE(_keys_15530)){
                _8852 = SEQ_PTR(_keys_15530)->length;
        }
        else {
            _8852 = 1;
        }
        if (_kx_15534 != _8852)
        goto L4; // [89] 98

        /** map.e:909					exit*/
        goto L2; // [95] 106
L4: 
L3: 

        /** map.e:912		end for*/
        _i_15536 = _i_15536 + 1;
        goto L1; // [101] 50
L2: 
        ;
    }

    /** map.e:913		if sorted_result then*/
    if (_sorted_result_15526 == 0)
    {
        goto L5; // [108] 123
    }
    else{
    }

    /** map.e:914			return stdsort:sort( keys )*/
    RefDS(_keys_15530);
    _8854 = _25sort(_keys_15530, 1);
    DeRef(_the_map_p_15525);
    DeRef(_slots_15527);
    DeRefDS(_keys_15530);
    return _8854;
L5: 

    /** map.e:916		return keys*/
    DeRef(_the_map_p_15525);
    DeRef(_slots_15527);
    DeRef(_8854);
    _8854 = NOVALUE;
    return _keys_15530;
    ;
}


object _34pairs(object _the_map_15601, object _sorted_result_15602)
{
    object _slots_15603 = NOVALUE;
    object _pairs_15606 = NOVALUE;
    object _px_15610 = NOVALUE;
    object _8904 = NOVALUE;
    object _8902 = NOVALUE;
    object _8901 = NOVALUE;
    object _8900 = NOVALUE;
    object _8899 = NOVALUE;
    object _8898 = NOVALUE;
    object _8897 = NOVALUE;
    object _8894 = NOVALUE;
    object _8893 = NOVALUE;
    object _8892 = NOVALUE;
    object _8890 = NOVALUE;
    object _8889 = NOVALUE;
    object _8887 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:1045		sequence slots = eumem:ram_space[the_map][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_15601)){
        _8887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15601)->dbl));
    }
    else{
        _8887 = (object)*(((s1_ptr)_2)->base + _the_map_15601);
    }
    DeRef(_slots_15603);
    _2 = (object)SEQ_PTR(_8887);
    _slots_15603 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_slots_15603);
    _8887 = NOVALUE;

    /** map.e:1046		sequence pairs = repeat( 0, eumem:ram_space[the_map][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_15601)){
        _8889 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15601)->dbl));
    }
    else{
        _8889 = (object)*(((s1_ptr)_2)->base + _the_map_15601);
    }
    _2 = (object)SEQ_PTR(_8889);
    _8890 = (object)*(((s1_ptr)_2)->base + 1);
    _8889 = NOVALUE;
    DeRef(_pairs_15606);
    _pairs_15606 = Repeat(0, _8890);
    _8890 = NOVALUE;

    /** map.e:1047		integer px = 0*/
    _px_15610 = 0;

    /** map.e:1048		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15603)){
            _8892 = SEQ_PTR(_slots_15603)->length;
    }
    else {
        _8892 = 1;
    }
    {
        object _i_15612;
        _i_15612 = 1;
L1: 
        if (_i_15612 > _8892){
            goto L2; // [43] 118
        }

        /** map.e:1049			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15603);
        _8893 = (object)*(((s1_ptr)_2)->base + _i_15612);
        _2 = (object)SEQ_PTR(_8893);
        _8894 = (object)*(((s1_ptr)_2)->base + 1);
        _8893 = NOVALUE;
        if (binary_op_a(LESS, _8894, 0)){
            _8894 = NOVALUE;
            goto L3; // [60] 111
        }
        _8894 = NOVALUE;

        /** map.e:1050				px += 1*/
        _px_15610 = _px_15610 + 1;

        /** map.e:1051				pairs[px] = { slots[i][SLOT_KEY], slots[i][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15603);
        _8897 = (object)*(((s1_ptr)_2)->base + _i_15612);
        _2 = (object)SEQ_PTR(_8897);
        _8898 = (object)*(((s1_ptr)_2)->base + 2);
        _8897 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15603);
        _8899 = (object)*(((s1_ptr)_2)->base + _i_15612);
        _2 = (object)SEQ_PTR(_8899);
        _8900 = (object)*(((s1_ptr)_2)->base + 3);
        _8899 = NOVALUE;
        Ref(_8900);
        Ref(_8898);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _8898;
        ((intptr_t *)_2)[2] = _8900;
        _8901 = MAKE_SEQ(_1);
        _8900 = NOVALUE;
        _8898 = NOVALUE;
        _2 = (object)SEQ_PTR(_pairs_15606);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pairs_15606 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _px_15610);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8901;
        if( _1 != _8901 ){
            DeRef(_1);
        }
        _8901 = NOVALUE;

        /** map.e:1052				if px = length( pairs ) then*/
        if (IS_SEQUENCE(_pairs_15606)){
                _8902 = SEQ_PTR(_pairs_15606)->length;
        }
        else {
            _8902 = 1;
        }
        if (_px_15610 != _8902)
        goto L4; // [101] 110

        /** map.e:1053					exit*/
        goto L2; // [107] 118
L4: 
L3: 

        /** map.e:1056		end for*/
        _i_15612 = _i_15612 + 1;
        goto L1; // [113] 50
L2: 
        ;
    }

    /** map.e:1057		if sorted_result then*/
    if (_sorted_result_15602 == 0)
    {
        goto L5; // [120] 135
    }
    else{
    }

    /** map.e:1058			return stdsort:sort( pairs )*/
    RefDS(_pairs_15606);
    _8904 = _25sort(_pairs_15606, 1);
    DeRef(_the_map_15601);
    DeRef(_slots_15603);
    DeRefDS(_pairs_15606);
    return _8904;
L5: 

    /** map.e:1060		return pairs*/
    DeRef(_the_map_15601);
    DeRef(_slots_15603);
    DeRef(_8904);
    _8904 = NOVALUE;
    return _pairs_15606;
    ;
}



// 0x9423E02C
