// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50check_coverage()
{
    object _25338 = NOVALUE;
    object _25337 = NOVALUE;
    object _25336 = NOVALUE;
    object _25335 = NOVALUE;
    object _25334 = NOVALUE;
    object _25333 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_50file_coverage_49229)){
            _25333 = SEQ_PTR(_50file_coverage_49229)->length;
    }
    else {
        _25333 = 1;
    }
    _25334 = _25333 + 1;
    _25333 = NOVALUE;
    if (IS_SEQUENCE(_28known_files_11573)){
            _25335 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _25335 = 1;
    }
    {
        object _i_49240;
        _i_49240 = _25334;
L1: 
        if (_i_49240 > _25335){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _25336 = (object)*(((s1_ptr)_2)->base + _i_49240);
        Ref(_25336);
        _25337 = _15canonical_path(_25336, 0, 1);
        _25336 = NOVALUE;
        _25338 = find_from(_25337, _50covered_files_49228, 1);
        DeRef(_25337);
        _25337 = NOVALUE;
        Append(&_50file_coverage_49229, _50file_coverage_49229, _25338);
        _25338 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_49240 = _i_49240 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25334);
    _25334 = NOVALUE;
    return;
    ;
}


void _50init_coverage()
{
    object _cmd_49264 = NOVALUE;
    object _25356 = NOVALUE;
    object _25355 = NOVALUE;
    object _25353 = NOVALUE;
    object _25352 = NOVALUE;
    object _25351 = NOVALUE;
    object _25349 = NOVALUE;
    object _25347 = NOVALUE;
    object _25346 = NOVALUE;
    object _25344 = NOVALUE;
    object _25343 = NOVALUE;
    object _25342 = NOVALUE;
    object _25341 = NOVALUE;
    object _25340 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_50initialized_coverage_49236 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _50initialized_coverage_49236 = 1;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_50file_coverage_49229)){
            _25340 = SEQ_PTR(_50file_coverage_49229)->length;
    }
    else {
        _25340 = 1;
    }
    {
        object _i_49255;
        _i_49255 = 1;
L2: 
        if (_i_49255 > _25340){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_28known_files_11573);
        _25341 = (object)*(((s1_ptr)_2)->base + _i_49255);
        Ref(_25341);
        _25342 = _15canonical_path(_25341, 0, 1);
        _25341 = NOVALUE;
        _25343 = find_from(_25342, _50covered_files_49228, 1);
        DeRef(_25342);
        _25342 = NOVALUE;
        _2 = (object)SEQ_PTR(_50file_coverage_49229);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _50file_coverage_49229 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_49255);
        *(intptr_t *)_2 = _25343;
        if( _1 != _25343 ){
        }
        _25343 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_49255 = _i_49255 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_50coverage_db_name_49230 == _22209)
    _25344 = 1;
    else if (IS_ATOM_INT(_50coverage_db_name_49230) && IS_ATOM_INT(_22209))
    _25344 = 0;
    else
    _25344 = (compare(_50coverage_db_name_49230, _22209) == 0);
    if (_25344 == 0)
    {
        _25344 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25344 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_49264);
    _cmd_49264 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_49264);
    _25346 = (object)*(((s1_ptr)_2)->base + 2);
    RefDS(_25346);
    _25347 = _15filebase(_25346);
    _25346 = NOVALUE;
    if (IS_SEQUENCE(_25347) && IS_ATOM(_25348)) {
    }
    else if (IS_ATOM(_25347) && IS_SEQUENCE(_25348)) {
        Ref(_25347);
        Prepend(&_25349, _25348, _25347);
    }
    else {
        Concat((object_ptr)&_25349, _25347, _25348);
        DeRef(_25347);
        _25347 = NOVALUE;
    }
    DeRef(_25347);
    _25347 = NOVALUE;
    _0 = _15canonical_path(_25349, 0, 0);
    DeRefDS(_50coverage_db_name_49230);
    _50coverage_db_name_49230 = _0;
    _25349 = NOVALUE;
L4: 
    DeRef(_cmd_49264);
    _cmd_49264 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_50coverage_erase_49231 == 0) {
        goto L5; // [111] 153
    }
    RefDS(_50coverage_db_name_49230);
    _25352 = _15file_exists(_50coverage_db_name_49230);
    if (_25352 == 0) {
        DeRef(_25352);
        _25352 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25352) && DBL_PTR(_25352)->dbl == 0.0){
            DeRef(_25352);
            _25352 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25352);
        _25352 = NOVALUE;
    }
    DeRef(_25352);
    _25352 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_49230);
    _25353 = _15delete_file(_50coverage_db_name_49230);
    if (IS_ATOM_INT(_25353)) {
        if (_25353 != 0){
            DeRef(_25353);
            _25353 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25353)->dbl != 0.0){
            DeRef(_25353);
            _25353 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25353);
    _25353 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_49230);
    ((intptr_t*)_2)[1] = _50coverage_db_name_49230;
    _25355 = MAKE_SEQ(_1);
    _49CompileErr(335, _25355, 0);
    _25355 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_50coverage_db_name_49230);
    _25356 = _41db_open(_50coverage_db_name_49230, 0);
    if (binary_op_a(NOTEQ, _25356, 0)){
        DeRef(_25356);
        _25356 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25356);
    _25356 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _50read_coverage_db();

    /** coverage.e:75			db_close()*/
    _41db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _50write_map(object _coverage_49294, object _table_name_49295)
{
    object _keys_49319 = NOVALUE;
    object _rec_49324 = NOVALUE;
    object _val_49328 = NOVALUE;
    object _31993 = NOVALUE;
    object _25373 = NOVALUE;
    object _25370 = NOVALUE;
    object _25368 = NOVALUE;
    object _25367 = NOVALUE;
    object _25365 = NOVALUE;
    object _25364 = NOVALUE;
    object _25362 = NOVALUE;
    object _25360 = NOVALUE;
    object _25358 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:80		if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_50coverage_db_name_49230);
    _25358 = _41db_select(_50coverage_db_name_49230, 2);
    if (binary_op_a(NOTEQ, _25358, 0)){
        DeRef(_25358);
        _25358 = NOVALUE;
        goto L1; // [16] 63
    }
    DeRef(_25358);
    _25358 = NOVALUE;

    /** coverage.e:81			if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_49295);
    _25360 = _41db_select_table(_table_name_49295);
    if (binary_op_a(EQUALS, _25360, 0)){
        DeRef(_25360);
        _25360 = NOVALUE;
        goto L2; // [28] 77
    }
    DeRef(_25360);
    _25360 = NOVALUE;

    /** coverage.e:82				if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_49295);
    _25362 = _41db_create_table(_table_name_49295, 50);
    if (binary_op_a(EQUALS, _25362, 0)){
        DeRef(_25362);
        _25362 = NOVALUE;
        goto L2; // [41] 77
    }
    DeRef(_25362);
    _25362 = NOVALUE;

    /** coverage.e:83					CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_49295);
    ((intptr_t*)_2)[1] = _table_name_49295;
    _25364 = MAKE_SEQ(_1);
    _49CompileErr(336, _25364, 0);
    _25364 = NOVALUE;
    goto L2; // [60] 77
L1: 

    /** coverage.e:87			CompileErr( COULD_NOT_CREATE_COVERAGE_TABLE_1, {table_name} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_49295);
    ((intptr_t*)_2)[1] = _table_name_49295;
    _25365 = MAKE_SEQ(_1);
    _49CompileErr(336, _25365, 0);
    _25365 = NOVALUE;
L2: 

    /** coverage.e:90		sequence keys = map:keys( coverage )*/
    Ref(_coverage_49294);
    _0 = _keys_49319;
    _keys_49319 = _34keys(_coverage_49294, 0);
    DeRef(_0);

    /** coverage.e:91		for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_49319)){
            _25367 = SEQ_PTR(_keys_49319)->length;
    }
    else {
        _25367 = 1;
    }
    {
        object _i_49322;
        _i_49322 = 1;
L3: 
        if (_i_49322 > _25367){
            goto L4; // [91] 171
        }

        /** coverage.e:92			integer rec = db_find_key( keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_49319);
        _25368 = (object)*(((s1_ptr)_2)->base + _i_49322);
        Ref(_25368);
        RefDS(_41current_table_name_16049);
        _rec_49324 = _41db_find_key(_25368, _41current_table_name_16049);
        _25368 = NOVALUE;
        if (!IS_ATOM_INT(_rec_49324)) {
            _1 = (object)(DBL_PTR(_rec_49324)->dbl);
            DeRefDS(_rec_49324);
            _rec_49324 = _1;
        }

        /** coverage.e:93			integer val = map:get( coverage, keys[i] )*/
        _2 = (object)SEQ_PTR(_keys_49319);
        _25370 = (object)*(((s1_ptr)_2)->base + _i_49322);
        Ref(_coverage_49294);
        Ref(_25370);
        _val_49328 = _34get(_coverage_49294, _25370, 0);
        _25370 = NOVALUE;
        if (!IS_ATOM_INT(_val_49328)) {
            _1 = (object)(DBL_PTR(_val_49328)->dbl);
            DeRefDS(_val_49328);
            _val_49328 = _1;
        }

        /** coverage.e:94			if rec > 0 then*/
        if (_rec_49324 <= 0)
        goto L5; // [129] 145

        /** coverage.e:95				db_replace_data( rec, val )*/
        RefDS(_41current_table_name_16049);
        _41db_replace_data(_rec_49324, _val_49328, _41current_table_name_16049);
        goto L6; // [142] 162
L5: 

        /** coverage.e:97				db_insert( keys[i], val )*/
        _2 = (object)SEQ_PTR(_keys_49319);
        _25373 = (object)*(((s1_ptr)_2)->base + _i_49322);
        Ref(_25373);
        RefDS(_41current_table_name_16049);
        _31993 = _41db_insert(_25373, _val_49328, _41current_table_name_16049);
        _25373 = NOVALUE;
        DeRef(_31993);
        _31993 = NOVALUE;
L6: 

        /** coverage.e:99		end for*/
        _i_49322 = _i_49322 + 1;
        goto L3; // [166] 98
L4: 
        ;
    }

    /** coverage.e:101	end procedure*/
    DeRef(_coverage_49294);
    DeRefDS(_table_name_49295);
    DeRef(_keys_49319);
    return;
    ;
}


object _50write_coverage_db()
{
    object _25388 = NOVALUE;
    object _25387 = NOVALUE;
    object _25386 = NOVALUE;
    object _25385 = NOVALUE;
    object _25384 = NOVALUE;
    object _25383 = NOVALUE;
    object _25382 = NOVALUE;
    object _25381 = NOVALUE;
    object _25378 = NOVALUE;
    object _25376 = NOVALUE;
    object _25374 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:105		if wrote_coverage then*/
    if (_50wrote_coverage_49337 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** coverage.e:106			return 1*/
    return 1;
L1: 

    /** coverage.e:108		wrote_coverage = 1*/
    _50wrote_coverage_49337 = 1;

    /** coverage.e:109		init_coverage()*/
    _50init_coverage();

    /** coverage.e:110		if not length( covered_files ) then*/
    if (IS_SEQUENCE(_50covered_files_49228)){
            _25374 = SEQ_PTR(_50covered_files_49228)->length;
    }
    else {
        _25374 = 1;
    }
    if (_25374 != 0)
    goto L2; // [31] 41
    _25374 = NOVALUE;

    /** coverage.e:111			return 1*/
    return 1;
L2: 

    /** coverage.e:114		if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_50coverage_db_name_49230);
    _25376 = _41db_open(_50coverage_db_name_49230, 2);
    if (binary_op_a(EQUALS, 0, _25376)){
        DeRef(_25376);
        _25376 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25376);
    _25376 = NOVALUE;

    /** coverage.e:115			if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_49230);
    _25378 = _41db_create(_50coverage_db_name_49230, 0, 5, 5);
    if (binary_op_a(EQUALS, 0, _25378)){
        DeRef(_25378);
        _25378 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25378);
    _25378 = NOVALUE;

    /** coverage.e:116				printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_49230);
    ((intptr_t*)_2)[1] = _50coverage_db_name_49230;
    _25381 = MAKE_SEQ(_1);
    EPrintf(2, _25380, _25381);
    DeRefDS(_25381);
    _25381 = NOVALUE;

    /** coverage.e:117				return 0*/
    return 0;
L4: 
L3: 

    /** coverage.e:121		process_lines()*/
    _50process_lines();

    /** coverage.e:122		for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_50routine_map_49234)){
            _25382 = SEQ_PTR(_50routine_map_49234)->length;
    }
    else {
        _25382 = 1;
    }
    {
        object _tx_49359;
        _tx_49359 = 1;
L5: 
        if (_tx_49359 > _25382){
            goto L6; // [106] 164
        }

        /** coverage.e:123			write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50routine_map_49234);
        _25383 = (object)*(((s1_ptr)_2)->base + _tx_49359);
        _2 = (object)SEQ_PTR(_50covered_files_49228);
        _25384 = (object)*(((s1_ptr)_2)->base + _tx_49359);
        if (IS_SEQUENCE(114) && IS_ATOM(_25384)) {
        }
        else if (IS_ATOM(114) && IS_SEQUENCE(_25384)) {
            Prepend(&_25385, _25384, 114);
        }
        else {
            Concat((object_ptr)&_25385, 114, _25384);
        }
        _25384 = NOVALUE;
        Ref(_25383);
        _50write_map(_25383, _25385);
        _25383 = NOVALUE;
        _25385 = NOVALUE;

        /** coverage.e:124			write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (object)SEQ_PTR(_50line_map_49233);
        _25386 = (object)*(((s1_ptr)_2)->base + _tx_49359);
        _2 = (object)SEQ_PTR(_50covered_files_49228);
        _25387 = (object)*(((s1_ptr)_2)->base + _tx_49359);
        if (IS_SEQUENCE(108) && IS_ATOM(_25387)) {
        }
        else if (IS_ATOM(108) && IS_SEQUENCE(_25387)) {
            Prepend(&_25388, _25387, 108);
        }
        else {
            Concat((object_ptr)&_25388, 108, _25387);
        }
        _25387 = NOVALUE;
        Ref(_25386);
        _50write_map(_25386, _25388);
        _25386 = NOVALUE;
        _25388 = NOVALUE;

        /** coverage.e:125		end for*/
        _tx_49359 = _tx_49359 + 1;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** coverage.e:127		db_close()*/
    _41db_close();

    /** coverage.e:129		routine_map = {}*/
    RefDS(_22209);
    DeRef(_50routine_map_49234);
    _50routine_map_49234 = _22209;

    /** coverage.e:130		line_map    = {}*/
    RefDS(_22209);
    DeRef(_50line_map_49233);
    _50line_map_49233 = _22209;

    /** coverage.e:131		return 1*/
    return 1;
    ;
}


void _50read_coverage_db()
{
    object _tables_49370 = NOVALUE;
    object _name_49376 = NOVALUE;
    object _fx_49380 = NOVALUE;
    object _the_map_49387 = NOVALUE;
    object _31992 = NOVALUE;
    object _25404 = NOVALUE;
    object _25403 = NOVALUE;
    object _25402 = NOVALUE;
    object _25398 = NOVALUE;
    object _25397 = NOVALUE;
    object _25396 = NOVALUE;
    object _25392 = NOVALUE;
    object _25391 = NOVALUE;
    object _25390 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_49370;
    _tables_49370 = _41db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_49370)){
            _25390 = SEQ_PTR(_tables_49370)->length;
    }
    else {
        _25390 = 1;
    }
    {
        object _i_49374;
        _i_49374 = 1;
L1: 
        if (_i_49374 > _25390){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_49370);
        _25391 = (object)*(((s1_ptr)_2)->base + _i_49374);
        if (IS_SEQUENCE(_25391)){
                _25392 = SEQ_PTR(_25391)->length;
        }
        else {
            _25392 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_49376;
        RHS_Slice(_25391, 2, _25392);
        _25391 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_49380 = find_from(_name_49376, _50covered_files_49228, 1);

        /** coverage.e:140			if not fx then*/
        if (_fx_49380 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_49376);
        _name_49376 = NOVALUE;
        DeRef(_the_map_49387);
        _the_map_49387 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_49370);
        _25396 = (object)*(((s1_ptr)_2)->base + _i_49374);
        Ref(_25396);
        _31992 = _41db_select_table(_25396);
        _25396 = NOVALUE;
        DeRef(_31992);
        _31992 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_49370);
        _25397 = (object)*(((s1_ptr)_2)->base + _i_49374);
        _2 = (object)SEQ_PTR(_25397);
        _25398 = (object)*(((s1_ptr)_2)->base + 1);
        _25397 = NOVALUE;
        if (binary_op_a(NOTEQ, _25398, 114)){
            _25398 = NOVALUE;
            goto L5; // [77] 92
        }
        _25398 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_49387);
        _2 = (object)SEQ_PTR(_50routine_map_49234);
        _the_map_49387 = (object)*(((s1_ptr)_2)->base + _fx_49380);
        Ref(_the_map_49387);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_49387);
        _2 = (object)SEQ_PTR(_50line_map_49233);
        _the_map_49387 = (object)*(((s1_ptr)_2)->base + _fx_49380);
        Ref(_the_map_49387);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_41current_table_name_16049);
        _25402 = _41db_table_size(_41current_table_name_16049);
        {
            object _j_49396;
            _j_49396 = 1;
L7: 
            if (binary_op_a(GREATER, _j_49396, _25402)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_49396);
            RefDS(_41current_table_name_16049);
            _25403 = _41db_record_key(_j_49396, _41current_table_name_16049);
            Ref(_j_49396);
            RefDS(_41current_table_name_16049);
            _25404 = _41db_record_data(_j_49396, _41current_table_name_16049);
            Ref(_the_map_49387);
            _34put(_the_map_49387, _25403, _25404, 2, 0);
            _25403 = NOVALUE;
            _25404 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_49396;
            if (IS_ATOM_INT(_j_49396)) {
                _j_49396 = _j_49396 + 1;
                if ((object)((uintptr_t)_j_49396 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_49396 = NewDouble((eudouble)_j_49396);
                }
            }
            else {
                _j_49396 = binary_op_a(PLUS, _j_49396, 1);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_49396);
        }
        DeRef(_name_49376);
        _name_49376 = NOVALUE;
        DeRef(_the_map_49387);
        _the_map_49387 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_49374 = _i_49374 + 1;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_49370);
    DeRef(_25402);
    _25402 = NOVALUE;
    return;
    ;
}


void _50coverage_db(object _name_49405)
{
    object _0, _1, _2;
    

    /** coverage.e:164		coverage_db_name = name*/
    RefDS(_name_49405);
    DeRef(_50coverage_db_name_49230);
    _50coverage_db_name_49230 = _name_49405;

    /** coverage.e:165	end procedure*/
    DeRefDS(_name_49405);
    return;
    ;
}


object _50coverage_on()
{
    object _25405 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_50file_coverage_49229);
    _25405 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    return _25405;
    ;
}


void _50new_covered_path(object _name_49417)
{
    object _new_1__tmp_at14_49421 = NOVALUE;
    object _new_inlined_new_at_14_49420 = NOVALUE;
    object _new_1__tmp_at36_49425 = NOVALUE;
    object _new_inlined_new_at_36_49424 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:176		covered_files = append( covered_files, name )*/
    RefDS(_name_49417);
    Append(&_50covered_files_49228, _50covered_files_49228, _name_49417);

    /** coverage.e:177		routine_map &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_49421;
    _new_1__tmp_at14_49421 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at14_49421);
    _0 = _new_inlined_new_at_14_49420;
    _new_inlined_new_at_14_49420 = _35malloc(_new_1__tmp_at14_49421, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_49421);
    _new_1__tmp_at14_49421 = NOVALUE;
    if (IS_SEQUENCE(_50routine_map_49234) && IS_ATOM(_new_inlined_new_at_14_49420)) {
        Ref(_new_inlined_new_at_14_49420);
        Append(&_50routine_map_49234, _50routine_map_49234, _new_inlined_new_at_14_49420);
    }
    else if (IS_ATOM(_50routine_map_49234) && IS_SEQUENCE(_new_inlined_new_at_14_49420)) {
    }
    else {
        Concat((object_ptr)&_50routine_map_49234, _50routine_map_49234, _new_inlined_new_at_14_49420);
    }

    /** coverage.e:178		line_map    &= map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at36_49425;
    _new_1__tmp_at36_49425 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at36_49425);
    _0 = _new_inlined_new_at_36_49424;
    _new_inlined_new_at_36_49424 = _35malloc(_new_1__tmp_at36_49425, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at36_49425);
    _new_1__tmp_at36_49425 = NOVALUE;
    if (IS_SEQUENCE(_50line_map_49233) && IS_ATOM(_new_inlined_new_at_36_49424)) {
        Ref(_new_inlined_new_at_36_49424);
        Append(&_50line_map_49233, _50line_map_49233, _new_inlined_new_at_36_49424);
    }
    else if (IS_ATOM(_50line_map_49233) && IS_SEQUENCE(_new_inlined_new_at_36_49424)) {
    }
    else {
        Concat((object_ptr)&_50line_map_49233, _50line_map_49233, _new_inlined_new_at_36_49424);
    }

    /** coverage.e:179	end procedure*/
    DeRefDS(_name_49417);
    return;
    ;
}


void _50add_coverage(object _cover_this_49429)
{
    object _path_49430 = NOVALUE;
    object _files_49439 = NOVALUE;
    object _subpath_49467 = NOVALUE;
    object _25444 = NOVALUE;
    object _25443 = NOVALUE;
    object _25442 = NOVALUE;
    object _25441 = NOVALUE;
    object _25440 = NOVALUE;
    object _25439 = NOVALUE;
    object _25438 = NOVALUE;
    object _25437 = NOVALUE;
    object _25436 = NOVALUE;
    object _25435 = NOVALUE;
    object _25434 = NOVALUE;
    object _25433 = NOVALUE;
    object _25431 = NOVALUE;
    object _25430 = NOVALUE;
    object _25429 = NOVALUE;
    object _25428 = NOVALUE;
    object _25427 = NOVALUE;
    object _25426 = NOVALUE;
    object _25425 = NOVALUE;
    object _25424 = NOVALUE;
    object _25422 = NOVALUE;
    object _25421 = NOVALUE;
    object _25420 = NOVALUE;
    object _25419 = NOVALUE;
    object _25418 = NOVALUE;
    object _25417 = NOVALUE;
    object _25416 = NOVALUE;
    object _25415 = NOVALUE;
    object _25412 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:185		sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_49429);
    _0 = _path_49430;
    _path_49430 = _15canonical_path(_cover_this_49429, 0, 2);
    DeRef(_0);

    /** coverage.e:187		if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_49430);
    _25412 = _15file_type(_path_49430);
    if (binary_op_a(NOTEQ, _25412, 2)){
        DeRef(_25412);
        _25412 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25412);
    _25412 = NOVALUE;

    /** coverage.e:188			sequence files = dir( path  )*/
    RefDS(_path_49430);
    _0 = _files_49439;
    _files_49439 = _15dir(_path_49430);
    DeRef(_0);

    /** coverage.e:190			for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_49439)){
            _25415 = SEQ_PTR(_files_49439)->length;
    }
    else {
        _25415 = 1;
    }
    {
        object _i_49443;
        _i_49443 = 1;
L2: 
        if (_i_49443 > _25415){
            goto L3; // [40] 206
        }

        /** coverage.e:191				if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (object)SEQ_PTR(_files_49439);
        _25416 = (object)*(((s1_ptr)_2)->base + _i_49443);
        _2 = (object)SEQ_PTR(_25416);
        _25417 = (object)*(((s1_ptr)_2)->base + 2);
        _25416 = NOVALUE;
        _25418 = find_from(100, _25417, 1);
        _25417 = NOVALUE;
        if (_25418 == 0)
        {
            _25418 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25418 = NOVALUE;
        }

        /** coverage.e:192					if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (object)SEQ_PTR(_files_49439);
        _25419 = (object)*(((s1_ptr)_2)->base + _i_49443);
        _2 = (object)SEQ_PTR(_25419);
        _25420 = (object)*(((s1_ptr)_2)->base + 1);
        _25419 = NOVALUE;
        RefDS(_23393);
        RefDS(_23394);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23394;
        ((intptr_t *)_2)[2] = _23393;
        _25421 = MAKE_SEQ(_1);
        _25422 = find_from(_25420, _25421, 1);
        _25420 = NOVALUE;
        DeRefDS(_25421);
        _25421 = NOVALUE;
        if (_25422 != 0)
        goto L5; // [88] 199
        _25422 = NOVALUE;

        /** coverage.e:193						add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (object)SEQ_PTR(_files_49439);
        _25424 = (object)*(((s1_ptr)_2)->base + _i_49443);
        _2 = (object)SEQ_PTR(_25424);
        _25425 = (object)*(((s1_ptr)_2)->base + 1);
        _25424 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25425;
            concat_list[1] = 92;
            concat_list[2] = _cover_this_49429;
            Concat_N((object_ptr)&_25426, concat_list, 3);
        }
        _25425 = NOVALUE;
        _50add_coverage(_25426);
        _25426 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** coverage.e:196				elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (object)SEQ_PTR(_files_49439);
        _25427 = (object)*(((s1_ptr)_2)->base + _i_49443);
        _2 = (object)SEQ_PTR(_25427);
        _25428 = (object)*(((s1_ptr)_2)->base + 1);
        _25427 = NOVALUE;
        Ref(_50eu_file_49411);
        Ref(_25428);
        _25429 = _51has_match(_50eu_file_49411, _25428, 1, 0);
        _25428 = NOVALUE;
        if (_25429 == 0) {
            DeRef(_25429);
            _25429 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25429) && DBL_PTR(_25429)->dbl == 0.0){
                DeRef(_25429);
                _25429 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25429);
            _25429 = NOVALUE;
        }
        DeRef(_25429);
        _25429 = NOVALUE;

        /** coverage.e:198					sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_49439);
        _25430 = (object)*(((s1_ptr)_2)->base + _i_49443);
        _2 = (object)SEQ_PTR(_25430);
        _25431 = (object)*(((s1_ptr)_2)->base + 1);
        _25430 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = _25431;
            concat_list[1] = 92;
            concat_list[2] = _path_49430;
            Concat_N((object_ptr)&_subpath_49467, concat_list, 3);
        }
        _25431 = NOVALUE;

        /** coverage.e:199					if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25433 = find_from(_subpath_49467, _50covered_files_49228, 1);
        _25434 = (_25433 == 0);
        _25433 = NOVALUE;
        if (_25434 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_49467);
        _25436 = _50excluded(_subpath_49467);
        if (IS_ATOM_INT(_25436)) {
            _25437 = (_25436 == 0);
        }
        else {
            _25437 = unary_op(NOT, _25436);
        }
        DeRef(_25436);
        _25436 = NOVALUE;
        if (_25437 == 0) {
            DeRef(_25437);
            _25437 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25437) && DBL_PTR(_25437)->dbl == 0.0){
                DeRef(_25437);
                _25437 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25437);
            _25437 = NOVALUE;
        }
        DeRef(_25437);
        _25437 = NOVALUE;

        /** coverage.e:200						new_covered_path( subpath )*/
        RefDS(_subpath_49467);
        _50new_covered_path(_subpath_49467);
L7: 
L6: 
        DeRef(_subpath_49467);
        _subpath_49467 = NOVALUE;
L5: 

        /** coverage.e:203			end for*/
        _i_49443 = _i_49443 + 1;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_49439);
    _files_49439 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** coverage.e:204		elsif regex:has_match( eu_file, path ) and*/
    Ref(_50eu_file_49411);
    RefDS(_path_49430);
    _25438 = _51has_match(_50eu_file_49411, _path_49430, 1, 0);
    if (IS_ATOM_INT(_25438)) {
        if (_25438 == 0) {
            DeRef(_25439);
            _25439 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25438)->dbl == 0.0) {
            DeRef(_25439);
            _25439 = 0;
            goto L9; // [222] 240
        }
    }
    _25440 = find_from(_path_49430, _50covered_files_49228, 1);
    _25441 = (_25440 == 0);
    _25440 = NOVALUE;
    DeRef(_25439);
    _25439 = (_25441 != 0);
L9: 
    if (_25439 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_49430);
    _25443 = _50excluded(_path_49430);
    if (IS_ATOM_INT(_25443)) {
        _25444 = (_25443 == 0);
    }
    else {
        _25444 = unary_op(NOT, _25443);
    }
    DeRef(_25443);
    _25443 = NOVALUE;
    if (_25444 == 0) {
        DeRef(_25444);
        _25444 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25444) && DBL_PTR(_25444)->dbl == 0.0){
            DeRef(_25444);
            _25444 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25444);
        _25444 = NOVALUE;
    }
    DeRef(_25444);
    _25444 = NOVALUE;

    /** coverage.e:207			new_covered_path( path )*/
    RefDS(_path_49430);
    _50new_covered_path(_path_49430);
LA: 
L8: 

    /** coverage.e:209	end procedure*/
    DeRefDS(_cover_this_49429);
    DeRef(_path_49430);
    DeRef(_25441);
    _25441 = NOVALUE;
    DeRef(_25434);
    _25434 = NOVALUE;
    DeRef(_25438);
    _25438 = NOVALUE;
    return;
    ;
}


object _50excluded(object _file_49491)
{
    object _25447 = NOVALUE;
    object _25446 = NOVALUE;
    object _25445 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:212		for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_50exclusion_patterns_49232)){
            _25445 = SEQ_PTR(_50exclusion_patterns_49232)->length;
    }
    else {
        _25445 = 1;
    }
    {
        object _i_49493;
        _i_49493 = 1;
L1: 
        if (_i_49493 > _25445){
            goto L2; // [10] 49
        }

        /** coverage.e:213			if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (object)SEQ_PTR(_50exclusion_patterns_49232);
        _25446 = (object)*(((s1_ptr)_2)->base + _i_49493);
        Ref(_25446);
        RefDS(_file_49491);
        _25447 = _51has_match(_25446, _file_49491, 1, 0);
        _25446 = NOVALUE;
        if (_25447 == 0) {
            DeRef(_25447);
            _25447 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25447) && DBL_PTR(_25447)->dbl == 0.0){
                DeRef(_25447);
                _25447 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25447);
            _25447 = NOVALUE;
        }
        DeRef(_25447);
        _25447 = NOVALUE;

        /** coverage.e:214				return 1*/
        DeRefDS(_file_49491);
        return 1;
L3: 

        /** coverage.e:216		end for*/
        _i_49493 = _i_49493 + 1;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** coverage.e:217		return 0*/
    DeRefDS(_file_49491);
    return 0;
    ;
}


void _50coverage_exclude(object _patterns_49500)
{
    object _ex_49505 = NOVALUE;
    object _fx_49512 = NOVALUE;
    object _25465 = NOVALUE;
    object _25464 = NOVALUE;
    object _25463 = NOVALUE;
    object _25462 = NOVALUE;
    object _25456 = NOVALUE;
    object _25455 = NOVALUE;
    object _25453 = NOVALUE;
    object _25451 = NOVALUE;
    object _25449 = NOVALUE;
    object _25448 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:221		for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_49500)){
            _25448 = SEQ_PTR(_patterns_49500)->length;
    }
    else {
        _25448 = 1;
    }
    {
        object _i_49502;
        _i_49502 = 1;
L1: 
        if (_i_49502 > _25448){
            goto L2; // [8] 163
        }

        /** coverage.e:222			regex ex = regex:new( patterns[i] )*/
        _2 = (object)SEQ_PTR(_patterns_49500);
        _25449 = (object)*(((s1_ptr)_2)->base + _i_49502);
        Ref(_25449);
        _0 = _ex_49505;
        _ex_49505 = _51new(_25449, 0);
        DeRef(_0);
        _25449 = NOVALUE;

        /** coverage.e:223			if regex( ex ) then*/
        Ref(_ex_49505);
        _25451 = _51regex(_ex_49505);
        if (_25451 == 0) {
            DeRef(_25451);
            _25451 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25451) && DBL_PTR(_25451)->dbl == 0.0){
                DeRef(_25451);
                _25451 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25451);
            _25451 = NOVALUE;
        }
        DeRef(_25451);
        _25451 = NOVALUE;

        /** coverage.e:224				exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_49505);
        Append(&_50exclusion_patterns_49232, _50exclusion_patterns_49232, _ex_49505);

        /** coverage.e:225				integer fx = 1*/
        _fx_49512 = 1;

        /** coverage.e:226				while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_50covered_files_49228)){
                _25453 = SEQ_PTR(_50covered_files_49228)->length;
        }
        else {
            _25453 = 1;
        }
        if (_fx_49512 > _25453)
        goto L5; // [58] 122

        /** coverage.e:227					if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (object)SEQ_PTR(_50covered_files_49228);
        _25455 = (object)*(((s1_ptr)_2)->base + _fx_49512);
        Ref(_ex_49505);
        Ref(_25455);
        _25456 = _51has_match(_ex_49505, _25455, 1, 0);
        _25455 = NOVALUE;
        if (_25456 == 0) {
            DeRef(_25456);
            _25456 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25456) && DBL_PTR(_25456)->dbl == 0.0){
                DeRef(_25456);
                _25456 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25456);
            _25456 = NOVALUE;
        }
        DeRef(_25456);
        _25456 = NOVALUE;

        /** coverage.e:228						covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50covered_files_49228);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49512)) ? _fx_49512 : (object)(DBL_PTR(_fx_49512)->dbl);
            int stop = (IS_ATOM_INT(_fx_49512)) ? _fx_49512 : (object)(DBL_PTR(_fx_49512)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50covered_files_49228), start, &_50covered_files_49228 );
                }
                else Tail(SEQ_PTR(_50covered_files_49228), stop+1, &_50covered_files_49228);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50covered_files_49228), start, &_50covered_files_49228);
            }
            else {
                assign_slice_seq = &assign_space;
                _50covered_files_49228 = Remove_elements(start, stop, (SEQ_PTR(_50covered_files_49228)->ref == 1));
            }
        }

        /** coverage.e:229						routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50routine_map_49234);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49512)) ? _fx_49512 : (object)(DBL_PTR(_fx_49512)->dbl);
            int stop = (IS_ATOM_INT(_fx_49512)) ? _fx_49512 : (object)(DBL_PTR(_fx_49512)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50routine_map_49234), start, &_50routine_map_49234 );
                }
                else Tail(SEQ_PTR(_50routine_map_49234), stop+1, &_50routine_map_49234);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50routine_map_49234), start, &_50routine_map_49234);
            }
            else {
                assign_slice_seq = &assign_space;
                _50routine_map_49234 = Remove_elements(start, stop, (SEQ_PTR(_50routine_map_49234)->ref == 1));
            }
        }

        /** coverage.e:230						line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50line_map_49233);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_49512)) ? _fx_49512 : (object)(DBL_PTR(_fx_49512)->dbl);
            int stop = (IS_ATOM_INT(_fx_49512)) ? _fx_49512 : (object)(DBL_PTR(_fx_49512)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50line_map_49233), start, &_50line_map_49233 );
                }
                else Tail(SEQ_PTR(_50line_map_49233), stop+1, &_50line_map_49233);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50line_map_49233), start, &_50line_map_49233);
            }
            else {
                assign_slice_seq = &assign_space;
                _50line_map_49233 = Remove_elements(start, stop, (SEQ_PTR(_50line_map_49233)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** coverage.e:232						fx += 1*/
        _fx_49512 = _fx_49512 + 1;

        /** coverage.e:234				end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 154
L3: 

        /** coverage.e:236				printf( 2,"%s\n", { GetMsgText( ERROR_CREATING_REGEX_FOR_COVERAGE_EXCLUSION_PATTERN_1, 1, {patterns[i]}) } )*/
        _2 = (object)SEQ_PTR(_patterns_49500);
        _25462 = (object)*(((s1_ptr)_2)->base + _i_49502);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25462);
        ((intptr_t*)_2)[1] = _25462;
        _25463 = MAKE_SEQ(_1);
        _25462 = NOVALUE;
        _25464 = _30GetMsgText(339, 1, _25463);
        _25463 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _25464;
        _25465 = MAKE_SEQ(_1);
        _25464 = NOVALUE;
        EPrintf(2, _25461, _25465);
        DeRefDS(_25465);
        _25465 = NOVALUE;
L7: 
        DeRef(_ex_49505);
        _ex_49505 = NOVALUE;

        /** coverage.e:238		end for*/
        _i_49502 = _i_49502 + 1;
        goto L1; // [158] 15
L2: 
        ;
    }

    /** coverage.e:240	end procedure*/
    DeRefDS(_patterns_49500);
    return;
    ;
}


void _50new_coverage_db()
{
    object _0, _1, _2;
    

    /** coverage.e:243		coverage_erase = 1*/
    _50coverage_erase_49231 = 1;

    /** coverage.e:244	end procedure*/
    return;
    ;
}


void _50include_line(object _line_number_49536)
{
    object _25466 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25466 = _50coverage_on();
    if (_25466 == 0) {
        DeRef(_25466);
        _25466 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25466) && DBL_PTR(_25466)->dbl == 0.0){
            DeRef(_25466);
            _25466 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25466);
        _25466 = NOVALUE;
    }
    DeRef(_25466);
    _25466 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _45emit_op(210);

    /** coverage.e:249			emit_addr( gline_number )*/
    _45emit_addr(_27gline_number_20576);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_50included_lines_49235, _50included_lines_49235, _line_number_49536);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _50include_routine()
{
    object _file_no_49552 = NOVALUE;
    object _25473 = NOVALUE;
    object _25472 = NOVALUE;
    object _25471 = NOVALUE;
    object _25469 = NOVALUE;
    object _25468 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25468 = _50coverage_on();
    if (_25468 == 0) {
        DeRef(_25468);
        _25468 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25468) && DBL_PTR(_25468)->dbl == 0.0){
            DeRef(_25468);
            _25468 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25468);
        _25468 = NOVALUE;
    }
    DeRef(_25468);
    _25468 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _45emit_op(211);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _45emit_addr(_27CurrentSub_20579);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25469 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_25469);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _file_no_49552 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _file_no_49552 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_file_no_49552)){
        _file_no_49552 = (object)DBL_PTR(_file_no_49552)->dbl;
    }
    _25469 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_49229);
    _25471 = (object)*(((s1_ptr)_2)->base + _file_no_49552);
    _2 = (object)SEQ_PTR(_50routine_map_49234);
    _25472 = (object)*(((s1_ptr)_2)->base + _25471);
    _25473 = _53sym_name(_27CurrentSub_20579);
    Ref(_25472);
    _34put(_25472, _25473, 0, 2, 0);
    _25472 = NOVALUE;
    _25473 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25471 = NOVALUE;
    return;
    ;
}


void _50process_lines()
{
    object _sline_49580 = NOVALUE;
    object _file_49584 = NOVALUE;
    object _line_49594 = NOVALUE;
    object _25491 = NOVALUE;
    object _25489 = NOVALUE;
    object _25488 = NOVALUE;
    object _25487 = NOVALUE;
    object _25486 = NOVALUE;
    object _25485 = NOVALUE;
    object _25483 = NOVALUE;
    object _25481 = NOVALUE;
    object _25480 = NOVALUE;
    object _25478 = NOVALUE;
    object _25477 = NOVALUE;
    object _25476 = NOVALUE;
    object _25474 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:267		if not length( included_lines ) then*/
    if (IS_SEQUENCE(_50included_lines_49235)){
            _25474 = SEQ_PTR(_50included_lines_49235)->length;
    }
    else {
        _25474 = 1;
    }
    if (_25474 != 0)
    goto L1; // [8] 17
    _25474 = NOVALUE;

    /** coverage.e:268			return*/
    return;
L1: 

    /** coverage.e:270		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _25476 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _25476 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _25477 = (object)*(((s1_ptr)_2)->base + _25476);
    _25478 = IS_ATOM(_25477);
    _25477 = NOVALUE;
    if (_25478 == 0)
    {
        _25478 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25478 = NOVALUE;
    }

    /** coverage.e:271			slist = s_expand( slist )*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L2: 

    /** coverage.e:273		for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_50included_lines_49235)){
            _25480 = SEQ_PTR(_50included_lines_49235)->length;
    }
    else {
        _25480 = 1;
    }
    {
        object _i_49578;
        _i_49578 = 1;
L3: 
        if (_i_49578 > _25480){
            goto L4; // [52] 157
        }

        /** coverage.e:274			sequence sline = slist[included_lines[i]]*/
        _2 = (object)SEQ_PTR(_50included_lines_49235);
        _25481 = (object)*(((s1_ptr)_2)->base + _i_49578);
        DeRef(_sline_49580);
        _2 = (object)SEQ_PTR(_27slist_20662);
        _sline_49580 = (object)*(((s1_ptr)_2)->base + _25481);
        Ref(_sline_49580);

        /** coverage.e:275			integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_sline_49580);
        _25483 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_50file_coverage_49229);
        if (!IS_ATOM_INT(_25483)){
            _file_49584 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25483)->dbl));
        }
        else{
            _file_49584 = (object)*(((s1_ptr)_2)->base + _25483);
        }

        /** coverage.e:276			if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_49584 == 0) {
            _25485 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_50line_map_49233)){
                _25486 = SEQ_PTR(_50line_map_49233)->length;
        }
        else {
            _25486 = 1;
        }
        _25487 = (_file_49584 <= _25486);
        _25486 = NOVALUE;
        _25485 = (_25487 != 0);
L5: 
        if (_25485 == 0) {
            goto L6; // [108] 146
        }
        _2 = (object)SEQ_PTR(_50line_map_49233);
        _25489 = (object)*(((s1_ptr)_2)->base + _file_49584);
        if (_25489 == 0) {
            _25489 = NOVALUE;
            goto L6; // [119] 146
        }
        else {
            if (!IS_ATOM_INT(_25489) && DBL_PTR(_25489)->dbl == 0.0){
                _25489 = NOVALUE;
                goto L6; // [119] 146
            }
            _25489 = NOVALUE;
        }
        _25489 = NOVALUE;

        /** coverage.e:277				integer line = sline[LINE]*/
        _2 = (object)SEQ_PTR(_sline_49580);
        _line_49594 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_line_49594))
        _line_49594 = (object)DBL_PTR(_line_49594)->dbl;

        /** coverage.e:278				map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (object)SEQ_PTR(_50line_map_49233);
        _25491 = (object)*(((s1_ptr)_2)->base + _file_49584);
        Ref(_25491);
        _34put(_25491, _line_49594, 0, 2, 0);
        _25491 = NOVALUE;
L6: 
        DeRef(_sline_49580);
        _sline_49580 = NOVALUE;

        /** coverage.e:280		end for*/
        _i_49578 = _i_49578 + 1;
        goto L3; // [152] 59
L4: 
        ;
    }

    /** coverage.e:281	end procedure*/
    DeRef(_25487);
    _25487 = NOVALUE;
    _25481 = NOVALUE;
    _25483 = NOVALUE;
    return;
    ;
}


object _50cover_line(object _gline_number_49600)
{
    object _sline_49610 = NOVALUE;
    object _file_49613 = NOVALUE;
    object _line_49618 = NOVALUE;
    object _25500 = NOVALUE;
    object _25497 = NOVALUE;
    object _25494 = NOVALUE;
    object _25493 = NOVALUE;
    object _25492 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_49600)) {
        _1 = (object)(DBL_PTR(_gline_number_49600)->dbl);
        DeRefDS(_gline_number_49600);
        _gline_number_49600 = _1;
    }

    /** coverage.e:284		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_27slist_20662)){
            _25492 = SEQ_PTR(_27slist_20662)->length;
    }
    else {
        _25492 = 1;
    }
    _2 = (object)SEQ_PTR(_27slist_20662);
    _25493 = (object)*(((s1_ptr)_2)->base + _25492);
    _25494 = IS_ATOM(_25493);
    _25493 = NOVALUE;
    if (_25494 == 0)
    {
        _25494 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25494 = NOVALUE;
    }

    /** coverage.e:285			slist = s_expand(slist)*/
    RefDS(_27slist_20662);
    _0 = _61s_expand(_27slist_20662);
    DeRefDS(_27slist_20662);
    _27slist_20662 = _0;
L1: 

    /** coverage.e:287		sequence sline = slist[gline_number]*/
    DeRef(_sline_49610);
    _2 = (object)SEQ_PTR(_27slist_20662);
    _sline_49610 = (object)*(((s1_ptr)_2)->base + _gline_number_49600);
    Ref(_sline_49610);

    /** coverage.e:288		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (object)SEQ_PTR(_sline_49610);
    _25497 = (object)*(((s1_ptr)_2)->base + 3);
    _2 = (object)SEQ_PTR(_50file_coverage_49229);
    if (!IS_ATOM_INT(_25497)){
        _file_49613 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25497)->dbl));
    }
    else{
        _file_49613 = (object)*(((s1_ptr)_2)->base + _25497);
    }

    /** coverage.e:289		if file then*/
    if (_file_49613 == 0)
    {
        goto L2; // [57] 84
    }
    else{
    }

    /** coverage.e:290			integer line = sline[LINE]*/
    _2 = (object)SEQ_PTR(_sline_49610);
    _line_49618 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_line_49618))
    _line_49618 = (object)DBL_PTR(_line_49618)->dbl;

    /** coverage.e:291			map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50line_map_49233);
    _25500 = (object)*(((s1_ptr)_2)->base + _file_49613);
    Ref(_25500);
    _34put(_25500, _line_49618, 1, 2, 0);
    _25500 = NOVALUE;
L2: 

    /** coverage.e:293		return 0*/
    DeRef(_sline_49610);
    _25497 = NOVALUE;
    return 0;
    ;
}


object _50cover_routine(object _sub_49625)
{
    object _file_no_49626 = NOVALUE;
    object _25505 = NOVALUE;
    object _25504 = NOVALUE;
    object _25503 = NOVALUE;
    object _25501 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_49625)) {
        _1 = (object)(DBL_PTR(_sub_49625)->dbl);
        DeRefDS(_sub_49625);
        _sub_49625 = _1;
    }

    /** coverage.e:297		integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _25501 = (object)*(((s1_ptr)_2)->base + _sub_49625);
    _2 = (object)SEQ_PTR(_25501);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _file_no_49626 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _file_no_49626 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    if (!IS_ATOM_INT(_file_no_49626)){
        _file_no_49626 = (object)DBL_PTR(_file_no_49626)->dbl;
    }
    _25501 = NOVALUE;

    /** coverage.e:298		map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (object)SEQ_PTR(_50file_coverage_49229);
    _25503 = (object)*(((s1_ptr)_2)->base + _file_no_49626);
    _2 = (object)SEQ_PTR(_50routine_map_49234);
    _25504 = (object)*(((s1_ptr)_2)->base + _25503);
    _25505 = _53sym_name(_sub_49625);
    Ref(_25504);
    _34put(_25504, _25505, 1, 2, 0);
    _25504 = NOVALUE;
    _25505 = NOVALUE;

    /** coverage.e:299		return 0*/
    _25503 = NOVALUE;
    return 0;
    ;
}



// 0x2394C865
