// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _28open_locked(object _file_path_11603)
{
    object _fh_11604 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:55		fh = open(file_path, "u")*/
    _fh_11604 = EOpen(_file_path_11603, _6510, 0);

    /** common.e:57		if fh = -1 then*/
    if (_fh_11604 != -1)
    goto L1; // [12] 24

    /** common.e:58			fh = open(file_path, "r")*/
    _fh_11604 = EOpen(_file_path_11603, _1317, 0);
L1: 

    /** common.e:61		return fh*/
    DeRefDS(_file_path_11603);
    return _fh_11604;
    ;
}


object _28get_eudir()
{
    object _possible_paths_11621 = NOVALUE;
    object _homepath_11626 = NOVALUE;
    object _homedrive_11628 = NOVALUE;
    object _possible_path_11651 = NOVALUE;
    object _possible_path_11665 = NOVALUE;
    object _file_check_11679 = NOVALUE;
    object _6561 = NOVALUE;
    object _6560 = NOVALUE;
    object _6559 = NOVALUE;
    object _6557 = NOVALUE;
    object _6555 = NOVALUE;
    object _6553 = NOVALUE;
    object _6552 = NOVALUE;
    object _6551 = NOVALUE;
    object _6550 = NOVALUE;
    object _6549 = NOVALUE;
    object _6547 = NOVALUE;
    object _6545 = NOVALUE;
    object _6544 = NOVALUE;
    object _6540 = NOVALUE;
    object _6538 = NOVALUE;
    object _6535 = NOVALUE;
    object _6534 = NOVALUE;
    object _6533 = NOVALUE;
    object _6532 = NOVALUE;
    object _6531 = NOVALUE;
    object _6530 = NOVALUE;
    object _6529 = NOVALUE;
    object _6528 = NOVALUE;
    object _6527 = NOVALUE;
    object _6516 = NOVALUE;
    object _6514 = NOVALUE;
    object _0, _1, _2;
    

    /** common.e:82		if sequence(eudir) then*/
    _6514 = IS_SEQUENCE(_28eudir_11599);
    if (_6514 == 0)
    {
        _6514 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _6514 = NOVALUE;
    }

    /** common.e:83			return eudir*/
    Ref(_28eudir_11599);
    DeRef(_possible_paths_11621);
    DeRefi(_homepath_11626);
    DeRefi(_homedrive_11628);
    return _28eudir_11599;
L1: 

    /** common.e:86		eudir = getenv("EUDIR")*/
    DeRef(_28eudir_11599);
    _28eudir_11599 = EGetEnv(_4812);

    /** common.e:87		if sequence(eudir) then*/
    _6516 = IS_SEQUENCE(_28eudir_11599);
    if (_6516 == 0)
    {
        _6516 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _6516 = NOVALUE;
    }

    /** common.e:88			return eudir*/
    Ref(_28eudir_11599);
    DeRef(_possible_paths_11621);
    DeRefi(_homepath_11626);
    DeRefi(_homedrive_11628);
    return _28eudir_11599;
L2: 

    /** common.e:91		ifdef UNIX then*/

    /** common.e:102			sequence possible_paths = {*/
    _0 = _possible_paths_11621;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_6521);
    ((intptr_t*)_2)[1] = _6521;
    RefDS(_6522);
    ((intptr_t*)_2)[2] = _6522;
    RefDS(_6523);
    ((intptr_t*)_2)[3] = _6523;
    _possible_paths_11621 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:107			object homepath = getenv("HOMEPATH")*/
    DeRefi(_homepath_11626);
    _homepath_11626 = EGetEnv(_4444);

    /** common.e:108			object homedrive = getenv("HOMEDRIVE")*/
    DeRefi(_homedrive_11628);
    _homedrive_11628 = EGetEnv(_4442);

    /** common.e:109			if sequence(homepath) and sequence(homedrive) then*/
    _6527 = IS_SEQUENCE(_homepath_11626);
    if (_6527 == 0) {
        goto L3; // [69] 134
    }
    _6529 = IS_SEQUENCE(_homedrive_11628);
    if (_6529 == 0)
    {
        _6529 = NOVALUE;
        goto L3; // [77] 134
    }
    else{
        _6529 = NOVALUE;
    }

    /** common.e:110				if length(homepath) and not equal(homepath[$], SLASH) then*/
    if (IS_SEQUENCE(_homepath_11626)){
            _6530 = SEQ_PTR(_homepath_11626)->length;
    }
    else {
        _6530 = 1;
    }
    if (_6530 == 0) {
        goto L4; // [85] 118
    }
    if (IS_SEQUENCE(_homepath_11626)){
            _6532 = SEQ_PTR(_homepath_11626)->length;
    }
    else {
        _6532 = 1;
    }
    _2 = (object)SEQ_PTR(_homepath_11626);
    _6533 = (object)*(((s1_ptr)_2)->base + _6532);
    if (_6533 == 92)
    _6534 = 1;
    else if (IS_ATOM_INT(_6533) && IS_ATOM_INT(92))
    _6534 = 0;
    else
    _6534 = (compare(_6533, 92) == 0);
    _6533 = NOVALUE;
    _6535 = (_6534 == 0);
    _6534 = NOVALUE;
    if (_6535 == 0)
    {
        DeRef(_6535);
        _6535 = NOVALUE;
        goto L4; // [106] 118
    }
    else{
        DeRef(_6535);
        _6535 = NOVALUE;
    }

    /** common.e:111					homepath &= SLASH*/
    if (IS_SEQUENCE(_homepath_11626) && IS_ATOM(92)) {
        Append(&_homepath_11626, _homepath_11626, 92);
    }
    else if (IS_ATOM(_homepath_11626) && IS_SEQUENCE(92)) {
    }
    else {
        Concat((object_ptr)&_homepath_11626, _homepath_11626, 92);
    }
L4: 

    /** common.e:114				possible_paths = append(possible_paths, homedrive & SLASH & homepath & "euphoria")*/
    {
        object concat_list[4];

        concat_list[0] = _6537;
        concat_list[1] = _homepath_11626;
        concat_list[2] = 92;
        concat_list[3] = _homedrive_11628;
        Concat_N((object_ptr)&_6538, concat_list, 4);
    }
    RefDS(_6538);
    Append(&_possible_paths_11621, _possible_paths_11621, _6538);
    DeRefDS(_6538);
    _6538 = NOVALUE;
L3: 

    /** common.e:118		for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_11621)){
            _6540 = SEQ_PTR(_possible_paths_11621)->length;
    }
    else {
        _6540 = 1;
    }
    {
        object _i_11649;
        _i_11649 = 1;
L5: 
        if (_i_11649 > _6540){
            goto L6; // [141] 200
        }

        /** common.e:119			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_11651);
        _2 = (object)SEQ_PTR(_possible_paths_11621);
        _possible_path_11651 = (object)*(((s1_ptr)_2)->base + _i_11649);
        RefDS(_possible_path_11651);

        /** common.e:121			if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            object concat_list[5];

            concat_list[0] = _6543;
            concat_list[1] = 92;
            concat_list[2] = _6542;
            concat_list[3] = 92;
            concat_list[4] = _possible_path_11651;
            Concat_N((object_ptr)&_6544, concat_list, 5);
        }
        _6545 = _15file_exists(_6544);
        _6544 = NOVALUE;
        if (_6545 == 0) {
            DeRef(_6545);
            _6545 = NOVALUE;
            goto L7; // [174] 191
        }
        else {
            if (!IS_ATOM_INT(_6545) && DBL_PTR(_6545)->dbl == 0.0){
                DeRef(_6545);
                _6545 = NOVALUE;
                goto L7; // [174] 191
            }
            DeRef(_6545);
            _6545 = NOVALUE;
        }
        DeRef(_6545);
        _6545 = NOVALUE;

        /** common.e:122				eudir = possible_path*/
        RefDS(_possible_path_11651);
        DeRef(_28eudir_11599);
        _28eudir_11599 = _possible_path_11651;

        /** common.e:123				return eudir*/
        RefDS(_28eudir_11599);
        DeRefDS(_possible_path_11651);
        DeRefDS(_possible_paths_11621);
        DeRefi(_homepath_11626);
        DeRefi(_homedrive_11628);
        return _28eudir_11599;
L7: 
        DeRef(_possible_path_11651);
        _possible_path_11651 = NOVALUE;

        /** common.e:125		end for*/
        _i_11649 = _i_11649 + 1;
        goto L5; // [195] 148
L6: 
        ;
    }

    /** common.e:127		possible_paths = include_paths(0)*/
    _0 = _possible_paths_11621;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_4835);
    ((intptr_t*)_2)[1] = _4835;
    RefDS(_4834);
    ((intptr_t*)_2)[2] = _4834;
    _possible_paths_11621 = MAKE_SEQ(_1);
    DeRef(_0);

    /** common.e:128		for i = 1 to length(possible_paths) do*/
    _6547 = 2;
    {
        object _i_11663;
        _i_11663 = 1;
L8: 
        if (_i_11663 > 2){
            goto L9; // [212] 337
        }

        /** common.e:129			sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_11665);
        _2 = (object)SEQ_PTR(_possible_paths_11621);
        _possible_path_11665 = (object)*(((s1_ptr)_2)->base + _i_11663);
        RefDS(_possible_path_11665);

        /** common.e:130			if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_11665)){
                _6549 = SEQ_PTR(_possible_path_11665)->length;
        }
        else {
            _6549 = 1;
        }
        _2 = (object)SEQ_PTR(_possible_path_11665);
        _6550 = (object)*(((s1_ptr)_2)->base + _6549);
        if (_6550 == 92)
        _6551 = 1;
        else if (IS_ATOM_INT(_6550) && IS_ATOM_INT(92))
        _6551 = 0;
        else
        _6551 = (compare(_6550, 92) == 0);
        _6550 = NOVALUE;
        if (_6551 == 0)
        {
            _6551 = NOVALUE;
            goto LA; // [242] 260
        }
        else{
            _6551 = NOVALUE;
        }

        /** common.e:131				possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_11665)){
                _6552 = SEQ_PTR(_possible_path_11665)->length;
        }
        else {
            _6552 = 1;
        }
        _6553 = _6552 - 1;
        _6552 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_11665;
        RHS_Slice(_possible_path_11665, 1, _6553);
LA: 

        /** common.e:134			if not ends("include", possible_path) then*/
        RefDS(_6542);
        RefDS(_possible_path_11665);
        _6555 = _14ends(_6542, _possible_path_11665);
        if (IS_ATOM_INT(_6555)) {
            if (_6555 != 0){
                DeRef(_6555);
                _6555 = NOVALUE;
                goto LB; // [267] 277
            }
        }
        else {
            if (DBL_PTR(_6555)->dbl != 0.0){
                DeRef(_6555);
                _6555 = NOVALUE;
                goto LB; // [267] 277
            }
        }
        DeRef(_6555);
        _6555 = NOVALUE;

        /** common.e:135				continue*/
        DeRefDS(_possible_path_11665);
        _possible_path_11665 = NOVALUE;
        DeRef(_file_check_11679);
        _file_check_11679 = NOVALUE;
        goto LC; // [274] 332
LB: 

        /** common.e:138			sequence file_check = possible_path*/
        RefDS(_possible_path_11665);
        DeRef(_file_check_11679);
        _file_check_11679 = _possible_path_11665;

        /** common.e:139			file_check &= SLASH & "euphoria.h"*/
        Prepend(&_6557, _6543, 92);
        Concat((object_ptr)&_file_check_11679, _file_check_11679, _6557);
        DeRefDS(_6557);
        _6557 = NOVALUE;

        /** common.e:141			if file_exists(file_check) then*/
        RefDS(_file_check_11679);
        _6559 = _15file_exists(_file_check_11679);
        if (_6559 == 0) {
            DeRef(_6559);
            _6559 = NOVALUE;
            goto LD; // [302] 328
        }
        else {
            if (!IS_ATOM_INT(_6559) && DBL_PTR(_6559)->dbl == 0.0){
                DeRef(_6559);
                _6559 = NOVALUE;
                goto LD; // [302] 328
            }
            DeRef(_6559);
            _6559 = NOVALUE;
        }
        DeRef(_6559);
        _6559 = NOVALUE;

        /** common.e:142				eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_11665)){
                _6560 = SEQ_PTR(_possible_path_11665)->length;
        }
        else {
            _6560 = 1;
        }
        _6561 = _6560 - 8;
        _6560 = NOVALUE;
        rhs_slice_target = (object_ptr)&_28eudir_11599;
        RHS_Slice(_possible_path_11665, 1, _6561);

        /** common.e:143				return eudir*/
        RefDS(_28eudir_11599);
        DeRefDS(_possible_path_11665);
        DeRefDS(_file_check_11679);
        DeRef(_possible_paths_11621);
        DeRefi(_homepath_11626);
        DeRefi(_homedrive_11628);
        DeRef(_6553);
        _6553 = NOVALUE;
        _6561 = NOVALUE;
        return _28eudir_11599;
LD: 
        DeRef(_possible_path_11665);
        _possible_path_11665 = NOVALUE;
        DeRef(_file_check_11679);
        _file_check_11679 = NOVALUE;

        /** common.e:145		end for*/
LC: 
        _i_11663 = _i_11663 + 1;
        goto L8; // [332] 219
L9: 
        ;
    }

    /** common.e:147		return ""*/
    RefDS(_5);
    DeRef(_possible_paths_11621);
    DeRefi(_homepath_11626);
    DeRefi(_homedrive_11628);
    DeRef(_6553);
    _6553 = NOVALUE;
    DeRef(_6561);
    _6561 = NOVALUE;
    return _5;
    ;
}


void _28set_eudir(object _new_eudir_11691)
{
    object _0, _1, _2;
    

    /** common.e:151		eudir = new_eudir*/
    RefDS(_new_eudir_11691);
    DeRef(_28eudir_11599);
    _28eudir_11599 = _new_eudir_11691;

    /** common.e:152		cmdline_eudir = 1*/
    _28cmdline_eudir_11600 = 1;

    /** common.e:153	end procedure*/
    DeRefDS(_new_eudir_11691);
    return;
    ;
}


object _28is_eudir_from_cmdline()
{
    object _0, _1, _2;
    

    /** common.e:156		return cmdline_eudir*/
    return _28cmdline_eudir_11600;
    ;
}



// 0x75374E4C
