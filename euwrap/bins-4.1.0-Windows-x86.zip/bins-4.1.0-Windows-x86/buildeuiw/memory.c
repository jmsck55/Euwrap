// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _8deallocate(object _addr_374)
{
    object _0, _1, _2;
    

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_374);

    /** memory.e:83	end procedure*/
    DeRef(_addr_374);
    return;
    ;
}


object _8prepare_block(object _addr_400, object _a_401, object _protection_402)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_401)) {
        _1 = (object)(DBL_PTR(_a_401)->dbl);
        DeRefDS(_a_401);
        _a_401 = _1;
    }

    /** memory.e:134		return addr*/
    return _addr_400;
    ;
}


object _8dep_works()
{
    object _74 = NOVALUE;
    object _0, _1, _2;
    

    /** memory.e:170		ifdef WINDOWS then*/

    /** memory.e:171			return (DEP_really_works and use_DEP)*/
    _74 = (_7DEP_really_works_315 != 0 && 1 != 0);
    return _74;

    /** memory.e:174		return 1*/
    _74 = NOVALUE;
    return 1;
    ;
}



// 0xF8348B6E
