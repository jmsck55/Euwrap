// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _43EndLineTable()
{
    object _0, _1, _2;
    

    /** parser.e:120		LineTable = append(LineTable, -2)*/
    Append(&_27LineTable_20661, _27LineTable_20661, -2);

    /** parser.e:121	end procedure*/
    return;
    ;
}


void _43CreateTopLevel()
{
    object _28083 = NOVALUE;
    object _28081 = NOVALUE;
    object _28079 = NOVALUE;
    object _28077 = NOVALUE;
    object _28075 = NOVALUE;
    object _28073 = NOVALUE;
    object _28071 = NOVALUE;
    object _28069 = NOVALUE;
    object _28067 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:125		SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28067 = NOVALUE;

    /** parser.e:126		SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28069 = NOVALUE;

    /** parser.e:127		SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _28071 = NOVALUE;

    /** parser.e:128		SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _28073 = NOVALUE;

    /** parser.e:129		SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _28075 = NOVALUE;

    /** parser.e:130		SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _28077 = NOVALUE;

    /** parser.e:131		SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _28079 = NOVALUE;

    /** parser.e:132		SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _28081 = NOVALUE;

    /** parser.e:133		SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _28083 = NOVALUE;

    /** parser.e:135		Start_block( PROC, TopLevelSub )*/
    _64Start_block(27, _27TopLevelSub_20578);

    /** parser.e:136	end procedure*/
    return;
    ;
}


void _43CheckForUndefinedGotoLabels()
{
    object _28097 = NOVALUE;
    object _28096 = NOVALUE;
    object _28093 = NOVALUE;
    object _28091 = NOVALUE;
    object _28089 = NOVALUE;
    object _28087 = NOVALUE;
    object _28086 = NOVALUE;
    object _28085 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:139		for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_27goto_delay_20682)){
            _28085 = SEQ_PTR(_27goto_delay_20682)->length;
    }
    else {
        _28085 = 1;
    }
    {
        object _i_55509;
        _i_55509 = 1;
L1: 
        if (_i_55509 > _28085){
            goto L2; // [8] 106
        }

        /** parser.e:140			if not equal(goto_delay[i],"") then*/
        _2 = (object)SEQ_PTR(_27goto_delay_20682);
        _28086 = (object)*(((s1_ptr)_2)->base + _i_55509);
        if (_28086 == _22209)
        _28087 = 1;
        else if (IS_ATOM_INT(_28086) && IS_ATOM_INT(_22209))
        _28087 = 0;
        else
        _28087 = (compare(_28086, _22209) == 0);
        _28086 = NOVALUE;
        if (_28087 != 0)
        goto L3; // [27] 99
        _28087 = NOVALUE;

        /** parser.e:141				line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55415);
        _28089 = (object)*(((s1_ptr)_2)->base + _i_55509);
        _2 = (object)SEQ_PTR(_28089);
        _27line_number_20572 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_27line_number_20572)){
            _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
        }
        _28089 = NOVALUE;

        /** parser.e:142				gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55415);
        _28091 = (object)*(((s1_ptr)_2)->base + _i_55509);
        _2 = (object)SEQ_PTR(_28091);
        _27gline_number_20576 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_27gline_number_20576)){
            _27gline_number_20576 = (object)DBL_PTR(_27gline_number_20576)->dbl;
        }
        _28091 = NOVALUE;

        /** parser.e:143				ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (object)SEQ_PTR(_43goto_line_55415);
        _28093 = (object)*(((s1_ptr)_2)->base + _i_55509);
        DeRef(_49ThisLine_49642);
        _2 = (object)SEQ_PTR(_28093);
        _49ThisLine_49642 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_49ThisLine_49642);
        _28093 = NOVALUE;

        /** parser.e:144				bp = length(ThisLine)*/
        if (IS_SEQUENCE(_49ThisLine_49642)){
                _49bp_49646 = SEQ_PTR(_49ThisLine_49642)->length;
        }
        else {
            _49bp_49646 = 1;
        }

        /** parser.e:145					CompileErr(UNKNOWN_LABEL_1, {goto_delay[i]})*/
        _2 = (object)SEQ_PTR(_27goto_delay_20682);
        _28096 = (object)*(((s1_ptr)_2)->base + _i_55509);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_28096);
        ((intptr_t*)_2)[1] = _28096;
        _28097 = MAKE_SEQ(_1);
        _28096 = NOVALUE;
        _49CompileErr(156, _28097, 0);
        _28097 = NOVALUE;
L3: 

        /** parser.e:147		end for*/
        _i_55509 = _i_55509 + 1;
        goto L1; // [101] 15
L2: 
        ;
    }

    /** parser.e:148	end procedure*/
    return;
    ;
}


void _43PushGoto()
{
    object _new_1__tmp_at88_55544 = NOVALUE;
    object _new_inlined_new_at_88_55543 = NOVALUE;
    object _28098 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:151		goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_43goto_addr_55417);
    ((intptr_t*)_2)[1] = _43goto_addr_55417;
    RefDS(_27goto_list_20683);
    ((intptr_t*)_2)[2] = _27goto_list_20683;
    RefDS(_43goto_labels_55416);
    ((intptr_t*)_2)[3] = _43goto_labels_55416;
    RefDS(_27goto_delay_20682);
    ((intptr_t*)_2)[4] = _27goto_delay_20682;
    RefDS(_43goto_line_55415);
    ((intptr_t*)_2)[5] = _43goto_line_55415;
    RefDS(_43goto_ref_55419);
    ((intptr_t*)_2)[6] = _43goto_ref_55419;
    RefDS(_43label_block_55420);
    ((intptr_t*)_2)[7] = _43label_block_55420;
    Ref(_43goto_init_55422);
    ((intptr_t*)_2)[8] = _43goto_init_55422;
    _28098 = MAKE_SEQ(_1);
    RefDS(_28098);
    Append(&_43goto_stack_55418, _43goto_stack_55418, _28098);
    DeRefDS(_28098);
    _28098 = NOVALUE;

    /** parser.e:152		goto_addr = {}*/
    RefDS(_22209);
    DeRefDS(_43goto_addr_55417);
    _43goto_addr_55417 = _22209;

    /** parser.e:153		goto_list = {}*/
    RefDS(_22209);
    DeRefDS(_27goto_list_20683);
    _27goto_list_20683 = _22209;

    /** parser.e:154		goto_labels = {}*/
    RefDS(_22209);
    DeRefDS(_43goto_labels_55416);
    _43goto_labels_55416 = _22209;

    /** parser.e:155		goto_delay = {}*/
    RefDS(_22209);
    DeRefDS(_27goto_delay_20682);
    _27goto_delay_20682 = _22209;

    /** parser.e:156		goto_line = {}*/
    RefDS(_22209);
    DeRefDS(_43goto_line_55415);
    _43goto_line_55415 = _22209;

    /** parser.e:157		goto_ref = {}*/
    RefDS(_22209);
    DeRefDS(_43goto_ref_55419);
    _43goto_ref_55419 = _22209;

    /** parser.e:158		label_block = {}*/
    RefDS(_22209);
    DeRefDS(_43label_block_55420);
    _43label_block_55420 = _22209;

    /** parser.e:159		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at88_55544;
    _new_1__tmp_at88_55544 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at88_55544);
    _0 = _35malloc(_new_1__tmp_at88_55544, 1);
    DeRef(_43goto_init_55422);
    _43goto_init_55422 = _0;
    DeRef(_new_1__tmp_at88_55544);
    _new_1__tmp_at88_55544 = NOVALUE;

    /** parser.e:160	end procedure*/
    return;
    ;
}


void _43PopGoto()
{
    object _28124 = NOVALUE;
    object _28122 = NOVALUE;
    object _28121 = NOVALUE;
    object _28119 = NOVALUE;
    object _28118 = NOVALUE;
    object _28116 = NOVALUE;
    object _28115 = NOVALUE;
    object _28113 = NOVALUE;
    object _28112 = NOVALUE;
    object _28110 = NOVALUE;
    object _28109 = NOVALUE;
    object _28107 = NOVALUE;
    object _28106 = NOVALUE;
    object _28104 = NOVALUE;
    object _28103 = NOVALUE;
    object _28101 = NOVALUE;
    object _28100 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:163		CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:164		goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28100 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28100 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28101 = (object)*(((s1_ptr)_2)->base + _28100);
    DeRef(_43goto_addr_55417);
    _2 = (object)SEQ_PTR(_28101);
    _43goto_addr_55417 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_43goto_addr_55417);
    _28101 = NOVALUE;

    /** parser.e:165		goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28103 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28103 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28104 = (object)*(((s1_ptr)_2)->base + _28103);
    DeRef(_27goto_list_20683);
    _2 = (object)SEQ_PTR(_28104);
    _27goto_list_20683 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_27goto_list_20683);
    _28104 = NOVALUE;

    /** parser.e:166		goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28106 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28106 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28107 = (object)*(((s1_ptr)_2)->base + _28106);
    DeRef(_43goto_labels_55416);
    _2 = (object)SEQ_PTR(_28107);
    _43goto_labels_55416 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_43goto_labels_55416);
    _28107 = NOVALUE;

    /** parser.e:167		goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28109 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28109 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28110 = (object)*(((s1_ptr)_2)->base + _28109);
    DeRef(_27goto_delay_20682);
    _2 = (object)SEQ_PTR(_28110);
    _27goto_delay_20682 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_27goto_delay_20682);
    _28110 = NOVALUE;

    /** parser.e:168		goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28112 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28112 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28113 = (object)*(((s1_ptr)_2)->base + _28112);
    DeRef(_43goto_line_55415);
    _2 = (object)SEQ_PTR(_28113);
    _43goto_line_55415 = (object)*(((s1_ptr)_2)->base + 5);
    Ref(_43goto_line_55415);
    _28113 = NOVALUE;

    /** parser.e:169		goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28115 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28115 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28116 = (object)*(((s1_ptr)_2)->base + _28115);
    DeRef(_43goto_ref_55419);
    _2 = (object)SEQ_PTR(_28116);
    _43goto_ref_55419 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_43goto_ref_55419);
    _28116 = NOVALUE;

    /** parser.e:170		label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28118 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28118 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28119 = (object)*(((s1_ptr)_2)->base + _28118);
    DeRef(_43label_block_55420);
    _2 = (object)SEQ_PTR(_28119);
    _43label_block_55420 = (object)*(((s1_ptr)_2)->base + 7);
    Ref(_43label_block_55420);
    _28119 = NOVALUE;

    /** parser.e:171		goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28121 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28121 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_stack_55418);
    _28122 = (object)*(((s1_ptr)_2)->base + _28121);
    DeRef(_43goto_init_55422);
    _2 = (object)SEQ_PTR(_28122);
    _43goto_init_55422 = (object)*(((s1_ptr)_2)->base + 8);
    Ref(_43goto_init_55422);
    _28122 = NOVALUE;

    /** parser.e:173		goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28124 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28124 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43goto_stack_55418);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28124)) ? _28124 : (object)(DBL_PTR(_28124)->dbl);
        int stop = (IS_ATOM_INT(_28124)) ? _28124 : (object)(DBL_PTR(_28124)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43goto_stack_55418), start, &_43goto_stack_55418 );
            }
            else Tail(SEQ_PTR(_43goto_stack_55418), stop+1, &_43goto_stack_55418);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43goto_stack_55418), start, &_43goto_stack_55418);
        }
        else {
            assign_slice_seq = &assign_space;
            _43goto_stack_55418 = Remove_elements(start, stop, (SEQ_PTR(_43goto_stack_55418)->ref == 1));
        }
    }
    _28124 = NOVALUE;
    _28124 = NOVALUE;

    /** parser.e:175	end procedure*/
    return;
    ;
}


void _43EnterTopLevel(object _end_line_table_55577)
{
    object _28143 = NOVALUE;
    object _28142 = NOVALUE;
    object _28140 = NOVALUE;
    object _28139 = NOVALUE;
    object _28137 = NOVALUE;
    object _28135 = NOVALUE;
    object _28133 = NOVALUE;
    object _28131 = NOVALUE;
    object _28130 = NOVALUE;
    object _28128 = NOVALUE;
    object _28126 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:179		if CurrentSub then*/
    if (_27CurrentSub_20579 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** parser.e:180			if end_line_table then*/
    if (_end_line_table_55577 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** parser.e:181				EndLineTable()*/
    _43EndLineTable();

    /** parser.e:182				SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _28126 = NOVALUE;

    /** parser.e:183				SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _28128 = NOVALUE;
L2: 
L1: 

    /** parser.e:186		if length(goto_stack) then*/
    if (IS_SEQUENCE(_43goto_stack_55418)){
            _28130 = SEQ_PTR(_43goto_stack_55418)->length;
    }
    else {
        _28130 = 1;
    }
    if (_28130 == 0)
    {
        _28130 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _28130 = NOVALUE;
    }

    /** parser.e:187			PopGoto()*/
    _43PopGoto();
L3: 

    /** parser.e:189		LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28131 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    DeRef(_27LineTable_20661);
    _2 = (object)SEQ_PTR(_28131);
    if (!IS_ATOM_INT(_27S_LINETAB_20244)){
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    }
    else{
        _27LineTable_20661 = (object)*(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    }
    Ref(_27LineTable_20661);
    _28131 = NOVALUE;

    /** parser.e:190		Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28133 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    DeRef(_27Code_20660);
    _2 = (object)SEQ_PTR(_28133);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _27Code_20660 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    Ref(_27Code_20660);
    _28133 = NOVALUE;

    /** parser.e:191		SymTab[TopLevelSub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28135 = NOVALUE;

    /** parser.e:192		SymTab[TopLevelSub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _28137 = NOVALUE;

    /** parser.e:193		previous_op = -1*/
    _27previous_op_20670 = -1;

    /** parser.e:194		CurrentSub = TopLevelSub*/
    _27CurrentSub_20579 = _27TopLevelSub_20578;

    /** parser.e:195		clear_last()*/
    _45clear_last();

    /** parser.e:196		if length( branch_stack ) then*/
    if (IS_SEQUENCE(_43branch_stack_55404)){
            _28139 = SEQ_PTR(_43branch_stack_55404)->length;
    }
    else {
        _28139 = 1;
    }
    if (_28139 == 0)
    {
        _28139 = NOVALUE;
        goto L4; // [171] 205
    }
    else{
        _28139 = NOVALUE;
    }

    /** parser.e:197			branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_43branch_stack_55404)){
            _28140 = SEQ_PTR(_43branch_stack_55404)->length;
    }
    else {
        _28140 = 1;
    }
    DeRef(_43branch_list_55403);
    _2 = (object)SEQ_PTR(_43branch_stack_55404);
    _43branch_list_55403 = (object)*(((s1_ptr)_2)->base + _28140);
    Ref(_43branch_list_55403);

    /** parser.e:198			branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_43branch_stack_55404)){
            _28142 = SEQ_PTR(_43branch_stack_55404)->length;
    }
    else {
        _28142 = 1;
    }
    _28143 = _28142 - 1;
    _28142 = NOVALUE;
    {
        int len = SEQ_PTR(_43branch_stack_55404)->length;
        int size = (IS_ATOM_INT(_28143)) ? _28143 : (object)(DBL_PTR(_28143)->dbl);
        if (size <= 0) {
            DeRef(_43branch_stack_55404);
            _43branch_stack_55404 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_43branch_stack_55404);
            DeRef(_43branch_stack_55404);
            _43branch_stack_55404 = _43branch_stack_55404;
        }
        else Tail(SEQ_PTR(_43branch_stack_55404), len-size+1, &_43branch_stack_55404);
    }
    _28143 = NOVALUE;
L4: 

    /** parser.e:200	end procedure*/
    return;
    ;
}


void _43LeaveTopLevel()
{
    object _28148 = NOVALUE;
    object _28146 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:204		branch_stack = append( branch_stack, branch_list )*/
    RefDS(_43branch_list_55403);
    Append(&_43branch_stack_55404, _43branch_stack_55404, _43branch_list_55403);

    /** parser.e:205		branch_list = {}*/
    RefDS(_22209);
    DeRefDS(_43branch_list_55403);
    _43branch_list_55403 = _22209;

    /** parser.e:206		PushGoto()*/
    _43PushGoto();

    /** parser.e:207		LastLineNumber = -1*/
    _61LastLineNumber_25929 = -1;

    /** parser.e:208		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _28146 = NOVALUE;

    /** parser.e:209		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _28148 = NOVALUE;

    /** parser.e:210		LineTable = {}*/
    RefDS(_22209);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22209;

    /** parser.e:211		Code = {}*/
    RefDS(_22209);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _22209;

    /** parser.e:212		previous_op = -1*/
    _27previous_op_20670 = -1;

    /** parser.e:213		clear_last()*/
    _45clear_last();

    /** parser.e:214	end procedure*/
    return;
    ;
}


void _43InitParser()
{
    object _new_1__tmp_at195_55653 = NOVALUE;
    object _new_inlined_new_at_195_55652 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:217		goto_stack = {}*/
    RefDS(_22209);
    DeRef(_43goto_stack_55418);
    _43goto_stack_55418 = _22209;

    /** parser.e:220		goto_labels = {}*/
    RefDS(_22209);
    DeRef(_43goto_labels_55416);
    _43goto_labels_55416 = _22209;

    /** parser.e:221		label_block = {}*/
    RefDS(_22209);
    DeRef(_43label_block_55420);
    _43label_block_55420 = _22209;

    /** parser.e:222		goto_ref = {}*/
    RefDS(_22209);
    DeRef(_43goto_ref_55419);
    _43goto_ref_55419 = _22209;

    /** parser.e:223		goto_addr = {}*/
    RefDS(_22209);
    DeRef(_43goto_addr_55417);
    _43goto_addr_55417 = _22209;

    /** parser.e:224		goto_line = {}*/
    RefDS(_22209);
    DeRef(_43goto_line_55415);
    _43goto_line_55415 = _22209;

    /** parser.e:225		break_list = {}*/
    RefDS(_22209);
    DeRefi(_43break_list_55423);
    _43break_list_55423 = _22209;

    /** parser.e:226		break_delay = {}*/
    RefDS(_22209);
    DeRef(_43break_delay_55424);
    _43break_delay_55424 = _22209;

    /** parser.e:227		exit_list = {}*/
    RefDS(_22209);
    DeRefi(_43exit_list_55425);
    _43exit_list_55425 = _22209;

    /** parser.e:228		exit_delay = {}*/
    RefDS(_22209);
    DeRef(_43exit_delay_55426);
    _43exit_delay_55426 = _22209;

    /** parser.e:229		continue_list = {}*/
    RefDS(_22209);
    DeRefi(_43continue_list_55427);
    _43continue_list_55427 = _22209;

    /** parser.e:230		continue_delay = {}*/
    RefDS(_22209);
    DeRef(_43continue_delay_55428);
    _43continue_delay_55428 = _22209;

    /** parser.e:231		init_stack = {}*/
    RefDS(_22209);
    DeRefi(_43init_stack_55438);
    _43init_stack_55438 = _22209;

    /** parser.e:232		CurrentSub = 0*/
    _27CurrentSub_20579 = 0;

    /** parser.e:233		CreateTopLevel()*/
    _43CreateTopLevel();

    /** parser.e:234		EnterTopLevel()*/
    _43EnterTopLevel(1);

    /** parser.e:235		backed_up_tok = {}*/
    RefDS(_22209);
    DeRef(_43backed_up_tok_55412);
    _43backed_up_tok_55412 = _22209;

    /** parser.e:236		loop_stack = {}*/
    RefDS(_22209);
    DeRefi(_43loop_stack_55439);
    _43loop_stack_55439 = _22209;

    /** parser.e:237		stmt_nest = 0*/
    _43stmt_nest_55437 = 0;

    /** parser.e:238		loop_labels = {}*/
    RefDS(_22209);
    DeRef(_43loop_labels_55433);
    _43loop_labels_55433 = _22209;

    /** parser.e:239		if_labels = {}*/
    RefDS(_22209);
    DeRef(_43if_labels_55434);
    _43if_labels_55434 = _22209;

    /** parser.e:240		if_stack = {}*/
    RefDS(_22209);
    DeRefi(_43if_stack_55440);
    _43if_stack_55440 = _22209;

    /** parser.e:241		continue_addr = {}*/
    RefDS(_22209);
    DeRefi(_43continue_addr_55430);
    _43continue_addr_55430 = _22209;

    /** parser.e:242		retry_addr = {}*/
    RefDS(_22209);
    DeRefi(_43retry_addr_55431);
    _43retry_addr_55431 = _22209;

    /** parser.e:243		entry_addr = {}*/
    RefDS(_22209);
    DeRefi(_43entry_addr_55429);
    _43entry_addr_55429 = _22209;

    /** parser.e:244		block_list = {}*/
    RefDS(_22209);
    DeRefi(_43block_list_55435);
    _43block_list_55435 = _22209;

    /** parser.e:245		block_index = 0*/
    _43block_index_55436 = 0;

    /** parser.e:246		param_num = -1*/
    _43param_num_55414 = -1;

    /** parser.e:247		entry_stack = {}*/
    RefDS(_22209);
    DeRef(_43entry_stack_55432);
    _43entry_stack_55432 = _22209;

    /** parser.e:248		goto_init = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at195_55653;
    _new_1__tmp_at195_55653 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at195_55653);
    _0 = _35malloc(_new_1__tmp_at195_55653, 1);
    DeRef(_43goto_init_55422);
    _43goto_init_55422 = _0;
    DeRef(_new_1__tmp_at195_55653);
    _new_1__tmp_at195_55653 = NOVALUE;

    /** parser.e:249	end procedure*/
    return;
    ;
}


void _43NotReached(object _tok_55670, object _keyword_55671)
{
    object _28163 = NOVALUE;
    object _28162 = NOVALUE;
    object _28161 = NOVALUE;
    object _28160 = NOVALUE;
    object _28159 = NOVALUE;
    object _28158 = NOVALUE;
    object _28156 = NOVALUE;
    object _28155 = NOVALUE;
    object _28154 = NOVALUE;
    object _28153 = NOVALUE;
    object _28151 = NOVALUE;
    object _28150 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_55670)) {
        _1 = (object)(DBL_PTR(_tok_55670)->dbl);
        DeRefDS(_tok_55670);
        _tok_55670 = _1;
    }

    /** parser.e:271		if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 402;
    ((intptr_t*)_2)[2] = 23;
    ((intptr_t*)_2)[3] = 414;
    ((intptr_t*)_2)[4] = -21;
    ((intptr_t*)_2)[5] = 186;
    ((intptr_t*)_2)[6] = 407;
    ((intptr_t*)_2)[7] = 408;
    ((intptr_t*)_2)[8] = 409;
    _28150 = MAKE_SEQ(_1);
    _28151 = find_from(_tok_55670, _28150, 1);
    DeRefDS(_28150);
    _28150 = NOVALUE;
    if (_28151 != 0)
    goto L1; // [39] 135
    _28151 = NOVALUE;

    /** parser.e:272			if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_55671 == _26490)
    _28153 = 1;
    else if (IS_ATOM_INT(_keyword_55671) && IS_ATOM_INT(_26490))
    _28153 = 0;
    else
    _28153 = (compare(_keyword_55671, _26490) == 0);
    if (_28153 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 422;
    ((intptr_t*)_2)[2] = 419;
    ((intptr_t*)_2)[3] = 47;
    _28155 = MAKE_SEQ(_1);
    _28156 = find_from(_tok_55670, _28155, 1);
    DeRefDS(_28155);
    _28155 = NOVALUE;
    if (_28156 == 0)
    {
        _28156 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _28156 = NOVALUE;
    }

    /** parser.e:273				return*/
    DeRefDSi(_keyword_55671);
    return;
L2: 

    /** parser.e:275			if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_55671 == _28157)
    _28158 = 1;
    else if (IS_ATOM_INT(_keyword_55671) && IS_ATOM_INT(_28157))
    _28158 = 0;
    else
    _28158 = (compare(_keyword_55671, _28157) == 0);
    if (_28158 == 0) {
        goto L3; // [85] 105
    }
    _28160 = (_tok_55670 == 419);
    if (_28160 == 0)
    {
        DeRef(_28160);
        _28160 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_28160);
        _28160 = NOVALUE;
    }

    /** parser.e:278				return*/
    DeRefDSi(_keyword_55671);
    return;
L3: 

    /** parser.e:280			Warning(218, not_reached_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _28161 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_28161);
    _28162 = _53name_ext(_28161);
    _28161 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28162;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_keyword_55671);
    ((intptr_t*)_2)[3] = _keyword_55671;
    _28163 = MAKE_SEQ(_1);
    _28162 = NOVALUE;
    _49Warning(218, 512, _28163);
    _28163 = NOVALUE;
L1: 

    /** parser.e:285	end procedure*/
    DeRefDSi(_keyword_55671);
    return;
    ;
}


void _43Forward_InitCheck(object _tok_55710, object _ref_55711)
{
    object _sym_55713 = NOVALUE;
    object _28169 = NOVALUE;
    object _28168 = NOVALUE;
    object _28167 = NOVALUE;
    object _28165 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:289		if ref then*/
    if (_ref_55711 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** parser.e:290			integer sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_55710);
    _sym_55713 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55713)){
        _sym_55713 = (object)DBL_PTR(_sym_55713)->dbl;
    }

    /** parser.e:291			if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_55710);
    _28165 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28165, 512)){
        _28165 = NOVALUE;
        goto L2; // [28] 50
    }
    _28165 = NOVALUE;

    /** parser.e:292				set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28167 = (object)*(((s1_ptr)_2)->base + _sym_55713);
    _2 = (object)SEQ_PTR(_28167);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _28168 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _28168 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _28167 = NOVALUE;
    Ref(_28168);
    _61set_qualified_fwd(_28168);
    _28168 = NOVALUE;
L2: 

    /** parser.e:294			ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (object)SEQ_PTR(_tok_55710);
    _28169 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28169);
    _ref_55711 = _42new_forward_reference(109, _28169, 109);
    _28169 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55711)) {
        _1 = (object)(DBL_PTR(_ref_55711)->dbl);
        DeRefDS(_ref_55711);
        _ref_55711 = _1;
    }

    /** parser.e:296			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109);

    /** parser.e:297			emit_addr( sym )*/
    _45emit_addr(_sym_55713);
L1: 

    /** parser.e:299	end procedure*/
    DeRef(_tok_55710);
    return;
    ;
}


void _43InitCheck(object _sym_55738, object _ref_55739)
{
    object _28246 = NOVALUE;
    object _28245 = NOVALUE;
    object _28244 = NOVALUE;
    object _28243 = NOVALUE;
    object _28242 = NOVALUE;
    object _28241 = NOVALUE;
    object _28240 = NOVALUE;
    object _28239 = NOVALUE;
    object _28237 = NOVALUE;
    object _28235 = NOVALUE;
    object _28234 = NOVALUE;
    object _28232 = NOVALUE;
    object _28231 = NOVALUE;
    object _28230 = NOVALUE;
    object _28229 = NOVALUE;
    object _28228 = NOVALUE;
    object _28227 = NOVALUE;
    object _28226 = NOVALUE;
    object _28225 = NOVALUE;
    object _28224 = NOVALUE;
    object _28223 = NOVALUE;
    object _28222 = NOVALUE;
    object _28221 = NOVALUE;
    object _28220 = NOVALUE;
    object _28219 = NOVALUE;
    object _28217 = NOVALUE;
    object _28216 = NOVALUE;
    object _28215 = NOVALUE;
    object _28214 = NOVALUE;
    object _28213 = NOVALUE;
    object _28212 = NOVALUE;
    object _28211 = NOVALUE;
    object _28210 = NOVALUE;
    object _28209 = NOVALUE;
    object _28207 = NOVALUE;
    object _28206 = NOVALUE;
    object _28205 = NOVALUE;
    object _28204 = NOVALUE;
    object _28203 = NOVALUE;
    object _28202 = NOVALUE;
    object _28201 = NOVALUE;
    object _28200 = NOVALUE;
    object _28199 = NOVALUE;
    object _28198 = NOVALUE;
    object _28197 = NOVALUE;
    object _28196 = NOVALUE;
    object _28195 = NOVALUE;
    object _28194 = NOVALUE;
    object _28193 = NOVALUE;
    object _28192 = NOVALUE;
    object _28191 = NOVALUE;
    object _28190 = NOVALUE;
    object _28189 = NOVALUE;
    object _28188 = NOVALUE;
    object _28187 = NOVALUE;
    object _28186 = NOVALUE;
    object _28184 = NOVALUE;
    object _28183 = NOVALUE;
    object _28182 = NOVALUE;
    object _28181 = NOVALUE;
    object _28180 = NOVALUE;
    object _28179 = NOVALUE;
    object _28178 = NOVALUE;
    object _28177 = NOVALUE;
    object _28176 = NOVALUE;
    object _28175 = NOVALUE;
    object _28174 = NOVALUE;
    object _28173 = NOVALUE;
    object _28171 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:306		if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _28171 = (_sym_55738 < 0);
    if (_28171 != 0) {
        goto L1; // [11] 90
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28173 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28173);
    _28174 = (object)*(((s1_ptr)_2)->base + 3);
    _28173 = NOVALUE;
    if (IS_ATOM_INT(_28174)) {
        _28175 = (_28174 == 1);
    }
    else {
        _28175 = binary_op(EQUALS, _28174, 1);
    }
    _28174 = NOVALUE;
    if (IS_ATOM_INT(_28175)) {
        if (_28175 == 0) {
            _28176 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_28175)->dbl == 0.0) {
            _28176 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28177 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28177);
    _28178 = (object)*(((s1_ptr)_2)->base + 4);
    _28177 = NOVALUE;
    if (IS_ATOM_INT(_28178)) {
        _28179 = (_28178 != 2);
    }
    else {
        _28179 = binary_op(NOTEQ, _28178, 2);
    }
    _28178 = NOVALUE;
    DeRef(_28176);
    if (IS_ATOM_INT(_28179))
    _28176 = (_28179 != 0);
    else
    _28176 = DBL_PTR(_28179)->dbl != 0.0;
L2: 
    if (_28176 == 0) {
        DeRef(_28180);
        _28180 = 0;
        goto L3; // [59] 85
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28181 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28181);
    _28182 = (object)*(((s1_ptr)_2)->base + 4);
    _28181 = NOVALUE;
    if (IS_ATOM_INT(_28182)) {
        _28183 = (_28182 != 4);
    }
    else {
        _28183 = binary_op(NOTEQ, _28182, 4);
    }
    _28182 = NOVALUE;
    if (IS_ATOM_INT(_28183))
    _28180 = (_28183 != 0);
    else
    _28180 = DBL_PTR(_28183)->dbl != 0.0;
L3: 
    if (_28180 == 0)
    {
        _28180 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _28180 = NOVALUE;
    }
L1: 

    /** parser.e:309			if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _28184 = (_sym_55738 < 0);
    if (_28184 != 0) {
        goto L5; // [96] 213
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28186 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28186);
    _28187 = (object)*(((s1_ptr)_2)->base + 4);
    _28186 = NOVALUE;
    if (IS_ATOM_INT(_28187)) {
        _28188 = (_28187 != 3);
    }
    else {
        _28188 = binary_op(NOTEQ, _28187, 3);
    }
    _28187 = NOVALUE;
    if (IS_ATOM_INT(_28188)) {
        if (_28188 == 0) {
            DeRef(_28189);
            _28189 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_28188)->dbl == 0.0) {
            DeRef(_28189);
            _28189 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28190 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28190);
    _28191 = (object)*(((s1_ptr)_2)->base + 1);
    _28190 = NOVALUE;
    if (_28191 == _27NOVALUE_20426)
    _28192 = 1;
    else if (IS_ATOM_INT(_28191) && IS_ATOM_INT(_27NOVALUE_20426))
    _28192 = 0;
    else
    _28192 = (compare(_28191, _27NOVALUE_20426) == 0);
    _28191 = NOVALUE;
    DeRef(_28189);
    _28189 = (_28192 != 0);
L6: 
    if (_28189 != 0) {
        DeRef(_28193);
        _28193 = 1;
        goto L7; // [144] 208
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28194 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28194);
    _28195 = (object)*(((s1_ptr)_2)->base + 4);
    _28194 = NOVALUE;
    if (IS_ATOM_INT(_28195)) {
        _28196 = (_28195 == 3);
    }
    else {
        _28196 = binary_op(EQUALS, _28195, 3);
    }
    _28195 = NOVALUE;
    if (IS_ATOM_INT(_28196)) {
        if (_28196 == 0) {
            DeRef(_28197);
            _28197 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_28196)->dbl == 0.0) {
            DeRef(_28197);
            _28197 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28198 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28198);
    _28199 = (object)*(((s1_ptr)_2)->base + 16);
    _28198 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28200 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_28200);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _28201 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _28201 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _28200 = NOVALUE;
    if (IS_ATOM_INT(_28199) && IS_ATOM_INT(_28201)) {
        _28202 = (_28199 >= _28201);
    }
    else {
        _28202 = binary_op(GREATEREQ, _28199, _28201);
    }
    _28199 = NOVALUE;
    _28201 = NOVALUE;
    DeRef(_28197);
    if (IS_ATOM_INT(_28202))
    _28197 = (_28202 != 0);
    else
    _28197 = DBL_PTR(_28202)->dbl != 0.0;
L8: 
    DeRef(_28193);
    _28193 = (_28197 != 0);
L7: 
    if (_28193 == 0)
    {
        _28193 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _28193 = NOVALUE;
    }
L5: 

    /** parser.e:313				if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _28203 = (_sym_55738 < 0);
    if (_28203 != 0) {
        _28204 = 1;
        goto LA; // [219] 243
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28205 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28205);
    _28206 = (object)*(((s1_ptr)_2)->base + 14);
    _28205 = NOVALUE;
    if (IS_ATOM_INT(_28206)) {
        _28207 = (_28206 == -1);
    }
    else {
        _28207 = binary_op(EQUALS, _28206, -1);
    }
    _28206 = NOVALUE;
    if (IS_ATOM_INT(_28207))
    _28204 = (_28207 != 0);
    else
    _28204 = DBL_PTR(_28207)->dbl != 0.0;
LA: 
    if (_28204 != 0) {
        goto LB; // [243] 270
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28209 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28209);
    _28210 = (object)*(((s1_ptr)_2)->base + 4);
    _28209 = NOVALUE;
    if (IS_ATOM_INT(_28210)) {
        _28211 = (_28210 != 3);
    }
    else {
        _28211 = binary_op(NOTEQ, _28210, 3);
    }
    _28210 = NOVALUE;
    if (_28211 == 0) {
        DeRef(_28211);
        _28211 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_28211) && DBL_PTR(_28211)->dbl == 0.0){
            DeRef(_28211);
            _28211 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_28211);
        _28211 = NOVALUE;
    }
    DeRef(_28211);
    _28211 = NOVALUE;
LB: 

    /** parser.e:316					if ref then*/
    if (_ref_55739 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** parser.e:317						if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _28212 = (_sym_55738 > 0);
    if (_28212 == 0) {
        goto LD; // [281] 317
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28214 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28214);
    _28215 = (object)*(((s1_ptr)_2)->base + 4);
    _28214 = NOVALUE;
    if (IS_ATOM_INT(_28215)) {
        _28216 = (_28215 == 9);
    }
    else {
        _28216 = binary_op(EQUALS, _28215, 9);
    }
    _28215 = NOVALUE;
    if (_28216 == 0) {
        DeRef(_28216);
        _28216 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_28216) && DBL_PTR(_28216)->dbl == 0.0){
            DeRef(_28216);
            _28216 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_28216);
        _28216 = NOVALUE;
    }
    DeRef(_28216);
    _28216 = NOVALUE;

    /** parser.e:318							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30);
    goto LE; // [314] 369
LD: 

    /** parser.e:319						elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _28217 = (_sym_55738 < 0);
    if (_28217 != 0) {
        goto LF; // [323] 351
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28219 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28219);
    _28220 = (object)*(((s1_ptr)_2)->base + 4);
    _28219 = NOVALUE;
    _28221 = find_from(_28220, _43SCOPE_TYPES_55396, 1);
    _28220 = NOVALUE;
    if (_28221 == 0)
    {
        _28221 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _28221 = NOVALUE;
    }
LF: 

    /** parser.e:320							emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _45emit_op(109);
    goto LE; // [358] 369
L10: 

    /** parser.e:322							emit_op(PRIVATE_INIT_CHECK)*/
    _45emit_op(30);
LE: 

    /** parser.e:324						emit_addr(sym)*/
    _45emit_addr(_sym_55738);
LC: 

    /** parser.e:326					if sym > 0 */
    _28222 = (_sym_55738 > 0);
    if (_28222 == 0) {
        _28223 = 0;
        goto L11; // [381] 411
    }
    _28224 = (_43short_circuit_55405 <= 0);
    if (_28224 != 0) {
        _28225 = 1;
        goto L12; // [391] 407
    }
    _28226 = (_43short_circuit_B_55407 == _9FALSE_439);
    _28225 = (_28226 != 0);
L12: 
    _28223 = (_28225 != 0);
L11: 
    if (_28223 == 0) {
        goto L9; // [411] 566
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28228 = (object)*(((s1_ptr)_2)->base + _sym_55738);
    _2 = (object)SEQ_PTR(_28228);
    _28229 = (object)*(((s1_ptr)_2)->base + 4);
    _28228 = NOVALUE;
    if (IS_ATOM_INT(_28229)) {
        _28230 = (_28229 != 3);
    }
    else {
        _28230 = binary_op(NOTEQ, _28229, 3);
    }
    _28229 = NOVALUE;
    if (IS_ATOM_INT(_28230)) {
        _28231 = (_28230 == 0);
    }
    else {
        _28231 = unary_op(NOT, _28230);
    }
    DeRef(_28230);
    _28230 = NOVALUE;
    if (_28231 == 0) {
        DeRef(_28231);
        _28231 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_28231) && DBL_PTR(_28231)->dbl == 0.0){
            DeRef(_28231);
            _28231 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_28231);
        _28231 = NOVALUE;
    }
    DeRef(_28231);
    _28231 = NOVALUE;

    /** parser.e:330						if CurrentSub != TopLevelSub */
    _28232 = (_27CurrentSub_20579 != _27TopLevelSub_20578);
    if (_28232 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_28known_files_11573)){
            _28234 = SEQ_PTR(_28known_files_11573)->length;
    }
    else {
        _28234 = 1;
    }
    _28235 = (_27current_file_no_20571 == _28234);
    _28234 = NOVALUE;
    if (_28235 == 0)
    {
        DeRef(_28235);
        _28235 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_28235);
        _28235 = NOVALUE;
    }
L13: 

    /** parser.e:335							init_stack = append(init_stack, sym)*/
    Append(&_43init_stack_55438, _43init_stack_55438, _sym_55738);

    /** parser.e:336							SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_55738 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43stmt_nest_55437;
    DeRef(_1);
    _28237 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** parser.e:343		elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_55739 == 0) {
        _28239 = 0;
        goto L14; // [504] 516
    }
    _28240 = (_sym_55738 > 0);
    _28239 = (_28240 != 0);
L14: 
    if (_28239 == 0) {
        _28241 = 0;
        goto L15; // [516] 534
    }
    _28242 = _53sym_mode(_sym_55738);
    if (IS_ATOM_INT(_28242)) {
        _28243 = (_28242 == 2);
    }
    else {
        _28243 = binary_op(EQUALS, _28242, 2);
    }
    DeRef(_28242);
    _28242 = NOVALUE;
    if (IS_ATOM_INT(_28243))
    _28241 = (_28243 != 0);
    else
    _28241 = DBL_PTR(_28243)->dbl != 0.0;
L15: 
    if (_28241 == 0) {
        goto L16; // [534] 565
    }
    _28245 = _53sym_obj(_sym_55738);
    if (_27NOVALUE_20426 == _28245)
    _28246 = 1;
    else if (IS_ATOM_INT(_27NOVALUE_20426) && IS_ATOM_INT(_28245))
    _28246 = 0;
    else
    _28246 = (compare(_27NOVALUE_20426, _28245) == 0);
    DeRef(_28245);
    _28245 = NOVALUE;
    if (_28246 == 0)
    {
        _28246 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _28246 = NOVALUE;
    }

    /** parser.e:344			emit_op( GLOBAL_INIT_CHECK )*/
    _45emit_op(109);

    /** parser.e:345			emit_addr(sym)*/
    _45emit_addr(_sym_55738);
L16: 
L9: 

    /** parser.e:349	end procedure*/
    DeRef(_28175);
    _28175 = NOVALUE;
    DeRef(_28183);
    _28183 = NOVALUE;
    DeRef(_28179);
    _28179 = NOVALUE;
    DeRef(_28224);
    _28224 = NOVALUE;
    DeRef(_28222);
    _28222 = NOVALUE;
    DeRef(_28203);
    _28203 = NOVALUE;
    DeRef(_28217);
    _28217 = NOVALUE;
    DeRef(_28240);
    _28240 = NOVALUE;
    DeRef(_28202);
    _28202 = NOVALUE;
    DeRef(_28212);
    _28212 = NOVALUE;
    DeRef(_28188);
    _28188 = NOVALUE;
    DeRef(_28226);
    _28226 = NOVALUE;
    DeRef(_28207);
    _28207 = NOVALUE;
    DeRef(_28196);
    _28196 = NOVALUE;
    DeRef(_28184);
    _28184 = NOVALUE;
    DeRef(_28232);
    _28232 = NOVALUE;
    DeRef(_28243);
    _28243 = NOVALUE;
    DeRef(_28171);
    _28171 = NOVALUE;
    return;
    ;
}


void _43InitDelete()
{
    object _28259 = NOVALUE;
    object _28258 = NOVALUE;
    object _28256 = NOVALUE;
    object _28255 = NOVALUE;
    object _28254 = NOVALUE;
    object _28253 = NOVALUE;
    object _28252 = NOVALUE;
    object _28251 = NOVALUE;
    object _28250 = NOVALUE;
    object _28249 = NOVALUE;
    object _28248 = NOVALUE;
    object _28247 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:354		while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_43init_stack_55438)){
            _28247 = SEQ_PTR(_43init_stack_55438)->length;
    }
    else {
        _28247 = 1;
    }
    if (_28247 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_43init_stack_55438)){
            _28249 = SEQ_PTR(_43init_stack_55438)->length;
    }
    else {
        _28249 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_55438);
    _28250 = (object)*(((s1_ptr)_2)->base + _28249);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28251 = (object)*(((s1_ptr)_2)->base + _28250);
    _2 = (object)SEQ_PTR(_28251);
    _28252 = (object)*(((s1_ptr)_2)->base + 14);
    _28251 = NOVALUE;
    if (IS_ATOM_INT(_28252)) {
        _28253 = (_28252 > _43stmt_nest_55437);
    }
    else {
        _28253 = binary_op(GREATER, _28252, _43stmt_nest_55437);
    }
    _28252 = NOVALUE;
    if (_28253 <= 0) {
        if (_28253 == 0) {
            DeRef(_28253);
            _28253 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_28253) && DBL_PTR(_28253)->dbl == 0.0){
                DeRef(_28253);
                _28253 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_28253);
            _28253 = NOVALUE;
        }
    }
    DeRef(_28253);
    _28253 = NOVALUE;

    /** parser.e:356			SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_43init_stack_55438)){
            _28254 = SEQ_PTR(_43init_stack_55438)->length;
    }
    else {
        _28254 = 1;
    }
    _2 = (object)SEQ_PTR(_43init_stack_55438);
    _28255 = (object)*(((s1_ptr)_2)->base + _28254);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_28255 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1;
    DeRef(_1);
    _28256 = NOVALUE;

    /** parser.e:357			init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_43init_stack_55438)){
            _28258 = SEQ_PTR(_43init_stack_55438)->length;
    }
    else {
        _28258 = 1;
    }
    _28259 = _28258 - 1;
    _28258 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43init_stack_55438;
    RHS_Slice(_43init_stack_55438, 1, _28259);

    /** parser.e:358		end while*/
    goto L1; // [88] 6
L2: 

    /** parser.e:359	end procedure*/
    DeRef(_28259);
    _28259 = NOVALUE;
    _28255 = NOVALUE;
    _28250 = NOVALUE;
    return;
    ;
}


void _43emit_forward_addr()
{
    object _28261 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:364		emit_addr(0)*/
    _45emit_addr(0);

    /** parser.e:365		branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28261 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28261 = 1;
    }
    Append(&_43branch_list_55403, _43branch_list_55403, _28261);
    _28261 = NOVALUE;

    /** parser.e:366	end procedure*/
    return;
    ;
}


void _43StraightenBranches()
{
    object _br_55912 = NOVALUE;
    object _target_55913 = NOVALUE;
    object _28282 = NOVALUE;
    object _28281 = NOVALUE;
    object _28280 = NOVALUE;
    object _28279 = NOVALUE;
    object _28277 = NOVALUE;
    object _28276 = NOVALUE;
    object _28275 = NOVALUE;
    object _28273 = NOVALUE;
    object _28272 = NOVALUE;
    object _28271 = NOVALUE;
    object _28270 = NOVALUE;
    object _28268 = NOVALUE;
    object _28265 = NOVALUE;
    object _28264 = NOVALUE;
    object _28263 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:373		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** parser.e:374			return -- do it in back-end*/
    return;
L1: 

    /** parser.e:376		for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_43branch_list_55403)){
            _28263 = SEQ_PTR(_43branch_list_55403)->length;
    }
    else {
        _28263 = 1;
    }
    {
        object _i_55917;
        _i_55917 = _28263;
L2: 
        if (_i_55917 < 1){
            goto L3; // [21] 170
        }

        /** parser.e:377			if branch_list[i] > length(Code) then*/
        _2 = (object)SEQ_PTR(_43branch_list_55403);
        _28264 = (object)*(((s1_ptr)_2)->base + _i_55917);
        if (IS_SEQUENCE(_27Code_20660)){
                _28265 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28265 = 1;
        }
        if (binary_op_a(LESSEQ, _28264, _28265)){
            _28264 = NOVALUE;
            _28265 = NOVALUE;
            goto L4; // [41] 53
        }
        _28264 = NOVALUE;
        _28265 = NOVALUE;

        /** parser.e:378				CompileErr("wtf")*/
        RefDS(_28267);
        RefDS(_22209);
        _49CompileErr(_28267, _22209, 0);
L4: 

        /** parser.e:380			target = Code[branch_list[i]]*/
        _2 = (object)SEQ_PTR(_43branch_list_55403);
        _28268 = (object)*(((s1_ptr)_2)->base + _i_55917);
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_28268)){
            _target_55913 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28268)->dbl));
        }
        else{
            _target_55913 = (object)*(((s1_ptr)_2)->base + _28268);
        }
        if (!IS_ATOM_INT(_target_55913)){
            _target_55913 = (object)DBL_PTR(_target_55913)->dbl;
        }

        /** parser.e:381			if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_27Code_20660)){
                _28270 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28270 = 1;
        }
        _28271 = (_target_55913 <= _28270);
        _28270 = NOVALUE;
        if (_28271 == 0) {
            goto L5; // [80] 163
        }
        _28273 = (_target_55913 > 0);
        if (_28273 == 0)
        {
            DeRef(_28273);
            _28273 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_28273);
            _28273 = NOVALUE;
        }

        /** parser.e:382				br = Code[target]*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        _br_55912 = (object)*(((s1_ptr)_2)->base + _target_55913);
        if (!IS_ATOM_INT(_br_55912)){
            _br_55912 = (object)DBL_PTR(_br_55912)->dbl;
        }

        /** parser.e:383				if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _28275 = (_br_55912 == 23);
        if (_28275 != 0) {
            _28276 = 1;
            goto L6; // [110] 124
        }
        _28277 = (_br_55912 == 22);
        _28276 = (_28277 != 0);
L6: 
        if (_28276 != 0) {
            goto L7; // [124] 139
        }
        _28279 = (_br_55912 == 61);
        if (_28279 == 0)
        {
            DeRef(_28279);
            _28279 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_28279);
            _28279 = NOVALUE;
        }
L7: 

        /** parser.e:384					backpatch(branch_list[i], Code[target+1])*/
        _2 = (object)SEQ_PTR(_43branch_list_55403);
        _28280 = (object)*(((s1_ptr)_2)->base + _i_55917);
        _28281 = _target_55913 + 1;
        _2 = (object)SEQ_PTR(_27Code_20660);
        _28282 = (object)*(((s1_ptr)_2)->base + _28281);
        Ref(_28280);
        Ref(_28282);
        _45backpatch(_28280, _28282);
        _28280 = NOVALUE;
        _28282 = NOVALUE;
L8: 
L5: 

        /** parser.e:387		end for*/
        _i_55917 = _i_55917 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** parser.e:388		branch_list = {}*/
    RefDS(_22209);
    DeRef(_43branch_list_55403);
    _43branch_list_55403 = _22209;

    /** parser.e:389	end procedure*/
    DeRef(_28271);
    _28271 = NOVALUE;
    DeRef(_28281);
    _28281 = NOVALUE;
    _28268 = NOVALUE;
    DeRef(_28275);
    _28275 = NOVALUE;
    DeRef(_28277);
    _28277 = NOVALUE;
    return;
    ;
}


void _43PatchEList(object _base_55965)
{
    object _break_top_55966 = NOVALUE;
    object _n_55967 = NOVALUE;
    object _28299 = NOVALUE;
    object _28298 = NOVALUE;
    object _28297 = NOVALUE;
    object _28293 = NOVALUE;
    object _28292 = NOVALUE;
    object _28291 = NOVALUE;
    object _28289 = NOVALUE;
    object _28288 = NOVALUE;
    object _28286 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:410		if not length(break_list) then*/
    if (IS_SEQUENCE(_43break_list_55423)){
            _28286 = SEQ_PTR(_43break_list_55423)->length;
    }
    else {
        _28286 = 1;
    }
    if (_28286 != 0)
    goto L1; // [10] 19
    _28286 = NOVALUE;

    /** parser.e:411			return*/
    return;
L1: 

    /** parser.e:414		break_top = 0*/
    _break_top_55966 = 0;

    /** parser.e:415		for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43break_list_55423)){
            _28288 = SEQ_PTR(_43break_list_55423)->length;
    }
    else {
        _28288 = 1;
    }
    _28289 = _base_55965 + 1;
    if (_28289 > MAXINT){
        _28289 = NewDouble((eudouble)_28289);
    }
    {
        object _i_55972;
        _i_55972 = _28288;
L2: 
        if (binary_op_a(LESS, _i_55972, _28289)){
            goto L3; // [35] 129
        }

        /** parser.e:416			n=break_delay[i]*/
        _2 = (object)SEQ_PTR(_43break_delay_55424);
        if (!IS_ATOM_INT(_i_55972)){
            _n_55967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55972)->dbl));
        }
        else{
            _n_55967 = (object)*(((s1_ptr)_2)->base + _i_55972);
        }
        if (!IS_ATOM_INT(_n_55967))
        _n_55967 = (object)DBL_PTR(_n_55967)->dbl;

        /** parser.e:417			break_delay[i] -= (n>0)*/
        _28291 = (_n_55967 > 0);
        _2 = (object)SEQ_PTR(_43break_delay_55424);
        if (!IS_ATOM_INT(_i_55972)){
            _28292 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55972)->dbl));
        }
        else{
            _28292 = (object)*(((s1_ptr)_2)->base + _i_55972);
        }
        if (IS_ATOM_INT(_28292)) {
            _28293 = _28292 - _28291;
            if ((object)((uintptr_t)_28293 +(uintptr_t) HIGH_BITS) >= 0){
                _28293 = NewDouble((eudouble)_28293);
            }
        }
        else {
            _28293 = binary_op(MINUS, _28292, _28291);
        }
        _28292 = NOVALUE;
        _28291 = NOVALUE;
        _2 = (object)SEQ_PTR(_43break_delay_55424);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43break_delay_55424 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_55972))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55972)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_55972);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28293;
        if( _1 != _28293 ){
            DeRef(_1);
        }
        _28293 = NOVALUE;

        /** parser.e:418			if n>1 then*/
        if (_n_55967 <= 1)
        goto L4; // [72] 93

        /** parser.e:419				if break_top = 0 then*/
        if (_break_top_55966 != 0)
        goto L5; // [78] 122

        /** parser.e:420					break_top = i*/
        Ref(_i_55972);
        _break_top_55966 = _i_55972;
        if (!IS_ATOM_INT(_break_top_55966)) {
            _1 = (object)(DBL_PTR(_break_top_55966)->dbl);
            DeRefDS(_break_top_55966);
            _break_top_55966 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:422			elsif n=1 then*/
        if (_n_55967 != 1)
        goto L6; // [95] 121

        /** parser.e:423				backpatch(break_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43break_list_55423);
        if (!IS_ATOM_INT(_i_55972)){
            _28297 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_55972)->dbl));
        }
        else{
            _28297 = (object)*(((s1_ptr)_2)->base + _i_55972);
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _28298 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28298 = 1;
        }
        _28299 = _28298 + 1;
        _28298 = NOVALUE;
        _45backpatch(_28297, _28299);
        _28297 = NOVALUE;
        _28299 = NOVALUE;
L6: 
L5: 

        /** parser.e:425		end for*/
        _0 = _i_55972;
        if (IS_ATOM_INT(_i_55972)) {
            _i_55972 = _i_55972 + -1;
            if ((object)((uintptr_t)_i_55972 +(uintptr_t) HIGH_BITS) >= 0){
                _i_55972 = NewDouble((eudouble)_i_55972);
            }
        }
        else {
            _i_55972 = binary_op_a(PLUS, _i_55972, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_55972);
    }

    /** parser.e:427		if break_top=0 then*/
    if (_break_top_55966 != 0)
    goto L7; // [131] 141

    /** parser.e:428		    break_top=base*/
    _break_top_55966 = _base_55965;
L7: 

    /** parser.e:431		break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_delay_55424;
    RHS_Slice(_43break_delay_55424, 1, _break_top_55966);

    /** parser.e:432		break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_43break_list_55423;
    RHS_Slice(_43break_list_55423, 1, _break_top_55966);

    /** parser.e:433	end procedure*/
    DeRef(_28289);
    _28289 = NOVALUE;
    return;
    ;
}


void _43PatchNList(object _base_55996)
{
    object _next_top_55997 = NOVALUE;
    object _n_55998 = NOVALUE;
    object _28316 = NOVALUE;
    object _28315 = NOVALUE;
    object _28314 = NOVALUE;
    object _28310 = NOVALUE;
    object _28309 = NOVALUE;
    object _28308 = NOVALUE;
    object _28306 = NOVALUE;
    object _28305 = NOVALUE;
    object _28303 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:439		if not length(continue_list) then*/
    if (IS_SEQUENCE(_43continue_list_55427)){
            _28303 = SEQ_PTR(_43continue_list_55427)->length;
    }
    else {
        _28303 = 1;
    }
    if (_28303 != 0)
    goto L1; // [10] 19
    _28303 = NOVALUE;

    /** parser.e:440			return*/
    return;
L1: 

    /** parser.e:443		next_top = 0*/
    _next_top_55997 = 0;

    /** parser.e:445		for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43continue_list_55427)){
            _28305 = SEQ_PTR(_43continue_list_55427)->length;
    }
    else {
        _28305 = 1;
    }
    _28306 = _base_55996 + 1;
    if (_28306 > MAXINT){
        _28306 = NewDouble((eudouble)_28306);
    }
    {
        object _i_56003;
        _i_56003 = _28305;
L2: 
        if (binary_op_a(LESS, _i_56003, _28306)){
            goto L3; // [35] 129
        }

        /** parser.e:446			n=continue_delay[i]*/
        _2 = (object)SEQ_PTR(_43continue_delay_55428);
        if (!IS_ATOM_INT(_i_56003)){
            _n_55998 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56003)->dbl));
        }
        else{
            _n_55998 = (object)*(((s1_ptr)_2)->base + _i_56003);
        }
        if (!IS_ATOM_INT(_n_55998))
        _n_55998 = (object)DBL_PTR(_n_55998)->dbl;

        /** parser.e:447			continue_delay[i] -= (n>0)*/
        _28308 = (_n_55998 > 0);
        _2 = (object)SEQ_PTR(_43continue_delay_55428);
        if (!IS_ATOM_INT(_i_56003)){
            _28309 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56003)->dbl));
        }
        else{
            _28309 = (object)*(((s1_ptr)_2)->base + _i_56003);
        }
        if (IS_ATOM_INT(_28309)) {
            _28310 = _28309 - _28308;
            if ((object)((uintptr_t)_28310 +(uintptr_t) HIGH_BITS) >= 0){
                _28310 = NewDouble((eudouble)_28310);
            }
        }
        else {
            _28310 = binary_op(MINUS, _28309, _28308);
        }
        _28309 = NOVALUE;
        _28308 = NOVALUE;
        _2 = (object)SEQ_PTR(_43continue_delay_55428);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43continue_delay_55428 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_56003))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56003)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_56003);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28310;
        if( _1 != _28310 ){
            DeRef(_1);
        }
        _28310 = NOVALUE;

        /** parser.e:448			if n>1 then*/
        if (_n_55998 <= 1)
        goto L4; // [72] 93

        /** parser.e:449				if next_top = 0 then*/
        if (_next_top_55997 != 0)
        goto L5; // [78] 122

        /** parser.e:450					next_top = i*/
        Ref(_i_56003);
        _next_top_55997 = _i_56003;
        if (!IS_ATOM_INT(_next_top_55997)) {
            _1 = (object)(DBL_PTR(_next_top_55997)->dbl);
            DeRefDS(_next_top_55997);
            _next_top_55997 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:452			elsif n=1 then*/
        if (_n_55998 != 1)
        goto L6; // [95] 121

        /** parser.e:453				backpatch(continue_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43continue_list_55427);
        if (!IS_ATOM_INT(_i_56003)){
            _28314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56003)->dbl));
        }
        else{
            _28314 = (object)*(((s1_ptr)_2)->base + _i_56003);
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _28315 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28315 = 1;
        }
        _28316 = _28315 + 1;
        _28315 = NOVALUE;
        _45backpatch(_28314, _28316);
        _28314 = NOVALUE;
        _28316 = NOVALUE;
L6: 
L5: 

        /** parser.e:455		end for*/
        _0 = _i_56003;
        if (IS_ATOM_INT(_i_56003)) {
            _i_56003 = _i_56003 + -1;
            if ((object)((uintptr_t)_i_56003 +(uintptr_t) HIGH_BITS) >= 0){
                _i_56003 = NewDouble((eudouble)_i_56003);
            }
        }
        else {
            _i_56003 = binary_op_a(PLUS, _i_56003, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_56003);
    }

    /** parser.e:457		if next_top=0 then*/
    if (_next_top_55997 != 0)
    goto L7; // [131] 141

    /** parser.e:458		    next_top=base*/
    _next_top_55997 = _base_55996;
L7: 

    /** parser.e:461		continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_delay_55428;
    RHS_Slice(_43continue_delay_55428, 1, _next_top_55997);

    /** parser.e:462		continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_43continue_list_55427;
    RHS_Slice(_43continue_list_55427, 1, _next_top_55997);

    /** parser.e:463	end procedure*/
    DeRef(_28306);
    _28306 = NOVALUE;
    return;
    ;
}


void _43PatchXList(object _base_56027)
{
    object _exit_top_56028 = NOVALUE;
    object _n_56029 = NOVALUE;
    object _28333 = NOVALUE;
    object _28332 = NOVALUE;
    object _28331 = NOVALUE;
    object _28327 = NOVALUE;
    object _28326 = NOVALUE;
    object _28325 = NOVALUE;
    object _28323 = NOVALUE;
    object _28322 = NOVALUE;
    object _28320 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:469		if not length(exit_list) then*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _28320 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _28320 = 1;
    }
    if (_28320 != 0)
    goto L1; // [10] 19
    _28320 = NOVALUE;

    /** parser.e:470			return*/
    return;
L1: 

    /** parser.e:473		exit_top = 0*/
    _exit_top_56028 = 0;

    /** parser.e:475		for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _28322 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _28322 = 1;
    }
    _28323 = _base_56027 + 1;
    if (_28323 > MAXINT){
        _28323 = NewDouble((eudouble)_28323);
    }
    {
        object _i_56034;
        _i_56034 = _28322;
L2: 
        if (binary_op_a(LESS, _i_56034, _28323)){
            goto L3; // [35] 129
        }

        /** parser.e:476			n=exit_delay[i]*/
        _2 = (object)SEQ_PTR(_43exit_delay_55426);
        if (!IS_ATOM_INT(_i_56034)){
            _n_56029 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56034)->dbl));
        }
        else{
            _n_56029 = (object)*(((s1_ptr)_2)->base + _i_56034);
        }
        if (!IS_ATOM_INT(_n_56029))
        _n_56029 = (object)DBL_PTR(_n_56029)->dbl;

        /** parser.e:477			exit_delay[i] -= (n>0)*/
        _28325 = (_n_56029 > 0);
        _2 = (object)SEQ_PTR(_43exit_delay_55426);
        if (!IS_ATOM_INT(_i_56034)){
            _28326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56034)->dbl));
        }
        else{
            _28326 = (object)*(((s1_ptr)_2)->base + _i_56034);
        }
        if (IS_ATOM_INT(_28326)) {
            _28327 = _28326 - _28325;
            if ((object)((uintptr_t)_28327 +(uintptr_t) HIGH_BITS) >= 0){
                _28327 = NewDouble((eudouble)_28327);
            }
        }
        else {
            _28327 = binary_op(MINUS, _28326, _28325);
        }
        _28326 = NOVALUE;
        _28325 = NOVALUE;
        _2 = (object)SEQ_PTR(_43exit_delay_55426);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43exit_delay_55426 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_56034))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56034)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_56034);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28327;
        if( _1 != _28327 ){
            DeRef(_1);
        }
        _28327 = NOVALUE;

        /** parser.e:478			if n>1 then*/
        if (_n_56029 <= 1)
        goto L4; // [72] 93

        /** parser.e:479				if exit_top = 0 then*/
        if (_exit_top_56028 != 0)
        goto L5; // [78] 122

        /** parser.e:480					exit_top = i*/
        Ref(_i_56034);
        _exit_top_56028 = _i_56034;
        if (!IS_ATOM_INT(_exit_top_56028)) {
            _1 = (object)(DBL_PTR(_exit_top_56028)->dbl);
            DeRefDS(_exit_top_56028);
            _exit_top_56028 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** parser.e:482			elsif n=1 then*/
        if (_n_56029 != 1)
        goto L6; // [95] 121

        /** parser.e:483				backpatch(exit_list[i],length(Code)+1)*/
        _2 = (object)SEQ_PTR(_43exit_list_55425);
        if (!IS_ATOM_INT(_i_56034)){
            _28331 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_56034)->dbl));
        }
        else{
            _28331 = (object)*(((s1_ptr)_2)->base + _i_56034);
        }
        if (IS_SEQUENCE(_27Code_20660)){
                _28332 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _28332 = 1;
        }
        _28333 = _28332 + 1;
        _28332 = NOVALUE;
        _45backpatch(_28331, _28333);
        _28331 = NOVALUE;
        _28333 = NOVALUE;
L6: 
L5: 

        /** parser.e:485		end for*/
        _0 = _i_56034;
        if (IS_ATOM_INT(_i_56034)) {
            _i_56034 = _i_56034 + -1;
            if ((object)((uintptr_t)_i_56034 +(uintptr_t) HIGH_BITS) >= 0){
                _i_56034 = NewDouble((eudouble)_i_56034);
            }
        }
        else {
            _i_56034 = binary_op_a(PLUS, _i_56034, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_56034);
    }

    /** parser.e:487		if exit_top=0 then*/
    if (_exit_top_56028 != 0)
    goto L7; // [131] 141

    /** parser.e:488		    exit_top=base*/
    _exit_top_56028 = _base_56027;
L7: 

    /** parser.e:491		exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_delay_55426;
    RHS_Slice(_43exit_delay_55426, 1, _exit_top_56028);

    /** parser.e:492		exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_43exit_list_55425;
    RHS_Slice(_43exit_list_55425, 1, _exit_top_56028);

    /** parser.e:493	end procedure*/
    DeRef(_28323);
    _28323 = NOVALUE;
    return;
    ;
}


void _43putback(object _t_56059)
{
    object _28338 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:497		backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_56059);
    Append(&_43backed_up_tok_55412, _43backed_up_tok_55412, _t_56059);

    /** parser.e:499		if t[T_SYM] then*/
    _2 = (object)SEQ_PTR(_t_56059);
    _28338 = (object)*(((s1_ptr)_2)->base + 2);
    if (_28338 == 0) {
        _28338 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_28338) && DBL_PTR(_28338)->dbl == 0.0){
            _28338 = NOVALUE;
            goto L1; // [17] 79
        }
        _28338 = NOVALUE;
    }
    _28338 = NOVALUE;

    /** parser.e:500			putback_ForwardLine     = ForwardLine*/
    Ref(_49ForwardLine_49643);
    DeRef(_49putback_ForwardLine_49644);
    _49putback_ForwardLine_49644 = _49ForwardLine_49643;

    /** parser.e:501			putback_forward_bp      = forward_bp*/
    _49putback_forward_bp_49648 = _49forward_bp_49647;

    /** parser.e:502			putback_fwd_line_number = fwd_line_number*/
    _27putback_fwd_line_number_20574 = _27fwd_line_number_20573;

    /** parser.e:504			if last_fwd_line_number then*/
    if (_27last_fwd_line_number_20575 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** parser.e:505				ForwardLine     = last_ForwardLine*/
    Ref(_49last_ForwardLine_49645);
    DeRef(_49ForwardLine_49643);
    _49ForwardLine_49643 = _49last_ForwardLine_49645;

    /** parser.e:506				forward_bp      = last_forward_bp*/
    _49forward_bp_49647 = _49last_forward_bp_49649;

    /** parser.e:507				fwd_line_number = last_fwd_line_number*/
    _27fwd_line_number_20573 = _27last_fwd_line_number_20575;
L2: 
L1: 

    /** parser.e:510	end procedure*/
    DeRef(_t_56059);
    return;
    ;
}


void _43start_recording()
{
    object _0, _1, _2;
    

    /** parser.e:519		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_56078, _43psm_stack_56078, _27Parser_mode_20677);

    /** parser.e:520		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_55449);
    Append(&_43can_stack_56079, _43can_stack_56079, _43canned_tokens_55449);

    /** parser.e:521		idx_stack &= canned_index*/
    Append(&_43idx_stack_56080, _43idx_stack_56080, _43canned_index_55450);

    /** parser.e:522		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_55412);
    Append(&_43tok_stack_56081, _43tok_stack_56081, _43backed_up_tok_55412);

    /** parser.e:523		canned_tokens = {}*/
    RefDS(_22209);
    DeRef(_43canned_tokens_55449);
    _43canned_tokens_55449 = _22209;

    /** parser.e:524		Parser_mode = PAM_RECORD*/
    _27Parser_mode_20677 = 1;

    /** parser.e:525		clear_last()*/
    _45clear_last();

    /** parser.e:526	end procedure*/
    return;
    ;
}


object _43restore_parser()
{
    object _n_56094 = NOVALUE;
    object _tok_56095 = NOVALUE;
    object _x_56096 = NOVALUE;
    object _28369 = NOVALUE;
    object _28368 = NOVALUE;
    object _28367 = NOVALUE;
    object _28365 = NOVALUE;
    object _28361 = NOVALUE;
    object _28360 = NOVALUE;
    object _28358 = NOVALUE;
    object _28356 = NOVALUE;
    object _28355 = NOVALUE;
    object _28353 = NOVALUE;
    object _28351 = NOVALUE;
    object _28350 = NOVALUE;
    object _28348 = NOVALUE;
    object _28346 = NOVALUE;
    object _28345 = NOVALUE;
    object _28343 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:533		n=Parser_mode*/
    _n_56094 = _27Parser_mode_20677;

    /** parser.e:534		x = canned_tokens*/
    Ref(_43canned_tokens_55449);
    DeRef(_x_56096);
    _x_56096 = _43canned_tokens_55449;

    /** parser.e:535		canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_43can_stack_56079)){
            _28343 = SEQ_PTR(_43can_stack_56079)->length;
    }
    else {
        _28343 = 1;
    }
    DeRef(_43canned_tokens_55449);
    _2 = (object)SEQ_PTR(_43can_stack_56079);
    _43canned_tokens_55449 = (object)*(((s1_ptr)_2)->base + _28343);
    Ref(_43canned_tokens_55449);

    /** parser.e:536		can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_43can_stack_56079)){
            _28345 = SEQ_PTR(_43can_stack_56079)->length;
    }
    else {
        _28345 = 1;
    }
    _28346 = _28345 - 1;
    _28345 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43can_stack_56079;
    RHS_Slice(_43can_stack_56079, 1, _28346);

    /** parser.e:537		canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_43idx_stack_56080)){
            _28348 = SEQ_PTR(_43idx_stack_56080)->length;
    }
    else {
        _28348 = 1;
    }
    _2 = (object)SEQ_PTR(_43idx_stack_56080);
    _43canned_index_55450 = (object)*(((s1_ptr)_2)->base + _28348);

    /** parser.e:538		idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_43idx_stack_56080)){
            _28350 = SEQ_PTR(_43idx_stack_56080)->length;
    }
    else {
        _28350 = 1;
    }
    _28351 = _28350 - 1;
    _28350 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43idx_stack_56080;
    RHS_Slice(_43idx_stack_56080, 1, _28351);

    /** parser.e:539		Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_43psm_stack_56078)){
            _28353 = SEQ_PTR(_43psm_stack_56078)->length;
    }
    else {
        _28353 = 1;
    }
    _2 = (object)SEQ_PTR(_43psm_stack_56078);
    _27Parser_mode_20677 = (object)*(((s1_ptr)_2)->base + _28353);

    /** parser.e:540		psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_43psm_stack_56078)){
            _28355 = SEQ_PTR(_43psm_stack_56078)->length;
    }
    else {
        _28355 = 1;
    }
    _28356 = _28355 - 1;
    _28355 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43psm_stack_56078;
    RHS_Slice(_43psm_stack_56078, 1, _28356);

    /** parser.e:541		tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_43tok_stack_56081)){
            _28358 = SEQ_PTR(_43tok_stack_56081)->length;
    }
    else {
        _28358 = 1;
    }
    DeRef(_tok_56095);
    _2 = (object)SEQ_PTR(_43tok_stack_56081);
    _tok_56095 = (object)*(((s1_ptr)_2)->base + _28358);
    RefDS(_tok_56095);

    /** parser.e:542		tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_43tok_stack_56081)){
            _28360 = SEQ_PTR(_43tok_stack_56081)->length;
    }
    else {
        _28360 = 1;
    }
    _28361 = _28360 - 1;
    _28360 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43tok_stack_56081;
    RHS_Slice(_43tok_stack_56081, 1, _28361);

    /** parser.e:543		clear_last()*/
    _45clear_last();

    /** parser.e:544		if n=PAM_PLAYBACK then*/
    if (_n_56094 != -1)
    goto L1; // [137] 150

    /** parser.e:545			return {}*/
    RefDS(_22209);
    DeRefDS(_tok_56095);
    DeRefDS(_x_56096);
    _28351 = NOVALUE;
    _28361 = NOVALUE;
    _28356 = NOVALUE;
    _28346 = NOVALUE;
    return _22209;
    goto L2; // [147] 167
L1: 

    /** parser.e:547		elsif n = PAM_NORMAL then*/
    if (_n_56094 != 0)
    goto L3; // [154] 166

    /** parser.e:548			use_private_list = 0*/
    _27use_private_list_20685 = 0;
L3: 
L2: 

    /** parser.e:550		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_55412)){
            _28365 = SEQ_PTR(_43backed_up_tok_55412)->length;
    }
    else {
        _28365 = 1;
    }
    if (_28365 <= 0)
    goto L4; // [174] 199

    /** parser.e:551			return x[1..$-1]*/
    if (IS_SEQUENCE(_x_56096)){
            _28367 = SEQ_PTR(_x_56096)->length;
    }
    else {
        _28367 = 1;
    }
    _28368 = _28367 - 1;
    _28367 = NOVALUE;
    rhs_slice_target = (object_ptr)&_28369;
    RHS_Slice(_x_56096, 1, _28368);
    DeRef(_tok_56095);
    DeRefDS(_x_56096);
    DeRef(_28351);
    _28351 = NOVALUE;
    _28368 = NOVALUE;
    DeRef(_28361);
    _28361 = NOVALUE;
    DeRef(_28356);
    _28356 = NOVALUE;
    DeRef(_28346);
    _28346 = NOVALUE;
    return _28369;
    goto L5; // [196] 206
L4: 

    /** parser.e:553			return x*/
    DeRef(_tok_56095);
    DeRef(_28351);
    _28351 = NOVALUE;
    DeRef(_28368);
    _28368 = NOVALUE;
    DeRef(_28369);
    _28369 = NOVALUE;
    DeRef(_28361);
    _28361 = NOVALUE;
    DeRef(_28356);
    _28356 = NOVALUE;
    DeRef(_28346);
    _28346 = NOVALUE;
    return _x_56096;
L5: 
    ;
}


void _43start_playback(object _s_56136)
{
    object _0, _1, _2;
    

    /** parser.e:558		psm_stack &= Parser_mode*/
    Append(&_43psm_stack_56078, _43psm_stack_56078, _27Parser_mode_20677);

    /** parser.e:559		can_stack = append(can_stack,canned_tokens)*/
    Ref(_43canned_tokens_55449);
    Append(&_43can_stack_56079, _43can_stack_56079, _43canned_tokens_55449);

    /** parser.e:560		idx_stack &= canned_index*/
    Append(&_43idx_stack_56080, _43idx_stack_56080, _43canned_index_55450);

    /** parser.e:561		tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_43backed_up_tok_55412);
    Append(&_43tok_stack_56081, _43tok_stack_56081, _43backed_up_tok_55412);

    /** parser.e:562		canned_index = 1*/
    _43canned_index_55450 = 1;

    /** parser.e:563		canned_tokens = s*/
    RefDS(_s_56136);
    DeRef(_43canned_tokens_55449);
    _43canned_tokens_55449 = _s_56136;

    /** parser.e:564		backed_up_tok = {}*/
    RefDS(_22209);
    DeRefDS(_43backed_up_tok_55412);
    _43backed_up_tok_55412 = _22209;

    /** parser.e:565		Parser_mode = PAM_PLAYBACK*/
    _27Parser_mode_20677 = -1;

    /** parser.e:566	end procedure*/
    DeRefDS(_s_56136);
    return;
    ;
}


void _43restore_parseargs_states()
{
    object _s_56155 = NOVALUE;
    object _n_56156 = NOVALUE;
    object _28386 = NOVALUE;
    object _28385 = NOVALUE;
    object _28377 = NOVALUE;
    object _28376 = NOVALUE;
    object _28374 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:584		s = parseargs_states[$]*/
    if (IS_SEQUENCE(_43parseargs_states_56144)){
            _28374 = SEQ_PTR(_43parseargs_states_56144)->length;
    }
    else {
        _28374 = 1;
    }
    DeRef(_s_56155);
    _2 = (object)SEQ_PTR(_43parseargs_states_56144);
    _s_56155 = (object)*(((s1_ptr)_2)->base + _28374);
    RefDS(_s_56155);

    /** parser.e:585		parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_43parseargs_states_56144)){
            _28376 = SEQ_PTR(_43parseargs_states_56144)->length;
    }
    else {
        _28376 = 1;
    }
    _28377 = _28376 - 1;
    _28376 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43parseargs_states_56144;
    RHS_Slice(_43parseargs_states_56144, 1, _28377);

    /** parser.e:586		n=s[PS_POSITION]*/
    _2 = (object)SEQ_PTR(_s_56155);
    _n_56156 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_56156))
    _n_56156 = (object)DBL_PTR(_n_56156)->dbl;

    /** parser.e:587		private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_43private_list_56149;
    RHS_Slice(_43private_list_56149, 1, _n_56156);

    /** parser.e:588		private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_27private_sym_20684;
    RHS_Slice(_27private_sym_20684, 1, _n_56156);

    /** parser.e:589		lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (object)SEQ_PTR(_s_56155);
    _43lock_scanner_56150 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_43lock_scanner_56150))
    _43lock_scanner_56150 = (object)DBL_PTR(_43lock_scanner_56150)->dbl;

    /** parser.e:590		use_private_list = s[PS_USE_LIST]*/
    _2 = (object)SEQ_PTR(_s_56155);
    _27use_private_list_20685 = (object)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_27use_private_list_20685)){
        _27use_private_list_20685 = (object)DBL_PTR(_27use_private_list_20685)->dbl;
    }

    /** parser.e:591		on_arg = s[PS_ON_ARG]*/
    _2 = (object)SEQ_PTR(_s_56155);
    _43on_arg_56151 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_43on_arg_56151))
    _43on_arg_56151 = (object)DBL_PTR(_43on_arg_56151)->dbl;

    /** parser.e:592		nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_43nested_calls_56152)){
            _28385 = SEQ_PTR(_43nested_calls_56152)->length;
    }
    else {
        _28385 = 1;
    }
    _28386 = _28385 - 1;
    _28385 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43nested_calls_56152;
    RHS_Slice(_43nested_calls_56152, 1, _28386);

    /** parser.e:593	end procedure*/
    DeRefDS(_s_56155);
    _28386 = NOVALUE;
    _28377 = NOVALUE;
    return;
    ;
}


object _43read_recorded_token(object _n_56176)
{
    object _t_56178 = NOVALUE;
    object _p_56179 = NOVALUE;
    object _prev_Nne_56180 = NOVALUE;
    object _ts_56209 = NOVALUE;
    object _31988 = NOVALUE;
    object _31987 = NOVALUE;
    object _31986 = NOVALUE;
    object _31985 = NOVALUE;
    object _31984 = NOVALUE;
    object _31983 = NOVALUE;
    object _31982 = NOVALUE;
    object _31981 = NOVALUE;
    object _28458 = NOVALUE;
    object _28457 = NOVALUE;
    object _28456 = NOVALUE;
    object _28455 = NOVALUE;
    object _28451 = NOVALUE;
    object _28449 = NOVALUE;
    object _28448 = NOVALUE;
    object _28447 = NOVALUE;
    object _28446 = NOVALUE;
    object _28444 = NOVALUE;
    object _28443 = NOVALUE;
    object _28442 = NOVALUE;
    object _28441 = NOVALUE;
    object _28439 = NOVALUE;
    object _28436 = NOVALUE;
    object _28434 = NOVALUE;
    object _28432 = NOVALUE;
    object _28431 = NOVALUE;
    object _28430 = NOVALUE;
    object _28429 = NOVALUE;
    object _28427 = NOVALUE;
    object _28425 = NOVALUE;
    object _28421 = NOVALUE;
    object _28419 = NOVALUE;
    object _28417 = NOVALUE;
    object _28416 = NOVALUE;
    object _28415 = NOVALUE;
    object _28414 = NOVALUE;
    object _28413 = NOVALUE;
    object _28412 = NOVALUE;
    object _28411 = NOVALUE;
    object _28410 = NOVALUE;
    object _28409 = NOVALUE;
    object _28408 = NOVALUE;
    object _28407 = NOVALUE;
    object _28406 = NOVALUE;
    object _28404 = NOVALUE;
    object _28403 = NOVALUE;
    object _28401 = NOVALUE;
    object _28400 = NOVALUE;
    object _28399 = NOVALUE;
    object _28398 = NOVALUE;
    object _28397 = NOVALUE;
    object _28396 = NOVALUE;
    object _28395 = NOVALUE;
    object _28394 = NOVALUE;
    object _28391 = NOVALUE;
    object _28389 = NOVALUE;
    object _28388 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_56176)) {
        _1 = (object)(DBL_PTR(_n_56176)->dbl);
        DeRefDS(_n_56176);
        _n_56176 = _1;
    }

    /** parser.e:597		integer p, prev_Nne*/

    /** parser.e:598		if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_20679);
    _28388 = (object)*(((s1_ptr)_2)->base + _n_56176);
    _28389 = IS_ATOM(_28388);
    _28388 = NOVALUE;
    if (_28389 == 0)
    {
        _28389 = NOVALUE;
        goto L1; // [16] 405
    }
    else{
        _28389 = NOVALUE;
    }

    /** parser.e:599			if use_private_list then*/
    if (_27use_private_list_20685 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** parser.e:600				p = find( Recorded[n], private_list)*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28391 = (object)*(((s1_ptr)_2)->base + _n_56176);
    _p_56179 = find_from(_28391, _43private_list_56149, 1);
    _28391 = NOVALUE;

    /** parser.e:601				if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_56179 <= 0)
    goto L3; // [43] 170

    /** parser.e:603					if TRANSLATE*/
    if (_27TRANSLATE_20179 == 0) {
        goto L4; // [51] 150
    }
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28395 = (object)*(((s1_ptr)_2)->base + _p_56179);
    if (IS_ATOM_INT(_28395)) {
        _28396 = (_28395 < 0);
    }
    else {
        _28396 = binary_op(LESS, _28395, 0);
    }
    _28395 = NOVALUE;
    if (IS_ATOM_INT(_28396)) {
        if (_28396 != 0) {
            _28397 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_28396)->dbl != 0.0) {
            _28397 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28398 = (object)*(((s1_ptr)_2)->base + _p_56179);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28398)){
        _28399 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28398)->dbl));
    }
    else{
        _28399 = (object)*(((s1_ptr)_2)->base + _28398);
    }
    _2 = (object)SEQ_PTR(_28399);
    _28400 = (object)*(((s1_ptr)_2)->base + 3);
    _28399 = NOVALUE;
    if (IS_ATOM_INT(_28400)) {
        _28401 = (_28400 == 3);
    }
    else {
        _28401 = binary_op(EQUALS, _28400, 3);
    }
    _28400 = NOVALUE;
    DeRef(_28397);
    if (IS_ATOM_INT(_28401))
    _28397 = (_28401 != 0);
    else
    _28397 = DBL_PTR(_28401)->dbl != 0.0;
L5: 
    if (_28397 == 0)
    {
        _28397 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _28397 = NOVALUE;
    }

    /** parser.e:610						symtab_index ts = NewTempSym()*/
    _ts_56209 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_ts_56209)) {
        _1 = (object)(DBL_PTR(_ts_56209)->dbl);
        DeRefDS(_ts_56209);
        _ts_56209 = _1;
    }

    /** parser.e:611						Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28403 = (object)*(((s1_ptr)_2)->base + _p_56179);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18;
    Ref(_28403);
    ((intptr_t*)_2)[2] = _28403;
    ((intptr_t*)_2)[3] = _ts_56209;
    _28404 = MAKE_SEQ(_1);
    _28403 = NOVALUE;
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _28404);
    DeRefDS(_28404);
    _28404 = NOVALUE;

    /** parser.e:612						return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _ts_56209;
    _28406 = MAKE_SEQ(_1);
    DeRef(_t_56178);
    _28398 = NOVALUE;
    DeRef(_28401);
    _28401 = NOVALUE;
    DeRef(_28396);
    _28396 = NOVALUE;
    return _28406;
    goto L6; // [147] 169
L4: 

    /** parser.e:614						return {VARIABLE, private_sym[p]}*/
    _2 = (object)SEQ_PTR(_27private_sym_20684);
    _28407 = (object)*(((s1_ptr)_2)->base + _p_56179);
    Ref(_28407);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _28407;
    _28408 = MAKE_SEQ(_1);
    _28407 = NOVALUE;
    DeRef(_t_56178);
    _28398 = NOVALUE;
    DeRef(_28401);
    _28401 = NOVALUE;
    DeRef(_28406);
    _28406 = NOVALUE;
    DeRef(_28396);
    _28396 = NOVALUE;
    return _28408;
L6: 
L3: 
L2: 

    /** parser.e:620			prev_Nne = No_new_entry*/
    _prev_Nne_56180 = _53No_new_entry_48382;

    /** parser.e:621			No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** parser.e:623			if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28409 = (object)*(((s1_ptr)_2)->base + _n_56176);
    if (IS_ATOM_INT(_28409)) {
        _28410 = (_28409 > 0);
    }
    else {
        _28410 = binary_op(GREATER, _28409, 0);
    }
    _28409 = NOVALUE;
    if (IS_ATOM_INT(_28410)) {
        if (_28410 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_28410)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28412 = (object)*(((s1_ptr)_2)->base + _n_56176);
    Ref(_28412);
    _28413 = _53sym_scope(_28412);
    _28412 = NOVALUE;
    if (IS_ATOM_INT(_28413)) {
        _28414 = (_28413 != 9);
    }
    else {
        _28414 = binary_op(NOTEQ, _28413, 9);
    }
    DeRef(_28413);
    _28413 = NOVALUE;
    if (_28414 == 0) {
        DeRef(_28414);
        _28414 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_28414) && DBL_PTR(_28414)->dbl == 0.0){
            DeRef(_28414);
            _28414 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_28414);
        _28414 = NOVALUE;
    }
    DeRef(_28414);
    _28414 = NOVALUE;

    /** parser.e:624				t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28415 = (object)*(((s1_ptr)_2)->base + _n_56176);
    Ref(_28415);
    _28416 = _53sym_token(_28415);
    _28415 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _28417 = (object)*(((s1_ptr)_2)->base + _n_56176);
    Ref(_28417);
    DeRef(_t_56178);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28416;
    ((intptr_t *)_2)[2] = _28417;
    _t_56178 = MAKE_SEQ(_1);
    _28417 = NOVALUE;
    _28416 = NOVALUE;

    /** parser.e:625				break "top if"*/
    goto L8; // [247] 734
L7: 

    /** parser.e:628			t = keyfind(Recorded[n],-1)*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28419 = (object)*(((s1_ptr)_2)->base + _n_56176);
    RefDS(_28419);
    DeRef(_31987);
    _31987 = _28419;
    _31988 = _53hashfn(_31987);
    _31987 = NOVALUE;
    RefDS(_28419);
    _0 = _t_56178;
    _t_56178 = _53keyfind(_28419, -1, _27current_file_no_20571, 0, _31988);
    DeRef(_0);
    _28419 = NOVALUE;
    _31988 = NOVALUE;

    /** parser.e:629			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56178);
    _28421 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28421, 509)){
        _28421 = NOVALUE;
        goto L8; // [286] 734
    }
    _28421 = NOVALUE;

    /** parser.e:630		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _p_56179 = (object)*(((s1_ptr)_2)->base + _n_56176);
    if (!IS_ATOM_INT(_p_56179)){
        _p_56179 = (object)DBL_PTR(_p_56179)->dbl;
    }

    /** parser.e:631		        if p = 0 then*/
    if (_p_56179 != 0)
    goto L9; // [302] 382

    /** parser.e:633					No_new_entry = 0*/
    _53No_new_entry_48382 = 0;

    /** parser.e:634					t = keyfind( Recorded[n], -1 )*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28425 = (object)*(((s1_ptr)_2)->base + _n_56176);
    RefDS(_28425);
    DeRef(_31985);
    _31985 = _28425;
    _31986 = _53hashfn(_31985);
    _31985 = NOVALUE;
    RefDS(_28425);
    _0 = _t_56178;
    _t_56178 = _53keyfind(_28425, -1, _27current_file_no_20571, 0, _31986);
    DeRef(_0);
    _28425 = NOVALUE;
    _31986 = NOVALUE;

    /** parser.e:635					No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** parser.e:636					if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56178);
    _28427 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28427, 509)){
        _28427 = NOVALUE;
        goto L8; // [355] 734
    }
    _28427 = NOVALUE;

    /** parser.e:637						CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28429 = (object)*(((s1_ptr)_2)->base + _n_56176);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28429);
    ((intptr_t*)_2)[1] = _28429;
    _28430 = MAKE_SEQ(_1);
    _28429 = NOVALUE;
    _49CompileErr(157, _28430, 0);
    _28430 = NOVALUE;
    goto L8; // [379] 734
L9: 

    /** parser.e:640					t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28431 = (object)*(((s1_ptr)_2)->base + _p_56179);
    _2 = (object)SEQ_PTR(_28431);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _28432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _28432 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _28431 = NOVALUE;
    Ref(_28432);
    DeRef(_t_56178);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28432;
    ((intptr_t *)_2)[2] = _p_56179;
    _t_56178 = MAKE_SEQ(_1);
    _28432 = NOVALUE;
    goto L8; // [402] 734
L1: 

    /** parser.e:644			prev_Nne = No_new_entry*/
    _prev_Nne_56180 = _53No_new_entry_48382;

    /** parser.e:645			No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** parser.e:646			t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_20679);
    _28434 = (object)*(((s1_ptr)_2)->base + _n_56176);
    Ref(_28434);
    DeRef(_31983);
    _31983 = _28434;
    _31984 = _53hashfn(_31983);
    _31983 = NOVALUE;
    Ref(_28434);
    _0 = _t_56178;
    _t_56178 = _53keyfind(_28434, -1, _27current_file_no_20571, 1, _31984);
    DeRef(_0);
    _28434 = NOVALUE;
    _31984 = NOVALUE;

    /** parser.e:647			if t[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_t_56178);
    _28436 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28436, 523)){
        _28436 = NOVALUE;
        goto LA; // [456] 524
    }
    _28436 = NOVALUE;

    /** parser.e:648				p = Ns_recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_sym_20681);
    _p_56179 = (object)*(((s1_ptr)_2)->base + _n_56176);
    if (!IS_ATOM_INT(_p_56179)){
        _p_56179 = (object)DBL_PTR(_p_56179)->dbl;
    }

    /** parser.e:649				if p = 0 or sym_token( p ) != NAMESPACE then*/
    _28439 = (_p_56179 == 0);
    if (_28439 != 0) {
        goto LB; // [476] 495
    }
    _28441 = _53sym_token(_p_56179);
    if (IS_ATOM_INT(_28441)) {
        _28442 = (_28441 != 523);
    }
    else {
        _28442 = binary_op(NOTEQ, _28441, 523);
    }
    DeRef(_28441);
    _28441 = NOVALUE;
    if (_28442 == 0) {
        DeRef(_28442);
        _28442 = NOVALUE;
        goto LC; // [491] 515
    }
    else {
        if (!IS_ATOM_INT(_28442) && DBL_PTR(_28442)->dbl == 0.0){
            DeRef(_28442);
            _28442 = NOVALUE;
            goto LC; // [491] 515
        }
        DeRef(_28442);
        _28442 = NOVALUE;
    }
    DeRef(_28442);
    _28442 = NOVALUE;
LB: 

    /** parser.e:650					CompileErr(UNKNOWN_NAMESPACE_1_IN_DEFAULT_ARGUMENT, {Ns_recorded[n]})*/
    _2 = (object)SEQ_PTR(_27Ns_recorded_20679);
    _28443 = (object)*(((s1_ptr)_2)->base + _n_56176);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28443);
    ((intptr_t*)_2)[1] = _28443;
    _28444 = MAKE_SEQ(_1);
    _28443 = NOVALUE;
    _49CompileErr(153, _28444, 0);
    _28444 = NOVALUE;
LC: 

    /** parser.e:652				t = {NAMESPACE, p}*/
    DeRef(_t_56178);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 523;
    ((intptr_t *)_2)[2] = _p_56179;
    _t_56178 = MAKE_SEQ(_1);
LA: 

    /** parser.e:655			t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28446 = (object)*(((s1_ptr)_2)->base + _n_56176);
    _2 = (object)SEQ_PTR(_t_56178);
    _28447 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28447)){
        _28448 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28447)->dbl));
    }
    else{
        _28448 = (object)*(((s1_ptr)_2)->base + _28447);
    }
    _2 = (object)SEQ_PTR(_28448);
    _28449 = (object)*(((s1_ptr)_2)->base + 1);
    _28448 = NOVALUE;
    RefDS(_28446);
    DeRef(_31981);
    _31981 = _28446;
    _31982 = _53hashfn(_31981);
    _31981 = NOVALUE;
    RefDS(_28446);
    Ref(_28449);
    _0 = _t_56178;
    _t_56178 = _53keyfind(_28446, _28449, _27current_file_no_20571, 0, _31982);
    DeRef(_0);
    _28446 = NOVALUE;
    _28449 = NOVALUE;
    _31982 = NOVALUE;

    /** parser.e:656			if t[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_t_56178);
    _28451 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28451, 509)){
        _28451 = NOVALUE;
        goto LD; // [577] 636
    }
    _28451 = NOVALUE;

    /** parser.e:657		        p = Recorded_sym[n]*/
    _2 = (object)SEQ_PTR(_27Recorded_sym_20680);
    _p_56179 = (object)*(((s1_ptr)_2)->base + _n_56176);
    if (!IS_ATOM_INT(_p_56179)){
        _p_56179 = (object)DBL_PTR(_p_56179)->dbl;
    }

    /** parser.e:658		        if p = 0 then*/
    if (_p_56179 != 0)
    goto LE; // [593] 617

    /** parser.e:659		        	CompileErr(VARIABLE_1_HAS_NOT_BEEN_DECLARED,{Recorded[n]})*/
    _2 = (object)SEQ_PTR(_27Recorded_20678);
    _28455 = (object)*(((s1_ptr)_2)->base + _n_56176);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_28455);
    ((intptr_t*)_2)[1] = _28455;
    _28456 = MAKE_SEQ(_1);
    _28455 = NOVALUE;
    _49CompileErr(157, _28456, 0);
    _28456 = NOVALUE;
LE: 

    /** parser.e:661			    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28457 = (object)*(((s1_ptr)_2)->base + _p_56179);
    _2 = (object)SEQ_PTR(_28457);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _28458 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _28458 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _28457 = NOVALUE;
    Ref(_28458);
    DeRef(_t_56178);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28458;
    ((intptr_t *)_2)[2] = _p_56179;
    _t_56178 = MAKE_SEQ(_1);
    _28458 = NOVALUE;
LD: 

    /** parser.e:663			n = t[T_ID]*/
    _2 = (object)SEQ_PTR(_t_56178);
    _n_56176 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_56176)){
        _n_56176 = (object)DBL_PTR(_n_56176)->dbl;
    }

    /** parser.e:664			if n = VARIABLE then*/
    if (_n_56176 != -100)
    goto LF; // [650] 666

    /** parser.e:665				n = QUALIFIED_VARIABLE*/
    _n_56176 = 512;
    goto L10; // [663] 725
LF: 

    /** parser.e:666			elsif n = FUNC then*/
    if (_n_56176 != 501)
    goto L11; // [670] 686

    /** parser.e:667				n = QUALIFIED_FUNC*/
    _n_56176 = 520;
    goto L10; // [683] 725
L11: 

    /** parser.e:668			elsif n = PROC then*/
    if (_n_56176 != 27)
    goto L12; // [690] 706

    /** parser.e:669				n = QUALIFIED_PROC*/
    _n_56176 = 521;
    goto L10; // [703] 725
L12: 

    /** parser.e:670			elsif n = TYPE then*/
    if (_n_56176 != 504)
    goto L13; // [710] 724

    /** parser.e:671				n = QUALIFIED_TYPE*/
    _n_56176 = 522;
L13: 
L10: 

    /** parser.e:673			t[T_ID] = n*/
    _2 = (object)SEQ_PTR(_t_56178);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _t_56178 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _n_56176;
    DeRef(_1);
L8: 

    /** parser.e:675		No_new_entry = prev_Nne*/
    _53No_new_entry_48382 = _prev_Nne_56180;

    /** parser.e:676	  	return t*/
    _28398 = NOVALUE;
    DeRef(_28408);
    _28408 = NOVALUE;
    _28447 = NOVALUE;
    DeRef(_28401);
    _28401 = NOVALUE;
    DeRef(_28406);
    _28406 = NOVALUE;
    DeRef(_28439);
    _28439 = NOVALUE;
    DeRef(_28410);
    _28410 = NOVALUE;
    DeRef(_28396);
    _28396 = NOVALUE;
    return _t_56178;
    ;
}


object _43next_token()
{
    object _t_56360 = NOVALUE;
    object _s_56361 = NOVALUE;
    object _28497 = NOVALUE;
    object _28496 = NOVALUE;
    object _28495 = NOVALUE;
    object _28494 = NOVALUE;
    object _28493 = NOVALUE;
    object _28492 = NOVALUE;
    object _28491 = NOVALUE;
    object _28490 = NOVALUE;
    object _28488 = NOVALUE;
    object _28487 = NOVALUE;
    object _28486 = NOVALUE;
    object _28485 = NOVALUE;
    object _28483 = NOVALUE;
    object _28481 = NOVALUE;
    object _28479 = NOVALUE;
    object _28475 = NOVALUE;
    object _28472 = NOVALUE;
    object _28469 = NOVALUE;
    object _28467 = NOVALUE;
    object _28465 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:682		sequence s*/

    /** parser.e:684		if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_43backed_up_tok_55412)){
            _28465 = SEQ_PTR(_43backed_up_tok_55412)->length;
    }
    else {
        _28465 = 1;
    }
    if (_28465 <= 0)
    goto L1; // [10] 82

    /** parser.e:685			t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_43backed_up_tok_55412)){
            _28467 = SEQ_PTR(_43backed_up_tok_55412)->length;
    }
    else {
        _28467 = 1;
    }
    DeRef(_t_56360);
    _2 = (object)SEQ_PTR(_43backed_up_tok_55412);
    _t_56360 = (object)*(((s1_ptr)_2)->base + _28467);
    Ref(_t_56360);

    /** parser.e:686			backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_43backed_up_tok_55412)){
            _28469 = SEQ_PTR(_43backed_up_tok_55412)->length;
    }
    else {
        _28469 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43backed_up_tok_55412);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28469)) ? _28469 : (object)(DBL_PTR(_28469)->dbl);
        int stop = (IS_ATOM_INT(_28469)) ? _28469 : (object)(DBL_PTR(_28469)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43backed_up_tok_55412), start, &_43backed_up_tok_55412 );
            }
            else Tail(SEQ_PTR(_43backed_up_tok_55412), stop+1, &_43backed_up_tok_55412);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43backed_up_tok_55412), start, &_43backed_up_tok_55412);
        }
        else {
            assign_slice_seq = &assign_space;
            _43backed_up_tok_55412 = Remove_elements(start, stop, (SEQ_PTR(_43backed_up_tok_55412)->ref == 1));
        }
    }
    _28469 = NOVALUE;
    _28469 = NOVALUE;

    /** parser.e:687			if putback_fwd_line_number then*/
    if (_27putback_fwd_line_number_20574 == 0)
    {
        goto L2; // [43] 349
    }
    else{
    }

    /** parser.e:689				ForwardLine     = putback_ForwardLine*/
    Ref(_49putback_ForwardLine_49644);
    DeRef(_49ForwardLine_49643);
    _49ForwardLine_49643 = _49putback_ForwardLine_49644;

    /** parser.e:690				forward_bp      = putback_forward_bp*/
    _49forward_bp_49647 = _49putback_forward_bp_49648;

    /** parser.e:691				fwd_line_number = putback_fwd_line_number*/
    _27fwd_line_number_20573 = _27putback_fwd_line_number_20574;

    /** parser.e:693				putback_fwd_line_number = 0*/
    _27putback_fwd_line_number_20574 = 0;
    goto L2; // [79] 349
L1: 

    /** parser.e:696		elsif Parser_mode = PAM_PLAYBACK then*/
    if (_27Parser_mode_20677 != -1)
    goto L3; // [88] 302

    /** parser.e:697			if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_55449)){
            _28472 = SEQ_PTR(_43canned_tokens_55449)->length;
    }
    else {
        _28472 = 1;
    }
    if (_43canned_index_55450 > _28472)
    goto L4; // [101] 150

    /** parser.e:698				t = canned_tokens[canned_index]*/
    DeRef(_t_56360);
    _2 = (object)SEQ_PTR(_43canned_tokens_55449);
    _t_56360 = (object)*(((s1_ptr)_2)->base + _43canned_index_55450);
    Ref(_t_56360);

    /** parser.e:699				if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_43canned_tokens_55449)){
            _28475 = SEQ_PTR(_43canned_tokens_55449)->length;
    }
    else {
        _28475 = 1;
    }
    if (_43canned_index_55450 >= _28475)
    goto L5; // [124] 139

    /** parser.e:700					canned_index += 1*/
    _43canned_index_55450 = _43canned_index_55450 + 1;
    goto L6; // [136] 157
L5: 

    /** parser.e:702		            s = restore_parser()*/
    _0 = _s_56361;
    _s_56361 = _43restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** parser.e:705		    	InternalErr(266)*/
    RefDS(_22209);
    _49InternalErr(266, _22209);
L6: 

    /** parser.e:707			if t[T_ID] = RECORDED then*/
    _2 = (object)SEQ_PTR(_t_56360);
    _28479 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28479, 508)){
        _28479 = NOVALUE;
        goto L7; // [169] 188
    }
    _28479 = NOVALUE;

    /** parser.e:708				t=read_recorded_token(t[T_SYM])*/
    _2 = (object)SEQ_PTR(_t_56360);
    _28481 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28481);
    _0 = _t_56360;
    _t_56360 = _43read_recorded_token(_28481);
    DeRef(_0);
    _28481 = NOVALUE;
    goto L2; // [185] 349
L7: 

    /** parser.e:709			elsif t[T_ID] = DEF_PARAM then*/
    _2 = (object)SEQ_PTR(_t_56360);
    _28483 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28483, 510)){
        _28483 = NOVALUE;
        goto L2; // [198] 349
    }
    _28483 = NOVALUE;

    /** parser.e:710	        	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_43nested_calls_56152)){
            _28485 = SEQ_PTR(_43nested_calls_56152)->length;
    }
    else {
        _28485 = 1;
    }
    {
        object _i_56408;
        _i_56408 = _28485;
L8: 
        if (_i_56408 < 1){
            goto L9; // [209] 288
        }

        /** parser.e:711	        	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (object)SEQ_PTR(_43nested_calls_56152);
        _28486 = (object)*(((s1_ptr)_2)->base + _i_56408);
        _2 = (object)SEQ_PTR(_t_56360);
        _28487 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_28487);
        _28488 = (object)*(((s1_ptr)_2)->base + 2);
        _28487 = NOVALUE;
        if (binary_op_a(NOTEQ, _28486, _28488)){
            _28486 = NOVALUE;
            _28488 = NOVALUE;
            goto LA; // [234] 281
        }
        _28486 = NOVALUE;
        _28488 = NOVALUE;

        /** parser.e:712						return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (object)SEQ_PTR(_43parseargs_states_56144);
        _28490 = (object)*(((s1_ptr)_2)->base + _i_56408);
        _2 = (object)SEQ_PTR(_28490);
        _28491 = (object)*(((s1_ptr)_2)->base + 1);
        _28490 = NOVALUE;
        _2 = (object)SEQ_PTR(_t_56360);
        _28492 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_28492);
        _28493 = (object)*(((s1_ptr)_2)->base + 1);
        _28492 = NOVALUE;
        if (IS_ATOM_INT(_28491) && IS_ATOM_INT(_28493)) {
            _28494 = _28491 + _28493;
        }
        else {
            _28494 = binary_op(PLUS, _28491, _28493);
        }
        _28491 = NOVALUE;
        _28493 = NOVALUE;
        _2 = (object)SEQ_PTR(_27private_sym_20684);
        if (!IS_ATOM_INT(_28494)){
            _28495 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28494)->dbl));
        }
        else{
            _28495 = (object)*(((s1_ptr)_2)->base + _28494);
        }
        Ref(_28495);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _28495;
        _28496 = MAKE_SEQ(_1);
        _28495 = NOVALUE;
        DeRef(_t_56360);
        DeRef(_s_56361);
        DeRef(_28494);
        _28494 = NOVALUE;
        return _28496;
LA: 

        /** parser.e:714				end for*/
        _i_56408 = _i_56408 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** parser.e:715				CompileErr(INTERNAL_NESTED_CALL_PARSING_ERROR)*/
    RefDS(_22209);
    _49CompileErr(98, _22209, 0);
    goto L2; // [299] 349
L3: 

    /** parser.e:717		elsif lock_scanner then*/
    if (_43lock_scanner_56150 == 0)
    {
        goto LB; // [306] 324
    }
    else{
    }

    /** parser.e:718			return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 505;
    ((intptr_t *)_2)[2] = 0;
    _28497 = MAKE_SEQ(_1);
    DeRef(_t_56360);
    DeRef(_s_56361);
    DeRef(_28494);
    _28494 = NOVALUE;
    DeRef(_28496);
    _28496 = NOVALUE;
    return _28497;
    goto L2; // [321] 349
LB: 

    /** parser.e:720		    t = Scanner()*/
    _0 = _t_56360;
    _t_56360 = _61Scanner();
    DeRef(_0);

    /** parser.e:721		    if Parser_mode = PAM_RECORD then*/
    if (_27Parser_mode_20677 != 1)
    goto LC; // [335] 348

    /** parser.e:722		        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_56360);
    Append(&_43canned_tokens_55449, _43canned_tokens_55449, _t_56360);
LC: 
L2: 

    /** parser.e:725		putback_fwd_line_number = 0*/
    _27putback_fwd_line_number_20574 = 0;

    /** parser.e:726		return t*/
    DeRef(_s_56361);
    DeRef(_28497);
    _28497 = NOVALUE;
    DeRef(_28494);
    _28494 = NOVALUE;
    DeRef(_28496);
    _28496 = NOVALUE;
    return _t_56360;
    ;
}


object _43Expr_list()
{
    object _tok_56444 = NOVALUE;
    object _n_56445 = NOVALUE;
    object _28513 = NOVALUE;
    object _28510 = NOVALUE;
    object _28509 = NOVALUE;
    object _28507 = NOVALUE;
    object _28506 = NOVALUE;
    object _28502 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:734		integer n*/

    /** parser.e:736		tok = next_token()*/
    _0 = _tok_56444;
    _tok_56444 = _43next_token();
    DeRef(_0);

    /** parser.e:737		putback(tok)*/
    Ref(_tok_56444);
    _43putback(_tok_56444);

    /** parser.e:738		if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_56444);
    _28502 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28502, -25)){
        _28502 = NOVALUE;
        goto L1; // [23] 36
    }
    _28502 = NOVALUE;

    /** parser.e:739			return 0*/
    DeRef(_tok_56444);
    return 0;
    goto L2; // [33] 142
L1: 

    /** parser.e:741			n = 0*/
    _n_56445 = 0;

    /** parser.e:742			short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:743			while TRUE do*/
L3: 
    if (_9TRUE_441 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** parser.e:744				gListItem &= 1*/
    Append(&_43gListItem_55441, _43gListItem_55441, 1);

    /** parser.e:745				Expr()*/
    _43Expr();

    /** parser.e:746				n += gListItem[$]*/
    if (IS_SEQUENCE(_43gListItem_55441)){
            _28506 = SEQ_PTR(_43gListItem_55441)->length;
    }
    else {
        _28506 = 1;
    }
    _2 = (object)SEQ_PTR(_43gListItem_55441);
    _28507 = (object)*(((s1_ptr)_2)->base + _28506);
    _n_56445 = _n_56445 + _28507;
    _28507 = NOVALUE;

    /** parser.e:747				gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_43gListItem_55441)){
            _28509 = SEQ_PTR(_43gListItem_55441)->length;
    }
    else {
        _28509 = 1;
    }
    _28510 = _28509 - 1;
    _28509 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43gListItem_55441;
    RHS_Slice(_43gListItem_55441, 1, _28510);

    /** parser.e:748				tok = next_token()*/
    _0 = _tok_56444;
    _tok_56444 = _43next_token();
    DeRef(_0);

    /** parser.e:749				if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56444);
    _28513 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28513, -30)){
        _28513 = NOVALUE;
        goto L3; // [119] 54
    }
    _28513 = NOVALUE;

    /** parser.e:750					exit*/
    goto L4; // [125] 133

    /** parser.e:752			end while*/
    goto L3; // [130] 54
L4: 

    /** parser.e:753			short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;
L2: 

    /** parser.e:755		putback(tok)*/
    Ref(_tok_56444);
    _43putback(_tok_56444);

    /** parser.e:756		return n*/
    DeRef(_tok_56444);
    DeRef(_28510);
    _28510 = NOVALUE;
    return _n_56445;
    ;
}


void _43tok_match(object _tok_56473, object _prevtok_56474)
{
    object _t_56476 = NOVALUE;
    object _expected_56477 = NOVALUE;
    object _actual_56478 = NOVALUE;
    object _prevname_56479 = NOVALUE;
    object _28525 = NOVALUE;
    object _28523 = NOVALUE;
    object _28520 = NOVALUE;
    object _28517 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:762		sequence expected, actual, prevname*/

    /** parser.e:764		t = next_token()*/
    _0 = _t_56476;
    _t_56476 = _43next_token();
    DeRef(_0);

    /** parser.e:765		if t[T_ID] != tok then*/
    _2 = (object)SEQ_PTR(_t_56476);
    _28517 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28517, _tok_56473)){
        _28517 = NOVALUE;
        goto L1; // [20] 96
    }
    _28517 = NOVALUE;

    /** parser.e:766			expected = LexName(tok)*/
    RefDS(_26621);
    _0 = _expected_56477;
    _expected_56477 = _45LexName(_tok_56473, _26621);
    DeRef(_0);

    /** parser.e:767			actual = LexName(t[T_ID])*/
    _2 = (object)SEQ_PTR(_t_56476);
    _28520 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_28520);
    RefDS(_26621);
    _0 = _actual_56478;
    _actual_56478 = _45LexName(_28520, _26621);
    DeRef(_0);
    _28520 = NOVALUE;

    /** parser.e:768			if prevtok = 0 then*/
    if (_prevtok_56474 != 0)
    goto L2; // [50] 70

    /** parser.e:769				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_POSSIBLY_1_NOT_2, {expected, actual})*/
    RefDS(_actual_56478);
    RefDS(_expected_56477);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _expected_56477;
    ((intptr_t *)_2)[2] = _actual_56478;
    _28523 = MAKE_SEQ(_1);
    _49CompileErr(132, _28523, 0);
    _28523 = NOVALUE;
    goto L3; // [67] 95
L2: 

    /** parser.e:771				prevname = LexName(prevtok)*/
    RefDS(_26621);
    _0 = _prevname_56479;
    _prevname_56479 = _45LexName(_prevtok_56474, _26621);
    DeRef(_0);

    /** parser.e:772				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_1_AFTER_2_NOT_3, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_expected_56477);
    ((intptr_t*)_2)[1] = _expected_56477;
    RefDS(_prevname_56479);
    ((intptr_t*)_2)[2] = _prevname_56479;
    RefDS(_actual_56478);
    ((intptr_t*)_2)[3] = _actual_56478;
    _28525 = MAKE_SEQ(_1);
    _49CompileErr(138, _28525, 0);
    _28525 = NOVALUE;
L3: 
L1: 

    /** parser.e:775	end procedure*/
    DeRef(_t_56476);
    DeRef(_expected_56477);
    DeRef(_actual_56478);
    DeRef(_prevname_56479);
    return;
    ;
}


void _43UndefinedVar(object _s_56515)
{
    object _dup_56517 = NOVALUE;
    object _errmsg_56518 = NOVALUE;
    object _rname_56519 = NOVALUE;
    object _fname_56520 = NOVALUE;
    object _28548 = NOVALUE;
    object _28547 = NOVALUE;
    object _28545 = NOVALUE;
    object _28543 = NOVALUE;
    object _28542 = NOVALUE;
    object _28540 = NOVALUE;
    object _28538 = NOVALUE;
    object _28536 = NOVALUE;
    object _28535 = NOVALUE;
    object _28534 = NOVALUE;
    object _28533 = NOVALUE;
    object _28532 = NOVALUE;
    object _28530 = NOVALUE;
    object _28529 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_56515)) {
        _1 = (object)(DBL_PTR(_s_56515)->dbl);
        DeRefDS(_s_56515);
        _s_56515 = _1;
    }

    /** parser.e:790		sequence errmsg*/

    /** parser.e:791		sequence rname*/

    /** parser.e:792		sequence fname*/

    /** parser.e:794		if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28529 = (object)*(((s1_ptr)_2)->base + _s_56515);
    _2 = (object)SEQ_PTR(_28529);
    _28530 = (object)*(((s1_ptr)_2)->base + 4);
    _28529 = NOVALUE;
    if (binary_op_a(NOTEQ, _28530, 9)){
        _28530 = NOVALUE;
        goto L1; // [25] 57
    }
    _28530 = NOVALUE;

    /** parser.e:795			CompileErr(MSG_1_HAS_NOT_BEEN_DECLARED, {SymTab[s][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28532 = (object)*(((s1_ptr)_2)->base + _s_56515);
    _2 = (object)SEQ_PTR(_28532);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28533 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28533 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28532 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_28533);
    ((intptr_t*)_2)[1] = _28533;
    _28534 = MAKE_SEQ(_1);
    _28533 = NOVALUE;
    _49CompileErr(19, _28534, 0);
    _28534 = NOVALUE;
    goto L2; // [54] 206
L1: 

    /** parser.e:797		elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28535 = (object)*(((s1_ptr)_2)->base + _s_56515);
    _2 = (object)SEQ_PTR(_28535);
    _28536 = (object)*(((s1_ptr)_2)->base + 4);
    _28535 = NOVALUE;
    if (binary_op_a(NOTEQ, _28536, 10)){
        _28536 = NOVALUE;
        goto L3; // [73] 183
    }
    _28536 = NOVALUE;

    /** parser.e:798			rname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28538 = (object)*(((s1_ptr)_2)->base + _s_56515);
    DeRef(_rname_56519);
    _2 = (object)SEQ_PTR(_28538);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _rname_56519 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _rname_56519 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_rname_56519);
    _28538 = NOVALUE;

    /** parser.e:799			errmsg = ""*/
    RefDS(_22209);
    DeRef(_errmsg_56518);
    _errmsg_56518 = _22209;

    /** parser.e:801			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_48371)){
            _28540 = SEQ_PTR(_53dup_globals_48371)->length;
    }
    else {
        _28540 = 1;
    }
    {
        object _i_56547;
        _i_56547 = 1;
L4: 
        if (_i_56547 > _28540){
            goto L5; // [107] 165
        }

        /** parser.e:802				dup = dup_globals[i]*/
        _2 = (object)SEQ_PTR(_53dup_globals_48371);
        _dup_56517 = (object)*(((s1_ptr)_2)->base + _i_56547);
        if (!IS_ATOM_INT(_dup_56517)){
            _dup_56517 = (object)DBL_PTR(_dup_56517)->dbl;
        }

        /** parser.e:803				fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28542 = (object)*(((s1_ptr)_2)->base + _dup_56517);
        _2 = (object)SEQ_PTR(_28542);
        if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
            _28543 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
        }
        else{
            _28543 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
        }
        _28542 = NOVALUE;
        DeRef(_fname_56520);
        _2 = (object)SEQ_PTR(_28known_files_11573);
        if (!IS_ATOM_INT(_28543)){
            _fname_56520 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28543)->dbl));
        }
        else{
            _fname_56520 = (object)*(((s1_ptr)_2)->base + _28543);
        }
        Ref(_fname_56520);

        /** parser.e:804				errmsg &= "    " & fname & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22404;
            concat_list[1] = _fname_56520;
            concat_list[2] = _25115;
            Concat_N((object_ptr)&_28545, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_56518, _errmsg_56518, _28545);
        DeRefDS(_28545);
        _28545 = NOVALUE;

        /** parser.e:806			end for*/
        _i_56547 = _i_56547 + 1;
        goto L4; // [160] 114
L5: 
        ;
    }

    /** parser.e:808			CompileErr(A_NAMESPACE_QUALIFIER_IS_NEEDED_TO_RESOLVE_1BECAUSE_2_IS_DECLARED_AS_A_GLOBALPUBLIC_SYMBOL_IN3, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_rname_56519, 2);
    ((intptr_t*)_2)[1] = _rname_56519;
    ((intptr_t*)_2)[2] = _rname_56519;
    RefDS(_errmsg_56518);
    ((intptr_t*)_2)[3] = _errmsg_56518;
    _28547 = MAKE_SEQ(_1);
    _49CompileErr(23, _28547, 0);
    _28547 = NOVALUE;
    goto L2; // [180] 206
L3: 

    /** parser.e:810		elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_27symbol_resolution_warning_20673)){
            _28548 = SEQ_PTR(_27symbol_resolution_warning_20673)->length;
    }
    else {
        _28548 = 1;
    }
    if (_28548 == 0)
    {
        _28548 = NOVALUE;
        goto L6; // [190] 205
    }
    else{
        _28548 = NOVALUE;
    }

    /** parser.e:811			Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_27symbol_resolution_warning_20673);
    RefDS(_22209);
    _49Warning(_27symbol_resolution_warning_20673, 1, _22209);
L6: 
L2: 

    /** parser.e:813	end procedure*/
    DeRef(_errmsg_56518);
    DeRef(_rname_56519);
    DeRef(_fname_56520);
    _28543 = NOVALUE;
    return;
    ;
}


void _43WrongNumberArgs(object _subsym_56572, object _only_56573)
{
    object _msgno_56574 = NOVALUE;
    object _28560 = NOVALUE;
    object _28559 = NOVALUE;
    object _28558 = NOVALUE;
    object _28557 = NOVALUE;
    object _28556 = NOVALUE;
    object _28554 = NOVALUE;
    object _28552 = NOVALUE;
    object _28550 = NOVALUE;
    object _28549 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56572)) {
        _1 = (object)(DBL_PTR(_subsym_56572)->dbl);
        DeRefDS(_subsym_56572);
        _subsym_56572 = _1;
    }

    /** parser.e:819		if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28549 = (object)*(((s1_ptr)_2)->base + _subsym_56572);
    _2 = (object)SEQ_PTR(_28549);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _28550 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _28550 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _28549 = NOVALUE;
    if (binary_op_a(NOTEQ, _28550, 1)){
        _28550 = NOVALUE;
        goto L1; // [19] 49
    }
    _28550 = NOVALUE;

    /** parser.e:820			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56573)){
            _28552 = SEQ_PTR(_only_56573)->length;
    }
    else {
        _28552 = 1;
    }
    if (_28552 != 0)
    goto L2; // [28] 40

    /** parser.e:821				msgno = 20*/
    _msgno_56574 = 20;
    goto L3; // [37] 73
L2: 

    /** parser.e:823				msgno = 237*/
    _msgno_56574 = 237;
    goto L3; // [46] 73
L1: 

    /** parser.e:826			if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_56573)){
            _28554 = SEQ_PTR(_only_56573)->length;
    }
    else {
        _28554 = 1;
    }
    if (_28554 != 0)
    goto L4; // [54] 66

    /** parser.e:827				msgno = 236*/
    _msgno_56574 = 236;
    goto L5; // [63] 72
L4: 

    /** parser.e:829				msgno = 238*/
    _msgno_56574 = 238;
L5: 
L3: 

    /** parser.e:833		CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28556 = (object)*(((s1_ptr)_2)->base + _subsym_56572);
    _2 = (object)SEQ_PTR(_28556);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28557 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28557 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28556 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28558 = (object)*(((s1_ptr)_2)->base + _subsym_56572);
    _2 = (object)SEQ_PTR(_28558);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _28559 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _28559 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _28558 = NOVALUE;
    Ref(_28559);
    Ref(_28557);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28557;
    ((intptr_t *)_2)[2] = _28559;
    _28560 = MAKE_SEQ(_1);
    _28559 = NOVALUE;
    _28557 = NOVALUE;
    _49CompileErr(_msgno_56574, _28560, 0);
    _28560 = NOVALUE;

    /** parser.e:834	end procedure*/
    DeRefDSi(_only_56573);
    return;
    ;
}


void _43MissingArgs(object _subsym_56603)
{
    object _eentry_56604 = NOVALUE;
    object _28565 = NOVALUE;
    object _28564 = NOVALUE;
    object _28563 = NOVALUE;
    object _28562 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:837		sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_56604);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _eentry_56604 = (object)*(((s1_ptr)_2)->base + _subsym_56603);
    Ref(_eentry_56604);

    /** parser.e:839		CompileErr(MSG_1_NEEDS_AT_LEAST_2_PARAMETERS_BUT_SOME_NONDEFAULTABLE_ARGUMENTS_ARE_MISSING, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (object)SEQ_PTR(_eentry_56604);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28562 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28562 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _2 = (object)SEQ_PTR(_eentry_56604);
    _28563 = (object)*(((s1_ptr)_2)->base + 28);
    _2 = (object)SEQ_PTR(_28563);
    _28564 = (object)*(((s1_ptr)_2)->base + 2);
    _28563 = NOVALUE;
    Ref(_28564);
    Ref(_28562);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _28562;
    ((intptr_t *)_2)[2] = _28564;
    _28565 = MAKE_SEQ(_1);
    _28564 = NOVALUE;
    _28562 = NOVALUE;
    _49CompileErr(235, _28565, 0);
    _28565 = NOVALUE;

    /** parser.e:840	end procedure*/
    DeRefDS(_eentry_56604);
    return;
    ;
}


void _43Parse_default_arg(object _subsym_56618, object _arg_56619, object _fwd_private_list_56620, object _fwd_private_sym_56621)
{
    object _param_56623 = NOVALUE;
    object _28585 = NOVALUE;
    object _28584 = NOVALUE;
    object _28583 = NOVALUE;
    object _28582 = NOVALUE;
    object _28581 = NOVALUE;
    object _28580 = NOVALUE;
    object _28579 = NOVALUE;
    object _28578 = NOVALUE;
    object _28577 = NOVALUE;
    object _28576 = NOVALUE;
    object _28575 = NOVALUE;
    object _28574 = NOVALUE;
    object _28573 = NOVALUE;
    object _28571 = NOVALUE;
    object _28570 = NOVALUE;
    object _28567 = NOVALUE;
    object _28566 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:843		symtab_index param = subsym*/
    _param_56623 = _subsym_56618;

    /** parser.e:844		on_arg = arg*/
    _43on_arg_56151 = _arg_56619;

    /** parser.e:845		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_56149)){
            _28566 = SEQ_PTR(_43private_list_56149)->length;
    }
    else {
        _28566 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28566;
    ((intptr_t*)_2)[2] = _43lock_scanner_56150;
    ((intptr_t*)_2)[3] = _27use_private_list_20685;
    ((intptr_t*)_2)[4] = _43on_arg_56151;
    _28567 = MAKE_SEQ(_1);
    _28566 = NOVALUE;
    RefDS(_28567);
    Append(&_43parseargs_states_56144, _43parseargs_states_56144, _28567);
    DeRefDS(_28567);
    _28567 = NOVALUE;

    /** parser.e:847		nested_calls &= subsym*/
    Append(&_43nested_calls_56152, _43nested_calls_56152, _subsym_56618);

    /** parser.e:849		for i = 1 to arg do*/
    _28570 = _arg_56619;
    {
        object _i_56630;
        _i_56630 = 1;
L1: 
        if (_i_56630 > _28570){
            goto L2; // [60] 90
        }

        /** parser.e:850			param = SymTab[param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28571 = (object)*(((s1_ptr)_2)->base + _param_56623);
        _2 = (object)SEQ_PTR(_28571);
        _param_56623 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_56623)){
            _param_56623 = (object)DBL_PTR(_param_56623)->dbl;
        }
        _28571 = NOVALUE;

        /** parser.e:851		end for*/
        _i_56630 = _i_56630 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** parser.e:853		private_list = fwd_private_list*/
    RefDS(_fwd_private_list_56620);
    DeRef(_43private_list_56149);
    _43private_list_56149 = _fwd_private_list_56620;

    /** parser.e:854		private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_56621);
    DeRef(_27private_sym_20684);
    _27private_sym_20684 = _fwd_private_sym_56621;

    /** parser.e:856		if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28573 = (object)*(((s1_ptr)_2)->base + _param_56623);
    _2 = (object)SEQ_PTR(_28573);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _28574 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _28574 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _28573 = NOVALUE;
    _28575 = IS_ATOM(_28574);
    _28574 = NOVALUE;
    if (_28575 == 0)
    {
        _28575 = NOVALUE;
        goto L3; // [121] 164
    }
    else{
        _28575 = NOVALUE;
    }

    /** parser.e:857			CompileErr(ARGUMENT_1_OF_2_3_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28576 = (object)*(((s1_ptr)_2)->base + _subsym_56618);
    _2 = (object)SEQ_PTR(_28576);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28577 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28577 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28576 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28578 = (object)*(((s1_ptr)_2)->base + _param_56623);
    _2 = (object)SEQ_PTR(_28578);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28579 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28579 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28578 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _arg_56619;
    Ref(_28577);
    ((intptr_t*)_2)[2] = _28577;
    Ref(_28579);
    ((intptr_t*)_2)[3] = _28579;
    _28580 = MAKE_SEQ(_1);
    _28579 = NOVALUE;
    _28577 = NOVALUE;
    _49CompileErr(26, _28580, 0);
    _28580 = NOVALUE;
L3: 

    /** parser.e:860		use_private_list = 1*/
    _27use_private_list_20685 = 1;

    /** parser.e:861		lock_scanner = 1*/
    _43lock_scanner_56150 = 1;

    /** parser.e:862		start_playback(SymTab[param][S_CODE] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28581 = (object)*(((s1_ptr)_2)->base + _param_56623);
    _2 = (object)SEQ_PTR(_28581);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _28582 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _28582 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _28581 = NOVALUE;
    Ref(_28582);
    _43start_playback(_28582);
    _28582 = NOVALUE;

    /** parser.e:863		call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56440].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:865		add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28583 = _45Top();
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28584 = (object)*(((s1_ptr)_2)->base + _param_56623);
    _2 = (object)SEQ_PTR(_28584);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28585 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28585 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28584 = NOVALUE;
    Ref(_28585);
    _42add_private_symbol(_28583, _28585);
    _28583 = NOVALUE;
    _28585 = NOVALUE;

    /** parser.e:866		lock_scanner = 0*/
    _43lock_scanner_56150 = 0;

    /** parser.e:867		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:868	end procedure*/
    DeRefDS(_fwd_private_list_56620);
    DeRefDSi(_fwd_private_sym_56621);
    return;
    ;
}


void _43ParseArgs(object _subsym_56669)
{
    object _n_56670 = NOVALUE;
    object _fda_56671 = NOVALUE;
    object _lnda_56672 = NOVALUE;
    object _tok_56674 = NOVALUE;
    object _s_56676 = NOVALUE;
    object _var_code_56677 = NOVALUE;
    object _name_56678 = NOVALUE;
    object _28695 = NOVALUE;
    object _28693 = NOVALUE;
    object _28689 = NOVALUE;
    object _28688 = NOVALUE;
    object _28687 = NOVALUE;
    object _28684 = NOVALUE;
    object _28681 = NOVALUE;
    object _28679 = NOVALUE;
    object _28677 = NOVALUE;
    object _28675 = NOVALUE;
    object _28673 = NOVALUE;
    object _28672 = NOVALUE;
    object _28671 = NOVALUE;
    object _28670 = NOVALUE;
    object _28669 = NOVALUE;
    object _28668 = NOVALUE;
    object _28667 = NOVALUE;
    object _28661 = NOVALUE;
    object _28660 = NOVALUE;
    object _28659 = NOVALUE;
    object _28658 = NOVALUE;
    object _28657 = NOVALUE;
    object _28656 = NOVALUE;
    object _28653 = NOVALUE;
    object _28650 = NOVALUE;
    object _28645 = NOVALUE;
    object _28643 = NOVALUE;
    object _28642 = NOVALUE;
    object _28641 = NOVALUE;
    object _28639 = NOVALUE;
    object _28636 = NOVALUE;
    object _28633 = NOVALUE;
    object _28631 = NOVALUE;
    object _28629 = NOVALUE;
    object _28627 = NOVALUE;
    object _28625 = NOVALUE;
    object _28624 = NOVALUE;
    object _28623 = NOVALUE;
    object _28622 = NOVALUE;
    object _28621 = NOVALUE;
    object _28620 = NOVALUE;
    object _28619 = NOVALUE;
    object _28617 = NOVALUE;
    object _28616 = NOVALUE;
    object _28615 = NOVALUE;
    object _28614 = NOVALUE;
    object _28613 = NOVALUE;
    object _28612 = NOVALUE;
    object _28609 = NOVALUE;
    object _28608 = NOVALUE;
    object _28607 = NOVALUE;
    object _28605 = NOVALUE;
    object _28604 = NOVALUE;
    object _28602 = NOVALUE;
    object _28598 = NOVALUE;
    object _28597 = NOVALUE;
    object _28595 = NOVALUE;
    object _28594 = NOVALUE;
    object _28592 = NOVALUE;
    object _28591 = NOVALUE;
    object _28590 = NOVALUE;
    object _28589 = NOVALUE;
    object _28588 = NOVALUE;
    object _28586 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_56669)) {
        _1 = (object)(DBL_PTR(_subsym_56669)->dbl);
        DeRefDS(_subsym_56669);
        _subsym_56669 = _1;
    }

    /** parser.e:875		object var_code*/

    /** parser.e:876		sequence name*/

    /** parser.e:878		n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28586 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
    _2 = (object)SEQ_PTR(_28586);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_56670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_56670 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_56670)){
        _n_56670 = (object)DBL_PTR(_n_56670)->dbl;
    }
    _28586 = NOVALUE;

    /** parser.e:879		if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28588 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
    _2 = (object)SEQ_PTR(_28588);
    _28589 = (object)*(((s1_ptr)_2)->base + 28);
    _28588 = NOVALUE;
    _28590 = IS_SEQUENCE(_28589);
    _28589 = NOVALUE;
    if (_28590 == 0)
    {
        _28590 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28590 = NOVALUE;
    }

    /** parser.e:880			fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28591 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
    _2 = (object)SEQ_PTR(_28591);
    _28592 = (object)*(((s1_ptr)_2)->base + 28);
    _28591 = NOVALUE;
    _2 = (object)SEQ_PTR(_28592);
    _fda_56671 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_56671)){
        _fda_56671 = (object)DBL_PTR(_fda_56671)->dbl;
    }
    _28592 = NOVALUE;

    /** parser.e:881			lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28594 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
    _2 = (object)SEQ_PTR(_28594);
    _28595 = (object)*(((s1_ptr)_2)->base + 28);
    _28594 = NOVALUE;
    _2 = (object)SEQ_PTR(_28595);
    _lnda_56672 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_56672)){
        _lnda_56672 = (object)DBL_PTR(_lnda_56672)->dbl;
    }
    _28595 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** parser.e:883			fda = 0*/
    _fda_56671 = 0;

    /** parser.e:884			lnda = 0*/
    _lnda_56672 = 0;
L2: 

    /** parser.e:886		s = subsym*/
    _s_56676 = _subsym_56669;

    /** parser.e:888		parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_43private_list_56149)){
            _28597 = SEQ_PTR(_43private_list_56149)->length;
    }
    else {
        _28597 = 1;
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28597;
    ((intptr_t*)_2)[2] = _43lock_scanner_56150;
    ((intptr_t*)_2)[3] = _27use_private_list_20685;
    ((intptr_t*)_2)[4] = _43on_arg_56151;
    _28598 = MAKE_SEQ(_1);
    _28597 = NOVALUE;
    RefDS(_28598);
    Append(&_43parseargs_states_56144, _43parseargs_states_56144, _28598);
    DeRefDS(_28598);
    _28598 = NOVALUE;

    /** parser.e:890		nested_calls &= subsym*/
    Append(&_43nested_calls_56152, _43nested_calls_56152, _subsym_56669);

    /** parser.e:891		lock_scanner = 0*/
    _43lock_scanner_56150 = 0;

    /** parser.e:892		on_arg = 0*/
    _43on_arg_56151 = 0;

    /** parser.e:894		short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:895		for i = 1 to n do*/
    _28602 = _n_56670;
    {
        object _i_56707;
        _i_56707 = 1;
L3: 
        if (_i_56707 > _28602){
            goto L4; // [161] 1050
        }

        /** parser.e:897		  	tok = next_token()*/
        _0 = _tok_56674;
        _tok_56674 = _43next_token();
        DeRef(_0);

        /** parser.e:899			if tok[T_ID] = QUESTION_MARK or tok[T_ID] = COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28604 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28604)) {
            _28605 = (_28604 == -31);
        }
        else {
            _28605 = binary_op(EQUALS, _28604, -31);
        }
        _28604 = NOVALUE;
        if (IS_ATOM_INT(_28605)) {
            if (_28605 != 0) {
                goto L5; // [187] 208
            }
        }
        else {
            if (DBL_PTR(_28605)->dbl != 0.0) {
                goto L5; // [187] 208
            }
        }
        _2 = (object)SEQ_PTR(_tok_56674);
        _28607 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28607)) {
            _28608 = (_28607 == -30);
        }
        else {
            _28608 = binary_op(EQUALS, _28607, -30);
        }
        _28607 = NOVALUE;
        if (_28608 == 0) {
            DeRef(_28608);
            _28608 = NOVALUE;
            goto L6; // [204] 505
        }
        else {
            if (!IS_ATOM_INT(_28608) && DBL_PTR(_28608)->dbl == 0.0){
                DeRef(_28608);
                _28608 = NOVALUE;
                goto L6; // [204] 505
            }
            DeRef(_28608);
            _28608 = NOVALUE;
        }
        DeRef(_28608);
        _28608 = NOVALUE;
L5: 

        /** parser.e:902				if tok[T_ID] = QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28609 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28609, -31)){
            _28609 = NOVALUE;
            goto L7; // [218] 297
        }
        _28609 = NOVALUE;

        /** parser.e:903					tok = next_token()*/
        _0 = _tok_56674;
        _tok_56674 = _43next_token();
        DeRef(_0);

        /** parser.e:904					if tok[T_ID] != RIGHT_ROUND and tok[T_ID] != COMMA then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28612 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28612)) {
            _28613 = (_28612 != -27);
        }
        else {
            _28613 = binary_op(NOTEQ, _28612, -27);
        }
        _28612 = NOVALUE;
        if (IS_ATOM_INT(_28613)) {
            if (_28613 == 0) {
                goto L8; // [241] 273
            }
        }
        else {
            if (DBL_PTR(_28613)->dbl == 0.0) {
                goto L8; // [241] 273
            }
        }
        _2 = (object)SEQ_PTR(_tok_56674);
        _28615 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28615)) {
            _28616 = (_28615 != -30);
        }
        else {
            _28616 = binary_op(NOTEQ, _28615, -30);
        }
        _28615 = NOVALUE;
        if (_28616 == 0) {
            DeRef(_28616);
            _28616 = NOVALUE;
            goto L8; // [258] 273
        }
        else {
            if (!IS_ATOM_INT(_28616) && DBL_PTR(_28616)->dbl == 0.0){
                DeRef(_28616);
                _28616 = NOVALUE;
                goto L8; // [258] 273
            }
            DeRef(_28616);
            _28616 = NOVALUE;
        }
        DeRef(_28616);
        _28616 = NOVALUE;

        /** parser.e:905						CompileErr( BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
        RefDS(_22209);
        _49CompileErr(41, _22209, 0);
        goto L9; // [270] 298
L8: 

        /** parser.e:906					elsif tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28617 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28617, -27)){
            _28617 = NOVALUE;
            goto L9; // [283] 298
        }
        _28617 = NOVALUE;

        /** parser.e:907						putback( tok )*/
        Ref(_tok_56674);
        _43putback(_tok_56674);
        goto L9; // [294] 298
L7: 
L9: 

        /** parser.e:912				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28619 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28619);
        _28620 = (object)*(((s1_ptr)_2)->base + 21);
        _28619 = NOVALUE;
        if (_28620 == 0) {
            _28620 = NOVALUE;
            goto LA; // [312] 372
        }
        else {
            if (!IS_ATOM_INT(_28620) && DBL_PTR(_28620)->dbl == 0.0){
                _28620 = NOVALUE;
                goto LA; // [312] 372
            }
            _28620 = NOVALUE;
        }
        _28620 = NOVALUE;

        /** parser.e:913					if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28621 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28621);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28622 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28621 = NOVALUE;
        _28623 = IS_ATOM(_28622);
        _28622 = NOVALUE;
        if (_28623 == 0)
        {
            _28623 = NOVALUE;
            goto LB; // [332] 343
        }
        else{
            _28623 = NOVALUE;
        }

        /** parser.e:914						var_code = 0*/
        DeRef(_var_code_56677);
        _var_code_56677 = 0;
        goto LC; // [340] 362
LB: 

        /** parser.e:916						var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28624 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28624);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28625 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28625 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28624 = NOVALUE;
        DeRef(_var_code_56677);
        _2 = (object)SEQ_PTR(_28625);
        _var_code_56677 = (object)*(((s1_ptr)_2)->base + _i_56707);
        Ref(_var_code_56677);
        _28625 = NOVALUE;
LC: 

        /** parser.e:918					name = ""*/
        RefDS(_22209);
        DeRef(_name_56678);
        _name_56678 = _22209;
        goto LD; // [369] 419
LA: 

        /** parser.e:920					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28627 = (object)*(((s1_ptr)_2)->base + _s_56676);
        _2 = (object)SEQ_PTR(_28627);
        _s_56676 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56676)){
            _s_56676 = (object)DBL_PTR(_s_56676)->dbl;
        }
        _28627 = NOVALUE;

        /** parser.e:921					var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28629 = (object)*(((s1_ptr)_2)->base + _s_56676);
        DeRef(_var_code_56677);
        _2 = (object)SEQ_PTR(_28629);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _var_code_56677 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _var_code_56677 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        Ref(_var_code_56677);
        _28629 = NOVALUE;

        /** parser.e:922					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28631 = (object)*(((s1_ptr)_2)->base + _s_56676);
        DeRef(_name_56678);
        _2 = (object)SEQ_PTR(_28631);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _name_56678 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _name_56678 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_name_56678);
        _28631 = NOVALUE;
LD: 

        /** parser.e:925				if atom(var_code) then  -- but no default set*/
        _28633 = IS_ATOM(_var_code_56677);
        if (_28633 == 0)
        {
            _28633 = NOVALUE;
            goto LE; // [426] 439
        }
        else{
            _28633 = NOVALUE;
        }

        /** parser.e:926					CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED,i)*/
        _49CompileErr(29, _i_56707, 0);
LE: 

        /** parser.e:929				use_private_list = 1*/
        _27use_private_list_20685 = 1;

        /** parser.e:930				start_playback(var_code)*/
        Ref(_var_code_56677);
        _43start_playback(_var_code_56677);

        /** parser.e:931				lock_scanner=1*/
        _43lock_scanner_56150 = 1;

        /** parser.e:934				Expr()*/
        _43Expr();

        /** parser.e:935				lock_scanner=0*/
        _43lock_scanner_56150 = 0;

        /** parser.e:936				on_arg += 1*/
        _43on_arg_56151 = _43on_arg_56151 + 1;

        /** parser.e:937				private_list = append(private_list,name)*/
        RefDS(_name_56678);
        Append(&_43private_list_56149, _43private_list_56149, _name_56678);

        /** parser.e:938				private_sym &= Top()*/
        _28636 = _45Top();
        if (IS_SEQUENCE(_27private_sym_20684) && IS_ATOM(_28636)) {
            Ref(_28636);
            Append(&_27private_sym_20684, _27private_sym_20684, _28636);
        }
        else if (IS_ATOM(_27private_sym_20684) && IS_SEQUENCE(_28636)) {
        }
        else {
            Concat((object_ptr)&_27private_sym_20684, _27private_sym_20684, _28636);
        }
        DeRef(_28636);
        _28636 = NOVALUE;

        /** parser.e:939				backed_up_tok = {tok} -- ????*/
        _0 = _43backed_up_tok_55412;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_tok_56674);
        ((intptr_t*)_2)[1] = _tok_56674;
        _43backed_up_tok_55412 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LF; // [502] 633
L6: 

        /** parser.e:942			elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28639 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28639, -27)){
            _28639 = NOVALUE;
            goto L10; // [515] 632
        }
        _28639 = NOVALUE;

        /** parser.e:944				if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28641 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28641);
        _28642 = (object)*(((s1_ptr)_2)->base + 21);
        _28641 = NOVALUE;
        if (_28642 == 0) {
            _28642 = NOVALUE;
            goto L11; // [533] 546
        }
        else {
            if (!IS_ATOM_INT(_28642) && DBL_PTR(_28642)->dbl == 0.0){
                _28642 = NOVALUE;
                goto L11; // [533] 546
            }
            _28642 = NOVALUE;
        }
        _28642 = NOVALUE;

        /** parser.e:945					name = ""*/
        RefDS(_22209);
        DeRef(_name_56678);
        _name_56678 = _22209;
        goto L12; // [543] 579
L11: 

        /** parser.e:947					s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28643 = (object)*(((s1_ptr)_2)->base + _s_56676);
        _2 = (object)SEQ_PTR(_28643);
        _s_56676 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56676)){
            _s_56676 = (object)DBL_PTR(_s_56676)->dbl;
        }
        _28643 = NOVALUE;

        /** parser.e:948					name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28645 = (object)*(((s1_ptr)_2)->base + _s_56676);
        DeRef(_name_56678);
        _2 = (object)SEQ_PTR(_28645);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _name_56678 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _name_56678 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_name_56678);
        _28645 = NOVALUE;
L12: 

        /** parser.e:951				use_private_list = Parser_mode != PAM_NORMAL*/
        _27use_private_list_20685 = (_27Parser_mode_20677 != 0);

        /** parser.e:952				putback(tok)*/
        Ref(_tok_56674);
        _43putback(_tok_56674);

        /** parser.e:953				Expr()*/
        _43Expr();

        /** parser.e:954				on_arg += 1*/
        _43on_arg_56151 = _43on_arg_56151 + 1;

        /** parser.e:955				private_list = append(private_list,name)*/
        RefDS(_name_56678);
        Append(&_43private_list_56149, _43private_list_56149, _name_56678);

        /** parser.e:956				private_sym &= Top()*/
        _28650 = _45Top();
        if (IS_SEQUENCE(_27private_sym_20684) && IS_ATOM(_28650)) {
            Ref(_28650);
            Append(&_27private_sym_20684, _27private_sym_20684, _28650);
        }
        else if (IS_ATOM(_27private_sym_20684) && IS_SEQUENCE(_28650)) {
        }
        else {
            Concat((object_ptr)&_27private_sym_20684, _27private_sym_20684, _28650);
        }
        DeRef(_28650);
        _28650 = NOVALUE;
L10: 
LF: 

        /** parser.e:959			if on_arg != n then*/
        if (_43on_arg_56151 == _n_56670)
        goto L13; // [637] 1043

        /** parser.e:960				if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28653 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28653, -27)){
            _28653 = NOVALUE;
            goto L14; // [651] 661
        }
        _28653 = NOVALUE;

        /** parser.e:961					putback( tok )*/
        Ref(_tok_56674);
        _43putback(_tok_56674);
L14: 

        /** parser.e:963				tok = next_token()*/
        _0 = _tok_56674;
        _tok_56674 = _43next_token();
        DeRef(_0);

        /** parser.e:964				if tok[T_ID] != COMMA and tok[T_ID] != QUESTION_MARK then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28656 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28656)) {
            _28657 = (_28656 != -30);
        }
        else {
            _28657 = binary_op(NOTEQ, _28656, -30);
        }
        _28656 = NOVALUE;
        if (IS_ATOM_INT(_28657)) {
            if (_28657 == 0) {
                goto L15; // [680] 1042
            }
        }
        else {
            if (DBL_PTR(_28657)->dbl == 0.0) {
                goto L15; // [680] 1042
            }
        }
        _2 = (object)SEQ_PTR(_tok_56674);
        _28659 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_28659)) {
            _28660 = (_28659 != -31);
        }
        else {
            _28660 = binary_op(NOTEQ, _28659, -31);
        }
        _28659 = NOVALUE;
        if (_28660 == 0) {
            DeRef(_28660);
            _28660 = NOVALUE;
            goto L15; // [697] 1042
        }
        else {
            if (!IS_ATOM_INT(_28660) && DBL_PTR(_28660)->dbl == 0.0){
                DeRef(_28660);
                _28660 = NOVALUE;
                goto L15; // [697] 1042
            }
            DeRef(_28660);
            _28660 = NOVALUE;
        }
        DeRef(_28660);
        _28660 = NOVALUE;

        /** parser.e:966			  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (object)SEQ_PTR(_tok_56674);
        _28661 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28661, -27)){
            _28661 = NOVALUE;
            goto L16; // [710] 1027
        }
        _28661 = NOVALUE;

        /** parser.e:968						if fda=0 then*/
        if (_fda_56671 != 0)
        goto L17; // [718] 731

        /** parser.e:969							WrongNumberArgs(subsym, "")*/
        RefDS(_22209);
        _43WrongNumberArgs(_subsym_56669, _22209);
        goto L18; // [728] 746
L17: 

        /** parser.e:970						elsif i<lnda then*/
        if (_i_56707 >= _lnda_56672)
        goto L19; // [735] 745

        /** parser.e:971							MissingArgs(subsym)*/
        _43MissingArgs(_subsym_56669);
L19: 
L18: 

        /** parser.e:973						lock_scanner = 1*/
        _43lock_scanner_56150 = 1;

        /** parser.e:974						use_private_list = 1*/
        _27use_private_list_20685 = 1;

        /** parser.e:977						while on_arg < n do*/
L1A: 
        if (_43on_arg_56151 >= _n_56670)
        goto L1B; // [765] 976

        /** parser.e:978							on_arg += 1*/
        _43on_arg_56151 = _43on_arg_56151 + 1;

        /** parser.e:979							if SymTab[subsym][S_OPCODE] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28667 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28667);
        _28668 = (object)*(((s1_ptr)_2)->base + 21);
        _28667 = NOVALUE;
        if (_28668 == 0) {
            _28668 = NOVALUE;
            goto L1C; // [791] 853
        }
        else {
            if (!IS_ATOM_INT(_28668) && DBL_PTR(_28668)->dbl == 0.0){
                _28668 = NOVALUE;
                goto L1C; // [791] 853
            }
            _28668 = NOVALUE;
        }
        _28668 = NOVALUE;

        /** parser.e:980								if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28669 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28669);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28670 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28670 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28669 = NOVALUE;
        _28671 = IS_ATOM(_28670);
        _28670 = NOVALUE;
        if (_28671 == 0)
        {
            _28671 = NOVALUE;
            goto L1D; // [811] 822
        }
        else{
            _28671 = NOVALUE;
        }

        /** parser.e:981									var_code = 0*/
        DeRef(_var_code_56677);
        _var_code_56677 = 0;
        goto L1E; // [819] 843
L1D: 

        /** parser.e:983									var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28672 = (object)*(((s1_ptr)_2)->base + _subsym_56669);
        _2 = (object)SEQ_PTR(_28672);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _28673 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _28673 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        _28672 = NOVALUE;
        DeRef(_var_code_56677);
        _2 = (object)SEQ_PTR(_28673);
        _var_code_56677 = (object)*(((s1_ptr)_2)->base + _43on_arg_56151);
        Ref(_var_code_56677);
        _28673 = NOVALUE;
L1E: 

        /** parser.e:986								name = ""*/
        RefDS(_22209);
        DeRef(_name_56678);
        _name_56678 = _22209;
        goto L1F; // [850] 900
L1C: 

        /** parser.e:989								s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28675 = (object)*(((s1_ptr)_2)->base + _s_56676);
        _2 = (object)SEQ_PTR(_28675);
        _s_56676 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_56676)){
            _s_56676 = (object)DBL_PTR(_s_56676)->dbl;
        }
        _28675 = NOVALUE;

        /** parser.e:990								var_code = SymTab[s][S_CODE]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28677 = (object)*(((s1_ptr)_2)->base + _s_56676);
        DeRef(_var_code_56677);
        _2 = (object)SEQ_PTR(_28677);
        if (!IS_ATOM_INT(_27S_CODE_20221)){
            _var_code_56677 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
        }
        else{
            _var_code_56677 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
        }
        Ref(_var_code_56677);
        _28677 = NOVALUE;

        /** parser.e:991								name = SymTab[s][S_NAME]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28679 = (object)*(((s1_ptr)_2)->base + _s_56676);
        DeRef(_name_56678);
        _2 = (object)SEQ_PTR(_28679);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _name_56678 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _name_56678 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_name_56678);
        _28679 = NOVALUE;
L1F: 

        /** parser.e:993							if sequence(var_code) then*/
        _28681 = IS_SEQUENCE(_var_code_56677);
        if (_28681 == 0)
        {
            _28681 = NOVALUE;
            goto L20; // [907] 959
        }
        else{
            _28681 = NOVALUE;
        }

        /** parser.e:995								putback( tok )*/
        Ref(_tok_56674);
        _43putback(_tok_56674);

        /** parser.e:996								start_playback(var_code)*/
        Ref(_var_code_56677);
        _43start_playback(_var_code_56677);

        /** parser.e:999								Expr()*/
        _43Expr();

        /** parser.e:1000								if on_arg < n then*/
        if (_43on_arg_56151 >= _n_56670)
        goto L1A; // [928] 763

        /** parser.e:1001									private_list = append(private_list,name)*/
        RefDS(_name_56678);
        Append(&_43private_list_56149, _43private_list_56149, _name_56678);

        /** parser.e:1002									private_sym &= Top()*/
        _28684 = _45Top();
        if (IS_SEQUENCE(_27private_sym_20684) && IS_ATOM(_28684)) {
            Ref(_28684);
            Append(&_27private_sym_20684, _27private_sym_20684, _28684);
        }
        else if (IS_ATOM(_27private_sym_20684) && IS_SEQUENCE(_28684)) {
        }
        else {
            Concat((object_ptr)&_27private_sym_20684, _27private_sym_20684, _28684);
        }
        DeRef(_28684);
        _28684 = NOVALUE;
        goto L1A; // [956] 763
L20: 

        /** parser.e:1005								CompileErr(ARGUMENT_1_WAS_OMITTED_BUT_THERE_IS_NO_DEFAULT_VALUE_DEFINED, on_arg)*/
        _49CompileErr(29, _43on_arg_56151, 0);

        /** parser.e:1007			  		    end while*/
        goto L1A; // [973] 763
L1B: 

        /** parser.e:1009						short_circuit += 1*/
        _43short_circuit_55405 = _43short_circuit_55405 + 1;

        /** parser.e:1010						if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_43backed_up_tok_55412)){
                _28687 = SEQ_PTR(_43backed_up_tok_55412)->length;
        }
        else {
            _28687 = 1;
        }
        _2 = (object)SEQ_PTR(_43backed_up_tok_55412);
        _28688 = (object)*(((s1_ptr)_2)->base + _28687);
        _2 = (object)SEQ_PTR(_28688);
        _28689 = (object)*(((s1_ptr)_2)->base + 1);
        _28688 = NOVALUE;
        if (binary_op_a(NOTEQ, _28689, 505)){
            _28689 = NOVALUE;
            goto L21; // [1003] 1015
        }
        _28689 = NOVALUE;

        /** parser.e:1011							backed_up_tok = {}*/
        RefDS(_22209);
        DeRefDS(_43backed_up_tok_55412);
        _43backed_up_tok_55412 = _22209;
L21: 

        /** parser.e:1014						restore_parseargs_states()*/
        _43restore_parseargs_states();

        /** parser.e:1016						return*/
        DeRef(_tok_56674);
        DeRef(_var_code_56677);
        DeRef(_name_56678);
        DeRef(_28657);
        _28657 = NOVALUE;
        DeRef(_28605);
        _28605 = NOVALUE;
        DeRef(_28613);
        _28613 = NOVALUE;
        return;
        goto L22; // [1024] 1041
L16: 

        /** parser.e:1018						putback(tok)*/
        Ref(_tok_56674);
        _43putback(_tok_56674);

        /** parser.e:1019						tok_match(COMMA)*/
        _43tok_match(-30, 0);
L22: 
L15: 
L13: 

        /** parser.e:1024		end for*/
        _i_56707 = _i_56707 + 1;
        goto L3; // [1045] 168
L4: 
        ;
    }

    /** parser.e:1025		tok = next_token()*/
    _0 = _tok_56674;
    _tok_56674 = _43next_token();
    DeRef(_0);

    /** parser.e:1026		short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;

    /** parser.e:1027		if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_56674);
    _28693 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28693, -27)){
        _28693 = NOVALUE;
        goto L23; // [1073] 1115
    }
    _28693 = NOVALUE;

    /** parser.e:1028			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_56674);
    _28695 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28695, -30)){
        _28695 = NOVALUE;
        goto L24; // [1087] 1100
    }
    _28695 = NOVALUE;

    /** parser.e:1029				WrongNumberArgs(subsym, "only ")*/
    RefDS(_28697);
    _43WrongNumberArgs(_subsym_56669, _28697);
    goto L25; // [1097] 1114
L24: 

    /** parser.e:1031				putback(tok)*/
    Ref(_tok_56674);
    _43putback(_tok_56674);

    /** parser.e:1032				tok_match(RIGHT_ROUND)*/
    _43tok_match(-27, 0);
L25: 
L23: 

    /** parser.e:1036		restore_parseargs_states()*/
    _43restore_parseargs_states();

    /** parser.e:1037	end procedure*/
    DeRef(_tok_56674);
    DeRef(_var_code_56677);
    DeRef(_name_56678);
    DeRef(_28657);
    _28657 = NOVALUE;
    DeRef(_28605);
    _28605 = NOVALUE;
    DeRef(_28613);
    _28613 = NOVALUE;
    return;
    ;
}


void _43Forward_var(object _tok_56919, object _init_check_56920, object _op_56921)
{
    object _ref_56925 = NOVALUE;
    object _28701 = NOVALUE;
    object _28699 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_56921)) {
        _1 = (object)(DBL_PTR(_op_56921)->dbl);
        DeRefDS(_op_56921);
        _op_56921 = _1;
    }

    /** parser.e:1041		ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (object)SEQ_PTR(_tok_56919);
    _28699 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28699);
    _ref_56925 = _42new_forward_reference(-100, _28699, _op_56921);
    _28699 = NOVALUE;
    if (!IS_ATOM_INT(_ref_56925)) {
        _1 = (object)(DBL_PTR(_ref_56925)->dbl);
        DeRefDS(_ref_56925);
        _ref_56925 = _1;
    }

    /** parser.e:1042		emit_opnd( - ref )*/
    if ((uintptr_t)_ref_56925 == (uintptr_t)HIGH_BITS){
        _28701 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _28701 = - _ref_56925;
    }
    _45emit_opnd(_28701);
    _28701 = NOVALUE;

    /** parser.e:1043		if init_check != -1 then*/
    if (_init_check_56920 == -1)
    goto L1; // [33] 44

    /** parser.e:1044			Forward_InitCheck( tok, init_check )*/
    Ref(_tok_56919);
    _43Forward_InitCheck(_tok_56919, _init_check_56920);
L1: 

    /** parser.e:1047	end procedure*/
    DeRef(_tok_56919);
    return;
    ;
}


void _43Forward_call(object _tok_56938, object _opcode_56939)
{
    object _args_56942 = NOVALUE;
    object _proc_56944 = NOVALUE;
    object _tok_id_56947 = NOVALUE;
    object _id_56954 = NOVALUE;
    object _fc_pc_56978 = NOVALUE;
    object _28720 = NOVALUE;
    object _28719 = NOVALUE;
    object _28716 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1050		integer args = 0*/
    _args_56942 = 0;

    /** parser.e:1051		symtab_index proc = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_56938);
    _proc_56944 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_56944)){
        _proc_56944 = (object)DBL_PTR(_proc_56944)->dbl;
    }

    /** parser.e:1052		integer tok_id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56938);
    _tok_id_56947 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_56947)){
        _tok_id_56947 = (object)DBL_PTR(_tok_id_56947)->dbl;
    }

    /** parser.e:1053		remove_symbol( proc )*/
    _53remove_symbol(_proc_56944);

    /** parser.e:1054		short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:1055		while 1 do*/
L1: 

    /** parser.e:1056			tok = next_token()*/
    _0 = _tok_56938;
    _tok_56938 = _43next_token();
    DeRef(_0);

    /** parser.e:1057			integer id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_56938);
    _id_56954 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_56954)){
        _id_56954 = (object)DBL_PTR(_id_56954)->dbl;
    }

    /** parser.e:1059			switch id do*/
    _0 = _id_56954;
    switch ( _0 ){ 

        /** parser.e:1060				case COMMA then*/
        case -30:

        /** parser.e:1061					emit_opnd( 0 ) -- clean this up later*/
        _45emit_opnd(0);

        /** parser.e:1062					args += 1*/
        _args_56942 = _args_56942 + 1;
        goto L2; // [83] 168

        /** parser.e:1064				case RIGHT_ROUND then*/
        case -27:

        /** parser.e:1065					exit*/
        goto L3; // [93] 175
        goto L2; // [95] 168

        /** parser.e:1067				case else*/
        default:

        /** parser.e:1068					putback( tok )*/
        Ref(_tok_56938);
        _43putback(_tok_56938);

        /** parser.e:1069					call_proc( forward_expr, {} )*/
        _0 = (object)_00[_43forward_expr_56440].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1070					args += 1*/
        _args_56942 = _args_56942 + 1;

        /** parser.e:1072					tok = next_token()*/
        _0 = _tok_56938;
        _tok_56938 = _43next_token();
        DeRef(_0);

        /** parser.e:1073					id = tok[T_ID]*/
        _2 = (object)SEQ_PTR(_tok_56938);
        _id_56954 = (object)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_56954)){
            _id_56954 = (object)DBL_PTR(_id_56954)->dbl;
        }

        /** parser.e:1074					if id = RIGHT_ROUND then*/
        if (_id_56954 != -27)
        goto L4; // [138] 149

        /** parser.e:1075						exit*/
        goto L3; // [146] 175
L4: 

        /** parser.e:1078					if id != COMMA then*/
        if (_id_56954 == -30)
        goto L5; // [153] 167

        /** parser.e:1079							CompileErr(EXPECTED__OR)*/
        RefDS(_22209);
        _49CompileErr(69, _22209, 0);
L5: 
    ;}L2: 

    /** parser.e:1082		end while*/
    goto L1; // [172] 46
L3: 

    /** parser.e:1084		integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28716 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28716 = 1;
    }
    _fc_pc_56978 = _28716 + 1;
    _28716 = NOVALUE;

    /** parser.e:1085		emit_opnd( args )*/
    _45emit_opnd(_args_56942);

    /** parser.e:1087		op_info1 = proc*/
    _45op_info1_51413 = _proc_56944;

    /** parser.e:1088		if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_56947 != 512)
    goto L6; // [202] 226

    /** parser.e:1089			set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28719 = (object)*(((s1_ptr)_2)->base + _proc_56944);
    _2 = (object)SEQ_PTR(_28719);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _28720 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _28720 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _28719 = NOVALUE;
    Ref(_28720);
    _61set_qualified_fwd(_28720);
    _28720 = NOVALUE;
    goto L7; // [223] 232
L6: 

    /** parser.e:1091			set_qualified_fwd( -1 )*/
    _61set_qualified_fwd(-1);
L7: 

    /** parser.e:1093		emit_op( opcode )*/
    _45emit_op(_opcode_56939);

    /** parser.e:1094		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L8; // [241] 260

    /** parser.e:1095			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L9; // [248] 259
    }
    else{
    }

    /** parser.e:1096				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
L9: 
L8: 

    /** parser.e:1099		short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;

    /** parser.e:1100	end procedure*/
    DeRef(_tok_56938);
    return;
    ;
}


void _43Object_call(object _tok_57006)
{
    object _tok2_57008 = NOVALUE;
    object _tok3_57009 = NOVALUE;
    object _save_factors_57010 = NOVALUE;
    object _save_lhs_subs_level_57011 = NOVALUE;
    object _sym_57013 = NOVALUE;
    object _28778 = NOVALUE;
    object _28776 = NOVALUE;
    object _28773 = NOVALUE;
    object _28769 = NOVALUE;
    object _28763 = NOVALUE;
    object _28760 = NOVALUE;
    object _28759 = NOVALUE;
    object _28758 = NOVALUE;
    object _28756 = NOVALUE;
    object _28755 = NOVALUE;
    object _28753 = NOVALUE;
    object _28752 = NOVALUE;
    object _28749 = NOVALUE;
    object _28748 = NOVALUE;
    object _28747 = NOVALUE;
    object _28745 = NOVALUE;
    object _28744 = NOVALUE;
    object _28742 = NOVALUE;
    object _28741 = NOVALUE;
    object _28740 = NOVALUE;
    object _28739 = NOVALUE;
    object _28737 = NOVALUE;
    object _28736 = NOVALUE;
    object _28734 = NOVALUE;
    object _28733 = NOVALUE;
    object _28730 = NOVALUE;
    object _28728 = NOVALUE;
    object _28727 = NOVALUE;
    object _28725 = NOVALUE;
    object _28724 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1104		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1107		tok2 = next_token()*/
    _0 = _tok2_57008;
    _tok2_57008 = _43next_token();
    DeRef(_0);

    /** parser.e:1108		if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28724 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28724)) {
        _28725 = (_28724 == -100);
    }
    else {
        _28725 = binary_op(EQUALS, _28724, -100);
    }
    _28724 = NOVALUE;
    if (IS_ATOM_INT(_28725)) {
        if (_28725 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28725)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28727 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28727)) {
        _28728 = (_28727 == 512);
    }
    else {
        _28728 = binary_op(EQUALS, _28727, 512);
    }
    _28727 = NOVALUE;
    if (_28728 == 0) {
        DeRef(_28728);
        _28728 = NOVALUE;
        goto L2; // [39] 582
    }
    else {
        if (!IS_ATOM_INT(_28728) && DBL_PTR(_28728)->dbl == 0.0){
            DeRef(_28728);
            _28728 = NOVALUE;
            goto L2; // [39] 582
        }
        DeRef(_28728);
        _28728 = NOVALUE;
    }
    DeRef(_28728);
    _28728 = NOVALUE;
L1: 

    /** parser.e:1109			tok3 = next_token()*/
    _0 = _tok3_57009;
    _tok3_57009 = _43next_token();
    DeRef(_0);

    /** parser.e:1110			if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_57009);
    _28730 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28730, -27)){
        _28730 = NOVALUE;
        goto L3; // [58] 155
    }
    _28730 = NOVALUE;

    /** parser.e:1112				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _sym_57013 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_57013)){
        _sym_57013 = (object)DBL_PTR(_sym_57013)->dbl;
    }

    /** parser.e:1113				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28733 = (object)*(((s1_ptr)_2)->base + _sym_57013);
    _2 = (object)SEQ_PTR(_28733);
    _28734 = (object)*(((s1_ptr)_2)->base + 4);
    _28733 = NOVALUE;
    if (binary_op_a(NOTEQ, _28734, 9)){
        _28734 = NOVALUE;
        goto L4; // [88] 108
    }
    _28734 = NOVALUE;

    /** parser.e:1114					Forward_var( tok2 )*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28736 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_57008);
    Ref(_28736);
    _43Forward_var(_tok2_57008, -1, _28736);
    _28736 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** parser.e:1116					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_57013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28739 = (object)*(((s1_ptr)_2)->base + _sym_57013);
    _2 = (object)SEQ_PTR(_28739);
    _28740 = (object)*(((s1_ptr)_2)->base + 5);
    _28739 = NOVALUE;
    if (IS_ATOM_INT(_28740)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28740 | (uintptr_t)1;
             _28741 = MAKE_UINT(tu);
        }
    }
    else {
        _28741 = binary_op(OR_BITS, _28740, 1);
    }
    _28740 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28741;
    if( _1 != _28741 ){
        DeRef(_1);
    }
    _28741 = NOVALUE;
    _28737 = NOVALUE;

    /** parser.e:1118					emit_opnd(sym)*/
    _45emit_opnd(_sym_57013);
L5: 

    /** parser.e:1120				putback( tok3 )*/
    Ref(_tok3_57009);
    _43putback(_tok3_57009);
    goto L6; // [152] 571
L3: 

    /** parser.e:1122			elsif tok3[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok3_57009);
    _28742 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28742, -30)){
        _28742 = NOVALUE;
        goto L7; // [165] 184
    }
    _28742 = NOVALUE;

    /** parser.e:1124				WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (object)SEQ_PTR(_tok_57006);
    _28744 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28744);
    RefDS(_22209);
    _43WrongNumberArgs(_28744, _22209);
    _28744 = NOVALUE;
    goto L6; // [181] 571
L7: 

    /** parser.e:1126			elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok3_57009);
    _28745 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28745, -26)){
        _28745 = NOVALUE;
        goto L8; // [194] 244
    }
    _28745 = NOVALUE;

    /** parser.e:1127				if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28747 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28747)){
        _28748 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28747)->dbl));
    }
    else{
        _28748 = (object)*(((s1_ptr)_2)->base + _28747);
    }
    _2 = (object)SEQ_PTR(_28748);
    _28749 = (object)*(((s1_ptr)_2)->base + 4);
    _28748 = NOVALUE;
    if (binary_op_a(NOTEQ, _28749, 9)){
        _28749 = NOVALUE;
        goto L9; // [220] 235
    }
    _28749 = NOVALUE;

    /** parser.e:1128					Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_57008);
    _43Forward_call(_tok2_57008, 196);
    goto L6; // [232] 571
L9: 

    /** parser.e:1130					Function_call( tok2 )*/
    Ref(_tok2_57008);
    _43Function_call(_tok2_57008);
    goto L6; // [241] 571
L8: 

    /** parser.e:1139				sym = tok2[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _sym_57013 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_57013)){
        _sym_57013 = (object)DBL_PTR(_sym_57013)->dbl;
    }

    /** parser.e:1140				if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28752 = (object)*(((s1_ptr)_2)->base + _sym_57013);
    _2 = (object)SEQ_PTR(_28752);
    _28753 = (object)*(((s1_ptr)_2)->base + 4);
    _28752 = NOVALUE;
    if (binary_op_a(NOTEQ, _28753, 9)){
        _28753 = NOVALUE;
        goto LA; // [270] 292
    }
    _28753 = NOVALUE;

    /** parser.e:1141					Forward_var( tok2, TRUE )*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28755 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_57008);
    Ref(_28755);
    _43Forward_var(_tok2_57008, _9TRUE_441, _28755);
    _28755 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** parser.e:1143					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_57013 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28758 = (object)*(((s1_ptr)_2)->base + _sym_57013);
    _2 = (object)SEQ_PTR(_28758);
    _28759 = (object)*(((s1_ptr)_2)->base + 5);
    _28758 = NOVALUE;
    if (IS_ATOM_INT(_28759)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28759 | (uintptr_t)1;
             _28760 = MAKE_UINT(tu);
        }
    }
    else {
        _28760 = binary_op(OR_BITS, _28759, 1);
    }
    _28759 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28760;
    if( _1 != _28760 ){
        DeRef(_1);
    }
    _28760 = NOVALUE;
    _28756 = NOVALUE;

    /** parser.e:1144					InitCheck(sym, TRUE)*/
    _43InitCheck(_sym_57013, _9TRUE_441);

    /** parser.e:1145					emit_opnd(sym)*/
    _45emit_opnd(_sym_57013);
LB: 

    /** parser.e:1149				if sym = left_sym then*/
    if (_sym_57013 != _43left_sym_55446)
    goto LC; // [343] 353

    /** parser.e:1150					lhs_subs_level = 0*/
    _43lhs_subs_level_55444 = 0;
LC: 

    /** parser.e:1155				tok2 = tok3*/
    Ref(_tok3_57009);
    DeRef(_tok2_57008);
    _tok2_57008 = _tok3_57009;

    /** parser.e:1156				current_sequence = append(current_sequence, sym)*/
    Append(&_45current_sequence_51421, _45current_sequence_51421, _sym_57013);

    /** parser.e:1157				while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28763 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28763, -28)){
        _28763 = NOVALUE;
        goto LE; // [381] 549
    }
    _28763 = NOVALUE;

    /** parser.e:1158					subs_depth += 1*/
    _43subs_depth_55447 = _43subs_depth_55447 + 1;

    /** parser.e:1159					if lhs_subs_level >= 0 then*/
    if (_43lhs_subs_level_55444 < 0)
    goto LF; // [397] 410

    /** parser.e:1160						lhs_subs_level += 1*/
    _43lhs_subs_level_55444 = _43lhs_subs_level_55444 + 1;
LF: 

    /** parser.e:1162					save_factors = factors*/
    _save_factors_57010 = _43factors_55443;

    /** parser.e:1163					save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_57011 = _43lhs_subs_level_55444;

    /** parser.e:1164					call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56440].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1165					tok2 = next_token()*/
    _0 = _tok2_57008;
    _tok2_57008 = _43next_token();
    DeRef(_0);

    /** parser.e:1166					if tok2[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok2_57008);
    _28769 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28769, 513)){
        _28769 = NOVALUE;
        goto L10; // [446] 484
    }
    _28769 = NOVALUE;

    /** parser.e:1167						call_proc(forward_expr, {})*/
    _0 = (object)_00[_43forward_expr_56440].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:1168						emit_op(RHS_SLICE)*/
    _45emit_op(46);

    /** parser.e:1169						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1170						tok2 = next_token()*/
    _0 = _tok2_57008;
    _tok2_57008 = _43next_token();
    DeRef(_0);

    /** parser.e:1171						exit*/
    goto LE; // [479] 549
    goto L11; // [481] 529
L10: 

    /** parser.e:1173						putback(tok2)*/
    Ref(_tok2_57008);
    _43putback(_tok2_57008);

    /** parser.e:1174						tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1175						subs_depth -= 1*/
    _43subs_depth_55447 = _43subs_depth_55447 - 1;

    /** parser.e:1176						current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51421)){
            _28773 = SEQ_PTR(_45current_sequence_51421)->length;
    }
    else {
        _28773 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51421);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28773)) ? _28773 : (object)(DBL_PTR(_28773)->dbl);
        int stop = (IS_ATOM_INT(_28773)) ? _28773 : (object)(DBL_PTR(_28773)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51421), stop+1, &_45current_sequence_51421);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51421 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51421)->ref == 1));
        }
    }
    _28773 = NOVALUE;
    _28773 = NOVALUE;

    /** parser.e:1177						emit_op(RHS_SUBS)*/
    _45emit_op(25);
L11: 

    /** parser.e:1180					factors = save_factors*/
    _43factors_55443 = _save_factors_57010;

    /** parser.e:1181					lhs_subs_level = save_lhs_subs_level*/
    _43lhs_subs_level_55444 = _save_lhs_subs_level_57011;

    /** parser.e:1182					tok2 = next_token()*/
    _0 = _tok2_57008;
    _tok2_57008 = _43next_token();
    DeRef(_0);

    /** parser.e:1183				end while*/
    goto LD; // [546] 373
LE: 

    /** parser.e:1184				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51421)){
            _28776 = SEQ_PTR(_45current_sequence_51421)->length;
    }
    else {
        _28776 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51421);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28776)) ? _28776 : (object)(DBL_PTR(_28776)->dbl);
        int stop = (IS_ATOM_INT(_28776)) ? _28776 : (object)(DBL_PTR(_28776)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51421), stop+1, &_45current_sequence_51421);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51421 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51421)->ref == 1));
        }
    }
    _28776 = NOVALUE;
    _28776 = NOVALUE;

    /** parser.e:1185				putback(tok2)*/
    Ref(_tok2_57008);
    _43putback(_tok2_57008);
L6: 

    /** parser.e:1189			tok_match( RIGHT_ROUND )*/
    _43tok_match(-27, 0);
    goto L12; // [579] 599
L2: 

    /** parser.e:1191			putback(tok2)*/
    Ref(_tok2_57008);
    _43putback(_tok2_57008);

    /** parser.e:1192			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57006);
    _28778 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28778);
    _43ParseArgs(_28778);
    _28778 = NOVALUE;
L12: 

    /** parser.e:1194	end procedure*/
    DeRef(_tok_57006);
    DeRef(_tok2_57008);
    DeRef(_tok3_57009);
    DeRef(_28725);
    _28725 = NOVALUE;
    _28747 = NOVALUE;
    return;
    ;
}


void _43Function_call(object _tok_57151)
{
    object _id_57152 = NOVALUE;
    object _scope_57153 = NOVALUE;
    object _opcode_57154 = NOVALUE;
    object _e_57155 = NOVALUE;
    object _28819 = NOVALUE;
    object _28818 = NOVALUE;
    object _28817 = NOVALUE;
    object _28816 = NOVALUE;
    object _28815 = NOVALUE;
    object _28814 = NOVALUE;
    object _28813 = NOVALUE;
    object _28811 = NOVALUE;
    object _28810 = NOVALUE;
    object _28808 = NOVALUE;
    object _28807 = NOVALUE;
    object _28806 = NOVALUE;
    object _28805 = NOVALUE;
    object _28804 = NOVALUE;
    object _28803 = NOVALUE;
    object _28802 = NOVALUE;
    object _28801 = NOVALUE;
    object _28800 = NOVALUE;
    object _28799 = NOVALUE;
    object _28798 = NOVALUE;
    object _28797 = NOVALUE;
    object _28796 = NOVALUE;
    object _28795 = NOVALUE;
    object _28794 = NOVALUE;
    object _28792 = NOVALUE;
    object _28790 = NOVALUE;
    object _28789 = NOVALUE;
    object _28787 = NOVALUE;
    object _28785 = NOVALUE;
    object _28784 = NOVALUE;
    object _28783 = NOVALUE;
    object _28782 = NOVALUE;
    object _28780 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1200		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _id_57152 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57152)){
        _id_57152 = (object)DBL_PTR(_id_57152)->dbl;
    }

    /** parser.e:1201		if id = FUNC or id = TYPE then*/
    _28780 = (_id_57152 == 501);
    if (_28780 != 0) {
        goto L1; // [19] 34
    }
    _28782 = (_id_57152 == 504);
    if (_28782 == 0)
    {
        DeRef(_28782);
        _28782 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28782);
        _28782 = NOVALUE;
    }
L1: 

    /** parser.e:1203			UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _28783 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28783);
    _43UndefinedVar(_28783);
    _28783 = NOVALUE;
L2: 

    /** parser.e:1206		e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _28784 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28784)){
        _28785 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28784)->dbl));
    }
    else{
        _28785 = (object)*(((s1_ptr)_2)->base + _28784);
    }
    _2 = (object)SEQ_PTR(_28785);
    _e_57155 = (object)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_57155)){
        _e_57155 = (object)DBL_PTR(_e_57155)->dbl;
    }
    _28785 = NOVALUE;

    /** parser.e:1207		if e then*/
    if (_e_57155 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** parser.e:1209			if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28787 = (_e_57155 == 1073741823);
    if (_28787 != 0) {
        goto L4; // [81] 102
    }
    _2 = (object)SEQ_PTR(_tok_57151);
    _28789 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28789)) {
        _28790 = (_28789 > _43left_sym_55446);
    }
    else {
        _28790 = binary_op(GREATER, _28789, _43left_sym_55446);
    }
    _28789 = NOVALUE;
    if (_28790 == 0) {
        DeRef(_28790);
        _28790 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28790) && DBL_PTR(_28790)->dbl == 0.0){
            DeRef(_28790);
            _28790 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28790);
        _28790 = NOVALUE;
    }
    DeRef(_28790);
    _28790 = NOVALUE;
L4: 

    /** parser.e:1211				side_effect_calls = or_bits(side_effect_calls, e)*/
    {uintptr_t tu;
         tu = (uintptr_t)_43side_effect_calls_55442 | (uintptr_t)_e_57155;
         _43side_effect_calls_55442 = MAKE_UINT(tu);
    }
L5: 

    /** parser.e:1214			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28794 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_28794);
    _28795 = (object)*(((s1_ptr)_2)->base + 23);
    _28794 = NOVALUE;
    if (IS_ATOM_INT(_28795)) {
        {uintptr_t tu;
             tu = (uintptr_t)_28795 | (uintptr_t)_e_57155;
             _28796 = MAKE_UINT(tu);
        }
    }
    else {
        _28796 = binary_op(OR_BITS, _28795, _e_57155);
    }
    _28795 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _28796;
    if( _1 != _28796 ){
        DeRef(_1);
    }
    _28796 = NOVALUE;
    _28792 = NOVALUE;

    /** parser.e:1216			if short_circuit > 0 and short_circuit_B and*/
    _28797 = (_43short_circuit_55405 > 0);
    if (_28797 == 0) {
        _28798 = 0;
        goto L6; // [154] 164
    }
    _28798 = (_43short_circuit_B_55407 != 0);
L6: 
    if (_28798 == 0) {
        goto L7; // [164] 228
    }
    _28800 = find_from(_id_57152, _29FUNC_TOKS_12289, 1);
    if (_28800 == 0)
    {
        _28800 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28800 = NOVALUE;
    }

    /** parser.e:1218				Warning(219, short_circuit_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _28801 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_28801);
    RefDS(_22209);
    _28802 = _15abbreviate_path(_28801, _22209);
    _28801 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_57151);
    _28803 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28803)){
        _28804 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28803)->dbl));
    }
    else{
        _28804 = (object)*(((s1_ptr)_2)->base + _28803);
    }
    _2 = (object)SEQ_PTR(_28804);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28805 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28805 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28804 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _28802;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    Ref(_28805);
    ((intptr_t*)_2)[3] = _28805;
    _28806 = MAKE_SEQ(_1);
    _28805 = NOVALUE;
    _28802 = NOVALUE;
    _49Warning(219, 2, _28806);
    _28806 = NOVALUE;
L7: 
L3: 

    /** parser.e:1222		tok_match(LEFT_ROUND)*/
    _43tok_match(-26, 0);

    /** parser.e:1223		scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _28807 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28807)){
        _28808 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28807)->dbl));
    }
    else{
        _28808 = (object)*(((s1_ptr)_2)->base + _28807);
    }
    _2 = (object)SEQ_PTR(_28808);
    _scope_57153 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_57153)){
        _scope_57153 = (object)DBL_PTR(_scope_57153)->dbl;
    }
    _28808 = NOVALUE;

    /** parser.e:1224		opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _28810 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28810)){
        _28811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28810)->dbl));
    }
    else{
        _28811 = (object)*(((s1_ptr)_2)->base + _28810);
    }
    _2 = (object)SEQ_PTR(_28811);
    _opcode_57154 = (object)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_57154)){
        _opcode_57154 = (object)DBL_PTR(_opcode_57154)->dbl;
    }
    _28811 = NOVALUE;

    /** parser.e:1225		if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _28813 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28813)){
        _28814 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28813)->dbl));
    }
    else{
        _28814 = (object)*(((s1_ptr)_2)->base + _28813);
    }
    _2 = (object)SEQ_PTR(_28814);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _28815 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _28815 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _28814 = NOVALUE;
    if (_28815 == _23166)
    _28816 = 1;
    else if (IS_ATOM_INT(_28815) && IS_ATOM_INT(_23166))
    _28816 = 0;
    else
    _28816 = (compare(_28815, _23166) == 0);
    _28815 = NOVALUE;
    if (_28816 == 0) {
        goto L8; // [305] 327
    }
    _28818 = (_scope_57153 == 7);
    if (_28818 == 0)
    {
        DeRef(_28818);
        _28818 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28818);
        _28818 = NOVALUE;
    }

    /** parser.e:1227			Object_call( tok )*/
    Ref(_tok_57151);
    _43Object_call(_tok_57151);
    goto L9; // [324] 339
L8: 

    /** parser.e:1230			ParseArgs(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _28819 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28819);
    _43ParseArgs(_28819);
    _28819 = NOVALUE;
L9: 

    /** parser.e:1233		if scope = SC_PREDEF then*/
    if (_scope_57153 != 7)
    goto LA; // [343] 355

    /** parser.e:1234			emit_op(opcode)*/
    _45emit_op(_opcode_57154);
    goto LB; // [352] 393
LA: 

    /** parser.e:1236			op_info1 = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_57151);
    _45op_info1_51413 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_45op_info1_51413)){
        _45op_info1_51413 = (object)DBL_PTR(_45op_info1_51413)->dbl;
    }

    /** parser.e:1238			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1239			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto LC; // [373] 392

    /** parser.e:1240				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** parser.e:1241					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
LD: 
LC: 
LB: 

    /** parser.e:1245	end procedure*/
    DeRef(_tok_57151);
    _28807 = NOVALUE;
    DeRef(_28787);
    _28787 = NOVALUE;
    DeRef(_28780);
    _28780 = NOVALUE;
    DeRef(_28797);
    _28797 = NOVALUE;
    _28813 = NOVALUE;
    _28803 = NOVALUE;
    _28810 = NOVALUE;
    _28784 = NOVALUE;
    return;
    ;
}


void _43Factor()
{
    object _tok_57259 = NOVALUE;
    object _id_57260 = NOVALUE;
    object _n_57261 = NOVALUE;
    object _save_factors_57262 = NOVALUE;
    object _save_lhs_subs_level_57263 = NOVALUE;
    object _sym_57265 = NOVALUE;
    object _forward_57296 = NOVALUE;
    object _28879 = NOVALUE;
    object _28878 = NOVALUE;
    object _28877 = NOVALUE;
    object _28875 = NOVALUE;
    object _28874 = NOVALUE;
    object _28873 = NOVALUE;
    object _28872 = NOVALUE;
    object _28871 = NOVALUE;
    object _28869 = NOVALUE;
    object _28865 = NOVALUE;
    object _28862 = NOVALUE;
    object _28858 = NOVALUE;
    object _28852 = NOVALUE;
    object _28847 = NOVALUE;
    object _28846 = NOVALUE;
    object _28845 = NOVALUE;
    object _28843 = NOVALUE;
    object _28842 = NOVALUE;
    object _28840 = NOVALUE;
    object _28838 = NOVALUE;
    object _28837 = NOVALUE;
    object _28836 = NOVALUE;
    object _28834 = NOVALUE;
    object _28827 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1250		integer id, n*/

    /** parser.e:1251		integer save_factors, save_lhs_subs_level*/

    /** parser.e:1254		factors += 1*/
    _43factors_55443 = _43factors_55443 + 1;

    /** parser.e:1255		tok = next_token()*/
    _0 = _tok_57259;
    _tok_57259 = _43next_token();
    DeRef(_0);

    /** parser.e:1256		id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57259);
    _id_57260 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57260)){
        _id_57260 = (object)DBL_PTR(_id_57260)->dbl;
    }

    /** parser.e:1257		if id = RECORDED then*/
    if (_id_57260 != 508)
    goto L1; // [32] 59

    /** parser.e:1258			tok = read_recorded_token(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_57259);
    _28827 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_28827);
    _0 = _tok_57259;
    _tok_57259 = _43read_recorded_token(_28827);
    DeRef(_0);
    _28827 = NOVALUE;

    /** parser.e:1259			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57259);
    _id_57260 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57260)){
        _id_57260 = (object)DBL_PTR(_id_57260)->dbl;
    }
L1: 

    /** parser.e:1261		switch id label "factor" do*/
    _0 = _id_57260;
    switch ( _0 ){ 

        /** parser.e:1262			case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** parser.e:1263				sym = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_tok_57259);
        _sym_57265 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_57265)){
            _sym_57265 = (object)DBL_PTR(_sym_57265)->dbl;
        }

        /** parser.e:1264				if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28834 = (_sym_57265 < 0);
        if (_28834 != 0) {
            goto L2; // [88] 115
        }
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28836 = (object)*(((s1_ptr)_2)->base + _sym_57265);
        _2 = (object)SEQ_PTR(_28836);
        _28837 = (object)*(((s1_ptr)_2)->base + 4);
        _28836 = NOVALUE;
        if (IS_ATOM_INT(_28837)) {
            _28838 = (_28837 == 9);
        }
        else {
            _28838 = binary_op(EQUALS, _28837, 9);
        }
        _28837 = NOVALUE;
        if (_28838 == 0) {
            DeRef(_28838);
            _28838 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28838) && DBL_PTR(_28838)->dbl == 0.0){
                DeRef(_28838);
                _28838 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28838);
            _28838 = NOVALUE;
        }
        DeRef(_28838);
        _28838 = NOVALUE;
L2: 

        /** parser.e:1265					token forward = next_token()*/
        _0 = _forward_57296;
        _forward_57296 = _43next_token();
        DeRef(_0);

        /** parser.e:1266					if forward[T_ID] = LEFT_ROUND then*/
        _2 = (object)SEQ_PTR(_forward_57296);
        _28840 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28840, -26)){
            _28840 = NOVALUE;
            goto L4; // [130] 151
        }
        _28840 = NOVALUE;

        /** parser.e:1267						Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_57259);
        _43Forward_call(_tok_57259, 196);

        /** parser.e:1268						break "factor"*/
        DeRef(_forward_57296);
        _forward_57296 = NOVALUE;
        goto L5; // [146] 694
        goto L6; // [148] 172
L4: 

        /** parser.e:1270						putback( forward )*/
        Ref(_forward_57296);
        _43putback(_forward_57296);

        /** parser.e:1271						Forward_var( tok, TRUE )*/
        _2 = (object)SEQ_PTR(_tok_57259);
        _28842 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_57259);
        Ref(_28842);
        _43Forward_var(_tok_57259, _9TRUE_441, _28842);
        _28842 = NOVALUE;
L6: 
        DeRef(_forward_57296);
        _forward_57296 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** parser.e:1275					UndefinedVar(sym)*/
        _43UndefinedVar(_sym_57265);

        /** parser.e:1276					SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_sym_57265 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28845 = (object)*(((s1_ptr)_2)->base + _sym_57265);
        _2 = (object)SEQ_PTR(_28845);
        _28846 = (object)*(((s1_ptr)_2)->base + 5);
        _28845 = NOVALUE;
        if (IS_ATOM_INT(_28846)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_28846 | (uintptr_t)1;
                 _28847 = MAKE_UINT(tu);
            }
        }
        else {
            _28847 = binary_op(OR_BITS, _28846, 1);
        }
        _28846 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _28847;
        if( _1 != _28847 ){
            DeRef(_1);
        }
        _28847 = NOVALUE;
        _28843 = NOVALUE;

        /** parser.e:1277					InitCheck(sym, TRUE)*/
        _43InitCheck(_sym_57265, _9TRUE_441);

        /** parser.e:1278					emit_opnd(sym)*/
        _45emit_opnd(_sym_57265);
L7: 

        /** parser.e:1281				if sym = left_sym then*/
        if (_sym_57265 != _43left_sym_55446)
        goto L8; // [233] 243

        /** parser.e:1282					lhs_subs_level = 0 -- start counting subscripts*/
        _43lhs_subs_level_55444 = 0;
L8: 

        /** parser.e:1285				short_circuit -= 1*/
        _43short_circuit_55405 = _43short_circuit_55405 - 1;

        /** parser.e:1286				tok = next_token()*/
        _0 = _tok_57259;
        _tok_57259 = _43next_token();
        DeRef(_0);

        /** parser.e:1287				current_sequence = append(current_sequence, sym)*/
        Append(&_45current_sequence_51421, _45current_sequence_51421, _sym_57265);

        /** parser.e:1288				while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (object)SEQ_PTR(_tok_57259);
        _28852 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28852, -28)){
            _28852 = NOVALUE;
            goto LA; // [279] 447
        }
        _28852 = NOVALUE;

        /** parser.e:1289					subs_depth += 1*/
        _43subs_depth_55447 = _43subs_depth_55447 + 1;

        /** parser.e:1290					if lhs_subs_level >= 0 then*/
        if (_43lhs_subs_level_55444 < 0)
        goto LB; // [295] 308

        /** parser.e:1291						lhs_subs_level += 1*/
        _43lhs_subs_level_55444 = _43lhs_subs_level_55444 + 1;
LB: 

        /** parser.e:1293					save_factors = factors*/
        _save_factors_57262 = _43factors_55443;

        /** parser.e:1294					save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_57263 = _43lhs_subs_level_55444;

        /** parser.e:1295					call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56440].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1296					tok = next_token()*/
        _0 = _tok_57259;
        _tok_57259 = _43next_token();
        DeRef(_0);

        /** parser.e:1297					if tok[T_ID] = SLICE then*/
        _2 = (object)SEQ_PTR(_tok_57259);
        _28858 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28858, 513)){
            _28858 = NOVALUE;
            goto LC; // [344] 382
        }
        _28858 = NOVALUE;

        /** parser.e:1298						call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56440].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1299						emit_op(RHS_SLICE)*/
        _45emit_op(46);

        /** parser.e:1300						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29, 0);

        /** parser.e:1301						tok = next_token()*/
        _0 = _tok_57259;
        _tok_57259 = _43next_token();
        DeRef(_0);

        /** parser.e:1302						exit*/
        goto LA; // [377] 447
        goto LD; // [379] 427
LC: 

        /** parser.e:1304						putback(tok)*/
        Ref(_tok_57259);
        _43putback(_tok_57259);

        /** parser.e:1305						tok_match(RIGHT_SQUARE)*/
        _43tok_match(-29, 0);

        /** parser.e:1306						subs_depth -= 1*/
        _43subs_depth_55447 = _43subs_depth_55447 - 1;

        /** parser.e:1307						current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _28862 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _28862 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_51421);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28862)) ? _28862 : (object)(DBL_PTR(_28862)->dbl);
            int stop = (IS_ATOM_INT(_28862)) ? _28862 : (object)(DBL_PTR(_28862)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421 );
                }
                else Tail(SEQ_PTR(_45current_sequence_51421), stop+1, &_45current_sequence_51421);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_51421 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51421)->ref == 1));
            }
        }
        _28862 = NOVALUE;
        _28862 = NOVALUE;

        /** parser.e:1308						emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _45emit_op(25);
LD: 

        /** parser.e:1310					factors = save_factors*/
        _43factors_55443 = _save_factors_57262;

        /** parser.e:1311					lhs_subs_level = save_lhs_subs_level*/
        _43lhs_subs_level_55444 = _save_lhs_subs_level_57263;

        /** parser.e:1312					tok = next_token()*/
        _0 = _tok_57259;
        _tok_57259 = _43next_token();
        DeRef(_0);

        /** parser.e:1313				end while*/
        goto L9; // [444] 271
LA: 

        /** parser.e:1314				current_sequence = remove( current_sequence, length( current_sequence ) )*/
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _28865 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _28865 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_45current_sequence_51421);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_28865)) ? _28865 : (object)(DBL_PTR(_28865)->dbl);
            int stop = (IS_ATOM_INT(_28865)) ? _28865 : (object)(DBL_PTR(_28865)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421 );
                }
                else Tail(SEQ_PTR(_45current_sequence_51421), stop+1, &_45current_sequence_51421);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421);
            }
            else {
                assign_slice_seq = &assign_space;
                _45current_sequence_51421 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51421)->ref == 1));
            }
        }
        _28865 = NOVALUE;
        _28865 = NOVALUE;

        /** parser.e:1315				putback(tok)*/
        Ref(_tok_57259);
        _43putback(_tok_57259);

        /** parser.e:1316				short_circuit += 1*/
        _43short_circuit_55405 = _43short_circuit_55405 + 1;
        goto L5; // [476] 694

        /** parser.e:1318			case DOLLAR then*/
        case -22:

        /** parser.e:1319				tok = next_token()*/
        _0 = _tok_57259;
        _tok_57259 = _43next_token();
        DeRef(_0);

        /** parser.e:1320				putback(tok)*/
        Ref(_tok_57259);
        _43putback(_tok_57259);

        /** parser.e:1321				if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (object)SEQ_PTR(_tok_57259);
        _28869 = (object)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28869, -25)){
            _28869 = NOVALUE;
            goto LE; // [502] 520
        }
        _28869 = NOVALUE;

        /** parser.e:1322					gListItem[$] = 0*/
        if (IS_SEQUENCE(_43gListItem_55441)){
                _28871 = SEQ_PTR(_43gListItem_55441)->length;
        }
        else {
            _28871 = 1;
        }
        _2 = (object)SEQ_PTR(_43gListItem_55441);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43gListItem_55441 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _28871);
        *(intptr_t *)_2 = 0;
        goto L5; // [517] 694
LE: 

        /** parser.e:1324					if subs_depth > 0 and length(current_sequence) then*/
        _28872 = (_43subs_depth_55447 > 0);
        if (_28872 == 0) {
            goto LF; // [528] 551
        }
        if (IS_SEQUENCE(_45current_sequence_51421)){
                _28874 = SEQ_PTR(_45current_sequence_51421)->length;
        }
        else {
            _28874 = 1;
        }
        if (_28874 == 0)
        {
            _28874 = NOVALUE;
            goto LF; // [538] 551
        }
        else{
            _28874 = NOVALUE;
        }

        /** parser.e:1325						emit_op(DOLLAR)*/
        _45emit_op(-22);
        goto L5; // [548] 694
LF: 

        /** parser.e:1327						CompileErr(MSG__MUST_ONLY_APPEAR_BETWEEN__AND__OR_AS_THE_LAST_ITEM_IN_A_SEQUENCE_LITERAL)*/
        RefDS(_22209);
        _49CompileErr(21, _22209, 0);
        goto L5; // [562] 694

        /** parser.e:1331			case ATOM then*/
        case 502:

        /** parser.e:1332				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_57259);
        _28875 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_28875);
        _45emit_opnd(_28875);
        _28875 = NOVALUE;
        goto L5; // [579] 694

        /** parser.e:1334			case LEFT_BRACE then*/
        case -24:

        /** parser.e:1335				n = Expr_list()*/
        _n_57261 = _43Expr_list();
        if (!IS_ATOM_INT(_n_57261)) {
            _1 = (object)(DBL_PTR(_n_57261)->dbl);
            DeRefDS(_n_57261);
            _n_57261 = _1;
        }

        /** parser.e:1336				tok_match(RIGHT_BRACE)*/
        _43tok_match(-25, 0);

        /** parser.e:1337				op_info1 = n*/
        _45op_info1_51413 = _n_57261;

        /** parser.e:1338				emit_op(RIGHT_BRACE_N)*/
        _45emit_op(31);
        goto L5; // [614] 694

        /** parser.e:1340			case STRING then*/
        case 503:

        /** parser.e:1341				emit_opnd(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_tok_57259);
        _28877 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_28877);
        _45emit_opnd(_28877);
        _28877 = NOVALUE;
        goto L5; // [631] 694

        /** parser.e:1343			case LEFT_ROUND then*/
        case -26:

        /** parser.e:1344				call_proc(forward_expr, {})*/
        _0 = (object)_00[_43forward_expr_56440].addr;
        (*(intptr_t (*)())_0)(
                             );

        /** parser.e:1345				tok_match(RIGHT_ROUND)*/
        _43tok_match(-27, 0);
        goto L5; // [652] 694

        /** parser.e:1347			case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** parser.e:1348				Function_call( tok )*/
        Ref(_tok_57259);
        _43Function_call(_tok_57259);
        goto L5; // [669] 694

        /** parser.e:1350			case else*/
        default:

        /** parser.e:1351				CompileErr(SYNTAX_ERROR__EXPECTED_TO_SEE_AN_EXPRESSION_NOT_1, {LexName(id)})*/
        RefDS(_26621);
        _28878 = _45LexName(_id_57260, _26621);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _28878;
        _28879 = MAKE_SEQ(_1);
        _28878 = NOVALUE;
        _49CompileErr(135, _28879, 0);
        _28879 = NOVALUE;
    ;}L5: 

    /** parser.e:1353	end procedure*/
    DeRef(_tok_57259);
    DeRef(_28872);
    _28872 = NOVALUE;
    DeRef(_28834);
    _28834 = NOVALUE;
    return;
    ;
}


void _43UFactor()
{
    object _tok_57418 = NOVALUE;
    object _28885 = NOVALUE;
    object _28883 = NOVALUE;
    object _28881 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1359		tok = next_token()*/
    _0 = _tok_57418;
    _tok_57418 = _43next_token();
    DeRef(_0);

    /** parser.e:1361		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_57418);
    _28881 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28881, 10)){
        _28881 = NOVALUE;
        goto L1; // [16] 34
    }
    _28881 = NOVALUE;

    /** parser.e:1362			Factor()*/
    _43Factor();

    /** parser.e:1363			emit_op(UMINUS)*/
    _45emit_op(12);
    goto L2; // [31] 93
L1: 

    /** parser.e:1365		elsif tok[T_ID] = NOT then*/
    _2 = (object)SEQ_PTR(_tok_57418);
    _28883 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28883, 7)){
        _28883 = NOVALUE;
        goto L3; // [44] 62
    }
    _28883 = NOVALUE;

    /** parser.e:1366			Factor()*/
    _43Factor();

    /** parser.e:1367			emit_op(NOT)*/
    _45emit_op(7);
    goto L2; // [59] 93
L3: 

    /** parser.e:1369		elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_57418);
    _28885 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28885, 11)){
        _28885 = NOVALUE;
        goto L4; // [72] 83
    }
    _28885 = NOVALUE;

    /** parser.e:1370			Factor()*/
    _43Factor();
    goto L2; // [80] 93
L4: 

    /** parser.e:1373			putback(tok)*/
    Ref(_tok_57418);
    _43putback(_tok_57418);

    /** parser.e:1374			Factor()*/
    _43Factor();
L2: 

    /** parser.e:1377	end procedure*/
    DeRef(_tok_57418);
    return;
    ;
}


object _43Term()
{
    object _tok_57443 = NOVALUE;
    object _28893 = NOVALUE;
    object _28892 = NOVALUE;
    object _28891 = NOVALUE;
    object _28889 = NOVALUE;
    object _28888 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1383		UFactor()*/
    _43UFactor();

    /** parser.e:1384		tok = next_token()*/
    _0 = _tok_57443;
    _tok_57443 = _43next_token();
    DeRef(_0);

    /** parser.e:1385		while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57443);
    _28888 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28888)) {
        _28889 = (_28888 == 13);
    }
    else {
        _28889 = binary_op(EQUALS, _28888, 13);
    }
    _28888 = NOVALUE;
    if (IS_ATOM_INT(_28889)) {
        if (_28889 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28889)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (object)SEQ_PTR(_tok_57443);
    _28891 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28891)) {
        _28892 = (_28891 == 14);
    }
    else {
        _28892 = binary_op(EQUALS, _28891, 14);
    }
    _28891 = NOVALUE;
    if (_28892 <= 0) {
        if (_28892 == 0) {
            DeRef(_28892);
            _28892 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28892) && DBL_PTR(_28892)->dbl == 0.0){
                DeRef(_28892);
                _28892 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28892);
            _28892 = NOVALUE;
        }
    }
    DeRef(_28892);
    _28892 = NOVALUE;
L2: 

    /** parser.e:1386			UFactor()*/
    _43UFactor();

    /** parser.e:1387			emit_op(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_57443);
    _28893 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_28893);
    _45emit_op(_28893);
    _28893 = NOVALUE;

    /** parser.e:1388			tok = next_token()*/
    _0 = _tok_57443;
    _tok_57443 = _43next_token();
    DeRef(_0);

    /** parser.e:1389		end while*/
    goto L1; // [66] 15
L3: 

    /** parser.e:1390		return tok*/
    DeRef(_28889);
    _28889 = NOVALUE;
    return _tok_57443;
    ;
}


object _43aexpr()
{
    object _tok_57460 = NOVALUE;
    object _id_57461 = NOVALUE;
    object _28900 = NOVALUE;
    object _28899 = NOVALUE;
    object _28897 = NOVALUE;
    object _28896 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1396		integer id*/

    /** parser.e:1398		tok = Term()*/
    _0 = _tok_57460;
    _tok_57460 = _43Term();
    DeRef(_0);

    /** parser.e:1399		while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57460);
    _28896 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28896)) {
        _28897 = (_28896 == 11);
    }
    else {
        _28897 = binary_op(EQUALS, _28896, 11);
    }
    _28896 = NOVALUE;
    if (IS_ATOM_INT(_28897)) {
        if (_28897 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28897)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (object)SEQ_PTR(_tok_57460);
    _28899 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28899)) {
        _28900 = (_28899 == 10);
    }
    else {
        _28900 = binary_op(EQUALS, _28899, 10);
    }
    _28899 = NOVALUE;
    if (_28900 <= 0) {
        if (_28900 == 0) {
            DeRef(_28900);
            _28900 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28900) && DBL_PTR(_28900)->dbl == 0.0){
                DeRef(_28900);
                _28900 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28900);
            _28900 = NOVALUE;
        }
    }
    DeRef(_28900);
    _28900 = NOVALUE;
L2: 

    /** parser.e:1400			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57460);
    _id_57461 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57461)){
        _id_57461 = (object)DBL_PTR(_id_57461)->dbl;
    }

    /** parser.e:1401			tok = Term()*/
    _0 = _tok_57460;
    _tok_57460 = _43Term();
    DeRef(_0);

    /** parser.e:1402			emit_op(id)*/
    _45emit_op(_id_57461);

    /** parser.e:1403		end while*/
    goto L1; // [68] 13
L3: 

    /** parser.e:1404		return tok*/
    DeRef(_28897);
    _28897 = NOVALUE;
    return _tok_57460;
    ;
}


object _43cexpr()
{
    object _tok_57480 = NOVALUE;
    object _concat_count_57481 = NOVALUE;
    object _28904 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1410		integer concat_count*/

    /** parser.e:1412		tok = aexpr()*/
    _0 = _tok_57480;
    _tok_57480 = _43aexpr();
    DeRef(_0);

    /** parser.e:1413		concat_count = 0*/
    _concat_count_57481 = 0;

    /** parser.e:1414		while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57480);
    _28904 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28904, 15)){
        _28904 = NOVALUE;
        goto L2; // [24] 44
    }
    _28904 = NOVALUE;

    /** parser.e:1415			tok = aexpr()*/
    _0 = _tok_57480;
    _tok_57480 = _43aexpr();
    DeRef(_0);

    /** parser.e:1416			concat_count += 1*/
    _concat_count_57481 = _concat_count_57481 + 1;

    /** parser.e:1417		end while*/
    goto L1; // [41] 18
L2: 

    /** parser.e:1419		if concat_count = 1 then*/
    if (_concat_count_57481 != 1)
    goto L3; // [46] 58

    /** parser.e:1420			emit_op( reserved:CONCAT )*/
    _45emit_op(15);
    goto L4; // [55] 81
L3: 

    /** parser.e:1422		elsif concat_count > 1 then*/
    if (_concat_count_57481 <= 1)
    goto L5; // [60] 80

    /** parser.e:1423			op_info1 = concat_count+1*/
    _45op_info1_51413 = _concat_count_57481 + 1;

    /** parser.e:1424			emit_op(CONCAT_N)*/
    _45emit_op(157);
L5: 
L4: 

    /** parser.e:1427		return tok*/
    return _tok_57480;
    ;
}


object _43rexpr()
{
    object _tok_57501 = NOVALUE;
    object _id_57502 = NOVALUE;
    object _28916 = NOVALUE;
    object _28915 = NOVALUE;
    object _28914 = NOVALUE;
    object _28913 = NOVALUE;
    object _28912 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1433		integer id*/

    /** parser.e:1435		tok = cexpr()*/
    _0 = _tok_57501;
    _tok_57501 = _43cexpr();
    DeRef(_0);

    /** parser.e:1436		while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (object)SEQ_PTR(_tok_57501);
    _28912 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28912)) {
        _28913 = (_28912 <= 6);
    }
    else {
        _28913 = binary_op(LESSEQ, _28912, 6);
    }
    _28912 = NOVALUE;
    if (IS_ATOM_INT(_28913)) {
        if (_28913 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28913)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (object)SEQ_PTR(_tok_57501);
    _28915 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28915)) {
        _28916 = (_28915 >= 1);
    }
    else {
        _28916 = binary_op(GREATEREQ, _28915, 1);
    }
    _28915 = NOVALUE;
    if (_28916 <= 0) {
        if (_28916 == 0) {
            DeRef(_28916);
            _28916 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28916) && DBL_PTR(_28916)->dbl == 0.0){
                DeRef(_28916);
                _28916 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28916);
            _28916 = NOVALUE;
        }
    }
    DeRef(_28916);
    _28916 = NOVALUE;

    /** parser.e:1437			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57501);
    _id_57502 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57502)){
        _id_57502 = (object)DBL_PTR(_id_57502)->dbl;
    }

    /** parser.e:1438			tok = cexpr()*/
    _0 = _tok_57501;
    _tok_57501 = _43cexpr();
    DeRef(_0);

    /** parser.e:1439			emit_op(id)*/
    _45emit_op(_id_57502);

    /** parser.e:1440		end while*/
    goto L1; // [67] 13
L2: 

    /** parser.e:1441		return tok*/
    DeRef(_28913);
    _28913 = NOVALUE;
    return _tok_57501;
    ;
}


void _43Expr()
{
    object _tok_57528 = NOVALUE;
    object _id_57529 = NOVALUE;
    object _patch_57530 = NOVALUE;
    object _28939 = NOVALUE;
    object _28937 = NOVALUE;
    object _28936 = NOVALUE;
    object _28934 = NOVALUE;
    object _28933 = NOVALUE;
    object _28932 = NOVALUE;
    object _28931 = NOVALUE;
    object _28930 = NOVALUE;
    object _28924 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1451		integer id*/

    /** parser.e:1452		integer patch*/

    /** parser.e:1454		ExprLine = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_43ExprLine_57523);
    _43ExprLine_57523 = _49ThisLine_49642;

    /** parser.e:1455		expr_bp = bp*/
    _43expr_bp_57524 = _49bp_49646;

    /** parser.e:1456		id = -1*/
    _id_57529 = -1;

    /** parser.e:1457		patch = 0*/
    _patch_57530 = 0;

    /** parser.e:1458		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** parser.e:1459			if id != -1 then*/
    if (_id_57529 == -1)
    goto L3; // [45] 116

    /** parser.e:1460				if id != XOR then*/
    if (_id_57529 == 152)
    goto L4; // [53] 115

    /** parser.e:1461					if short_circuit > 0 then*/
    if (_43short_circuit_55405 <= 0)
    goto L5; // [61] 114

    /** parser.e:1462						if id = OR then*/
    if (_id_57529 != 9)
    goto L6; // [69] 83

    /** parser.e:1463							emit_op(SC1_OR)*/
    _45emit_op(143);
    goto L7; // [80] 91
L6: 

    /** parser.e:1465							emit_op(SC1_AND)*/
    _45emit_op(141);
L7: 

    /** parser.e:1467						patch = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28924 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28924 = 1;
    }
    _patch_57530 = _28924 + 1;
    _28924 = NOVALUE;

    /** parser.e:1468						emit_forward_addr()*/
    _43emit_forward_addr();

    /** parser.e:1469						short_circuit_B = TRUE*/
    _43short_circuit_B_55407 = _9TRUE_441;
L5: 
L4: 
L3: 

    /** parser.e:1474			tok = rexpr()*/
    _0 = _tok_57528;
    _tok_57528 = _43rexpr();
    DeRef(_0);

    /** parser.e:1476			if id != -1 then*/
    if (_id_57529 == -1)
    goto L8; // [123] 268

    /** parser.e:1477				if id != XOR then*/
    if (_id_57529 == 152)
    goto L9; // [131] 261

    /** parser.e:1478					if short_circuit > 0 then*/
    if (_43short_circuit_55405 <= 0)
    goto LA; // [139] 252

    /** parser.e:1479						if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (object)SEQ_PTR(_tok_57528);
    _28930 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28930)) {
        _28931 = (_28930 != 410);
    }
    else {
        _28931 = binary_op(NOTEQ, _28930, 410);
    }
    _28930 = NOVALUE;
    if (IS_ATOM_INT(_28931)) {
        if (_28931 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28931)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (object)SEQ_PTR(_tok_57528);
    _28933 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28933)) {
        _28934 = (_28933 != 411);
    }
    else {
        _28934 = binary_op(NOTEQ, _28933, 411);
    }
    _28933 = NOVALUE;
    if (_28934 == 0) {
        DeRef(_28934);
        _28934 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28934) && DBL_PTR(_28934)->dbl == 0.0){
            DeRef(_28934);
            _28934 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28934);
        _28934 = NOVALUE;
    }
    DeRef(_28934);
    _28934 = NOVALUE;

    /** parser.e:1480							if id = OR then*/
    if (_id_57529 != 9)
    goto LC; // [181] 195

    /** parser.e:1481								emit_op(SC2_OR)*/
    _45emit_op(144);
    goto LD; // [192] 219
LC: 

    /** parser.e:1483								emit_op(SC2_AND)*/
    _45emit_op(142);
    goto LD; // [203] 219
LB: 

    /** parser.e:1486							SC1_type = id -- if/while/elsif must patch*/
    _43SC1_type_55410 = _id_57529;

    /** parser.e:1487							emit_op(SC2_NULL)*/
    _45emit_op(145);
LD: 

    /** parser.e:1489						if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** parser.e:1490							emit_op(NOP1)   -- to get label here*/
    _45emit_op(159);
LE: 

    /** parser.e:1492						backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _28936 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _28936 = 1;
    }
    _28937 = _28936 + 1;
    _28936 = NOVALUE;
    _45backpatch(_patch_57530, _28937);
    _28937 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** parser.e:1494						emit_op(id)*/
    _45emit_op(_id_57529);
    goto LF; // [258] 267
L9: 

    /** parser.e:1497					emit_op(id)*/
    _45emit_op(_id_57529);
LF: 
L8: 

    /** parser.e:1500			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57528);
    _id_57529 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_57529)){
        _id_57529 = (object)DBL_PTR(_id_57529)->dbl;
    }

    /** parser.e:1501			if not find(id, boolOps) then*/
    _28939 = find_from(_id_57529, _43boolOps_57518, 1);
    if (_28939 != 0)
    goto L1; // [287] 38
    _28939 = NOVALUE;

    /** parser.e:1502				exit*/
    goto L2; // [292] 300

    /** parser.e:1504		end while*/
    goto L1; // [297] 38
L2: 

    /** parser.e:1505		putback(tok)*/
    Ref(_tok_57528);
    _43putback(_tok_57528);

    /** parser.e:1506		SC1_patch = patch -- extra line*/
    _43SC1_patch_55409 = _patch_57530;

    /** parser.e:1507	end procedure*/
    DeRef(_tok_57528);
    DeRef(_28931);
    _28931 = NOVALUE;
    return;
    ;
}


void _43TypeCheck(object _var_57605)
{
    object _which_type_57606 = NOVALUE;
    object _ref_57616 = NOVALUE;
    object _ref_57649 = NOVALUE;
    object _28995 = NOVALUE;
    object _28994 = NOVALUE;
    object _28993 = NOVALUE;
    object _28992 = NOVALUE;
    object _28991 = NOVALUE;
    object _28989 = NOVALUE;
    object _28988 = NOVALUE;
    object _28987 = NOVALUE;
    object _28986 = NOVALUE;
    object _28985 = NOVALUE;
    object _28984 = NOVALUE;
    object _28982 = NOVALUE;
    object _28981 = NOVALUE;
    object _28978 = NOVALUE;
    object _28977 = NOVALUE;
    object _28976 = NOVALUE;
    object _28975 = NOVALUE;
    object _28970 = NOVALUE;
    object _28969 = NOVALUE;
    object _28965 = NOVALUE;
    object _28963 = NOVALUE;
    object _28962 = NOVALUE;
    object _28961 = NOVALUE;
    object _28959 = NOVALUE;
    object _28958 = NOVALUE;
    object _28957 = NOVALUE;
    object _28956 = NOVALUE;
    object _28955 = NOVALUE;
    object _28954 = NOVALUE;
    object _28951 = NOVALUE;
    object _28949 = NOVALUE;
    object _28947 = NOVALUE;
    object _28946 = NOVALUE;
    object _28945 = NOVALUE;
    object _28943 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_57605)) {
        _1 = (object)(DBL_PTR(_var_57605)->dbl);
        DeRefDS(_var_57605);
        _var_57605 = _1;
    }

    /** parser.e:1515		if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28943 = (_var_57605 < 0);
    if (_28943 != 0) {
        goto L1; // [9] 36
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28945 = (object)*(((s1_ptr)_2)->base + _var_57605);
    _2 = (object)SEQ_PTR(_28945);
    _28946 = (object)*(((s1_ptr)_2)->base + 4);
    _28945 = NOVALUE;
    if (IS_ATOM_INT(_28946)) {
        _28947 = (_28946 == 9);
    }
    else {
        _28947 = binary_op(EQUALS, _28946, 9);
    }
    _28946 = NOVALUE;
    if (_28947 == 0) {
        DeRef(_28947);
        _28947 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28947) && DBL_PTR(_28947)->dbl == 0.0){
            DeRef(_28947);
            _28947 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28947);
        _28947 = NOVALUE;
    }
    DeRef(_28947);
    _28947 = NOVALUE;
L1: 

    /** parser.e:1517			integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_57616 = _42new_forward_reference(65, _var_57605, 197);
    if (!IS_ATOM_INT(_ref_57616)) {
        _1 = (object)(DBL_PTR(_ref_57616)->dbl);
        DeRefDS(_ref_57616);
        _ref_57616 = _1;
    }

    /** parser.e:1518			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197;
    ((intptr_t*)_2)[2] = _var_57605;
    ((intptr_t*)_2)[3] = _27OpTypeCheck_20642;
    _28949 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _28949);
    DeRefDS(_28949);
    _28949 = NOVALUE;

    /** parser.e:1519			return*/
    DeRef(_28943);
    _28943 = NOVALUE;
    return;
L2: 

    /** parser.e:1522		which_type = SymTab[var][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28951 = (object)*(((s1_ptr)_2)->base + _var_57605);
    _2 = (object)SEQ_PTR(_28951);
    _which_type_57606 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_57606)){
        _which_type_57606 = (object)DBL_PTR(_which_type_57606)->dbl;
    }
    _28951 = NOVALUE;

    /** parser.e:1523		if which_type = 0 then*/
    if (_which_type_57606 != 0)
    goto L3; // [96] 106

    /** parser.e:1524			return	-- Not a typed identifier.*/
    DeRef(_28943);
    _28943 = NOVALUE;
    return;
L3: 

    /** parser.e:1526		if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28954 = (_which_type_57606 > 0);
    if (_28954 == 0) {
        goto L4; // [112] 141
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28956 = (object)*(((s1_ptr)_2)->base + _which_type_57606);
    if (IS_SEQUENCE(_28956)){
            _28957 = SEQ_PTR(_28956)->length;
    }
    else {
        _28957 = 1;
    }
    _28956 = NOVALUE;
    if (IS_ATOM_INT(_27S_TOKEN_20214)) {
        _28958 = (_28957 < _27S_TOKEN_20214);
    }
    else {
        _28958 = binary_op(LESS, _28957, _27S_TOKEN_20214);
    }
    _28957 = NOVALUE;
    if (_28958 == 0) {
        DeRef(_28958);
        _28958 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28958) && DBL_PTR(_28958)->dbl == 0.0){
            DeRef(_28958);
            _28958 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28958);
        _28958 = NOVALUE;
    }
    DeRef(_28958);
    _28958 = NOVALUE;

    /** parser.e:1527			return	-- Not a typed identifier.*/
    DeRef(_28943);
    _28943 = NOVALUE;
    _28956 = NOVALUE;
    DeRef(_28954);
    _28954 = NOVALUE;
    return;
L4: 

    /** parser.e:1530		if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28959 = (_which_type_57606 < 0);
    if (_28959 != 0) {
        goto L5; // [147] 174
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28961 = (object)*(((s1_ptr)_2)->base + _which_type_57606);
    _2 = (object)SEQ_PTR(_28961);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _28962 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _28962 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _28961 = NOVALUE;
    if (IS_ATOM_INT(_28962)) {
        _28963 = (_28962 == -100);
    }
    else {
        _28963 = binary_op(EQUALS, _28962, -100);
    }
    _28962 = NOVALUE;
    if (_28963 == 0) {
        DeRef(_28963);
        _28963 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28963) && DBL_PTR(_28963)->dbl == 0.0){
            DeRef(_28963);
            _28963 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28963);
        _28963 = NOVALUE;
    }
    DeRef(_28963);
    _28963 = NOVALUE;
L5: 

    /** parser.e:1531			integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_57649 = _42new_forward_reference(65, _which_type_57606, 504);
    if (!IS_ATOM_INT(_ref_57649)) {
        _1 = (object)(DBL_PTR(_ref_57649)->dbl);
        DeRefDS(_ref_57649);
        _ref_57649 = _1;
    }

    /** parser.e:1532			Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 197;
    ((intptr_t*)_2)[2] = _var_57605;
    ((intptr_t*)_2)[3] = _27OpTypeCheck_20642;
    _28965 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27Code_20660, _27Code_20660, _28965);
    DeRefDS(_28965);
    _28965 = NOVALUE;

    /** parser.e:1534			return*/
    DeRef(_28959);
    _28959 = NOVALUE;
    DeRef(_28943);
    _28943 = NOVALUE;
    _28956 = NOVALUE;
    DeRef(_28954);
    _28954 = NOVALUE;
    return;
L6: 

    /** parser.e:1537		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** parser.e:1538			if OpTypeCheck then*/
    if (_27OpTypeCheck_20642 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** parser.e:1539				switch which_type do*/
    if( _43_57663_cases == 0 ){
        _43_57663_cases = 1;
        SEQ_PTR( _28967 )->base[1] = _53object_type_47184;
        SEQ_PTR( _28967 )->base[2] = _53sequence_type_47188;
        SEQ_PTR( _28967 )->base[3] = _53atom_type_47186;
        SEQ_PTR( _28967 )->base[4] = _53integer_type_47190;
    }
    _1 = find(_which_type_57606, _28967);
    switch ( _1 ){ 

        /** parser.e:1540					case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** parser.e:1542					case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** parser.e:1544						op_info1 = var*/
        _45op_info1_51413 = _var_57605;

        /** parser.e:1545						emit_op(INTEGER_CHECK)*/
        _45emit_op(96);
        goto L8; // [265] 481

        /** parser.e:1546					case else*/
        case 0:

        /** parser.e:1547						if SymTab[which_type][S_EFFECT] then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _28969 = (object)*(((s1_ptr)_2)->base + _which_type_57606);
        _2 = (object)SEQ_PTR(_28969);
        _28970 = (object)*(((s1_ptr)_2)->base + 23);
        _28969 = NOVALUE;
        if (_28970 == 0) {
            _28970 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28970) && DBL_PTR(_28970)->dbl == 0.0){
                _28970 = NOVALUE;
                goto L9; // [285] 312
            }
            _28970 = NOVALUE;
        }
        _28970 = NOVALUE;

        /** parser.e:1549							emit_opnd(var)*/
        _45emit_opnd(_var_57605);

        /** parser.e:1550							op_info1 = which_type*/
        _45op_info1_51413 = _which_type_57606;

        /** parser.e:1552							emit_or_inline()*/
        _66emit_or_inline();

        /** parser.e:1553							emit_op(TYPE_CHECK)*/
        _45emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** parser.e:1559			if OpTypeCheck then*/
    if (_27OpTypeCheck_20642 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** parser.e:1560				if which_type != object_type then*/
    if (_which_type_57606 == _53object_type_47184)
    goto LB; // [328] 479

    /** parser.e:1561					if which_type = integer_type then*/
    if (_which_type_57606 != _53integer_type_47190)
    goto LC; // [336] 357

    /** parser.e:1562							op_info1 = var*/
    _45op_info1_51413 = _var_57605;

    /** parser.e:1563							emit_op(INTEGER_CHECK)*/
    _45emit_op(96);
    goto LD; // [354] 478
LC: 

    /** parser.e:1565					elsif which_type = sequence_type then*/
    if (_which_type_57606 != _53sequence_type_47188)
    goto LE; // [361] 382

    /** parser.e:1566							op_info1 = var*/
    _45op_info1_51413 = _var_57605;

    /** parser.e:1567							emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97);
    goto LD; // [379] 478
LE: 

    /** parser.e:1569					elsif which_type = atom_type then*/
    if (_which_type_57606 != _53atom_type_47186)
    goto LF; // [386] 407

    /** parser.e:1570							op_info1 = var*/
    _45op_info1_51413 = _var_57605;

    /** parser.e:1571							emit_op(ATOM_CHECK)*/
    _45emit_op(101);
    goto LD; // [404] 478
LF: 

    /** parser.e:1575							if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28975 = (object)*(((s1_ptr)_2)->base + _which_type_57606);
    _2 = (object)SEQ_PTR(_28975);
    _28976 = (object)*(((s1_ptr)_2)->base + 2);
    _28975 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28976)){
        _28977 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28976)->dbl));
    }
    else{
        _28977 = (object)*(((s1_ptr)_2)->base + _28976);
    }
    _2 = (object)SEQ_PTR(_28977);
    _28978 = (object)*(((s1_ptr)_2)->base + 15);
    _28977 = NOVALUE;
    if (binary_op_a(NOTEQ, _28978, _53integer_type_47190)){
        _28978 = NOVALUE;
        goto L10; // [435] 454
    }
    _28978 = NOVALUE;

    /** parser.e:1577								op_info1 = var*/
    _45op_info1_51413 = _var_57605;

    /** parser.e:1578								emit_op(INTEGER_CHECK) -- need integer conversion*/
    _45emit_op(96);
L10: 

    /** parser.e:1580							emit_opnd(var)*/
    _45emit_opnd(_var_57605);

    /** parser.e:1581							op_info1 = which_type*/
    _45op_info1_51413 = _which_type_57606;

    /** parser.e:1582							emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:1584							emit_op(TYPE_CHECK)*/
    _45emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** parser.e:1590		if TRANSLATE or not OpTypeCheck then*/
    if (_27TRANSLATE_20179 != 0) {
        goto L11; // [485] 499
    }
    _28981 = (_27OpTypeCheck_20642 == 0);
    if (_28981 == 0)
    {
        DeRef(_28981);
        _28981 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28981);
        _28981 = NOVALUE;
    }
L11: 

    /** parser.e:1591			op_info1 = var*/
    _45op_info1_51413 = _var_57605;

    /** parser.e:1592			if which_type = sequence_type or*/
    _28982 = (_which_type_57606 == _53sequence_type_47188);
    if (_28982 != 0) {
        goto L13; // [514] 553
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28984 = (object)*(((s1_ptr)_2)->base + _which_type_57606);
    _2 = (object)SEQ_PTR(_28984);
    _28985 = (object)*(((s1_ptr)_2)->base + 2);
    _28984 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28985)){
        _28986 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28985)->dbl));
    }
    else{
        _28986 = (object)*(((s1_ptr)_2)->base + _28985);
    }
    _2 = (object)SEQ_PTR(_28986);
    _28987 = (object)*(((s1_ptr)_2)->base + 15);
    _28986 = NOVALUE;
    if (IS_ATOM_INT(_28987)) {
        _28988 = (_28987 == _53sequence_type_47188);
    }
    else {
        _28988 = binary_op(EQUALS, _28987, _53sequence_type_47188);
    }
    _28987 = NOVALUE;
    if (_28988 == 0) {
        DeRef(_28988);
        _28988 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28988) && DBL_PTR(_28988)->dbl == 0.0){
            DeRef(_28988);
            _28988 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28988);
        _28988 = NOVALUE;
    }
    DeRef(_28988);
    _28988 = NOVALUE;
L13: 

    /** parser.e:1595				emit_op(SEQUENCE_CHECK)*/
    _45emit_op(97);
    goto L15; // [560] 619
L14: 

    /** parser.e:1597			elsif which_type = integer_type or*/
    _28989 = (_which_type_57606 == _53integer_type_47190);
    if (_28989 != 0) {
        goto L16; // [571] 610
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28991 = (object)*(((s1_ptr)_2)->base + _which_type_57606);
    _2 = (object)SEQ_PTR(_28991);
    _28992 = (object)*(((s1_ptr)_2)->base + 2);
    _28991 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_28992)){
        _28993 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_28992)->dbl));
    }
    else{
        _28993 = (object)*(((s1_ptr)_2)->base + _28992);
    }
    _2 = (object)SEQ_PTR(_28993);
    _28994 = (object)*(((s1_ptr)_2)->base + 15);
    _28993 = NOVALUE;
    if (IS_ATOM_INT(_28994)) {
        _28995 = (_28994 == _53integer_type_47190);
    }
    else {
        _28995 = binary_op(EQUALS, _28994, _53integer_type_47190);
    }
    _28994 = NOVALUE;
    if (_28995 == 0) {
        DeRef(_28995);
        _28995 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28995) && DBL_PTR(_28995)->dbl == 0.0){
            DeRef(_28995);
            _28995 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28995);
        _28995 = NOVALUE;
    }
    DeRef(_28995);
    _28995 = NOVALUE;
L16: 

    /** parser.e:1600				emit_op(INTEGER_CHECK)*/
    _45emit_op(96);
L17: 
L15: 
L12: 

    /** parser.e:1603	end procedure*/
    DeRef(_28982);
    _28982 = NOVALUE;
    DeRef(_28989);
    _28989 = NOVALUE;
    _28976 = NOVALUE;
    DeRef(_28959);
    _28959 = NOVALUE;
    _28992 = NOVALUE;
    DeRef(_28943);
    _28943 = NOVALUE;
    _28956 = NOVALUE;
    DeRef(_28954);
    _28954 = NOVALUE;
    _28985 = NOVALUE;
    return;
    ;
}


void _43Assignment(object _left_var_57770)
{
    object _tok_57772 = NOVALUE;
    object _subs_57773 = NOVALUE;
    object _slice_57774 = NOVALUE;
    object _assign_op_57775 = NOVALUE;
    object _subs1_patch_57776 = NOVALUE;
    object _dangerous_57778 = NOVALUE;
    object _lname_57903 = NOVALUE;
    object _temp_len_57922 = NOVALUE;
    object _29092 = NOVALUE;
    object _29091 = NOVALUE;
    object _29090 = NOVALUE;
    object _29089 = NOVALUE;
    object _29088 = NOVALUE;
    object _29087 = NOVALUE;
    object _29086 = NOVALUE;
    object _29077 = NOVALUE;
    object _29076 = NOVALUE;
    object _29075 = NOVALUE;
    object _29074 = NOVALUE;
    object _29073 = NOVALUE;
    object _29072 = NOVALUE;
    object _29071 = NOVALUE;
    object _29070 = NOVALUE;
    object _29069 = NOVALUE;
    object _29068 = NOVALUE;
    object _29067 = NOVALUE;
    object _29066 = NOVALUE;
    object _29065 = NOVALUE;
    object _29064 = NOVALUE;
    object _29063 = NOVALUE;
    object _29061 = NOVALUE;
    object _29060 = NOVALUE;
    object _29059 = NOVALUE;
    object _29057 = NOVALUE;
    object _29052 = NOVALUE;
    object _29051 = NOVALUE;
    object _29048 = NOVALUE;
    object _29047 = NOVALUE;
    object _29045 = NOVALUE;
    object _29039 = NOVALUE;
    object _29034 = NOVALUE;
    object _29031 = NOVALUE;
    object _29028 = NOVALUE;
    object _29025 = NOVALUE;
    object _29024 = NOVALUE;
    object _29023 = NOVALUE;
    object _29021 = NOVALUE;
    object _29020 = NOVALUE;
    object _29019 = NOVALUE;
    object _29018 = NOVALUE;
    object _29017 = NOVALUE;
    object _29016 = NOVALUE;
    object _29014 = NOVALUE;
    object _29013 = NOVALUE;
    object _29012 = NOVALUE;
    object _29011 = NOVALUE;
    object _29009 = NOVALUE;
    object _29008 = NOVALUE;
    object _29007 = NOVALUE;
    object _29006 = NOVALUE;
    object _29005 = NOVALUE;
    object _29003 = NOVALUE;
    object _29002 = NOVALUE;
    object _29001 = NOVALUE;
    object _28998 = NOVALUE;
    object _28997 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1608		integer subs, slice, assign_op, subs1_patch*/

    /** parser.e:1611		left_sym = left_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_left_var_57770);
    _43left_sym_55446 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_43left_sym_55446)){
        _43left_sym_55446 = (object)DBL_PTR(_43left_sym_55446)->dbl;
    }

    /** parser.e:1612		if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _28997 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_28997);
    _28998 = (object)*(((s1_ptr)_2)->base + 4);
    _28997 = NOVALUE;
    if (binary_op_a(NOTEQ, _28998, 9)){
        _28998 = NOVALUE;
        goto L1; // [31] 54
    }
    _28998 = NOVALUE;

    /** parser.e:1613			Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_57770);
    _43Forward_var(_left_var_57770, -1, 18);

    /** parser.e:1614			left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _45Pop();
    _43left_sym_55446 = _0;
    if (!IS_ATOM_INT(_43left_sym_55446)) {
        _1 = (object)(DBL_PTR(_43left_sym_55446)->dbl);
        DeRefDS(_43left_sym_55446);
        _43left_sym_55446 = _1;
    }
    goto L2; // [51] 271
L1: 

    /** parser.e:1616			UndefinedVar(left_sym)*/
    _43UndefinedVar(_43left_sym_55446);

    /** parser.e:1617			if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29001 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29001);
    _29002 = (object)*(((s1_ptr)_2)->base + 4);
    _29001 = NOVALUE;
    if (IS_ATOM_INT(_29002)) {
        _29003 = (_29002 == 2);
    }
    else {
        _29003 = binary_op(EQUALS, _29002, 2);
    }
    _29002 = NOVALUE;
    if (IS_ATOM_INT(_29003)) {
        if (_29003 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_29003)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29005 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29005);
    _29006 = (object)*(((s1_ptr)_2)->base + 4);
    _29005 = NOVALUE;
    if (IS_ATOM_INT(_29006)) {
        _29007 = (_29006 == 4);
    }
    else {
        _29007 = binary_op(EQUALS, _29006, 4);
    }
    _29006 = NOVALUE;
    if (_29007 == 0) {
        DeRef(_29007);
        _29007 = NOVALUE;
        goto L4; // [108] 124
    }
    else {
        if (!IS_ATOM_INT(_29007) && DBL_PTR(_29007)->dbl == 0.0){
            DeRef(_29007);
            _29007 = NOVALUE;
            goto L4; // [108] 124
        }
        DeRef(_29007);
        _29007 = NOVALUE;
    }
    DeRef(_29007);
    _29007 = NOVALUE;
L3: 

    /** parser.e:1619				CompileErr(MAY_NOT_ASSIGN_TO_A_FORLOOP_VARIABLE)*/
    RefDS(_22209);
    _49CompileErr(109, _22209, 0);
    goto L5; // [121] 233
L4: 

    /** parser.e:1621			elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29008 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29008);
    _29009 = (object)*(((s1_ptr)_2)->base + 3);
    _29008 = NOVALUE;
    if (binary_op_a(NOTEQ, _29009, 2)){
        _29009 = NOVALUE;
        goto L6; // [142] 158
    }
    _29009 = NOVALUE;

    /** parser.e:1622				CompileErr(MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22209);
    _49CompileErr(110, _22209, 0);
    goto L5; // [155] 233
L6: 

    /** parser.e:1624			elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29011 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29011);
    _29012 = (object)*(((s1_ptr)_2)->base + 4);
    _29011 = NOVALUE;
    _29013 = find_from(_29012, _43SCOPE_TYPES_55396, 1);
    _29012 = NOVALUE;
    if (_29013 == 0)
    {
        _29013 = NOVALUE;
        goto L7; // [181] 232
    }
    else{
        _29013 = NOVALUE;
    }

    /** parser.e:1626				SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29016 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_29016);
    _29017 = (object)*(((s1_ptr)_2)->base + 23);
    _29016 = NOVALUE;
    _29018 = (_43left_sym_55446 % 29);
    _29019 = power(2, _29018);
    _29018 = NOVALUE;
    if (IS_ATOM_INT(_29017) && IS_ATOM_INT(_29019)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29017 | (uintptr_t)_29019;
             _29020 = MAKE_UINT(tu);
        }
    }
    else {
        _29020 = binary_op(OR_BITS, _29017, _29019);
    }
    _29017 = NOVALUE;
    DeRef(_29019);
    _29019 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29020;
    if( _1 != _29020 ){
        DeRef(_1);
    }
    _29020 = NOVALUE;
    _29014 = NOVALUE;
L7: 
L5: 

    /** parser.e:1630			SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_55446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29023 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29023);
    _29024 = (object)*(((s1_ptr)_2)->base + 5);
    _29023 = NOVALUE;
    if (IS_ATOM_INT(_29024)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29024 | (uintptr_t)2;
             _29025 = MAKE_UINT(tu);
        }
    }
    else {
        _29025 = binary_op(OR_BITS, _29024, 2);
    }
    _29024 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29025;
    if( _1 != _29025 ){
        DeRef(_1);
    }
    _29025 = NOVALUE;
    _29021 = NOVALUE;
L2: 

    /** parser.e:1635		tok = next_token()*/
    _0 = _tok_57772;
    _tok_57772 = _43next_token();
    DeRef(_0);

    /** parser.e:1636		subs = 0*/
    _subs_57773 = 0;

    /** parser.e:1637		slice = FALSE*/
    _slice_57774 = _9FALSE_439;

    /** parser.e:1639		dangerous = FALSE*/
    _dangerous_57778 = _9FALSE_439;

    /** parser.e:1640		side_effect_calls = 0*/
    _43side_effect_calls_55442 = 0;

    /** parser.e:1643		emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55446);

    /** parser.e:1644		current_sequence = append(current_sequence, left_sym)*/
    Append(&_45current_sequence_51421, _45current_sequence_51421, _43left_sym_55446);

    /** parser.e:1646		while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (object)SEQ_PTR(_tok_57772);
    _29028 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29028, -28)){
        _29028 = NOVALUE;
        goto L9; // [334] 523
    }
    _29028 = NOVALUE;

    /** parser.e:1647			subs_depth += 1*/
    _43subs_depth_55447 = _43subs_depth_55447 + 1;

    /** parser.e:1648			if lhs_ptr then*/
    if (_45lhs_ptr_51423 == 0)
    {
        goto LA; // [350] 405
    }
    else{
    }

    /** parser.e:1650				current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51421)){
            _29031 = SEQ_PTR(_45current_sequence_51421)->length;
    }
    else {
        _29031 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51421);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29031)) ? _29031 : (object)(DBL_PTR(_29031)->dbl);
        int stop = (IS_ATOM_INT(_29031)) ? _29031 : (object)(DBL_PTR(_29031)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51421), stop+1, &_45current_sequence_51421);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51421 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51421)->ref == 1));
        }
    }
    _29031 = NOVALUE;
    _29031 = NOVALUE;

    /** parser.e:1651				if subs = 1 then*/
    if (_subs_57773 != 1)
    goto LB; // [371] 396

    /** parser.e:1653					subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29034 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29034 = 1;
    }
    _subs1_patch_57776 = _29034 + 1;
    _29034 = NOVALUE;

    /** parser.e:1654					emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _45emit_op(161);
    goto LC; // [393] 404
LB: 

    /** parser.e:1657					emit_op(LHS_SUBS) -- adds to current_sequence*/
    _45emit_op(95);
LC: 
LA: 

    /** parser.e:1660			subs += 1*/
    _subs_57773 = _subs_57773 + 1;

    /** parser.e:1661			if subs = 1 then*/
    if (_subs_57773 != 1)
    goto LD; // [413] 428

    /** parser.e:1662				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_55446, _9TRUE_441);
LD: 

    /** parser.e:1664			Expr()*/
    _43Expr();

    /** parser.e:1665			tok = next_token()*/
    _0 = _tok_57772;
    _tok_57772 = _43next_token();
    DeRef(_0);

    /** parser.e:1666			if tok[T_ID] = SLICE then*/
    _2 = (object)SEQ_PTR(_tok_57772);
    _29039 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29039, 513)){
        _29039 = NOVALUE;
        goto LE; // [447] 484
    }
    _29039 = NOVALUE;

    /** parser.e:1667				Expr()*/
    _43Expr();

    /** parser.e:1668				slice = TRUE*/
    _slice_57774 = _9TRUE_441;

    /** parser.e:1669				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1670				tok = next_token()*/
    _0 = _tok_57772;
    _tok_57772 = _43next_token();
    DeRef(_0);

    /** parser.e:1671				exit  -- no further subs or slices allowed*/
    goto L9; // [479] 523
    goto LF; // [481] 506
LE: 

    /** parser.e:1673				putback(tok)*/
    Ref(_tok_57772);
    _43putback(_tok_57772);

    /** parser.e:1674				tok_match(RIGHT_SQUARE)*/
    _43tok_match(-29, 0);

    /** parser.e:1675				subs_depth -= 1*/
    _43subs_depth_55447 = _43subs_depth_55447 - 1;
LF: 

    /** parser.e:1677			tok = next_token()*/
    _0 = _tok_57772;
    _tok_57772 = _43next_token();
    DeRef(_0);

    /** parser.e:1678			lhs_ptr = TRUE*/
    _45lhs_ptr_51423 = _9TRUE_441;

    /** parser.e:1679		end while*/
    goto L8; // [520] 326
L9: 

    /** parser.e:1681		lhs_ptr = FALSE*/
    _45lhs_ptr_51423 = _9FALSE_439;

    /** parser.e:1683		assign_op = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_57772);
    _assign_op_57775 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_57775)){
        _assign_op_57775 = (object)DBL_PTR(_assign_op_57775)->dbl;
    }

    /** parser.e:1684		if not find(assign_op, ASSIGN_OPS) then*/
    _29045 = find_from(_assign_op_57775, _43ASSIGN_OPS_55388, 1);
    if (_29045 != 0)
    goto L10; // [549] 613
    _29045 = NOVALUE;

    /** parser.e:1685			sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_left_var_57770);
    _29047 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29047)){
        _29048 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29047)->dbl));
    }
    else{
        _29048 = (object)*(((s1_ptr)_2)->base + _29047);
    }
    DeRef(_lname_57903);
    _2 = (object)SEQ_PTR(_29048);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _lname_57903 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _lname_57903 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_lname_57903);
    _29048 = NOVALUE;

    /** parser.e:1686			if assign_op = COLON then*/
    if (_assign_op_57775 != -23)
    goto L11; // [578] 598

    /** parser.e:1687				CompileErr(SYNTAX_ERROR__UNKNOWN_NAMESPACE_1_USED, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57903);
    ((intptr_t*)_2)[1] = _lname_57903;
    _29051 = MAKE_SEQ(_1);
    _49CompileErr(133, _29051, 0);
    _29051 = NOVALUE;
    goto L12; // [595] 612
L11: 

    /** parser.e:1689				CompileErr(EXPECTED_TO_SEE_AN_ASSIGNMENT_AFTER_1_SUCH_AS__OR, {lname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lname_57903);
    ((intptr_t*)_2)[1] = _lname_57903;
    _29052 = MAKE_SEQ(_1);
    _49CompileErr(76, _29052, 0);
    _29052 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_57903);
    _lname_57903 = NOVALUE;

    /** parser.e:1693		if subs = 0 then*/
    if (_subs_57773 != 0)
    goto L13; // [617] 745

    /** parser.e:1695			integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _temp_len_57922 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _temp_len_57922 = 1;
    }

    /** parser.e:1696			if assign_op = EQUALS then*/
    if (_assign_op_57775 != 3)
    goto L14; // [632] 653

    /** parser.e:1697				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1698				InitCheck(left_sym, FALSE)*/
    _43InitCheck(_43left_sym_55446, _9FALSE_439);
    goto L15; // [650] 726
L14: 

    /** parser.e:1700				InitCheck(left_sym, TRUE)*/
    _43InitCheck(_43left_sym_55446, _9TRUE_441);

    /** parser.e:1701				if left_sym > 0 then*/
    if (_43left_sym_55446 <= 0)
    goto L16; // [667] 709

    /** parser.e:1702					SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_43left_sym_55446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29059 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29059);
    _29060 = (object)*(((s1_ptr)_2)->base + 5);
    _29059 = NOVALUE;
    if (IS_ATOM_INT(_29060)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29060 | (uintptr_t)1;
             _29061 = MAKE_UINT(tu);
        }
    }
    else {
        _29061 = binary_op(OR_BITS, _29060, 1);
    }
    _29060 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29061;
    if( _1 != _29061 ){
        DeRef(_1);
    }
    _29061 = NOVALUE;
    _29057 = NOVALUE;
L16: 

    /** parser.e:1704				emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55446);

    /** parser.e:1705				Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1706				emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57775);
L15: 

    /** parser.e:1708			emit_op(ASSIGN)*/
    _45emit_op(18);

    /** parser.e:1709			TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_55446);
    goto L17; // [742] 1169
L13: 

    /** parser.e:1712			factors = 0*/
    _43factors_55443 = 0;

    /** parser.e:1713			lhs_subs_level = -1*/
    _43lhs_subs_level_55444 = -1;

    /** parser.e:1714			Expr() -- RHS expression*/
    _43Expr();

    /** parser.e:1716			if subs > 1 then*/
    if (_subs_57773 <= 1)
    goto L18; // [761] 900

    /** parser.e:1717				if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _29063 = (_43left_sym_55446 < 0);
    if (_29063 != 0) {
        _29064 = 1;
        goto L19; // [773] 801
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29065 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29065);
    _29066 = (object)*(((s1_ptr)_2)->base + 4);
    _29065 = NOVALUE;
    if (IS_ATOM_INT(_29066)) {
        _29067 = (_29066 != 3);
    }
    else {
        _29067 = binary_op(NOTEQ, _29066, 3);
    }
    _29066 = NOVALUE;
    if (IS_ATOM_INT(_29067))
    _29064 = (_29067 != 0);
    else
    _29064 = DBL_PTR(_29067)->dbl != 0.0;
L19: 
    if (_29064 == 0) {
        goto L1A; // [801] 835
    }
    _29069 = (_43left_sym_55446 % 29);
    _29070 = power(2, _29069);
    _29069 = NOVALUE;
    if (IS_ATOM_INT(_29070)) {
        {uintptr_t tu;
             tu = (uintptr_t)_43side_effect_calls_55442 & (uintptr_t)_29070;
             _29071 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_43side_effect_calls_55442;
        _29071 = Dand_bits(&temp_d, DBL_PTR(_29070));
    }
    DeRef(_29070);
    _29070 = NOVALUE;
    if (_29071 == 0) {
        DeRef(_29071);
        _29071 = NOVALUE;
        goto L1A; // [824] 835
    }
    else {
        if (!IS_ATOM_INT(_29071) && DBL_PTR(_29071)->dbl == 0.0){
            DeRef(_29071);
            _29071 = NOVALUE;
            goto L1A; // [824] 835
        }
        DeRef(_29071);
        _29071 = NOVALUE;
    }
    DeRef(_29071);
    _29071 = NOVALUE;

    /** parser.e:1722					dangerous = TRUE*/
    _dangerous_57778 = _9TRUE_441;
L1A: 

    /** parser.e:1725				if factors = 1 and*/
    _29072 = (_43factors_55443 == 1);
    if (_29072 == 0) {
        _29073 = 0;
        goto L1B; // [843] 857
    }
    _29074 = (_43lhs_subs_level_55444 >= 0);
    _29073 = (_29074 != 0);
L1B: 
    if (_29073 == 0) {
        goto L1C; // [857] 883
    }
    _29076 = _subs_57773 + _slice_57774;
    if ((object)((uintptr_t)_29076 + (uintptr_t)HIGH_BITS) >= 0){
        _29076 = NewDouble((eudouble)_29076);
    }
    if (IS_ATOM_INT(_29076)) {
        _29077 = (_43lhs_subs_level_55444 < _29076);
    }
    else {
        _29077 = ((eudouble)_43lhs_subs_level_55444 < DBL_PTR(_29076)->dbl);
    }
    DeRef(_29076);
    _29076 = NOVALUE;
    if (_29077 == 0)
    {
        DeRef(_29077);
        _29077 = NOVALUE;
        goto L1C; // [872] 883
    }
    else{
        DeRef(_29077);
        _29077 = NOVALUE;
    }

    /** parser.e:1729					dangerous = TRUE*/
    _dangerous_57778 = _9TRUE_441;
L1C: 

    /** parser.e:1732				if dangerous then*/
    if (_dangerous_57778 == 0)
    {
        goto L1D; // [885] 899
    }
    else{
    }

    /** parser.e:1738					backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _45backpatch(_subs1_patch_57776, 166);
L1D: 
L18: 

    /** parser.e:1742			if slice then*/
    if (_slice_57774 == 0)
    {
        goto L1E; // [902] 970
    }
    else{
    }

    /** parser.e:1743				if assign_op != EQUALS then*/
    if (_assign_op_57775 == 3)
    goto L1F; // [909] 943

    /** parser.e:1744					if subs = 1 then*/
    if (_subs_57773 != 1)
    goto L20; // [915] 929

    /** parser.e:1745						emit_op(ASSIGN_OP_SLICE)*/
    _45emit_op(150);
    goto L21; // [926] 937
L20: 

    /** parser.e:1747						emit_op(PASSIGN_OP_SLICE)*/
    _45emit_op(165);
L21: 

    /** parser.e:1749					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57775);
L1F: 

    /** parser.e:1751				if subs = 1 then*/
    if (_subs_57773 != 1)
    goto L22; // [945] 959

    /** parser.e:1752					emit_op(ASSIGN_SLICE)*/
    _45emit_op(45);
    goto L23; // [956] 1060
L22: 

    /** parser.e:1754					emit_op(PASSIGN_SLICE)*/
    _45emit_op(163);
    goto L23; // [967] 1060
L1E: 

    /** parser.e:1757				if assign_op = EQUALS then*/
    if (_assign_op_57775 != 3)
    goto L24; // [974] 1005

    /** parser.e:1758					if subs = 1 then*/
    if (_subs_57773 != 1)
    goto L25; // [980] 994

    /** parser.e:1759						emit_op(ASSIGN_SUBS)*/
    _45emit_op(16);
    goto L26; // [991] 1059
L25: 

    /** parser.e:1761						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162);
    goto L26; // [1002] 1059
L24: 

    /** parser.e:1764					if subs = 1 then*/
    if (_subs_57773 != 1)
    goto L27; // [1007] 1021

    /** parser.e:1765						emit_op(ASSIGN_OP_SUBS)*/
    _45emit_op(149);
    goto L28; // [1018] 1029
L27: 

    /** parser.e:1767						emit_op(PASSIGN_OP_SUBS)*/
    _45emit_op(164);
L28: 

    /** parser.e:1769					emit_assign_op(assign_op)*/
    _45emit_assign_op(_assign_op_57775);

    /** parser.e:1770					if subs = 1 then*/
    if (_subs_57773 != 1)
    goto L29; // [1036] 1050

    /** parser.e:1771						emit_op(ASSIGN_SUBS2)*/
    _45emit_op(148);
    goto L2A; // [1047] 1058
L29: 

    /** parser.e:1773						emit_op(PASSIGN_SUBS)*/
    _45emit_op(162);
L2A: 
L26: 
L23: 

    /** parser.e:1778			if subs > 1 then*/
    if (_subs_57773 <= 1)
    goto L2B; // [1062] 1114

    /** parser.e:1779				if dangerous then*/
    if (_dangerous_57778 == 0)
    {
        goto L2C; // [1068] 1105
    }
    else{
    }

    /** parser.e:1781					emit_opnd(left_sym)*/
    _45emit_opnd(_43left_sym_55446);

    /** parser.e:1782					emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _45emit_opnd(_45lhs_subs1_copy_temp_51426);

    /** parser.e:1783					emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _45emit_temp(_45lhs_subs1_copy_temp_51426, 1);

    /** parser.e:1784					emit_op(ASSIGN)*/
    _45emit_op(18);
    goto L2D; // [1102] 1113
L2C: 

    /** parser.e:1787					TempFree(lhs_subs1_copy_temp)*/
    _45TempFree(_45lhs_subs1_copy_temp_51426);
L2D: 
L2B: 

    /** parser.e:1791			if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_27OpTypeCheck_20642 == 0) {
        goto L2E; // [1118] 1168
    }
    _29087 = (_43left_sym_55446 < 0);
    if (_29087 != 0) {
        DeRef(_29088);
        _29088 = 1;
        goto L2F; // [1128] 1156
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29089 = (object)*(((s1_ptr)_2)->base + _43left_sym_55446);
    _2 = (object)SEQ_PTR(_29089);
    _29090 = (object)*(((s1_ptr)_2)->base + 15);
    _29089 = NOVALUE;
    if (IS_ATOM_INT(_29090)) {
        _29091 = (_29090 != _53sequence_type_47188);
    }
    else {
        _29091 = binary_op(NOTEQ, _29090, _53sequence_type_47188);
    }
    _29090 = NOVALUE;
    if (IS_ATOM_INT(_29091))
    _29088 = (_29091 != 0);
    else
    _29088 = DBL_PTR(_29091)->dbl != 0.0;
L2F: 
    if (_29088 == 0)
    {
        _29088 = NOVALUE;
        goto L2E; // [1157] 1168
    }
    else{
        _29088 = NOVALUE;
    }

    /** parser.e:1792				TypeCheck(left_sym)*/
    _43TypeCheck(_43left_sym_55446);
L2E: 
L17: 

    /** parser.e:1796		current_sequence = remove( current_sequence, length( current_sequence ) )*/
    if (IS_SEQUENCE(_45current_sequence_51421)){
            _29092 = SEQ_PTR(_45current_sequence_51421)->length;
    }
    else {
        _29092 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_45current_sequence_51421);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29092)) ? _29092 : (object)(DBL_PTR(_29092)->dbl);
        int stop = (IS_ATOM_INT(_29092)) ? _29092 : (object)(DBL_PTR(_29092)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421 );
            }
            else Tail(SEQ_PTR(_45current_sequence_51421), stop+1, &_45current_sequence_51421);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_45current_sequence_51421), start, &_45current_sequence_51421);
        }
        else {
            assign_slice_seq = &assign_space;
            _45current_sequence_51421 = Remove_elements(start, stop, (SEQ_PTR(_45current_sequence_51421)->ref == 1));
        }
    }
    _29092 = NOVALUE;
    _29092 = NOVALUE;

    /** parser.e:1798		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L30; // [1189] 1215

    /** parser.e:1799			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L31; // [1196] 1214
    }
    else{
    }

    /** parser.e:1800				emit_op(DISPLAY_VAR)*/
    _45emit_op(87);

    /** parser.e:1801				emit_addr(left_sym)*/
    _45emit_addr(_43left_sym_55446);
L31: 
L30: 

    /** parser.e:1804	end procedure*/
    DeRef(_left_var_57770);
    DeRef(_tok_57772);
    DeRef(_29067);
    _29067 = NOVALUE;
    DeRef(_29087);
    _29087 = NOVALUE;
    DeRef(_29074);
    _29074 = NOVALUE;
    _29047 = NOVALUE;
    DeRef(_29063);
    _29063 = NOVALUE;
    DeRef(_29003);
    _29003 = NOVALUE;
    DeRef(_29091);
    _29091 = NOVALUE;
    DeRef(_29072);
    _29072 = NOVALUE;
    return;
    ;
}


void _43Multi_assign()
{
    object _lhs_syms_58062 = NOVALUE;
    object _lhs_list_58063 = NOVALUE;
    object _tok_58065 = NOVALUE;
    object _need_comma_58066 = NOVALUE;
    object _temp_sym_58128 = NOVALUE;
    object _temps_58131 = NOVALUE;
    object _len_58179 = NOVALUE;
    object _29151 = NOVALUE;
    object _29149 = NOVALUE;
    object _29147 = NOVALUE;
    object _29145 = NOVALUE;
    object _29144 = NOVALUE;
    object _29143 = NOVALUE;
    object _29142 = NOVALUE;
    object _29141 = NOVALUE;
    object _29140 = NOVALUE;
    object _29138 = NOVALUE;
    object _29137 = NOVALUE;
    object _29136 = NOVALUE;
    object _29135 = NOVALUE;
    object _29134 = NOVALUE;
    object _29132 = NOVALUE;
    object _29131 = NOVALUE;
    object _29130 = NOVALUE;
    object _29129 = NOVALUE;
    object _29128 = NOVALUE;
    object _29124 = NOVALUE;
    object _29123 = NOVALUE;
    object _29122 = NOVALUE;
    object _29121 = NOVALUE;
    object _29118 = NOVALUE;
    object _29117 = NOVALUE;
    object _29115 = NOVALUE;
    object _29114 = NOVALUE;
    object _29113 = NOVALUE;
    object _29111 = NOVALUE;
    object _29110 = NOVALUE;
    object _29109 = NOVALUE;
    object _29108 = NOVALUE;
    object _29106 = NOVALUE;
    object _29105 = NOVALUE;
    object _29104 = NOVALUE;
    object _29102 = NOVALUE;
    object _29101 = NOVALUE;
    object _29098 = NOVALUE;
    object _29095 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:1811		sequence lhs_syms = {}*/
    RefDS(_22209);
    DeRef(_lhs_syms_58062);
    _lhs_syms_58062 = _22209;

    /** parser.e:1812		sequence lhs_list = {} -- make sure we don't repeat anything*/
    RefDS(_22209);
    DeRef(_lhs_list_58063);
    _lhs_list_58063 = _22209;

    /** parser.e:1814		integer need_comma = 0*/
    _need_comma_58066 = 0;

    /** parser.e:1815		while tok[T_ID] != RIGHT_BRACE with entry do*/
    goto L1; // [22] 215
L2: 
    _2 = (object)SEQ_PTR(_tok_58065);
    _29095 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29095, -25)){
        _29095 = NOVALUE;
        goto L3; // [35] 225
    }
    _29095 = NOVALUE;

    /** parser.e:1817			if need_comma then*/
    if (_need_comma_58066 == 0)
    {
        goto L4; // [41] 63
    }
    else{
    }

    /** parser.e:1818				putback( tok )*/
    Ref(_tok_58065);
    _43putback(_tok_58065);

    /** parser.e:1819				tok_match( COMMA )*/
    _43tok_match(-30, 0);

    /** parser.e:1820				tok = next_token()*/
    _0 = _tok_58065;
    _tok_58065 = _43next_token();
    DeRef(_0);
L4: 

    /** parser.e:1823			if tok[T_ID] = QUESTION_MARK then*/
    _2 = (object)SEQ_PTR(_tok_58065);
    _29098 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29098, -31)){
        _29098 = NOVALUE;
        goto L5; // [73] 86
    }
    _29098 = NOVALUE;

    /** parser.e:1825				lhs_syms &= 0*/
    Append(&_lhs_syms_58062, _lhs_syms_58062, 0);
    goto L6; // [83] 207
L5: 

    /** parser.e:1826			elsif tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_58065);
    _29101 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29101)) {
        _29102 = (_29101 == -100);
    }
    else {
        _29102 = binary_op(EQUALS, _29101, -100);
    }
    _29101 = NOVALUE;
    if (IS_ATOM_INT(_29102)) {
        if (_29102 != 0) {
            goto L7; // [100] 121
        }
    }
    else {
        if (DBL_PTR(_29102)->dbl != 0.0) {
            goto L7; // [100] 121
        }
    }
    _2 = (object)SEQ_PTR(_tok_58065);
    _29104 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29104)) {
        _29105 = (_29104 == 512);
    }
    else {
        _29105 = binary_op(EQUALS, _29104, 512);
    }
    _29104 = NOVALUE;
    if (_29105 == 0) {
        DeRef(_29105);
        _29105 = NOVALUE;
        goto L8; // [117] 197
    }
    else {
        if (!IS_ATOM_INT(_29105) && DBL_PTR(_29105)->dbl == 0.0){
            DeRef(_29105);
            _29105 = NOVALUE;
            goto L8; // [117] 197
        }
        DeRef(_29105);
        _29105 = NOVALUE;
    }
    DeRef(_29105);
    _29105 = NOVALUE;
L7: 

    /** parser.e:1827				lhs_syms &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_58065);
    _29106 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_lhs_syms_58062) && IS_ATOM(_29106)) {
        Ref(_29106);
        Append(&_lhs_syms_58062, _lhs_syms_58062, _29106);
    }
    else if (IS_ATOM(_lhs_syms_58062) && IS_SEQUENCE(_29106)) {
    }
    else {
        Concat((object_ptr)&_lhs_syms_58062, _lhs_syms_58062, _29106);
    }
    _29106 = NOVALUE;

    /** parser.e:1828				if SymTab[lhs_syms[$]][S_SCOPE] = SC_UNDEFINED then*/
    if (IS_SEQUENCE(_lhs_syms_58062)){
            _29108 = SEQ_PTR(_lhs_syms_58062)->length;
    }
    else {
        _29108 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58062);
    _29109 = (object)*(((s1_ptr)_2)->base + _29108);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29109)){
        _29110 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29109)->dbl));
    }
    else{
        _29110 = (object)*(((s1_ptr)_2)->base + _29109);
    }
    _2 = (object)SEQ_PTR(_29110);
    _29111 = (object)*(((s1_ptr)_2)->base + 4);
    _29110 = NOVALUE;
    if (binary_op_a(NOTEQ, _29111, 9)){
        _29111 = NOVALUE;
        goto L9; // [156] 180
    }
    _29111 = NOVALUE;

    /** parser.e:1829					lhs_list = append( lhs_list, sym_name( lhs_syms[$] ) )*/
    if (IS_SEQUENCE(_lhs_syms_58062)){
            _29113 = SEQ_PTR(_lhs_syms_58062)->length;
    }
    else {
        _29113 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58062);
    _29114 = (object)*(((s1_ptr)_2)->base + _29113);
    Ref(_29114);
    _29115 = _53sym_name(_29114);
    _29114 = NOVALUE;
    Ref(_29115);
    Append(&_lhs_list_58063, _lhs_list_58063, _29115);
    DeRef(_29115);
    _29115 = NOVALUE;
    goto L6; // [177] 207
L9: 

    /** parser.e:1831					lhs_list &= lhs_syms[$]*/
    if (IS_SEQUENCE(_lhs_syms_58062)){
            _29117 = SEQ_PTR(_lhs_syms_58062)->length;
    }
    else {
        _29117 = 1;
    }
    _2 = (object)SEQ_PTR(_lhs_syms_58062);
    _29118 = (object)*(((s1_ptr)_2)->base + _29117);
    if (IS_SEQUENCE(_lhs_list_58063) && IS_ATOM(_29118)) {
        Ref(_29118);
        Append(&_lhs_list_58063, _lhs_list_58063, _29118);
    }
    else if (IS_ATOM(_lhs_list_58063) && IS_SEQUENCE(_29118)) {
    }
    else {
        Concat((object_ptr)&_lhs_list_58063, _lhs_list_58063, _29118);
    }
    _29118 = NOVALUE;
    goto L6; // [194] 207
L8: 

    /** parser.e:1834				CompileErr( A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(24, _22209, 0);
L6: 

    /** parser.e:1837			need_comma = 1*/
    _need_comma_58066 = 1;

    /** parser.e:1838		entry*/
L1: 

    /** parser.e:1839			tok = next_token()*/
    _0 = _tok_58065;
    _tok_58065 = _43next_token();
    DeRef(_0);

    /** parser.e:1840		end while*/
    goto L2; // [222] 25
L3: 

    /** parser.e:1843		if length( lhs_list ) != length( remove_dups( sort( lhs_list ) ) ) then*/
    if (IS_SEQUENCE(_lhs_list_58063)){
            _29121 = SEQ_PTR(_lhs_list_58063)->length;
    }
    else {
        _29121 = 1;
    }
    RefDS(_lhs_list_58063);
    _29122 = _25sort(_lhs_list_58063, 1);
    _29123 = _24remove_dups(_29122, 2);
    _29122 = NOVALUE;
    if (IS_SEQUENCE(_29123)){
            _29124 = SEQ_PTR(_29123)->length;
    }
    else {
        _29124 = 1;
    }
    DeRef(_29123);
    _29123 = NOVALUE;
    if (_29121 == _29124)
    goto LA; // [243] 257

    /** parser.e:1844			CompileErr( DUPLICATE_MULTI_ASSIGN )*/
    RefDS(_22209);
    _49CompileErr(602, _22209, 0);
LA: 

    /** parser.e:1846		tok_match( EQUALS )*/
    _43tok_match(3, 0);

    /** parser.e:1849		Expr()*/
    _43Expr();

    /** parser.e:1851		symtab_index temp_sym = Pop()*/
    _temp_sym_58128 = _45Pop();
    if (!IS_ATOM_INT(_temp_sym_58128)) {
        _1 = (object)(DBL_PTR(_temp_sym_58128)->dbl);
        DeRefDS(_temp_sym_58128);
        _temp_sym_58128 = _1;
    }

    /** parser.e:1852		sequence temps = pop_temps()*/
    _0 = _temps_58131;
    _temps_58131 = _45pop_temps();
    DeRef(_0);

    /** parser.e:1853		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LB; // [287] 303
    }
    else{
    }

    /** parser.e:1854			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_58128);

    /** parser.e:1855			emit_op( REF_TEMP )*/
    _45emit_op(207);
LB: 

    /** parser.e:1858		for i = 1 to length( lhs_syms ) do*/
    if (IS_SEQUENCE(_lhs_syms_58062)){
            _29128 = SEQ_PTR(_lhs_syms_58062)->length;
    }
    else {
        _29128 = 1;
    }
    {
        object _i_58140;
        _i_58140 = 1;
LC: 
        if (_i_58140 > _29128){
            goto LD; // [308] 512
        }

        /** parser.e:1859			if lhs_syms[i] then*/
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29129 = (object)*(((s1_ptr)_2)->base + _i_58140);
        if (_29129 == 0) {
            _29129 = NOVALUE;
            goto LE; // [321] 503
        }
        else {
            if (!IS_ATOM_INT(_29129) && DBL_PTR(_29129)->dbl == 0.0){
                _29129 = NOVALUE;
                goto LE; // [321] 503
            }
            _29129 = NOVALUE;
        }
        _29129 = NOVALUE;

        /** parser.e:1860				if SymTab[lhs_syms[i]][S_SCOPE] = SC_UNDEFINED then*/
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29130 = (object)*(((s1_ptr)_2)->base + _i_58140);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_29130)){
            _29131 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29130)->dbl));
        }
        else{
            _29131 = (object)*(((s1_ptr)_2)->base + _29130);
        }
        _2 = (object)SEQ_PTR(_29131);
        _29132 = (object)*(((s1_ptr)_2)->base + 4);
        _29131 = NOVALUE;
        if (binary_op_a(NOTEQ, _29132, 9)){
            _29132 = NOVALUE;
            goto LF; // [344] 379
        }
        _29132 = NOVALUE;

        /** parser.e:1861					Forward_var( { VARIABLE, lhs_syms[i]}, ,ASSIGN )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29134 = (object)*(((s1_ptr)_2)->base + _i_58140);
        Ref(_29134);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100;
        ((intptr_t *)_2)[2] = _29134;
        _29135 = MAKE_SEQ(_1);
        _29134 = NOVALUE;
        _43Forward_var(_29135, -1, 18);
        _29135 = NOVALUE;

        /** parser.e:1862					lhs_syms[i] = Pop()*/
        _29136 = _45Pop();
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _lhs_syms_58062 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_58140);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29136;
        if( _1 != _29136 ){
            DeRef(_1);
        }
        _29136 = NOVALUE;
        goto L10; // [376] 421
LF: 

        /** parser.e:1864					SymTab[lhs_syms[i]][S_USAGE] = or_bits(SymTab[lhs_syms[i]][S_USAGE], U_WRITTEN)*/
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29137 = (object)*(((s1_ptr)_2)->base + _i_58140);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29137))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29137)->dbl));
        else
        _3 = (object)(_29137 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29140 = (object)*(((s1_ptr)_2)->base + _i_58140);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!IS_ATOM_INT(_29140)){
            _29141 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29140)->dbl));
        }
        else{
            _29141 = (object)*(((s1_ptr)_2)->base + _29140);
        }
        _2 = (object)SEQ_PTR(_29141);
        _29142 = (object)*(((s1_ptr)_2)->base + 5);
        _29141 = NOVALUE;
        if (IS_ATOM_INT(_29142)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_29142 | (uintptr_t)2;
                 _29143 = MAKE_UINT(tu);
            }
        }
        else {
            _29143 = binary_op(OR_BITS, _29142, 2);
        }
        _29142 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29143;
        if( _1 != _29143 ){
            DeRef(_1);
        }
        _29143 = NOVALUE;
        _29138 = NOVALUE;
L10: 

        /** parser.e:1867				emit_opnd( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29144 = (object)*(((s1_ptr)_2)->base + _i_58140);
        Ref(_29144);
        _45emit_opnd(_29144);
        _29144 = NOVALUE;

        /** parser.e:1869				emit_opnd( temp_sym )*/
        _45emit_opnd(_temp_sym_58128);

        /** parser.e:1870				emit_opnd( NewIntSym( i ) )*/
        _29145 = _53NewIntSym(_i_58140);
        _45emit_opnd(_29145);
        _29145 = NOVALUE;

        /** parser.e:1871				emit_op( RHS_SUBS )*/
        _45emit_op(25);

        /** parser.e:1872				integer len = length( Code )*/
        if (IS_SEQUENCE(_27Code_20660)){
                _len_58179 = SEQ_PTR(_27Code_20660)->length;
        }
        else {
            _len_58179 = 1;
        }

        /** parser.e:1873				if Code[len] = temp_sym then*/
        _2 = (object)SEQ_PTR(_27Code_20660);
        _29147 = (object)*(((s1_ptr)_2)->base + _len_58179);
        if (binary_op_a(NOTEQ, _29147, _temp_sym_58128)){
            _29147 = NOVALUE;
            goto L11; // [466] 486
        }
        _29147 = NOVALUE;

        /** parser.e:1875					Code = remove( Code, len - 1, len )*/
        _29149 = _len_58179 - 1;
        {
            s1_ptr assign_space = SEQ_PTR(_27Code_20660);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_29149)) ? _29149 : (object)(DBL_PTR(_29149)->dbl);
            int stop = (IS_ATOM_INT(_len_58179)) ? _len_58179 : (object)(DBL_PTR(_len_58179)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_27Code_20660), start, &_27Code_20660 );
                }
                else Tail(SEQ_PTR(_27Code_20660), stop+1, &_27Code_20660);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_27Code_20660), start, &_27Code_20660);
            }
            else {
                assign_slice_seq = &assign_space;
                _27Code_20660 = Remove_elements(start, stop, (SEQ_PTR(_27Code_20660)->ref == 1));
            }
        }
        _29149 = NOVALUE;
L11: 

        /** parser.e:1877				emit_op( ASSIGN )*/
        _45emit_op(18);

        /** parser.e:1879				TypeCheck( lhs_syms[i] )*/
        _2 = (object)SEQ_PTR(_lhs_syms_58062);
        _29151 = (object)*(((s1_ptr)_2)->base + _i_58140);
        Ref(_29151);
        _43TypeCheck(_29151);
        _29151 = NOVALUE;
LE: 

        /** parser.e:1882		end for*/
        _i_58140 = _i_58140 + 1;
        goto LC; // [507] 315
LD: 
        ;
    }

    /** parser.e:1884		push_temps( temps )*/
    RefDS(_temps_58131);
    _45push_temps(_temps_58131);

    /** parser.e:1885		flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:1887		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L12; // [526] 542
    }
    else{
    }

    /** parser.e:1888			emit_opnd( temp_sym )*/
    _45emit_opnd(_temp_sym_58128);

    /** parser.e:1889			emit_op( DEREF_TEMP )*/
    _45emit_op(208);
L12: 

    /** parser.e:1891	end procedure*/
    DeRef(_lhs_syms_58062);
    DeRef(_lhs_list_58063);
    DeRef(_tok_58065);
    DeRef(_temps_58131);
    DeRef(_29102);
    _29102 = NOVALUE;
    _29130 = NOVALUE;
    _29109 = NOVALUE;
    _29140 = NOVALUE;
    _29137 = NOVALUE;
    _29123 = NOVALUE;
    return;
    ;
}


void _43Return_statement()
{
    object _tok_58203 = NOVALUE;
    object _pop_58204 = NOVALUE;
    object _last_op_58211 = NOVALUE;
    object _last_pc_58214 = NOVALUE;
    object _is_tail_58217 = NOVALUE;
    object _29183 = NOVALUE;
    object _29181 = NOVALUE;
    object _29180 = NOVALUE;
    object _29179 = NOVALUE;
    object _29178 = NOVALUE;
    object _29176 = NOVALUE;
    object _29175 = NOVALUE;
    object _29174 = NOVALUE;
    object _29173 = NOVALUE;
    object _29172 = NOVALUE;
    object _29171 = NOVALUE;
    object _29170 = NOVALUE;
    object _29169 = NOVALUE;
    object _29165 = NOVALUE;
    object _29164 = NOVALUE;
    object _29162 = NOVALUE;
    object _29161 = NOVALUE;
    object _29160 = NOVALUE;
    object _29159 = NOVALUE;
    object _29158 = NOVALUE;
    object _29157 = NOVALUE;
    object _29156 = NOVALUE;
    object _29155 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1897		integer pop*/

    /** parser.e:1898		if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto L1; // [9] 23

    /** parser.e:1899			CompileErr(RETURN_MUST_BE_INSIDE_A_PROCEDURE_OR_FUNCTION)*/
    RefDS(_22209);
    _49CompileErr(130, _22209, 0);
L1: 

    /** parser.e:1902		integer*/

    /** parser.e:1903			last_op = Last_op(),*/
    _last_op_58211 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_58211)) {
        _1 = (object)(DBL_PTR(_last_op_58211)->dbl);
        DeRefDS(_last_op_58211);
        _last_op_58211 = _1;
    }

    /** parser.e:1904			last_pc = Last_pc(),*/
    _last_pc_58214 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_58214)) {
        _1 = (object)(DBL_PTR(_last_pc_58214)->dbl);
        DeRefDS(_last_pc_58214);
        _last_pc_58214 = _1;
    }

    /** parser.e:1905			is_tail = 0*/
    _is_tail_58217 = 0;

    /** parser.e:1907		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _29155 = (_last_op_58211 == 27);
    if (_29155 == 0) {
        _29156 = 0;
        goto L2; // [52] 69
    }
    if (IS_SEQUENCE(_27Code_20660)){
            _29157 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29157 = 1;
    }
    _29158 = (_29157 > _last_pc_58214);
    _29157 = NOVALUE;
    _29156 = (_29158 != 0);
L2: 
    if (_29156 == 0) {
        goto L3; // [69] 99
    }
    _29160 = _last_pc_58214 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _29161 = (object)*(((s1_ptr)_2)->base + _29160);
    if (IS_ATOM_INT(_29161)) {
        _29162 = (_29161 == _27CurrentSub_20579);
    }
    else {
        _29162 = binary_op(EQUALS, _29161, _27CurrentSub_20579);
    }
    _29161 = NOVALUE;
    if (_29162 == 0) {
        DeRef(_29162);
        _29162 = NOVALUE;
        goto L3; // [90] 99
    }
    else {
        if (!IS_ATOM_INT(_29162) && DBL_PTR(_29162)->dbl == 0.0){
            DeRef(_29162);
            _29162 = NOVALUE;
            goto L3; // [90] 99
        }
        DeRef(_29162);
        _29162 = NOVALUE;
    }
    DeRef(_29162);
    _29162 = NOVALUE;

    /** parser.e:1908			is_tail = 1*/
    _is_tail_58217 = 1;
L3: 

    /** parser.e:1911		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L4; // [103] 129

    /** parser.e:1912			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L5; // [110] 128
    }
    else{
    }

    /** parser.e:1913				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:1914				emit_addr(CurrentSub)*/
    _45emit_addr(_27CurrentSub_20579);
L5: 
L4: 

    /** parser.e:1917		if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29164 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_29164);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _29165 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _29165 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _29164 = NOVALUE;
    if (binary_op_a(EQUALS, _29165, 27)){
        _29165 = NOVALUE;
        goto L6; // [147] 273
    }
    _29165 = NOVALUE;

    /** parser.e:1918			Expr()*/
    _43Expr();

    /** parser.e:1919			last_op = Last_op()*/
    _last_op_58211 = _45Last_op();
    if (!IS_ATOM_INT(_last_op_58211)) {
        _1 = (object)(DBL_PTR(_last_op_58211)->dbl);
        DeRefDS(_last_op_58211);
        _last_op_58211 = _1;
    }

    /** parser.e:1920			last_pc = Last_pc()*/
    _last_pc_58214 = _45Last_pc();
    if (!IS_ATOM_INT(_last_pc_58214)) {
        _1 = (object)(DBL_PTR(_last_pc_58214)->dbl);
        DeRefDS(_last_pc_58214);
        _last_pc_58214 = _1;
    }

    /** parser.e:1921			if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _29169 = (_last_op_58211 == 27);
    if (_29169 == 0) {
        _29170 = 0;
        goto L7; // [177] 194
    }
    if (IS_SEQUENCE(_27Code_20660)){
            _29171 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29171 = 1;
    }
    _29172 = (_29171 > _last_pc_58214);
    _29171 = NOVALUE;
    _29170 = (_29172 != 0);
L7: 
    if (_29170 == 0) {
        goto L8; // [194] 253
    }
    _29174 = _last_pc_58214 + 1;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _29175 = (object)*(((s1_ptr)_2)->base + _29174);
    if (IS_ATOM_INT(_29175)) {
        _29176 = (_29175 == _27CurrentSub_20579);
    }
    else {
        _29176 = binary_op(EQUALS, _29175, _27CurrentSub_20579);
    }
    _29175 = NOVALUE;
    if (_29176 == 0) {
        DeRef(_29176);
        _29176 = NOVALUE;
        goto L8; // [215] 253
    }
    else {
        if (!IS_ATOM_INT(_29176) && DBL_PTR(_29176)->dbl == 0.0){
            DeRef(_29176);
            _29176 = NOVALUE;
            goto L8; // [215] 253
        }
        DeRef(_29176);
        _29176 = NOVALUE;
    }
    DeRef(_29176);
    _29176 = NOVALUE;

    /** parser.e:1922				pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_58204 = _45Pop();
    if (!IS_ATOM_INT(_pop_58204)) {
        _1 = (object)(DBL_PTR(_pop_58204)->dbl);
        DeRefDS(_pop_58204);
        _pop_58204 = _1;
    }

    /** parser.e:1923				Code[Last_pc()] = PROC_TAIL*/
    _29178 = _45Last_pc();
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_29178))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29178)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _29178);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 203;
    DeRef(_1);

    /** parser.e:1924				if object(pop_temps()) then end if*/
    _29179 = _45pop_temps();
    if( NOVALUE == _29179 ){
        _29180 = 0;
    }
    else{
        if (IS_ATOM_INT(_29179))
        _29180 = 1;
        else if (IS_ATOM_DBL(_29179)) {
             if (IS_ATOM_INT(DoubleToInt(_29179))) {
                 _29180 = 1;
                 } else {
                     _29180 = 2;
                } } else if (IS_SEQUENCE(_29179))
                _29180 = 3;
                else
                _29180 = 0;
            }
            DeRef(_29179);
            _29179 = NOVALUE;
            if (_29180 == 0)
            {
                _29180 = NOVALUE;
                goto L9; // [246] 300
            }
            else{
                _29180 = NOVALUE;
            }
            goto L9; // [250] 300
L8: 

            /** parser.e:1926				FuncReturn = TRUE*/
            _43FuncReturn_55413 = _9TRUE_441;

            /** parser.e:1927				emit_op(RETURNF)*/
            _45emit_op(28);
            goto L9; // [270] 300
L6: 

            /** parser.e:1930			if is_tail then*/
            if (_is_tail_58217 == 0)
            {
                goto LA; // [275] 292
            }
            else{
            }

            /** parser.e:1931				Code[Last_pc()] = PROC_TAIL*/
            _29181 = _45Last_pc();
            _2 = (object)SEQ_PTR(_27Code_20660);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _27Code_20660 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_29181))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29181)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _29181);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 203;
            DeRef(_1);
LA: 

            /** parser.e:1933			emit_op(RETURNP)*/
            _45emit_op(29);
L9: 

            /** parser.e:1936		tok = next_token()*/
            _0 = _tok_58203;
            _tok_58203 = _43next_token();
            DeRef(_0);

            /** parser.e:1937		putback(tok)*/
            Ref(_tok_58203);
            _43putback(_tok_58203);

            /** parser.e:1938		NotReached(tok[T_ID], "return")*/
            _2 = (object)SEQ_PTR(_tok_58203);
            _29183 = (object)*(((s1_ptr)_2)->base + 1);
            Ref(_29183);
            RefDS(_26548);
            _43NotReached(_29183, _26548);
            _29183 = NOVALUE;

            /** parser.e:1939	end procedure*/
            DeRef(_tok_58203);
            DeRef(_29155);
            _29155 = NOVALUE;
            DeRef(_29181);
            _29181 = NOVALUE;
            DeRef(_29174);
            _29174 = NOVALUE;
            DeRef(_29158);
            _29158 = NOVALUE;
            DeRef(_29169);
            _29169 = NOVALUE;
            DeRef(_29178);
            _29178 = NOVALUE;
            DeRef(_29160);
            _29160 = NOVALUE;
            DeRef(_29172);
            _29172 = NOVALUE;
            return;
    ;
}


object _43exit_level(object _tok_58293, object _flag_58294)
{
    object _arg_58295 = NOVALUE;
    object _n_58296 = NOVALUE;
    object _num_labels_58297 = NOVALUE;
    object _negative_58298 = NOVALUE;
    object _labels_58299 = NOVALUE;
    object _29212 = NOVALUE;
    object _29211 = NOVALUE;
    object _29210 = NOVALUE;
    object _29209 = NOVALUE;
    object _29208 = NOVALUE;
    object _29205 = NOVALUE;
    object _29204 = NOVALUE;
    object _29203 = NOVALUE;
    object _29201 = NOVALUE;
    object _29200 = NOVALUE;
    object _29199 = NOVALUE;
    object _29198 = NOVALUE;
    object _29196 = NOVALUE;
    object _29191 = NOVALUE;
    object _29190 = NOVALUE;
    object _29188 = NOVALUE;
    object _29185 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1946		integer negative = 0*/
    _negative_58298 = 0;

    /** parser.e:1949		if flag then*/
    if (_flag_58294 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** parser.e:1950			labels = if_labels*/
    RefDS(_43if_labels_55434);
    DeRef(_labels_58299);
    _labels_58299 = _43if_labels_55434;
    goto L2; // [22] 35
L1: 

    /** parser.e:1952			labels = loop_labels*/
    RefDS(_43loop_labels_55433);
    DeRef(_labels_58299);
    _labels_58299 = _43loop_labels_55433;
L2: 

    /** parser.e:1954		num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_58299)){
            _num_labels_58297 = SEQ_PTR(_labels_58299)->length;
    }
    else {
        _num_labels_58297 = 1;
    }

    /** parser.e:1956		if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_58293);
    _29185 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29185, 10)){
        _29185 = NOVALUE;
        goto L3; // [52] 67
    }
    _29185 = NOVALUE;

    /** parser.e:1957			tok = next_token()*/
    _0 = _tok_58293;
    _tok_58293 = _43next_token();
    DeRef(_0);

    /** parser.e:1958			negative = 1*/
    _negative_58298 = 1;
L3: 

    /** parser.e:1961		if tok[T_ID]=ATOM then*/
    _2 = (object)SEQ_PTR(_tok_58293);
    _29188 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29188, 502)){
        _29188 = NOVALUE;
        goto L4; // [77] 180
    }
    _29188 = NOVALUE;

    /** parser.e:1962			arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58293);
    _29190 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29190)){
        _29191 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29190)->dbl));
    }
    else{
        _29191 = (object)*(((s1_ptr)_2)->base + _29190);
    }
    DeRef(_arg_58295);
    _2 = (object)SEQ_PTR(_29191);
    _arg_58295 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_58295);
    _29191 = NOVALUE;

    /** parser.e:1963			n = floor(arg)*/
    if (IS_ATOM_INT(_arg_58295))
    _n_58296 = e_floor(_arg_58295);
    else
    _n_58296 = unary_op(FLOOR, _arg_58295);
    if (!IS_ATOM_INT(_n_58296)) {
        _1 = (object)(DBL_PTR(_n_58296)->dbl);
        DeRefDS(_n_58296);
        _n_58296 = _1;
    }

    /** parser.e:1964			if negative then*/
    if (_negative_58298 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** parser.e:1965				n = num_labels - n*/
    _n_58296 = _num_labels_58297 - _n_58296;
    goto L6; // [119] 135
L5: 

    /** parser.e:1966			elsif n = 0 then*/
    if (_n_58296 != 0)
    goto L7; // [124] 134

    /** parser.e:1967				n = num_labels*/
    _n_58296 = _num_labels_58297;
L7: 
L6: 

    /** parser.e:1969			if n<=0 or n>num_labels then*/
    _29196 = (_n_58296 <= 0);
    if (_29196 != 0) {
        goto L8; // [141] 154
    }
    _29198 = (_n_58296 > _num_labels_58297);
    if (_29198 == 0)
    {
        DeRef(_29198);
        _29198 = NOVALUE;
        goto L9; // [150] 164
    }
    else{
        DeRef(_29198);
        _29198 = NOVALUE;
    }
L8: 

    /** parser.e:1970				CompileErr(EXITBREAK_ARGUMENT_OUT_OF_RANGE)*/
    RefDS(_22209);
    _49CompileErr(87, _22209, 0);
L9: 

    /** parser.e:1972			return {n, next_token()}*/
    _29199 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _n_58296;
    ((intptr_t *)_2)[2] = _29199;
    _29200 = MAKE_SEQ(_1);
    _29199 = NOVALUE;
    DeRef(_tok_58293);
    DeRef(_arg_58295);
    DeRef(_labels_58299);
    _29190 = NOVALUE;
    DeRef(_29196);
    _29196 = NOVALUE;
    return _29200;
    goto LA; // [177] 270
L4: 

    /** parser.e:1973		elsif tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58293);
    _29201 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29201, 503)){
        _29201 = NOVALUE;
        goto LB; // [190] 259
    }
    _29201 = NOVALUE;

    /** parser.e:1974			n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (object)SEQ_PTR(_tok_58293);
    _29203 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29203)){
        _29204 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29203)->dbl));
    }
    else{
        _29204 = (object)*(((s1_ptr)_2)->base + _29203);
    }
    _2 = (object)SEQ_PTR(_29204);
    _29205 = (object)*(((s1_ptr)_2)->base + 1);
    _29204 = NOVALUE;
    _n_58296 = find_from(_29205, _labels_58299, 1);
    _29205 = NOVALUE;

    /** parser.e:1975			if n = 0 then*/
    if (_n_58296 != 0)
    goto LC; // [221] 235

    /** parser.e:1976				CompileErr(UNKNOWN_BLOCK_LABEL)*/
    RefDS(_22209);
    _49CompileErr(152, _22209, 0);
LC: 

    /** parser.e:1978			return {num_labels + 1 - n, next_token()}*/
    _29208 = _num_labels_58297 + 1;
    if (_29208 > MAXINT){
        _29208 = NewDouble((eudouble)_29208);
    }
    if (IS_ATOM_INT(_29208)) {
        _29209 = _29208 - _n_58296;
        if ((object)((uintptr_t)_29209 +(uintptr_t) HIGH_BITS) >= 0){
            _29209 = NewDouble((eudouble)_29209);
        }
    }
    else {
        _29209 = NewDouble(DBL_PTR(_29208)->dbl - (eudouble)_n_58296);
    }
    DeRef(_29208);
    _29208 = NOVALUE;
    _29210 = _43next_token();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29209;
    ((intptr_t *)_2)[2] = _29210;
    _29211 = MAKE_SEQ(_1);
    _29210 = NOVALUE;
    _29209 = NOVALUE;
    DeRef(_tok_58293);
    DeRef(_arg_58295);
    DeRef(_labels_58299);
    DeRef(_29200);
    _29200 = NOVALUE;
    _29203 = NOVALUE;
    _29190 = NOVALUE;
    DeRef(_29196);
    _29196 = NOVALUE;
    return _29211;
    goto LA; // [256] 270
LB: 

    /** parser.e:1980			return {1, tok} -- no parameters*/
    Ref(_tok_58293);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1;
    ((intptr_t *)_2)[2] = _tok_58293;
    _29212 = MAKE_SEQ(_1);
    DeRef(_tok_58293);
    DeRef(_arg_58295);
    DeRef(_labels_58299);
    DeRef(_29200);
    _29200 = NOVALUE;
    _29203 = NOVALUE;
    _29190 = NOVALUE;
    DeRef(_29196);
    _29196 = NOVALUE;
    DeRef(_29211);
    _29211 = NOVALUE;
    return _29212;
LA: 
    ;
}


void _43GLabel_statement()
{
    object _tok_58358 = NOVALUE;
    object _labbel_58359 = NOVALUE;
    object _laddr_58360 = NOVALUE;
    object _n_58361 = NOVALUE;
    object _29231 = NOVALUE;
    object _29229 = NOVALUE;
    object _29228 = NOVALUE;
    object _29227 = NOVALUE;
    object _29226 = NOVALUE;
    object _29224 = NOVALUE;
    object _29221 = NOVALUE;
    object _29219 = NOVALUE;
    object _29217 = NOVALUE;
    object _29216 = NOVALUE;
    object _29214 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:1986		object labbel*/

    /** parser.e:1987		object laddr*/

    /** parser.e:1988		integer n*/

    /** parser.e:1990		tok = next_token()*/
    _0 = _tok_58358;
    _tok_58358 = _43next_token();
    DeRef(_0);

    /** parser.e:1992		if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58358);
    _29214 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29214, 503)){
        _29214 = NOVALUE;
        goto L1; // [22] 36
    }
    _29214 = NOVALUE;

    /** parser.e:1993			CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_CONSTANT_STRING)*/
    RefDS(_22209);
    _49CompileErr(35, _22209, 0);
L1: 

    /** parser.e:1996		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58358);
    _29216 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29216)){
        _29217 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29216)->dbl));
    }
    else{
        _29217 = (object)*(((s1_ptr)_2)->base + _29216);
    }
    DeRef(_labbel_58359);
    _2 = (object)SEQ_PTR(_29217);
    _labbel_58359 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_58359);
    _29217 = NOVALUE;

    /** parser.e:1997		laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29219 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29219 = 1;
    }
    _laddr_58360 = _29219 + 1;
    _29219 = NOVALUE;

    /** parser.e:1999		if find(labbel, goto_labels) then*/
    _29221 = find_from(_labbel_58359, _43goto_labels_55416, 1);
    if (_29221 == 0)
    {
        _29221 = NOVALUE;
        goto L2; // [76] 89
    }
    else{
        _29221 = NOVALUE;
    }

    /** parser.e:2000			CompileErr(DUPLICATE_LABEL_NAME)*/
    RefDS(_22209);
    _49CompileErr(59, _22209, 0);
L2: 

    /** parser.e:2003		goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_58359);
    Append(&_43goto_labels_55416, _43goto_labels_55416, _labbel_58359);

    /** parser.e:2004		goto_addr = append(goto_addr, laddr)*/
    Append(&_43goto_addr_55417, _43goto_addr_55417, _laddr_58360);

    /** parser.e:2005		label_block = append( label_block, top_block() )*/
    _29224 = _64top_block(0);
    Ref(_29224);
    Append(&_43label_block_55420, _43label_block_55420, _29224);
    DeRef(_29224);
    _29224 = NOVALUE;

    /** parser.e:2007		while n with entry do*/
    goto L3; // [119] 178
L4: 
    if (_n_58361 == 0)
    {
        goto L5; // [124] 192
    }
    else{
    }

    /** parser.e:2008			backpatch(goto_list[n], laddr)*/
    _2 = (object)SEQ_PTR(_27goto_list_20683);
    _29226 = (object)*(((s1_ptr)_2)->base + _n_58361);
    Ref(_29226);
    _45backpatch(_29226, _laddr_58360);
    _29226 = NOVALUE;

    /** parser.e:2009			set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (object)SEQ_PTR(_43goto_ref_55419);
    _29227 = (object)*(((s1_ptr)_2)->base + _n_58361);
    _29228 = _64top_block(0);
    Ref(_29227);
    _42set_glabel_block(_29227, _29228);
    _29227 = NOVALUE;
    _29228 = NOVALUE;

    /** parser.e:2010			goto_delay[n] = "" --clear it*/
    RefDS(_22209);
    _2 = (object)SEQ_PTR(_27goto_delay_20682);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27goto_delay_20682 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_58361);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);

    /** parser.e:2011			goto_line[n] = {-1,""} --clear it*/
    RefDS(_22209);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _22209;
    _29229 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_43goto_line_55415);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43goto_line_55415 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_58361);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29229;
    if( _1 != _29229 ){
        DeRef(_1);
    }
    _29229 = NOVALUE;

    /** parser.e:2013		entry*/
L3: 

    /** parser.e:2014			n = find(labbel, goto_delay)*/
    _n_58361 = find_from(_labbel_58359, _27goto_delay_20682, 1);

    /** parser.e:2015		end while*/
    goto L4; // [189] 122
L5: 

    /** parser.e:2017		force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_43goto_init_55422);
    Ref(_labbel_58359);
    RefDS(_22209);
    _29231 = _34get(_43goto_init_55422, _labbel_58359, _22209);
    _43force_uninitialize(_29231);
    _29231 = NOVALUE;

    /** parser.e:2019		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [209] 225
    }
    else{
    }

    /** parser.e:2020			emit_op(GLABEL)*/
    _45emit_op(189);

    /** parser.e:2021			emit_addr(laddr)*/
    _45emit_addr(_laddr_58360);
L6: 

    /** parser.e:2023	end procedure*/
    DeRef(_tok_58358);
    DeRef(_labbel_58359);
    _29216 = NOVALUE;
    return;
    ;
}


void _43Goto_statement()
{
    object _tok_58410 = NOVALUE;
    object _n_58411 = NOVALUE;
    object _num_labels_58412 = NOVALUE;
    object _31980 = NOVALUE;
    object _29270 = NOVALUE;
    object _29269 = NOVALUE;
    object _29266 = NOVALUE;
    object _29265 = NOVALUE;
    object _29264 = NOVALUE;
    object _29263 = NOVALUE;
    object _29262 = NOVALUE;
    object _29261 = NOVALUE;
    object _29260 = NOVALUE;
    object _29259 = NOVALUE;
    object _29258 = NOVALUE;
    object _29257 = NOVALUE;
    object _29256 = NOVALUE;
    object _29255 = NOVALUE;
    object _29253 = NOVALUE;
    object _29252 = NOVALUE;
    object _29250 = NOVALUE;
    object _29249 = NOVALUE;
    object _29247 = NOVALUE;
    object _29246 = NOVALUE;
    object _29244 = NOVALUE;
    object _29243 = NOVALUE;
    object _29242 = NOVALUE;
    object _29241 = NOVALUE;
    object _29238 = NOVALUE;
    object _29237 = NOVALUE;
    object _29236 = NOVALUE;
    object _29234 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2028		integer n*/

    /** parser.e:2029		integer num_labels*/

    /** parser.e:2031		tok = next_token()*/
    _0 = _tok_58410;
    _tok_58410 = _43next_token();
    DeRef(_0);

    /** parser.e:2032		num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_43goto_labels_55416)){
            _num_labels_58412 = SEQ_PTR(_43goto_labels_55416)->length;
    }
    else {
        _num_labels_58412 = 1;
    }

    /** parser.e:2034		if tok[T_ID]=STRING then*/
    _2 = (object)SEQ_PTR(_tok_58410);
    _29234 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29234, 503)){
        _29234 = NOVALUE;
        goto L1; // [27] 267
    }
    _29234 = NOVALUE;

    /** parser.e:2035			n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (object)SEQ_PTR(_tok_58410);
    _29236 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29236)){
        _29237 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29236)->dbl));
    }
    else{
        _29237 = (object)*(((s1_ptr)_2)->base + _29236);
    }
    _2 = (object)SEQ_PTR(_29237);
    _29238 = (object)*(((s1_ptr)_2)->base + 1);
    _29237 = NOVALUE;
    _n_58411 = find_from(_29238, _43goto_labels_55416, 1);
    _29238 = NOVALUE;

    /** parser.e:2036			if n = 0 then*/
    if (_n_58411 != 0)
    goto L2; // [60] 241

    /** parser.e:2037				goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (object)SEQ_PTR(_tok_58410);
    _29241 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29241)){
        _29242 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29241)->dbl));
    }
    else{
        _29242 = (object)*(((s1_ptr)_2)->base + _29241);
    }
    _2 = (object)SEQ_PTR(_29242);
    _29243 = (object)*(((s1_ptr)_2)->base + 1);
    _29242 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_29243);
    ((intptr_t*)_2)[1] = _29243;
    _29244 = MAKE_SEQ(_1);
    _29243 = NOVALUE;
    Concat((object_ptr)&_27goto_delay_20682, _27goto_delay_20682, _29244);
    DeRefDS(_29244);
    _29244 = NOVALUE;

    /** parser.e:2038				goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29246 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29246 = 1;
    }
    _29247 = _29246 + 2;
    _29246 = NOVALUE;
    Append(&_27goto_list_20683, _27goto_list_20683, _29247);
    _29247 = NOVALUE;

    /** parser.e:2039				goto_line &= {{line_number,ThisLine}}*/
    Ref(_49ThisLine_49642);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27line_number_20572;
    ((intptr_t *)_2)[2] = _49ThisLine_49642;
    _29249 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29249;
    _29250 = MAKE_SEQ(_1);
    _29249 = NOVALUE;
    Concat((object_ptr)&_43goto_line_55415, _43goto_line_55415, _29250);
    DeRefDS(_29250);
    _29250 = NOVALUE;

    /** parser.e:2040				goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _29252 = _64top_block(0);
    _31980 = 188;
    _29253 = _42new_forward_reference(188, _29252, 188);
    _29252 = NOVALUE;
    _31980 = NOVALUE;
    if (IS_SEQUENCE(_43goto_ref_55419) && IS_ATOM(_29253)) {
        Ref(_29253);
        Append(&_43goto_ref_55419, _43goto_ref_55419, _29253);
    }
    else if (IS_ATOM(_43goto_ref_55419) && IS_SEQUENCE(_29253)) {
    }
    else {
        Concat((object_ptr)&_43goto_ref_55419, _43goto_ref_55419, _29253);
    }
    DeRef(_29253);
    _29253 = NOVALUE;

    /** parser.e:2041				map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (object)SEQ_PTR(_tok_58410);
    _29255 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29255)){
        _29256 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29255)->dbl));
    }
    else{
        _29256 = (object)*(((s1_ptr)_2)->base + _29255);
    }
    _2 = (object)SEQ_PTR(_29256);
    _29257 = (object)*(((s1_ptr)_2)->base + 1);
    _29256 = NOVALUE;
    _29258 = _43get_private_uninitialized();
    Ref(_43goto_init_55422);
    Ref(_29257);
    _34put(_43goto_init_55422, _29257, _29258, 1, 0);
    _29257 = NOVALUE;
    _29258 = NOVALUE;

    /** parser.e:2042				add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_43goto_ref_55419)){
            _29259 = SEQ_PTR(_43goto_ref_55419)->length;
    }
    else {
        _29259 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_55419);
    _29260 = (object)*(((s1_ptr)_2)->base + _29259);
    _2 = (object)SEQ_PTR(_tok_58410);
    _29261 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_29261);
    _29262 = _53sym_obj(_29261);
    _29261 = NOVALUE;
    Ref(_29260);
    _42add_data(_29260, _29262);
    _29260 = NOVALUE;
    _29262 = NOVALUE;

    /** parser.e:2043				set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_43goto_ref_55419)){
            _29263 = SEQ_PTR(_43goto_ref_55419)->length;
    }
    else {
        _29263 = 1;
    }
    _2 = (object)SEQ_PTR(_43goto_ref_55419);
    _29264 = (object)*(((s1_ptr)_2)->base + _29263);
    Ref(_29264);
    Ref(_49ThisLine_49642);
    _42set_line(_29264, _27line_number_20572, _49ThisLine_49642, _49bp_49646);
    _29264 = NOVALUE;
    goto L3; // [238] 259
L2: 

    /** parser.e:2045				Goto_block( top_block(), label_block[n] )*/
    _29265 = _64top_block(0);
    _2 = (object)SEQ_PTR(_43label_block_55420);
    _29266 = (object)*(((s1_ptr)_2)->base + _n_58411);
    Ref(_29266);
    _64Goto_block(_29265, _29266, 0);
    _29265 = NOVALUE;
    _29266 = NOVALUE;
L3: 

    /** parser.e:2047			tok = next_token()*/
    _0 = _tok_58410;
    _tok_58410 = _43next_token();
    DeRef(_0);
    goto L4; // [264] 277
L1: 

    /** parser.e:2049			CompileErr(GOTO_STATEMENT_WITHOUT_A_STRING_LABEL)*/
    RefDS(_22209);
    _49CompileErr(96, _22209, 0);
L4: 

    /** parser.e:2052		emit_op(GOTO)*/
    _45emit_op(188);

    /** parser.e:2053		if n = 0 then*/
    if (_n_58411 != 0)
    goto L5; // [288] 300

    /** parser.e:2054			emit_addr(0) -- to be back-patched*/
    _45emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** parser.e:2056			emit_addr(goto_addr[n])*/
    _2 = (object)SEQ_PTR(_43goto_addr_55417);
    _29269 = (object)*(((s1_ptr)_2)->base + _n_58411);
    Ref(_29269);
    _45emit_addr(_29269);
    _29269 = NOVALUE;
L6: 

    /** parser.e:2059		putback(tok)*/
    Ref(_tok_58410);
    _43putback(_tok_58410);

    /** parser.e:2060		NotReached(tok[T_ID], "goto")*/
    _2 = (object)SEQ_PTR(_tok_58410);
    _29270 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29270);
    RefDS(_26490);
    _43NotReached(_29270, _26490);
    _29270 = NOVALUE;

    /** parser.e:2061	end procedure*/
    DeRef(_tok_58410);
    _29241 = NOVALUE;
    _29236 = NOVALUE;
    _29255 = NOVALUE;
    return;
    ;
}


void _43Exit_statement()
{
    object _addr_inlined_AppendXList_at_65_58515 = NOVALUE;
    object _tok_58497 = NOVALUE;
    object _by_ref_58498 = NOVALUE;
    object _29278 = NOVALUE;
    object _29277 = NOVALUE;
    object _29276 = NOVALUE;
    object _29275 = NOVALUE;
    object _29273 = NOVALUE;
    object _29271 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2066		sequence by_ref*/

    /** parser.e:2068		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _29271 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _29271 = 1;
    }
    if (_29271 != 0)
    goto L1; // [10] 23
    _29271 = NOVALUE;

    /** parser.e:2069			CompileErr(EXIT_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(88, _22209, 0);
L1: 

    /** parser.e:2072		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29273 = _43next_token();
    _0 = _by_ref_58498;
    _by_ref_58498 = _43exit_level(_29273, 0);
    DeRef(_0);
    _29273 = NOVALUE;

    /** parser.e:2073		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58498);
    _29275 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29275);
    _64Leave_blocks(_29275, 1);
    _29275 = NOVALUE;

    /** parser.e:2074		emit_op(EXIT)*/
    _45emit_op(61);

    /** parser.e:2075		AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29276 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29276 = 1;
    }
    _29277 = _29276 + 1;
    _29276 = NOVALUE;
    _addr_inlined_AppendXList_at_65_58515 = _29277;
    _29277 = NOVALUE;

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_55425, _43exit_list_55425, _addr_inlined_AppendXList_at_65_58515);

    /** parser.e:399	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2076		exit_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58498);
    _29278 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_43exit_delay_55426) && IS_ATOM(_29278)) {
        Ref(_29278);
        Append(&_43exit_delay_55426, _43exit_delay_55426, _29278);
    }
    else if (IS_ATOM(_43exit_delay_55426) && IS_SEQUENCE(_29278)) {
    }
    else {
        Concat((object_ptr)&_43exit_delay_55426, _43exit_delay_55426, _29278);
    }
    _29278 = NOVALUE;

    /** parser.e:2077		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2078		tok = by_ref[2]*/
    DeRef(_tok_58497);
    _2 = (object)SEQ_PTR(_by_ref_58498);
    _tok_58497 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58497);

    /** parser.e:2079		putback(tok)*/
    Ref(_tok_58497);
    _43putback(_tok_58497);

    /** parser.e:2080	end procedure*/
    DeRef(_tok_58497);
    DeRefDS(_by_ref_58498);
    return;
    ;
}


void _43Continue_statement()
{
    object _addr_inlined_AppendNList_at_153_58561 = NOVALUE;
    object _tok_58522 = NOVALUE;
    object _by_ref_58523 = NOVALUE;
    object _loop_level_58524 = NOVALUE;
    object _29304 = NOVALUE;
    object _29301 = NOVALUE;
    object _29300 = NOVALUE;
    object _29299 = NOVALUE;
    object _29298 = NOVALUE;
    object _29297 = NOVALUE;
    object _29296 = NOVALUE;
    object _29294 = NOVALUE;
    object _29293 = NOVALUE;
    object _29292 = NOVALUE;
    object _29291 = NOVALUE;
    object _29290 = NOVALUE;
    object _29289 = NOVALUE;
    object _29288 = NOVALUE;
    object _29287 = NOVALUE;
    object _29285 = NOVALUE;
    object _29283 = NOVALUE;
    object _29281 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2085		sequence by_ref*/

    /** parser.e:2086		integer loop_level*/

    /** parser.e:2088		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _29281 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _29281 = 1;
    }
    if (_29281 != 0)
    goto L1; // [12] 25
    _29281 = NOVALUE;

    /** parser.e:2089			CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(49, _22209, 0);
L1: 

    /** parser.e:2092		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29283 = _43next_token();
    _0 = _by_ref_58523;
    _by_ref_58523 = _43exit_level(_29283, 0);
    DeRef(_0);
    _29283 = NOVALUE;

    /** parser.e:2093		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58523);
    _29285 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29285);
    _64Leave_blocks(_29285, 1);
    _29285 = NOVALUE;

    /** parser.e:2094		emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2095		loop_level = by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58523);
    _loop_level_58524 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_58524))
    _loop_level_58524 = (object)DBL_PTR(_loop_level_58524)->dbl;

    /** parser.e:2098		if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_43continue_addr_55430)){
            _29287 = SEQ_PTR(_43continue_addr_55430)->length;
    }
    else {
        _29287 = 1;
    }
    _29288 = _29287 + 1;
    _29287 = NOVALUE;
    _29289 = _29288 - _loop_level_58524;
    _29288 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55430);
    _29290 = (object)*(((s1_ptr)_2)->base + _29289);
    if (_29290 == 0)
    {
        _29290 = NOVALUE;
        goto L2; // [81] 142
    }
    else{
        _29290 = NOVALUE;
    }

    /** parser.e:2099			if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_43continue_addr_55430)){
            _29291 = SEQ_PTR(_43continue_addr_55430)->length;
    }
    else {
        _29291 = 1;
    }
    _29292 = _29291 + 1;
    _29291 = NOVALUE;
    _29293 = _29292 - _loop_level_58524;
    _29292 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55430);
    _29294 = (object)*(((s1_ptr)_2)->base + _29293);
    if (_29294 >= 0)
    goto L3; // [103] 117

    /** parser.e:2101				CompileErr(CONTINUE_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(49, _22209, 0);
L3: 

    /** parser.e:2103			emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_43continue_addr_55430)){
            _29296 = SEQ_PTR(_43continue_addr_55430)->length;
    }
    else {
        _29296 = 1;
    }
    _29297 = _29296 + 1;
    _29296 = NOVALUE;
    _29298 = _29297 - _loop_level_58524;
    _29297 = NOVALUE;
    _2 = (object)SEQ_PTR(_43continue_addr_55430);
    _29299 = (object)*(((s1_ptr)_2)->base + _29298);
    _45emit_addr(_29299);
    _29299 = NOVALUE;
    goto L4; // [139] 186
L2: 

    /** parser.e:2105			AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29300 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29300 = 1;
    }
    _29301 = _29300 + 1;
    _29300 = NOVALUE;
    _addr_inlined_AppendNList_at_153_58561 = _29301;
    _29301 = NOVALUE;

    /** parser.e:403		continue_list = append(continue_list, addr)*/
    Append(&_43continue_list_55427, _43continue_list_55427, _addr_inlined_AppendNList_at_153_58561);

    /** parser.e:404	end procedure*/
    goto L5; // [168] 171
L5: 

    /** parser.e:2106			continue_delay &= loop_level*/
    Append(&_43continue_delay_55428, _43continue_delay_55428, _loop_level_58524);

    /** parser.e:2107			emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();
L4: 

    /** parser.e:2110		tok = by_ref[2]*/
    DeRef(_tok_58522);
    _2 = (object)SEQ_PTR(_by_ref_58523);
    _tok_58522 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58522);

    /** parser.e:2111		putback(tok)*/
    Ref(_tok_58522);
    _43putback(_tok_58522);

    /** parser.e:2113		NotReached(tok[T_ID], "continue")*/
    _2 = (object)SEQ_PTR(_tok_58522);
    _29304 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29304);
    RefDS(_26452);
    _43NotReached(_29304, _26452);
    _29304 = NOVALUE;

    /** parser.e:2114	end procedure*/
    DeRef(_tok_58522);
    DeRefDS(_by_ref_58523);
    DeRef(_29289);
    _29289 = NOVALUE;
    _29294 = NOVALUE;
    DeRef(_29293);
    _29293 = NOVALUE;
    DeRef(_29298);
    _29298 = NOVALUE;
    return;
    ;
}


void _43Retry_statement()
{
    object _by_ref_58568 = NOVALUE;
    object _tok_58570 = NOVALUE;
    object _29328 = NOVALUE;
    object _29326 = NOVALUE;
    object _29325 = NOVALUE;
    object _29324 = NOVALUE;
    object _29323 = NOVALUE;
    object _29322 = NOVALUE;
    object _29320 = NOVALUE;
    object _29319 = NOVALUE;
    object _29318 = NOVALUE;
    object _29317 = NOVALUE;
    object _29316 = NOVALUE;
    object _29314 = NOVALUE;
    object _29313 = NOVALUE;
    object _29312 = NOVALUE;
    object _29311 = NOVALUE;
    object _29310 = NOVALUE;
    object _29309 = NOVALUE;
    object _29307 = NOVALUE;
    object _29305 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2122		if not length(loop_stack) then*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _29305 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _29305 = 1;
    }
    if (_29305 != 0)
    goto L1; // [8] 21
    _29305 = NOVALUE;

    /** parser.e:2123			CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(131, _22209, 0);
L1: 

    /** parser.e:2126		by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _29307 = _43next_token();
    _0 = _by_ref_58568;
    _by_ref_58568 = _43exit_level(_29307, 0);
    DeRef(_0);
    _29307 = NOVALUE;

    /** parser.e:2127		Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58568);
    _29309 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29309);
    _64Leave_blocks(_29309, 1);
    _29309 = NOVALUE;

    /** parser.e:2128		if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _29310 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _29310 = 1;
    }
    _29311 = _29310 + 1;
    _29310 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58568);
    _29312 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29312)) {
        _29313 = _29311 - _29312;
    }
    else {
        _29313 = binary_op(MINUS, _29311, _29312);
    }
    _29311 = NOVALUE;
    _29312 = NOVALUE;
    _2 = (object)SEQ_PTR(_43loop_stack_55439);
    if (!IS_ATOM_INT(_29313)){
        _29314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29313)->dbl));
    }
    else{
        _29314 = (object)*(((s1_ptr)_2)->base + _29313);
    }
    if (_29314 != 21)
    goto L2; // [70] 84

    /** parser.e:2129			emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _45emit_op(184);
    goto L3; // [81] 129
L2: 

    /** parser.e:2131			if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_43retry_addr_55431)){
            _29316 = SEQ_PTR(_43retry_addr_55431)->length;
    }
    else {
        _29316 = 1;
    }
    _29317 = _29316 + 1;
    _29316 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58568);
    _29318 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29318)) {
        _29319 = _29317 - _29318;
    }
    else {
        _29319 = binary_op(MINUS, _29317, _29318);
    }
    _29317 = NOVALUE;
    _29318 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_55431);
    if (!IS_ATOM_INT(_29319)){
        _29320 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29319)->dbl));
    }
    else{
        _29320 = (object)*(((s1_ptr)_2)->base + _29319);
    }
    if (_29320 >= 0)
    goto L4; // [107] 121

    /** parser.e:2133				CompileErr(RETRY_STATEMENT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(131, _22209, 0);
L4: 

    /** parser.e:2135			emit_op(ELSE)*/
    _45emit_op(23);
L3: 

    /** parser.e:2138		emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_43retry_addr_55431)){
            _29322 = SEQ_PTR(_43retry_addr_55431)->length;
    }
    else {
        _29322 = 1;
    }
    _29323 = _29322 + 1;
    _29322 = NOVALUE;
    _2 = (object)SEQ_PTR(_by_ref_58568);
    _29324 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29324)) {
        _29325 = _29323 - _29324;
    }
    else {
        _29325 = binary_op(MINUS, _29323, _29324);
    }
    _29323 = NOVALUE;
    _29324 = NOVALUE;
    _2 = (object)SEQ_PTR(_43retry_addr_55431);
    if (!IS_ATOM_INT(_29325)){
        _29326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29325)->dbl));
    }
    else{
        _29326 = (object)*(((s1_ptr)_2)->base + _29325);
    }
    _45emit_addr(_29326);
    _29326 = NOVALUE;

    /** parser.e:2139		tok = by_ref[2]*/
    DeRef(_tok_58570);
    _2 = (object)SEQ_PTR(_by_ref_58568);
    _tok_58570 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58570);

    /** parser.e:2140		putback(tok)*/
    Ref(_tok_58570);
    _43putback(_tok_58570);

    /** parser.e:2141		NotReached(tok[T_ID], "retry")*/
    _2 = (object)SEQ_PTR(_tok_58570);
    _29328 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29328);
    RefDS(_26546);
    _43NotReached(_29328, _26546);
    _29328 = NOVALUE;

    /** parser.e:2142	end procedure*/
    DeRefDS(_by_ref_58568);
    DeRef(_tok_58570);
    DeRef(_29313);
    _29313 = NOVALUE;
    DeRef(_29319);
    _29319 = NOVALUE;
    DeRef(_29325);
    _29325 = NOVALUE;
    _29320 = NOVALUE;
    _29314 = NOVALUE;
    return;
    ;
}


object _43in_switch()
{
    object _29333 = NOVALUE;
    object _29332 = NOVALUE;
    object _29331 = NOVALUE;
    object _29330 = NOVALUE;
    object _29329 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2145		if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _29329 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _29329 = 1;
    }
    if (_29329 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_43if_stack_55440)){
            _29331 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _29331 = 1;
    }
    _2 = (object)SEQ_PTR(_43if_stack_55440);
    _29332 = (object)*(((s1_ptr)_2)->base + _29331);
    _29333 = (_29332 == 185);
    _29332 = NOVALUE;
    if (_29333 == 0)
    {
        DeRef(_29333);
        _29333 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_29333);
        _29333 = NOVALUE;
    }

    /** parser.e:2146			return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** parser.e:2148			return 0*/
    return 0;
L2: 
    ;
}


void _43Break_statement()
{
    object _addr_inlined_AppendEList_at_65_58643 = NOVALUE;
    object _tok_58625 = NOVALUE;
    object _by_ref_58626 = NOVALUE;
    object _29344 = NOVALUE;
    object _29341 = NOVALUE;
    object _29340 = NOVALUE;
    object _29339 = NOVALUE;
    object _29338 = NOVALUE;
    object _29336 = NOVALUE;
    object _29334 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2154		sequence by_ref*/

    /** parser.e:2156		if not length(if_labels) then*/
    if (IS_SEQUENCE(_43if_labels_55434)){
            _29334 = SEQ_PTR(_43if_labels_55434)->length;
    }
    else {
        _29334 = 1;
    }
    if (_29334 != 0)
    goto L1; // [10] 23
    _29334 = NOVALUE;

    /** parser.e:2157			CompileErr(BREAK_STATEMENT_MUST_BE_INSIDE_A_IF_OR_A_SWITCH_BLOCK)*/
    RefDS(_22209);
    _49CompileErr(40, _22209, 0);
L1: 

    /** parser.e:2160		by_ref = exit_level(next_token(),1)*/
    _29336 = _43next_token();
    _0 = _by_ref_58626;
    _by_ref_58626 = _43exit_level(_29336, 1);
    DeRef(_0);
    _29336 = NOVALUE;

    /** parser.e:2161		Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (object)SEQ_PTR(_by_ref_58626);
    _29338 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29338);
    _64Leave_blocks(_29338, 2);
    _29338 = NOVALUE;

    /** parser.e:2162		emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2163		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29339 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29339 = 1;
    }
    _29340 = _29339 + 1;
    _29339 = NOVALUE;
    _addr_inlined_AppendEList_at_65_58643 = _29340;
    _29340 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55423, _43break_list_55423, _addr_inlined_AppendEList_at_65_58643);

    /** parser.e:394	end procedure*/
    goto L2; // [80] 83
L2: 

    /** parser.e:2165		break_delay &= by_ref[1]*/
    _2 = (object)SEQ_PTR(_by_ref_58626);
    _29341 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_43break_delay_55424) && IS_ATOM(_29341)) {
        Ref(_29341);
        Append(&_43break_delay_55424, _43break_delay_55424, _29341);
    }
    else if (IS_ATOM(_43break_delay_55424) && IS_SEQUENCE(_29341)) {
    }
    else {
        Concat((object_ptr)&_43break_delay_55424, _43break_delay_55424, _29341);
    }
    _29341 = NOVALUE;

    /** parser.e:2166		emit_forward_addr()    -- to be back-patched*/
    _43emit_forward_addr();

    /** parser.e:2167		tok = by_ref[2]*/
    DeRef(_tok_58625);
    _2 = (object)SEQ_PTR(_by_ref_58626);
    _tok_58625 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_58625);

    /** parser.e:2168		putback(tok)*/
    Ref(_tok_58625);
    _43putback(_tok_58625);

    /** parser.e:2169		NotReached(tok[T_ID], "break")*/
    _2 = (object)SEQ_PTR(_tok_58625);
    _29344 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29344);
    RefDS(_26436);
    _43NotReached(_29344, _26436);
    _29344 = NOVALUE;

    /** parser.e:2170	end procedure*/
    DeRef(_tok_58625);
    DeRefDS(_by_ref_58626);
    return;
    ;
}


object _43finish_block_header(object _opcode_58652)
{
    object _tok_58654 = NOVALUE;
    object _labbel_58655 = NOVALUE;
    object _has_entry_58656 = NOVALUE;
    object _29398 = NOVALUE;
    object _29397 = NOVALUE;
    object _29396 = NOVALUE;
    object _29395 = NOVALUE;
    object _29392 = NOVALUE;
    object _29387 = NOVALUE;
    object _29384 = NOVALUE;
    object _29382 = NOVALUE;
    object _29379 = NOVALUE;
    object _29378 = NOVALUE;
    object _29376 = NOVALUE;
    object _29373 = NOVALUE;
    object _29370 = NOVALUE;
    object _29369 = NOVALUE;
    object _29367 = NOVALUE;
    object _29365 = NOVALUE;
    object _29362 = NOVALUE;
    object _29359 = NOVALUE;
    object _29358 = NOVALUE;
    object _29356 = NOVALUE;
    object _29354 = NOVALUE;
    object _29353 = NOVALUE;
    object _29352 = NOVALUE;
    object _29349 = NOVALUE;
    object _29346 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2176		object labbel*/

    /** parser.e:2177		integer has_entry*/

    /** parser.e:2179		tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);

    /** parser.e:2180		has_entry=0*/
    _has_entry_58656 = 0;

    /** parser.e:2182		if tok[T_ID] = WITH then*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29346 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29346, 420)){
        _29346 = NOVALUE;
        goto L1; // [27] 160
    }
    _29346 = NOVALUE;

    /** parser.e:2183			tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);

    /** parser.e:2184			switch tok[T_ID] do*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29349 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29349) ){
        goto L2; // [44] 140
    }
    if(!IS_ATOM_INT(_29349)){
        if( (DBL_PTR(_29349)->dbl != (eudouble) ((object) DBL_PTR(_29349)->dbl) ) ){
            goto L2; // [44] 140
        }
        _0 = (object) DBL_PTR(_29349)->dbl;
    }
    else {
        _0 = _29349;
    };
    _29349 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:2185			    case ENTRY then*/
        case 424:

        /** parser.e:2186					if not (opcode = WHILE or opcode = LOOP) then*/
        _29352 = (_opcode_58652 == 47);
        if (_29352 != 0) {
            DeRef(_29353);
            _29353 = 1;
            goto L3; // [61] 75
        }
        _29354 = (_opcode_58652 == 422);
        _29353 = (_29354 != 0);
L3: 
        if (_29353 != 0)
        goto L4; // [75] 88
        _29353 = NOVALUE;

        /** parser.e:2187						CompileErr(MSG_WITH_ENTRY_IS_ONLY_VALID_ON_A_WHILE_OR_LOOP_STATEMENT)*/
        RefDS(_22209);
        _49CompileErr(14, _22209, 0);
L4: 

        /** parser.e:2190				    has_entry = 1*/
        _has_entry_58656 = 1;
        goto L5; // [93] 152

        /** parser.e:2192				case FALLTHRU then*/
        case 431:

        /** parser.e:2193					if not opcode = SWITCH then*/
        _29356 = (_opcode_58652 == 0);
        if (_29356 != 185)
        goto L6; // [106] 120

        /** parser.e:2194						CompileErr(MSG_WITH_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
        RefDS(_22209);
        _49CompileErr(13, _22209, 0);
L6: 

        /** parser.e:2197					switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_43switch_stack_55654)){
                _29358 = SEQ_PTR(_43switch_stack_55654)->length;
        }
        else {
            _29358 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55654);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _43switch_stack_55654 = MAKE_SEQ(_2);
        }
        _3 = (object)(_29358 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 1;
        DeRef(_1);
        _29359 = NOVALUE;
        goto L5; // [136] 152

        /** parser.e:2199				case else*/
        default:
L2: 

        /** parser.e:2200				    CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
        RefDS(_22209);
        _49CompileErr(27, _22209, 0);
    ;}L5: 

    /** parser.e:2203	        tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);
    goto L7; // [157] 250
L1: 

    /** parser.e:2204		elsif tok[T_ID] = WITHOUT then*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29362 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29362, 421)){
        _29362 = NOVALUE;
        goto L8; // [170] 249
    }
    _29362 = NOVALUE;

    /** parser.e:2205			tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);

    /** parser.e:2206			if tok[T_ID] = FALLTHRU then*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29365 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29365, 431)){
        _29365 = NOVALUE;
        goto L9; // [189] 233
    }
    _29365 = NOVALUE;

    /** parser.e:2207				if not opcode = SWITCH then*/
    _29367 = (_opcode_58652 == 0);
    if (_29367 != 185)
    goto LA; // [200] 214

    /** parser.e:2208					CompileErr(MSG_WITHOUT_FALLTHRU_IS_ONLY_VALID_IN_A_SWITCH_STATEMENT)*/
    RefDS(_22209);
    _49CompileErr(15, _22209, 0);
LA: 

    /** parser.e:2211				switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29369 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29369 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29369 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29370 = NOVALUE;
    goto LB; // [230] 243
L9: 

    /** parser.e:2214				CompileErr(AN_UNKNOWN_WITHWITHOUT_OPTION_HAS_BEEN_SPECIFIED)*/
    RefDS(_22209);
    _49CompileErr(27, _22209, 0);
LB: 

    /** parser.e:2216	        tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2219		labbel=0*/
    DeRef(_labbel_58655);
    _labbel_58655 = 0;

    /** parser.e:2220		if tok[T_ID]=LABEL then*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29373 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29373, 419)){
        _29373 = NOVALUE;
        goto LC; // [265] 329
    }
    _29373 = NOVALUE;

    /** parser.e:2221			tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);

    /** parser.e:2222			if tok[T_ID] != STRING then*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29376 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29376, 503)){
        _29376 = NOVALUE;
        goto LD; // [284] 298
    }
    _29376 = NOVALUE;

    /** parser.e:2223				CompileErr(A_LABEL_CLAUSE_MUST_BE_FOLLOWED_BY_A_LITERAL_STRING)*/
    RefDS(_22209);
    _49CompileErr(38, _22209, 0);
LD: 

    /** parser.e:2225			labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29378 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_29378)){
        _29379 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29378)->dbl));
    }
    else{
        _29379 = (object)*(((s1_ptr)_2)->base + _29378);
    }
    DeRef(_labbel_58655);
    _2 = (object)SEQ_PTR(_29379);
    _labbel_58655 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_58655);
    _29379 = NOVALUE;

    /** parser.e:2226			block_label( labbel )*/
    Ref(_labbel_58655);
    _64block_label(_labbel_58655);

    /** parser.e:2227			tok = next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);
LC: 

    /** parser.e:2229		if opcode = IF or opcode = SWITCH then*/
    _29382 = (_opcode_58652 == 20);
    if (_29382 != 0) {
        goto LE; // [337] 352
    }
    _29384 = (_opcode_58652 == 185);
    if (_29384 == 0)
    {
        DeRef(_29384);
        _29384 = NOVALUE;
        goto LF; // [348] 363
    }
    else{
        DeRef(_29384);
        _29384 = NOVALUE;
    }
LE: 

    /** parser.e:2230			if_labels = append(if_labels,labbel)*/
    Ref(_labbel_58655);
    Append(&_43if_labels_55434, _43if_labels_55434, _labbel_58655);
    goto L10; // [360] 372
LF: 

    /** parser.e:2232			loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_58655);
    Append(&_43loop_labels_55433, _43loop_labels_55433, _labbel_58655);
L10: 

    /** parser.e:2234		if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_43block_list_55435)){
            _29387 = SEQ_PTR(_43block_list_55435)->length;
    }
    else {
        _29387 = 1;
    }
    if (_43block_index_55436 != _29387)
    goto L11; // [381] 404

    /** parser.e:2235		    block_list &= opcode*/
    Append(&_43block_list_55435, _43block_list_55435, _opcode_58652);

    /** parser.e:2236		    block_index += 1*/
    _43block_index_55436 = _43block_index_55436 + 1;
    goto L12; // [401] 423
L11: 

    /** parser.e:2238		    block_index += 1*/
    _43block_index_55436 = _43block_index_55436 + 1;

    /** parser.e:2239		    block_list[block_index] = opcode*/
    _2 = (object)SEQ_PTR(_43block_list_55435);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43block_list_55435 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _43block_index_55436);
    *(intptr_t *)_2 = _opcode_58652;
L12: 

    /** parser.e:2241		if tok[T_ID]=ENTRY then*/
    _2 = (object)SEQ_PTR(_tok_58654);
    _29392 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29392, 424)){
        _29392 = NOVALUE;
        goto L13; // [433] 463
    }
    _29392 = NOVALUE;

    /** parser.e:2242		    if has_entry then*/
    if (_has_entry_58656 == 0)
    {
        goto L14; // [439] 452
    }
    else{
    }

    /** parser.e:2243		        CompileErr(DUPLICATE_ENTRY_CLAUSE_IN_A_LOOP_HEADER)*/
    RefDS(_22209);
    _49CompileErr(64, _22209, 0);
L14: 

    /** parser.e:2245		    has_entry=1*/
    _has_entry_58656 = 1;

    /** parser.e:2246		    tok=next_token()*/
    _0 = _tok_58654;
    _tok_58654 = _43next_token();
    DeRef(_0);
L13: 

    /** parser.e:2248		if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_58656 == 0) {
        goto L15; // [465] 503
    }
    _29396 = (_opcode_58652 == 20);
    if (_29396 != 0) {
        DeRef(_29397);
        _29397 = 1;
        goto L16; // [475] 489
    }
    _29398 = (_opcode_58652 == 185);
    _29397 = (_29398 != 0);
L16: 
    if (_29397 == 0)
    {
        _29397 = NOVALUE;
        goto L15; // [490] 503
    }
    else{
        _29397 = NOVALUE;
    }

    /** parser.e:2249			CompileErr(ENTRY_KEYWORD_IS_NOT_SUPPORTED_INSIDE_AN_IF_OR_SWITCH_BLOCK_HEADER)*/
    RefDS(_22209);
    _49CompileErr(80, _22209, 0);
L15: 

    /** parser.e:2251		if opcode = IF then*/
    if (_opcode_58652 != 20)
    goto L17; // [507] 523

    /** parser.e:2252			opcode = THEN*/
    _opcode_58652 = 410;
    goto L18; // [520] 533
L17: 

    /** parser.e:2254			opcode = DO*/
    _opcode_58652 = 411;
L18: 

    /** parser.e:2256		putback(tok)*/
    Ref(_tok_58654);
    _43putback(_tok_58654);

    /** parser.e:2257		tok_match(opcode)*/
    _43tok_match(_opcode_58652, 0);

    /** parser.e:2258		return has_entry*/
    DeRef(_tok_58654);
    DeRef(_labbel_58655);
    DeRef(_29354);
    _29354 = NOVALUE;
    DeRef(_29352);
    _29352 = NOVALUE;
    DeRef(_29396);
    _29396 = NOVALUE;
    DeRef(_29367);
    _29367 = NOVALUE;
    DeRef(_29382);
    _29382 = NOVALUE;
    DeRef(_29398);
    _29398 = NOVALUE;
    _29378 = NOVALUE;
    DeRef(_29356);
    _29356 = NOVALUE;
    return _has_entry_58656;
    ;
}


void _43If_statement()
{
    object _addr_inlined_AppendEList_at_624_58910 = NOVALUE;
    object _addr_inlined_AppendEList_at_260_58839 = NOVALUE;
    object _tok_58782 = NOVALUE;
    object _prev_false_58783 = NOVALUE;
    object _prev_false2_58784 = NOVALUE;
    object _elist_base_58785 = NOVALUE;
    object _temps_58793 = NOVALUE;
    object _31979 = NOVALUE;
    object _29464 = NOVALUE;
    object _29463 = NOVALUE;
    object _29460 = NOVALUE;
    object _29459 = NOVALUE;
    object _29457 = NOVALUE;
    object _29456 = NOVALUE;
    object _29455 = NOVALUE;
    object _29453 = NOVALUE;
    object _29452 = NOVALUE;
    object _29450 = NOVALUE;
    object _29449 = NOVALUE;
    object _29448 = NOVALUE;
    object _29446 = NOVALUE;
    object _29445 = NOVALUE;
    object _29443 = NOVALUE;
    object _29442 = NOVALUE;
    object _29441 = NOVALUE;
    object _29440 = NOVALUE;
    object _29438 = NOVALUE;
    object _29437 = NOVALUE;
    object _29434 = NOVALUE;
    object _29432 = NOVALUE;
    object _29431 = NOVALUE;
    object _29430 = NOVALUE;
    object _29427 = NOVALUE;
    object _29424 = NOVALUE;
    object _29423 = NOVALUE;
    object _29421 = NOVALUE;
    object _29420 = NOVALUE;
    object _29418 = NOVALUE;
    object _29417 = NOVALUE;
    object _29415 = NOVALUE;
    object _29412 = NOVALUE;
    object _29410 = NOVALUE;
    object _29409 = NOVALUE;
    object _29408 = NOVALUE;
    object _29404 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2265		integer prev_false*/

    /** parser.e:2266		integer prev_false2*/

    /** parser.e:2267		integer elist_base*/

    /** parser.e:2269		if_stack &= IF*/
    Append(&_43if_stack_55440, _43if_stack_55440, 20);

    /** parser.e:2271		Start_block( IF )*/
    _64Start_block(20, 0);

    /** parser.e:2273		elist_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_55423)){
            _elist_base_58785 = SEQ_PTR(_43break_list_55423)->length;
    }
    else {
        _elist_base_58785 = 1;
    }

    /** parser.e:2274		short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;

    /** parser.e:2275		short_circuit_B = FALSE*/
    _43short_circuit_B_55407 = _9FALSE_439;

    /** parser.e:2276		SC1_type = 0*/
    _43SC1_type_55410 = 0;

    /** parser.e:2277		Expr()*/
    _43Expr();

    /** parser.e:2279		sequence temps = get_temps()*/
    _31979 = Repeat(_22209, 2);
    _0 = _temps_58793;
    _temps_58793 = _45get_temps(_31979);
    DeRef(_0);
    _31979 = NOVALUE;

    /** parser.e:2281		emit_op(IF)*/
    _45emit_op(20);

    /** parser.e:2282		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29404 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29404 = 1;
    }
    _prev_false_58783 = _29404 + 1;
    _29404 = NOVALUE;

    /** parser.e:2283		emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2284		prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_58784 = _43finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_58784)) {
        _1 = (object)(DBL_PTR(_prev_false2_58784)->dbl);
        DeRefDS(_prev_false2_58784);
        _prev_false2_58784 = _1;
    }

    /** parser.e:2285		if SC1_type = OR then*/
    if (_43SC1_type_55410 != 9)
    goto L1; // [106] 159

    /** parser.e:2286			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29408 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29408 +(uintptr_t) HIGH_BITS) >= 0){
        _29408 = NewDouble((eudouble)_29408);
    }
    _45backpatch(_29408, 147);
    _29408 = NOVALUE;

    /** parser.e:2287			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** parser.e:2288				emit_op(NOP1)  -- to get label here*/
    _45emit_op(159);
L2: 

    /** parser.e:2290			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29409 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29409 = 1;
    }
    _29410 = _29409 + 1;
    _29409 = NOVALUE;
    _45backpatch(_43SC1_patch_55409, _29410);
    _29410 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** parser.e:2291		elsif SC1_type = AND then*/
    if (_43SC1_type_55410 != 8)
    goto L4; // [165] 191

    /** parser.e:2292			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29412 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29412 +(uintptr_t) HIGH_BITS) >= 0){
        _29412 = NewDouble((eudouble)_29412);
    }
    _45backpatch(_29412, 146);
    _29412 = NOVALUE;

    /** parser.e:2293			prev_false2 = SC1_patch*/
    _prev_false2_58784 = _43SC1_patch_55409;
L4: 
L3: 

    /** parser.e:2295		short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:2298		Statement_list()*/
    _43Statement_list();

    /** parser.e:2299		tok = next_token()*/
    _0 = _tok_58782;
    _tok_58782 = _43next_token();
    DeRef(_0);

    /** parser.e:2301		while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (object)SEQ_PTR(_tok_58782);
    _29415 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29415, 414)){
        _29415 = NOVALUE;
        goto L6; // [222] 530
    }
    _29415 = NOVALUE;

    /** parser.e:2302			Sibling_block( IF )*/
    _64Sibling_block(20);

    /** parser.e:2305			emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2306			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29417 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29417 = 1;
    }
    _29418 = _29417 + 1;
    _29417 = NOVALUE;
    _addr_inlined_AppendEList_at_260_58839 = _29418;
    _29418 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55423, _43break_list_55423, _addr_inlined_AppendEList_at_260_58839);

    /** parser.e:394	end procedure*/
    goto L7; // [266] 269
L7: 

    /** parser.e:2307			break_delay &= 1*/
    Append(&_43break_delay_55424, _43break_delay_55424, 1);

    /** parser.e:2308			emit_forward_addr()  -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2309			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** parser.e:2310				emit_op(NOP1)*/
    _45emit_op(159);
L8: 

    /** parser.e:2312			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29420 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29420 = 1;
    }
    _29421 = _29420 + 1;
    _29420 = NOVALUE;
    _45backpatch(_prev_false_58783, _29421);
    _29421 = NOVALUE;

    /** parser.e:2313			if prev_false2 != 0 then*/
    if (_prev_false2_58784 == 0)
    goto L9; // [315] 335

    /** parser.e:2314				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29423 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29423 = 1;
    }
    _29424 = _29423 + 1;
    _29423 = NOVALUE;
    _45backpatch(_prev_false2_58784, _29424);
    _29424 = NOVALUE;
L9: 

    /** parser.e:2317			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:2318			short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;

    /** parser.e:2319			short_circuit_B = FALSE*/
    _43short_circuit_B_55407 = _9FALSE_439;

    /** parser.e:2320			SC1_type = 0*/
    _43SC1_type_55410 = 0;

    /** parser.e:2322			push_temps( temps )*/
    RefDS(_temps_58793);
    _45push_temps(_temps_58793);

    /** parser.e:2323			Expr()*/
    _43Expr();

    /** parser.e:2325			temps = get_temps( temps )*/
    RefDS(_temps_58793);
    _0 = _temps_58793;
    _temps_58793 = _45get_temps(_temps_58793);
    DeRefDS(_0);

    /** parser.e:2327			emit_op(IF)*/
    _45emit_op(20);

    /** parser.e:2328			prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29427 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29427 = 1;
    }
    _prev_false_58783 = _29427 + 1;
    _29427 = NOVALUE;

    /** parser.e:2329			prev_false2 = 0*/
    _prev_false2_58784 = 0;

    /** parser.e:2330			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2331			if SC1_type = OR then*/
    if (_43SC1_type_55410 != 9)
    goto LA; // [414] 467

    /** parser.e:2332				backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29430 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29430 +(uintptr_t) HIGH_BITS) >= 0){
        _29430 = NewDouble((eudouble)_29430);
    }
    _45backpatch(_29430, 147);
    _29430 = NOVALUE;

    /** parser.e:2333				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** parser.e:2334					emit_op(NOP1)*/
    _45emit_op(159);
LB: 

    /** parser.e:2336				backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29431 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29431 = 1;
    }
    _29432 = _29431 + 1;
    _29431 = NOVALUE;
    _45backpatch(_43SC1_patch_55409, _29432);
    _29432 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** parser.e:2337			elsif SC1_type = AND then*/
    if (_43SC1_type_55410 != 8)
    goto LD; // [473] 499

    /** parser.e:2338				backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29434 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29434 +(uintptr_t) HIGH_BITS) >= 0){
        _29434 = NewDouble((eudouble)_29434);
    }
    _45backpatch(_29434, 146);
    _29434 = NOVALUE;

    /** parser.e:2339				prev_false2 = SC1_patch*/
    _prev_false2_58784 = _43SC1_patch_55409;
LD: 
LC: 

    /** parser.e:2341			short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:2342			tok_match(THEN)*/
    _43tok_match(410, 0);

    /** parser.e:2345			Statement_list()*/
    _43Statement_list();

    /** parser.e:2346			tok = next_token()*/
    _0 = _tok_58782;
    _tok_58782 = _43next_token();
    DeRef(_0);

    /** parser.e:2347		end while*/
    goto L5; // [527] 214
L6: 

    /** parser.e:2349		if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (object)SEQ_PTR(_tok_58782);
    _29437 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29437)) {
        _29438 = (_29437 == 23);
    }
    else {
        _29438 = binary_op(EQUALS, _29437, 23);
    }
    _29437 = NOVALUE;
    if (IS_ATOM_INT(_29438)) {
        if (_29438 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_29438)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (object)SEQ_PTR(_temps_58793);
    _29440 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29440)){
            _29441 = SEQ_PTR(_29440)->length;
    }
    else {
        _29441 = 1;
    }
    _29440 = NOVALUE;
    if (_29441 == 0)
    {
        _29441 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _29441 = NOVALUE;
    }
LE: 

    /** parser.e:2354			Sibling_block( IF )*/
    _64Sibling_block(20);

    /** parser.e:2356			StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9FALSE_439, 0, 1);

    /** parser.e:2357			emit_op(ELSE)*/
    _45emit_op(23);

    /** parser.e:2358			AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29442 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29442 = 1;
    }
    _29443 = _29442 + 1;
    _29442 = NOVALUE;
    _addr_inlined_AppendEList_at_624_58910 = _29443;
    _29443 = NOVALUE;

    /** parser.e:393		break_list = append(break_list, addr)*/
    Append(&_43break_list_55423, _43break_list_55423, _addr_inlined_AppendEList_at_624_58910);

    /** parser.e:394	end procedure*/
    goto L10; // [611] 614
L10: 

    /** parser.e:2359			break_delay &= 1*/
    Append(&_43break_delay_55424, _43break_delay_55424, 1);

    /** parser.e:2360			emit_forward_addr() -- to be patched*/
    _43emit_forward_addr();

    /** parser.e:2361			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** parser.e:2362				emit_op(NOP1)*/
    _45emit_op(159);
L11: 

    /** parser.e:2364			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29445 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29445 = 1;
    }
    _29446 = _29445 + 1;
    _29445 = NOVALUE;
    _45backpatch(_prev_false_58783, _29446);
    _29446 = NOVALUE;

    /** parser.e:2365			if prev_false2 != 0 then*/
    if (_prev_false2_58784 == 0)
    goto L12; // [660] 680

    /** parser.e:2366				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29448 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29448 = 1;
    }
    _29449 = _29448 + 1;
    _29448 = NOVALUE;
    _45backpatch(_prev_false2_58784, _29449);
    _29449 = NOVALUE;
L12: 

    /** parser.e:2369			push_temps( temps )*/
    RefDS(_temps_58793);
    _45push_temps(_temps_58793);

    /** parser.e:2371			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_58782);
    _29450 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29450, 23)){
        _29450 = NOVALUE;
        goto L13; // [695] 706
    }
    _29450 = NOVALUE;

    /** parser.e:2372				Statement_list()*/
    _43Statement_list();
    goto L14; // [703] 773
L13: 

    /** parser.e:2374				putback(tok)*/
    Ref(_tok_58782);
    _43putback(_tok_58782);
    goto L14; // [712] 773
LF: 

    /** parser.e:2377			putback(tok)*/
    Ref(_tok_58782);
    _43putback(_tok_58782);

    /** parser.e:2378			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** parser.e:2379				emit_op(NOP1)*/
    _45emit_op(159);
L15: 

    /** parser.e:2381			backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29452 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29452 = 1;
    }
    _29453 = _29452 + 1;
    _29452 = NOVALUE;
    _45backpatch(_prev_false_58783, _29453);
    _29453 = NOVALUE;

    /** parser.e:2382			if prev_false2 != 0 then*/
    if (_prev_false2_58784 == 0)
    goto L16; // [752] 772

    /** parser.e:2383				backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29455 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29455 = 1;
    }
    _29456 = _29455 + 1;
    _29455 = NOVALUE;
    _45backpatch(_prev_false2_58784, _29456);
    _29456 = NOVALUE;
L16: 
L14: 

    /** parser.e:2387		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:2388		tok_match(IF, END)*/
    _43tok_match(20, 402);

    /** parser.e:2390		End_block( IF )*/
    _64End_block(20);

    /** parser.e:2392		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** parser.e:2393			if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_43break_list_55423)){
            _29457 = SEQ_PTR(_43break_list_55423)->length;
    }
    else {
        _29457 = 1;
    }
    if (_29457 <= _elist_base_58785)
    goto L18; // [812] 824

    /** parser.e:2394				emit_op(NOP1)  -- to emit label here*/
    _45emit_op(159);
L18: 
L17: 

    /** parser.e:2397		PatchEList(elist_base)*/
    _43PatchEList(_elist_base_58785);

    /** parser.e:2398		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_55434)){
            _29459 = SEQ_PTR(_43if_labels_55434)->length;
    }
    else {
        _29459 = 1;
    }
    _29460 = _29459 - 1;
    _29459 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_55434;
    RHS_Slice(_43if_labels_55434, 1, _29460);

    /** parser.e:2399		block_index -= 1*/
    _43block_index_55436 = _43block_index_55436 - 1;

    /** parser.e:2400		if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _29463 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _29463 = 1;
    }
    _29464 = _29463 - 1;
    _29463 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_55440;
    RHS_Slice(_43if_stack_55440, 1, _29464);

    /** parser.e:2402	end procedure*/
    DeRef(_tok_58782);
    DeRef(_temps_58793);
    DeRef(_29438);
    _29438 = NOVALUE;
    _29460 = NOVALUE;
    _29464 = NOVALUE;
    _29440 = NOVALUE;
    return;
    ;
}


void _43exit_loop(object _exit_base_58970)
{
    object _29479 = NOVALUE;
    object _29478 = NOVALUE;
    object _29476 = NOVALUE;
    object _29475 = NOVALUE;
    object _29473 = NOVALUE;
    object _29472 = NOVALUE;
    object _29470 = NOVALUE;
    object _29469 = NOVALUE;
    object _29467 = NOVALUE;
    object _29466 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2405		PatchXList(exit_base)*/
    _43PatchXList(_exit_base_58970);

    /** parser.e:2406		loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_43loop_labels_55433)){
            _29466 = SEQ_PTR(_43loop_labels_55433)->length;
    }
    else {
        _29466 = 1;
    }
    _29467 = _29466 - 1;
    _29466 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_labels_55433;
    RHS_Slice(_43loop_labels_55433, 1, _29467);

    /** parser.e:2407		loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _29469 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _29469 = 1;
    }
    _29470 = _29469 - 1;
    _29469 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43loop_stack_55439;
    RHS_Slice(_43loop_stack_55439, 1, _29470);

    /** parser.e:2408		continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_43continue_addr_55430)){
            _29472 = SEQ_PTR(_43continue_addr_55430)->length;
    }
    else {
        _29472 = 1;
    }
    _29473 = _29472 - 1;
    _29472 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43continue_addr_55430;
    RHS_Slice(_43continue_addr_55430, 1, _29473);

    /** parser.e:2409		retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43retry_addr_55431)){
            _29475 = SEQ_PTR(_43retry_addr_55431)->length;
    }
    else {
        _29475 = 1;
    }
    _29476 = _29475 - 1;
    _29475 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43retry_addr_55431;
    RHS_Slice(_43retry_addr_55431, 1, _29476);

    /** parser.e:2410		entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_43entry_addr_55429)){
            _29478 = SEQ_PTR(_43entry_addr_55429)->length;
    }
    else {
        _29478 = 1;
    }
    _29479 = _29478 - 1;
    _29478 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43entry_addr_55429;
    RHS_Slice(_43entry_addr_55429, 1, _29479);

    /** parser.e:2411		block_index -= 1*/
    _43block_index_55436 = _43block_index_55436 - 1;

    /** parser.e:2412	end procedure*/
    _29467 = NOVALUE;
    _29470 = NOVALUE;
    _29479 = NOVALUE;
    _29473 = NOVALUE;
    _29476 = NOVALUE;
    return;
    ;
}


void _43push_switch()
{
    object _new_1__tmp_at14_58993 = NOVALUE;
    object _new_inlined_new_at_14_58992 = NOVALUE;
    object _29483 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2415		if_stack &= SWITCH*/
    Append(&_43if_stack_55440, _43if_stack_55440, 185);

    /** parser.e:2416		switch_stack = append( switch_stack,*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at14_58993;
    _new_1__tmp_at14_58993 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at14_58993);
    _0 = _new_inlined_new_at_14_58992;
    _new_inlined_new_at_14_58992 = _35malloc(_new_1__tmp_at14_58993, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at14_58993);
    _new_1__tmp_at14_58993 = NOVALUE;
    _1 = NewS1(13);
    _2 = (object)((s1_ptr)_1)->base;
    RefDSn(_22209, 2);
    ((intptr_t*)_2)[1] = _22209;
    ((intptr_t*)_2)[2] = _22209;
    ((intptr_t*)_2)[3] = 0;
    ((intptr_t*)_2)[4] = 0;
    ((intptr_t*)_2)[5] = 0;
    ((intptr_t*)_2)[6] = 0;
    Ref(_new_inlined_new_at_14_58992);
    ((intptr_t*)_2)[7] = _new_inlined_new_at_14_58992;
    RefDS(_22209);
    ((intptr_t*)_2)[8] = _22209;
    ((intptr_t*)_2)[9] = 0;
    RefDSn(_22209, 4);
    ((intptr_t*)_2)[10] = _22209;
    ((intptr_t*)_2)[11] = _22209;
    ((intptr_t*)_2)[12] = _22209;
    ((intptr_t*)_2)[13] = _22209;
    _29483 = MAKE_SEQ(_1);
    RefDS(_29483);
    Append(&_43switch_stack_55654, _43switch_stack_55654, _29483);
    DeRefDS(_29483);
    _29483 = NOVALUE;

    /** parser.e:2433	end procedure*/
    return;
    ;
}


void _43pop_switch(object _break_base_58998)
{
    object _29498 = NOVALUE;
    object _29497 = NOVALUE;
    object _29495 = NOVALUE;
    object _29494 = NOVALUE;
    object _29492 = NOVALUE;
    object _29491 = NOVALUE;
    object _29489 = NOVALUE;
    object _29488 = NOVALUE;
    object _29487 = NOVALUE;
    object _29486 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2438		PatchEList( break_base )*/
    _43PatchEList(_break_base_58998);

    /** parser.e:2439		block_index -= 1*/
    _43block_index_55436 = _43block_index_55436 - 1;

    /** parser.e:2440		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29486 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29486 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29487 = (object)*(((s1_ptr)_2)->base + _29486);
    _2 = (object)SEQ_PTR(_29487);
    _29488 = (object)*(((s1_ptr)_2)->base + 1);
    _29487 = NOVALUE;
    if (IS_SEQUENCE(_29488)){
            _29489 = SEQ_PTR(_29488)->length;
    }
    else {
        _29489 = 1;
    }
    _29488 = NOVALUE;
    if (_29489 <= 0)
    goto L1; // [34] 46

    /** parser.e:2441			End_block( CASE )*/
    _64End_block(186);
L1: 

    /** parser.e:2443		if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_43if_labels_55434)){
            _29491 = SEQ_PTR(_43if_labels_55434)->length;
    }
    else {
        _29491 = 1;
    }
    _29492 = _29491 - 1;
    _29491 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_labels_55434;
    RHS_Slice(_43if_labels_55434, 1, _29492);

    /** parser.e:2444		if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _29494 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _29494 = 1;
    }
    _29495 = _29494 - 1;
    _29494 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43if_stack_55440;
    RHS_Slice(_43if_stack_55440, 1, _29495);

    /** parser.e:2445		switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29497 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29497 = 1;
    }
    _29498 = _29497 - 1;
    _29497 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43switch_stack_55654;
    RHS_Slice(_43switch_stack_55654, 1, _29498);

    /** parser.e:2446	end procedure*/
    _29492 = NOVALUE;
    _29488 = NOVALUE;
    _29495 = NOVALUE;
    _29498 = NOVALUE;
    return;
    ;
}


void _43add_case(object _sym_59019, object _sign_59020)
{
    object _29545 = NOVALUE;
    object _29544 = NOVALUE;
    object _29543 = NOVALUE;
    object _29542 = NOVALUE;
    object _29541 = NOVALUE;
    object _29540 = NOVALUE;
    object _29538 = NOVALUE;
    object _29537 = NOVALUE;
    object _29536 = NOVALUE;
    object _29535 = NOVALUE;
    object _29533 = NOVALUE;
    object _29532 = NOVALUE;
    object _29531 = NOVALUE;
    object _29530 = NOVALUE;
    object _29528 = NOVALUE;
    object _29527 = NOVALUE;
    object _29526 = NOVALUE;
    object _29525 = NOVALUE;
    object _29524 = NOVALUE;
    object _29522 = NOVALUE;
    object _29521 = NOVALUE;
    object _29520 = NOVALUE;
    object _29519 = NOVALUE;
    object _29518 = NOVALUE;
    object _29517 = NOVALUE;
    object _29515 = NOVALUE;
    object _29514 = NOVALUE;
    object _29513 = NOVALUE;
    object _29512 = NOVALUE;
    object _29511 = NOVALUE;
    object _29510 = NOVALUE;
    object _29508 = NOVALUE;
    object _29507 = NOVALUE;
    object _29505 = NOVALUE;
    object _29504 = NOVALUE;
    object _29503 = NOVALUE;
    object _29502 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2450		if sign < 0 then*/
    if (_sign_59020 >= 0)
    goto L1; // [5] 15

    /** parser.e:2451			sym = -sym*/
    _0 = _sym_59019;
    if (IS_ATOM_INT(_sym_59019)) {
        if ((uintptr_t)_sym_59019 == (uintptr_t)HIGH_BITS){
            _sym_59019 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _sym_59019 = - _sym_59019;
        }
    }
    else {
        _sym_59019 = unary_op(UMINUS, _sym_59019);
    }
    DeRefi(_0);
L1: 

    /** parser.e:2454		if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29502 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29502 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29503 = (object)*(((s1_ptr)_2)->base + _29502);
    _2 = (object)SEQ_PTR(_29503);
    _29504 = (object)*(((s1_ptr)_2)->base + 1);
    _29503 = NOVALUE;
    _29505 = find_from(_sym_59019, _29504, 1);
    _29504 = NOVALUE;
    if (_29505 != 0)
    goto L2; // [35] 252

    /** parser.e:2455			switch_stack[$][SWITCH_CASES]            = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29507 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29507 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29507 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29510 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29510 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29511 = (object)*(((s1_ptr)_2)->base + _29510);
    _2 = (object)SEQ_PTR(_29511);
    _29512 = (object)*(((s1_ptr)_2)->base + 1);
    _29511 = NOVALUE;
    Ref(_sym_59019);
    Append(&_29513, _29512, _sym_59019);
    _29512 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29513;
    if( _1 != _29513 ){
        DeRef(_1);
    }
    _29513 = NOVALUE;
    _29508 = NOVALUE;

    /** parser.e:2456			switch_stack[$][SWITCH_JUMP_TABLE]      &= length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29514 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29514 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29514 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_27Code_20660)){
            _29517 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29517 = 1;
    }
    _29518 = _29517 + 1;
    _29517 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29519 = (object)*(((s1_ptr)_2)->base + 2);
    _29515 = NOVALUE;
    if (IS_SEQUENCE(_29519) && IS_ATOM(_29518)) {
        Append(&_29520, _29519, _29518);
    }
    else if (IS_ATOM(_29519) && IS_SEQUENCE(_29518)) {
    }
    else {
        Concat((object_ptr)&_29520, _29519, _29518);
        _29519 = NOVALUE;
    }
    _29519 = NOVALUE;
    _29518 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29520;
    if( _1 != _29520 ){
        DeRef(_1);
    }
    _29520 = NOVALUE;
    _29515 = NOVALUE;

    /** parser.e:2457			switch_stack[$][SWITCH_THISLINE]        &= {ThisLine}*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29521 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29521 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29521 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_49ThisLine_49642);
    ((intptr_t*)_2)[1] = _49ThisLine_49642;
    _29524 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29525 = (object)*(((s1_ptr)_2)->base + 10);
    _29522 = NOVALUE;
    if (IS_SEQUENCE(_29525) && IS_ATOM(_29524)) {
    }
    else if (IS_ATOM(_29525) && IS_SEQUENCE(_29524)) {
        Ref(_29525);
        Prepend(&_29526, _29524, _29525);
    }
    else {
        Concat((object_ptr)&_29526, _29525, _29524);
        _29525 = NOVALUE;
    }
    _29525 = NOVALUE;
    DeRefDS(_29524);
    _29524 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29526;
    if( _1 != _29526 ){
        DeRef(_1);
    }
    _29526 = NOVALUE;
    _29522 = NOVALUE;

    /** parser.e:2458			switch_stack[$][SWITCH_BP]              &= bp*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29527 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29527 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29527 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29530 = (object)*(((s1_ptr)_2)->base + 11);
    _29528 = NOVALUE;
    if (IS_SEQUENCE(_29530) && IS_ATOM(_49bp_49646)) {
        Append(&_29531, _29530, _49bp_49646);
    }
    else if (IS_ATOM(_29530) && IS_SEQUENCE(_49bp_49646)) {
    }
    else {
        Concat((object_ptr)&_29531, _29530, _49bp_49646);
        _29530 = NOVALUE;
    }
    _29530 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29531;
    if( _1 != _29531 ){
        DeRef(_1);
    }
    _29531 = NOVALUE;
    _29528 = NOVALUE;

    /** parser.e:2459			switch_stack[$][SWITCH_LINE_NUMBER]     &= line_number*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29532 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29532 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29532 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29535 = (object)*(((s1_ptr)_2)->base + 12);
    _29533 = NOVALUE;
    if (IS_SEQUENCE(_29535) && IS_ATOM(_27line_number_20572)) {
        Append(&_29536, _29535, _27line_number_20572);
    }
    else if (IS_ATOM(_29535) && IS_SEQUENCE(_27line_number_20572)) {
    }
    else {
        Concat((object_ptr)&_29536, _29535, _27line_number_20572);
        _29535 = NOVALUE;
    }
    _29535 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29536;
    if( _1 != _29536 ){
        DeRef(_1);
    }
    _29536 = NOVALUE;
    _29533 = NOVALUE;

    /** parser.e:2460			switch_stack[$][SWITCH_CURRENT_FILE_NO] &= current_file_no*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29537 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29537 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29537 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29540 = (object)*(((s1_ptr)_2)->base + 13);
    _29538 = NOVALUE;
    if (IS_SEQUENCE(_29540) && IS_ATOM(_27current_file_no_20571)) {
        Append(&_29541, _29540, _27current_file_no_20571);
    }
    else if (IS_ATOM(_29540) && IS_SEQUENCE(_27current_file_no_20571)) {
    }
    else {
        Concat((object_ptr)&_29541, _29540, _27current_file_no_20571);
        _29540 = NOVALUE;
    }
    _29540 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29541;
    if( _1 != _29541 ){
        DeRef(_1);
    }
    _29541 = NOVALUE;
    _29538 = NOVALUE;

    /** parser.e:2462			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [217] 262
    }
    else{
    }

    /** parser.e:2463				emit_addr( CASE )*/
    _45emit_addr(186);

    /** parser.e:2464				emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29542 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29542 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29543 = (object)*(((s1_ptr)_2)->base + _29542);
    _2 = (object)SEQ_PTR(_29543);
    _29544 = (object)*(((s1_ptr)_2)->base + 1);
    _29543 = NOVALUE;
    if (IS_SEQUENCE(_29544)){
            _29545 = SEQ_PTR(_29544)->length;
    }
    else {
        _29545 = 1;
    }
    _29544 = NOVALUE;
    _45emit_addr(_29545);
    _29545 = NOVALUE;
    goto L3; // [249] 262
L2: 

    /** parser.e:2467			CompileErr( DUPLICATE_CASE_VALUE_USED)*/
    RefDS(_22209);
    _49CompileErr(63, _22209, 0);
L3: 

    /** parser.e:2469	end procedure*/
    DeRef(_sym_59019);
    _29544 = NOVALUE;
    return;
    ;
}


void _43case_else()
{
    object _29553 = NOVALUE;
    object _29552 = NOVALUE;
    object _29550 = NOVALUE;
    object _29549 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2476		switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29549 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29549 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29549 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_27Code_20660)){
            _29552 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29552 = 1;
    }
    _29553 = _29552 + 1;
    _29552 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29553;
    if( _1 != _29553 ){
        DeRef(_1);
    }
    _29553 = NOVALUE;
    _29550 = NOVALUE;

    /** parser.e:2477		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** parser.e:2478			emit_addr( CASE )*/
    _45emit_addr(186);

    /** parser.e:2479			emit_addr( 0 )*/
    _45emit_addr(0);
L1: 

    /** parser.e:2482	end procedure*/
    return;
    ;
}


void _43Case_statement()
{
    object _else_case_2__tmp_at147_59143 = NOVALUE;
    object _else_case_1__tmp_at147_59142 = NOVALUE;
    object _else_case_inlined_else_case_at_147_59141 = NOVALUE;
    object _tok_59104 = NOVALUE;
    object _condition_59106 = NOVALUE;
    object _start_line_59136 = NOVALUE;
    object _sign_59148 = NOVALUE;
    object _fwd_59161 = NOVALUE;
    object _symi_59171 = NOVALUE;
    object _fwdref_59243 = NOVALUE;
    object _31978 = NOVALUE;
    object _29635 = NOVALUE;
    object _29634 = NOVALUE;
    object _29633 = NOVALUE;
    object _29632 = NOVALUE;
    object _29631 = NOVALUE;
    object _29630 = NOVALUE;
    object _29628 = NOVALUE;
    object _29627 = NOVALUE;
    object _29626 = NOVALUE;
    object _29625 = NOVALUE;
    object _29624 = NOVALUE;
    object _29623 = NOVALUE;
    object _29621 = NOVALUE;
    object _29618 = NOVALUE;
    object _29615 = NOVALUE;
    object _29614 = NOVALUE;
    object _29613 = NOVALUE;
    object _29612 = NOVALUE;
    object _29609 = NOVALUE;
    object _29608 = NOVALUE;
    object _29607 = NOVALUE;
    object _29606 = NOVALUE;
    object _29603 = NOVALUE;
    object _29602 = NOVALUE;
    object _29601 = NOVALUE;
    object _29600 = NOVALUE;
    object _29598 = NOVALUE;
    object _29597 = NOVALUE;
    object _29596 = NOVALUE;
    object _29594 = NOVALUE;
    object _29593 = NOVALUE;
    object _29592 = NOVALUE;
    object _29591 = NOVALUE;
    object _29590 = NOVALUE;
    object _29588 = NOVALUE;
    object _29587 = NOVALUE;
    object _29585 = NOVALUE;
    object _29584 = NOVALUE;
    object _29583 = NOVALUE;
    object _29582 = NOVALUE;
    object _29578 = NOVALUE;
    object _29577 = NOVALUE;
    object _29576 = NOVALUE;
    object _29573 = NOVALUE;
    object _29570 = NOVALUE;
    object _29567 = NOVALUE;
    object _29566 = NOVALUE;
    object _29565 = NOVALUE;
    object _29564 = NOVALUE;
    object _29563 = NOVALUE;
    object _29562 = NOVALUE;
    object _29561 = NOVALUE;
    object _29559 = NOVALUE;
    object _29558 = NOVALUE;
    object _29557 = NOVALUE;
    object _29556 = NOVALUE;
    object _29554 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2489		if not in_switch() then*/
    _29554 = _43in_switch();
    if (IS_ATOM_INT(_29554)) {
        if (_29554 != 0){
            DeRef(_29554);
            _29554 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29554)->dbl != 0.0){
            DeRef(_29554);
            _29554 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29554);
    _29554 = NOVALUE;

    /** parser.e:2490			CompileErr( A_CASE_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22209);
    _49CompileErr(34, _22209, 0);
L1: 

    /** parser.e:2493		if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29556 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29556 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29557 = (object)*(((s1_ptr)_2)->base + _29556);
    _2 = (object)SEQ_PTR(_29557);
    _29558 = (object)*(((s1_ptr)_2)->base + 1);
    _29557 = NOVALUE;
    if (IS_SEQUENCE(_29558)){
            _29559 = SEQ_PTR(_29558)->length;
    }
    else {
        _29559 = 1;
    }
    _29558 = NOVALUE;
    if (_29559 <= 0)
    goto L2; // [37] 103

    /** parser.e:2495			Sibling_block( CASE )*/
    _64Sibling_block(186);

    /** parser.e:2497			if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29561 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29561 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29562 = (object)*(((s1_ptr)_2)->base + _29561);
    _2 = (object)SEQ_PTR(_29562);
    _29563 = (object)*(((s1_ptr)_2)->base + 5);
    _29562 = NOVALUE;
    if (IS_ATOM_INT(_29563)) {
        _29564 = (_29563 == 0);
    }
    else {
        _29564 = unary_op(NOT, _29563);
    }
    _29563 = NOVALUE;
    if (IS_ATOM_INT(_29564)) {
        if (_29564 == 0) {
            goto L3; // [66] 112
        }
    }
    else {
        if (DBL_PTR(_29564)->dbl == 0.0) {
            goto L3; // [66] 112
        }
    }
    _29566 = (_43fallthru_case_59100 == 0);
    if (_29566 == 0)
    {
        DeRef(_29566);
        _29566 = NOVALUE;
        goto L3; // [76] 112
    }
    else{
        DeRef(_29566);
        _29566 = NOVALUE;
    }

    /** parser.e:2501				putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 186;
    ((intptr_t *)_2)[2] = 0;
    _29567 = MAKE_SEQ(_1);
    _43putback(_29567);
    _29567 = NOVALUE;

    /** parser.e:2502				Break_statement()*/
    _43Break_statement();

    /** parser.e:2503				tok = next_token()*/
    _0 = _tok_59104;
    _tok_59104 = _43next_token();
    DeRef(_0);
    goto L3; // [100] 112
L2: 

    /** parser.e:2506			Start_block( CASE )*/
    _64Start_block(186, 0);
L3: 

    /** parser.e:2509		StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_441, 0, 1);

    /** parser.e:2511		fallthru_case = 0*/
    _43fallthru_case_59100 = 0;

    /** parser.e:2512		integer start_line = line_number*/
    _start_line_59136 = _27line_number_20572;

    /** parser.e:2513		while 1 do*/
L4: 

    /** parser.e:2515			if else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _else_case_1__tmp_at147_59142 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _else_case_1__tmp_at147_59142 = 1;
    }
    DeRef(_else_case_2__tmp_at147_59143);
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _else_case_2__tmp_at147_59143 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at147_59142);
    RefDS(_else_case_2__tmp_at147_59143);
    DeRef(_else_case_inlined_else_case_at_147_59141);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at147_59143);
    _else_case_inlined_else_case_at_147_59141 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_147_59141);
    DeRef(_else_case_2__tmp_at147_59143);
    _else_case_2__tmp_at147_59143 = NOVALUE;
    if (_else_case_inlined_else_case_at_147_59141 == 0) {
        goto L5; // [162] 175
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_147_59141) && DBL_PTR(_else_case_inlined_else_case_at_147_59141)->dbl == 0.0){
            goto L5; // [162] 175
        }
    }

    /** parser.e:2516				CompileErr( A_CASE_BLOCK_CANNOT_FOLLOW_A_CASE_ELSE_BLOCK)*/
    RefDS(_22209);
    _49CompileErr(33, _22209, 0);
L5: 

    /** parser.e:2518			maybe_namespace()*/
    _61maybe_namespace();

    /** parser.e:2519			tok = next_token()*/
    _0 = _tok_59104;
    _tok_59104 = _43next_token();
    DeRef(_0);

    /** parser.e:2520			integer sign = 1*/
    _sign_59148 = 1;

    /** parser.e:2521			if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29570 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29570, 10)){
        _29570 = NOVALUE;
        goto L6; // [199] 216
    }
    _29570 = NOVALUE;

    /** parser.e:2522				sign = -1*/
    _sign_59148 = -1;

    /** parser.e:2523				tok = next_token()*/
    _0 = _tok_59104;
    _tok_59104 = _43next_token();
    DeRef(_0);
    goto L7; // [213] 237
L6: 

    /** parser.e:2524			elsif tok[T_ID] = PLUS then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29573 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29573, 11)){
        _29573 = NOVALUE;
        goto L8; // [226] 236
    }
    _29573 = NOVALUE;

    /** parser.e:2525				tok = next_token()*/
    _0 = _tok_59104;
    _tok_59104 = _43next_token();
    DeRef(_0);
L8: 
L7: 

    /** parser.e:2528			integer fwd*/

    /** parser.e:2529			if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29576 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 502;
    ((intptr_t*)_2)[2] = 503;
    ((intptr_t*)_2)[3] = 23;
    _29577 = MAKE_SEQ(_1);
    _29578 = find_from(_29576, _29577, 1);
    _29576 = NOVALUE;
    DeRefDS(_29577);
    _29577 = NOVALUE;
    if (_29578 != 0)
    goto L9; // [264] 439
    _29578 = NOVALUE;

    /** parser.e:2531				integer symi = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _symi_59171 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_59171)){
        _symi_59171 = (object)DBL_PTR(_symi_59171)->dbl;
    }

    /** parser.e:2532				fwd = -1*/
    _fwd_59161 = -1;

    /** parser.e:2533				if symi > 0 then*/
    if (_symi_59171 <= 0)
    goto LA; // [284] 434

    /** parser.e:2534					if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29582 = (object)*(((s1_ptr)_2)->base + 1);
    _29583 = find_from(_29582, _29VAR_TOKS_12287, 1);
    _29582 = NOVALUE;
    if (_29583 == 0)
    {
        _29583 = NOVALUE;
        goto LB; // [303] 433
    }
    else{
        _29583 = NOVALUE;
    }

    /** parser.e:2535						if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29584 = (object)*(((s1_ptr)_2)->base + _symi_59171);
    _2 = (object)SEQ_PTR(_29584);
    _29585 = (object)*(((s1_ptr)_2)->base + 4);
    _29584 = NOVALUE;
    if (binary_op_a(NOTEQ, _29585, 9)){
        _29585 = NOVALUE;
        goto LC; // [322] 334
    }
    _29585 = NOVALUE;

    /** parser.e:2537							fwd = symi*/
    _fwd_59161 = _symi_59171;
    goto LD; // [331] 432
LC: 

    /** parser.e:2538						elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29587 = (object)*(((s1_ptr)_2)->base + _symi_59171);
    _2 = (object)SEQ_PTR(_29587);
    _29588 = (object)*(((s1_ptr)_2)->base + 3);
    _29587 = NOVALUE;
    if (binary_op_a(NOTEQ, _29588, 2)){
        _29588 = NOVALUE;
        goto LE; // [350] 431
    }
    _29588 = NOVALUE;

    /** parser.e:2539							fwd = 0*/
    _fwd_59161 = 0;

    /** parser.e:2540							if SymTab[symi][S_CODE] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29590 = (object)*(((s1_ptr)_2)->base + _symi_59171);
    _2 = (object)SEQ_PTR(_29590);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _29591 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _29591 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _29590 = NOVALUE;
    if (_29591 == 0) {
        _29591 = NOVALUE;
        goto LF; // [373] 397
    }
    else {
        if (!IS_ATOM_INT(_29591) && DBL_PTR(_29591)->dbl == 0.0){
            _29591 = NOVALUE;
            goto LF; // [373] 397
        }
        _29591 = NOVALUE;
    }
    _29591 = NOVALUE;

    /** parser.e:2541								tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29592 = (object)*(((s1_ptr)_2)->base + _symi_59171);
    _2 = (object)SEQ_PTR(_29592);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _29593 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _29593 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _29592 = NOVALUE;
    Ref(_29593);
    _2 = (object)SEQ_PTR(_tok_59104);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_59104 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29593;
    if( _1 != _29593 ){
        DeRef(_1);
    }
    _29593 = NOVALUE;
LF: 

    /** parser.e:2543							SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_symi_59171 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29596 = (object)*(((s1_ptr)_2)->base + _symi_59171);
    _2 = (object)SEQ_PTR(_29596);
    _29597 = (object)*(((s1_ptr)_2)->base + 5);
    _29596 = NOVALUE;
    if (IS_ATOM_INT(_29597)) {
        {uintptr_t tu;
             tu = (uintptr_t)_29597 | (uintptr_t)1;
             _29598 = MAKE_UINT(tu);
        }
    }
    else {
        _29598 = binary_op(OR_BITS, _29597, 1);
    }
    _29597 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29598;
    if( _1 != _29598 ){
        DeRef(_1);
    }
    _29598 = NOVALUE;
    _29594 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [436] 445
L9: 

    /** parser.e:2548				fwd = 0*/
    _fwd_59161 = 0;
L10: 

    /** parser.e:2551			if fwd < 0 then*/
    if (_fwd_59161 >= 0)
    goto L11; // [449] 477

    /** parser.e:2552				CompileErr( FOUND_1_BUT_EXPECTED_ELSE_AN_ATOM_STRING_CONSTANT_OR_ENUM, {find_category(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29600 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29600);
    _29601 = _62find_category(_29600);
    _29600 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29601;
    _29602 = MAKE_SEQ(_1);
    _29601 = NOVALUE;
    _49CompileErr(91, _29602, 0);
    _29602 = NOVALUE;
L11: 

    /** parser.e:2555			if tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29603 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29603, 23)){
        _29603 = NOVALUE;
        goto L12; // [487] 552
    }
    _29603 = NOVALUE;

    /** parser.e:2556				if sign = -1 then*/
    if (_sign_59148 != -1)
    goto L13; // [493] 507

    /** parser.e:2557					CompileErr( EXPECTED_AN_ATOM_STRING_OR_A_CONSTANT_ASSIGNED_AN_ATOM_OR_A_STRING)*/
    RefDS(_22209);
    _49CompileErr(71, _22209, 0);
L13: 

    /** parser.e:2559				if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29606 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29606 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29607 = (object)*(((s1_ptr)_2)->base + _29606);
    _2 = (object)SEQ_PTR(_29607);
    _29608 = (object)*(((s1_ptr)_2)->base + 1);
    _29607 = NOVALUE;
    if (IS_SEQUENCE(_29608)){
            _29609 = SEQ_PTR(_29608)->length;
    }
    else {
        _29609 = 1;
    }
    _29608 = NOVALUE;
    if (_29609 != 0)
    goto L14; // [525] 539

    /** parser.e:2560					CompileErr( CASE_ELSE_CANNOT_BE_FIRST_CASE_IN_SWITCH)*/
    RefDS(_22209);
    _49CompileErr(44, _22209, 0);
L14: 

    /** parser.e:2562				case_else()*/
    _43case_else();

    /** parser.e:2563				exit*/
    goto L15; // [547] 789
    goto L16; // [549] 623
L12: 

    /** parser.e:2565			elsif fwd then*/
    if (_fwd_59161 == 0)
    {
        goto L17; // [554] 606
    }
    else{
    }

    /** parser.e:2566				integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31978);
    _31978 = 186;
    _fwdref_59243 = _42new_forward_reference(186, _fwd_59161, 186);
    _31978 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_59243)) {
        _1 = (object)(DBL_PTR(_fwdref_59243)->dbl);
        DeRefDS(_fwdref_59243);
        _fwdref_59243 = _1;
    }

    /** parser.e:2567				add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _fwdref_59243;
    _29612 = MAKE_SEQ(_1);
    _43add_case(_29612, _sign_59148);
    _29612 = NOVALUE;

    /** parser.e:2568				fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29613 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29613 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29614 = (object)*(((s1_ptr)_2)->base + _29613);
    _2 = (object)SEQ_PTR(_29614);
    _29615 = (object)*(((s1_ptr)_2)->base + 4);
    _29614 = NOVALUE;
    Ref(_29615);
    _42set_data(_fwdref_59243, _29615);
    _29615 = NOVALUE;
    goto L16; // [603] 623
L17: 

    /** parser.e:2571				condition = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _condition_59106 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_59106)){
        _condition_59106 = (object)DBL_PTR(_condition_59106)->dbl;
    }

    /** parser.e:2572				add_case( condition, sign )*/
    _43add_case(_condition_59106, _sign_59148);
L16: 

    /** parser.e:2575			tok = next_token()*/
    _0 = _tok_59104;
    _tok_59104 = _43next_token();
    DeRef(_0);

    /** parser.e:2576			if tok[T_ID] = THEN then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29618 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29618, 410)){
        _29618 = NOVALUE;
        goto L18; // [638] 742
    }
    _29618 = NOVALUE;

    /** parser.e:2577				tok = next_token()*/
    _0 = _tok_59104;
    _tok_59104 = _43next_token();
    DeRef(_0);

    /** parser.e:2579				if tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29621 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29621, 186)){
        _29621 = NOVALUE;
        goto L19; // [657] 727
    }
    _29621 = NOVALUE;

    /** parser.e:2580					if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29623 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29623 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29624 = (object)*(((s1_ptr)_2)->base + _29623);
    _2 = (object)SEQ_PTR(_29624);
    _29625 = (object)*(((s1_ptr)_2)->base + 5);
    _29624 = NOVALUE;
    if (_29625 == 0) {
        _29625 = NOVALUE;
        goto L1A; // [676] 691
    }
    else {
        if (!IS_ATOM_INT(_29625) && DBL_PTR(_29625)->dbl == 0.0){
            _29625 = NOVALUE;
            goto L1A; // [676] 691
        }
        _29625 = NOVALUE;
    }
    _29625 = NOVALUE;

    /** parser.e:2581						start_line = line_number*/
    _start_line_59136 = _27line_number_20572;
    goto L1B; // [688] 782
L1A: 

    /** parser.e:2583						putback( tok )*/
    Ref(_tok_59104);
    _43putback(_tok_59104);

    /** parser.e:2584						Warning(220, empty_case_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _29626 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_29626);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29626;
    ((intptr_t *)_2)[2] = _start_line_59136;
    _29627 = MAKE_SEQ(_1);
    _29626 = NOVALUE;
    _49Warning(220, 2048, _29627);
    _29627 = NOVALUE;

    /** parser.e:2586						exit*/
    goto L15; // [721] 789
    goto L1B; // [724] 782
L19: 

    /** parser.e:2589					putback( tok )*/
    Ref(_tok_59104);
    _43putback(_tok_59104);

    /** parser.e:2590					exit*/
    goto L15; // [736] 789
    goto L1B; // [739] 782
L18: 

    /** parser.e:2593			elsif tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29628 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29628, -30)){
        _29628 = NOVALUE;
        goto L1C; // [752] 781
    }
    _29628 = NOVALUE;

    /** parser.e:2594				CompileErr(EXPECTED_THEN_OR__NOT_1,{LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_59104);
    _29630 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_29630);
    RefDS(_26621);
    _29631 = _45LexName(_29630, _26621);
    _29630 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _29631;
    _29632 = MAKE_SEQ(_1);
    _29631 = NOVALUE;
    _49CompileErr(66, _29632, 0);
    _29632 = NOVALUE;
L1C: 
L1B: 

    /** parser.e:2597		end while*/
    goto L4; // [786] 142
L15: 

    /** parser.e:2598		StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:2599		emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29633 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29633 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29634 = (object)*(((s1_ptr)_2)->base + _29633);
    _2 = (object)SEQ_PTR(_29634);
    _29635 = (object)*(((s1_ptr)_2)->base + 6);
    _29634 = NOVALUE;
    Ref(_29635);
    _45emit_temp(_29635, 1);
    _29635 = NOVALUE;

    /** parser.e:2600		flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:2601	end procedure*/
    DeRef(_tok_59104);
    DeRef(_29564);
    _29564 = NOVALUE;
    _29558 = NOVALUE;
    _29608 = NOVALUE;
    return;
    ;
}


void _43Fallthru_statement()
{
    object _29636 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2604		if not in_switch() then*/
    _29636 = _43in_switch();
    if (IS_ATOM_INT(_29636)) {
        if (_29636 != 0){
            DeRef(_29636);
            _29636 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    else {
        if (DBL_PTR(_29636)->dbl != 0.0){
            DeRef(_29636);
            _29636 = NOVALUE;
            goto L1; // [6] 19
        }
    }
    DeRef(_29636);
    _29636 = NOVALUE;

    /** parser.e:2605			CompileErr( A_FALLTHRU_MUST_BE_INSIDE_A_SWITCH)*/
    RefDS(_22209);
    _49CompileErr(22, _22209, 0);
L1: 

    /** parser.e:2607		tok_match( CASE )*/
    _43tok_match(186, 0);

    /** parser.e:2608		fallthru_case = 1*/
    _43fallthru_case_59100 = 1;

    /** parser.e:2609		Case_statement()*/
    _43Case_statement();

    /** parser.e:2610	end procedure*/
    return;
    ;
}


void _43update_translator_info(object _sym_59311, object _all_ints_59312, object _has_integer_59313, object _has_atom_59314, object _has_sequence_59315)
{
    object _29661 = NOVALUE;
    object _29659 = NOVALUE;
    object _29657 = NOVALUE;
    object _29655 = NOVALUE;
    object _29653 = NOVALUE;
    object _29652 = NOVALUE;
    object _29650 = NOVALUE;
    object _29648 = NOVALUE;
    object _29647 = NOVALUE;
    object _29646 = NOVALUE;
    object _29645 = NOVALUE;
    object _29644 = NOVALUE;
    object _29642 = NOVALUE;
    object _29640 = NOVALUE;
    object _29638 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2615		SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3;
    DeRef(_1);
    _29638 = NOVALUE;

    /** parser.e:2616		SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _29640 = NOVALUE;

    /** parser.e:2617		SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29644 = (object)*(((s1_ptr)_2)->base + _sym_59311);
    _2 = (object)SEQ_PTR(_29644);
    _29645 = (object)*(((s1_ptr)_2)->base + 1);
    _29644 = NOVALUE;
    if (IS_SEQUENCE(_29645)){
            _29646 = SEQ_PTR(_29645)->length;
    }
    else {
        _29646 = 1;
    }
    _29645 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29646;
    if( _1 != _29646 ){
        DeRef(_1);
    }
    _29646 = NOVALUE;
    _29642 = NOVALUE;

    /** parser.e:2619		if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29647 = (object)*(((s1_ptr)_2)->base + _sym_59311);
    _2 = (object)SEQ_PTR(_29647);
    _29648 = (object)*(((s1_ptr)_2)->base + 32);
    _29647 = NOVALUE;
    if (binary_op_a(LESSEQ, _29648, 0)){
        _29648 = NOVALUE;
        goto L1; // [89] 198
    }
    _29648 = NOVALUE;

    /** parser.e:2620			if all_ints then*/
    if (_all_ints_59312 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** parser.e:2621				SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _29650 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** parser.e:2623			elsif has_atom + has_sequence + has_integer > 1 then*/
    _29652 = _has_atom_59314 + _has_sequence_59315;
    if ((object)((uintptr_t)_29652 + (uintptr_t)HIGH_BITS) >= 0){
        _29652 = NewDouble((eudouble)_29652);
    }
    if (IS_ATOM_INT(_29652)) {
        _29653 = _29652 + _has_integer_59313;
        if ((object)((uintptr_t)_29653 + (uintptr_t)HIGH_BITS) >= 0){
            _29653 = NewDouble((eudouble)_29653);
        }
    }
    else {
        _29653 = NewDouble(DBL_PTR(_29652)->dbl + (eudouble)_has_integer_59313);
    }
    DeRef(_29652);
    _29652 = NOVALUE;
    if (binary_op_a(LESSEQ, _29653, 1)){
        DeRef(_29653);
        _29653 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29653);
    _29653 = NOVALUE;

    /** parser.e:2624				SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _29655 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** parser.e:2626			elsif has_atom then*/
    if (_has_atom_59314 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** parser.e:2627				SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _29657 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** parser.e:2630				SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8;
    DeRef(_1);
    _29659 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** parser.e:2634			SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_59311 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _29661 = NOVALUE;
L3: 

    /** parser.e:2636	end procedure*/
    _29645 = NOVALUE;
    return;
    ;
}


void _43optimize_switch(object _switch_pc_59376, object _else_bp_59377, object _cases_59378, object _jump_table_59379)
{
    object _values_59380 = NOVALUE;
    object _min_59384 = NOVALUE;
    object _max_59386 = NOVALUE;
    object _all_ints_59388 = NOVALUE;
    object _has_integer_59389 = NOVALUE;
    object _has_atom_59390 = NOVALUE;
    object _has_sequence_59391 = NOVALUE;
    object _has_unassigned_59392 = NOVALUE;
    object _has_fwdref_59393 = NOVALUE;
    object _unique_values_59394 = NOVALUE;
    object _unique_jumps_59396 = NOVALUE;
    object _new_1__tmp_at74_59399 = NOVALUE;
    object _new_inlined_new_at_74_59398 = NOVALUE;
    object _jump_59400 = NOVALUE;
    object _jump_offset_59404 = NOVALUE;
    object _sym_59411 = NOVALUE;
    object _sign_59413 = NOVALUE;
    object _value_i_59426 = NOVALUE;
    object _v_59450 = NOVALUE;
    object _else_target_59536 = NOVALUE;
    object _opcode_59539 = NOVALUE;
    object _delta_59545 = NOVALUE;
    object _switch_table_59555 = NOVALUE;
    object _offset_59558 = NOVALUE;
    object _29775 = NOVALUE;
    object _29774 = NOVALUE;
    object _29773 = NOVALUE;
    object _29772 = NOVALUE;
    object _29770 = NOVALUE;
    object _29768 = NOVALUE;
    object _29765 = NOVALUE;
    object _29764 = NOVALUE;
    object _29763 = NOVALUE;
    object _29762 = NOVALUE;
    object _29761 = NOVALUE;
    object _29760 = NOVALUE;
    object _29759 = NOVALUE;
    object _29756 = NOVALUE;
    object _29755 = NOVALUE;
    object _29754 = NOVALUE;
    object _29753 = NOVALUE;
    object _29752 = NOVALUE;
    object _29751 = NOVALUE;
    object _29747 = NOVALUE;
    object _29746 = NOVALUE;
    object _29744 = NOVALUE;
    object _29743 = NOVALUE;
    object _29742 = NOVALUE;
    object _29741 = NOVALUE;
    object _29740 = NOVALUE;
    object _29739 = NOVALUE;
    object _29738 = NOVALUE;
    object _29737 = NOVALUE;
    object _29736 = NOVALUE;
    object _29735 = NOVALUE;
    object _29733 = NOVALUE;
    object _29732 = NOVALUE;
    object _29728 = NOVALUE;
    object _29726 = NOVALUE;
    object _29725 = NOVALUE;
    object _29724 = NOVALUE;
    object _29722 = NOVALUE;
    object _29719 = NOVALUE;
    object _29718 = NOVALUE;
    object _29717 = NOVALUE;
    object _29715 = NOVALUE;
    object _29714 = NOVALUE;
    object _29713 = NOVALUE;
    object _29711 = NOVALUE;
    object _29710 = NOVALUE;
    object _29709 = NOVALUE;
    object _29707 = NOVALUE;
    object _29706 = NOVALUE;
    object _29705 = NOVALUE;
    object _29703 = NOVALUE;
    object _29700 = NOVALUE;
    object _29699 = NOVALUE;
    object _29698 = NOVALUE;
    object _29697 = NOVALUE;
    object _29696 = NOVALUE;
    object _29695 = NOVALUE;
    object _29694 = NOVALUE;
    object _29693 = NOVALUE;
    object _29692 = NOVALUE;
    object _29691 = NOVALUE;
    object _29690 = NOVALUE;
    object _29689 = NOVALUE;
    object _29686 = NOVALUE;
    object _29685 = NOVALUE;
    object _29684 = NOVALUE;
    object _29682 = NOVALUE;
    object _29681 = NOVALUE;
    object _29679 = NOVALUE;
    object _29678 = NOVALUE;
    object _29677 = NOVALUE;
    object _29673 = NOVALUE;
    object _29672 = NOVALUE;
    object _29671 = NOVALUE;
    object _29669 = NOVALUE;
    object _29668 = NOVALUE;
    object _29664 = NOVALUE;
    object _29663 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2641		sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29663 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29663 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29664 = (object)*(((s1_ptr)_2)->base + _29663);
    DeRef(_values_59380);
    _2 = (object)SEQ_PTR(_29664);
    _values_59380 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_values_59380);
    _29664 = NOVALUE;

    /** parser.e:2642		atom min =  1e+300*/
    RefDS(_29666);
    DeRef(_min_59384);
    _min_59384 = _29666;

    /** parser.e:2643		atom max = -1e+300*/
    RefDS(_29667);
    DeRef(_max_59386);
    _max_59386 = _29667;

    /** parser.e:2644		integer all_ints = 1*/
    _all_ints_59388 = 1;

    /** parser.e:2645		integer has_integer    = 0*/
    _has_integer_59389 = 0;

    /** parser.e:2646		integer has_atom       = 0*/
    _has_atom_59390 = 0;

    /** parser.e:2647		integer has_sequence   = 0*/
    _has_sequence_59391 = 0;

    /** parser.e:2648		integer has_unassigned = 0*/
    _has_unassigned_59392 = 0;

    /** parser.e:2649		integer has_fwdref     = 0*/
    _has_fwdref_59393 = 0;

    /** parser.e:2650		sequence unique_values = {}*/
    RefDS(_22209);
    DeRef(_unique_values_59394);
    _unique_values_59394 = _22209;

    /** parser.e:2651		map unique_jumps = map:new()*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at74_59399;
    _new_1__tmp_at74_59399 = _34new_map_seq(8);
    DeRef(_0);
    Ref(_new_1__tmp_at74_59399);
    _0 = _unique_jumps_59396;
    _unique_jumps_59396 = _35malloc(_new_1__tmp_at74_59399, 1);
    DeRef(_0);
    DeRef(_new_1__tmp_at74_59399);
    _new_1__tmp_at74_59399 = NOVALUE;

    /** parser.e:2653		sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29668 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29668 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29669 = (object)*(((s1_ptr)_2)->base + _29668);
    DeRef(_jump_59400);
    _2 = (object)SEQ_PTR(_29669);
    _jump_59400 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_59400);
    _29669 = NOVALUE;

    /** parser.e:2654		integer jump_offset = 0*/
    _jump_offset_59404 = 0;

    /** parser.e:2655		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_59380)){
            _29671 = SEQ_PTR(_values_59380)->length;
    }
    else {
        _29671 = 1;
    }
    {
        object _i_59406;
        _i_59406 = 1;
L1: 
        if (_i_59406 > _29671){
            goto L2; // [116] 586
        }

        /** parser.e:2656			if sequence( values[i] ) then*/
        _2 = (object)SEQ_PTR(_values_59380);
        _29672 = (object)*(((s1_ptr)_2)->base + _i_59406);
        _29673 = IS_SEQUENCE(_29672);
        _29672 = NOVALUE;
        if (_29673 == 0)
        {
            _29673 = NOVALUE;
            goto L3; // [132] 145
        }
        else{
            _29673 = NOVALUE;
        }

        /** parser.e:2657				has_fwdref = 1*/
        _has_fwdref_59393 = 1;

        /** parser.e:2658				exit*/
        goto L2; // [142] 586
L3: 

        /** parser.e:2660			integer sym = values[i]*/
        _2 = (object)SEQ_PTR(_values_59380);
        _sym_59411 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (!IS_ATOM_INT(_sym_59411))
        _sym_59411 = (object)DBL_PTR(_sym_59411)->dbl;

        /** parser.e:2661			integer sign*/

        /** parser.e:2663			if sym < 0 then*/
        if (_sym_59411 >= 0)
        goto L4; // [155] 174

        /** parser.e:2664				sign = -1*/
        _sign_59413 = -1;

        /** parser.e:2665				sym = -sym*/
        _sym_59411 = - _sym_59411;
        goto L5; // [171] 180
L4: 

        /** parser.e:2667				sign = 1*/
        _sign_59413 = 1;
L5: 

        /** parser.e:2669			if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29677 = (object)*(((s1_ptr)_2)->base + _sym_59411);
        _2 = (object)SEQ_PTR(_29677);
        _29678 = (object)*(((s1_ptr)_2)->base + 1);
        _29677 = NOVALUE;
        if (_29678 == _27NOVALUE_20426)
        _29679 = 1;
        else if (IS_ATOM_INT(_29678) && IS_ATOM_INT(_27NOVALUE_20426))
        _29679 = 0;
        else
        _29679 = (compare(_29678, _27NOVALUE_20426) == 0);
        _29678 = NOVALUE;
        if (_29679 != 0)
        goto L6; // [200] 565
        _29679 = NOVALUE;

        /** parser.e:2670				object value_i = sign * SymTab[sym][S_OBJ]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29681 = (object)*(((s1_ptr)_2)->base + _sym_59411);
        _2 = (object)SEQ_PTR(_29681);
        _29682 = (object)*(((s1_ptr)_2)->base + 1);
        _29681 = NOVALUE;
        DeRef(_value_i_59426);
        if (IS_ATOM_INT(_29682)) {
            if (_sign_59413 == (short)_sign_59413 && _29682 <= INT15 && _29682 >= -INT15){
                _value_i_59426 = _sign_59413 * _29682;
            }
            else{
                _value_i_59426 = NewDouble(_sign_59413 * (eudouble)_29682);
            }
        }
        else {
            _value_i_59426 = binary_op(MULTIPLY, _sign_59413, _29682);
        }
        _29682 = NOVALUE;

        /** parser.e:2671				values[i] = value_i*/
        Ref(_value_i_59426);
        _2 = (object)SEQ_PTR(_values_59380);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _values_59380 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_59406);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _value_i_59426;
        DeRef(_1);

        /** parser.e:2672				if TRANSLATE then*/
        if (_27TRANSLATE_20179 == 0)
        {
            goto L7; // [233] 274
        }
        else{
        }

        /** parser.e:2673					if Code[jump[i]-2] = CASE then*/
        _2 = (object)SEQ_PTR(_jump_59400);
        _29684 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (IS_ATOM_INT(_29684)) {
            _29685 = _29684 - 2;
        }
        else {
            _29685 = binary_op(MINUS, _29684, 2);
        }
        _29684 = NOVALUE;
        _2 = (object)SEQ_PTR(_27Code_20660);
        if (!IS_ATOM_INT(_29685)){
            _29686 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_29685)->dbl));
        }
        else{
            _29686 = (object)*(((s1_ptr)_2)->base + _29685);
        }
        if (binary_op_a(NOTEQ, _29686, 186)){
            _29686 = NOVALUE;
            goto L8; // [254] 267
        }
        _29686 = NOVALUE;

        /** parser.e:2674						jump_offset -=2*/
        _jump_offset_59404 = _jump_offset_59404 - 2;
        goto L9; // [264] 273
L8: 

        /** parser.e:2676						jump_offset = 0*/
        _jump_offset_59404 = 0;
L9: 
L7: 

        /** parser.e:2680				if find( value_i, map:get( unique_jumps, jump[i] + jump_offset, {}) ) then*/
        _2 = (object)SEQ_PTR(_jump_59400);
        _29689 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (IS_ATOM_INT(_29689)) {
            _29690 = _29689 + _jump_offset_59404;
            if ((object)((uintptr_t)_29690 + (uintptr_t)HIGH_BITS) >= 0){
                _29690 = NewDouble((eudouble)_29690);
            }
        }
        else {
            _29690 = binary_op(PLUS, _29689, _jump_offset_59404);
        }
        _29689 = NOVALUE;
        Ref(_unique_jumps_59396);
        RefDS(_22209);
        _29691 = _34get(_unique_jumps_59396, _29690, _22209);
        _29690 = NOVALUE;
        _29692 = find_from(_value_i_59426, _29691, 1);
        DeRef(_29691);
        _29691 = NOVALUE;
        if (_29692 == 0)
        {
            _29692 = NOVALUE;
            goto LA; // [295] 301
        }
        else{
            _29692 = NOVALUE;
        }
        goto LB; // [298] 560
LA: 

        /** parser.e:2683				elsif find( value_i, unique_values ) then*/
        _29693 = find_from(_value_i_59426, _unique_values_59394, 1);
        if (_29693 == 0)
        {
            _29693 = NOVALUE;
            goto LC; // [308] 467
        }
        else{
            _29693 = NOVALUE;
        }

        /** parser.e:2686					object v = ""*/
        RefDS(_22209);
        DeRef(_v_59450);
        _v_59450 = _22209;

        /** parser.e:2687					if length( SymTab[sym] ) > S_NAME and sequence( sym_name( sym ) ) then*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _29694 = (object)*(((s1_ptr)_2)->base + _sym_59411);
        if (IS_SEQUENCE(_29694)){
                _29695 = SEQ_PTR(_29694)->length;
        }
        else {
            _29695 = 1;
        }
        _29694 = NOVALUE;
        if (IS_ATOM_INT(_27S_NAME_20209)) {
            _29696 = (_29695 > _27S_NAME_20209);
        }
        else {
            _29696 = binary_op(GREATER, _29695, _27S_NAME_20209);
        }
        _29695 = NOVALUE;
        if (IS_ATOM_INT(_29696)) {
            if (_29696 == 0) {
                goto LD; // [333] 359
            }
        }
        else {
            if (DBL_PTR(_29696)->dbl == 0.0) {
                goto LD; // [333] 359
            }
        }
        _29698 = _53sym_name(_sym_59411);
        _29699 = IS_SEQUENCE(_29698);
        DeRef(_29698);
        _29698 = NOVALUE;
        if (_29699 == 0)
        {
            _29699 = NOVALUE;
            goto LD; // [345] 359
        }
        else{
            _29699 = NOVALUE;
        }

        /** parser.e:2688						v = sym_name( sym ) & " = " */
        _29700 = _53sym_name(_sym_59411);
        if (IS_SEQUENCE(_29700) && IS_ATOM(_29701)) {
        }
        else if (IS_ATOM(_29700) && IS_SEQUENCE(_29701)) {
            Ref(_29700);
            Prepend(&_v_59450, _29701, _29700);
        }
        else {
            Concat((object_ptr)&_v_59450, _29700, _29701);
            DeRef(_29700);
            _29700 = NOVALUE;
        }
        DeRef(_29700);
        _29700 = NOVALUE;
LD: 

        /** parser.e:2691					v &= sprint( value_i )*/
        Ref(_value_i_59426);
        _29703 = _12sprint(_value_i_59426);
        if (IS_SEQUENCE(_v_59450) && IS_ATOM(_29703)) {
            Ref(_29703);
            Append(&_v_59450, _v_59450, _29703);
        }
        else if (IS_ATOM(_v_59450) && IS_SEQUENCE(_29703)) {
            Ref(_v_59450);
            Prepend(&_v_59450, _29703, _v_59450);
        }
        else {
            Concat((object_ptr)&_v_59450, _v_59450, _29703);
        }
        DeRef(_29703);
        _29703 = NOVALUE;

        /** parser.e:2692					ThisLine        = switch_stack[$][SWITCH_THISLINE][i]*/
        if (IS_SEQUENCE(_43switch_stack_55654)){
                _29705 = SEQ_PTR(_43switch_stack_55654)->length;
        }
        else {
            _29705 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55654);
        _29706 = (object)*(((s1_ptr)_2)->base + _29705);
        _2 = (object)SEQ_PTR(_29706);
        _29707 = (object)*(((s1_ptr)_2)->base + 10);
        _29706 = NOVALUE;
        DeRef(_49ThisLine_49642);
        _2 = (object)SEQ_PTR(_29707);
        _49ThisLine_49642 = (object)*(((s1_ptr)_2)->base + _i_59406);
        Ref(_49ThisLine_49642);
        _29707 = NOVALUE;

        /** parser.e:2693					bp              = switch_stack[$][SWITCH_BP][i]*/
        if (IS_SEQUENCE(_43switch_stack_55654)){
                _29709 = SEQ_PTR(_43switch_stack_55654)->length;
        }
        else {
            _29709 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55654);
        _29710 = (object)*(((s1_ptr)_2)->base + _29709);
        _2 = (object)SEQ_PTR(_29710);
        _29711 = (object)*(((s1_ptr)_2)->base + 11);
        _29710 = NOVALUE;
        _2 = (object)SEQ_PTR(_29711);
        _49bp_49646 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (!IS_ATOM_INT(_49bp_49646)){
            _49bp_49646 = (object)DBL_PTR(_49bp_49646)->dbl;
        }
        _29711 = NOVALUE;

        /** parser.e:2694					line_number     = switch_stack[$][SWITCH_LINE_NUMBER][i]*/
        if (IS_SEQUENCE(_43switch_stack_55654)){
                _29713 = SEQ_PTR(_43switch_stack_55654)->length;
        }
        else {
            _29713 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55654);
        _29714 = (object)*(((s1_ptr)_2)->base + _29713);
        _2 = (object)SEQ_PTR(_29714);
        _29715 = (object)*(((s1_ptr)_2)->base + 12);
        _29714 = NOVALUE;
        _2 = (object)SEQ_PTR(_29715);
        _27line_number_20572 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (!IS_ATOM_INT(_27line_number_20572)){
            _27line_number_20572 = (object)DBL_PTR(_27line_number_20572)->dbl;
        }
        _29715 = NOVALUE;

        /** parser.e:2695					current_file_no = switch_stack[$][SWITCH_CURRENT_FILE_NO][i]*/
        if (IS_SEQUENCE(_43switch_stack_55654)){
                _29717 = SEQ_PTR(_43switch_stack_55654)->length;
        }
        else {
            _29717 = 1;
        }
        _2 = (object)SEQ_PTR(_43switch_stack_55654);
        _29718 = (object)*(((s1_ptr)_2)->base + _29717);
        _2 = (object)SEQ_PTR(_29718);
        _29719 = (object)*(((s1_ptr)_2)->base + 13);
        _29718 = NOVALUE;
        _2 = (object)SEQ_PTR(_29719);
        _27current_file_no_20571 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (!IS_ATOM_INT(_27current_file_no_20571)){
            _27current_file_no_20571 = (object)DBL_PTR(_27current_file_no_20571)->dbl;
        }
        _29719 = NOVALUE;

        /** parser.e:2697					CompileErr("duplicate case value used in switch: [1]", {v})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_v_59450);
        ((intptr_t*)_2)[1] = _v_59450;
        _29722 = MAKE_SEQ(_1);
        RefDS(_29721);
        _49CompileErr(_29721, _29722, 0);
        _29722 = NOVALUE;
        DeRefDS(_v_59450);
        _v_59450 = NOVALUE;
        goto LB; // [464] 560
LC: 

        /** parser.e:2700					unique_values   &= value_i*/
        if (IS_SEQUENCE(_unique_values_59394) && IS_ATOM(_value_i_59426)) {
            Ref(_value_i_59426);
            Append(&_unique_values_59394, _unique_values_59394, _value_i_59426);
        }
        else if (IS_ATOM(_unique_values_59394) && IS_SEQUENCE(_value_i_59426)) {
        }
        else {
            Concat((object_ptr)&_unique_values_59394, _unique_values_59394, _value_i_59426);
        }

        /** parser.e:2701					map:put( unique_jumps, jump[i] + jump_offset, value_i, map:APPEND )*/
        _2 = (object)SEQ_PTR(_jump_59400);
        _29724 = (object)*(((s1_ptr)_2)->base + _i_59406);
        if (IS_ATOM_INT(_29724)) {
            _29725 = _29724 + _jump_offset_59404;
            if ((object)((uintptr_t)_29725 + (uintptr_t)HIGH_BITS) >= 0){
                _29725 = NewDouble((eudouble)_29725);
            }
        }
        else {
            _29725 = binary_op(PLUS, _29724, _jump_offset_59404);
        }
        _29724 = NOVALUE;
        Ref(_unique_jumps_59396);
        Ref(_value_i_59426);
        _34put(_unique_jumps_59396, _29725, _value_i_59426, 6, 0);
        _29725 = NOVALUE;

        /** parser.e:2703					if not is_integer( value_i ) then*/
        Ref(_value_i_59426);
        _29726 = _27is_integer(_value_i_59426);
        if (IS_ATOM_INT(_29726)) {
            if (_29726 != 0){
                DeRef(_29726);
                _29726 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        else {
            if (DBL_PTR(_29726)->dbl != 0.0){
                DeRef(_29726);
                _29726 = NOVALUE;
                goto LE; // [496] 529
            }
        }
        DeRef(_29726);
        _29726 = NOVALUE;

        /** parser.e:2704						all_ints = 0*/
        _all_ints_59388 = 0;

        /** parser.e:2705						if atom( value_i ) then*/
        _29728 = IS_ATOM(_value_i_59426);
        if (_29728 == 0)
        {
            _29728 = NOVALUE;
            goto LF; // [509] 520
        }
        else{
            _29728 = NOVALUE;
        }

        /** parser.e:2706							has_atom = 1*/
        _has_atom_59390 = 1;
        goto L10; // [517] 559
LF: 

        /** parser.e:2708							has_sequence = 1*/
        _has_sequence_59391 = 1;
        goto L10; // [526] 559
LE: 

        /** parser.e:2711						has_integer = 1*/
        _has_integer_59389 = 1;

        /** parser.e:2713						if value_i < min then*/
        if (binary_op_a(GREATEREQ, _value_i_59426, _min_59384)){
            goto L11; // [536] 546
        }

        /** parser.e:2714							min = value_i*/
        Ref(_value_i_59426);
        DeRef(_min_59384);
        _min_59384 = _value_i_59426;
L11: 

        /** parser.e:2717						if value_i > max then*/
        if (binary_op_a(LESSEQ, _value_i_59426, _max_59386)){
            goto L12; // [548] 558
        }

        /** parser.e:2718							max = value_i*/
        Ref(_value_i_59426);
        DeRef(_max_59386);
        _max_59386 = _value_i_59426;
L12: 
L10: 
LB: 
        DeRef(_value_i_59426);
        _value_i_59426 = NOVALUE;
        goto L13; // [562] 577
L6: 

        /** parser.e:2723				has_unassigned = 1*/
        _has_unassigned_59392 = 1;

        /** parser.e:2724				exit*/
        goto L2; // [574] 586
L13: 

        /** parser.e:2726		end for*/
        _i_59406 = _i_59406 + 1;
        goto L1; // [581] 123
L2: 
        ;
    }

    /** parser.e:2728		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59392 != 0) {
        goto L14; // [588] 597
    }
    if (_has_fwdref_59393 == 0)
    {
        goto L15; // [593] 615
    }
    else{
    }
L14: 

    /** parser.e:2729			values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29732 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29732 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29733 = (object)*(((s1_ptr)_2)->base + _29732);
    DeRef(_values_59380);
    _2 = (object)SEQ_PTR(_29733);
    _values_59380 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_values_59380);
    _29733 = NOVALUE;
L15: 

    /** parser.e:2732		if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29735 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29735 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29736 = (object)*(((s1_ptr)_2)->base + _29735);
    _2 = (object)SEQ_PTR(_29736);
    _29737 = (object)*(((s1_ptr)_2)->base + 3);
    _29736 = NOVALUE;
    if (_29737 == 0) {
        _29737 = NOVALUE;
        goto L16; // [630] 657
    }
    else {
        if (!IS_ATOM_INT(_29737) && DBL_PTR(_29737)->dbl == 0.0){
            _29737 = NOVALUE;
            goto L16; // [630] 657
        }
        _29737 = NOVALUE;
    }
    _29737 = NOVALUE;

    /** parser.e:2733				Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29738 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29738 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29739 = (object)*(((s1_ptr)_2)->base + _29738);
    _2 = (object)SEQ_PTR(_29739);
    _29740 = (object)*(((s1_ptr)_2)->base + 3);
    _29739 = NOVALUE;
    Ref(_29740);
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_59377);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29740;
    if( _1 != _29740 ){
        DeRef(_1);
    }
    _29740 = NOVALUE;
    goto L17; // [654] 681
L16: 

    /** parser.e:2736			Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29741 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29741 = 1;
    }
    _29742 = _29741 + 1;
    _29741 = NOVALUE;
    _29743 = _29742 + _27TRANSLATE_20179;
    _29742 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _else_bp_59377);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29743;
    if( _1 != _29743 ){
        DeRef(_1);
    }
    _29743 = NOVALUE;
L17: 

    /** parser.e:2739		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L18; // [685] 712
    }
    else{
    }

    /** parser.e:2744			SymTab[cases][S_OBJ] &= 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_59378 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _29746 = (object)*(((s1_ptr)_2)->base + 1);
    _29744 = NOVALUE;
    if (IS_SEQUENCE(_29746) && IS_ATOM(0)) {
        Append(&_29747, _29746, 0);
    }
    else if (IS_ATOM(_29746) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29747, _29746, 0);
        _29746 = NOVALUE;
    }
    _29746 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29747;
    if( _1 != _29747 ){
        DeRef(_1);
    }
    _29747 = NOVALUE;
    _29744 = NOVALUE;
L18: 

    /** parser.e:2748		integer else_target = Code[else_bp]*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    _else_target_59536 = (object)*(((s1_ptr)_2)->base + _else_bp_59377);
    if (!IS_ATOM_INT(_else_target_59536)){
        _else_target_59536 = (object)DBL_PTR(_else_target_59536)->dbl;
    }

    /** parser.e:2749		integer opcode = SWITCH*/
    _opcode_59539 = 185;

    /** parser.e:2750		if has_unassigned or has_fwdref then*/
    if (_has_unassigned_59392 != 0) {
        goto L19; // [733] 742
    }
    if (_has_fwdref_59393 == 0)
    {
        goto L1A; // [738] 754
    }
    else{
    }
L19: 

    /** parser.e:2751			opcode = SWITCH_RT*/
    _opcode_59539 = 202;
    goto L1B; // [751] 907
L1A: 

    /** parser.e:2753		elsif all_ints then*/
    if (_all_ints_59388 == 0)
    {
        goto L1C; // [756] 904
    }
    else{
    }

    /** parser.e:2754			atom delta = max - min*/
    DeRef(_delta_59545);
    if (IS_ATOM_INT(_max_59386) && IS_ATOM_INT(_min_59384)) {
        _delta_59545 = _max_59386 - _min_59384;
        if ((object)((uintptr_t)_delta_59545 +(uintptr_t) HIGH_BITS) >= 0){
            _delta_59545 = NewDouble((eudouble)_delta_59545);
        }
    }
    else {
        if (IS_ATOM_INT(_max_59386)) {
            _delta_59545 = NewDouble((eudouble)_max_59386 - DBL_PTR(_min_59384)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_59384)) {
                _delta_59545 = NewDouble(DBL_PTR(_max_59386)->dbl - (eudouble)_min_59384);
            }
            else
            _delta_59545 = NewDouble(DBL_PTR(_max_59386)->dbl - DBL_PTR(_min_59384)->dbl);
        }
    }

    /** parser.e:2755			if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29751 = (_27TRANSLATE_20179 == 0);
    if (_29751 == 0) {
        _29752 = 0;
        goto L1D; // [772] 784
    }
    if (IS_ATOM_INT(_delta_59545)) {
        _29753 = (_delta_59545 < 1024);
    }
    else {
        _29753 = (DBL_PTR(_delta_59545)->dbl < (eudouble)1024);
    }
    _29752 = (_29753 != 0);
L1D: 
    if (_29752 == 0) {
        goto L1E; // [784] 893
    }
    if (IS_ATOM_INT(_delta_59545)) {
        _29755 = (_delta_59545 >= 0);
    }
    else {
        _29755 = (DBL_PTR(_delta_59545)->dbl >= (eudouble)0);
    }
    if (_29755 == 0)
    {
        DeRef(_29755);
        _29755 = NOVALUE;
        goto L1E; // [793] 893
    }
    else{
        DeRef(_29755);
        _29755 = NOVALUE;
    }

    /** parser.e:2756				opcode = SWITCH_SPI*/
    _opcode_59539 = 192;

    /** parser.e:2758				sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_59545)) {
        _29756 = _delta_59545 + 1;
    }
    else
    _29756 = binary_op(PLUS, 1, _delta_59545);
    DeRef(_switch_table_59555);
    _switch_table_59555 = Repeat(_else_target_59536, _29756);
    DeRef(_29756);
    _29756 = NOVALUE;

    /** parser.e:2759				integer offset = min - 1*/
    if (IS_ATOM_INT(_min_59384)) {
        _offset_59558 = _min_59384 - 1;
    }
    else {
        _offset_59558 = NewDouble(DBL_PTR(_min_59384)->dbl - (eudouble)1);
    }
    if (!IS_ATOM_INT(_offset_59558)) {
        _1 = (object)(DBL_PTR(_offset_59558)->dbl);
        DeRefDS(_offset_59558);
        _offset_59558 = _1;
    }

    /** parser.e:2760				for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_59380)){
            _29759 = SEQ_PTR(_values_59380)->length;
    }
    else {
        _29759 = 1;
    }
    {
        object _i_59561;
        _i_59561 = 1;
L1F: 
        if (_i_59561 > _29759){
            goto L20; // [828] 860
        }

        /** parser.e:2761					switch_table[values[i] - offset] = jump[i]*/
        _2 = (object)SEQ_PTR(_values_59380);
        _29760 = (object)*(((s1_ptr)_2)->base + _i_59561);
        if (IS_ATOM_INT(_29760)) {
            _29761 = _29760 - _offset_59558;
            if ((object)((uintptr_t)_29761 +(uintptr_t) HIGH_BITS) >= 0){
                _29761 = NewDouble((eudouble)_29761);
            }
        }
        else {
            _29761 = binary_op(MINUS, _29760, _offset_59558);
        }
        _29760 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_59400);
        _29762 = (object)*(((s1_ptr)_2)->base + _i_59561);
        Ref(_29762);
        _2 = (object)SEQ_PTR(_switch_table_59555);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _switch_table_59555 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29761))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_29761)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _29761);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _29762;
        if( _1 != _29762 ){
            DeRef(_1);
        }
        _29762 = NOVALUE;

        /** parser.e:2762				end for*/
        _i_59561 = _i_59561 + 1;
        goto L1F; // [855] 835
L20: 
        ;
    }

    /** parser.e:2763				Code[switch_pc + 2] = offset*/
    _29763 = _switch_pc_59376 + 2;
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29763);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _offset_59558;
    DeRef(_1);

    /** parser.e:2764				switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29764 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29764 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29764 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_59555);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_table_59555;
    DeRef(_1);
    _29765 = NOVALUE;
    DeRefDS(_switch_table_59555);
    _switch_table_59555 = NOVALUE;
    goto L21; // [890] 903
L1E: 

    /** parser.e:2766				opcode = SWITCH_I*/
    _opcode_59539 = 193;
L21: 
L1C: 
    DeRef(_delta_59545);
    _delta_59545 = NOVALUE;
L1B: 

    /** parser.e:2770		Code[switch_pc] = opcode*/
    _2 = (object)SEQ_PTR(_27Code_20660);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _27Code_20660 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _switch_pc_59376);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _opcode_59539;
    DeRef(_1);

    /** parser.e:2771		if opcode != SWITCH_SPI then*/
    if (_opcode_59539 == 192)
    goto L22; // [919] 956

    /** parser.e:2772			SymTab[cases][S_OBJ] = values*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cases_59378 + ((s1_ptr)_2)->base);
    RefDS(_values_59380);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _values_59380;
    DeRef(_1);
    _29768 = NOVALUE;

    /** parser.e:2773			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L23; // [942] 955
    }
    else{
    }

    /** parser.e:2774				update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _43update_translator_info(_cases_59378, _all_ints_59388, _has_integer_59389, _has_atom_59390, _has_sequence_59391);
L23: 
L22: 

    /** parser.e:2779		SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_59379 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29772 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29772 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29773 = (object)*(((s1_ptr)_2)->base + _29772);
    _2 = (object)SEQ_PTR(_29773);
    _29774 = (object)*(((s1_ptr)_2)->base + 2);
    _29773 = NOVALUE;
    if (IS_ATOM_INT(_29774)) {
        _29775 = _29774 - _switch_pc_59376;
        if ((object)((uintptr_t)_29775 +(uintptr_t) HIGH_BITS) >= 0){
            _29775 = NewDouble((eudouble)_29775);
        }
    }
    else {
        _29775 = binary_op(MINUS, _29774, _switch_pc_59376);
    }
    _29774 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29775;
    if( _1 != _29775 ){
        DeRef(_1);
    }
    _29775 = NOVALUE;
    _29770 = NOVALUE;

    /** parser.e:2781	end procedure*/
    DeRef(_values_59380);
    DeRef(_min_59384);
    DeRef(_max_59386);
    DeRef(_unique_values_59394);
    DeRef(_unique_jumps_59396);
    DeRef(_jump_59400);
    DeRef(_29751);
    _29751 = NOVALUE;
    DeRef(_29763);
    _29763 = NOVALUE;
    DeRef(_29753);
    _29753 = NOVALUE;
    DeRef(_29696);
    _29696 = NOVALUE;
    DeRef(_29685);
    _29685 = NOVALUE;
    _29694 = NOVALUE;
    DeRef(_29761);
    _29761 = NOVALUE;
    return;
    ;
}


void _43Switch_statement()
{
    object _else_case_2__tmp_at250_59655 = NOVALUE;
    object _else_case_1__tmp_at250_59654 = NOVALUE;
    object _else_case_inlined_else_case_at_250_59653 = NOVALUE;
    object _break_base_59593 = NOVALUE;
    object _cases_59595 = NOVALUE;
    object _jump_table_59596 = NOVALUE;
    object _else_bp_59597 = NOVALUE;
    object _switch_pc_59598 = NOVALUE;
    object _t_59635 = NOVALUE;
    object _29806 = NOVALUE;
    object _29805 = NOVALUE;
    object _29804 = NOVALUE;
    object _29803 = NOVALUE;
    object _29802 = NOVALUE;
    object _29798 = NOVALUE;
    object _29794 = NOVALUE;
    object _29793 = NOVALUE;
    object _29791 = NOVALUE;
    object _29790 = NOVALUE;
    object _29788 = NOVALUE;
    object _29787 = NOVALUE;
    object _29785 = NOVALUE;
    object _29784 = NOVALUE;
    object _29783 = NOVALUE;
    object _29782 = NOVALUE;
    object _29781 = NOVALUE;
    object _29780 = NOVALUE;
    object _29778 = NOVALUE;
    object _29777 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:2786		integer else_bp*/

    /** parser.e:2787		integer switch_pc*/

    /** parser.e:2789		push_switch()*/
    _43push_switch();

    /** parser.e:2790		break_base = length(break_list)*/
    if (IS_SEQUENCE(_43break_list_55423)){
            _break_base_59593 = SEQ_PTR(_43break_list_55423)->length;
    }
    else {
        _break_base_59593 = 1;
    }

    /** parser.e:2792		Expr()*/
    _43Expr();

    /** parser.e:2793		switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29777 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29777 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29777 + ((s1_ptr)_2)->base);
    _29780 = _45Top();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _29780;
    if( _1 != _29780 ){
        DeRef(_1);
    }
    _29780 = NOVALUE;
    _29778 = NOVALUE;

    /** parser.e:2794		clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29781 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29781 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29782 = (object)*(((s1_ptr)_2)->base + _29781);
    _2 = (object)SEQ_PTR(_29782);
    _29783 = (object)*(((s1_ptr)_2)->base + 6);
    _29782 = NOVALUE;
    Ref(_29783);
    _45clear_temp(_29783);
    _29783 = NOVALUE;

    /** parser.e:2796		cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _29784 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _29784 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1;
    ((intptr_t *)_2)[2] = _29784;
    _29785 = MAKE_SEQ(_1);
    _29784 = NOVALUE;
    _cases_59595 = _53NewStringSym(_29785);
    _29785 = NOVALUE;
    if (!IS_ATOM_INT(_cases_59595)) {
        _1 = (object)(DBL_PTR(_cases_59595)->dbl);
        DeRefDS(_cases_59595);
        _cases_59595 = _1;
    }

    /** parser.e:2798		emit_opnd( cases )*/
    _45emit_opnd(_cases_59595);

    /** parser.e:2800		jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_28SymTab_11572)){
            _29787 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _29787 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2;
    ((intptr_t *)_2)[2] = _29787;
    _29788 = MAKE_SEQ(_1);
    _29787 = NOVALUE;
    _jump_table_59596 = _53NewStringSym(_29788);
    _29788 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_59596)) {
        _1 = (object)(DBL_PTR(_jump_table_59596)->dbl);
        DeRefDS(_jump_table_59596);
        _jump_table_59596 = _1;
    }

    /** parser.e:2801		emit_opnd( jump_table )*/
    _45emit_opnd(_jump_table_59596);

    /** parser.e:2803		if finish_block_header(SWITCH) then end if*/
    _29790 = _43finish_block_header(185);
    if (_29790 == 0) {
        DeRef(_29790);
        _29790 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29790) && DBL_PTR(_29790)->dbl == 0.0){
            DeRef(_29790);
            _29790 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29790);
        _29790 = NOVALUE;
    }
    DeRef(_29790);
    _29790 = NOVALUE;
L1: 

    /** parser.e:2805		switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29791 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29791 = 1;
    }
    _switch_pc_59598 = _29791 + 1;
    _29791 = NOVALUE;

    /** parser.e:2806		switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29793 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29793 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43switch_stack_55654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_29793 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _switch_pc_59598;
    DeRef(_1);
    _29794 = NOVALUE;

    /** parser.e:2808		emit_op(SWITCH)*/
    _45emit_op(185);

    /** parser.e:2809		emit_forward_addr()  -- the else*/
    _43emit_forward_addr();

    /** parser.e:2810		else_bp = length( Code )*/
    if (IS_SEQUENCE(_27Code_20660)){
            _else_bp_59597 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _else_bp_59597 = 1;
    }

    /** parser.e:2813		t = next_token()*/
    _0 = _t_59635;
    _t_59635 = _43next_token();
    DeRef(_0);

    /** parser.e:2814		if t[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_t_59635);
    _29798 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29798, 186)){
        _29798 = NOVALUE;
        goto L2; // [173] 188
    }
    _29798 = NOVALUE;

    /** parser.e:2816			Case_statement()*/
    _43Case_statement();

    /** parser.e:2818			Statement_list()*/
    _43Statement_list();
    goto L3; // [185] 194
L2: 

    /** parser.e:2821			putback(t)*/
    Ref(_t_59635);
    _43putback(_t_59635);
L3: 

    /** parser.e:2824		optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _43optimize_switch(_switch_pc_59598, _else_bp_59597, _cases_59595, _jump_table_59596);

    /** parser.e:2825		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:2826		tok_match(SWITCH, END)*/
    _43tok_match(185, 402);

    /** parser.e:2827		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** parser.e:2828			emit_op(NOPSWITCH)*/
    _45emit_op(187);
L4: 

    /** parser.e:2831		if not else_case() then*/

    /** parser.e:2472		return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _else_case_1__tmp_at250_59654 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _else_case_1__tmp_at250_59654 = 1;
    }
    DeRef(_else_case_2__tmp_at250_59655);
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _else_case_2__tmp_at250_59655 = (object)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_59654);
    RefDS(_else_case_2__tmp_at250_59655);
    DeRef(_else_case_inlined_else_case_at_250_59653);
    _2 = (object)SEQ_PTR(_else_case_2__tmp_at250_59655);
    _else_case_inlined_else_case_at_250_59653 = (object)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_59653);
    DeRef(_else_case_2__tmp_at250_59655);
    _else_case_2__tmp_at250_59655 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_59653)) {
        if (_else_case_inlined_else_case_at_250_59653 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_59653)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** parser.e:2832			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L6; // [262] 303

    /** parser.e:2833				StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_441, 0, 1);

    /** parser.e:2834				emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_43switch_stack_55654)){
            _29802 = SEQ_PTR(_43switch_stack_55654)->length;
    }
    else {
        _29802 = 1;
    }
    _2 = (object)SEQ_PTR(_43switch_stack_55654);
    _29803 = (object)*(((s1_ptr)_2)->base + _29802);
    _2 = (object)SEQ_PTR(_29803);
    _29804 = (object)*(((s1_ptr)_2)->base + 6);
    _29803 = NOVALUE;
    Ref(_29804);
    _45emit_temp(_29804, 1);
    _29804 = NOVALUE;

    /** parser.e:2835				flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);
L6: 

    /** parser.e:2838			Warning(221, no_case_else_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _29805 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    Ref(_29805);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _29805;
    ((intptr_t *)_2)[2] = _27line_number_20572;
    _29806 = MAKE_SEQ(_1);
    _29805 = NOVALUE;
    _49Warning(221, 4096, _29806);
    _29806 = NOVALUE;
L5: 

    /** parser.e:2841		pop_switch( break_base )*/
    _43pop_switch(_break_base_59593);

    /** parser.e:2842	end procedure*/
    DeRef(_t_59635);
    return;
    ;
}


object _43get_private_uninitialized()
{
    object _uninitialized_59678 = NOVALUE;
    object _s_59684 = NOVALUE;
    object _pu_59690 = NOVALUE;
    object _29823 = NOVALUE;
    object _29821 = NOVALUE;
    object _29820 = NOVALUE;
    object _29819 = NOVALUE;
    object _29818 = NOVALUE;
    object _29817 = NOVALUE;
    object _29816 = NOVALUE;
    object _29815 = NOVALUE;
    object _29814 = NOVALUE;
    object _29813 = NOVALUE;
    object _29812 = NOVALUE;
    object _29811 = NOVALUE;
    object _29808 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2845		sequence uninitialized = {}*/
    RefDS(_22209);
    DeRefi(_uninitialized_59678);
    _uninitialized_59678 = _22209;

    /** parser.e:2846		if CurrentSub != TopLevelSub then*/
    if (_27CurrentSub_20579 == _27TopLevelSub_20578)
    goto L1; // [14] 149

    /** parser.e:2847			symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29808 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_29808);
    _s_59684 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59684)){
        _s_59684 = (object)DBL_PTR(_s_59684)->dbl;
    }
    _29808 = NOVALUE;

    /** parser.e:2848			sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_59690);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 3;
    ((intptr_t *)_2)[2] = 9;
    _pu_59690 = MAKE_SEQ(_1);

    /** parser.e:2849			while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_59684 == 0) {
        goto L3; // [51] 148
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29812 = (object)*(((s1_ptr)_2)->base + _s_59684);
    _2 = (object)SEQ_PTR(_29812);
    _29813 = (object)*(((s1_ptr)_2)->base + 4);
    _29812 = NOVALUE;
    _29814 = find_from(_29813, _pu_59690, 1);
    _29813 = NOVALUE;
    if (_29814 == 0)
    {
        _29814 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29814 = NOVALUE;
    }

    /** parser.e:2850				if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29815 = (object)*(((s1_ptr)_2)->base + _s_59684);
    _2 = (object)SEQ_PTR(_29815);
    _29816 = (object)*(((s1_ptr)_2)->base + 4);
    _29815 = NOVALUE;
    if (IS_ATOM_INT(_29816)) {
        _29817 = (_29816 == 3);
    }
    else {
        _29817 = binary_op(EQUALS, _29816, 3);
    }
    _29816 = NOVALUE;
    if (IS_ATOM_INT(_29817)) {
        if (_29817 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29817)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29819 = (object)*(((s1_ptr)_2)->base + _s_59684);
    _2 = (object)SEQ_PTR(_29819);
    _29820 = (object)*(((s1_ptr)_2)->base + 14);
    _29819 = NOVALUE;
    if (IS_ATOM_INT(_29820)) {
        _29821 = (_29820 == -1);
    }
    else {
        _29821 = binary_op(EQUALS, _29820, -1);
    }
    _29820 = NOVALUE;
    if (_29821 == 0) {
        DeRef(_29821);
        _29821 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29821) && DBL_PTR(_29821)->dbl == 0.0){
            DeRef(_29821);
            _29821 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29821);
        _29821 = NOVALUE;
    }
    DeRef(_29821);
    _29821 = NOVALUE;

    /** parser.e:2851					uninitialized &= s*/
    Append(&_uninitialized_59678, _uninitialized_59678, _s_59684);
L4: 

    /** parser.e:2853				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _29823 = (object)*(((s1_ptr)_2)->base + _s_59684);
    _2 = (object)SEQ_PTR(_29823);
    _s_59684 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59684)){
        _s_59684 = (object)DBL_PTR(_s_59684)->dbl;
    }
    _29823 = NOVALUE;

    /** parser.e:2854			end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_59690);
    _pu_59690 = NOVALUE;

    /** parser.e:2856		return uninitialized*/
    DeRef(_29817);
    _29817 = NOVALUE;
    return _uninitialized_59678;
    ;
}


void _43While_statement()
{
    object _bp1_59721 = NOVALUE;
    object _bp2_59722 = NOVALUE;
    object _exit_base_59723 = NOVALUE;
    object _next_base_59724 = NOVALUE;
    object _uninitialized_59725 = NOVALUE;
    object _temps_59795 = NOVALUE;
    object _29859 = NOVALUE;
    object _29858 = NOVALUE;
    object _29857 = NOVALUE;
    object _29853 = NOVALUE;
    object _29852 = NOVALUE;
    object _29850 = NOVALUE;
    object _29848 = NOVALUE;
    object _29847 = NOVALUE;
    object _29846 = NOVALUE;
    object _29842 = NOVALUE;
    object _29840 = NOVALUE;
    object _29838 = NOVALUE;
    object _29832 = NOVALUE;
    object _29830 = NOVALUE;
    object _29829 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2865		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59725;
    _uninitialized_59725 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2867		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59725);
    Append(&_43entry_stack_55432, _43entry_stack_55432, _uninitialized_59725);

    /** parser.e:2869		Start_block( WHILE )*/
    _64Start_block(47, 0);

    /** parser.e:2871		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _exit_base_59723 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _exit_base_59723 = 1;
    }

    /** parser.e:2872		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55427)){
            _next_base_59724 = SEQ_PTR(_43continue_list_55427)->length;
    }
    else {
        _next_base_59724 = 1;
    }

    /** parser.e:2873		entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29829 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29829 = 1;
    }
    _29830 = _29829 + 1;
    _29829 = NOVALUE;
    Append(&_43entry_addr_55429, _43entry_addr_55429, _29830);
    _29830 = NOVALUE;

    /** parser.e:2874		emit_op(NOP2) -- Entry_statement may patch this later*/
    _45emit_op(110);

    /** parser.e:2875		emit_addr(0)*/
    _45emit_addr(0);

    /** parser.e:2876		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** parser.e:2877			emit_op(NOPWHILE)*/
    _45emit_op(158);
L1: 

    /** parser.e:2879		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29832 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29832 = 1;
    }
    _bp1_59721 = _29832 + 1;
    _29832 = NOVALUE;

    /** parser.e:2880		continue_addr &= bp1*/
    Append(&_43continue_addr_55430, _43continue_addr_55430, _bp1_59721);

    /** parser.e:2881		short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;

    /** parser.e:2882		short_circuit_B = FALSE*/
    _43short_circuit_B_55407 = _9FALSE_439;

    /** parser.e:2883		SC1_type = 0*/
    _43SC1_type_55410 = 0;

    /** parser.e:2884		Expr()*/
    _43Expr();

    /** parser.e:2885		optimized_while = FALSE*/
    _45optimized_while_51415 = _9FALSE_439;

    /** parser.e:2886		emit_op(WHILE)*/
    _45emit_op(47);

    /** parser.e:2887		short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:2888		if not optimized_while then*/
    if (_45optimized_while_51415 != 0)
    goto L2; // [153] 174

    /** parser.e:2890			bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29838 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29838 = 1;
    }
    _bp2_59722 = _29838 + 1;
    _29838 = NOVALUE;

    /** parser.e:2891			emit_forward_addr() -- will be patched*/
    _43emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** parser.e:2893			bp2 = 0*/
    _bp2_59722 = 0;
L3: 

    /** parser.e:2895		if finish_block_header(WHILE)=0 then*/
    _29840 = _43finish_block_header(47);
    if (binary_op_a(NOTEQ, _29840, 0)){
        DeRef(_29840);
        _29840 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29840);
    _29840 = NOVALUE;

    /** parser.e:2896			entry_addr[$]=-1*/
    if (IS_SEQUENCE(_43entry_addr_55429)){
            _29842 = SEQ_PTR(_43entry_addr_55429)->length;
    }
    else {
        _29842 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55429);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_55429 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _29842);
    *(intptr_t *)_2 = -1;
L4: 

    /** parser.e:2899		loop_stack &= WHILE*/
    Append(&_43loop_stack_55439, _43loop_stack_55439, 47);

    /** parser.e:2901		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _exit_base_59723 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _exit_base_59723 = 1;
    }

    /** parser.e:2902		if SC1_type = OR then*/
    if (_43SC1_type_55410 != 9)
    goto L5; // [227] 280

    /** parser.e:2903			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29846 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29846 +(uintptr_t) HIGH_BITS) >= 0){
        _29846 = NewDouble((eudouble)_29846);
    }
    _45backpatch(_29846, 147);
    _29846 = NOVALUE;

    /** parser.e:2904			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** parser.e:2905				emit_op(NOP1)*/
    _45emit_op(159);
L6: 

    /** parser.e:2907			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29847 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29847 = 1;
    }
    _29848 = _29847 + 1;
    _29847 = NOVALUE;
    _45backpatch(_43SC1_patch_55409, _29848);
    _29848 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** parser.e:2908		elsif SC1_type = AND then*/
    if (_43SC1_type_55410 != 8)
    goto L8; // [286] 330

    /** parser.e:2909			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29850 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29850 +(uintptr_t) HIGH_BITS) >= 0){
        _29850 = NewDouble((eudouble)_29850);
    }
    _45backpatch(_29850, 146);
    _29850 = NOVALUE;

    /** parser.e:2910			AppendXList(SC1_patch)*/

    /** parser.e:398		exit_list = append(exit_list, addr)*/
    Append(&_43exit_list_55425, _43exit_list_55425, _43SC1_patch_55409);

    /** parser.e:399	end procedure*/
    goto L9; // [318] 321
L9: 

    /** parser.e:2911			exit_delay &= 1*/
    Append(&_43exit_delay_55426, _43exit_delay_55426, 1);
L8: 
L7: 

    /** parser.e:2913		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29852 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29852 = 1;
    }
    _29853 = _29852 + 1;
    _29852 = NOVALUE;
    Append(&_43retry_addr_55431, _43retry_addr_55431, _29853);
    _29853 = NOVALUE;

    /** parser.e:2915		sequence temps = pop_temps()*/
    _0 = _temps_59795;
    _temps_59795 = _45pop_temps();
    DeRef(_0);

    /** parser.e:2917		push_temps( temps )*/
    RefDS(_temps_59795);
    _45push_temps(_temps_59795);

    /** parser.e:2919		Statement_list()*/
    _43Statement_list();

    /** parser.e:2920		PatchNList(next_base)*/
    _43PatchNList(_next_base_59724);

    /** parser.e:2921		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:2922		tok_match(WHILE, END)*/
    _43tok_match(47, 402);

    /** parser.e:2924		End_block( WHILE )*/
    _64End_block(47);

    /** parser.e:2926		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:2927		emit_op(ENDWHILE)*/
    _45emit_op(22);

    /** parser.e:2928		emit_addr(bp1)*/
    _45emit_addr(_bp1_59721);

    /** parser.e:2929		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** parser.e:2930			emit_op(NOP1)*/
    _45emit_op(159);
LA: 

    /** parser.e:2932		if bp2 != 0 then*/
    if (_bp2_59722 == 0)
    goto LB; // [434] 454

    /** parser.e:2933			backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29857 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29857 = 1;
    }
    _29858 = _29857 + 1;
    _29857 = NOVALUE;
    _45backpatch(_bp2_59722, _29858);
    _29858 = NOVALUE;
LB: 

    /** parser.e:2935		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59723);

    /** parser.e:2936		entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_43entry_stack_55432)){
            _29859 = SEQ_PTR(_43entry_stack_55432)->length;
    }
    else {
        _29859 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_43entry_stack_55432);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29859)) ? _29859 : (object)(DBL_PTR(_29859)->dbl);
        int stop = (IS_ATOM_INT(_29859)) ? _29859 : (object)(DBL_PTR(_29859)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_43entry_stack_55432), start, &_43entry_stack_55432 );
            }
            else Tail(SEQ_PTR(_43entry_stack_55432), stop+1, &_43entry_stack_55432);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_43entry_stack_55432), start, &_43entry_stack_55432);
        }
        else {
            assign_slice_seq = &assign_space;
            _43entry_stack_55432 = Remove_elements(start, stop, (SEQ_PTR(_43entry_stack_55432)->ref == 1));
        }
    }
    _29859 = NOVALUE;
    _29859 = NOVALUE;

    /** parser.e:2937		push_temps( temps )*/
    RefDS(_temps_59795);
    _45push_temps(_temps_59795);

    /** parser.e:2938	end procedure*/
    DeRef(_uninitialized_59725);
    DeRefDS(_temps_59795);
    return;
    ;
}


void _43Loop_statement()
{
    object _bp1_59825 = NOVALUE;
    object _exit_base_59826 = NOVALUE;
    object _next_base_59827 = NOVALUE;
    object _t_59829 = NOVALUE;
    object _uninitialized_59832 = NOVALUE;
    object _29883 = NOVALUE;
    object _29881 = NOVALUE;
    object _29880 = NOVALUE;
    object _29879 = NOVALUE;
    object _29873 = NOVALUE;
    object _29872 = NOVALUE;
    object _29870 = NOVALUE;
    object _29867 = NOVALUE;
    object _29866 = NOVALUE;
    object _29865 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:2946		Start_block( LOOP )*/
    _64Start_block(422, 0);

    /** parser.e:2948		sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_59832;
    _uninitialized_59832 = _43get_private_uninitialized();
    DeRef(_0);

    /** parser.e:2949		entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_59832);
    Append(&_43entry_stack_55432, _43entry_stack_55432, _uninitialized_59832);

    /** parser.e:2951		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _exit_base_59826 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _exit_base_59826 = 1;
    }

    /** parser.e:2952		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55427)){
            _next_base_59827 = SEQ_PTR(_43continue_list_55427)->length;
    }
    else {
        _next_base_59827 = 1;
    }

    /** parser.e:2953		emit_op(NOP2) -- Entry_statement() may patch this*/
    _45emit_op(110);

    /** parser.e:2954		emit_addr(0)*/
    _45emit_addr(0);

    /** parser.e:2955		if finish_block_header(LOOP) then*/
    _29865 = _43finish_block_header(422);
    if (_29865 == 0) {
        DeRef(_29865);
        _29865 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29865) && DBL_PTR(_29865)->dbl == 0.0){
            DeRef(_29865);
            _29865 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29865);
        _29865 = NOVALUE;
    }
    DeRef(_29865);
    _29865 = NOVALUE;

    /** parser.e:2956		    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29866 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29866 = 1;
    }
    _29867 = _29866 - 1;
    _29866 = NOVALUE;
    Append(&_43entry_addr_55429, _43entry_addr_55429, _29867);
    _29867 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** parser.e:2958			entry_addr &= -1*/
    Append(&_43entry_addr_55429, _43entry_addr_55429, -1);
L2: 

    /** parser.e:2962		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** parser.e:2963			emit_op(NOP1)*/
    _45emit_op(159);
L3: 

    /** parser.e:2965		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29870 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29870 = 1;
    }
    _bp1_59825 = _29870 + 1;
    _29870 = NOVALUE;

    /** parser.e:2966		retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29872 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29872 = 1;
    }
    _29873 = _29872 + 1;
    _29872 = NOVALUE;
    Append(&_43retry_addr_55431, _43retry_addr_55431, _29873);
    _29873 = NOVALUE;

    /** parser.e:2967		continue_addr &= 0*/
    Append(&_43continue_addr_55430, _43continue_addr_55430, 0);

    /** parser.e:2968		loop_stack &= LOOP*/
    Append(&_43loop_stack_55439, _43loop_stack_55439, 422);

    /** parser.e:2970		Statement_list()*/
    _43Statement_list();

    /** parser.e:2972		End_block( LOOP )*/
    _64End_block(422);

    /** parser.e:2974		tok_match(UNTIL)*/
    _43tok_match(423, 0);

    /** parser.e:2975		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** parser.e:2976			emit_op(NOP1)*/
    _45emit_op(159);
L4: 

    /** parser.e:2978		PatchNList(next_base)*/
    _43PatchNList(_next_base_59827);

    /** parser.e:2979		StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:2980		short_circuit += 1*/
    _43short_circuit_55405 = _43short_circuit_55405 + 1;

    /** parser.e:2981		short_circuit_B = FALSE*/
    _43short_circuit_B_55407 = _9FALSE_439;

    /** parser.e:2982		SC1_type = 0*/
    _43SC1_type_55410 = 0;

    /** parser.e:2983		Expr()*/
    _43Expr();

    /** parser.e:2984		if SC1_type = OR then*/
    if (_43SC1_type_55410 != 9)
    goto L5; // [229] 282

    /** parser.e:2985			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29879 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29879 +(uintptr_t) HIGH_BITS) >= 0){
        _29879 = NewDouble((eudouble)_29879);
    }
    _45backpatch(_29879, 147);
    _29879 = NOVALUE;

    /** parser.e:2986			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** parser.e:2987			    emit_op(NOP1)  -- to get label here*/
    _45emit_op(159);
L6: 

    /** parser.e:2989			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _29880 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _29880 = 1;
    }
    _29881 = _29880 + 1;
    _29880 = NOVALUE;
    _45backpatch(_43SC1_patch_55409, _29881);
    _29881 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** parser.e:2990		elsif SC1_type = AND then*/
    if (_43SC1_type_55410 != 8)
    goto L8; // [288] 307

    /** parser.e:2991			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29883 = _43SC1_patch_55409 - 3;
    if ((object)((uintptr_t)_29883 +(uintptr_t) HIGH_BITS) >= 0){
        _29883 = NewDouble((eudouble)_29883);
    }
    _45backpatch(_29883, 146);
    _29883 = NOVALUE;
L8: 
L7: 

    /** parser.e:2993		short_circuit -= 1*/
    _43short_circuit_55405 = _43short_circuit_55405 - 1;

    /** parser.e:2994		emit_op(IF)*/
    _45emit_op(20);

    /** parser.e:2995		emit_addr(bp1)*/
    _45emit_addr(_bp1_59825);

    /** parser.e:2996		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** parser.e:2997			emit_op(NOP1)*/
    _45emit_op(159);
L9: 

    /** parser.e:2999		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_59826);

    /** parser.e:3001		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:3002		tok_match(LOOP, END)*/
    _43tok_match(422, 402);

    /** parser.e:3004	end procedure*/
    DeRef(_uninitialized_59832);
    return;
    ;
}


void _43Ifdef_statement()
{
    object _option_59911 = NOVALUE;
    object _matched_59912 = NOVALUE;
    object _has_matched_59913 = NOVALUE;
    object _in_matched_59914 = NOVALUE;
    object _dead_ifdef_59915 = NOVALUE;
    object _in_elsedef_59916 = NOVALUE;
    object _tok_59918 = NOVALUE;
    object _keyw_59919 = NOVALUE;
    object _parser_id_59923 = NOVALUE;
    object _negate_59939 = NOVALUE;
    object _conjunction_59940 = NOVALUE;
    object _at_start_59941 = NOVALUE;
    object _prev_conj_59942 = NOVALUE;
    object _this_matched_60027 = NOVALUE;
    object _gotword_60043 = NOVALUE;
    object _gotthen_60044 = NOVALUE;
    object _if_lvl_60045 = NOVALUE;
    object _30000 = NOVALUE;
    object _29999 = NOVALUE;
    object _29995 = NOVALUE;
    object _29993 = NOVALUE;
    object _29990 = NOVALUE;
    object _29988 = NOVALUE;
    object _29987 = NOVALUE;
    object _29983 = NOVALUE;
    object _29980 = NOVALUE;
    object _29977 = NOVALUE;
    object _29973 = NOVALUE;
    object _29971 = NOVALUE;
    object _29970 = NOVALUE;
    object _29969 = NOVALUE;
    object _29968 = NOVALUE;
    object _29967 = NOVALUE;
    object _29966 = NOVALUE;
    object _29965 = NOVALUE;
    object _29961 = NOVALUE;
    object _29958 = NOVALUE;
    object _29957 = NOVALUE;
    object _29956 = NOVALUE;
    object _29952 = NOVALUE;
    object _29951 = NOVALUE;
    object _29950 = NOVALUE;
    object _29947 = NOVALUE;
    object _29944 = NOVALUE;
    object _29943 = NOVALUE;
    object _29942 = NOVALUE;
    object _29940 = NOVALUE;
    object _29929 = NOVALUE;
    object _29927 = NOVALUE;
    object _29926 = NOVALUE;
    object _29925 = NOVALUE;
    object _29924 = NOVALUE;
    object _29923 = NOVALUE;
    object _29922 = NOVALUE;
    object _29921 = NOVALUE;
    object _29918 = NOVALUE;
    object _29917 = NOVALUE;
    object _29915 = NOVALUE;
    object _29913 = NOVALUE;
    object _29912 = NOVALUE;
    object _29910 = NOVALUE;
    object _29908 = NOVALUE;
    object _29907 = NOVALUE;
    object _29905 = NOVALUE;
    object _29904 = NOVALUE;
    object _29903 = NOVALUE;
    object _29900 = NOVALUE;
    object _29898 = NOVALUE;
    object _29895 = NOVALUE;
    object _29894 = NOVALUE;
    object _29893 = NOVALUE;
    object _29891 = NOVALUE;
    object _29889 = NOVALUE;
    object _29888 = NOVALUE;
    object _29887 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3012		integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_59912 = 0;
    _has_matched_59913 = 0;
    _in_matched_59914 = 0;
    _dead_ifdef_59915 = 0;
    _in_elsedef_59916 = 0;

    /** parser.e:3014		sequence keyw ="ifdef"*/
    RefDS(_26498);
    DeRefi(_keyw_59919);
    _keyw_59919 = _26498;

    /** parser.e:3016		live_ifdef += 1*/
    _43live_ifdef_59907 = _43live_ifdef_59907 + 1;

    /** parser.e:3017		ifdef_lineno &= line_number*/
    Append(&_43ifdef_lineno_59908, _43ifdef_lineno_59908, _27line_number_20572);

    /** parser.e:3019		integer parser_id*/

    /** parser.e:3020		if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29887 = (_27CurrentSub_20579 != _27TopLevelSub_20578);
    if (_29887 != 0) {
        _29888 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_43if_labels_55434)){
            _29889 = SEQ_PTR(_43if_labels_55434)->length;
    }
    else {
        _29889 = 1;
    }
    _29888 = (_29889 != 0);
L1: 
    if (_29888 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_43loop_labels_55433)){
            _29891 = SEQ_PTR(_43loop_labels_55433)->length;
    }
    else {
        _29891 = 1;
    }
    if (_29891 == 0)
    {
        _29891 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29891 = NOVALUE;
    }
L2: 

    /** parser.e:3021			parser_id = forward_Statement_list*/
    _parser_id_59923 = _43forward_Statement_list_58649;
    goto L4; // [89] 100
L3: 

    /** parser.e:3023			parser_id = top_level_parser*/
    _parser_id_59923 = _43top_level_parser_59906;
L4: 

    /** parser.e:3026		while 1 label "top" do*/
L5: 

    /** parser.e:3027			if matched = 0 and in_elsedef = 0 then*/
    _29893 = (_matched_59912 == 0);
    if (_29893 == 0) {
        goto L6; // [111] 656
    }
    _29895 = (_in_elsedef_59916 == 0);
    if (_29895 == 0)
    {
        DeRef(_29895);
        _29895 = NOVALUE;
        goto L6; // [120] 656
    }
    else{
        DeRef(_29895);
        _29895 = NOVALUE;
    }

    /** parser.e:3028				integer negate = 0, conjunction = 0*/
    _negate_59939 = 0;
    _conjunction_59940 = 0;

    /** parser.e:3029				integer at_start = 1*/
    _at_start_59941 = 1;

    /** parser.e:3030				sequence prev_conj = ""*/
    RefDS(_22209);
    DeRef(_prev_conj_59942);
    _prev_conj_59942 = _22209;

    /** parser.e:3032				while 1 label "deflist" do*/
L7: 

    /** parser.e:3033					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59911;
    _option_59911 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3034					if equal(option, "then") then*/
    if (_option_59911 == _26565)
    _29898 = 1;
    else if (IS_ATOM_INT(_option_59911) && IS_ATOM_INT(_26565))
    _29898 = 0;
    else
    _29898 = (compare(_option_59911, _26565) == 0);
    if (_29898 == 0)
    {
        _29898 = NOVALUE;
        goto L8; // [162] 240
    }
    else{
        _29898 = NOVALUE;
    }

    /** parser.e:3035						if at_start = 1 then*/
    if (_at_start_59941 != 1)
    goto L9; // [167] 187

    /** parser.e:3036							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29900 = MAKE_SEQ(_1);
    _49CompileErr(6, _29900, 0);
    _29900 = NOVALUE;
    goto LA; // [184] 542
L9: 

    /** parser.e:3037						elsif conjunction = 0 then*/
    if (_conjunction_59940 != 0)
    goto LB; // [189] 223

    /** parser.e:3038							if negate = 0 then*/
    if (_negate_59939 != 0)
    goto LC; // [195] 206

    /** parser.e:3039								exit "deflist"*/
    goto LD; // [201] 630
    goto LA; // [203] 542
LC: 

    /** parser.e:3041								CompileErr(MSG_1_THEN_FOLLOWS_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29903 = MAKE_SEQ(_1);
    _49CompileErr(11, _29903, 0);
    _29903 = NOVALUE;
    goto LA; // [220] 542
LB: 

    /** parser.e:3044							CompileErr(MSG_1_THEN_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59942);
    RefDS(_keyw_59919);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59919;
    ((intptr_t *)_2)[2] = _prev_conj_59942;
    _29904 = MAKE_SEQ(_1);
    _49CompileErr(8, _29904, 0);
    _29904 = NOVALUE;
    goto LA; // [237] 542
L8: 

    /** parser.e:3046					elsif equal(option, "not") then*/
    if (_option_59911 == _26526)
    _29905 = 1;
    else if (IS_ATOM_INT(_option_59911) && IS_ATOM_INT(_26526))
    _29905 = 0;
    else
    _29905 = (compare(_option_59911, _26526) == 0);
    if (_29905 == 0)
    {
        _29905 = NOVALUE;
        goto LE; // [246] 284
    }
    else{
        _29905 = NOVALUE;
    }

    /** parser.e:3047						if negate = 0 then*/
    if (_negate_59939 != 0)
    goto LF; // [251] 267

    /** parser.e:3048							negate = 1*/
    _negate_59939 = 1;

    /** parser.e:3049							continue "deflist"*/
    goto L7; // [262] 148
    goto LA; // [264] 542
LF: 

    /** parser.e:3051							CompileErr(MSG_1_DUPLICATE_NOT, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29907 = MAKE_SEQ(_1);
    _49CompileErr(7, _29907, 0);
    _29907 = NOVALUE;
    goto LA; // [281] 542
LE: 

    /** parser.e:3053					elsif equal(option, "and") then*/
    if (_option_59911 == _26430)
    _29908 = 1;
    else if (IS_ATOM_INT(_option_59911) && IS_ATOM_INT(_26430))
    _29908 = 0;
    else
    _29908 = (compare(_option_59911, _26430) == 0);
    if (_29908 == 0)
    {
        _29908 = NOVALUE;
        goto L10; // [290] 357
    }
    else{
        _29908 = NOVALUE;
    }

    /** parser.e:3054						if at_start = 1 then*/
    if (_at_start_59941 != 1)
    goto L11; // [295] 315

    /** parser.e:3055							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_AND, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29910 = MAKE_SEQ(_1);
    _49CompileErr(2, _29910, 0);
    _29910 = NOVALUE;
    goto LA; // [312] 542
L11: 

    /** parser.e:3056						elsif conjunction = 0 then*/
    if (_conjunction_59940 != 0)
    goto L12; // [317] 340

    /** parser.e:3057							conjunction = 1*/
    _conjunction_59940 = 1;

    /** parser.e:3058							prev_conj = option*/
    RefDS(_option_59911);
    DeRef(_prev_conj_59942);
    _prev_conj_59942 = _option_59911;

    /** parser.e:3059							continue "deflist"*/
    goto L7; // [335] 148
    goto LA; // [337] 542
L12: 

    /** parser.e:3061							CompileErr(MSG_1_AND_FOLLOWS_2,{keyw,prev_conj})*/
    RefDS(_prev_conj_59942);
    RefDS(_keyw_59919);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59919;
    ((intptr_t *)_2)[2] = _prev_conj_59942;
    _29912 = MAKE_SEQ(_1);
    _49CompileErr(10, _29912, 0);
    _29912 = NOVALUE;
    goto LA; // [354] 542
L10: 

    /** parser.e:3063					elsif equal(option, "or") then*/
    if (_option_59911 == _26530)
    _29913 = 1;
    else if (IS_ATOM_INT(_option_59911) && IS_ATOM_INT(_26530))
    _29913 = 0;
    else
    _29913 = (compare(_option_59911, _26530) == 0);
    if (_29913 == 0)
    {
        _29913 = NOVALUE;
        goto L13; // [363] 430
    }
    else{
        _29913 = NOVALUE;
    }

    /** parser.e:3064						if at_start = 1 then*/
    if (_at_start_59941 != 1)
    goto L14; // [368] 388

    /** parser.e:3065							CompileErr(MSG_1_IS_MISSING_DEFINED_WORD_BEFORE_THEN, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29915 = MAKE_SEQ(_1);
    _49CompileErr(6, _29915, 0);
    _29915 = NOVALUE;
    goto LA; // [385] 542
L14: 

    /** parser.e:3066						elsif conjunction = 0 then*/
    if (_conjunction_59940 != 0)
    goto L15; // [390] 413

    /** parser.e:3067							conjunction = 2*/
    _conjunction_59940 = 2;

    /** parser.e:3068							prev_conj = option*/
    RefDS(_option_59911);
    DeRef(_prev_conj_59942);
    _prev_conj_59942 = _option_59911;

    /** parser.e:3069							continue "deflist"*/
    goto L7; // [408] 148
    goto LA; // [410] 542
L15: 

    /** parser.e:3071							CompileErr(MSG_1_OR_FOLLOWS_2, {keyw, prev_conj})*/
    RefDS(_prev_conj_59942);
    RefDS(_keyw_59919);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _keyw_59919;
    ((intptr_t *)_2)[2] = _prev_conj_59942;
    _29917 = MAKE_SEQ(_1);
    _49CompileErr(9, _29917, 0);
    _29917 = NOVALUE;
    goto LA; // [427] 542
L13: 

    /** parser.e:3073					elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_59911)){
            _29918 = SEQ_PTR(_option_59911)->length;
    }
    else {
        _29918 = 1;
    }
    if (_29918 != 0)
    goto L16; // [435] 474

    /** parser.e:3074						if at_start = 1 then*/
    if (_at_start_59941 != 1)
    goto L17; // [441] 461

    /** parser.e:3075							CompileErr(NO_WORD_WAS_FOUND_FOLLOWING_1, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29921 = MAKE_SEQ(_1);
    _49CompileErr(122, _29921, 0);
    _29921 = NOVALUE;
    goto LA; // [458] 542
L17: 

    /** parser.e:3077							CompileErr(EXPECTING_POSSIBLY_THEN_NOT_END_OF_LINE)*/
    RefDS(_22209);
    _49CompileErr(82, _22209, 0);
    goto LA; // [471] 542
L16: 

    /** parser.e:3079					elsif not at_start and length(prev_conj) = 0 then*/
    _29922 = (_at_start_59941 == 0);
    if (_29922 == 0) {
        goto L18; // [479] 510
    }
    if (IS_SEQUENCE(_prev_conj_59942)){
            _29924 = SEQ_PTR(_prev_conj_59942)->length;
    }
    else {
        _29924 = 1;
    }
    _29925 = (_29924 == 0);
    _29924 = NOVALUE;
    if (_29925 == 0)
    {
        DeRef(_29925);
        _29925 = NOVALUE;
        goto L18; // [491] 510
    }
    else{
        DeRef(_29925);
        _29925 = NOVALUE;
    }

    /** parser.e:3080						CompileErr(MSG_1_NOT_UNDERSTOOD, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29926 = MAKE_SEQ(_1);
    _49CompileErr(4, _29926, 0);
    _29926 = NOVALUE;
    goto LA; // [507] 542
L18: 

    /** parser.e:3081					elsif t_identifier(option) = 0 then*/
    RefDS(_option_59911);
    _29927 = _9t_identifier(_option_59911);
    if (binary_op_a(NOTEQ, _29927, 0)){
        DeRef(_29927);
        _29927 = NOVALUE;
        goto L19; // [516] 536
    }
    DeRef(_29927);
    _29927 = NOVALUE;

    /** parser.e:3082						CompileErr(MSG_1_WORD_MUST_BE_AN_IDENTIFIER, {keyw})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_keyw_59919);
    ((intptr_t*)_2)[1] = _keyw_59919;
    _29929 = MAKE_SEQ(_1);
    _49CompileErr(3, _29929, 0);
    _29929 = NOVALUE;
    goto LA; // [533] 542
L19: 

    /** parser.e:3084						at_start = 0*/
    _at_start_59941 = 0;
LA: 

    /** parser.e:3087					integer this_matched = find(option, OpDefines)*/
    _this_matched_60027 = find_from(_option_59911, _27OpDefines_20645, 1);

    /** parser.e:3088					if negate then*/
    if (_negate_59939 == 0)
    {
        goto L1A; // [553] 567
    }
    else{
    }

    /** parser.e:3089						this_matched = not this_matched*/
    _this_matched_60027 = (_this_matched_60027 == 0);

    /** parser.e:3090						negate = 0*/
    _negate_59939 = 0;
L1A: 

    /** parser.e:3093					if conjunction = 0 then*/
    if (_conjunction_59940 != 0)
    goto L1B; // [569] 581

    /** parser.e:3094						matched = this_matched*/
    _matched_59912 = _this_matched_60027;
    goto L1C; // [578] 623
L1B: 

    /** parser.e:3096						if conjunction = 1 then*/
    if (_conjunction_59940 != 1)
    goto L1D; // [583] 596

    /** parser.e:3097							matched = matched and this_matched*/
    _matched_59912 = (_matched_59912 != 0 && _this_matched_60027 != 0);
    goto L1E; // [593] 610
L1D: 

    /** parser.e:3098						elsif conjunction = 2 then*/
    if (_conjunction_59940 != 2)
    goto L1F; // [598] 609

    /** parser.e:3099							matched = matched or this_matched*/
    _matched_59912 = (_matched_59912 != 0 || _this_matched_60027 != 0);
L1F: 
L1E: 

    /** parser.e:3101						conjunction = 0*/
    _conjunction_59940 = 0;

    /** parser.e:3102						prev_conj = ""*/
    RefDS(_22209);
    DeRef(_prev_conj_59942);
    _prev_conj_59942 = _22209;
L1C: 

    /** parser.e:3104				end while*/
    goto L7; // [627] 148
LD: 

    /** parser.e:3106				in_matched = matched*/
    _in_matched_59914 = _matched_59912;

    /** parser.e:3107				if matched then*/
    if (_matched_59912 == 0)
    {
        goto L20; // [637] 655
    }
    else{
    }

    /** parser.e:3108					No_new_entry = 0*/
    _53No_new_entry_48382 = 0;

    /** parser.e:3109					call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59923].addr;
    (*(intptr_t (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_59942);
    _prev_conj_59942 = NOVALUE;

    /** parser.e:3115			integer gotword = 0*/
    _gotword_60043 = 0;

    /** parser.e:3116			integer gotthen = 0*/
    _gotthen_60044 = 0;

    /** parser.e:3117			integer if_lvl  = 0*/
    _if_lvl_60045 = 0;

    /** parser.e:3118			No_new_entry = not matched*/
    _53No_new_entry_48382 = (_matched_59912 == 0);

    /** parser.e:3119			has_matched = has_matched or matched*/
    _has_matched_59913 = (_has_matched_59913 != 0 || _matched_59912 != 0);

    /** parser.e:3120			keyw = "elsifdef"*/
    RefDS(_26466);
    DeRefi(_keyw_59919);
    _keyw_59919 = _26466;

    /** parser.e:3121			while 1 do*/
L21: 

    /** parser.e:3122				tok = next_token()*/
    _0 = _tok_59918;
    _tok_59918 = _43next_token();
    DeRef(_0);

    /** parser.e:3123				if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29940 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29940, -21)){
        _29940 = NOVALUE;
        goto L22; // [713] 738
    }
    _29940 = NOVALUE;

    /** parser.e:3124					CompileErr(END_OF_FILE_REACHED_WHILE_SEARCHING_FOR_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _29942 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _29942 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _29943 = (object)*(((s1_ptr)_2)->base + _29942);
    _49CompileErr(65, _29943, 0);
    _29943 = NOVALUE;
    goto L21; // [735] 698
L22: 

    /** parser.e:3125				elsif tok[T_ID] = END then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29944 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29944, 402)){
        _29944 = NOVALUE;
        goto L23; // [748] 874
    }
    _29944 = NOVALUE;

    /** parser.e:3126					tok = next_token()*/
    _0 = _tok_59918;
    _tok_59918 = _43next_token();
    DeRef(_0);

    /** parser.e:3127					if tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29947 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29947, 407)){
        _29947 = NOVALUE;
        goto L24; // [767] 795
    }
    _29947 = NOVALUE;

    /** parser.e:3128						if dead_ifdef then*/
    if (_dead_ifdef_59915 == 0)
    {
        goto L25; // [773] 785
    }
    else{
    }

    /** parser.e:3129							dead_ifdef -= 1*/
    _dead_ifdef_59915 = _dead_ifdef_59915 - 1;
    goto L21; // [782] 698
L25: 

    /** parser.e:3131							exit "top"*/
    goto L26; // [789] 1350
    goto L21; // [792] 698
L24: 

    /** parser.e:3133					elsif in_matched then*/
    if (_in_matched_59914 == 0)
    {
        goto L27; // [797] 821
    }
    else{
    }

    /** parser.e:3135						CompileErr(EXPECTING_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _29950 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _29950 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _29951 = (object)*(((s1_ptr)_2)->base + _29950);
    _49CompileErr(75, _29951, 0);
    _29951 = NOVALUE;
    goto L21; // [818] 698
L27: 

    /** parser.e:3137						if tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29952 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29952, 20)){
        _29952 = NOVALUE;
        goto L21; // [831] 698
    }
    _29952 = NOVALUE;

    /** parser.e:3138							if if_lvl > 0 then*/
    if (_if_lvl_60045 <= 0)
    goto L28; // [837] 850

    /** parser.e:3139								if_lvl -= 1*/
    _if_lvl_60045 = _if_lvl_60045 - 1;
    goto L21; // [847] 698
L28: 

    /** parser.e:3141								CompileErr(MISMATCHED_END_IF_SHOULD_THIS_BE_AN_END_IFDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _29956 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _29956 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _29957 = (object)*(((s1_ptr)_2)->base + _29956);
    _49CompileErr(111, _29957, 0);
    _29957 = NOVALUE;
    goto L21; // [871] 698
L23: 

    /** parser.e:3145				elsif tok[T_ID] = IF then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29958 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29958, 20)){
        _29958 = NOVALUE;
        goto L29; // [884] 897
    }
    _29958 = NOVALUE;

    /** parser.e:3146					if_lvl += 1*/
    _if_lvl_60045 = _if_lvl_60045 + 1;
    goto L21; // [894] 698
L29: 

    /** parser.e:3147				elsif tok[T_ID] = ELSE then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29961 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29961, 23)){
        _29961 = NOVALUE;
        goto L2A; // [907] 945
    }
    _29961 = NOVALUE;

    /** parser.e:3148					if not in_matched then*/
    if (_in_matched_59914 != 0)
    goto L21; // [913] 698

    /** parser.e:3149						if if_lvl = 0 then*/
    if (_if_lvl_60045 != 0)
    goto L21; // [918] 698

    /** parser.e:3150							CompileErr(MISMATCHED_ELSE_SHOULD_THIS_BE_AN_ELSEDEF_TO_MATCH_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _29965 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _29965 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _29966 = (object)*(((s1_ptr)_2)->base + _29965);
    _49CompileErr(108, _29966, 0);
    _29966 = NOVALUE;
    goto L21; // [942] 698
L2A: 

    /** parser.e:3153				elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29967 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29967)) {
        _29968 = (_29967 == 408);
    }
    else {
        _29968 = binary_op(EQUALS, _29967, 408);
    }
    _29967 = NOVALUE;
    if (IS_ATOM_INT(_29968)) {
        if (_29968 == 0) {
            goto L2B; // [959] 1101
        }
    }
    else {
        if (DBL_PTR(_29968)->dbl == 0.0) {
            goto L2B; // [959] 1101
        }
    }
    _29970 = (_dead_ifdef_59915 == 0);
    if (_29970 == 0)
    {
        DeRef(_29970);
        _29970 = NOVALUE;
        goto L2B; // [967] 1101
    }
    else{
        DeRef(_29970);
        _29970 = NOVALUE;
    }

    /** parser.e:3154					if has_matched then*/
    if (_has_matched_59913 == 0)
    {
        goto L2C; // [972] 1343
    }
    else{
    }

    /** parser.e:3155						in_matched = 0*/
    _in_matched_59914 = 0;

    /** parser.e:3156						No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** parser.e:3157						gotword = 0*/
    _gotword_60043 = 0;

    /** parser.e:3158						gotthen = 0*/
    _gotthen_60044 = 0;

    /** parser.e:3159						while length(option) > 0 with entry do*/
    goto L2D; // [999] 1041
L2E: 
    if (IS_SEQUENCE(_option_59911)){
            _29971 = SEQ_PTR(_option_59911)->length;
    }
    else {
        _29971 = 1;
    }
    if (_29971 <= 0)
    goto L2F; // [1007] 1054

    /** parser.e:3160							if equal(option, "then") then*/
    if (_option_59911 == _26565)
    _29973 = 1;
    else if (IS_ATOM_INT(_option_59911) && IS_ATOM_INT(_26565))
    _29973 = 0;
    else
    _29973 = (compare(_option_59911, _26565) == 0);
    if (_29973 == 0)
    {
        _29973 = NOVALUE;
        goto L30; // [1017] 1032
    }
    else{
        _29973 = NOVALUE;
    }

    /** parser.e:3161								gotthen = 1*/
    _gotthen_60044 = 1;

    /** parser.e:3162								exit*/
    goto L2F; // [1027] 1054
    goto L31; // [1029] 1038
L30: 

    /** parser.e:3164								gotword = 1*/
    _gotword_60043 = 1;
L31: 

    /** parser.e:3166						entry*/
L2D: 

    /** parser.e:3167							option = StringToken()*/
    RefDS(_5);
    _0 = _option_59911;
    _option_59911 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3168						end while*/
    goto L2E; // [1051] 1002
L2F: 

    /** parser.e:3169						if gotword = 0 then*/
    if (_gotword_60043 != 0)
    goto L32; // [1056] 1070

    /** parser.e:3170							CompileErr(EXPECTING_A_WORD_TO_FOLLOW_ELSIFDEF)*/
    RefDS(_22209);
    _49CompileErr(78, _22209, 0);
L32: 

    /** parser.e:3172						if gotthen = 0 then*/
    if (_gotthen_60044 != 0)
    goto L33; // [1072] 1086

    /** parser.e:3173							CompileErr(EXPECTING_THEN_ON_ELSIFDEF_LINE)*/
    RefDS(_22209);
    _49CompileErr(77, _22209, 0);
L33: 

    /** parser.e:3175						read_line()*/
    _61read_line();
    goto L21; // [1090] 698

    /** parser.e:3177						exit*/
    goto L2C; // [1095] 1343
    goto L21; // [1098] 698
L2B: 

    /** parser.e:3179				elsif tok[T_ID] = ELSEDEF then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29977 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29977, 409)){
        _29977 = NOVALUE;
        goto L34; // [1111] 1273
    }
    _29977 = NOVALUE;

    /** parser.e:3180					gotword = line_number*/
    _gotword_60043 = _27line_number_20572;

    /** parser.e:3181					option = StringToken()*/
    RefDS(_5);
    _0 = _option_59911;
    _option_59911 = _61StringToken(_5);
    DeRef(_0);

    /** parser.e:3182					if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_59911)){
            _29980 = SEQ_PTR(_option_59911)->length;
    }
    else {
        _29980 = 1;
    }
    if (_29980 <= 0)
    goto L35; // [1137] 1173

    /** parser.e:3183						if line_number = gotword then*/
    if (_27line_number_20572 != _gotword_60043)
    goto L36; // [1145] 1159

    /** parser.e:3184							CompileErr(NOT_EXPECTING_ANYTHING_ON_SAME_LINE_AS_ELSDEF)*/
    RefDS(_22209);
    _49CompileErr(116, _22209, 0);
L36: 

    /** parser.e:3186						bp -= length(option)*/
    if (IS_SEQUENCE(_option_59911)){
            _29983 = SEQ_PTR(_option_59911)->length;
    }
    else {
        _29983 = 1;
    }
    _49bp_49646 = _49bp_49646 - _29983;
    _29983 = NOVALUE;
L35: 

    /** parser.e:3188					if not dead_ifdef then*/
    if (_dead_ifdef_59915 != 0)
    goto L21; // [1175] 698

    /** parser.e:3189						if has_matched then*/
    if (_has_matched_59913 == 0)
    {
        goto L37; // [1180] 1202
    }
    else{
    }

    /** parser.e:3190							in_matched = 0*/
    _in_matched_59914 = 0;

    /** parser.e:3191							No_new_entry = 1*/
    _53No_new_entry_48382 = 1;

    /** parser.e:3192							read_line()*/
    _61read_line();
    goto L21; // [1199] 698
L37: 

    /** parser.e:3194							No_new_entry = 0*/
    _53No_new_entry_48382 = 0;

    /** parser.e:3195							in_elsedef = 1*/
    _in_elsedef_59916 = 1;

    /** parser.e:3196							call_proc(parser_id, {})*/
    _0 = (object)_00[_parser_id_59923].addr;
    (*(intptr_t (*)())_0)(
                         );

    /** parser.e:3197							tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:3198							tok_match(IFDEF, END)*/
    _43tok_match(407, 402);

    /** parser.e:3199							live_ifdef -= 1*/
    _43live_ifdef_59907 = _43live_ifdef_59907 - 1;

    /** parser.e:3200							ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _29987 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _29987 = 1;
    }
    _29988 = _29987 - 1;
    _29987 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59908;
    RHS_Slice(_43ifdef_lineno_59908, 1, _29988);

    /** parser.e:3201							return*/
    DeRef(_option_59911);
    DeRef(_tok_59918);
    DeRefi(_keyw_59919);
    _29988 = NOVALUE;
    DeRef(_29922);
    _29922 = NOVALUE;
    DeRef(_29968);
    _29968 = NOVALUE;
    DeRef(_29893);
    _29893 = NOVALUE;
    DeRef(_29887);
    _29887 = NOVALUE;
    return;
    goto L21; // [1270] 698
L34: 

    /** parser.e:3204				elsif tok[T_ID] = IFDEF then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29990 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29990, 407)){
        _29990 = NOVALUE;
        goto L38; // [1283] 1296
    }
    _29990 = NOVALUE;

    /** parser.e:3205					dead_ifdef += 1*/
    _dead_ifdef_59915 = _dead_ifdef_59915 + 1;
    goto L21; // [1293] 698
L38: 

    /** parser.e:3207				elsif tok[T_ID] = INCLUDE then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29993 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29993, 418)){
        _29993 = NOVALUE;
        goto L39; // [1306] 1317
    }
    _29993 = NOVALUE;

    /** parser.e:3209					read_line()*/
    _61read_line();
    goto L21; // [1314] 698
L39: 

    /** parser.e:3211				elsif tok[T_ID] = CASE then*/
    _2 = (object)SEQ_PTR(_tok_59918);
    _29995 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29995, 186)){
        _29995 = NOVALUE;
        goto L21; // [1327] 698
    }
    _29995 = NOVALUE;

    /** parser.e:3213					tok = next_token()*/
    _0 = _tok_59918;
    _tok_59918 = _43next_token();
    DeRef(_0);

    /** parser.e:3216			end while*/
    goto L21; // [1340] 698
L2C: 

    /** parser.e:3217		end while*/
    goto L5; // [1347] 105
L26: 

    /** parser.e:3219		live_ifdef -= 1*/
    _43live_ifdef_59907 = _43live_ifdef_59907 - 1;

    /** parser.e:3220		ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _29999 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _29999 = 1;
    }
    _30000 = _29999 - 1;
    _29999 = NOVALUE;
    rhs_slice_target = (object_ptr)&_43ifdef_lineno_59908;
    RHS_Slice(_43ifdef_lineno_59908, 1, _30000);

    /** parser.e:3221		No_new_entry = 0*/
    _53No_new_entry_48382 = 0;

    /** parser.e:3222	end procedure*/
    DeRef(_option_59911);
    DeRef(_tok_59918);
    DeRefi(_keyw_59919);
    DeRef(_29988);
    _29988 = NOVALUE;
    DeRef(_29922);
    _29922 = NOVALUE;
    _30000 = NOVALUE;
    DeRef(_29968);
    _29968 = NOVALUE;
    DeRef(_29893);
    _29893 = NOVALUE;
    DeRef(_29887);
    _29887 = NOVALUE;
    return;
    ;
}


object _43SetPrivateScope(object _s_60198, object _type_sym_60200, object _n_60201)
{
    object _hashval_60202 = NOVALUE;
    object _scope_60203 = NOVALUE;
    object _t_60205 = NOVALUE;
    object _30021 = NOVALUE;
    object _30020 = NOVALUE;
    object _30019 = NOVALUE;
    object _30018 = NOVALUE;
    object _30017 = NOVALUE;
    object _30016 = NOVALUE;
    object _30013 = NOVALUE;
    object _30010 = NOVALUE;
    object _30008 = NOVALUE;
    object _30006 = NOVALUE;
    object _30002 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_60198)) {
        _1 = (object)(DBL_PTR(_s_60198)->dbl);
        DeRefDS(_s_60198);
        _s_60198 = _1;
    }

    /** parser.e:3230		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30002 = (object)*(((s1_ptr)_2)->base + _s_60198);
    _2 = (object)SEQ_PTR(_30002);
    _scope_60203 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_60203)){
        _scope_60203 = (object)DBL_PTR(_scope_60203)->dbl;
    }
    _30002 = NOVALUE;

    /** parser.e:3231		switch scope do*/
    _0 = _scope_60203;
    switch ( _0 ){ 

        /** parser.e:3232			case SC_PRIVATE then*/
        case 3:

        /** parser.e:3233				DefinedYet(s)*/
        _53DefinedYet(_s_60198);

        /** parser.e:3234				Block_var( s )*/
        _64Block_var(_s_60198);

        /** parser.e:3235				return s*/
        return _s_60198;
        goto L1; // [50] 260

        /** parser.e:3237			case SC_LOOP_VAR then*/
        case 2:

        /** parser.e:3238				DefinedYet(s)*/
        _53DefinedYet(_s_60198);

        /** parser.e:3239				return s*/
        return _s_60198;
        goto L1; // [67] 260

        /** parser.e:3241			case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** parser.e:3242				SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60198 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 4);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 3;
        DeRef(_1);
        _30006 = NOVALUE;

        /** parser.e:3243				SymTab[s][S_VARNUM] = n*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60198 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 16);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _n_60201;
        DeRef(_1);
        _30008 = NOVALUE;

        /** parser.e:3244				SymTab[s][S_VTYPE] = type_sym*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_60198 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _type_sym_60200;
        DeRef(_1);
        _30010 = NOVALUE;

        /** parser.e:3245				if type_sym < 0 then*/
        if (_type_sym_60200 >= 0)
        goto L2; // [124] 135

        /** parser.e:3246					register_forward_type( s, type_sym )*/
        _42register_forward_type(_s_60198, _type_sym_60200);
L2: 

        /** parser.e:3248				Block_var( s )*/
        _64Block_var(_s_60198);

        /** parser.e:3249				return s*/
        return _s_60198;
        goto L1; // [146] 260

        /** parser.e:3251			case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** parser.e:3252				hashval = SymTab[s][S_HASHVAL]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30013 = (object)*(((s1_ptr)_2)->base + _s_60198);
        _2 = (object)SEQ_PTR(_30013);
        _hashval_60202 = (object)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_60202)){
            _hashval_60202 = (object)DBL_PTR(_hashval_60202)->dbl;
        }
        _30013 = NOVALUE;

        /** parser.e:3253				t = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _t_60205 = (object)*(((s1_ptr)_2)->base + _hashval_60202);
        if (!IS_ATOM_INT(_t_60205)){
            _t_60205 = (object)DBL_PTR(_t_60205)->dbl;
        }

        /** parser.e:3254				buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30016 = (object)*(((s1_ptr)_2)->base + _s_60198);
        _2 = (object)SEQ_PTR(_30016);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _30017 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _30017 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        _30016 = NOVALUE;
        Ref(_30017);
        _30018 = _53NewEntry(_30017, _n_60201, 3, -100, _hashval_60202, _t_60205, _type_sym_60200);
        _30017 = NOVALUE;
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_60202);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30018;
        if( _1 != _30018 ){
            DeRef(_1);
        }
        _30018 = NOVALUE;

        /** parser.e:3256				Block_var( buckets[hashval] )*/
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _30019 = (object)*(((s1_ptr)_2)->base + _hashval_60202);
        Ref(_30019);
        _64Block_var(_30019);
        _30019 = NOVALUE;

        /** parser.e:3257				return buckets[hashval]*/
        _2 = (object)SEQ_PTR(_53buckets_47180);
        _30020 = (object)*(((s1_ptr)_2)->base + _hashval_60202);
        Ref(_30020);
        return _30020;
        goto L1; // [243] 260

        /** parser.e:3259			case else*/
        default:

        /** parser.e:3260				InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _scope_60203;
        _30021 = MAKE_SEQ(_1);
        _49InternalErr(267, _30021);
        _30021 = NOVALUE;
    ;}L1: 

    /** parser.e:3264		return 0*/
    _30020 = NOVALUE;
    return 0;
    ;
}


void _43For_statement()
{
    object _bp1_60270 = NOVALUE;
    object _bp2_60271 = NOVALUE;
    object _exit_base_60272 = NOVALUE;
    object _next_base_60273 = NOVALUE;
    object _end_op_60274 = NOVALUE;
    object _tok_60276 = NOVALUE;
    object _loop_var_60277 = NOVALUE;
    object _loop_var_sym_60279 = NOVALUE;
    object _save_syms_60280 = NOVALUE;
    object _30068 = NOVALUE;
    object _30066 = NOVALUE;
    object _30065 = NOVALUE;
    object _30059 = NOVALUE;
    object _30057 = NOVALUE;
    object _30055 = NOVALUE;
    object _30054 = NOVALUE;
    object _30053 = NOVALUE;
    object _30052 = NOVALUE;
    object _30050 = NOVALUE;
    object _30048 = NOVALUE;
    object _30047 = NOVALUE;
    object _30046 = NOVALUE;
    object _30045 = NOVALUE;
    object _30043 = NOVALUE;
    object _30041 = NOVALUE;
    object _30037 = NOVALUE;
    object _30035 = NOVALUE;
    object _30032 = NOVALUE;
    object _30030 = NOVALUE;
    object _30024 = NOVALUE;
    object _30023 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3273		sequence save_syms*/

    /** parser.e:3275		Start_block( FOR )*/
    _64Start_block(21, 0);

    /** parser.e:3276		loop_var = next_token()*/
    _0 = _loop_var_60277;
    _loop_var_60277 = _43next_token();
    DeRef(_0);

    /** parser.e:3277		if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_loop_var_60277);
    _30023 = (object)*(((s1_ptr)_2)->base + 1);
    _30024 = find_from(_30023, _29ADDR_TOKS_12281, 1);
    _30023 = NOVALUE;
    if (_30024 != 0)
    goto L1; // [31] 44
    _30024 = NOVALUE;

    /** parser.e:3278			CompileErr(A_LOOP_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(28, _22209, 0);
L1: 

    /** parser.e:3281		if BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L2; // [48] 57
    }
    else{
    }

    /** parser.e:3282			add_ref(loop_var)*/
    Ref(_loop_var_60277);
    _53add_ref(_loop_var_60277);
L2: 

    /** parser.e:3285		tok_match(EQUALS)*/
    _43tok_match(3, 0);

    /** parser.e:3286		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _exit_base_60272 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _exit_base_60272 = 1;
    }

    /** parser.e:3287		next_base = length(continue_list)*/
    if (IS_SEQUENCE(_43continue_list_55427)){
            _next_base_60273 = SEQ_PTR(_43continue_list_55427)->length;
    }
    else {
        _next_base_60273 = 1;
    }

    /** parser.e:3288		Expr()*/
    _43Expr();

    /** parser.e:3289		tok_match(TO)*/
    _43tok_match(403, 0);

    /** parser.e:3290		exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_43exit_list_55425)){
            _exit_base_60272 = SEQ_PTR(_43exit_list_55425)->length;
    }
    else {
        _exit_base_60272 = 1;
    }

    /** parser.e:3291		Expr()*/
    _43Expr();

    /** parser.e:3292		tok = next_token()*/
    _0 = _tok_60276;
    _tok_60276 = _43next_token();
    DeRef(_0);

    /** parser.e:3293		if tok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_tok_60276);
    _30030 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30030, 404)){
        _30030 = NOVALUE;
        goto L3; // [117] 137
    }
    _30030 = NOVALUE;

    /** parser.e:3294			Expr()*/
    _43Expr();

    /** parser.e:3295			end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_60274 = 39;
    goto L4; // [134] 161
L3: 

    /** parser.e:3298			emit_opnd(NewIntSym(1))*/
    _30032 = _53NewIntSym(1);
    _45emit_opnd(_30032);
    _30032 = NOVALUE;

    /** parser.e:3299			putback(tok)*/
    Ref(_tok_60276);
    _43putback(_tok_60276);

    /** parser.e:3300			end_op = ENDFOR_INT_UP1*/
    _end_op_60274 = 54;
L4: 

    /** parser.e:3303		loop_var_sym = loop_var[T_SYM]*/
    _2 = (object)SEQ_PTR(_loop_var_60277);
    _loop_var_sym_60279 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_60279)){
        _loop_var_sym_60279 = (object)DBL_PTR(_loop_var_sym_60279)->dbl;
    }

    /** parser.e:3304		if CurrentSub = TopLevelSub then*/
    if (_27CurrentSub_20579 != _27TopLevelSub_20578)
    goto L5; // [177] 223

    /** parser.e:3305			DefinedYet(loop_var_sym)*/
    _53DefinedYet(_loop_var_sym_60279);

    /** parser.e:3306			SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60279 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4;
    DeRef(_1);
    _30035 = NOVALUE;

    /** parser.e:3307			SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60279 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_47184;
    DeRef(_1);
    _30037 = NOVALUE;
    goto L6; // [220] 267
L5: 

    /** parser.e:3309			loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_60279 = _43SetPrivateScope(_loop_var_sym_60279, _53object_type_47184, _43param_num_55414);
    if (!IS_ATOM_INT(_loop_var_sym_60279)) {
        _1 = (object)(DBL_PTR(_loop_var_sym_60279)->dbl);
        DeRefDS(_loop_var_sym_60279);
        _loop_var_sym_60279 = _1;
    }

    /** parser.e:3310			param_num += 1*/
    _43param_num_55414 = _43param_num_55414 + 1;

    /** parser.e:3311			SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60279 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30041 = NOVALUE;

    /** parser.e:3312			Pop_block_var()*/
    _64Pop_block_var();
L6: 

    /** parser.e:3314		SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_loop_var_sym_60279 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30045 = (object)*(((s1_ptr)_2)->base + _loop_var_sym_60279);
    _2 = (object)SEQ_PTR(_30045);
    _30046 = (object)*(((s1_ptr)_2)->base + 5);
    _30045 = NOVALUE;
    if (IS_ATOM_INT(_30046)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30046 | (uintptr_t)3;
             _30047 = MAKE_UINT(tu);
        }
    }
    else {
        _30047 = binary_op(OR_BITS, _30046, 3);
    }
    _30046 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30047;
    if( _1 != _30047 ){
        DeRef(_1);
    }
    _30047 = NOVALUE;
    _30043 = NOVALUE;

    /** parser.e:3316		op_info1 = loop_var_sym*/
    _45op_info1_51413 = _loop_var_sym_60279;

    /** parser.e:3317		emit_op(FOR)*/
    _45emit_op(21);

    /** parser.e:3318		emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_60279);

    /** parser.e:3319		if finish_block_header(FOR) then*/
    _30048 = _43finish_block_header(21);
    if (_30048 == 0) {
        DeRef(_30048);
        _30048 = NOVALUE;
        goto L7; // [327] 340
    }
    else {
        if (!IS_ATOM_INT(_30048) && DBL_PTR(_30048)->dbl == 0.0){
            DeRef(_30048);
            _30048 = NOVALUE;
            goto L7; // [327] 340
        }
        DeRef(_30048);
        _30048 = NOVALUE;
    }
    DeRef(_30048);
    _30048 = NOVALUE;

    /** parser.e:3320			CompileErr(ENTRY_IS_NOT_SUPPORTED_IN_FOR_LOOPS)*/
    RefDS(_22209);
    _49CompileErr(83, _22209, 0);
L7: 

    /** parser.e:3322		entry_addr &= 0*/
    Append(&_43entry_addr_55429, _43entry_addr_55429, 0);

    /** parser.e:3323		bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30050 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30050 = 1;
    }
    _bp1_60270 = _30050 + 1;
    _30050 = NOVALUE;

    /** parser.e:3324		emit_addr(0) -- will be patched - don't straighten*/
    _45emit_addr(0);

    /** parser.e:3326		save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30052 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30052 = 1;
    }
    _30053 = _30052 - 5;
    _30052 = NOVALUE;
    if (IS_SEQUENCE(_27Code_20660)){
            _30054 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30054 = 1;
    }
    _30055 = _30054 - 3;
    _30054 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_60280;
    RHS_Slice(_27Code_20660, _30053, _30055);

    /** parser.e:3327		for i = 1 to 3 do*/
    {
        object _i_60370;
        _i_60370 = 1;
L8: 
        if (_i_60370 > 3){
            goto L9; // [389] 412
        }

        /** parser.e:3328			clear_temp( save_syms[i] )*/
        _2 = (object)SEQ_PTR(_save_syms_60280);
        _30057 = (object)*(((s1_ptr)_2)->base + _i_60370);
        Ref(_30057);
        _45clear_temp(_30057);
        _30057 = NOVALUE;

        /** parser.e:3329		end for*/
        _i_60370 = _i_60370 + 1;
        goto L8; // [407] 396
L9: 
        ;
    }

    /** parser.e:3330		flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:3332		bp2 = length(Code)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _bp2_60271 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _bp2_60271 = 1;
    }

    /** parser.e:3333		retry_addr &= bp2 + 1*/
    _30059 = _bp2_60271 + 1;
    Append(&_43retry_addr_55431, _43retry_addr_55431, _30059);
    _30059 = NOVALUE;

    /** parser.e:3334		continue_addr &= 0*/
    Append(&_43continue_addr_55430, _43continue_addr_55430, 0);

    /** parser.e:3336		loop_stack &= FOR*/
    Append(&_43loop_stack_55439, _43loop_stack_55439, 21);

    /** parser.e:3338		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto LA; // [458] 482

    /** parser.e:3339			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LB; // [465] 481
    }
    else{
    }

    /** parser.e:3340				emit_op(DISPLAY_VAR)*/
    _45emit_op(87);

    /** parser.e:3341				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_60279);
LB: 
LA: 

    /** parser.e:3345		Statement_list()*/
    _43Statement_list();

    /** parser.e:3346		tok_match(END)*/
    _43tok_match(402, 0);

    /** parser.e:3347		tok_match(FOR, END)*/
    _43tok_match(21, 402);

    /** parser.e:3349		End_block( FOR )*/
    _64End_block(21);

    /** parser.e:3351		StartSourceLine(TRUE, TRANSLATE)*/
    _45StartSourceLine(_9TRUE_441, _27TRANSLATE_20179, 2);

    /** parser.e:3352		op_info1 = loop_var_sym*/
    _45op_info1_51413 = _loop_var_sym_60279;

    /** parser.e:3353		op_info2 = bp2 + 1*/
    _45op_info2_51414 = _bp2_60271 + 1;

    /** parser.e:3354		PatchNList(next_base)*/
    _43PatchNList(_next_base_60273);

    /** parser.e:3355		emit_op(end_op)*/
    _45emit_op(_end_op_60274);

    /** parser.e:3356		backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30065 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30065 = 1;
    }
    _30066 = _30065 + 1;
    _30065 = NOVALUE;
    _45backpatch(_bp1_60270, _30066);
    _30066 = NOVALUE;

    /** parser.e:3357		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto LC; // [568] 592

    /** parser.e:3358			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LD; // [575] 591
    }
    else{
    }

    /** parser.e:3359				emit_op(ERASE_SYMBOL)*/
    _45emit_op(90);

    /** parser.e:3360				emit_addr(loop_var_sym)*/
    _45emit_addr(_loop_var_sym_60279);
LD: 
LC: 

    /** parser.e:3364		Hide(loop_var_sym)*/
    _53Hide(_loop_var_sym_60279);

    /** parser.e:3365		exit_loop(exit_base)*/
    _43exit_loop(_exit_base_60272);

    /** parser.e:3366		for i = 1 to 3 do*/
    {
        object _i_60416;
        _i_60416 = 1;
LE: 
        if (_i_60416 > 3){
            goto LF; // [604] 630
        }

        /** parser.e:3367			emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (object)SEQ_PTR(_save_syms_60280);
        _30068 = (object)*(((s1_ptr)_2)->base + _i_60416);
        Ref(_30068);
        _45emit_temp(_30068, 1);
        _30068 = NOVALUE;

        /** parser.e:3368		end for*/
        _i_60416 = _i_60416 + 1;
        goto LE; // [625] 611
LF: 
        ;
    }

    /** parser.e:3369		flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:3370	end procedure*/
    DeRef(_tok_60276);
    DeRef(_loop_var_60277);
    DeRef(_save_syms_60280);
    DeRef(_30055);
    _30055 = NOVALUE;
    DeRef(_30053);
    _30053 = NOVALUE;
    return;
    ;
}


object _43CompileType(object _type_ptr_60424)
{
    object _t_60425 = NOVALUE;
    object _30079 = NOVALUE;
    object _30078 = NOVALUE;
    object _30077 = NOVALUE;
    object _30071 = NOVALUE;
    object _30070 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_60424)) {
        _1 = (object)(DBL_PTR(_type_ptr_60424)->dbl);
        DeRefDS(_type_ptr_60424);
        _type_ptr_60424 = _1;
    }

    /** parser.e:3376		if type_ptr < 0 then*/
    if (_type_ptr_60424 >= 0)
    goto L1; // [5] 16

    /** parser.e:3378			return type_ptr*/
    return _type_ptr_60424;
L1: 

    /** parser.e:3381		if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30070 = (object)*(((s1_ptr)_2)->base + _type_ptr_60424);
    _2 = (object)SEQ_PTR(_30070);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _30071 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _30071 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _30070 = NOVALUE;
    if (binary_op_a(NOTEQ, _30071, 415)){
        _30071 = NOVALUE;
        goto L2; // [32] 47
    }
    _30071 = NOVALUE;

    /** parser.e:3382			return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** parser.e:3384		elsif type_ptr = integer_type then*/
    if (_type_ptr_60424 != _53integer_type_47190)
    goto L4; // [51] 66

    /** parser.e:3385			return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** parser.e:3387		elsif type_ptr = atom_type then*/
    if (_type_ptr_60424 != _53atom_type_47186)
    goto L5; // [70] 85

    /** parser.e:3388			return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** parser.e:3390		elsif type_ptr = sequence_type then*/
    if (_type_ptr_60424 != _53sequence_type_47188)
    goto L6; // [89] 104

    /** parser.e:3391			return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** parser.e:3393		elsif type_ptr = object_type then*/
    if (_type_ptr_60424 != _53object_type_47184)
    goto L7; // [108] 123

    /** parser.e:3394			return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** parser.e:3398			t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30077 = (object)*(((s1_ptr)_2)->base + _type_ptr_60424);
    _2 = (object)SEQ_PTR(_30077);
    _30078 = (object)*(((s1_ptr)_2)->base + 2);
    _30077 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30078)){
        _30079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30078)->dbl));
    }
    else{
        _30079 = (object)*(((s1_ptr)_2)->base + _30078);
    }
    _2 = (object)SEQ_PTR(_30079);
    _t_60425 = (object)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_60425)){
        _t_60425 = (object)DBL_PTR(_t_60425)->dbl;
    }
    _30079 = NOVALUE;

    /** parser.e:3399			if t = integer_type then*/
    if (_t_60425 != _53integer_type_47190)
    goto L8; // [155] 170

    /** parser.e:3400				return TYPE_INTEGER*/
    _30078 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** parser.e:3401			elsif t = atom_type then*/
    if (_t_60425 != _53atom_type_47186)
    goto LA; // [174] 189

    /** parser.e:3402				return TYPE_ATOM*/
    _30078 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** parser.e:3403			elsif t = sequence_type then*/
    if (_t_60425 != _53sequence_type_47188)
    goto LB; // [193] 208

    /** parser.e:3404				return TYPE_SEQUENCE*/
    _30078 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** parser.e:3406				return TYPE_OBJECT*/
    _30078 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


object _43get_assigned_sym()
{
    object _30092 = NOVALUE;
    object _30091 = NOVALUE;
    object _30090 = NOVALUE;
    object _30088 = NOVALUE;
    object _30087 = NOVALUE;
    object _30086 = NOVALUE;
    object _30085 = NOVALUE;
    object _30084 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3416		if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30084 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30084 = 1;
    }
    _30085 = _30084 - 2;
    _30084 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _30086 = (object)*(((s1_ptr)_2)->base + _30085);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 18;
    ((intptr_t *)_2)[2] = 113;
    _30087 = MAKE_SEQ(_1);
    _30088 = find_from(_30086, _30087, 1);
    _30086 = NOVALUE;
    DeRefDS(_30087);
    _30087 = NOVALUE;
    if (_30088 != 0)
    goto L1; // [29] 39
    _30088 = NOVALUE;

    /** parser.e:3417			return 0*/
    _30085 = NOVALUE;
    return 0;
L1: 

    /** parser.e:3419		return Code[$-1]*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30090 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30090 = 1;
    }
    _30091 = _30090 - 1;
    _30090 = NOVALUE;
    _2 = (object)SEQ_PTR(_27Code_20660);
    _30092 = (object)*(((s1_ptr)_2)->base + _30091);
    Ref(_30092);
    DeRef(_30085);
    _30085 = NOVALUE;
    _30091 = NOVALUE;
    return _30092;
    ;
}


void _43Assign_Constant(object _sym_60494)
{
    object _valsym_60496 = NOVALUE;
    object _val_60499 = NOVALUE;
    object _30119 = NOVALUE;
    object _30118 = NOVALUE;
    object _30116 = NOVALUE;
    object _30115 = NOVALUE;
    object _30114 = NOVALUE;
    object _30112 = NOVALUE;
    object _30111 = NOVALUE;
    object _30110 = NOVALUE;
    object _30108 = NOVALUE;
    object _30107 = NOVALUE;
    object _30106 = NOVALUE;
    object _30104 = NOVALUE;
    object _30103 = NOVALUE;
    object _30102 = NOVALUE;
    object _30100 = NOVALUE;
    object _30098 = NOVALUE;
    object _30096 = NOVALUE;
    object _30094 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3423		symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_60496 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60496)) {
        _1 = (object)(DBL_PTR(_valsym_60496)->dbl);
        DeRefDS(_valsym_60496);
        _valsym_60496 = _1;
    }

    /** parser.e:3424		object val = SymTab[valsym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30094 = (object)*(((s1_ptr)_2)->base + _valsym_60496);
    DeRef(_val_60499);
    _2 = (object)SEQ_PTR(_30094);
    _val_60499 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_val_60499);
    _30094 = NOVALUE;

    /** parser.e:3426		SymTab[sym][S_OBJ] = val*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    Ref(_val_60499);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_60499;
    DeRef(_1);
    _30096 = NOVALUE;

    /** parser.e:3427		SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30098 = NOVALUE;

    /** parser.e:3429		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** parser.e:3431			SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30102 = (object)*(((s1_ptr)_2)->base + _valsym_60496);
    _2 = (object)SEQ_PTR(_30102);
    _30103 = (object)*(((s1_ptr)_2)->base + 36);
    _30102 = NOVALUE;
    Ref(_30103);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30103;
    if( _1 != _30103 ){
        DeRef(_1);
    }
    _30103 = NOVALUE;
    _30100 = NOVALUE;

    /** parser.e:3432			SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30106 = (object)*(((s1_ptr)_2)->base + _valsym_60496);
    _2 = (object)SEQ_PTR(_30106);
    _30107 = (object)*(((s1_ptr)_2)->base + 33);
    _30106 = NOVALUE;
    Ref(_30107);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30107;
    if( _1 != _30107 ){
        DeRef(_1);
    }
    _30107 = NOVALUE;
    _30104 = NOVALUE;

    /** parser.e:3433			SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30110 = (object)*(((s1_ptr)_2)->base + _valsym_60496);
    _2 = (object)SEQ_PTR(_30110);
    _30111 = (object)*(((s1_ptr)_2)->base + 30);
    _30110 = NOVALUE;
    Ref(_30111);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30111;
    if( _1 != _30111 ){
        DeRef(_1);
    }
    _30111 = NOVALUE;
    _30108 = NOVALUE;

    /** parser.e:3434			SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30114 = (object)*(((s1_ptr)_2)->base + _valsym_60496);
    _2 = (object)SEQ_PTR(_30114);
    _30115 = (object)*(((s1_ptr)_2)->base + 31);
    _30114 = NOVALUE;
    Ref(_30115);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30115;
    if( _1 != _30115 ){
        DeRef(_1);
    }
    _30115 = NOVALUE;
    _30112 = NOVALUE;

    /** parser.e:3435			SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60494 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30118 = (object)*(((s1_ptr)_2)->base + _valsym_60496);
    _2 = (object)SEQ_PTR(_30118);
    _30119 = (object)*(((s1_ptr)_2)->base + 32);
    _30118 = NOVALUE;
    Ref(_30119);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30119;
    if( _1 != _30119 ){
        DeRef(_1);
    }
    _30119 = NOVALUE;
    _30116 = NOVALUE;
L1: 

    /** parser.e:3437	end procedure*/
    DeRef(_val_60499);
    return;
    ;
}


object _43Global_declaration(object _type_ptr_60556, object _scope_60557)
{
    object _new_symbols_60558 = NOVALUE;
    object _tok_60560 = NOVALUE;
    object _tsym_60561 = NOVALUE;
    object _prevtok_60562 = NOVALUE;
    object _sym_60564 = NOVALUE;
    object _valsym_60565 = NOVALUE;
    object _h_60566 = NOVALUE;
    object _count_60567 = NOVALUE;
    object _val_60568 = NOVALUE;
    object _usedval_60569 = NOVALUE;
    object _deltafunc_60570 = NOVALUE;
    object _delta_60571 = NOVALUE;
    object _is_fwd_ref_60572 = NOVALUE;
    object _ptok_60589 = NOVALUE;
    object _negate_60605 = NOVALUE;
    object _negate_60854 = NOVALUE;
    object _31977 = NOVALUE;
    object _31976 = NOVALUE;
    object _31975 = NOVALUE;
    object _30359 = NOVALUE;
    object _30357 = NOVALUE;
    object _30355 = NOVALUE;
    object _30353 = NOVALUE;
    object _30351 = NOVALUE;
    object _30348 = NOVALUE;
    object _30346 = NOVALUE;
    object _30345 = NOVALUE;
    object _30344 = NOVALUE;
    object _30343 = NOVALUE;
    object _30342 = NOVALUE;
    object _30341 = NOVALUE;
    object _30339 = NOVALUE;
    object _30335 = NOVALUE;
    object _30333 = NOVALUE;
    object _30331 = NOVALUE;
    object _30329 = NOVALUE;
    object _30327 = NOVALUE;
    object _30325 = NOVALUE;
    object _30324 = NOVALUE;
    object _30322 = NOVALUE;
    object _30321 = NOVALUE;
    object _30320 = NOVALUE;
    object _30318 = NOVALUE;
    object _30316 = NOVALUE;
    object _30314 = NOVALUE;
    object _30313 = NOVALUE;
    object _30312 = NOVALUE;
    object _30310 = NOVALUE;
    object _30309 = NOVALUE;
    object _30308 = NOVALUE;
    object _30306 = NOVALUE;
    object _30304 = NOVALUE;
    object _30302 = NOVALUE;
    object _30301 = NOVALUE;
    object _30300 = NOVALUE;
    object _30299 = NOVALUE;
    object _30298 = NOVALUE;
    object _30295 = NOVALUE;
    object _30293 = NOVALUE;
    object _30291 = NOVALUE;
    object _30290 = NOVALUE;
    object _30289 = NOVALUE;
    object _30285 = NOVALUE;
    object _30284 = NOVALUE;
    object _30283 = NOVALUE;
    object _30279 = NOVALUE;
    object _30278 = NOVALUE;
    object _30277 = NOVALUE;
    object _30275 = NOVALUE;
    object _30274 = NOVALUE;
    object _30273 = NOVALUE;
    object _30272 = NOVALUE;
    object _30271 = NOVALUE;
    object _30270 = NOVALUE;
    object _30269 = NOVALUE;
    object _30268 = NOVALUE;
    object _30267 = NOVALUE;
    object _30264 = NOVALUE;
    object _30262 = NOVALUE;
    object _30261 = NOVALUE;
    object _30259 = NOVALUE;
    object _30258 = NOVALUE;
    object _30256 = NOVALUE;
    object _30255 = NOVALUE;
    object _30254 = NOVALUE;
    object _30253 = NOVALUE;
    object _30251 = NOVALUE;
    object _30249 = NOVALUE;
    object _30247 = NOVALUE;
    object _30244 = NOVALUE;
    object _30241 = NOVALUE;
    object _30238 = NOVALUE;
    object _30236 = NOVALUE;
    object _30235 = NOVALUE;
    object _30234 = NOVALUE;
    object _30233 = NOVALUE;
    object _30231 = NOVALUE;
    object _30230 = NOVALUE;
    object _30229 = NOVALUE;
    object _30228 = NOVALUE;
    object _30224 = NOVALUE;
    object _30223 = NOVALUE;
    object _30222 = NOVALUE;
    object _30221 = NOVALUE;
    object _30220 = NOVALUE;
    object _30219 = NOVALUE;
    object _30216 = NOVALUE;
    object _30214 = NOVALUE;
    object _30213 = NOVALUE;
    object _30212 = NOVALUE;
    object _30211 = NOVALUE;
    object _30210 = NOVALUE;
    object _30207 = NOVALUE;
    object _30205 = NOVALUE;
    object _30203 = NOVALUE;
    object _30202 = NOVALUE;
    object _30201 = NOVALUE;
    object _30200 = NOVALUE;
    object _30199 = NOVALUE;
    object _30198 = NOVALUE;
    object _30197 = NOVALUE;
    object _30195 = NOVALUE;
    object _30192 = NOVALUE;
    object _30190 = NOVALUE;
    object _30189 = NOVALUE;
    object _30188 = NOVALUE;
    object _30187 = NOVALUE;
    object _30186 = NOVALUE;
    object _30185 = NOVALUE;
    object _30184 = NOVALUE;
    object _30183 = NOVALUE;
    object _30180 = NOVALUE;
    object _30179 = NOVALUE;
    object _30178 = NOVALUE;
    object _30176 = NOVALUE;
    object _30175 = NOVALUE;
    object _30174 = NOVALUE;
    object _30173 = NOVALUE;
    object _30172 = NOVALUE;
    object _30170 = NOVALUE;
    object _30169 = NOVALUE;
    object _30168 = NOVALUE;
    object _30166 = NOVALUE;
    object _30165 = NOVALUE;
    object _30163 = NOVALUE;
    object _30160 = NOVALUE;
    object _30158 = NOVALUE;
    object _30156 = NOVALUE;
    object _30148 = NOVALUE;
    object _30147 = NOVALUE;
    object _30145 = NOVALUE;
    object _30142 = NOVALUE;
    object _30135 = NOVALUE;
    object _30132 = NOVALUE;
    object _30131 = NOVALUE;
    object _30129 = NOVALUE;
    object _30125 = NOVALUE;
    object _30124 = NOVALUE;
    object _30123 = NOVALUE;
    object _30122 = NOVALUE;
    object _30121 = NOVALUE;
    object _30120 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_60556)) {
        _1 = (object)(DBL_PTR(_type_ptr_60556)->dbl);
        DeRefDS(_type_ptr_60556);
        _type_ptr_60556 = _1;
    }

    /** parser.e:3447		object tsym*/

    /** parser.e:3448		object prevtok = 0*/
    DeRef(_prevtok_60562);
    _prevtok_60562 = 0;

    /** parser.e:3450		integer h, count = 0*/
    _count_60567 = 0;

    /** parser.e:3451		atom val = 1, usedval*/
    DeRef(_val_60568);
    _val_60568 = 1;

    /** parser.e:3452		integer deltafunc = '+'*/
    _deltafunc_60570 = 43;

    /** parser.e:3453		atom delta = 1*/
    DeRef(_delta_60571);
    _delta_60571 = 1;

    /** parser.e:3455		new_symbols = {}*/
    RefDS(_22209);
    DeRefi(_new_symbols_60558);
    _new_symbols_60558 = _22209;

    /** parser.e:3456		integer is_fwd_ref = 0*/
    _is_fwd_ref_60572 = 0;

    /** parser.e:3457		if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _30120 = (_type_ptr_60556 > 0);
    if (_30120 == 0) {
        goto L1; // [50] 105
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30122 = (object)*(((s1_ptr)_2)->base + _type_ptr_60556);
    _2 = (object)SEQ_PTR(_30122);
    _30123 = (object)*(((s1_ptr)_2)->base + 4);
    _30122 = NOVALUE;
    if (IS_ATOM_INT(_30123)) {
        _30124 = (_30123 == 9);
    }
    else {
        _30124 = binary_op(EQUALS, _30123, 9);
    }
    _30123 = NOVALUE;
    if (_30124 == 0) {
        DeRef(_30124);
        _30124 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_30124) && DBL_PTR(_30124)->dbl == 0.0){
            DeRef(_30124);
            _30124 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_30124);
        _30124 = NOVALUE;
    }
    DeRef(_30124);
    _30124 = NOVALUE;

    /** parser.e:3458			is_fwd_ref = 1*/
    _is_fwd_ref_60572 = 1;

    /** parser.e:3459			Hide(type_ptr)*/
    _53Hide(_type_ptr_60556);

    /** parser.e:3460			type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31977);
    _31977 = 504;
    _30125 = _42new_forward_reference(504, _type_ptr_60556, 504);
    _31977 = NOVALUE;
    if (IS_ATOM_INT(_30125)) {
        if ((uintptr_t)_30125 == (uintptr_t)HIGH_BITS){
            _type_ptr_60556 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_ptr_60556 = - _30125;
        }
    }
    else {
        _type_ptr_60556 = unary_op(UMINUS, _30125);
    }
    DeRef(_30125);
    _30125 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_60556)) {
        _1 = (object)(DBL_PTR(_type_ptr_60556)->dbl);
        DeRefDS(_type_ptr_60556);
        _type_ptr_60556 = _1;
    }
L1: 

    /** parser.e:3463		if type_ptr = -1 then*/
    if (_type_ptr_60556 != -1)
    goto L2; // [107] 426

    /** parser.e:3465			sequence ptok = next_token()*/
    _0 = _ptok_60589;
    _ptok_60589 = _43next_token();
    DeRef(_0);

    /** parser.e:3466			if ptok[T_ID] = TYPE_DECL then*/
    _2 = (object)SEQ_PTR(_ptok_60589);
    _30129 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30129, 416)){
        _30129 = NOVALUE;
        goto L3; // [128] 172
    }
    _30129 = NOVALUE;

    /** parser.e:3469				putback(keyfind("enum",-1))*/
    RefDS(_26474);
    DeRef(_31975);
    _31975 = _26474;
    _31976 = _53hashfn(_31975);
    _31975 = NOVALUE;
    RefDS(_26474);
    _30131 = _53keyfind(_26474, -1, _27current_file_no_20571, 0, _31976);
    _31976 = NOVALUE;
    _43putback(_30131);
    _30131 = NOVALUE;

    /** parser.e:3470				SubProg(TYPE_DECL, scope, 0)*/
    _43SubProg(416, _scope_60557, 0);

    /** parser.e:3471				return {}*/
    RefDS(_22209);
    DeRefDS(_ptok_60589);
    DeRefi(_new_symbols_60558);
    DeRef(_tok_60560);
    DeRef(_tsym_60561);
    DeRef(_prevtok_60562);
    DeRef(_val_60568);
    DeRef(_usedval_60569);
    DeRef(_delta_60571);
    DeRef(_30120);
    _30120 = NOVALUE;
    return _22209;
    goto L4; // [169] 425
L3: 

    /** parser.e:3472			elsif ptok[T_ID] = BY then*/
    _2 = (object)SEQ_PTR(_ptok_60589);
    _30132 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30132, 404)){
        _30132 = NOVALUE;
        goto L5; // [182] 419
    }
    _30132 = NOVALUE;

    /** parser.e:3474				integer negate = 0*/
    _negate_60605 = 0;

    /** parser.e:3475				ptok = next_token()*/
    _0 = _ptok_60589;
    _ptok_60589 = _43next_token();
    DeRefDS(_0);

    /** parser.e:3476				switch ptok[T_ID] do*/
    _2 = (object)SEQ_PTR(_ptok_60589);
    _30135 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30135) ){
        goto L6; // [206] 285
    }
    if(!IS_ATOM_INT(_30135)){
        if( (DBL_PTR(_30135)->dbl != (eudouble) ((object) DBL_PTR(_30135)->dbl) ) ){
            goto L6; // [206] 285
        }
        _0 = (object) DBL_PTR(_30135)->dbl;
    }
    else {
        _0 = _30135;
    };
    _30135 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3477					case reserved:MULTIPLY then*/
        case 13:

        /** parser.e:3478						deltafunc = '*'*/
        _deltafunc_60570 = 42;

        /** parser.e:3479						ptok = next_token()*/
        _0 = _ptok_60589;
        _ptok_60589 = _43next_token();
        DeRef(_0);
        goto L7; // [227] 293

        /** parser.e:3481					case reserved:DIVIDE then*/
        case 14:

        /** parser.e:3482						deltafunc = '/'*/
        _deltafunc_60570 = 47;

        /** parser.e:3483						ptok = next_token()*/
        _0 = _ptok_60589;
        _ptok_60589 = _43next_token();
        DeRef(_0);
        goto L7; // [245] 293

        /** parser.e:3485					case MINUS then*/
        case 10:

        /** parser.e:3486						deltafunc = '-'*/
        _deltafunc_60570 = 45;

        /** parser.e:3487						ptok = next_token()*/
        _0 = _ptok_60589;
        _ptok_60589 = _43next_token();
        DeRef(_0);
        goto L7; // [263] 293

        /** parser.e:3489					case PLUS then*/
        case 11:

        /** parser.e:3490						deltafunc = '+'*/
        _deltafunc_60570 = 43;

        /** parser.e:3491						ptok = next_token()*/
        _0 = _ptok_60589;
        _ptok_60589 = _43next_token();
        DeRef(_0);
        goto L7; // [281] 293

        /** parser.e:3493					case else*/
        default:
L6: 

        /** parser.e:3494						deltafunc = '+'*/
        _deltafunc_60570 = 43;
    ;}L7: 

    /** parser.e:3498				if ptok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_ptok_60589);
    _30142 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30142, 10)){
        _30142 = NOVALUE;
        goto L8; // [303] 320
    }
    _30142 = NOVALUE;

    /** parser.e:3499					negate = 1*/
    _negate_60605 = 1;

    /** parser.e:3500					ptok = next_token()*/
    _0 = _ptok_60589;
    _ptok_60589 = _43next_token();
    DeRefDS(_0);
L8: 

    /** parser.e:3502				if ptok[T_ID] != ATOM then*/
    _2 = (object)SEQ_PTR(_ptok_60589);
    _30145 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30145, 502)){
        _30145 = NOVALUE;
        goto L9; // [330] 344
    }
    _30145 = NOVALUE;

    /** parser.e:3503					CompileErr( A_NUMERIC_LITERAL_WAS_EXPECTED)*/
    RefDS(_22209);
    _49CompileErr(344, _22209, 0);
L9: 

    /** parser.e:3506				delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_ptok_60589);
    _30147 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30147)){
        _30148 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30147)->dbl));
    }
    else{
        _30148 = (object)*(((s1_ptr)_2)->base + _30147);
    }
    DeRef(_delta_60571);
    _2 = (object)SEQ_PTR(_30148);
    _delta_60571 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_60571);
    _30148 = NOVALUE;

    /** parser.e:3507				if negate then*/
    if (_negate_60605 == 0)
    {
        goto LA; // [366] 375
    }
    else{
    }

    /** parser.e:3508					delta = -delta*/
    _0 = _delta_60571;
    if (IS_ATOM_INT(_delta_60571)) {
        if ((uintptr_t)_delta_60571 == (uintptr_t)HIGH_BITS){
            _delta_60571 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _delta_60571 = - _delta_60571;
        }
    }
    else {
        _delta_60571 = unary_op(UMINUS, _delta_60571);
    }
    DeRef(_0);
LA: 

    /** parser.e:3511				switch deltafunc do*/
    _0 = _deltafunc_60570;
    switch ( _0 ){ 

        /** parser.e:3512					case '/' then*/
        case 47:

        /** parser.e:3513						delta = 1 / delta*/
        _0 = _delta_60571;
        if (IS_ATOM_INT(_delta_60571)) {
            _delta_60571 = (1 % _delta_60571) ? NewDouble((eudouble)1 / _delta_60571) : (1 / _delta_60571);
        }
        else {
            _delta_60571 = NewDouble((eudouble)1 / DBL_PTR(_delta_60571)->dbl);
        }
        DeRef(_0);

        /** parser.e:3514						deltafunc = '*'*/
        _deltafunc_60570 = 42;
        goto LB; // [397] 414

        /** parser.e:3516					case '-' then*/
        case 45:

        /** parser.e:3517						delta = -delta*/
        _0 = _delta_60571;
        if (IS_ATOM_INT(_delta_60571)) {
            if ((uintptr_t)_delta_60571 == (uintptr_t)HIGH_BITS){
                _delta_60571 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _delta_60571 = - _delta_60571;
            }
        }
        else {
            _delta_60571 = unary_op(UMINUS, _delta_60571);
        }
        DeRef(_0);

        /** parser.e:3518						deltafunc = '+'*/
        _deltafunc_60570 = 43;
    ;}LB: 
    goto L4; // [416] 425
L5: 

    /** parser.e:3523				putback(ptok)*/
    RefDS(_ptok_60589);
    _43putback(_ptok_60589);
L4: 
L2: 
    DeRef(_ptok_60589);
    _ptok_60589 = NOVALUE;

    /** parser.e:3527		valsym = 0*/
    _valsym_60565 = 0;

    /** parser.e:3528		while TRUE do*/
LC: 
    if (_9TRUE_441 == 0)
    {
        goto LD; // [442] 2303
    }
    else{
    }

    /** parser.e:3529			tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);

    /** parser.e:3530			if tok[T_ID] = DOLLAR then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30156 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30156, -22)){
        _30156 = NOVALUE;
        goto LE; // [460] 499
    }
    _30156 = NOVALUE;

    /** parser.e:3531				if not equal(prevtok, 0) then*/
    if (_prevtok_60562 == 0)
    _30158 = 1;
    else if (IS_ATOM_INT(_prevtok_60562) && IS_ATOM_INT(0))
    _30158 = 0;
    else
    _30158 = (compare(_prevtok_60562, 0) == 0);
    if (_30158 != 0)
    goto LF; // [470] 498
    _30158 = NOVALUE;

    /** parser.e:3532					if prevtok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_prevtok_60562);
    _30160 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30160, -30)){
        _30160 = NOVALUE;
        goto L10; // [483] 497
    }
    _30160 = NOVALUE;

    /** parser.e:3534						tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);

    /** parser.e:3535						exit*/
    goto LD; // [494] 2303
L10: 
LF: 
LE: 

    /** parser.e:3539			if tok[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30163 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30163, -21)){
        _30163 = NOVALUE;
        goto L11; // [509] 523
    }
    _30163 = NOVALUE;

    /** parser.e:3540				CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(32, _22209, 0);
L11: 

    /** parser.e:3543			if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30165 = (object)*(((s1_ptr)_2)->base + 1);
    _30166 = find_from(_30165, _29ADDR_TOKS_12281, 1);
    _30165 = NOVALUE;
    if (_30166 != 0)
    goto L12; // [538] 565
    _30166 = NOVALUE;

    /** parser.e:3544				CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(tok[T_ID])} )*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30168 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30168);
    _30169 = _62find_category(_30168);
    _30168 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30169;
    _30170 = MAKE_SEQ(_1);
    _30169 = NOVALUE;
    _49CompileErr(25, _30170, 0);
    _30170 = NOVALUE;
L12: 

    /** parser.e:3546			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _sym_60564 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_60564)){
        _sym_60564 = (object)DBL_PTR(_sym_60564)->dbl;
    }

    /** parser.e:3547			DefinedYet(sym)*/
    _53DefinedYet(_sym_60564);

    /** parser.e:3548			if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30172 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30172);
    _30173 = (object)*(((s1_ptr)_2)->base + 4);
    _30172 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6;
    ((intptr_t*)_2)[2] = 7;
    ((intptr_t*)_2)[3] = 13;
    ((intptr_t*)_2)[4] = 11;
    _30174 = MAKE_SEQ(_1);
    _30175 = find_from(_30173, _30174, 1);
    _30173 = NOVALUE;
    DeRefDS(_30174);
    _30174 = NOVALUE;
    if (_30175 == 0)
    {
        _30175 = NOVALUE;
        goto L13; // [614] 676
    }
    else{
        _30175 = NOVALUE;
    }

    /** parser.e:3549				h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30176 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30176);
    _h_60566 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_60566)){
        _h_60566 = (object)DBL_PTR(_h_60566)->dbl;
    }
    _30176 = NOVALUE;

    /** parser.e:3551				sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30178 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30178);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30179 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30179 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30178 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _30180 = (object)*(((s1_ptr)_2)->base + _h_60566);
    Ref(_30179);
    Ref(_30180);
    _sym_60564 = _53NewEntry(_30179, 0, 0, -100, _h_60566, _30180, 0);
    _30179 = NOVALUE;
    _30180 = NOVALUE;
    if (!IS_ATOM_INT(_sym_60564)) {
        _1 = (object)(DBL_PTR(_sym_60564)->dbl);
        DeRefDS(_sym_60564);
        _sym_60564 = _1;
    }

    /** parser.e:3552				buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _2 = (object)(((s1_ptr)_2)->base + _h_60566);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60564;
    DeRef(_1);
L13: 

    /** parser.e:3555			new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_60558, _new_symbols_60558, _sym_60564);

    /** parser.e:3556			Block_var( sym )*/
    _64Block_var(_sym_60564);

    /** parser.e:3557			if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30183 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30183);
    _30184 = (object)*(((s1_ptr)_2)->base + 4);
    _30183 = NOVALUE;
    if (IS_ATOM_INT(_30184)) {
        _30185 = (_30184 == 9);
    }
    else {
        _30185 = binary_op(EQUALS, _30184, 9);
    }
    _30184 = NOVALUE;
    if (IS_ATOM_INT(_30185)) {
        if (_30185 == 0) {
            goto L14; // [707] 751
        }
    }
    else {
        if (DBL_PTR(_30185)->dbl == 0.0) {
            goto L14; // [707] 751
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30187 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30187);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _30188 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _30188 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _30187 = NOVALUE;
    if (IS_ATOM_INT(_30188)) {
        _30189 = (_30188 != _27current_file_no_20571);
    }
    else {
        _30189 = binary_op(NOTEQ, _30188, _27current_file_no_20571);
    }
    _30188 = NOVALUE;
    if (_30189 == 0) {
        DeRef(_30189);
        _30189 = NOVALUE;
        goto L14; // [730] 751
    }
    else {
        if (!IS_ATOM_INT(_30189) && DBL_PTR(_30189)->dbl == 0.0){
            DeRef(_30189);
            _30189 = NOVALUE;
            goto L14; // [730] 751
        }
        DeRef(_30189);
        _30189 = NOVALUE;
    }
    DeRef(_30189);
    _30189 = NOVALUE;

    /** parser.e:3558				SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FILE_NO_20205))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27current_file_no_20571;
    DeRef(_1);
    _30190 = NOVALUE;
L14: 

    /** parser.e:3560			SymTab[sym][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_60557;
    DeRef(_1);
    _30192 = NOVALUE;

    /** parser.e:3562			if type_ptr = 0 then*/
    if (_type_ptr_60556 != 0)
    goto L15; // [768] 1103

    /** parser.e:3564				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30195 = NOVALUE;

    /** parser.e:3566				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30197 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30197);
    _30198 = (object)*(((s1_ptr)_2)->base + 11);
    _30197 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30199 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30199);
    _30200 = (object)*(((s1_ptr)_2)->base + 9);
    _30199 = NOVALUE;
    Ref(_30200);
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_30198))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30198)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30198);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30200;
    if( _1 != _30200 ){
        DeRef(_1);
    }
    _30200 = NOVALUE;

    /** parser.e:3567				tok_match(EQUALS)*/
    _43tok_match(3, 0);

    /** parser.e:3568				StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_439, 0, 3);

    /** parser.e:3569				emit_opnd(sym)*/
    _45emit_opnd(_sym_60564);

    /** parser.e:3570				Expr()  -- no new symbols can be defined in here*/
    _43Expr();

    /** parser.e:3571				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30201 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30201);
    _30202 = (object)*(((s1_ptr)_2)->base + 11);
    _30201 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_30202))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30202)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30202);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60564;
    DeRef(_1);

    /** parser.e:3572				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30203 = NOVALUE;

    /** parser.e:3573				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L16; // [890] 928
    }
    else{
    }

    /** parser.e:3574					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _30205 = NOVALUE;

    /** parser.e:3575					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    _30207 = NOVALUE;
L16: 

    /** parser.e:3577				valsym = Top()*/
    _valsym_60565 = _45Top();
    if (!IS_ATOM_INT(_valsym_60565)) {
        _1 = (object)(DBL_PTR(_valsym_60565)->dbl);
        DeRefDS(_valsym_60565);
        _valsym_60565 = _1;
    }

    /** parser.e:3579				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30210 = (_valsym_60565 > 0);
    if (_30210 == 0) {
        goto L17; // [941] 982
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30212 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30212);
    _30213 = (object)*(((s1_ptr)_2)->base + 1);
    _30212 = NOVALUE;
    if (IS_ATOM_INT(_30213) && IS_ATOM_INT(_27NOVALUE_20426)){
        _30214 = (_30213 < _27NOVALUE_20426) ? -1 : (_30213 > _27NOVALUE_20426);
    }
    else{
        _30214 = compare(_30213, _27NOVALUE_20426);
    }
    _30213 = NOVALUE;
    if (_30214 == 0)
    {
        _30214 = NOVALUE;
        goto L17; // [964] 982
    }
    else{
        _30214 = NOVALUE;
    }

    /** parser.e:3580					Assign_Constant( sym )*/
    _43Assign_Constant(_sym_60564);

    /** parser.e:3581					sym = Pop()*/
    _sym_60564 = _45Pop();
    if (!IS_ATOM_INT(_sym_60564)) {
        _1 = (object)(DBL_PTR(_sym_60564)->dbl);
        DeRefDS(_sym_60564);
        _sym_60564 = _1;
    }
    goto L18; // [979] 2269
L17: 

    /** parser.e:3584					emit_op(ASSIGN)*/
    _45emit_op(18);

    /** parser.e:3585					if Last_op() = ASSIGN then*/
    _30216 = _45Last_op();
    if (binary_op_a(NOTEQ, _30216, 18)){
        DeRef(_30216);
        _30216 = NOVALUE;
        goto L19; // [996] 1010
    }
    DeRef(_30216);
    _30216 = NOVALUE;

    /** parser.e:3586						valsym = get_assigned_sym()*/
    _valsym_60565 = _43get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_60565)) {
        _1 = (object)(DBL_PTR(_valsym_60565)->dbl);
        DeRefDS(_valsym_60565);
        _valsym_60565 = _1;
    }
    goto L1A; // [1007] 1018
L19: 

    /** parser.e:3589						valsym = -1*/
    _valsym_60565 = -1;
L1A: 

    /** parser.e:3591					if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _30219 = (_valsym_60565 > 0);
    if (_30219 == 0) {
        goto L1B; // [1024] 1066
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30221 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30221);
    _30222 = (object)*(((s1_ptr)_2)->base + 1);
    _30221 = NOVALUE;
    if (IS_ATOM_INT(_30222) && IS_ATOM_INT(_27NOVALUE_20426)){
        _30223 = (_30222 < _27NOVALUE_20426) ? -1 : (_30222 > _27NOVALUE_20426);
    }
    else{
        _30223 = compare(_30222, _27NOVALUE_20426);
    }
    _30222 = NOVALUE;
    if (_30223 == 0)
    {
        _30223 = NOVALUE;
        goto L1B; // [1047] 1066
    }
    else{
        _30223 = NOVALUE;
    }

    /** parser.e:3593						SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60565;
    DeRef(_1);
    _30224 = NOVALUE;
L1B: 

    /** parser.e:3596					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L18; // [1070] 2269
    }
    else{
    }

    /** parser.e:3597						count += 1*/
    _count_60567 = _count_60567 + 1;

    /** parser.e:3598						if count = 10 then*/
    if (_count_60567 != 10)
    goto L18; // [1081] 2269

    /** parser.e:3599							count = 0*/
    _count_60567 = 0;

    /** parser.e:3601							emit_op( RETURNT )*/
    _45emit_op(34);
    goto L18; // [1100] 2269
L15: 

    /** parser.e:3606			elsif type_ptr = -1 and not is_fwd_ref then*/
    _30228 = (_type_ptr_60556 == -1);
    if (_30228 == 0) {
        goto L1C; // [1109] 2096
    }
    _30230 = (_is_fwd_ref_60572 == 0);
    if (_30230 == 0)
    {
        DeRef(_30230);
        _30230 = NOVALUE;
        goto L1C; // [1117] 2096
    }
    else{
        DeRef(_30230);
        _30230 = NOVALUE;
    }

    /** parser.e:3608				StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_439, 0, 3);

    /** parser.e:3609				SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30231 = NOVALUE;

    /** parser.e:3611				buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30233 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30233);
    _30234 = (object)*(((s1_ptr)_2)->base + 11);
    _30233 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30235 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30235);
    _30236 = (object)*(((s1_ptr)_2)->base + 9);
    _30235 = NOVALUE;
    Ref(_30236);
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_30234))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30234)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30234);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30236;
    if( _1 != _30236 ){
        DeRef(_1);
    }
    _30236 = NOVALUE;

    /** parser.e:3612				tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);

    /** parser.e:3615				emit_opnd(sym)*/
    _45emit_opnd(_sym_60564);

    /** parser.e:3617				if tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30238 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30238, 3)){
        _30238 = NOVALUE;
        goto L1D; // [1200] 1607
    }
    _30238 = NOVALUE;

    /** parser.e:3618					integer negate = 1*/
    _negate_60854 = 1;

    /** parser.e:3620					tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);

    /** parser.e:3621					if tok[T_ID] = MINUS then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30241 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30241, 10)){
        _30241 = NOVALUE;
        goto L1E; // [1224] 1239
    }
    _30241 = NOVALUE;

    /** parser.e:3622						negate = -1*/
    _negate_60854 = -1;

    /** parser.e:3623						tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);
L1E: 

    /** parser.e:3626					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30244 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30244, 502)){
        _30244 = NOVALUE;
        goto L1F; // [1249] 1266
    }
    _30244 = NOVALUE;

    /** parser.e:3627						valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _valsym_60565 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60565)){
        _valsym_60565 = (object)DBL_PTR(_valsym_60565)->dbl;
    }
    goto L20; // [1263] 1464
L1F: 

    /** parser.e:3628					elsif tok[T_SYM] > 0 then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30247 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _30247, 0)){
        _30247 = NOVALUE;
        goto L21; // [1274] 1454
    }
    _30247 = NOVALUE;

    /** parser.e:3629						tsym = SymTab[tok[T_SYM]]*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30249 = (object)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_60561);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30249)){
        _tsym_60561 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30249)->dbl));
    }
    else{
        _tsym_60561 = (object)*(((s1_ptr)_2)->base + _30249);
    }
    Ref(_tsym_60561);

    /** parser.e:3630						if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_tsym_60561);
    _30251 = (object)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _30251, 2)){
        _30251 = NOVALUE;
        goto L22; // [1302] 1415
    }
    _30251 = NOVALUE;

    /** parser.e:3631							if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_60561)){
            _30253 = SEQ_PTR(_tsym_60561)->length;
    }
    else {
        _30253 = 1;
    }
    if (IS_ATOM_INT(_27S_CODE_20221)) {
        _30254 = (_30253 >= _27S_CODE_20221);
    }
    else {
        _30254 = binary_op(GREATEREQ, _30253, _27S_CODE_20221);
    }
    _30253 = NOVALUE;
    if (IS_ATOM_INT(_30254)) {
        if (_30254 == 0) {
            goto L23; // [1317] 1344
        }
    }
    else {
        if (DBL_PTR(_30254)->dbl == 0.0) {
            goto L23; // [1317] 1344
        }
    }
    _2 = (object)SEQ_PTR(_tsym_60561);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _30256 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _30256 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    if (_30256 == 0) {
        _30256 = NOVALUE;
        goto L23; // [1328] 1344
    }
    else {
        if (!IS_ATOM_INT(_30256) && DBL_PTR(_30256)->dbl == 0.0){
            _30256 = NOVALUE;
            goto L23; // [1328] 1344
        }
        _30256 = NOVALUE;
    }
    _30256 = NOVALUE;

    /** parser.e:3632								valsym = tsym[S_CODE]*/
    _2 = (object)SEQ_PTR(_tsym_60561);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _valsym_60565 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _valsym_60565 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    if (!IS_ATOM_INT(_valsym_60565)){
        _valsym_60565 = (object)DBL_PTR(_valsym_60565)->dbl;
    }
    goto L20; // [1341] 1464
L23: 

    /** parser.e:3634							elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (object)SEQ_PTR(_tsym_60561);
    _30258 = (object)*(((s1_ptr)_2)->base + 1);
    if (_30258 == _27NOVALUE_20426)
    _30259 = 1;
    else if (IS_ATOM_INT(_30258) && IS_ATOM_INT(_27NOVALUE_20426))
    _30259 = 0;
    else
    _30259 = (compare(_30258, _27NOVALUE_20426) == 0);
    _30258 = NOVALUE;
    if (_30259 != 0)
    goto L24; // [1358] 1402
    _30259 = NOVALUE;

    /** parser.e:3635								if is_integer(tsym[S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tsym_60561);
    _30261 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30261);
    _30262 = _27is_integer(_30261);
    _30261 = NOVALUE;
    if (_30262 == 0) {
        DeRef(_30262);
        _30262 = NOVALUE;
        goto L25; // [1373] 1389
    }
    else {
        if (!IS_ATOM_INT(_30262) && DBL_PTR(_30262)->dbl == 0.0){
            DeRef(_30262);
            _30262 = NOVALUE;
            goto L25; // [1373] 1389
        }
        DeRef(_30262);
        _30262 = NOVALUE;
    }
    DeRef(_30262);
    _30262 = NOVALUE;

    /** parser.e:3636									valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _valsym_60565 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60565)){
        _valsym_60565 = (object)DBL_PTR(_valsym_60565)->dbl;
    }
    goto L20; // [1386] 1464
L25: 

    /** parser.e:3638									CompileErr(AN_ENUM_CONSTANT_MUST_BE_AN_INTEGER)*/
    RefDS(_22209);
    _49CompileErr(30, _22209, 0);
    goto L20; // [1399] 1464
L24: 

    /** parser.e:3641								CompileErr(ENUM_CONSTANTS_MUST_BE_ASSIGNED_AN_INTEGER)*/
    RefDS(_22209);
    _49CompileErr(70, _22209, 0);
    goto L20; // [1412] 1464
L22: 

    /** parser.e:3643						elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_tsym_60561);
    _30264 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30264, _27NOVALUE_20426)){
        _30264 = NOVALUE;
        goto L26; // [1425] 1441
    }
    _30264 = NOVALUE;

    /** parser.e:3645							CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_22209);
    _49CompileErr(331, _22209, 0);
    goto L20; // [1438] 1464
L26: 

    /** parser.e:3647							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22209);
    _49CompileErr(99, _22209, 0);
    goto L20; // [1451] 1464
L21: 

    /** parser.e:3651							CompileErr(INTEGER_OR_CONSTANT_EXPECTED)*/
    RefDS(_22209);
    _49CompileErr(99, _22209, 0);
L20: 

    /** parser.e:3653					valsym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _valsym_60565 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_60565)){
        _valsym_60565 = (object)DBL_PTR(_valsym_60565)->dbl;
    }

    /** parser.e:3654					if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30267 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30267);
    _30268 = (object)*(((s1_ptr)_2)->base + 1);
    _30267 = NOVALUE;
    _30269 = IS_ATOM(_30268);
    _30268 = NOVALUE;
    _30270 = (_30269 == 0);
    _30269 = NOVALUE;
    if (_30270 == 0) {
        goto L27; // [1494] 1526
    }
    _2 = (object)SEQ_PTR(_tsym_60561);
    _30272 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30272)) {
        _30273 = (_30272 != 9);
    }
    else {
        _30273 = binary_op(NOTEQ, _30272, 9);
    }
    _30272 = NOVALUE;
    if (_30273 == 0) {
        DeRef(_30273);
        _30273 = NOVALUE;
        goto L27; // [1513] 1526
    }
    else {
        if (!IS_ATOM_INT(_30273) && DBL_PTR(_30273)->dbl == 0.0){
            DeRef(_30273);
            _30273 = NOVALUE;
            goto L27; // [1513] 1526
        }
        DeRef(_30273);
        _30273 = NOVALUE;
    }
    DeRef(_30273);
    _30273 = NOVALUE;

    /** parser.e:3655						CompileErr(ENUM_CONSTANTS_MUST_BE_INTEGERS)*/
    RefDS(_22209);
    _49CompileErr(84, _22209, 0);
L27: 

    /** parser.e:3657					val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30274 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30274);
    _30275 = (object)*(((s1_ptr)_2)->base + 1);
    _30274 = NOVALUE;
    DeRef(_val_60568);
    if (IS_ATOM_INT(_30275)) {
        if (_30275 == (short)_30275 && _negate_60854 <= INT15 && _negate_60854 >= -INT15){
            _val_60568 = _30275 * _negate_60854;
        }
        else{
            _val_60568 = NewDouble(_30275 * (eudouble)_negate_60854);
        }
    }
    else {
        _val_60568 = binary_op(MULTIPLY, _30275, _negate_60854);
    }
    _30275 = NOVALUE;

    /** parser.e:3658					if is_integer(val) then*/
    Ref(_val_60568);
    _30277 = _27is_integer(_val_60568);
    if (_30277 == 0) {
        DeRef(_30277);
        _30277 = NOVALUE;
        goto L28; // [1550] 1565
    }
    else {
        if (!IS_ATOM_INT(_30277) && DBL_PTR(_30277)->dbl == 0.0){
            DeRef(_30277);
            _30277 = NOVALUE;
            goto L28; // [1550] 1565
        }
        DeRef(_30277);
        _30277 = NOVALUE;
    }
    DeRef(_30277);
    _30277 = NOVALUE;

    /** parser.e:3659						Push(NewIntSym(val))*/
    Ref(_val_60568);
    _30278 = _53NewIntSym(_val_60568);
    _45Push(_30278);
    _30278 = NOVALUE;
    goto L29; // [1562] 1575
L28: 

    /** parser.e:3661						Push(NewDoubleSym(val))*/
    Ref(_val_60568);
    _30279 = _53NewDoubleSym(_val_60568);
    _45Push(_30279);
    _30279 = NOVALUE;
L29: 

    /** parser.e:3663					usedval = val*/
    Ref(_val_60568);
    DeRef(_usedval_60569);
    _usedval_60569 = _val_60568;

    /** parser.e:3664					if deltafunc = '+' then*/
    if (_deltafunc_60570 != 43)
    goto L2A; // [1582] 1595

    /** parser.e:3665						val += delta*/
    _0 = _val_60568;
    if (IS_ATOM_INT(_val_60568) && IS_ATOM_INT(_delta_60571)) {
        _val_60568 = _val_60568 + _delta_60571;
        if ((object)((uintptr_t)_val_60568 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60568 = NewDouble((eudouble)_val_60568);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60568)) {
            _val_60568 = NewDouble((eudouble)_val_60568 + DBL_PTR(_delta_60571)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60571)) {
                _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl + (eudouble)_delta_60571);
            }
            else
            _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl + DBL_PTR(_delta_60571)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1592] 1602
L2A: 

    /** parser.e:3667						val *= delta*/
    _0 = _val_60568;
    if (IS_ATOM_INT(_val_60568) && IS_ATOM_INT(_delta_60571)) {
        if (_val_60568 == (short)_val_60568 && _delta_60571 <= INT15 && _delta_60571 >= -INT15){
            _val_60568 = _val_60568 * _delta_60571;
        }
        else{
            _val_60568 = NewDouble(_val_60568 * (eudouble)_delta_60571);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60568)) {
            _val_60568 = NewDouble((eudouble)_val_60568 * DBL_PTR(_delta_60571)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60571)) {
                _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl * (eudouble)_delta_60571);
            }
            else
            _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl * DBL_PTR(_delta_60571)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1604] 1678
L1D: 

    /** parser.e:3670					putback(tok)*/
    Ref(_tok_60560);
    _43putback(_tok_60560);

    /** parser.e:3671					if is_integer(val) then*/
    Ref(_val_60568);
    _30283 = _27is_integer(_val_60568);
    if (_30283 == 0) {
        DeRef(_30283);
        _30283 = NOVALUE;
        goto L2D; // [1618] 1633
    }
    else {
        if (!IS_ATOM_INT(_30283) && DBL_PTR(_30283)->dbl == 0.0){
            DeRef(_30283);
            _30283 = NOVALUE;
            goto L2D; // [1618] 1633
        }
        DeRef(_30283);
        _30283 = NOVALUE;
    }
    DeRef(_30283);
    _30283 = NOVALUE;

    /** parser.e:3672						Push(NewIntSym(val))*/
    Ref(_val_60568);
    _30284 = _53NewIntSym(_val_60568);
    _45Push(_30284);
    _30284 = NOVALUE;
    goto L2E; // [1630] 1643
L2D: 

    /** parser.e:3674						Push(NewDoubleSym(val))*/
    Ref(_val_60568);
    _30285 = _53NewDoubleSym(_val_60568);
    _45Push(_30285);
    _30285 = NOVALUE;
L2E: 

    /** parser.e:3676					usedval = val*/
    Ref(_val_60568);
    DeRef(_usedval_60569);
    _usedval_60569 = _val_60568;

    /** parser.e:3677					if deltafunc = '+' then*/
    if (_deltafunc_60570 != 43)
    goto L2F; // [1650] 1663

    /** parser.e:3678						val += delta*/
    _0 = _val_60568;
    if (IS_ATOM_INT(_val_60568) && IS_ATOM_INT(_delta_60571)) {
        _val_60568 = _val_60568 + _delta_60571;
        if ((object)((uintptr_t)_val_60568 + (uintptr_t)HIGH_BITS) >= 0){
            _val_60568 = NewDouble((eudouble)_val_60568);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60568)) {
            _val_60568 = NewDouble((eudouble)_val_60568 + DBL_PTR(_delta_60571)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60571)) {
                _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl + (eudouble)_delta_60571);
            }
            else
            _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl + DBL_PTR(_delta_60571)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1660] 1670
L2F: 

    /** parser.e:3680						val *= delta*/
    _0 = _val_60568;
    if (IS_ATOM_INT(_val_60568) && IS_ATOM_INT(_delta_60571)) {
        if (_val_60568 == (short)_val_60568 && _delta_60571 <= INT15 && _delta_60571 >= -INT15){
            _val_60568 = _val_60568 * _delta_60571;
        }
        else{
            _val_60568 = NewDouble(_val_60568 * (eudouble)_delta_60571);
        }
    }
    else {
        if (IS_ATOM_INT(_val_60568)) {
            _val_60568 = NewDouble((eudouble)_val_60568 * DBL_PTR(_delta_60571)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_60571)) {
                _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl * (eudouble)_delta_60571);
            }
            else
            _val_60568 = NewDouble(DBL_PTR(_val_60568)->dbl * DBL_PTR(_delta_60571)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** parser.e:3682					valsym = 0*/
    _valsym_60565 = 0;
L2C: 

    /** parser.e:3684				buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30289 = (object)*(((s1_ptr)_2)->base + _sym_60564);
    _2 = (object)SEQ_PTR(_30289);
    _30290 = (object)*(((s1_ptr)_2)->base + 11);
    _30289 = NOVALUE;
    _2 = (object)SEQ_PTR(_53buckets_47180);
    if (!IS_ATOM_INT(_30290))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30290)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _30290);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_60564;
    DeRef(_1);

    /** parser.e:3685				SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30291 = NOVALUE;

    /** parser.e:3687				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L31; // [1719] 1757
    }
    else{
    }

    /** parser.e:3688					SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16;
    DeRef(_1);
    _30293 = NOVALUE;

    /** parser.e:3689					SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_27NOVALUE_20426);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27NOVALUE_20426;
    DeRef(_1);
    _30295 = NOVALUE;
L31: 

    /** parser.e:3692				if valsym < 0 then*/
    if (_valsym_60565 >= 0)
    goto L32; // [1759] 1764
L32: 

    /** parser.e:3697				if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_60565 == 0) {
        goto L33; // [1766] 1946
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30299 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30299);
    _30300 = (object)*(((s1_ptr)_2)->base + 1);
    _30299 = NOVALUE;
    if (IS_ATOM_INT(_30300) && IS_ATOM_INT(_27NOVALUE_20426)){
        _30301 = (_30300 < _27NOVALUE_20426) ? -1 : (_30300 > _27NOVALUE_20426);
    }
    else{
        _30301 = compare(_30300, _27NOVALUE_20426);
    }
    _30300 = NOVALUE;
    if (_30301 == 0)
    {
        _30301 = NOVALUE;
        goto L33; // [1789] 1946
    }
    else{
        _30301 = NOVALUE;
    }

    /** parser.e:3699					SymTab[sym][S_CODE] = valsym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _valsym_60565;
    DeRef(_1);
    _30302 = NOVALUE;

    /** parser.e:3700					SymTab[sym][S_OBJ]  = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_usedval_60569);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60569;
    DeRef(_1);
    _30304 = NOVALUE;

    /** parser.e:3702					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L34; // [1828] 2079
    }
    else{
    }

    /** parser.e:3704						SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30308 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30308);
    _30309 = (object)*(((s1_ptr)_2)->base + 36);
    _30308 = NOVALUE;
    Ref(_30309);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30309;
    if( _1 != _30309 ){
        DeRef(_1);
    }
    _30309 = NOVALUE;
    _30306 = NOVALUE;

    /** parser.e:3705						SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30312 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30312);
    _30313 = (object)*(((s1_ptr)_2)->base + 33);
    _30312 = NOVALUE;
    Ref(_30313);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30313;
    if( _1 != _30313 ){
        DeRef(_1);
    }
    _30313 = NOVALUE;
    _30310 = NOVALUE;

    /** parser.e:3706						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_usedval_60569);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60569;
    DeRef(_1);
    _30314 = NOVALUE;

    /** parser.e:3707						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_usedval_60569);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60569;
    DeRef(_1);
    _30316 = NOVALUE;

    /** parser.e:3708						SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30320 = (object)*(((s1_ptr)_2)->base + _valsym_60565);
    _2 = (object)SEQ_PTR(_30320);
    _30321 = (object)*(((s1_ptr)_2)->base + 32);
    _30320 = NOVALUE;
    Ref(_30321);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30321;
    if( _1 != _30321 ){
        DeRef(_1);
    }
    _30321 = NOVALUE;
    _30318 = NOVALUE;
    goto L34; // [1943] 2079
L33: 

    /** parser.e:3711					SymTab[sym][S_OBJ] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_usedval_60569);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60569;
    DeRef(_1);
    _30322 = NOVALUE;

    /** parser.e:3712					if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L35; // [1967] 2078
    }
    else{
    }

    /** parser.e:3714						if is_integer( usedval ) then*/
    Ref(_usedval_60569);
    _30324 = _27is_integer(_usedval_60569);
    if (_30324 == 0) {
        DeRef(_30324);
        _30324 = NOVALUE;
        goto L36; // [1976] 1999
    }
    else {
        if (!IS_ATOM_INT(_30324) && DBL_PTR(_30324)->dbl == 0.0){
            DeRef(_30324);
            _30324 = NOVALUE;
            goto L36; // [1976] 1999
        }
        DeRef(_30324);
        _30324 = NOVALUE;
    }
    DeRef(_30324);
    _30324 = NOVALUE;

    /** parser.e:3715							SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _30325 = NOVALUE;
    goto L37; // [1996] 2017
L36: 

    /** parser.e:3717							SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2;
    DeRef(_1);
    _30327 = NOVALUE;
L37: 

    /** parser.e:3719						SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30329 = NOVALUE;

    /** parser.e:3720						SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_usedval_60569);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60569;
    DeRef(_1);
    _30331 = NOVALUE;

    /** parser.e:3721						SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    Ref(_usedval_60569);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _usedval_60569;
    DeRef(_1);
    _30333 = NOVALUE;

    /** parser.e:3722						SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30335 = NOVALUE;
L35: 
L34: 

    /** parser.e:3725				valsym = Pop()*/
    _valsym_60565 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60565)) {
        _1 = (object)(DBL_PTR(_valsym_60565)->dbl);
        DeRefDS(_valsym_60565);
        _valsym_60565 = _1;
    }

    /** parser.e:3726				valsym = Pop()*/
    _valsym_60565 = _45Pop();
    if (!IS_ATOM_INT(_valsym_60565)) {
        _1 = (object)(DBL_PTR(_valsym_60565)->dbl);
        DeRefDS(_valsym_60565);
        _valsym_60565 = _1;
    }
    goto L18; // [2093] 2269
L1C: 

    /** parser.e:3729				SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1;
    DeRef(_1);
    _30339 = NOVALUE;

    /** parser.e:3730				if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _30341 = (_type_ptr_60556 > 0);
    if (_30341 == 0) {
        goto L38; // [2119] 2165
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30343 = (object)*(((s1_ptr)_2)->base + _type_ptr_60556);
    _2 = (object)SEQ_PTR(_30343);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _30344 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _30344 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _30343 = NOVALUE;
    if (IS_ATOM_INT(_30344)) {
        _30345 = (_30344 == 415);
    }
    else {
        _30345 = binary_op(EQUALS, _30344, 415);
    }
    _30344 = NOVALUE;
    if (_30345 == 0) {
        DeRef(_30345);
        _30345 = NOVALUE;
        goto L38; // [2142] 2165
    }
    else {
        if (!IS_ATOM_INT(_30345) && DBL_PTR(_30345)->dbl == 0.0){
            DeRef(_30345);
            _30345 = NOVALUE;
            goto L38; // [2142] 2165
        }
        DeRef(_30345);
        _30345 = NOVALUE;
    }
    DeRef(_30345);
    _30345 = NOVALUE;

    /** parser.e:3731					SymTab[sym][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _53object_type_47184;
    DeRef(_1);
    _30346 = NOVALUE;
    goto L39; // [2162] 2194
L38: 

    /** parser.e:3733					SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_ptr_60556;
    DeRef(_1);
    _30348 = NOVALUE;

    /** parser.e:3734					if type_ptr < 0 then*/
    if (_type_ptr_60556 >= 0)
    goto L3A; // [2182] 2193

    /** parser.e:3735						register_forward_type( sym, type_ptr )*/
    _42register_forward_type(_sym_60564, _type_ptr_60556);
L3A: 
L39: 

    /** parser.e:3739				if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3B; // [2198] 2221
    }
    else{
    }

    /** parser.e:3740					SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_60564 + ((s1_ptr)_2)->base);
    _30353 = _43CompileType(_type_ptr_60556);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30353;
    if( _1 != _30353 ){
        DeRef(_1);
    }
    _30353 = NOVALUE;
    _30351 = NOVALUE;
L3B: 

    /** parser.e:3743		   		tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);

    /** parser.e:3744	   			putback(tok)*/
    Ref(_tok_60560);
    _43putback(_tok_60560);

    /** parser.e:3745		   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30355 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30355, 3)){
        _30355 = NOVALUE;
        goto L3C; // [2241] 2268
    }
    _30355 = NOVALUE;

    /** parser.e:3746		   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_439, 0, 3);

    /** parser.e:3747		   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _sym_60564;
    _30357 = MAKE_SEQ(_1);
    _43Assignment(_30357);
    _30357 = NOVALUE;
L3C: 
L18: 

    /** parser.e:3750			tok = next_token()*/
    _0 = _tok_60560;
    _tok_60560 = _43next_token();
    DeRef(_0);

    /** parser.e:3751			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_60560);
    _30359 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30359, -30)){
        _30359 = NOVALUE;
        goto L3D; // [2284] 2293
    }
    _30359 = NOVALUE;

    /** parser.e:3752				exit*/
    goto LD; // [2290] 2303
L3D: 

    /** parser.e:3754			prevtok = tok*/
    Ref(_tok_60560);
    DeRef(_prevtok_60562);
    _prevtok_60562 = _tok_60560;

    /** parser.e:3755		end while*/
    goto LC; // [2300] 440
LD: 

    /** parser.e:3756		putback(tok)*/
    Ref(_tok_60560);
    _43putback(_tok_60560);

    /** parser.e:3757		return new_symbols*/
    DeRef(_tok_60560);
    DeRef(_tsym_60561);
    DeRef(_prevtok_60562);
    DeRef(_val_60568);
    DeRef(_usedval_60569);
    DeRef(_delta_60571);
    _30249 = NOVALUE;
    DeRef(_30185);
    _30185 = NOVALUE;
    _30147 = NOVALUE;
    DeRef(_30228);
    _30228 = NOVALUE;
    DeRef(_30341);
    _30341 = NOVALUE;
    _30234 = NOVALUE;
    DeRef(_30254);
    _30254 = NOVALUE;
    _30198 = NOVALUE;
    _30202 = NOVALUE;
    DeRef(_30219);
    _30219 = NOVALUE;
    DeRef(_30120);
    _30120 = NOVALUE;
    DeRef(_30210);
    _30210 = NOVALUE;
    DeRef(_30270);
    _30270 = NOVALUE;
    _30290 = NOVALUE;
    return _new_symbols_60558;
    ;
}


void _43Private_declaration(object _type_sym_61145)
{
    object _tok_61147 = NOVALUE;
    object _sym_61149 = NOVALUE;
    object _31974 = NOVALUE;
    object _31973 = NOVALUE;
    object _31972 = NOVALUE;
    object _30385 = NOVALUE;
    object _30383 = NOVALUE;
    object _30381 = NOVALUE;
    object _30379 = NOVALUE;
    object _30377 = NOVALUE;
    object _30375 = NOVALUE;
    object _30373 = NOVALUE;
    object _30370 = NOVALUE;
    object _30368 = NOVALUE;
    object _30367 = NOVALUE;
    object _30364 = NOVALUE;
    object _30362 = NOVALUE;
    object _30361 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_61145)) {
        _1 = (object)(DBL_PTR(_type_sym_61145)->dbl);
        DeRefDS(_type_sym_61145);
        _type_sym_61145 = _1;
    }

    /** parser.e:3765		if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30361 = (object)*(((s1_ptr)_2)->base + _type_sym_61145);
    _2 = (object)SEQ_PTR(_30361);
    _30362 = (object)*(((s1_ptr)_2)->base + 4);
    _30361 = NOVALUE;
    if (binary_op_a(NOTEQ, _30362, 9)){
        _30362 = NOVALUE;
        goto L1; // [19] 47
    }
    _30362 = NOVALUE;

    /** parser.e:3766			Hide( type_sym )*/
    _53Hide(_type_sym_61145);

    /** parser.e:3767			type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31974 = 504;
    _30364 = _42new_forward_reference(504, _type_sym_61145, 504);
    _31974 = NOVALUE;
    if (IS_ATOM_INT(_30364)) {
        if ((uintptr_t)_30364 == (uintptr_t)HIGH_BITS){
            _type_sym_61145 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _type_sym_61145 = - _30364;
        }
    }
    else {
        _type_sym_61145 = unary_op(UMINUS, _30364);
    }
    DeRef(_30364);
    _30364 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_61145)) {
        _1 = (object)(DBL_PTR(_type_sym_61145)->dbl);
        DeRefDS(_type_sym_61145);
        _type_sym_61145 = _1;
    }
L1: 

    /** parser.e:3770		while TRUE do*/
L2: 
    if (_9TRUE_441 == 0)
    {
        goto L3; // [54] 257
    }
    else{
    }

    /** parser.e:3771			tok = next_token()*/
    _0 = _tok_61147;
    _tok_61147 = _43next_token();
    DeRef(_0);

    /** parser.e:3772			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61147);
    _30367 = (object)*(((s1_ptr)_2)->base + 1);
    _30368 = find_from(_30367, _29ID_TOKS_12283, 1);
    _30367 = NOVALUE;
    if (_30368 != 0)
    goto L4; // [77] 90
    _30368 = NOVALUE;

    /** parser.e:3773				CompileErr(A_VARIABLE_NAME_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(24, _22209, 0);
L4: 

    /** parser.e:3775			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61147);
    _30370 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30370);
    _sym_61149 = _43SetPrivateScope(_30370, _type_sym_61145, _43param_num_55414);
    _30370 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61149)) {
        _1 = (object)(DBL_PTR(_sym_61149)->dbl);
        DeRefDS(_sym_61149);
        _sym_61149 = _1;
    }

    /** parser.e:3776			param_num += 1*/
    _43param_num_55414 = _43param_num_55414 + 1;

    /** parser.e:3778			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L5; // [120] 143
    }
    else{
    }

    /** parser.e:3779				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61149 + ((s1_ptr)_2)->base);
    _30375 = _43CompileType(_type_sym_61145);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30375;
    if( _1 != _30375 ){
        DeRef(_1);
    }
    _30375 = NOVALUE;
    _30373 = NOVALUE;
L5: 

    /** parser.e:3782	   		tok = next_token()*/
    _0 = _tok_61147;
    _tok_61147 = _43next_token();
    DeRef(_0);

    /** parser.e:3783	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (object)SEQ_PTR(_tok_61147);
    _30377 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30377, 3)){
        _30377 = NOVALUE;
        goto L6; // [158] 233
    }
    _30377 = NOVALUE;

    /** parser.e:3784			    putback(tok)*/
    Ref(_tok_61147);
    _43putback(_tok_61147);

    /** parser.e:3785			    StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3797			    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _sym_61149;
    _30379 = MAKE_SEQ(_1);
    _43Assignment(_30379);
    _30379 = NOVALUE;

    /** parser.e:3800				tok = next_token()*/
    _0 = _tok_61147;
    _tok_61147 = _43next_token();
    DeRef(_0);

    /** parser.e:3801				if tok[T_ID]=IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_61147);
    _30381 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30381, 509)){
        _30381 = NOVALUE;
        goto L7; // [202] 232
    }
    _30381 = NOVALUE;

    /** parser.e:3802					tok = keyfind(tok[T_SYM],-1)*/
    _2 = (object)SEQ_PTR(_tok_61147);
    _30383 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30383);
    DeRef(_31972);
    _31972 = _30383;
    _31973 = _53hashfn(_31972);
    _31972 = NOVALUE;
    Ref(_30383);
    _0 = _tok_61147;
    _tok_61147 = _53keyfind(_30383, -1, _27current_file_no_20571, 0, _31973);
    DeRef(_0);
    _30383 = NOVALUE;
    _31973 = NOVALUE;
L7: 
L6: 

    /** parser.e:3806			if tok[T_ID] != COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61147);
    _30385 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30385, -30)){
        _30385 = NOVALUE;
        goto L2; // [243] 52
    }
    _30385 = NOVALUE;

    /** parser.e:3807				exit*/
    goto L3; // [249] 257

    /** parser.e:3809		end while*/
    goto L2; // [254] 52
L3: 

    /** parser.e:3810		putback(tok)*/
    Ref(_tok_61147);
    _43putback(_tok_61147);

    /** parser.e:3811	end procedure*/
    DeRef(_tok_61147);
    return;
    ;
}


void _43Procedure_call(object _tok_61212)
{
    object _n_61213 = NOVALUE;
    object _scope_61214 = NOVALUE;
    object _opcode_61215 = NOVALUE;
    object _temp_tok_61217 = NOVALUE;
    object _s_61219 = NOVALUE;
    object _sub_61220 = NOVALUE;
    object _30421 = NOVALUE;
    object _30416 = NOVALUE;
    object _30415 = NOVALUE;
    object _30414 = NOVALUE;
    object _30413 = NOVALUE;
    object _30412 = NOVALUE;
    object _30411 = NOVALUE;
    object _30410 = NOVALUE;
    object _30409 = NOVALUE;
    object _30408 = NOVALUE;
    object _30407 = NOVALUE;
    object _30406 = NOVALUE;
    object _30404 = NOVALUE;
    object _30403 = NOVALUE;
    object _30402 = NOVALUE;
    object _30401 = NOVALUE;
    object _30400 = NOVALUE;
    object _30399 = NOVALUE;
    object _30398 = NOVALUE;
    object _30396 = NOVALUE;
    object _30395 = NOVALUE;
    object _30394 = NOVALUE;
    object _30392 = NOVALUE;
    object _30390 = NOVALUE;
    object _30388 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3820		tok_match(LEFT_ROUND)*/
    _43tok_match(-26, 0);

    /** parser.e:3821		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61212);
    _s_61219 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_61219)){
        _s_61219 = (object)DBL_PTR(_s_61219)->dbl;
    }

    /** parser.e:3822		sub=s*/
    _sub_61220 = _s_61219;

    /** parser.e:3823		n = SymTab[s][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30388 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30388);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _n_61213 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _n_61213 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    if (!IS_ATOM_INT(_n_61213)){
        _n_61213 = (object)DBL_PTR(_n_61213)->dbl;
    }
    _30388 = NOVALUE;

    /** parser.e:3824		scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30390 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30390);
    _scope_61214 = (object)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_61214)){
        _scope_61214 = (object)DBL_PTR(_scope_61214)->dbl;
    }
    _30390 = NOVALUE;

    /** parser.e:3825		opcode = SymTab[s][S_OPCODE]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30392 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30392);
    _opcode_61215 = (object)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_61215)){
        _opcode_61215 = (object)DBL_PTR(_opcode_61215)->dbl;
    }
    _30392 = NOVALUE;

    /** parser.e:3826		if SymTab[s][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30394 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30394);
    _30395 = (object)*(((s1_ptr)_2)->base + 23);
    _30394 = NOVALUE;
    if (_30395 == 0) {
        _30395 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_30395) && DBL_PTR(_30395)->dbl == 0.0){
            _30395 = NOVALUE;
            goto L1; // [88] 139
        }
        _30395 = NOVALUE;
    }
    _30395 = NOVALUE;

    /** parser.e:3827			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30398 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_30398);
    _30399 = (object)*(((s1_ptr)_2)->base + 23);
    _30398 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30400 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30400);
    _30401 = (object)*(((s1_ptr)_2)->base + 23);
    _30400 = NOVALUE;
    if (IS_ATOM_INT(_30399) && IS_ATOM_INT(_30401)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30399 | (uintptr_t)_30401;
             _30402 = MAKE_UINT(tu);
        }
    }
    else {
        _30402 = binary_op(OR_BITS, _30399, _30401);
    }
    _30399 = NOVALUE;
    _30401 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30402;
    if( _1 != _30402 ){
        DeRef(_1);
    }
    _30402 = NOVALUE;
    _30396 = NOVALUE;
L1: 

    /** parser.e:3830		ParseArgs(s)*/
    _43ParseArgs(_s_61219);

    /** parser.e:3833		for i=1 to n+1 do*/
    _30403 = _n_61213 + 1;
    if (_30403 > MAXINT){
        _30403 = NewDouble((eudouble)_30403);
    }
    {
        object _i_61257;
        _i_61257 = 1;
L2: 
        if (binary_op_a(GREATER, _i_61257, _30403)){
            goto L3; // [150] 180
        }

        /** parser.e:3834			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30404 = (object)*(((s1_ptr)_2)->base + _s_61219);
        _2 = (object)SEQ_PTR(_30404);
        _s_61219 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_61219)){
            _s_61219 = (object)DBL_PTR(_s_61219)->dbl;
        }
        _30404 = NOVALUE;

        /** parser.e:3835		end for*/
        _0 = _i_61257;
        if (IS_ATOM_INT(_i_61257)) {
            _i_61257 = _i_61257 + 1;
            if ((object)((uintptr_t)_i_61257 +(uintptr_t) HIGH_BITS) >= 0){
                _i_61257 = NewDouble((eudouble)_i_61257);
            }
        }
        else {
            _i_61257 = binary_op_a(PLUS, _i_61257, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_61257);
    }

    /** parser.e:3836		while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_61219 == 0) {
        goto L5; // [185] 281
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30407 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30407);
    _30408 = (object)*(((s1_ptr)_2)->base + 4);
    _30407 = NOVALUE;
    if (IS_ATOM_INT(_30408)) {
        _30409 = (_30408 == 3);
    }
    else {
        _30409 = binary_op(EQUALS, _30408, 3);
    }
    _30408 = NOVALUE;
    if (_30409 <= 0) {
        if (_30409 == 0) {
            DeRef(_30409);
            _30409 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_30409) && DBL_PTR(_30409)->dbl == 0.0){
                DeRef(_30409);
                _30409 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_30409);
            _30409 = NOVALUE;
        }
    }
    DeRef(_30409);
    _30409 = NOVALUE;

    /** parser.e:3837			if sequence(SymTab[s][S_CODE]) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30410 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30410);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _30411 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _30411 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _30410 = NOVALUE;
    _30412 = IS_SEQUENCE(_30411);
    _30411 = NOVALUE;
    if (_30412 == 0)
    {
        _30412 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _30412 = NOVALUE;
    }

    /** parser.e:3838				start_playback(SymTab[s][S_CODE])*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30413 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30413);
    if (!IS_ATOM_INT(_27S_CODE_20221)){
        _30414 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    }
    else{
        _30414 = (object)*(((s1_ptr)_2)->base + _27S_CODE_20221);
    }
    _30413 = NOVALUE;
    Ref(_30414);
    _43start_playback(_30414);
    _30414 = NOVALUE;

    /** parser.e:3839				Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _s_61219;
    _30415 = MAKE_SEQ(_1);
    _43Assignment(_30415);
    _30415 = NOVALUE;
L6: 

    /** parser.e:3841			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30416 = (object)*(((s1_ptr)_2)->base + _s_61219);
    _2 = (object)SEQ_PTR(_30416);
    _s_61219 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_61219)){
        _s_61219 = (object)DBL_PTR(_s_61219)->dbl;
    }
    _30416 = NOVALUE;

    /** parser.e:3842		end while*/
    goto L4; // [278] 185
L5: 

    /** parser.e:3844		s = sub*/
    _s_61219 = _sub_61220;

    /** parser.e:3845		if scope = SC_PREDEF then*/
    if (_scope_61214 != 7)
    goto L7; // [292] 335

    /** parser.e:3846			emit_op(opcode)*/
    _45emit_op(_opcode_61215);

    /** parser.e:3847			if opcode = ABORT then*/
    if (_opcode_61215 != 126)
    goto L8; // [305] 370

    /** parser.e:3848				temp_tok = next_token()*/
    _0 = _temp_tok_61217;
    _temp_tok_61217 = _43next_token();
    DeRef(_0);

    /** parser.e:3849				putback(temp_tok)*/
    Ref(_temp_tok_61217);
    _43putback(_temp_tok_61217);

    /** parser.e:3850				NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (object)SEQ_PTR(_temp_tok_61217);
    _30421 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30421);
    RefDS(_28157);
    _43NotReached(_30421, _28157);
    _30421 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** parser.e:3853			op_info1 = s*/
    _45op_info1_51413 = _s_61219;

    /** parser.e:3855			emit_or_inline()*/
    _66emit_or_inline();

    /** parser.e:3856			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L9; // [350] 369

    /** parser.e:3857				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** parser.e:3858					emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
LA: 
L9: 
L8: 

    /** parser.e:3862	end procedure*/
    DeRef(_tok_61212);
    DeRef(_temp_tok_61217);
    DeRef(_30403);
    _30403 = NOVALUE;
    return;
    ;
}


void _43Print_statement()
{
    object _30428 = NOVALUE;
    object _30427 = NOVALUE;
    object _30426 = NOVALUE;
    object _30424 = NOVALUE;
    object _30423 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3866		emit_opnd(NewIntSym(1)) -- stdout*/
    _30423 = _53NewIntSym(1);
    _45emit_opnd(_30423);
    _30423 = NOVALUE;

    /** parser.e:3867		Expr()*/
    _43Expr();

    /** parser.e:3868		emit_op(QPRINT)*/
    _45emit_op(36);

    /** parser.e:3869		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27CurrentSub_20579 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30426 = (object)*(((s1_ptr)_2)->base + _27CurrentSub_20579);
    _2 = (object)SEQ_PTR(_30426);
    _30427 = (object)*(((s1_ptr)_2)->base + 23);
    _30426 = NOVALUE;
    if (IS_ATOM_INT(_30427)) {
        {uintptr_t tu;
             tu = (uintptr_t)_30427 | (uintptr_t)536870912;
             _30428 = MAKE_UINT(tu);
        }
    }
    else {
        _30428 = binary_op(OR_BITS, _30427, 536870912);
    }
    _30427 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30428;
    if( _1 != _30428 ){
        DeRef(_1);
    }
    _30428 = NOVALUE;
    _30424 = NOVALUE;

    /** parser.e:3871	end procedure*/
    return;
    ;
}


void _43Entry_statement()
{
    object _addr_61328 = NOVALUE;
    object _30452 = NOVALUE;
    object _30451 = NOVALUE;
    object _30450 = NOVALUE;
    object _30449 = NOVALUE;
    object _30448 = NOVALUE;
    object _30447 = NOVALUE;
    object _30446 = NOVALUE;
    object _30445 = NOVALUE;
    object _30441 = NOVALUE;
    object _30439 = NOVALUE;
    object _30438 = NOVALUE;
    object _30437 = NOVALUE;
    object _30436 = NOVALUE;
    object _30434 = NOVALUE;
    object _30433 = NOVALUE;
    object _30432 = NOVALUE;
    object _30430 = NOVALUE;
    object _30429 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3878		if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _30429 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _30429 = 1;
    }
    _30430 = (_30429 == 0);
    _30429 = NOVALUE;
    if (_30430 != 0) {
        goto L1; // [11] 26
    }
    _30432 = (_43block_index_55436 == 0);
    if (_30432 == 0)
    {
        DeRef(_30432);
        _30432 = NOVALUE;
        goto L2; // [22] 36
    }
    else{
        DeRef(_30432);
        _30432 = NOVALUE;
    }
L1: 

    /** parser.e:3879			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(144, _22209, 0);
L2: 

    /** parser.e:3881		if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (object)SEQ_PTR(_43block_list_55435);
    _30433 = (object)*(((s1_ptr)_2)->base + _43block_index_55436);
    _30434 = (_30433 == 20);
    _30433 = NOVALUE;
    if (_30434 != 0) {
        goto L3; // [52] 75
    }
    _2 = (object)SEQ_PTR(_43block_list_55435);
    _30436 = (object)*(((s1_ptr)_2)->base + _43block_index_55436);
    _30437 = (_30436 == 185);
    _30436 = NOVALUE;
    if (_30437 == 0)
    {
        DeRef(_30437);
        _30437 = NOVALUE;
        goto L4; // [71] 87
    }
    else{
        DeRef(_30437);
        _30437 = NOVALUE;
    }
L3: 

    /** parser.e:3882			CompileErr(THE_INNERMOST_BLOCK_CONTAINING_AN_ENTRY_STATEMENT_MUST_BE_THE_LOOP_IT_DEFINES_AN_ENTRY_IN)*/
    RefDS(_22209);
    _49CompileErr(143, _22209, 0);
    goto L5; // [84] 115
L4: 

    /** parser.e:3883		elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_43loop_stack_55439)){
            _30438 = SEQ_PTR(_43loop_stack_55439)->length;
    }
    else {
        _30438 = 1;
    }
    _2 = (object)SEQ_PTR(_43loop_stack_55439);
    _30439 = (object)*(((s1_ptr)_2)->base + _30438);
    if (_30439 != 21)
    goto L6; // [100] 114

    /** parser.e:3884			CompileErr(THE_ENTRY_STATEMENT_CAN_NOT_BE_USED_IN_A_FOR_BLOCK)*/
    RefDS(_22209);
    _49CompileErr(142, _22209, 0);
L6: 
L5: 

    /** parser.e:3886		addr = entry_addr[$]*/
    if (IS_SEQUENCE(_43entry_addr_55429)){
            _30441 = SEQ_PTR(_43entry_addr_55429)->length;
    }
    else {
        _30441 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55429);
    _addr_61328 = (object)*(((s1_ptr)_2)->base + _30441);

    /** parser.e:3887		if addr=0  then*/
    if (_addr_61328 != 0)
    goto L7; // [128] 144

    /** parser.e:3888			CompileErr(THE_ENTRY_STATEMENT_MUST_APPEAR_AT_MOST_ONCE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(141, _22209, 0);
    goto L8; // [141] 161
L7: 

    /** parser.e:3889		elsif addr<0 then*/
    if (_addr_61328 >= 0)
    goto L9; // [146] 160

    /** parser.e:3890			CompileErr(ENTRY_STATEMENT_IS_BEING_USED_WITHOUT_A_CORRESPONDING_ENTRY_CLAUSE_IN_THE_LOOP_HEADER)*/
    RefDS(_22209);
    _49CompileErr(73, _22209, 0);
L9: 
L8: 

    /** parser.e:3892		backpatch(addr,ELSE)*/
    _45backpatch(_addr_61328, 23);

    /** parser.e:3893		backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _30445 = _addr_61328 + 1;
    if (_30445 > MAXINT){
        _30445 = NewDouble((eudouble)_30445);
    }
    if (IS_SEQUENCE(_27Code_20660)){
            _30446 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30446 = 1;
    }
    _30447 = _30446 + 1;
    _30446 = NOVALUE;
    _30448 = (_27TRANSLATE_20179 > 0);
    _30449 = _30447 + _30448;
    _30447 = NOVALUE;
    _30448 = NOVALUE;
    _45backpatch(_30445, _30449);
    _30445 = NOVALUE;
    _30449 = NOVALUE;

    /** parser.e:3894		entry_addr[$] = 0*/
    if (IS_SEQUENCE(_43entry_addr_55429)){
            _30450 = SEQ_PTR(_43entry_addr_55429)->length;
    }
    else {
        _30450 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_addr_55429);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _43entry_addr_55429 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _30450);
    *(intptr_t *)_2 = 0;

    /** parser.e:3895		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto LA; // [213] 224
    }
    else{
    }

    /** parser.e:3896		    emit_op(NOP1)*/
    _45emit_op(159);
LA: 

    /** parser.e:3899		force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_43entry_stack_55432)){
            _30451 = SEQ_PTR(_43entry_stack_55432)->length;
    }
    else {
        _30451 = 1;
    }
    _2 = (object)SEQ_PTR(_43entry_stack_55432);
    _30452 = (object)*(((s1_ptr)_2)->base + _30451);
    Ref(_30452);
    _43force_uninitialize(_30452);
    _30452 = NOVALUE;

    /** parser.e:3901	end procedure*/
    DeRef(_30434);
    _30434 = NOVALUE;
    _30439 = NOVALUE;
    DeRef(_30430);
    _30430 = NOVALUE;
    return;
    ;
}


void _43force_uninitialize(object _uninitialized_61383)
{
    object _30455 = NOVALUE;
    object _30454 = NOVALUE;
    object _30453 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:3907		for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_61383)){
            _30453 = SEQ_PTR(_uninitialized_61383)->length;
    }
    else {
        _30453 = 1;
    }
    {
        object _i_61385;
        _i_61385 = 1;
L1: 
        if (_i_61385 > _30453){
            goto L2; // [8] 41
        }

        /** parser.e:3908			SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (object)SEQ_PTR(_uninitialized_61383);
        _30454 = (object)*(((s1_ptr)_2)->base + _i_61385);
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _28SymTab_11572 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30454))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30454)->dbl));
        else
        _3 = (object)(_30454 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 14);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = -1;
        DeRef(_1);
        _30455 = NOVALUE;

        /** parser.e:3909		end for*/
        _i_61385 = _i_61385 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** parser.e:3910	end procedure*/
    DeRefDS(_uninitialized_61383);
    _30454 = NOVALUE;
    return;
    ;
}


void _43Statement_list()
{
    object _tok_61395 = NOVALUE;
    object _id_61396 = NOVALUE;
    object _forward_61419 = NOVALUE;
    object _test_61568 = NOVALUE;
    object _30528 = NOVALUE;
    object _30527 = NOVALUE;
    object _30524 = NOVALUE;
    object _30522 = NOVALUE;
    object _30521 = NOVALUE;
    object _30518 = NOVALUE;
    object _30515 = NOVALUE;
    object _30514 = NOVALUE;
    object _30513 = NOVALUE;
    object _30510 = NOVALUE;
    object _30508 = NOVALUE;
    object _30506 = NOVALUE;
    object _30504 = NOVALUE;
    object _30486 = NOVALUE;
    object _30485 = NOVALUE;
    object _30483 = NOVALUE;
    object _30481 = NOVALUE;
    object _30480 = NOVALUE;
    object _30478 = NOVALUE;
    object _30476 = NOVALUE;
    object _30475 = NOVALUE;
    object _30474 = NOVALUE;
    object _30473 = NOVALUE;
    object _30468 = NOVALUE;
    object _30465 = NOVALUE;
    object _30464 = NOVALUE;
    object _30463 = NOVALUE;
    object _30462 = NOVALUE;
    object _30460 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:3915		integer id*/

    /** parser.e:3917		stmt_nest += 1*/
    _43stmt_nest_55437 = _43stmt_nest_55437 + 1;

    /** parser.e:3918		while TRUE do*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [18] 1125
    }
    else{
    }

    /** parser.e:3919			tok = next_token()*/
    _0 = _tok_61395;
    _tok_61395 = _43next_token();
    DeRef(_0);

    /** parser.e:3920			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_61395);
    _id_61396 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_61396)){
        _id_61396 = (object)DBL_PTR(_id_61396)->dbl;
    }

    /** parser.e:3921			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30460 = (_id_61396 == -100);
    if (_30460 != 0) {
        goto L3; // [44] 59
    }
    _30462 = (_id_61396 == 512);
    if (_30462 == 0)
    {
        DeRef(_30462);
        _30462 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_30462);
        _30462 = NOVALUE;
    }
L3: 

    /** parser.e:3922				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61395);
    _30463 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30463)){
        _30464 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30463)->dbl));
    }
    else{
        _30464 = (object)*(((s1_ptr)_2)->base + _30463);
    }
    _2 = (object)SEQ_PTR(_30464);
    _30465 = (object)*(((s1_ptr)_2)->base + 4);
    _30464 = NOVALUE;
    if (binary_op_a(NOTEQ, _30465, 9)){
        _30465 = NOVALUE;
        goto L5; // [81] 210
    }
    _30465 = NOVALUE;

    /** parser.e:3923					token forward = next_token()*/
    _0 = _forward_61419;
    _forward_61419 = _43next_token();
    DeRef(_0);

    /** parser.e:3924					switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_61419);
    _30468 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30468) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_30468)){
        if( (DBL_PTR(_30468)->dbl != (eudouble) ((object) DBL_PTR(_30468)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (object) DBL_PTR(_30468)->dbl;
    }
    else {
        _0 = _30468;
    };
    _30468 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:3925						case LEFT_ROUND then*/
        case -26:

        /** parser.e:3926							StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_441, 0, 2);

        /** parser.e:3928							Forward_call( tok )*/
        Ref(_tok_61395);
        _43Forward_call(_tok_61395, 195);

        /** parser.e:3929							flush_temps()*/
        RefDS(_22209);
        _45flush_temps(_22209);

        /** parser.e:3930							continue*/
        DeRef(_forward_61419);
        _forward_61419 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** parser.e:3932						case VARIABLE then*/
        case -100:

        /** parser.e:3933							putback( forward )*/
        Ref(_forward_61419);
        _43putback(_forward_61419);

        /** parser.e:3934							if param_num != -1 then*/
        if (_43param_num_55414 == -1)
        goto L7; // [150] 176

        /** parser.e:3936								param_num += 1*/
        _43param_num_55414 = _43param_num_55414 + 1;

        /** parser.e:3937								Private_declaration( tok[T_SYM] )*/
        _2 = (object)SEQ_PTR(_tok_61395);
        _30473 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30473);
        _43Private_declaration(_30473);
        _30473 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** parser.e:3939								Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (object)SEQ_PTR(_tok_61395);
        _30474 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30474);
        _30475 = _43Global_declaration(_30474, 5);
        _30474 = NOVALUE;
L8: 

        /** parser.e:3941							flush_temps()*/
        RefDS(_22209);
        _45flush_temps(_22209);

        /** parser.e:3942							continue*/
        DeRef(_forward_61419);
        _forward_61419 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** parser.e:3945					putback( forward )*/
    Ref(_forward_61419);
    _43putback(_forward_61419);
L5: 
    DeRef(_forward_61419);
    _forward_61419 = NOVALUE;

    /** parser.e:3947				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3948				Assignment(tok)*/
    Ref(_tok_61395);
    _43Assignment(_tok_61395);
    goto L9; // [226] 1115
L4: 

    /** parser.e:3950			elsif id = PROC or id = QUALIFIED_PROC then*/
    _30476 = (_id_61396 == 27);
    if (_30476 != 0) {
        goto LA; // [237] 252
    }
    _30478 = (_id_61396 == 521);
    if (_30478 == 0)
    {
        DeRef(_30478);
        _30478 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_30478);
        _30478 = NOVALUE;
    }
LA: 

    /** parser.e:3951				if id = PROC then*/
    if (_id_61396 != 27)
    goto LC; // [256] 272

    /** parser.e:3953					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61395);
    _30480 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30480);
    _43UndefinedVar(_30480);
    _30480 = NOVALUE;
LC: 

    /** parser.e:3955				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3956				Procedure_call(tok)*/
    Ref(_tok_61395);
    _43Procedure_call(_tok_61395);
    goto L9; // [286] 1115
LB: 

    /** parser.e:3958			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30481 = (_id_61396 == 501);
    if (_30481 != 0) {
        goto LD; // [297] 312
    }
    _30483 = (_id_61396 == 520);
    if (_30483 == 0)
    {
        DeRef(_30483);
        _30483 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_30483);
        _30483 = NOVALUE;
    }
LD: 

    /** parser.e:3959				if id = FUNC then*/
    if (_id_61396 != 501)
    goto LF; // [316] 332

    /** parser.e:3961					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61395);
    _30485 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30485);
    _43UndefinedVar(_30485);
    _30485 = NOVALUE;
LF: 

    /** parser.e:3963				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3964				Procedure_call(tok)*/
    Ref(_tok_61395);
    _43Procedure_call(_tok_61395);

    /** parser.e:3965				clear_op()*/
    _45clear_op();

    /** parser.e:3966				if Pop() then end if*/
    _30486 = _45Pop();
    if (_30486 == 0) {
        DeRef(_30486);
        _30486 = NOVALUE;
        goto L9; // [355] 1115
    }
    else {
        if (!IS_ATOM_INT(_30486) && DBL_PTR(_30486)->dbl == 0.0){
            DeRef(_30486);
            _30486 = NOVALUE;
            goto L9; // [355] 1115
        }
        DeRef(_30486);
        _30486 = NOVALUE;
    }
    DeRef(_30486);
    _30486 = NOVALUE;
    goto L9; // [359] 1115
LE: 

    /** parser.e:3968			elsif id = IF then*/
    if (_id_61396 != 20)
    goto L10; // [366] 386

    /** parser.e:3969				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3970				If_statement()*/
    _43If_statement();
    goto L9; // [383] 1115
L10: 

    /** parser.e:3972			elsif id = FOR then*/
    if (_id_61396 != 21)
    goto L11; // [390] 410

    /** parser.e:3973				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3974				For_statement()*/
    _43For_statement();
    goto L9; // [407] 1115
L11: 

    /** parser.e:3976			elsif id = RETURN then*/
    if (_id_61396 != 413)
    goto L12; // [414] 434

    /** parser.e:3977				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3978				Return_statement()*/
    _43Return_statement();
    goto L9; // [431] 1115
L12: 

    /** parser.e:3980			elsif id = LABEL then*/
    if (_id_61396 != 419)
    goto L13; // [438] 460

    /** parser.e:3981				StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_441, 0, 1);

    /** parser.e:3982				GLabel_statement()*/
    _43GLabel_statement();
    goto L9; // [457] 1115
L13: 

    /** parser.e:3984			elsif id = GOTO then*/
    if (_id_61396 != 188)
    goto L14; // [464] 484

    /** parser.e:3985				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3986				Goto_statement()*/
    _43Goto_statement();
    goto L9; // [481] 1115
L14: 

    /** parser.e:3988			elsif id = EXIT then*/
    if (_id_61396 != 61)
    goto L15; // [488] 508

    /** parser.e:3989				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3990				Exit_statement()*/
    _43Exit_statement();
    goto L9; // [505] 1115
L15: 

    /** parser.e:3992			elsif id = BREAK then*/
    if (_id_61396 != 425)
    goto L16; // [512] 532

    /** parser.e:3993				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3994				Break_statement()*/
    _43Break_statement();
    goto L9; // [529] 1115
L16: 

    /** parser.e:3996			elsif id = WHILE then*/
    if (_id_61396 != 47)
    goto L17; // [536] 556

    /** parser.e:3997				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:3998				While_statement()*/
    _43While_statement();
    goto L9; // [553] 1115
L17: 

    /** parser.e:4000			elsif id = LOOP then*/
    if (_id_61396 != 422)
    goto L18; // [560] 580

    /** parser.e:4001			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4002		        Loop_statement()*/
    _43Loop_statement();
    goto L9; // [577] 1115
L18: 

    /** parser.e:4004			elsif id = ENTRY then*/
    if (_id_61396 != 424)
    goto L19; // [584] 606

    /** parser.e:4005			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _45StartSourceLine(_9TRUE_441, 0, 1);

    /** parser.e:4006			    Entry_statement()*/
    _43Entry_statement();
    goto L9; // [603] 1115
L19: 

    /** parser.e:4008			elsif id = QUESTION_MARK then*/
    if (_id_61396 != -31)
    goto L1A; // [610] 630

    /** parser.e:4009				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4010				Print_statement()*/
    _43Print_statement();
    goto L9; // [627] 1115
L1A: 

    /** parser.e:4012			elsif id = CONTINUE then*/
    if (_id_61396 != 426)
    goto L1B; // [634] 654

    /** parser.e:4013				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4014				Continue_statement()*/
    _43Continue_statement();
    goto L9; // [651] 1115
L1B: 

    /** parser.e:4016			elsif id = RETRY then*/
    if (_id_61396 != 184)
    goto L1C; // [658] 678

    /** parser.e:4017				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4018				Retry_statement()*/
    _43Retry_statement();
    goto L9; // [675] 1115
L1C: 

    /** parser.e:4020			elsif id = IFDEF then*/
    if (_id_61396 != 407)
    goto L1D; // [682] 702

    /** parser.e:4021				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4022				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L9; // [699] 1115
L1D: 

    /** parser.e:4024			elsif id = CASE then*/
    if (_id_61396 != 186)
    goto L1E; // [706] 717

    /** parser.e:4025				Case_statement()*/
    _43Case_statement();
    goto L9; // [714] 1115
L1E: 

    /** parser.e:4027			elsif id = SWITCH then*/
    if (_id_61396 != 185)
    goto L1F; // [721] 741

    /** parser.e:4028				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4029				Switch_statement()*/
    _43Switch_statement();
    goto L9; // [738] 1115
L1F: 

    /** parser.e:4031			elsif id = FALLTHRU then*/
    if (_id_61396 != 431)
    goto L20; // [745] 756

    /** parser.e:4032				Fallthru_statement()*/
    _43Fallthru_statement();
    goto L9; // [753] 1115
L20: 

    /** parser.e:4034			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30504 = (_id_61396 == 504);
    if (_30504 != 0) {
        goto L21; // [764] 779
    }
    _30506 = (_id_61396 == 522);
    if (_30506 == 0)
    {
        DeRef(_30506);
        _30506 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_30506);
        _30506 = NOVALUE;
    }
L21: 

    /** parser.e:4035				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4036				token test = next_token()*/
    _0 = _test_61568;
    _test_61568 = _43next_token();
    DeRef(_0);

    /** parser.e:4037				putback( test )*/
    Ref(_test_61568);
    _43putback(_test_61568);

    /** parser.e:4038				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_61568);
    _30508 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30508, -26)){
        _30508 = NOVALUE;
        goto L23; // [808] 852
    }
    _30508 = NOVALUE;

    /** parser.e:4039					StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4040					Procedure_call(tok)*/
    Ref(_tok_61395);
    _43Procedure_call(_tok_61395);

    /** parser.e:4041					clear_op()*/
    _45clear_op();

    /** parser.e:4042					if Pop() then end if*/
    _30510 = _45Pop();
    if (_30510 == 0) {
        DeRef(_30510);
        _30510 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_30510) && DBL_PTR(_30510)->dbl == 0.0){
            DeRef(_30510);
            _30510 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_30510);
        _30510 = NOVALUE;
    }
    DeRef(_30510);
    _30510 = NOVALUE;
L24: 

    /** parser.e:4043					ExecCommand()*/
    _43ExecCommand();

    /** parser.e:4044					continue*/
    DeRef(_test_61568);
    _test_61568 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** parser.e:4047					if param_num != -1 then*/
    if (_43param_num_55414 == -1)
    goto L26; // [856] 882

    /** parser.e:4049						param_num += 1*/
    _43param_num_55414 = _43param_num_55414 + 1;

    /** parser.e:4050						Private_declaration( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61395);
    _30513 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30513);
    _43Private_declaration(_30513);
    _30513 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** parser.e:4052						Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_61395);
    _30514 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30514);
    _30515 = _43Global_declaration(_30514, 5);
    _30514 = NOVALUE;
L27: 
L25: 
    DeRef(_test_61568);
    _test_61568 = NOVALUE;
    goto L9; // [901] 1115
L22: 

    /** parser.e:4055			elsif id = LEFT_BRACE then*/
    if (_id_61396 != -24)
    goto L28; // [908] 928

    /** parser.e:4056				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4057				Multi_assign()*/
    _43Multi_assign();
    goto L9; // [925] 1115
L28: 

    /** parser.e:4060				if id = ELSE then*/
    if (_id_61396 != 23)
    goto L29; // [932] 990

    /** parser.e:4061					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _30518 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _30518 = 1;
    }
    if (_30518 != 0)
    goto L2A; // [943] 1051

    /** parser.e:4062						if live_ifdef > 0 then*/
    if (_43live_ifdef_59907 <= 0)
    goto L2B; // [951] 976

    /** parser.e:4063							CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _30521 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _30521 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _30522 = (object)*(((s1_ptr)_2)->base + _30521);
    _49CompileErr(134, _30522, 0);
    _30522 = NOVALUE;
    goto L2A; // [973] 1051
L2B: 

    /** parser.e:4065							CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22209);
    _49CompileErr(118, _22209, 0);
    goto L2A; // [987] 1051
L29: 

    /** parser.e:4068				elsif id = ELSIF then*/
    if (_id_61396 != 414)
    goto L2C; // [994] 1050

    /** parser.e:4069					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _30524 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _30524 = 1;
    }
    if (_30524 != 0)
    goto L2D; // [1005] 1049

    /** parser.e:4070						if live_ifdef > 0 then*/
    if (_43live_ifdef_59907 <= 0)
    goto L2E; // [1013] 1038

    /** parser.e:4071							CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _30527 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _30527 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _30528 = (object)*(((s1_ptr)_2)->base + _30527);
    _49CompileErr(139, _30528, 0);
    _30528 = NOVALUE;
    goto L2F; // [1035] 1048
L2E: 

    /** parser.e:4073							CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22209);
    _49CompileErr(119, _22209, 0);
L2F: 
L2D: 
L2C: 
L2A: 

    /** parser.e:4078				putback( tok )*/
    Ref(_tok_61395);
    _43putback(_tok_61395);

    /** parser.e:4080				switch id do*/
    _0 = _id_61396;
    switch ( _0 ){ 

        /** parser.e:4081					case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** parser.e:4083						stmt_nest -= 1*/
        _43stmt_nest_55437 = _43stmt_nest_55437 - 1;

        /** parser.e:4084						InitDelete()*/
        _43InitDelete();

        /** parser.e:4085						flush_temps()*/
        RefDS(_22209);
        _45flush_temps(_22209);

        /** parser.e:4086						return*/
        DeRef(_tok_61395);
        DeRef(_30504);
        _30504 = NOVALUE;
        DeRef(_30481);
        _30481 = NOVALUE;
        DeRef(_30475);
        _30475 = NOVALUE;
        DeRef(_30476);
        _30476 = NOVALUE;
        DeRef(_30460);
        _30460 = NOVALUE;
        _30463 = NOVALUE;
        DeRef(_30515);
        _30515 = NOVALUE;
        return;
        goto L30; // [1099] 1114

        /** parser.e:4088					case else*/
        default:

        /** parser.e:4089						tok_match( END )*/
        _43tok_match(402, 0);
    ;}L30: 
L9: 

    /** parser.e:4094			flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:4095		end while*/
    goto L1; // [1122] 16
L2: 

    /** parser.e:4096	end procedure*/
    DeRef(_tok_61395);
    DeRef(_30504);
    _30504 = NOVALUE;
    DeRef(_30481);
    _30481 = NOVALUE;
    DeRef(_30475);
    _30475 = NOVALUE;
    DeRef(_30476);
    _30476 = NOVALUE;
    DeRef(_30460);
    _30460 = NOVALUE;
    _30463 = NOVALUE;
    DeRef(_30515);
    _30515 = NOVALUE;
    return;
    ;
}


void _43SubProg(object _prog_type_61647, object _scope_61648, object _deprecated_61649)
{
    object _h_61650 = NOVALUE;
    object _pt_61651 = NOVALUE;
    object _p_61653 = NOVALUE;
    object _type_sym_61654 = NOVALUE;
    object _sym_61655 = NOVALUE;
    object _tok_61657 = NOVALUE;
    object _prog_name_61658 = NOVALUE;
    object _first_def_arg_61659 = NOVALUE;
    object _again_61660 = NOVALUE;
    object _type_enum_61661 = NOVALUE;
    object _seq_sym_61662 = NOVALUE;
    object _i1_sym_61663 = NOVALUE;
    object _enum_syms_61664 = NOVALUE;
    object _type_enum_gline_61665 = NOVALUE;
    object _real_gline_61666 = NOVALUE;
    object _tsym_61678 = NOVALUE;
    object _seq_symbol_61689 = NOVALUE;
    object _middle_def_args_61894 = NOVALUE;
    object _last_nda_61895 = NOVALUE;
    object _start_def_61896 = NOVALUE;
    object _last_link_61898 = NOVALUE;
    object _temptok_61925 = NOVALUE;
    object _undef_type_61927 = NOVALUE;
    object _tokcat_61979 = NOVALUE;
    object _31971 = NOVALUE;
    object _31970 = NOVALUE;
    object _31969 = NOVALUE;
    object _31968 = NOVALUE;
    object _31967 = NOVALUE;
    object _31966 = NOVALUE;
    object _31965 = NOVALUE;
    object _31964 = NOVALUE;
    object _31963 = NOVALUE;
    object _30794 = NOVALUE;
    object _30792 = NOVALUE;
    object _30791 = NOVALUE;
    object _30789 = NOVALUE;
    object _30788 = NOVALUE;
    object _30787 = NOVALUE;
    object _30786 = NOVALUE;
    object _30785 = NOVALUE;
    object _30783 = NOVALUE;
    object _30782 = NOVALUE;
    object _30779 = NOVALUE;
    object _30778 = NOVALUE;
    object _30777 = NOVALUE;
    object _30776 = NOVALUE;
    object _30774 = NOVALUE;
    object _30765 = NOVALUE;
    object _30763 = NOVALUE;
    object _30762 = NOVALUE;
    object _30761 = NOVALUE;
    object _30760 = NOVALUE;
    object _30757 = NOVALUE;
    object _30756 = NOVALUE;
    object _30755 = NOVALUE;
    object _30753 = NOVALUE;
    object _30750 = NOVALUE;
    object _30749 = NOVALUE;
    object _30748 = NOVALUE;
    object _30746 = NOVALUE;
    object _30745 = NOVALUE;
    object _30742 = NOVALUE;
    object _30740 = NOVALUE;
    object _30738 = NOVALUE;
    object _30737 = NOVALUE;
    object _30736 = NOVALUE;
    object _30735 = NOVALUE;
    object _30733 = NOVALUE;
    object _30732 = NOVALUE;
    object _30731 = NOVALUE;
    object _30730 = NOVALUE;
    object _30729 = NOVALUE;
    object _30728 = NOVALUE;
    object _30725 = NOVALUE;
    object _30723 = NOVALUE;
    object _30721 = NOVALUE;
    object _30719 = NOVALUE;
    object _30717 = NOVALUE;
    object _30714 = NOVALUE;
    object _30712 = NOVALUE;
    object _30711 = NOVALUE;
    object _30708 = NOVALUE;
    object _30704 = NOVALUE;
    object _30703 = NOVALUE;
    object _30701 = NOVALUE;
    object _30699 = NOVALUE;
    object _30697 = NOVALUE;
    object _30695 = NOVALUE;
    object _30693 = NOVALUE;
    object _30691 = NOVALUE;
    object _30690 = NOVALUE;
    object _30689 = NOVALUE;
    object _30688 = NOVALUE;
    object _30687 = NOVALUE;
    object _30686 = NOVALUE;
    object _30685 = NOVALUE;
    object _30684 = NOVALUE;
    object _30683 = NOVALUE;
    object _30682 = NOVALUE;
    object _30681 = NOVALUE;
    object _30680 = NOVALUE;
    object _30677 = NOVALUE;
    object _30676 = NOVALUE;
    object _30675 = NOVALUE;
    object _30674 = NOVALUE;
    object _30673 = NOVALUE;
    object _30672 = NOVALUE;
    object _30671 = NOVALUE;
    object _30670 = NOVALUE;
    object _30669 = NOVALUE;
    object _30668 = NOVALUE;
    object _30667 = NOVALUE;
    object _30666 = NOVALUE;
    object _30665 = NOVALUE;
    object _30664 = NOVALUE;
    object _30663 = NOVALUE;
    object _30661 = NOVALUE;
    object _30659 = NOVALUE;
    object _30658 = NOVALUE;
    object _30653 = NOVALUE;
    object _30652 = NOVALUE;
    object _30650 = NOVALUE;
    object _30649 = NOVALUE;
    object _30648 = NOVALUE;
    object _30647 = NOVALUE;
    object _30646 = NOVALUE;
    object _30645 = NOVALUE;
    object _30644 = NOVALUE;
    object _30643 = NOVALUE;
    object _30642 = NOVALUE;
    object _30641 = NOVALUE;
    object _30639 = NOVALUE;
    object _30638 = NOVALUE;
    object _30636 = NOVALUE;
    object _30635 = NOVALUE;
    object _30634 = NOVALUE;
    object _30633 = NOVALUE;
    object _30632 = NOVALUE;
    object _30631 = NOVALUE;
    object _30630 = NOVALUE;
    object _30628 = NOVALUE;
    object _30625 = NOVALUE;
    object _30623 = NOVALUE;
    object _30621 = NOVALUE;
    object _30619 = NOVALUE;
    object _30617 = NOVALUE;
    object _30615 = NOVALUE;
    object _30613 = NOVALUE;
    object _30611 = NOVALUE;
    object _30609 = NOVALUE;
    object _30607 = NOVALUE;
    object _30606 = NOVALUE;
    object _30605 = NOVALUE;
    object _30604 = NOVALUE;
    object _30603 = NOVALUE;
    object _30602 = NOVALUE;
    object _30601 = NOVALUE;
    object _30599 = NOVALUE;
    object _30598 = NOVALUE;
    object _30596 = NOVALUE;
    object _30594 = NOVALUE;
    object _30592 = NOVALUE;
    object _30591 = NOVALUE;
    object _30588 = NOVALUE;
    object _30587 = NOVALUE;
    object _30586 = NOVALUE;
    object _30585 = NOVALUE;
    object _30584 = NOVALUE;
    object _30582 = NOVALUE;
    object _30581 = NOVALUE;
    object _30580 = NOVALUE;
    object _30579 = NOVALUE;
    object _30578 = NOVALUE;
    object _30576 = NOVALUE;
    object _30575 = NOVALUE;
    object _30574 = NOVALUE;
    object _30572 = NOVALUE;
    object _30571 = NOVALUE;
    object _30570 = NOVALUE;
    object _30569 = NOVALUE;
    object _30565 = NOVALUE;
    object _30564 = NOVALUE;
    object _30563 = NOVALUE;
    object _30561 = NOVALUE;
    object _30560 = NOVALUE;
    object _30559 = NOVALUE;
    object _30558 = NOVALUE;
    object _30557 = NOVALUE;
    object _30556 = NOVALUE;
    object _30552 = NOVALUE;
    object _30551 = NOVALUE;
    object _30550 = NOVALUE;
    object _30548 = NOVALUE;
    object _30547 = NOVALUE;
    object _30546 = NOVALUE;
    object _30544 = NOVALUE;
    object _30543 = NOVALUE;
    object _30541 = NOVALUE;
    object _30540 = NOVALUE;
    object _30539 = NOVALUE;
    object _30535 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_61647)) {
        _1 = (object)(DBL_PTR(_prog_type_61647)->dbl);
        DeRefDS(_prog_type_61647);
        _prog_type_61647 = _1;
    }

    /** parser.e:4105		integer first_def_arg*/

    /** parser.e:4106		integer again*/

    /** parser.e:4107		integer type_enum*/

    /** parser.e:4108		object seq_sym*/

    /** parser.e:4109		object i1_sym*/

    /** parser.e:4110		sequence enum_syms = {}*/
    RefDS(_22209);
    DeRef(_enum_syms_61664);
    _enum_syms_61664 = _22209;

    /** parser.e:4111		integer type_enum_gline, real_gline*/

    /** parser.e:4113		LeaveTopLevel()*/
    _43LeaveTopLevel();

    /** parser.e:4114		prog_name = next_token()*/
    _0 = _prog_name_61658;
    _prog_name_61658 = _43next_token();
    DeRef(_0);

    /** parser.e:4115		if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _30535 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30535, -21)){
        _30535 = NOVALUE;
        goto L1; // [45] 59
    }
    _30535 = NOVALUE;

    /** parser.e:4116			CompileErr( AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(32, _22209, 0);
L1: 

    /** parser.e:4118		type_enum =  0*/
    _type_enum_61661 = 0;

    /** parser.e:4119		if prog_type = TYPE_DECL then*/
    if (_prog_type_61647 != 416)
    goto L2; // [68] 322

    /** parser.e:4120			object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_61678);
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _tsym_61678 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_61678);

    /** parser.e:4121			if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _30539 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30539);
    _30540 = _53sym_name(_30539);
    _30539 = NOVALUE;
    if (_30540 == _26474)
    _30541 = 1;
    else if (IS_ATOM_INT(_30540) && IS_ATOM_INT(_26474))
    _30541 = 0;
    else
    _30541 = (compare(_30540, _26474) == 0);
    DeRef(_30540);
    _30540 = NOVALUE;
    if (_30541 == 0)
    {
        _30541 = NOVALUE;
        goto L3; // [96] 319
    }
    else{
        _30541 = NOVALUE;
    }

    /** parser.e:4125				EnterTopLevel( FALSE )*/
    _43EnterTopLevel(_9FALSE_439);

    /** parser.e:4126				type_enum_gline = gline_number*/
    _type_enum_gline_61665 = _27gline_number_20576;

    /** parser.e:4127				type_enum = 1*/
    _type_enum_61661 = 1;

    /** parser.e:4128				sequence seq_symbol*/

    /** parser.e:4129				prog_name = next_token()*/
    _0 = _prog_name_61658;
    _prog_name_61658 = _43next_token();
    DeRef(_0);

    /** parser.e:4130				if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _30543 = (object)*(((s1_ptr)_2)->base + 1);
    _30544 = find_from(_30543, _29ADDR_TOKS_12281, 1);
    _30543 = NOVALUE;
    if (_30544 != 0)
    goto L4; // [142] 169
    _30544 = NOVALUE;

    /** parser.e:4131					CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _30546 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30546);
    _30547 = _62find_category(_30546);
    _30546 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30547;
    _30548 = MAKE_SEQ(_1);
    _30547 = NOVALUE;
    _49CompileErr(25, _30548, 0);
    _30548 = NOVALUE;
L4: 

    /** parser.e:4133				enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_61664;
    _enum_syms_61664 = _43Global_declaration(-1, _scope_61648);
    DeRef(_0);

    /** parser.e:4134				seq_symbol = enum_syms*/
    RefDS(_enum_syms_61664);
    DeRef(_seq_symbol_61689);
    _seq_symbol_61689 = _enum_syms_61664;

    /** parser.e:4135				for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_61664)){
            _30550 = SEQ_PTR(_enum_syms_61664)->length;
    }
    else {
        _30550 = 1;
    }
    {
        object _i_61706;
        _i_61706 = 1;
L5: 
        if (_i_61706 > _30550){
            goto L6; // [190] 218
        }

        /** parser.e:4136					seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (object)SEQ_PTR(_enum_syms_61664);
        _30551 = (object)*(((s1_ptr)_2)->base + _i_61706);
        Ref(_30551);
        _30552 = _53sym_obj(_30551);
        _30551 = NOVALUE;
        _2 = (object)SEQ_PTR(_seq_symbol_61689);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _seq_symbol_61689 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_61706);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _30552;
        if( _1 != _30552 ){
            DeRef(_1);
        }
        _30552 = NOVALUE;

        /** parser.e:4137				end for*/
        _i_61706 = _i_61706 + 1;
        goto L5; // [213] 197
L6: 
        ;
    }

    /** parser.e:4142				i1_sym = keyfind("i1",-1)*/
    RefDS(_30553);
    DeRef(_31970);
    _31970 = _30553;
    _31971 = _53hashfn(_31970);
    _31970 = NOVALUE;
    RefDS(_30553);
    _0 = _i1_sym_61663;
    _i1_sym_61663 = _53keyfind(_30553, -1, _27current_file_no_20571, 0, _31971);
    DeRef(_0);
    _31971 = NOVALUE;

    /** parser.e:4143				seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_61689);
    _0 = _seq_sym_61662;
    _seq_sym_61662 = _53NewStringSym(_seq_symbol_61689);
    DeRef(_0);

    /** parser.e:4144				putback(keyfind("return",-1))*/
    RefDS(_26548);
    DeRef(_31968);
    _31968 = _26548;
    _31969 = _53hashfn(_31968);
    _31968 = NOVALUE;
    RefDS(_26548);
    _30556 = _53keyfind(_26548, -1, _27current_file_no_20571, 0, _31969);
    _31969 = NOVALUE;
    _43putback(_30556);
    _30556 = NOVALUE;

    /** parser.e:4145				putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27;
    ((intptr_t *)_2)[2] = 0;
    _30557 = MAKE_SEQ(_1);
    _43putback(_30557);
    _30557 = NOVALUE;

    /** parser.e:4146				putback(i1_sym)*/
    Ref(_i1_sym_61663);
    _43putback(_i1_sym_61663);

    /** parser.e:4147				putback(keyfind("object",-1))*/
    RefDS(_23166);
    DeRef(_31966);
    _31966 = _23166;
    _31967 = _53hashfn(_31966);
    _31966 = NOVALUE;
    RefDS(_23166);
    _30558 = _53keyfind(_23166, -1, _27current_file_no_20571, 0, _31967);
    _31967 = NOVALUE;
    _43putback(_30558);
    _30558 = NOVALUE;

    /** parser.e:4148				putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26;
    ((intptr_t *)_2)[2] = 0;
    _30559 = MAKE_SEQ(_1);
    _43putback(_30559);
    _30559 = NOVALUE;

    /** parser.e:4150				LeaveTopLevel()*/
    _43LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_61689);
    _seq_symbol_61689 = NOVALUE;
L2: 
    DeRef(_tsym_61678);
    _tsym_61678 = NOVALUE;

    /** parser.e:4153		if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _30560 = (object)*(((s1_ptr)_2)->base + 1);
    _30561 = find_from(_30560, _29ADDR_TOKS_12281, 1);
    _30560 = NOVALUE;
    if (_30561 != 0)
    goto L7; // [339] 366
    _30561 = NOVALUE;

    /** parser.e:4154			CompileErr(FOUND__1__BUT_WAS_EXPECTING_AN_IDENTIFIER_NAME, {find_category(prog_name[T_ID])} )*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _30563 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30563);
    _30564 = _62find_category(_30563);
    _30563 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30564;
    _30565 = MAKE_SEQ(_1);
    _30564 = NOVALUE;
    _49CompileErr(25, _30565, 0);
    _30565 = NOVALUE;
L7: 

    /** parser.e:4156		p = prog_name[T_SYM]*/
    _2 = (object)SEQ_PTR(_prog_name_61658);
    _p_61653 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_61653)){
        _p_61653 = (object)DBL_PTR(_p_61653)->dbl;
    }

    /** parser.e:4157		DefinedYet(p)*/
    _53DefinedYet(_p_61653);

    /** parser.e:4158		if prog_type = PROCEDURE then*/
    if (_prog_type_61647 != 405)
    goto L8; // [385] 401

    /** parser.e:4159			pt = PROC*/
    _pt_61651 = 27;
    goto L9; // [398] 431
L8: 

    /** parser.e:4160		elsif prog_type = FUNCTION then*/
    if (_prog_type_61647 != 406)
    goto LA; // [405] 421

    /** parser.e:4161			pt = FUNC*/
    _pt_61651 = 501;
    goto L9; // [418] 431
LA: 

    /** parser.e:4163			pt = TYPE*/
    _pt_61651 = 504;
L9: 

    /** parser.e:4166		clear_fwd_refs()*/
    _42clear_fwd_refs();

    /** parser.e:4167		if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30569 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30569);
    _30570 = (object)*(((s1_ptr)_2)->base + 4);
    _30569 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 7;
    ((intptr_t*)_2)[2] = 6;
    ((intptr_t*)_2)[3] = 13;
    ((intptr_t*)_2)[4] = 11;
    ((intptr_t*)_2)[5] = 12;
    _30571 = MAKE_SEQ(_1);
    _30572 = find_from(_30570, _30571, 1);
    _30570 = NOVALUE;
    DeRefDS(_30571);
    _30571 = NOVALUE;
    if (_30572 == 0)
    {
        _30572 = NOVALUE;
        goto LB; // [472] 668
    }
    else{
        _30572 = NOVALUE;
    }

    /** parser.e:4169			if scope = SC_OVERRIDE then*/
    if (_scope_61648 != 12)
    goto LC; // [479] 605

    /** parser.e:4170				if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30574 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30574);
    _30575 = (object)*(((s1_ptr)_2)->base + 4);
    _30574 = NOVALUE;
    if (IS_ATOM_INT(_30575)) {
        _30576 = (_30575 == 7);
    }
    else {
        _30576 = binary_op(EQUALS, _30575, 7);
    }
    _30575 = NOVALUE;
    if (IS_ATOM_INT(_30576)) {
        if (_30576 != 0) {
            goto LD; // [503] 530
        }
    }
    else {
        if (DBL_PTR(_30576)->dbl != 0.0) {
            goto LD; // [503] 530
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30578 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30578);
    _30579 = (object)*(((s1_ptr)_2)->base + 4);
    _30578 = NOVALUE;
    if (IS_ATOM_INT(_30579)) {
        _30580 = (_30579 == 12);
    }
    else {
        _30580 = binary_op(EQUALS, _30579, 12);
    }
    _30579 = NOVALUE;
    if (_30580 == 0) {
        DeRef(_30580);
        _30580 = NOVALUE;
        goto LE; // [526] 604
    }
    else {
        if (!IS_ATOM_INT(_30580) && DBL_PTR(_30580)->dbl == 0.0){
            DeRef(_30580);
            _30580 = NOVALUE;
            goto LE; // [526] 604
        }
        DeRef(_30580);
        _30580 = NOVALUE;
    }
    DeRef(_30580);
    _30580 = NOVALUE;
LD: 

    /** parser.e:4171						if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30581 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30581);
    _30582 = (object)*(((s1_ptr)_2)->base + 4);
    _30581 = NOVALUE;
    if (binary_op_a(NOTEQ, _30582, 12)){
        _30582 = NOVALUE;
        goto LF; // [546] 558
    }
    _30582 = NOVALUE;

    /** parser.e:4172							again = 223*/
    _again_61660 = 223;
    goto L10; // [555] 564
LF: 

    /** parser.e:4174							again = 222*/
    _again_61660 = 222;
L10: 

    /** parser.e:4176						Warning(again, override_warning_flag,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _30584 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30585 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30585);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30586 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30586 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30585 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30584);
    ((intptr_t*)_2)[1] = _30584;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    Ref(_30586);
    ((intptr_t*)_2)[3] = _30586;
    _30587 = MAKE_SEQ(_1);
    _30586 = NOVALUE;
    _30584 = NOVALUE;
    _49Warning(_again_61660, 4, _30587);
    _30587 = NOVALUE;
LE: 
LC: 

    /** parser.e:4181			h = SymTab[p][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30588 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30588);
    _h_61650 = (object)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_61650)){
        _h_61650 = (object)DBL_PTR(_h_61650)->dbl;
    }
    _30588 = NOVALUE;

    /** parser.e:4182			sym = buckets[h]*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _sym_61655 = (object)*(((s1_ptr)_2)->base + _h_61650);
    if (!IS_ATOM_INT(_sym_61655)){
        _sym_61655 = (object)DBL_PTR(_sym_61655)->dbl;
    }

    /** parser.e:4183			p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30591 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30591);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30592 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30592 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30591 = NOVALUE;
    Ref(_30592);
    _p_61653 = _53NewEntry(_30592, 0, 0, _pt_61651, _h_61650, _sym_61655, 0);
    _30592 = NOVALUE;
    if (!IS_ATOM_INT(_p_61653)) {
        _1 = (object)(DBL_PTR(_p_61653)->dbl);
        DeRefDS(_p_61653);
        _p_61653 = _1;
    }

    /** parser.e:4184			buckets[h] = p*/
    _2 = (object)SEQ_PTR(_53buckets_47180);
    _2 = (object)(((s1_ptr)_2)->base + _h_61650);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_61653;
    DeRef(_1);
LB: 

    /** parser.e:4187		Start_block( pt, p )*/
    _64Start_block(_pt_61651, _p_61653);

    /** parser.e:4189		CurrentSub = p*/
    _27CurrentSub_20579 = _p_61653;

    /** parser.e:4190		first_def_arg = 0*/
    _first_def_arg_61659 = 0;

    /** parser.e:4191		temps_allocated = 0*/
    _53temps_allocated_47715 = 0;

    /** parser.e:4193		SymTab[p][S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_61648;
    DeRef(_1);
    _30594 = NOVALUE;

    /** parser.e:4195		SymTab[p][S_TOKEN] = pt*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TOKEN_20214))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _pt_61651;
    DeRef(_1);
    _30596 = NOVALUE;

    /** parser.e:4197		if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30598 = (object)*(((s1_ptr)_2)->base + _p_61653);
    if (IS_SEQUENCE(_30598)){
            _30599 = SEQ_PTR(_30598)->length;
    }
    else {
        _30599 = 1;
    }
    _30598 = NOVALUE;
    if (_30599 >= _27SIZEOF_ROUTINE_ENTRY_20335)
    goto L11; // [738] 780

    /** parser.e:4199			SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30601 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30602 = (object)*(((s1_ptr)_2)->base + _p_61653);
    if (IS_SEQUENCE(_30602)){
            _30603 = SEQ_PTR(_30602)->length;
    }
    else {
        _30603 = 1;
    }
    _30602 = NOVALUE;
    _30604 = _27SIZEOF_ROUTINE_ENTRY_20335 - _30603;
    _30603 = NOVALUE;
    _30605 = Repeat(0, _30604);
    _30604 = NOVALUE;
    if (IS_SEQUENCE(_30601) && IS_ATOM(_30605)) {
    }
    else if (IS_ATOM(_30601) && IS_SEQUENCE(_30605)) {
        Ref(_30601);
        Prepend(&_30606, _30605, _30601);
    }
    else {
        Concat((object_ptr)&_30606, _30601, _30605);
        _30601 = NOVALUE;
    }
    _30601 = NOVALUE;
    DeRefDS(_30605);
    _30605 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _p_61653);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30606;
    if( _1 != _30606 ){
        DeRef(_1);
    }
    _30606 = NOVALUE;
L11: 

    /** parser.e:4203		SymTab[p][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30607 = NOVALUE;

    /** parser.e:4204		SymTab[p][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30609 = NOVALUE;

    /** parser.e:4205		SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30611 = NOVALUE;

    /** parser.e:4206		SymTab[p][S_REFLIST] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _30613 = NOVALUE;

    /** parser.e:4207		SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27gline_number_20576;
    DeRef(_1);
    _30615 = NOVALUE;

    /** parser.e:4208		SymTab[p][S_TEMPS] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_TEMPS_20254))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TEMPS_20254)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_TEMPS_20254);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30617 = NOVALUE;

    /** parser.e:4209		SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30619 = NOVALUE;

    /** parser.e:4210		SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    RefDS(_22209);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22209;
    DeRef(_1);
    _30621 = NOVALUE;

    /** parser.e:4211		SymTab[p][S_DEPRECATED] = deprecated*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _deprecated_61649;
    DeRef(_1);
    _30623 = NOVALUE;

    /** parser.e:4213		if type_enum then*/
    if (_type_enum_61661 == 0)
    {
        goto L12; // [921] 978
    }
    else{
    }

    /** parser.e:4214			SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_FIRSTLINE_20249))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FIRSTLINE_20249)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_FIRSTLINE_20249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_enum_gline_61665;
    DeRef(_1);
    _30625 = NOVALUE;

    /** parser.e:4215			real_gline = gline_number*/
    _real_gline_61666 = _27gline_number_20576;

    /** parser.e:4216			gline_number = type_enum_gline*/
    _27gline_number_20576 = _type_enum_gline_61665;

    /** parser.e:4217			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _45StartSourceLine(_9FALSE_439, 0, 3);

    /** parser.e:4218			gline_number = real_gline*/
    _27gline_number_20576 = _real_gline_61666;
    goto L13; // [975] 990
L12: 

    /** parser.e:4220			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _45StartSourceLine(_9FALSE_439, 0, 3);
L13: 

    /** parser.e:4223		tok_match(LEFT_ROUND)*/
    _43tok_match(-26, 0);

    /** parser.e:4224		tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4225		param_num = 0*/
    _43param_num_55414 = 0;

    /** parser.e:4228		sequence middle_def_args = {}*/
    RefDS(_22209);
    DeRef(_middle_def_args_61894);
    _middle_def_args_61894 = _22209;

    /** parser.e:4229		integer last_nda = 0, start_def = 0*/
    _last_nda_61895 = 0;
    _start_def_61896 = 0;

    /** parser.e:4230		symtab_index last_link = p*/
    _last_link_61898 = _p_61653;

    /** parser.e:4231		while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (object)SEQ_PTR(_tok_61657);
    _30628 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30628, -27)){
        _30628 = NOVALUE;
        goto L15; // [1043] 1830
    }
    _30628 = NOVALUE;

    /** parser.e:4234			if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30630 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30630)) {
        _30631 = (_30630 != 504);
    }
    else {
        _30631 = binary_op(NOTEQ, _30630, 504);
    }
    _30630 = NOVALUE;
    if (IS_ATOM_INT(_30631)) {
        if (_30631 == 0) {
            goto L16; // [1061] 1291
        }
    }
    else {
        if (DBL_PTR(_30631)->dbl == 0.0) {
            goto L16; // [1061] 1291
        }
    }
    _2 = (object)SEQ_PTR(_tok_61657);
    _30633 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30633)) {
        _30634 = (_30633 != 522);
    }
    else {
        _30634 = binary_op(NOTEQ, _30633, 522);
    }
    _30633 = NOVALUE;
    if (_30634 == 0) {
        DeRef(_30634);
        _30634 = NOVALUE;
        goto L16; // [1078] 1291
    }
    else {
        if (!IS_ATOM_INT(_30634) && DBL_PTR(_30634)->dbl == 0.0){
            DeRef(_30634);
            _30634 = NOVALUE;
            goto L16; // [1078] 1291
        }
        DeRef(_30634);
        _30634 = NOVALUE;
    }
    DeRef(_30634);
    _30634 = NOVALUE;

    /** parser.e:4235				if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30635 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30635)) {
        _30636 = (_30635 == -100);
    }
    else {
        _30636 = binary_op(EQUALS, _30635, -100);
    }
    _30635 = NOVALUE;
    if (IS_ATOM_INT(_30636)) {
        if (_30636 != 0) {
            goto L17; // [1095] 1116
        }
    }
    else {
        if (DBL_PTR(_30636)->dbl != 0.0) {
            goto L17; // [1095] 1116
        }
    }
    _2 = (object)SEQ_PTR(_tok_61657);
    _30638 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30638)) {
        _30639 = (_30638 == 512);
    }
    else {
        _30639 = binary_op(EQUALS, _30638, 512);
    }
    _30638 = NOVALUE;
    if (_30639 == 0) {
        DeRef(_30639);
        _30639 = NOVALUE;
        goto L18; // [1112] 1280
    }
    else {
        if (!IS_ATOM_INT(_30639) && DBL_PTR(_30639)->dbl == 0.0){
            DeRef(_30639);
            _30639 = NOVALUE;
            goto L18; // [1112] 1280
        }
        DeRef(_30639);
        _30639 = NOVALUE;
    }
    DeRef(_30639);
    _30639 = NOVALUE;
L17: 

    /** parser.e:4237					token temptok = next_token()*/
    _0 = _temptok_61925;
    _temptok_61925 = _43next_token();
    DeRef(_0);

    /** parser.e:4238					integer undef_type = 0*/
    _undef_type_61927 = 0;

    /** parser.e:4239					if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (object)SEQ_PTR(_temptok_61925);
    _30641 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30641)) {
        _30642 = (_30641 != 504);
    }
    else {
        _30642 = binary_op(NOTEQ, _30641, 504);
    }
    _30641 = NOVALUE;
    if (IS_ATOM_INT(_30642)) {
        if (_30642 == 0) {
            goto L19; // [1140] 1243
        }
    }
    else {
        if (DBL_PTR(_30642)->dbl == 0.0) {
            goto L19; // [1140] 1243
        }
    }
    _2 = (object)SEQ_PTR(_temptok_61925);
    _30644 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30644)) {
        _30645 = (_30644 != 522);
    }
    else {
        _30645 = binary_op(NOTEQ, _30644, 522);
    }
    _30644 = NOVALUE;
    if (_30645 == 0) {
        DeRef(_30645);
        _30645 = NOVALUE;
        goto L19; // [1157] 1243
    }
    else {
        if (!IS_ATOM_INT(_30645) && DBL_PTR(_30645)->dbl == 0.0){
            DeRef(_30645);
            _30645 = NOVALUE;
            goto L19; // [1157] 1243
        }
        DeRef(_30645);
        _30645 = NOVALUE;
    }
    DeRef(_30645);
    _30645 = NOVALUE;

    /** parser.e:4240						if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_temptok_61925);
    _30646 = (object)*(((s1_ptr)_2)->base + 1);
    _30647 = find_from(_30646, _29FULL_ID_TOKS_12285, 1);
    _30646 = NOVALUE;
    if (_30647 == 0)
    {
        _30647 = NOVALUE;
        goto L1A; // [1175] 1242
    }
    else{
        _30647 = NOVALUE;
    }

    /** parser.e:4242							if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30648 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30648)){
        _30649 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30648)->dbl));
    }
    else{
        _30649 = (object)*(((s1_ptr)_2)->base + _30648);
    }
    _2 = (object)SEQ_PTR(_30649);
    _30650 = (object)*(((s1_ptr)_2)->base + 4);
    _30649 = NOVALUE;
    if (binary_op_a(NOTEQ, _30650, 9)){
        _30650 = NOVALUE;
        goto L1B; // [1200] 1231
    }
    _30650 = NOVALUE;

    /** parser.e:4245								undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30652 = (object)*(((s1_ptr)_2)->base + 2);
    DeRef(_31965);
    _31965 = 504;
    Ref(_30652);
    _30653 = _42new_forward_reference(504, _30652, 504);
    _30652 = NOVALUE;
    _31965 = NOVALUE;
    if (IS_ATOM_INT(_30653)) {
        if ((uintptr_t)_30653 == (uintptr_t)HIGH_BITS){
            _undef_type_61927 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _undef_type_61927 = - _30653;
        }
    }
    else {
        _undef_type_61927 = unary_op(UMINUS, _30653);
    }
    DeRef(_30653);
    _30653 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_61927)) {
        _1 = (object)(DBL_PTR(_undef_type_61927)->dbl);
        DeRefDS(_undef_type_61927);
        _undef_type_61927 = _1;
    }
    goto L1C; // [1228] 1241
L1B: 

    /** parser.e:4247								CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(37, _22209, 0);
L1C: 
L1A: 
L19: 

    /** parser.e:4251					putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_61925);
    _43putback(_temptok_61925);

    /** parser.e:4252					if undef_type != 0 then*/
    if (_undef_type_61927 == 0)
    goto L1D; // [1250] 1265

    /** parser.e:4254						tok[T_SYM] = undef_type*/
    _2 = (object)SEQ_PTR(_tok_61657);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_61657 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _undef_type_61927;
    DeRef(_1);
    goto L1E; // [1262] 1275
L1D: 

    /** parser.e:4256						CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(37, _22209, 0);
L1E: 
    DeRef(_temptok_61925);
    _temptok_61925 = NOVALUE;
    goto L1F; // [1277] 1290
L18: 

    /** parser.e:4259					CompileErr(A_TYPE_IS_EXPECTED_HERE)*/
    RefDS(_22209);
    _49CompileErr(37, _22209, 0);
L1F: 
L16: 

    /** parser.e:4262			type_sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _type_sym_61654 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_61654)){
        _type_sym_61654 = (object)DBL_PTR(_type_sym_61654)->dbl;
    }

    /** parser.e:4263			tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4264			if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30658 = (object)*(((s1_ptr)_2)->base + 1);
    _30659 = find_from(_30658, _29ID_TOKS_12283, 1);
    _30658 = NOVALUE;
    if (_30659 != 0)
    goto L20; // [1321] 1439
    _30659 = NOVALUE;

    /** parser.e:4265				sequence tokcat = find_category(tok[T_ID])*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30661 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30661);
    _0 = _tokcat_61979;
    _tokcat_61979 = _62find_category(_30661);
    DeRef(_0);
    _30661 = NOVALUE;

    /** parser.e:4266				if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30663 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30663)) {
        _30664 = (_30663 != 0);
    }
    else {
        _30664 = binary_op(NOTEQ, _30663, 0);
    }
    _30663 = NOVALUE;
    if (IS_ATOM_INT(_30664)) {
        if (_30664 == 0) {
            goto L21; // [1350] 1413
        }
    }
    else {
        if (DBL_PTR(_30664)->dbl == 0.0) {
            goto L21; // [1350] 1413
        }
    }
    _2 = (object)SEQ_PTR(_tok_61657);
    _30666 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30666)){
        _30667 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30666)->dbl));
    }
    else{
        _30667 = (object)*(((s1_ptr)_2)->base + _30666);
    }
    if (IS_SEQUENCE(_30667)){
            _30668 = SEQ_PTR(_30667)->length;
    }
    else {
        _30668 = 1;
    }
    _30667 = NOVALUE;
    if (IS_ATOM_INT(_27S_NAME_20209)) {
        _30669 = (_30668 >= _27S_NAME_20209);
    }
    else {
        _30669 = binary_op(GREATEREQ, _30668, _27S_NAME_20209);
    }
    _30668 = NOVALUE;
    if (_30669 == 0) {
        DeRef(_30669);
        _30669 = NOVALUE;
        goto L21; // [1376] 1413
    }
    else {
        if (!IS_ATOM_INT(_30669) && DBL_PTR(_30669)->dbl == 0.0){
            DeRef(_30669);
            _30669 = NOVALUE;
            goto L21; // [1376] 1413
        }
        DeRef(_30669);
        _30669 = NOVALUE;
    }
    DeRef(_30669);
    _30669 = NOVALUE;

    /** parser.e:4267					CompileErr(FOUND_1_2_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30670 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30670)){
        _30671 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30670)->dbl));
    }
    else{
        _30671 = (object)*(((s1_ptr)_2)->base + _30670);
    }
    _2 = (object)SEQ_PTR(_30671);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _30672 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _30672 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _30671 = NOVALUE;
    Ref(_30672);
    RefDS(_tokcat_61979);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tokcat_61979;
    ((intptr_t *)_2)[2] = _30672;
    _30673 = MAKE_SEQ(_1);
    _30672 = NOVALUE;
    _49CompileErr(90, _30673, 0);
    _30673 = NOVALUE;
    goto L22; // [1410] 1438
L21: 

    /** parser.e:4269					CompileErr(FOUND_1_BUT_WAS_EXPECTING_A_PARAMETER_NAME_INSTEAD, {LexName(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30674 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30674);
    RefDS(_26621);
    _30675 = _45LexName(_30674, _26621);
    _30674 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30675;
    _30676 = MAKE_SEQ(_1);
    _30675 = NOVALUE;
    _49CompileErr(92, _30676, 0);
    _30676 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_61979);
    _tokcat_61979 = NOVALUE;

    /** parser.e:4272			sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30677 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30677);
    _sym_61655 = _43SetPrivateScope(_30677, _type_sym_61654, _43param_num_55414);
    _30677 = NOVALUE;
    if (!IS_ATOM_INT(_sym_61655)) {
        _1 = (object)(DBL_PTR(_sym_61655)->dbl);
        DeRefDS(_sym_61655);
        _sym_61655 = _1;
    }

    /** parser.e:4273			param_num += 1*/
    _43param_num_55414 = _43param_num_55414 + 1;

    /** parser.e:4275			if SymTab[last_link][S_NEXT] != sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30680 = (object)*(((s1_ptr)_2)->base + _last_link_61898);
    _2 = (object)SEQ_PTR(_30680);
    _30681 = (object)*(((s1_ptr)_2)->base + 2);
    _30680 = NOVALUE;
    if (IS_ATOM_INT(_30681)) {
        _30682 = (_30681 != _sym_61655);
    }
    else {
        _30682 = binary_op(NOTEQ, _30681, _sym_61655);
    }
    _30681 = NOVALUE;
    if (IS_ATOM_INT(_30682)) {
        if (_30682 == 0) {
            goto L23; // [1485] 1566
        }
    }
    else {
        if (DBL_PTR(_30682)->dbl == 0.0) {
            goto L23; // [1485] 1566
        }
    }
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30684 = (object)*(((s1_ptr)_2)->base + _last_link_61898);
    _2 = (object)SEQ_PTR(_30684);
    _30685 = (object)*(((s1_ptr)_2)->base + 2);
    _30684 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30685)){
        _30686 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30685)->dbl));
    }
    else{
        _30686 = (object)*(((s1_ptr)_2)->base + _30685);
    }
    _2 = (object)SEQ_PTR(_30686);
    _30687 = (object)*(((s1_ptr)_2)->base + 4);
    _30686 = NOVALUE;
    if (IS_ATOM_INT(_30687)) {
        _30688 = (_30687 == 9);
    }
    else {
        _30688 = binary_op(EQUALS, _30687, 9);
    }
    _30687 = NOVALUE;
    if (_30688 == 0) {
        DeRef(_30688);
        _30688 = NOVALUE;
        goto L23; // [1520] 1566
    }
    else {
        if (!IS_ATOM_INT(_30688) && DBL_PTR(_30688)->dbl == 0.0){
            DeRef(_30688);
            _30688 = NOVALUE;
            goto L23; // [1520] 1566
        }
        DeRef(_30688);
        _30688 = NOVALUE;
    }
    DeRef(_30688);
    _30688 = NOVALUE;

    /** parser.e:4278				SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30689 = (object)*(((s1_ptr)_2)->base + _last_link_61898);
    _2 = (object)SEQ_PTR(_30689);
    _30690 = (object)*(((s1_ptr)_2)->base + 2);
    _30689 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30690))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_30690)->dbl));
    else
    _3 = (object)(_30690 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30691 = NOVALUE;

    /** parser.e:4279				SymTab[last_link][S_NEXT] = sym*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_last_link_61898 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_61655;
    DeRef(_1);
    _30693 = NOVALUE;
L23: 

    /** parser.e:4282			last_link = sym*/
    _last_link_61898 = _sym_61655;

    /** parser.e:4284			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L24; // [1577] 1600
    }
    else{
    }

    /** parser.e:4285				SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61655 + ((s1_ptr)_2)->base);
    _30697 = _43CompileType(_type_sym_61654);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30697;
    if( _1 != _30697 ){
        DeRef(_1);
    }
    _30697 = NOVALUE;
    _30695 = NOVALUE;
L24: 

    /** parser.e:4289			tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4290			if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30699 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30699, 3)){
        _30699 = NOVALUE;
        goto L25; // [1615] 1697
    }
    _30699 = NOVALUE;

    /** parser.e:4291				start_recording()*/
    _43start_recording();

    /** parser.e:4292				Expr()*/
    _43Expr();

    /** parser.e:4293				SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_61655 + ((s1_ptr)_2)->base);
    _30703 = _43restore_parser();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30703;
    if( _1 != _30703 ){
        DeRef(_1);
    }
    _30703 = NOVALUE;
    _30701 = NOVALUE;

    /** parser.e:4294				if Pop() then end if -- don't leak the default argument*/
    _30704 = _45Pop();
    if (_30704 == 0) {
        DeRef(_30704);
        _30704 = NOVALUE;
        goto L26; // [1650] 1654
    }
    else {
        if (!IS_ATOM_INT(_30704) && DBL_PTR(_30704)->dbl == 0.0){
            DeRef(_30704);
            _30704 = NOVALUE;
            goto L26; // [1650] 1654
        }
        DeRef(_30704);
        _30704 = NOVALUE;
    }
    DeRef(_30704);
    _30704 = NOVALUE;
L26: 

    /** parser.e:4295				tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4296				if first_def_arg = 0 then*/
    if (_first_def_arg_61659 != 0)
    goto L27; // [1661] 1673

    /** parser.e:4297					first_def_arg = param_num*/
    _first_def_arg_61659 = _43param_num_55414;
L27: 

    /** parser.e:4299				previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _27previous_op_20670 = -1;

    /** parser.e:4300				if start_def = 0 then*/
    if (_start_def_61896 != 0)
    goto L28; // [1682] 1754

    /** parser.e:4301					start_def = param_num*/
    _start_def_61896 = _43param_num_55414;
    goto L28; // [1694] 1754
L25: 

    /** parser.e:4304				last_nda = param_num*/
    _last_nda_61895 = _43param_num_55414;

    /** parser.e:4305				if start_def then*/
    if (_start_def_61896 == 0)
    {
        goto L29; // [1706] 1753
    }
    else{
    }

    /** parser.e:4306					if start_def = param_num-1 then*/
    _30708 = _43param_num_55414 - 1;
    if ((object)((uintptr_t)_30708 +(uintptr_t) HIGH_BITS) >= 0){
        _30708 = NewDouble((eudouble)_30708);
    }
    if (binary_op_a(NOTEQ, _start_def_61896, _30708)){
        DeRef(_30708);
        _30708 = NOVALUE;
        goto L2A; // [1717] 1730
    }
    DeRef(_30708);
    _30708 = NOVALUE;

    /** parser.e:4307						middle_def_args &= start_def*/
    Append(&_middle_def_args_61894, _middle_def_args_61894, _start_def_61896);
    goto L2B; // [1727] 1747
L2A: 

    /** parser.e:4309						middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30711 = _43param_num_55414 - 1;
    if ((object)((uintptr_t)_30711 +(uintptr_t) HIGH_BITS) >= 0){
        _30711 = NewDouble((eudouble)_30711);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _start_def_61896;
    ((intptr_t *)_2)[2] = _30711;
    _30712 = MAKE_SEQ(_1);
    _30711 = NOVALUE;
    RefDS(_30712);
    Append(&_middle_def_args_61894, _middle_def_args_61894, _30712);
    DeRefDS(_30712);
    _30712 = NOVALUE;
L2B: 

    /** parser.e:4311					start_def = 0*/
    _start_def_61896 = 0;
L29: 
L28: 

    /** parser.e:4314			if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30714 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30714, -30)){
        _30714 = NOVALUE;
        goto L2C; // [1764] 1800
    }
    _30714 = NOVALUE;

    /** parser.e:4315				tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4316				if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30717 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30717, -27)){
        _30717 = NOVALUE;
        goto L14; // [1783] 1035
    }
    _30717 = NOVALUE;

    /** parser.e:4317					CompileErr(EXPECTED_TO_SEE_A_PARAMETER_DECLARATION_NOT)*/
    RefDS(_22209);
    _49CompileErr(85, _22209, 0);
    goto L14; // [1797] 1035
L2C: 

    /** parser.e:4319			elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30719 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30719, -27)){
        _30719 = NOVALUE;
        goto L14; // [1810] 1035
    }
    _30719 = NOVALUE;

    /** parser.e:4320				CompileErr(BADLYFORMED_LIST_OF_PARAMETERS__EXPECTED__OR)*/
    RefDS(_22209);
    _49CompileErr(41, _22209, 0);

    /** parser.e:4322		end while*/
    goto L14; // [1827] 1035
L15: 

    /** parser.e:4323		Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_22209);
    DeRef(_27Code_20660);
    _27Code_20660 = _22209;

    /** parser.e:4325		SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _43param_num_55414;
    DeRef(_1);
    _30721 = NOVALUE;

    /** parser.e:4326		SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _first_def_arg_61659;
    ((intptr_t*)_2)[2] = _last_nda_61895;
    RefDS(_middle_def_args_61894);
    ((intptr_t*)_2)[3] = _middle_def_args_61894;
    _30725 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30725;
    if( _1 != _30725 ){
        DeRef(_1);
    }
    _30725 = NOVALUE;
    _30723 = NOVALUE;

    /** parser.e:4327		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L2D; // [1879] 1913
    }
    else{
    }

    /** parser.e:4328			if param_num > max_params then*/
    if (_43param_num_55414 <= _45max_params_51419)
    goto L2E; // [1888] 1902

    /** parser.e:4329				max_params = param_num*/
    _45max_params_51419 = _43param_num_55414;
L2E: 

    /** parser.e:4331			num_routines += 1*/
    _27num_routines_20580 = _27num_routines_20580 + 1;
L2D: 

    /** parser.e:4333		if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30728 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30728);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _30729 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _30729 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _30728 = NOVALUE;
    if (IS_ATOM_INT(_30729)) {
        _30730 = (_30729 == 504);
    }
    else {
        _30730 = binary_op(EQUALS, _30729, 504);
    }
    _30729 = NOVALUE;
    if (IS_ATOM_INT(_30730)) {
        if (_30730 == 0) {
            goto L2F; // [1933] 1957
        }
    }
    else {
        if (DBL_PTR(_30730)->dbl == 0.0) {
            goto L2F; // [1933] 1957
        }
    }
    _30732 = (_43param_num_55414 != 1);
    if (_30732 == 0)
    {
        DeRef(_30732);
        _30732 = NOVALUE;
        goto L2F; // [1944] 1957
    }
    else{
        DeRef(_30732);
        _30732 = NOVALUE;
    }

    /** parser.e:4334			CompileErr(TYPES_MUST_HAVE_EXACTLY_ONE_PARAMETER)*/
    RefDS(_22209);
    _49CompileErr(148, _22209, 0);
L2F: 

    /** parser.e:4337		include_routine()*/
    _50include_routine();

    /** parser.e:4340		sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30733 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30733);
    _sym_61655 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61655)){
        _sym_61655 = (object)DBL_PTR(_sym_61655)->dbl;
    }
    _30733 = NOVALUE;

    /** parser.e:4341		for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30735 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30735);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _30736 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _30736 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _30735 = NOVALUE;
    {
        object _i_62138;
        _i_62138 = 1;
L30: 
        if (binary_op_a(GREATER, _i_62138, _30736)){
            goto L31; // [1991] 2070
        }

        /** parser.e:4342			while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30737 = (object)*(((s1_ptr)_2)->base + _sym_61655);
        _2 = (object)SEQ_PTR(_30737);
        _30738 = (object)*(((s1_ptr)_2)->base + 4);
        _30737 = NOVALUE;
        if (binary_op_a(EQUALS, _30738, 3)){
            _30738 = NOVALUE;
            goto L33; // [2017] 2042
        }
        _30738 = NOVALUE;

        /** parser.e:4343				sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30740 = (object)*(((s1_ptr)_2)->base + _sym_61655);
        _2 = (object)SEQ_PTR(_30740);
        _sym_61655 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61655)){
            _sym_61655 = (object)DBL_PTR(_sym_61655)->dbl;
        }
        _30740 = NOVALUE;

        /** parser.e:4344			end while*/
        goto L32; // [2039] 2003
L33: 

        /** parser.e:4345			TypeCheck(sym)*/
        _43TypeCheck(_sym_61655);

        /** parser.e:4346			sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30742 = (object)*(((s1_ptr)_2)->base + _sym_61655);
        _2 = (object)SEQ_PTR(_30742);
        _sym_61655 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61655)){
            _sym_61655 = (object)DBL_PTR(_sym_61655)->dbl;
        }
        _30742 = NOVALUE;

        /** parser.e:4347		end for*/
        _0 = _i_62138;
        if (IS_ATOM_INT(_i_62138)) {
            _i_62138 = _i_62138 + 1;
            if ((object)((uintptr_t)_i_62138 +(uintptr_t) HIGH_BITS) >= 0){
                _i_62138 = NewDouble((eudouble)_i_62138);
            }
        }
        else {
            _i_62138 = binary_op_a(PLUS, _i_62138, 1);
        }
        DeRef(_0);
        goto L30; // [2065] 1998
L31: 
        ;
        DeRef(_i_62138);
    }

    /** parser.e:4352		tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4353		while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (object)SEQ_PTR(_tok_61657);
    _30745 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30745)) {
        _30746 = (_30745 == 504);
    }
    else {
        _30746 = binary_op(EQUALS, _30745, 504);
    }
    _30745 = NOVALUE;
    if (IS_ATOM_INT(_30746)) {
        if (_30746 != 0) {
            goto L35; // [2092] 2113
        }
    }
    else {
        if (DBL_PTR(_30746)->dbl != 0.0) {
            goto L35; // [2092] 2113
        }
    }
    _2 = (object)SEQ_PTR(_tok_61657);
    _30748 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30748)) {
        _30749 = (_30748 == 522);
    }
    else {
        _30749 = binary_op(EQUALS, _30748, 522);
    }
    _30748 = NOVALUE;
    if (_30749 <= 0) {
        if (_30749 == 0) {
            DeRef(_30749);
            _30749 = NOVALUE;
            goto L36; // [2109] 2134
        }
        else {
            if (!IS_ATOM_INT(_30749) && DBL_PTR(_30749)->dbl == 0.0){
                DeRef(_30749);
                _30749 = NOVALUE;
                goto L36; // [2109] 2134
            }
            DeRef(_30749);
            _30749 = NOVALUE;
        }
    }
    DeRef(_30749);
    _30749 = NOVALUE;
L35: 

    /** parser.e:4354			Private_declaration(tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_tok_61657);
    _30750 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_30750);
    _43Private_declaration(_30750);
    _30750 = NOVALUE;

    /** parser.e:4355			tok = next_token()*/
    _0 = _tok_61657;
    _tok_61657 = _43next_token();
    DeRef(_0);

    /** parser.e:4356		end while*/
    goto L34; // [2131] 2080
L36: 

    /** parser.e:4358		if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L37; // [2138] 2241

    /** parser.e:4359			if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L38; // [2145] 2240
    }
    else{
    }

    /** parser.e:4361				emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:4362				emit_addr(p)*/
    _45emit_addr(_p_61653);

    /** parser.e:4364				sym = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30753 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30753);
    _sym_61655 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61655)){
        _sym_61655 = (object)DBL_PTR(_sym_61655)->dbl;
    }
    _30753 = NOVALUE;

    /** parser.e:4365				for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _30755 = (object)*(((s1_ptr)_2)->base + _p_61653);
    _2 = (object)SEQ_PTR(_30755);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _30756 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _30756 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _30755 = NOVALUE;
    {
        object _i_62185;
        _i_62185 = 1;
L39: 
        if (binary_op_a(GREATER, _i_62185, _30756)){
            goto L3A; // [2190] 2232
        }

        /** parser.e:4366					emit_op(DISPLAY_VAR)*/
        _45emit_op(87);

        /** parser.e:4367					emit_addr(sym)*/
        _45emit_addr(_sym_61655);

        /** parser.e:4368					sym = SymTab[sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_28SymTab_11572);
        _30757 = (object)*(((s1_ptr)_2)->base + _sym_61655);
        _2 = (object)SEQ_PTR(_30757);
        _sym_61655 = (object)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_61655)){
            _sym_61655 = (object)DBL_PTR(_sym_61655)->dbl;
        }
        _30757 = NOVALUE;

        /** parser.e:4369				end for*/
        _0 = _i_62185;
        if (IS_ATOM_INT(_i_62185)) {
            _i_62185 = _i_62185 + 1;
            if ((object)((uintptr_t)_i_62185 +(uintptr_t) HIGH_BITS) >= 0){
                _i_62185 = NewDouble((eudouble)_i_62185);
            }
        }
        else {
            _i_62185 = binary_op_a(PLUS, _i_62185, 1);
        }
        DeRef(_0);
        goto L39; // [2227] 2197
L3A: 
        ;
        DeRef(_i_62185);
    }

    /** parser.e:4371				emit_op(UPDATE_GLOBALS)*/
    _45emit_op(89);
L38: 
L37: 

    /** parser.e:4374		putback(tok)*/
    Ref(_tok_61657);
    _43putback(_tok_61657);

    /** parser.e:4377		FuncReturn = FALSE*/
    _43FuncReturn_55413 = _9FALSE_439;

    /** parser.e:4378		if type_enum then*/
    if (_type_enum_61661 == 0)
    {
        goto L3B; // [2257] 2426
    }
    else{
    }

    /** parser.e:4380			stmt_nest += 1*/
    _43stmt_nest_55437 = _43stmt_nest_55437 + 1;

    /** parser.e:4381			tok_match(RETURN)*/
    _43tok_match(413, 0);

    /** parser.e:4382			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -27;
    ((intptr_t *)_2)[2] = 0;
    _30760 = MAKE_SEQ(_1);
    _43putback(_30760);
    _30760 = NOVALUE;

    /** parser.e:4383			putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_61662);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100;
    ((intptr_t *)_2)[2] = _seq_sym_61662;
    _30761 = MAKE_SEQ(_1);
    _43putback(_30761);
    _30761 = NOVALUE;

    /** parser.e:4384			putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -30;
    ((intptr_t *)_2)[2] = 0;
    _30762 = MAKE_SEQ(_1);
    _43putback(_30762);
    _30762 = NOVALUE;

    /** parser.e:4385			putback(i1_sym)*/
    Ref(_i1_sym_61663);
    _43putback(_i1_sym_61663);

    /** parser.e:4386			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -26;
    ((intptr_t *)_2)[2] = 0;
    _30763 = MAKE_SEQ(_1);
    _43putback(_30763);
    _30763 = NOVALUE;

    /** parser.e:4387			putback(keyfind("find",-1))*/
    RefDS(_30764);
    DeRef(_31963);
    _31963 = _30764;
    _31964 = _53hashfn(_31963);
    _31963 = NOVALUE;
    RefDS(_30764);
    _30765 = _53keyfind(_30764, -1, _27current_file_no_20571, 0, _31964);
    _31964 = NOVALUE;
    _43putback(_30765);
    _30765 = NOVALUE;

    /** parser.e:4388			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L3C; // [2355] 2381

    /** parser.e:4389				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L3D; // [2362] 2380
    }
    else{
    }

    /** parser.e:4390					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:4391					emit_addr(CurrentSub)*/
    _45emit_addr(_27CurrentSub_20579);
L3D: 
L3C: 

    /** parser.e:4394			Expr()*/
    _43Expr();

    /** parser.e:4395			FuncReturn = TRUE*/
    _43FuncReturn_55413 = _9TRUE_441;

    /** parser.e:4396			emit_op(RETURNF)*/
    _45emit_op(28);

    /** parser.e:4397			flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:4398			stmt_nest -= 1*/
    _43stmt_nest_55437 = _43stmt_nest_55437 - 1;

    /** parser.e:4399			InitDelete()*/
    _43InitDelete();

    /** parser.e:4400			flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);
    goto L3E; // [2423] 2439
L3B: 

    /** parser.e:4402			Statement_list()*/
    _43Statement_list();

    /** parser.e:4404			tok_match(END)*/
    _43tok_match(402, 0);
L3E: 

    /** parser.e:4408		tok_match(prog_type, END)*/
    _43tok_match(_prog_type_61647, 402);

    /** parser.e:4410		if prog_type != PROCEDURE then*/
    if (_prog_type_61647 == 405)
    goto L3F; // [2451] 2503

    /** parser.e:4411			if not FuncReturn then*/
    if (_43FuncReturn_55413 != 0)
    goto L40; // [2459] 2493

    /** parser.e:4412				if prog_type = FUNCTION then*/
    if (_prog_type_61647 != 406)
    goto L41; // [2466] 2482

    /** parser.e:4413					CompileErr(NO_VALUE_RETURNED_FROM_FUNCTION)*/
    RefDS(_22209);
    _49CompileErr(120, _22209, 0);
    goto L42; // [2479] 2492
L41: 

    /** parser.e:4415					CompileErr(TYPE_MUST_RETURN_TRUE__FALSE_VALUE)*/
    RefDS(_22209);
    _49CompileErr(149, _22209, 0);
L42: 
L40: 

    /** parser.e:4418			emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _45emit_op(43);
    goto L43; // [2500] 2563
L3F: 

    /** parser.e:4421			StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4422			if not TRANSLATE then*/
    if (_27TRANSLATE_20179 != 0)
    goto L44; // [2516] 2540

    /** parser.e:4423				if OpTrace then*/
    if (_27OpTrace_20641 == 0)
    {
        goto L45; // [2523] 2539
    }
    else{
    }

    /** parser.e:4424					emit_op(ERASE_PRIVATE_NAMES)*/
    _45emit_op(88);

    /** parser.e:4425					emit_addr(p)*/
    _45emit_addr(_p_61653);
L45: 
L44: 

    /** parser.e:4428			emit_op(RETURNP)*/
    _45emit_op(29);

    /** parser.e:4429			if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L46; // [2551] 2562
    }
    else{
    }

    /** parser.e:4430				emit_op(BADRETURNF) -- just to mark end of procedure*/
    _45emit_op(43);
L46: 
L43: 

    /** parser.e:4433		Drop_block( pt )*/
    _64Drop_block(_pt_61651);

    /** parser.e:4435		if Strict_Override > 0 then*/
    if (_27Strict_Override_20638 <= 0)
    goto L47; // [2572] 2587

    /** parser.e:4436			Strict_Override -= 1	-- Reset at the end of each routine.*/
    _27Strict_Override_20638 = _27Strict_Override_20638 - 1;
L47: 

    /** parser.e:4439		SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    _30776 = _53temps_allocated_47715 + _43param_num_55414;
    if ((object)((uintptr_t)_30776 + (uintptr_t)HIGH_BITS) >= 0){
        _30776 = NewDouble((eudouble)_30776);
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269)){
        _30777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    }
    else{
        _30777 = (object)*(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    }
    _30774 = NOVALUE;
    if (IS_ATOM_INT(_30777) && IS_ATOM_INT(_30776)) {
        _30778 = _30777 + _30776;
        if ((object)((uintptr_t)_30778 + (uintptr_t)HIGH_BITS) >= 0){
            _30778 = NewDouble((eudouble)_30778);
        }
    }
    else {
        _30778 = binary_op(PLUS, _30777, _30776);
    }
    _30777 = NOVALUE;
    DeRef(_30776);
    _30776 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_STACK_SPACE_20269))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_STACK_SPACE_20269)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_STACK_SPACE_20269);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30778;
    if( _1 != _30778 ){
        DeRef(_1);
    }
    _30778 = NOVALUE;
    _30774 = NOVALUE;

    /** parser.e:4440		if temps_allocated + param_num > max_stack_per_call then*/
    _30779 = _53temps_allocated_47715 + _43param_num_55414;
    if ((object)((uintptr_t)_30779 + (uintptr_t)HIGH_BITS) >= 0){
        _30779 = NewDouble((eudouble)_30779);
    }
    if (binary_op_a(LESSEQ, _30779, _27max_stack_per_call_20671)){
        DeRef(_30779);
        _30779 = NOVALUE;
        goto L48; // [2630] 2647
    }
    DeRef(_30779);
    _30779 = NOVALUE;

    /** parser.e:4441			max_stack_per_call = temps_allocated + param_num*/
    _27max_stack_per_call_20671 = _53temps_allocated_47715 + _43param_num_55414;
L48: 

    /** parser.e:4443		param_num = -1*/
    _43param_num_55414 = -1;

    /** parser.e:4445		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:4446		check_inline( p )*/
    _66check_inline(_p_61653);

    /** parser.e:4447		param_num = -1*/
    _43param_num_55414 = -1;

    /** parser.e:4448		EnterTopLevel()*/
    _43EnterTopLevel(1);

    /** parser.e:4451		if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_61664)){
            _30782 = SEQ_PTR(_enum_syms_61664)->length;
    }
    else {
        _30782 = 1;
    }
    if (_30782 == 0)
    {
        _30782 = NOVALUE;
        goto L49; // [2676] 2763
    }
    else{
        _30782 = NOVALUE;
    }

    /** parser.e:4452			SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_61653 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_61664)){
            _30785 = SEQ_PTR(_enum_syms_61664)->length;
    }
    else {
        _30785 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61664);
    _30786 = (object)*(((s1_ptr)_2)->base + _30785);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30786)){
        _30787 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30786)->dbl));
    }
    else{
        _30787 = (object)*(((s1_ptr)_2)->base + _30786);
    }
    _2 = (object)SEQ_PTR(_30787);
    _30788 = (object)*(((s1_ptr)_2)->base + 2);
    _30787 = NOVALUE;
    Ref(_30788);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30788;
    if( _1 != _30788 ){
        DeRef(_1);
    }
    _30788 = NOVALUE;
    _30783 = NOVALUE;

    /** parser.e:4453			SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_47193 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_enum_syms_61664);
    _30791 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30791);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30791;
    if( _1 != _30791 ){
        DeRef(_1);
    }
    _30791 = NOVALUE;
    _30789 = NOVALUE;

    /** parser.e:4454			last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_61664)){
            _30792 = SEQ_PTR(_enum_syms_61664)->length;
    }
    else {
        _30792 = 1;
    }
    _2 = (object)SEQ_PTR(_enum_syms_61664);
    _53last_sym_47193 = (object)*(((s1_ptr)_2)->base + _30792);
    if (!IS_ATOM_INT(_53last_sym_47193)){
        _53last_sym_47193 = (object)DBL_PTR(_53last_sym_47193)->dbl;
    }

    /** parser.e:4455			SymTab[last_sym][S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_53last_sym_47193 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0;
    DeRef(_1);
    _30794 = NOVALUE;
L49: 

    /** parser.e:4457	end procedure*/
    DeRef(_tok_61657);
    DeRef(_prog_name_61658);
    DeRef(_seq_sym_61662);
    DeRef(_i1_sym_61663);
    DeRef(_enum_syms_61664);
    DeRef(_middle_def_args_61894);
    DeRef(_30746);
    _30746 = NOVALUE;
    DeRef(_30664);
    _30664 = NOVALUE;
    DeRef(_30631);
    _30631 = NOVALUE;
    DeRef(_30642);
    _30642 = NOVALUE;
    _30598 = NOVALUE;
    _30756 = NOVALUE;
    _30602 = NOVALUE;
    DeRef(_30576);
    _30576 = NOVALUE;
    DeRef(_30730);
    _30730 = NOVALUE;
    _30690 = NOVALUE;
    _30685 = NOVALUE;
    _30667 = NOVALUE;
    _30786 = NOVALUE;
    _30666 = NOVALUE;
    DeRef(_30636);
    _30636 = NOVALUE;
    DeRef(_30682);
    _30682 = NOVALUE;
    _30736 = NOVALUE;
    _30670 = NOVALUE;
    _30648 = NOVALUE;
    return;
    ;
}


void _43InitGlobals()
{
    object _30813 = NOVALUE;
    object _30811 = NOVALUE;
    object _30810 = NOVALUE;
    object _30809 = NOVALUE;
    object _30808 = NOVALUE;
    object _30807 = NOVALUE;
    object _30806 = NOVALUE;
    object _30804 = NOVALUE;
    object _30803 = NOVALUE;
    object _30802 = NOVALUE;
    object _30801 = NOVALUE;
    object _30799 = NOVALUE;
    object _30798 = NOVALUE;
    object _30797 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4461		ResetTP()*/
    _61ResetTP();

    /** parser.e:4462		OpTypeCheck = TRUE*/
    _27OpTypeCheck_20642 = _9TRUE_441;

    /** parser.e:4464		OpDefines &= {*/
    _30797 = _40version_major();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30797;
    _30798 = MAKE_SEQ(_1);
    _30797 = NOVALUE;
    _30799 = EPrintf(-9999999, _30796, _30798);
    DeRefDS(_30798);
    _30798 = NOVALUE;
    _30801 = _40version_major();
    _30802 = _40version_minor();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _30801;
    ((intptr_t *)_2)[2] = _30802;
    _30803 = MAKE_SEQ(_1);
    _30802 = NOVALUE;
    _30801 = NOVALUE;
    _30804 = EPrintf(-9999999, _30800, _30803);
    DeRefDS(_30803);
    _30803 = NOVALUE;
    _30806 = _40version_major();
    _30807 = _40version_minor();
    _30808 = _40version_patch();
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30806;
    ((intptr_t*)_2)[2] = _30807;
    ((intptr_t*)_2)[3] = _30808;
    _30809 = MAKE_SEQ(_1);
    _30808 = NOVALUE;
    _30807 = NOVALUE;
    _30806 = NOVALUE;
    _30810 = EPrintf(-9999999, _30805, _30809);
    DeRefDS(_30809);
    _30809 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _30799;
    ((intptr_t*)_2)[2] = _30804;
    ((intptr_t*)_2)[3] = _30810;
    _30811 = MAKE_SEQ(_1);
    _30810 = NOVALUE;
    _30804 = NOVALUE;
    _30799 = NOVALUE;
    Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _30811);
    DeRefDS(_30811);
    _30811 = NOVALUE;

    /** parser.e:4470		OpDefines &= GetPlatformDefines()*/
    _30813 = _44GetPlatformDefines(0);
    if (IS_SEQUENCE(_27OpDefines_20645) && IS_ATOM(_30813)) {
        Ref(_30813);
        Append(&_27OpDefines_20645, _27OpDefines_20645, _30813);
    }
    else if (IS_ATOM(_27OpDefines_20645) && IS_SEQUENCE(_30813)) {
    }
    else {
        Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _30813);
    }
    DeRef(_30813);
    _30813 = NOVALUE;

    /** parser.e:4472		if repl then*/

    /** parser.e:4476			OpInline = DEFAULT_INLINE*/
    _27OpInline_20646 = 30;

    /** parser.e:4478		OpIndirectInclude = 1*/
    _27OpIndirectInclude_20647 = 1;

    /** parser.e:4479	end procedure*/
    return;
    ;
}


void _43not_supported_compile(object _feature_62355)
{
    object _30815 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4483		CompileErr(MSG_1_IS_NOT_SUPPORTED_IN_EUPHORIA_FOR_2, {feature, version_name})*/
    RefDS(_27version_name_20193);
    RefDS(_feature_62355);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _feature_62355;
    ((intptr_t *)_2)[2] = _27version_name_20193;
    _30815 = MAKE_SEQ(_1);
    _49CompileErr(5, _30815, 0);
    _30815 = NOVALUE;

    /** parser.e:4484	end procedure*/
    DeRefDSi(_feature_62355);
    return;
    ;
}


void _43SetWith(object _on_off_62362)
{
    object _option_62363 = NOVALUE;
    object _idx_62364 = NOVALUE;
    object _reset_flags_62365 = NOVALUE;
    object _tok_62417 = NOVALUE;
    object _good_sofar_62467 = NOVALUE;
    object _tok_62470 = NOVALUE;
    object _warning_extra_62472 = NOVALUE;
    object _endlist_62565 = NOVALUE;
    object _tok_62714 = NOVALUE;
    object _30962 = NOVALUE;
    object _30961 = NOVALUE;
    object _30960 = NOVALUE;
    object _30959 = NOVALUE;
    object _30958 = NOVALUE;
    object _30955 = NOVALUE;
    object _30954 = NOVALUE;
    object _30953 = NOVALUE;
    object _30951 = NOVALUE;
    object _30949 = NOVALUE;
    object _30948 = NOVALUE;
    object _30947 = NOVALUE;
    object _30944 = NOVALUE;
    object _30942 = NOVALUE;
    object _30941 = NOVALUE;
    object _30940 = NOVALUE;
    object _30939 = NOVALUE;
    object _30938 = NOVALUE;
    object _30934 = NOVALUE;
    object _30932 = NOVALUE;
    object _30930 = NOVALUE;
    object _30926 = NOVALUE;
    object _30921 = NOVALUE;
    object _30920 = NOVALUE;
    object _30915 = NOVALUE;
    object _30914 = NOVALUE;
    object _30913 = NOVALUE;
    object _30912 = NOVALUE;
    object _30911 = NOVALUE;
    object _30910 = NOVALUE;
    object _30909 = NOVALUE;
    object _30908 = NOVALUE;
    object _30907 = NOVALUE;
    object _30906 = NOVALUE;
    object _30904 = NOVALUE;
    object _30903 = NOVALUE;
    object _30901 = NOVALUE;
    object _30900 = NOVALUE;
    object _30899 = NOVALUE;
    object _30897 = NOVALUE;
    object _30896 = NOVALUE;
    object _30894 = NOVALUE;
    object _30891 = NOVALUE;
    object _30889 = NOVALUE;
    object _30886 = NOVALUE;
    object _30885 = NOVALUE;
    object _30884 = NOVALUE;
    object _30883 = NOVALUE;
    object _30876 = NOVALUE;
    object _30875 = NOVALUE;
    object _30873 = NOVALUE;
    object _30870 = NOVALUE;
    object _30869 = NOVALUE;
    object _30867 = NOVALUE;
    object _30866 = NOVALUE;
    object _30865 = NOVALUE;
    object _30864 = NOVALUE;
    object _30863 = NOVALUE;
    object _30862 = NOVALUE;
    object _30859 = NOVALUE;
    object _30858 = NOVALUE;
    object _30857 = NOVALUE;
    object _30856 = NOVALUE;
    object _30855 = NOVALUE;
    object _30854 = NOVALUE;
    object _30851 = NOVALUE;
    object _30850 = NOVALUE;
    object _30849 = NOVALUE;
    object _30847 = NOVALUE;
    object _30844 = NOVALUE;
    object _30842 = NOVALUE;
    object _30841 = NOVALUE;
    object _30839 = NOVALUE;
    object _30838 = NOVALUE;
    object _30837 = NOVALUE;
    object _30836 = NOVALUE;
    object _30835 = NOVALUE;
    object _30834 = NOVALUE;
    object _30832 = NOVALUE;
    object _30829 = NOVALUE;
    object _30828 = NOVALUE;
    object _30827 = NOVALUE;
    object _30826 = NOVALUE;
    object _30824 = NOVALUE;
    object _30823 = NOVALUE;
    object _30822 = NOVALUE;
    object _30821 = NOVALUE;
    object _30819 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4490		integer reset_flags = 1*/
    _reset_flags_62365 = 1;

    /** parser.e:4493		option = StringToken("&+=")*/
    RefDS(_30816);
    _0 = _option_62363;
    _option_62363 = _61StringToken(_30816);
    DeRef(_0);

    /** parser.e:4495		if equal(option, "type_check") then*/
    if (_option_62363 == _30818)
    _30819 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30818))
    _30819 = 0;
    else
    _30819 = (compare(_option_62363, _30818) == 0);
    if (_30819 == 0)
    {
        _30819 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30819 = NOVALUE;
    }

    /** parser.e:4496			OpTypeCheck = on_off*/
    _27OpTypeCheck_20642 = _on_off_62362;
    goto L2; // [32] 1546
L1: 

    /** parser.e:4498		elsif equal(option, "profile") then*/
    if (_option_62363 == _30820)
    _30821 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30820))
    _30821 = 0;
    else
    _30821 = (compare(_option_62363, _30820) == 0);
    if (_30821 == 0)
    {
        _30821 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30821 = NOVALUE;
    }

    /** parser.e:4499			if not TRANSLATE and not BIND then*/
    _30822 = (_27TRANSLATE_20179 == 0);
    if (_30822 == 0) {
        goto L2; // [51] 1546
    }
    _30824 = (_27BIND_20182 == 0);
    if (_30824 == 0)
    {
        DeRef(_30824);
        _30824 = NOVALUE;
        goto L2; // [61] 1546
    }
    else{
        DeRef(_30824);
        _30824 = NOVALUE;
    }

    /** parser.e:4500				OpProfileStatement = on_off*/
    _27OpProfileStatement_20643 = _on_off_62362;

    /** parser.e:4501				if OpProfileStatement then*/
    if (_27OpProfileStatement_20643 == 0)
    {
        goto L2; // [75] 1546
    }
    else{
    }

    /** parser.e:4502					if AnyTimeProfile then*/
    if (_28AnyTimeProfile_11595 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** parser.e:4503						Warning(224, mixed_profile_warning_flag)*/
    RefDS(_22209);
    _49Warning(224, 1024, _22209);

    /** parser.e:4504						OpProfileStatement = FALSE*/
    _27OpProfileStatement_20643 = _9FALSE_439;
    goto L2; // [103] 1546
L4: 

    /** parser.e:4506						AnyStatementProfile = TRUE*/
    _28AnyStatementProfile_11596 = _9TRUE_441;
    goto L2; // [118] 1546
L3: 

    /** parser.e:4511		elsif equal(option, "profile_time") then*/
    if (_option_62363 == _30825)
    _30826 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30825))
    _30826 = 0;
    else
    _30826 = (compare(_option_62363, _30825) == 0);
    if (_30826 == 0)
    {
        _30826 = NOVALUE;
        goto L5; // [127] 364
    }
    else{
        _30826 = NOVALUE;
    }

    /** parser.e:4512			if not TRANSLATE and not BIND then*/
    _30827 = (_27TRANSLATE_20179 == 0);
    if (_30827 == 0) {
        goto L2; // [137] 1546
    }
    _30829 = (_27BIND_20182 == 0);
    if (_30829 == 0)
    {
        DeRef(_30829);
        _30829 = NOVALUE;
        goto L2; // [147] 1546
    }
    else{
        DeRef(_30829);
        _30829 = NOVALUE;
    }

    /** parser.e:4513				if not IWINDOWS then*/
    if (_44IWINDOWS_20714 != 0)
    goto L6; // [154] 169

    /** parser.e:4514					if on_off then*/
    if (_on_off_62362 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** parser.e:4515						not_supported_compile("profile_time")*/
    RefDS(_30825);
    _43not_supported_compile(_30825);
L7: 
L6: 

    /** parser.e:4518				OpProfileTime = on_off*/
    _27OpProfileTime_20644 = _on_off_62362;

    /** parser.e:4519				if OpProfileTime then*/
    if (_27OpProfileTime_20644 == 0)
    {
        goto L8; // [180] 358
    }
    else{
    }

    /** parser.e:4520					if AnyStatementProfile then*/
    if (_28AnyStatementProfile_11596 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** parser.e:4521						Warning(224,mixed_profile_warning_flag)*/
    RefDS(_22209);
    _49Warning(224, 1024, _22209);

    /** parser.e:4522						OpProfileTime = FALSE*/
    _27OpProfileTime_20644 = _9FALSE_439;
L9: 

    /** parser.e:4524					token tok = next_token()*/
    _0 = _tok_62417;
    _tok_62417 = _43next_token();
    DeRef(_0);

    /** parser.e:4525					if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62417);
    _30832 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30832, 502)){
        _30832 = NOVALUE;
        goto LA; // [224] 319
    }
    _30832 = NOVALUE;

    /** parser.e:4526						if is_integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_tok_62417);
    _30834 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30834)){
        _30835 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30834)->dbl));
    }
    else{
        _30835 = (object)*(((s1_ptr)_2)->base + _30834);
    }
    _2 = (object)SEQ_PTR(_30835);
    _30836 = (object)*(((s1_ptr)_2)->base + 1);
    _30835 = NOVALUE;
    Ref(_30836);
    _30837 = _27is_integer(_30836);
    _30836 = NOVALUE;
    if (_30837 == 0) {
        DeRef(_30837);
        _30837 = NOVALUE;
        goto LB; // [252] 280
    }
    else {
        if (!IS_ATOM_INT(_30837) && DBL_PTR(_30837)->dbl == 0.0){
            DeRef(_30837);
            _30837 = NOVALUE;
            goto LB; // [252] 280
        }
        DeRef(_30837);
        _30837 = NOVALUE;
    }
    DeRef(_30837);
    _30837 = NOVALUE;

    /** parser.e:4527							sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62417);
    _30838 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30838)){
        _30839 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30838)->dbl));
    }
    else{
        _30839 = (object)*(((s1_ptr)_2)->base + _30838);
    }
    _2 = (object)SEQ_PTR(_30839);
    _27sample_size_20672 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_27sample_size_20672)){
        _27sample_size_20672 = (object)DBL_PTR(_27sample_size_20672)->dbl;
    }
    _30839 = NOVALUE;
    goto LC; // [277] 288
LB: 

    /** parser.e:4529							sample_size = -1*/
    _27sample_size_20672 = -1;
LC: 

    /** parser.e:4531						if sample_size < 1 and OpProfileTime then*/
    _30841 = (_27sample_size_20672 < 1);
    if (_30841 == 0) {
        goto LD; // [296] 332
    }
    if (_27OpProfileTime_20644 == 0)
    {
        goto LD; // [303] 332
    }
    else{
    }

    /** parser.e:4532							CompileErr(SAMPLE_SIZE_MUST_BE_A_POSITIVE_INTEGER)*/
    RefDS(_22209);
    _49CompileErr(136, _22209, 0);
    goto LD; // [316] 332
LA: 

    /** parser.e:4535						putback(tok)*/
    Ref(_tok_62417);
    _43putback(_tok_62417);

    /** parser.e:4536						sample_size = DEFAULT_SAMPLE_SIZE*/
    _27sample_size_20672 = 25000;
LD: 

    /** parser.e:4538					if OpProfileTime then*/
    if (_27OpProfileTime_20644 == 0)
    {
        goto LE; // [336] 357
    }
    else{
    }

    /** parser.e:4539						if IWINDOWS then*/
    if (_44IWINDOWS_20714 == 0)
    {
        goto LF; // [343] 356
    }
    else{
    }

    /** parser.e:4540							AnyTimeProfile = TRUE*/
    _28AnyTimeProfile_11595 = _9TRUE_441;
LF: 
LE: 
L8: 
    DeRef(_tok_62417);
    _tok_62417 = NOVALUE;
    goto L2; // [361] 1546
L5: 

    /** parser.e:4546		elsif equal(option, "trace") then*/
    if (_option_62363 == _30843)
    _30844 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30843))
    _30844 = 0;
    else
    _30844 = (compare(_option_62363, _30843) == 0);
    if (_30844 == 0)
    {
        _30844 = NOVALUE;
        goto L10; // [370] 391
    }
    else{
        _30844 = NOVALUE;
    }

    /** parser.e:4547			if not BIND then*/
    if (_27BIND_20182 != 0)
    goto L2; // [377] 1546

    /** parser.e:4548				OpTrace = on_off*/
    _27OpTrace_20641 = _on_off_62362;
    goto L2; // [388] 1546
L10: 

    /** parser.e:4551		elsif equal(option, "warning") then*/
    if (_option_62363 == _30846)
    _30847 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30846))
    _30847 = 0;
    else
    _30847 = (compare(_option_62363, _30846) == 0);
    if (_30847 == 0)
    {
        _30847 = NOVALUE;
        goto L11; // [397] 1243
    }
    else{
        _30847 = NOVALUE;
    }

    /** parser.e:4552			integer good_sofar = line_number*/
    _good_sofar_62467 = _27line_number_20572;

    /** parser.e:4553			reset_flags = 1*/
    _reset_flags_62365 = 1;

    /** parser.e:4554			token tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4555			integer warning_extra = 1*/
    _warning_extra_62472 = 1;

    /** parser.e:4556			if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30849 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519;
    ((intptr_t *)_2)[2] = 515;
    _30850 = MAKE_SEQ(_1);
    _30851 = find_from(_30849, _30850, 1);
    _30849 = NOVALUE;
    DeRefDS(_30850);
    _30850 = NOVALUE;
    if (_30851 == 0)
    goto L12; // [445] 506

    /** parser.e:4557				tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4558				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30854 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30854)) {
        _30855 = (_30854 != -24);
    }
    else {
        _30855 = binary_op(NOTEQ, _30854, -24);
    }
    _30854 = NOVALUE;
    if (IS_ATOM_INT(_30855)) {
        if (_30855 == 0) {
            goto L13; // [468] 498
        }
    }
    else {
        if (DBL_PTR(_30855)->dbl == 0.0) {
            goto L13; // [468] 498
        }
    }
    _2 = (object)SEQ_PTR(_tok_62470);
    _30857 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30857)) {
        _30858 = (_30857 != -26);
    }
    else {
        _30858 = binary_op(NOTEQ, _30857, -26);
    }
    _30857 = NOVALUE;
    if (_30858 == 0) {
        DeRef(_30858);
        _30858 = NOVALUE;
        goto L13; // [485] 498
    }
    else {
        if (!IS_ATOM_INT(_30858) && DBL_PTR(_30858)->dbl == 0.0){
            DeRef(_30858);
            _30858 = NOVALUE;
            goto L13; // [485] 498
        }
        DeRef(_30858);
        _30858 = NOVALUE;
    }
    DeRef(_30858);
    _30858 = NOVALUE;

    /** parser.e:4559					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22209);
    _49CompileErr(160, _22209, 0);
L13: 

    /** parser.e:4561				reset_flags = 0*/
    _reset_flags_62365 = 0;
    goto L14; // [503] 734
L12: 

    /** parser.e:4562			elsif tok[T_ID] = EQUALS then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30859 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30859, 3)){
        _30859 = NOVALUE;
        goto L15; // [516] 577
    }
    _30859 = NOVALUE;

    /** parser.e:4563				tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4564				if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30862 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30862)) {
        _30863 = (_30862 != -24);
    }
    else {
        _30863 = binary_op(NOTEQ, _30862, -24);
    }
    _30862 = NOVALUE;
    if (IS_ATOM_INT(_30863)) {
        if (_30863 == 0) {
            goto L16; // [539] 569
        }
    }
    else {
        if (DBL_PTR(_30863)->dbl == 0.0) {
            goto L16; // [539] 569
        }
    }
    _2 = (object)SEQ_PTR(_tok_62470);
    _30865 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30865)) {
        _30866 = (_30865 != -26);
    }
    else {
        _30866 = binary_op(NOTEQ, _30865, -26);
    }
    _30865 = NOVALUE;
    if (_30866 == 0) {
        DeRef(_30866);
        _30866 = NOVALUE;
        goto L16; // [556] 569
    }
    else {
        if (!IS_ATOM_INT(_30866) && DBL_PTR(_30866)->dbl == 0.0){
            DeRef(_30866);
            _30866 = NOVALUE;
            goto L16; // [556] 569
        }
        DeRef(_30866);
        _30866 = NOVALUE;
    }
    DeRef(_30866);
    _30866 = NOVALUE;

    /** parser.e:4565					CompileErr(WARNING_NAMES_MUST_BE_ENCLOSED_IN)*/
    RefDS(_22209);
    _49CompileErr(160, _22209, 0);
L16: 

    /** parser.e:4567				reset_flags = 1*/
    _reset_flags_62365 = 1;
    goto L14; // [574] 734
L15: 

    /** parser.e:4568			elsif tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30867 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30867, -100)){
        _30867 = NOVALUE;
        goto L17; // [587] 733
    }
    _30867 = NOVALUE;

    /** parser.e:4569				option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30869 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30869)){
        _30870 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30869)->dbl));
    }
    else{
        _30870 = (object)*(((s1_ptr)_2)->base + _30869);
    }
    DeRef(_option_62363);
    _2 = (object)SEQ_PTR(_30870);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _option_62363 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _option_62363 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_option_62363);
    _30870 = NOVALUE;

    /** parser.e:4570				if equal(option, "save") then*/
    if (_option_62363 == _30872)
    _30873 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30872))
    _30873 = 0;
    else
    _30873 = (compare(_option_62363, _30872) == 0);
    if (_30873 == 0)
    {
        _30873 = NOVALUE;
        goto L18; // [619] 643
    }
    else{
        _30873 = NOVALUE;
    }

    /** parser.e:4571					prev_OpWarning = OpWarning*/
    _27prev_OpWarning_20640 = _27OpWarning_20639;

    /** parser.e:4572					warning_extra = FALSE*/
    _warning_extra_62472 = _9FALSE_439;
    goto L19; // [640] 732
L18: 

    /** parser.e:4574				elsif equal(option, "restore") then*/
    if (_option_62363 == _30874)
    _30875 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30874))
    _30875 = 0;
    else
    _30875 = (compare(_option_62363, _30874) == 0);
    if (_30875 == 0)
    {
        _30875 = NOVALUE;
        goto L1A; // [649] 673
    }
    else{
        _30875 = NOVALUE;
    }

    /** parser.e:4575					OpWarning = prev_OpWarning*/
    _27OpWarning_20639 = _27prev_OpWarning_20640;

    /** parser.e:4576					warning_extra = FALSE*/
    _warning_extra_62472 = _9FALSE_439;
    goto L19; // [670] 732
L1A: 

    /** parser.e:4578				elsif equal(option, "strict") then*/
    if (_option_62363 == _25703)
    _30876 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_25703))
    _30876 = 0;
    else
    _30876 = (compare(_option_62363, _25703) == 0);
    if (_30876 == 0)
    {
        _30876 = NOVALUE;
        goto L1B; // [679] 731
    }
    else{
        _30876 = NOVALUE;
    }

    /** parser.e:4579					if on_off = 0 then*/
    if (_on_off_62362 != 0)
    goto L1C; // [684] 701

    /** parser.e:4580						Strict_Override += 1*/
    _27Strict_Override_20638 = _27Strict_Override_20638 + 1;
    goto L1D; // [698] 721
L1C: 

    /** parser.e:4581					elsif Strict_Override > 0 then*/
    if (_27Strict_Override_20638 <= 0)
    goto L1E; // [705] 720

    /** parser.e:4582						Strict_Override -= 1*/
    _27Strict_Override_20638 = _27Strict_Override_20638 - 1;
L1E: 
L1D: 

    /** parser.e:4584					warning_extra = FALSE*/
    _warning_extra_62472 = _9FALSE_439;
L1B: 
L19: 
L17: 
L14: 

    /** parser.e:4588			if warning_extra = TRUE then*/
    if (_warning_extra_62472 != _9TRUE_441)
    goto L1F; // [738] 1238

    /** parser.e:4589				if reset_flags then*/
    if (_reset_flags_62365 == 0)
    {
        goto L20; // [744] 776
    }
    else{
    }

    /** parser.e:4590					if on_off = 0 then*/
    if (_on_off_62362 != 0)
    goto L21; // [749] 765

    /** parser.e:4591						OpWarning = no_warning_flag*/
    _27OpWarning_20639 = 0;
    goto L22; // [762] 775
L21: 

    /** parser.e:4593						OpWarning = all_warning_flag*/
    _27OpWarning_20639 = 32767;
L22: 
L20: 

    /** parser.e:4597				if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30883 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -24;
    ((intptr_t *)_2)[2] = -26;
    _30884 = MAKE_SEQ(_1);
    _30885 = find_from(_30883, _30884, 1);
    _30883 = NOVALUE;
    DeRefDS(_30884);
    _30884 = NOVALUE;
    if (_30885 == 0)
    {
        _30885 = NOVALUE;
        goto L23; // [797] 1231
    }
    else{
        _30885 = NOVALUE;
    }

    /** parser.e:4598					integer endlist*/

    /** parser.e:4599					if tok[T_ID] = LEFT_BRACE then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30886 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30886, -24)){
        _30886 = NOVALUE;
        goto L24; // [812] 828
    }
    _30886 = NOVALUE;

    /** parser.e:4600						endlist = RIGHT_BRACE*/
    _endlist_62565 = -25;
    goto L25; // [825] 838
L24: 

    /** parser.e:4602						endlist = RIGHT_ROUND*/
    _endlist_62565 = -27;
L25: 

    /** parser.e:4604					tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4605					while tok[T_ID] != endlist do*/
L26: 
    _2 = (object)SEQ_PTR(_tok_62470);
    _30889 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30889, _endlist_62565)){
        _30889 = NOVALUE;
        goto L27; // [856] 1226
    }
    _30889 = NOVALUE;

    /** parser.e:4606						if tok[T_ID] = COMMA then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30891 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30891, -30)){
        _30891 = NOVALUE;
        goto L28; // [870] 884
    }
    _30891 = NOVALUE;

    /** parser.e:4607							tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4608							continue*/
    goto L26; // [881] 848
L28: 

    /** parser.e:4611						if tok[T_ID] = STRING then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30894 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30894, 503)){
        _30894 = NOVALUE;
        goto L29; // [894] 923
    }
    _30894 = NOVALUE;

    /** parser.e:4612							option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30896 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30896)){
        _30897 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30896)->dbl));
    }
    else{
        _30897 = (object)*(((s1_ptr)_2)->base + _30896);
    }
    DeRef(_option_62363);
    _2 = (object)SEQ_PTR(_30897);
    _option_62363 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_option_62363);
    _30897 = NOVALUE;
    goto L2A; // [920] 1071
L29: 

    /** parser.e:4613						elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30899 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30899)){
        _30900 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30899)->dbl));
    }
    else{
        _30900 = (object)*(((s1_ptr)_2)->base + _30899);
    }
    if (IS_SEQUENCE(_30900)){
            _30901 = SEQ_PTR(_30900)->length;
    }
    else {
        _30901 = 1;
    }
    _30900 = NOVALUE;
    if (binary_op_a(LESS, _30901, _27S_NAME_20209)){
        _30901 = NOVALUE;
        goto L2B; // [942] 971
    }
    _30901 = NOVALUE;

    /** parser.e:4614							option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (object)SEQ_PTR(_tok_62470);
    _30903 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30903)){
        _30904 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30903)->dbl));
    }
    else{
        _30904 = (object)*(((s1_ptr)_2)->base + _30903);
    }
    DeRef(_option_62363);
    _2 = (object)SEQ_PTR(_30904);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _option_62363 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _option_62363 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    Ref(_option_62363);
    _30904 = NOVALUE;
    goto L2A; // [968] 1071
L2B: 

    /** parser.e:4616							option = ""*/
    RefDS(_22209);
    DeRef(_option_62363);
    _option_62363 = _22209;

    /** parser.e:4617							for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_23493)){
            _30906 = SEQ_PTR(_62keylist_23493)->length;
    }
    else {
        _30906 = 1;
    }
    {
        object _k_62612;
        _k_62612 = 1;
L2C: 
        if (_k_62612 > _30906){
            goto L2D; // [985] 1070
        }

        /** parser.e:4618								if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _30907 = (object)*(((s1_ptr)_2)->base + _k_62612);
        _2 = (object)SEQ_PTR(_30907);
        _30908 = (object)*(((s1_ptr)_2)->base + 4);
        _30907 = NOVALUE;
        if (IS_ATOM_INT(_30908)) {
            _30909 = (_30908 == 8);
        }
        else {
            _30909 = binary_op(EQUALS, _30908, 8);
        }
        _30908 = NOVALUE;
        if (IS_ATOM_INT(_30909)) {
            if (_30909 == 0) {
                goto L2E; // [1012] 1063
            }
        }
        else {
            if (DBL_PTR(_30909)->dbl == 0.0) {
                goto L2E; // [1012] 1063
            }
        }
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _30911 = (object)*(((s1_ptr)_2)->base + _k_62612);
        _2 = (object)SEQ_PTR(_30911);
        if (!IS_ATOM_INT(_27S_TOKEN_20214)){
            _30912 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
        }
        else{
            _30912 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
        }
        _30911 = NOVALUE;
        _2 = (object)SEQ_PTR(_tok_62470);
        _30913 = (object)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30912) && IS_ATOM_INT(_30913)) {
            _30914 = (_30912 == _30913);
        }
        else {
            _30914 = binary_op(EQUALS, _30912, _30913);
        }
        _30912 = NOVALUE;
        _30913 = NOVALUE;
        if (_30914 == 0) {
            DeRef(_30914);
            _30914 = NOVALUE;
            goto L2E; // [1039] 1063
        }
        else {
            if (!IS_ATOM_INT(_30914) && DBL_PTR(_30914)->dbl == 0.0){
                DeRef(_30914);
                _30914 = NOVALUE;
                goto L2E; // [1039] 1063
            }
            DeRef(_30914);
            _30914 = NOVALUE;
        }
        DeRef(_30914);
        _30914 = NOVALUE;

        /** parser.e:4621										option = keylist[k][S_NAME]*/
        _2 = (object)SEQ_PTR(_62keylist_23493);
        _30915 = (object)*(((s1_ptr)_2)->base + _k_62612);
        DeRef(_option_62363);
        _2 = (object)SEQ_PTR(_30915);
        if (!IS_ATOM_INT(_27S_NAME_20209)){
            _option_62363 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
        }
        else{
            _option_62363 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
        }
        Ref(_option_62363);
        _30915 = NOVALUE;

        /** parser.e:4622										exit*/
        goto L2D; // [1060] 1070
L2E: 

        /** parser.e:4624							end for*/
        _k_62612 = _k_62612 + 1;
        goto L2C; // [1065] 992
L2D: 
        ;
    }
L2A: 

    /** parser.e:4628						idx = find(option, warning_names)*/
    _idx_62364 = find_from(_option_62363, _27warning_names_20616, 1);

    /** parser.e:4629						if idx = 0 then*/
    if (_idx_62364 != 0)
    goto L2F; // [1082] 1137

    /** parser.e:4630		 					if good_sofar != line_number then*/
    if (_good_sofar_62467 == _27line_number_20572)
    goto L30; // [1090] 1104

    /** parser.e:4631	 							CompileErr(TOO_MANY_WARNING_ERRORS)*/
    RefDS(_22209);
    _49CompileErr(147, _22209, 0);
L30: 

    /** parser.e:4633							Warning(225, 0,*/
    _2 = (object)SEQ_PTR(_28known_files_11573);
    _30920 = (object)*(((s1_ptr)_2)->base + _27current_file_no_20571);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_30920);
    ((intptr_t*)_2)[1] = _30920;
    ((intptr_t*)_2)[2] = _27line_number_20572;
    RefDS(_option_62363);
    ((intptr_t*)_2)[3] = _option_62363;
    _30921 = MAKE_SEQ(_1);
    _30920 = NOVALUE;
    _49Warning(225, 0, _30921);
    _30921 = NOVALUE;

    /** parser.e:4635							tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4636							continue*/
    goto L26; // [1134] 848
L2F: 

    /** parser.e:4639						idx = warning_flags[idx]*/
    _2 = (object)SEQ_PTR(_27warning_flags_20614);
    _idx_62364 = (object)*(((s1_ptr)_2)->base + _idx_62364);

    /** parser.e:4640						if idx = 0 then*/
    if (_idx_62364 != 0)
    goto L31; // [1149] 1183

    /** parser.e:4641							if on_off then*/
    if (_on_off_62362 == 0)
    {
        goto L32; // [1155] 1170
    }
    else{
    }

    /** parser.e:4642								OpWarning = no_warning_flag*/
    _27OpWarning_20639 = 0;
    goto L33; // [1167] 1216
L32: 

    /** parser.e:4644							    OpWarning = all_warning_flag*/
    _27OpWarning_20639 = 32767;
    goto L33; // [1180] 1216
L31: 

    /** parser.e:4647							if on_off then*/
    if (_on_off_62362 == 0)
    {
        goto L34; // [1185] 1201
    }
    else{
    }

    /** parser.e:4648								OpWarning = or_bits(OpWarning, idx)*/
    {uintptr_t tu;
         tu = (uintptr_t)_27OpWarning_20639 | (uintptr_t)_idx_62364;
         _27OpWarning_20639 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_27OpWarning_20639)) {
        _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
        DeRefDS(_27OpWarning_20639);
        _27OpWarning_20639 = _1;
    }
    goto L35; // [1198] 1215
L34: 

    /** parser.e:4650							    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30926 = not_bits(_idx_62364);
    if (IS_ATOM_INT(_30926)) {
        {uintptr_t tu;
             tu = (uintptr_t)_27OpWarning_20639 & (uintptr_t)_30926;
             _27OpWarning_20639 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_27OpWarning_20639;
        _27OpWarning_20639 = Dand_bits(&temp_d, DBL_PTR(_30926));
    }
    DeRef(_30926);
    _30926 = NOVALUE;
    if (!IS_ATOM_INT(_27OpWarning_20639)) {
        _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
        DeRefDS(_27OpWarning_20639);
        _27OpWarning_20639 = _1;
    }
L35: 
L33: 

    /** parser.e:4653						tok = next_token()*/
    _0 = _tok_62470;
    _tok_62470 = _43next_token();
    DeRef(_0);

    /** parser.e:4654					end while*/
    goto L26; // [1223] 848
L27: 
    goto L36; // [1228] 1237
L23: 

    /** parser.e:4656					putback(tok)*/
    Ref(_tok_62470);
    _43putback(_tok_62470);
L36: 
L1F: 
    DeRef(_tok_62470);
    _tok_62470 = NOVALUE;
    goto L2; // [1240] 1546
L11: 

    /** parser.e:4659		elsif equal(option, "define") then*/
    if (_option_62363 == _30929)
    _30930 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30929))
    _30930 = 0;
    else
    _30930 = (compare(_option_62363, _30929) == 0);
    if (_30930 == 0)
    {
        _30930 = NOVALUE;
        goto L37; // [1249] 1376
    }
    else{
        _30930 = NOVALUE;
    }

    /** parser.e:4660			option = StringToken()*/
    RefDS(_5);
    _0 = _option_62363;
    _option_62363 = _61StringToken(_5);
    DeRefDS(_0);

    /** parser.e:4661			if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_62363)){
            _30932 = SEQ_PTR(_option_62363)->length;
    }
    else {
        _30932 = 1;
    }
    if (_30932 != 0)
    goto L38; // [1265] 1281

    /** parser.e:4662				CompileErr(EXPECTING_TO_FIND_A_WORD_TO_DEFINE_BUT_REACHED_END_OF_LINE_FIRST)*/
    RefDS(_22209);
    _49CompileErr(81, _22209, 0);
    goto L39; // [1278] 1301
L38: 

    /** parser.e:4664			elsif not t_identifier(option) then*/
    RefDS(_option_62363);
    _30934 = _9t_identifier(_option_62363);
    if (IS_ATOM_INT(_30934)) {
        if (_30934 != 0){
            DeRef(_30934);
            _30934 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    else {
        if (DBL_PTR(_30934)->dbl != 0.0){
            DeRef(_30934);
            _30934 = NOVALUE;
            goto L3A; // [1287] 1300
        }
    }
    DeRef(_30934);
    _30934 = NOVALUE;

    /** parser.e:4665				CompileErr(DEFINED_WORD_MUST_ONLY_HAVE_ALPHANUMERICS_AND_UNDERSCORE)*/
    RefDS(_22209);
    _49CompileErr(61, _22209, 0);
L3A: 
L39: 

    /** parser.e:4668			if on_off = 0 then*/
    if (_on_off_62362 != 0)
    goto L3B; // [1303] 1358

    /** parser.e:4669				idx = find(option, OpDefines)*/
    _idx_62364 = find_from(_option_62363, _27OpDefines_20645, 1);

    /** parser.e:4670				if idx then*/
    if (_idx_62364 == 0)
    {
        goto L2; // [1318] 1546
    }
    else{
    }

    /** parser.e:4671					OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30938 = _idx_62364 - 1;
    rhs_slice_target = (object_ptr)&_30939;
    RHS_Slice(_27OpDefines_20645, 1, _30938);
    _30940 = _idx_62364 + 1;
    if (IS_SEQUENCE(_27OpDefines_20645)){
            _30941 = SEQ_PTR(_27OpDefines_20645)->length;
    }
    else {
        _30941 = 1;
    }
    rhs_slice_target = (object_ptr)&_30942;
    RHS_Slice(_27OpDefines_20645, _30940, _30941);
    Concat((object_ptr)&_27OpDefines_20645, _30939, _30942);
    DeRefDS(_30939);
    _30939 = NOVALUE;
    DeRef(_30939);
    _30939 = NOVALUE;
    DeRefDS(_30942);
    _30942 = NOVALUE;
    goto L2; // [1355] 1546
L3B: 

    /** parser.e:4674				OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_62363);
    ((intptr_t*)_2)[1] = _option_62363;
    _30944 = MAKE_SEQ(_1);
    Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _30944);
    DeRefDS(_30944);
    _30944 = NOVALUE;
    goto L2; // [1373] 1546
L37: 

    /** parser.e:4677		elsif equal(option, "inline") then*/
    if (_option_62363 == _30946)
    _30947 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30946))
    _30947 = 0;
    else
    _30947 = (compare(_option_62363, _30946) == 0);
    if (_30947 == 0)
    {
        _30947 = NOVALUE;
        goto L3C; // [1382] 1478
    }
    else{
        _30947 = NOVALUE;
    }

    /** parser.e:4679			if on_off and not repl then*/
    if (_on_off_62362 == 0) {
        goto L3D; // [1387] 1467
    }
    _30949 = (0 == 0);
    if (_30949 == 0)
    {
        DeRef(_30949);
        _30949 = NOVALUE;
        goto L3D; // [1397] 1467
    }
    else{
        DeRef(_30949);
        _30949 = NOVALUE;
    }

    /** parser.e:4680				token tok = next_token()*/
    _0 = _tok_62714;
    _tok_62714 = _43next_token();
    DeRef(_0);

    /** parser.e:4681				if tok[T_ID] = ATOM then*/
    _2 = (object)SEQ_PTR(_tok_62714);
    _30951 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30951, 502)){
        _30951 = NOVALUE;
        goto L3E; // [1415] 1447
    }
    _30951 = NOVALUE;

    /** parser.e:4682					OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_62714);
    _30953 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30953)){
        _30954 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30953)->dbl));
    }
    else{
        _30954 = (object)*(((s1_ptr)_2)->base + _30953);
    }
    _2 = (object)SEQ_PTR(_30954);
    _30955 = (object)*(((s1_ptr)_2)->base + 1);
    _30954 = NOVALUE;
    if (IS_ATOM_INT(_30955))
    _27OpInline_20646 = e_floor(_30955);
    else
    _27OpInline_20646 = unary_op(FLOOR, _30955);
    _30955 = NOVALUE;
    if (!IS_ATOM_INT(_27OpInline_20646)) {
        _1 = (object)(DBL_PTR(_27OpInline_20646)->dbl);
        DeRefDS(_27OpInline_20646);
        _27OpInline_20646 = _1;
    }
    goto L3F; // [1444] 1462
L3E: 

    /** parser.e:4684					putback(tok)*/
    Ref(_tok_62714);
    _43putback(_tok_62714);

    /** parser.e:4685					OpInline = DEFAULT_INLINE*/
    _27OpInline_20646 = 30;
L3F: 
    DeRef(_tok_62714);
    _tok_62714 = NOVALUE;
    goto L2; // [1464] 1546
L3D: 

    /** parser.e:4688				OpInline = 0*/
    _27OpInline_20646 = 0;
    goto L2; // [1475] 1546
L3C: 

    /** parser.e:4692		elsif equal( option, "indirect_includes" ) then*/
    if (_option_62363 == _30957)
    _30958 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_30957))
    _30958 = 0;
    else
    _30958 = (compare(_option_62363, _30957) == 0);
    if (_30958 == 0)
    {
        _30958 = NOVALUE;
        goto L40; // [1484] 1497
    }
    else{
        _30958 = NOVALUE;
    }

    /** parser.e:4693			OpIndirectInclude = on_off*/
    _27OpIndirectInclude_20647 = _on_off_62362;
    goto L2; // [1494] 1546
L40: 

    /** parser.e:4695		elsif equal(option, "batch") then*/
    if (_option_62363 == _25700)
    _30959 = 1;
    else if (IS_ATOM_INT(_option_62363) && IS_ATOM_INT(_25700))
    _30959 = 0;
    else
    _30959 = (compare(_option_62363, _25700) == 0);
    if (_30959 == 0)
    {
        _30959 = NOVALUE;
        goto L41; // [1503] 1516
    }
    else{
        _30959 = NOVALUE;
    }

    /** parser.e:4696			batch_job = on_off*/
    _27batch_job_20584 = _on_off_62362;
    goto L2; // [1513] 1546
L41: 

    /** parser.e:4698		elsif integer(to_number(option, -1)) then*/
    RefDS(_option_62363);
    _30960 = _13to_number(_option_62363, -1);
    if (IS_ATOM_INT(_30960))
    _30961 = 1;
    else if (IS_ATOM_DBL(_30960))
    _30961 = IS_ATOM_INT(DoubleToInt(_30960));
    else
    _30961 = 0;
    DeRef(_30960);
    _30960 = NOVALUE;
    if (_30961 == 0)
    {
        _30961 = NOVALUE;
        goto L42; // [1526] 1532
    }
    else{
        _30961 = NOVALUE;
    }
    goto L2; // [1529] 1546
L42: 

    /** parser.e:4702			CompileErr(UNKNOWN_WITHWITHOUT_OPTION_1, {option})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_option_62363);
    ((intptr_t*)_2)[1] = _option_62363;
    _30962 = MAKE_SEQ(_1);
    _49CompileErr(154, _30962, 0);
    _30962 = NOVALUE;
L2: 

    /** parser.e:4705	end procedure*/
    DeRef(_option_62363);
    DeRef(_30827);
    _30827 = NOVALUE;
    _30834 = NOVALUE;
    _30903 = NOVALUE;
    _30900 = NOVALUE;
    _30899 = NOVALUE;
    _30838 = NOVALUE;
    _30869 = NOVALUE;
    DeRef(_30938);
    _30938 = NOVALUE;
    DeRef(_30909);
    _30909 = NOVALUE;
    DeRef(_30940);
    _30940 = NOVALUE;
    _30896 = NOVALUE;
    DeRef(_30822);
    _30822 = NOVALUE;
    DeRef(_30855);
    _30855 = NOVALUE;
    DeRef(_30841);
    _30841 = NOVALUE;
    DeRef(_30863);
    _30863 = NOVALUE;
    _30953 = NOVALUE;
    return;
    ;
}


void _43ExecCommand()
{
    object _0, _1, _2;
    

    /** parser.e:4709		if TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** parser.e:4710			emit_op(RETURNT)*/
    _45emit_op(34);
L1: 

    /** parser.e:4712		StraightenBranches()  -- straighten top-level*/
    _43StraightenBranches();

    /** parser.e:4713	end procedure*/
    return;
    ;
}


object _43undefined_var(object _tok_62758, object _scope_62759)
{
    object _forward_62761 = NOVALUE;
    object _30968 = NOVALUE;
    object _30967 = NOVALUE;
    object _30964 = NOVALUE;
    object _0, _1, _2;
    

    /** parser.e:4716		token forward = next_token()*/
    _0 = _forward_62761;
    _forward_62761 = _43next_token();
    DeRef(_0);

    /** parser.e:4717			switch forward[T_ID] do*/
    _2 = (object)SEQ_PTR(_forward_62761);
    _30964 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30964) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30964)){
        if( (DBL_PTR(_30964)->dbl != (eudouble) ((object) DBL_PTR(_30964)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (object) DBL_PTR(_30964)->dbl;
    }
    else {
        _0 = _30964;
    };
    _30964 = NOVALUE;
    switch ( _0 ){ 

        /** parser.e:4718				case LEFT_ROUND then*/
        case -26:

        /** parser.e:4719					StartSourceLine( TRUE )*/
        _45StartSourceLine(_9TRUE_441, 0, 2);

        /** parser.e:4720					Forward_call( tok )*/
        Ref(_tok_62758);
        _43Forward_call(_tok_62758, 195);

        /** parser.e:4721					return 1*/
        DeRef(_tok_62758);
        DeRef(_forward_62761);
        return 1;
        goto L2; // [48] 96

        /** parser.e:4723				case VARIABLE then*/
        case -100:

        /** parser.e:4724					putback( forward )*/
        Ref(_forward_62761);
        _43putback(_forward_62761);

        /** parser.e:4725					Global_declaration( tok[T_SYM], scope )*/
        _2 = (object)SEQ_PTR(_tok_62758);
        _30967 = (object)*(((s1_ptr)_2)->base + 2);
        Ref(_30967);
        _30968 = _43Global_declaration(_30967, _scope_62759);
        _30967 = NOVALUE;

        /** parser.e:4726					return 1*/
        DeRef(_tok_62758);
        DeRef(_forward_62761);
        DeRef(_30968);
        _30968 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** parser.e:4728				case else*/
        default:
L1: 

        /** parser.e:4729					putback( forward )*/
        Ref(_forward_62761);
        _43putback(_forward_62761);

        /** parser.e:4730					return 0*/
        DeRef(_tok_62758);
        DeRef(_forward_62761);
        DeRef(_30968);
        _30968 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _43real_parser(object _nested_62780)
{
    object _tok_62782 = NOVALUE;
    object _id_62783 = NOVALUE;
    object _scope_62784 = NOVALUE;
    object _deprecated_62846 = NOVALUE;
    object _test_62941 = NOVALUE;
    object _31108 = NOVALUE;
    object _31106 = NOVALUE;
    object _31105 = NOVALUE;
    object _31104 = NOVALUE;
    object _31103 = NOVALUE;
    object _31102 = NOVALUE;
    object _31101 = NOVALUE;
    object _31100 = NOVALUE;
    object _31095 = NOVALUE;
    object _31094 = NOVALUE;
    object _31091 = NOVALUE;
    object _31089 = NOVALUE;
    object _31088 = NOVALUE;
    object _31085 = NOVALUE;
    object _31071 = NOVALUE;
    object _31064 = NOVALUE;
    object _31063 = NOVALUE;
    object _31061 = NOVALUE;
    object _31059 = NOVALUE;
    object _31058 = NOVALUE;
    object _31056 = NOVALUE;
    object _31054 = NOVALUE;
    object _31049 = NOVALUE;
    object _31047 = NOVALUE;
    object _31045 = NOVALUE;
    object _31044 = NOVALUE;
    object _31043 = NOVALUE;
    object _31041 = NOVALUE;
    object _31039 = NOVALUE;
    object _31037 = NOVALUE;
    object _31035 = NOVALUE;
    object _31034 = NOVALUE;
    object _31033 = NOVALUE;
    object _31032 = NOVALUE;
    object _31031 = NOVALUE;
    object _31030 = NOVALUE;
    object _31029 = NOVALUE;
    object _31028 = NOVALUE;
    object _31027 = NOVALUE;
    object _31026 = NOVALUE;
    object _31025 = NOVALUE;
    object _31024 = NOVALUE;
    object _31023 = NOVALUE;
    object _31022 = NOVALUE;
    object _31020 = NOVALUE;
    object _31019 = NOVALUE;
    object _31018 = NOVALUE;
    object _31017 = NOVALUE;
    object _31015 = NOVALUE;
    object _31013 = NOVALUE;
    object _31012 = NOVALUE;
    object _31011 = NOVALUE;
    object _31009 = NOVALUE;
    object _30998 = NOVALUE;
    object _30996 = NOVALUE;
    object _30995 = NOVALUE;
    object _30994 = NOVALUE;
    object _30993 = NOVALUE;
    object _30992 = NOVALUE;
    object _30991 = NOVALUE;
    object _30990 = NOVALUE;
    object _30989 = NOVALUE;
    object _30988 = NOVALUE;
    object _30986 = NOVALUE;
    object _30985 = NOVALUE;
    object _30984 = NOVALUE;
    object _30983 = NOVALUE;
    object _30982 = NOVALUE;
    object _30981 = NOVALUE;
    object _30980 = NOVALUE;
    object _30979 = NOVALUE;
    object _30978 = NOVALUE;
    object _30977 = NOVALUE;
    object _30975 = NOVALUE;
    object _30971 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:4737		integer id*/

    /** parser.e:4738		integer scope*/

    /** parser.e:4740		while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_9TRUE_441 == 0)
    {
        goto L2; // [14] 1925
    }
    else{
    }

    /** parser.e:4741			if OpInline = 25000 then*/
    if (_27OpInline_20646 != 25000)
    goto L3; // [21] 35

    /** parser.e:4742				CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30970);
    _49CompileErr(_30970, _27OpInline_20646, 0);
L3: 

    /** parser.e:4744			start_index = length(Code)+1*/
    if (IS_SEQUENCE(_27Code_20660)){
            _30971 = SEQ_PTR(_27Code_20660)->length;
    }
    else {
        _30971 = 1;
    }
    _43start_index_55411 = _30971 + 1;
    _30971 = NOVALUE;

    /** parser.e:4745			tok = next_token()*/
    _0 = _tok_62782;
    _tok_62782 = _43next_token();
    DeRef(_0);

    /** parser.e:4746			id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _id_62783 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62783)){
        _id_62783 = (object)DBL_PTR(_id_62783)->dbl;
    }

    /** parser.e:4747			if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30975 = (_id_62783 == -100);
    if (_30975 != 0) {
        goto L4; // [69] 84
    }
    _30977 = (_id_62783 == 512);
    if (_30977 == 0)
    {
        DeRef(_30977);
        _30977 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30977);
        _30977 = NOVALUE;
    }
L4: 

    /** parser.e:4748				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _30978 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_30978)){
        _30979 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_30978)->dbl));
    }
    else{
        _30979 = (object)*(((s1_ptr)_2)->base + _30978);
    }
    _2 = (object)SEQ_PTR(_30979);
    _30980 = (object)*(((s1_ptr)_2)->base + 4);
    _30979 = NOVALUE;
    if (IS_ATOM_INT(_30980)) {
        _30981 = (_30980 == 9);
    }
    else {
        _30981 = binary_op(EQUALS, _30980, 9);
    }
    _30980 = NOVALUE;
    if (IS_ATOM_INT(_30981)) {
        if (_30981 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30981)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_62782);
    _30983 = _43undefined_var(_tok_62782, 5);
    if (_30983 == 0) {
        DeRef(_30983);
        _30983 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30983) && DBL_PTR(_30983)->dbl == 0.0){
            DeRef(_30983);
            _30983 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30983);
        _30983 = NOVALUE;
    }
    DeRef(_30983);
    _30983 = NOVALUE;

    /** parser.e:4750					continue*/
    goto L1; // [127] 12
L6: 

    /** parser.e:4752				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4753				Assignment(tok)*/
    Ref(_tok_62782);
    _43Assignment(_tok_62782);

    /** parser.e:4754				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [148] 1915
L5: 

    /** parser.e:4756			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30984 = (_id_62783 == 405);
    if (_30984 != 0) {
        _30985 = 1;
        goto L8; // [159] 173
    }
    _30986 = (_id_62783 == 406);
    _30985 = (_30986 != 0);
L8: 
    if (_30985 != 0) {
        goto L9; // [173] 188
    }
    _30988 = (_id_62783 == 416);
    if (_30988 == 0)
    {
        DeRef(_30988);
        _30988 = NOVALUE;
        goto LA; // [184] 206
    }
    else{
        DeRef(_30988);
        _30988 = NOVALUE;
    }
L9: 

    /** parser.e:4757				SubProg(tok[T_ID], SC_LOCAL, 0)*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _30989 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_30989);
    _43SubProg(_30989, 5, 0);
    _30989 = NOVALUE;
    goto L7; // [203] 1915
LA: 

    /** parser.e:4759			elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC or id = DEPRECATE then*/
    _30990 = (_id_62783 == 412);
    if (_30990 != 0) {
        _30991 = 1;
        goto LB; // [214] 228
    }
    _30992 = (_id_62783 == 428);
    _30991 = (_30992 != 0);
LB: 
    if (_30991 != 0) {
        _30993 = 1;
        goto LC; // [228] 242
    }
    _30994 = (_id_62783 == 429);
    _30993 = (_30994 != 0);
LC: 
    if (_30993 != 0) {
        _30995 = 1;
        goto LD; // [242] 256
    }
    _30996 = (_id_62783 == 430);
    _30995 = (_30996 != 0);
LD: 
    if (_30995 != 0) {
        goto LE; // [256] 271
    }
    _30998 = (_id_62783 == 433);
    if (_30998 == 0)
    {
        DeRef(_30998);
        _30998 = NOVALUE;
        goto LF; // [267] 692
    }
    else{
        DeRef(_30998);
        _30998 = NOVALUE;
    }
LE: 

    /** parser.e:4760				integer deprecated = 0*/
    _deprecated_62846 = 0;

    /** parser.e:4762				if id = DEPRECATE then*/
    if (_id_62783 != 433)
    goto L10; // [280] 305

    /** parser.e:4763					deprecated = 1*/
    _deprecated_62846 = 1;

    /** parser.e:4765					tok = next_token()*/
    _0 = _tok_62782;
    _tok_62782 = _43next_token();
    DeRef(_0);

    /** parser.e:4766					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _id_62783 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62783)){
        _id_62783 = (object)DBL_PTR(_id_62783)->dbl;
    }
L10: 

    /** parser.e:4769				scope = SC_LOCAL*/
    _scope_62784 = 5;

    /** parser.e:4770				if id = GLOBAL then*/
    if (_id_62783 != 412)
    goto L11; // [318] 334

    /** parser.e:4771				    scope = SC_GLOBAL*/
    _scope_62784 = 6;
    goto L12; // [331] 393
L11: 

    /** parser.e:4772				elsif id = EXPORT then*/
    if (_id_62783 != 428)
    goto L13; // [338] 354

    /** parser.e:4773					scope = SC_EXPORT*/
    _scope_62784 = 11;
    goto L12; // [351] 393
L13: 

    /** parser.e:4774				elsif id = OVERRIDE then*/
    if (_id_62783 != 429)
    goto L14; // [358] 374

    /** parser.e:4775					scope = SC_OVERRIDE*/
    _scope_62784 = 12;
    goto L12; // [371] 393
L14: 

    /** parser.e:4776				elsif id = PUBLIC then*/
    if (_id_62783 != 430)
    goto L15; // [378] 392

    /** parser.e:4777					scope = SC_PUBLIC*/
    _scope_62784 = 13;
L15: 
L12: 

    /** parser.e:4781				if scope != SC_LOCAL then*/
    if (_scope_62784 == 5)
    goto L16; // [397] 417

    /** parser.e:4782					tok = next_token()*/
    _0 = _tok_62782;
    _tok_62782 = _43next_token();
    DeRef(_0);

    /** parser.e:4783					id = tok[T_ID]*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _id_62783 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_62783)){
        _id_62783 = (object)DBL_PTR(_id_62783)->dbl;
    }
L16: 

    /** parser.e:4786				if id = TYPE or id = QUALIFIED_TYPE then*/
    _31009 = (_id_62783 == 504);
    if (_31009 != 0) {
        goto L17; // [425] 440
    }
    _31011 = (_id_62783 == 522);
    if (_31011 == 0)
    {
        DeRef(_31011);
        _31011 = NOVALUE;
        goto L18; // [436] 456
    }
    else{
        DeRef(_31011);
        _31011 = NOVALUE;
    }
L17: 

    /** parser.e:4787					Global_declaration(tok[T_SYM], scope )*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _31012 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31012);
    _31013 = _43Global_declaration(_31012, _scope_62784);
    _31012 = NOVALUE;
    goto L19; // [453] 687
L18: 

    /** parser.e:4789				elsif id = CONSTANT then*/
    if (_id_62783 != 417)
    goto L1A; // [460] 478

    /** parser.e:4790					Global_declaration(0, scope )*/
    _31015 = _43Global_declaration(0, _scope_62784);

    /** parser.e:4791					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [475] 687
L1A: 

    /** parser.e:4793				elsif id = ENUM then*/
    if (_id_62783 != 427)
    goto L1B; // [482] 500

    /** parser.e:4794					Global_declaration(-1, scope )*/
    _31017 = _43Global_declaration(-1, _scope_62784);

    /** parser.e:4795					ExecCommand()*/
    _43ExecCommand();
    goto L19; // [497] 687
L1B: 

    /** parser.e:4797				elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _31018 = (_id_62783 == 405);
    if (_31018 != 0) {
        _31019 = 1;
        goto L1C; // [508] 522
    }
    _31020 = (_id_62783 == 406);
    _31019 = (_31020 != 0);
L1C: 
    if (_31019 != 0) {
        goto L1D; // [522] 537
    }
    _31022 = (_id_62783 == 416);
    if (_31022 == 0)
    {
        DeRef(_31022);
        _31022 = NOVALUE;
        goto L1E; // [533] 547
    }
    else{
        DeRef(_31022);
        _31022 = NOVALUE;
    }
L1D: 

    /** parser.e:4798					SubProg(id, scope, deprecated)*/
    _43SubProg(_id_62783, _scope_62784, _deprecated_62846);
    goto L19; // [544] 687
L1E: 

    /** parser.e:4800				elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _31023 = (_scope_62784 == 13);
    if (_31023 == 0) {
        goto L1F; // [555] 581
    }
    _31025 = (_id_62783 == 418);
    if (_31025 == 0)
    {
        DeRef(_31025);
        _31025 = NOVALUE;
        goto L1F; // [566] 581
    }
    else{
        DeRef(_31025);
        _31025 = NOVALUE;
    }

    /** parser.e:4801					IncludeScan( 1 )*/
    _61IncludeScan(1);

    /** parser.e:4802					PushGoto()*/
    _43PushGoto();
    goto L19; // [578] 687
L1F: 

    /** parser.e:4803				elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _31026 = (_id_62783 == -100);
    if (_31026 != 0) {
        _31027 = 1;
        goto L20; // [589] 603
    }
    _31028 = (_id_62783 == 512);
    _31027 = (_31028 != 0);
L20: 
    if (_31027 == 0) {
        _31029 = 0;
        goto L21; // [603] 635
    }
    _2 = (object)SEQ_PTR(_tok_62782);
    _31030 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_31030)){
        _31031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31030)->dbl));
    }
    else{
        _31031 = (object)*(((s1_ptr)_2)->base + _31030);
    }
    _2 = (object)SEQ_PTR(_31031);
    _31032 = (object)*(((s1_ptr)_2)->base + 4);
    _31031 = NOVALUE;
    if (IS_ATOM_INT(_31032)) {
        _31033 = (_31032 == 9);
    }
    else {
        _31033 = binary_op(EQUALS, _31032, 9);
    }
    _31032 = NOVALUE;
    if (IS_ATOM_INT(_31033))
    _31029 = (_31033 != 0);
    else
    _31029 = DBL_PTR(_31033)->dbl != 0.0;
L21: 
    if (_31029 == 0) {
        goto L22; // [635] 657
    }
    Ref(_tok_62782);
    _31035 = _43undefined_var(_tok_62782, _scope_62784);
    if (_31035 == 0) {
        DeRef(_31035);
        _31035 = NOVALUE;
        goto L22; // [645] 657
    }
    else {
        if (!IS_ATOM_INT(_31035) && DBL_PTR(_31035)->dbl == 0.0){
            DeRef(_31035);
            _31035 = NOVALUE;
            goto L22; // [645] 657
        }
        DeRef(_31035);
        _31035 = NOVALUE;
    }
    DeRef(_31035);
    _31035 = NOVALUE;

    /** parser.e:4807					continue*/
    goto L1; // [652] 12
    goto L19; // [654] 687
L22: 

    /** parser.e:4809				elsif scope = SC_GLOBAL then*/
    if (_scope_62784 != 6)
    goto L23; // [661] 677

    /** parser.e:4810					CompileErr( MSG_GLOBAL_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22209);
    _49CompileErr(18, _22209, 0);
    goto L19; // [674] 687
L23: 

    /** parser.e:4812					CompileErr( MSG_PUBLIC_OR_EXPORT_MUST_BE_FOLLOWED_BYA_TYPE_CONSTANT_ENUM_PROCEDURE_TYPE_OR_FUNCTION)*/
    RefDS(_22209);
    _49CompileErr(16, _22209, 0);
L19: 
    goto L7; // [689] 1915
LF: 

    /** parser.e:4815			elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _31037 = (_id_62783 == 504);
    if (_31037 != 0) {
        goto L24; // [700] 715
    }
    _31039 = (_id_62783 == 522);
    if (_31039 == 0)
    {
        DeRef(_31039);
        _31039 = NOVALUE;
        goto L25; // [711] 800
    }
    else{
        DeRef(_31039);
        _31039 = NOVALUE;
    }
L24: 

    /** parser.e:4816				token test = next_token()*/
    _0 = _test_62941;
    _test_62941 = _43next_token();
    DeRef(_0);

    /** parser.e:4817				putback( test )*/
    Ref(_test_62941);
    _43putback(_test_62941);

    /** parser.e:4818				if test[T_ID] = LEFT_ROUND then*/
    _2 = (object)SEQ_PTR(_test_62941);
    _31041 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _31041, -26)){
        _31041 = NOVALUE;
        goto L26; // [735] 773
    }
    _31041 = NOVALUE;

    /** parser.e:4819						StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4820						Procedure_call(tok)*/
    Ref(_tok_62782);
    _43Procedure_call(_tok_62782);

    /** parser.e:4821						clear_op()*/
    _45clear_op();

    /** parser.e:4822						if Pop() then end if*/
    _31043 = _45Pop();
    if (_31043 == 0) {
        DeRef(_31043);
        _31043 = NOVALUE;
        goto L27; // [762] 766
    }
    else {
        if (!IS_ATOM_INT(_31043) && DBL_PTR(_31043)->dbl == 0.0){
            DeRef(_31043);
            _31043 = NOVALUE;
            goto L27; // [762] 766
        }
        DeRef(_31043);
        _31043 = NOVALUE;
    }
    DeRef(_31043);
    _31043 = NOVALUE;
L27: 

    /** parser.e:4823						ExecCommand()*/
    _43ExecCommand();
    goto L28; // [770] 789
L26: 

    /** parser.e:4826					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _31044 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31044);
    _31045 = _43Global_declaration(_31044, 5);
    _31044 = NOVALUE;
L28: 

    /** parser.e:4829				continue*/
    DeRef(_test_62941);
    _test_62941 = NOVALUE;
    goto L1; // [793] 12
    goto L7; // [797] 1915
L25: 

    /** parser.e:4831			elsif id = CONSTANT then*/
    if (_id_62783 != 417)
    goto L29; // [804] 824

    /** parser.e:4832				Global_declaration(0, SC_LOCAL)*/
    _31047 = _43Global_declaration(0, 5);

    /** parser.e:4833				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [821] 1915
L29: 

    /** parser.e:4835			elsif id = ENUM then*/
    if (_id_62783 != 427)
    goto L2A; // [828] 848

    /** parser.e:4836				Global_declaration(-1, SC_LOCAL)*/
    _31049 = _43Global_declaration(-1, 5);

    /** parser.e:4837				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [845] 1915
L2A: 

    /** parser.e:4839			elsif id = IF then*/
    if (_id_62783 != 20)
    goto L2B; // [852] 876

    /** parser.e:4840				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4841				If_statement()*/
    _43If_statement();

    /** parser.e:4842				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [873] 1915
L2B: 

    /** parser.e:4844			elsif id = FOR then*/
    if (_id_62783 != 21)
    goto L2C; // [880] 904

    /** parser.e:4845				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4846				For_statement()*/
    _43For_statement();

    /** parser.e:4847				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [901] 1915
L2C: 

    /** parser.e:4849			elsif id = WHILE then*/
    if (_id_62783 != 47)
    goto L2D; // [908] 932

    /** parser.e:4850				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4851				While_statement()*/
    _43While_statement();

    /** parser.e:4852				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [929] 1915
L2D: 

    /** parser.e:4854			elsif id = LOOP then*/
    if (_id_62783 != 422)
    goto L2E; // [936] 960

    /** parser.e:4855			    StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4856			    Loop_statement()*/
    _43Loop_statement();

    /** parser.e:4857			    ExecCommand()*/
    _43ExecCommand();
    goto L7; // [957] 1915
L2E: 

    /** parser.e:4859			elsif id = PROC or id = QUALIFIED_PROC then*/
    _31054 = (_id_62783 == 27);
    if (_31054 != 0) {
        goto L2F; // [968] 983
    }
    _31056 = (_id_62783 == 521);
    if (_31056 == 0)
    {
        DeRef(_31056);
        _31056 = NOVALUE;
        goto L30; // [979] 1024
    }
    else{
        DeRef(_31056);
        _31056 = NOVALUE;
    }
L2F: 

    /** parser.e:4860				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4861				if id = PROC then*/
    if (_id_62783 != 27)
    goto L31; // [996] 1012

    /** parser.e:4863					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _31058 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31058);
    _43UndefinedVar(_31058);
    _31058 = NOVALUE;
L31: 

    /** parser.e:4866				Procedure_call(tok)*/
    Ref(_tok_62782);
    _43Procedure_call(_tok_62782);

    /** parser.e:4867				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1021] 1915
L30: 

    /** parser.e:4869			elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _31059 = (_id_62783 == 501);
    if (_31059 != 0) {
        goto L32; // [1032] 1047
    }
    _31061 = (_id_62783 == 520);
    if (_31061 == 0)
    {
        DeRef(_31061);
        _31061 = NOVALUE;
        goto L33; // [1043] 1101
    }
    else{
        DeRef(_31061);
        _31061 = NOVALUE;
    }
L32: 

    /** parser.e:4870				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4871				if id = FUNC then*/
    if (_id_62783 != 501)
    goto L34; // [1060] 1076

    /** parser.e:4873					UndefinedVar( tok[T_SYM] )*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _31063 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_31063);
    _43UndefinedVar(_31063);
    _31063 = NOVALUE;
L34: 

    /** parser.e:4876				Procedure_call(tok)*/
    Ref(_tok_62782);
    _43Procedure_call(_tok_62782);

    /** parser.e:4877				clear_op()*/
    _45clear_op();

    /** parser.e:4878				if Pop() then end if*/
    _31064 = _45Pop();
    if (_31064 == 0) {
        DeRef(_31064);
        _31064 = NOVALUE;
        goto L35; // [1090] 1094
    }
    else {
        if (!IS_ATOM_INT(_31064) && DBL_PTR(_31064)->dbl == 0.0){
            DeRef(_31064);
            _31064 = NOVALUE;
            goto L35; // [1090] 1094
        }
        DeRef(_31064);
        _31064 = NOVALUE;
    }
    DeRef(_31064);
    _31064 = NOVALUE;
L35: 

    /** parser.e:4879				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1098] 1915
L33: 

    /** parser.e:4881			elsif id = RETURN then*/
    if (_id_62783 != 413)
    goto L36; // [1105] 1116

    /** parser.e:4882				Return_statement() -- will fail - not allowed at top level*/
    _43Return_statement();
    goto L7; // [1113] 1915
L36: 

    /** parser.e:4884			elsif id = EXIT then*/
    if (_id_62783 != 61)
    goto L37; // [1120] 1158

    /** parser.e:4885				if nested then*/
    if (_nested_62780 == 0)
    {
        goto L38; // [1126] 1145
    }
    else{
    }

    /** parser.e:4886				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4887				Exit_statement()*/
    _43Exit_statement();
    goto L7; // [1142] 1915
L38: 

    /** parser.e:4889				CompileErr(EXIT_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(89, _22209, 0);
    goto L7; // [1155] 1915
L37: 

    /** parser.e:4892			elsif id = INCLUDE then*/
    if (_id_62783 != 418)
    goto L39; // [1162] 1178

    /** parser.e:4893				IncludeScan( 0 )*/
    _61IncludeScan(0);

    /** parser.e:4894				PushGoto()*/
    _43PushGoto();
    goto L7; // [1175] 1915
L39: 

    /** parser.e:4896			elsif id = WITH then*/
    if (_id_62783 != 420)
    goto L3A; // [1182] 1196

    /** parser.e:4897				SetWith(TRUE)*/
    _43SetWith(_9TRUE_441);
    goto L7; // [1193] 1915
L3A: 

    /** parser.e:4899			elsif id = WITHOUT then*/
    if (_id_62783 != 421)
    goto L3B; // [1200] 1214

    /** parser.e:4900				SetWith(FALSE)*/
    _43SetWith(_9FALSE_439);
    goto L7; // [1211] 1915
L3B: 

    /** parser.e:4902			elsif id = END_OF_FILE then*/
    if (_id_62783 != -21)
    goto L3C; // [1218] 1335

    /** parser.e:4903				if IncludePop() then*/
    _31071 = _61IncludePop();
    if (_31071 == 0) {
        DeRef(_31071);
        _31071 = NOVALUE;
        goto L3D; // [1227] 1323
    }
    else {
        if (!IS_ATOM_INT(_31071) && DBL_PTR(_31071)->dbl == 0.0){
            DeRef(_31071);
            _31071 = NOVALUE;
            goto L3D; // [1227] 1323
        }
        DeRef(_31071);
        _31071 = NOVALUE;
    }
    DeRef(_31071);
    _31071 = NOVALUE;

    /** parser.e:4904					backed_up_tok = {}*/
    RefDS(_22209);
    DeRef(_43backed_up_tok_55412);
    _43backed_up_tok_55412 = _22209;

    /** parser.e:4905					PopGoto()*/
    _43PopGoto();

    /** parser.e:4906					read_line()*/
    _61read_line();

    /** parser.e:4908					last_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49last_ForwardLine_49645);
    _49last_ForwardLine_49645 = _49ThisLine_49642;

    /** parser.e:4909					last_fwd_line_number = line_number*/
    _27last_fwd_line_number_20575 = _27line_number_20572;

    /** parser.e:4910					last_forward_bp      = bp*/
    _49last_forward_bp_49649 = _49bp_49646;

    /** parser.e:4912					putback_ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49putback_ForwardLine_49644);
    _49putback_ForwardLine_49644 = _49ThisLine_49642;

    /** parser.e:4913					putback_fwd_line_number = line_number*/
    _27putback_fwd_line_number_20574 = _27line_number_20572;

    /** parser.e:4914					putback_forward_bp      = bp*/
    _49putback_forward_bp_49648 = _49bp_49646;

    /** parser.e:4916					ForwardLine     = ThisLine*/
    Ref(_49ThisLine_49642);
    DeRef(_49ForwardLine_49643);
    _49ForwardLine_49643 = _49ThisLine_49642;

    /** parser.e:4917					fwd_line_number = line_number*/
    _27fwd_line_number_20573 = _27line_number_20572;

    /** parser.e:4918					forward_bp      = bp*/
    _49forward_bp_49647 = _49bp_49646;
    goto L7; // [1320] 1915
L3D: 

    /** parser.e:4921					CheckForUndefinedGotoLabels()*/
    _43CheckForUndefinedGotoLabels();

    /** parser.e:4922					exit -- all finished*/
    goto L2; // [1329] 1925
    goto L7; // [1332] 1915
L3C: 

    /** parser.e:4925			elsif id = QUESTION_MARK then*/
    if (_id_62783 != -31)
    goto L3E; // [1339] 1363

    /** parser.e:4926				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4927				Print_statement()*/
    _43Print_statement();

    /** parser.e:4928				ExecCommand()*/
    _43ExecCommand();
    goto L7; // [1360] 1915
L3E: 

    /** parser.e:4930			elsif id = LABEL then*/
    if (_id_62783 != 419)
    goto L3F; // [1367] 1389

    /** parser.e:4931				StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_441, 0, 1);

    /** parser.e:4932				GLabel_statement()*/
    _43GLabel_statement();
    goto L7; // [1386] 1915
L3F: 

    /** parser.e:4934			elsif id = GOTO then*/
    if (_id_62783 != 188)
    goto L40; // [1393] 1413

    /** parser.e:4935				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4936				Goto_statement()*/
    _43Goto_statement();
    goto L7; // [1410] 1915
L40: 

    /** parser.e:4938			elsif id = CONTINUE then*/
    if (_id_62783 != 426)
    goto L41; // [1417] 1455

    /** parser.e:4939				if nested then*/
    if (_nested_62780 == 0)
    {
        goto L42; // [1423] 1442
    }
    else{
    }

    /** parser.e:4940					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4941					Continue_statement()*/
    _43Continue_statement();
    goto L7; // [1439] 1915
L42: 

    /** parser.e:4943					CompileErr(CONTINUE_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(50, _22209, 0);
    goto L7; // [1452] 1915
L41: 

    /** parser.e:4946			elsif id = RETRY then*/
    if (_id_62783 != 184)
    goto L43; // [1459] 1497

    /** parser.e:4947				if nested then*/
    if (_nested_62780 == 0)
    {
        goto L44; // [1465] 1484
    }
    else{
    }

    /** parser.e:4948					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4949					Retry_statement()*/
    _43Retry_statement();
    goto L7; // [1481] 1915
L44: 

    /** parser.e:4951					CompileErr(RETRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(128, _22209, 0);
    goto L7; // [1494] 1915
L43: 

    /** parser.e:4954			elsif id = BREAK then*/
    if (_id_62783 != 425)
    goto L45; // [1501] 1539

    /** parser.e:4955				if nested then*/
    if (_nested_62780 == 0)
    {
        goto L46; // [1507] 1526
    }
    else{
    }

    /** parser.e:4956					StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4957					Break_statement()*/
    _43Break_statement();
    goto L7; // [1523] 1915
L46: 

    /** parser.e:4959					CompileErr(BREAK_MUST_BE_INSIDE_AN_IF_BLOCK)*/
    RefDS(_22209);
    _49CompileErr(39, _22209, 0);
    goto L7; // [1536] 1915
L45: 

    /** parser.e:4962			elsif id = ENTRY then*/
    if (_id_62783 != 424)
    goto L47; // [1543] 1583

    /** parser.e:4963				if nested then*/
    if (_nested_62780 == 0)
    {
        goto L48; // [1549] 1570
    }
    else{
    }

    /** parser.e:4964				    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _45StartSourceLine(_9TRUE_441, 0, 1);

    /** parser.e:4965				    Entry_statement()*/
    _43Entry_statement();
    goto L7; // [1567] 1915
L48: 

    /** parser.e:4967					CompileErr(ENTRY_MUST_BE_INSIDE_A_LOOP)*/
    RefDS(_22209);
    _49CompileErr(72, _22209, 0);
    goto L7; // [1580] 1915
L47: 

    /** parser.e:4970			elsif id = IFDEF then*/
    if (_id_62783 != 407)
    goto L49; // [1587] 1607

    /** parser.e:4971				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4972				Ifdef_statement()*/
    _43Ifdef_statement();
    goto L7; // [1604] 1915
L49: 

    /** parser.e:4974			elsif id = CASE then*/
    if (_id_62783 != 186)
    goto L4A; // [1611] 1622

    /** parser.e:4975				Case_statement()*/
    _43Case_statement();
    goto L7; // [1619] 1915
L4A: 

    /** parser.e:4977			elsif id = SWITCH then*/
    if (_id_62783 != 185)
    goto L4B; // [1626] 1646

    /** parser.e:4978				StartSourceLine(TRUE)*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4979				Switch_statement()*/
    _43Switch_statement();
    goto L7; // [1643] 1915
L4B: 

    /** parser.e:4981			elsif id = LEFT_BRACE then*/
    if (_id_62783 != -24)
    goto L4C; // [1650] 1670

    /** parser.e:4982				StartSourceLine( TRUE )*/
    _45StartSourceLine(_9TRUE_441, 0, 2);

    /** parser.e:4983				Multi_assign()*/
    _43Multi_assign();
    goto L7; // [1667] 1915
L4C: 

    /** parser.e:4985			elsif id = ILLEGAL_CHAR then*/
    if (_id_62783 != -20)
    goto L4D; // [1674] 1690

    /** parser.e:4986				CompileErr(ILLEGAL_CHARACTER)*/
    RefDS(_22209);
    _49CompileErr(102, _22209, 0);
    goto L7; // [1687] 1915
L4D: 

    /** parser.e:4989				if nested then*/
    if (_nested_62780 == 0)
    {
        goto L4E; // [1692] 1852
    }
    else{
    }

    /** parser.e:4990					if id = ELSE then*/
    if (_id_62783 != 23)
    goto L4F; // [1699] 1757

    /** parser.e:4991						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _31085 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _31085 = 1;
    }
    if (_31085 != 0)
    goto L50; // [1710] 1818

    /** parser.e:4992							if live_ifdef > 0 then*/
    if (_43live_ifdef_59907 <= 0)
    goto L51; // [1718] 1743

    /** parser.e:4993								CompileErr(SHOULD_THIS_BE_ELSEDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _31088 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _31088 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _31089 = (object)*(((s1_ptr)_2)->base + _31088);
    _49CompileErr(134, _31089, 0);
    _31089 = NOVALUE;
    goto L50; // [1740] 1818
L51: 

    /** parser.e:4995								CompileErr(NOT_EXPECTING_ELSE)*/
    RefDS(_22209);
    _49CompileErr(118, _22209, 0);
    goto L50; // [1754] 1818
L4F: 

    /** parser.e:4998					elsif id = ELSIF then*/
    if (_id_62783 != 414)
    goto L52; // [1761] 1817

    /** parser.e:4999						if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_43if_stack_55440)){
            _31091 = SEQ_PTR(_43if_stack_55440)->length;
    }
    else {
        _31091 = 1;
    }
    if (_31091 != 0)
    goto L53; // [1772] 1816

    /** parser.e:5000							if live_ifdef > 0 then*/
    if (_43live_ifdef_59907 <= 0)
    goto L54; // [1780] 1805

    /** parser.e:5001								CompileErr(SHOULD_THIS_BE_ELSIFDEF_FOR_THE_IFDEF_ON_LINE_1, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_43ifdef_lineno_59908)){
            _31094 = SEQ_PTR(_43ifdef_lineno_59908)->length;
    }
    else {
        _31094 = 1;
    }
    _2 = (object)SEQ_PTR(_43ifdef_lineno_59908);
    _31095 = (object)*(((s1_ptr)_2)->base + _31094);
    _49CompileErr(139, _31095, 0);
    _31095 = NOVALUE;
    goto L55; // [1802] 1815
L54: 

    /** parser.e:5003								CompileErr(NOT_EXPECTING_ELSIF)*/
    RefDS(_22209);
    _49CompileErr(119, _22209, 0);
L55: 
L53: 
L52: 
L50: 

    /** parser.e:5007					putback(tok)*/
    Ref(_tok_62782);
    _43putback(_tok_62782);

    /** parser.e:5008					if stmt_nest > 0 then*/
    if (_43stmt_nest_55437 <= 0)
    goto L56; // [1827] 1844

    /** parser.e:5009						stmt_nest -= 1*/
    _43stmt_nest_55437 = _43stmt_nest_55437 - 1;

    /** parser.e:5010						InitDelete()*/
    _43InitDelete();
L56: 

    /** parser.e:5012					return*/
    DeRef(_tok_62782);
    DeRef(_30984);
    _30984 = NOVALUE;
    DeRef(_31059);
    _31059 = NOVALUE;
    DeRef(_31054);
    _31054 = NOVALUE;
    _30978 = NOVALUE;
    DeRef(_31017);
    _31017 = NOVALUE;
    DeRef(_31028);
    _31028 = NOVALUE;
    DeRef(_31023);
    _31023 = NOVALUE;
    DeRef(_30994);
    _30994 = NOVALUE;
    DeRef(_30981);
    _30981 = NOVALUE;
    DeRef(_31020);
    _31020 = NOVALUE;
    DeRef(_30975);
    _30975 = NOVALUE;
    DeRef(_31015);
    _31015 = NOVALUE;
    DeRef(_31026);
    _31026 = NOVALUE;
    DeRef(_31009);
    _31009 = NOVALUE;
    DeRef(_30992);
    _30992 = NOVALUE;
    DeRef(_31018);
    _31018 = NOVALUE;
    DeRef(_31047);
    _31047 = NOVALUE;
    DeRef(_30996);
    _30996 = NOVALUE;
    DeRef(_31037);
    _31037 = NOVALUE;
    DeRef(_31013);
    _31013 = NOVALUE;
    DeRef(_30990);
    _30990 = NOVALUE;
    DeRef(_31033);
    _31033 = NOVALUE;
    _31030 = NOVALUE;
    DeRef(_30986);
    _30986 = NOVALUE;
    DeRef(_31045);
    _31045 = NOVALUE;
    DeRef(_31049);
    _31049 = NOVALUE;
    return;
    goto L57; // [1849] 1914
L4E: 

    /** parser.e:5014					if id = END then*/
    if (_id_62783 != 402)
    goto L58; // [1856] 1889

    /** parser.e:5015						tok = next_token()*/
    _0 = _tok_62782;
    _tok_62782 = _43next_token();
    DeRef(_0);

    /** parser.e:5016						CompileErr(MSG_END_HAS_NO_MATCHING_1, {find_token_text(tok[T_ID])})*/
    _2 = (object)SEQ_PTR(_tok_62782);
    _31100 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_31100);
    _31101 = _62find_token_text(_31100);
    _31100 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31101;
    _31102 = MAKE_SEQ(_1);
    _31101 = NOVALUE;
    _49CompileErr(17, _31102, 0);
    _31102 = NOVALUE;
L58: 

    /** parser.e:5019					CompileErr(NOT_EXPECTING_TO_SEE_1_HERE, { match_replace(",", find_token_text(id), "") })*/
    _31103 = _62find_token_text(_id_62783);
    RefDS(_26444);
    RefDS(_22209);
    _31104 = _14match_replace(_26444, _31103, _22209, 0);
    _31103 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31104;
    _31105 = MAKE_SEQ(_1);
    _31104 = NOVALUE;
    _49CompileErr(117, _31105, 0);
    _31105 = NOVALUE;
L57: 
L7: 

    /** parser.e:5024			flush_temps()*/
    RefDS(_22209);
    _45flush_temps(_22209);

    /** parser.e:5025		end while*/
    goto L1; // [1922] 12
L2: 

    /** parser.e:5026		emit_op(RETURNT)*/
    _45emit_op(34);

    /** parser.e:5027		clear_last()*/
    _45clear_last();

    /** parser.e:5028		StraightenBranches()*/
    _43StraightenBranches();

    /** parser.e:5029		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _31106 = NOVALUE;

    /** parser.e:5030		EndLineTable()*/
    _43EndLineTable();

    /** parser.e:5031		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _31108 = NOVALUE;

    /** parser.e:5032	end procedure*/
    DeRef(_tok_62782);
    DeRef(_30984);
    _30984 = NOVALUE;
    DeRef(_31059);
    _31059 = NOVALUE;
    DeRef(_31054);
    _31054 = NOVALUE;
    _30978 = NOVALUE;
    DeRef(_31017);
    _31017 = NOVALUE;
    DeRef(_31028);
    _31028 = NOVALUE;
    DeRef(_31023);
    _31023 = NOVALUE;
    DeRef(_30994);
    _30994 = NOVALUE;
    DeRef(_30981);
    _30981 = NOVALUE;
    DeRef(_31020);
    _31020 = NOVALUE;
    DeRef(_30975);
    _30975 = NOVALUE;
    DeRef(_31015);
    _31015 = NOVALUE;
    DeRef(_31026);
    _31026 = NOVALUE;
    DeRef(_31009);
    _31009 = NOVALUE;
    DeRef(_30992);
    _30992 = NOVALUE;
    DeRef(_31018);
    _31018 = NOVALUE;
    DeRef(_31047);
    _31047 = NOVALUE;
    DeRef(_30996);
    _30996 = NOVALUE;
    DeRef(_31037);
    _31037 = NOVALUE;
    DeRef(_31013);
    _31013 = NOVALUE;
    DeRef(_30990);
    _30990 = NOVALUE;
    DeRef(_31033);
    _31033 = NOVALUE;
    _31030 = NOVALUE;
    DeRef(_30986);
    _30986 = NOVALUE;
    DeRef(_31045);
    _31045 = NOVALUE;
    DeRef(_31049);
    _31049 = NOVALUE;
    return;
    ;
}


void _43parser()
{
    object _31112 = NOVALUE;
    object _31110 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** parser.e:5035		real_parser(0)*/
    _43real_parser(0);

    /** parser.e:5036		mark_final_targets()*/
    _53mark_final_targets();

    /** parser.e:5037		resolve_unincluded_globals( 1 )*/
    _53resolve_unincluded_globals(1);

    /** parser.e:5038		Resolve_forward_references( 1 )*/
    _42Resolve_forward_references(1);

    /** parser.e:5039		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27Code_20660);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_CODE_20221))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_CODE_20221)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_CODE_20221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27Code_20660;
    DeRef(_1);
    _31110 = NOVALUE;

    /** parser.e:5040		SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _28SymTab_11572 = MAKE_SEQ(_2);
    }
    _3 = (object)(_27TopLevelSub_20578 + ((s1_ptr)_2)->base);
    RefDS(_27LineTable_20661);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27S_LINETAB_20244))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_LINETAB_20244)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27S_LINETAB_20244);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27LineTable_20661;
    DeRef(_1);
    _31112 = NOVALUE;

    /** parser.e:5041		Code = {}*/
    RefDS(_22209);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _22209;

    /** parser.e:5042		LineTable = {}*/
    RefDS(_22209);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22209;

    /** parser.e:5043		inline_deferred_calls()*/
    _66inline_deferred_calls();

    /** parser.e:5044		if not repl then*/

    /** parser.e:5045		End_block( PROC )*/
    _64End_block(27);

    /** parser.e:5046		Code = {}*/
    RefDS(_22209);
    DeRefDS(_27Code_20660);
    _27Code_20660 = _22209;

    /** parser.e:5047		LineTable = {}*/
    RefDS(_22209);
    DeRefDS(_27LineTable_20661);
    _27LineTable_20661 = _22209;

    /** parser.e:5049	end procedure*/
    return;
    ;
}


void _43nested_parser()
{
    object _0, _1, _2;
    

    /** parser.e:5052		real_parser(1)*/
    _43real_parser(1);

    /** parser.e:5053	end procedure*/
    return;
    ;
}



// 0x68F069ED
