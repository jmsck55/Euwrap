// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _12sprint(object _x_9853)
{
    object _s_9854 = NOVALUE;
    object _5401 = NOVALUE;
    object _5399 = NOVALUE;
    object _5398 = NOVALUE;
    object _5395 = NOVALUE;
    object _5394 = NOVALUE;
    object _5392 = NOVALUE;
    object _5391 = NOVALUE;
    object _5390 = NOVALUE;
    object _5389 = NOVALUE;
    object _5388 = NOVALUE;
    object _5387 = NOVALUE;
    object _5386 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:93		if atom(x) then*/
    _5386 = IS_ATOM(_x_9853);
    if (_5386 == 0)
    {
        _5386 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _5386 = NOVALUE;
    }

    /** text.e:94			return sprintf("%.10g", x)*/
    _5387 = EPrintf(-9999999, _765, _x_9853);
    DeRef(_x_9853);
    DeRef(_s_9854);
    return _5387;
    goto L2; // [19] 137
L1: 

    /** text.e:96			s = "{"*/
    RefDS(_1219);
    DeRef(_s_9854);
    _s_9854 = _1219;

    /** text.e:97			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_9853)){
            _5388 = SEQ_PTR(_x_9853)->length;
    }
    else {
        _5388 = 1;
    }
    {
        object _i_9860;
        _i_9860 = 1;
L3: 
        if (_i_9860 > _5388){
            goto L4; // [34] 98
        }

        /** text.e:98				if atom(x[i]) then*/
        _2 = (object)SEQ_PTR(_x_9853);
        _5389 = (object)*(((s1_ptr)_2)->base + _i_9860);
        _5390 = IS_ATOM(_5389);
        _5389 = NOVALUE;
        if (_5390 == 0)
        {
            _5390 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _5390 = NOVALUE;
        }

        /** text.e:99					s &= sprintf("%.10g", x[i])*/
        _2 = (object)SEQ_PTR(_x_9853);
        _5391 = (object)*(((s1_ptr)_2)->base + _i_9860);
        _5392 = EPrintf(-9999999, _765, _5391);
        _5391 = NOVALUE;
        Concat((object_ptr)&_s_9854, _s_9854, _5392);
        DeRefDS(_5392);
        _5392 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** text.e:101					s &= sprint(x[i])*/
        _2 = (object)SEQ_PTR(_x_9853);
        _5394 = (object)*(((s1_ptr)_2)->base + _i_9860);
        Ref(_5394);
        _5395 = _12sprint(_5394);
        _5394 = NOVALUE;
        if (IS_SEQUENCE(_s_9854) && IS_ATOM(_5395)) {
            Ref(_5395);
            Append(&_s_9854, _s_9854, _5395);
        }
        else if (IS_ATOM(_s_9854) && IS_SEQUENCE(_5395)) {
        }
        else {
            Concat((object_ptr)&_s_9854, _s_9854, _5395);
        }
        DeRef(_5395);
        _5395 = NOVALUE;
L6: 

        /** text.e:103				s &= ','*/
        Append(&_s_9854, _s_9854, 44);

        /** text.e:104			end for*/
        _i_9860 = _i_9860 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** text.e:105			if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_9854)){
            _5398 = SEQ_PTR(_s_9854)->length;
    }
    else {
        _5398 = 1;
    }
    _2 = (object)SEQ_PTR(_s_9854);
    _5399 = (object)*(((s1_ptr)_2)->base + _5398);
    if (binary_op_a(NOTEQ, _5399, 44)){
        _5399 = NOVALUE;
        goto L7; // [107] 123
    }
    _5399 = NOVALUE;

    /** text.e:106				s[$] = '}'*/
    if (IS_SEQUENCE(_s_9854)){
            _5401 = SEQ_PTR(_s_9854)->length;
    }
    else {
        _5401 = 1;
    }
    _2 = (object)SEQ_PTR(_s_9854);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _s_9854 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _5401);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** text.e:108				s &= '}'*/
    Append(&_s_9854, _s_9854, 125);
L8: 

    /** text.e:110			return s*/
    DeRef(_x_9853);
    DeRef(_5387);
    _5387 = NOVALUE;
    return _s_9854;
L2: 
    ;
}


object _12trim(object _source_9923, object _what_9924, object _ret_index_9925)
{
    object _rpos_9926 = NOVALUE;
    object _lpos_9927 = NOVALUE;
    object _5442 = NOVALUE;
    object _5440 = NOVALUE;
    object _5438 = NOVALUE;
    object _5436 = NOVALUE;
    object _5433 = NOVALUE;
    object _5432 = NOVALUE;
    object _5427 = NOVALUE;
    object _5426 = NOVALUE;
    object _5424 = NOVALUE;
    object _5422 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:243		if atom(what) then*/
    _5422 = 0;
    if (_5422 == 0)
    {
        _5422 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _5422 = NOVALUE;
    }

    /** text.e:244			what = {what}*/
    _0 = _what_9924;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_what_9924);
    ((intptr_t*)_2)[1] = _what_9924;
    _what_9924 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** text.e:247		lpos = 1*/
    _lpos_9927 = 1;

    /** text.e:248		while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_9923)){
            _5424 = SEQ_PTR(_source_9923)->length;
    }
    else {
        _5424 = 1;
    }
    if (_lpos_9927 > _5424)
    goto L3; // [33] 67

    /** text.e:249			if not find(source[lpos], what) then*/
    _2 = (object)SEQ_PTR(_source_9923);
    _5426 = (object)*(((s1_ptr)_2)->base + _lpos_9927);
    _5427 = find_from(_5426, _what_9924, 1);
    _5426 = NOVALUE;
    if (_5427 != 0)
    goto L4; // [48] 56
    _5427 = NOVALUE;

    /** text.e:250				exit*/
    goto L3; // [53] 67
L4: 

    /** text.e:252			lpos += 1*/
    _lpos_9927 = _lpos_9927 + 1;

    /** text.e:253		end while*/
    goto L2; // [64] 30
L3: 

    /** text.e:255		rpos = length(source)*/
    if (IS_SEQUENCE(_source_9923)){
            _rpos_9926 = SEQ_PTR(_source_9923)->length;
    }
    else {
        _rpos_9926 = 1;
    }

    /** text.e:256		while rpos > lpos do*/
L5: 
    if (_rpos_9926 <= _lpos_9927)
    goto L6; // [77] 111

    /** text.e:257			if not find(source[rpos], what) then*/
    _2 = (object)SEQ_PTR(_source_9923);
    _5432 = (object)*(((s1_ptr)_2)->base + _rpos_9926);
    _5433 = find_from(_5432, _what_9924, 1);
    _5432 = NOVALUE;
    if (_5433 != 0)
    goto L7; // [92] 100
    _5433 = NOVALUE;

    /** text.e:258				exit*/
    goto L6; // [97] 111
L7: 

    /** text.e:260			rpos -= 1*/
    _rpos_9926 = _rpos_9926 - 1;

    /** text.e:261		end while*/
    goto L5; // [108] 77
L6: 

    /** text.e:263		if ret_index then*/
    if (_ret_index_9925 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** text.e:264			return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _lpos_9927;
    ((intptr_t *)_2)[2] = _rpos_9926;
    _5436 = MAKE_SEQ(_1);
    DeRefDS(_source_9923);
    DeRef(_what_9924);
    return _5436;
    goto L9; // [126] 180
L8: 

    /** text.e:266			if lpos = 1 then*/
    if (_lpos_9927 != 1)
    goto LA; // [131] 152

    /** text.e:267				if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_9923)){
            _5438 = SEQ_PTR(_source_9923)->length;
    }
    else {
        _5438 = 1;
    }
    if (_rpos_9926 != _5438)
    goto LB; // [140] 151

    /** text.e:268					return source*/
    DeRef(_what_9924);
    DeRef(_5436);
    _5436 = NOVALUE;
    return _source_9923;
LB: 
LA: 

    /** text.e:271			if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_9923)){
            _5440 = SEQ_PTR(_source_9923)->length;
    }
    else {
        _5440 = 1;
    }
    if (_lpos_9927 <= _5440)
    goto LC; // [157] 168

    /** text.e:272				return {}*/
    RefDS(_5);
    DeRefDS(_source_9923);
    DeRef(_what_9924);
    DeRef(_5436);
    _5436 = NOVALUE;
    return _5;
LC: 

    /** text.e:274			return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_5442;
    RHS_Slice(_source_9923, _lpos_9927, _rpos_9926);
    DeRefDS(_source_9923);
    DeRef(_what_9924);
    DeRef(_5436);
    _5436 = NOVALUE;
    return _5442;
L9: 
    ;
}


object _12change_case(object _x_10136, object _api_10137)
{
    object _changed_text_10138 = NOVALUE;
    object _single_char_10139 = NOVALUE;
    object _len_10140 = NOVALUE;
    object _5571 = NOVALUE;
    object _5569 = NOVALUE;
    object _5567 = NOVALUE;
    object _5566 = NOVALUE;
    object _5563 = NOVALUE;
    object _5561 = NOVALUE;
    object _5559 = NOVALUE;
    object _5558 = NOVALUE;
    object _5557 = NOVALUE;
    object _5556 = NOVALUE;
    object _5555 = NOVALUE;
    object _5552 = NOVALUE;
    object _5550 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:464			integer single_char = 0*/
    _single_char_10139 = 0;

    /** text.e:467			if not string(x) then*/
    Ref(_x_10136);
    _5550 = _9string(_x_10136);
    if (IS_ATOM_INT(_5550)) {
        if (_5550 != 0){
            DeRef(_5550);
            _5550 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    else {
        if (DBL_PTR(_5550)->dbl != 0.0){
            DeRef(_5550);
            _5550 = NOVALUE;
            goto L1; // [12] 95
        }
    }
    DeRef(_5550);
    _5550 = NOVALUE;

    /** text.e:468				if atom(x) then*/
    _5552 = IS_ATOM(_x_10136);
    if (_5552 == 0)
    {
        _5552 = NOVALUE;
        goto L2; // [20] 50
    }
    else{
        _5552 = NOVALUE;
    }

    /** text.e:469					if x = 0 then*/
    if (binary_op_a(NOTEQ, _x_10136, 0)){
        goto L3; // [25] 36
    }

    /** text.e:470						return 0*/
    DeRef(_x_10136);
    DeRef(_api_10137);
    DeRefi(_changed_text_10138);
    return 0;
L3: 

    /** text.e:472					x = {x}*/
    _0 = _x_10136;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_x_10136);
    ((intptr_t*)_2)[1] = _x_10136;
    _x_10136 = MAKE_SEQ(_1);
    DeRef(_0);

    /** text.e:473					single_char = 1*/
    _single_char_10139 = 1;
    goto L4; // [47] 94
L2: 

    /** text.e:475					for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_10136)){
            _5555 = SEQ_PTR(_x_10136)->length;
    }
    else {
        _5555 = 1;
    }
    {
        object _i_10152;
        _i_10152 = 1;
L5: 
        if (_i_10152 > _5555){
            goto L6; // [55] 87
        }

        /** text.e:476						x[i] = change_case(x[i], api)*/
        _2 = (object)SEQ_PTR(_x_10136);
        _5556 = (object)*(((s1_ptr)_2)->base + _i_10152);
        Ref(_api_10137);
        DeRef(_5557);
        _5557 = _api_10137;
        Ref(_5556);
        _5558 = _12change_case(_5556, _5557);
        _5556 = NOVALUE;
        _5557 = NOVALUE;
        _2 = (object)SEQ_PTR(_x_10136);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_10136 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10152);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5558;
        if( _1 != _5558 ){
            DeRef(_1);
        }
        _5558 = NOVALUE;

        /** text.e:477					end for*/
        _i_10152 = _i_10152 + 1;
        goto L5; // [82] 62
L6: 
        ;
    }

    /** text.e:478					return x*/
    DeRef(_api_10137);
    DeRefi(_changed_text_10138);
    return _x_10136;
L4: 
L1: 

    /** text.e:481			if length(x) = 0 then*/
    if (IS_SEQUENCE(_x_10136)){
            _5559 = SEQ_PTR(_x_10136)->length;
    }
    else {
        _5559 = 1;
    }
    if (_5559 != 0)
    goto L7; // [100] 111

    /** text.e:482				return x*/
    DeRef(_api_10137);
    DeRefi(_changed_text_10138);
    return _x_10136;
L7: 

    /** text.e:484			if length(x) >= tm_size then*/
    if (IS_SEQUENCE(_x_10136)){
            _5561 = SEQ_PTR(_x_10136)->length;
    }
    else {
        _5561 = 1;
    }
    if (_5561 < _12tm_size_10130)
    goto L8; // [118] 148

    /** text.e:485				tm_size = length(x) + 1*/
    if (IS_SEQUENCE(_x_10136)){
            _5563 = SEQ_PTR(_x_10136)->length;
    }
    else {
        _5563 = 1;
    }
    _12tm_size_10130 = _5563 + 1;
    _5563 = NOVALUE;

    /** text.e:486				free(temp_mem)*/
    Ref(_12temp_mem_10131);
    _6free(_12temp_mem_10131);

    /** text.e:487				temp_mem = allocate(tm_size)*/
    _0 = _6allocate(_12tm_size_10130, 0);
    DeRef(_12temp_mem_10131);
    _12temp_mem_10131 = _0;
L8: 

    /** text.e:489			poke(temp_mem, x)*/
    if (IS_ATOM_INT(_12temp_mem_10131)){
        poke_addr = (uint8_t *)_12temp_mem_10131;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_12temp_mem_10131)->dbl);
    }
    if (IS_ATOM_INT(_x_10136)) {
        *poke_addr = (uint8_t)_x_10136;
    }
    else if (IS_ATOM(_x_10136)) {
        *poke_addr = (uint8_t)DBL_PTR(_x_10136)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_x_10136);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** text.e:490			len = c_func(api, {temp_mem, length(x)} )*/
    if (IS_SEQUENCE(_x_10136)){
            _5566 = SEQ_PTR(_x_10136)->length;
    }
    else {
        _5566 = 1;
    }
    Ref(_12temp_mem_10131);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12temp_mem_10131;
    ((intptr_t *)_2)[2] = _5566;
    _5567 = MAKE_SEQ(_1);
    _5566 = NOVALUE;
    _len_10140 = call_c(1, _api_10137, _5567);
    DeRefDS(_5567);
    _5567 = NOVALUE;
    if (!IS_ATOM_INT(_len_10140)) {
        _1 = (object)(DBL_PTR(_len_10140)->dbl);
        DeRefDS(_len_10140);
        _len_10140 = _1;
    }

    /** text.e:491			changed_text = peek({temp_mem, len})*/
    Ref(_12temp_mem_10131);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12temp_mem_10131;
    ((intptr_t *)_2)[2] = _len_10140;
    _5569 = MAKE_SEQ(_1);
    DeRefi(_changed_text_10138);
    _1 = (object)SEQ_PTR(_5569);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _changed_text_10138 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_5569);
    _5569 = NOVALUE;

    /** text.e:492			if single_char then*/
    if (_single_char_10139 == 0)
    {
        goto L9; // [188] 204
    }
    else{
    }

    /** text.e:493				return changed_text[1]*/
    _2 = (object)SEQ_PTR(_changed_text_10138);
    _5571 = (object)*(((s1_ptr)_2)->base + 1);
    DeRef(_x_10136);
    DeRef(_api_10137);
    DeRefDSi(_changed_text_10138);
    return _5571;
    goto LA; // [201] 211
L9: 

    /** text.e:495				return changed_text*/
    DeRef(_x_10136);
    DeRef(_api_10137);
    _5571 = NOVALUE;
    return _changed_text_10138;
LA: 
    ;
}


object _12lower(object _x_10178)
{
    object _5575 = NOVALUE;
    object _5572 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:535		if length(lower_case_SET) != 0 then*/
    _5572 = 0;

    /** text.e:539		ifdef WINDOWS then*/

    /** text.e:540			return change_case(x, api_CharLowerBuff)*/
    Ref(_x_10178);
    Ref(_12api_CharLowerBuff_10114);
    _5575 = _12change_case(_x_10178, _12api_CharLowerBuff_10114);
    DeRef(_x_10178);
    return _5575;
    ;
}


object _12upper(object _x_10186)
{
    object _5579 = NOVALUE;
    object _5576 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:581		if length(upper_case_SET) != 0 then*/
    _5576 = 0;

    /** text.e:584		ifdef WINDOWS then*/

    /** text.e:585			return change_case(x, api_CharUpperBuff)*/
    Ref(_x_10186);
    Ref(_12api_CharUpperBuff_10122);
    _5579 = _12change_case(_x_10186, _12api_CharUpperBuff_10122);
    DeRef(_x_10186);
    return _5579;
    ;
}


object _12proper(object _x_10194)
{
    object _pos_10195 = NOVALUE;
    object _inword_10196 = NOVALUE;
    object _convert_10197 = NOVALUE;
    object _res_10198 = NOVALUE;
    object _5608 = NOVALUE;
    object _5607 = NOVALUE;
    object _5606 = NOVALUE;
    object _5605 = NOVALUE;
    object _5604 = NOVALUE;
    object _5603 = NOVALUE;
    object _5602 = NOVALUE;
    object _5601 = NOVALUE;
    object _5600 = NOVALUE;
    object _5599 = NOVALUE;
    object _5597 = NOVALUE;
    object _5596 = NOVALUE;
    object _5592 = NOVALUE;
    object _5589 = NOVALUE;
    object _5586 = NOVALUE;
    object _5583 = NOVALUE;
    object _5582 = NOVALUE;
    object _5581 = NOVALUE;
    object _5580 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:633		inword = 0	-- Initially not in a word*/
    _inword_10196 = 0;

    /** text.e:634		convert = 1	-- Initially convert text*/
    _convert_10197 = 1;

    /** text.e:635		res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_10194);
    DeRef(_res_10198);
    _res_10198 = _x_10194;

    /** text.e:636		for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_10198)){
            _5580 = SEQ_PTR(_res_10198)->length;
    }
    else {
        _5580 = 1;
    }
    {
        object _i_10200;
        _i_10200 = 1;
L1: 
        if (_i_10200 > _5580){
            goto L2; // [25] 298
        }

        /** text.e:637			if integer(res[i]) then*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5581 = (object)*(((s1_ptr)_2)->base + _i_10200);
        if (IS_ATOM_INT(_5581))
        _5582 = 1;
        else if (IS_ATOM_DBL(_5581))
        _5582 = IS_ATOM_INT(DoubleToInt(_5581));
        else
        _5582 = 0;
        _5581 = NOVALUE;
        if (_5582 == 0)
        {
            _5582 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _5582 = NOVALUE;
        }

        /** text.e:638				if convert then*/
        if (_convert_10197 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** text.e:640					pos = types:t_upper(res[i])*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5583 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5583);
        _pos_10195 = _9t_upper(_5583);
        _5583 = NOVALUE;
        if (!IS_ATOM_INT(_pos_10195)) {
            _1 = (object)(DBL_PTR(_pos_10195)->dbl);
            DeRefDS(_pos_10195);
            _pos_10195 = _1;
        }

        /** text.e:641					if pos = 0 then*/
        if (_pos_10195 != 0)
        goto L5; // [63] 175

        /** text.e:643						pos = types:t_lower(res[i])*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5586 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5586);
        _pos_10195 = _9t_lower(_5586);
        _5586 = NOVALUE;
        if (!IS_ATOM_INT(_pos_10195)) {
            _1 = (object)(DBL_PTR(_pos_10195)->dbl);
            DeRefDS(_pos_10195);
            _pos_10195 = _1;
        }

        /** text.e:644						if pos = 0 then*/
        if (_pos_10195 != 0)
        goto L6; // [81] 138

        /** text.e:647							pos = t_digit(res[i])*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5589 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5589);
        _pos_10195 = _9t_digit(_5589);
        _5589 = NOVALUE;
        if (!IS_ATOM_INT(_pos_10195)) {
            _1 = (object)(DBL_PTR(_pos_10195)->dbl);
            DeRefDS(_pos_10195);
            _pos_10195 = _1;
        }

        /** text.e:648							if pos = 0 then*/
        if (_pos_10195 != 0)
        goto L4; // [99] 291

        /** text.e:650								pos = t_specword(res[i])*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5592 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5592);
        _pos_10195 = _9t_specword(_5592);
        _5592 = NOVALUE;
        if (!IS_ATOM_INT(_pos_10195)) {
            _1 = (object)(DBL_PTR(_pos_10195)->dbl);
            DeRefDS(_pos_10195);
            _pos_10195 = _1;
        }

        /** text.e:651								if pos then*/
        if (_pos_10195 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** text.e:652									inword = 1*/
        _inword_10196 = 1;
        goto L4; // [125] 291
L7: 

        /** text.e:654									inword = 0*/
        _inword_10196 = 0;
        goto L4; // [135] 291
L6: 

        /** text.e:658							if inword = 0 then*/
        if (_inword_10196 != 0)
        goto L4; // [140] 291

        /** text.e:660								if pos <= 26 then*/
        if (_pos_10195 > 26)
        goto L8; // [146] 165

        /** text.e:661									res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5596 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5596);
        _5597 = _12upper(_5596);
        _5596 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_10198);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_10198 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10200);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5597;
        if( _1 != _5597 ){
            DeRef(_1);
        }
        _5597 = NOVALUE;
L8: 

        /** text.e:663								inword = 1	-- now we are in a word*/
        _inword_10196 = 1;
        goto L4; // [172] 291
L5: 

        /** text.e:667						if inword = 1 then*/
        if (_inword_10196 != 1)
        goto L9; // [177] 198

        /** text.e:669							res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5599 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5599);
        _5600 = _12lower(_5599);
        _5599 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_10198);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_10198 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10200);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5600;
        if( _1 != _5600 ){
            DeRef(_1);
        }
        _5600 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** text.e:671							inword = 1	-- now we are in a word*/
        _inword_10196 = 1;
        goto L4; // [206] 291
L3: 

        /** text.e:678				if convert then*/
        if (_convert_10197 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** text.e:680					for j = 1 to i-1 do*/
        _5601 = _i_10200 - 1;
        {
            object _j_10240;
            _j_10240 = 1;
LB: 
            if (_j_10240 > _5601){
                goto LC; // [220] 257
            }

            /** text.e:681						if atom(x[j]) then*/
            _2 = (object)SEQ_PTR(_x_10194);
            _5602 = (object)*(((s1_ptr)_2)->base + _j_10240);
            _5603 = IS_ATOM(_5602);
            _5602 = NOVALUE;
            if (_5603 == 0)
            {
                _5603 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _5603 = NOVALUE;
            }

            /** text.e:682							res[j] = x[j]*/
            _2 = (object)SEQ_PTR(_x_10194);
            _5604 = (object)*(((s1_ptr)_2)->base + _j_10240);
            Ref(_5604);
            _2 = (object)SEQ_PTR(_res_10198);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _res_10198 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_10240);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _5604;
            if( _1 != _5604 ){
                DeRef(_1);
            }
            _5604 = NOVALUE;
LD: 

            /** text.e:684					end for*/
            _j_10240 = _j_10240 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** text.e:686					convert = 0*/
        _convert_10197 = 0;
LA: 

        /** text.e:689				if sequence(res[i]) then*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5605 = (object)*(((s1_ptr)_2)->base + _i_10200);
        _5606 = IS_SEQUENCE(_5605);
        _5605 = NOVALUE;
        if (_5606 == 0)
        {
            _5606 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _5606 = NOVALUE;
        }

        /** text.e:690					res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (object)SEQ_PTR(_res_10198);
        _5607 = (object)*(((s1_ptr)_2)->base + _i_10200);
        Ref(_5607);
        _5608 = _12proper(_5607);
        _5607 = NOVALUE;
        _2 = (object)SEQ_PTR(_res_10198);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _res_10198 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10200);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5608;
        if( _1 != _5608 ){
            DeRef(_1);
        }
        _5608 = NOVALUE;
LE: 
L4: 

        /** text.e:693		end for*/
        _i_10200 = _i_10200 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** text.e:694		return res*/
    DeRefDS(_x_10194);
    DeRef(_5601);
    _5601 = NOVALUE;
    return _res_10198;
    ;
}


object _12quote(object _text_in_10516, object _quote_pair_10517, object _esc_10519, object _sp_10521)
{
    object _5879 = NOVALUE;
    object _5878 = NOVALUE;
    object _5877 = NOVALUE;
    object _5875 = NOVALUE;
    object _5874 = NOVALUE;
    object _5873 = NOVALUE;
    object _5871 = NOVALUE;
    object _5870 = NOVALUE;
    object _5869 = NOVALUE;
    object _5868 = NOVALUE;
    object _5867 = NOVALUE;
    object _5866 = NOVALUE;
    object _5865 = NOVALUE;
    object _5864 = NOVALUE;
    object _5863 = NOVALUE;
    object _5861 = NOVALUE;
    object _5860 = NOVALUE;
    object _5859 = NOVALUE;
    object _5857 = NOVALUE;
    object _5856 = NOVALUE;
    object _5855 = NOVALUE;
    object _5854 = NOVALUE;
    object _5853 = NOVALUE;
    object _5852 = NOVALUE;
    object _5851 = NOVALUE;
    object _5850 = NOVALUE;
    object _5849 = NOVALUE;
    object _5847 = NOVALUE;
    object _5846 = NOVALUE;
    object _5844 = NOVALUE;
    object _5843 = NOVALUE;
    object _5842 = NOVALUE;
    object _5840 = NOVALUE;
    object _5839 = NOVALUE;
    object _5838 = NOVALUE;
    object _5837 = NOVALUE;
    object _5836 = NOVALUE;
    object _5835 = NOVALUE;
    object _5834 = NOVALUE;
    object _5833 = NOVALUE;
    object _5832 = NOVALUE;
    object _5831 = NOVALUE;
    object _5830 = NOVALUE;
    object _5829 = NOVALUE;
    object _5828 = NOVALUE;
    object _5827 = NOVALUE;
    object _5826 = NOVALUE;
    object _5825 = NOVALUE;
    object _5824 = NOVALUE;
    object _5821 = NOVALUE;
    object _5820 = NOVALUE;
    object _5819 = NOVALUE;
    object _5818 = NOVALUE;
    object _5817 = NOVALUE;
    object _5816 = NOVALUE;
    object _5815 = NOVALUE;
    object _5814 = NOVALUE;
    object _5813 = NOVALUE;
    object _5812 = NOVALUE;
    object _5811 = NOVALUE;
    object _5810 = NOVALUE;
    object _5809 = NOVALUE;
    object _5808 = NOVALUE;
    object _5805 = NOVALUE;
    object _5803 = NOVALUE;
    object _5802 = NOVALUE;
    object _5800 = NOVALUE;
    object _5798 = NOVALUE;
    object _5797 = NOVALUE;
    object _5796 = NOVALUE;
    object _5794 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:1118		if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_10516)){
            _5794 = SEQ_PTR(_text_in_10516)->length;
    }
    else {
        _5794 = 1;
    }
    if (_5794 != 0)
    goto L1; // [10] 21

    /** text.e:1119			return text_in*/
    DeRef(_quote_pair_10517);
    DeRef(_sp_10521);
    return _text_in_10516;
L1: 

    /** text.e:1122		if atom(quote_pair) then*/
    _5796 = IS_ATOM(_quote_pair_10517);
    if (_5796 == 0)
    {
        _5796 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _5796 = NOVALUE;
    }

    /** text.e:1123			quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_quote_pair_10517);
    ((intptr_t*)_2)[1] = _quote_pair_10517;
    _5797 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_quote_pair_10517);
    ((intptr_t*)_2)[1] = _quote_pair_10517;
    _5798 = MAKE_SEQ(_1);
    DeRef(_quote_pair_10517);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5797;
    ((intptr_t *)_2)[2] = _5798;
    _quote_pair_10517 = MAKE_SEQ(_1);
    _5798 = NOVALUE;
    _5797 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** text.e:1124		elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_10517)){
            _5800 = SEQ_PTR(_quote_pair_10517)->length;
    }
    else {
        _5800 = 1;
    }
    if (_5800 != 1)
    goto L4; // [51] 72

    /** text.e:1125			quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5802 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5803 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_5803);
    Ref(_5802);
    DeRef(_quote_pair_10517);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5802;
    ((intptr_t *)_2)[2] = _5803;
    _quote_pair_10517 = MAKE_SEQ(_1);
    _5803 = NOVALUE;
    _5802 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** text.e:1126		elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_10517)){
            _5805 = SEQ_PTR(_quote_pair_10517)->length;
    }
    else {
        _5805 = 1;
    }
    if (_5805 != 0)
    goto L5; // [77] 88

    /** text.e:1127			quote_pair = {"\"", "\""}*/
    RefDS(_5786);
    RefDS(_5786);
    DeRef(_quote_pair_10517);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _5786;
    ((intptr_t *)_2)[2] = _5786;
    _quote_pair_10517 = MAKE_SEQ(_1);
L5: 
L3: 

    /** text.e:1130		if sequence(text_in[1]) then*/
    _2 = (object)SEQ_PTR(_text_in_10516);
    _5808 = (object)*(((s1_ptr)_2)->base + 1);
    _5809 = IS_SEQUENCE(_5808);
    _5808 = NOVALUE;
    if (_5809 == 0)
    {
        _5809 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _5809 = NOVALUE;
    }

    /** text.e:1131			for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_10516)){
            _5810 = SEQ_PTR(_text_in_10516)->length;
    }
    else {
        _5810 = 1;
    }
    {
        object _i_10544;
        _i_10544 = 1;
L7: 
        if (_i_10544 > _5810){
            goto L8; // [106] 159
        }

        /** text.e:1132				if sequence(text_in[i]) then*/
        _2 = (object)SEQ_PTR(_text_in_10516);
        _5811 = (object)*(((s1_ptr)_2)->base + _i_10544);
        _5812 = IS_SEQUENCE(_5811);
        _5811 = NOVALUE;
        if (_5812 == 0)
        {
            _5812 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _5812 = NOVALUE;
        }

        /** text.e:1133					text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (object)SEQ_PTR(_text_in_10516);
        _5813 = (object)*(((s1_ptr)_2)->base + _i_10544);
        Ref(_quote_pair_10517);
        DeRef(_5814);
        _5814 = _quote_pair_10517;
        DeRef(_5815);
        _5815 = _esc_10519;
        Ref(_sp_10521);
        DeRef(_5816);
        _5816 = _sp_10521;
        Ref(_5813);
        _5817 = _12quote(_5813, _5814, _5815, _5816);
        _5813 = NOVALUE;
        _5814 = NOVALUE;
        _5815 = NOVALUE;
        _5816 = NOVALUE;
        _2 = (object)SEQ_PTR(_text_in_10516);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _text_in_10516 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10544);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5817;
        if( _1 != _5817 ){
            DeRef(_1);
        }
        _5817 = NOVALUE;
L9: 

        /** text.e:1135			end for*/
        _i_10544 = _i_10544 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** text.e:1137			return text_in*/
    DeRef(_quote_pair_10517);
    DeRef(_sp_10521);
    return _text_in_10516;
L6: 

    /** text.e:1141		for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_10521)){
            _5818 = SEQ_PTR(_sp_10521)->length;
    }
    else {
        _5818 = 1;
    }
    {
        object _i_10555;
        _i_10555 = 1;
LA: 
        if (_i_10555 > _5818){
            goto LB; // [171] 220
        }

        /** text.e:1142			if find(sp[i], text_in) then*/
        _2 = (object)SEQ_PTR(_sp_10521);
        _5819 = (object)*(((s1_ptr)_2)->base + _i_10555);
        _5820 = find_from(_5819, _text_in_10516, 1);
        _5819 = NOVALUE;
        if (_5820 == 0)
        {
            _5820 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _5820 = NOVALUE;
        }

        /** text.e:1143				exit*/
        goto LB; // [194] 220
LC: 

        /** text.e:1146			if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_10521)){
                _5821 = SEQ_PTR(_sp_10521)->length;
        }
        else {
            _5821 = 1;
        }
        if (_i_10555 != _5821)
        goto LD; // [202] 213

        /** text.e:1148				return text_in*/
        DeRef(_quote_pair_10517);
        DeRef(_sp_10521);
        return _text_in_10516;
LD: 

        /** text.e:1150		end for*/
        _i_10555 = _i_10555 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** text.e:1152		if esc >= 0  then*/
    if (_esc_10519 < 0)
    goto LE; // [222] 561

    /** text.e:1156			if atom(quote_pair[1]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5824 = (object)*(((s1_ptr)_2)->base + 1);
    _5825 = IS_ATOM(_5824);
    _5824 = NOVALUE;
    if (_5825 == 0)
    {
        _5825 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _5825 = NOVALUE;
    }

    /** text.e:1157				quote_pair[1] = {quote_pair[1]}*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5826 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_5826);
    ((intptr_t*)_2)[1] = _5826;
    _5827 = MAKE_SEQ(_1);
    _5826 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _quote_pair_10517 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5827;
    if( _1 != _5827 ){
        DeRef(_1);
    }
    _5827 = NOVALUE;
LF: 

    /** text.e:1159			if atom(quote_pair[2]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5828 = (object)*(((s1_ptr)_2)->base + 2);
    _5829 = IS_ATOM(_5828);
    _5828 = NOVALUE;
    if (_5829 == 0)
    {
        _5829 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _5829 = NOVALUE;
    }

    /** text.e:1160				quote_pair[2] = {quote_pair[2]}*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5830 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_5830);
    ((intptr_t*)_2)[1] = _5830;
    _5831 = MAKE_SEQ(_1);
    _5830 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _quote_pair_10517 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5831;
    if( _1 != _5831 ){
        DeRef(_1);
    }
    _5831 = NOVALUE;
L10: 

    /** text.e:1163			if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5832 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5833 = (object)*(((s1_ptr)_2)->base + 2);
    if (_5832 == _5833)
    _5834 = 1;
    else if (IS_ATOM_INT(_5832) && IS_ATOM_INT(_5833))
    _5834 = 0;
    else
    _5834 = (compare(_5832, _5833) == 0);
    _5832 = NOVALUE;
    _5833 = NOVALUE;
    if (_5834 == 0)
    {
        _5834 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _5834 = NOVALUE;
    }

    /** text.e:1165				if match(quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5835 = (object)*(((s1_ptr)_2)->base + 1);
    _5836 = e_match_from(_5835, _text_in_10516, 1);
    _5835 = NOVALUE;
    if (_5836 == 0)
    {
        _5836 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _5836 = NOVALUE;
    }

    /** text.e:1166					if match(esc & quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5837 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5837)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5837)) {
        Prepend(&_5838, _5837, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5838, _esc_10519, _5837);
    }
    _5837 = NOVALUE;
    _5839 = e_match_from(_5838, _text_in_10516, 1);
    DeRefDS(_5838);
    _5838 = NOVALUE;
    if (_5839 == 0)
    {
        _5839 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _5839 = NOVALUE;
    }

    /** text.e:1167						text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_5840, _esc_10519, _esc_10519);
    RefDS(_text_in_10516);
    _0 = _text_in_10516;
    _text_in_10516 = _14match_replace(_esc_10519, _text_in_10516, _5840, 0);
    DeRefDS(_0);
    _5840 = NOVALUE;
L13: 

    /** text.e:1169					text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5842 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5843 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5843)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5843)) {
        Prepend(&_5844, _5843, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5844, _esc_10519, _5843);
    }
    _5843 = NOVALUE;
    Ref(_5842);
    RefDS(_text_in_10516);
    _0 = _text_in_10516;
    _text_in_10516 = _14match_replace(_5842, _text_in_10516, _5844, 0);
    DeRefDS(_0);
    _5842 = NOVALUE;
    _5844 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** text.e:1172				if match(quote_pair[1], text_in) or*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5846 = (object)*(((s1_ptr)_2)->base + 1);
    _5847 = e_match_from(_5846, _text_in_10516, 1);
    _5846 = NOVALUE;
    if (_5847 != 0) {
        goto L14; // [383] 401
    }
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5849 = (object)*(((s1_ptr)_2)->base + 2);
    _5850 = e_match_from(_5849, _text_in_10516, 1);
    _5849 = NOVALUE;
    if (_5850 == 0)
    {
        _5850 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _5850 = NOVALUE;
    }
L14: 

    /** text.e:1174					if match(esc & quote_pair[1], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5851 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5851)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5851)) {
        Prepend(&_5852, _5851, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5852, _esc_10519, _5851);
    }
    _5851 = NOVALUE;
    _5853 = e_match_from(_5852, _text_in_10516, 1);
    DeRefDS(_5852);
    _5852 = NOVALUE;
    if (_5853 == 0)
    {
        _5853 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _5853 = NOVALUE;
    }

    /** text.e:1175						text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5854 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5854)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5854)) {
        Prepend(&_5855, _5854, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5855, _esc_10519, _5854);
    }
    _5854 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5856 = (object)*(((s1_ptr)_2)->base + 1);
    {
        object concat_list[3];

        concat_list[0] = _5856;
        concat_list[1] = _esc_10519;
        concat_list[2] = _esc_10519;
        Concat_N((object_ptr)&_5857, concat_list, 3);
    }
    _5856 = NOVALUE;
    RefDS(_text_in_10516);
    _0 = _text_in_10516;
    _text_in_10516 = _14match_replace(_5855, _text_in_10516, _5857, 0);
    DeRefDS(_0);
    _5855 = NOVALUE;
    _5857 = NOVALUE;
L16: 

    /** text.e:1177					text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5859 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5860 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5860)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5860)) {
        Prepend(&_5861, _5860, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5861, _esc_10519, _5860);
    }
    _5860 = NOVALUE;
    Ref(_5859);
    RefDS(_text_in_10516);
    _0 = _text_in_10516;
    _text_in_10516 = _14match_replace(_5859, _text_in_10516, _5861, 0);
    DeRefDS(_0);
    _5859 = NOVALUE;
    _5861 = NOVALUE;
L15: 

    /** text.e:1180				if match(quote_pair[2], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5863 = (object)*(((s1_ptr)_2)->base + 2);
    _5864 = e_match_from(_5863, _text_in_10516, 1);
    _5863 = NOVALUE;
    if (_5864 == 0)
    {
        _5864 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _5864 = NOVALUE;
    }

    /** text.e:1181					if match(esc & quote_pair[2], text_in) then*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5865 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5865)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5865)) {
        Prepend(&_5866, _5865, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5866, _esc_10519, _5865);
    }
    _5865 = NOVALUE;
    _5867 = e_match_from(_5866, _text_in_10516, 1);
    DeRefDS(_5866);
    _5866 = NOVALUE;
    if (_5867 == 0)
    {
        _5867 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _5867 = NOVALUE;
    }

    /** text.e:1182						text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5868 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5868)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5868)) {
        Prepend(&_5869, _5868, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5869, _esc_10519, _5868);
    }
    _5868 = NOVALUE;
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5870 = (object)*(((s1_ptr)_2)->base + 2);
    {
        object concat_list[3];

        concat_list[0] = _5870;
        concat_list[1] = _esc_10519;
        concat_list[2] = _esc_10519;
        Concat_N((object_ptr)&_5871, concat_list, 3);
    }
    _5870 = NOVALUE;
    RefDS(_text_in_10516);
    _0 = _text_in_10516;
    _text_in_10516 = _14match_replace(_5869, _text_in_10516, _5871, 0);
    DeRefDS(_0);
    _5869 = NOVALUE;
    _5871 = NOVALUE;
L18: 

    /** text.e:1184					text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5873 = (object)*(((s1_ptr)_2)->base + 2);
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5874 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_10519) && IS_ATOM(_5874)) {
    }
    else if (IS_ATOM(_esc_10519) && IS_SEQUENCE(_5874)) {
        Prepend(&_5875, _5874, _esc_10519);
    }
    else {
        Concat((object_ptr)&_5875, _esc_10519, _5874);
    }
    _5874 = NOVALUE;
    Ref(_5873);
    RefDS(_text_in_10516);
    _0 = _text_in_10516;
    _text_in_10516 = _14match_replace(_5873, _text_in_10516, _5875, 0);
    DeRefDS(_0);
    _5873 = NOVALUE;
    _5875 = NOVALUE;
L17: 
L12: 
LE: 

    /** text.e:1189		return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5877 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_quote_pair_10517);
    _5878 = (object)*(((s1_ptr)_2)->base + 2);
    {
        object concat_list[3];

        concat_list[0] = _5878;
        concat_list[1] = _text_in_10516;
        concat_list[2] = _5877;
        Concat_N((object_ptr)&_5879, concat_list, 3);
    }
    _5878 = NOVALUE;
    _5877 = NOVALUE;
    DeRefDS(_text_in_10516);
    DeRef(_quote_pair_10517);
    DeRef(_sp_10521);
    return _5879;
    ;
}


object _12format(object _format_pattern_10737, object _arg_list_10738)
{
    object _result_10739 = NOVALUE;
    object _in_token_10740 = NOVALUE;
    object _tch_10741 = NOVALUE;
    object _i_10742 = NOVALUE;
    object _tend_10743 = NOVALUE;
    object _cap_10744 = NOVALUE;
    object _align_10745 = NOVALUE;
    object _psign_10746 = NOVALUE;
    object _msign_10747 = NOVALUE;
    object _zfill_10748 = NOVALUE;
    object _bwz_10749 = NOVALUE;
    object _spacer_10750 = NOVALUE;
    object _alt_10751 = NOVALUE;
    object _width_10752 = NOVALUE;
    object _decs_10753 = NOVALUE;
    object _pos_10754 = NOVALUE;
    object _argn_10755 = NOVALUE;
    object _argl_10756 = NOVALUE;
    object _trimming_10757 = NOVALUE;
    object _hexout_10758 = NOVALUE;
    object _binout_10759 = NOVALUE;
    object _tsep_10760 = NOVALUE;
    object _istext_10761 = NOVALUE;
    object _prevargv_10762 = NOVALUE;
    object _currargv_10763 = NOVALUE;
    object _idname_10764 = NOVALUE;
    object _envsym_10765 = NOVALUE;
    object _envvar_10766 = NOVALUE;
    object _ep_10767 = NOVALUE;
    object _pflag_10768 = NOVALUE;
    object _count_10769 = NOVALUE;
    object _sp_10841 = NOVALUE;
    object _sp_10876 = NOVALUE;
    object _argtext_10923 = NOVALUE;
    object _tempv_11168 = NOVALUE;
    object _pretty_sprint_inlined_pretty_sprint_at_2521_11223 = NOVALUE;
    object _options_inlined_pretty_sprint_at_2518_11222 = NOVALUE;
    object _pretty_sprint_inlined_pretty_sprint_at_2577_11230 = NOVALUE;
    object _options_inlined_pretty_sprint_at_2574_11229 = NOVALUE;
    object _x_inlined_pretty_sprint_at_2571_11228 = NOVALUE;
    object _msg_inlined_crash_at_2725_11252 = NOVALUE;
    object _dpos_11314 = NOVALUE;
    object _dist_11315 = NOVALUE;
    object _bracketed_11316 = NOVALUE;
    object _6411 = NOVALUE;
    object _6410 = NOVALUE;
    object _6409 = NOVALUE;
    object _6407 = NOVALUE;
    object _6406 = NOVALUE;
    object _6405 = NOVALUE;
    object _6402 = NOVALUE;
    object _6401 = NOVALUE;
    object _6398 = NOVALUE;
    object _6396 = NOVALUE;
    object _6393 = NOVALUE;
    object _6392 = NOVALUE;
    object _6391 = NOVALUE;
    object _6388 = NOVALUE;
    object _6385 = NOVALUE;
    object _6384 = NOVALUE;
    object _6383 = NOVALUE;
    object _6382 = NOVALUE;
    object _6379 = NOVALUE;
    object _6378 = NOVALUE;
    object _6377 = NOVALUE;
    object _6374 = NOVALUE;
    object _6372 = NOVALUE;
    object _6369 = NOVALUE;
    object _6368 = NOVALUE;
    object _6367 = NOVALUE;
    object _6366 = NOVALUE;
    object _6363 = NOVALUE;
    object _6358 = NOVALUE;
    object _6357 = NOVALUE;
    object _6356 = NOVALUE;
    object _6355 = NOVALUE;
    object _6353 = NOVALUE;
    object _6352 = NOVALUE;
    object _6351 = NOVALUE;
    object _6350 = NOVALUE;
    object _6349 = NOVALUE;
    object _6348 = NOVALUE;
    object _6347 = NOVALUE;
    object _6342 = NOVALUE;
    object _6338 = NOVALUE;
    object _6337 = NOVALUE;
    object _6335 = NOVALUE;
    object _6333 = NOVALUE;
    object _6332 = NOVALUE;
    object _6331 = NOVALUE;
    object _6330 = NOVALUE;
    object _6329 = NOVALUE;
    object _6326 = NOVALUE;
    object _6324 = NOVALUE;
    object _6323 = NOVALUE;
    object _6322 = NOVALUE;
    object _6321 = NOVALUE;
    object _6318 = NOVALUE;
    object _6317 = NOVALUE;
    object _6315 = NOVALUE;
    object _6314 = NOVALUE;
    object _6313 = NOVALUE;
    object _6312 = NOVALUE;
    object _6311 = NOVALUE;
    object _6308 = NOVALUE;
    object _6307 = NOVALUE;
    object _6306 = NOVALUE;
    object _6303 = NOVALUE;
    object _6302 = NOVALUE;
    object _6300 = NOVALUE;
    object _6296 = NOVALUE;
    object _6295 = NOVALUE;
    object _6293 = NOVALUE;
    object _6292 = NOVALUE;
    object _6284 = NOVALUE;
    object _6280 = NOVALUE;
    object _6278 = NOVALUE;
    object _6277 = NOVALUE;
    object _6276 = NOVALUE;
    object _6273 = NOVALUE;
    object _6271 = NOVALUE;
    object _6270 = NOVALUE;
    object _6269 = NOVALUE;
    object _6267 = NOVALUE;
    object _6266 = NOVALUE;
    object _6265 = NOVALUE;
    object _6264 = NOVALUE;
    object _6261 = NOVALUE;
    object _6260 = NOVALUE;
    object _6259 = NOVALUE;
    object _6257 = NOVALUE;
    object _6256 = NOVALUE;
    object _6255 = NOVALUE;
    object _6254 = NOVALUE;
    object _6252 = NOVALUE;
    object _6250 = NOVALUE;
    object _6248 = NOVALUE;
    object _6246 = NOVALUE;
    object _6244 = NOVALUE;
    object _6242 = NOVALUE;
    object _6241 = NOVALUE;
    object _6240 = NOVALUE;
    object _6239 = NOVALUE;
    object _6238 = NOVALUE;
    object _6237 = NOVALUE;
    object _6235 = NOVALUE;
    object _6234 = NOVALUE;
    object _6232 = NOVALUE;
    object _6231 = NOVALUE;
    object _6229 = NOVALUE;
    object _6227 = NOVALUE;
    object _6226 = NOVALUE;
    object _6223 = NOVALUE;
    object _6221 = NOVALUE;
    object _6217 = NOVALUE;
    object _6215 = NOVALUE;
    object _6214 = NOVALUE;
    object _6213 = NOVALUE;
    object _6211 = NOVALUE;
    object _6210 = NOVALUE;
    object _6209 = NOVALUE;
    object _6208 = NOVALUE;
    object _6207 = NOVALUE;
    object _6205 = NOVALUE;
    object _6203 = NOVALUE;
    object _6202 = NOVALUE;
    object _6201 = NOVALUE;
    object _6200 = NOVALUE;
    object _6196 = NOVALUE;
    object _6193 = NOVALUE;
    object _6192 = NOVALUE;
    object _6189 = NOVALUE;
    object _6188 = NOVALUE;
    object _6187 = NOVALUE;
    object _6185 = NOVALUE;
    object _6184 = NOVALUE;
    object _6183 = NOVALUE;
    object _6182 = NOVALUE;
    object _6180 = NOVALUE;
    object _6178 = NOVALUE;
    object _6177 = NOVALUE;
    object _6176 = NOVALUE;
    object _6175 = NOVALUE;
    object _6174 = NOVALUE;
    object _6173 = NOVALUE;
    object _6171 = NOVALUE;
    object _6170 = NOVALUE;
    object _6169 = NOVALUE;
    object _6167 = NOVALUE;
    object _6166 = NOVALUE;
    object _6165 = NOVALUE;
    object _6164 = NOVALUE;
    object _6162 = NOVALUE;
    object _6159 = NOVALUE;
    object _6158 = NOVALUE;
    object _6156 = NOVALUE;
    object _6155 = NOVALUE;
    object _6153 = NOVALUE;
    object _6150 = NOVALUE;
    object _6149 = NOVALUE;
    object _6146 = NOVALUE;
    object _6144 = NOVALUE;
    object _6140 = NOVALUE;
    object _6138 = NOVALUE;
    object _6137 = NOVALUE;
    object _6136 = NOVALUE;
    object _6134 = NOVALUE;
    object _6132 = NOVALUE;
    object _6131 = NOVALUE;
    object _6130 = NOVALUE;
    object _6129 = NOVALUE;
    object _6128 = NOVALUE;
    object _6126 = NOVALUE;
    object _6124 = NOVALUE;
    object _6123 = NOVALUE;
    object _6122 = NOVALUE;
    object _6121 = NOVALUE;
    object _6119 = NOVALUE;
    object _6116 = NOVALUE;
    object _6114 = NOVALUE;
    object _6113 = NOVALUE;
    object _6112 = NOVALUE;
    object _6111 = NOVALUE;
    object _6110 = NOVALUE;
    object _6108 = NOVALUE;
    object _6107 = NOVALUE;
    object _6106 = NOVALUE;
    object _6104 = NOVALUE;
    object _6103 = NOVALUE;
    object _6102 = NOVALUE;
    object _6101 = NOVALUE;
    object _6099 = NOVALUE;
    object _6098 = NOVALUE;
    object _6097 = NOVALUE;
    object _6094 = NOVALUE;
    object _6093 = NOVALUE;
    object _6092 = NOVALUE;
    object _6091 = NOVALUE;
    object _6089 = NOVALUE;
    object _6088 = NOVALUE;
    object _6087 = NOVALUE;
    object _6086 = NOVALUE;
    object _6083 = NOVALUE;
    object _6082 = NOVALUE;
    object _6081 = NOVALUE;
    object _6079 = NOVALUE;
    object _6078 = NOVALUE;
    object _6077 = NOVALUE;
    object _6076 = NOVALUE;
    object _6073 = NOVALUE;
    object _6072 = NOVALUE;
    object _6071 = NOVALUE;
    object _6070 = NOVALUE;
    object _6068 = NOVALUE;
    object _6067 = NOVALUE;
    object _6066 = NOVALUE;
    object _6064 = NOVALUE;
    object _6063 = NOVALUE;
    object _6062 = NOVALUE;
    object _6060 = NOVALUE;
    object _6053 = NOVALUE;
    object _6051 = NOVALUE;
    object _6050 = NOVALUE;
    object _6043 = NOVALUE;
    object _6040 = NOVALUE;
    object _6036 = NOVALUE;
    object _6034 = NOVALUE;
    object _6033 = NOVALUE;
    object _6030 = NOVALUE;
    object _6028 = NOVALUE;
    object _6026 = NOVALUE;
    object _6023 = NOVALUE;
    object _6021 = NOVALUE;
    object _6020 = NOVALUE;
    object _6019 = NOVALUE;
    object _6018 = NOVALUE;
    object _6017 = NOVALUE;
    object _6014 = NOVALUE;
    object _6012 = NOVALUE;
    object _6011 = NOVALUE;
    object _6010 = NOVALUE;
    object _6007 = NOVALUE;
    object _6005 = NOVALUE;
    object _6003 = NOVALUE;
    object _6000 = NOVALUE;
    object _5999 = NOVALUE;
    object _5992 = NOVALUE;
    object _5989 = NOVALUE;
    object _5988 = NOVALUE;
    object _5981 = NOVALUE;
    object _5977 = NOVALUE;
    object _5974 = NOVALUE;
    object _5963 = NOVALUE;
    object _5961 = NOVALUE;
    object _0, _1, _2;
    

    /** text.e:1445		if atom(arg_list) then*/
    _5961 = IS_ATOM(_arg_list_10738);
    if (_5961 == 0)
    {
        _5961 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5961 = NOVALUE;
    }

    /** text.e:1446			arg_list = {arg_list}*/
    _0 = _arg_list_10738;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_list_10738);
    ((intptr_t*)_2)[1] = _arg_list_10738;
    _arg_list_10738 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** text.e:1449		result = ""*/
    RefDS(_5);
    DeRef(_result_10739);
    _result_10739 = _5;

    /** text.e:1450		in_token = 0*/
    _in_token_10740 = 0;

    /** text.e:1453		i = 0*/
    _i_10742 = 0;

    /** text.e:1454		tend = 0*/
    _tend_10743 = 0;

    /** text.e:1455		argl = 0*/
    _argl_10756 = 0;

    /** text.e:1456		spacer = 0*/
    _spacer_10750 = 0;

    /** text.e:1457		prevargv = 0*/
    DeRef(_prevargv_10762);
    _prevargv_10762 = 0;

    /** text.e:1458	    while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_10737)){
            _5963 = SEQ_PTR(_format_pattern_10737)->length;
    }
    else {
        _5963 = 1;
    }
    if (_i_10742 >= _5963)
    goto L3; // [63] 3614

    /** text.e:1459	    	i += 1*/
    _i_10742 = _i_10742 + 1;

    /** text.e:1460	    	tch = format_pattern[i]*/
    _2 = (object)SEQ_PTR(_format_pattern_10737);
    _tch_10741 = (object)*(((s1_ptr)_2)->base + _i_10742);
    if (!IS_ATOM_INT(_tch_10741))
    _tch_10741 = (object)DBL_PTR(_tch_10741)->dbl;

    /** text.e:1461	    	if not in_token then*/
    if (_in_token_10740 != 0)
    goto L4; // [81] 210

    /** text.e:1462	    		if tch = '[' then*/
    if (_tch_10741 != 91)
    goto L5; // [86] 200

    /** text.e:1463	    			in_token = 1*/
    _in_token_10740 = 1;

    /** text.e:1464	    			tend = 0*/
    _tend_10743 = 0;

    /** text.e:1465					cap = 0*/
    _cap_10744 = 0;

    /** text.e:1466					align = 0*/
    _align_10745 = 0;

    /** text.e:1467					psign = 0*/
    _psign_10746 = 0;

    /** text.e:1468					msign = 0*/
    _msign_10747 = 0;

    /** text.e:1469					zfill = 0*/
    _zfill_10748 = 0;

    /** text.e:1470					bwz = 0*/
    _bwz_10749 = 0;

    /** text.e:1471					spacer = 0*/
    _spacer_10750 = 0;

    /** text.e:1472					alt = 0*/
    _alt_10751 = 0;

    /** text.e:1473	    			width = 0*/
    _width_10752 = 0;

    /** text.e:1474	    			decs = -1*/
    _decs_10753 = -1;

    /** text.e:1475	    			argn = 0*/
    _argn_10755 = 0;

    /** text.e:1476	    			hexout = 0*/
    _hexout_10758 = 0;

    /** text.e:1477	    			binout = 0*/
    _binout_10759 = 0;

    /** text.e:1478	    			trimming = 0*/
    _trimming_10757 = 0;

    /** text.e:1479	    			tsep = 0*/
    _tsep_10760 = 0;

    /** text.e:1480	    			istext = 0*/
    _istext_10761 = 0;

    /** text.e:1481	    			idname = ""*/
    RefDS(_5);
    DeRef(_idname_10764);
    _idname_10764 = _5;

    /** text.e:1482	    			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_10766);
    _envvar_10766 = _5;

    /** text.e:1483	    			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_10765);
    _envsym_10765 = _5;
    goto L2; // [197] 60
L5: 

    /** text.e:1485	    			result &= tch*/
    Append(&_result_10739, _result_10739, _tch_10741);
    goto L2; // [207] 60
L4: 

    /** text.e:1488				switch tch do*/
    _0 = _tch_10741;
    switch ( _0 ){ 

        /** text.e:1489	    			case ']' then*/
        case 93:

        /** text.e:1490	    				in_token = 0*/
        _in_token_10740 = 0;

        /** text.e:1491	    				tend = i*/
        _tend_10743 = _i_10742;
        goto L6; // [231] 1072

        /** text.e:1493	    			case '[' then*/
        case 91:

        /** text.e:1494		    			result &= tch*/
        Append(&_result_10739, _result_10739, _tch_10741);

        /** text.e:1495		    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_10737)){
                _5974 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _5974 = 1;
        }
        if (_i_10742 >= _5974)
        goto L6; // [251] 1072

        /** text.e:1496		    				i += 1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1497		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _5977 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _5977, 93)){
            _5977 = NOVALUE;
            goto L7; // [267] 248
        }
        _5977 = NOVALUE;

        /** text.e:1498		    					in_token = 0*/
        _in_token_10740 = 0;

        /** text.e:1499		    					tend = 0*/
        _tend_10743 = 0;

        /** text.e:1500		    					exit*/
        goto L6; // [283] 1072

        /** text.e:1502		    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** text.e:1504		    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** text.e:1505		    			cap = tch*/
        _cap_10744 = _tch_10741;
        goto L6; // [306] 1072

        /** text.e:1507		    		case 'b' then*/
        case 98:

        /** text.e:1508		    			bwz = 1*/
        _bwz_10749 = 1;
        goto L6; // [317] 1072

        /** text.e:1510		    		case 's' then*/
        case 115:

        /** text.e:1511		    			spacer = 1*/
        _spacer_10750 = 1;
        goto L6; // [328] 1072

        /** text.e:1513		    		case 't' then*/
        case 116:

        /** text.e:1514		    			trimming = 1*/
        _trimming_10757 = 1;
        goto L6; // [339] 1072

        /** text.e:1516		    		case 'z' then*/
        case 122:

        /** text.e:1517		    			zfill = 1*/
        _zfill_10748 = 1;
        goto L6; // [350] 1072

        /** text.e:1519		    		case 'X' then*/
        case 88:

        /** text.e:1520		    			hexout = 1*/
        _hexout_10758 = 1;
        goto L6; // [361] 1072

        /** text.e:1522		    		case 'B' then*/
        case 66:

        /** text.e:1523		    			binout = 1*/
        _binout_10759 = 1;
        goto L6; // [372] 1072

        /** text.e:1525		    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** text.e:1526		    			align = tch*/
        _align_10745 = _tch_10741;
        goto L6; // [387] 1072

        /** text.e:1528		    		case '+' then*/
        case 43:

        /** text.e:1529		    			psign = 1*/
        _psign_10746 = 1;
        goto L6; // [398] 1072

        /** text.e:1531		    		case '(' then*/
        case 40:

        /** text.e:1532		    			msign = 1*/
        _msign_10747 = 1;
        goto L6; // [409] 1072

        /** text.e:1534		    		case '?' then*/
        case 63:

        /** text.e:1535		    			alt = 1*/
        _alt_10751 = 1;
        goto L6; // [420] 1072

        /** text.e:1537		    		case 'T' then*/
        case 84:

        /** text.e:1538		    			istext = 1*/
        _istext_10761 = 1;
        goto L6; // [431] 1072

        /** text.e:1540		    		case ':' then*/
        case 58:

        /** text.e:1541		    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_10737)){
                _5981 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _5981 = 1;
        }
        if (_i_10742 >= _5981)
        goto L6; // [445] 1072

        /** text.e:1542		    				i += 1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1543		    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _tch_10741 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (!IS_ATOM_INT(_tch_10741))
        _tch_10741 = (object)DBL_PTR(_tch_10741)->dbl;

        /** text.e:1544		    				pos = find(tch, "0123456789")*/
        _pos_10754 = find_from(_tch_10741, _1739, 1);

        /** text.e:1545		    				if pos = 0 then*/
        if (_pos_10754 != 0)
        goto L9; // [470] 485

        /** text.e:1546		    					i -= 1*/
        _i_10742 = _i_10742 - 1;

        /** text.e:1547		    					exit*/
        goto L6; // [482] 1072
L9: 

        /** text.e:1549		    				width = width * 10 + pos - 1*/
        if (_width_10752 == (short)_width_10752){
            _5988 = _width_10752 * 10;
        }
        else{
            _5988 = NewDouble(_width_10752 * (eudouble)10);
        }
        if (IS_ATOM_INT(_5988)) {
            _5989 = _5988 + _pos_10754;
            if ((object)((uintptr_t)_5989 + (uintptr_t)HIGH_BITS) >= 0){
                _5989 = NewDouble((eudouble)_5989);
            }
        }
        else {
            _5989 = NewDouble(DBL_PTR(_5988)->dbl + (eudouble)_pos_10754);
        }
        DeRef(_5988);
        _5988 = NOVALUE;
        if (IS_ATOM_INT(_5989)) {
            _width_10752 = _5989 - 1;
        }
        else {
            _width_10752 = NewDouble(DBL_PTR(_5989)->dbl - (eudouble)1);
        }
        DeRef(_5989);
        _5989 = NOVALUE;
        if (!IS_ATOM_INT(_width_10752)) {
            _1 = (object)(DBL_PTR(_width_10752)->dbl);
            DeRefDS(_width_10752);
            _width_10752 = _1;
        }

        /** text.e:1550		    				if width = 0 then*/
        if (_width_10752 != 0)
        goto L8; // [505] 442

        /** text.e:1551		    					zfill = '0'*/
        _zfill_10748 = 48;

        /** text.e:1553		    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** text.e:1555		    		case '.' then*/
        case 46:

        /** text.e:1556		    			decs = 0*/
        _decs_10753 = 0;

        /** text.e:1557		    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_10737)){
                _5992 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _5992 = 1;
        }
        if (_i_10742 >= _5992)
        goto L6; // [539] 1072

        /** text.e:1558		    				i += 1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1559		    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _tch_10741 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (!IS_ATOM_INT(_tch_10741))
        _tch_10741 = (object)DBL_PTR(_tch_10741)->dbl;

        /** text.e:1560		    				pos = find(tch, "0123456789")*/
        _pos_10754 = find_from(_tch_10741, _1739, 1);

        /** text.e:1561		    				if pos = 0 then*/
        if (_pos_10754 != 0)
        goto LB; // [564] 579

        /** text.e:1562		    					i -= 1*/
        _i_10742 = _i_10742 - 1;

        /** text.e:1563		    					exit*/
        goto L6; // [576] 1072
LB: 

        /** text.e:1565		    				decs = decs * 10 + pos - 1*/
        if (_decs_10753 == (short)_decs_10753){
            _5999 = _decs_10753 * 10;
        }
        else{
            _5999 = NewDouble(_decs_10753 * (eudouble)10);
        }
        if (IS_ATOM_INT(_5999)) {
            _6000 = _5999 + _pos_10754;
            if ((object)((uintptr_t)_6000 + (uintptr_t)HIGH_BITS) >= 0){
                _6000 = NewDouble((eudouble)_6000);
            }
        }
        else {
            _6000 = NewDouble(DBL_PTR(_5999)->dbl + (eudouble)_pos_10754);
        }
        DeRef(_5999);
        _5999 = NOVALUE;
        if (IS_ATOM_INT(_6000)) {
            _decs_10753 = _6000 - 1;
        }
        else {
            _decs_10753 = NewDouble(DBL_PTR(_6000)->dbl - (eudouble)1);
        }
        DeRef(_6000);
        _6000 = NOVALUE;
        if (!IS_ATOM_INT(_decs_10753)) {
            _1 = (object)(DBL_PTR(_decs_10753)->dbl);
            DeRefDS(_decs_10753);
            _decs_10753 = _1;
        }

        /** text.e:1566		    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** text.e:1568		    		case '{' then*/
        case 123:

        /** text.e:1570		    			integer sp*/

        /** text.e:1572		    			sp = i + 1*/
        _sp_10841 = _i_10742 + 1;

        /** text.e:1573		    			i = sp*/
        _i_10742 = _sp_10841;

        /** text.e:1574		    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_10737)){
                _6003 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _6003 = 1;
        }
        if (_i_10742 >= _6003)
        goto LD; // [627] 672

        /** text.e:1575		    				if format_pattern[i] = '}' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _6005 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _6005, 125)){
            _6005 = NOVALUE;
            goto LE; // [637] 646
        }
        _6005 = NOVALUE;

        /** text.e:1576		    					exit*/
        goto LD; // [643] 672
LE: 

        /** text.e:1578		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _6007 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _6007, 93)){
            _6007 = NOVALUE;
            goto LF; // [652] 661
        }
        _6007 = NOVALUE;

        /** text.e:1579		    					exit*/
        goto LD; // [658] 672
LF: 

        /** text.e:1581		    				i += 1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1582		    			end while*/
        goto LC; // [669] 624
LD: 

        /** text.e:1583		    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _6010 = _i_10742 - 1;
        rhs_slice_target = (object_ptr)&_6011;
        RHS_Slice(_format_pattern_10737, _sp_10841, _6010);
        RefDS(_4905);
        _6012 = _12trim(_6011, _4905, 0);
        _6011 = NOVALUE;
        if (IS_SEQUENCE(_6012) && IS_ATOM(61)) {
            Append(&_idname_10764, _6012, 61);
        }
        else if (IS_ATOM(_6012) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_10764, _6012, 61);
            DeRef(_6012);
            _6012 = NOVALUE;
        }
        DeRef(_6012);
        _6012 = NOVALUE;

        /** text.e:1584	    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _6014 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _6014, 93)){
            _6014 = NOVALUE;
            goto L10; // [699] 710
        }
        _6014 = NOVALUE;

        /** text.e:1585	    					i -= 1*/
        _i_10742 = _i_10742 - 1;
L10: 

        /** text.e:1588	    				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_10738)){
                _6017 = SEQ_PTR(_arg_list_10738)->length;
        }
        else {
            _6017 = 1;
        }
        {
            object _j_10862;
            _j_10862 = 1;
L11: 
            if (_j_10862 > _6017){
                goto L12; // [715] 797
            }

            /** text.e:1589	    					if sequence(arg_list[j]) then*/
            _2 = (object)SEQ_PTR(_arg_list_10738);
            _6018 = (object)*(((s1_ptr)_2)->base + _j_10862);
            _6019 = IS_SEQUENCE(_6018);
            _6018 = NOVALUE;
            if (_6019 == 0)
            {
                _6019 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _6019 = NOVALUE;
            }

            /** text.e:1590	    						if search:begins(idname, arg_list[j]) then*/
            _2 = (object)SEQ_PTR(_arg_list_10738);
            _6020 = (object)*(((s1_ptr)_2)->base + _j_10862);
            RefDS(_idname_10764);
            Ref(_6020);
            _6021 = _14begins(_idname_10764, _6020);
            _6020 = NOVALUE;
            if (_6021 == 0) {
                DeRef(_6021);
                _6021 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_6021) && DBL_PTR(_6021)->dbl == 0.0){
                    DeRef(_6021);
                    _6021 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_6021);
                _6021 = NOVALUE;
            }
            DeRef(_6021);
            _6021 = NOVALUE;

            /** text.e:1591	    							if argn = 0 then*/
            if (_argn_10755 != 0)
            goto L15; // [752] 766

            /** text.e:1592	    								argn = j*/
            _argn_10755 = _j_10862;

            /** text.e:1593	    								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /** text.e:1597	    					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_10738)){
                    _6023 = SEQ_PTR(_arg_list_10738)->length;
            }
            else {
                _6023 = 1;
            }
            if (_j_10862 != _6023)
            goto L16; // [773] 790

            /** text.e:1598	    						idname = ""*/
            RefDS(_5);
            DeRef(_idname_10764);
            _idname_10764 = _5;

            /** text.e:1599	    						argn = -1*/
            _argn_10755 = -1;
L16: 

            /** text.e:1601	    				end for*/
            _j_10862 = _j_10862 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** text.e:1602		    		case '%' then*/
        case 37:

        /** text.e:1604		    			integer sp*/

        /** text.e:1606		    			sp = i + 1*/
        _sp_10876 = _i_10742 + 1;

        /** text.e:1607		    			i = sp*/
        _i_10742 = _sp_10876;

        /** text.e:1608		    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_10737)){
                _6026 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _6026 = 1;
        }
        if (_i_10742 >= _6026)
        goto L18; // [826] 871

        /** text.e:1609		    				if format_pattern[i] = '%' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _6028 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _6028, 37)){
            _6028 = NOVALUE;
            goto L19; // [836] 845
        }
        _6028 = NOVALUE;

        /** text.e:1610		    					exit*/
        goto L18; // [842] 871
L19: 

        /** text.e:1612		    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _6030 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _6030, 93)){
            _6030 = NOVALUE;
            goto L1A; // [851] 860
        }
        _6030 = NOVALUE;

        /** text.e:1613		    					exit*/
        goto L18; // [857] 871
L1A: 

        /** text.e:1615		    				i += 1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1616		    			end while*/
        goto L17; // [868] 823
L18: 

        /** text.e:1617		    			envsym = trim(format_pattern[sp .. i-1])*/
        _6033 = _i_10742 - 1;
        rhs_slice_target = (object_ptr)&_6034;
        RHS_Slice(_format_pattern_10737, _sp_10876, _6033);
        RefDS(_4905);
        _0 = _envsym_10765;
        _envsym_10765 = _12trim(_6034, _4905, 0);
        DeRef(_0);
        _6034 = NOVALUE;

        /** text.e:1618	    				if format_pattern[i] = ']' then*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _6036 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (binary_op_a(NOTEQ, _6036, 93)){
            _6036 = NOVALUE;
            goto L1B; // [894] 905
        }
        _6036 = NOVALUE;

        /** text.e:1619	    					i -= 1*/
        _i_10742 = _i_10742 - 1;
L1B: 

        /** text.e:1622	    				envvar = getenv(envsym)*/
        DeRefi(_envvar_10766);
        _envvar_10766 = EGetEnv(_envsym_10765);

        /** text.e:1624	    				argn = -1*/
        _argn_10755 = -1;

        /** text.e:1625	    				if atom(envvar) then*/
        _6040 = IS_ATOM(_envvar_10766);
        if (_6040 == 0)
        {
            _6040 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _6040 = NOVALUE;
        }

        /** text.e:1626	    					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_10766);
        _envvar_10766 = _5;
L1C: 
        goto L6; // [931] 1072

        /** text.e:1630		    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** text.e:1631		    			if argn = 0 then*/
        if (_argn_10755 != 0)
        goto L6; // [957] 1072

        /** text.e:1632			    			i -= 1*/
        _i_10742 = _i_10742 - 1;

        /** text.e:1633			    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_10737)){
                _6043 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _6043 = 1;
        }
        if (_i_10742 >= _6043)
        goto L6; // [975] 1072

        /** text.e:1634			    				i += 1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1635			    				tch = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _tch_10741 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (!IS_ATOM_INT(_tch_10741))
        _tch_10741 = (object)DBL_PTR(_tch_10741)->dbl;

        /** text.e:1636			    				pos = find(tch, "0123456789")*/
        _pos_10754 = find_from(_tch_10741, _1739, 1);

        /** text.e:1637			    				if pos = 0 then*/
        if (_pos_10754 != 0)
        goto L1E; // [1000] 1015

        /** text.e:1638			    					i -= 1*/
        _i_10742 = _i_10742 - 1;

        /** text.e:1639			    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** text.e:1641			    				argn = argn * 10 + pos - 1*/
        if (_argn_10755 == (short)_argn_10755){
            _6050 = _argn_10755 * 10;
        }
        else{
            _6050 = NewDouble(_argn_10755 * (eudouble)10);
        }
        if (IS_ATOM_INT(_6050)) {
            _6051 = _6050 + _pos_10754;
            if ((object)((uintptr_t)_6051 + (uintptr_t)HIGH_BITS) >= 0){
                _6051 = NewDouble((eudouble)_6051);
            }
        }
        else {
            _6051 = NewDouble(DBL_PTR(_6050)->dbl + (eudouble)_pos_10754);
        }
        DeRef(_6050);
        _6050 = NOVALUE;
        if (IS_ATOM_INT(_6051)) {
            _argn_10755 = _6051 - 1;
        }
        else {
            _argn_10755 = NewDouble(DBL_PTR(_6051)->dbl - (eudouble)1);
        }
        DeRef(_6051);
        _6051 = NOVALUE;
        if (!IS_ATOM_INT(_argn_10755)) {
            _1 = (object)(DBL_PTR(_argn_10755)->dbl);
            DeRefDS(_argn_10755);
            _argn_10755 = _1;
        }

        /** text.e:1642			    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** text.e:1645		    		case ',' then*/
        case 44:

        /** text.e:1646		    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_10737)){
                _6053 = SEQ_PTR(_format_pattern_10737)->length;
        }
        else {
            _6053 = 1;
        }
        if (_i_10742 >= _6053)
        goto L6; // [1048] 1072

        /** text.e:1647		    				i +=1*/
        _i_10742 = _i_10742 + 1;

        /** text.e:1648		    				tsep = format_pattern[i]*/
        _2 = (object)SEQ_PTR(_format_pattern_10737);
        _tsep_10760 = (object)*(((s1_ptr)_2)->base + _i_10742);
        if (!IS_ATOM_INT(_tsep_10760))
        _tsep_10760 = (object)DBL_PTR(_tsep_10760)->dbl;
        goto L6; // [1065] 1072

        /** text.e:1651		    		case else*/
        default:
    ;}L6: 

    /** text.e:1655	    		if tend > 0 then*/
    if (_tend_10743 <= 0)
    goto L1F; // [1074] 3606

    /** text.e:1657	    			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10923);
    _argtext_10923 = _5;

    /** text.e:1659	    			if argn = 0 then*/
    if (_argn_10755 != 0)
    goto L20; // [1089] 1100

    /** text.e:1660	    				argn = argl + 1*/
    _argn_10755 = _argl_10756 + 1;
L20: 

    /** text.e:1662	    			argl = argn*/
    _argl_10756 = _argn_10755;

    /** text.e:1664	    			if argn < 1 or argn > length(arg_list) then*/
    _6060 = (_argn_10755 < 1);
    if (_6060 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_10738)){
            _6062 = SEQ_PTR(_arg_list_10738)->length;
    }
    else {
        _6062 = 1;
    }
    _6063 = (_argn_10755 > _6062);
    _6062 = NOVALUE;
    if (_6063 == 0)
    {
        DeRef(_6063);
        _6063 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_6063);
        _6063 = NOVALUE;
    }
L21: 

    /** text.e:1665	    				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_10766)){
            _6064 = SEQ_PTR(_envvar_10766)->length;
    }
    else {
        _6064 = 1;
    }
    if (_6064 <= 0)
    goto L23; // [1134] 1153

    /** text.e:1666	    					argtext = envvar*/
    Ref(_envvar_10766);
    DeRef(_argtext_10923);
    _argtext_10923 = _envvar_10766;

    /** text.e:1667		    				currargv = envvar*/
    Ref(_envvar_10766);
    DeRef(_currargv_10763);
    _currargv_10763 = _envvar_10766;
    goto L24; // [1150] 2647
L23: 

    /** text.e:1669	    					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_10923);
    _argtext_10923 = _5;

    /** text.e:1670		    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_10763);
    _currargv_10763 = _5;
    goto L24; // [1166] 2647
L22: 

    /** text.e:1673						if string(arg_list[argn]) then*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6066 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    Ref(_6066);
    _6067 = _9string(_6066);
    _6066 = NOVALUE;
    if (_6067 == 0) {
        DeRef(_6067);
        _6067 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_6067) && DBL_PTR(_6067)->dbl == 0.0){
            DeRef(_6067);
            _6067 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_6067);
        _6067 = NOVALUE;
    }
    DeRef(_6067);
    _6067 = NOVALUE;

    /** text.e:1674							if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_10764)){
            _6068 = SEQ_PTR(_idname_10764)->length;
    }
    else {
        _6068 = 1;
    }
    if (_6068 <= 0)
    goto L26; // [1189] 1217

    /** text.e:1675								argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6070 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (IS_SEQUENCE(_idname_10764)){
            _6071 = SEQ_PTR(_idname_10764)->length;
    }
    else {
        _6071 = 1;
    }
    _6072 = _6071 + 1;
    _6071 = NOVALUE;
    if (IS_SEQUENCE(_6070)){
            _6073 = SEQ_PTR(_6070)->length;
    }
    else {
        _6073 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_6070, _6072, _6073);
    _6070 = NOVALUE;
    goto L27; // [1214] 2640
L26: 

    /** text.e:1677								argtext = arg_list[argn]*/
    DeRef(_argtext_10923);
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _argtext_10923 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    Ref(_argtext_10923);
    goto L27; // [1226] 2640
L25: 

    /** text.e:1680						elsif integer(arg_list[argn]) */
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6076 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (IS_ATOM_INT(_6076))
    _6077 = 1;
    else if (IS_ATOM_DBL(_6076))
    _6077 = IS_ATOM_INT(DoubleToInt(_6076));
    else
    _6077 = 0;
    _6076 = NOVALUE;
    if (_6077 == 0) {
        _6078 = 0;
        goto L28; // [1238] 1254
    }
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6079 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (IS_ATOM_INT(_6079)) {
        _6081 = (_6079 <= 1073741823);
    }
    else {
        _6081 = binary_op(LESSEQ, _6079, 1073741823);
    }
    _6079 = NOVALUE;
    if (IS_ATOM_INT(_6081))
    _6078 = (_6081 != 0);
    else
    _6078 = DBL_PTR(_6081)->dbl != 0.0;
L28: 
    if (_6078 == 0) {
        goto L29; // [1254] 1812
    }
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6083 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    _6086 = binary_op(GREATEREQ, _6083, _6085);
    _6083 = NOVALUE;
    if (_6086 == 0) {
        DeRef(_6086);
        _6086 = NOVALUE;
        goto L29; // [1267] 1812
    }
    else {
        if (!IS_ATOM_INT(_6086) && DBL_PTR(_6086)->dbl == 0.0){
            DeRef(_6086);
            _6086 = NOVALUE;
            goto L29; // [1267] 1812
        }
        DeRef(_6086);
        _6086 = NOVALUE;
    }
    DeRef(_6086);
    _6086 = NOVALUE;

    /** text.e:1684							if istext then*/
    if (_istext_10761 == 0)
    {
        goto L2A; // [1274] 1298
    }
    else{
    }

    /** text.e:1685								argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6087 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    Ref(_6087);
    _6088 = _21abs(_6087);
    _6087 = NOVALUE;
    _6089 = binary_op(AND_BITS, _341, _6088);
    DeRef(_6088);
    _6088 = NOVALUE;
    _0 = _argtext_10923;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6089;
    _argtext_10923 = MAKE_SEQ(_1);
    DeRef(_0);
    _6089 = NOVALUE;
    goto L27; // [1295] 2640
L2A: 

    /** text.e:1687							elsif bwz != 0 and arg_list[argn] = 0 then*/
    _6091 = (_bwz_10749 != 0);
    if (_6091 == 0) {
        goto L2B; // [1306] 1333
    }
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6093 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (IS_ATOM_INT(_6093)) {
        _6094 = (_6093 == 0);
    }
    else {
        _6094 = binary_op(EQUALS, _6093, 0);
    }
    _6093 = NOVALUE;
    if (_6094 == 0) {
        DeRef(_6094);
        _6094 = NOVALUE;
        goto L2B; // [1319] 1333
    }
    else {
        if (!IS_ATOM_INT(_6094) && DBL_PTR(_6094)->dbl == 0.0){
            DeRef(_6094);
            _6094 = NOVALUE;
            goto L2B; // [1319] 1333
        }
        DeRef(_6094);
        _6094 = NOVALUE;
    }
    DeRef(_6094);
    _6094 = NOVALUE;

    /** text.e:1688								argtext = repeat(' ', width)*/
    DeRef(_argtext_10923);
    _argtext_10923 = Repeat(32, _width_10752);
    goto L27; // [1330] 2640
L2B: 

    /** text.e:1690							elsif binout = 1 then*/
    if (_binout_10759 != 1)
    goto L2C; // [1337] 1476

    /** text.e:1691								argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6097 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    Ref(_6097);
    _6098 = _13int_to_bits(_6097, 32);
    _6097 = NOVALUE;
    _6099 = _24reverse(_6098, 1, 0);
    _6098 = NOVALUE;
    DeRef(_argtext_10923);
    if (IS_ATOM_INT(_6099)) {
        _argtext_10923 = _6099 + 48;
        if ((object)((uintptr_t)_argtext_10923 + (uintptr_t)HIGH_BITS) >= 0){
            _argtext_10923 = NewDouble((eudouble)_argtext_10923);
        }
    }
    else {
        _argtext_10923 = binary_op(PLUS, _6099, 48);
    }
    DeRef(_6099);
    _6099 = NOVALUE;

    /** text.e:1692								if zfill != 0 and width > 0 then*/
    _6101 = (_zfill_10748 != 0);
    if (_6101 == 0) {
        goto L2D; // [1372] 1418
    }
    _6103 = (_width_10752 > 0);
    if (_6103 == 0)
    {
        DeRef(_6103);
        _6103 = NOVALUE;
        goto L2D; // [1383] 1418
    }
    else{
        DeRef(_6103);
        _6103 = NOVALUE;
    }

    /** text.e:1693									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6104 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6104 = 1;
    }
    if (_width_10752 <= _6104)
    goto L27; // [1393] 2640

    /** text.e:1694										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6106 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6106 = 1;
    }
    _6107 = _width_10752 - _6106;
    _6106 = NOVALUE;
    _6108 = Repeat(48, _6107);
    _6107 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _6108, _argtext_10923);
    DeRefDS(_6108);
    _6108 = NOVALUE;
    DeRef(_6108);
    _6108 = NOVALUE;
    goto L27; // [1415] 2640
L2D: 

    /** text.e:1697									count = 1*/
    _count_10769 = 1;

    /** text.e:1698									while count < length(argtext) and argtext[count] = '0' do*/
L2E: 
    if (IS_SEQUENCE(_argtext_10923)){
            _6110 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6110 = 1;
    }
    _6111 = (_count_10769 < _6110);
    _6110 = NOVALUE;
    if (_6111 == 0) {
        goto L2F; // [1435] 1462
    }
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6113 = (object)*(((s1_ptr)_2)->base + _count_10769);
    if (IS_ATOM_INT(_6113)) {
        _6114 = (_6113 == 48);
    }
    else {
        _6114 = binary_op(EQUALS, _6113, 48);
    }
    _6113 = NOVALUE;
    if (_6114 <= 0) {
        if (_6114 == 0) {
            DeRef(_6114);
            _6114 = NOVALUE;
            goto L2F; // [1448] 1462
        }
        else {
            if (!IS_ATOM_INT(_6114) && DBL_PTR(_6114)->dbl == 0.0){
                DeRef(_6114);
                _6114 = NOVALUE;
                goto L2F; // [1448] 1462
            }
            DeRef(_6114);
            _6114 = NOVALUE;
        }
    }
    DeRef(_6114);
    _6114 = NOVALUE;

    /** text.e:1699										count += 1*/
    _count_10769 = _count_10769 + 1;

    /** text.e:1700									end while*/
    goto L2E; // [1459] 1428
L2F: 

    /** text.e:1701									argtext = argtext[count .. $]*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6116 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6116 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, _count_10769, _6116);
    goto L27; // [1473] 2640
L2C: 

    /** text.e:1704							elsif hexout = 0 then*/
    if (_hexout_10758 != 0)
    goto L30; // [1480] 1746

    /** text.e:1705								argtext = sprintf("%d", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6119 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_argtext_10923);
    _argtext_10923 = EPrintf(-9999999, _764, _6119);
    _6119 = NOVALUE;

    /** text.e:1706								if zfill != 0 and width > 0 then*/
    _6121 = (_zfill_10748 != 0);
    if (_6121 == 0) {
        goto L31; // [1502] 1599
    }
    _6123 = (_width_10752 > 0);
    if (_6123 == 0)
    {
        DeRef(_6123);
        _6123 = NOVALUE;
        goto L31; // [1513] 1599
    }
    else{
        DeRef(_6123);
        _6123 = NOVALUE;
    }

    /** text.e:1707									if argtext[1] = '-' then*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6124 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6124, 45)){
        _6124 = NOVALUE;
        goto L32; // [1522] 1568
    }
    _6124 = NOVALUE;

    /** text.e:1708										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6126 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6126 = 1;
    }
    if (_width_10752 <= _6126)
    goto L33; // [1533] 1598

    /** text.e:1709											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6128 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6128 = 1;
    }
    _6129 = _width_10752 - _6128;
    _6128 = NOVALUE;
    _6130 = Repeat(48, _6129);
    _6129 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10923)){
            _6131 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6131 = 1;
    }
    rhs_slice_target = (object_ptr)&_6132;
    RHS_Slice(_argtext_10923, 2, _6131);
    {
        object concat_list[3];

        concat_list[0] = _6132;
        concat_list[1] = _6130;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6132);
    _6132 = NOVALUE;
    DeRefDS(_6130);
    _6130 = NOVALUE;
    goto L33; // [1565] 1598
L32: 

    /** text.e:1712										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6134 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6134 = 1;
    }
    if (_width_10752 <= _6134)
    goto L34; // [1575] 1597

    /** text.e:1713											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6136 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6136 = 1;
    }
    _6137 = _width_10752 - _6136;
    _6136 = NOVALUE;
    _6138 = Repeat(48, _6137);
    _6137 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _6138, _argtext_10923);
    DeRefDS(_6138);
    _6138 = NOVALUE;
    DeRef(_6138);
    _6138 = NOVALUE;
L34: 
L33: 
L31: 

    /** text.e:1718								if arg_list[argn] > 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6140 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (binary_op_a(LESSEQ, _6140, 0)){
        _6140 = NOVALUE;
        goto L35; // [1605] 1653
    }
    _6140 = NOVALUE;

    /** text.e:1719									if psign then*/
    if (_psign_10746 == 0)
    {
        goto L27; // [1613] 2640
    }
    else{
    }

    /** text.e:1720										if zfill = 0 then*/
    if (_zfill_10748 != 0)
    goto L36; // [1618] 1631

    /** text.e:1721											argtext = '+' & argtext*/
    Prepend(&_argtext_10923, _argtext_10923, 43);
    goto L27; // [1628] 2640
L36: 

    /** text.e:1722										elsif argtext[1] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6144 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6144, 48)){
        _6144 = NOVALUE;
        goto L27; // [1637] 2640
    }
    _6144 = NOVALUE;

    /** text.e:1723											argtext[1] = '+'*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_10923 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 43;
    DeRef(_1);
    goto L27; // [1650] 2640
L35: 

    /** text.e:1726								elsif arg_list[argn] < 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6146 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (binary_op_a(GREATEREQ, _6146, 0)){
        _6146 = NOVALUE;
        goto L27; // [1659] 2640
    }
    _6146 = NOVALUE;

    /** text.e:1727									if msign then*/
    if (_msign_10747 == 0)
    {
        goto L27; // [1667] 2640
    }
    else{
    }

    /** text.e:1728										if zfill = 0 then*/
    if (_zfill_10748 != 0)
    goto L37; // [1672] 1695

    /** text.e:1729											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6149 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6149 = 1;
    }
    rhs_slice_target = (object_ptr)&_6150;
    RHS_Slice(_argtext_10923, 2, _6149);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _6150;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6150);
    _6150 = NOVALUE;
    goto L27; // [1692] 2640
L37: 

    /** text.e:1731											if argtext[2] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6153 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _6153, 48)){
        _6153 = NOVALUE;
        goto L38; // [1701] 1724
    }
    _6153 = NOVALUE;

    /** text.e:1732												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6155 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6155 = 1;
    }
    rhs_slice_target = (object_ptr)&_6156;
    RHS_Slice(_argtext_10923, 3, _6155);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _6156;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6156);
    _6156 = NOVALUE;
    goto L27; // [1721] 2640
L38: 

    /** text.e:1736												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6158 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6158 = 1;
    }
    rhs_slice_target = (object_ptr)&_6159;
    RHS_Slice(_argtext_10923, 2, _6158);
    Append(&_argtext_10923, _6159, 41);
    DeRefDS(_6159);
    _6159 = NOVALUE;
    goto L27; // [1743] 2640
L30: 

    /** text.e:1742								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6162 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_argtext_10923);
    _argtext_10923 = EPrintf(-9999999, _6161, _6162);
    _6162 = NOVALUE;

    /** text.e:1743								if zfill != 0 and width > 0 then*/
    _6164 = (_zfill_10748 != 0);
    if (_6164 == 0) {
        goto L27; // [1764] 2640
    }
    _6166 = (_width_10752 > 0);
    if (_6166 == 0)
    {
        DeRef(_6166);
        _6166 = NOVALUE;
        goto L27; // [1775] 2640
    }
    else{
        DeRef(_6166);
        _6166 = NOVALUE;
    }

    /** text.e:1744									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6167 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6167 = 1;
    }
    if (_width_10752 <= _6167)
    goto L27; // [1785] 2640

    /** text.e:1745										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6169 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6169 = 1;
    }
    _6170 = _width_10752 - _6169;
    _6169 = NOVALUE;
    _6171 = Repeat(48, _6170);
    _6170 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _6171, _argtext_10923);
    DeRefDS(_6171);
    _6171 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    goto L27; // [1809] 2640
L29: 

    /** text.e:1750						elsif atom(arg_list[argn]) then*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6173 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    _6174 = IS_ATOM(_6173);
    _6173 = NOVALUE;
    if (_6174 == 0)
    {
        _6174 = NOVALUE;
        goto L39; // [1821] 2224
    }
    else{
        _6174 = NOVALUE;
    }

    /** text.e:1751							if istext then*/
    if (_istext_10761 == 0)
    {
        goto L3A; // [1828] 1855
    }
    else{
    }

    /** text.e:1752								argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6175 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (IS_ATOM_INT(_6175))
    _6176 = e_floor(_6175);
    else
    _6176 = unary_op(FLOOR, _6175);
    _6175 = NOVALUE;
    _6177 = _21abs(_6176);
    _6176 = NOVALUE;
    _6178 = binary_op(AND_BITS, _341, _6177);
    DeRef(_6177);
    _6177 = NOVALUE;
    _0 = _argtext_10923;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6178;
    _argtext_10923 = MAKE_SEQ(_1);
    DeRef(_0);
    _6178 = NOVALUE;
    goto L27; // [1852] 2640
L3A: 

    /** text.e:1755								if hexout then*/
    if (_hexout_10758 == 0)
    {
        goto L3B; // [1859] 1927
    }
    else{
    }

    /** text.e:1756									argtext = sprintf("%x", arg_list[argn])*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6180 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_argtext_10923);
    _argtext_10923 = EPrintf(-9999999, _6161, _6180);
    _6180 = NOVALUE;

    /** text.e:1757									if zfill != 0 and width > 0 then*/
    _6182 = (_zfill_10748 != 0);
    if (_6182 == 0) {
        goto L27; // [1880] 2640
    }
    _6184 = (_width_10752 > 0);
    if (_6184 == 0)
    {
        DeRef(_6184);
        _6184 = NOVALUE;
        goto L27; // [1891] 2640
    }
    else{
        DeRef(_6184);
        _6184 = NOVALUE;
    }

    /** text.e:1758										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6185 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6185 = 1;
    }
    if (_width_10752 <= _6185)
    goto L27; // [1901] 2640

    /** text.e:1759											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6187 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6187 = 1;
    }
    _6188 = _width_10752 - _6187;
    _6187 = NOVALUE;
    _6189 = Repeat(48, _6188);
    _6188 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _6189, _argtext_10923);
    DeRefDS(_6189);
    _6189 = NOVALUE;
    DeRef(_6189);
    _6189 = NOVALUE;
    goto L27; // [1924] 2640
L3B: 

    /** text.e:1763									argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6192 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    _6193 = EPrintf(-9999999, _6191, _6192);
    _6192 = NOVALUE;
    RefDS(_4905);
    _0 = _argtext_10923;
    _argtext_10923 = _12trim(_6193, _4905, 0);
    DeRef(_0);
    _6193 = NOVALUE;

    /** text.e:1765									while ep != 0 with entry do*/
    goto L3C; // [1947] 1970
L3D: 
    if (_ep_10767 == 0)
    goto L3E; // [1952] 1982

    /** text.e:1766										argtext = remove(argtext, ep+2)*/
    _6196 = _ep_10767 + 2;
    if ((object)((uintptr_t)_6196 + (uintptr_t)HIGH_BITS) >= 0){
        _6196 = NewDouble((eudouble)_6196);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10923);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_6196)) ? _6196 : (object)(DBL_PTR(_6196)->dbl);
        int stop = (IS_ATOM_INT(_6196)) ? _6196 : (object)(DBL_PTR(_6196)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10923), start, &_argtext_10923 );
            }
            else Tail(SEQ_PTR(_argtext_10923), stop+1, &_argtext_10923);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10923), start, &_argtext_10923);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10923 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10923)->ref == 1));
        }
    }
    DeRef(_6196);
    _6196 = NOVALUE;
    _6196 = NOVALUE;

    /** text.e:1767									entry*/
L3C: 

    /** text.e:1768										ep = match("e+0", argtext)*/
    _ep_10767 = e_match_from(_6198, _argtext_10923, 1);

    /** text.e:1769									end while*/
    goto L3D; // [1979] 1950
L3E: 

    /** text.e:1770									if zfill != 0 and width > 0 then*/
    _6200 = (_zfill_10748 != 0);
    if (_6200 == 0) {
        goto L3F; // [1990] 2075
    }
    _6202 = (_width_10752 > 0);
    if (_6202 == 0)
    {
        DeRef(_6202);
        _6202 = NOVALUE;
        goto L3F; // [2001] 2075
    }
    else{
        DeRef(_6202);
        _6202 = NOVALUE;
    }

    /** text.e:1771										if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6203 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6203 = 1;
    }
    if (_width_10752 <= _6203)
    goto L40; // [2011] 2074

    /** text.e:1772											if argtext[1] = '-' then*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6205 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6205, 45)){
        _6205 = NOVALUE;
        goto L41; // [2021] 2055
    }
    _6205 = NOVALUE;

    /** text.e:1773												argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6207 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6207 = 1;
    }
    _6208 = _width_10752 - _6207;
    _6207 = NOVALUE;
    _6209 = Repeat(48, _6208);
    _6208 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10923)){
            _6210 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6210 = 1;
    }
    rhs_slice_target = (object_ptr)&_6211;
    RHS_Slice(_argtext_10923, 2, _6210);
    {
        object concat_list[3];

        concat_list[0] = _6211;
        concat_list[1] = _6209;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6211);
    _6211 = NOVALUE;
    DeRefDS(_6209);
    _6209 = NOVALUE;
    goto L42; // [2052] 2073
L41: 

    /** text.e:1775												argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6213 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6213 = 1;
    }
    _6214 = _width_10752 - _6213;
    _6213 = NOVALUE;
    _6215 = Repeat(48, _6214);
    _6214 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _6215, _argtext_10923);
    DeRefDS(_6215);
    _6215 = NOVALUE;
    DeRef(_6215);
    _6215 = NOVALUE;
L42: 
L40: 
L3F: 

    /** text.e:1779									if arg_list[argn] > 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6217 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (binary_op_a(LESSEQ, _6217, 0)){
        _6217 = NOVALUE;
        goto L43; // [2081] 2129
    }
    _6217 = NOVALUE;

    /** text.e:1780										if psign  then*/
    if (_psign_10746 == 0)
    {
        goto L27; // [2089] 2640
    }
    else{
    }

    /** text.e:1781											if zfill = 0 then*/
    if (_zfill_10748 != 0)
    goto L44; // [2094] 2107

    /** text.e:1782												argtext = '+' & argtext*/
    Prepend(&_argtext_10923, _argtext_10923, 43);
    goto L27; // [2104] 2640
L44: 

    /** text.e:1783											elsif argtext[1] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6221 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6221, 48)){
        _6221 = NOVALUE;
        goto L27; // [2113] 2640
    }
    _6221 = NOVALUE;

    /** text.e:1784												argtext[1] = '+'*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_10923 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 43;
    DeRef(_1);
    goto L27; // [2126] 2640
L43: 

    /** text.e:1787									elsif arg_list[argn] < 0 then*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6223 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (binary_op_a(GREATEREQ, _6223, 0)){
        _6223 = NOVALUE;
        goto L27; // [2135] 2640
    }
    _6223 = NOVALUE;

    /** text.e:1788										if msign then*/
    if (_msign_10747 == 0)
    {
        goto L27; // [2143] 2640
    }
    else{
    }

    /** text.e:1789											if zfill = 0 then*/
    if (_zfill_10748 != 0)
    goto L45; // [2148] 2171

    /** text.e:1790												argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6226 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6226 = 1;
    }
    rhs_slice_target = (object_ptr)&_6227;
    RHS_Slice(_argtext_10923, 2, _6226);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _6227;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6227);
    _6227 = NOVALUE;
    goto L27; // [2168] 2640
L45: 

    /** text.e:1792												if argtext[2] = '0' then*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6229 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _6229, 48)){
        _6229 = NOVALUE;
        goto L46; // [2177] 2200
    }
    _6229 = NOVALUE;

    /** text.e:1793													argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6231 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6231 = 1;
    }
    rhs_slice_target = (object_ptr)&_6232;
    RHS_Slice(_argtext_10923, 3, _6231);
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _6232;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6232);
    _6232 = NOVALUE;
    goto L27; // [2197] 2640
L46: 

    /** text.e:1795													argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6234 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6234 = 1;
    }
    rhs_slice_target = (object_ptr)&_6235;
    RHS_Slice(_argtext_10923, 2, _6234);
    Append(&_argtext_10923, _6235, 41);
    DeRefDS(_6235);
    _6235 = NOVALUE;
    goto L27; // [2221] 2640
L39: 

    /** text.e:1804							if alt != 0 and length(arg_list[argn]) = 2 then*/
    _6237 = (_alt_10751 != 0);
    if (_6237 == 0) {
        goto L47; // [2232] 2551
    }
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6239 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    if (IS_SEQUENCE(_6239)){
            _6240 = SEQ_PTR(_6239)->length;
    }
    else {
        _6240 = 1;
    }
    _6239 = NOVALUE;
    _6241 = (_6240 == 2);
    _6240 = NOVALUE;
    if (_6241 == 0)
    {
        DeRef(_6241);
        _6241 = NOVALUE;
        goto L47; // [2248] 2551
    }
    else{
        DeRef(_6241);
        _6241 = NOVALUE;
    }

    /** text.e:1805								object tempv*/

    /** text.e:1806								if atom(prevargv) then*/
    _6242 = IS_ATOM(_prevargv_10762);
    if (_6242 == 0)
    {
        _6242 = NOVALUE;
        goto L48; // [2258] 2294
    }
    else{
        _6242 = NOVALUE;
    }

    /** text.e:1807									if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_10762, 1)){
        goto L49; // [2263] 2280
    }

    /** text.e:1808										tempv = arg_list[argn][1]*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6244 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_tempv_11168);
    _2 = (object)SEQ_PTR(_6244);
    _tempv_11168 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_11168);
    _6244 = NOVALUE;
    goto L4A; // [2277] 2328
L49: 

    /** text.e:1810										tempv = arg_list[argn][2]*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6246 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_tempv_11168);
    _2 = (object)SEQ_PTR(_6246);
    _tempv_11168 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_11168);
    _6246 = NOVALUE;
    goto L4A; // [2291] 2328
L48: 

    /** text.e:1813									if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_10762)){
            _6248 = SEQ_PTR(_prevargv_10762)->length;
    }
    else {
        _6248 = 1;
    }
    if (_6248 != 0)
    goto L4B; // [2299] 2316

    /** text.e:1814										tempv = arg_list[argn][1]*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6250 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_tempv_11168);
    _2 = (object)SEQ_PTR(_6250);
    _tempv_11168 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_11168);
    _6250 = NOVALUE;
    goto L4C; // [2313] 2327
L4B: 

    /** text.e:1816										tempv = arg_list[argn][2]*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6252 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    DeRef(_tempv_11168);
    _2 = (object)SEQ_PTR(_6252);
    _tempv_11168 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_11168);
    _6252 = NOVALUE;
L4C: 
L4A: 

    /** text.e:1820								if string(tempv) then*/
    Ref(_tempv_11168);
    _6254 = _9string(_tempv_11168);
    if (_6254 == 0) {
        DeRef(_6254);
        _6254 = NOVALUE;
        goto L4D; // [2336] 2349
    }
    else {
        if (!IS_ATOM_INT(_6254) && DBL_PTR(_6254)->dbl == 0.0){
            DeRef(_6254);
            _6254 = NOVALUE;
            goto L4D; // [2336] 2349
        }
        DeRef(_6254);
        _6254 = NOVALUE;
    }
    DeRef(_6254);
    _6254 = NOVALUE;

    /** text.e:1821									argtext = tempv*/
    Ref(_tempv_11168);
    DeRef(_argtext_10923);
    _argtext_10923 = _tempv_11168;
    goto L4E; // [2346] 2546
L4D: 

    /** text.e:1822								elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_11168))
    _6255 = 1;
    else if (IS_ATOM_DBL(_tempv_11168))
    _6255 = IS_ATOM_INT(DoubleToInt(_tempv_11168));
    else
    _6255 = 0;
    if (_6255 == 0)
    {
        _6255 = NOVALUE;
        goto L4F; // [2354] 2420
    }
    else{
        _6255 = NOVALUE;
    }

    /** text.e:1823									if istext then*/
    if (_istext_10761 == 0)
    {
        goto L50; // [2359] 2379
    }
    else{
    }

    /** text.e:1824										argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_11168);
    _6256 = _21abs(_tempv_11168);
    _6257 = binary_op(AND_BITS, _341, _6256);
    DeRef(_6256);
    _6256 = NOVALUE;
    _0 = _argtext_10923;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6257;
    _argtext_10923 = MAKE_SEQ(_1);
    DeRef(_0);
    _6257 = NOVALUE;
    goto L4E; // [2376] 2546
L50: 

    /** text.e:1826									elsif bwz != 0 and tempv = 0 then*/
    _6259 = (_bwz_10749 != 0);
    if (_6259 == 0) {
        goto L51; // [2387] 2410
    }
    if (IS_ATOM_INT(_tempv_11168)) {
        _6261 = (_tempv_11168 == 0);
    }
    else {
        _6261 = binary_op(EQUALS, _tempv_11168, 0);
    }
    if (_6261 == 0) {
        DeRef(_6261);
        _6261 = NOVALUE;
        goto L51; // [2396] 2410
    }
    else {
        if (!IS_ATOM_INT(_6261) && DBL_PTR(_6261)->dbl == 0.0){
            DeRef(_6261);
            _6261 = NOVALUE;
            goto L51; // [2396] 2410
        }
        DeRef(_6261);
        _6261 = NOVALUE;
    }
    DeRef(_6261);
    _6261 = NOVALUE;

    /** text.e:1827										argtext = repeat(' ', width)*/
    DeRef(_argtext_10923);
    _argtext_10923 = Repeat(32, _width_10752);
    goto L4E; // [2407] 2546
L51: 

    /** text.e:1829										argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_10923);
    _argtext_10923 = EPrintf(-9999999, _764, _tempv_11168);
    goto L4E; // [2417] 2546
L4F: 

    /** text.e:1832								elsif atom(tempv) then*/
    _6264 = IS_ATOM(_tempv_11168);
    if (_6264 == 0)
    {
        _6264 = NOVALUE;
        goto L52; // [2425] 2502
    }
    else{
        _6264 = NOVALUE;
    }

    /** text.e:1833									if istext then*/
    if (_istext_10761 == 0)
    {
        goto L53; // [2430] 2453
    }
    else{
    }

    /** text.e:1834										argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_11168))
    _6265 = e_floor(_tempv_11168);
    else
    _6265 = unary_op(FLOOR, _tempv_11168);
    _6266 = _21abs(_6265);
    _6265 = NOVALUE;
    _6267 = binary_op(AND_BITS, _341, _6266);
    DeRef(_6266);
    _6266 = NOVALUE;
    _0 = _argtext_10923;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6267;
    _argtext_10923 = MAKE_SEQ(_1);
    DeRef(_0);
    _6267 = NOVALUE;
    goto L4E; // [2450] 2546
L53: 

    /** text.e:1835									elsif bwz != 0 and tempv = 0 then*/
    _6269 = (_bwz_10749 != 0);
    if (_6269 == 0) {
        goto L54; // [2461] 2484
    }
    if (IS_ATOM_INT(_tempv_11168)) {
        _6271 = (_tempv_11168 == 0);
    }
    else {
        _6271 = binary_op(EQUALS, _tempv_11168, 0);
    }
    if (_6271 == 0) {
        DeRef(_6271);
        _6271 = NOVALUE;
        goto L54; // [2470] 2484
    }
    else {
        if (!IS_ATOM_INT(_6271) && DBL_PTR(_6271)->dbl == 0.0){
            DeRef(_6271);
            _6271 = NOVALUE;
            goto L54; // [2470] 2484
        }
        DeRef(_6271);
        _6271 = NOVALUE;
    }
    DeRef(_6271);
    _6271 = NOVALUE;

    /** text.e:1836										argtext = repeat(' ', width)*/
    DeRef(_argtext_10923);
    _argtext_10923 = Repeat(32, _width_10752);
    goto L4E; // [2481] 2546
L54: 

    /** text.e:1838										argtext = trim(sprintf("%15.15g", tempv))*/
    _6273 = EPrintf(-9999999, _6191, _tempv_11168);
    RefDS(_4905);
    _0 = _argtext_10923;
    _argtext_10923 = _12trim(_6273, _4905, 0);
    DeRef(_0);
    _6273 = NOVALUE;
    goto L4E; // [2499] 2546
L52: 

    /** text.e:1841									argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1000;
    RefDS(_764);
    ((intptr_t*)_2)[5] = _764;
    RefDS(_6275);
    ((intptr_t*)_2)[6] = _6275;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 1;
    ((intptr_t*)_2)[10] = 0;
    _6276 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2518_11222);
    _options_inlined_pretty_sprint_at_2518_11222 = _6276;
    _6276 = NOVALUE;

    /** pretty.e:364		pretty_printing = 0*/
    _10pretty_printing_1612 = 0;

    /** pretty.e:365		pretty( x, options )*/
    Ref(_tempv_11168);
    RefDS(_options_inlined_pretty_sprint_at_2518_11222);
    _10pretty(_tempv_11168, _options_inlined_pretty_sprint_at_2518_11222);

    /** pretty.e:366		return pretty_line*/
    RefDS(_10pretty_line_1615);
    DeRef(_argtext_10923);
    _argtext_10923 = _10pretty_line_1615;
    DeRef(_options_inlined_pretty_sprint_at_2518_11222);
    _options_inlined_pretty_sprint_at_2518_11222 = NOVALUE;
L4E: 
    DeRef(_tempv_11168);
    _tempv_11168 = NOVALUE;
    goto L55; // [2548] 2627
L47: 

    /** text.e:1846								argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _6277 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    _1 = NewS1(10);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2;
    ((intptr_t*)_2)[2] = 0;
    ((intptr_t*)_2)[3] = 1;
    ((intptr_t*)_2)[4] = 1000;
    RefDS(_764);
    ((intptr_t*)_2)[5] = _764;
    RefDS(_6275);
    ((intptr_t*)_2)[6] = _6275;
    ((intptr_t*)_2)[7] = 32;
    ((intptr_t*)_2)[8] = 127;
    ((intptr_t*)_2)[9] = 1;
    ((intptr_t*)_2)[10] = 0;
    _6278 = MAKE_SEQ(_1);
    Ref(_6277);
    DeRef(_x_inlined_pretty_sprint_at_2571_11228);
    _x_inlined_pretty_sprint_at_2571_11228 = _6277;
    _6277 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2574_11229);
    _options_inlined_pretty_sprint_at_2574_11229 = _6278;
    _6278 = NOVALUE;

    /** pretty.e:364		pretty_printing = 0*/
    _10pretty_printing_1612 = 0;

    /** pretty.e:365		pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2571_11228);
    RefDS(_options_inlined_pretty_sprint_at_2574_11229);
    _10pretty(_x_inlined_pretty_sprint_at_2571_11228, _options_inlined_pretty_sprint_at_2574_11229);

    /** pretty.e:366		return pretty_line*/
    RefDS(_10pretty_line_1615);
    DeRef(_argtext_10923);
    _argtext_10923 = _10pretty_line_1615;
    DeRef(_x_inlined_pretty_sprint_at_2571_11228);
    _x_inlined_pretty_sprint_at_2571_11228 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2574_11229);
    _options_inlined_pretty_sprint_at_2574_11229 = NOVALUE;

    /** text.e:1851							while ep != 0 with entry do*/
    goto L55; // [2604] 2627
L56: 
    if (_ep_10767 == 0)
    goto L57; // [2609] 2639

    /** text.e:1852								argtext = remove(argtext, ep+2)*/
    _6280 = _ep_10767 + 2;
    if ((object)((uintptr_t)_6280 + (uintptr_t)HIGH_BITS) >= 0){
        _6280 = NewDouble((eudouble)_6280);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_10923);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_6280)) ? _6280 : (object)(DBL_PTR(_6280)->dbl);
        int stop = (IS_ATOM_INT(_6280)) ? _6280 : (object)(DBL_PTR(_6280)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_10923), start, &_argtext_10923 );
            }
            else Tail(SEQ_PTR(_argtext_10923), stop+1, &_argtext_10923);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_10923), start, &_argtext_10923);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_10923 = Remove_elements(start, stop, (SEQ_PTR(_argtext_10923)->ref == 1));
        }
    }
    DeRef(_6280);
    _6280 = NOVALUE;
    _6280 = NOVALUE;

    /** text.e:1853							entry*/
L55: 

    /** text.e:1854								ep = match("e+0", argtext)*/
    _ep_10767 = e_match_from(_6198, _argtext_10923, 1);

    /** text.e:1855							end while*/
    goto L56; // [2636] 2607
L57: 
L27: 

    /** text.e:1857		    			currargv = arg_list[argn]*/
    DeRef(_currargv_10763);
    _2 = (object)SEQ_PTR(_arg_list_10738);
    _currargv_10763 = (object)*(((s1_ptr)_2)->base + _argn_10755);
    Ref(_currargv_10763);
L24: 

    /** text.e:1861	    			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6284 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6284 = 1;
    }
    if (_6284 <= 0)
    goto L58; // [2652] 3562

    /** text.e:1862	    				switch cap do*/
    _0 = _cap_10744;
    switch ( _0 ){ 

        /** text.e:1863	    					case 'u' then*/
        case 117:

        /** text.e:1864	    						argtext = upper(argtext)*/
        RefDS(_argtext_10923);
        _0 = _argtext_10923;
        _argtext_10923 = _12upper(_argtext_10923);
        DeRefDS(_0);
        goto L59; // [2677] 2743

        /** text.e:1865	    					case 'l' then*/
        case 108:

        /** text.e:1866	    						argtext = lower(argtext)*/
        RefDS(_argtext_10923);
        _0 = _argtext_10923;
        _argtext_10923 = _12lower(_argtext_10923);
        DeRefDS(_0);
        goto L59; // [2691] 2743

        /** text.e:1867	    					case 'w' then*/
        case 119:

        /** text.e:1868	    						argtext = proper(argtext)*/
        RefDS(_argtext_10923);
        _0 = _argtext_10923;
        _argtext_10923 = _12proper(_argtext_10923);
        DeRefDS(_0);
        goto L59; // [2705] 2743

        /** text.e:1869	    					case 0 then*/
        case 0:

        /** text.e:1871								cap = cap*/
        _cap_10744 = _cap_10744;
        goto L59; // [2716] 2743

        /** text.e:1873	    					case else*/
        default:

        /** text.e:1874	    						error:crash("logic error: 'cap' mode in format.")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2725_11252);
        _msg_inlined_crash_at_2725_11252 = EPrintf(-9999999, _6291, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2725_11252);

        /** error.e:53	end procedure*/
        goto L5A; // [2737] 2740
L5A: 
        DeRefi(_msg_inlined_crash_at_2725_11252);
        _msg_inlined_crash_at_2725_11252 = NOVALUE;
    ;}L59: 

    /** text.e:1878						if atom(currargv) then*/
    _6292 = IS_ATOM(_currargv_10763);
    if (_6292 == 0)
    {
        _6292 = NOVALUE;
        goto L5B; // [2750] 2993
    }
    else{
        _6292 = NOVALUE;
    }

    /** text.e:1879							if find('e', argtext) = 0 then*/
    _6293 = find_from(101, _argtext_10923, 1);
    if (_6293 != 0)
    goto L5C; // [2760] 2992

    /** text.e:1881								pflag = 0*/
    _pflag_10768 = 0;

    /** text.e:1882								if msign and currargv < 0 then*/
    if (_msign_10747 == 0) {
        goto L5D; // [2773] 2791
    }
    if (IS_ATOM_INT(_currargv_10763)) {
        _6296 = (_currargv_10763 < 0);
    }
    else {
        _6296 = binary_op(LESS, _currargv_10763, 0);
    }
    if (_6296 == 0) {
        DeRef(_6296);
        _6296 = NOVALUE;
        goto L5D; // [2782] 2791
    }
    else {
        if (!IS_ATOM_INT(_6296) && DBL_PTR(_6296)->dbl == 0.0){
            DeRef(_6296);
            _6296 = NOVALUE;
            goto L5D; // [2782] 2791
        }
        DeRef(_6296);
        _6296 = NOVALUE;
    }
    DeRef(_6296);
    _6296 = NOVALUE;

    /** text.e:1883									pflag = 1*/
    _pflag_10768 = 1;
L5D: 

    /** text.e:1885								if decs != -1 then*/
    if (_decs_10753 == -1)
    goto L5E; // [2795] 2991

    /** text.e:1886									pos = find('.', argtext)*/
    _pos_10754 = find_from(46, _argtext_10923, 1);

    /** text.e:1887									if pos then*/
    if (_pos_10754 == 0)
    {
        goto L5F; // [2808] 2936
    }
    else{
    }

    /** text.e:1888										if decs = 0 then*/
    if (_decs_10753 != 0)
    goto L60; // [2813] 2831

    /** text.e:1889											argtext = argtext [1 .. pos-1 ]*/
    _6300 = _pos_10754 - 1;
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, 1, _6300);
    goto L61; // [2828] 2990
L60: 

    /** text.e:1891											pos = length(argtext) - pos - pflag*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6302 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6302 = 1;
    }
    _6303 = _6302 - _pos_10754;
    if ((object)((uintptr_t)_6303 +(uintptr_t) HIGH_BITS) >= 0){
        _6303 = NewDouble((eudouble)_6303);
    }
    _6302 = NOVALUE;
    if (IS_ATOM_INT(_6303)) {
        _pos_10754 = _6303 - _pflag_10768;
    }
    else {
        _pos_10754 = NewDouble(DBL_PTR(_6303)->dbl - (eudouble)_pflag_10768);
    }
    DeRef(_6303);
    _6303 = NOVALUE;
    if (!IS_ATOM_INT(_pos_10754)) {
        _1 = (object)(DBL_PTR(_pos_10754)->dbl);
        DeRefDS(_pos_10754);
        _pos_10754 = _1;
    }

    /** text.e:1892											if pos > decs then*/
    if (_pos_10754 <= _decs_10753)
    goto L62; // [2848] 2873

    /** text.e:1893												argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6306 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6306 = 1;
    }
    _6307 = _6306 - _pos_10754;
    if ((object)((uintptr_t)_6307 +(uintptr_t) HIGH_BITS) >= 0){
        _6307 = NewDouble((eudouble)_6307);
    }
    _6306 = NOVALUE;
    if (IS_ATOM_INT(_6307)) {
        _6308 = _6307 + _decs_10753;
    }
    else {
        _6308 = NewDouble(DBL_PTR(_6307)->dbl + (eudouble)_decs_10753);
    }
    DeRef(_6307);
    _6307 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, 1, _6308);
    goto L61; // [2870] 2990
L62: 

    /** text.e:1894											elsif pos < decs then*/
    if (_pos_10754 >= _decs_10753)
    goto L61; // [2875] 2990

    /** text.e:1895												if pflag then*/
    if (_pflag_10768 == 0)
    {
        goto L63; // [2881] 2915
    }
    else{
    }

    /** text.e:1896													argtext = argtext[ 1 .. $ - 1 ] & repeat('0', decs - pos) & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6311 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6311 = 1;
    }
    _6312 = _6311 - 1;
    _6311 = NOVALUE;
    rhs_slice_target = (object_ptr)&_6313;
    RHS_Slice(_argtext_10923, 1, _6312);
    _6314 = _decs_10753 - _pos_10754;
    _6315 = Repeat(48, _6314);
    _6314 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _6315;
        concat_list[2] = _6313;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6315);
    _6315 = NOVALUE;
    DeRefDS(_6313);
    _6313 = NOVALUE;
    goto L61; // [2912] 2990
L63: 

    /** text.e:1898													argtext = argtext & repeat('0', decs - pos)*/
    _6317 = _decs_10753 - _pos_10754;
    _6318 = Repeat(48, _6317);
    _6317 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _argtext_10923, _6318);
    DeRefDS(_6318);
    _6318 = NOVALUE;
    goto L61; // [2933] 2990
L5F: 

    /** text.e:1902									elsif decs > 0 then*/
    if (_decs_10753 <= 0)
    goto L64; // [2938] 2989

    /** text.e:1903										if pflag then*/
    if (_pflag_10768 == 0)
    {
        goto L65; // [2944] 2975
    }
    else{
    }

    /** text.e:1904											argtext = argtext[1 .. $ - 1] & '.' & repeat('0', decs) & ')'*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6321 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6321 = 1;
    }
    _6322 = _6321 - 1;
    _6321 = NOVALUE;
    rhs_slice_target = (object_ptr)&_6323;
    RHS_Slice(_argtext_10923, 1, _6322);
    _6324 = Repeat(48, _decs_10753);
    {
        object concat_list[4];

        concat_list[0] = 41;
        concat_list[1] = _6324;
        concat_list[2] = 46;
        concat_list[3] = _6323;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 4);
    }
    DeRefDS(_6324);
    _6324 = NOVALUE;
    DeRefDS(_6323);
    _6323 = NOVALUE;
    goto L66; // [2972] 2988
L65: 

    /** text.e:1906											argtext = argtext & '.' & repeat('0', decs)*/
    _6326 = Repeat(48, _decs_10753);
    {
        object concat_list[3];

        concat_list[0] = _6326;
        concat_list[1] = 46;
        concat_list[2] = _argtext_10923;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6326);
    _6326 = NOVALUE;
L66: 
L64: 
L61: 
L5E: 
L5C: 
L5B: 

    /** text.e:1914	    				if align = 0 then*/
    if (_align_10745 != 0)
    goto L67; // [2997] 3024

    /** text.e:1915	    					if atom(currargv) then*/
    _6329 = IS_ATOM(_currargv_10763);
    if (_6329 == 0)
    {
        _6329 = NOVALUE;
        goto L68; // [3006] 3017
    }
    else{
        _6329 = NOVALUE;
    }

    /** text.e:1916	    						align = '>'*/
    _align_10745 = 62;
    goto L69; // [3014] 3023
L68: 

    /** text.e:1918	    						align = '<'*/
    _align_10745 = 60;
L69: 
L67: 

    /** text.e:1922	    				if atom(currargv) then*/
    _6330 = IS_ATOM(_currargv_10763);
    if (_6330 == 0)
    {
        _6330 = NOVALUE;
        goto L6A; // [3029] 3266
    }
    else{
        _6330 = NOVALUE;
    }

    /** text.e:1923		    				if tsep != 0 and zfill = 0 then*/
    _6331 = (_tsep_10760 != 0);
    if (_6331 == 0) {
        goto L6B; // [3040] 3263
    }
    _6333 = (_zfill_10748 == 0);
    if (_6333 == 0)
    {
        DeRef(_6333);
        _6333 = NOVALUE;
        goto L6B; // [3051] 3263
    }
    else{
        DeRef(_6333);
        _6333 = NOVALUE;
    }

    /** text.e:1924		    					integer dpos*/

    /** text.e:1925		    					integer dist*/

    /** text.e:1926		    					integer bracketed*/

    /** text.e:1928		    					if binout or hexout then*/
    if (_binout_10759 != 0) {
        goto L6C; // [3064] 3073
    }
    if (_hexout_10758 == 0)
    {
        goto L6D; // [3069] 3086
    }
    else{
    }
L6C: 

    /** text.e:1929		    						dist = 4*/
    _dist_11315 = 4;

    /** text.e:1930								psign = 0*/
    _psign_10746 = 0;
    goto L6E; // [3083] 3092
L6D: 

    /** text.e:1932		    						dist = 3*/
    _dist_11315 = 3;
L6E: 

    /** text.e:1934		    					bracketed = (argtext[1] = '(')*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    _6335 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6335)) {
        _bracketed_11316 = (_6335 == 40);
    }
    else {
        _bracketed_11316 = binary_op(EQUALS, _6335, 40);
    }
    _6335 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_11316)) {
        _1 = (object)(DBL_PTR(_bracketed_11316)->dbl);
        DeRefDS(_bracketed_11316);
        _bracketed_11316 = _1;
    }

    /** text.e:1935		    					if bracketed then*/
    if (_bracketed_11316 == 0)
    {
        goto L6F; // [3106] 3124
    }
    else{
    }

    /** text.e:1936		    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6337 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6337 = 1;
    }
    _6338 = _6337 - 1;
    _6337 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, 2, _6338);
L6F: 

    /** text.e:1938		    					dpos = find('.', argtext)*/
    _dpos_11314 = find_from(46, _argtext_10923, 1);

    /** text.e:1939		    					if dpos = 0 then*/
    if (_dpos_11314 != 0)
    goto L70; // [3133] 3149

    /** text.e:1940		    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6342 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6342 = 1;
    }
    _dpos_11314 = _6342 + 1;
    _6342 = NOVALUE;
    goto L71; // [3146] 3163
L70: 

    /** text.e:1942		    						if tsep = '.' then*/
    if (_tsep_10760 != 46)
    goto L72; // [3151] 3162

    /** text.e:1943		    							argtext[dpos] = ','*/
    _2 = (object)SEQ_PTR(_argtext_10923);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _argtext_10923 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _dpos_11314);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 44;
    DeRef(_1);
L72: 
L71: 

    /** text.e:1946		    					while dpos > dist do*/
L73: 
    if (_dpos_11314 <= _dist_11315)
    goto L74; // [3170] 3248

    /** text.e:1947		    						dpos -= dist*/
    _dpos_11314 = _dpos_11314 - _dist_11315;

    /** text.e:1948		    						if dpos > 1 + (currargv < 0) * not msign + (currargv > 0) * psign then*/
    if (IS_ATOM_INT(_currargv_10763)) {
        _6347 = (_currargv_10763 < 0);
    }
    else {
        _6347 = binary_op(LESS, _currargv_10763, 0);
    }
    _6348 = (_msign_10747 == 0);
    if (IS_ATOM_INT(_6347)) {
        if (_6347 == (short)_6347 && _6348 <= INT15 && _6348 >= -INT15){
            _6349 = _6347 * _6348;
        }
        else{
            _6349 = NewDouble(_6347 * (eudouble)_6348);
        }
    }
    else {
        _6349 = binary_op(MULTIPLY, _6347, _6348);
    }
    DeRef(_6347);
    _6347 = NOVALUE;
    _6348 = NOVALUE;
    if (IS_ATOM_INT(_6349)) {
        _6350 = _6349 + 1;
        if (_6350 > MAXINT){
            _6350 = NewDouble((eudouble)_6350);
        }
    }
    else
    _6350 = binary_op(PLUS, 1, _6349);
    DeRef(_6349);
    _6349 = NOVALUE;
    if (IS_ATOM_INT(_currargv_10763)) {
        _6351 = (_currargv_10763 > 0);
    }
    else {
        _6351 = binary_op(GREATER, _currargv_10763, 0);
    }
    if (IS_ATOM_INT(_6351)) {
        if (_6351 == (short)_6351 && _psign_10746 <= INT15 && _psign_10746 >= -INT15){
            _6352 = _6351 * _psign_10746;
        }
        else{
            _6352 = NewDouble(_6351 * (eudouble)_psign_10746);
        }
    }
    else {
        _6352 = binary_op(MULTIPLY, _6351, _psign_10746);
    }
    DeRef(_6351);
    _6351 = NOVALUE;
    if (IS_ATOM_INT(_6350) && IS_ATOM_INT(_6352)) {
        _6353 = _6350 + _6352;
        if ((object)((uintptr_t)_6353 + (uintptr_t)HIGH_BITS) >= 0){
            _6353 = NewDouble((eudouble)_6353);
        }
    }
    else {
        _6353 = binary_op(PLUS, _6350, _6352);
    }
    DeRef(_6350);
    _6350 = NOVALUE;
    DeRef(_6352);
    _6352 = NOVALUE;
    if (binary_op_a(LESSEQ, _dpos_11314, _6353)){
        DeRef(_6353);
        _6353 = NOVALUE;
        goto L73; // [3213] 3168
    }
    DeRef(_6353);
    _6353 = NOVALUE;

    /** text.e:1949		    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _6355 = _dpos_11314 - 1;
    rhs_slice_target = (object_ptr)&_6356;
    RHS_Slice(_argtext_10923, 1, _6355);
    if (IS_SEQUENCE(_argtext_10923)){
            _6357 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6357 = 1;
    }
    rhs_slice_target = (object_ptr)&_6358;
    RHS_Slice(_argtext_10923, _dpos_11314, _6357);
    {
        object concat_list[3];

        concat_list[0] = _6358;
        concat_list[1] = _tsep_10760;
        concat_list[2] = _6356;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6358);
    _6358 = NOVALUE;
    DeRefDS(_6356);
    _6356 = NOVALUE;

    /** text.e:1951		    					end while*/
    goto L73; // [3245] 3168
L74: 

    /** text.e:1952		    					if bracketed then*/
    if (_bracketed_11316 == 0)
    {
        goto L75; // [3250] 3262
    }
    else{
    }

    /** text.e:1953		    						argtext = '(' & argtext & ')'*/
    {
        object concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_10923;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
L75: 
L6B: 
L6A: 

    /** text.e:1958	    				if width <= 0 then*/
    if (_width_10752 > 0)
    goto L76; // [3270] 3280

    /** text.e:1959	    					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_10923)){
            _width_10752 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _width_10752 = 1;
    }
L76: 

    /** text.e:1963	    				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6363 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6363 = 1;
    }
    if (_width_10752 >= _6363)
    goto L77; // [3285] 3416

    /** text.e:1964	    					if align = '>' then*/
    if (_align_10745 != 62)
    goto L78; // [3291] 3319

    /** text.e:1965	    						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6366 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6366 = 1;
    }
    _6367 = _6366 - _width_10752;
    if ((object)((uintptr_t)_6367 +(uintptr_t) HIGH_BITS) >= 0){
        _6367 = NewDouble((eudouble)_6367);
    }
    _6366 = NOVALUE;
    if (IS_ATOM_INT(_6367)) {
        _6368 = _6367 + 1;
        if (_6368 > MAXINT){
            _6368 = NewDouble((eudouble)_6368);
        }
    }
    else
    _6368 = binary_op(PLUS, 1, _6367);
    DeRef(_6367);
    _6367 = NOVALUE;
    if (IS_SEQUENCE(_argtext_10923)){
            _6369 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6369 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, _6368, _6369);
    goto L79; // [3316] 3553
L78: 

    /** text.e:1966	    					elsif align = 'c' then*/
    if (_align_10745 != 99)
    goto L7A; // [3321] 3405

    /** text.e:1967	    						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6372 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6372 = 1;
    }
    _pos_10754 = _6372 - _width_10752;
    _6372 = NOVALUE;

    /** text.e:1968	    						if remainder(pos, 2) = 0 then*/
    _6374 = (_pos_10754 % 2);
    if (_6374 != 0)
    goto L7B; // [3340] 3373

    /** text.e:1969	    							pos = pos / 2*/
    if (_pos_10754 & 1) {
        _pos_10754 = NewDouble((_pos_10754 >> 1) + 0.5);
    }
    else
    _pos_10754 = _pos_10754 >> 1;
    if (!IS_ATOM_INT(_pos_10754)) {
        _1 = (object)(DBL_PTR(_pos_10754)->dbl);
        DeRefDS(_pos_10754);
        _pos_10754 = _1;
    }

    /** text.e:1970	    							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _6377 = _pos_10754 + 1;
    if (_6377 > MAXINT){
        _6377 = NewDouble((eudouble)_6377);
    }
    if (IS_SEQUENCE(_argtext_10923)){
            _6378 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6378 = 1;
    }
    _6379 = _6378 - _pos_10754;
    _6378 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, _6377, _6379);
    goto L79; // [3370] 3553
L7B: 

    /** text.e:1972	    							pos = floor(pos / 2)*/
    _pos_10754 = _pos_10754 >> 1;

    /** text.e:1973	    							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _6382 = _pos_10754 + 1;
    if (_6382 > MAXINT){
        _6382 = NewDouble((eudouble)_6382);
    }
    if (IS_SEQUENCE(_argtext_10923)){
            _6383 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6383 = 1;
    }
    _6384 = _6383 - _pos_10754;
    if ((object)((uintptr_t)_6384 +(uintptr_t) HIGH_BITS) >= 0){
        _6384 = NewDouble((eudouble)_6384);
    }
    _6383 = NOVALUE;
    if (IS_ATOM_INT(_6384)) {
        _6385 = _6384 - 1;
    }
    else {
        _6385 = NewDouble(DBL_PTR(_6384)->dbl - (eudouble)1);
    }
    DeRef(_6384);
    _6384 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, _6382, _6385);
    goto L79; // [3402] 3553
L7A: 

    /** text.e:1976	    						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_10923;
    RHS_Slice(_argtext_10923, 1, _width_10752);
    goto L79; // [3413] 3553
L77: 

    /** text.e:1978	    				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6388 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6388 = 1;
    }
    if (_width_10752 <= _6388)
    goto L7C; // [3421] 3552

    /** text.e:1979							if align = '>' then*/
    if (_align_10745 != 62)
    goto L7D; // [3427] 3451

    /** text.e:1980								argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6391 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6391 = 1;
    }
    _6392 = _width_10752 - _6391;
    _6391 = NOVALUE;
    _6393 = Repeat(32, _6392);
    _6392 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _6393, _argtext_10923);
    DeRefDS(_6393);
    _6393 = NOVALUE;
    DeRef(_6393);
    _6393 = NOVALUE;
    goto L7E; // [3448] 3551
L7D: 

    /** text.e:1981	    					elsif align = 'c' then*/
    if (_align_10745 != 99)
    goto L7F; // [3453] 3533

    /** text.e:1982	    						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6396 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6396 = 1;
    }
    _pos_10754 = _width_10752 - _6396;
    _6396 = NOVALUE;

    /** text.e:1983	    						if remainder(pos, 2) = 0 then*/
    _6398 = (_pos_10754 % 2);
    if (_6398 != 0)
    goto L80; // [3472] 3503

    /** text.e:1984	    							pos = pos / 2*/
    if (_pos_10754 & 1) {
        _pos_10754 = NewDouble((_pos_10754 >> 1) + 0.5);
    }
    else
    _pos_10754 = _pos_10754 >> 1;
    if (!IS_ATOM_INT(_pos_10754)) {
        _1 = (object)(DBL_PTR(_pos_10754)->dbl);
        DeRefDS(_pos_10754);
        _pos_10754 = _1;
    }

    /** text.e:1985	    							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _6401 = Repeat(32, _pos_10754);
    _6402 = Repeat(32, _pos_10754);
    {
        object concat_list[3];

        concat_list[0] = _6402;
        concat_list[1] = _argtext_10923;
        concat_list[2] = _6401;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6402);
    _6402 = NOVALUE;
    DeRefDS(_6401);
    _6401 = NOVALUE;
    goto L7E; // [3500] 3551
L80: 

    /** text.e:1987	    							pos = floor(pos / 2)*/
    _pos_10754 = _pos_10754 >> 1;

    /** text.e:1988	    							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _6405 = Repeat(32, _pos_10754);
    _6406 = _pos_10754 + 1;
    _6407 = Repeat(32, _6406);
    _6406 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _6407;
        concat_list[1] = _argtext_10923;
        concat_list[2] = _6405;
        Concat_N((object_ptr)&_argtext_10923, concat_list, 3);
    }
    DeRefDS(_6407);
    _6407 = NOVALUE;
    DeRefDS(_6405);
    _6405 = NOVALUE;
    goto L7E; // [3530] 3551
L7F: 

    /** text.e:1992								argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_10923)){
            _6409 = SEQ_PTR(_argtext_10923)->length;
    }
    else {
        _6409 = 1;
    }
    _6410 = _width_10752 - _6409;
    _6409 = NOVALUE;
    _6411 = Repeat(32, _6410);
    _6410 = NOVALUE;
    Concat((object_ptr)&_argtext_10923, _argtext_10923, _6411);
    DeRefDS(_6411);
    _6411 = NOVALUE;
L7E: 
L7C: 
L79: 

    /** text.e:1995	    				result &= argtext*/
    Concat((object_ptr)&_result_10739, _result_10739, _argtext_10923);
    goto L81; // [3559] 3575
L58: 

    /** text.e:1998	    				if spacer then*/
    if (_spacer_10750 == 0)
    {
        goto L82; // [3564] 3574
    }
    else{
    }

    /** text.e:1999	    					result &= ' '*/
    Append(&_result_10739, _result_10739, 32);
L82: 
L81: 

    /** text.e:2003	   				if trimming then*/
    if (_trimming_10757 == 0)
    {
        goto L83; // [3579] 3593
    }
    else{
    }

    /** text.e:2004	   					result = trim(result)*/
    RefDS(_result_10739);
    RefDS(_4905);
    _0 = _result_10739;
    _result_10739 = _12trim(_result_10739, _4905, 0);
    DeRefDS(_0);
L83: 

    /** text.e:2007	    			tend = 0*/
    _tend_10743 = 0;

    /** text.e:2008			    	prevargv = currargv*/
    Ref(_currargv_10763);
    DeRef(_prevargv_10762);
    _prevargv_10762 = _currargv_10763;
L1F: 
    DeRef(_argtext_10923);
    _argtext_10923 = NOVALUE;

    /** text.e:2011	    end while*/
    goto L2; // [3611] 60
L3: 

    /** text.e:2013		return result*/
    DeRefDS(_format_pattern_10737);
    DeRef(_arg_list_10738);
    DeRef(_prevargv_10762);
    DeRef(_currargv_10763);
    DeRef(_idname_10764);
    DeRef(_envsym_10765);
    DeRefi(_envvar_10766);
    DeRef(_6010);
    _6010 = NOVALUE;
    DeRef(_6322);
    _6322 = NOVALUE;
    DeRef(_6033);
    _6033 = NOVALUE;
    DeRef(_6200);
    _6200 = NOVALUE;
    DeRef(_6338);
    _6338 = NOVALUE;
    DeRef(_6368);
    _6368 = NOVALUE;
    DeRef(_6101);
    _6101 = NOVALUE;
    DeRef(_6081);
    _6081 = NOVALUE;
    DeRef(_6382);
    _6382 = NOVALUE;
    DeRef(_6379);
    _6379 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6164);
    _6164 = NOVALUE;
    DeRef(_6385);
    _6385 = NOVALUE;
    DeRef(_6091);
    _6091 = NOVALUE;
    DeRef(_6111);
    _6111 = NOVALUE;
    DeRef(_6182);
    _6182 = NOVALUE;
    DeRef(_6312);
    _6312 = NOVALUE;
    DeRef(_6121);
    _6121 = NOVALUE;
    DeRef(_6072);
    _6072 = NOVALUE;
    DeRef(_6331);
    _6331 = NOVALUE;
    DeRef(_6377);
    _6377 = NOVALUE;
    DeRef(_6374);
    _6374 = NOVALUE;
    DeRef(_6237);
    _6237 = NOVALUE;
    DeRef(_6259);
    _6259 = NOVALUE;
    DeRef(_6308);
    _6308 = NOVALUE;
    _6239 = NOVALUE;
    DeRef(_6355);
    _6355 = NOVALUE;
    DeRef(_6398);
    _6398 = NOVALUE;
    DeRef(_6060);
    _6060 = NOVALUE;
    return _result_10739;
    ;
}



// 0x4D255A5A
