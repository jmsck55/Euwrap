// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55update_checksum(object _raw_data_45793)
{
    object _23822 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23822 = calc_hash(_raw_data_45793, -5);
    _0 = _55cfile_check_45774;
    if (IS_ATOM_INT(_55cfile_check_45774) && IS_ATOM_INT(_23822)) {
        {uintptr_t tu;
             tu = (uintptr_t)_55cfile_check_45774 ^ (uintptr_t)_23822;
             _55cfile_check_45774 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_55cfile_check_45774)) {
            temp_d.dbl = (eudouble)_55cfile_check_45774;
            _55cfile_check_45774 = Dxor_bits(&temp_d, DBL_PTR(_23822));
        }
        else {
            if (IS_ATOM_INT(_23822)) {
                temp_d.dbl = (eudouble)_23822;
                _55cfile_check_45774 = Dxor_bits(DBL_PTR(_55cfile_check_45774), &temp_d);
            }
            else
            _55cfile_check_45774 = Dxor_bits(DBL_PTR(_55cfile_check_45774), DBL_PTR(_23822));
        }
    }
    DeRef(_0);
    DeRef(_23822);
    _23822 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45793);
    return;
    ;
}


void _55write_checksum(object _file_45798)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45798, _23824, _55cfile_check_45774);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_55cfile_check_45774);
    _55cfile_check_45774 = 0;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _55find_file_element(object _needle_45802, object _files_45803)
{
    object _23840 = NOVALUE;
    object _23839 = NOVALUE;
    object _23838 = NOVALUE;
    object _23837 = NOVALUE;
    object _23836 = NOVALUE;
    object _23835 = NOVALUE;
    object _23834 = NOVALUE;
    object _23833 = NOVALUE;
    object _23832 = NOVALUE;
    object _23831 = NOVALUE;
    object _23830 = NOVALUE;
    object _23829 = NOVALUE;
    object _23828 = NOVALUE;
    object _23827 = NOVALUE;
    object _23826 = NOVALUE;
    object _23825 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:228		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45803)){
            _23825 = SEQ_PTR(_files_45803)->length;
    }
    else {
        _23825 = 1;
    }
    {
        object _j_45805;
        _j_45805 = 1;
L1: 
        if (_j_45805 > _23825){
            goto L2; // [10] 50
        }

        /** buildsys.e:229			if equal(files[j][D_NAME],needle) then*/
        _2 = (object)SEQ_PTR(_files_45803);
        _23826 = (object)*(((s1_ptr)_2)->base + _j_45805);
        _2 = (object)SEQ_PTR(_23826);
        _23827 = (object)*(((s1_ptr)_2)->base + 1);
        _23826 = NOVALUE;
        if (_23827 == _needle_45802)
        _23828 = 1;
        else if (IS_ATOM_INT(_23827) && IS_ATOM_INT(_needle_45802))
        _23828 = 0;
        else
        _23828 = (compare(_23827, _needle_45802) == 0);
        _23827 = NOVALUE;
        if (_23828 == 0)
        {
            _23828 = NOVALUE;
            goto L3; // [33] 43
        }
        else{
            _23828 = NOVALUE;
        }

        /** buildsys.e:230				return j*/
        DeRefDS(_needle_45802);
        DeRefDS(_files_45803);
        return _j_45805;
L3: 

        /** buildsys.e:232		end for*/
        _j_45805 = _j_45805 + 1;
        goto L1; // [45] 17
L2: 
        ;
    }

    /** buildsys.e:233		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45803)){
            _23829 = SEQ_PTR(_files_45803)->length;
    }
    else {
        _23829 = 1;
    }
    {
        object _j_45813;
        _j_45813 = 1;
L4: 
        if (_j_45813 > _23829){
            goto L5; // [55] 103
        }

        /** buildsys.e:234			if equal(lower(files[j][D_NAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45803);
        _23830 = (object)*(((s1_ptr)_2)->base + _j_45813);
        _2 = (object)SEQ_PTR(_23830);
        _23831 = (object)*(((s1_ptr)_2)->base + 1);
        _23830 = NOVALUE;
        Ref(_23831);
        _23832 = _12lower(_23831);
        _23831 = NOVALUE;
        RefDS(_needle_45802);
        _23833 = _12lower(_needle_45802);
        if (_23832 == _23833)
        _23834 = 1;
        else if (IS_ATOM_INT(_23832) && IS_ATOM_INT(_23833))
        _23834 = 0;
        else
        _23834 = (compare(_23832, _23833) == 0);
        DeRef(_23832);
        _23832 = NOVALUE;
        DeRef(_23833);
        _23833 = NOVALUE;
        if (_23834 == 0)
        {
            _23834 = NOVALUE;
            goto L6; // [86] 96
        }
        else{
            _23834 = NOVALUE;
        }

        /** buildsys.e:235				return j*/
        DeRefDS(_needle_45802);
        DeRefDS(_files_45803);
        return _j_45813;
L6: 

        /** buildsys.e:237		end for*/
        _j_45813 = _j_45813 + 1;
        goto L4; // [98] 62
L5: 
        ;
    }

    /** buildsys.e:239		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45803)){
            _23835 = SEQ_PTR(_files_45803)->length;
    }
    else {
        _23835 = 1;
    }
    {
        object _j_45825;
        _j_45825 = 1;
L7: 
        if (_j_45825 > _23835){
            goto L8; // [108] 156
        }

        /** buildsys.e:240			if equal(lower(files[j][D_ALTNAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45803);
        _23836 = (object)*(((s1_ptr)_2)->base + _j_45825);
        _2 = (object)SEQ_PTR(_23836);
        _23837 = (object)*(((s1_ptr)_2)->base + 11);
        _23836 = NOVALUE;
        Ref(_23837);
        _23838 = _12lower(_23837);
        _23837 = NOVALUE;
        RefDS(_needle_45802);
        _23839 = _12lower(_needle_45802);
        if (_23838 == _23839)
        _23840 = 1;
        else if (IS_ATOM_INT(_23838) && IS_ATOM_INT(_23839))
        _23840 = 0;
        else
        _23840 = (compare(_23838, _23839) == 0);
        DeRef(_23838);
        _23838 = NOVALUE;
        DeRef(_23839);
        _23839 = NOVALUE;
        if (_23840 == 0)
        {
            _23840 = NOVALUE;
            goto L9; // [139] 149
        }
        else{
            _23840 = NOVALUE;
        }

        /** buildsys.e:241				return j*/
        DeRefDS(_needle_45802);
        DeRefDS(_files_45803);
        return _j_45825;
L9: 

        /** buildsys.e:243		end for*/
        _j_45825 = _j_45825 + 1;
        goto L7; // [151] 115
L8: 
        ;
    }

    /** buildsys.e:244		return 0*/
    DeRefDS(_needle_45802);
    DeRefDS(_files_45803);
    return 0;
    ;
}


object _55adjust_for_command_line_passing(object _long_path_45846)
{
    object _slash_45847 = NOVALUE;
    object _longs_45855 = NOVALUE;
    object _short_path_45861 = NOVALUE;
    object _files_45867 = NOVALUE;
    object _file_location_45870 = NOVALUE;
    object _23879 = NOVALUE;
    object _23878 = NOVALUE;
    object _23876 = NOVALUE;
    object _23875 = NOVALUE;
    object _23873 = NOVALUE;
    object _23872 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _23863 = NOVALUE;
    object _23862 = NOVALUE;
    object _23861 = NOVALUE;
    object _23860 = NOVALUE;
    object _23859 = NOVALUE;
    object _23857 = NOVALUE;
    object _23856 = NOVALUE;
    object _23854 = NOVALUE;
    object _23852 = NOVALUE;
    object _23850 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:315			slash = SLASH*/
    _slash_45847 = 92;

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:320			long_path = regex:find_replace(quote_pattern, long_path, "")*/
    Ref(_55quote_pattern_45839);
    RefDS(_long_path_45846);
    RefDS(_22209);
    _0 = _long_path_45846;
    _long_path_45846 = _51find_replace(_55quote_pattern_45839, _long_path_45846, _22209, 1, 0);
    DeRefDS(_0);

    /** buildsys.e:321			sequence longs = split( slash_pattern, long_path )*/
    Ref(_55slash_pattern_45836);
    RefDS(_long_path_45846);
    _0 = _longs_45855;
    _longs_45855 = _51split(_55slash_pattern_45836, _long_path_45846, 1, 0);
    DeRef(_0);

    /** buildsys.e:322			if length(longs)=0 then*/
    if (IS_SEQUENCE(_longs_45855)){
            _23850 = SEQ_PTR(_longs_45855)->length;
    }
    else {
        _23850 = 1;
    }
    if (_23850 != 0)
    goto L1; // [79] 90

    /** buildsys.e:323				return long_path*/
    DeRefDS(_longs_45855);
    DeRef(_short_path_45861);
    return _long_path_45846;
L1: 

    /** buildsys.e:325			sequence short_path = longs[1] & slash*/
    _2 = (object)SEQ_PTR(_longs_45855);
    _23852 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_23852) && IS_ATOM(_slash_45847)) {
        Append(&_short_path_45861, _23852, _slash_45847);
    }
    else if (IS_ATOM(_23852) && IS_SEQUENCE(_slash_45847)) {
    }
    else {
        Concat((object_ptr)&_short_path_45861, _23852, _slash_45847);
        _23852 = NOVALUE;
    }
    _23852 = NOVALUE;

    /** buildsys.e:326			for i = 2 to length(longs) do*/
    if (IS_SEQUENCE(_longs_45855)){
            _23854 = SEQ_PTR(_longs_45855)->length;
    }
    else {
        _23854 = 1;
    }
    {
        object _i_45865;
        _i_45865 = 2;
L2: 
        if (_i_45865 > _23854){
            goto L3; // [107] 266
        }

        /** buildsys.e:327				object files = dir(short_path)*/
        RefDS(_short_path_45861);
        _0 = _files_45867;
        _files_45867 = _15dir(_short_path_45861);
        DeRef(_0);

        /** buildsys.e:328				integer file_location = 0*/
        _file_location_45870 = 0;

        /** buildsys.e:329				if sequence(files) then*/
        _23856 = IS_SEQUENCE(_files_45867);
        if (_23856 == 0)
        {
            _23856 = NOVALUE;
            goto L4; // [130] 147
        }
        else{
            _23856 = NOVALUE;
        }

        /** buildsys.e:330					file_location = find_file_element(longs[i], files)*/
        _2 = (object)SEQ_PTR(_longs_45855);
        _23857 = (object)*(((s1_ptr)_2)->base + _i_45865);
        Ref(_23857);
        Ref(_files_45867);
        _file_location_45870 = _55find_file_element(_23857, _files_45867);
        _23857 = NOVALUE;
        if (!IS_ATOM_INT(_file_location_45870)) {
            _1 = (object)(DBL_PTR(_file_location_45870)->dbl);
            DeRefDS(_file_location_45870);
            _file_location_45870 = _1;
        }
L4: 

        /** buildsys.e:332				if file_location then*/
        if (_file_location_45870 == 0)
        {
            goto L5; // [149] 215
        }
        else{
        }

        /** buildsys.e:333					if sequence(files[file_location][D_ALTNAME]) then*/
        _2 = (object)SEQ_PTR(_files_45867);
        _23859 = (object)*(((s1_ptr)_2)->base + _file_location_45870);
        _2 = (object)SEQ_PTR(_23859);
        _23860 = (object)*(((s1_ptr)_2)->base + 11);
        _23859 = NOVALUE;
        _23861 = IS_SEQUENCE(_23860);
        _23860 = NOVALUE;
        if (_23861 == 0)
        {
            _23861 = NOVALUE;
            goto L6; // [167] 189
        }
        else{
            _23861 = NOVALUE;
        }

        /** buildsys.e:334						short_path &= files[file_location][D_ALTNAME]*/
        _2 = (object)SEQ_PTR(_files_45867);
        _23862 = (object)*(((s1_ptr)_2)->base + _file_location_45870);
        _2 = (object)SEQ_PTR(_23862);
        _23863 = (object)*(((s1_ptr)_2)->base + 11);
        _23862 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45861) && IS_ATOM(_23863)) {
            Ref(_23863);
            Append(&_short_path_45861, _short_path_45861, _23863);
        }
        else if (IS_ATOM(_short_path_45861) && IS_SEQUENCE(_23863)) {
        }
        else {
            Concat((object_ptr)&_short_path_45861, _short_path_45861, _23863);
        }
        _23863 = NOVALUE;
        goto L7; // [186] 206
L6: 

        /** buildsys.e:336						short_path &= files[file_location][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_45867);
        _23865 = (object)*(((s1_ptr)_2)->base + _file_location_45870);
        _2 = (object)SEQ_PTR(_23865);
        _23866 = (object)*(((s1_ptr)_2)->base + 1);
        _23865 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45861) && IS_ATOM(_23866)) {
            Ref(_23866);
            Append(&_short_path_45861, _short_path_45861, _23866);
        }
        else if (IS_ATOM(_short_path_45861) && IS_SEQUENCE(_23866)) {
        }
        else {
            Concat((object_ptr)&_short_path_45861, _short_path_45861, _23866);
        }
        _23866 = NOVALUE;
L7: 

        /** buildsys.e:338					short_path &= slash*/
        Append(&_short_path_45861, _short_path_45861, _slash_45847);
        goto L8; // [212] 257
L5: 

        /** buildsys.e:340					if not find(' ',longs[i]) then*/
        _2 = (object)SEQ_PTR(_longs_45855);
        _23869 = (object)*(((s1_ptr)_2)->base + _i_45865);
        _23870 = find_from(32, _23869, 1);
        _23869 = NOVALUE;
        if (_23870 != 0)
        goto L9; // [226] 250
        _23870 = NOVALUE;

        /** buildsys.e:341						short_path &= longs[i] & slash*/
        _2 = (object)SEQ_PTR(_longs_45855);
        _23872 = (object)*(((s1_ptr)_2)->base + _i_45865);
        if (IS_SEQUENCE(_23872) && IS_ATOM(_slash_45847)) {
            Append(&_23873, _23872, _slash_45847);
        }
        else if (IS_ATOM(_23872) && IS_SEQUENCE(_slash_45847)) {
        }
        else {
            Concat((object_ptr)&_23873, _23872, _slash_45847);
            _23872 = NOVALUE;
        }
        _23872 = NOVALUE;
        Concat((object_ptr)&_short_path_45861, _short_path_45861, _23873);
        DeRefDS(_23873);
        _23873 = NOVALUE;

        /** buildsys.e:342						continue*/
        DeRef(_files_45867);
        _files_45867 = NOVALUE;
        goto LA; // [247] 261
L9: 

        /** buildsys.e:344					return 0*/
        DeRef(_files_45867);
        DeRefDS(_long_path_45846);
        DeRef(_longs_45855);
        DeRef(_short_path_45861);
        return 0;
L8: 
        DeRef(_files_45867);
        _files_45867 = NOVALUE;

        /** buildsys.e:346			end for -- i*/
LA: 
        _i_45865 = _i_45865 + 1;
        goto L2; // [261] 114
L3: 
        ;
    }

    /** buildsys.e:347			if short_path[$] = slash then*/
    if (IS_SEQUENCE(_short_path_45861)){
            _23875 = SEQ_PTR(_short_path_45861)->length;
    }
    else {
        _23875 = 1;
    }
    _2 = (object)SEQ_PTR(_short_path_45861);
    _23876 = (object)*(((s1_ptr)_2)->base + _23875);
    if (binary_op_a(NOTEQ, _23876, _slash_45847)){
        _23876 = NOVALUE;
        goto LB; // [275] 294
    }
    _23876 = NOVALUE;

    /** buildsys.e:348				short_path = short_path[1..$-1]*/
    if (IS_SEQUENCE(_short_path_45861)){
            _23878 = SEQ_PTR(_short_path_45861)->length;
    }
    else {
        _23878 = 1;
    }
    _23879 = _23878 - 1;
    _23878 = NOVALUE;
    rhs_slice_target = (object_ptr)&_short_path_45861;
    RHS_Slice(_short_path_45861, 1, _23879);
LB: 

    /** buildsys.e:350			return short_path*/
    DeRefDS(_long_path_45846);
    DeRef(_longs_45855);
    DeRef(_23879);
    _23879 = NOVALUE;
    return _short_path_45861;
    ;
}


object _55adjust_for_build_file(object _long_path_45908)
{
    object _short_path_45909 = NOVALUE;
    object _23887 = NOVALUE;
    object _23886 = NOVALUE;
    object _23885 = NOVALUE;
    object _23884 = NOVALUE;
    object _23883 = NOVALUE;
    object _23882 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45908);
    _0 = _short_path_45909;
    _short_path_45909 = _55adjust_for_command_line_passing(_long_path_45908);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23882 = IS_ATOM(_short_path_45909);
    if (_23882 == 0)
    {
        _23882 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23882 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45908);
    return _short_path_45909;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23883 = (0 == 1);
    if (_23883 == 0) {
        _23884 = 0;
        goto L2; // [32] 46
    }
    _23885 = (3 != 3);
    _23884 = (_23885 != 0);
L2: 
    if (_23884 == 0) {
        goto L3; // [46] 69
    }
    if (_44TWINDOWS_20715 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45909);
    _23887 = _55windows_to_mingw_path(_short_path_45909);
    DeRefDS(_long_path_45908);
    DeRef(_short_path_45909);
    DeRef(_23883);
    _23883 = NOVALUE;
    DeRef(_23885);
    _23885 = NOVALUE;
    return _23887;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45908);
    DeRef(_23887);
    _23887 = NOVALUE;
    DeRef(_23883);
    _23883 = NOVALUE;
    DeRef(_23885);
    _23885 = NOVALUE;
    return _short_path_45909;
L4: 
    ;
}


object _55setup_build()
{
    object _c_exe_45924 = NOVALUE;
    object _c_flags_45925 = NOVALUE;
    object _l_exe_45926 = NOVALUE;
    object _l_flags_45927 = NOVALUE;
    object _obj_ext_45928 = NOVALUE;
    object _exe_ext_45929 = NOVALUE;
    object _l_flags_begin_45930 = NOVALUE;
    object _rc_comp_45931 = NOVALUE;
    object _l_names_45932 = NOVALUE;
    object _l_ext_45933 = NOVALUE;
    object _t_slash_45934 = NOVALUE;
    object _eudir_45976 = NOVALUE;
    object _compile_dir_46034 = NOVALUE;
    object _bits_46045 = NOVALUE;
    object _m_flag_46055 = NOVALUE;
    object _24044 = NOVALUE;
    object _24041 = NOVALUE;
    object _24040 = NOVALUE;
    object _24037 = NOVALUE;
    object _24036 = NOVALUE;
    object _24033 = NOVALUE;
    object _24032 = NOVALUE;
    object _24029 = NOVALUE;
    object _24028 = NOVALUE;
    object _24021 = NOVALUE;
    object _24020 = NOVALUE;
    object _24015 = NOVALUE;
    object _24014 = NOVALUE;
    object _24009 = NOVALUE;
    object _24008 = NOVALUE;
    object _24005 = NOVALUE;
    object _24004 = NOVALUE;
    object _23992 = NOVALUE;
    object _23991 = NOVALUE;
    object _23976 = NOVALUE;
    object _23975 = NOVALUE;
    object _23967 = NOVALUE;
    object _23965 = NOVALUE;
    object _23964 = NOVALUE;
    object _23963 = NOVALUE;
    object _23962 = NOVALUE;
    object _23958 = NOVALUE;
    object _23957 = NOVALUE;
    object _23943 = NOVALUE;
    object _23942 = NOVALUE;
    object _23939 = NOVALUE;
    object _23927 = NOVALUE;
    object _23923 = NOVALUE;
    object _23920 = NOVALUE;
    object _23919 = NOVALUE;
    object _23918 = NOVALUE;
    object _23915 = NOVALUE;
    object _23914 = NOVALUE;
    object _23913 = NOVALUE;
    object _23910 = NOVALUE;
    object _23906 = NOVALUE;
    object _23905 = NOVALUE;
    object _23903 = NOVALUE;
    object _23902 = NOVALUE;
    object _23901 = NOVALUE;
    object _23900 = NOVALUE;
    object _23893 = NOVALUE;
    object _23892 = NOVALUE;
    object _23891 = NOVALUE;
    object _23890 = NOVALUE;
    object _23889 = NOVALUE;
    object _23888 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_22209);
    DeRef(_c_exe_45924);
    _c_exe_45924 = _22209;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_22209);
    DeRef(_c_flags_45925);
    _c_flags_45925 = _22209;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_22209);
    DeRef(_l_exe_45926);
    _l_exe_45926 = _22209;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_22209);
    DeRefi(_l_flags_45927);
    _l_flags_45927 = _22209;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_22209);
    DeRefi(_obj_ext_45928);
    _obj_ext_45928 = _22209;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_22209);
    DeRefi(_exe_ext_45929);
    _exe_ext_45929 = _22209;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_22209);
    DeRefi(_l_flags_begin_45930);
    _l_flags_begin_45930 = _22209;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_22209);
    DeRef(_rc_comp_45931);
    _rc_comp_45931 = _22209;

    /** buildsys.e:385		if dll_option*/
    if (_57dll_option_42941 == 0) {
        _23888 = 0;
        goto L1; // [61] 78
    }
    _23889 = 0;
    _23890 = (0 > 0);
    _23889 = NOVALUE;
    _23888 = (_23890 != 0);
L1: 
    if (_23888 == 0) {
        goto L2; // [78] 101
    }
    _23892 = (_44TWINDOWS_20715 == 0);
    if (_23892 == 0)
    {
        DeRef(_23892);
        _23892 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23892);
        _23892 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_57user_pic_library_42954);
    DeRef(_57user_library_42953);
    _57user_library_42953 = _57user_pic_library_42954;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_57user_library_42953)){
            _23893 = SEQ_PTR(_57user_library_42953)->length;
    }
    else {
        _23893 = 1;
    }
    if (_23893 != 0)
    goto L3; // [108] 366

    /** buildsys.e:392			if debug_option then*/
    if (_57debug_option_42951 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23896);
    RefDS(_23895);
    DeRef(_l_names_45932);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23895;
    ((intptr_t *)_2)[2] = _23896;
    _l_names_45932 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23895);
    RefDS(_23896);
    DeRef(_l_names_45932);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23896;
    ((intptr_t *)_2)[2] = _23895;
    _l_names_45932 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (0 != 0) {
        goto L6; // [139] 154
    }
    _23900 = (0 == 1);
    if (_23900 == 0)
    {
        DeRef(_23900);
        _23900 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23900);
        _23900 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22490);
    DeRefi(_l_ext_45933);
    _l_ext_45933 = _22490;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23785);
    DeRefi(_t_slash_45934);
    _t_slash_45934 = _23785;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_57dll_option_42941 == 0) {
        goto L8; // [172] 247
    }
    _23902 = (_44TWINDOWS_20715 == 0);
    if (_23902 == 0)
    {
        DeRef(_23902);
        _23902 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23902);
        _23902 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45932)){
            _23903 = SEQ_PTR(_l_names_45932)->length;
    }
    else {
        _23903 = 1;
    }
    {
        object _i_45967;
        _i_45967 = 1;
L9: 
        if (_i_45967 > _23903){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45932);
        _23905 = (object)*(((s1_ptr)_2)->base + _i_45967);
        if (IS_SEQUENCE(_23905) && IS_ATOM(_23904)) {
        }
        else if (IS_ATOM(_23905) && IS_SEQUENCE(_23904)) {
            Ref(_23905);
            Prepend(&_23906, _23904, _23905);
        }
        else {
            Concat((object_ptr)&_23906, _23905, _23904);
            _23905 = NOVALUE;
        }
        _23905 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45932);
        _2 = (object)(((s1_ptr)_2)->base + _i_45967);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23906;
        if( _1 != _23906 ){
            DeRef(_1);
        }
        _23906 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45967 = _i_45967 + 1;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
    if (_44TWINDOWS_20715 == 0)
    {
        goto LB; // [228] 246
    }
    else{
    }

    /** buildsys.e:410				l_ext = "lib"*/
    RefDS(_23907);
    DeRefi(_l_ext_45933);
    _l_ext_45933 = _23907;

    /** buildsys.e:411				t_slash = "\\"*/
    RefDS(_23908);
    DeRefi(_t_slash_45934);
    _t_slash_45934 = _23908;
LB: 
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45976;
    _eudir_45976 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45976);
    _23910 = _15file_exists(_eudir_45976);
    if (IS_ATOM_INT(_23910)) {
        if (_23910 != 0){
            DeRef(_23910);
            _23910 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23910)->dbl != 0.0){
            DeRef(_23910);
            _23910 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    DeRef(_23910);
    _23910 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23913 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23913;
    _23914 = MAKE_SEQ(_1);
    _23913 = NOVALUE;
    EPrintf(2, _23912, _23914);
    DeRefDS(_23914);
    _23914 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1);
LC: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45932)){
            _23915 = SEQ_PTR(_l_names_45932)->length;
    }
    else {
        _23915 = 1;
    }
    {
        object _tk_45988;
        _tk_45988 = 1;
LD: 
        if (_tk_45988 > _23915){
            goto LE; // [286] 365
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45932);
        _23918 = (object)*(((s1_ptr)_2)->base + _tk_45988);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45934, 2);
        ((intptr_t*)_2)[1] = _t_slash_45934;
        ((intptr_t*)_2)[2] = _t_slash_45934;
        Ref(_23918);
        ((intptr_t*)_2)[3] = _23918;
        RefDS(_l_ext_45933);
        ((intptr_t*)_2)[4] = _l_ext_45933;
        _23919 = MAKE_SEQ(_1);
        _23918 = NOVALUE;
        _23920 = EPrintf(-9999999, _23917, _23919);
        DeRefDS(_23919);
        _23919 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45976) && IS_ATOM(_23920)) {
        }
        else if (IS_ATOM(_eudir_45976) && IS_SEQUENCE(_23920)) {
            Ref(_eudir_45976);
            Prepend(&_57user_library_42953, _23920, _eudir_45976);
        }
        else {
            Concat((object_ptr)&_57user_library_42953, _eudir_45976, _23920);
        }
        DeRefDS(_23920);
        _23920 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (0 != 0) {
            goto LF; // [324] 339
        }
        _23923 = (0 == 1);
        if (_23923 == 0)
        {
            DeRef(_23923);
            _23923 = NOVALUE;
            goto L10; // [335] 342
        }
        else{
            DeRef(_23923);
            _23923 = NOVALUE;
        }
LF: 

        /** buildsys.e:422					ifdef UNIX then*/
L10: 

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_57user_library_42953);
        _23927 = _15file_exists(_57user_library_42953);
        if (_23927 == 0) {
            DeRef(_23927);
            _23927 = NOVALUE;
            goto L11; // [350] 358
        }
        else {
            if (!IS_ATOM_INT(_23927) && DBL_PTR(_23927)->dbl == 0.0){
                DeRef(_23927);
                _23927 = NOVALUE;
                goto L11; // [350] 358
            }
            DeRef(_23927);
            _23927 = NOVALUE;
        }
        DeRef(_23927);
        _23927 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LE; // [355] 365
L11: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45988 = _tk_45988 + 1;
        goto LD; // [360] 293
LE: 
        ;
    }
L3: 
    DeRef(_eudir_45976);
    _eudir_45976 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_57user_library_42953);
    _0 = _55adjust_for_build_file(_57user_library_42953);
    DeRefDS(_57user_library_42953);
    _57user_library_42953 = _0;

    /** buildsys.e:443		if TWINDOWS then*/
    if (_44TWINDOWS_20715 == 0)
    {
        goto L12; // [382] 437
    }
    else{
    }

    /** buildsys.e:444			if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:447				c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _23932);

    /** buildsys.e:450			if dll_option then*/
    if (_57dll_option_42941 == 0)
    {
        goto L13; // [413] 426
    }
    else{
    }

    /** buildsys.e:451				exe_ext = ".dll"*/
    RefDS(_23934);
    DeRefi(_exe_ext_45929);
    _exe_ext_45929 = _23934;
    goto L14; // [423] 478
L13: 

    /** buildsys.e:453				exe_ext = ".exe"*/
    RefDS(_23935);
    DeRefi(_exe_ext_45929);
    _exe_ext_45929 = _23935;
    goto L14; // [434] 478
L12: 

    /** buildsys.e:455		elsif TOSX then*/

    /** buildsys.e:460			if dll_option then*/
    if (_57dll_option_42941 == 0)
    {
        goto L15; // [466] 477
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23937);
    DeRefi(_exe_ext_45929);
    _exe_ext_45929 = _23937;
L15: 
L14: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_46034;
    _compile_dir_46034 = _57get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_46034);
    _23939 = _15file_exists(_compile_dir_46034);
    if (IS_ATOM_INT(_23939)) {
        if (_23939 != 0){
            DeRef(_23939);
            _23939 = NOVALUE;
            goto L16; // [489] 510
        }
    }
    else {
        if (DBL_PTR(_23939)->dbl != 0.0){
            DeRef(_23939);
            _23939 = NOVALUE;
            goto L16; // [489] 510
        }
    }
    DeRef(_23939);
    _23939 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23942 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23942;
    _23943 = MAKE_SEQ(_1);
    _23942 = NOVALUE;
    EPrintf(2, _23941, _23943);
    DeRefDS(_23943);
    _23943 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1);
L16: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_46045 = 32;

    /** buildsys.e:472		if TX86_64 then*/

    /** buildsys.e:476		switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45924, _55compiler_prefix_45758, _23946);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45926, _55compiler_prefix_45758, _23946);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23949);
        DeRefi(_obj_ext_45928);
        _obj_ext_45928 = _23949;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_22209);
        DeRefi(_m_flag_46055);
        _m_flag_46055 = _22209;

        /** buildsys.e:483				if not TARM then*/

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_46055);
        _m_flag_46055 = EPrintf(-9999999, _23951, _bits_46045);

        /** buildsys.e:488				if debug_option then*/
        if (_57debug_option_42951 == 0)
        {
            goto L17; // [589] 601
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _23953);
        goto L18; // [598] 608
L17: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _23955);
L18: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_57dll_option_42941 == 0) {
            goto L19; // [612] 632
        }
        _23958 = (_44TWINDOWS_20715 == 0);
        if (_23958 == 0)
        {
            DeRef(_23958);
            _23958 = NOVALUE;
            goto L19; // [622] 632
        }
        else{
            DeRef(_23958);
            _23958 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _23959);
L19: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23962 = _57get_eucompiledir();
        _23963 = _55adjust_for_build_file(_23962);
        _23962 = NOVALUE;
        RefDS(_m_flag_46055);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_46055;
        ((intptr_t *)_2)[2] = _23963;
        _23964 = MAKE_SEQ(_1);
        _23963 = NOVALUE;
        _23965 = EPrintf(-9999999, _23961, _23964);
        DeRefDS(_23964);
        _23964 = NOVALUE;
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _23965);
        DeRefDS(_23965);
        _23965 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (_44TWINDOWS_20715 == 0) {
            goto L1A; // [657] 674
        }
        goto L1A; // [664] 674

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _23968);
L1A: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_57user_library_42953);
        _23975 = _55adjust_for_command_line_passing(_57user_library_42953);
        RefDS(_m_flag_46055);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23975;
        ((intptr_t *)_2)[2] = _m_flag_46055;
        _23976 = MAKE_SEQ(_1);
        _23975 = NOVALUE;
        DeRefi(_l_flags_45927);
        _l_flags_45927 = EPrintf(-9999999, _23974, _23976);
        DeRefDS(_23976);
        _23976 = NOVALUE;

        /** buildsys.e:514				if dll_option then*/
        if (_57dll_option_42941 == 0)
        {
            goto L1B; // [716] 726
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _23978);
L1B: 

        /** buildsys.e:518				if TLINUX then*/

        /** buildsys.e:520				elsif TBSD then*/

        /** buildsys.e:522				elsif TOSX then*/

        /** buildsys.e:524				elsif TWINDOWS then*/
        if (_44TWINDOWS_20715 == 0)
        {
            goto L1C; // [778] 810
        }
        else{
        }

        /** buildsys.e:525					if mno_cygwin then*/

        /** buildsys.e:529					if not con_option then*/
        if (_57con_option_42943 != 0)
        goto L1D; // [799] 809

        /** buildsys.e:532						l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _23988);
L1D: 
L1C: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23991 = _15current_dir();
        _23992 = _55adjust_for_build_file(_23991);
        _23991 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23993;
            concat_list[1] = _23992;
            concat_list[2] = _23990;
            concat_list[3] = _55compiler_prefix_45758;
            Concat_N((object_ptr)&_rc_comp_45931, concat_list, 4);
        }
        DeRef(_23992);
        _23992 = NOVALUE;
        DeRefi(_m_flag_46055);
        _m_flag_46055 = NOVALUE;
        goto L1E; // [831] 1037

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45924, _55compiler_prefix_45758, _23995);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45926, _55compiler_prefix_45758, _23997);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23999);
        DeRefi(_obj_ext_45928);
        _obj_ext_45928 = _23999;

        /** buildsys.e:544				if debug_option then*/
        if (_57debug_option_42951 == 0)
        {
            goto L1F; // [864] 881
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_24000);
        DeRef(_c_flags_45925);
        _c_flags_45925 = _24000;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45930, _l_flags_begin_45930, _24001);
L1F: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42956;
        _24004 = MAKE_SEQ(_1);
        _24005 = EPrintf(-9999999, _24003, _24004);
        DeRefDS(_24004);
        _24004 = NOVALUE;
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _24005);
        DeRefDS(_24005);
        _24005 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _57total_stack_size_42956;
        _24008 = MAKE_SEQ(_1);
        _24009 = EPrintf(-9999999, _24007, _24008);
        DeRefDS(_24008);
        _24008 = NOVALUE;
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _24009);
        DeRefDS(_24009);
        _24009 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _24011);

        /** buildsys.e:553				if dll_option then*/
        if (_57dll_option_42941 == 0)
        {
            goto L20; // [923] 949
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_46034);
        _24014 = _55adjust_for_build_file(_compile_dir_46034);
        if (IS_SEQUENCE(_24013) && IS_ATOM(_24014)) {
            Ref(_24014);
            Append(&_24015, _24013, _24014);
        }
        else if (IS_ATOM(_24013) && IS_SEQUENCE(_24014)) {
        }
        else {
            Concat((object_ptr)&_24015, _24013, _24014);
        }
        DeRef(_24014);
        _24014 = NOVALUE;
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _24015);
        DeRefDS(_24015);
        _24015 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _24017);
        goto L21; // [946] 987
L20: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_46034);
        _24020 = _55adjust_for_build_file(_compile_dir_46034);
        if (IS_SEQUENCE(_24019) && IS_ATOM(_24020)) {
            Ref(_24020);
            Append(&_24021, _24019, _24020);
        }
        else if (IS_ATOM(_24019) && IS_SEQUENCE(_24020)) {
        }
        else {
            Concat((object_ptr)&_24021, _24019, _24020);
        }
        DeRef(_24020);
        _24020 = NOVALUE;
        Concat((object_ptr)&_c_flags_45925, _c_flags_45925, _24021);
        DeRefDS(_24021);
        _24021 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_57con_option_42943 == 0)
        {
            goto L22; // [967] 979
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45927, _24023, _l_flags_45927);
        goto L23; // [976] 986
L22: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45927, _24025, _l_flags_45927);
L23: 
L21: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57user_library_42953);
        ((intptr_t*)_2)[1] = _57user_library_42953;
        _24028 = MAKE_SEQ(_1);
        _24029 = EPrintf(-9999999, _24027, _24028);
        DeRefDS(_24028);
        _24028 = NOVALUE;
        Concat((object_ptr)&_l_flags_45927, _l_flags_45927, _24029);
        DeRefDS(_24029);
        _24029 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _24032 = _15current_dir();
        _24033 = _55adjust_for_build_file(_24032);
        _24032 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _24034;
            concat_list[1] = _24033;
            concat_list[2] = _24031;
            concat_list[3] = _55compiler_prefix_45758;
            Concat_N((object_ptr)&_rc_comp_45931, concat_list, 4);
        }
        DeRef(_24033);
        _24033 = NOVALUE;
        goto L1E; // [1021] 1037

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_22209);
        _49CompileErr(43, _22209, 0);
    ;}L1E: 

    /** buildsys.e:575		if length(cflags) then*/
    _24036 = 0;

    /** buildsys.e:580		if length(extra_cflags) then*/
    _24037 = 0;

    /** buildsys.e:584		if length(lflags) then*/
    _24040 = 0;

    /** buildsys.e:589		if length(extra_lflags) then*/
    _24041 = 0;

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45924);
    ((intptr_t*)_2)[1] = _c_exe_45924;
    RefDS(_c_flags_45925);
    ((intptr_t*)_2)[2] = _c_flags_45925;
    RefDS(_l_exe_45926);
    ((intptr_t*)_2)[3] = _l_exe_45926;
    RefDS(_l_flags_45927);
    ((intptr_t*)_2)[4] = _l_flags_45927;
    RefDS(_obj_ext_45928);
    ((intptr_t*)_2)[5] = _obj_ext_45928;
    RefDS(_exe_ext_45929);
    ((intptr_t*)_2)[6] = _exe_ext_45929;
    RefDS(_l_flags_begin_45930);
    ((intptr_t*)_2)[7] = _l_flags_begin_45930;
    RefDS(_rc_comp_45931);
    ((intptr_t*)_2)[8] = _rc_comp_45931;
    RefDS(_57user_library_42953);
    ((intptr_t*)_2)[9] = _57user_library_42953;
    _24044 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45924);
    DeRefDS(_c_flags_45925);
    DeRefDS(_l_exe_45926);
    DeRefDSi(_l_flags_45927);
    DeRefDSi(_obj_ext_45928);
    DeRefDSi(_exe_ext_45929);
    DeRefDSi(_l_flags_begin_45930);
    DeRefDS(_rc_comp_45931);
    DeRef(_l_names_45932);
    DeRefi(_l_ext_45933);
    DeRefi(_t_slash_45934);
    DeRef(_compile_dir_46034);
    DeRef(_23890);
    _23890 = NOVALUE;
    return _24044;
    ;
}


void _55ensure_exename(object _ext_46202)
{
    object _24051 = NOVALUE;
    object _24050 = NOVALUE;
    object _24049 = NOVALUE;
    object _24048 = NOVALUE;
    object _24046 = NOVALUE;
    object _24045 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24045 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24045)){
            _24046 = SEQ_PTR(_24045)->length;
    }
    else {
        _24046 = 1;
    }
    _24045 = NOVALUE;
    if (_24046 != 0)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _24048 = _15current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_46202;
        concat_list[1] = _57file0_44899;
        concat_list[2] = 92;
        concat_list[3] = _24048;
        Concat_N((object_ptr)&_24049, concat_list, 4);
    }
    DeRef(_24048);
    _24048 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _2 = (object)(((s1_ptr)_2)->base + 1);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24049;
    if( _1 != _24049 ){
        DeRef(_1);
    }
    _24049 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24050 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24050);
    _24051 = _55adjust_for_command_line_passing(_24050);
    _24050 = NOVALUE;
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _2 = (object)(((s1_ptr)_2)->base + 11);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24051;
    if( _1 != _24051 ){
        DeRef(_1);
    }
    _24051 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_46202);
    _24045 = NOVALUE;
    return;
    ;
}


void _55write_objlink_file()
{
    object _settings_46220 = NOVALUE;
    object _fh_46222 = NOVALUE;
    object _s_46270 = NOVALUE;
    object _24100 = NOVALUE;
    object _24098 = NOVALUE;
    object _24097 = NOVALUE;
    object _24096 = NOVALUE;
    object _24095 = NOVALUE;
    object _24094 = NOVALUE;
    object _24093 = NOVALUE;
    object _24092 = NOVALUE;
    object _24091 = NOVALUE;
    object _24090 = NOVALUE;
    object _24089 = NOVALUE;
    object _24088 = NOVALUE;
    object _24087 = NOVALUE;
    object _24085 = NOVALUE;
    object _24084 = NOVALUE;
    object _24083 = NOVALUE;
    object _24082 = NOVALUE;
    object _24080 = NOVALUE;
    object _24079 = NOVALUE;
    object _24078 = NOVALUE;
    object _24077 = NOVALUE;
    object _24076 = NOVALUE;
    object _24075 = NOVALUE;
    object _24069 = NOVALUE;
    object _24068 = NOVALUE;
    object _24065 = NOVALUE;
    object _24064 = NOVALUE;
    object _24063 = NOVALUE;
    object _24062 = NOVALUE;
    object _24061 = NOVALUE;
    object _24059 = NOVALUE;
    object _24058 = NOVALUE;
    object _24057 = NOVALUE;
    object _24054 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_46220;
    _settings_46220 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24053;
        concat_list[1] = _57file0_44899;
        concat_list[2] = _57output_dir_42955;
        Concat_N((object_ptr)&_24054, concat_list, 3);
    }
    _fh_46222 = EOpen(_24054, _24055, 0);
    DeRefDS(_24054);
    _24054 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46220);
    _24057 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24057);
    _55ensure_exename(_24057);
    _24057 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_46220);
    _24058 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_24058)){
            _24059 = SEQ_PTR(_24058)->length;
    }
    else {
        _24059 = 1;
    }
    _24058 = NOVALUE;
    if (_24059 <= 0)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_46220);
    _24061 = (object)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_24061) && IS_ATOM(_44HOSTNL_20738)) {
    }
    else if (IS_ATOM(_24061) && IS_SEQUENCE(_44HOSTNL_20738)) {
        Ref(_24061);
        Prepend(&_24062, _44HOSTNL_20738, _24061);
    }
    else {
        Concat((object_ptr)&_24062, _24061, _44HOSTNL_20738);
        _24061 = NOVALUE;
    }
    _24061 = NOVALUE;
    EPuts(_fh_46222, _24062); // DJP 
    DeRefDS(_24062);
    _24062 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42945)){
            _24063 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _24063 = 1;
    }
    {
        object _i_46238;
        _i_46238 = 1;
L2: 
        if (_i_46238 > _24063){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24064 = (object)*(((s1_ptr)_2)->base + _i_46238);
        _24065 = e_match_from(_23355, _24064, 1);
        _24064 = NOVALUE;
        if (_24065 == 0)
        {
            _24065 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _24065 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24068 = (object)*(((s1_ptr)_2)->base + _i_46238);
        Concat((object_ptr)&_24069, _24068, _44HOSTNL_20738);
        _24068 = NOVALUE;
        _24068 = NOVALUE;
        EPuts(_fh_46222, _24069); // DJP 
        DeRefDS(_24069);
        _24069 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_46238 = _i_46238 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_46220);
    _24075 = (object)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_24075) && IS_ATOM(_44HOSTNL_20738)) {
    }
    else if (IS_ATOM(_24075) && IS_SEQUENCE(_44HOSTNL_20738)) {
        Ref(_24075);
        Prepend(&_24076, _44HOSTNL_20738, _24075);
    }
    else {
        Concat((object_ptr)&_24076, _24075, _44HOSTNL_20738);
        _24075 = NOVALUE;
    }
    _24075 = NOVALUE;
    RefDS(_4905);
    _24077 = _12trim(_24076, _4905, 0);
    _24076 = NOVALUE;
    EPuts(_fh_46222, _24077); // DJP 
    DeRef(_24077);
    _24077 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _24078 = (0 == 2);
    if (_24078 == 0) {
        goto L5; // [194] 361
    }
    if (_57dll_option_42941 == 0)
    {
        goto L5; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_46222, _44HOSTNL_20738); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _24080 = (object)*(((s1_ptr)_2)->base + _27TopLevelSub_20578);
    DeRef(_s_46270);
    _2 = (object)SEQ_PTR(_24080);
    _s_46270 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_46270);
    _24080 = NOVALUE;

    /** buildsys.e:641			while s do*/
L6: 
    if (_s_46270 <= 0) {
        if (_s_46270 == 0) {
            goto L7; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_46270) && DBL_PTR(_s_46270)->dbl == 0.0){
                goto L7; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46270)){
        _24082 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46270)->dbl));
    }
    else{
        _24082 = (object)*(((s1_ptr)_2)->base + _s_46270);
    }
    _2 = (object)SEQ_PTR(_24082);
    if (!IS_ATOM_INT(_27S_TOKEN_20214)){
        _24083 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_TOKEN_20214)->dbl));
    }
    else{
        _24083 = (object)*(((s1_ptr)_2)->base + _27S_TOKEN_20214);
    }
    _24082 = NOVALUE;
    _24084 = find_from(_24083, _29RTN_TOKS_12277, 1);
    _24083 = NOVALUE;
    if (_24084 == 0)
    {
        _24084 = NOVALUE;
        goto L8; // [256] 341
    }
    else{
        _24084 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_46270);
    _24085 = _57is_exported(_s_46270);
    if (_24085 == 0) {
        DeRef(_24085);
        _24085 = NOVALUE;
        goto L9; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_24085) && DBL_PTR(_24085)->dbl == 0.0){
            DeRef(_24085);
            _24085 = NOVALUE;
            goto L9; // [265] 340
        }
        DeRef(_24085);
        _24085 = NOVALUE;
    }
    DeRef(_24085);
    _24085 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_24087, _24086, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46270)){
        _24088 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46270)->dbl));
    }
    else{
        _24088 = (object)*(((s1_ptr)_2)->base + _s_46270);
    }
    _2 = (object)SEQ_PTR(_24088);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24089 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24089 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24088 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46270)){
        _24090 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46270)->dbl));
    }
    else{
        _24090 = (object)*(((s1_ptr)_2)->base + _s_46270);
    }
    _2 = (object)SEQ_PTR(_24090);
    if (!IS_ATOM_INT(_27S_FILE_NO_20205)){
        _24091 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_FILE_NO_20205)->dbl));
    }
    else{
        _24091 = (object)*(((s1_ptr)_2)->base + _27S_FILE_NO_20205);
    }
    _24090 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46270)){
        _24092 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46270)->dbl));
    }
    else{
        _24092 = (object)*(((s1_ptr)_2)->base + _s_46270);
    }
    _2 = (object)SEQ_PTR(_24092);
    if (!IS_ATOM_INT(_27S_NAME_20209)){
        _24093 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NAME_20209)->dbl));
    }
    else{
        _24093 = (object)*(((s1_ptr)_2)->base + _27S_NAME_20209);
    }
    _24092 = NOVALUE;
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46270)){
        _24094 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46270)->dbl));
    }
    else{
        _24094 = (object)*(((s1_ptr)_2)->base + _s_46270);
    }
    _2 = (object)SEQ_PTR(_24094);
    if (!IS_ATOM_INT(_27S_NUM_ARGS_20260)){
        _24095 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27S_NUM_ARGS_20260)->dbl));
    }
    else{
        _24095 = (object)*(((s1_ptr)_2)->base + _27S_NUM_ARGS_20260);
    }
    _24094 = NOVALUE;
    if (IS_ATOM_INT(_24095)) {
        if (_24095 == (short)_24095){
            _24096 = _24095 * 4;
        }
        else{
            _24096 = NewDouble(_24095 * (eudouble)4);
        }
    }
    else {
        _24096 = binary_op(MULTIPLY, _24095, 4);
    }
    _24095 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24089);
    ((intptr_t*)_2)[1] = _24089;
    Ref(_24091);
    ((intptr_t*)_2)[2] = _24091;
    Ref(_24093);
    ((intptr_t*)_2)[3] = _24093;
    ((intptr_t*)_2)[4] = _24096;
    _24097 = MAKE_SEQ(_1);
    _24096 = NOVALUE;
    _24093 = NOVALUE;
    _24091 = NOVALUE;
    _24089 = NOVALUE;
    EPrintf(_fh_46222, _24087, _24097);
    DeRefDS(_24087);
    _24087 = NOVALUE;
    DeRefDS(_24097);
    _24097 = NOVALUE;
L9: 
L8: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    if (!IS_ATOM_INT(_s_46270)){
        _24098 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46270)->dbl));
    }
    else{
        _24098 = (object)*(((s1_ptr)_2)->base + _s_46270);
    }
    DeRef(_s_46270);
    _2 = (object)SEQ_PTR(_24098);
    _s_46270 = (object)*(((s1_ptr)_2)->base + 2);
    Ref(_s_46270);
    _24098 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L6; // [357] 232
L7: 
L5: 
    DeRef(_s_46270);
    _s_46270 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_46222);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_24100, _57file0_44899, _24053);
    RefDS(_24100);
    Append(&_57generated_files_42945, _57generated_files_42945, _24100);
    DeRefDS(_24100);
    _24100 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_46220);
    _24058 = NOVALUE;
    DeRef(_24078);
    _24078 = NOVALUE;
    return;
    ;
}


void _55write_makefile_srcobj_list(object _fh_46319)
{
    object _file_count_46349 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24130 = NOVALUE;
    object _24128 = NOVALUE;
    object _24127 = NOVALUE;
    object _24126 = NOVALUE;
    object _24124 = NOVALUE;
    object _24123 = NOVALUE;
    object _24121 = NOVALUE;
    object _24120 = NOVALUE;
    object _24119 = NOVALUE;
    object _24118 = NOVALUE;
    object _24117 = NOVALUE;
    object _24116 = NOVALUE;
    object _24114 = NOVALUE;
    object _24113 = NOVALUE;
    object _24112 = NOVALUE;
    object _24108 = NOVALUE;
    object _24107 = NOVALUE;
    object _24106 = NOVALUE;
    object _24105 = NOVALUE;
    object _24104 = NOVALUE;
    object _24103 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_57file0_44899);
    _24103 = _12upper(_57file0_44899);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24103;
    _24104 = MAKE_SEQ(_1);
    _24103 = NOVALUE;
    EPrintf(_fh_46319, _24102, _24104);
    DeRefDS(_24104);
    _24104 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42945)){
            _24105 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _24105 = 1;
    }
    {
        object _i_46326;
        _i_46326 = 1;
L1: 
        if (_i_46326 > _24105){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24106 = (object)*(((s1_ptr)_2)->base + _i_46326);
        if (IS_SEQUENCE(_24106)){
                _24107 = SEQ_PTR(_24106)->length;
        }
        else {
            _24107 = 1;
        }
        _2 = (object)SEQ_PTR(_24106);
        _24108 = (object)*(((s1_ptr)_2)->base + _24107);
        _24106 = NOVALUE;
        if (binary_op_a(NOTEQ, _24108, 99)){
            _24108 = NOVALUE;
            goto L3; // [48] 87
        }
        _24108 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_46326 <= 1)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20738);
        ((intptr_t*)_2)[1] = _44HOSTNL_20738;
        _24112 = MAKE_SEQ(_1);
        EPrintf(_fh_46319, _24111, _24112);
        DeRefDS(_24112);
        _24112 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24113 = (object)*(((s1_ptr)_2)->base + _i_46326);
        Concat((object_ptr)&_24114, _23595, _24113);
        _24113 = NOVALUE;
        EPuts(_fh_46319, _24114); // DJP 
        DeRefDS(_24114);
        _24114 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_46326 = _i_46326 + 1;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_46319, _44HOSTNL_20738); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_57file0_44899);
    _24116 = _12upper(_57file0_44899);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24116;
    _24117 = MAKE_SEQ(_1);
    _24116 = NOVALUE;
    EPrintf(_fh_46319, _24115, _24117);
    DeRefDS(_24117);
    _24117 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_46349 = 0;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42945)){
            _24118 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _24118 = 1;
    }
    {
        object _i_46351;
        _i_46351 = 1;
L5: 
        if (_i_46351 > _24118){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24119 = (object)*(((s1_ptr)_2)->base + _i_46351);
        _24120 = e_match_from(_23355, _24119, 1);
        _24119 = NOVALUE;
        if (_24120 == 0)
        {
            _24120 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _24120 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_46349 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20738);
        ((intptr_t*)_2)[1] = _44HOSTNL_20738;
        _24121 = MAKE_SEQ(_1);
        EPrintf(_fh_46319, _24111, _24121);
        DeRefDS(_24121);
        _24121 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_46349 = _file_count_46349 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24123 = (object)*(((s1_ptr)_2)->base + _i_46351);
        Concat((object_ptr)&_24124, _23595, _24123);
        _24123 = NOVALUE;
        EPuts(_fh_46319, _24124); // DJP 
        DeRefDS(_24124);
        _24124 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_46351 = _i_46351 + 1;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_46319, _44HOSTNL_20738); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_57file0_44899);
    _24126 = _12upper(_57file0_44899);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24126;
    _24127 = MAKE_SEQ(_1);
    _24126 = NOVALUE;
    EPrintf(_fh_46319, _24125, _24127);
    DeRefDS(_24127);
    _24127 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42945)){
            _24128 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _24128 = 1;
    }
    {
        object _i_46372;
        _i_46372 = 1;
L9: 
        if (_i_46372 > _24128){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_46372 <= 1)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_44HOSTNL_20738);
        ((intptr_t*)_2)[1] = _44HOSTNL_20738;
        _24130 = MAKE_SEQ(_1);
        EPrintf(_fh_46319, _24111, _24130);
        DeRefDS(_24130);
        _24130 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24131 = (object)*(((s1_ptr)_2)->base + _i_46372);
        Concat((object_ptr)&_24132, _23595, _24131);
        _24131 = NOVALUE;
        EPuts(_fh_46319, _24132); // DJP 
        DeRefDS(_24132);
        _24132 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_46372 = _i_46372 + 1;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_46319, _44HOSTNL_20738); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _55windows_to_mingw_path(object _s_46385)
{
    object _24134 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_46385);
    _24134 = _14find_replace(92, _s_46385, 47, 0);
    DeRefDS(_s_46385);
    return _24134;
    ;
}


void _55write_makefile_full()
{
    object _settings_46390 = NOVALUE;
    object _fh_46393 = NOVALUE;
    object _24261 = NOVALUE;
    object _24259 = NOVALUE;
    object _24257 = NOVALUE;
    object _24256 = NOVALUE;
    object _24255 = NOVALUE;
    object _24254 = NOVALUE;
    object _24253 = NOVALUE;
    object _24251 = NOVALUE;
    object _24250 = NOVALUE;
    object _24248 = NOVALUE;
    object _24247 = NOVALUE;
    object _24246 = NOVALUE;
    object _24245 = NOVALUE;
    object _24243 = NOVALUE;
    object _24242 = NOVALUE;
    object _24240 = NOVALUE;
    object _24239 = NOVALUE;
    object _24237 = NOVALUE;
    object _24236 = NOVALUE;
    object _24235 = NOVALUE;
    object _24234 = NOVALUE;
    object _24233 = NOVALUE;
    object _24232 = NOVALUE;
    object _24231 = NOVALUE;
    object _24230 = NOVALUE;
    object _24228 = NOVALUE;
    object _24227 = NOVALUE;
    object _24226 = NOVALUE;
    object _24225 = NOVALUE;
    object _24224 = NOVALUE;
    object _24223 = NOVALUE;
    object _24222 = NOVALUE;
    object _24221 = NOVALUE;
    object _24220 = NOVALUE;
    object _24219 = NOVALUE;
    object _24218 = NOVALUE;
    object _24217 = NOVALUE;
    object _24216 = NOVALUE;
    object _24214 = NOVALUE;
    object _24213 = NOVALUE;
    object _24151 = NOVALUE;
    object _24150 = NOVALUE;
    object _24149 = NOVALUE;
    object _24147 = NOVALUE;
    object _24146 = NOVALUE;
    object _24145 = NOVALUE;
    object _24143 = NOVALUE;
    object _24142 = NOVALUE;
    object _24141 = NOVALUE;
    object _24138 = NOVALUE;
    object _24136 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_46390;
    _settings_46390 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46390);
    _24136 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24136);
    _55ensure_exename(_24136);
    _24136 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24137;
        concat_list[1] = _57file0_44899;
        concat_list[2] = _57output_dir_42955;
        Concat_N((object_ptr)&_24138, concat_list, 3);
    }
    _fh_46393 = EOpen(_24138, _24055, 0);
    DeRefDS(_24138);
    _24138 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_24141, _24140, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_settings_46390);
    _24142 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24142);
    ((intptr_t*)_2)[1] = _24142;
    _24143 = MAKE_SEQ(_1);
    _24142 = NOVALUE;
    EPrintf(_fh_46393, _24141, _24143);
    DeRefDS(_24141);
    _24141 = NOVALUE;
    DeRefDS(_24143);
    _24143 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_24145, _24144, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_settings_46390);
    _24146 = (object)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24146);
    ((intptr_t*)_2)[1] = _24146;
    _24147 = MAKE_SEQ(_1);
    _24146 = NOVALUE;
    EPrintf(_fh_46393, _24145, _24147);
    DeRefDS(_24145);
    _24145 = NOVALUE;
    DeRefDS(_24147);
    _24147 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_24149, _24148, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_settings_46390);
    _24150 = (object)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24150);
    ((intptr_t*)_2)[1] = _24150;
    _24151 = MAKE_SEQ(_1);
    _24150 = NOVALUE;
    EPrintf(_fh_46393, _24149, _24151);
    DeRefDS(_24149);
    _24149 = NOVALUE;
    DeRefDS(_24151);
    _24151 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/

    /** buildsys.e:731			write_objlink_file()*/
    _55write_objlink_file();

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46393);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_46393, _44HOSTNL_20738); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_46390);
    _24213 = (object)*(((s1_ptr)_2)->base + 9);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24213);
    ((intptr_t*)_2)[1] = _24213;
    _24214 = MAKE_SEQ(_1);
    _24213 = NOVALUE;
    EPrintf(_fh_46393, _24212, _24214);
    DeRefDS(_24214);
    _24214 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24216, _24215, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24217 = (object)*(((s1_ptr)_2)->base + 11);
    Ref(_24217);
    _24218 = _55adjust_for_build_file(_24217);
    _24217 = NOVALUE;
    RefDS(_57file0_44899);
    _24219 = _12upper(_57file0_44899);
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24220 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24218;
    ((intptr_t*)_2)[2] = _24219;
    RefDS(_24220);
    ((intptr_t*)_2)[3] = _24220;
    _24221 = MAKE_SEQ(_1);
    _24220 = NOVALUE;
    _24219 = NOVALUE;
    _24218 = NOVALUE;
    EPrintf(_fh_46393, _24216, _24221);
    DeRefDS(_24216);
    _24216 = NOVALUE;
    DeRefDS(_24221);
    _24221 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24222 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24222)){
            _24223 = SEQ_PTR(_24222)->length;
    }
    else {
        _24223 = 1;
    }
    _24222 = NOVALUE;
    if (_24223 == 0)
    {
        _24223 = NOVALUE;
        goto L1; // [646] 690
    }
    else{
        _24223 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46390);
    _24224 = (object)*(((s1_ptr)_2)->base + 8);
    {
        object concat_list[3];

        concat_list[0] = _44HOSTNL_20738;
        concat_list[1] = _24224;
        concat_list[2] = _24171;
        Concat_N((object_ptr)&_24225, concat_list, 3);
    }
    _24224 = NOVALUE;
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24226 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24227 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24227);
    RefDS(_24226);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24226;
    ((intptr_t *)_2)[2] = _24227;
    _24228 = MAKE_SEQ(_1);
    _24227 = NOVALUE;
    _24226 = NOVALUE;
    _18writef(_fh_46393, _24225, _24228, 0);
    _24225 = NOVALUE;
    _24228 = NOVALUE;
L1: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24230, _24229, _44HOSTNL_20738);
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24231 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_57file0_44899);
    _24232 = _12upper(_57file0_44899);
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24233 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24233)){
            _24234 = SEQ_PTR(_24233)->length;
    }
    else {
        _24234 = 1;
    }
    _24233 = NOVALUE;
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24235 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24235);
    RefDS(_22209);
    _24236 = _56iif(_24234, _24235, _22209);
    _24234 = NOVALUE;
    _24235 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24231);
    ((intptr_t*)_2)[1] = _24231;
    ((intptr_t*)_2)[2] = _24232;
    ((intptr_t*)_2)[3] = _24236;
    _24237 = MAKE_SEQ(_1);
    _24236 = NOVALUE;
    _24232 = NOVALUE;
    _24231 = NOVALUE;
    EPrintf(_fh_46393, _24230, _24237);
    DeRefDS(_24230);
    _24230 = NOVALUE;
    DeRefDS(_24237);
    _24237 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_46393, _44HOSTNL_20738); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24239, _24238, _44HOSTNL_20738);
    RefDS(_57file0_44899);
    RefDS(_57file0_44899);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44899;
    ((intptr_t *)_2)[2] = _57file0_44899;
    _24240 = MAKE_SEQ(_1);
    EPrintf(_fh_46393, _24239, _24240);
    DeRefDS(_24239);
    _24239 = NOVALUE;
    DeRefDS(_24240);
    _24240 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_46393, _44HOSTNL_20738); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24242, _24241, _44HOSTNL_20738);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_57file0_44899);
    ((intptr_t*)_2)[1] = _57file0_44899;
    _24243 = MAKE_SEQ(_1);
    EPrintf(_fh_46393, _24242, _24243);
    DeRefDS(_24242);
    _24242 = NOVALUE;
    DeRefDS(_24243);
    _24243 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24245, _24244, _44HOSTNL_20738);
    RefDS(_57file0_44899);
    _24246 = _12upper(_57file0_44899);
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24247 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24247);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24246;
    ((intptr_t *)_2)[2] = _24247;
    _24248 = MAKE_SEQ(_1);
    _24247 = NOVALUE;
    _24246 = NOVALUE;
    EPrintf(_fh_46393, _24245, _24248);
    DeRefDS(_24245);
    _24245 = NOVALUE;
    DeRefDS(_24248);
    _24248 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_46393, _44HOSTNL_20738); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24250, _24249, _44HOSTNL_20738);
    RefDS(_57file0_44899);
    RefDS(_57file0_44899);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _57file0_44899;
    ((intptr_t *)_2)[2] = _57file0_44899;
    _24251 = MAKE_SEQ(_1);
    EPrintf(_fh_46393, _24250, _24251);
    DeRefDS(_24250);
    _24250 = NOVALUE;
    DeRefDS(_24251);
    _24251 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24253, _24252, _44HOSTNL_20738);
    RefDS(_57file0_44899);
    _24254 = _12upper(_57file0_44899);
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24255 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24256 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24254;
    RefDS(_24255);
    ((intptr_t*)_2)[2] = _24255;
    Ref(_24256);
    ((intptr_t*)_2)[3] = _24256;
    _24257 = MAKE_SEQ(_1);
    _24256 = NOVALUE;
    _24255 = NOVALUE;
    _24254 = NOVALUE;
    EPrintf(_fh_46393, _24253, _24257);
    DeRefDS(_24253);
    _24253 = NOVALUE;
    DeRefDS(_24257);
    _24257 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_46393, _44HOSTNL_20738); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24259, _24258, _44HOSTNL_20738);
    EPuts(_fh_46393, _24259); // DJP 
    DeRefDS(_24259);
    _24259 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24261, _24260, _44HOSTNL_20738);
    EPuts(_fh_46393, _24261); // DJP 
    DeRefDS(_24261);
    _24261 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_46393, _44HOSTNL_20738); // DJP 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_46393);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_46390);
    _24233 = NOVALUE;
    _24222 = NOVALUE;
    return;
    ;
}


void _55write_makefile_partial()
{
    object _settings_46619 = NOVALUE;
    object _fh_46621 = NOVALUE;
    object _24263 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46619;
    _settings_46619 = _55setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24137;
        concat_list[1] = _57file0_44899;
        concat_list[2] = _57output_dir_42955;
        Concat_N((object_ptr)&_24263, concat_list, 3);
    }
    _fh_46621 = EOpen(_24263, _24055, 0);
    DeRefDS(_24263);
    _24263 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_46621);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46621);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46619);
    return;
    ;
}


void _55build_direct(object _link_only_46628, object _the_file0_46629)
{
    object _cmd_46635 = NOVALUE;
    object _objs_46636 = NOVALUE;
    object _settings_46637 = NOVALUE;
    object _cwd_46639 = NOVALUE;
    object _status_46642 = NOVALUE;
    object _link_files_46673 = NOVALUE;
    object _pdone_46699 = NOVALUE;
    object _files_46750 = NOVALUE;
    object _32000 = NOVALUE;
    object _31999 = NOVALUE;
    object _31998 = NOVALUE;
    object _31997 = NOVALUE;
    object _31996 = NOVALUE;
    object _31994 = NOVALUE;
    object _24407 = NOVALUE;
    object _24406 = NOVALUE;
    object _24405 = NOVALUE;
    object _24404 = NOVALUE;
    object _24403 = NOVALUE;
    object _24402 = NOVALUE;
    object _24401 = NOVALUE;
    object _24399 = NOVALUE;
    object _24398 = NOVALUE;
    object _24397 = NOVALUE;
    object _24396 = NOVALUE;
    object _24392 = NOVALUE;
    object _24391 = NOVALUE;
    object _24390 = NOVALUE;
    object _24389 = NOVALUE;
    object _24388 = NOVALUE;
    object _24387 = NOVALUE;
    object _24386 = NOVALUE;
    object _24385 = NOVALUE;
    object _24384 = NOVALUE;
    object _24383 = NOVALUE;
    object _24382 = NOVALUE;
    object _24381 = NOVALUE;
    object _24380 = NOVALUE;
    object _24379 = NOVALUE;
    object _24378 = NOVALUE;
    object _24375 = NOVALUE;
    object _24374 = NOVALUE;
    object _24373 = NOVALUE;
    object _24372 = NOVALUE;
    object _24369 = NOVALUE;
    object _24367 = NOVALUE;
    object _24366 = NOVALUE;
    object _24365 = NOVALUE;
    object _24364 = NOVALUE;
    object _24363 = NOVALUE;
    object _24362 = NOVALUE;
    object _24359 = NOVALUE;
    object _24358 = NOVALUE;
    object _24354 = NOVALUE;
    object _24353 = NOVALUE;
    object _24352 = NOVALUE;
    object _24348 = NOVALUE;
    object _24347 = NOVALUE;
    object _24346 = NOVALUE;
    object _24345 = NOVALUE;
    object _24344 = NOVALUE;
    object _24343 = NOVALUE;
    object _24342 = NOVALUE;
    object _24341 = NOVALUE;
    object _24340 = NOVALUE;
    object _24339 = NOVALUE;
    object _24338 = NOVALUE;
    object _24337 = NOVALUE;
    object _24335 = NOVALUE;
    object _24334 = NOVALUE;
    object _24333 = NOVALUE;
    object _24332 = NOVALUE;
    object _24331 = NOVALUE;
    object _24329 = NOVALUE;
    object _24328 = NOVALUE;
    object _24327 = NOVALUE;
    object _24326 = NOVALUE;
    object _24325 = NOVALUE;
    object _24323 = NOVALUE;
    object _24321 = NOVALUE;
    object _24320 = NOVALUE;
    object _24319 = NOVALUE;
    object _24318 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _24314 = NOVALUE;
    object _24311 = NOVALUE;
    object _24310 = NOVALUE;
    object _24309 = NOVALUE;
    object _24308 = NOVALUE;
    object _24307 = NOVALUE;
    object _24306 = NOVALUE;
    object _24305 = NOVALUE;
    object _24304 = NOVALUE;
    object _24303 = NOVALUE;
    object _24302 = NOVALUE;
    object _24299 = NOVALUE;
    object _24298 = NOVALUE;
    object _24295 = NOVALUE;
    object _24293 = NOVALUE;
    object _24292 = NOVALUE;
    object _24291 = NOVALUE;
    object _24290 = NOVALUE;
    object _24287 = NOVALUE;
    object _24286 = NOVALUE;
    object _24285 = NOVALUE;
    object _24284 = NOVALUE;
    object _24282 = NOVALUE;
    object _24281 = NOVALUE;
    object _24280 = NOVALUE;
    object _24279 = NOVALUE;
    object _24278 = NOVALUE;
    object _24275 = NOVALUE;
    object _24269 = NOVALUE;
    object _24265 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    _24265 = 0;

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22209);
    DeRef(_objs_46636);
    _objs_46636 = _22209;
    _0 = _settings_46637;
    _settings_46637 = _55setup_build();
    DeRef(_0);
    _0 = _cwd_46639;
    _cwd_46639 = _15current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46637);
    _24269 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_24269);
    _55ensure_exename(_24269);
    _24269 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/

    /** buildsys.e:819			switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_27silent_20687 != 0)
        goto L1; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24274);
        ((intptr_t*)_2)[1] = _24274;
        _24275 = MAKE_SEQ(_1);
        _30ShowMsg(1, 176, _24275, 1);
        _24275 = NOVALUE;
        goto L1; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _55write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_27silent_20687 != 0)
        goto L2; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24277);
        ((intptr_t*)_2)[1] = _24277;
        _24278 = MAKE_SEQ(_1);
        _30ShowMsg(1, 176, _24278, 1);
        _24278 = NOVALUE;
L2: 
    ;}L1: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24279 = 1;
    if (_24279 == 0) {
        goto L3; // [131] 159
    }
    _24281 = 0;
    _24282 = (0 > 0);
    _24281 = NOVALUE;
    if (_24282 == 0)
    {
        DeRef(_24282);
        _24282 = NOVALUE;
        goto L3; // [145] 159
    }
    else{
        DeRef(_24282);
        _24282 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_57output_dir_42955);
    _32000 = _15chdir(_57output_dir_42955);
    DeRef(_32000);
    _32000 = NOVALUE;
L3: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_22209);
    DeRef(_link_files_46673);
    _link_files_46673 = _22209;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46628 != 0)
    goto L4; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42945)){
            _24284 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _24284 = 1;
    }
    {
        object _i_46677;
        _i_46677 = 1;
L5: 
        if (_i_46677 > _24284){
            goto L6; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24285 = (object)*(((s1_ptr)_2)->base + _i_46677);
        if (IS_SEQUENCE(_24285)){
                _24286 = SEQ_PTR(_24285)->length;
        }
        else {
            _24286 = 1;
        }
        _2 = (object)SEQ_PTR(_24285);
        _24287 = (object)*(((s1_ptr)_2)->base + _24286);
        _24285 = NOVALUE;
        if (binary_op_a(NOTEQ, _24287, 99)){
            _24287 = NOVALUE;
            goto L7; // [200] 438
        }
        _24287 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46637);
        _24290 = (object)*(((s1_ptr)_2)->base + 1);
        _2 = (object)SEQ_PTR(_settings_46637);
        _24291 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24292 = (object)*(((s1_ptr)_2)->base + _i_46677);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24290);
        ((intptr_t*)_2)[1] = _24290;
        Ref(_24291);
        ((intptr_t*)_2)[2] = _24291;
        RefDS(_24292);
        ((intptr_t*)_2)[3] = _24292;
        _24293 = MAKE_SEQ(_1);
        _24292 = NOVALUE;
        _24291 = NOVALUE;
        _24290 = NOVALUE;
        DeRef(_cmd_46635);
        _cmd_46635 = EPrintf(-9999999, _24289, _24293);
        DeRefDS(_24293);
        _24293 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24295 = (object)*(((s1_ptr)_2)->base + _i_46677);
        RefDS(_24295);
        Append(&_link_files_46673, _link_files_46673, _24295);
        _24295 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_27silent_20687 != 0)
        goto L8; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_57generated_files_42945)){
                _24298 = SEQ_PTR(_57generated_files_42945)->length;
        }
        else {
            _24298 = 1;
        }
        _24299 = (_i_46677 % _24298) ? NewDouble((eudouble)_i_46677 / _24298) : (_i_46677 / _24298);
        _24298 = NOVALUE;
        DeRef(_pdone_46699);
        if (IS_ATOM_INT(_24299)) {
            if (_24299 <= INT15 && _24299 >= -INT15){
                _pdone_46699 = 100 * _24299;
            }
            else{
                _pdone_46699 = NewDouble(100 * (eudouble)_24299);
            }
        }
        else {
            _pdone_46699 = NewDouble((eudouble)100 * DBL_PTR(_24299)->dbl);
        }
        DeRef(_24299);
        _24299 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_27verbose_20690 != 0)
        goto L9; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _24302 = 0;
            goto LA; // [273] 291
        }
        _2 = (object)SEQ_PTR(_57outdated_files_42946);
        _24303 = (object)*(((s1_ptr)_2)->base + _i_46677);
        if (IS_ATOM_INT(_24303)) {
            _24304 = (_24303 == 0);
        }
        else {
            _24304 = binary_op(EQUALS, _24303, 0);
        }
        _24303 = NOVALUE;
        if (IS_ATOM_INT(_24304))
        _24302 = (_24304 != 0);
        else
        _24302 = DBL_PTR(_24304)->dbl != 0.0;
LA: 
        if (_24302 == 0) {
            goto LB; // [291] 334
        }
        _24306 = (0 == 0);
        if (_24306 == 0)
        {
            DeRef(_24306);
            _24306 = NOVALUE;
            goto LB; // [302] 334
        }
        else{
            DeRef(_24306);
            _24306 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24307 = (object)*(((s1_ptr)_2)->base + _i_46677);
        RefDS(_24307);
        Ref(_pdone_46699);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46699;
        ((intptr_t *)_2)[2] = _24307;
        _24308 = MAKE_SEQ(_1);
        _24307 = NOVALUE;
        _30ShowMsg(1, 325, _24308, 1);
        _24308 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46699);
        _pdone_46699 = NOVALUE;
        goto LC; // [329] 474
        goto LD; // [331] 373
LB: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24309 = (object)*(((s1_ptr)_2)->base + _i_46677);
        RefDS(_24309);
        Ref(_pdone_46699);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46699;
        ((intptr_t *)_2)[2] = _24309;
        _24310 = MAKE_SEQ(_1);
        _24309 = NOVALUE;
        _30ShowMsg(1, 163, _24310, 1);
        _24310 = NOVALUE;
        goto LD; // [355] 373
L9: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46635);
        Ref(_pdone_46699);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46699;
        ((intptr_t *)_2)[2] = _cmd_46635;
        _24311 = MAKE_SEQ(_1);
        _30ShowMsg(1, 163, _24311, 1);
        _24311 = NOVALUE;
LD: 
L8: 
        DeRef(_pdone_46699);
        _pdone_46699 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46642 = system_exec_call(_cmd_46635, 0);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46642 == 0)
        goto LE; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24314 = (object)*(((s1_ptr)_2)->base + _i_46677);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24314);
        ((intptr_t*)_2)[1] = _24314;
        _24315 = MAKE_SEQ(_1);
        _24314 = NOVALUE;
        _30ShowMsg(2, 164, _24315, 1);
        _24315 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46635);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46642;
        ((intptr_t *)_2)[2] = _cmd_46635;
        _24316 = MAKE_SEQ(_1);
        _30ShowMsg(2, 165, _24316, 1);
        _24316 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto GF;
        goto LE; // [435] 472
L7: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24318 = (object)*(((s1_ptr)_2)->base + _i_46677);
        _24319 = e_match_from(_23355, _24318, 1);
        _24318 = NOVALUE;
        if (_24319 == 0)
        {
            _24319 = NOVALUE;
            goto L10; // [451] 471
        }
        else{
            _24319 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24320 = (object)*(((s1_ptr)_2)->base + _i_46677);
        Concat((object_ptr)&_24321, _23595, _24320);
        _24320 = NOVALUE;
        Concat((object_ptr)&_objs_46636, _objs_46636, _24321);
        DeRefDS(_24321);
        _24321 = NOVALUE;
L10: 
LE: 

        /** buildsys.e:874			end for*/
LC: 
        _i_46677 = _i_46677 + 1;
        goto L5; // [474] 185
L6: 
        ;
    }
    goto L11; // [479] 541
L4: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24323, _57file0_44899, _23805);
    _0 = _files_46750;
    _files_46750 = _18read_lines(_24323);
    DeRef(_0);
    _24323 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46750)){
            _24325 = SEQ_PTR(_files_46750)->length;
    }
    else {
        _24325 = 1;
    }
    {
        object _i_46756;
        _i_46756 = 1;
L12: 
        if (_i_46756 > _24325){
            goto L13; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46750);
        _24326 = (object)*(((s1_ptr)_2)->base + _i_46756);
        Ref(_24326);
        _24327 = _15filebase(_24326);
        _24326 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46637);
        _24328 = (object)*(((s1_ptr)_2)->base + 5);
        {
            object concat_list[4];

            concat_list[0] = _24328;
            concat_list[1] = _23394;
            concat_list[2] = _24327;
            concat_list[3] = _23595;
            Concat_N((object_ptr)&_24329, concat_list, 4);
        }
        _24328 = NOVALUE;
        DeRef(_24327);
        _24327 = NOVALUE;
        Concat((object_ptr)&_objs_46636, _objs_46636, _24329);
        DeRefDS(_24329);
        _24329 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46756 = _i_46756 + 1;
        goto L12; // [533] 506
L13: 
        ;
    }
    DeRef(_files_46750);
    _files_46750 = NOVALUE;
L11: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_57keep_42948 == 0) {
        _24331 = 0;
        goto L14; // [545] 556
    }
    _24332 = (_link_only_46628 == 0);
    _24331 = (_24332 != 0);
L14: 
    if (_24331 == 0) {
        goto L15; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46673)){
            _24334 = SEQ_PTR(_link_files_46673)->length;
    }
    else {
        _24334 = 1;
    }
    if (_24334 == 0)
    {
        _24334 = NOVALUE;
        goto L15; // [564] 585
    }
    else{
        _24334 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24335, _57file0_44899, _23805);
    RefDS(_link_files_46673);
    _31999 = _18write_lines(_24335, _link_files_46673);
    _24335 = NOVALUE;
    DeRef(_31999);
    _31999 = NOVALUE;
    goto L16; // [582] 609
L15: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_57keep_42948 != 0)
    goto L17; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24337, _57file0_44899, _23805);
    _31998 = _15delete_file(_24337);
    _24337 = NOVALUE;
    DeRef(_31998);
    _31998 = NOVALUE;
L17: 
L16: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24338 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24338)){
            _24339 = SEQ_PTR(_24338)->length;
    }
    else {
        _24339 = 1;
    }
    _24338 = NOVALUE;
    if (_24339 == 0) {
        _24340 = 0;
        goto L18; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46637);
    _24341 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24341)){
            _24342 = SEQ_PTR(_24341)->length;
    }
    else {
        _24342 = 1;
    }
    _24341 = NOVALUE;
    _24340 = (_24342 != 0);
L18: 
    if (_24340 == 0) {
        goto L19; // [637] 742
    }
    _24344 = (0 == 1);
    if (_24344 == 0)
    {
        DeRef(_24344);
        _24344 = NOVALUE;
        goto L19; // [648] 742
    }
    else{
        DeRef(_24344);
        _24344 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46637);
    _24345 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24346 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24347 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24347);
    RefDS(_24346);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24346;
    ((intptr_t *)_2)[2] = _24347;
    _24348 = MAKE_SEQ(_1);
    _24347 = NOVALUE;
    _24346 = NOVALUE;
    Ref(_24345);
    _0 = _cmd_46635;
    _cmd_46635 = _12format(_24345, _24348);
    DeRef(_0);
    _24345 = NOVALUE;
    _24348 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46642 = system_exec_call(_cmd_46635, 0);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46642 == 0)
    goto L1A; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24352 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24352);
    ((intptr_t*)_2)[1] = _24352;
    _24353 = MAKE_SEQ(_1);
    _24352 = NOVALUE;
    _30ShowMsg(2, 350, _24353, 1);
    _24353 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46635);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46642;
    ((intptr_t *)_2)[2] = _cmd_46635;
    _24354 = MAKE_SEQ(_1);
    _30ShowMsg(2, 169, _24354, 1);
    _24354 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto GF;
L1A: 
L19: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = 0;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46637);
        _24358 = (object)*(((s1_ptr)_2)->base + 3);
        RefDS(_57file0_44899);
        Ref(_24358);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24358;
        ((intptr_t *)_2)[2] = _57file0_44899;
        _24359 = MAKE_SEQ(_1);
        _24358 = NOVALUE;
        DeRef(_cmd_46635);
        _cmd_46635 = EPrintf(-9999999, _24357, _24359);
        DeRefDS(_24359);
        _24359 = NOVALUE;
        goto L1B; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46637);
        _24362 = (object)*(((s1_ptr)_2)->base + 3);
        _2 = (object)SEQ_PTR(_55exe_name_45760);
        _24363 = (object)*(((s1_ptr)_2)->base + 11);
        Ref(_24363);
        _24364 = _55adjust_for_build_file(_24363);
        _24363 = NOVALUE;
        _2 = (object)SEQ_PTR(_55res_file_45772);
        _24365 = (object)*(((s1_ptr)_2)->base + 11);
        _2 = (object)SEQ_PTR(_settings_46637);
        _24366 = (object)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24362);
        ((intptr_t*)_2)[1] = _24362;
        ((intptr_t*)_2)[2] = _24364;
        RefDS(_objs_46636);
        ((intptr_t*)_2)[3] = _objs_46636;
        RefDS(_24365);
        ((intptr_t*)_2)[4] = _24365;
        Ref(_24366);
        ((intptr_t*)_2)[5] = _24366;
        _24367 = MAKE_SEQ(_1);
        _24366 = NOVALUE;
        _24365 = NOVALUE;
        _24364 = NOVALUE;
        _24362 = NOVALUE;
        DeRef(_cmd_46635);
        _cmd_46635 = EPrintf(-9999999, _24361, _24367);
        DeRefDS(_24367);
        _24367 = NOVALUE;
        goto L1B; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0;
        _24369 = MAKE_SEQ(_1);
        _30ShowMsg(2, 167, _24369, 1);
        _24369 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto GF;
    ;}L1B: 

    /** buildsys.e:921		if not silent then*/
    if (_27silent_20687 != 0)
    goto L1C; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_27verbose_20690 != 0)
    goto L1D; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24372 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24372);
    RefDS(_22209);
    _24373 = _15abbreviate_path(_24372, _22209);
    _24372 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24373;
    _24374 = MAKE_SEQ(_1);
    _24373 = NOVALUE;
    _30ShowMsg(1, 166, _24374, 1);
    _24374 = NOVALUE;
    goto L1E; // [889] 909
L1D: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46635);
    ((intptr_t*)_2)[1] = _cmd_46635;
    _24375 = MAKE_SEQ(_1);
    _30ShowMsg(1, 166, _24375, 1);
    _24375 = NOVALUE;
L1E: 
L1C: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46642 = system_exec_call(_cmd_46635, 0);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46642 == 0)
    goto L1F; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24378 = (object)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24378);
    ((intptr_t*)_2)[1] = _24378;
    _24379 = MAKE_SEQ(_1);
    _24378 = NOVALUE;
    _30ShowMsg(2, 168, _24379, 1);
    _24379 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46635);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46642;
    ((intptr_t *)_2)[2] = _cmd_46635;
    _24380 = MAKE_SEQ(_1);
    _30ShowMsg(2, 169, _24380, 1);
    _24380 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto GF;
L1F: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24381 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24381)){
            _24382 = SEQ_PTR(_24381)->length;
    }
    else {
        _24382 = 1;
    }
    _24381 = NOVALUE;
    if (_24382 == 0) {
        _24383 = 0;
        goto L20; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46637);
    _24384 = (object)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_24384)){
            _24385 = SEQ_PTR(_24384)->length;
    }
    else {
        _24385 = 1;
    }
    _24384 = NOVALUE;
    _24383 = (_24385 != 0);
L20: 
    if (_24383 == 0) {
        goto L21; // [995] 1118
    }
    _24387 = (0 == 2);
    if (_24387 == 0)
    {
        DeRef(_24387);
        _24387 = NOVALUE;
        goto L21; // [1006] 1118
    }
    else{
        DeRef(_24387);
        _24387 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46637);
    _24388 = (object)*(((s1_ptr)_2)->base + 8);
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24389 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24390 = (object)*(((s1_ptr)_2)->base + 11);
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24391 = (object)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24389);
    ((intptr_t*)_2)[1] = _24389;
    RefDS(_24390);
    ((intptr_t*)_2)[2] = _24390;
    Ref(_24391);
    ((intptr_t*)_2)[3] = _24391;
    _24392 = MAKE_SEQ(_1);
    _24391 = NOVALUE;
    _24390 = NOVALUE;
    _24389 = NOVALUE;
    Ref(_24388);
    _0 = _cmd_46635;
    _cmd_46635 = _12format(_24388, _24392);
    DeRef(_0);
    _24388 = NOVALUE;
    _24392 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46642 = system_exec_call(_cmd_46635, 0);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46642 == 0)
    goto L22; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_55rc_file_45766);
    _24396 = (object)*(((s1_ptr)_2)->base + 1);
    _2 = (object)SEQ_PTR(_55exe_name_45760);
    _24397 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_24397);
    RefDS(_24396);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24396;
    ((intptr_t *)_2)[2] = _24397;
    _24398 = MAKE_SEQ(_1);
    _24397 = NOVALUE;
    _24396 = NOVALUE;
    _30ShowMsg(2, 187, _24398, 1);
    _24398 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46635);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46642;
    ((intptr_t *)_2)[2] = _cmd_46635;
    _24399 = MAKE_SEQ(_1);
    _30ShowMsg(2, 169, _24399, 1);
    _24399 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto GF;
L22: 
L21: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
GF:

    /** buildsys.e:950		if keep = 0 then*/
    if (_57keep_42948 != 0)
    goto L23; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_42945)){
            _24401 = SEQ_PTR(_57generated_files_42945)->length;
    }
    else {
        _24401 = 1;
    }
    {
        object _i_46892;
        _i_46892 = 1;
L24: 
        if (_i_46892 > _24401){
            goto L25; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_27verbose_20690 == 0)
        {
            goto L26; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24402 = (object)*(((s1_ptr)_2)->base + _i_46892);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24402);
        ((intptr_t*)_2)[1] = _24402;
        _24403 = MAKE_SEQ(_1);
        _24402 = NOVALUE;
        _30ShowMsg(1, 347, _24403, 1);
        _24403 = NOVALUE;
L26: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_57generated_files_42945);
        _24404 = (object)*(((s1_ptr)_2)->base + _i_46892);
        RefDS(_24404);
        _31997 = _15delete_file(_24404);
        _24404 = NOVALUE;
        DeRef(_31997);
        _31997 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46892 = _i_46892 + 1;
        goto L24; // [1188] 1144
L25: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24405 = (object)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_24405)){
            _24406 = SEQ_PTR(_24405)->length;
    }
    else {
        _24406 = 1;
    }
    _24405 = NOVALUE;
    if (_24406 == 0)
    {
        _24406 = NOVALUE;
        goto L27; // [1206] 1226
    }
    else{
        _24406 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_55res_file_45772);
    _24407 = (object)*(((s1_ptr)_2)->base + 11);
    RefDS(_24407);
    _31996 = _15delete_file(_24407);
    _24407 = NOVALUE;
    DeRef(_31996);
    _31996 = NOVALUE;
L27: 

    /** buildsys.e:962			if remove_output_dir then*/
L23: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46639);
    _31994 = _15chdir(_cwd_46639);
    DeRef(_31994);
    _31994 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46629);
    DeRef(_cmd_46635);
    DeRef(_objs_46636);
    DeRef(_settings_46637);
    DeRefDS(_cwd_46639);
    DeRef(_link_files_46673);
    _24384 = NOVALUE;
    _24381 = NOVALUE;
    _24338 = NOVALUE;
    _24405 = NOVALUE;
    DeRef(_24304);
    _24304 = NOVALUE;
    _24341 = NOVALUE;
    DeRef(_24332);
    _24332 = NOVALUE;
    return;
    ;
}


void _55write_buildfile()
{
    object _make_command_46934 = NOVALUE;
    object _settings_46979 = NOVALUE;
    object _24434 = NOVALUE;
    object _24433 = NOVALUE;
    object _24429 = NOVALUE;
    object _24428 = NOVALUE;
    object _24427 = NOVALUE;
    object _24425 = NOVALUE;
    object _24424 = NOVALUE;
    object _24423 = NOVALUE;
    object _24422 = NOVALUE;
    object _24421 = NOVALUE;
    object _24420 = NOVALUE;
    object _24419 = NOVALUE;
    object _24418 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = 3;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _55write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_27silent_20687 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24417);
        DeRefi(_make_command_46934);
        _make_command_46934 = _24417;

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24418 = _27cfile_count_20650 + 2;
        if ((object)((uintptr_t)_24418 + (uintptr_t)HIGH_BITS) >= 0){
            _24418 = NewDouble((eudouble)_24418);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24418;
        _24419 = MAKE_SEQ(_1);
        _24418 = NOVALUE;
        _30ShowMsg(1, 170, _24419, 1);
        _24419 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24420 = 1;
        if (_24420 == 0) {
            goto L2; // [80] 122
        }
        _24422 = 0;
        _24423 = (0 > 0);
        _24422 = NOVALUE;
        if (_24423 == 0)
        {
            DeRef(_24423);
            _24423 = NOVALUE;
            goto L2; // [94] 122
        }
        else{
            DeRef(_24423);
            _24423 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57output_dir_42955);
        ((intptr_t*)_2)[1] = _57output_dir_42955;
        RefDS(_make_command_46934);
        ((intptr_t*)_2)[2] = _make_command_46934;
        RefDS(_57file0_44899);
        ((intptr_t*)_2)[3] = _57file0_44899;
        _24424 = MAKE_SEQ(_1);
        _30ShowMsg(1, 174, _24424, 1);
        _24424 = NOVALUE;
        goto L3; // [119] 141
L2: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_57file0_44899);
        RefDS(_make_command_46934);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46934;
        ((intptr_t *)_2)[2] = _57file0_44899;
        _24425 = MAKE_SEQ(_1);
        _30ShowMsg(1, 172, _24425, 1);
        _24425 = NOVALUE;
L3: 
L1: 
        DeRefi(_make_command_46934);
        _make_command_46934 = NOVALUE;
        goto L4; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _55write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_27silent_20687 != 0)
        goto L4; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24427 = _27cfile_count_20650 + 2;
        if ((object)((uintptr_t)_24427 + (uintptr_t)HIGH_BITS) >= 0){
            _24427 = NewDouble((eudouble)_24427);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24427;
        _24428 = MAKE_SEQ(_1);
        _24427 = NOVALUE;
        _30ShowMsg(1, 170, _24428, 1);
        _24428 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_57file0_44899);
        ((intptr_t*)_2)[1] = _57file0_44899;
        _24429 = MAKE_SEQ(_1);
        _30ShowMsg(1, 173, _24429, 1);
        _24429 = NOVALUE;
        goto L4; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_22209);
        _55build_direct(0, _22209);

        /** buildsys.e:1014				if not silent then*/
        if (_27silent_20687 != 0)
        goto L5; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46979;
        _settings_46979 = _55setup_build();
        DeRef(_0);
L5: 
        DeRef(_settings_46979);
        _settings_46979 = NOVALUE;
        goto L4; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_27silent_20687 != 0)
        goto L4; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24433 = _27cfile_count_20650 + 2;
        if ((object)((uintptr_t)_24433 + (uintptr_t)HIGH_BITS) >= 0){
            _24433 = NewDouble((eudouble)_24433);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24433;
        _24434 = MAKE_SEQ(_1);
        _24433 = NOVALUE;
        _30ShowMsg(1, 170, _24434, 1);
        _24434 = NOVALUE;
        goto L4; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_22209);
        _49CompileErr(151, _22209, 0);
    ;}L4: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x52153266
