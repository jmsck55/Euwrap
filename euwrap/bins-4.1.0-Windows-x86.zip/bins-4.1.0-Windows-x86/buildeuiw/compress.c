// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _59compress(object _x_22935)
{
    object _x4_22936 = NOVALUE;
    object _s_22937 = NOVALUE;
    object _12967 = NOVALUE;
    object _12966 = NOVALUE;
    object _12965 = NOVALUE;
    object _12963 = NOVALUE;
    object _12962 = NOVALUE;
    object _12960 = NOVALUE;
    object _12958 = NOVALUE;
    object _12957 = NOVALUE;
    object _12956 = NOVALUE;
    object _12955 = NOVALUE;
    object _12953 = NOVALUE;
    object _12951 = NOVALUE;
    object _12949 = NOVALUE;
    object _12947 = NOVALUE;
    object _12946 = NOVALUE;
    object _12945 = NOVALUE;
    object _12943 = NOVALUE;
    object _12942 = NOVALUE;
    object _12941 = NOVALUE;
    object _12940 = NOVALUE;
    object _12939 = NOVALUE;
    object _12938 = NOVALUE;
    object _12937 = NOVALUE;
    object _12936 = NOVALUE;
    object _12935 = NOVALUE;
    object _12934 = NOVALUE;
    object _12932 = NOVALUE;
    object _12931 = NOVALUE;
    object _12930 = NOVALUE;
    object _12929 = NOVALUE;
    object _12928 = NOVALUE;
    object _12927 = NOVALUE;
    object _12925 = NOVALUE;
    object _12924 = NOVALUE;
    object _12923 = NOVALUE;
    object _12922 = NOVALUE;
    object _12921 = NOVALUE;
    object _12920 = NOVALUE;
    object _12919 = NOVALUE;
    object _12918 = NOVALUE;
    object _12917 = NOVALUE;
    object _0, _1, _2;
    

    /** compress.e:59		if integer(x) then*/
    if (IS_ATOM_INT(_x_22935))
    _12917 = 1;
    else if (IS_ATOM_DBL(_x_22935))
    _12917 = IS_ATOM_INT(DoubleToInt(_x_22935));
    else
    _12917 = 0;
    if (_12917 == 0)
    {
        _12917 = NOVALUE;
        goto L1; // [6] 220
    }
    else{
        _12917 = NOVALUE;
    }

    /** compress.e:60			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_22935)) {
        _12918 = (_x_22935 >= -2);
    }
    else {
        _12918 = binary_op(GREATEREQ, _x_22935, -2);
    }
    if (IS_ATOM_INT(_12918)) {
        if (_12918 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12918)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_22935)) {
        _12920 = (_x_22935 <= 244);
    }
    else {
        _12920 = binary_op(LESSEQ, _x_22935, 244);
    }
    if (_12920 == 0) {
        DeRef(_12920);
        _12920 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12920) && DBL_PTR(_12920)->dbl == 0.0){
            DeRef(_12920);
            _12920 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12920);
        _12920 = NOVALUE;
    }
    DeRef(_12920);
    _12920 = NOVALUE;

    /** compress.e:61				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_22935)) {
        _12921 = _x_22935 - -2;
        if ((object)((uintptr_t)_12921 +(uintptr_t) HIGH_BITS) >= 0){
            _12921 = NewDouble((eudouble)_12921);
        }
    }
    else {
        _12921 = binary_op(MINUS, _x_22935, -2);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12921;
    _12922 = MAKE_SEQ(_1);
    _12921 = NOVALUE;
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12918);
    _12918 = NOVALUE;
    return _12922;
    goto L3; // [41] 389
L2: 

    /** compress.e:63			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22935)) {
        _12923 = (_x_22935 >= _59MIN2B_22909);
    }
    else {
        _12923 = binary_op(GREATEREQ, _x_22935, _59MIN2B_22909);
    }
    if (IS_ATOM_INT(_12923)) {
        if (_12923 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12923)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_22935)) {
        _12925 = (_x_22935 <= 32767);
    }
    else {
        _12925 = binary_op(LESSEQ, _x_22935, 32767);
    }
    if (_12925 == 0) {
        DeRef(_12925);
        _12925 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12925) && DBL_PTR(_12925)->dbl == 0.0){
            DeRef(_12925);
            _12925 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12925);
        _12925 = NOVALUE;
    }
    DeRef(_12925);
    _12925 = NOVALUE;

    /** compress.e:64				x -= MIN2B*/
    _0 = _x_22935;
    if (IS_ATOM_INT(_x_22935)) {
        _x_22935 = _x_22935 - _59MIN2B_22909;
        if ((object)((uintptr_t)_x_22935 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22935 = NewDouble((eudouble)_x_22935);
        }
    }
    else {
        _x_22935 = binary_op(MINUS, _x_22935, _59MIN2B_22909);
    }
    DeRef(_0);

    /** compress.e:65				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_22935)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22935 & (uintptr_t)255;
             _12927 = MAKE_UINT(tu);
        }
    }
    else {
        _12927 = binary_op(AND_BITS, _x_22935, 255);
    }
    if (IS_ATOM_INT(_x_22935)) {
        if (256 > 0 && _x_22935 >= 0) {
            _12928 = _x_22935 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22935 / (eudouble)256);
            if (_x_22935 != MININT)
            _12928 = (object)temp_dbl;
            else
            _12928 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22935, 256);
        _12928 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 247;
    ((intptr_t*)_2)[2] = _12927;
    ((intptr_t*)_2)[3] = _12928;
    _12929 = MAKE_SEQ(_1);
    _12928 = NOVALUE;
    _12927 = NOVALUE;
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    return _12929;
    goto L3; // [94] 389
L4: 

    /** compress.e:67			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22935)) {
        _12930 = (_x_22935 >= _59MIN3B_22915);
    }
    else {
        _12930 = binary_op(GREATEREQ, _x_22935, _59MIN3B_22915);
    }
    if (IS_ATOM_INT(_12930)) {
        if (_12930 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12930)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_22935)) {
        _12932 = (_x_22935 <= 8388607);
    }
    else {
        _12932 = binary_op(LESSEQ, _x_22935, 8388607);
    }
    if (_12932 == 0) {
        DeRef(_12932);
        _12932 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12932) && DBL_PTR(_12932)->dbl == 0.0){
            DeRef(_12932);
            _12932 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12932);
        _12932 = NOVALUE;
    }
    DeRef(_12932);
    _12932 = NOVALUE;

    /** compress.e:68				x -= MIN3B*/
    _0 = _x_22935;
    if (IS_ATOM_INT(_x_22935)) {
        _x_22935 = _x_22935 - _59MIN3B_22915;
        if ((object)((uintptr_t)_x_22935 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22935 = NewDouble((eudouble)_x_22935);
        }
    }
    else {
        _x_22935 = binary_op(MINUS, _x_22935, _59MIN3B_22915);
    }
    DeRef(_0);

    /** compress.e:69				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_22935)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22935 & (uintptr_t)255;
             _12934 = MAKE_UINT(tu);
        }
    }
    else {
        _12934 = binary_op(AND_BITS, _x_22935, 255);
    }
    if (IS_ATOM_INT(_x_22935)) {
        if (256 > 0 && _x_22935 >= 0) {
            _12935 = _x_22935 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22935 / (eudouble)256);
            if (_x_22935 != MININT)
            _12935 = (object)temp_dbl;
            else
            _12935 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22935, 256);
        _12935 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12935)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12935 & (uintptr_t)255;
             _12936 = MAKE_UINT(tu);
        }
    }
    else {
        _12936 = binary_op(AND_BITS, _12935, 255);
    }
    DeRef(_12935);
    _12935 = NOVALUE;
    if (IS_ATOM_INT(_x_22935)) {
        if (65536 > 0 && _x_22935 >= 0) {
            _12937 = _x_22935 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22935 / (eudouble)65536);
            if (_x_22935 != MININT)
            _12937 = (object)temp_dbl;
            else
            _12937 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22935, 65536);
        _12937 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 248;
    ((intptr_t*)_2)[2] = _12934;
    ((intptr_t*)_2)[3] = _12936;
    ((intptr_t*)_2)[4] = _12937;
    _12938 = MAKE_SEQ(_1);
    _12937 = NOVALUE;
    _12936 = NOVALUE;
    _12934 = NOVALUE;
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    return _12938;
    goto L3; // [156] 389
L5: 

    /** compress.e:71			elsif x >= MIN4B and x <= MAX4B then*/
    if (IS_ATOM_INT(_x_22935) && IS_ATOM_INT(_59MIN4B_22921)) {
        _12939 = (_x_22935 >= _59MIN4B_22921);
    }
    else {
        _12939 = binary_op(GREATEREQ, _x_22935, _59MIN4B_22921);
    }
    if (IS_ATOM_INT(_12939)) {
        if (_12939 == 0) {
            goto L6; // [167] 199
        }
    }
    else {
        if (DBL_PTR(_12939)->dbl == 0.0) {
            goto L6; // [167] 199
        }
    }
    if (IS_ATOM_INT(_x_22935) && IS_ATOM_INT(_59MAX4B_22924)) {
        _12941 = (_x_22935 <= _59MAX4B_22924);
    }
    else {
        _12941 = binary_op(LESSEQ, _x_22935, _59MAX4B_22924);
    }
    if (_12941 == 0) {
        DeRef(_12941);
        _12941 = NOVALUE;
        goto L6; // [178] 199
    }
    else {
        if (!IS_ATOM_INT(_12941) && DBL_PTR(_12941)->dbl == 0.0){
            DeRef(_12941);
            _12941 = NOVALUE;
            goto L6; // [178] 199
        }
        DeRef(_12941);
        _12941 = NOVALUE;
    }
    DeRef(_12941);
    _12941 = NOVALUE;

    /** compress.e:72				return I4B & int_to_bytes(x)*/
    Ref(_x_22935);
    _12942 = _13int_to_bytes(_x_22935, 4);
    if (IS_SEQUENCE(249) && IS_ATOM(_12942)) {
    }
    else if (IS_ATOM(249) && IS_SEQUENCE(_12942)) {
        Prepend(&_12943, _12942, 249);
    }
    else {
        Concat((object_ptr)&_12943, 249, _12942);
    }
    DeRef(_12942);
    _12942 = NOVALUE;
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12938);
    _12938 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    DeRef(_12939);
    _12939 = NOVALUE;
    return _12943;
    goto L3; // [196] 389
L6: 

    /** compress.e:75				ifdef EU4_0 then*/

    /** compress.e:79					return I8B & int_to_bytes(x, 8)*/
    Ref(_x_22935);
    _12945 = _13int_to_bytes(_x_22935, 8);
    if (IS_SEQUENCE(250) && IS_ATOM(_12945)) {
    }
    else if (IS_ATOM(250) && IS_SEQUENCE(_12945)) {
        Prepend(&_12946, _12945, 250);
    }
    else {
        Concat((object_ptr)&_12946, 250, _12945);
    }
    DeRef(_12945);
    _12945 = NOVALUE;
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12943);
    _12943 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12938);
    _12938 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    DeRef(_12939);
    _12939 = NOVALUE;
    return _12946;
    goto L3; // [217] 389
L1: 

    /** compress.e:83		elsif atom(x) then*/
    _12947 = IS_ATOM(_x_22935);
    if (_12947 == 0)
    {
        _12947 = NOVALUE;
        goto L7; // [225] 309
    }
    else{
        _12947 = NOVALUE;
    }

    /** compress.e:85			x4 = atom_to_float32(x)*/
    Ref(_x_22935);
    _0 = _x4_22936;
    _x4_22936 = _13atom_to_float32(_x_22935);
    DeRef(_0);

    /** compress.e:86			if x = float32_to_atom(x4) then*/
    RefDS(_x4_22936);
    _12949 = _13float32_to_atom(_x4_22936);
    if (binary_op_a(NOTEQ, _x_22935, _12949)){
        DeRef(_12949);
        _12949 = NOVALUE;
        goto L8; // [242] 259
    }
    DeRef(_12949);
    _12949 = NOVALUE;

    /** compress.e:88				return F4B & x4*/
    Prepend(&_12951, _x4_22936, 251);
    DeRef(_x_22935);
    DeRefDS(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12943);
    _12943 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12938);
    _12938 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12946);
    _12946 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    DeRef(_12939);
    _12939 = NOVALUE;
    return _12951;
    goto L3; // [256] 389
L8: 

    /** compress.e:90				x4 = atom_to_float64( x )*/
    Ref(_x_22935);
    _0 = _x4_22936;
    _x4_22936 = _13atom_to_float64(_x_22935);
    DeRef(_0);

    /** compress.e:91				if x = float64_to_atom( x4 ) then*/
    RefDS(_x4_22936);
    _12953 = _13float64_to_atom(_x4_22936);
    if (binary_op_a(NOTEQ, _x_22935, _12953)){
        DeRef(_12953);
        _12953 = NOVALUE;
        goto L9; // [273] 290
    }
    DeRef(_12953);
    _12953 = NOVALUE;

    /** compress.e:92					return F8B & x4*/
    Prepend(&_12955, _x4_22936, 252);
    DeRef(_x_22935);
    DeRefDS(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12951);
    _12951 = NOVALUE;
    DeRef(_12943);
    _12943 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12938);
    _12938 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12946);
    _12946 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    DeRef(_12939);
    _12939 = NOVALUE;
    return _12955;
    goto L3; // [287] 389
L9: 

    /** compress.e:94					return F10B & atom_to_float80( x )*/
    Ref(_x_22935);
    _12956 = _13atom_to_float80(_x_22935);
    if (IS_SEQUENCE(253) && IS_ATOM(_12956)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12956)) {
        Prepend(&_12957, _12956, 253);
    }
    else {
        Concat((object_ptr)&_12957, 253, _12956);
    }
    DeRef(_12956);
    _12956 = NOVALUE;
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_s_22937);
    DeRef(_12951);
    _12951 = NOVALUE;
    DeRef(_12943);
    _12943 = NOVALUE;
    DeRef(_12955);
    _12955 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12938);
    _12938 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12946);
    _12946 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    DeRef(_12939);
    _12939 = NOVALUE;
    return _12957;
    goto L3; // [306] 389
L7: 

    /** compress.e:100			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22935)){
            _12958 = SEQ_PTR(_x_22935)->length;
    }
    else {
        _12958 = 1;
    }
    if (_12958 > 255)
    goto LA; // [314] 330

    /** compress.e:101				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22935)){
            _12960 = SEQ_PTR(_x_22935)->length;
    }
    else {
        _12960 = 1;
    }
    DeRef(_s_22937);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254;
    ((intptr_t *)_2)[2] = _12960;
    _s_22937 = MAKE_SEQ(_1);
    _12960 = NOVALUE;
    goto LB; // [327] 345
LA: 

    /** compress.e:103				s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22935)){
            _12962 = SEQ_PTR(_x_22935)->length;
    }
    else {
        _12962 = 1;
    }
    _12963 = _13int_to_bytes(_12962, 4);
    _12962 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12963)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12963)) {
        Prepend(&_s_22937, _12963, 255);
    }
    else {
        Concat((object_ptr)&_s_22937, 255, _12963);
    }
    DeRef(_12963);
    _12963 = NOVALUE;
LB: 

    /** compress.e:105			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22935)){
            _12965 = SEQ_PTR(_x_22935)->length;
    }
    else {
        _12965 = 1;
    }
    {
        object _i_23009;
        _i_23009 = 1;
LC: 
        if (_i_23009 > _12965){
            goto LD; // [350] 380
        }

        /** compress.e:106				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_22935);
        _12966 = (object)*(((s1_ptr)_2)->base + _i_23009);
        Ref(_12966);
        _12967 = _59compress(_12966);
        _12966 = NOVALUE;
        if (IS_SEQUENCE(_s_22937) && IS_ATOM(_12967)) {
            Ref(_12967);
            Append(&_s_22937, _s_22937, _12967);
        }
        else if (IS_ATOM(_s_22937) && IS_SEQUENCE(_12967)) {
        }
        else {
            Concat((object_ptr)&_s_22937, _s_22937, _12967);
        }
        DeRef(_12967);
        _12967 = NOVALUE;

        /** compress.e:107			end for*/
        _i_23009 = _i_23009 + 1;
        goto LC; // [375] 357
LD: 
        ;
    }

    /** compress.e:108			return s*/
    DeRef(_x_22935);
    DeRef(_x4_22936);
    DeRef(_12951);
    _12951 = NOVALUE;
    DeRef(_12943);
    _12943 = NOVALUE;
    DeRef(_12955);
    _12955 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12923);
    _12923 = NOVALUE;
    DeRef(_12938);
    _12938 = NOVALUE;
    DeRef(_12930);
    _12930 = NOVALUE;
    DeRef(_12918);
    _12918 = NOVALUE;
    DeRef(_12946);
    _12946 = NOVALUE;
    DeRef(_12929);
    _12929 = NOVALUE;
    DeRef(_12939);
    _12939 = NOVALUE;
    DeRef(_12957);
    _12957 = NOVALUE;
    return _s_22937;
L3: 
    ;
}



// 0xAE977164
