// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47add_options(object _new_options_50132)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16;
        if (insert_pos <= 0) {
            Concat(&_47options_50128,_new_options_50132,_47options_50128);
        }
        else if (insert_pos > SEQ_PTR(_47options_50128)->length){
            Concat(&_47options_50128,_47options_50128,_new_options_50132);
        }
        else if (IS_SEQUENCE(_new_options_50132)) {
            if( _47options_50128 != _47options_50128 || SEQ_PTR( _47options_50128 )->ref != 1 ){
                DeRef( _47options_50128 );
                RefDS( _47options_50128 );
            }
            assign_space = Add_internal_space( _47options_50128, insert_pos,((s1_ptr)SEQ_PTR(_new_options_50132))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_50132), _47options_50128 == _47options_50128 );
            _47options_50128 = MAKE_SEQ( assign_space );
        }
        else {
            if( _47options_50128 == _47options_50128 && SEQ_PTR( _47options_50128 )->ref == 1 ){
                _47options_50128 = Insert( _47options_50128, _new_options_50132, insert_pos);
            }
            else {
                DeRef( _47options_50128 );
                RefDS( _47options_50128 );
                _47options_50128 = Insert( _47options_50128, _new_options_50132, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_50132);
    return;
    ;
}


object _47get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_47options_50128);
    return _47options_50128;
    ;
}


object _47get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_47switches_50001);
    return _47switches_50001;
    ;
}


void _47show_copyrights()
{
    object _notices_50142 = NOVALUE;
    object _25734 = NOVALUE;
    object _25733 = NOVALUE;
    object _25731 = NOVALUE;
    object _25730 = NOVALUE;
    object _25729 = NOVALUE;
    object _25728 = NOVALUE;
    object _25726 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_50142;
    _notices_50142 = _40all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_50142)){
            _25726 = SEQ_PTR(_notices_50142)->length;
    }
    else {
        _25726 = 1;
    }
    {
        object _i_50146;
        _i_50146 = 1;
L1: 
        if (_i_50146 > _25726){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_50142);
        _25728 = (object)*(((s1_ptr)_2)->base + _i_50146);
        _2 = (object)SEQ_PTR(_25728);
        _25729 = (object)*(((s1_ptr)_2)->base + 1);
        _25728 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_50142);
        _25730 = (object)*(((s1_ptr)_2)->base + _i_50146);
        _2 = (object)SEQ_PTR(_25730);
        _25731 = (object)*(((s1_ptr)_2)->base + 2);
        _25730 = NOVALUE;
        RefDS(_22404);
        Ref(_25731);
        RefDS(_25732);
        _25733 = _14match_replace(_22404, _25731, _25732, 0);
        _25731 = NOVALUE;
        Ref(_25729);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25729;
        ((intptr_t *)_2)[2] = _25733;
        _25734 = MAKE_SEQ(_1);
        _25733 = NOVALUE;
        _25729 = NOVALUE;
        EPrintf(2, _25727, _25734);
        DeRefDS(_25734);
        _25734 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_50146 = _i_50146 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_50142);
    return;
    ;
}


void _47show_banner()
{
    object _version_type_inlined_version_type_at_220_50215 = NOVALUE;
    object _version_string_short_1__tmp_at204_50213 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_50212 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_50193 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_50185 = NOVALUE;
    object _prod_name_50159 = NOVALUE;
    object _memory_type_50160 = NOVALUE;
    object _misc_info_50182 = NOVALUE;
    object _EuConsole_50197 = NOVALUE;
    object _25759 = NOVALUE;
    object _25758 = NOVALUE;
    object _25757 = NOVALUE;
    object _25754 = NOVALUE;
    object _25753 = NOVALUE;
    object _25749 = NOVALUE;
    object _25748 = NOVALUE;
    object _25747 = NOVALUE;
    object _25745 = NOVALUE;
    object _25743 = NOVALUE;
    object _25742 = NOVALUE;
    object _25741 = NOVALUE;
    object _25736 = NOVALUE;
    object _25735 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_27INTERPRET_20176 == 0) {
        goto L1; // [5] 33
    }
    _25736 = (_27BIND_20182 == 0);
    if (_25736 == 0)
    {
        DeRef(_25736);
        _25736 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25736);
        _25736 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_22209);
    _0 = _prod_name_50159;
    _prod_name_50159 = _30GetMsgText(270, 0, _22209);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_27TRANSLATE_20179 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_22209);
    _0 = _prod_name_50159;
    _prod_name_50159 = _30GetMsgText(271, 0, _22209);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_27BIND_20182 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_22209);
    _0 = _prod_name_50159;
    _prod_name_50159 = _30GetMsgText(272, 0, _22209);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_22209);
    _0 = _memory_type_50160;
    _memory_type_50160 = _30GetMsgText(274, 0, _22209);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25741 = _40arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_8535);
    DeRefi(_platform_name_inlined_platform_name_at_94_50185);
    _platform_name_inlined_platform_name_at_94_50185 = _8535;
    _25742 = _40version_date(0);
    _25743 = _40version_node(0);
    _0 = _misc_info_50182;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25741;
    RefDS(_platform_name_inlined_platform_name_at_94_50185);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_50185;
    RefDS(_memory_type_50160);
    ((intptr_t*)_2)[3] = _memory_type_50160;
    RefDS(_22209);
    ((intptr_t*)_2)[4] = _22209;
    ((intptr_t*)_2)[5] = _25742;
    ((intptr_t*)_2)[6] = _25743;
    _misc_info_50182 = MAKE_SEQ(_1);
    DeRef(_0);
    _25743 = NOVALUE;
    _25742 = NOVALUE;
    _25741 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_40is_developmental_14904 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25745 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_50193);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _version_revision_inlined_version_revision_at_133_50193 = (object)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_133_50193);
    _25747 = _40version_node(0);
    Ref(_version_revision_inlined_version_revision_at_133_50193);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_50193;
    ((intptr_t *)_2)[2] = _25747;
    _25748 = MAKE_SEQ(_1);
    _25747 = NOVALUE;
    _25749 = EPrintf(-9999999, _25746, _25748);
    DeRefDS(_25748);
    _25748 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_50182);
    _2 = (object)(((s1_ptr)_2)->base + 6);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25749;
    if( _1 != _25749 ){
        DeRef(_1);
    }
    _25749 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_50197);
    _EuConsole_50197 = EGetEnv(_25750);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_50197 == _25752)
    _25753 = 1;
    else if (IS_ATOM_INT(_EuConsole_50197) && IS_ATOM_INT(_25752))
    _25753 = 0;
    else
    _25753 = (compare(_EuConsole_50197, _25752) == 0);
    if (_25753 == 0)
    {
        _25753 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25753 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_22209);
    _25754 = _30GetMsgText(275, 0, _22209);
    _2 = (object)SEQ_PTR(_misc_info_50182);
    _2 = (object)(((s1_ptr)_2)->base + 4);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25754;
    if( _1 != _25754 ){
        DeRef(_1);
    }
    _25754 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_50182);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        int stop = (IS_ATOM_INT(4)) ? 4 : (object)(DBL_PTR(4)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_50182), start, &_misc_info_50182 );
            }
            else Tail(SEQ_PTR(_misc_info_50182), stop+1, &_misc_info_50182);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_50182), start, &_misc_info_50182);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_50182 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_50182)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_50213;
    RHS_Slice(_40version_info_14902, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_50212);
    _version_string_short_inlined_version_string_short_at_204_50212 = EPrintf(-9999999, _8593, _version_string_short_1__tmp_at204_50213);
    DeRef(_version_string_short_1__tmp_at204_50213);
    _version_string_short_1__tmp_at204_50213 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_50215);
    _2 = (object)SEQ_PTR(_40version_info_14902);
    _version_type_inlined_version_type_at_220_50215 = (object)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_220_50215);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_50159);
    ((intptr_t*)_2)[1] = _prod_name_50159;
    RefDS(_version_string_short_inlined_version_string_short_at_204_50212);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_50212;
    Ref(_version_type_inlined_version_type_at_220_50215);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_50215;
    _25757 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25758, _25757, _misc_info_50182);
    DeRefDS(_25757);
    _25757 = NOVALUE;
    DeRef(_25757);
    _25757 = NOVALUE;
    _25759 = EPrintf(-9999999, _25756, _25758);
    DeRefDS(_25758);
    _25758 = NOVALUE;
    _49screen_output(2, _25759);
    _25759 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_50159);
    DeRef(_memory_type_50160);
    DeRefDS(_misc_info_50182);
    DeRefi(_EuConsole_50197);
    return;
    ;
}


object _47find_opt(object _name_type_50227, object _opt_50228, object _opts_50229)
{
    object _o_50233 = NOVALUE;
    object _has_case_50235 = NOVALUE;
    object _25772 = NOVALUE;
    object _25771 = NOVALUE;
    object _25770 = NOVALUE;
    object _25769 = NOVALUE;
    object _25768 = NOVALUE;
    object _25767 = NOVALUE;
    object _25766 = NOVALUE;
    object _25765 = NOVALUE;
    object _25764 = NOVALUE;
    object _25762 = NOVALUE;
    object _25760 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_50229)){
            _25760 = SEQ_PTR(_opts_50229)->length;
    }
    else {
        _25760 = 1;
    }
    {
        object _i_50231;
        _i_50231 = 1;
L1: 
        if (_i_50231 > _25760){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_50233);
        _2 = (object)SEQ_PTR(_opts_50229);
        _o_50233 = (object)*(((s1_ptr)_2)->base + _i_50231);
        Ref(_o_50233);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_50233);
        _25762 = (object)*(((s1_ptr)_2)->base + 4);
        _has_case_50235 = find_from(99, _25762, 1);
        _25762 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_50235 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_50233);
        _25765 = (object)*(((s1_ptr)_2)->base + _name_type_50227);
        if (_25765 == _opt_50228)
        _25766 = 1;
        else if (IS_ATOM_INT(_25765) && IS_ATOM_INT(_opt_50228))
        _25766 = 0;
        else
        _25766 = (compare(_25765, _opt_50228) == 0);
        _25765 = NOVALUE;
        if (_25766 == 0)
        {
            _25766 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25766 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_50228);
        DeRefDS(_opts_50229);
        return _o_50233;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25767 = (_has_case_50235 == 0);
        if (_25767 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_50233);
        _25769 = (object)*(((s1_ptr)_2)->base + _name_type_50227);
        Ref(_25769);
        _25770 = _12lower(_25769);
        _25769 = NOVALUE;
        RefDS(_opt_50228);
        _25771 = _12lower(_opt_50228);
        if (_25770 == _25771)
        _25772 = 1;
        else if (IS_ATOM_INT(_25770) && IS_ATOM_INT(_25771))
        _25772 = 0;
        else
        _25772 = (compare(_25770, _25771) == 0);
        DeRef(_25770);
        _25770 = NOVALUE;
        DeRef(_25771);
        _25771 = NOVALUE;
        if (_25772 == 0)
        {
            _25772 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25772 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_50228);
        DeRefDS(_opts_50229);
        DeRef(_25767);
        _25767 = NOVALUE;
        return _o_50233;
L5: 
L4: 
        DeRef(_o_50233);
        _o_50233 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_50231 = _i_50231 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_22209);
    DeRefDS(_opt_50228);
    DeRefDS(_opts_50229);
    DeRef(_25767);
    _25767 = NOVALUE;
    return _22209;
    ;
}


object _47merge_parameters(object _a_50252, object _b_50253, object _opts_50254, object _dedupe_50255)
{
    object _i_50256 = NOVALUE;
    object _opt_50260 = NOVALUE;
    object _this_opt_50266 = NOVALUE;
    object _bi_50267 = NOVALUE;
    object _beginLen_50327 = NOVALUE;
    object _first_extra_50349 = NOVALUE;
    object _opt_50353 = NOVALUE;
    object _this_opt_50358 = NOVALUE;
    object _25866 = NOVALUE;
    object _25865 = NOVALUE;
    object _25862 = NOVALUE;
    object _25861 = NOVALUE;
    object _25860 = NOVALUE;
    object _25858 = NOVALUE;
    object _25857 = NOVALUE;
    object _25856 = NOVALUE;
    object _25855 = NOVALUE;
    object _25853 = NOVALUE;
    object _25852 = NOVALUE;
    object _25850 = NOVALUE;
    object _25849 = NOVALUE;
    object _25848 = NOVALUE;
    object _25847 = NOVALUE;
    object _25846 = NOVALUE;
    object _25845 = NOVALUE;
    object _25844 = NOVALUE;
    object _25842 = NOVALUE;
    object _25839 = NOVALUE;
    object _25838 = NOVALUE;
    object _25833 = NOVALUE;
    object _25831 = NOVALUE;
    object _25830 = NOVALUE;
    object _25829 = NOVALUE;
    object _25828 = NOVALUE;
    object _25827 = NOVALUE;
    object _25826 = NOVALUE;
    object _25825 = NOVALUE;
    object _25824 = NOVALUE;
    object _25820 = NOVALUE;
    object _25819 = NOVALUE;
    object _25818 = NOVALUE;
    object _25817 = NOVALUE;
    object _25816 = NOVALUE;
    object _25815 = NOVALUE;
    object _25814 = NOVALUE;
    object _25813 = NOVALUE;
    object _25812 = NOVALUE;
    object _25811 = NOVALUE;
    object _25810 = NOVALUE;
    object _25809 = NOVALUE;
    object _25808 = NOVALUE;
    object _25807 = NOVALUE;
    object _25806 = NOVALUE;
    object _25804 = NOVALUE;
    object _25803 = NOVALUE;
    object _25802 = NOVALUE;
    object _25801 = NOVALUE;
    object _25800 = NOVALUE;
    object _25799 = NOVALUE;
    object _25798 = NOVALUE;
    object _25797 = NOVALUE;
    object _25795 = NOVALUE;
    object _25794 = NOVALUE;
    object _25793 = NOVALUE;
    object _25792 = NOVALUE;
    object _25790 = NOVALUE;
    object _25789 = NOVALUE;
    object _25788 = NOVALUE;
    object _25787 = NOVALUE;
    object _25786 = NOVALUE;
    object _25785 = NOVALUE;
    object _25784 = NOVALUE;
    object _25782 = NOVALUE;
    object _25781 = NOVALUE;
    object _25779 = NOVALUE;
    object _25776 = NOVALUE;
    object _25773 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_50256 = 1;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_50252)){
            _25773 = SEQ_PTR(_a_50252)->length;
    }
    else {
        _25773 = 1;
    }
    if (_i_50256 > _25773)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_50260);
    _2 = (object)SEQ_PTR(_a_50252);
    _opt_50260 = (object)*(((s1_ptr)_2)->base + _i_50256);
    Ref(_opt_50260);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_50260)){
            _25776 = SEQ_PTR(_opt_50260)->length;
    }
    else {
        _25776 = 1;
    }
    if (_25776 >= 2)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_50256 = _i_50256 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_50260);
    _opt_50260 = NOVALUE;
    DeRef(_this_opt_50266);
    _this_opt_50266 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_22209);
    DeRef(_this_opt_50266);
    _this_opt_50266 = _22209;

    /** cominit.e:209			integer bi = 0*/
    _bi_50267 = 0;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50260);
    _25779 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25779, 45)){
        _25779 = NOVALUE;
        goto L4; // [74] 149
    }
    _25779 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50260)){
            _25781 = SEQ_PTR(_opt_50260)->length;
    }
    else {
        _25781 = 1;
    }
    rhs_slice_target = (object_ptr)&_25782;
    RHS_Slice(_opt_50260, 3, _25781);
    RefDS(_opts_50254);
    _0 = _this_opt_50266;
    _this_opt_50266 = _47find_opt(2, _25782, _opts_50254);
    DeRefDS(_0);
    _25782 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50253)){
            _25784 = SEQ_PTR(_b_50253)->length;
    }
    else {
        _25784 = 1;
    }
    {
        object _j_50275;
        _j_50275 = 1;
L5: 
        if (_j_50275 > _25784){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_50253);
        _25785 = (object)*(((s1_ptr)_2)->base + _j_50275);
        Ref(_25785);
        _25786 = _12lower(_25785);
        _25785 = NOVALUE;
        RefDS(_opt_50260);
        _25787 = _12lower(_opt_50260);
        if (_25786 == _25787)
        _25788 = 1;
        else if (IS_ATOM_INT(_25786) && IS_ATOM_INT(_25787))
        _25788 = 0;
        else
        _25788 = (compare(_25786, _25787) == 0);
        DeRef(_25786);
        _25786 = NOVALUE;
        DeRef(_25787);
        _25787 = NOVALUE;
        if (_25788 == 0)
        {
            _25788 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25788 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_50267 = _j_50275;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_50275 = _j_50275 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50260);
    _25789 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25789)) {
        _25790 = (_25789 == 45);
    }
    else {
        _25790 = binary_op(EQUALS, _25789, 45);
    }
    _25789 = NOVALUE;
    if (IS_ATOM_INT(_25790)) {
        if (_25790 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25790)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_50260);
    _25792 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25792)) {
        _25793 = (_25792 == 47);
    }
    else {
        _25793 = binary_op(EQUALS, _25792, 47);
    }
    _25792 = NOVALUE;
    if (_25793 == 0) {
        DeRef(_25793);
        _25793 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25793) && DBL_PTR(_25793)->dbl == 0.0){
            DeRef(_25793);
            _25793 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25793);
        _25793 = NOVALUE;
    }
    DeRef(_25793);
    _25793 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50260)){
            _25794 = SEQ_PTR(_opt_50260)->length;
    }
    else {
        _25794 = 1;
    }
    rhs_slice_target = (object_ptr)&_25795;
    RHS_Slice(_opt_50260, 2, _25794);
    RefDS(_opts_50254);
    _0 = _this_opt_50266;
    _this_opt_50266 = _47find_opt(1, _25795, _opts_50254);
    DeRef(_0);
    _25795 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50253)){
            _25797 = SEQ_PTR(_b_50253)->length;
    }
    else {
        _25797 = 1;
    }
    {
        object _j_50292;
        _j_50292 = 1;
LB: 
        if (_j_50292 > _25797){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_50253);
        _25798 = (object)*(((s1_ptr)_2)->base + _j_50292);
        Ref(_25798);
        _25799 = _12lower(_25798);
        _25798 = NOVALUE;
        if (IS_SEQUENCE(_opt_50260)){
                _25800 = SEQ_PTR(_opt_50260)->length;
        }
        else {
            _25800 = 1;
        }
        rhs_slice_target = (object_ptr)&_25801;
        RHS_Slice(_opt_50260, 2, _25800);
        _25802 = _12lower(_25801);
        _25801 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25802)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25802)) {
            Prepend(&_25803, _25802, 45);
        }
        else {
            Concat((object_ptr)&_25803, 45, _25802);
        }
        DeRef(_25802);
        _25802 = NOVALUE;
        if (_25799 == _25803)
        _25804 = 1;
        else if (IS_ATOM_INT(_25799) && IS_ATOM_INT(_25803))
        _25804 = 0;
        else
        _25804 = (compare(_25799, _25803) == 0);
        DeRef(_25799);
        _25799 = NOVALUE;
        DeRefDS(_25803);
        _25803 = NOVALUE;
        if (_25804 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_50253);
        _25806 = (object)*(((s1_ptr)_2)->base + _j_50292);
        Ref(_25806);
        _25807 = _12lower(_25806);
        _25806 = NOVALUE;
        if (IS_SEQUENCE(_opt_50260)){
                _25808 = SEQ_PTR(_opt_50260)->length;
        }
        else {
            _25808 = 1;
        }
        rhs_slice_target = (object_ptr)&_25809;
        RHS_Slice(_opt_50260, 2, _25808);
        _25810 = _12lower(_25809);
        _25809 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25810)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25810)) {
            Prepend(&_25811, _25810, 47);
        }
        else {
            Concat((object_ptr)&_25811, 47, _25810);
        }
        DeRef(_25810);
        _25810 = NOVALUE;
        if (_25807 == _25811)
        _25812 = 1;
        else if (IS_ATOM_INT(_25807) && IS_ATOM_INT(_25811))
        _25812 = 0;
        else
        _25812 = (compare(_25807, _25811) == 0);
        DeRef(_25807);
        _25807 = NOVALUE;
        DeRefDS(_25811);
        _25811 = NOVALUE;
        if (_25812 == 0)
        {
            _25812 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25812 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_50267 = _j_50292;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_50292 = _j_50292 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_50266)){
            _25813 = SEQ_PTR(_this_opt_50266)->length;
    }
    else {
        _25813 = 1;
    }
    if (_25813 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_50266);
    _25815 = (object)*(((s1_ptr)_2)->base + 4);
    _25816 = find_from(42, _25815, 1);
    _25815 = NOVALUE;
    _25817 = (_25816 == 0);
    _25816 = NOVALUE;
    if (_25817 == 0)
    {
        DeRef(_25817);
        _25817 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25817);
        _25817 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_50267 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50266);
    _25818 = (object)*(((s1_ptr)_2)->base + 4);
    _25819 = find_from(112, _25818, 1);
    _25818 = NOVALUE;
    if (_25819 == 0)
    {
        _25819 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25819 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25820 = _i_50256 + 1;
    if (_25820 > MAXINT){
        _25820 = NewDouble((eudouble)_25820);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_50252);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50256)) ? _i_50256 : (object)(DBL_PTR(_i_50256)->dbl);
        int stop = (IS_ATOM_INT(_25820)) ? _25820 : (object)(DBL_PTR(_25820)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50252), start, &_a_50252 );
            }
            else Tail(SEQ_PTR(_a_50252), stop+1, &_a_50252);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50252), start, &_a_50252);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50252 = Remove_elements(start, stop, (SEQ_PTR(_a_50252)->ref == 1));
        }
    }
    DeRef(_25820);
    _25820 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_50252);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50256)) ? _i_50256 : (object)(DBL_PTR(_i_50256)->dbl);
        int stop = (IS_ATOM_INT(_i_50256)) ? _i_50256 : (object)(DBL_PTR(_i_50256)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50252), start, &_a_50252 );
            }
            else Tail(SEQ_PTR(_a_50252), stop+1, &_a_50252);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50252), start, &_a_50252);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50252 = Remove_elements(start, stop, (SEQ_PTR(_a_50252)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_50252)){
            _beginLen_50327 = SEQ_PTR(_a_50252)->length;
    }
    else {
        _beginLen_50327 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25824 = (_dedupe_50255 == 0);
    if (_25824 == 0) {
        goto L13; // [376] 438
    }
    _25826 = (_i_50256 < _beginLen_50327);
    if (_25826 == 0)
    {
        DeRef(_25826);
        _25826 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25826);
        _25826 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25827 = _i_50256 + 1;
    if (_25827 > MAXINT){
        _25827 = NewDouble((eudouble)_25827);
    }
    if (IS_SEQUENCE(_a_50252)){
            _25828 = SEQ_PTR(_a_50252)->length;
    }
    else {
        _25828 = 1;
    }
    rhs_slice_target = (object_ptr)&_25829;
    RHS_Slice(_a_50252, _25827, _25828);
    rhs_slice_target = (object_ptr)&_25830;
    RHS_Slice(_a_50252, 1, _i_50256);
    RefDS(_opts_50254);
    DeRef(_25831);
    _25831 = _opts_50254;
    _0 = _a_50252;
    _a_50252 = _47merge_parameters(_25829, _25830, _25831, 1);
    DeRefDS(_0);
    _25829 = NOVALUE;
    _25830 = NOVALUE;
    _25831 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_50252)){
            _25833 = SEQ_PTR(_a_50252)->length;
    }
    else {
        _25833 = 1;
    }
    if (_beginLen_50327 != _25833)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_50256 = _i_50256 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_50256 = _i_50256 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_50256 = _i_50256 + 1;
L12: 
    DeRef(_opt_50260);
    _opt_50260 = NOVALUE;
    DeRef(_this_opt_50266);
    _this_opt_50266 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_50255 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25838, _b_50253, _a_50252);
    DeRefDS(_a_50252);
    DeRefDS(_b_50253);
    DeRefDS(_opts_50254);
    DeRef(_25827);
    _25827 = NOVALUE;
    DeRef(_25790);
    _25790 = NOVALUE;
    DeRef(_25824);
    _25824 = NOVALUE;
    return _25838;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_50349 = 0;

    /** cominit.e:292		i = 1*/
    _i_50256 = 1;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_50253)){
            _25839 = SEQ_PTR(_b_50253)->length;
    }
    else {
        _25839 = 1;
    }
    if (_i_50256 > _25839)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_50353);
    _2 = (object)SEQ_PTR(_b_50253);
    _opt_50353 = (object)*(((s1_ptr)_2)->base + _i_50256);
    Ref(_opt_50353);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_50353)){
            _25842 = SEQ_PTR(_opt_50353)->length;
    }
    else {
        _25842 = 1;
    }
    if (_25842 > 1)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_50349 = _i_50256;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_50353);
    _opt_50353 = NOVALUE;
    DeRef(_this_opt_50358);
    _this_opt_50358 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_22209);
    DeRef(_this_opt_50358);
    _this_opt_50358 = _22209;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50353);
    _25844 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25844)) {
        _25845 = (_25844 == 45);
    }
    else {
        _25845 = binary_op(EQUALS, _25844, 45);
    }
    _25844 = NOVALUE;
    if (IS_ATOM_INT(_25845)) {
        if (_25845 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25845)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_50353);
    _25847 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25847)) {
        _25848 = (_25847 == 45);
    }
    else {
        _25848 = binary_op(EQUALS, _25847, 45);
    }
    _25847 = NOVALUE;
    if (_25848 == 0) {
        DeRef(_25848);
        _25848 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25848) && DBL_PTR(_25848)->dbl == 0.0){
            DeRef(_25848);
            _25848 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25848);
        _25848 = NOVALUE;
    }
    DeRef(_25848);
    _25848 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50353)){
            _25849 = SEQ_PTR(_opt_50353)->length;
    }
    else {
        _25849 = 1;
    }
    rhs_slice_target = (object_ptr)&_25850;
    RHS_Slice(_opt_50353, 3, _25849);
    RefDS(_opts_50254);
    _0 = _this_opt_50358;
    _this_opt_50358 = _47find_opt(2, _25850, _opts_50254);
    DeRef(_0);
    _25850 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50353);
    _25852 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25852)) {
        _25853 = (_25852 == 45);
    }
    else {
        _25853 = binary_op(EQUALS, _25852, 45);
    }
    _25852 = NOVALUE;
    if (IS_ATOM_INT(_25853)) {
        if (_25853 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25853)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_50353);
    _25855 = (object)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25855)) {
        _25856 = (_25855 == 47);
    }
    else {
        _25856 = binary_op(EQUALS, _25855, 47);
    }
    _25855 = NOVALUE;
    if (_25856 == 0) {
        DeRef(_25856);
        _25856 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25856) && DBL_PTR(_25856)->dbl == 0.0){
            DeRef(_25856);
            _25856 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25856);
        _25856 = NOVALUE;
    }
    DeRef(_25856);
    _25856 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50353)){
            _25857 = SEQ_PTR(_opt_50353)->length;
    }
    else {
        _25857 = 1;
    }
    rhs_slice_target = (object_ptr)&_25858;
    RHS_Slice(_opt_50353, 2, _25857);
    RefDS(_opts_50254);
    _0 = _this_opt_50358;
    _this_opt_50358 = _47find_opt(1, _25858, _opts_50254);
    DeRef(_0);
    _25858 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_50358)){
            _25860 = SEQ_PTR(_this_opt_50358)->length;
    }
    else {
        _25860 = 1;
    }
    if (_25860 == 0)
    {
        _25860 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25860 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50358);
    _25861 = (object)*(((s1_ptr)_2)->base + 4);
    _25862 = find_from(112, _25861, 1);
    _25861 = NOVALUE;
    if (_25862 == 0)
    {
        _25862 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25862 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_50256 = _i_50256 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_50349 = _i_50256;

    /** cominit.e:317				exit*/
    DeRef(_opt_50353);
    _opt_50353 = NOVALUE;
    DeRef(_this_opt_50358);
    _this_opt_50358 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_50256 = _i_50256 + 1;
    DeRef(_opt_50353);
    _opt_50353 = NOVALUE;
    DeRef(_this_opt_50358);
    _this_opt_50358 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_50349 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_50349;
        if (insert_pos <= 0) {
            Concat(&_25865,_a_50252,_b_50253);
        }
        else if (insert_pos > SEQ_PTR(_b_50253)->length){
            Concat(&_25865,_b_50253,_a_50252);
        }
        else if (IS_SEQUENCE(_a_50252)) {
            if( _25865 != _b_50253 || SEQ_PTR( _b_50253 )->ref != 1 ){
                DeRef( _25865 );
                RefDS( _b_50253 );
            }
            assign_space = Add_internal_space( _b_50253, insert_pos,((s1_ptr)SEQ_PTR(_a_50252))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_50252), _b_50253 == _25865 );
            _25865 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25865 == _b_50253 && SEQ_PTR( _b_50253 )->ref == 1 ){
                _25865 = Insert( _b_50253, _a_50252, insert_pos);
            }
            else {
                DeRef( _25865 );
                RefDS( _b_50253 );
                _25865 = Insert( _b_50253, _a_50252, insert_pos);
            }
        }
    }
    DeRefDS(_a_50252);
    DeRefDS(_b_50253);
    DeRefDS(_opts_50254);
    DeRef(_25838);
    _25838 = NOVALUE;
    DeRef(_25853);
    _25853 = NOVALUE;
    DeRef(_25845);
    _25845 = NOVALUE;
    DeRef(_25827);
    _25827 = NOVALUE;
    DeRef(_25790);
    _25790 = NOVALUE;
    DeRef(_25824);
    _25824 = NOVALUE;
    return _25865;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25866, _b_50253, _a_50252);
    DeRefDS(_a_50252);
    DeRefDS(_b_50253);
    DeRefDS(_opts_50254);
    DeRef(_25838);
    _25838 = NOVALUE;
    DeRef(_25853);
    _25853 = NOVALUE;
    DeRef(_25845);
    _25845 = NOVALUE;
    DeRef(_25827);
    _25827 = NOVALUE;
    DeRef(_25790);
    _25790 = NOVALUE;
    DeRef(_25824);
    _25824 = NOVALUE;
    DeRef(_25865);
    _25865 = NOVALUE;
    return _25866;
    ;
}


object _47validate_opt(object _opt_type_50391, object _arg_50392, object _args_50393, object _ix_50394)
{
    object _opt_50395 = NOVALUE;
    object _this_opt_50403 = NOVALUE;
    object _25885 = NOVALUE;
    object _25884 = NOVALUE;
    object _25883 = NOVALUE;
    object _25882 = NOVALUE;
    object _25881 = NOVALUE;
    object _25879 = NOVALUE;
    object _25878 = NOVALUE;
    object _25877 = NOVALUE;
    object _25876 = NOVALUE;
    object _25875 = NOVALUE;
    object _25873 = NOVALUE;
    object _25870 = NOVALUE;
    object _25868 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_50391 != 1)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_50392)){
            _25868 = SEQ_PTR(_arg_50392)->length;
    }
    else {
        _25868 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50395;
    RHS_Slice(_arg_50392, 2, _25868);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_50392)){
            _25870 = SEQ_PTR(_arg_50392)->length;
    }
    else {
        _25870 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50395;
    RHS_Slice(_arg_50392, 3, _25870);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_50395);
    RefDS(_47options_50128);
    _0 = _this_opt_50403;
    _this_opt_50403 = _47find_opt(_opt_type_50391, _opt_50395, _47options_50128);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_50403)){
            _25873 = SEQ_PTR(_this_opt_50403)->length;
    }
    else {
        _25873 = 1;
    }
    if (_25873 != 0)
    goto L3; // [58] 72
    _25873 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _25875 = MAKE_SEQ(_1);
    DeRefDS(_arg_50392);
    DeRefDS(_args_50393);
    DeRefDS(_opt_50395);
    DeRefDS(_this_opt_50403);
    return _25875;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_50403);
    _25876 = (object)*(((s1_ptr)_2)->base + 4);
    _25877 = find_from(112, _25876, 1);
    _25876 = NOVALUE;
    if (_25877 == 0)
    {
        _25877 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25877 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_50393)){
            _25878 = SEQ_PTR(_args_50393)->length;
    }
    else {
        _25878 = 1;
    }
    _25879 = _25878 - 1;
    _25878 = NOVALUE;
    if (_ix_50394 != _25879)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_50392);
    ((intptr_t*)_2)[1] = _arg_50392;
    _25881 = MAKE_SEQ(_1);
    _49CompileErr(353, _25881, 0);
    _25881 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25882 = _ix_50394 + 2;
    if ((object)((uintptr_t)_25882 + (uintptr_t)HIGH_BITS) >= 0){
        _25882 = NewDouble((eudouble)_25882);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50394;
    ((intptr_t *)_2)[2] = _25882;
    _25883 = MAKE_SEQ(_1);
    _25882 = NOVALUE;
    DeRefDS(_arg_50392);
    DeRefDS(_args_50393);
    DeRef(_opt_50395);
    DeRef(_this_opt_50403);
    DeRef(_25875);
    _25875 = NOVALUE;
    DeRef(_25879);
    _25879 = NOVALUE;
    return _25883;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25884 = _ix_50394 + 1;
    if (_25884 > MAXINT){
        _25884 = NewDouble((eudouble)_25884);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50394;
    ((intptr_t *)_2)[2] = _25884;
    _25885 = MAKE_SEQ(_1);
    _25884 = NOVALUE;
    DeRefDS(_arg_50392);
    DeRefDS(_args_50393);
    DeRef(_opt_50395);
    DeRef(_this_opt_50403);
    DeRef(_25875);
    _25875 = NOVALUE;
    DeRef(_25883);
    _25883 = NOVALUE;
    DeRef(_25879);
    _25879 = NOVALUE;
    return _25885;
L6: 
    ;
}


object _47find_next_opt(object _ix_50428, object _args_50429)
{
    object _arg_50433 = NOVALUE;
    object _25907 = NOVALUE;
    object _25906 = NOVALUE;
    object _25904 = NOVALUE;
    object _25903 = NOVALUE;
    object _25902 = NOVALUE;
    object _25901 = NOVALUE;
    object _25900 = NOVALUE;
    object _25899 = NOVALUE;
    object _25898 = NOVALUE;
    object _25897 = NOVALUE;
    object _25895 = NOVALUE;
    object _25893 = NOVALUE;
    object _25891 = NOVALUE;
    object _25889 = NOVALUE;
    object _25886 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50429)){
            _25886 = SEQ_PTR(_args_50429)->length;
    }
    else {
        _25886 = 1;
    }
    if (_ix_50428 >= _25886)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50433);
    _2 = (object)SEQ_PTR(_args_50429);
    _arg_50433 = (object)*(((s1_ptr)_2)->base + _ix_50428);
    Ref(_arg_50433);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50433)){
            _25889 = SEQ_PTR(_arg_50433)->length;
    }
    else {
        _25889 = 1;
    }
    if (_25889 <= 1)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50433);
    _25891 = (object)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25891, 45)){
        _25891 = NOVALUE;
        goto L4; // [40] 111
    }
    _25891 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50433);
    _25893 = (object)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25893, 45)){
        _25893 = NOVALUE;
        goto L5; // [50] 94
    }
    _25893 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50433)){
            _25895 = SEQ_PTR(_arg_50433)->length;
    }
    else {
        _25895 = 1;
    }
    if (_25895 != 2)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25897 = _ix_50428 - 1;
    if ((object)((uintptr_t)_25897 +(uintptr_t) HIGH_BITS) >= 0){
        _25897 = NewDouble((eudouble)_25897);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25897;
    _25898 = MAKE_SEQ(_1);
    _25897 = NOVALUE;
    DeRefDS(_arg_50433);
    DeRefDS(_args_50429);
    return _25898;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50433);
    RefDS(_args_50429);
    _25899 = _47validate_opt(2, _arg_50433, _args_50429, _ix_50428);
    DeRefDS(_arg_50433);
    DeRefDS(_args_50429);
    DeRef(_25898);
    _25898 = NOVALUE;
    return _25899;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50433);
    RefDS(_args_50429);
    _25900 = _47validate_opt(1, _arg_50433, _args_50429, _ix_50428);
    DeRefDS(_arg_50433);
    DeRefDS(_args_50429);
    DeRef(_25898);
    _25898 = NOVALUE;
    DeRef(_25899);
    _25899 = NOVALUE;
    return _25900;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25901 = _ix_50428 - 1;
    if ((object)((uintptr_t)_25901 +(uintptr_t) HIGH_BITS) >= 0){
        _25901 = NewDouble((eudouble)_25901);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25901;
    _25902 = MAKE_SEQ(_1);
    _25901 = NOVALUE;
    DeRef(_arg_50433);
    DeRefDS(_args_50429);
    DeRef(_25900);
    _25900 = NOVALUE;
    DeRef(_25898);
    _25898 = NOVALUE;
    DeRef(_25899);
    _25899 = NOVALUE;
    return _25902;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25903 = _ix_50428 - 1;
    if ((object)((uintptr_t)_25903 +(uintptr_t) HIGH_BITS) >= 0){
        _25903 = NewDouble((eudouble)_25903);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25903;
    _25904 = MAKE_SEQ(_1);
    _25903 = NOVALUE;
    DeRef(_arg_50433);
    DeRefDS(_args_50429);
    DeRef(_25900);
    _25900 = NOVALUE;
    DeRef(_25902);
    _25902 = NOVALUE;
    DeRef(_25898);
    _25898 = NOVALUE;
    DeRef(_25899);
    _25899 = NOVALUE;
    return _25904;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50428 = _ix_50428 + 1;
    DeRef(_arg_50433);
    _arg_50433 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25906 = _ix_50428 - 1;
    if ((object)((uintptr_t)_25906 +(uintptr_t) HIGH_BITS) >= 0){
        _25906 = NewDouble((eudouble)_25906);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = _25906;
    _25907 = MAKE_SEQ(_1);
    _25906 = NOVALUE;
    DeRefDS(_args_50429);
    DeRef(_25900);
    _25900 = NOVALUE;
    DeRef(_25904);
    _25904 = NOVALUE;
    DeRef(_25902);
    _25902 = NOVALUE;
    DeRef(_25898);
    _25898 = NOVALUE;
    DeRef(_25899);
    _25899 = NOVALUE;
    return _25907;
    ;
}


object _47expand_config_options(object _args_50463)
{
    object _idx_50464 = NOVALUE;
    object _next_idx_50465 = NOVALUE;
    object _files_50466 = NOVALUE;
    object _cmd_1_2_50467 = NOVALUE;
    object _25930 = NOVALUE;
    object _25929 = NOVALUE;
    object _25928 = NOVALUE;
    object _25927 = NOVALUE;
    object _25926 = NOVALUE;
    object _25925 = NOVALUE;
    object _25924 = NOVALUE;
    object _25923 = NOVALUE;
    object _25922 = NOVALUE;
    object _25917 = NOVALUE;
    object _25915 = NOVALUE;
    object _25914 = NOVALUE;
    object _25913 = NOVALUE;
    object _25911 = NOVALUE;
    object _25910 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50464 = 1;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_22209);
    DeRef(_files_50466);
    _files_50466 = _22209;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50467;
    RHS_Slice(_args_50463, 1, 2);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50463);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (object)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (object)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50463), start, &_args_50463 );
            }
            else Tail(SEQ_PTR(_args_50463), stop+1, &_args_50463);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50463), start, &_args_50463);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50463 = Remove_elements(start, stop, (SEQ_PTR(_args_50463)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50464 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50463);
    _25910 = (object)*(((s1_ptr)_2)->base + _idx_50464);
    Ref(_25910);
    _25911 = _12upper(_25910);
    _25910 = NOVALUE;
    if (_25911 == _25912)
    _25913 = 1;
    else if (IS_ATOM_INT(_25911) && IS_ATOM_INT(_25912))
    _25913 = 0;
    else
    _25913 = (compare(_25911, _25912) == 0);
    DeRef(_25911);
    _25911 = NOVALUE;
    if (_25913 == 0)
    {
        _25913 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25913 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25914 = _idx_50464 + 1;
    _2 = (object)SEQ_PTR(_args_50463);
    _25915 = (object)*(((s1_ptr)_2)->base + _25914);
    Ref(_25915);
    Append(&_files_50466, _files_50466, _25915);
    _25915 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25917 = _idx_50464 + 1;
    if (_25917 > MAXINT){
        _25917 = NewDouble((eudouble)_25917);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50463);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50464)) ? _idx_50464 : (object)(DBL_PTR(_idx_50464)->dbl);
        int stop = (IS_ATOM_INT(_25917)) ? _25917 : (object)(DBL_PTR(_25917)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50463), start, &_args_50463 );
            }
            else Tail(SEQ_PTR(_args_50463), stop+1, &_args_50463);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50463), start, &_args_50463);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50463 = Remove_elements(start, stop, (SEQ_PTR(_args_50463)->ref == 1));
        }
    }
    DeRef(_25917);
    _25917 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50465);
    _idx_50464 = (object)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_50464))
    _idx_50464 = (object)DBL_PTR(_idx_50464)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50463);
    _0 = _next_idx_50465;
    _next_idx_50465 = _47find_next_opt(_idx_50464, _args_50463);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50465);
    _idx_50464 = (object)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_50464))
    _idx_50464 = (object)DBL_PTR(_idx_50464)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50466);
    _25922 = _46GetDefaultArgs(_files_50466);
    _2 = (object)SEQ_PTR(_next_idx_50465);
    _25923 = (object)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25924;
    RHS_Slice(_args_50463, 1, _25923);
    RefDS(_47options_50128);
    _25925 = _47merge_parameters(_25922, _25924, _47options_50128, 1);
    _25922 = NOVALUE;
    _25924 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50465);
    _25926 = (object)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25926)) {
        _25927 = _25926 + 1;
        if (_25927 > MAXINT){
            _25927 = NewDouble((eudouble)_25927);
        }
    }
    else
    _25927 = binary_op(PLUS, 1, _25926);
    _25926 = NOVALUE;
    if (IS_SEQUENCE(_args_50463)){
            _25928 = SEQ_PTR(_args_50463)->length;
    }
    else {
        _25928 = 1;
    }
    rhs_slice_target = (object_ptr)&_25929;
    RHS_Slice(_args_50463, _25927, _25928);
    {
        object concat_list[3];

        concat_list[0] = _25929;
        concat_list[1] = _25925;
        concat_list[2] = _cmd_1_2_50467;
        Concat_N((object_ptr)&_25930, concat_list, 3);
    }
    DeRefDS(_25929);
    _25929 = NOVALUE;
    DeRef(_25925);
    _25925 = NOVALUE;
    DeRefDS(_args_50463);
    DeRefDS(_next_idx_50465);
    DeRefDS(_files_50466);
    DeRefDS(_cmd_1_2_50467);
    DeRef(_25914);
    _25914 = NOVALUE;
    _25923 = NOVALUE;
    DeRef(_25927);
    _25927 = NOVALUE;
    return _25930;
    ;
}


void _47handle_common_options(object _opts_50498)
{
    object _opt_keys_50499 = NOVALUE;
    object _option_w_50501 = NOVALUE;
    object _key_50505 = NOVALUE;
    object _val_50507 = NOVALUE;
    object _this_warn_50553 = NOVALUE;
    object _auto_add_warn_50555 = NOVALUE;
    object _n_50561 = NOVALUE;
    object _this_warn_50584 = NOVALUE;
    object _auto_add_warn_50586 = NOVALUE;
    object _n_50592 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50628 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50641 = NOVALUE;
    object _25989 = NOVALUE;
    object _25988 = NOVALUE;
    object _25986 = NOVALUE;
    object _25984 = NOVALUE;
    object _25982 = NOVALUE;
    object _25981 = NOVALUE;
    object _25980 = NOVALUE;
    object _25979 = NOVALUE;
    object _25978 = NOVALUE;
    object _25977 = NOVALUE;
    object _25976 = NOVALUE;
    object _25975 = NOVALUE;
    object _25973 = NOVALUE;
    object _25971 = NOVALUE;
    object _25970 = NOVALUE;
    object _25969 = NOVALUE;
    object _25964 = NOVALUE;
    object _25962 = NOVALUE;
    object _25960 = NOVALUE;
    object _25957 = NOVALUE;
    object _25956 = NOVALUE;
    object _25951 = NOVALUE;
    object _25949 = NOVALUE;
    object _25947 = NOVALUE;
    object _25945 = NOVALUE;
    object _25944 = NOVALUE;
    object _25943 = NOVALUE;
    object _25942 = NOVALUE;
    object _25941 = NOVALUE;
    object _25940 = NOVALUE;
    object _25938 = NOVALUE;
    object _25937 = NOVALUE;
    object _25932 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50498);
    _0 = _opt_keys_50499;
    _opt_keys_50499 = _34keys(_opts_50498, 0);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50501 = 0;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50499)){
            _25932 = SEQ_PTR(_opt_keys_50499)->length;
    }
    else {
        _25932 = 1;
    }
    {
        object _idx_50503;
        _idx_50503 = 1;
L1: 
        if (_idx_50503 > _25932){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50505);
        _2 = (object)SEQ_PTR(_opt_keys_50499);
        _key_50505 = (object)*(((s1_ptr)_2)->base + _idx_50503);
        Ref(_key_50505);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50498);
        RefDS(_key_50505);
        _0 = _val_50507;
        _val_50507 = _34get(_opts_50498, _key_50505, 0);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50505, _25935);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50507)){
                    _25937 = SEQ_PTR(_val_50507)->length;
            }
            else {
                _25937 = 1;
            }
            {
                object _i_50513;
                _i_50513 = 1;
L3: 
                if (_i_50513 > _25937){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50507);
                _25938 = (object)*(((s1_ptr)_2)->base + _i_50513);
                Ref(_25938);
                _46add_include_directory(_25938);
                _25938 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50513 = _i_50513 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_27OpDefines_20645) && IS_ATOM(_val_50507)) {
                Ref(_val_50507);
                Append(&_27OpDefines_20645, _27OpDefines_20645, _val_50507);
            }
            else if (IS_ATOM(_27OpDefines_20645) && IS_SEQUENCE(_val_50507)) {
            }
            else {
                Concat((object_ptr)&_27OpDefines_20645, _27OpDefines_20645, _val_50507);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _27batch_job_20584 = 1;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _27test_only_20583 = 1;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _27Strict_is_on_20637 = 1;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50507)){
                    _25940 = SEQ_PTR(_val_50507)->length;
            }
            else {
                _25940 = 1;
            }
            {
                object _i_50528;
                _i_50528 = 1;
L6: 
                if (_i_50528 > _25940){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50507);
                _25941 = (object)*(((s1_ptr)_2)->base + _i_50528);
                Ref(_25941);
                _63add_preprocessor(_25941, 0, 0);
                _25941 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50528 = _i_50528 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _28force_preprocessor_11591 = 1;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50507)){
                    _25942 = SEQ_PTR(_val_50507)->length;
            }
            else {
                _25942 = 1;
            }
            {
                object _i_50536;
                _i_50536 = 1;
L8: 
                if (_i_50536 > _25942){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50507);
                _25943 = (object)*(((s1_ptr)_2)->base + _i_50536);
                Ref(_25943);
                _25944 = _12lower(_25943);
                _25943 = NOVALUE;
                RefDS(_22209);
                RefDS(_5);
                _25945 = _24filter(_25944, _24STDFLTR_ALPHA_7031, _22209, _5);
                _25944 = NOVALUE;
                Ref(_25945);
                Append(&_28LocalizeQual_11592, _28LocalizeQual_11592, _25945);
                DeRef(_25945);
                _25945 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50536 = _i_50536 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50507);
            DeRef(_28LocalDB_11593);
            _28LocalDB_11593 = _val_50507;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50507)){
                    _25947 = SEQ_PTR(_val_50507)->length;
            }
            else {
                _25947 = 1;
            }
            {
                object _i_50551;
                _i_50551 = 1;
LA: 
                if (_i_50551 > _25947){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50553);
                _2 = (object)SEQ_PTR(_val_50507);
                _this_warn_50553 = (object)*(((s1_ptr)_2)->base + _i_50551);
                Ref(_this_warn_50553);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50555 = 0;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50553);
                _25949 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25949, 43)){
                    _25949 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25949 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50555 = 1;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50553)){
                        _25951 = SEQ_PTR(_this_warn_50553)->length;
                }
                else {
                    _25951 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50553;
                RHS_Slice(_this_warn_50553, 2, _25951);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50561 = find_from(_this_warn_50553, _27warning_names_20616, 1);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50561 == 0)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50555 != 0) {
                    goto LE; // [325] 338
                }
                _25956 = (_option_w_50501 == 1);
                if (_25956 == 0)
                {
                    DeRef(_25956);
                    _25956 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25956);
                    _25956 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _25957 = (object)*(((s1_ptr)_2)->base + _n_50561);
                {uintptr_t tu;
                     tu = (uintptr_t)_27OpWarning_20639 | (uintptr_t)_25957;
                     _27OpWarning_20639 = MAKE_UINT(tu);
                }
                _25957 = NOVALUE;
                if (!IS_ATOM_INT(_27OpWarning_20639)) {
                    _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
                    DeRefDS(_27OpWarning_20639);
                    _27OpWarning_20639 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50501 = 1;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _27OpWarning_20639 = (object)*(((s1_ptr)_2)->base + _n_50561);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _27prev_OpWarning_20640 = _27OpWarning_20639;
LD: 
                DeRef(_this_warn_50553);
                _this_warn_50553 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50551 = _i_50551 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50507)){
                    _25960 = SEQ_PTR(_val_50507)->length;
            }
            else {
                _25960 = 1;
            }
            {
                object _i_50582;
                _i_50582 = 1;
L11: 
                if (_i_50582 > _25960){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50584);
                _2 = (object)SEQ_PTR(_val_50507);
                _this_warn_50584 = (object)*(((s1_ptr)_2)->base + _i_50582);
                Ref(_this_warn_50584);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50586 = 0;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50584);
                _25962 = (object)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25962, 43)){
                    _25962 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25962 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50586 = 1;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50584)){
                        _25964 = SEQ_PTR(_this_warn_50584)->length;
                }
                else {
                    _25964 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50584;
                RHS_Slice(_this_warn_50584, 2, _25964);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50592 = find_from(_this_warn_50584, _27warning_names_20616, 1);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50592 == 0)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50586 != 0) {
                    goto L15; // [466] 479
                }
                _25969 = (_option_w_50501 == -1);
                if (_25969 == 0)
                {
                    DeRef(_25969);
                    _25969 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25969);
                    _25969 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _25970 = (object)*(((s1_ptr)_2)->base + _n_50592);
                _25971 = not_bits(_25970);
                _25970 = NOVALUE;
                if (IS_ATOM_INT(_25971)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_27OpWarning_20639 & (uintptr_t)_25971;
                         _27OpWarning_20639 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_27OpWarning_20639;
                    _27OpWarning_20639 = Dand_bits(&temp_d, DBL_PTR(_25971));
                }
                DeRef(_25971);
                _25971 = NOVALUE;
                if (!IS_ATOM_INT(_27OpWarning_20639)) {
                    _1 = (object)(DBL_PTR(_27OpWarning_20639)->dbl);
                    DeRefDS(_27OpWarning_20639);
                    _27OpWarning_20639 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50501 = -1;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_27warning_flags_20614);
                _25973 = (object)*(((s1_ptr)_2)->base + _n_50592);
                _27OpWarning_20639 = 32767 - _25973;
                _25973 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _27prev_OpWarning_20640 = _27OpWarning_20639;
L14: 
                DeRef(_this_warn_50584);
                _this_warn_50584 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50582 = _i_50582 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50507);
            DeRef(_27TempWarningName_20585);
            _27TempWarningName_20585 = _val_50507;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_27TempWarningName_20585);
            _5warning_file(_27TempWarningName_20585);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _47show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25975 = (_27batch_job_20584 == 0);
            if (_25975 == 0) {
                goto L18; // [579] 634
            }
            _25977 = (_27test_only_20583 == 0);
            if (_25977 == 0)
            {
                DeRef(_25977);
                _25977 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25977);
                _25977 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22209);
            _25978 = _30GetMsgText(278, 0, _22209);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50628);
            _prompt_inlined_maybe_any_key_at_617_50628 = _25978;
            _25978 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50628);
            _38any_key(_prompt_inlined_maybe_any_key_at_617_50628, 2);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50628);
            _prompt_inlined_maybe_any_key_at_617_50628 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50629 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _47show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25979 = (_27batch_job_20584 == 0);
            if (_25979 == 0) {
                goto L1A; // [655] 710
            }
            _25981 = (_27test_only_20583 == 0);
            if (_25981 == 0)
            {
                DeRef(_25981);
                _25981 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25981);
                _25981 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22209);
            _25982 = _30GetMsgText(278, 0, _22209);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50641);
            _prompt_inlined_maybe_any_key_at_693_50641 = _25982;
            _25982 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50641);
            _38any_key(_prompt_inlined_maybe_any_key_at_693_50641, 2);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50641);
            _prompt_inlined_maybe_any_key_at_693_50641 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50642 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50507);
            _28set_eudir(_val_50507);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50507);
            _0 = _val_50507;
            _val_50507 = _17value(_val_50507, 1, _17GET_SHORT_ANSWER_4103);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50507);
            _25984 = (object)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _25984, 0)){
                _25984 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25984 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50507);
            _25986 = (object)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_25986))
            _27trace_lines_64988 = e_floor(_25986);
            else
            _27trace_lines_64988 = unary_op(FLOOR, _25986);
            _25986 = NOVALUE;
            if (!IS_ATOM_INT(_27trace_lines_64988)) {
                _1 = (object)(DBL_PTR(_27trace_lines_64988)->dbl);
                DeRefDS(_27trace_lines_64988);
                _27trace_lines_64988 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_22209);
            _25988 = _30GetMsgText(604, 1, _22209);
            EPuts(2, _25988); // DJP 
            DeRef(_25988);
            _25988 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1);
L1D: 
        ;}L5: 
        DeRef(_key_50505);
        _key_50505 = NOVALUE;
        DeRef(_val_50507);
        _val_50507 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50503 = _idx_50503 + 1;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_28LocalizeQual_11592)){
            _25989 = SEQ_PTR(_28LocalizeQual_11592)->length;
    }
    else {
        _25989 = 1;
    }
    if (_25989 != 0)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _28LocalizeQual_11592;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25991);
    ((intptr_t*)_2)[1] = _25991;
    _28LocalizeQual_11592 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50498);
    DeRef(_opt_keys_50499);
    DeRef(_25979);
    _25979 = NOVALUE;
    DeRef(_25975);
    _25975 = NOVALUE;
    return;
    ;
}


void _47finalize_command_line(object _opts_50668)
{
    object _extras_50675 = NOVALUE;
    object _pairs_50680 = NOVALUE;
    object _pair_50685 = NOVALUE;
    object _26021 = NOVALUE;
    object _26019 = NOVALUE;
    object _26016 = NOVALUE;
    object _26015 = NOVALUE;
    object _26014 = NOVALUE;
    object _26013 = NOVALUE;
    object _26012 = NOVALUE;
    object _26011 = NOVALUE;
    object _26010 = NOVALUE;
    object _26009 = NOVALUE;
    object _26008 = NOVALUE;
    object _26007 = NOVALUE;
    object _26006 = NOVALUE;
    object _26005 = NOVALUE;
    object _26004 = NOVALUE;
    object _26003 = NOVALUE;
    object _26002 = NOVALUE;
    object _26001 = NOVALUE;
    object _26000 = NOVALUE;
    object _25999 = NOVALUE;
    object _25997 = NOVALUE;
    object _25994 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_27Strict_is_on_20637 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _27OpWarning_20639 = 32767;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _27prev_OpWarning_20640 = 32767;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50668);
    RefDS(_48EXTRAS_20984);
    _0 = _extras_50675;
    _extras_50675 = _34get(_opts_50668, _48EXTRAS_20984, 0);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50675)){
            _25994 = SEQ_PTR(_extras_50675)->length;
    }
    else {
        _25994 = 1;
    }
    if (_25994 <= 0)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50668);
    _0 = _pairs_50680;
    _pairs_50680 = _34pairs(_opts_50668, 0);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50680)){
            _25997 = SEQ_PTR(_pairs_50680)->length;
    }
    else {
        _25997 = 1;
    }
    {
        object _i_50683;
        _i_50683 = 1;
L3: 
        if (_i_50683 > _25997){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50685);
        _2 = (object)SEQ_PTR(_pairs_50680);
        _pair_50685 = (object)*(((s1_ptr)_2)->base + _i_50683);
        Ref(_pair_50685);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50685);
        _25999 = (object)*(((s1_ptr)_2)->base + 1);
        if (_25999 == _48EXTRAS_20984)
        _26000 = 1;
        else if (IS_ATOM_INT(_25999) && IS_ATOM_INT(_48EXTRAS_20984))
        _26000 = 0;
        else
        _26000 = (compare(_25999, _48EXTRAS_20984) == 0);
        _25999 = NOVALUE;
        if (_26000 == 0)
        {
            _26000 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _26000 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50685);
        _pair_50685 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50685);
        _26001 = (object)*(((s1_ptr)_2)->base + 1);
        Prepend(&_26002, _26001, 45);
        _26001 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50685);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50685 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26002;
        if( _1 != _26002 ){
            DeRef(_1);
        }
        _26002 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50685);
        _26003 = (object)*(((s1_ptr)_2)->base + 2);
        _26004 = IS_SEQUENCE(_26003);
        _26003 = NOVALUE;
        if (_26004 == 0)
        {
            _26004 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _26004 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50685);
        _26005 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_26005)){
                _26006 = SEQ_PTR(_26005)->length;
        }
        else {
            _26006 = 1;
        }
        _26005 = NOVALUE;
        if (_26006 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50685);
        _26008 = (object)*(((s1_ptr)_2)->base + 2);
        _2 = (object)SEQ_PTR(_26008);
        _26009 = (object)*(((s1_ptr)_2)->base + 1);
        _26008 = NOVALUE;
        _26010 = IS_SEQUENCE(_26009);
        _26009 = NOVALUE;
        if (_26010 == 0)
        {
            _26010 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _26010 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50685);
        _26011 = (object)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_26011)){
                _26012 = SEQ_PTR(_26011)->length;
        }
        else {
            _26012 = 1;
        }
        _26011 = NOVALUE;
        {
            object _j_50703;
            _j_50703 = 1;
L9: 
            if (_j_50703 > _26012){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50685);
            _26013 = (object)*(((s1_ptr)_2)->base + 1);
            _2 = (object)SEQ_PTR(_pair_50685);
            _26014 = (object)*(((s1_ptr)_2)->base + 2);
            _2 = (object)SEQ_PTR(_26014);
            _26015 = (object)*(((s1_ptr)_2)->base + _j_50703);
            _26014 = NOVALUE;
            Ref(_26015);
            Ref(_26013);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _26013;
            ((intptr_t *)_2)[2] = _26015;
            _26016 = MAKE_SEQ(_1);
            _26015 = NOVALUE;
            _26013 = NOVALUE;
            Concat((object_ptr)&_47switches_50001, _47switches_50001, _26016);
            DeRefDS(_26016);
            _26016 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50703 = _j_50703 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_47switches_50001, _47switches_50001, _pair_50685);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50685);
        _26019 = (object)*(((s1_ptr)_2)->base + 1);
        Ref(_26019);
        Append(&_47switches_50001, _47switches_50001, _26019);
        _26019 = NOVALUE;
LB: 
        DeRef(_pair_50685);
        _pair_50685 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50683 = _i_50683 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_26021;
    RHS_Slice(_27Argv_20582, 2, 3);
    Concat((object_ptr)&_27Argv_20582, _26021, _extras_50675);
    DeRefDS(_26021);
    _26021 = NOVALUE;
    DeRef(_26021);
    _26021 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_27Argv_20582)){
            _27Argc_20581 = SEQ_PTR(_27Argv_20582)->length;
    }
    else {
        _27Argc_20581 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_47src_name_50000);
    _2 = (object)SEQ_PTR(_extras_50675);
    _47src_name_50000 = (object)*(((s1_ptr)_2)->base + 1);
    Ref(_47src_name_50000);
L2: 
    DeRef(_pairs_50680);
    _pairs_50680 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50668);
    DeRef(_extras_50675);
    _26005 = NOVALUE;
    _26011 = NOVALUE;
    return;
    ;
}



// 0x00C2F04F
