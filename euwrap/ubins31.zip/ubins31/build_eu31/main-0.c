// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

main0()
{
    int _743 = 0;
    int _741 = 0;
    int _745 = 0;
    int _747 = 0;
    int _749 = 0;
    int _751 = 0;
    int _753 = 0;
    int _755 = 0;
    int _757 = 0;
    int _759 = 0;
    int _761 = 0;
    int _763 = 0;
    int _765 = 0;
    int _767 = 0;
    int _769 = 0;
    int _771 = 0;
    int _773 = 0;
    int _775 = 0;
    int _777 = 0;
    int _779 = 0;
    int _781 = 0;
    int _783 = 0;
    int _785 = 0;
    int _787 = 0;
    int _789 = 0;
    int _791 = 0;
    int _793 = 0;
    int _795 = 0;
    int _797 = 0;
    int _799 = 0;
    int _801 = 0;
    int _803 = 0;
    int _805 = 0;
    int _807 = 0;
    int _809 = 0;
    int _811 = 0;
    int _813 = 0;
    int _815 = 0;
    int _817 = 0;
    int _819 = 0;
    int _821 = 0;
    int _823 = 0;
    int _825 = 0;
    int _827 = 0;
    int _829 = 0;
    int _831 = 0;
    int _833 = 0;
    int _835 = 0;
    int _837 = 0;
    int _839 = 0;
    int _841 = 0;
    int _843 = 0;
    int _845 = 0;
    int _847 = 0;
    int _849 = 0;
    int _851 = 0;
    int _853 = 0;
    int _855 = 0;
    int _857 = 0;
    int _739 = 0;
    int _737 = 0;
    int _735 = 0;
    int _733 = 0;
    int _731 = 0;
    int _729 = 0;
    int _727 = 0;
    int _725 = 0;
    int _723 = 0;
    int _721 = 0;
    int _719 = 0;
    int _717 = 0;
    int _715 = 0;
    int _713 = 0;
    int _711 = 0;
    int _709 = 0;
    int _707 = 0;
    int _705 = 0;
    int _703 = 0;
    int _701 = 0;
    int _699 = 0;
    int _697 = 0;
    int _695 = 0;
    int _693 = 0;
    int _691 = 0;
    int _689 = 0;
    int _687 = 0;
    int _685 = 0;
    int _683 = 0;
    int _681 = 0;
    int _679 = 0;
    int _677 = 0;
    int _675 = 0;
    int _673 = 0;
    int _671 = 0;
    int _669 = 0;
    int _667 = 0;
    int _665 = 0;
    int _663 = 0;
    int _152 = 0;
    int _0, _1, _2, _3;
    
    

    // op_result = repeat(T_UNKNOWN, MAX_OPCODE)
    DeRef1(_14op_result);
    _14op_result = Repeat(5, 179);

    // op_result[RIGHT_BRACE_N] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 31);
    *(int *)_2 = 3;

    // op_result[RIGHT_BRACE_2] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 85);
    *(int *)_2 = 3;

    // op_result[REPEAT] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = 3;

    // op_result[APPEND] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 35);
    *(int *)_2 = 3;

    // op_result[RHS_SLICE] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 46);
    *(int *)_2 = 3;

    // op_result[CONCAT] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 15);
    *(int *)_2 = 3;

    // op_result[CONCAT_N] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 159);
    *(int *)_2 = 3;

    // op_result[PREPEND] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 57);
    *(int *)_2 = 3;

    // op_result[COMMAND_LINE] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 100);
    *(int *)_2 = 3;

    // op_result[SPRINTF] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 53);
    *(int *)_2 = 3;

    // op_result[ROUTINE_ID] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 136);
    *(int *)_2 = 1;

    // op_result[GETC] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 33);
    *(int *)_2 = 1;

    // op_result[OPEN] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 37);
    *(int *)_2 = 1;

    // op_result[LENGTH] = T_INTEGER   -- assume less than a billion
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 42);
    *(int *)_2 = 1;

    // op_result[PLENGTH] = T_INTEGER  -- ""
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 162);
    *(int *)_2 = 1;

    // op_result[IS_AN_OBJECT] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = 1;

    // op_result[IS_AN_ATOM] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 67);
    *(int *)_2 = 1;

    // op_result[IS_A_SEQUENCE] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 68);
    *(int *)_2 = 1;

    // op_result[COMPARE] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 76);
    *(int *)_2 = 1;

    // op_result[EQUAL] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 155);
    *(int *)_2 = 1;

    // op_result[FIND] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 77);
    *(int *)_2 = 1;

    // op_result[FIND_FROM] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 178);
    *(int *)_2 = 1;

    // op_result[MATCH]  = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 78);
    *(int *)_2 = 1;

    // op_result[MATCH_FROM]  = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 179);
    *(int *)_2 = 1;

    // op_result[GET_KEY] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 79);
    *(int *)_2 = 1;

    // op_result[IS_AN_INTEGER] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 94);
    *(int *)_2 = 1;

    // op_result[ASSIGN_I] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 113);
    *(int *)_2 = 1;

    // op_result[RHS_SUBS_I] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 114);
    *(int *)_2 = 1;

    // op_result[PLUS_I] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 115);
    *(int *)_2 = 1;

    // op_result[MINUS_I] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 116);
    *(int *)_2 = 1;

    // op_result[PLUS1_I] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 117);
    *(int *)_2 = 1;

    // op_result[SYSTEM_EXEC] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 156);
    *(int *)_2 = 1;

    // op_result[TIME] = T_ATOM
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 70);
    *(int *)_2 = 4;

    // op_result[TASK_STATUS] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 175);
    *(int *)_2 = 1;

    // op_result[TASK_SELF] = T_ATOM
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 172);
    *(int *)_2 = 4;

    // op_result[TASK_CREATE] = T_ATOM
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 169);
    *(int *)_2 = 4;

    // op_result[TASK_LIST] = T_SEQUENCE
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 174);
    *(int *)_2 = 3;

    // op_result[PLATFORM] = T_INTEGER
    _2 = (int)SEQ_PTR(_14op_result);
    _2 = (int)(((s1_ptr)_2)->base + 157);
    *(int *)_2 = 1;

    // sample_size = 0
    _15sample_size = 0;

    // max_stack_per_call = 1
    _15max_stack_per_call = 1;

    // branch_list = {}
    RefDS(_39);
    DeRef1(_15branch_list);
    _15branch_list = _39;

    // short_circuit = 0
    _15short_circuit = 0;

    // short_circuit_B = FALSE   -- circuit expression? given short_circuit is TRUE.
    _15short_circuit_B = 0;

    // side_effect_calls = 0     -- on local/global variables
    _15side_effect_calls = 0;

    // factors = 0
    _15factors = 0;

    // lhs_subs_level = -1
    _15lhs_subs_level = -1;

    // left_sym = 0
    _15left_sym = 0;

    // forward_expr = routine_id("Expr")
    _15forward_expr = CRoutineId(181, 15, _3313);

    // forward_Statement_list = routine_id("Statement_list")
    _15forward_Statement_list = CRoutineId(195, 15, _3698);

    // mix_msg = "can't mix profile and profile_time"
    RefDS(_3842);
    DeRef1(_15mix_msg);
    _15mix_msg = _3842;
    _1 = NewS1(179);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3961);
    *((int *)(_2+4)) = _3961;
    RefDS(_3962);
    *((int *)(_2+8)) = _3962;
    RefDS(_3963);
    *((int *)(_2+12)) = _3963;
    RefDS(_3964);
    *((int *)(_2+16)) = _3964;
    RefDS(_3965);
    *((int *)(_2+20)) = _3965;
    RefDS(_3966);
    *((int *)(_2+24)) = _3966;
    RefDS(_3967);
    *((int *)(_2+28)) = _3967;
    RefDS(_3968);
    *((int *)(_2+32)) = _3968;
    RefDS(_3969);
    *((int *)(_2+36)) = _3969;
    RefDS(_3970);
    *((int *)(_2+40)) = _3970;
    RefDS(_3971);
    *((int *)(_2+44)) = _3971;
    RefDS(_3972);
    *((int *)(_2+48)) = _3972;
    RefDS(_3973);
    *((int *)(_2+52)) = _3973;
    RefDS(_3974);
    *((int *)(_2+56)) = _3974;
    RefDS(_3975);
    *((int *)(_2+60)) = _3975;
    RefDS(_3976);
    *((int *)(_2+64)) = _3976;
    RefDS(_3977);
    *((int *)(_2+68)) = _3977;
    RefDS(_3978);
    *((int *)(_2+72)) = _3978;
    RefDS(_3979);
    *((int *)(_2+76)) = _3979;
    RefDS(_3980);
    *((int *)(_2+80)) = _3980;
    RefDS(_3981);
    *((int *)(_2+84)) = _3981;
    RefDS(_3982);
    *((int *)(_2+88)) = _3982;
    RefDS(_3983);
    *((int *)(_2+92)) = _3983;
    RefDS(_3984);
    *((int *)(_2+96)) = _3984;
    RefDS(_3985);
    *((int *)(_2+100)) = _3985;
    RefDS(_3986);
    *((int *)(_2+104)) = _3986;
    RefDS(_3987);
    *((int *)(_2+108)) = _3987;
    RefDS(_3988);
    *((int *)(_2+112)) = _3988;
    RefDS(_3989);
    *((int *)(_2+116)) = _3989;
    RefDS(_3990);
    *((int *)(_2+120)) = _3990;
    RefDS(_3991);
    *((int *)(_2+124)) = _3991;
    RefDS(_3992);
    *((int *)(_2+128)) = _3992;
    RefDS(_3993);
    *((int *)(_2+132)) = _3993;
    RefDS(_3994);
    *((int *)(_2+136)) = _3994;
    RefDS(_3995);
    *((int *)(_2+140)) = _3995;
    RefDS(_3996);
    *((int *)(_2+144)) = _3996;
    RefDS(_3997);
    *((int *)(_2+148)) = _3997;
    RefDS(_3998);
    *((int *)(_2+152)) = _3998;
    RefDS(_3999);
    *((int *)(_2+156)) = _3999;
    RefDS(_4000);
    *((int *)(_2+160)) = _4000;
    RefDS(_4001);
    *((int *)(_2+164)) = _4001;
    RefDS(_4002);
    *((int *)(_2+168)) = _4002;
    RefDS(_4003);
    *((int *)(_2+172)) = _4003;
    RefDS(_4004);
    *((int *)(_2+176)) = _4004;
    RefDS(_4005);
    *((int *)(_2+180)) = _4005;
    RefDS(_4006);
    *((int *)(_2+184)) = _4006;
    RefDS(_4007);
    *((int *)(_2+188)) = _4007;
    RefDS(_4008);
    *((int *)(_2+192)) = _4008;
    RefDS(_4009);
    *((int *)(_2+196)) = _4009;
    RefDS(_4010);
    *((int *)(_2+200)) = _4010;
    RefDS(_4011);
    *((int *)(_2+204)) = _4011;
    RefDS(_4012);
    *((int *)(_2+208)) = _4012;
    RefDS(_4013);
    *((int *)(_2+212)) = _4013;
    RefDS(_4014);
    *((int *)(_2+216)) = _4014;
    RefDS(_4015);
    *((int *)(_2+220)) = _4015;
    RefDS(_4016);
    *((int *)(_2+224)) = _4016;
    RefDS(_4017);
    *((int *)(_2+228)) = _4017;
    RefDS(_4018);
    *((int *)(_2+232)) = _4018;
    RefDS(_4019);
    *((int *)(_2+236)) = _4019;
    RefDS(_4020);
    *((int *)(_2+240)) = _4020;
    RefDS(_4021);
    *((int *)(_2+244)) = _4021;
    RefDS(_4022);
    *((int *)(_2+248)) = _4022;
    RefDS(_4023);
    *((int *)(_2+252)) = _4023;
    RefDS(_4024);
    *((int *)(_2+256)) = _4024;
    RefDS(_4025);
    *((int *)(_2+260)) = _4025;
    RefDS(_4026);
    *((int *)(_2+264)) = _4026;
    RefDS(_4027);
    *((int *)(_2+268)) = _4027;
    RefDS(_4028);
    *((int *)(_2+272)) = _4028;
    RefDS(_4029);
    *((int *)(_2+276)) = _4029;
    RefDS(_4030);
    *((int *)(_2+280)) = _4030;
    RefDS(_4031);
    *((int *)(_2+284)) = _4031;
    RefDS(_4032);
    *((int *)(_2+288)) = _4032;
    RefDS(_4033);
    *((int *)(_2+292)) = _4033;
    RefDS(_4034);
    *((int *)(_2+296)) = _4034;
    RefDS(_4035);
    *((int *)(_2+300)) = _4035;
    RefDS(_4036);
    *((int *)(_2+304)) = _4036;
    RefDS(_4037);
    *((int *)(_2+308)) = _4037;
    RefDS(_4038);
    *((int *)(_2+312)) = _4038;
    RefDS(_4039);
    *((int *)(_2+316)) = _4039;
    RefDS(_4040);
    *((int *)(_2+320)) = _4040;
    RefDS(_4041);
    *((int *)(_2+324)) = _4041;
    RefDS(_4042);
    *((int *)(_2+328)) = _4042;
    RefDS(_4043);
    *((int *)(_2+332)) = _4043;
    RefDS(_4044);
    *((int *)(_2+336)) = _4044;
    RefDS(_4045);
    *((int *)(_2+340)) = _4045;
    RefDS(_4046);
    *((int *)(_2+344)) = _4046;
    RefDS(_4047);
    *((int *)(_2+348)) = _4047;
    RefDS(_4048);
    *((int *)(_2+352)) = _4048;
    RefDS(_4049);
    *((int *)(_2+356)) = _4049;
    RefDS(_4050);
    *((int *)(_2+360)) = _4050;
    RefDS(_4051);
    *((int *)(_2+364)) = _4051;
    RefDS(_4052);
    *((int *)(_2+368)) = _4052;
    RefDS(_4053);
    *((int *)(_2+372)) = _4053;
    RefDS(_4054);
    *((int *)(_2+376)) = _4054;
    RefDS(_4055);
    *((int *)(_2+380)) = _4055;
    RefDS(_4056);
    *((int *)(_2+384)) = _4056;
    RefDS(_4057);
    *((int *)(_2+388)) = _4057;
    RefDS(_4058);
    *((int *)(_2+392)) = _4058;
    RefDS(_4059);
    *((int *)(_2+396)) = _4059;
    RefDS(_4060);
    *((int *)(_2+400)) = _4060;
    RefDS(_4061);
    *((int *)(_2+404)) = _4061;
    RefDS(_4062);
    *((int *)(_2+408)) = _4062;
    RefDS(_4063);
    *((int *)(_2+412)) = _4063;
    RefDS(_4064);
    *((int *)(_2+416)) = _4064;
    RefDS(_4065);
    *((int *)(_2+420)) = _4065;
    RefDS(_4066);
    *((int *)(_2+424)) = _4066;
    RefDS(_4067);
    *((int *)(_2+428)) = _4067;
    RefDS(_4068);
    *((int *)(_2+432)) = _4068;
    RefDS(_4069);
    *((int *)(_2+436)) = _4069;
    RefDS(_4070);
    *((int *)(_2+440)) = _4070;
    RefDS(_4071);
    *((int *)(_2+444)) = _4071;
    RefDS(_4072);
    *((int *)(_2+448)) = _4072;
    RefDS(_4073);
    *((int *)(_2+452)) = _4073;
    RefDS(_4074);
    *((int *)(_2+456)) = _4074;
    RefDS(_4075);
    *((int *)(_2+460)) = _4075;
    RefDS(_4076);
    *((int *)(_2+464)) = _4076;
    RefDS(_4077);
    *((int *)(_2+468)) = _4077;
    RefDS(_4078);
    *((int *)(_2+472)) = _4078;
    RefDS(_4079);
    *((int *)(_2+476)) = _4079;
    RefDS(_4080);
    *((int *)(_2+480)) = _4080;
    RefDS(_4081);
    *((int *)(_2+484)) = _4081;
    RefDS(_4082);
    *((int *)(_2+488)) = _4082;
    RefDS(_4083);
    *((int *)(_2+492)) = _4083;
    RefDS(_4084);
    *((int *)(_2+496)) = _4084;
    RefDS(_4085);
    *((int *)(_2+500)) = _4085;
    RefDS(_4086);
    *((int *)(_2+504)) = _4086;
    RefDS(_4087);
    *((int *)(_2+508)) = _4087;
    RefDS(_4088);
    *((int *)(_2+512)) = _4088;
    RefDS(_4089);
    *((int *)(_2+516)) = _4089;
    RefDS(_4090);
    *((int *)(_2+520)) = _4090;
    RefDS(_4091);
    *((int *)(_2+524)) = _4091;
    RefDS(_4092);
    *((int *)(_2+528)) = _4092;
    RefDS(_4093);
    *((int *)(_2+532)) = _4093;
    RefDS(_4094);
    *((int *)(_2+536)) = _4094;
    RefDS(_4095);
    *((int *)(_2+540)) = _4095;
    RefDS(_4096);
    *((int *)(_2+544)) = _4096;
    RefDS(_4097);
    *((int *)(_2+548)) = _4097;
    RefDS(_4098);
    *((int *)(_2+552)) = _4098;
    RefDS(_4099);
    *((int *)(_2+556)) = _4099;
    RefDS(_4100);
    *((int *)(_2+560)) = _4100;
    RefDS(_4101);
    *((int *)(_2+564)) = _4101;
    RefDS(_4102);
    *((int *)(_2+568)) = _4102;
    RefDS(_4103);
    *((int *)(_2+572)) = _4103;
    RefDS(_4104);
    *((int *)(_2+576)) = _4104;
    RefDS(_4105);
    *((int *)(_2+580)) = _4105;
    RefDS(_4106);
    *((int *)(_2+584)) = _4106;
    RefDS(_4107);
    *((int *)(_2+588)) = _4107;
    RefDS(_4108);
    *((int *)(_2+592)) = _4108;
    RefDS(_4109);
    *((int *)(_2+596)) = _4109;
    RefDS(_4110);
    *((int *)(_2+600)) = _4110;
    RefDS(_4111);
    *((int *)(_2+604)) = _4111;
    RefDS(_4112);
    *((int *)(_2+608)) = _4112;
    RefDS(_4113);
    *((int *)(_2+612)) = _4113;
    RefDS(_4114);
    *((int *)(_2+616)) = _4114;
    RefDS(_4115);
    *((int *)(_2+620)) = _4115;
    RefDS(_4116);
    *((int *)(_2+624)) = _4116;
    RefDS(_4117);
    *((int *)(_2+628)) = _4117;
    RefDS(_4118);
    *((int *)(_2+632)) = _4118;
    RefDS(_4119);
    *((int *)(_2+636)) = _4119;
    RefDS(_4120);
    *((int *)(_2+640)) = _4120;
    RefDS(_4121);
    *((int *)(_2+644)) = _4121;
    RefDS(_4122);
    *((int *)(_2+648)) = _4122;
    RefDS(_4123);
    *((int *)(_2+652)) = _4123;
    RefDS(_4124);
    *((int *)(_2+656)) = _4124;
    RefDS(_4125);
    *((int *)(_2+660)) = _4125;
    RefDS(_4126);
    *((int *)(_2+664)) = _4126;
    RefDS(_4127);
    *((int *)(_2+668)) = _4127;
    RefDS(_4128);
    *((int *)(_2+672)) = _4128;
    RefDS(_4129);
    *((int *)(_2+676)) = _4129;
    RefDS(_4130);
    *((int *)(_2+680)) = _4130;
    RefDS(_4131);
    *((int *)(_2+684)) = _4131;
    RefDS(_4132);
    *((int *)(_2+688)) = _4132;
    RefDS(_4133);
    *((int *)(_2+692)) = _4133;
    RefDS(_4134);
    *((int *)(_2+696)) = _4134;
    RefDS(_4135);
    *((int *)(_2+700)) = _4135;
    RefDS(_4136);
    *((int *)(_2+704)) = _4136;
    RefDS(_4137);
    *((int *)(_2+708)) = _4137;
    RefDS(_4138);
    *((int *)(_2+712)) = _4138;
    RefDS(_4139);
    *((int *)(_2+716)) = _4139;
    _18opnames = MAKE_SEQ(_1);

    // crash_msg = 0
    DeRef1(_16crash_msg);
    _16crash_msg = 0;

    // crash_list = {}
    RefDS(_39);
    DeRef1(_16crash_list);
    _16crash_list = _39;

    // crash_count = 0
    _16crash_count = 0;

    // t_id = tmp_alloc()
    _0 = _10tmp_alloc();
    _16t_id = _0;

    // t_arglist = tmp_alloc()
    _0 = _10tmp_alloc();
    _16t_arglist = _0;

    // t_return_val = tmp_alloc()
    _0 = _10tmp_alloc();
    _16t_return_val = _0;

    // call_back_routine = NewEntry("_call_back_", 0, 0, PROC, 0, 0, 0)
    RefDS(_4144);
    _0 = _10NewEntry(_4144, 0, 0, 27, 0, 0, 0);
    _16call_back_routine = _0;

    // SymTab[call_back_routine] = SymTab[call_back_routine] & 
    _2 = (int)SEQ_PTR(_4SymTab);
    _741 = (int)*(((s1_ptr)_2)->base + _16call_back_routine);
    RefDS(_741);
    _2 = (int)SEQ_PTR(_4SymTab);
    _743 = (int)*(((s1_ptr)_2)->base + _16call_back_routine);
    RefDS(_743);
    _0 = _743;
    _743 = SEQ_PTR(_743)->length;
    DeRef1(_0);
    _743 = 25 - _743;
    _743 = Repeat(0, _743);
    Concat((object_ptr)&_743, _741, (s1_ptr)_743);
    RefDS(_743);
    _2 = (int)SEQ_PTR(_4SymTab);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _4SymTab = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _16call_back_routine);
    _1 = *(int *)_2;
    *(int *)_2 = _743;
    DeRefDS(_1);

    // SymTab[call_back_routine][S_SAVED_PRIVATES] = {}
    _2 = (int)SEQ_PTR(_4SymTab);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _4SymTab = MAKE_SEQ(_2);
    }
    _3 = (int)(_16call_back_routine + ((s1_ptr)_2)->base);
    RefDS(_39);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _39;
    DeRef(_1);

    // call_back_code = {CALL_FUNC,
    _0 = _16call_back_code;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 139;
    *((int *)(_2+8)) = _16t_id;
    *((int *)(_2+12)) = _16t_arglist;
    *((int *)(_2+16)) = _16t_return_val;
    *((int *)(_2+20)) = 137;
    _16call_back_code = MAKE_SEQ(_1);
    DeRef1(_0);

    // SymTab[call_back_routine][S_CODE] = call_back_code
    _2 = (int)SEQ_PTR(_4SymTab);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _4SymTab = MAKE_SEQ(_2);
    }
    _3 = (int)(_16call_back_routine + ((s1_ptr)_2)->base);
    RefDS(_16call_back_code);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _16call_back_code;
    DeRef(_1);

    // TraceOn = FALSE
    _16TraceOn = 0;
    RefDS(_4157);
    _16TASK_NEVER = _4157;
    RefDS(_4158);
    _16TASK_ID_MAX = _4158;

    // id_wrap = FALSE  
    _16id_wrap = 0;

    // next_task_id = 1
    DeRef1(_16next_task_id);
    _16next_task_id = 1;

    // if EDOS then
    if (_4EDOS == 0)
        goto LA;

    //     clock_period = 0.055  -- DOS default (can change)
    RefDS(_4159);
    DeRef1(_16clock_period);
    _16clock_period = _4159;
    goto LB;
LA:

    //     clock_period = 0.01   -- Windows/Linux/FreeBSD
    RefDS(_4160);
    DeRef1(_16clock_period);
    _16clock_period = _4160;
LB:

    // tcb = {
    _0 = _743;
    _1 = NewS1(16);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    *((int *)(_2+28)) = 0;
    *((int *)(_2+32)) = 1;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 1;
    *((int *)(_2+44)) = 1;
    *((int *)(_2+48)) = 0;
    RefDS(_39);
    *((int *)(_2+52)) = _39;
    *((int *)(_2+56)) = 1;
    RefDSn(_39, 2);
    *((int *)(_2+60)) = _39;
    *((int *)(_2+64)) = _39;
    _743 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _16tcb;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_743);
    *((int *)(_2+4)) = _743;
    _16tcb = MAKE_SEQ(_1);
    DeRef1(_0);

    // rt_first = 0 -- unsorted list of active rt tasks
    _16rt_first = 0;

    // ts_first = 1 -- unsorted list of active ts tasks (initialized to initial task)
    _16ts_first = 1;

    // e_routine = {}
    RefDS(_39);
    DeRef1(_16e_routine);
    _16e_routine = _39;

    // err_file_name = "ex.err" 
    RefDS(_4163);
    DeRef1(_16err_file_name);
    _16err_file_name = _4163;

    // clock_stopped = FALSE
    _16clock_stopped = 0;

    // save_clock = -1
    DeRef1(_16save_clock);
    _16save_clock = -1;

    // trace_file = -1
    _16trace_file = -1;

    // trace_line = 0
    _16trace_line = 0;

    // result = 0
    _16result = 0;

    // forward_general_callback = routine_id("general_callback")
    _16forward_general_callback = CRoutineId(381, 16, _6605);

    // call_backs = {}
    RefDS(_39);
    DeRef1(_16call_backs);
    _16call_backs = _39;
    _1 = NewS1(24);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 137;
    *((int *)(_2+8)) = 224;
    *((int *)(_2+12)) = 131;
    *((int *)(_2+16)) = 192;
    *((int *)(_2+20)) = 4;
    *((int *)(_2+24)) = 80;
    *((int *)(_2+28)) = 104;
    *((int *)(_2+32)) = 0;
    *((int *)(_2+36)) = 0;
    *((int *)(_2+40)) = 0;
    *((int *)(_2+44)) = 0;
    *((int *)(_2+48)) = 255;
    *((int *)(_2+52)) = 21;
    *((int *)(_2+56)) = 0;
    *((int *)(_2+60)) = 0;
    *((int *)(_2+64)) = 0;
    *((int *)(_2+68)) = 0;
    *((int *)(_2+72)) = 194;
    *((int *)(_2+76)) = 0;
    *((int *)(_2+80)) = 0;
    *((int *)(_2+84)) = 0;
    *((int *)(_2+88)) = 0;
    *((int *)(_2+92)) = 0;
    *((int *)(_2+96)) = 0;
    _16cb_std = MAKE_SEQ(_1);
    _1 = NewS1(27);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 137;
    *((int *)(_2+8)) = 224;
    *((int *)(_2+12)) = 131;
    *((int *)(_2+16)) = 192;
    *((int *)(_2+20)) = 4;
    *((int *)(_2+24)) = 80;
    *((int *)(_2+28)) = 104;
    *((int *)(_2+32)) = 0;
    *((int *)(_2+36)) = 0;
    *((int *)(_2+40)) = 0;
    *((int *)(_2+44)) = 0;
    *((int *)(_2+48)) = 255;
    *((int *)(_2+52)) = 21;
    *((int *)(_2+56)) = 0;
    *((int *)(_2+60)) = 0;
    *((int *)(_2+64)) = 0;
    *((int *)(_2+68)) = 0;
    *((int *)(_2+72)) = 131;
    *((int *)(_2+76)) = 196;
    *((int *)(_2+80)) = 8;
    *((int *)(_2+84)) = 195;
    *((int *)(_2+88)) = 0;
    *((int *)(_2+92)) = 0;
    *((int *)(_2+96)) = 0;
    *((int *)(_2+100)) = 0;
    *((int *)(_2+104)) = 0;
    *((int *)(_2+108)) = 0;
    _16cb_cdecl = MAKE_SEQ(_1);

    // Execute_id = routine_id("Execute")
    _4Execute_id = CRoutineId(388, 16, _6754);
    RefDS(_6756);
    _20DIGITS = _6756;
    Concat((object_ptr)&_20HEX_DIGITS, _20DIGITS, (s1_ptr)_6757);
    Concat((object_ptr)&_20START_NUMERIC, _20DIGITS, (s1_ptr)_6759);
    RefDS(_6774);
    _20ESCAPE_CHARS = _6774;
    RefDS(_6775);
    _20ESCAPED_CHARS = _6775;

    // main()
    _19main();
    Cleanup(0);
}
