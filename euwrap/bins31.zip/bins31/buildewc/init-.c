#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int _23;
int _25;
int _34;
int _39;
int _55;
int _57;
int _60;
int _70;
int _98;
int _113;
int _122;
int _150;
int _151;
int _161;
int _261;
int _268;
int _269;
int _270;
int _271;
int _274;
int _277;
int _320;
int _321;
int _599;
int _609;
int _621;
int _623;
int _628;
int _629;
int _634;
int _638;
int _639;
int _640;
int _643;
int _648;
int _651;
int _654;
int _660;
int _662;
int _664;
int _666;
int _668;
int _670;
int _672;
int _674;
int _676;
int _678;
int _680;
int _682;
int _684;
int _686;
int _688;
int _690;
int _692;
int _694;
int _696;
int _698;
int _700;
int _702;
int _704;
int _706;
int _708;
int _710;
int _712;
int _714;
int _716;
int _718;
int _720;
int _722;
int _724;
int _726;
int _728;
int _730;
int _732;
int _734;
int _736;
int _738;
int _740;
int _742;
int _744;
int _746;
int _748;
int _750;
int _752;
int _754;
int _756;
int _758;
int _760;
int _762;
int _764;
int _766;
int _768;
int _770;
int _772;
int _774;
int _776;
int _778;
int _780;
int _782;
int _784;
int _786;
int _788;
int _790;
int _792;
int _794;
int _796;
int _798;
int _800;
int _802;
int _804;
int _806;
int _808;
int _810;
int _812;
int _814;
int _816;
int _818;
int _820;
int _822;
int _824;
int _826;
int _828;
int _830;
int _832;
int _834;
int _836;
int _838;
int _840;
int _842;
int _844;
int _846;
int _848;
int _850;
int _852;
int _854;
int _856;
int _859;
int _862;
int _867;
int _868;
int _869;
int _870;
int _913;
int _930;
int _1015;
int _1021;
int _1030;
int _1073;
int _1076;
int _1376;
int _1377;
int _1383;
int _1384;
int _1394;
int _1396;
int _1399;
int _1404;
int _1444;
int _1517;
int _1518;
int _1565;
int _1648;
int _1653;
int _1669;
int _1672;
int _1682;
int _1696;
int _1731;
int _1734;
int _1763;
int _1767;
int _1804;
int _1807;
int _1808;
int _1815;
int _1864;
int _1913;
int _1954;
int _1964;
int _1977;
int _2017;
int _2025;
int _2057;
int _2058;
int _2098;
int _2101;
int _2130;
int _2133;
int _2153;
int _2158;
int _2172;
int _2181;
int _2188;
int _2224;
int _2227;
int _2228;
int _2229;
int _2231;
int _2233;
int _2235;
int _2237;
int _2239;
int _2241;
int _2243;
int _2245;
int _2247;
int _2249;
int _2251;
int _2253;
int _2255;
int _2257;
int _2259;
int _2261;
int _2263;
int _2265;
int _2267;
int _2269;
int _2271;
int _2273;
int _2275;
int _2277;
int _2279;
int _2281;
int _2283;
int _2285;
int _2287;
int _2289;
int _2291;
int _2293;
int _2295;
int _2297;
int _2299;
int _2301;
int _2303;
int _2305;
int _2307;
int _2309;
int _2313;
int _2315;
int _2317;
int _2319;
int _2321;
int _2323;
int _2325;
int _2327;
int _2329;
int _2332;
int _2335;
int _2337;
int _2339;
int _2341;
int _2381;
int _2549;
int _2693;
int _2723;
int _2735;
int _2740;
int _2798;
int _2808;
int _2899;
int _2903;
int _2932;
int _2938;
int _2939;
int _2996;
int _3108;
int _3114;
int _3122;
int _3139;
int _3140;
int _3163;
int _3198;
int _3226;
int _3243;
int _3313;
int _3353;
int _3357;
int _3398;
int _3437;
int _3445;
int _3519;
int _3521;
int _3529;
int _3538;
int _3544;
int _3594;
int _3644;
int _3674;
int _3698;
int _3710;
int _3715;
int _3771;
int _3778;
int _3793;
int _3796;
int _3806;
int _3831;
int _3832;
int _3842;
int _3844;
int _3850;
int _3868;
int _3871;
int _3879;
int _3908;
int _3923;
int _3926;
int _3934;
int _3935;
int _3961;
int _3962;
int _3963;
int _3964;
int _3965;
int _3966;
int _3967;
int _3968;
int _3969;
int _3970;
int _3971;
int _3972;
int _3973;
int _3974;
int _3975;
int _3976;
int _3977;
int _3978;
int _3979;
int _3980;
int _3981;
int _3982;
int _3983;
int _3984;
int _3985;
int _3986;
int _3987;
int _3988;
int _3989;
int _3990;
int _3991;
int _3992;
int _3993;
int _3994;
int _3995;
int _3996;
int _3997;
int _3998;
int _3999;
int _4000;
int _4001;
int _4002;
int _4003;
int _4004;
int _4005;
int _4006;
int _4007;
int _4008;
int _4009;
int _4010;
int _4011;
int _4012;
int _4013;
int _4014;
int _4015;
int _4016;
int _4017;
int _4018;
int _4019;
int _4020;
int _4021;
int _4022;
int _4023;
int _4024;
int _4025;
int _4026;
int _4027;
int _4028;
int _4029;
int _4030;
int _4031;
int _4032;
int _4033;
int _4034;
int _4035;
int _4036;
int _4037;
int _4038;
int _4039;
int _4040;
int _4041;
int _4042;
int _4043;
int _4044;
int _4045;
int _4046;
int _4047;
int _4048;
int _4049;
int _4050;
int _4051;
int _4052;
int _4053;
int _4054;
int _4055;
int _4056;
int _4057;
int _4058;
int _4059;
int _4060;
int _4061;
int _4062;
int _4063;
int _4064;
int _4065;
int _4066;
int _4067;
int _4068;
int _4069;
int _4070;
int _4071;
int _4072;
int _4073;
int _4074;
int _4075;
int _4076;
int _4077;
int _4078;
int _4079;
int _4080;
int _4081;
int _4082;
int _4083;
int _4084;
int _4085;
int _4086;
int _4087;
int _4088;
int _4089;
int _4090;
int _4091;
int _4092;
int _4093;
int _4094;
int _4095;
int _4096;
int _4097;
int _4098;
int _4099;
int _4100;
int _4101;
int _4102;
int _4103;
int _4104;
int _4105;
int _4106;
int _4107;
int _4108;
int _4109;
int _4110;
int _4111;
int _4112;
int _4113;
int _4114;
int _4115;
int _4116;
int _4117;
int _4118;
int _4119;
int _4120;
int _4121;
int _4122;
int _4123;
int _4124;
int _4125;
int _4126;
int _4127;
int _4128;
int _4129;
int _4130;
int _4131;
int _4132;
int _4133;
int _4134;
int _4135;
int _4136;
int _4137;
int _4138;
int _4139;
int _4144;
int _4157;
int _4158;
int _4159;
int _4160;
int _4163;
int _4166;
int _4194;
int _4198;
int _4307;
int _4314;
int _4333;
int _4336;
int _4337;
int _4338;
int _4339;
int _4340;
int _4349;
int _4353;
int _4357;
int _4358;
int _4416;
int _4418;
int _4431;
int _4438;
int _4440;
int _4446;
int _4455;
int _4460;
int _4476;
int _4641;
int _4714;
int _4721;
int _4753;
int _4772;
int _4778;
int _4784;
int _4788;
int _4796;
int _4835;
int _4837;
int _4840;
int _4841;
int _4844;
int _4854;
int _4865;
int _4867;
int _4960;
int _4973;
int _4975;
int _4981;
int _5059;
int _5073;
int _5090;
int _5139;
int _5141;
int _5149;
int _5154;
int _5157;
int _5159;
int _5162;
int _5164;
int _5168;
int _5177;
int _5180;
int _5189;
int _5194;
int _5243;
int _5655;
int _5668;
int _5795;
int _5850;
int _5853;
int _5856;
int _6051;
int _6058;
int _6064;
int _6070;
int _6208;
int _6211;
int _6214;
int _6265;
int _6279;
int _6283;
int _6287;
int _6302;
int _6329;
int _6334;
int _6338;
int _6341;
int _6434;
int _6437;
int _6467;
int _6470;
int _6556;
int _6605;
int _6628;
int _6646;
int _6672;
int _6746;
int _6751;
int _6754;
int _6756;
int _6757;
int _6759;
int _6772;
int _6774;
int _6775;
int _6890;
int _6901;
int _6932;
int _6968;
int _6969;
int _6971;
int _6973;
int _6975;
int _6976;
int _6977;
int _6978;
int _6979;
int _6980;
int _6981;
int _6982;
int _6983;
int _6984;
int _6985;
int _6990;
int _7012;
int _7013;
int _7014;
int _7047;
int _7050;
int _7053;
int _7054;
int _7056;
int _7057;
int _7062;
int _7068;

int _2pretty_end_col;
int _2pretty_chars;
int _2pretty_start_col;
int _2pretty_level;
int _2pretty_file;
int _2pretty_ascii;
int _2pretty_indent;
int _2pretty_ascii_min;
int _2pretty_ascii_max;
int _2pretty_line_count;
int _2pretty_line_max;
int _2pretty_dots;
int _2pretty_fp_format;
int _2pretty_int_format;
int _2pretty_line;
int _2PI;
int _2PI_HALF;
int _3TO_LOWER;
int _4INTERPRETER_VERSION;
int _4TRANSLATOR_VERSION;
int _4mybsd;
int _4ELINUX;
int _4EWINDOWS;
int _4EDOS;
int _4w32;
int _4version_name;
int _4PATH_SEPARATOR;
int _4SLASH;
int _4SLASH_CHARS;
int _4SIZEOF_ROUTINE_ENTRY;
int _4SIZEOF_VAR_ENTRY;
int _4SIZEOF_TEMP_ENTRY;
int _4E_OTHER_EFFECT;
int _4MININT;
int _4NOVALUE;
int _4SymTab;
int _4eudir;
int _4file_name;
int _4file_name_entered;
int _4shroud_only;
int _4current_file_no;
int _4line_number;
int _4gline_number;
int _4file_start_sym;
int _4TopLevelSub;
int _4CurrentSub;
int _4num_routines;
int _4Argc;
int _4Argv;
int _4OpWarning;
int _4OpTrace;
int _4OpTypeCheck;
int _4OpProfileStatement;
int _4OpProfileTime;
int _4dj_path;
int _4wat_path;
int _4bor_path;
int _4cfile_count;
int _4cfile_size;
int _4Initializing;
int _4temp_name_type;
int _4Execute_id;
int _4Code;
int _4LineTable;
int _4slist;
int _7MAX_ADDR;
int _7LOW_ADDR;
int _7mem;
int _7check_calls;
int _6Errors;
int _6TempErrFile;
int _6TempErrName;
int _6ThisLine;
int _6bp;
int _6warning_list;
int _8keylist;
int _9emit_c_output;
int _9c_code;
int _9c_h;
int _9main_name_num;
int _9init_name_num;
int _9novalue;
int _9target;
int _9CREATE_INF;
int _9CREATE_NAN1;
int _9CREATE_NAN2;
int _9indent;
int _9temp_indent;
int _10buckets;
int _10object_type;
int _10atom_type;
int _10sequence_type;
int _10integer_type;
int _10e_routine;
int _10literal_init;
int _10lastintval;
int _10lastintsym;
int _10last_sym;
int _10BLANK_ENTRY;
int _10SEARCH_LIMIT;
int _10temps_allocated;
int _10dup_globals;
int _12SLASH;
int _12my_dir;
int _11main_path;
int _11src_file;
int _11new_include_name;
int _11new_include_space;
int _11start_include;
int _11LastLineNumber;
int _11AnyStatementProfile;
int _11AnyTimeProfile;
int _11shebang;
int _11char_class;
int _11id_char;
int _11IncludeStk;
int _11all_source;
int _11current_source;
int _11current_source_next;
int _14op_info1;
int _14op_info2;
int _14optimized_while;
int _14trace_called;
int _14last_routine_id;
int _14max_params;
int _14last_max_params;
int _14previous_op;
int _14current_sequence;
int _14lhs_ptr;
int _14lhs_subs1_copy_temp;
int _14lhs_target_temp;
int _14cg_stack;
int _14assignable;
int _14token_name;
int _14op_result;
int _15max_stack_per_call;
int _15sample_size;
int _15branch_list;
int _15short_circuit;
int _15short_circuit_B;
int _15SC1_patch;
int _15SC1_type;
int _15start_index;
int _15backed_up_tok;
int _15FuncReturn;
int _15param_num;
int _15elist;
int _15exit_list;
int _15loop_nest;
int _15stmt_nest;
int _15init_stack;
int _15side_effect_calls;
int _15factors;
int _15lhs_subs_level;
int _15left_sym;
int _15forward_expr;
int _15forward_Statement_list;
int _15mix_msg;
int _18opnames;
int _16crash_msg;
int _16call_backs;
int _16call_back_code;
int _16t_id;
int _16t_arglist;
int _16t_return_val;
int _16call_back_routine;
int _16crash_list;
int _16crash_count;
int _16TraceOn;
int _16pc;
int _16a;
int _16b;
int _16c;
int _16d;
int _16target;
int _16len;
int _16keep_running;
int _16lhs_seq_index;
int _16lhs_subs;
int _16val;
int _16TASK_NEVER;
int _16TASK_ID_MAX;
int _16id_wrap;
int _16current_task;
int _16call_stack;
int _16next_task_id;
int _16clock_period;
int _16tcb;
int _16rt_first;
int _16ts_first;
int _16e_routine;
int _16err_file;
int _16err_file_name;
int _16screen_err_out;
int _16forward_general_callback;
int _16clock_stopped;
int _16save_clock;
int _16trace_file;
int _16trace_line;
int _16result;
int _16result_val;
int _16operation;
int _16cb_std;
int _16cb_cdecl;
int _20DIGITS;
int _20HEX_DIGITS;
int _20START_NUMERIC;
int _20input_file;
int _20input_string;
int _20string_next;
int _20ch;
int _20ESCAPE_CHARS;
int _20ESCAPED_CHARS;


struct routine_list _00[] = {
  {"instance", _2instance, 0, -2, 0, 0},
  {"sleep", _2sleep, 1, -2, 1, 0},
  {"reverse", _2reverse, 2, -2, 1, 0},
  {"sprint", _2sprint, 3, -2, 1, 0},
  {"pretty_print", _2pretty_print, 9, -2, 3, 0},
  {"arccos", _2arccos, 11, -2, 1, 0},
  {"arcsin", _2arcsin, 12, -2, 1, 0},
  {"lower", _3lower, 13, -3, 1, 0},
  {"upper", _3upper, 14, -3, 1, 0},
  {"wildcard_match", _3wildcard_match, 16, -3, 2, 0},
  {"wildcard_file", _3wildcard_file, 17, -3, 2, 0},
  {"boolean", _4boolean, 18, -4, 1, 0},
  {"symtab_entry", _4symtab_entry, 19, -4, 1, 0},
  {"symtab_index", _4symtab_index, 20, -4, 1, 0},
  {"temp_index", _4temp_index, 21, -4, 1, 0},
  {"token", _4token, 22, -4, 1, 0},
  {"file", _4file, 23, -4, 1, 0},
  {"allocate", _7allocate, 31, -7, 1, 0},
  {"free", _7free, 32, -7, 1, 0},
  {"allocate_low", _7allocate_low, 33, -7, 1, 0},
  {"free_low", _7free_low, 34, -7, 1, 0},
  {"dos_interrupt", _7dos_interrupt, 35, -7, 2, 0},
  {"int_to_bytes", _7int_to_bytes, 36, -7, 1, 0},
  {"bytes_to_int", _7bytes_to_int, 37, -7, 1, 0},
  {"int_to_bits", _7int_to_bits, 38, -7, 2, 0},
  {"bits_to_int", _7bits_to_int, 39, -7, 1, 0},
  {"set_rand", _7set_rand, 40, -7, 1, 0},
  {"use_vesa", _7use_vesa, 41, -7, 1, 0},
  {"crash_message", _7crash_message, 42, -7, 1, 0},
  {"crash_file", _7crash_file, 43, -7, 1, 0},
  {"crash_routine", _7crash_routine, 44, -7, 1, 0},
  {"tick_rate", _7tick_rate, 45, -7, 1, 0},
  {"get_vector", _7get_vector, 46, -7, 1, 0},
  {"set_vector", _7set_vector, 47, -7, 2, 0},
  {"lock_memory", _7lock_memory, 48, -7, 2, 0},
  {"atom_to_float64", _7atom_to_float64, 49, -7, 1, 0},
  {"atom_to_float32", _7atom_to_float32, 50, -7, 1, 0},
  {"float64_to_atom", _7float64_to_atom, 51, -7, 1, 0},
  {"float32_to_atom", _7float32_to_atom, 52, -7, 1, 0},
  {"allocate_string", _7allocate_string, 53, -7, 1, 0},
  {"register_block", _7register_block, 54, -7, 2, 0},
  {"unregister_block", _7unregister_block, 55, -7, 1, 0},
  {"check_all_blocks", _7check_all_blocks, 56, -7, 0, 0},
  {"screen_output", _6screen_output, 57, -6, 2, 0},
  {"Warning", _6Warning, 58, -6, 1, 0},
  {"ShowWarnings", _6ShowWarnings, 59, -6, 1, 0},
  {"Cleanup", _6Cleanup, 60, -6, 1, 0},
  {"OpenErrFile", _6OpenErrFile, 61, -6, 0, 0},
  {"CompileErr", _6CompileErr, 63, -6, 1, 0},
  {"InternalErr", _6InternalErr, 65, -6, 1, 0},
  {"c_putc", _9c_putc, 66, -9, 1, 0},
  {"c_hputs", _9c_hputs, 67, -9, 1, 0},
  {"c_puts", _9c_puts, 68, -9, 1, 0},
  {"c_hprintf", _9c_hprintf, 69, -9, 2, 0},
  {"c_printf", _9c_printf, 70, -9, 2, 0},
  {"c_printf8", _9c_printf8, 71, -9, 1, 0},
  {"adjust_indent_before", _9adjust_indent_before, 72, -9, 1, 0},
  {"adjust_indent_after", _9adjust_indent_after, 73, -9, 1, 0},
  {"NewEntry", _10NewEntry, 75, -10, 7, 0},
  {"tmp_alloc", _10tmp_alloc, 76, -10, 0, 0},
  {"DefinedYet", _10DefinedYet, 78, -10, 1, 0},
  {"name_ext", _10name_ext, 79, -10, 1, 0},
  {"NewStringSym", _10NewStringSym, 80, -10, 1, 0},
  {"NewIntSym", _10NewIntSym, 81, -10, 1, 0},
  {"NewDoubleSym", _10NewDoubleSym, 82, -10, 1, 0},
  {"NewTempSym", _10NewTempSym, 83, -10, 0, 0},
  {"InitSymTab", _10InitSymTab, 84, -10, 0, 0},
  {"add_ref", _10add_ref, 85, -10, 1, 0},
  {"MarkTargets", _10MarkTargets, 86, -10, 2, 0},
  {"keyfind", _10keyfind, 87, -10, 2, 0},
  {"Hide", _10Hide, 88, -10, 1, 0},
  {"HideLocals", _10HideLocals, 90, -10, 0, 0},
  {"ExitScope", _10ExitScope, 91, -10, 0, 0},
  {"sort", _13sort, 92, -13, 1, 0},
  {"custom_sort", _13custom_sort, 93, -13, 2, 0},
  {"seek", _12seek, 97, -12, 2, 0},
  {"where", _12where, 98, -12, 1, 0},
  {"flush", _12flush, 99, -12, 1, 0},
  {"lock_file", _12lock_file, 102, -12, 3, 0},
  {"unlock_file", _12unlock_file, 103, -12, 2, 0},
  {"dir", _12dir, 104, -12, 1, 0},
  {"current_dir", _12current_dir, 105, -12, 0, 0},
  {"chdir", _12chdir, 106, -12, 1, 0},
  {"allow_break", _12allow_break, 107, -12, 1, 0},
  {"check_break", _12check_break, 108, -12, 0, 0},
  {"walk_dir", _12walk_dir, 110, -12, 3, 0},
  {"InitLex", _11InitLex, 111, -11, 0, 0},
  {"ResetTP", _11ResetTP, 112, -11, 0, 0},
  {"fetch_line", _11fetch_line, 114, -11, 1, 0},
  {"AppendSourceLine", _11AppendSourceLine, 115, -11, 0, 0},
  {"s_expand", _11s_expand, 116, -11, 1, 0},
  {"read_line", _11read_line, 117, -11, 0, 0},
  {"IncludePop", _11IncludePop, 125, -11, 0, 0},
  {"Scanner", _11Scanner, 129, -11, 0, 0},
  {"StringToken", _11StringToken, 131, -11, 0, 0},
  {"IncludeScan", _11IncludeScan, 132, -11, 0, 0},
  {"TempFree", _14TempFree, 137, -14, 1, 0},
  {"LexName", _14LexName, 139, -14, 1, 0},
  {"InitEmit", _14InitEmit, 140, -14, 0, 0},
  {"emit_opnd", _14emit_opnd, 143, -14, 1, 0},
  {"emit_addr", _14emit_addr, 144, -14, 1, 0},
  {"backpatch", _14backpatch, 146, -14, 2, 0},
  {"emit_op", _14emit_op, 151, -14, 1, 0},
  {"emit_assign_op", _14emit_assign_op, 152, -14, 1, 0},
  {"StartSourceLine", _14StartSourceLine, 153, -14, 1, 0},
  {"InitParser", _15InitParser, 158, -15, 0, 0},
  {"Expr", _15Expr, 181, 15, 0, 0},
  {"Statement_list", _15Statement_list, 195, 15, 0, 0},
  {"InitGlobals", _15InitGlobals, 197, -15, 0, 0},
  {"parser", _15parser, 201, -15, 0, 0},
  {"open_dll", _17open_dll, 202, -17, 1, 0},
  {"define_c_var", _17define_c_var, 203, -17, 2, 0},
  {"define_c_proc", _17define_c_proc, 204, -17, 3, 0},
  {"define_c_func", _17define_c_func, 205, -17, 4, 0},
  {"call_back", _17call_back, 206, -17, 1, 0},
  {"free_console", _17free_console, 207, -17, 0, 0},
  {"open_err_file", _16open_err_file, 208, 16, 0, 0},
  {"both_puts", _16both_puts, 209, 16, 1, 0},
  {"both_printf", _16both_printf, 210, 16, 2, 0},
  {"find_line", _16find_line, 211, 16, 2, 0},
  {"show_var", _16show_var, 212, 16, 1, 0},
  {"save_private_block", _16save_private_block, 213, 16, 2, 0},
  {"load_private_block", _16load_private_block, 214, 16, 2, 0},
  {"restore_privates", _16restore_privates, 215, 16, 1, 0},
  {"trace_back", _16trace_back, 216, 16, 1, 0},
  {"call_crash_routines", _16call_crash_routines, 217, 16, 0, 0},
  {"quit_after_error", _16quit_after_error, 218, 16, 0, 0},
  {"RTFatalType", _16RTFatalType, 219, 16, 1, 0},
  {"RTFatal", _16RTFatal, 220, 16, 1, 0},
  {"RTInternal", _16RTInternal, 221, 16, 1, 0},
  {"wait", _16wait, 222, 16, 1, 0},
  {"scheduler", _16scheduler, 223, 16, 0, 0},
  {"task_insert", _16task_insert, 224, 16, 2, 0},
  {"task_delete", _16task_delete, 225, 16, 2, 0},
  {"opTASK_YIELD", _16opTASK_YIELD, 226, 16, 0, 0},
  {"kill_task", _16kill_task, 227, 16, 1, 0},
  {"which_task", _16which_task, 228, 16, 1, 0},
  {"opTASK_STATUS", _16opTASK_STATUS, 229, 16, 0, 0},
  {"opTASK_LIST", _16opTASK_LIST, 230, 16, 0, 0},
  {"opTASK_SELF", _16opTASK_SELF, 231, 16, 0, 0},
  {"opTASK_CLOCK_STOP", _16opTASK_CLOCK_STOP, 232, 16, 0, 0},
  {"opTASK_CLOCK_START", _16opTASK_CLOCK_START, 233, 16, 0, 0},
  {"opTASK_SUSPEND", _16opTASK_SUSPEND, 234, 16, 0, 0},
  {"opTASK_CREATE", _16opTASK_CREATE, 235, 16, 0, 0},
  {"opTASK_SCHEDULE", _16opTASK_SCHEDULE, 236, 16, 0, 0},
  {"one_trace_line", _16one_trace_line, 237, 16, 1, 0},
  {"opSTARTLINE", _16opSTARTLINE, 238, 16, 0, 0},
  {"opPROC", _16opPROC, 239, 16, 0, 0},
  {"opRETURNP", _16opRETURNP, 240, 16, 0, 0},
  {"opRETURNF", _16opRETURNF, 241, 16, 0, 0},
  {"opCALL_BACK_RETURN", _16opCALL_BACK_RETURN, 242, 16, 0, 0},
  {"opBADRETURNF", _16opBADRETURNF, 243, 16, 0, 0},
  {"opRETURNT", _16opRETURNT, 244, 16, 0, 0},
  {"opRHS_SUBS", _16opRHS_SUBS, 245, 16, 0, 0},
  {"opIF", _16opIF, 246, 16, 0, 0},
  {"opINTEGER_CHECK", _16opINTEGER_CHECK, 247, 16, 0, 0},
  {"opATOM_CHECK", _16opATOM_CHECK, 248, 16, 0, 0},
  {"opSEQUENCE_CHECK", _16opSEQUENCE_CHECK, 249, 16, 0, 0},
  {"opASSIGN", _16opASSIGN, 250, 16, 0, 0},
  {"opELSE", _16opELSE, 251, 16, 0, 0},
  {"opRIGHT_BRACE_N", _16opRIGHT_BRACE_N, 252, 16, 0, 0},
  {"opRIGHT_BRACE_2", _16opRIGHT_BRACE_2, 253, 16, 0, 0},
  {"opPLUS1", _16opPLUS1, 254, 16, 0, 0},
  {"opGLOBAL_INIT_CHECK", _16opGLOBAL_INIT_CHECK, 255, 16, 0, 0},
  {"opWHILE", _16opWHILE, 256, 16, 0, 0},
  {"var_subs", _16var_subs, 257, 16, 2, 0},
  {"opLENGTH", _16opLENGTH, 258, 16, 0, 0},
  {"opPLENGTH", _16opPLENGTH, 259, 16, 0, 0},
  {"opLHS_SUBS", _16opLHS_SUBS, 260, 16, 0, 0},
  {"opLHS_SUBS1", _16opLHS_SUBS1, 261, 16, 0, 0},
  {"opLHS_SUBS1_COPY", _16opLHS_SUBS1_COPY, 262, 16, 0, 0},
  {"lhs_check_subs", _16lhs_check_subs, 263, 16, 2, 0},
  {"check_slice", _16check_slice, 264, 16, 3, 0},
  {"lhs_check_slice", _16lhs_check_slice, 265, 16, 4, 0},
  {"var_slice", _16var_slice, 266, 16, 4, 0},
  {"assign_subs", _16assign_subs, 267, 16, 3, 0},
  {"assign_slice", _16assign_slice, 268, 16, 5, 0},
  {"opASSIGN_SUBS", _16opASSIGN_SUBS, 269, 16, 0, 0},
  {"opPASSIGN_SUBS", _16opPASSIGN_SUBS, 270, 16, 0, 0},
  {"opASSIGN_OP_SUBS", _16opASSIGN_OP_SUBS, 271, 16, 0, 0},
  {"opPASSIGN_OP_SUBS", _16opPASSIGN_OP_SUBS, 272, 16, 0, 0},
  {"opASSIGN_OP_SLICE", _16opASSIGN_OP_SLICE, 273, 16, 0, 0},
  {"opPASSIGN_OP_SLICE", _16opPASSIGN_OP_SLICE, 274, 16, 0, 0},
  {"opASSIGN_SLICE", _16opASSIGN_SLICE, 275, 16, 0, 0},
  {"opPASSIGN_SLICE", _16opPASSIGN_SLICE, 276, 16, 0, 0},
  {"opRHS_SLICE", _16opRHS_SLICE, 277, 16, 0, 0},
  {"opTYPE_CHECK", _16opTYPE_CHECK, 278, 16, 0, 0},
  {"opIS_AN_INTEGER", _16opIS_AN_INTEGER, 279, 16, 0, 0},
  {"opIS_AN_ATOM", _16opIS_AN_ATOM, 280, 16, 0, 0},
  {"opIS_A_SEQUENCE", _16opIS_A_SEQUENCE, 281, 16, 0, 0},
  {"opIS_AN_OBJECT", _16opIS_AN_OBJECT, 282, 16, 0, 0},
  {"opSQRT", _16opSQRT, 283, 16, 0, 0},
  {"opSIN", _16opSIN, 284, 16, 0, 0},
  {"opCOS", _16opCOS, 285, 16, 0, 0},
  {"opTAN", _16opTAN, 286, 16, 0, 0},
  {"opARCTAN", _16opARCTAN, 287, 16, 0, 0},
  {"opLOG", _16opLOG, 288, 16, 0, 0},
  {"opNOT_BITS", _16opNOT_BITS, 289, 16, 0, 0},
  {"opFLOOR", _16opFLOOR, 290, 16, 0, 0},
  {"opNOT_IFW", _16opNOT_IFW, 291, 16, 0, 0},
  {"opNOT", _16opNOT, 292, 16, 0, 0},
  {"opUMINUS", _16opUMINUS, 293, 16, 0, 0},
  {"opRAND", _16opRAND, 294, 16, 0, 0},
  {"opDIV2", _16opDIV2, 295, 16, 0, 0},
  {"opFLOOR_DIV2", _16opFLOOR_DIV2, 296, 16, 0, 0},
  {"opGREATER_IFW", _16opGREATER_IFW, 297, 16, 0, 0},
  {"opNOTEQ_IFW", _16opNOTEQ_IFW, 298, 16, 0, 0},
  {"opLESSEQ_IFW", _16opLESSEQ_IFW, 299, 16, 0, 0},
  {"opGREATEREQ_IFW", _16opGREATEREQ_IFW, 300, 16, 0, 0},
  {"opEQUALS_IFW", _16opEQUALS_IFW, 301, 16, 0, 0},
  {"opLESS_IFW", _16opLESS_IFW, 302, 16, 0, 0},
  {"opMULTIPLY", _16opMULTIPLY, 303, 16, 0, 0},
  {"opPLUS", _16opPLUS, 304, 16, 0, 0},
  {"opMINUS", _16opMINUS, 305, 16, 0, 0},
  {"opOR", _16opOR, 306, 16, 0, 0},
  {"opXOR", _16opXOR, 307, 16, 0, 0},
  {"opAND", _16opAND, 308, 16, 0, 0},
  {"opDIVIDE", _16opDIVIDE, 309, 16, 0, 0},
  {"opREMAINDER", _16opREMAINDER, 310, 16, 0, 0},
  {"opFLOOR_DIV", _16opFLOOR_DIV, 311, 16, 0, 0},
  {"opAND_BITS", _16opAND_BITS, 312, 16, 0, 0},
  {"opOR_BITS", _16opOR_BITS, 313, 16, 0, 0},
  {"opXOR_BITS", _16opXOR_BITS, 314, 16, 0, 0},
  {"opPOWER", _16opPOWER, 315, 16, 0, 0},
  {"opLESS", _16opLESS, 316, 16, 0, 0},
  {"opGREATER", _16opGREATER, 317, 16, 0, 0},
  {"opEQUALS", _16opEQUALS, 318, 16, 0, 0},
  {"opNOTEQ", _16opNOTEQ, 319, 16, 0, 0},
  {"opLESSEQ", _16opLESSEQ, 320, 16, 0, 0},
  {"opGREATEREQ", _16opGREATEREQ, 321, 16, 0, 0},
  {"opSC1_AND", _16opSC1_AND, 322, 16, 0, 0},
  {"opSC1_AND_IF", _16opSC1_AND_IF, 323, 16, 0, 0},
  {"opSC1_OR", _16opSC1_OR, 324, 16, 0, 0},
  {"opSC1_OR_IF", _16opSC1_OR_IF, 325, 16, 0, 0},
  {"opSC2_OR", _16opSC2_OR, 326, 16, 0, 0},
  {"opFOR", _16opFOR, 327, 16, 0, 0},
  {"opENDFOR_GENERAL", _16opENDFOR_GENERAL, 328, 16, 0, 0},
  {"opENDFOR_INT_UP1", _16opENDFOR_INT_UP1, 329, 16, 0, 0},
  {"RTLookup", _16RTLookup, 330, 16, 4, 0},
  {"opCALL_PROC", _16opCALL_PROC, 331, 16, 0, 0},
  {"opROUTINE_ID", _16opROUTINE_ID, 332, 16, 0, 0},
  {"opAPPEND", _16opAPPEND, 333, 16, 0, 0},
  {"opPREPEND", _16opPREPEND, 334, 16, 0, 0},
  {"opCONCAT", _16opCONCAT, 335, 16, 0, 0},
  {"opCONCAT_N", _16opCONCAT_N, 336, 16, 0, 0},
  {"opREPEAT", _16opREPEAT, 337, 16, 0, 0},
  {"opDATE", _16opDATE, 338, 16, 0, 0},
  {"opTIME", _16opTIME, 339, 16, 0, 0},
  {"opSPACE_USED", _16opSPACE_USED, 340, 16, 0, 0},
  {"opNOP2", _16opNOP2, 341, 16, 0, 0},
  {"opPOSITION", _16opPOSITION, 342, 16, 0, 0},
  {"opEQUAL", _16opEQUAL, 343, 16, 0, 0},
  {"opCOMPARE", _16opCOMPARE, 344, 16, 0, 0},
  {"opFIND", _16opFIND, 345, 16, 0, 0},
  {"opMATCH", _16opMATCH, 346, 16, 0, 0},
  {"opFIND_FROM", _16opFIND_FROM, 347, 16, 0, 0},
  {"opMATCH_FROM", _16opMATCH_FROM, 348, 16, 0, 0},
  {"opPEEK4U", _16opPEEK4U, 349, 16, 0, 0},
  {"opPEEK4S", _16opPEEK4S, 350, 16, 0, 0},
  {"opPEEK", _16opPEEK, 351, 16, 0, 0},
  {"opPOKE", _16opPOKE, 352, 16, 0, 0},
  {"opPOKE4", _16opPOKE4, 353, 16, 0, 0},
  {"opMEM_COPY", _16opMEM_COPY, 354, 16, 0, 0},
  {"opMEM_SET", _16opMEM_SET, 355, 16, 0, 0},
  {"opPIXEL", _16opPIXEL, 356, 16, 0, 0},
  {"opGET_PIXEL", _16opGET_PIXEL, 357, 16, 0, 0},
  {"opCALL", _16opCALL, 358, 16, 0, 0},
  {"opSYSTEM", _16opSYSTEM, 359, 16, 0, 0},
  {"opSYSTEM_EXEC", _16opSYSTEM_EXEC, 360, 16, 0, 0},
  {"opOPEN", _16opOPEN, 361, 16, 0, 0},
  {"opCLOSE", _16opCLOSE, 362, 16, 0, 0},
  {"opABORT", _16opABORT, 363, 16, 0, 0},
  {"opGETC", _16opGETC, 364, 16, 0, 0},
  {"opGETS", _16opGETS, 365, 16, 0, 0},
  {"opGET_KEY", _16opGET_KEY, 366, 16, 0, 0},
  {"opCLEAR_SCREEN", _16opCLEAR_SCREEN, 367, 16, 0, 0},
  {"opPUTS", _16opPUTS, 368, 16, 0, 0},
  {"opQPRINT", _16opQPRINT, 369, 16, 0, 0},
  {"opPRINT", _16opPRINT, 370, 16, 0, 0},
  {"opPRINTF", _16opPRINTF, 371, 16, 0, 0},
  {"opSPRINTF", _16opSPRINTF, 372, 16, 0, 0},
  {"opCOMMAND_LINE", _16opCOMMAND_LINE, 373, 16, 0, 0},
  {"opGETENV", _16opGETENV, 374, 16, 0, 0},
  {"opC_PROC", _16opC_PROC, 375, 16, 0, 0},
  {"opC_FUNC", _16opC_FUNC, 376, 16, 0, 0},
  {"opTRACE", _16opTRACE, 377, 16, 0, 0},
  {"opPROFILE", _16opPROFILE, 378, 16, 0, 0},
  {"opUPDATE_GLOBALS", _16opUPDATE_GLOBALS, 379, 16, 0, 0},
  {"do_exec", _16do_exec, 380, 16, 0, 0},
  {"general_callback", _16general_callback, 381, 16, 2, 0},
  {"machine_callback", _16machine_callback, 382, 16, 2, 0},
  {"do_callback", _16do_callback, 383, 16, 1, 0},
  {"do_crash_routine", _16do_crash_routine, 384, 16, 1, 0},
  {"opMACHINE_FUNC", _16opMACHINE_FUNC, 385, 16, 0, 0},
  {"opMACHINE_PROC", _16opMACHINE_PROC, 386, 16, 0, 0},
  {"InitBackEnd", _16InitBackEnd, 387, -16, 1, 0},
  {"Execute", _16Execute, 388, -16, 2, 0},
  {"", 0, 999999999, 0, 0, 0}
};

struct ns_list _01[] = {
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern double sqrt();
    _7068 = NewString("\nPress Enter\n");
    _7062 = NewString("Can't open %s\n");
    _4163 = NewString("ex.err");
    _7057 = NewString("/usr231/home/r/h/rhc");
    _7056 = NewString("\\EUPHORIA");
    _7054 = NewString("/euphoria");
    _7053 = NewString("euphoria");
    _7050 = NewString("HOME");
    _7047 = NewString("EUDIR");
    _1669 = NewString("r");
    _7012 = NewString(".exu");
    _7013 = NewString(".exw");
    _7014 = NewString(".ex");
    _39 = NewString("");
    _6990 = NewString(" \t\n");
    _629 = NewString("\n");
    _6985 = NewString("\nfile name to translate to C? ");
    _6984 = NewString("\nfile name to execute? ");
    _6983 = NewString("\nfile name to bind/shroud? ");
    _6982 = NewString("See http://www.RapidEuphoria.com/License.txt \n");
    _6981 = NewString("Copyright (c) Rapid Deployment Software 2007 \n");
    _6980 = NewString("for 32-bit DOS.\n");
    _6979 = NewString("for 32-bit Windows.\n");
    _6978 = NewString("for DOS/Windows.\n");
    _6977 = NewString("for Linux.\n");
    _6976 = NewString("for FreeBSD.\n");
    _6975 = NewString("for Linux/FreeBSD.\n");
    _6969 = NewString(" ");
    _6973 = NewString("Euphoria Binder ");
    _6971 = NewString("Euphoria to C Translator ");
    _6968 = NewString("Euphoria Interpreter ");
    _6932 = NewString("PATH");
    _6901 = NewString("A number from %g to %g is expected here - try again\n");
    _6890 = NewString("A number is expected - try again\n");
    _6775 = NewString("\n\t'\"\\\r");
    _6774 = NewString("nt'\"\\r");
    _6772 = NewString(" \t\n\r");
    _6759 = NewString("-+.#");
    _6757 = NewString("ABCDEF");
    _6756 = NewString("0123456789");
    _6754 = NewString("Execute");
    _6751 = NewString("no routine id for op");
    _6746 = NewString("op");
    _4066 = NewString("LESSEQ_IFW");
    _4083 = NewString("LESSEQ_IFW_I");
    _4063 = NewString("GREATEREQ_IFW");
    _4080 = NewString("GREATEREQ_IFW_I");
    _4065 = NewString("NOTEQ_IFW");
    _4082 = NewString("NOTEQ_IFW_I");
    _4064 = NewString("EQUALS_IFW");
    _4081 = NewString("EQUALS_IFW_I");
    _4062 = NewString("LESS_IFW");
    _4079 = NewString("LESS_IFW_I");
    _4067 = NewString("GREATER_IFW");
    _4084 = NewString("GREATER_IFW_I");
    _4070 = NewString("NOP2");
    _4121 = NewString("NOP1");
    _4120 = NewString("NOPWHILE");
    _4118 = NewString("END_PARAM_CHECK");
    _4117 = NewString("PLATFORM");
    _4110 = NewString("ASSIGN_SUBS2");
    _4107 = NewString("SC2_NULL");
    _4106 = NewString("SC2_OR");
    _4104 = NewString("SC2_AND");
    _4113 = NewString("PROFILE");
    _4050 = NewString("ERASE_SYMBOL");
    _4048 = NewString("ERASE_PRIVATE_NAMES");
    _4047 = NewString("DISPLAY_VAR");
    _4098 = NewString("CALL_PROC");
    _4099 = NewString("CALL_FUNC");
    _3999 = NewString("ENDFOR_GENERAL");
    _4015 = NewString("ENDFOR_INT_DOWN1");
    _4012 = NewString("ENDFOR_INT_DOWN");
    _4008 = NewString("ENDFOR_INT_UP");
    _4010 = NewString("ENDFOR_DOWN");
    _4009 = NewString("ENDFOR_UP");
    _3981 = NewString("FOR");
    _4085 = NewString("FOR_I");
    _3970 = NewString("MINUS");
    _4076 = NewString("MINUS_I");
    _3971 = NewString("PLUS");
    _4075 = NewString("PLUS_I");
    _4069 = NewString("GLOBAL_INIT_CHECK");
    _3990 = NewString("PRIVATE_INIT_CHECK");
    _4053 = NewString("PLUS1");
    _4077 = NewString("PLUS1_I");
    _3983 = NewString("ELSE");
    _3982 = NewString("ENDWHILE");
    _4021 = NewString("EXIT");
    _3978 = NewString("ASSIGN");
    _4073 = NewString("ASSIGN_I");
    _3976 = NewString("ASSIGN_SUBS");
    _4078 = NewString("ASSIGN_SUBS_I");
    _4044 = NewString("ASSIGN_SUBS_CHECK");
    _3985 = NewString("RHS_SUBS");
    _4074 = NewString("RHS_SUBS_I");
    _4052 = NewString("RHS_SUBS_CHECK");
    _6672 = NewString("crash routine requires a valid routine id");
    _6646 = NewString("machine_callback");
    _6628 = NewString("Invalid routine id");
    _6605 = NewString("general_callback");
    _6556 = NewString("argument to getenv must be a sequence");
    _6470 = NewString("device or file name must be a sequence");
    _6467 = NewString("invalid open mode");
    _6437 = NewString("second argument of system() must be an atom");
    _6434 = NewString("first argument of system() must be a sequence");
    _6341 = NewString("index out of bounds in match_from()");
    _6338 = NewString("second argument of match_from() must be a sequence");
    _6334 = NewString("first argument of match_from() must be a non-empty sequence");
    _6329 = NewString("first argument of match_from() must be a sequence");
    _6302 = NewString("second argument of find_from() must be a sequence");
    _6287 = NewString("first argument of match() must be a non-empty sequence");
    _6283 = NewString("second argument of match() must be a sequence");
    _6279 = NewString("first argument of match() must be a sequence");
    _6265 = NewString("second argument of find() must be a sequence");
    _6214 = NewString("repetition count is too large");
    _6211 = NewString("repetition count must not be negative");
    _6208 = NewString("repetition count must be an atom");
    _6070 = NewString("call to %s() via routine-id should pass %d arguments, not %d");
    _6064 = NewString("argument list must be a sequence");
    _6058 = NewString("the value returned by %s() must be assigned or used");
    _6051 = NewString("%s() does not return a value");
    _4714 = NewString("invalid routine id");
    _5856 = NewString("for-loop increment is not an atom");
    _5853 = NewString("for-loop limit is not an atom");
    _5850 = NewString("for-loop variable is not an atom");
    _5795 = NewString("true/false condition must be an ATOM");
    _5655 = NewString("attempt to divide by 0");
    _5668 = NewString("Can't get remainder of a number divided by 0");
    _4981 = NewString("subscript value %d is out of bounds, reading from a sequence of length %d");
    _5243 = NewString("subscript must be an atom\n(assigning to subscript of a sequence)");
    _5194 = NewString("subscript must be an atom");
    _4973 = NewString("attempt to subscript an atom\n(reading from it)");
    _5189 = NewString("lengths do not match on assignment to slice");
    _5180 = NewString("slice ends past end of sequence");
    _5177 = NewString("slice starts past end of sequence");
    _5168 = NewString("slice length is less than 0");
    _5164 = NewString("attempt to slice an atom");
    _5162 = NewString("slice upper index is less than 0");
    _5159 = NewString("slice upper index is not an atom");
    _5157 = NewString("slice lower index is less than 1");
    _5154 = NewString("slice lower index is not an atom");
    _5149 = NewString("subscript value %d is out of bounds, assigning to a sequence of length %d");
    _5141 = NewString("subscript must be an atom\n(assigning to a sequence of length %d)");
    _5139 = NewString("attempt to subscript an atom\n(assigning to it)");
    _5090 = NewString("length of an atom is not defined");
    _5073 = NewString("A subscript must be an atom");
    _5059 = NewString(" has not been initialized");
    _4975 = NewString("subscript must be an atom\n(reading an element of a sequence)");
    _4960 = NewString("attempt to exit a function without returning a value");
    _4867 = NewString("=== THE END ===");
    _4865 = NewString("               ");
    _4854 = NewString("%s:%d\t%s");
    _4844 = NewString("Couldn't open ctrace.out");
    _4841 = NewString("wb");
    _4840 = NewString("ctrace.out");
    _4837 = NewString("%-77.77s\r\n");
    _4835 = NewString("%-78.78s\n");
    _4796 = NewDouble((double)1.0000000000000001e-09);
    _4788 = NewString("task min time must be <= task max time");
    _4784 = NewString("min and max times must be greater than or equal to 0");
    _4778 = NewString("min and max times must be atoms");
    _4772 = NewString("second argument must be {min-time, max-time}");
    _4753 = NewString("number of executions must be greater than 0");
    _4721 = NewString("specify the routine id of a procedure, not a function or type");
    _4641 = NewString("invalid task id");
    _113 = NewString(" ...");
    _4476 = NewString(",}");
    _4460 = NewString("type_check error\n%s is ");
    _4455 = NewString("\nPress Enter...\n");
    _4446 = NewString("ex_crash.err");
    _4440 = NewString(":\n");
    _4438 = NewString("\n ");
    _4431 = NewString("\x05\x06\x04");
    _4418 = NewString("\n\nGlobal & Local Variables\n");
    _4416 = NewString("\n--> see ");
    _4358 = NewString("%s()");
    _4357 = NewString("in type ");
    _4353 = NewString("in function ");
    _4349 = NewString("in procedure ");
    _862 = NewString("_toplevel_");
    _4340 = NewString("%s:%d ");
    _4339 = NewString("external program\n");
    _4338 = NewString("Windows\n");
    _4337 = NewString("^^^ call-back from ");
    _4336 = NewString("^^^ called to handle run-time crash\n");
    _4333 = NewString("... called from ");
    _4314 = NewString(" TASK ID %d: %s ");
    _4307 = NewString("initial task");
    _23 = NewString("%.10g");
    _122 = NewString("%d");
    _4198 = NewString("<no value>");
    _4194 = NewString(" = ");
    _913 = NewString("    ");
    _4166 = NewString("Can't open ");
    _623 = NewString("w");
    _4160 = NewDouble((double)1.0000000000000000e-02);
    _4159 = NewDouble((double)5.5000000000000000e-02);
    _4158 = NewDouble((double)9.0000000000000000e+15);
    _4157 = NewDouble((double)1.0000000000000001e+300);
    _4144 = NewString("_call_back_");
    _4139 = NewString("MATCH_FROM");
    _4138 = NewString("FIND_FROM");
    _4137 = NewString("TASK_CLOCK_START");
    _4136 = NewString("TASK_CLOCK_STOP");
    _4135 = NewString("TASK_STATUS");
    _4134 = NewString("TASK_LIST");
    _4133 = NewString("TASK_SUSPEND");
    _4132 = NewString("TASK_SELF");
    _4131 = NewString("TASK_YIELD");
    _4130 = NewString("TASK_SCHEDULE");
    _4129 = NewString("TASK_CREATE");
    _4128 = NewString("LHS_SUBS1_COPY");
    _4127 = NewString("PASSIGN_OP_SLICE");
    _4126 = NewString("PASSIGN_OP_SUBS");
    _4125 = NewString("PASSIGN_SLICE");
    _4124 = NewString("PASSIGN_SUBS");
    _4123 = NewString("LHS_SUBS1");
    _4122 = NewString("PLENGTH");
    _4119 = NewString("CONCAT_N");
    _4116 = NewString("SYSTEM_EXEC");
    _4115 = NewString("EQUAL");
    _4114 = NewString("XOR");
    _4112 = NewString("ASSIGN_OP_SLICE");
    _4111 = NewString("ASSIGN_OP_SUBS");
    _4109 = NewString("SC1_OR_IF");
    _4108 = NewString("SC1_AND_IF");
    _4105 = NewString("SC1_OR");
    _4103 = NewString("SC1_AND");
    _4102 = NewString("PEEK4U");
    _4101 = NewString("PEEK4S");
    _4100 = NewString("POKE4");
    _4097 = NewString("CALL_BACK_RETURN");
    _4096 = NewString("ROUTINE_ID");
    _4095 = NewString("C_FUNC");
    _4094 = NewString("C_PROC");
    _4093 = NewString("MEM_SET");
    _4092 = NewString("MEM_COPY");
    _4091 = NewString("GET_PIXEL");
    _4090 = NewString("PIXEL");
    _4089 = NewString("CALL");
    _4088 = NewString("POKE");
    _4087 = NewString("PEEK");
    _4086 = NewString("ABORT");
    _4072 = NewString("MACHINE_PROC");
    _4071 = NewString("MACHINE_FUNC");
    _4068 = NewString("NOT_IFW");
    _4061 = NewString("ATOM_CHECK");
    _4060 = NewString("COMMAND_LINE");
    _4059 = NewString("SYSTEM");
    _4058 = NewString("DIV2");
    _4057 = NewString("SEQUENCE_CHECK");
    _4056 = NewString("INTEGER_CHECK");
    _4055 = NewString("LHS_SUBS");
    _4054 = NewString("IS_AN_INTEGER");
    _4051 = NewString("GETENV");
    _4049 = NewString("UPDATE_GLOBALS");
    _4046 = NewString("CLOSE");
    _4045 = NewString("RIGHT_BRACE_2");
    _4043 = NewString("FLOOR");
    _4042 = NewString("TAN");
    _4041 = NewString("COS");
    _4040 = NewString("SIN");
    _4039 = NewString("GET_KEY");
    _4038 = NewString("MATCH");
    _4037 = NewString("FIND");
    _4036 = NewString("COMPARE");
    _4035 = NewString("SPACE_USED");
    _4034 = NewString("LOG");
    _4033 = NewString("ARCTAN");
    _4032 = NewString("POWER");
    _4031 = NewString("REMAINDER");
    _4030 = NewString("TIME");
    _4029 = NewString("DATE");
    _4028 = NewString("IS_A_SEQUENCE");
    _4027 = NewString("IS_AN_ATOM");
    _4026 = NewString("FLOOR_DIV2");
    _4025 = NewString("TYPE_CHECK");
    _4024 = NewString("TRACE");
    _4023 = NewString("FLOOR_DIV");
    _4022 = NewString("RAND");
    _4020 = NewString("POSITION");
    _4019 = NewString("CLEAR_SCREEN");
    _4018 = NewString("STARTLINE");
    _4017 = NewString("PREPEND");
    _4016 = NewString("AND_BITS");
    _4014 = NewString("ENDFOR_INT_UP1");
    _4013 = NewString("SPRINTF");
    _4011 = NewString("NOT_BITS");
    _4007 = NewString("WHILE");
    _4006 = NewString("RHS_SLICE");
    _4005 = NewString("ASSIGN_SLICE");
    _4004 = NewString("PUTS");
    _4003 = NewString("BADRETURNF");
    _4002 = NewString("LENGTH");
    _4001 = NewString("SQRT");
    _4000 = NewString("IS_AN_OBJECT");
    _3998 = NewString("PRINTF");
    _3997 = NewString("OPEN");
    _3996 = NewString("QPRINT");
    _3995 = NewString("APPEND");
    _3994 = NewString("RETURNT");
    _3993 = NewString("GETC");
    _3992 = NewString("REPEAT");
    _3991 = NewString("RIGHT_BRACE_N");
    _3989 = NewString("RETURNP");
    _3988 = NewString("RETURNF");
    _3987 = NewString("PROC");
    _3986 = NewString("XOR_BITS");
    _3984 = NewString("OR_BITS");
    _3980 = NewString("IF");
    _3979 = NewString("PRINT");
    _3977 = NewString("GETS");
    _3975 = NewString("CONCAT");
    _3974 = NewString("DIVIDE");
    _3973 = NewString("MULTIPLY");
    _3972 = NewString("UMINUS");
    _3969 = NewString("OR");
    _3968 = NewString("AND");
    _3967 = NewString("NOT");
    _3966 = NewString("GREATER");
    _3965 = NewString("LESSEQ");
    _3964 = NewString("NOTEQ");
    _3963 = NewString("EQUALS");
    _3962 = NewString("GREATEREQ");
    _3961 = NewString("LESS");
    _3935 = NewString("unknown command");
    _3934 = NewString("illegal character");
    _3926 = NewString("exit must be inside a loop");
    _3923 = NewString("function result must be assigned or used");
    _3908 = NewString("'global' must be followed by:\n     <a type>, 'constant', 'procedure', 'type' or 'function'");
    _3879 = NewString("unknown with/without option");
    _3871 = NewString("warning");
    _758 = NewString("trace");
    _3868 = NewString("sample size must be a positive integer");
    _3850 = NewString("profile_time");
    _828 = NewString("profile");
    _3844 = NewString("type_check");
    _3842 = NewString("can't mix profile and profile_time");
    _648 = NewString("%s is not supported in Euphoria for %s");
    _3832 = NewString("type must return true / false value");
    _3831 = NewString("no value returned from function");
    _3806 = NewString("types must have exactly one parameter");
    _3796 = NewString("badly-formed list of parameters - expected ',' or ')'");
    _3793 = NewString("expected to see a parameter declaration, not ')'");
    _3778 = NewString("a parameter name is expected here");
    _3771 = NewString("a type is expected here");
    _3715 = NewString("built-in routine %s() redefined");
    _3710 = NewString("\x07\x06");
    _3594 = NewString("a name is expected here");
    _3698 = NewString("Statement_list");
    _3674 = NewString("abort()");
    _3644 = NewString("a variable name is expected here");
    _2133 = NewString("\x06\x07");
    _3544 = NewString("a loop variable name is expected here");
    _3538 = NewString("SetPS");
    _3529 = NewString("\x05\x06\x07");
    _3521 = NewString("\t\n");
    _3519 = NewString("\x03\x02");
    _690 = NewString("exit");
    _3445 = NewString("exit statement must be inside a loop");
    _672 = NewString("return");
    _3437 = NewString("return must be inside a procedure or function");
    _3398 = NewString("Syntax error - expected to see =, +=, -=, *=, /= or &=");
    _3357 = NewString("may not change the value of a constant");
    _3353 = NewString("may not assign to a for-loop variable");
    _3313 = NewString("Expr");
    _3243 = NewString("Syntax error - expected to see an expression, not %s");
    _3226 = NewString("%.99s:%d - call to %s() might be short-circuited");
    _3198 = NewString("'$' must only appear between '[' and ']'");
    _3163 = NewString("only ");
    _3140 = NewString("%s takes %s%d argument%s");
    _3139 = NewString("s");
    _3122 = NewString("A namespace qualifier is needed to resolve %s.\n%s is defined as a global symbol in:\n");
    _3114 = NewString("%s has not been declared");
    _3108 = NewString("Syntax error - expected to see possibly %s, not %s");
    _2996 = NewString("%s:%d - statement after %s will never be executed");
    _2939 = NewString("unknown opcode: %d");
    _2938 = NewString("Statements have been inserted to trace execution of your program.");
    _2932 = NewString("\x99\xAD");
    _2903 = NewString("\x56\x7E\x81");
    _2899 = NewString("\x45\x46\x4B\x4F\xAE\x64");
    _2808 = NewString("\x84\x85\x26");
    _2798 = NewString("\x0A\x23\x39\x4C\x9B\x4D\x4E\x9C\x0F\x20\x6F\x87\x25\x35\xA9");
    _2740 = NewString("\x03\x01\x06\x04\x05\x02\x08\x09\x9A\x47\x38\x18\x1A");
    _2735 = NewString("\x63\x2C\x13\x24\x3C\x70\x86\x82\x80\x8C\xAA");
    _2723 = NewString("\x5E\x43\x44\x28\x2A\x21\x29\x50\x51\x52\x49\x4A\x11\x83\x5B");
    _2693 = NewString("\x3E\x7F\x8D\x8E\x33\x07\xAF");
    _2549 = NewString("\xA1\x6E\xA0\x1E\x6D\x3A\x3B\x3D\x16\x17\x58\x2B\x5A\x59\x57"
"\x89\x9E\xAB\xB1\xB0");
    _2381 = NewString("this ...");
    _2341 = NewString("'?'");
    _2339 = NewString("'while'");
    _2337 = NewString("'without'");
    _2335 = NewString("'with'");
    _2309 = NewString("a variable");
    _2332 = NewString("'type'");
    _2313 = NewString("a type");
    _2329 = NewString("'then'");
    _2327 = NewString("'to'");
    _2325 = NewString("a character string");
    _2323 = NewString("a slice");
    _2321 = NewString("'return'");
    _2319 = NewString("']'");
    _2317 = NewString("')'");
    _2315 = NewString("'}'");
    _2305 = NewString("a procedure");
    _2263 = NewString("a function");
    _2307 = NewString("'procedure'");
    _2303 = NewString("'+'");
    _2301 = NewString("'or'");
    _2299 = NewString("'!='");
    _2297 = NewString("'not'");
    _2295 = NewString("end-of-line");
    _2293 = NewString("a namespace qualifier");
    _2291 = NewString("'*'");
    _2289 = NewString("'-'");
    _2287 = NewString("'<='");
    _2285 = NewString("'<'");
    _2283 = NewString("'['");
    _2281 = NewString("'('");
    _2279 = NewString("'{'");
    _2277 = NewString("'include'");
    _2275 = NewString("an illegal character");
    _2273 = NewString("'if'");
    _2271 = NewString("'>='");
    _2269 = NewString("'>'");
    _2267 = NewString("'global'");
    _2265 = NewString("'function'");
    _2261 = NewString("'for'");
    _2259 = NewString("'exit'");
    _2257 = NewString("'='");
    _2255 = NewString("the end of file");
    _2253 = NewString("'end'");
    _2251 = NewString("'elsif'");
    _2249 = NewString("'else'");
    _2247 = NewString("'do'");
    _2245 = NewString("'/'");
    _2243 = NewString("'constant'");
    _2241 = NewString("'&'");
    _2239 = NewString("','");
    _2237 = NewString("':'");
    _2235 = NewString("'by'");
    _2233 = NewString("'!'");
    _2231 = NewString("a number");
    _2229 = NewString("'and'");
    _2228 = NewString("improper syntax for include-as");
    _2227 = NewString("missing namespace qualifier");
    _2224 = NewString("a new namespace identifier is expected here");
    _2188 = NewString("file name is missing");
    _2153 = NewString("\x20\x09\x0A\x0D\x1A");
    _2181 = NewString("missing closing quote on file name");
    _2172 = NewString("\x0A\x0D\x22\x1A");
    _2158 = NewString("--");
    _2130 = NewString("Scanner()");
    _2101 = NewString("character constant is missing a closing '");
    _2098 = NewString("single-quote character is empty");
    _2017 = NewString("tab character found in string - use \\t instead");
    _2058 = NewString("hex number not formed correctly");
    _2057 = NewString("#! may only be on the first line of a program");
    _2025 = NewString("end of line reached with no closing \"");
    _1807 = NewString("number not formed correctly");
    _1977 = NewString("exponent not formed correctly");
    _1964 = NewString("fractional part of number is missing");
    _1954 = NewString("only one decimal point allowed");
    _1913 = NewString("an identifier is expected here");
    _1815 = NewDouble((double)1.0000000000000000e+01);
    _1864 = NewDouble((double)3.0800000000000000e+02);
    _1808 = NewDouble((double)0.0000000000000000e+00);
    _1804 = NewString("unknown escape character");
    _1767 = NewString("program includes too many files");
    _1763 = NewString("includes are nested too deeply");
    _1734 = NewString("can't find %s in %s\nor in %s\nor in %s%sinclude");
    _1731 = NewString("can't find %s in %s\nor in %s%sinclude");
    _1517 = NewString(".");
    _700 = NewString("include");
    _1696 = NewString(" \t");
    _1682 = NewString("EUINC");
    _1672 = NewString("can't open %s");
    _1653 = NewString("illegal character (ASCII 0)");
    _1648 = NewString("\x1A");
    _1565 = NewString("out of memory - turn off trace and profile");
    _1518 = NewString("..");
    _1444 = NewDouble((double)3.5000000000000000e+00);
    _1404 = NewString("%s %s in %s is %s");
    _1399 = NewString("%s %s in %s() in %s is %s");
    _1396 = NewString("never assigned a value");
    _1394 = NewString("not used");
    _1376 = NewString("local constant");
    _1384 = NewString("private variable");
    _1383 = NewString("parameter");
    _1377 = NewString("local variable");
    _714 = NewString("sequence");
    _712 = NewString("integer");
    _742 = NewString("atom");
    _718 = NewString("object");
    _1076 = NewString("extern int _%d;\n");
    _1073 = NewString("int _%d;\n");
    _1030 = NewString("/\\:");
    _1021 = NewString("attempt to redefine %s");
    _1015 = NewString("\x09\x0A\x07");
    _668 = NewString("else");
    _930 = NewString("if ");
    _870 = NewString("%.16e");
    _869 = NewString("((1.0/sqrt(0.0)) / (1.0/sqrt(0.0)))");
    _868 = NewString("sqrt(-1.0)");
    _867 = NewString("(1.0/sqrt(0.0))");
    _859 = NewString("space_used");
    _856 = NewString("match_from");
    _854 = NewString("find_from");
    _852 = NewString("task_clock_start");
    _850 = NewString("task_clock_stop");
    _848 = NewString("task_status");
    _846 = NewString("task_list");
    _844 = NewString("task_suspend");
    _842 = NewString("task_self");
    _840 = NewString("task_yield");
    _838 = NewString("task_schedule");
    _836 = NewString("task_create");
    _834 = NewString("platform");
    _832 = NewString("system_exec");
    _830 = NewString("equal");
    _826 = NewString("peek4u");
    _824 = NewString("peek4s");
    _822 = NewString("poke4");
    _820 = NewString("call_func");
    _818 = NewString("call_proc");
    _816 = NewString("routine_id");
    _814 = NewString("c_func");
    _812 = NewString("c_proc");
    _810 = NewString("mem_set");
    _808 = NewString("mem_copy");
    _806 = NewString("get_pixel");
    _804 = NewString("pixel");
    _802 = NewString("not_bits");
    _800 = NewString("xor_bits");
    _798 = NewString("or_bits");
    _796 = NewString("and_bits");
    _794 = NewString("arctan");
    _792 = NewString("sprintf");
    _790 = NewString("call");
    _788 = NewString("poke");
    _786 = NewString("peek");
    _784 = NewString("abort");
    _782 = NewString("machine_proc");
    _780 = NewString("machine_func");
    _778 = NewString("power");
    _776 = NewString("remainder");
    _774 = NewString("date");
    _772 = NewString("system");
    _770 = NewString("log");
    _768 = NewString("tan");
    _766 = NewString("cos");
    _764 = NewString("sin");
    _762 = NewString("sqrt");
    _760 = NewString("getenv");
    _756 = NewString("close");
    _754 = NewString("open");
    _752 = NewString("command_line");
    _750 = NewString("time");
    _748 = NewString("match");
    _746 = NewString("find");
    _744 = NewString("compare");
    _740 = NewString("repeat");
    _738 = NewString("rand");
    _736 = NewString("get_key");
    _734 = NewString("gets");
    _732 = NewString("getc");
    _730 = NewString("floor");
    _728 = NewString("clear_screen");
    _726 = NewString("printf");
    _724 = NewString("print");
    _722 = NewString("prepend");
    _720 = NewString("append");
    _716 = NewString("position");
    _710 = NewString("puts");
    _708 = NewString("length");
    _706 = NewString("xor");
    _704 = NewString("without");
    _702 = NewString("with");
    _698 = NewString("not");
    _696 = NewString("by");
    _694 = NewString("global");
    _692 = NewString("function");
    _688 = NewString("or");
    _686 = NewString("and");
    _684 = NewString("to");
    _682 = NewString("constant");
    _680 = NewString("type");
    _678 = NewString("while");
    _676 = NewString("elsif");
    _674 = NewString("do");
    _670 = NewString("for");
    _666 = NewString("procedure");
    _664 = NewString("then");
    _662 = NewString("end");
    _660 = NewString("if");
    _621 = NewString("\nPress Enter\n");
    _654 = NewString("Internal Error at %s:%d - %s\n");
    _651 = NewString("Internal Error: %s\n");
    _643 = NewString("%s:%d\n%s\n");
    _640 = NewString("^\n\n");
    _639 = NewString(" ");
    _638 = NewString("\t");
    _634 = NewString("<end-of-file>\n");
    _628 = NewString("Can't create error message file: ");
    _609 = NewString("\nPress Enter to continue, q to quit\n\n");
    _599 = NewString("Warning: %s\n");
    _321 = NewDouble((double)-1.2958371958709999e+307);
    _320 = NewDouble((double)1.2958371958709999e+307);
    _277 = NewString("\\/:");
    _274 = NewString("/");
    _271 = NewString("Linux");
    _270 = NewString("WIN32");
    _269 = NewString("DOS32");
    _268 = NewString("DOS32 built for DJGPP");
    _261 = NewString("3.1.1");
    _161 = NewDouble((double)1.0000000000000000e+00);
    _151 = NewDouble((double)2.0000000000000000e+00);
    _150 = NewDouble((double)3.1415926535897931e+00);
    _98 = NewString("\t\r\n");
    _70 = NewString("\t\n\r");
    _60 = NewString("\\r");
    _57 = NewString("\\n");
    _55 = NewString("\\t");
    _34 = NewString("}");
    _25 = NewString("{");
}
