#include "C:\Users\Owner\OneDrive\euphoria\include\euphoria.h"
#include "main-.h"

int _23;
int _25;
int _34;
int _39;
int _55;
int _57;
int _60;
int _70;
int _98;
int _113;
int _122;
int _150;
int _151;
int _161;
int _261;
int _268;
int _269;
int _270;
int _271;
int _274;
int _277;
int _320;
int _321;
int _599;
int _609;
int _621;
int _623;
int _628;
int _629;
int _634;
int _638;
int _639;
int _640;
int _643;
int _648;
int _651;
int _654;
int _660;
int _662;
int _664;
int _666;
int _668;
int _670;
int _672;
int _674;
int _676;
int _678;
int _680;
int _682;
int _684;
int _686;
int _688;
int _690;
int _692;
int _694;
int _696;
int _698;
int _700;
int _702;
int _704;
int _706;
int _708;
int _710;
int _712;
int _714;
int _716;
int _718;
int _720;
int _722;
int _724;
int _726;
int _728;
int _730;
int _732;
int _734;
int _736;
int _738;
int _740;
int _742;
int _744;
int _746;
int _748;
int _750;
int _752;
int _754;
int _756;
int _758;
int _760;
int _762;
int _764;
int _766;
int _768;
int _770;
int _772;
int _774;
int _776;
int _778;
int _780;
int _782;
int _784;
int _786;
int _788;
int _790;
int _792;
int _794;
int _796;
int _798;
int _800;
int _802;
int _804;
int _806;
int _808;
int _810;
int _812;
int _814;
int _816;
int _818;
int _820;
int _822;
int _824;
int _826;
int _828;
int _830;
int _832;
int _834;
int _836;
int _838;
int _840;
int _842;
int _844;
int _846;
int _848;
int _850;
int _852;
int _854;
int _856;
int _859;
int _862;
int _867;
int _868;
int _869;
int _870;
int _913;
int _930;
int _1015;
int _1021;
int _1030;
int _1073;
int _1076;
int _1376;
int _1377;
int _1383;
int _1384;
int _1394;
int _1396;
int _1399;
int _1404;
int _1444;
int _1517;
int _1518;
int _1565;
int _1648;
int _1653;
int _1669;
int _1672;
int _1682;
int _1696;
int _1731;
int _1734;
int _1763;
int _1767;
int _1804;
int _1807;
int _1808;
int _1815;
int _1864;
int _1913;
int _1954;
int _1964;
int _1977;
int _2017;
int _2025;
int _2057;
int _2058;
int _2098;
int _2101;
int _2130;
int _2133;
int _2153;
int _2158;
int _2172;
int _2181;
int _2188;
int _2224;
int _2227;
int _2228;
int _2229;
int _2231;
int _2233;
int _2235;
int _2237;
int _2239;
int _2241;
int _2243;
int _2245;
int _2247;
int _2249;
int _2251;
int _2253;
int _2255;
int _2257;
int _2259;
int _2261;
int _2263;
int _2265;
int _2267;
int _2269;
int _2271;
int _2273;
int _2275;
int _2277;
int _2279;
int _2281;
int _2283;
int _2285;
int _2287;
int _2289;
int _2291;
int _2293;
int _2295;
int _2297;
int _2299;
int _2301;
int _2303;
int _2305;
int _2307;
int _2309;
int _2313;
int _2315;
int _2317;
int _2319;
int _2321;
int _2323;
int _2325;
int _2327;
int _2329;
int _2332;
int _2335;
int _2337;
int _2339;
int _2341;
int _2381;
int _2549;
int _2693;
int _2723;
int _2735;
int _2740;
int _2798;
int _2808;
int _2899;
int _2903;
int _2932;
int _2938;
int _2939;
int _2996;
int _3108;
int _3114;
int _3122;
int _3139;
int _3140;
int _3163;
int _3198;
int _3226;
int _3243;
int _3313;
int _3353;
int _3357;
int _3398;
int _3437;
int _3445;
int _3519;
int _3521;
int _3529;
int _3538;
int _3544;
int _3594;
int _3644;
int _3674;
int _3698;
int _3710;
int _3715;
int _3771;
int _3778;
int _3793;
int _3796;
int _3806;
int _3831;
int _3832;
int _3842;
int _3844;
int _3850;
int _3868;
int _3871;
int _3879;
int _3908;
int _3923;
int _3926;
int _3934;
int _3935;
int _3942;
int _3943;
int _3944;
int _3948;
int _3949;
int _4009;
int _4020;
int _4078;
int _4083;
int _4094;
int _4287;
int _4289;
int _4290;
int _4292;
int _4293;
int _4295;
int _4296;
int _4298;
int _4299;
int _4301;
int _4302;
int _4304;
int _4305;
int _4307;
int _4308;
int _4310;
int _4311;
int _4313;
int _4314;
int _4316;
int _4317;
int _4319;
int _4320;
int _4322;
int _4323;
int _4325;
int _4326;
int _4328;
int _4329;
int _4331;
int _4345;
int _4350;
int _4457;
int _4460;
int _4461;
int _4649;
int _4664;
int _4669;
int _4673;
int _4674;
int _4675;
int _4678;
int _4692;
int _4693;
int _4696;
int _4697;
int _4702;
int _4718;
int _4719;
int _4743;
int _4744;
int _4745;
int _4758;
int _4767;
int _4769;
int _4780;
int _4789;
int _4800;
int _4811;
int _4814;
int _4818;
int _4822;
int _4823;
int _4824;
int _4826;
int _4831;
int _4841;
int _4848;
int _4852;
int _4854;
int _4859;
int _4861;
int _4879;
int _4881;
int _4884;
int _4886;
int _4887;
int _4889;
int _4890;
int _4891;
int _4892;
int _4893;
int _4895;
int _4896;
int _4898;
int _4899;
int _4900;
int _4902;
int _4904;
int _4906;
int _4907;
int _4910;
int _4911;
int _4912;
int _4913;
int _4914;
int _4915;
int _4916;
int _4920;
int _4922;
int _4923;
int _4924;
int _4926;
int _4928;
int _4930;
int _4931;
int _4932;
int _4933;
int _4934;
int _4936;
int _4937;
int _4938;
int _4939;
int _4940;
int _4942;
int _4943;
int _4945;
int _4947;
int _4949;
int _4952;
int _4954;
int _4956;
int _4959;
int _4962;
int _4964;
int _4966;
int _4967;
int _4969;
int _4970;
int _4972;
int _4975;
int _4979;
int _4981;
int _4983;
int _4985;
int _4987;
int _4990;
int _4991;
int _4992;
int _4994;
int _4997;
int _5000;
int _5002;
int _5005;
int _5006;
int _5008;
int _5009;
int _5010;
int _5012;
int _5015;
int _5023;
int _5027;
int _5031;
int _5032;
int _5033;
int _5036;
int _5037;
int _5040;
int _5041;
int _5043;
int _5045;
int _5047;
int _5049;
int _5051;
int _5053;
int _5054;
int _5055;
int _5056;
int _5057;
int _5072;
int _5075;
int _5084;
int _5086;
int _5090;
int _5092;
int _5094;
int _5098;
int _5100;
int _5135;
int _5152;
int _5153;
int _5158;
int _5165;
int _5168;
int _5169;
int _5180;
int _5208;
int _5209;
int _5249;
int _5252;
int _5253;
int _5254;
int _5255;
int _5256;
int _5257;
int _5258;
int _5259;
int _5260;
int _5261;
int _5262;
int _5263;
int _5264;
int _5265;
int _5266;
int _5267;
int _5268;
int _5269;
int _5270;
int _5271;
int _5272;
int _5273;
int _5274;
int _5275;
int _5276;
int _5277;
int _5278;
int _5279;
int _5280;
int _5281;
int _5282;
int _5283;
int _5284;
int _5285;
int _5286;
int _5287;
int _5288;
int _5289;
int _5290;
int _5291;
int _5292;
int _5293;
int _5294;
int _5295;
int _5296;
int _5297;
int _5298;
int _5299;
int _5300;
int _5301;
int _5302;
int _5303;
int _5304;
int _5305;
int _5306;
int _5307;
int _5308;
int _5309;
int _5310;
int _5311;
int _5312;
int _5313;
int _5314;
int _5315;
int _5316;
int _5317;
int _5318;
int _5319;
int _5320;
int _5321;
int _5322;
int _5323;
int _5324;
int _5325;
int _5326;
int _5327;
int _5328;
int _5329;
int _5330;
int _5331;
int _5332;
int _5333;
int _5334;
int _5335;
int _5336;
int _5337;
int _5338;
int _5339;
int _5340;
int _5341;
int _5342;
int _5343;
int _5344;
int _5345;
int _5346;
int _5347;
int _5348;
int _5349;
int _5350;
int _5351;
int _5352;
int _5353;
int _5354;
int _5355;
int _5356;
int _5357;
int _5358;
int _5359;
int _5360;
int _5361;
int _5362;
int _5363;
int _5364;
int _5365;
int _5366;
int _5367;
int _5368;
int _5369;
int _5370;
int _5371;
int _5372;
int _5373;
int _5374;
int _5375;
int _5376;
int _5377;
int _5378;
int _5379;
int _5380;
int _5381;
int _5382;
int _5383;
int _5384;
int _5385;
int _5386;
int _5387;
int _5388;
int _5389;
int _5390;
int _5391;
int _5392;
int _5393;
int _5394;
int _5395;
int _5396;
int _5397;
int _5398;
int _5399;
int _5400;
int _5401;
int _5402;
int _5403;
int _5404;
int _5405;
int _5406;
int _5407;
int _5408;
int _5409;
int _5410;
int _5411;
int _5412;
int _5413;
int _5414;
int _5415;
int _5416;
int _5417;
int _5418;
int _5419;
int _5420;
int _5421;
int _5422;
int _5423;
int _5424;
int _5425;
int _5426;
int _5427;
int _5428;
int _5429;
int _5430;
int _5470;
int _5496;
int _5512;
int _5538;
int _5564;
int _5616;
int _5633;
int _5636;
int _5641;
int _5642;
int _5669;
int _5671;
int _5672;
int _5675;
int _5676;
int _5677;
int _5737;
int _5739;
int _5740;
int _5742;
int _5743;
int _5744;
int _5749;
int _5774;
int _5781;
int _5783;
int _5789;
int _5793;
int _5799;
int _5803;
int _5807;
int _5820;
int _5822;
int _5825;
int _5826;
int _5827;
int _5828;
int _5830;
int _5832;
int _5835;
int _5837;
int _5839;
int _5840;
int _5842;
int _5849;
int _5850;
int _5851;
int _5852;
int _5853;
int _5854;
int _5855;
int _5861;
int _5862;
int _5863;
int _5864;
int _5865;
int _5866;
int _5867;
int _5914;
int _5917;
int _5929;
int _5980;
int _6105;
int _6116;
int _6120;
int _6121;
int _6124;
int _6138;
int _6150;
int _6155;
int _6161;
int _6162;
int _6167;
int _6182;
int _6192;
int _6197;
int _6207;
int _6208;
int _6286;
int _6294;
int _6302;
int _6321;
int _6340;
int _6348;
int _6360;
int _6361;
int _6380;
int _6382;
int _6444;
int _6503;
int _6523;
int _6621;
int _6699;
int _6705;
int _6712;
int _6715;
int _6719;
int _6749;
int _6756;
int _6759;
int _6763;
int _6779;
int _6813;
int _6814;
int _6817;
int _6830;
int _6837;
int _6842;
int _6843;
int _6846;
int _6851;
int _6950;
int _6952;
int _6979;
int _7035;
int _7036;
int _7046;
int _7049;
int _7055;
int _7063;
int _7078;
int _7120;
int _7133;
int _7138;
int _7141;
int _7146;
int _7180;
int _7192;
int _7195;
int _7200;
int _7218;
int _7222;
int _7223;
int _7224;
int _7232;
int _7240;
int _7243;
int _7247;
int _7253;
int _7254;
int _7257;
int _7282;
int _7311;
int _7321;
int _7362;
int _7432;
int _7433;
int _7439;
int _7461;
int _7462;
int _7465;
int _7467;
int _7469;
int _7471;
int _7475;
int _7477;
int _7501;
int _7502;
int _7511;
int _7580;
int _7614;
int _7617;
int _7631;
int _7637;
int _7646;
int _7647;
int _7649;
int _7658;
int _7682;
int _7693;
int _7696;
int _7700;
int _7704;
int _7705;
int _7711;
int _7716;
int _7738;
int _7803;
int _7804;
int _7811;
int _7825;
int _7831;
int _7837;
int _7847;
int _7867;
int _7876;
int _7900;
int _7914;
int _7918;
int _7920;
int _7922;
int _7924;
int _7926;
int _7928;
int _7930;
int _7932;
int _7960;
int _7980;
int _7989;
int _7990;
int _7998;
int _7999;
int _8000;
int _8001;
int _8014;
int _8015;
int _8031;
int _8032;
int _8033;
int _8034;
int _8044;
int _8045;
int _8047;
int _8071;
int _8084;
int _8086;
int _8088;
int _8089;
int _8090;
int _8099;
int _8101;
int _8102;
int _8103;
int _8112;
int _8114;
int _8115;
int _8116;
int _8118;
int _8119;
int _8120;
int _8122;
int _8123;
int _8124;
int _8134;
int _8135;
int _8136;
int _8144;
int _8146;
int _8147;
int _8155;
int _8177;
int _8179;
int _8180;
int _8181;
int _8183;
int _8184;
int _8185;
int _8186;
int _8205;
int _8206;
int _8209;
int _8210;
int _8211;
int _8213;
int _8214;
int _8215;
int _8217;
int _8218;
int _8219;
int _8221;
int _8222;
int _8230;
int _8232;
int _8233;
int _8243;
int _8244;
int _8254;
int _8255;
int _8265;
int _8266;
int _8276;
int _8277;
int _8287;
int _8288;
int _8322;
int _8352;
int _8369;
int _8403;
int _8417;
int _8429;
int _8481;
int _8487;
int _8518;
int _8524;
int _8546;
int _8612;
int _8622;
int _8649;
int _8650;
int _8748;
int _8751;
int _8755;
int _8758;
int _8759;
int _8764;
int _8765;
int _8768;
int _8773;
int _8774;
int _8775;
int _8776;
int _8780;
int _8972;
int _9006;
int _9012;
int _9015;
int _9018;
int _9034;
int _9088;
int _9143;
int _9151;
int _9173;
int _9225;
int _9243;
int _9318;
int _9319;
int _9321;
int _9322;
int _9340;
int _9355;
int _9386;
int _9394;
int _9402;
int _9408;
int _9421;
int _9429;
int _9437;
int _9455;
int _9461;
int _9470;
int _9476;
int _9494;
int _9514;
int _9534;
int _9554;
int _9597;
int _9603;
int _9609;
int _9612;
int _9626;
int _9631;
int _9680;
int _9681;
int _9682;
int _9683;
int _9686;
int _9689;
int _9693;
int _9694;
int _9695;
int _9696;
int _9699;
int _9700;
int _9703;
int _9704;
int _9705;
int _9706;
int _9707;
int _9710;
int _9711;
int _9750;
int _9753;
int _9764;
int _9767;
int _9812;
int _9816;
int _9817;
int _9818;
int _9819;
int _9820;
int _9823;
int _9824;
int _9825;
int _9828;
int _9829;
int _9832;
int _9833;
int _9840;
int _9841;
int _9842;
int _9847;
int _9848;
int _9849;
int _9855;
int _9864;
int _9873;
int _9884;
int _9913;
int _9916;
int _9919;
int _9921;
int _9934;
int _9951;
int _9974;
int _9977;
int _9988;
int _9991;
int _9999;
int _10002;
int _10010;
int _10016;
int _10018;
int _10019;
int _10020;
int _10021;
int _10024;
int _10027;
int _10030;
int _10043;
int _10056;
int _10063;
int _10065;
int _10074;
int _10080;
int _10087;
int _10104;
int _10106;
int _10120;
int _10128;
int _10143;
int _10162;
int _10175;
int _10191;
int _10206;
int _10215;
int _10221;
int _10228;
int _10239;
int _10246;
int _10250;
int _10257;
int _10264;
int _10275;
int _10285;
int _10287;
int _10293;
int _10294;
int _10297;
int _10299;
int _10301;
int _10302;
int _10304;
int _10305;
int _10306;
int _10309;
int _10311;
int _10312;
int _10313;
int _10316;
int _10317;
int _10319;
int _10320;
int _10322;
int _10325;
int _10328;
int _10329;
int _10331;
int _10332;
int _10334;
int _10336;
int _10337;
int _10339;
int _10340;
int _10342;
int _10343;
int _10345;
int _10346;
int _10348;
int _10349;
int _10351;
int _10352;
int _10353;
int _10356;
int _10357;
int _10359;
int _10360;
int _10362;
int _10363;
int _10365;
int _10366;
int _10367;
int _10368;
int _10371;
int _10372;
int _10373;
int _10374;
int _10375;
int _10376;
int _10377;
int _10378;
int _10379;
int _10380;
int _10381;
int _10384;
int _10385;
int _10390;
int _10397;
int _10399;
int _10400;
int _10411;
int _10412;
int _10415;
int _10417;
int _10418;
int _10419;
int _10420;
int _10421;
int _10422;
int _10424;
int _10425;
int _10426;
int _10427;
int _10428;
int _10429;
int _10430;
int _10434;
int _10435;
int _10436;
int _10437;
int _10438;
int _10439;
int _10440;
int _10441;
int _10442;
int _10443;
int _10444;
int _10445;
int _10446;
int _10447;
int _10448;
int _10459;
int _10460;
int _10461;
int _10462;
int _10464;
int _10465;
int _10468;
int _10469;
int _10470;
int _10471;
int _10472;
int _10475;
int _10476;
int _10477;
int _10478;
int _10480;
int _10483;
int _10484;
int _10485;
int _10486;
int _10487;
int _10488;
int _10490;
int _10492;
int _10493;
int _10494;
int _10495;
int _10496;
int _10497;
int _10498;
int _10500;
int _10501;
int _10503;
int _10504;
int _10505;
int _10506;
int _10507;
int _10508;
int _10509;
int _10512;
int _10513;
int _10514;
int _10517;
int _10518;
int _10521;
int _10525;
int _10530;
int _10543;
int _10554;
int _10558;
int _10560;
int _10562;
int _10564;
int _10566;
int _10567;
int _10571;
int _10572;
int _10573;
int _10574;
int _10575;
int _10576;
int _10577;
int _10578;
int _10579;
int _10580;
int _10581;
int _10584;
int _10585;
int _10586;
int _10587;
int _10588;
int _10589;
int _10591;
int _10604;
int _10606;
int _10607;
int _10722;
int _10733;
int _10766;
int _10769;
int _10774;
int _10778;
int _10780;
int _10783;
int _10786;
int _10789;
int _10792;
int _10794;
int _10812;
int _10820;
int _10827;
int _10830;
int _10833;
int _10863;
int _10864;
int _10865;
int _10867;
int _10870;
int _10872;
int _10876;
int _10879;
int _10882;
int _10885;
int _10894;
int _10937;
int _10938;
int _10940;
int _10942;
int _10944;
int _10945;
int _10946;
int _10947;
int _10948;
int _10949;
int _10950;
int _10951;
int _10952;
int _10953;
int _10954;
int _10959;
int _10981;
int _10982;
int _10983;
int _10996;
int _11017;
int _11020;
int _11023;
int _11024;
int _11026;
int _11027;
int _11030;
int _11033;
int _11039;

int _2pretty_end_col;
int _2pretty_chars;
int _2pretty_start_col;
int _2pretty_level;
int _2pretty_file;
int _2pretty_ascii;
int _2pretty_indent;
int _2pretty_ascii_min;
int _2pretty_ascii_max;
int _2pretty_line_count;
int _2pretty_line_max;
int _2pretty_dots;
int _2pretty_fp_format;
int _2pretty_int_format;
int _2pretty_line;
int _2PI;
int _2PI_HALF;
int _3TO_LOWER;
int _4INTERPRETER_VERSION;
int _4TRANSLATOR_VERSION;
int _4mybsd;
int _4ELINUX;
int _4EWINDOWS;
int _4EDOS;
int _4w32;
int _4version_name;
int _4PATH_SEPARATOR;
int _4SLASH;
int _4SLASH_CHARS;
int _4SIZEOF_ROUTINE_ENTRY;
int _4SIZEOF_VAR_ENTRY;
int _4SIZEOF_TEMP_ENTRY;
int _4E_OTHER_EFFECT;
int _4MININT;
int _4NOVALUE;
int _4SymTab;
int _4eudir;
int _4file_name;
int _4file_name_entered;
int _4shroud_only;
int _4current_file_no;
int _4line_number;
int _4gline_number;
int _4file_start_sym;
int _4TopLevelSub;
int _4CurrentSub;
int _4num_routines;
int _4Argc;
int _4Argv;
int _4OpWarning;
int _4OpTrace;
int _4OpTypeCheck;
int _4OpProfileStatement;
int _4OpProfileTime;
int _4dj_path;
int _4wat_path;
int _4bor_path;
int _4cfile_count;
int _4cfile_size;
int _4Initializing;
int _4temp_name_type;
int _4Execute_id;
int _4Code;
int _4LineTable;
int _4slist;
int _7MAX_ADDR;
int _7LOW_ADDR;
int _7mem;
int _7check_calls;
int _6Errors;
int _6TempErrFile;
int _6TempErrName;
int _6ThisLine;
int _6bp;
int _6warning_list;
int _8keylist;
int _9emit_c_output;
int _9c_code;
int _9c_h;
int _9main_name_num;
int _9init_name_num;
int _9novalue;
int _9target;
int _9CREATE_INF;
int _9CREATE_NAN1;
int _9CREATE_NAN2;
int _9indent;
int _9temp_indent;
int _10buckets;
int _10object_type;
int _10atom_type;
int _10sequence_type;
int _10integer_type;
int _10e_routine;
int _10literal_init;
int _10lastintval;
int _10lastintsym;
int _10last_sym;
int _10BLANK_ENTRY;
int _10SEARCH_LIMIT;
int _10temps_allocated;
int _10dup_globals;
int _12SLASH;
int _12my_dir;
int _11main_path;
int _11src_file;
int _11new_include_name;
int _11new_include_space;
int _11start_include;
int _11LastLineNumber;
int _11AnyStatementProfile;
int _11AnyTimeProfile;
int _11shebang;
int _11char_class;
int _11id_char;
int _11IncludeStk;
int _11all_source;
int _11current_source;
int _11current_source_next;
int _14op_info1;
int _14op_info2;
int _14optimized_while;
int _14trace_called;
int _14last_routine_id;
int _14max_params;
int _14last_max_params;
int _14previous_op;
int _14current_sequence;
int _14lhs_ptr;
int _14lhs_subs1_copy_temp;
int _14lhs_target_temp;
int _14cg_stack;
int _14assignable;
int _14token_name;
int _14op_result;
int _15max_stack_per_call;
int _15sample_size;
int _15branch_list;
int _15short_circuit;
int _15short_circuit_B;
int _15SC1_patch;
int _15SC1_type;
int _15start_index;
int _15backed_up_tok;
int _15FuncReturn;
int _15param_num;
int _15elist;
int _15exit_list;
int _15loop_nest;
int _15stmt_nest;
int _15init_stack;
int _15side_effect_calls;
int _15factors;
int _15lhs_subs_level;
int _15left_sym;
int _15forward_expr;
int _15forward_Statement_list;
int _15mix_msg;
int _16Pass;
int _16BB_info;
int _16LeftSym;
int _16dll_option;
int _16con_option;
int _16fastfp;
int _16files_to_delete;
int _16keep;
int _16total_stack_size;
int _16deleted_routines;
int _16c_opts;
int _16file_chars;
int _16link_line;
int _16link_file;
int _16doit;
int _16cc_name;
int _16echo;
int _16file0;
int _17opnames;
int _18MAXLEN;
int _18target;
int _18in_loop;
int _18label_map;
int _18deref_str;
int _18deref_type;
int _18deref_elem_type;
int _18deref_short;
int _18deref_buff;
int _18previous_previous_op;
int _18previous_op;
int _18opcode;
int _18iii;
int _18n;
int _18t;
int _18ov;
int _18len;
int _18const_subs;
int _18sub;
int _18sym;
int _18gencode;
int _18intcode;
int _18intcode_extra;
int _18intcode2;
int _18main_name;
int _18target_type;
int _18target_elem;
int _18atom_type;
int _18target_val;
int _18np;
int _18pc;
int _18dblfn;
int _18all_done;
int _18tasks_created;
int _18operation;
int _18hex_chars;
int _20DIGITS;
int _20HEX_DIGITS;
int _20START_NUMERIC;
int _20input_file;
int _20input_string;
int _20string_next;
int _20ch;
int _20ESCAPE_CHARS;
int _20ESCAPED_CHARS;
int _19wat_option;
int _19djg_option;
int _19bor_option;
int _19lcc_option;


struct routine_list _00[] = {
  {"instance", _2instance, 0, -2, 0, 0},
  {"sleep", _2sleep, 1, -2, 1, 0},
  {"reverse", _2reverse, 2, -2, 1, 0},
  {"sprint", _2sprint, 3, -2, 1, 0},
  {"pretty_print", _2pretty_print, 9, -2, 3, 0},
  {"arccos", _2arccos, 11, -2, 1, 0},
  {"arcsin", _2arcsin, 12, -2, 1, 0},
  {"lower", _3lower, 13, -3, 1, 0},
  {"upper", _3upper, 14, -3, 1, 0},
  {"wildcard_match", _3wildcard_match, 16, -3, 2, 0},
  {"wildcard_file", _3wildcard_file, 17, -3, 2, 0},
  {"boolean", _4boolean, 18, -4, 1, 0},
  {"symtab_entry", _4symtab_entry, 19, -4, 1, 0},
  {"symtab_index", _4symtab_index, 20, -4, 1, 0},
  {"temp_index", _4temp_index, 21, -4, 1, 0},
  {"token", _4token, 22, -4, 1, 0},
  {"file", _4file, 23, -4, 1, 0},
  {"allocate", _7allocate, 31, -7, 1, 0},
  {"free", _7free, 32, -7, 1, 0},
  {"allocate_low", _7allocate_low, 33, -7, 1, 0},
  {"free_low", _7free_low, 34, -7, 1, 0},
  {"dos_interrupt", _7dos_interrupt, 35, -7, 2, 0},
  {"int_to_bytes", _7int_to_bytes, 36, -7, 1, 0},
  {"bytes_to_int", _7bytes_to_int, 37, -7, 1, 0},
  {"int_to_bits", _7int_to_bits, 38, -7, 2, 0},
  {"bits_to_int", _7bits_to_int, 39, -7, 1, 0},
  {"set_rand", _7set_rand, 40, -7, 1, 0},
  {"use_vesa", _7use_vesa, 41, -7, 1, 0},
  {"crash_message", _7crash_message, 42, -7, 1, 0},
  {"crash_file", _7crash_file, 43, -7, 1, 0},
  {"crash_routine", _7crash_routine, 44, -7, 1, 0},
  {"tick_rate", _7tick_rate, 45, -7, 1, 0},
  {"get_vector", _7get_vector, 46, -7, 1, 0},
  {"set_vector", _7set_vector, 47, -7, 2, 0},
  {"lock_memory", _7lock_memory, 48, -7, 2, 0},
  {"atom_to_float64", _7atom_to_float64, 49, -7, 1, 0},
  {"atom_to_float32", _7atom_to_float32, 50, -7, 1, 0},
  {"float64_to_atom", _7float64_to_atom, 51, -7, 1, 0},
  {"float32_to_atom", _7float32_to_atom, 52, -7, 1, 0},
  {"allocate_string", _7allocate_string, 53, -7, 1, 0},
  {"register_block", _7register_block, 54, -7, 2, 0},
  {"unregister_block", _7unregister_block, 55, -7, 1, 0},
  {"check_all_blocks", _7check_all_blocks, 56, -7, 0, 0},
  {"screen_output", _6screen_output, 57, -6, 2, 0},
  {"Warning", _6Warning, 58, -6, 1, 0},
  {"ShowWarnings", _6ShowWarnings, 59, -6, 1, 0},
  {"Cleanup", _6Cleanup, 60, -6, 1, 0},
  {"OpenErrFile", _6OpenErrFile, 61, -6, 0, 0},
  {"CompileErr", _6CompileErr, 63, -6, 1, 0},
  {"InternalErr", _6InternalErr, 65, -6, 1, 0},
  {"c_putc", _9c_putc, 66, -9, 1, 0},
  {"c_hputs", _9c_hputs, 67, -9, 1, 0},
  {"c_puts", _9c_puts, 68, -9, 1, 0},
  {"c_hprintf", _9c_hprintf, 69, -9, 2, 0},
  {"c_printf", _9c_printf, 70, -9, 2, 0},
  {"c_printf8", _9c_printf8, 71, -9, 1, 0},
  {"adjust_indent_before", _9adjust_indent_before, 72, -9, 1, 0},
  {"adjust_indent_after", _9adjust_indent_after, 73, -9, 1, 0},
  {"NewEntry", _10NewEntry, 75, -10, 7, 0},
  {"tmp_alloc", _10tmp_alloc, 76, -10, 0, 0},
  {"DefinedYet", _10DefinedYet, 78, -10, 1, 0},
  {"name_ext", _10name_ext, 79, -10, 1, 0},
  {"NewStringSym", _10NewStringSym, 80, -10, 1, 0},
  {"NewIntSym", _10NewIntSym, 81, -10, 1, 0},
  {"NewDoubleSym", _10NewDoubleSym, 82, -10, 1, 0},
  {"NewTempSym", _10NewTempSym, 83, -10, 0, 0},
  {"InitSymTab", _10InitSymTab, 84, -10, 0, 0},
  {"add_ref", _10add_ref, 85, -10, 1, 0},
  {"MarkTargets", _10MarkTargets, 86, -10, 2, 0},
  {"keyfind", _10keyfind, 87, -10, 2, 0},
  {"Hide", _10Hide, 88, -10, 1, 0},
  {"HideLocals", _10HideLocals, 90, -10, 0, 0},
  {"ExitScope", _10ExitScope, 91, -10, 0, 0},
  {"sort", _13sort, 92, -13, 1, 0},
  {"custom_sort", _13custom_sort, 93, -13, 2, 0},
  {"seek", _12seek, 97, -12, 2, 0},
  {"where", _12where, 98, -12, 1, 0},
  {"flush", _12flush, 99, -12, 1, 0},
  {"lock_file", _12lock_file, 102, -12, 3, 0},
  {"unlock_file", _12unlock_file, 103, -12, 2, 0},
  {"dir", _12dir, 104, -12, 1, 0},
  {"current_dir", _12current_dir, 105, -12, 0, 0},
  {"chdir", _12chdir, 106, -12, 1, 0},
  {"allow_break", _12allow_break, 107, -12, 1, 0},
  {"check_break", _12check_break, 108, -12, 0, 0},
  {"walk_dir", _12walk_dir, 110, -12, 3, 0},
  {"InitLex", _11InitLex, 111, -11, 0, 0},
  {"ResetTP", _11ResetTP, 112, -11, 0, 0},
  {"fetch_line", _11fetch_line, 114, -11, 1, 0},
  {"AppendSourceLine", _11AppendSourceLine, 115, -11, 0, 0},
  {"s_expand", _11s_expand, 116, -11, 1, 0},
  {"read_line", _11read_line, 117, -11, 0, 0},
  {"IncludePop", _11IncludePop, 125, -11, 0, 0},
  {"Scanner", _11Scanner, 129, -11, 0, 0},
  {"StringToken", _11StringToken, 131, -11, 0, 0},
  {"IncludeScan", _11IncludeScan, 132, -11, 0, 0},
  {"TempFree", _14TempFree, 137, -14, 1, 0},
  {"LexName", _14LexName, 139, -14, 1, 0},
  {"InitEmit", _14InitEmit, 140, -14, 0, 0},
  {"emit_opnd", _14emit_opnd, 143, -14, 1, 0},
  {"emit_addr", _14emit_addr, 144, -14, 1, 0},
  {"backpatch", _14backpatch, 146, -14, 2, 0},
  {"emit_op", _14emit_op, 151, -14, 1, 0},
  {"emit_assign_op", _14emit_assign_op, 152, -14, 1, 0},
  {"StartSourceLine", _14StartSourceLine, 153, -14, 1, 0},
  {"InitParser", _15InitParser, 158, -15, 0, 0},
  {"Expr", _15Expr, 181, 15, 0, 0},
  {"Statement_list", _15Statement_list, 195, 15, 0, 0},
  {"InitGlobals", _15InitGlobals, 197, -15, 0, 0},
  {"parser", _15parser, 201, -15, 0, 0},
  {"NewBB", _16NewBB, 203, -16, 3, 0},
  {"BB_var_obj", _16BB_var_obj, 204, -16, 1, 0},
  {"BB_var_type", _16BB_var_type, 205, -16, 1, 0},
  {"GType", _16GType, 206, -16, 1, 0},
  {"ObjValue", _16ObjValue, 207, -16, 1, 0},
  {"TypeIs", _16TypeIs, 208, -16, 2, 0},
  {"TypeIsNot", _16TypeIsNot, 209, -16, 2, 0},
  {"or_type", _16or_type, 210, -16, 2, 0},
  {"SetBBType", _16SetBBType, 211, -16, 4, 0},
  {"ok_name", _16ok_name, 212, -16, 1, 0},
  {"CName", _16CName, 213, -16, 1, 0},
  {"c_stmt", _16c_stmt, 214, -16, 2, 0},
  {"c_stmt0", _16c_stmt0, 215, -16, 1, 0},
  {"DeclareFileVars", _16DeclareFileVars, 216, -16, 0, 0},
  {"PromoteTypeInfo", _16PromoteTypeInfo, 217, -16, 0, 0},
  {"DeclareRoutineList", _16DeclareRoutineList, 218, -16, 0, 0},
  {"DeclareNameSpaceList", _16DeclareNameSpaceList, 219, -16, 0, 0},
  {"version", _16version, 221, -16, 0, 0},
  {"new_c_file", _16new_c_file, 222, -16, 1, 0},
  {"start_emake", _16start_emake, 226, -16, 0, 0},
  {"finish_emake", _16finish_emake, 227, -16, 0, 0},
  {"GenerateUserRoutines", _16GenerateUserRoutines, 228, -16, 0, 0},
  {"min", _18min, 229, 18, 2, 0},
  {"max", _18max, 230, 18, 2, 0},
  {"abs", _18abs, 231, 18, 1, 0},
  {"savespace", _18savespace, 232, 18, 0, 0},
  {"BB_temp_type", _18BB_temp_type, 233, 18, 1, 0},
  {"BB_temp_elem", _18BB_temp_elem, 234, 18, 1, 0},
  {"BB_var_elem", _18BB_var_elem, 235, 18, 1, 0},
  {"BB_var_seqlen", _18BB_var_seqlen, 236, 18, 1, 0},
  {"SeqElem", _18SeqElem, 237, 18, 1, 0},
  {"SeqLen", _18SeqLen, 238, 18, 1, 0},
  {"ObjMinMax", _18ObjMinMax, 239, 18, 1, 0},
  {"IntegerSize", _18IntegerSize, 240, 18, 2, 0},
  {"find_label", _18find_label, 241, 18, 1, 0},
  {"forward_branch_into", _18forward_branch_into, 242, 18, 2, 0},
  {"Label", _18Label, 243, 18, 1, 0},
  {"Goto", _18Goto, 244, 18, 1, 0},
  {"BB_exist", _18BB_exist, 245, 18, 1, 0},
  {"c_fixquote", _18c_fixquote, 246, 18, 1, 0},
  {"IsParameter", _18IsParameter, 247, 18, 1, 0},
  {"CRef", _18CRef, 248, 18, 1, 0},
  {"CRefn", _18CRefn, 249, 18, 2, 0},
  {"target_differs", _18target_differs, 250, 18, 4, 0},
  {"CSaveStr", _18CSaveStr, 251, 18, 5, 0},
  {"CDeRefStr", _18CDeRefStr, 252, 18, 1, 0},
  {"CDeRef", _18CDeRef, 253, 18, 1, 0},
  {"CUnaryOp", _18CUnaryOp, 254, 18, 3, 0},
  {"seg_peek1", _18seg_peek1, 255, 18, 3, 0},
  {"seg_peek4", _18seg_peek4, 256, 18, 3, 0},
  {"seg_poke1", _18seg_poke1, 257, 18, 2, 0},
  {"seg_poke4", _18seg_poke4, 258, 18, 2, 0},
  {"machine_func_type", _18machine_func_type, 259, 18, 1, 0},
  {"machine_func_elem_type", _18machine_func_elem_type, 260, 18, 1, 0},
  {"main_temps", _18main_temps, 261, 18, 0, 0},
  {"FoldInteger", _18FoldInteger, 262, 18, 4, 0},
  {"FlushDeRef", _18FlushDeRef, 263, 18, 0, 0},
  {"FinalDeRef", _18FinalDeRef, 264, 18, 1, 0},
  {"NotInRange", _18NotInRange, 265, 18, 2, 0},
  {"IntegerMultiply", _18IntegerMultiply, 266, 18, 2, 0},
  {"unary_div", _18unary_div, 267, 18, 4, 0},
  {"unary_optimize", _18unary_optimize, 268, 18, 6, 0},
  {"ifwi", _18ifwi, 269, 18, 2, 0},
  {"ifw", _18ifw, 270, 18, 3, 0},
  {"binary_op", _18binary_op, 271, 18, 9, 0},
  {"arg_list", _18arg_list, 272, 18, 1, 0},
  {"opSTARTLINE", _18opSTARTLINE, 273, 18, 0, 0},
  {"opPROC", _18opPROC, 274, 18, 0, 0},
  {"opRHS_SUBS", _18opRHS_SUBS, 275, 18, 0, 0},
  {"opNOP1", _18opNOP1, 276, 18, 0, 0},
  {"opINTERNAL_ERROR", _18opINTERNAL_ERROR, 277, 18, 0, 0},
  {"opIF", _18opIF, 278, 18, 0, 0},
  {"opINTEGER_CHECK", _18opINTEGER_CHECK, 279, 18, 0, 0},
  {"opATOM_CHECK", _18opATOM_CHECK, 280, 18, 0, 0},
  {"opASSIGN_SUBS", _18opASSIGN_SUBS, 281, 18, 0, 0},
  {"opLENGTH", _18opLENGTH, 282, 18, 0, 0},
  {"opASSIGN", _18opASSIGN, 283, 18, 0, 0},
  {"opASSIGN_I", _18opASSIGN_I, 284, 18, 0, 0},
  {"opEXIT", _18opEXIT, 285, 18, 0, 0},
  {"opRIGHT_BRACE_N", _18opRIGHT_BRACE_N, 286, 18, 0, 0},
  {"opRIGHT_BRACE_2", _18opRIGHT_BRACE_2, 287, 18, 0, 0},
  {"opPLUS1", _18opPLUS1, 288, 18, 0, 0},
  {"opRETURNT", _18opRETURNT, 289, 18, 0, 0},
  {"opGLOBAL_INIT_CHECK", _18opGLOBAL_INIT_CHECK, 290, 18, 0, 0},
  {"opLHS_SUBS", _18opLHS_SUBS, 291, 18, 0, 0},
  {"opASSIGN_OP_SLICE", _18opASSIGN_OP_SLICE, 292, 18, 0, 0},
  {"opASSIGN_SLICE", _18opASSIGN_SLICE, 293, 18, 0, 0},
  {"opRHS_SLICE", _18opRHS_SLICE, 294, 18, 0, 0},
  {"opTYPE_CHECK", _18opTYPE_CHECK, 295, 18, 0, 0},
  {"opIS_AN_INTEGER", _18opIS_AN_INTEGER, 296, 18, 0, 0},
  {"opIS_AN_ATOM", _18opIS_AN_ATOM, 297, 18, 0, 0},
  {"opIS_A_SEQUENCE", _18opIS_A_SEQUENCE, 298, 18, 0, 0},
  {"opIS_AN_OBJECT", _18opIS_AN_OBJECT, 299, 18, 0, 0},
  {"opSQRT", _18opSQRT, 300, 18, 0, 0},
  {"opSIN", _18opSIN, 301, 18, 0, 0},
  {"opCOS", _18opCOS, 302, 18, 0, 0},
  {"opTAN", _18opTAN, 303, 18, 0, 0},
  {"opARCTAN", _18opARCTAN, 304, 18, 0, 0},
  {"opLOG", _18opLOG, 305, 18, 0, 0},
  {"opNOT_BITS", _18opNOT_BITS, 306, 18, 0, 0},
  {"opFLOOR", _18opFLOOR, 307, 18, 0, 0},
  {"opNOT_IFW", _18opNOT_IFW, 308, 18, 0, 0},
  {"opNOT", _18opNOT, 309, 18, 0, 0},
  {"opUMINUS", _18opUMINUS, 310, 18, 0, 0},
  {"opRAND", _18opRAND, 311, 18, 0, 0},
  {"opDIV2", _18opDIV2, 312, 18, 0, 0},
  {"opFLOOR_DIV2", _18opFLOOR_DIV2, 313, 18, 0, 0},
  {"opGREATER_IFW", _18opGREATER_IFW, 314, 18, 0, 0},
  {"opNOTEQ_IFW", _18opNOTEQ_IFW, 315, 18, 0, 0},
  {"opLESSEQ_IFW", _18opLESSEQ_IFW, 316, 18, 0, 0},
  {"opGREATEREQ_IFW", _18opGREATEREQ_IFW, 317, 18, 0, 0},
  {"opEQUALS_IFW", _18opEQUALS_IFW, 318, 18, 0, 0},
  {"opLESS_IFW", _18opLESS_IFW, 319, 18, 0, 0},
  {"opLESS_IFW_I", _18opLESS_IFW_I, 320, 18, 0, 0},
  {"opGREATER_IFW_I", _18opGREATER_IFW_I, 321, 18, 0, 0},
  {"opEQUALS_IFW_I", _18opEQUALS_IFW_I, 322, 18, 0, 0},
  {"opNOTEQ_IFW_I", _18opNOTEQ_IFW_I, 323, 18, 0, 0},
  {"opLESSEQ_IFW_I", _18opLESSEQ_IFW_I, 324, 18, 0, 0},
  {"opGREATEREQ_IFW_I", _18opGREATEREQ_IFW_I, 325, 18, 0, 0},
  {"opMULTIPLY", _18opMULTIPLY, 326, 18, 0, 0},
  {"opPLUS", _18opPLUS, 327, 18, 0, 0},
  {"opMINUS", _18opMINUS, 328, 18, 0, 0},
  {"opOR", _18opOR, 329, 18, 0, 0},
  {"opXOR", _18opXOR, 330, 18, 0, 0},
  {"opAND", _18opAND, 331, 18, 0, 0},
  {"opDIVIDE", _18opDIVIDE, 332, 18, 0, 0},
  {"opREMAINDER", _18opREMAINDER, 333, 18, 0, 0},
  {"opFLOOR_DIV", _18opFLOOR_DIV, 334, 18, 0, 0},
  {"opAND_BITS", _18opAND_BITS, 335, 18, 0, 0},
  {"opOR_BITS", _18opOR_BITS, 336, 18, 0, 0},
  {"opXOR_BITS", _18opXOR_BITS, 337, 18, 0, 0},
  {"opPOWER", _18opPOWER, 338, 18, 0, 0},
  {"opLESS", _18opLESS, 339, 18, 0, 0},
  {"opGREATER", _18opGREATER, 340, 18, 0, 0},
  {"opEQUALS", _18opEQUALS, 341, 18, 0, 0},
  {"opNOTEQ", _18opNOTEQ, 342, 18, 0, 0},
  {"opLESSEQ", _18opLESSEQ, 343, 18, 0, 0},
  {"opGREATEREQ", _18opGREATEREQ, 344, 18, 0, 0},
  {"opSC1_AND", _18opSC1_AND, 345, 18, 0, 0},
  {"opSC1_OR", _18opSC1_OR, 346, 18, 0, 0},
  {"opSC2_OR", _18opSC2_OR, 347, 18, 0, 0},
  {"opFOR", _18opFOR, 348, 18, 0, 0},
  {"opENDFOR_GENERAL", _18opENDFOR_GENERAL, 349, 18, 0, 0},
  {"opCALL_PROC", _18opCALL_PROC, 350, 18, 0, 0},
  {"opCALL_BACK_RETURN", _18opCALL_BACK_RETURN, 351, 18, 0, 0},
  {"opBADRETURNF", _18opBADRETURNF, 352, 18, 0, 0},
  {"opRETURNF", _18opRETURNF, 353, 18, 0, 0},
  {"opRETURNP", _18opRETURNP, 354, 18, 0, 0},
  {"opROUTINE_ID", _18opROUTINE_ID, 355, 18, 0, 0},
  {"opAPPEND", _18opAPPEND, 356, 18, 0, 0},
  {"opPREPEND", _18opPREPEND, 357, 18, 0, 0},
  {"opCONCAT", _18opCONCAT, 358, 18, 0, 0},
  {"opCONCAT_N", _18opCONCAT_N, 359, 18, 0, 0},
  {"opREPEAT", _18opREPEAT, 360, 18, 0, 0},
  {"opDATE", _18opDATE, 361, 18, 0, 0},
  {"opTIME", _18opTIME, 362, 18, 0, 0},
  {"opSPACE_USED", _18opSPACE_USED, 363, 18, 0, 0},
  {"opPOSITION", _18opPOSITION, 364, 18, 0, 0},
  {"opEQUAL", _18opEQUAL, 365, 18, 0, 0},
  {"opCOMPARE", _18opCOMPARE, 366, 18, 0, 0},
  {"opFIND", _18opFIND, 367, 18, 0, 0},
  {"opFIND_FROM", _18opFIND_FROM, 368, 18, 0, 0},
  {"opMATCH", _18opMATCH, 369, 18, 0, 0},
  {"opMATCH_FROM", _18opMATCH_FROM, 370, 18, 0, 0},
  {"opPEEK", _18opPEEK, 371, 18, 0, 0},
  {"opPOKE", _18opPOKE, 372, 18, 0, 0},
  {"opMEM_COPY", _18opMEM_COPY, 373, 18, 0, 0},
  {"opMEM_SET", _18opMEM_SET, 374, 18, 0, 0},
  {"opPIXEL", _18opPIXEL, 375, 18, 0, 0},
  {"opGET_PIXEL", _18opGET_PIXEL, 376, 18, 0, 0},
  {"opCALL", _18opCALL, 377, 18, 0, 0},
  {"opSYSTEM", _18opSYSTEM, 378, 18, 0, 0},
  {"opSYSTEM_EXEC", _18opSYSTEM_EXEC, 379, 18, 0, 0},
  {"opOPEN", _18opOPEN, 380, 18, 0, 0},
  {"opCLOSE", _18opCLOSE, 381, 18, 0, 0},
  {"opGETC", _18opGETC, 382, 18, 0, 0},
  {"opGETS", _18opGETS, 383, 18, 0, 0},
  {"opGET_KEY", _18opGET_KEY, 384, 18, 0, 0},
  {"opCLEAR_SCREEN", _18opCLEAR_SCREEN, 385, 18, 0, 0},
  {"opPUTS", _18opPUTS, 386, 18, 0, 0},
  {"opPRINT", _18opPRINT, 387, 18, 0, 0},
  {"opPRINTF", _18opPRINTF, 388, 18, 0, 0},
  {"opSPRINTF", _18opSPRINTF, 389, 18, 0, 0},
  {"opCOMMAND_LINE", _18opCOMMAND_LINE, 390, 18, 0, 0},
  {"opGETENV", _18opGETENV, 391, 18, 0, 0},
  {"opMACHINE_FUNC", _18opMACHINE_FUNC, 392, 18, 0, 0},
  {"opMACHINE_PROC", _18opMACHINE_PROC, 393, 18, 0, 0},
  {"opC_FUNC", _18opC_FUNC, 394, 18, 0, 0},
  {"opC_PROC", _18opC_PROC, 395, 18, 0, 0},
  {"opTRACE", _18opTRACE, 396, 18, 0, 0},
  {"opPROFILE", _18opPROFILE, 397, 18, 0, 0},
  {"opUPDATE_GLOBALS", _18opUPDATE_GLOBALS, 398, 18, 0, 0},
  {"dll_tasking", _18dll_tasking, 399, 18, 0, 0},
  {"opTASK_CREATE", _18opTASK_CREATE, 400, 18, 0, 0},
  {"opTASK_SCHEDULE", _18opTASK_SCHEDULE, 401, 18, 0, 0},
  {"opTASK_YIELD", _18opTASK_YIELD, 402, 18, 0, 0},
  {"opTASK_SELF", _18opTASK_SELF, 403, 18, 0, 0},
  {"opTASK_SUSPEND", _18opTASK_SUSPEND, 404, 18, 0, 0},
  {"opTASK_LIST", _18opTASK_LIST, 405, 18, 0, 0},
  {"opTASK_STATUS", _18opTASK_STATUS, 406, 18, 0, 0},
  {"opTASK_CLOCK_STOP", _18opTASK_CLOCK_STOP, 407, 18, 0, 0},
  {"opTASK_CLOCK_START", _18opTASK_CLOCK_START, 408, 18, 0, 0},
  {"init_opcodes", _18init_opcodes, 409, -18, 0, 0},
  {"Execute", _18Execute, 411, -18, 1, 0},
  {"", 0, 999999999, 0, 0, 0}
};

struct ns_list _01[] = {
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern double sqrt();
    _11039 = NewString("\nPress Enter\n");
    _11033 = NewString("Can't open %s\n");
    _11030 = NewString("ex.err");
    _11027 = NewString("/usr231/home/r/h/rhc");
    _11026 = NewString("\\EUPHORIA");
    _11024 = NewString("/euphoria");
    _11023 = NewString("euphoria");
    _11020 = NewString("HOME");
    _11017 = NewString("EUDIR");
    _10996 = NewString("r");
    _10981 = NewString(".exu");
    _10982 = NewString(".exw");
    _10983 = NewString(".ex");
    _39 = NewString("");
    _10959 = NewString(" \t\n");
    _629 = NewString("\n");
    _10954 = NewString("\nfile name to translate to C? ");
    _10953 = NewString("\nfile name to execute? ");
    _10952 = NewString("\nfile name to bind/shroud? ");
    _10951 = NewString("See http://www.RapidEuphoria.com/License.txt \n");
    _10950 = NewString("Copyright (c) Rapid Deployment Software 2007 \n");
    _10949 = NewString("for 32-bit DOS.\n");
    _10948 = NewString("for 32-bit Windows.\n");
    _10947 = NewString("for DOS/Windows.\n");
    _10946 = NewString("for Linux.\n");
    _10945 = NewString("for FreeBSD.\n");
    _10944 = NewString("for Linux/FreeBSD.\n");
    _10938 = NewString(" ");
    _10942 = NewString("Euphoria Binder ");
    _10940 = NewString("Euphoria to C Translator ");
    _10937 = NewString("Euphoria Interpreter ");
    _10820 = NewString("PATH");
    _10885 = NewString("WATCOM environment variable is not set");
    _10894 = NewString("Can't find Borland installation directory");
    _10876 = NewString("WATCOM");
    _10882 = NewString("DJGPP environment variable is not set");
    _10879 = NewString("C:\\WATCOM");
    _10872 = NewString("DJGPP");
    _10870 = NewString("Can't open main-.h file for output\n");
    _10412 = NewString("w");
    _10867 = NewString("main-.h");
    _10425 = NewString("#include \"main-.h\"\n\n");
    _10865 = NewString("euphoria.h\"\n");
    _10864 = NewString("include");
    _10419 = NewString("#include \"");
    _10863 = NewString("Can't open init-.c for output\n");
    _10508 = NewString("init-.c");
    _10827 = NewString("BORLAND\\BCC");
    _10830 = NewString("\\BCC");
    _10833 = NewString("BORLAND\\");
    _10812 = NewString("unknown option: ");
    _10794 = NewString("-STACK");
    _10792 = NewString("-BOR");
    _10789 = NewString("-LCC");
    _10786 = NewString("-FASTFP");
    _10783 = NewString("-DJG");
    _10780 = NewString("-KEEP");
    _10778 = NewString("-WAT");
    _10774 = NewString("-CON");
    _10766 = NewString("-DLL");
    _10769 = NewString("-SO");
    _10733 = NewString("A number from %g to %g is expected here - try again\n");
    _10722 = NewString("A number is expected - try again\n");
    _10607 = NewString("\n\t'\"\\\r");
    _10606 = NewString("nt'\"\\r");
    _10604 = NewString(" \t\n\r");
    _10591 = NewString("-+.#");
    _10589 = NewString("ABCDEF");
    _10588 = NewString("0123456789");
    _10587 = NewString("To build your .exe file, type: emake\n");
    _10586 = NewString("To build your .dll file, type: emake\n");
    _10585 = NewString("To build your executable file, type: ./emake\n");
    _10584 = NewString("To build your shared library, type: ./emake\n");
    _10581 = NewString("\n%d .c files were created.\n");
    _10580 = NewString("extern void *winInstance;\n\n");
    _10579 = NewString("extern int current_task;\n");
    _10578 = NewString("extern struct tcb *tcb;\n");
    _10577 = NewString("extern void *xstdin;\n");
    _10576 = NewString("extern int in_from_keyb;\n");
    _10575 = NewString("extern void *last_r_file_ptr;\n");
    _10574 = NewString("extern object last_r_file_no;\n");
    _10573 = NewString("extern s1_ptr *assign_slice_seq;\n");
    _10572 = NewString("extern object_ptr rhs_slice_target;\n");
    _10571 = NewString("extern int TraceOn;\n");
    _6207 = NewString("}\n");
    _10567 = NewString("\");\n");
    _10566 = NewString("\\\\");
    _10564 = NewString("\\\"");
    _10562 = NewString("\\r");
    _10560 = NewString("\\n");
    _10558 = NewString("\\t");
    _10554 = NewString("\"\n\"");
    _10543 = NewString("\n\t\r");
    _10530 = NewString("%d = NewString(\"");
    _4675 = NewString(");\n");
    _10525 = NewString("%d = NewDouble((double)");
    _10521 = NewString("_");
    _10514 = NewString("extern double sqrt();\n");
    _5169 = NewString("{\n");
    _7649 = NewString("%d()\n");
    _10517 = NewString("init_literal");
    _10518 = NewString("init-%d");
    _7647 = NewString("%d();\n");
    _10513 = NewString("void init_literal()\n{\n");
    _10512 = NewString("Can't open init-.c for append\n");
    _10509 = NewString("a");
    _10507 = NewString("return 1;\n");
    _10506 = NewString("EuInit();\n");
    _10505 = NewString("if (Reason == 1)\n");
    _10504 = NewString("int __declspec (dllexport) __stdcall DllMain(int hDLL, int Reason, void *Reserved)\n");
    _10503 = NewString("int __stdcall LibMain(int hDLL, int Reason, void *Reserved)\n");
    _10501 = NewString("Cleanup(0);\n");
    _4460 = NewString(";\n");
    _10500 = NewString("shift_args(argc, argv);\n");
    _10498 = NewString("init_literal();\n");
    _10497 = NewString("#endif\n");
    _10496 = NewString("eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)sysconf(_SC_CLK_TCK));\n");
    _10495 = NewString("#else\n");
    _10493 = NewString("eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)CLK_TCK);\n");
    _10494 = NewString("#ifdef CLK_TCK\n");
    _10492 = NewString("eu_startup(_00, _01, 1, (int)CLOCKS_PER_SEC, (int)CLOCKS_PER_SEC);\n");
    _10490 = NewString("stack_base = (char *)&_0;\n");
    _10484 = NewString("Argv = argv;\n");
    _10483 = NewString("Argc = argc;\n");
    _10471 = NewString("\nArgc = 0;\n");
    _10488 = NewString("winInstance = hInstance;\n");
    _10487 = NewString("argv = make_arg_cv(szCmdLine, &argc);\n");
    _10486 = NewString("Argc = 1;\n");
    _10485 = NewString("argc = 1;\n");
    _10472 = NewString("default_heap = GetProcessHeap();\n");
    _10480 = NewString("_control87(MCW_EM,MCW_EM);\n");
    _10478 = NewString("char **argv;\n\n");
    _10477 = NewString("int argc;\n");
    _10476 = NewString("hInstance = 0;\n");
    _10475 = NewString("void *hInstance;\n\n");
    _10468 = NewString("\nvoid main(int argc, char *argv[])\n");
    _10470 = NewString("\nvoid _init()\n");
    _10469 = NewString("\nvoid __stdcall WinMain(void *hInstance, void *hPrevInstance, char *szCmdLine, int iCmdShow)\n");
    _10465 = NewString("\nvoid EuInit()\n");
    _10464 = NewString("\nint __stdcall _CRT_INIT (int, int, void *);\n");
    _10462 = NewString("extern long bytes_allocated;\n");
    _10461 = NewString("extern int total_stack_size;\n");
    _10460 = NewString("int total_stack_size = %d;\n");
    _10459 = NewString("unsigned _stklen=%d;\n");
    _10448 = NewString("extern char *stack_base;\n");
    _10447 = NewString("char *stack_base;\n");
    _10446 = NewString("extern double temp_dbl;\n");
    _10445 = NewString("double temp_dbl;\n");
    _10444 = NewString("extern struct d temp_d;\n");
    _10443 = NewString("struct d temp_d;\n");
    _10442 = NewString("extern unsigned long *poke4_addr;\n");
    _10441 = NewString("unsigned long *poke4_addr;\n");
    _10440 = NewString("extern unsigned char *poke_addr;\n");
    _10439 = NewString("unsigned char *poke_addr;\n");
    _10438 = NewString("extern unsigned long *peek4_addr;\n");
    _10437 = NewString("unsigned long *peek4_addr;\n");
    _10436 = NewString("extern __Go32_Info_Block _go32_info_block;\n");
    _10435 = NewString("unsigned __stdcall GetProcessHeap(void);\n");
    _10434 = NewString("__declspec(dllimport) unsigned __stdcall GetProcessHeap(void);\n");
    _10430 = NewString("unsigned default_heap;\n");
    _10429 = NewString("extern char **Argv;\n");
    _10428 = NewString("char **Argv;\n");
    _10427 = NewString("extern int Argc;\n");
    _10426 = NewString("int Argc;\n");
    _10424 = NewString("#include <float.h>\n");
    _10422 = NewString("\\include\\euphoria.h\"\n");
    _10421 = NewString("#include <unistd.h>\n");
    _10420 = NewString("/include/euphoria.h\"\n");
    _10418 = NewString("#include <time.h>\n");
    _10417 = NewString("#include <go32.h>\n");
    _10415 = NewString("Can't open main-.c for output\n");
    _10411 = NewString("main-.c");
    _10400 = NewString("\\x");
    _10399 = NewString("0123456789ABCDEF");
    _10397 = NewString("Execute");
    _10390 = NewString("no routine id for op");
    _10385 = NewString("op");
    _10384 = NewString("INTERNAL_ERROR");
    _10381 = NewString("NOP2");
    _10380 = NewString("END_PARAM_CHECK");
    _10379 = NewString("ENDFOR_INT_DOWN");
    _10378 = NewString("PLATFORM");
    _10377 = NewString("ASSIGN_SUBS2");
    _10376 = NewString("ENDFOR_INT_DOWN1");
    _10375 = NewString("ENDFOR_DOWN");
    _10374 = NewString("SC2_NULL");
    _10373 = NewString("ENDFOR_UP");
    _10372 = NewString("ENDFOR_INT_UP");
    _10371 = NewString("PROFILE");
    _10368 = NewString("ERASE_SYMBOL");
    _10367 = NewString("ERASE_PRIVATE_NAMES");
    _10366 = NewString("DISPLAY_VAR");
    _10365 = NewString("PRINT");
    _10363 = NewString("QPRINT");
    _10362 = NewString("CLOSE");
    _10360 = NewString("ABORT");
    _10359 = NewString("POKE");
    _10357 = NewString("POKE4");
    _10356 = NewString("PEEK");
    _10353 = NewString("PEEK4S");
    _10352 = NewString("PEEK4U");
    _10351 = NewString("CALL_PROC");
    _10349 = NewString("CALL_FUNC");
    _10348 = NewString("ENDFOR_GENERAL");
    _10346 = NewString("ENDFOR_INT_UP1");
    _10345 = NewString("FOR");
    _10343 = NewString("FOR_I");
    _10342 = NewString("SC2_OR");
    _10340 = NewString("SC2_AND");
    _10339 = NewString("SC1_OR");
    _10337 = NewString("SC1_OR_IF");
    _10336 = NewString("SC1_AND");
    _5399 = NewString("SC1_AND_IF");
    _10334 = NewString("MINUS");
    _10332 = NewString("MINUS_I");
    _10331 = NewString("PLUS");
    _10329 = NewString("PLUS_I");
    _10328 = NewString("ASSIGN_SLICE");
    _5416 = NewString("PASSIGN_SLICE");
    _5403 = NewString("ASSIGN_OP_SLICE");
    _5418 = NewString("PASSIGN_OP_SLICE");
    _10325 = NewString("LHS_SUBS");
    _5419 = NewString("LHS_SUBS1_COPY");
    _5414 = NewString("LHS_SUBS1");
    _10322 = NewString("GLOBAL_INIT_CHECK");
    _10320 = NewString("PRIVATE_INIT_CHECK");
    _10319 = NewString("PLUS1");
    _10317 = NewString("PLUS1_I");
    _10316 = NewString("EXIT");
    _10313 = NewString("ENDWHILE");
    _10312 = NewString("ELSE");
    _10311 = NewString("LENGTH");
    _5413 = NewString("PLENGTH");
    _10309 = NewString("ASSIGN_SUBS");
    _5415 = NewString("PASSIGN_SUBS");
    _10306 = NewString("ASSIGN_SUBS_I");
    _10305 = NewString("ASSIGN_SUBS_CHECK");
    _10304 = NewString("ATOM_CHECK");
    _10302 = NewString("SEQUENCE_CHECK");
    _10301 = NewString("IF");
    _10299 = NewString("WHILE");
    _5412 = NewString("NOP1");
    _5411 = NewString("NOPWHILE");
    _10297 = NewString("RHS_SUBS");
    _10294 = NewString("RHS_SUBS_I");
    _10293 = NewString("RHS_SUBS_CHECK");
    _5417 = NewString("PASSIGN_OP_SUBS");
    _5402 = NewString("ASSIGN_OP_SUBS");
    _10287 = NewString("task_clock_start();\n");
    _10285 = NewString("task_clock_stop();\n");
    _5774 = NewString("_0");
    _10275 = NewString("@ = task_status(@);\n");
    _10264 = NewString("@ = task_list();\n");
    _10257 = NewString("task_suspend(@);\n");
    _10250 = NewString("@ = NewDouble(tcb[current_task].tid);\n");
    _10246 = NewString("task_yield();\n");
    _10239 = NewString("task_schedule(@, @);\n");
    _10228 = NewString("@ = task_create(@, @);\n");
    _10221 = NewString("Multitasking operations are not supported in a .dll or .so");
    _10215 = NewString("TraceOn = DBL_PTR(@)->dbl != 0.0;\n");
    _5799 = NewString("else\n");
    _5781 = NewString("\x04\x10");
    _10206 = NewString("TraceOn = @;\n");
    _6197 = NewString("\x01\x04\x10");
    _5783 = NewString("if (IS_ATOM_INT(@))\n");
    _10191 = NewString("call_c(0, @, @);\n");
    _10175 = NewString("@ = call_c(1, @, @);\n");
    _10162 = NewString("machine(@, @);\n");
    _10143 = NewString("@ = machine(@, @);\n");
    _10128 = NewString("@ = EGetEnv(@);\n");
    _10120 = NewString("@ = Command_Line();\n");
    _10106 = NewString(", @, @);\n");
    _9018 = NewString("%d");
    _10104 = NewString("@ = EPrintf(");
    _10087 = NewString("EPrintf(@, @, @);\n");
    _10080 = NewString("StdPrint(@, @, 0);\n");
    _10074 = NewString("StdPrint(@, @, 1);\n");
    _10065 = NewString("EPuts(@, @);\n");
    _10063 = NewString("ClearScreen();\n");
    _10056 = NewString("@ = get_key(0);\n");
    _10019 = NewString("show_console();\n");
    _10043 = NewString("@ = EGets(@);\n");
    _10030 = NewString("@ = getc(last_r_file_ptr);\n");
    _10027 = NewString("@ = wingetch();\n");
    _10024 = NewString("@ = getc(xstdin);\n");
    _10021 = NewString("@ = mgetch(1);\n");
    _10020 = NewString("if (in_from_keyb) {\n");
    _10018 = NewString("if (last_r_file_ptr == xstdin) {\n");
    _10016 = NewString("last_r_file_no = NOVALUE;\n");
    _10010 = NewString("last_r_file_no = @;\n");
    _10002 = NewString("last_r_file_ptr = which_file(@, EF_READ);\n");
    _9999 = NewString("if (@ != last_r_file_no) {\n");
    _9991 = NewString("EClose((int)DBL_PTR(@)->dbl);\n");
    _9988 = NewString("UserCleanup((int)DBL_PTR(@)->dbl);\n");
    _9977 = NewString("EClose(@);\n");
    _9974 = NewString("UserCleanup(@);\n");
    _9951 = NewString("@ = EOpen(@, @);\n");
    _9934 = NewString("@ = system_exec_call(@, @);\n");
    _9921 = NewString("system_call(@, @);\n");
    _9919 = NewString("(*(void(*)())_0)();\n");
    _9916 = NewString("_0 = (int)(unsigned long)(DBL_PTR(@)->dbl);\n");
    _9913 = NewString("_0 = (int)@;\n");
    _9884 = NewString("@ = Get_Pixel(@);\n");
    _9873 = NewString("Pixel(@, @);\n");
    _9864 = NewString("memory_set(@, @, @);\n");
    _9855 = NewString("memory_copy(@, @, @);\n");
    _9849 = NewString("*poke_addr++ = (signed char)DBL_PTR(_2)->dbl;\n");
    _9848 = NewString("*poke_addr++ = (signed char)_0;\n");
    _9847 = NewString("_0 = (signed char)DBL_PTR(_2)->dbl;\n");
    _9842 = NewString("*(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;\n");
    _9841 = NewString("*(int *)poke4_addr++ = (unsigned long)_0;\n");
    _9840 = NewString("_0 = (unsigned long)DBL_PTR(_2)->dbl;\n");
    _6208 = NewString("else {\n");
    _8780 = NewString("break;\n");
    _9825 = NewString("else if (_2 == NOVALUE)\n");
    _9833 = NewString("*poke_addr++ = (unsigned char)_2;\n");
    _9832 = NewString("*(int *)poke4_addr++ = (unsigned long)_2;\n");
    _9820 = NewString("if (IS_ATOM_INT(_2))\n");
    _9819 = NewString("_2 = *((int *)_1);\n");
    _9818 = NewString("_1 += 4;\n");
    _9817 = NewString("while (1) {\n");
    _9829 = NewString("_farpokeb(_go32_info_block.selector_for_linear_memory, (unsigned long)(poke_addr++), (unsigned char)DBL_PTR(_2)->dbl);\n");
    _9828 = NewString("_farpokel(_go32_info_block.selector_for_linear_memory, (unsigned long)(poke4_addr++), (unsigned long)DBL_PTR(_2)->dbl);\n");
    _9824 = NewString("_farpokeb(_go32_info_block.selector_for_linear_memory, (unsigned long)(poke_addr++), (unsigned char)_2);\n");
    _9823 = NewString("_farpokel(_go32_info_block.selector_for_linear_memory, (unsigned long)(poke4_addr++), (unsigned long)_2);\n");
    _9693 = NewString("if ((unsigned)poke_addr <= LOW_MEMORY_MAX) {\n");
    _9816 = NewString("if ((unsigned)poke4_addr <= LOW_MEMORY_MAX) {\n");
    _9812 = NewString("_1 = (int)((s1_ptr)_1)->base;\n");
    _8748 = NewString("_1 = (int)SEQ_PTR(@);\n");
    _4094 = NewString("\x08\x10");
    _9631 = NewString("\x01\x08");
    _9626 = NewString("else if (IS_ATOM(@)) {\n");
    _6192 = NewString("if (IS_ATOM_INT(@)) {\n");
    _9767 = NewString("poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(@)->dbl);\n");
    _9764 = NewString("poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(@)->dbl);\n");
    _9753 = NewString("poke_addr = (unsigned char *)@;\n");
    _9750 = NewString("poke4_addr = (unsigned long *)@;\n");
    _7867 = NewString("\x01\x04\x02");
    _9707 = NewString("*(int *)poke4_addr = _1;\n");
    _9706 = NewString("_1 = NewDouble((double)(unsigned long)_1);\n");
    _9705 = NewString("if ((unsigned)_1 > (unsigned)MAXINT)\n");
    _9704 = NewString("_1 = NewDouble((double)(long)_1);\n");
    _9703 = NewString("if (_1 < MININT || _1 > MAXINT)\n");
    _9711 = NewString("_1 = (int)*peek4_addr++;\n");
    _9710 = NewString("*(int *)poke4_addr = *poke_addr++;\n");
    _9696 = NewString("poke4_addr++;\n");
    _9695 = NewString("while (--_2 >= 0) {\n");
    _9700 = NewString("_1 = _farpeekl(_go32_info_block.selector_for_linear_memory, (unsigned)(peek4_addr++));\n");
    _9699 = NewString("*(int *)poke4_addr = _farpeekb(_go32_info_block.selector_for_linear_memory, (unsigned)(poke_addr++));\n");
    _9694 = NewString("if ((unsigned)peek4_addr <= LOW_MEMORY_MAX) {\n");
    _9689 = NewString("poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;\n");
    _9686 = NewString("@ = MAKE_SEQ(poke4_addr);\n");
    _9683 = NewString("poke4_addr = (unsigned long *)NewS1(_2);\n");
    _9682 = NewString("_2 = get_pos_int(\"peek\", *(((s1_ptr)_1)->base+2));\n");
    _9681 = NewString("peek4_addr = (unsigned long *)get_pos_int(\"peek4s/peek4u\", *(((s1_ptr)_1)->base+1));\n");
    _9680 = NewString("poke_addr = (unsigned char *)get_pos_int(\"peek\", *(((s1_ptr)_1)->base+1));\n");
    _9612 = NewString("@ = NewDouble((double)(unsigned long)@);\n");
    _9609 = NewString("if ((unsigned)@ > (unsigned)MAXINT)\n");
    _9603 = NewString("@ = NewDouble((double)(long)@);\n");
    _9597 = NewString("if (@ < MININT || @ > MAXINT)\n");
    _9554 = NewString("@ = e_match_from(@, @, @);\n");
    _9534 = NewString("@ = e_match(@, @);\n");
    _9514 = NewString("@ = find_from(@, @, @);\n");
    _9494 = NewString("@ = find(@, @);\n");
    _9476 = NewString("@ = compare(@, @);\n");
    _9470 = NewString("(@ > @);\n");
    _9461 = NewString("@ = (@ < @) ? -1 : ");
    _9455 = NewString("if (IS_ATOM_INT(@) && IS_ATOM_INT(@))\n");
    _9437 = NewString("@ = (compare(@, @) == 0);\n");
    _7831 = NewString("@ = 0;\n");
    _9429 = NewString("else if (IS_ATOM_INT(@) && IS_ATOM_INT(@))\n");
    _7825 = NewString("@ = 1;\n");
    _9421 = NewString("if (@ == @)\n");
    _9408 = NewString("Position(@, @);\n");
    _9402 = NewString("@ = bytes_allocated;\n");
    _9394 = NewString("@ = NewDouble(current_time());\n");
    _9386 = NewString("@ = Date();\n");
    _9355 = NewString("@ = Repeat(@, @);\n");
    _5677 = NewString(", %d);\n");
    _9340 = NewString("Concat_N((object_ptr)&@, concat_list");
    _9322 = NewString("%d] = ");
    _9321 = NewString("concat_list[");
    _9319 = NewString("%d];\n\n");
    _9318 = NewString("int concat_list[");
    _9243 = NewString("\x08\x04");
    _9225 = NewString("Concat((object_ptr)&@, @, (s1_ptr)@);\n");
    _9088 = NewString("Prepend(&@, @, @);\n");
    _9151 = NewString("\x10\x08");
    _9173 = NewString("else if (IS_ATOM(@) && IS_SEQUENCE(@)) {\n");
    _9034 = NewString("Append(&@, @, @);\n");
    _9143 = NewString("if (IS_SEQUENCE(@) && IS_ATOM(@)) {\n");
    _5807 = NewString(", @);\n");
    _9015 = NewString("%d, ");
    _9012 = NewString("@ = CRoutineId(");
    _9006 = NewString("return 0;\n");
    _8972 = NewString("return ");
    _7200 = NewString("@ = _1;\n");
    _8776 = NewString("(*(int (*)())_0)(\n");
    _8774 = NewString("_1 = (*(int (*)())_0)(\n");
    _8775 = NewString("(*(int (__stdcall *)())_0)(\n");
    _8773 = NewString("_1 = (*(int (__stdcall *)())_0)(\n");
    _8768 = NewString("if (_00[@].convention) {\n");
    _8765 = NewString("%d));\n");
    _8764 = NewString("Ref(*(int *)(_2+");
    _8759 = NewString("%d:\n");
    _8758 = NewString("case ");
    _8755 = NewString("switch(((s1_ptr)_1)->length) {\n");
    _8751 = NewString("_0 = (int)_00[@].addr;\n");
    _7439 = NewString("_2 = (int)((s1_ptr)_1)->base;\n");
    _6621 = NewString("if (IS_ATOM_INT(@) && IS_ATOM_INT(@)) {\n");
    _8088 = NewString("@1 = @2 + @3;\n");
    _8090 = NewString("@1 = NewDouble((double)@1);\n");
    _8650 = NewString("if ((long)((unsigned long)@1 +(unsigned long) HIGH_BITS) >= 0) \n");
    _8649 = NewString("@ = binary_op_a(PLUS, @, @);\n");
    _8524 = NewString("if (binary_op_a(LESS, @, @))\n");
    _8487 = NewString("if (binary_op_a(GREATER, @, @))\n");
    _8622 = NewString("if (DBL_PTR(@)->dbl >= 0.0) {\n");
    _8612 = NewString("else if (IS_ATOM_INT(@)) {\n");
    _8546 = NewString("if (@ >= 0) {\n");
    _8518 = NewString("if (@ < @)\n");
    _8481 = NewString("if (@ > @)\n");
    _7362 = NewString("@ = @;\n");
    _8429 = NewString("{ int @;\n");
    _8417 = NewString("@ = DBL_PTR(@)->dbl != 0.0;\n");
    _8403 = NewString("@ = (@ != 0);\n");
    _8369 = NewString("if (DBL_PTR(@)->dbl != 0.0) {\n");
    _8352 = NewString("if (@ != 0) {\n");
    _8322 = NewString("if (DBL_PTR(@)->dbl == 0.0) {\n");
    _7141 = NewString("if (@ == 0) {\n");
    _6286 = NewString(">=");
    _8288 = NewString("@ = (@ >= @);\n");
    _8287 = NewString("@ = binary_op(GREATEREQ, @, @);\n");
    _6294 = NewString("<=");
    _8277 = NewString("@ = (@ <= @);\n");
    _8276 = NewString("@ = binary_op(LESSEQ, @, @);\n");
    _6302 = NewString("!=");
    _8266 = NewString("@ = (@ != @);\n");
    _8265 = NewString("@ = binary_op(NOTEQ, @, @);\n");
    _6321 = NewString("==");
    _8255 = NewString("@ = (@ == @);\n");
    _8254 = NewString("@ = binary_op(EQUALS, @, @);\n");
    _6340 = NewString(">");
    _8244 = NewString("@ = (@ > @);\n");
    _8243 = NewString("@ = binary_op(GREATER, @, @);\n");
    _6348 = NewString("<");
    _8233 = NewString("@ = (@ < @);\n");
    _8232 = NewString("@ = binary_op(LESS, @, @);\n");
    _8230 = NewString("Dpower");
    _8222 = NewString("@ = power(@, @);\n");
    _8221 = NewString("@ = binary_op(POWER, @, @);\n");
    _8219 = NewString("Dxor_bits");
    _8218 = NewString("@ = (@ ^ @);\n");
    _8217 = NewString("@ = binary_op(XOR_BITS, @, @);\n");
    _8215 = NewString("Dor_bits");
    _8214 = NewString("@ = (@ | @);\n");
    _8213 = NewString("@ = binary_op(OR_BITS, @, @);\n");
    _8211 = NewString("Dand_bits");
    _8210 = NewString("@ = (@ & @);\n");
    _8209 = NewString("@ = binary_op(AND_BITS, @, @);\n");
    _8206 = NewString("@1 = NewDouble(temp_dbl);\n");
    _8186 = NewString("@1 = (long)temp_dbl;\n");
    _8205 = NewString("if (@2 != MININT)\n");
    _8185 = NewString("temp_dbl = floor((double)@2 / (double)@3);\n");
    _8184 = NewString("@1 = @2 / @3;\n");
    _8183 = NewString("if (@3 > 0 && @2 >= 0) {\n");
    _8181 = NewString("DeRef(_2);\n");
    _8180 = NewString("@1 = unary_op(FLOOR, _2);\n");
    _8179 = NewString("_2 = binary_op(DIVIDE, @2, @3);\n");
    _8177 = NewString("Dremainder");
    _8155 = NewString("RTFatal(\"remainder of a number divided by 0\");\n");
    _8147 = NewString("@ = (@ % @);\n");
    _8146 = NewString("@ = binary_op(REMAINDER, @, @);\n");
    _8144 = NewString("/");
    _8136 = NewString("@1 = (@2 % @3) ? NewDouble((double)@2 / @3) : (@2 / @3);\n");
    _8135 = NewString("@ = binary_op(DIVIDE, @, @);\n");
    _8134 = NewString("RTFatal(\"divide by 0\");\n");
    _8124 = NewString("Dand");
    _8123 = NewString("@ = (@ != 0 && @ != 0);\n");
    _8122 = NewString("@ = binary_op(AND, @, @);\n");
    _8120 = NewString("Dxor");
    _8119 = NewString("@ = ((@ != 0) != (@ != 0));\n");
    _8118 = NewString("@ = binary_op(XOR, @, @);\n");
    _8116 = NewString("Dor");
    _8115 = NewString("@ = (@ != 0 || @ != 0);\n");
    _8114 = NewString("@ = binary_op(OR, @, @);\n");
    _8112 = NewString("-");
    _8103 = NewString("if ((long)((unsigned long)@1 +(unsigned long) HIGH_BITS) >= 0)\n");
    _8102 = NewString("@1 = @2 - @3;\n");
    _8101 = NewString("@ = binary_op(MINUS, @, @);\n");
    _8099 = NewString("+");
    _8089 = NewString("if ((long)((unsigned long)@1 + (unsigned long)HIGH_BITS) >= 0) \n");
    _8086 = NewString("@ = binary_op(PLUS, @, @);\n");
    _8084 = NewString("*");
    _6182 = NewString("@1 = @2 * @3;\n");
    _8071 = NewString("@ = binary_op(MULTIPLY, @, @);\n");
    _5253 = NewString("GREATEREQ");
    _5255 = NewString("NOTEQ");
    _5252 = NewString("LESS");
    _5257 = NewString("GREATER");
    _5254 = NewString("EQUALS");
    _5256 = NewString("LESSEQ");
    _8047 = NewString("@ = @ >> 1;\n");
    _7257 = NewString("DeRef(_1);\n");
    _8045 = NewString("@1 = unary_op(FLOOR, _1);\n");
    _8044 = NewString("_1 = binary_op(DIVIDE, @2, 2);\n");
    _8034 = NewString("@1 = @2 >> 1;\n");
    _8033 = NewString("@1 = NewDouble((@2 >> 1) + 0.5);\n");
    _8032 = NewString("if (@2 & 1) {\n");
    _8031 = NewString("@ = binary_op(DIVIDE, @, 2);\n");
    _8015 = NewString("@ = good_rand() % ((unsigned)@) + 1;\n");
    _8014 = NewString("@ = unary_op(RAND, @);\n");
    _7999 = NewString("@1 = - @2;\n");
    _8001 = NewString("@1 = (int)NewDouble((double)-0xC0000000);\n");
    _8000 = NewString("if (@2 == 0xC0000000)\n");
    _7998 = NewString("@ = unary_op(UMINUS, @);\n");
    _7990 = NewString("@ = (@ == 0);\n");
    _7989 = NewString("@ = unary_op(NOT, @);\n");
    _7980 = NewString("if (DBL_PTR(@)->dbl != 0.0)\n");
    _7960 = NewString("if (@ != 0)\n");
    _5334 = NewString("FLOOR");
    _7932 = NewString("e_floor");
    _5302 = NewString("NOT_BITS");
    _7930 = NewString("not_bits");
    _5325 = NewString("LOG");
    _7928 = NewString("e_log");
    _5324 = NewString("ARCTAN");
    _7926 = NewString("e_arctan");
    _5333 = NewString("TAN");
    _7924 = NewString("e_tan");
    _5332 = NewString("COS");
    _7922 = NewString("e_cos");
    _5331 = NewString("SIN");
    _7920 = NewString("e_sin");
    _5292 = NewString("SQRT");
    _7918 = NewString("e_sqrt");
    _7914 = NewString("\x01\x01");
    _7900 = NewString("@ = IS_SEQUENCE(@);\n");
    _7876 = NewString("@ = IS_ATOM(@);\n");
    _7837 = NewString("@ = IS_ATOM_INT(DoubleToInt(@));\n");
    _7847 = NewString("else if (IS_ATOM_DBL(@))\n");
    _7803 = NewString("RTFatal(\"user-defined type_check failure\");\n");
    _7811 = NewString("if (!(IS_ATOM_DBL(@) && DBL_PTR(@)->dbl != 0.0))\n");
    _7192 = NewString("if (!IS_ATOM_INT(@)) {\n");
    _7180 = NewString("if (@ == 0)\n");
    _7804 = NewString("if (@ != 1) {\n");
    _7716 = NewString("RHS_Slice((s1_ptr)@, @, @);\n");
    _7700 = NewString("rhs_slice_target = (object_ptr)&@;\n");
    _7738 = NewString("AssignSlice(@, @, @);\n");
    _7711 = NewString("assign_slice_seq = (s1_ptr *)&@;\n");
    _7704 = NewString("assign_slice_seq = (s1_ptr *)_3;\n");
    _7705 = NewString("RHS_Slice((s1_ptr)*(int *)_3, @, @);\n");
    _7696 = NewString("_3 = (int)(@ + ((s1_ptr)_2)->base);\n");
    _7693 = NewString("_3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(@)->dbl));\n");
    _7046 = NewString("if (!IS_ATOM_INT(@))\n");
    _7232 = NewString("@ = MAKE_SEQ(_2);\n");
    _7682 = NewString("*(object_ptr)_3 = MAKE_SEQ(_2);\n");
    _7223 = NewString("_2 = (int)SequenceCopy((s1_ptr)_2);\n");
    _7222 = NewString("if (!UNIQUE(_2)) {\n");
    _7036 = NewString("_2 = (int)SEQ_PTR(@);\n");
    _7063 = NewString("Ref(@);\n");
    _6105 = NewString("DeRef(@);\n");
    _7658 = NewString("_2 = (int)SEQ_PTR(*(object_ptr)_3);\n");
    _7646 = NewString("main");
    _5094 = NewString("main-%d");
    _7637 = NewString("@ = 1+(long)(DBL_PTR(@)->dbl);\n");
    _7631 = NewString("@ = binary_op(PLUS, 1, @);\n");
    _7617 = NewString("@ = NewDouble((double)@);\n");
    _7614 = NewString("if (@ > MAXINT)\n");
    _7580 = NewString("@ = @ + 1;\n");
    _5980 = NewString("%d;\n");
    _5789 = NewString("@ = ");
    _7477 = NewString("@ = MAKE_SEQ(_1);\n");
    _7511 = NewString("((int *)_2)[2] = @;\n");
    _7502 = NewString("((int *)_2)[1] = @;\n");
    _7501 = NewString("_1 = NewS1(2);\n");
    _7433 = NewString("%d);\n");
    _7475 = NewString(" @, ");
    _7471 = NewString("+%d,");
    _7469 = NewString("RepeatElem(_2");
    _7467 = NewString(" = @;\n");
    _7465 = NewString("))");
    _7462 = NewString("+%d");
    _7461 = NewString("*((int *)(_2");
    _7432 = NewString("_1 = NewS1(");
    _7311 = NewString("@ = SEQ_PTR(@)->length;\n");
    _7321 = NewString("@ = SEQ_PTR(*(object_ptr)_3)->length;\n");
    _7282 = NewString("DeRefDS(_1);\n");
    _7254 = NewString("*(int *)_2 = @;\n");
    _7253 = NewString("*(int *)_2 = _0;\n");
    _7247 = NewString("_1 = *(int *)_2;\n");
    _7243 = NewString("_2 = (int)(((s1_ptr)_2)->base + @);\n");
    _7240 = NewString("_2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(@)->dbl));\n");
    _7224 = NewString("*(int *)_3 = MAKE_SEQ(_2);\n");
    _7035 = NewString("_2 = (int)SEQ_PTR(*(int *)_3);\n");
    _7218 = NewString("_0 = @;\n");
    _6121 = NewString("DeRefDS(@);\n");
    _7195 = NewString("_1 = (long)(DBL_PTR(@)->dbl);\n");
    _7146 = NewString("if (!IS_ATOM_INT(@) && DBL_PTR(@)->dbl == 0.0)\n");
    _7138 = NewString("if (@ <= 0) {\n");
    _7133 = NewString("This opcode should never be emitted!");
    _7120 = NewString("RefDS(@);\n");
    _7078 = NewString("@ = (long)DBL_PTR(@)->dbl;\n");
    _7055 = NewString("@ = (int)*(((s1_ptr)_2)->base + @);\n");
    _7049 = NewString("@ = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(@)->dbl));\n");
    _6979 = NewString("@ = _0;\n");
    _5165 = NewString(", ");
    _4669 = NewString("(");
    _6952 = NewString("@");
    _6950 = NewString("_0 = ");
    _6851 = NewString(" --");
    _6846 = NewString(" \t\r\n");
    _6843 = NewString("// ");
    _6842 = NewString("\");\n");
    _6837 = NewString(":%d\t");
    _6830 = NewString("ctrace(\"");
    _6817 = NewString(" );\n");
    _6814 = NewString("%d)");
    _6813 = NewString("*(int *)(_2+");
    _6719 = NewString(" DBL_PTR(@)->dbl);\n");
    _6759 = NewString("NewDouble(DBL_PTR(@)->dbl ");
    _6756 = NewString("(DBL_PTR(@)->dbl ");
    _6779 = NewString("(DBL_PTR(@), DBL_PTR(@));\n");
    _6763 = NewString(" (double)@);\n");
    _6749 = NewString("(DBL_PTR(@), &temp_d);\n");
    _6699 = NewString("temp_d.dbl = (double)@;\n");
    _6715 = NewString("NewDouble((double)@ ");
    _6712 = NewString("((double)@ ");
    _6705 = NewString("(&temp_d, DBL_PTR(@));\n");
    _6503 = NewString("\x0B\x73\x0A\x74");
    _6523 = NewString("\x0B\x73\x0A\x74\x0D\x3F");
    _6444 = NewString("\x0B\x73\x0A\x74\x0D\x3F\x48");
    _6382 = NewString(", @, @))\n");
    _6380 = NewString("if (binary_op_a(");
    _6361 = NewString(" @)\n");
    _6360 = NewString("if (@ ");
    _6138 = NewString("@1 = NewDouble(@2 * (double)@3);\n");
    _5168 = NewString(")\n");
    _6167 = NewString(" && ");
    _6162 = NewString("if (");
    _6161 = NewString("@3 >= -INT15");
    _6155 = NewString("@3 <= INT15");
    _6150 = NewString("@2 == (short)@2");
    _6124 = NewString("DeRef5(@");
    _6120 = NewString("DeRefDSi(@);\n");
    _6116 = NewString("DeRefi(@);\n");
    _5209 = NewString("int _0, _1, _2;\n\n");
    _5208 = NewString("int _0, _1, _2, _3;\n\n");
    _5180 = NewString(" = 0");
    _4345 = NewString("_%d");
    _4457 = NewString("int ");
    _5929 = NewString("\x0D\x19\x03\x17\x22\x2E\x30");
    _5917 = NewString("\x0D\x19\x17\x3A\x22\x27\x2E\x30");
    _5914 = NewString("\x14\x32\x34\x38\x37\x10\x2F\x31");
    _5867 = NewString("_farpokel(_go32_info_block.selector_for_linear_memory, (unsigned long)poke4_addr, (unsigned long)@);\n");
    _5864 = NewString("*poke4_addr = (unsigned long)@;\n");
    _5865 = NewString("if ((unsigned)poke4_addr > LOW_MEMORY_MAX)\n");
    _5866 = NewString("_farpokel(_go32_info_block.selector_for_linear_memory, (unsigned long)poke4_addr, (unsigned long)DBL_PTR(@)->dbl);\n");
    _5863 = NewString("*poke4_addr = (unsigned long)DBL_PTR(@)->dbl;\n");
    _5862 = NewString("*poke4_addr = (unsigned long)_1;\n");
    _5861 = NewString("_1 = (unsigned long)DBL_PTR(@)->dbl;\n");
    _5855 = NewString("_farpokeb(_go32_info_block.selector_for_linear_memory, (unsigned long)poke_addr, (unsigned char)@);\n");
    _5852 = NewString("*poke_addr = (unsigned char)@;\n");
    _5853 = NewString("if ((unsigned)poke_addr > LOW_MEMORY_MAX)\n");
    _5854 = NewString("_farpokeb(_go32_info_block.selector_for_linear_memory, (unsigned long)poke_addr, (unsigned char)DBL_PTR(@)->dbl);\n");
    _5851 = NewString("*poke_addr = (signed char)DBL_PTR(@)->dbl;\n");
    _5850 = NewString("*poke_addr = _1;\n");
    _5849 = NewString("_1 = (signed char)DBL_PTR(@)->dbl;\n");
    _5842 = NewString("@ = _farpeekl(_go32_info_block.selector_for_linear_memory, (unsigned)@);\n");
    _5837 = NewString("@ = *(unsigned long *)@;\n");
    _5830 = NewString("if ((unsigned)@ > LOW_MEMORY_MAX)\n");
    _5840 = NewString("@ = _farpeekl(_go32_info_block.selector_for_linear_memory, (unsigned)_1);\n");
    _5839 = NewString("@ = *(unsigned long *)_1;\n");
    _5826 = NewString("if ((unsigned)_1 > LOW_MEMORY_MAX)\n");
    _5825 = NewString("_1 = (int)(unsigned)DBL_PTR(@)->dbl;\n");
    _5835 = NewString("@ = *(unsigned long *)(unsigned long)(DBL_PTR(@)->dbl);\n");
    _5832 = NewString("@ = _farpeekb(_go32_info_block.selector_for_linear_memory, (unsigned)@);\n");
    _5822 = NewString("@ = *(unsigned char *)@;\n");
    _5828 = NewString("@ = _farpeekb(_go32_info_block.selector_for_linear_memory, (unsigned)_1);\n");
    _5827 = NewString("@ = *(unsigned char *)_1;\n");
    _5820 = NewString("@ = *(unsigned char *)(unsigned long)(DBL_PTR(@)->dbl);\n");
    _5803 = NewString("@ = unary_op(");
    _5793 = NewString("(@);\n");
    _5669 = NewString("\x02\x08");
    _5743 = NewString("DeRef(");
    _5742 = NewString("DeRefi(");
    _5740 = NewString("DeRefDS(");
    _5739 = NewString("DeRefDSi(");
    _5737 = NewString("DeRef1(");
    _5749 = NewString("internal: deref problem");
    _5744 = NewString(" = ");
    _5676 = NewString("Refn(");
    _5675 = NewString("RefDSn(");
    _5672 = NewString("Ref(");
    _5671 = NewString("RefDS(");
    _5642 = NewString("L%x;\n");
    _5641 = NewString("goto ");
    _5636 = NewString("\x17\x16\x3D");
    _5633 = NewString("6'");
    _5616 = NewString("L%x:\n");
    _5564 = NewString("\x97\xA6\x5C\x19\x72\x54\x10\x76");
    _5538 = NewString("Bad seq_elem");
    _5512 = NewString("Bad BB_elem");
    _5496 = NewString("Bad BB_elem type");
    _5470 = NewString("Bad BB_temp_type");
    _5430 = NewString("MATCH_FROM");
    _5429 = NewString("FIND_FROM");
    _5428 = NewString("TASK_CLOCK_START");
    _5427 = NewString("TASK_CLOCK_STOP");
    _5426 = NewString("TASK_STATUS");
    _5425 = NewString("TASK_LIST");
    _5424 = NewString("TASK_SUSPEND");
    _5423 = NewString("TASK_SELF");
    _5422 = NewString("TASK_YIELD");
    _5421 = NewString("TASK_SCHEDULE");
    _5420 = NewString("TASK_CREATE");
    _5410 = NewString("CONCAT_N");
    _5409 = NewString("END_PARAM_CHECK");
    _5408 = NewString("PLATFORM");
    _5407 = NewString("SYSTEM_EXEC");
    _5406 = NewString("EQUAL");
    _5405 = NewString("XOR");
    _5404 = NewString("PROFILE");
    _5401 = NewString("ASSIGN_SUBS2");
    _5400 = NewString("SC1_OR_IF");
    _5398 = NewString("SC2_NULL");
    _5397 = NewString("SC2_OR");
    _5396 = NewString("SC1_OR");
    _5395 = NewString("SC2_AND");
    _5394 = NewString("SC1_AND");
    _5393 = NewString("PEEK4U");
    _5392 = NewString("PEEK4S");
    _5391 = NewString("POKE4");
    _5390 = NewString("CALL_FUNC");
    _5389 = NewString("CALL_PROC");
    _5388 = NewString("CALL_BACK_RETURN");
    _5387 = NewString("ROUTINE_ID");
    _5386 = NewString("C_FUNC");
    _5385 = NewString("C_PROC");
    _5384 = NewString("MEM_SET");
    _5383 = NewString("MEM_COPY");
    _5382 = NewString("GET_PIXEL");
    _5381 = NewString("PIXEL");
    _5380 = NewString("CALL");
    _5379 = NewString("POKE");
    _5378 = NewString("PEEK");
    _5377 = NewString("ABORT");
    _5376 = NewString("FOR_I");
    _5375 = NewString("GREATER_IFW_I");
    _5374 = NewString("LESSEQ_IFW_I");
    _5373 = NewString("NOTEQ_IFW_I");
    _5372 = NewString("EQUALS_IFW_I");
    _5371 = NewString("GREATEREQ_IFW_I");
    _5370 = NewString("LESS_IFW_I");
    _5369 = NewString("ASSIGN_SUBS_I");
    _5368 = NewString("PLUS1_I");
    _5367 = NewString("MINUS_I");
    _5366 = NewString("PLUS_I");
    _5365 = NewString("RHS_SUBS_I");
    _5364 = NewString("ASSIGN_I");
    _5363 = NewString("MACHINE_PROC");
    _5362 = NewString("MACHINE_FUNC");
    _5361 = NewString("NOP2");
    _5360 = NewString("GLOBAL_INIT_CHECK");
    _5359 = NewString("NOT_IFW");
    _5358 = NewString("GREATER_IFW");
    _5357 = NewString("LESSEQ_IFW");
    _5356 = NewString("NOTEQ_IFW");
    _5355 = NewString("EQUALS_IFW");
    _5354 = NewString("GREATEREQ_IFW");
    _5353 = NewString("LESS_IFW");
    _5352 = NewString("ATOM_CHECK");
    _5351 = NewString("COMMAND_LINE");
    _5350 = NewString("SYSTEM");
    _5349 = NewString("DIV2");
    _5348 = NewString("SEQUENCE_CHECK");
    _5347 = NewString("INTEGER_CHECK");
    _5346 = NewString("LHS_SUBS");
    _5345 = NewString("IS_AN_INTEGER");
    _5344 = NewString("PLUS1");
    _5343 = NewString("RHS_SUBS_CHECK");
    _5342 = NewString("GETENV");
    _5341 = NewString("ERASE_SYMBOL");
    _5340 = NewString("UPDATE_GLOBALS");
    _5339 = NewString("ERASE_PRIVATE_NAMES");
    _5338 = NewString("DISPLAY_VAR");
    _5337 = NewString("CLOSE");
    _5336 = NewString("RIGHT_BRACE_2");
    _5335 = NewString("ASSIGN_SUBS_CHECK");
    _5330 = NewString("GET_KEY");
    _5329 = NewString("MATCH");
    _5328 = NewString("FIND");
    _5327 = NewString("COMPARE");
    _5326 = NewString("SPACE_USED");
    _5323 = NewString("POWER");
    _5322 = NewString("REMAINDER");
    _5321 = NewString("TIME");
    _5320 = NewString("DATE");
    _5319 = NewString("IS_A_SEQUENCE");
    _5318 = NewString("IS_AN_ATOM");
    _5317 = NewString("FLOOR_DIV2");
    _5316 = NewString("TYPE_CHECK");
    _5315 = NewString("TRACE");
    _5314 = NewString("FLOOR_DIV");
    _5313 = NewString("RAND");
    _5312 = NewString("EXIT");
    _5311 = NewString("POSITION");
    _5310 = NewString("CLEAR_SCREEN");
    _5309 = NewString("STARTLINE");
    _5308 = NewString("PREPEND");
    _5307 = NewString("AND_BITS");
    _5306 = NewString("ENDFOR_INT_DOWN1");
    _5305 = NewString("ENDFOR_INT_UP1");
    _5304 = NewString("SPRINTF");
    _5303 = NewString("ENDFOR_INT_DOWN");
    _5301 = NewString("ENDFOR_DOWN");
    _5300 = NewString("ENDFOR_UP");
    _5299 = NewString("ENDFOR_INT_UP");
    _5298 = NewString("WHILE");
    _5297 = NewString("RHS_SLICE");
    _5296 = NewString("ASSIGN_SLICE");
    _5295 = NewString("PUTS");
    _5294 = NewString("BADRETURNF");
    _5293 = NewString("LENGTH");
    _5291 = NewString("IS_AN_OBJECT");
    _5290 = NewString("ENDFOR_GENERAL");
    _5289 = NewString("PRINTF");
    _5288 = NewString("OPEN");
    _5287 = NewString("QPRINT");
    _5286 = NewString("APPEND");
    _5285 = NewString("RETURNT");
    _5284 = NewString("GETC");
    _5283 = NewString("REPEAT");
    _5282 = NewString("RIGHT_BRACE_N");
    _5281 = NewString("PRIVATE_INIT_CHECK");
    _5280 = NewString("RETURNP");
    _5279 = NewString("RETURNF");
    _5278 = NewString("PROC");
    _5277 = NewString("XOR_BITS");
    _5276 = NewString("RHS_SUBS");
    _5275 = NewString("OR_BITS");
    _5274 = NewString("ELSE");
    _5273 = NewString("ENDWHILE");
    _5272 = NewString("FOR");
    _5271 = NewString("IF");
    _5270 = NewString("PRINT");
    _5269 = NewString("ASSIGN");
    _5268 = NewString("GETS");
    _5267 = NewString("ASSIGN_SUBS");
    _5266 = NewString("CONCAT");
    _5265 = NewString("DIVIDE");
    _5264 = NewString("MULTIPLY");
    _5263 = NewString("UMINUS");
    _5262 = NewString("PLUS");
    _5261 = NewString("MINUS");
    _5260 = NewString("OR");
    _5259 = NewString("AND");
    _5258 = NewString("NOT");
    _5249 = NewString("    ;\n}\n\n\n");
    _4350 = NewString("_");
    _5158 = NewString("int _");
    _5153 = NewString("int @(");
    _5152 = NewString("@(");
    _4664 = NewString("int __stdcall\n");
    _5100 = NewString("%s %s %s.c\n");
    _5098 = NewString("%s %s.c\n");
    _5135 = NewString("_ ");
    _639 = NewString(" ");
    _5092 = NewString("%s %s main-%d.c\n");
    _5090 = NewString("%s main-%d.c\n");
    _5072 = NewString("main-");
    _5086 = NewString("%s %s main-.c\n");
    _5084 = NewString("%s main-.c\n");
    _5075 = NewString(" conflicts with a file name used internally by the Translator");
    _4949 = NewString("init-");
    _5057 = NewString("chmod +x emake");
    _5056 = NewString(":done\n");
    _5055 = NewString("echo Run the translator to create new .c files\n");
    _5054 = NewString(":nofiles\n");
    _5053 = NewString("goto done\n");
    _5051 = NewString("echo you can now execute: %s.exe\n");
    _5049 = NewString("if not exist %s.exe goto done\n");
    _5047 = NewString("echo you can now link with: %s.dll\n");
    _5045 = NewString("if not exist %s.dll goto done\n");
    _5043 = NewString("echo you can now execute: ./%s\n");
    _5041 = NewString("echo you can now link with: ./%s.so\n");
    _5040 = NewString("rm -f *.o\n");
    _5037 = NewString(" -o%s%s\n");
    _5036 = NewString(" -ldl");
    _5033 = NewString("gcc %s %s.o %s %s/bin/ecu.a -lm ");
    _5032 = NewString(".so");
    _5031 = NewString("-shared -nostartfiles");
    _5027 = NewString("STACKSIZE %d,%d\n");
    _5023 = NewString("Couldn't open .def file for output");
    _623 = NewString("w");
    _5015 = NewString("%s.def");
    _4969 = NewString("del *.obj > NUL\n");
    _5012 = NewString("%s\\bin\\ecwl.lib\n");
    _5010 = NewString("lcclnk -s -subsystem %s -stack-reserve %d -stack-commit %d %s.obj @objfiles.lnk\n");
    _5009 = NewString("windows");
    _5008 = NewString("console");
    _5006 = NewString("lcclnk -s -dll -subsystem windows %s.obj %s.def @objfiles.lnk\n");
    _5005 = NewString("del *.tds > NUL\n");
    _5002 = NewString("%s\\bin\\ecwb.lib\n");
    _5000 = NewString("bcc32 %s %s.c @objfiles.lnk\n");
    _4997 = NewString("FILE %s\\bin\\ecw.lib\n");
    _4962 = NewString("wlink FILE %s.obj @objfiles.lnk\n");
    _4994 = NewString("set LFN=\n");
    _4992 = NewString("strip %s.exe\n");
    _4991 = NewString("set LFN=n\n");
    _4990 = NewString("del *.o\n");
    _4987 = NewString("gcc %s.o -o%s.exe @objfiles.lnk\n");
    _4985 = NewString("%s\\bin\\liballeg.a\n");
    _4983 = NewString("%s\\bin\\ec.a\n");
    _4981 = NewString("cwc %s.exe\n");
    _4979 = NewString("le23p %s.exe\n");
    _4972 = NewString("rb");
    _4975 = NewString("\\bin\\cwc.exe");
    _4970 = NewString("\\bin\\le23p.exe");
    _4967 = NewString("ec.lib\n");
    _4966 = NewString("ecfastfp.lib\n");
    _4964 = NewString("FILE %s\\bin\\");
    _4959 = NewString("%s linking\n");
    _4956 = NewString("init-%d");
    _4954 = NewString("%s %s init-%d.c\n");
    _4952 = NewString("%s init-%d.c\n");
    _4947 = NewString("%s %s init-.c\n");
    _4945 = NewString("%s init-.c\n");
    _4943 = NewString("lcc");
    _4942 = NewString("bcc32");
    _4934 = NewString("OPTION CASEEXACT\n");
    _4933 = NewString("OPTION ELIMINATE\n");
    _4932 = NewString("OPTION QUIET\n");
    _4940 = NewString("COMMIT STACK=%d\n");
    _4931 = NewString("OPTION STACK=%d\n");
    _4939 = NewString("RUNTIME WINDOWS=4.0\n");
    _4938 = NewString("SYSTEM NT_WIN\n");
    _4937 = NewString("SYSTEM NT\n");
    _4936 = NewString("SYSTEM NT_DLL initinstance terminstance\n");
    _4922 = NewString("wcc386");
    _4913 = NewString("gcc");
    _4930 = NewString("format os2 le ^\n");
    _4928 = NewString("OPTION stub=%s\\bin\\cwstub.exe\n");
    _4926 = NewString("libpath %s\\lib386\\dos\n");
    _4924 = NewString("libpath %s\\lib386\n");
    _4923 = NewString("option osname='CauseWay'\n");
    _4920 = NewString("Couldn't open objfiles.lnk for output");
    _4916 = NewString("objfiles.lnk");
    _4914 = NewString("echo");
    _4893 = NewString("-c -w -fsigned-char -O2 -ffast-math -fomit-frame-pointer");
    _4915 = NewString("-c -w -fPIC -fsigned-char -O2 -ffast-math -fomit-frame-pointer");
    _4912 = NewString("echo compiling with GNU C\n");
    _4911 = NewString("-w -O -Zp4");
    _4910 = NewString("echo compiling with LCCWIN\n");
    _4907 = NewString("\\lib");
    _4906 = NewString("\\include -L");
    _4904 = NewString("-tW");
    _4902 = NewString("-tWC");
    _4900 = NewString("-tWD");
    _4899 = NewString(" -q -w- -O2 -5 -a4 -I");
    _4898 = NewString("echo compiling with BORLAND\n");
    _4896 = NewString("/bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s");
    _4895 = NewString("/bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s");
    _4889 = NewString("echo compiling with WATCOM\n");
    _4892 = NewString("echo compiling with DJGPP\n");
    _4891 = NewString("/w0 /zq /j /zp4 /fpc /5r /otimra /s");
    _4890 = NewString("/w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s");
    _4887 = NewString("if not exist main-.c goto nofiles\n");
    _4886 = NewString("@echo off\n");
    _4884 = NewString("Couldn't create batch file for compile.\n");
    _4881 = NewString("emake.bat");
    _4879 = NewString("emake");
    _4861 = NewString("%s.obj\n");
    _4859 = NewString("%s.c\n");
    _4852 = NewString("FILE %s.obj\n");
    _4854 = NewString("%s.o\n");
    _4848 = NewString(".o ");
    _4814 = NewString(".c");
    _4841 = NewString("Sorry, too many .c files with the same base name");
    _4831 = NewString("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ");
    _4826 = NewString("#include \"main-.h\"\n\n");
    _4824 = NewString("euphoria.h\"\n");
    _700 = NewString("include");
    _4823 = NewString("#include \"");
    _4822 = NewString("#include <go32.h>\n");
    _4818 = NewString("Couldn't open .c file for output");
    _4811 = NewString("// Euphoria To C version ");
    _4800 = NewString("_%d%s@%d\n");
    _4789 = NewString("EXPORT %s='__%d%s@%d'\n");
    _4780 = NewString("%s=_%d%s\n");
    _4769 = NewString("EXPORTS\n");
    _4767 = NewString("  {\"\", 0, 999999999, 0}\n};\n\n");
    _4692 = NewString(",\n");
    _34 = NewString("}");
    _4702 = NewString(", %d");
    _4758 = NewString("\", %d");
    _4693 = NewString("  {\"");
    _4745 = NewString("struct ns_list _01[] = {\n");
    _4744 = NewString("extern struct ns_list _01[];\n");
    _4743 = NewString("  {\"\", 0, 999999999, 0, 0, 0}\n};\n\n");
    _4719 = NewString(", 0");
    _4718 = NewString(", 1");
    _4697 = NewString("(int (*)())");
    _4696 = NewString("\", ");
    _4678 = NewString("struct routine_list _00[] = {\n");
    _4674 = NewString(", int");
    _4673 = NewString("int");
    _4649 = NewString("extern struct routine_list _00[];\n");
    _4461 = NewString("extern int ");
    _122 = NewString("%d");
    _4331 = NewString("huge97531");
    _4329 = NewString("huge");
    _4328 = NewString("interrupt97531");
    _4326 = NewString("interrupt");
    _4325 = NewString("near97531");
    _4323 = NewString("near");
    _4322 = NewString("try97531");
    _4320 = NewString("try");
    _4319 = NewString("pascal97531");
    _4317 = NewString("pascal");
    _4316 = NewString("fastcall97531");
    _4314 = NewString("fastcall");
    _4313 = NewString("stdcall97531");
    _4311 = NewString("stdcall");
    _4310 = NewString("asm97531");
    _4308 = NewString("asm");
    _4307 = NewString("far1697531");
    _4305 = NewString("far16");
    _4304 = NewString("far97531");
    _4302 = NewString("far");
    _4301 = NewString("cdecl97531");
    _4299 = NewString("cdecl");
    _4298 = NewString("Try97531");
    _4296 = NewString("Try");
    _4295 = NewString("Packed97531");
    _4293 = NewString("Packed");
    _4292 = NewString("Seg1697531");
    _4290 = NewString("Seg16");
    _4289 = NewString("Bool97531");
    _4287 = NewString("Bool");
    _4083 = NewString("\x03\x01");
    _4078 = NewString("or_type: t1 is %d, t2 is %d\n");
    _4020 = NewString("Bad GType");
    _4009 = NewString("Bad BB_var_type");
    _3949 = NewString("del ");
    _3948 = NewString("rm ");
    _3944 = NewString("init-.c");
    _3943 = NewString("main-.h");
    _3942 = NewString("main-.c");
    _3935 = NewString("unknown command");
    _3934 = NewString("illegal character");
    _3926 = NewString("exit must be inside a loop");
    _3923 = NewString("function result must be assigned or used");
    _3908 = NewString("'global' must be followed by:\n     <a type>, 'constant', 'procedure', 'type' or 'function'");
    _3879 = NewString("unknown with/without option");
    _3871 = NewString("warning");
    _758 = NewString("trace");
    _3868 = NewString("sample size must be a positive integer");
    _3850 = NewString("profile_time");
    _828 = NewString("profile");
    _3844 = NewString("type_check");
    _3842 = NewString("can't mix profile and profile_time");
    _648 = NewString("%s is not supported in Euphoria for %s");
    _3832 = NewString("type must return true / false value");
    _3831 = NewString("no value returned from function");
    _3806 = NewString("types must have exactly one parameter");
    _3796 = NewString("badly-formed list of parameters - expected ',' or ')'");
    _3793 = NewString("expected to see a parameter declaration, not ')'");
    _3778 = NewString("a parameter name is expected here");
    _3771 = NewString("a type is expected here");
    _3715 = NewString("built-in routine %s() redefined");
    _3710 = NewString("\x07\x06");
    _3594 = NewString("a name is expected here");
    _3698 = NewString("Statement_list");
    _3674 = NewString("abort()");
    _3644 = NewString("a variable name is expected here");
    _2133 = NewString("\x06\x07");
    _3544 = NewString("a loop variable name is expected here");
    _3538 = NewString("SetPS");
    _3529 = NewString("\x05\x06\x07");
    _3521 = NewString("\t\n");
    _3519 = NewString("\x03\x02");
    _690 = NewString("exit");
    _3445 = NewString("exit statement must be inside a loop");
    _672 = NewString("return");
    _3437 = NewString("return must be inside a procedure or function");
    _3398 = NewString("Syntax error - expected to see =, +=, -=, *=, /= or &=");
    _3357 = NewString("may not change the value of a constant");
    _3353 = NewString("may not assign to a for-loop variable");
    _3313 = NewString("Expr");
    _3243 = NewString("Syntax error - expected to see an expression, not %s");
    _3226 = NewString("%.99s:%d - call to %s() might be short-circuited");
    _3198 = NewString("'$' must only appear between '[' and ']'");
    _3163 = NewString("only ");
    _3140 = NewString("%s takes %s%d argument%s");
    _3139 = NewString("s");
    _913 = NewString("    ");
    _3122 = NewString("A namespace qualifier is needed to resolve %s.\n%s is defined as a global symbol in:\n");
    _3114 = NewString("%s has not been declared");
    _3108 = NewString("Syntax error - expected to see possibly %s, not %s");
    _2996 = NewString("%s:%d - statement after %s will never be executed");
    _2939 = NewString("unknown opcode: %d");
    _2938 = NewString("Statements have been inserted to trace execution of your program.");
    _2932 = NewString("\x99\xAD");
    _2903 = NewString("\x56\x7E\x81");
    _2899 = NewString("\x45\x46\x4B\x4F\xAE\x64");
    _2808 = NewString("\x84\x85\x26");
    _2798 = NewString("\x0A\x23\x39\x4C\x9B\x4D\x4E\x9C\x0F\x20\x6F\x87\x25\x35\xA9");
    _2740 = NewString("\x03\x01\x06\x04\x05\x02\x08\x09\x9A\x47\x38\x18\x1A");
    _2735 = NewString("\x63\x2C\x13\x24\x3C\x70\x86\x82\x80\x8C\xAA");
    _2723 = NewString("\x5E\x43\x44\x28\x2A\x21\x29\x50\x51\x52\x49\x4A\x11\x83\x5B");
    _2693 = NewString("\x3E\x7F\x8D\x8E\x33\x07\xAF");
    _2549 = NewString("\xA1\x6E\xA0\x1E\x6D\x3A\x3B\x3D\x16\x17\x58\x2B\x5A\x59\x57"
"\x89\x9E\xAB\xB1\xB0");
    _2381 = NewString("this ...");
    _2341 = NewString("'?'");
    _2339 = NewString("'while'");
    _2337 = NewString("'without'");
    _2335 = NewString("'with'");
    _2309 = NewString("a variable");
    _2332 = NewString("'type'");
    _2313 = NewString("a type");
    _2329 = NewString("'then'");
    _2327 = NewString("'to'");
    _2325 = NewString("a character string");
    _2323 = NewString("a slice");
    _2321 = NewString("'return'");
    _2319 = NewString("']'");
    _2317 = NewString("')'");
    _2315 = NewString("'}'");
    _2305 = NewString("a procedure");
    _2263 = NewString("a function");
    _2307 = NewString("'procedure'");
    _2303 = NewString("'+'");
    _2301 = NewString("'or'");
    _2299 = NewString("'!='");
    _2297 = NewString("'not'");
    _2295 = NewString("end-of-line");
    _2293 = NewString("a namespace qualifier");
    _2291 = NewString("'*'");
    _2289 = NewString("'-'");
    _2287 = NewString("'<='");
    _2285 = NewString("'<'");
    _2283 = NewString("'['");
    _2281 = NewString("'('");
    _2279 = NewString("'{'");
    _2277 = NewString("'include'");
    _2275 = NewString("an illegal character");
    _2273 = NewString("'if'");
    _2271 = NewString("'>='");
    _2269 = NewString("'>'");
    _2267 = NewString("'global'");
    _2265 = NewString("'function'");
    _2261 = NewString("'for'");
    _2259 = NewString("'exit'");
    _2257 = NewString("'='");
    _2255 = NewString("the end of file");
    _2253 = NewString("'end'");
    _2251 = NewString("'elsif'");
    _2249 = NewString("'else'");
    _2247 = NewString("'do'");
    _2245 = NewString("'/'");
    _2243 = NewString("'constant'");
    _2241 = NewString("'&'");
    _2239 = NewString("','");
    _2237 = NewString("':'");
    _2235 = NewString("'by'");
    _2233 = NewString("'!'");
    _2231 = NewString("a number");
    _2229 = NewString("'and'");
    _2228 = NewString("improper syntax for include-as");
    _2227 = NewString("missing namespace qualifier");
    _2224 = NewString("a new namespace identifier is expected here");
    _2188 = NewString("file name is missing");
    _2153 = NewString("\x20\x09\x0A\x0D\x1A");
    _2181 = NewString("missing closing quote on file name");
    _2172 = NewString("\x0A\x0D\x22\x1A");
    _2158 = NewString("--");
    _2130 = NewString("Scanner()");
    _2101 = NewString("character constant is missing a closing '");
    _2098 = NewString("single-quote character is empty");
    _2017 = NewString("tab character found in string - use \\t instead");
    _2058 = NewString("hex number not formed correctly");
    _2057 = NewString("#! may only be on the first line of a program");
    _2025 = NewString("end of line reached with no closing \"");
    _1807 = NewString("number not formed correctly");
    _1977 = NewString("exponent not formed correctly");
    _1964 = NewString("fractional part of number is missing");
    _1954 = NewString("only one decimal point allowed");
    _1913 = NewString("an identifier is expected here");
    _1815 = NewDouble((double)1.0000000000000000e+01);
    _1864 = NewDouble((double)3.0800000000000000e+02);
    _1808 = NewDouble((double)0.0000000000000000e+00);
    _1804 = NewString("unknown escape character");
    _1767 = NewString("program includes too many files");
    _1763 = NewString("includes are nested too deeply");
    _1734 = NewString("can't find %s in %s\nor in %s\nor in %s%sinclude");
    _1731 = NewString("can't find %s in %s\nor in %s%sinclude");
    _1517 = NewString(".");
    _1669 = NewString("r");
    _1696 = NewString(" \t");
    _1682 = NewString("EUINC");
    _1672 = NewString("can't open %s");
    _1653 = NewString("illegal character (ASCII 0)");
    _1648 = NewString("\x1A");
    _1565 = NewString("out of memory - turn off trace and profile");
    _1518 = NewString("..");
    _1444 = NewDouble((double)3.5000000000000000e+00);
    _1404 = NewString("%s %s in %s is %s");
    _1399 = NewString("%s %s in %s() in %s is %s");
    _1396 = NewString("never assigned a value");
    _1394 = NewString("not used");
    _1376 = NewString("local constant");
    _1384 = NewString("private variable");
    _1383 = NewString("parameter");
    _1377 = NewString("local variable");
    _714 = NewString("sequence");
    _712 = NewString("integer");
    _742 = NewString("atom");
    _718 = NewString("object");
    _862 = NewString("_toplevel_");
    _1076 = NewString("extern int _%d;\n");
    _1073 = NewString("int _%d;\n");
    _1030 = NewString("/\\:");
    _1021 = NewString("attempt to redefine %s");
    _1015 = NewString("\x09\x0A\x07");
    _668 = NewString("else");
    _930 = NewString("if ");
    _870 = NewString("%.16e");
    _869 = NewString("((1.0/sqrt(0.0)) / (1.0/sqrt(0.0)))");
    _868 = NewString("sqrt(-1.0)");
    _867 = NewString("(1.0/sqrt(0.0))");
    _859 = NewString("space_used");
    _856 = NewString("match_from");
    _854 = NewString("find_from");
    _852 = NewString("task_clock_start");
    _850 = NewString("task_clock_stop");
    _848 = NewString("task_status");
    _846 = NewString("task_list");
    _844 = NewString("task_suspend");
    _842 = NewString("task_self");
    _840 = NewString("task_yield");
    _838 = NewString("task_schedule");
    _836 = NewString("task_create");
    _834 = NewString("platform");
    _832 = NewString("system_exec");
    _830 = NewString("equal");
    _826 = NewString("peek4u");
    _824 = NewString("peek4s");
    _822 = NewString("poke4");
    _820 = NewString("call_func");
    _818 = NewString("call_proc");
    _816 = NewString("routine_id");
    _814 = NewString("c_func");
    _812 = NewString("c_proc");
    _810 = NewString("mem_set");
    _808 = NewString("mem_copy");
    _806 = NewString("get_pixel");
    _804 = NewString("pixel");
    _802 = NewString("not_bits");
    _800 = NewString("xor_bits");
    _798 = NewString("or_bits");
    _796 = NewString("and_bits");
    _794 = NewString("arctan");
    _792 = NewString("sprintf");
    _790 = NewString("call");
    _788 = NewString("poke");
    _786 = NewString("peek");
    _784 = NewString("abort");
    _782 = NewString("machine_proc");
    _780 = NewString("machine_func");
    _778 = NewString("power");
    _776 = NewString("remainder");
    _774 = NewString("date");
    _772 = NewString("system");
    _770 = NewString("log");
    _768 = NewString("tan");
    _766 = NewString("cos");
    _764 = NewString("sin");
    _762 = NewString("sqrt");
    _760 = NewString("getenv");
    _756 = NewString("close");
    _754 = NewString("open");
    _752 = NewString("command_line");
    _750 = NewString("time");
    _748 = NewString("match");
    _746 = NewString("find");
    _744 = NewString("compare");
    _740 = NewString("repeat");
    _738 = NewString("rand");
    _736 = NewString("get_key");
    _734 = NewString("gets");
    _732 = NewString("getc");
    _730 = NewString("floor");
    _728 = NewString("clear_screen");
    _726 = NewString("printf");
    _724 = NewString("print");
    _722 = NewString("prepend");
    _720 = NewString("append");
    _716 = NewString("position");
    _710 = NewString("puts");
    _708 = NewString("length");
    _706 = NewString("xor");
    _704 = NewString("without");
    _702 = NewString("with");
    _698 = NewString("not");
    _696 = NewString("by");
    _694 = NewString("global");
    _692 = NewString("function");
    _688 = NewString("or");
    _686 = NewString("and");
    _684 = NewString("to");
    _682 = NewString("constant");
    _680 = NewString("type");
    _678 = NewString("while");
    _676 = NewString("elsif");
    _674 = NewString("do");
    _670 = NewString("for");
    _666 = NewString("procedure");
    _664 = NewString("then");
    _662 = NewString("end");
    _660 = NewString("if");
    _621 = NewString("\nPress Enter\n");
    _654 = NewString("Internal Error at %s:%d - %s\n");
    _651 = NewString("Internal Error: %s\n");
    _643 = NewString("%s:%d\n%s\n");
    _640 = NewString("^\n\n");
    _638 = NewString("\t");
    _634 = NewString("<end-of-file>\n");
    _628 = NewString("Can't create error message file: ");
    _609 = NewString("\nPress Enter to continue, q to quit\n\n");
    _599 = NewString("Warning: %s\n");
    _321 = NewDouble((double)-1.2958371958709999e+307);
    _320 = NewDouble((double)1.2958371958709999e+307);
    _277 = NewString("\\/:");
    _274 = NewString("/");
    _271 = NewString("Linux");
    _270 = NewString("WIN32");
    _269 = NewString("DOS32");
    _268 = NewString("DOS32 built for DJGPP");
    _261 = NewString("3.1.1");
    _161 = NewDouble((double)1.0000000000000000e+00);
    _151 = NewDouble((double)2.0000000000000000e+00);
    _150 = NewDouble((double)3.1415926535897931e+00);
    _23 = NewString("%.10g");
    _113 = NewString(" ...");
    _98 = NewString("\t\r\n");
    _70 = NewString("\t\n\r");
    _60 = NewString("\\r");
    _57 = NewString("\\n");
    _55 = NewString("\\t");
    _25 = NewString("{");
}
