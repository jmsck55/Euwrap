// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void  __stdcall _2set_return_linked_list(object _i_389)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_389)) {
        _1 = (object)(DBL_PTR(_i_389)->dbl);
        DeRefDS(_i_389);
        _i_389 = _1;
    }

    /** list.e:40		always_linked_list = i*/
    _2always_linked_list_386 = _i_389;

    /** list.e:41	end procedure*/
    return;
    ;
}
void set_return_linked_list() __attribute__ ((alias ("_2set_return_linked_list@4")));


object  __stdcall _2get_return_linked_list()
{
    object _0, _1, _2;
    

    /** list.e:43		return always_linked_list*/
    return _2always_linked_list_386;
    ;
}
object get_return_linked_list() __attribute__ ((alias ("_2get_return_linked_list@0")));


object  __stdcall _2mystring(object _x_394)
{
    object _flag_395 = NOVALUE;
    object _i_396 = NOVALUE;
    object _ob_397 = NOVALUE;
    object _111 = NOVALUE;
    object _104 = NOVALUE;
    object _102 = NOVALUE;
    object _100 = NOVALUE;
    object _0, _1, _2;
    

    /** list.e:49		if not sequence(x) then*/
    _100 = IS_SEQUENCE(_x_394);
    if (_100 != 0)
    goto L1; // [6] 16
    _100 = NOVALUE;

    /** list.e:50			return 0*/
    DeRef(_x_394);
    DeRef(_ob_397);
    return 0;
L1: 

    /** list.e:52		flag = 0*/
    _flag_395 = 0;

    /** list.e:53		for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_394)){
            _102 = SEQ_PTR(_x_394)->length;
    }
    else {
        _102 = 1;
    }
    {
        object _j_402;
        _j_402 = 1;
L2: 
        if (_j_402 > _102){
            goto L3; // [26] 107
        }

        /** list.e:54			ob = x[j]*/
        DeRef(_ob_397);
        _2 = (object)SEQ_PTR(_x_394);
        _ob_397 = (object)*(((s1_ptr)_2)->base + _j_402);
        Ref(_ob_397);

        /** list.e:55			if not integer(ob) then*/
        if (IS_ATOM_INT(_ob_397))
        _104 = 1;
        else if (IS_ATOM_DBL(_ob_397))
        _104 = IS_ATOM_INT(DoubleToInt(_ob_397));
        else
        _104 = 0;
        if (_104 != 0)
        goto L4; // [44] 54
        _104 = NOVALUE;

        /** list.e:56				return 0*/
        DeRef(_x_394);
        DeRef(_ob_397);
        return 0;
L4: 

        /** list.e:58			i = ob*/
        Ref(_ob_397);
        _i_396 = _ob_397;
        if (!IS_ATOM_INT(_i_396)) {
            _1 = (object)(DBL_PTR(_i_396)->dbl);
            DeRefDS(_i_396);
            _i_396 = _1;
        }

        /** list.e:59			if i < 0 then*/
        if (_i_396 >= 0)
        goto L5; // [63] 74

        /** list.e:60				return 0*/
        DeRef(_x_394);
        DeRef(_ob_397);
        return 0;
L5: 

        /** list.e:62			if i > 255 then*/
        if (_i_396 <= 255)
        goto L6; // [76] 87

        /** list.e:63				return 0*/
        DeRef(_x_394);
        DeRef(_ob_397);
        return 0;
L6: 

        /** list.e:65			if flag = 0 then*/
        if (_flag_395 != 0)
        goto L7; // [89] 100

        /** list.e:66				flag = (i = 0)*/
        _flag_395 = (_i_396 == 0);
L7: 

        /** list.e:68		end for*/
        _j_402 = _j_402 + 1;
        goto L2; // [102] 33
L3: 
        ;
    }

    /** list.e:69		return 1 + flag*/
    _111 = _flag_395 + 1;
    if (_111 > MAXINT){
        _111 = NewDouble((eudouble)_111);
    }
    DeRef(_x_394);
    DeRef(_ob_397);
    return _111;
    ;
}
object mystring() __attribute__ ((alias ("_2mystring@4")));


object  __stdcall _2myarray(object _x_419)
{
    object _flag_420 = NOVALUE;
    object _i_421 = NOVALUE;
    object _ob_422 = NOVALUE;
    object _119 = NOVALUE;
    object _116 = NOVALUE;
    object _114 = NOVALUE;
    object _112 = NOVALUE;
    object _0, _1, _2;
    

    /** list.e:76		if not sequence(x) then*/
    _112 = IS_SEQUENCE(_x_419);
    if (_112 != 0)
    goto L1; // [6] 16
    _112 = NOVALUE;

    /** list.e:77			return 0*/
    DeRef(_x_419);
    DeRef(_i_421);
    DeRef(_ob_422);
    return 0;
L1: 

    /** list.e:79		flag = 1*/
    _flag_420 = 1;

    /** list.e:80		for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_419)){
            _114 = SEQ_PTR(_x_419)->length;
    }
    else {
        _114 = 1;
    }
    {
        object _j_427;
        _j_427 = 1;
L2: 
        if (_j_427 > _114){
            goto L3; // [26] 152
        }

        /** list.e:81			ob = x[j]*/
        DeRef(_ob_422);
        _2 = (object)SEQ_PTR(_x_419);
        _ob_422 = (object)*(((s1_ptr)_2)->base + _j_427);
        Ref(_ob_422);

        /** list.e:82			if not atom(ob) then*/
        _116 = IS_ATOM(_ob_422);
        if (_116 != 0)
        goto L4; // [44] 54
        _116 = NOVALUE;

        /** list.e:83				return 0*/
        DeRef(_x_419);
        DeRef(_i_421);
        DeRef(_ob_422);
        return 0;
L4: 

        /** list.e:85			if flag <= 2 then*/
        if (_flag_420 > 2)
        goto L5; // [56] 145

        /** list.e:86				i = ob*/
        Ref(_ob_422);
        DeRef(_i_421);
        _i_421 = _ob_422;

        /** list.e:87				if floor(i) != i then*/
        if (IS_ATOM_INT(_i_421))
        _119 = e_floor(_i_421);
        else
        _119 = unary_op(FLOOR, _i_421);
        if (binary_op_a(EQUALS, _119, _i_421)){
            DeRef(_119);
            _119 = NOVALUE;
            goto L6; // [70] 82
        }
        DeRef(_119);
        _119 = NOVALUE;

        /** list.e:88					flag = 3 -- for double*/
        _flag_420 = 3;
        goto L7; // [79] 144
L6: 

        /** list.e:89				elsif i < (-2147483648) then*/
        if (binary_op_a(GREATEREQ, _i_421, _122)){
            goto L8; // [84] 96
        }

        /** list.e:90					flag = 3 -- for double*/
        _flag_420 = 3;
        goto L7; // [93] 144
L8: 

        /** list.e:91				elsif i > 4294967295 then*/
        if (binary_op_a(LESSEQ, _i_421, _124)){
            goto L9; // [98] 110
        }

        /** list.e:92					flag = 3 -- for double*/
        _flag_420 = 3;
        goto L7; // [107] 144
L9: 

        /** list.e:93				elsif flag = 2 then*/
        if (_flag_420 != 2)
        goto LA; // [112] 131

        /** list.e:94					if i > 2147483647 then*/
        if (binary_op_a(LESSEQ, _i_421, _127)){
            goto L7; // [118] 144
        }

        /** list.e:95						flag = 3 -- for double*/
        _flag_420 = 3;
        goto L7; // [128] 144
LA: 

        /** list.e:97				elsif i < 0 then*/
        if (binary_op_a(GREATEREQ, _i_421, 0)){
            goto LB; // [133] 143
        }

        /** list.e:98					flag = 2 -- for signed int*/
        _flag_420 = 2;
LB: 
L7: 
L5: 

        /** list.e:101		end for*/
        _j_427 = _j_427 + 1;
        goto L2; // [147] 33
L3: 
        ;
    }

    /** list.e:102		return flag -- 3 for double, 2 for signed int, 1 for unsigned int, 0 for linked list*/
    DeRef(_x_419);
    DeRef(_i_421);
    DeRef(_ob_422);
    return _flag_420;
    ;
}
object myarray() __attribute__ ((alias ("_2myarray@4")));


object  __stdcall _2sequence_to_linked_list(object _s_471)
{
    object _ma_472 = NOVALUE;
    object _next_473 = NOVALUE;
    object _tmp_474 = NOVALUE;
    object _a_475 = NOVALUE;
    object _i_476 = NOVALUE;
    object _222 = NOVALUE;
    object _221 = NOVALUE;
    object _220 = NOVALUE;
    object _219 = NOVALUE;
    object _217 = NOVALUE;
    object _215 = NOVALUE;
    object _214 = NOVALUE;
    object _212 = NOVALUE;
    object _211 = NOVALUE;
    object _210 = NOVALUE;
    object _209 = NOVALUE;
    object _207 = NOVALUE;
    object _206 = NOVALUE;
    object _204 = NOVALUE;
    object _203 = NOVALUE;
    object _201 = NOVALUE;
    object _200 = NOVALUE;
    object _199 = NOVALUE;
    object _198 = NOVALUE;
    object _197 = NOVALUE;
    object _196 = NOVALUE;
    object _195 = NOVALUE;
    object _193 = NOVALUE;
    object _192 = NOVALUE;
    object _191 = NOVALUE;
    object _189 = NOVALUE;
    object _188 = NOVALUE;
    object _186 = NOVALUE;
    object _185 = NOVALUE;
    object _184 = NOVALUE;
    object _182 = NOVALUE;
    object _181 = NOVALUE;
    object _179 = NOVALUE;
    object _178 = NOVALUE;
    object _177 = NOVALUE;
    object _175 = NOVALUE;
    object _174 = NOVALUE;
    object _171 = NOVALUE;
    object _170 = NOVALUE;
    object _169 = NOVALUE;
    object _167 = NOVALUE;
    object _166 = NOVALUE;
    object _165 = NOVALUE;
    object _163 = NOVALUE;
    object _159 = NOVALUE;
    object _157 = NOVALUE;
    object _156 = NOVALUE;
    object _155 = NOVALUE;
    object _153 = NOVALUE;
    object _152 = NOVALUE;
    object _150 = NOVALUE;
    object _149 = NOVALUE;
    object _148 = NOVALUE;
    object _147 = NOVALUE;
    object _146 = NOVALUE;
    object _145 = NOVALUE;
    object _144 = NOVALUE;
    object _143 = NOVALUE;
    object _141 = NOVALUE;
    object _140 = NOVALUE;
    object _139 = NOVALUE;
    object _137 = NOVALUE;
    object _0, _1, _2;
    

    /** list.e:151		ma = allocate(SIZE_OF_STRUCT)*/
    _0 = _ma_472;
    _ma_472 = _3allocate(16);
    DeRef(_0);

    /** list.e:152		if integer(s) then -- most of the time it will be an integer(a)*/
    if (IS_ATOM_INT(_s_471))
    _137 = 1;
    else if (IS_ATOM_DBL(_s_471))
    _137 = IS_ATOM_INT(DoubleToInt(_s_471));
    else
    _137 = 0;
    if (_137 == 0)
    {
        _137 = NOVALUE;
        goto L1; // [12] 54
    }
    else{
        _137 = NOVALUE;
    }

    /** list.e:153			i = s*/
    Ref(_s_471);
    _i_476 = _s_471;
    if (!IS_ATOM_INT(_i_476)) {
        _1 = (object)(DBL_PTR(_i_476)->dbl);
        DeRefDS(_i_476);
        _i_476 = _1;
    }

    /** list.e:154			if i >= 0 then*/
    if (_i_476 < 0)
    goto L2; // [24] 36

    /** list.e:155				poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2UINT_FLAG_463)->dbl;
    goto L3; // [33] 42
L2: 

    /** list.e:157				poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2INT_FLAG_461)->dbl;
L3: 

    /** list.e:159			poke4(ma + 4, i)*/
    if (IS_ATOM_INT(_ma_472)) {
        _139 = _ma_472 + 4;
        if ((object)((uintptr_t)_139 + (uintptr_t)HIGH_BITS) >= 0){
            _139 = NewDouble((eudouble)_139);
        }
    }
    else {
        _139 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_139)){
        poke4_addr = (uint32_t *)_139;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_139)->dbl);
    }
    *poke4_addr = (uint32_t)_i_476;
    DeRef(_139);
    _139 = NOVALUE;
    goto L4; // [51] 695
L1: 

    /** list.e:160		elsif atom(s) then*/
    _140 = IS_ATOM(_s_471);
    if (_140 == 0)
    {
        _140 = NOVALUE;
        goto L5; // [59] 212
    }
    else{
        _140 = NOVALUE;
    }

    /** list.e:161			a = s*/
    Ref(_s_471);
    DeRef(_a_475);
    _a_475 = _s_471;

    /** list.e:162			if a = floor(a) then*/
    if (IS_ATOM_INT(_a_475))
    _141 = e_floor(_a_475);
    else
    _141 = unary_op(FLOOR, _a_475);
    if (binary_op_a(NOTEQ, _a_475, _141)){
        DeRef(_141);
        _141 = NOVALUE;
        goto L6; // [72] 179
    }
    DeRef(_141);
    _141 = NOVALUE;

    /** list.e:164				if a <= #FFFFFFFF and a >= 0 then*/
    if (IS_ATOM_INT(_a_475)) {
        _143 = ((eudouble)_a_475 <= DBL_PTR(_124)->dbl);
    }
    else {
        _143 = (DBL_PTR(_a_475)->dbl <= DBL_PTR(_124)->dbl);
    }
    if (_143 == 0) {
        goto L7; // [82] 111
    }
    if (IS_ATOM_INT(_a_475)) {
        _145 = (_a_475 >= 0);
    }
    else {
        _145 = (DBL_PTR(_a_475)->dbl >= (eudouble)0);
    }
    if (_145 == 0)
    {
        DeRef(_145);
        _145 = NOVALUE;
        goto L7; // [91] 111
    }
    else{
        DeRef(_145);
        _145 = NOVALUE;
    }

    /** list.e:165					poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2UINT_FLAG_463)->dbl;

    /** list.e:166					poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_472)) {
        _146 = _ma_472 + 4;
        if ((object)((uintptr_t)_146 + (uintptr_t)HIGH_BITS) >= 0){
            _146 = NewDouble((eudouble)_146);
        }
    }
    else {
        _146 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_146)){
        poke4_addr = (uint32_t *)_146;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_146)->dbl);
    }
    if (IS_ATOM_INT(_a_475)) {
        *poke4_addr = (uint32_t)_a_475;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_a_475)->dbl;
    }
    DeRef(_146);
    _146 = NOVALUE;
    goto L4; // [108] 695
L7: 

    /** list.e:167				elsif a <= 2147483647 and a >= -2147483648 then*/
    if (IS_ATOM_INT(_a_475)) {
        _147 = ((eudouble)_a_475 <= DBL_PTR(_127)->dbl);
    }
    else {
        _147 = (DBL_PTR(_a_475)->dbl <= DBL_PTR(_127)->dbl);
    }
    if (_147 == 0) {
        goto L8; // [117] 146
    }
    if (IS_ATOM_INT(_a_475)) {
        _149 = ((eudouble)_a_475 >= DBL_PTR(_122)->dbl);
    }
    else {
        _149 = (DBL_PTR(_a_475)->dbl >= DBL_PTR(_122)->dbl);
    }
    if (_149 == 0)
    {
        DeRef(_149);
        _149 = NOVALUE;
        goto L8; // [126] 146
    }
    else{
        DeRef(_149);
        _149 = NOVALUE;
    }

    /** list.e:168					poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2INT_FLAG_461)->dbl;

    /** list.e:169					poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_472)) {
        _150 = _ma_472 + 4;
        if ((object)((uintptr_t)_150 + (uintptr_t)HIGH_BITS) >= 0){
            _150 = NewDouble((eudouble)_150);
        }
    }
    else {
        _150 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_150)){
        poke4_addr = (uint32_t *)_150;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_150)->dbl);
    }
    if (IS_ATOM_INT(_a_475)) {
        *poke4_addr = (uint32_t)_a_475;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_a_475)->dbl;
    }
    DeRef(_150);
    _150 = NOVALUE;
    goto L4; // [143] 695
L8: 

    /** list.e:171					tmp = allocate(8)*/
    _0 = _tmp_474;
    _tmp_474 = _3allocate(8);
    DeRef(_0);

    /** list.e:172					poke(tmp, atom_to_float64(a))*/
    Ref(_a_475);
    _152 = _3atom_to_float64(_a_475);
    if (IS_ATOM_INT(_tmp_474)){
        poke_addr = (uint8_t *)_tmp_474;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_tmp_474)->dbl);
    }
    if (IS_ATOM_INT(_152)) {
        *poke_addr = (uint8_t)_152;
    }
    else if (IS_ATOM(_152)) {
        *poke_addr = (uint8_t)DBL_PTR(_152)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_152);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_152);
    _152 = NOVALUE;

    /** list.e:173					poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2DOUBLE_FLAG_459)->dbl;

    /** list.e:174					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _153 = _ma_472 + 4;
        if ((object)((uintptr_t)_153 + (uintptr_t)HIGH_BITS) >= 0){
            _153 = NewDouble((eudouble)_153);
        }
    }
    else {
        _153 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_153)){
        poke4_addr = (uint32_t *)_153;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_153)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_153);
    _153 = NOVALUE;
    goto L4; // [176] 695
L6: 

    /** list.e:177				tmp = allocate(8)*/
    _0 = _tmp_474;
    _tmp_474 = _3allocate(8);
    DeRef(_0);

    /** list.e:178				poke(tmp, atom_to_float64(a))*/
    Ref(_a_475);
    _155 = _3atom_to_float64(_a_475);
    if (IS_ATOM_INT(_tmp_474)){
        poke_addr = (uint8_t *)_tmp_474;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_tmp_474)->dbl);
    }
    if (IS_ATOM_INT(_155)) {
        *poke_addr = (uint8_t)_155;
    }
    else if (IS_ATOM(_155)) {
        *poke_addr = (uint8_t)DBL_PTR(_155)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_155);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_155);
    _155 = NOVALUE;

    /** list.e:179				poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2DOUBLE_FLAG_459)->dbl;

    /** list.e:180				poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _156 = _ma_472 + 4;
        if ((object)((uintptr_t)_156 + (uintptr_t)HIGH_BITS) >= 0){
            _156 = NewDouble((eudouble)_156);
        }
    }
    else {
        _156 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_156)){
        poke4_addr = (uint32_t *)_156;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_156)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_156);
    _156 = NOVALUE;
    goto L4; // [209] 695
L5: 

    /** list.e:182		elsif length(s) = 0 then*/
    if (IS_SEQUENCE(_s_471)){
            _157 = SEQ_PTR(_s_471)->length;
    }
    else {
        _157 = 1;
    }
    if (_157 != 0)
    goto L9; // [217] 233

    /** list.e:183			poke4(ma, {NULL,NULL})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _159 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    _1 = (object)SEQ_PTR(_159);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke4_addr++ = (int32_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_159);
    _159 = NOVALUE;
    goto L4; // [230] 695
L9: 

    /** list.e:185			if not always_linked_list then*/
    if (_2always_linked_list_386 != 0)
    goto LA; // [237] 548

    /** list.e:186				i = mystring(s)*/
    Ref(_s_471);
    _i_476 = _2mystring(_s_471);
    if (!IS_ATOM_INT(_i_476)) {
        _1 = (object)(DBL_PTR(_i_476)->dbl);
        DeRefDS(_i_476);
        _i_476 = _1;
    }

    /** list.e:187				if i then -- string*/
    if (_i_476 == 0)
    {
        goto LB; // [250] 338
    }
    else{
    }

    /** list.e:188					if i = 2 then*/
    if (_i_476 != 2)
    goto LC; // [255] 297

    /** list.e:190						tmp = allocate(length(s))*/
    if (IS_SEQUENCE(_s_471)){
            _163 = SEQ_PTR(_s_471)->length;
    }
    else {
        _163 = 1;
    }
    _0 = _tmp_474;
    _tmp_474 = _3allocate(_163);
    DeRef(_0);
    _163 = NOVALUE;

    /** list.e:191						poke(tmp, s)*/
    if (IS_ATOM_INT(_tmp_474)){
        poke_addr = (uint8_t *)_tmp_474;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_tmp_474)->dbl);
    }
    if (IS_ATOM_INT(_s_471)) {
        *poke_addr = (uint8_t)_s_471;
    }
    else if (IS_ATOM(_s_471)) {
        *poke_addr = (uint8_t)DBL_PTR(_s_471)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_s_471);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** list.e:192						poke4(ma, or_bits(CBYTES, length(s))) -- needs a check for MAX_LENGTH*/
    if (IS_SEQUENCE(_s_471)){
            _165 = SEQ_PTR(_s_471)->length;
    }
    else {
        _165 = 1;
    }
    temp_d.dbl = (eudouble)_165;
    _166 = Dor_bits(DBL_PTR(_2CBYTES_468), &temp_d);
    _165 = NOVALUE;
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    if (IS_ATOM_INT(_166)) {
        *poke4_addr = (uint32_t)_166;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_166)->dbl;
    }
    DeRef(_166);
    _166 = NOVALUE;

    /** list.e:193						poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _167 = _ma_472 + 4;
        if ((object)((uintptr_t)_167 + (uintptr_t)HIGH_BITS) >= 0){
            _167 = NewDouble((eudouble)_167);
        }
    }
    else {
        _167 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_167)){
        poke4_addr = (uint32_t *)_167;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_167)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_167);
    _167 = NOVALUE;
    goto LD; // [294] 318
LC: 

    /** list.e:196						tmp = allocate_string(s)*/
    Ref(_s_471);
    _0 = _tmp_474;
    _tmp_474 = _3allocate_string(_s_471);
    DeRef(_0);

    /** list.e:197						poke4(ma, CSTRING) -- why?*/
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)DBL_PTR(_2CSTRING_467)->dbl;

    /** list.e:198						poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _169 = _ma_472 + 4;
        if ((object)((uintptr_t)_169 + (uintptr_t)HIGH_BITS) >= 0){
            _169 = NewDouble((eudouble)_169);
        }
    }
    else {
        _169 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_169)){
        poke4_addr = (uint32_t *)_169;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_169)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_169);
    _169 = NOVALUE;
LD: 

    /** list.e:200					poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_472)) {
        _170 = _ma_472 + 8;
        if ((object)((uintptr_t)_170 + (uintptr_t)HIGH_BITS) >= 0){
            _170 = NewDouble((eudouble)_170);
        }
    }
    else {
        _170 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)8);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _171 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_170)){
        poke4_addr = (uint32_t *)_170;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_170)->dbl);
    }
    _1 = (object)SEQ_PTR(_171);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke4_addr++ = (int32_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_170);
    _170 = NOVALUE;
    DeRefDS(_171);
    _171 = NOVALUE;

    /** list.e:201					return ma*/
    DeRef(_s_471);
    DeRef(_next_473);
    DeRef(_tmp_474);
    DeRef(_a_475);
    DeRef(_143);
    _143 = NOVALUE;
    DeRef(_147);
    _147 = NOVALUE;
    return _ma_472;
LB: 

    /** list.e:203				i = myarray(s)*/
    Ref(_s_471);
    _i_476 = _2myarray(_s_471);
    if (!IS_ATOM_INT(_i_476)) {
        _1 = (object)(DBL_PTR(_i_476)->dbl);
        DeRefDS(_i_476);
        _i_476 = _1;
    }

    /** list.e:204				if i then*/
    if (_i_476 == 0)
    {
        goto LE; // [348] 547
    }
    else{
    }

    /** list.e:205					if i = 1 then*/
    if (_i_476 != 1)
    goto LF; // [353] 399

    /** list.e:207						tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_471)){
            _174 = SEQ_PTR(_s_471)->length;
    }
    else {
        _174 = 1;
    }
    if (_174 == (short)_174){
        _175 = _174 * 4;
    }
    else{
        _175 = NewDouble(_174 * (eudouble)4);
    }
    _174 = NOVALUE;
    _0 = _tmp_474;
    _tmp_474 = _3allocate(_175);
    DeRef(_0);
    _175 = NOVALUE;

    /** list.e:208						poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_474)){
        poke4_addr = (uint32_t *)_tmp_474;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_tmp_474)->dbl);
    }
    if (IS_ATOM_INT(_s_471)) {
        *poke4_addr = (uint32_t)_s_471;
    }
    else if (IS_ATOM(_s_471)) {
        *poke4_addr = (uint32_t)DBL_PTR(_s_471)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_s_471);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** list.e:209						poke4(ma, or_bits(UINT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_471)){
            _177 = SEQ_PTR(_s_471)->length;
    }
    else {
        _177 = 1;
    }
    temp_d.dbl = (eudouble)_177;
    _178 = Dor_bits(DBL_PTR(_2UINT_FLAG_463), &temp_d);
    _177 = NOVALUE;
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    if (IS_ATOM_INT(_178)) {
        *poke4_addr = (uint32_t)_178;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_178)->dbl;
    }
    DeRef(_178);
    _178 = NOVALUE;

    /** list.e:210						poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _179 = _ma_472 + 4;
        if ((object)((uintptr_t)_179 + (uintptr_t)HIGH_BITS) >= 0){
            _179 = NewDouble((eudouble)_179);
        }
    }
    else {
        _179 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_179)){
        poke4_addr = (uint32_t *)_179;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_179)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_179);
    _179 = NOVALUE;
    goto L10; // [396] 527
LF: 

    /** list.e:211					elsif i = 2 then*/
    if (_i_476 != 2)
    goto L11; // [401] 447

    /** list.e:213						tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_471)){
            _181 = SEQ_PTR(_s_471)->length;
    }
    else {
        _181 = 1;
    }
    if (_181 == (short)_181){
        _182 = _181 * 4;
    }
    else{
        _182 = NewDouble(_181 * (eudouble)4);
    }
    _181 = NOVALUE;
    _0 = _tmp_474;
    _tmp_474 = _3allocate(_182);
    DeRef(_0);
    _182 = NOVALUE;

    /** list.e:214						poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_474)){
        poke4_addr = (uint32_t *)_tmp_474;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_tmp_474)->dbl);
    }
    if (IS_ATOM_INT(_s_471)) {
        *poke4_addr = (uint32_t)_s_471;
    }
    else if (IS_ATOM(_s_471)) {
        *poke4_addr = (uint32_t)DBL_PTR(_s_471)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_s_471);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** list.e:215						poke4(ma, or_bits(INT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_471)){
            _184 = SEQ_PTR(_s_471)->length;
    }
    else {
        _184 = 1;
    }
    temp_d.dbl = (eudouble)_184;
    _185 = Dor_bits(DBL_PTR(_2INT_FLAG_461), &temp_d);
    _184 = NOVALUE;
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    if (IS_ATOM_INT(_185)) {
        *poke4_addr = (uint32_t)_185;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_185)->dbl;
    }
    DeRef(_185);
    _185 = NOVALUE;

    /** list.e:216						poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _186 = _ma_472 + 4;
        if ((object)((uintptr_t)_186 + (uintptr_t)HIGH_BITS) >= 0){
            _186 = NewDouble((eudouble)_186);
        }
    }
    else {
        _186 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_186)){
        poke4_addr = (uint32_t *)_186;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_186)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_186);
    _186 = NOVALUE;
    goto L10; // [444] 527
L11: 

    /** list.e:217					elsif i = 3 then*/
    if (_i_476 != 3)
    goto L12; // [449] 526

    /** list.e:219						tmp = allocate(length(s) * 8)*/
    if (IS_SEQUENCE(_s_471)){
            _188 = SEQ_PTR(_s_471)->length;
    }
    else {
        _188 = 1;
    }
    if (_188 == (short)_188){
        _189 = _188 * 8;
    }
    else{
        _189 = NewDouble(_188 * (eudouble)8);
    }
    _188 = NOVALUE;
    _0 = _tmp_474;
    _tmp_474 = _3allocate(_189);
    DeRef(_0);
    _189 = NOVALUE;

    /** list.e:220						for j = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_471)){
            _191 = SEQ_PTR(_s_471)->length;
    }
    else {
        _191 = 1;
    }
    {
        object _j_562;
        _j_562 = 1;
L13: 
        if (_j_562 > _191){
            goto L14; // [471] 504
        }

        /** list.e:221							poke(tmp, atom_to_float64(s[j]))*/
        _2 = (object)SEQ_PTR(_s_471);
        _192 = (object)*(((s1_ptr)_2)->base + _j_562);
        Ref(_192);
        _193 = _3atom_to_float64(_192);
        _192 = NOVALUE;
        if (IS_ATOM_INT(_tmp_474)){
            poke_addr = (uint8_t *)_tmp_474;
        }
        else {
            poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_tmp_474)->dbl);
        }
        if (IS_ATOM_INT(_193)) {
            *poke_addr = (uint8_t)_193;
        }
        else if (IS_ATOM(_193)) {
            *poke_addr = (uint8_t)DBL_PTR(_193)->dbl;
        }
        else {
            _1 = (object)SEQ_PTR(_193);
            _1 = (object)((s1_ptr)_1)->base;
            while (1) {
                _1 += sizeof(object);
                _2 = *((object *)_1);
                if (IS_ATOM_INT(_2)) {
                    *poke_addr++ = (uint8_t)_2;
                }
                else if (_2 == NOVALUE) {
                    break;
                }
                else {
                    *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
                }
            }
        }
        DeRef(_193);
        _193 = NOVALUE;

        /** list.e:222							tmp += 8*/
        _0 = _tmp_474;
        if (IS_ATOM_INT(_tmp_474)) {
            _tmp_474 = _tmp_474 + 8;
            if ((object)((uintptr_t)_tmp_474 + (uintptr_t)HIGH_BITS) >= 0){
                _tmp_474 = NewDouble((eudouble)_tmp_474);
            }
        }
        else {
            _tmp_474 = NewDouble(DBL_PTR(_tmp_474)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** list.e:223						end for*/
        _j_562 = _j_562 + 1;
        goto L13; // [499] 478
L14: 
        ;
    }

    /** list.e:224						poke4(ma, or_bits(DOUBLE_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_471)){
            _195 = SEQ_PTR(_s_471)->length;
    }
    else {
        _195 = 1;
    }
    temp_d.dbl = (eudouble)_195;
    _196 = Dor_bits(DBL_PTR(_2DOUBLE_FLAG_459), &temp_d);
    _195 = NOVALUE;
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    if (IS_ATOM_INT(_196)) {
        *poke4_addr = (uint32_t)_196;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_196)->dbl;
    }
    DeRef(_196);
    _196 = NOVALUE;

    /** list.e:225						poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_472)) {
        _197 = _ma_472 + 4;
        if ((object)((uintptr_t)_197 + (uintptr_t)HIGH_BITS) >= 0){
            _197 = NewDouble((eudouble)_197);
        }
    }
    else {
        _197 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_197)){
        poke4_addr = (uint32_t *)_197;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_197)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_197);
    _197 = NOVALUE;
L12: 
L10: 

    /** list.e:227					poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_472)) {
        _198 = _ma_472 + 8;
        if ((object)((uintptr_t)_198 + (uintptr_t)HIGH_BITS) >= 0){
            _198 = NewDouble((eudouble)_198);
        }
    }
    else {
        _198 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)8);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _199 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_198)){
        poke4_addr = (uint32_t *)_198;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_198)->dbl);
    }
    _1 = (object)SEQ_PTR(_199);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke4_addr++ = (int32_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_198);
    _198 = NOVALUE;
    DeRefDS(_199);
    _199 = NOVALUE;

    /** list.e:228					return ma*/
    DeRef(_s_471);
    DeRef(_next_473);
    DeRef(_tmp_474);
    DeRef(_a_475);
    DeRef(_143);
    _143 = NOVALUE;
    DeRef(_147);
    _147 = NOVALUE;
    return _ma_472;
LE: 
LA: 

    /** list.e:232			next = NULL -- 0*/
    DeRef(_next_473);
    _next_473 = 0;

    /** list.e:233			poke4(ma, length(s))*/
    if (IS_SEQUENCE(_s_471)){
            _200 = SEQ_PTR(_s_471)->length;
    }
    else {
        _200 = 1;
    }
    if (IS_ATOM_INT(_ma_472)){
        poke4_addr = (uint32_t *)_ma_472;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_472)->dbl);
    }
    *poke4_addr = (uint32_t)_200;
    _200 = NOVALUE;

    /** list.e:234			if length(s) then*/
    if (IS_SEQUENCE(_s_471)){
            _201 = SEQ_PTR(_s_471)->length;
    }
    else {
        _201 = 1;
    }
    if (_201 == 0)
    {
        _201 = NOVALUE;
        goto L15; // [566] 678
    }
    else{
        _201 = NOVALUE;
    }

    /** list.e:235				a = allocate(8) -- iterators to beginning and end of list*/
    _0 = _a_475;
    _a_475 = _3allocate(8);
    DeRef(_0);

    /** list.e:237				next = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_471)){
            _203 = SEQ_PTR(_s_471)->length;
    }
    else {
        _203 = 1;
    }
    _2 = (object)SEQ_PTR(_s_471);
    _204 = (object)*(((s1_ptr)_2)->base + _203);
    Ref(_204);
    _next_473 = _2sequence_to_linked_list(_204);
    _204 = NOVALUE;

    /** list.e:238				s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_471)){
            _206 = SEQ_PTR(_s_471)->length;
    }
    else {
        _206 = 1;
    }
    _207 = _206 - 1;
    _206 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_471;
    RHS_Slice(_s_471, 1, _207);

    /** list.e:239				poke4(a + 4, next) -- store the end iterator*/
    if (IS_ATOM_INT(_a_475)) {
        _209 = _a_475 + 4;
        if ((object)((uintptr_t)_209 + (uintptr_t)HIGH_BITS) >= 0){
            _209 = NewDouble((eudouble)_209);
        }
    }
    else {
        _209 = NewDouble(DBL_PTR(_a_475)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_209)){
        poke4_addr = (uint32_t *)_209;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_209)->dbl);
    }
    if (IS_ATOM_INT(_next_473)) {
        *poke4_addr = (uint32_t)_next_473;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_next_473)->dbl;
    }
    DeRef(_209);
    _209 = NOVALUE;

    /** list.e:240				while length(s) do*/
L16: 
    if (IS_SEQUENCE(_s_471)){
            _210 = SEQ_PTR(_s_471)->length;
    }
    else {
        _210 = 1;
    }
    if (_210 == 0)
    {
        _210 = NOVALUE;
        goto L17; // [619] 677
    }
    else{
        _210 = NOVALUE;
    }

    /** list.e:241					tmp = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_471)){
            _211 = SEQ_PTR(_s_471)->length;
    }
    else {
        _211 = 1;
    }
    _2 = (object)SEQ_PTR(_s_471);
    _212 = (object)*(((s1_ptr)_2)->base + _211);
    Ref(_212);
    _0 = _tmp_474;
    _tmp_474 = _2sequence_to_linked_list(_212);
    DeRef(_0);
    _212 = NOVALUE;

    /** list.e:242					s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_471)){
            _214 = SEQ_PTR(_s_471)->length;
    }
    else {
        _214 = 1;
    }
    _215 = _214 - 1;
    _214 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_471;
    RHS_Slice(_s_471, 1, _215);

    /** list.e:243					poke4(next + 8, tmp)*/
    if (IS_ATOM_INT(_next_473)) {
        _217 = _next_473 + 8;
        if ((object)((uintptr_t)_217 + (uintptr_t)HIGH_BITS) >= 0){
            _217 = NewDouble((eudouble)_217);
        }
    }
    else {
        _217 = NewDouble(DBL_PTR(_next_473)->dbl + (eudouble)8);
    }
    if (IS_ATOM_INT(_217)){
        poke4_addr = (uint32_t *)_217;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_217)->dbl);
    }
    if (IS_ATOM_INT(_tmp_474)) {
        *poke4_addr = (uint32_t)_tmp_474;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_tmp_474)->dbl;
    }
    DeRef(_217);
    _217 = NOVALUE;

    /** list.e:244					poke4(tmp + 12, next)*/
    if (IS_ATOM_INT(_tmp_474)) {
        _219 = _tmp_474 + 12;
        if ((object)((uintptr_t)_219 + (uintptr_t)HIGH_BITS) >= 0){
            _219 = NewDouble((eudouble)_219);
        }
    }
    else {
        _219 = NewDouble(DBL_PTR(_tmp_474)->dbl + (eudouble)12);
    }
    if (IS_ATOM_INT(_219)){
        poke4_addr = (uint32_t *)_219;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_219)->dbl);
    }
    if (IS_ATOM_INT(_next_473)) {
        *poke4_addr = (uint32_t)_next_473;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_next_473)->dbl;
    }
    DeRef(_219);
    _219 = NOVALUE;

    /** list.e:245					next = tmp*/
    Ref(_tmp_474);
    DeRef(_next_473);
    _next_473 = _tmp_474;

    /** list.e:246				end while*/
    goto L16; // [674] 616
L17: 
L15: 

    /** list.e:248			poke4(a, next) -- store the beginning iterator*/
    if (IS_ATOM_INT(_a_475)){
        poke4_addr = (uint32_t *)_a_475;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_a_475)->dbl);
    }
    if (IS_ATOM_INT(_next_473)) {
        *poke4_addr = (uint32_t)_next_473;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_next_473)->dbl;
    }

    /** list.e:249			poke4(ma + 4, a) -- point data to the iterators*/
    if (IS_ATOM_INT(_ma_472)) {
        _220 = _ma_472 + 4;
        if ((object)((uintptr_t)_220 + (uintptr_t)HIGH_BITS) >= 0){
            _220 = NewDouble((eudouble)_220);
        }
    }
    else {
        _220 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)4);
    }
    if (IS_ATOM_INT(_220)){
        poke4_addr = (uint32_t *)_220;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_220)->dbl);
    }
    if (IS_ATOM_INT(_a_475)) {
        *poke4_addr = (uint32_t)_a_475;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_a_475)->dbl;
    }
    DeRef(_220);
    _220 = NOVALUE;
L4: 

    /** list.e:252		poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_472)) {
        _221 = _ma_472 + 8;
        if ((object)((uintptr_t)_221 + (uintptr_t)HIGH_BITS) >= 0){
            _221 = NewDouble((eudouble)_221);
        }
    }
    else {
        _221 = NewDouble(DBL_PTR(_ma_472)->dbl + (eudouble)8);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0;
    ((intptr_t *)_2)[2] = 0;
    _222 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_221)){
        poke4_addr = (uint32_t *)_221;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_221)->dbl);
    }
    _1 = (object)SEQ_PTR(_222);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke4_addr++ = (int32_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_221);
    _221 = NOVALUE;
    DeRefDS(_222);
    _222 = NOVALUE;

    /** list.e:253		return ma*/
    DeRef(_s_471);
    DeRef(_next_473);
    DeRef(_tmp_474);
    DeRef(_a_475);
    DeRef(_143);
    _143 = NOVALUE;
    DeRef(_207);
    _207 = NOVALUE;
    DeRef(_147);
    _147 = NOVALUE;
    DeRef(_215);
    _215 = NOVALUE;
    return _ma_472;
    ;
}
object sequence_to_linked_list() __attribute__ ((alias ("_2sequence_to_linked_list@4")));


void  __stdcall _2free_linked_list(object _ma_601)
{
    object _len_602 = NOVALUE;
    object _tmp_603 = NOVALUE;
    object _next_604 = NOVALUE;
    object _ptr_605 = NOVALUE;
    object _234 = NOVALUE;
    object _232 = NOVALUE;
    object _231 = NOVALUE;
    object _227 = NOVALUE;
    object _226 = NOVALUE;
    object _224 = NOVALUE;
    object _0, _1, _2;
    

    /** list.e:257		len = peek4u(ma)*/
    DeRef(_len_602);
    if (IS_ATOM_INT(_ma_601)) {
        _len_602 = (object)*(uint32_t *)_ma_601;
        if ((uintptr_t)_len_602 > (uintptr_t)MAXINT){
            _len_602 = NewDouble((eudouble)(uintptr_t)_len_602);
        }
    }
    else {
        _len_602 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_ma_601)->dbl);
        if ((uintptr_t)_len_602 > (uintptr_t)MAXINT){
            _len_602 = NewDouble((eudouble)(uintptr_t)_len_602);
        }
    }

    /** list.e:258		ptr = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_601)) {
        _224 = _ma_601 + 4;
        if ((object)((uintptr_t)_224 + (uintptr_t)HIGH_BITS) >= 0){
            _224 = NewDouble((eudouble)_224);
        }
    }
    else {
        _224 = NewDouble(DBL_PTR(_ma_601)->dbl + (eudouble)4);
    }
    DeRef(_ptr_605);
    if (IS_ATOM_INT(_224)) {
        _ptr_605 = (object)*(uint32_t *)_224;
        if ((uintptr_t)_ptr_605 > (uintptr_t)MAXINT){
            _ptr_605 = NewDouble((eudouble)(uintptr_t)_ptr_605);
        }
    }
    else {
        _ptr_605 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_224)->dbl);
        if ((uintptr_t)_ptr_605 > (uintptr_t)MAXINT){
            _ptr_605 = NewDouble((eudouble)(uintptr_t)_ptr_605);
        }
    }
    DeRef(_224);
    _224 = NOVALUE;

    /** list.e:259		if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_602)) {
        temp_d.dbl = (eudouble)_len_602;
        _226 = Dand_bits(&temp_d, DBL_PTR(_2SIGN_FLAG_458));
    }
    else {
        _226 = Dand_bits(DBL_PTR(_len_602), DBL_PTR(_2SIGN_FLAG_458));
    }
    if (_226 == 0) {
        DeRef(_226);
        _226 = NOVALUE;
        goto L1; // [21] 57
    }
    else {
        if (!IS_ATOM_INT(_226) && DBL_PTR(_226)->dbl == 0.0){
            DeRef(_226);
            _226 = NOVALUE;
            goto L1; // [21] 57
        }
        DeRef(_226);
        _226 = NOVALUE;
    }
    DeRef(_226);
    _226 = NOVALUE;

    /** list.e:260		 	if and_bits(len, MAX_LENGTH) then*/
    if (IS_ATOM_INT(_len_602)) {
        {uintptr_t tu;
             tu = (uintptr_t)_len_602 & (uintptr_t)268435455;
             _227 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)268435455;
        _227 = Dand_bits(DBL_PTR(_len_602), &temp_d);
    }
    if (_227 == 0) {
        DeRef(_227);
        _227 = NOVALUE;
        goto L2; // [30] 41
    }
    else {
        if (!IS_ATOM_INT(_227) && DBL_PTR(_227)->dbl == 0.0){
            DeRef(_227);
            _227 = NOVALUE;
            goto L2; // [30] 41
        }
        DeRef(_227);
        _227 = NOVALUE;
    }
    DeRef(_227);
    _227 = NOVALUE;

    /** list.e:262				free(ptr)*/
    Ref(_ptr_605);
    _3free(_ptr_605);
    goto L3; // [38] 116
L2: 

    /** list.e:263			elsif len = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _len_602, _2DOUBLE_FLAG_459)){
        goto L3; // [43] 116
    }

    /** list.e:264				free(ptr)*/
    Ref(_ptr_605);
    _3free(_ptr_605);
    goto L3; // [54] 116
L1: 

    /** list.e:266		elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_602, 0)){
        goto L4; // [59] 115
    }

    /** list.e:267			tmp = peek4u(ptr) -- iterator to the beginning of the list*/
    DeRef(_tmp_603);
    if (IS_ATOM_INT(_ptr_605)) {
        _tmp_603 = (object)*(uint32_t *)_ptr_605;
        if ((uintptr_t)_tmp_603 > (uintptr_t)MAXINT){
            _tmp_603 = NewDouble((eudouble)(uintptr_t)_tmp_603);
        }
    }
    else {
        _tmp_603 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_ptr_605)->dbl);
        if ((uintptr_t)_tmp_603 > (uintptr_t)MAXINT){
            _tmp_603 = NewDouble((eudouble)(uintptr_t)_tmp_603);
        }
    }

    /** list.e:268			free(ptr) -- free the iterators*/
    Ref(_ptr_605);
    _3free(_ptr_605);

    /** list.e:269			for i = 1 to len do*/
    Ref(_len_602);
    DeRef(_231);
    _231 = _len_602;
    {
        object _i_622;
        _i_622 = 1;
L5: 
        if (binary_op_a(GREATER, _i_622, _231)){
            goto L6; // [78] 114
        }

        /** list.e:270				next = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_603)) {
            _232 = _tmp_603 + 12;
            if ((object)((uintptr_t)_232 + (uintptr_t)HIGH_BITS) >= 0){
                _232 = NewDouble((eudouble)_232);
            }
        }
        else {
            _232 = NewDouble(DBL_PTR(_tmp_603)->dbl + (eudouble)12);
        }
        DeRef(_next_604);
        if (IS_ATOM_INT(_232)) {
            _next_604 = (object)*(uint32_t *)_232;
            if ((uintptr_t)_next_604 > (uintptr_t)MAXINT){
                _next_604 = NewDouble((eudouble)(uintptr_t)_next_604);
            }
        }
        else {
            _next_604 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_232)->dbl);
            if ((uintptr_t)_next_604 > (uintptr_t)MAXINT){
                _next_604 = NewDouble((eudouble)(uintptr_t)_next_604);
            }
        }
        DeRef(_232);
        _232 = NOVALUE;

        /** list.e:271				free_linked_list(tmp)*/
        Ref(_tmp_603);
        DeRef(_234);
        _234 = _tmp_603;
        _2free_linked_list(_234);
        _234 = NOVALUE;

        /** list.e:272				tmp = next*/
        Ref(_next_604);
        DeRef(_tmp_603);
        _tmp_603 = _next_604;

        /** list.e:273			end for*/
        _0 = _i_622;
        if (IS_ATOM_INT(_i_622)) {
            _i_622 = _i_622 + 1;
            if ((object)((uintptr_t)_i_622 +(uintptr_t) HIGH_BITS) >= 0){
                _i_622 = NewDouble((eudouble)_i_622);
            }
        }
        else {
            _i_622 = binary_op_a(PLUS, _i_622, 1);
        }
        DeRef(_0);
        goto L5; // [109] 85
L6: 
        ;
        DeRef(_i_622);
    }
L4: 
L3: 

    /** list.e:282		free(ma)*/
    Ref(_ma_601);
    _3free(_ma_601);

    /** list.e:283	end procedure*/
    DeRef(_ma_601);
    DeRef(_len_602);
    DeRef(_tmp_603);
    DeRef(_next_604);
    DeRef(_ptr_605);
    return;
    ;
}
void free_linked_list() __attribute__ ((alias ("_2free_linked_list@4")));


object  __stdcall _2linked_list_to_sequence(object _ma_630)
{
    object _len_631 = NOVALUE;
    object _tmp_632 = NOVALUE;
    object _val_633 = NOVALUE;
    object _s_634 = NOVALUE;
    object _293 = NOVALUE;
    object _292 = NOVALUE;
    object _290 = NOVALUE;
    object _289 = NOVALUE;
    object _288 = NOVALUE;
    object _287 = NOVALUE;
    object _283 = NOVALUE;
    object _280 = NOVALUE;
    object _278 = NOVALUE;
    object _277 = NOVALUE;
    object _275 = NOVALUE;
    object _274 = NOVALUE;
    object _273 = NOVALUE;
    object _272 = NOVALUE;
    object _268 = NOVALUE;
    object _266 = NOVALUE;
    object _265 = NOVALUE;
    object _264 = NOVALUE;
    object _262 = NOVALUE;
    object _261 = NOVALUE;
    object _260 = NOVALUE;
    object _259 = NOVALUE;
    object _256 = NOVALUE;
    object _253 = NOVALUE;
    object _251 = NOVALUE;
    object _250 = NOVALUE;
    object _247 = NOVALUE;
    object _245 = NOVALUE;
    object _244 = NOVALUE;
    object _238 = NOVALUE;
    object _236 = NOVALUE;
    object _0, _1, _2;
    

    /** list.e:289		len = peek4u(ma)*/
    DeRef(_len_631);
    if (IS_ATOM_INT(_ma_630)) {
        _len_631 = (object)*(uint32_t *)_ma_630;
        if ((uintptr_t)_len_631 > (uintptr_t)MAXINT){
            _len_631 = NewDouble((eudouble)(uintptr_t)_len_631);
        }
    }
    else {
        _len_631 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_ma_630)->dbl);
        if ((uintptr_t)_len_631 > (uintptr_t)MAXINT){
            _len_631 = NewDouble((eudouble)(uintptr_t)_len_631);
        }
    }

    /** list.e:290		if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_631)) {
        temp_d.dbl = (eudouble)_len_631;
        _236 = Dand_bits(&temp_d, DBL_PTR(_2SIGN_FLAG_458));
    }
    else {
        _236 = Dand_bits(DBL_PTR(_len_631), DBL_PTR(_2SIGN_FLAG_458));
    }
    if (_236 == 0) {
        DeRef(_236);
        _236 = NOVALUE;
        goto L1; // [12] 380
    }
    else {
        if (!IS_ATOM_INT(_236) && DBL_PTR(_236)->dbl == 0.0){
            DeRef(_236);
            _236 = NOVALUE;
            goto L1; // [12] 380
        }
        DeRef(_236);
        _236 = NOVALUE;
    }
    DeRef(_236);
    _236 = NOVALUE;

    /** list.e:291			if len = CSTRING then*/
    if (binary_op_a(NOTEQ, _len_631, _2CSTRING_467)){
        goto L2; // [17] 44
    }

    /** list.e:293				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_630)) {
        _238 = _ma_630 + 4;
        if ((object)((uintptr_t)_238 + (uintptr_t)HIGH_BITS) >= 0){
            _238 = NewDouble((eudouble)_238);
        }
    }
    else {
        _238 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    DeRef(_tmp_632);
    if (IS_ATOM_INT(_238)) {
        _tmp_632 = (object)*(uint32_t *)_238;
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_238)->dbl);
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    DeRef(_238);
    _238 = NOVALUE;

    /** list.e:294				s = peek_string(tmp)*/
    DeRef(_s_634);
    if (IS_ATOM_INT(_tmp_632)) {
        _s_634 =  NewString((char *)_tmp_632);
    }
    else {
        _s_634 = NewString((char *)(uintptr_t)(DBL_PTR(_tmp_632)->dbl));
    }

    /** list.e:295				return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
L2: 

    /** list.e:297			val = and_bits(len, SIGN_MASK)*/
    DeRef(_val_633);
    if (IS_ATOM_INT(_len_631)) {
        temp_d.dbl = (eudouble)_len_631;
        _val_633 = Dand_bits(&temp_d, DBL_PTR(_2SIGN_MASK_456));
    }
    else {
        _val_633 = Dand_bits(DBL_PTR(_len_631), DBL_PTR(_2SIGN_MASK_456));
    }

    /** list.e:298			len = and_bits(len, MAX_LENGTH)*/
    _0 = _len_631;
    if (IS_ATOM_INT(_len_631)) {
        {uintptr_t tu;
             tu = (uintptr_t)_len_631 & (uintptr_t)268435455;
             _len_631 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)268435455;
        _len_631 = Dand_bits(DBL_PTR(_len_631), &temp_d);
    }
    DeRef(_0);

    /** list.e:299			if val = UINT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_633, _2UINT_FLAG_463)){
        goto L3; // [58] 108
    }

    /** list.e:300				if len then*/
    if (_len_631 == 0) {
        goto L4; // [64] 91
    }
    else {
        if (!IS_ATOM_INT(_len_631) && DBL_PTR(_len_631)->dbl == 0.0){
            goto L4; // [64] 91
        }
    }

    /** list.e:301					s = peek4u({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_630)) {
        _244 = _ma_630 + 4;
        if ((object)((uintptr_t)_244 + (uintptr_t)HIGH_BITS) >= 0){
            _244 = NewDouble((eudouble)_244);
        }
    }
    else {
        _244 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    Ref(_len_631);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _244;
    ((intptr_t *)_2)[2] = _len_631;
    _245 = MAKE_SEQ(_1);
    _244 = NOVALUE;
    DeRef(_s_634);
    _1 = (object)SEQ_PTR(_245);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _s_634 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)*peek4_addr++;
        if ((uintptr_t)_1 > (uintptr_t)MAXINT){
            _1 = NewDouble((eudouble)(uintptr_t)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_245);
    _245 = NOVALUE;

    /** list.e:302					return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
    goto L5; // [88] 107
L4: 

    /** list.e:304					tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_630)) {
        _247 = _ma_630 + 4;
        if ((object)((uintptr_t)_247 + (uintptr_t)HIGH_BITS) >= 0){
            _247 = NewDouble((eudouble)_247);
        }
    }
    else {
        _247 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    DeRef(_tmp_632);
    if (IS_ATOM_INT(_247)) {
        _tmp_632 = (object)*(uint32_t *)_247;
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_247)->dbl);
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    DeRef(_247);
    _247 = NOVALUE;

    /** list.e:305					return tmp*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_val_633);
    DeRef(_s_634);
    return _tmp_632;
L5: 
L3: 

    /** list.e:308			if val = INT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_633, _2INT_FLAG_461)){
        goto L6; // [110] 160
    }

    /** list.e:309				if len then*/
    if (_len_631 == 0) {
        goto L7; // [116] 143
    }
    else {
        if (!IS_ATOM_INT(_len_631) && DBL_PTR(_len_631)->dbl == 0.0){
            goto L7; // [116] 143
        }
    }

    /** list.e:310					s = peek4s({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_630)) {
        _250 = _ma_630 + 4;
        if ((object)((uintptr_t)_250 + (uintptr_t)HIGH_BITS) >= 0){
            _250 = NewDouble((eudouble)_250);
        }
    }
    else {
        _250 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    Ref(_len_631);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _250;
    ((intptr_t *)_2)[2] = _len_631;
    _251 = MAKE_SEQ(_1);
    _250 = NOVALUE;
    DeRef(_s_634);
    _1 = (object)SEQ_PTR(_251);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _s_634 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)(int32_t)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT){
            _1 = NewDouble((eudouble)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_251);
    _251 = NOVALUE;

    /** list.e:311					return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
    goto L8; // [140] 159
L7: 

    /** list.e:313					tmp = peek4s(ma + 4)*/
    if (IS_ATOM_INT(_ma_630)) {
        _253 = _ma_630 + 4;
        if ((object)((uintptr_t)_253 + (uintptr_t)HIGH_BITS) >= 0){
            _253 = NewDouble((eudouble)_253);
        }
    }
    else {
        _253 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    DeRef(_tmp_632);
    if (IS_ATOM_INT(_253)) {
        _tmp_632 = (object)*(int32_t *)_253;
        if (_tmp_632 < MININT || _tmp_632 > MAXINT){
            _tmp_632 = NewDouble((eudouble)(object)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_253)->dbl);
        if (_tmp_632 < MININT || _tmp_632 > MAXINT){
            _tmp_632 = NewDouble((eudouble)(object)_tmp_632);
        }
    }
    DeRef(_253);
    _253 = NOVALUE;

    /** list.e:314					return tmp*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_val_633);
    DeRef(_s_634);
    return _tmp_632;
L8: 
L6: 

    /** list.e:317			if val = FLOAT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_633, _2FLOAT_FLAG_465)){
        goto L9; // [162] 262
    }

    /** list.e:318				if len then*/
    if (_len_631 == 0) {
        goto LA; // [168] 237
    }
    else {
        if (!IS_ATOM_INT(_len_631) && DBL_PTR(_len_631)->dbl == 0.0){
            goto LA; // [168] 237
        }
    }

    /** list.e:319					tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_630)) {
        _256 = _ma_630 + 4;
        if ((object)((uintptr_t)_256 + (uintptr_t)HIGH_BITS) >= 0){
            _256 = NewDouble((eudouble)_256);
        }
    }
    else {
        _256 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    DeRef(_tmp_632);
    if (IS_ATOM_INT(_256)) {
        _tmp_632 = (object)*(uint32_t *)_256;
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_256)->dbl);
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    DeRef(_256);
    _256 = NOVALUE;

    /** list.e:320					s = repeat(0, len)*/
    DeRef(_s_634);
    _s_634 = Repeat(0, _len_631);

    /** list.e:321					for i = 1 to len do*/
    Ref(_len_631);
    DeRef(_259);
    _259 = _len_631;
    {
        object _i_670;
        _i_670 = 1;
LB: 
        if (binary_op_a(GREATER, _i_670, _259)){
            goto LC; // [191] 228
        }

        /** list.e:322						s[i] = float32_to_atom(peek({tmp, 4}))*/
        Ref(_tmp_632);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _tmp_632;
        ((intptr_t *)_2)[2] = 4;
        _260 = MAKE_SEQ(_1);
        _1 = (object)SEQ_PTR(_260);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _261 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        DeRefDS(_260);
        _260 = NOVALUE;
        _262 = _3float32_to_atom(_261);
        _261 = NOVALUE;
        _2 = (object)SEQ_PTR(_s_634);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _s_634 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_670))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_670)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_670);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _262;
        if( _1 != _262 ){
            DeRef(_1);
        }
        _262 = NOVALUE;

        /** list.e:323						tmp += 8*/
        _0 = _tmp_632;
        if (IS_ATOM_INT(_tmp_632)) {
            _tmp_632 = _tmp_632 + 8;
            if ((object)((uintptr_t)_tmp_632 + (uintptr_t)HIGH_BITS) >= 0){
                _tmp_632 = NewDouble((eudouble)_tmp_632);
            }
        }
        else {
            _tmp_632 = NewDouble(DBL_PTR(_tmp_632)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** list.e:324					end for*/
        _0 = _i_670;
        if (IS_ATOM_INT(_i_670)) {
            _i_670 = _i_670 + 1;
            if ((object)((uintptr_t)_i_670 +(uintptr_t) HIGH_BITS) >= 0){
                _i_670 = NewDouble((eudouble)_i_670);
            }
        }
        else {
            _i_670 = binary_op_a(PLUS, _i_670, 1);
        }
        DeRef(_0);
        goto LB; // [223] 198
LC: 
        ;
        DeRef(_i_670);
    }

    /** list.e:325					return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
    goto LD; // [234] 261
LA: 

    /** list.e:327					tmp = float32_to_atom(peek({ma + 4, 4}))*/
    if (IS_ATOM_INT(_ma_630)) {
        _264 = _ma_630 + 4;
        if ((object)((uintptr_t)_264 + (uintptr_t)HIGH_BITS) >= 0){
            _264 = NewDouble((eudouble)_264);
        }
    }
    else {
        _264 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _264;
    ((intptr_t *)_2)[2] = 4;
    _265 = MAKE_SEQ(_1);
    _264 = NOVALUE;
    _1 = (object)SEQ_PTR(_265);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _266 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_265);
    _265 = NOVALUE;
    _0 = _tmp_632;
    _tmp_632 = _3float32_to_atom(_266);
    DeRef(_0);
    _266 = NOVALUE;

    /** list.e:328					return tmp*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_val_633);
    DeRef(_s_634);
    return _tmp_632;
LD: 
L9: 

    /** list.e:332			tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_630)) {
        _268 = _ma_630 + 4;
        if ((object)((uintptr_t)_268 + (uintptr_t)HIGH_BITS) >= 0){
            _268 = NewDouble((eudouble)_268);
        }
    }
    else {
        _268 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    DeRef(_tmp_632);
    if (IS_ATOM_INT(_268)) {
        _tmp_632 = (object)*(uint32_t *)_268;
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_268)->dbl);
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    DeRef(_268);
    _268 = NOVALUE;

    /** list.e:333			if val = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _val_633, _2DOUBLE_FLAG_459)){
        goto LE; // [273] 360
    }

    /** list.e:334				if len then*/
    if (_len_631 == 0) {
        goto LF; // [279] 339
    }
    else {
        if (!IS_ATOM_INT(_len_631) && DBL_PTR(_len_631)->dbl == 0.0){
            goto LF; // [279] 339
        }
    }

    /** list.e:335					s = repeat(0, len)*/
    DeRef(_s_634);
    _s_634 = Repeat(0, _len_631);

    /** list.e:336					for i = 1 to len do*/
    Ref(_len_631);
    DeRef(_272);
    _272 = _len_631;
    {
        object _i_690;
        _i_690 = 1;
L10: 
        if (binary_op_a(GREATER, _i_690, _272)){
            goto L11; // [293] 330
        }

        /** list.e:337						s[i] = float64_to_atom(peek({tmp, 8}))*/
        Ref(_tmp_632);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _tmp_632;
        ((intptr_t *)_2)[2] = 8;
        _273 = MAKE_SEQ(_1);
        _1 = (object)SEQ_PTR(_273);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _274 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        DeRefDS(_273);
        _273 = NOVALUE;
        _275 = _3float64_to_atom(_274);
        _274 = NOVALUE;
        _2 = (object)SEQ_PTR(_s_634);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _s_634 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_690))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_690)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _i_690);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _275;
        if( _1 != _275 ){
            DeRef(_1);
        }
        _275 = NOVALUE;

        /** list.e:338						tmp += 8*/
        _0 = _tmp_632;
        if (IS_ATOM_INT(_tmp_632)) {
            _tmp_632 = _tmp_632 + 8;
            if ((object)((uintptr_t)_tmp_632 + (uintptr_t)HIGH_BITS) >= 0){
                _tmp_632 = NewDouble((eudouble)_tmp_632);
            }
        }
        else {
            _tmp_632 = NewDouble(DBL_PTR(_tmp_632)->dbl + (eudouble)8);
        }
        DeRef(_0);

        /** list.e:339					end for*/
        _0 = _i_690;
        if (IS_ATOM_INT(_i_690)) {
            _i_690 = _i_690 + 1;
            if ((object)((uintptr_t)_i_690 +(uintptr_t) HIGH_BITS) >= 0){
                _i_690 = NewDouble((eudouble)_i_690);
            }
        }
        else {
            _i_690 = binary_op_a(PLUS, _i_690, 1);
        }
        DeRef(_0);
        goto L10; // [325] 300
L11: 
        ;
        DeRef(_i_690);
    }

    /** list.e:340					return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
    goto L12; // [336] 359
LF: 

    /** list.e:342					tmp = float64_to_atom(peek({tmp, 8}))*/
    Ref(_tmp_632);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tmp_632;
    ((intptr_t *)_2)[2] = 8;
    _277 = MAKE_SEQ(_1);
    _1 = (object)SEQ_PTR(_277);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _278 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_277);
    _277 = NOVALUE;
    _0 = _tmp_632;
    _tmp_632 = _3float64_to_atom(_278);
    DeRef(_0);
    _278 = NOVALUE;

    /** list.e:343					return tmp*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_val_633);
    DeRef(_s_634);
    return _tmp_632;
L12: 
LE: 

    /** list.e:349			s = peek({tmp, len})*/
    Ref(_len_631);
    Ref(_tmp_632);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _tmp_632;
    ((intptr_t *)_2)[2] = _len_631;
    _280 = MAKE_SEQ(_1);
    DeRef(_s_634);
    _1 = (object)SEQ_PTR(_280);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _s_634 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_280);
    _280 = NOVALUE;

    /** list.e:350			return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
    goto L13; // [377] 476
L1: 

    /** list.e:352		elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_631, 0)){
        goto L14; // [382] 469
    }

    /** list.e:354			tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_630)) {
        _283 = _ma_630 + 4;
        if ((object)((uintptr_t)_283 + (uintptr_t)HIGH_BITS) >= 0){
            _283 = NewDouble((eudouble)_283);
        }
    }
    else {
        _283 = NewDouble(DBL_PTR(_ma_630)->dbl + (eudouble)4);
    }
    DeRef(_tmp_632);
    if (IS_ATOM_INT(_283)) {
        _tmp_632 = (object)*(uint32_t *)_283;
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_283)->dbl);
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    DeRef(_283);
    _283 = NOVALUE;

    /** list.e:355			tmp = peek4u(tmp)*/
    _0 = _tmp_632;
    if (IS_ATOM_INT(_tmp_632)) {
        _tmp_632 = (object)*(uint32_t *)_tmp_632;
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    else {
        _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_tmp_632)->dbl);
        if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
            _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
        }
    }
    DeRef(_0);

    /** list.e:356			s = repeat(0, len)*/
    DeRef(_s_634);
    _s_634 = Repeat(0, _len_631);

    /** list.e:357			s[1] = linked_list_to_sequence(tmp)*/
    Ref(_tmp_632);
    DeRef(_287);
    _287 = _tmp_632;
    _288 = _2linked_list_to_sequence(_287);
    _287 = NOVALUE;
    _2 = (object)SEQ_PTR(_s_634);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _s_634 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1);
    *(intptr_t *)_2 = _288;
    if( _1 != _288 ){
    }
    _288 = NOVALUE;

    /** list.e:358			for i = 2 to length(s) do*/
    if (IS_SEQUENCE(_s_634)){
            _289 = SEQ_PTR(_s_634)->length;
    }
    else {
        _289 = 1;
    }
    {
        object _i_713;
        _i_713 = 2;
L15: 
        if (_i_713 > _289){
            goto L16; // [424] 460
        }

        /** list.e:359				tmp = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_632)) {
            _290 = _tmp_632 + 12;
            if ((object)((uintptr_t)_290 + (uintptr_t)HIGH_BITS) >= 0){
                _290 = NewDouble((eudouble)_290);
            }
        }
        else {
            _290 = NewDouble(DBL_PTR(_tmp_632)->dbl + (eudouble)12);
        }
        DeRef(_tmp_632);
        if (IS_ATOM_INT(_290)) {
            _tmp_632 = (object)*(uint32_t *)_290;
            if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
                _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
            }
        }
        else {
            _tmp_632 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_290)->dbl);
            if ((uintptr_t)_tmp_632 > (uintptr_t)MAXINT){
                _tmp_632 = NewDouble((eudouble)(uintptr_t)_tmp_632);
            }
        }
        DeRef(_290);
        _290 = NOVALUE;

        /** list.e:360				s[i] = linked_list_to_sequence(tmp)*/
        Ref(_tmp_632);
        DeRef(_292);
        _292 = _tmp_632;
        _293 = _2linked_list_to_sequence(_292);
        _292 = NOVALUE;
        _2 = (object)SEQ_PTR(_s_634);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _s_634 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_713);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _293;
        if( _1 != _293 ){
            DeRef(_1);
        }
        _293 = NOVALUE;

        /** list.e:361			end for*/
        _i_713 = _i_713 + 1;
        goto L15; // [455] 431
L16: 
        ;
    }

    /** list.e:362			return s*/
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    return _s_634;
    goto L13; // [466] 476
L14: 

    /** list.e:364			return {}*/
    RefDS(_5);
    DeRef(_ma_630);
    DeRef(_len_631);
    DeRef(_tmp_632);
    DeRef(_val_633);
    DeRef(_s_634);
    return _5;
L13: 
    ;
}
object linked_list_to_sequence() __attribute__ ((alias ("_2linked_list_to_sequence@4")));



// 0xE1A3EFBF
