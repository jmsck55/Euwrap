// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include <windows.h>
#include <time.h>
#include "include/euphoria.h"
#include "main-.h"



int Argc;
char **Argv;
HANDLE default_heap;
//'test me!' is this in the header?: unsigned __stdcall GetProcessHeap(void);
uintptr_t *peekptr_addr;
uint8_t *peek_addr;
uint16_t *peek2_addr;
uint64_t *peek8_addr;
uint32_t *peek4_addr;
uint8_t *poke_addr;
uint16_t *poke2_addr;
uint32_t *poke4_addr;
uint64_t *poke8_addr;
uintptr_t *pokeptr_addr;
struct d temp_d;
double temp_dbl;
char *stack_base;
void init_literal();
int total_stack_size = 262144;

int EuInit()
{
    s1_ptr _0switch_ptr;
    object _36 = 0;
    object _0, _1, _2;
    
    
    Argc = 0;
    default_heap = GetProcessHeap();

    _02 = (char**) malloc( sizeof( char* ) * 4 );
    _02[0] = (char*) malloc( sizeof( char* ) );
    _02[0][0] = 3;
    _02[1] = "\x01\x02\x07\x00";
    _02[2] = "\x02\x00\x02\x03";
    _02[3] = "\x03\x00\x00\x02";

    eu_startup(_00, _01, _02, (object)CLOCKS_PER_SEC, (object)CLOCKS_PER_SEC);
    trace_lines = 500;
    _0switch_ptr = (s1_ptr) NewS1( 3 );
    _0switch_ptr->base[1] = NewString("-dll    ");
    _0switch_ptr->base[2] = NewString("-keep    ");
    _0switch_ptr->base[3] = NewString("-gcc    ");
    _0switches = MAKE_SEQ( _0switch_ptr );

    init_literal();
    _3MAX_ADDR_202 = _3max_addr();
    _36 = 1048576;
    _3LOW_ADDR_204 = 1048575;
    _36 = NOVALUE;

    /** machine.e:147	mem = allocate(4)*/

    /** machine.e:106	    return machine_func(M_ALLOC, n)*/
    DeRef1(_3mem_286);
    _3mem_286 = machine(16, 4);

    /** machine.e:267	check_calls = 1*/
    _3check_calls_376 = 1;

    /** list.e:37	always_linked_list = 0*/
    _2always_linked_list_386 = 0;

    /** libeu4.e:44	init()*/

    /** libeu4.e:40		high_address = 0*/
    _1high_address_723 = 0;

    /** libeu4.e:41		data = {} -- objects*/
    RefDS(_5);
    DeRef1(_1data_724);
    _1data_724 = _5;

    /** libeu4.e:42		free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef1(_1free_list_725);
    _1free_list_725 = _5;

    /** libeu4.e:43	end procedure*/
    goto L1; // [74] 77
L1: 
    ;
    return 0;
}
int __stdcall LibMain(int hDLL, int Reason, void *Reserved)
{
    if (Reason == DLL_PROCESS_ATTACH){
        EuInit();
    }
    else if (Reason == DLL_PROCESS_DETACH ){
        EuUninit();
    }
    return 1;
}

extern void *call_back_arg1;
extern void *call_back_arg2;
extern void *call_back_arg3;
extern void *call_back_arg4;
extern void *call_back_arg5;
extern void *call_back_arg6;
extern void *call_back_arg7;
extern void *call_back_arg8;
extern void *call_back_arg9;
extern void *call_back_result;
extern void *TempErrName;
extern void **double_blocks;
extern int  double_blocks_allocated;
void _0cleanup_vars();


void EuUninit(){
    int i;
    _0cleanup_vars();
    DeRef( _495 );
    DeRef( _494 );
    DeRef( _5 );
    DeRef( _122 );
    DeRef( _121 );
    DeRef( _127 );
    DeRef( _124 );
    DeRef( _135 );
    DeRef( _134 );
    DeRef( _133 );
    DeRef( _132 );
    DeRef( _131 );
    EFree( call_back_arg1 );
    EFree( call_back_arg2 );
    EFree( call_back_arg3 );
    EFree( call_back_arg4 );
    EFree( call_back_arg5 );
    EFree( call_back_arg6 );
    EFree( call_back_arg7 );
    EFree( call_back_arg8 );
    EFree( call_back_arg9 );
    EFree( call_back_result );
    EFree( TempErrName );
    DeRefDS( _0switches );
    free( _02[0] );
    free( _02 );
    for( i = 0; i < double_blocks_allocated; ++i ){
        EFree( double_blocks[i] );
    }
    EFree( double_blocks );
}
// GenerateUserRoutines

// 0xE49B6C96
