// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _3max_addr()
{
    object _33 = NOVALUE;
    object _32 = NOVALUE;
    object _31 = NOVALUE;
    object _30 = NOVALUE;
    object _28 = NOVALUE;
    object _27 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:53		if integer( power(2, 32 ) ) then*/
    _27 = power(2, 32);
    if (IS_ATOM_INT(_27))
    _28 = 1;
    else if (IS_ATOM_DBL(_27))
    _28 = IS_ATOM_INT(DoubleToInt(_27));
    else
    _28 = 0;
    DeRef(_27);
    _27 = NOVALUE;
    if (_28 == 0)
    {
        _28 = NOVALUE;
        goto L1; // [10] 30
    }
    else{
        _28 = NOVALUE;
    }

    /** machine.e:54			return power(2, 64 ) - 1*/
    _30 = power(2, 64);
    if (IS_ATOM_INT(_30)) {
        _31 = _30 - 1;
        if ((object)((uintptr_t)_31 +(uintptr_t) HIGH_BITS) >= 0){
            _31 = NewDouble((eudouble)_31);
        }
    }
    else {
        _31 = NewDouble(DBL_PTR(_30)->dbl - (eudouble)1);
    }
    DeRef(_30);
    _30 = NOVALUE;
    return _31;
    goto L2; // [27] 45
L1: 

    /** machine.e:56			return power(2, 32)-1*/
    _32 = power(2, 32);
    if (IS_ATOM_INT(_32)) {
        _33 = _32 - 1;
        if ((object)((uintptr_t)_33 +(uintptr_t) HIGH_BITS) >= 0){
            _33 = NewDouble((eudouble)_33);
        }
    }
    else {
        _33 = NewDouble(DBL_PTR(_32)->dbl - (eudouble)1);
    }
    DeRef(_32);
    _32 = NOVALUE;
    DeRef(_31);
    _31 = NOVALUE;
    return _33;
L2: 
    ;
}


object  __stdcall _3allocate(object _n_256)
{
    object _58 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_256)) {
        _1 = (object)(DBL_PTR(_n_256)->dbl);
        DeRefDS(_n_256);
        _n_256 = _1;
    }

    /** machine.e:106	    return machine_func(M_ALLOC, n)*/
    _58 = machine(16, _n_256);
    return _58;
    ;
}


void  __stdcall _3free(object _a_260)
{
    object _0, _1, _2;
    

    /** machine.e:111	    machine_proc(M_FREE, a)*/
    machine(17, _a_260);

    /** machine.e:112	end procedure*/
    DeRef(_a_260);
    return;
    ;
}


object  __stdcall _3allocate_low(object _n_263)
{
    object _allocate_inlined_allocate_at_4_265 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_263)) {
        _1 = (object)(DBL_PTR(_n_263)->dbl);
        DeRefDS(_n_263);
        _n_263 = _1;
    }

    /** machine.e:118	    return allocate( n )*/

    /** machine.e:106	    return machine_func(M_ALLOC, n)*/
    DeRef(_allocate_inlined_allocate_at_4_265);
    _allocate_inlined_allocate_at_4_265 = machine(16, _n_263);
    return _allocate_inlined_allocate_at_4_265;
    ;
}


void  __stdcall _3free_low(object _a_268)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_268)) {
        _1 = (object)(DBL_PTR(_a_268)->dbl);
        DeRefDS(_a_268);
        _a_268 = _1;
    }

    /** machine.e:123	    free( a )*/

    /** machine.e:111	    machine_proc(M_FREE, a)*/
    machine(17, _a_268);

    /** machine.e:112	end procedure*/
    goto L1; // [12] 15
L1: 

    /** machine.e:124	end procedure*/
    return;
    ;
}


object  __stdcall _3int_to_bytes(object _x_272)
{
    object _a_273 = NOVALUE;
    object _b_274 = NOVALUE;
    object _c_275 = NOVALUE;
    object _d_276 = NOVALUE;
    object _67 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:136	    a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_272)) {
        _a_273 = (_x_272 % 256);
    }
    else {
        temp_d.dbl = (eudouble)256;
        _a_273 = Dremainder(DBL_PTR(_x_272), &temp_d);
    }
    if (!IS_ATOM_INT(_a_273)) {
        _1 = (object)(DBL_PTR(_a_273)->dbl);
        DeRefDS(_a_273);
        _a_273 = _1;
    }

    /** machine.e:137	    x = floor(x / #100)*/
    _0 = _x_272;
    if (IS_ATOM_INT(_x_272)) {
        if (256 > 0 && _x_272 >= 0) {
            _x_272 = _x_272 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_272 / (eudouble)256);
            if (_x_272 != MININT)
            _x_272 = (object)temp_dbl;
            else
            _x_272 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_272, 256);
        _x_272 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** machine.e:138	    b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_272)) {
        _b_274 = (_x_272 % 256);
    }
    else {
        temp_d.dbl = (eudouble)256;
        _b_274 = Dremainder(DBL_PTR(_x_272), &temp_d);
    }
    if (!IS_ATOM_INT(_b_274)) {
        _1 = (object)(DBL_PTR(_b_274)->dbl);
        DeRefDS(_b_274);
        _b_274 = _1;
    }

    /** machine.e:139	    x = floor(x / #100)*/
    _0 = _x_272;
    if (IS_ATOM_INT(_x_272)) {
        if (256 > 0 && _x_272 >= 0) {
            _x_272 = _x_272 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_272 / (eudouble)256);
            if (_x_272 != MININT)
            _x_272 = (object)temp_dbl;
            else
            _x_272 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_272, 256);
        _x_272 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** machine.e:140	    c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_272)) {
        _c_275 = (_x_272 % 256);
    }
    else {
        temp_d.dbl = (eudouble)256;
        _c_275 = Dremainder(DBL_PTR(_x_272), &temp_d);
    }
    if (!IS_ATOM_INT(_c_275)) {
        _1 = (object)(DBL_PTR(_c_275)->dbl);
        DeRefDS(_c_275);
        _c_275 = _1;
    }

    /** machine.e:141	    x = floor(x / #100)*/
    _0 = _x_272;
    if (IS_ATOM_INT(_x_272)) {
        if (256 > 0 && _x_272 >= 0) {
            _x_272 = _x_272 / 256;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_272 / (eudouble)256);
            if (_x_272 != MININT)
            _x_272 = (object)temp_dbl;
            else
            _x_272 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_272, 256);
        _x_272 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** machine.e:142	    d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_272)) {
        _d_276 = (_x_272 % 256);
    }
    else {
        temp_d.dbl = (eudouble)256;
        _d_276 = Dremainder(DBL_PTR(_x_272), &temp_d);
    }
    if (!IS_ATOM_INT(_d_276)) {
        _1 = (object)(DBL_PTR(_d_276)->dbl);
        DeRefDS(_d_276);
        _d_276 = _1;
    }

    /** machine.e:143	    return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _a_273;
    ((intptr_t*)_2)[2] = _b_274;
    ((intptr_t*)_2)[3] = _c_275;
    ((intptr_t*)_2)[4] = _d_276;
    _67 = MAKE_SEQ(_1);
    DeRef(_x_272);
    return _67;
    ;
}


object  __stdcall _3bytes_to_int(object _s_291)
{
    object _71 = NOVALUE;
    object _70 = NOVALUE;
    object _68 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:151	    if length(s) = 4 then*/
    if (IS_SEQUENCE(_s_291)){
            _68 = SEQ_PTR(_s_291)->length;
    }
    else {
        _68 = 1;
    }
    if (_68 != 4)
    goto L1; // [8] 22

    /** machine.e:152		poke(mem, s)*/
    if (IS_ATOM_INT(_3mem_286)){
        poke_addr = (uint8_t *)_3mem_286;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_3mem_286)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_291);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }
    goto L2; // [19] 35
L1: 

    /** machine.e:154		poke(mem, s[1..4]) -- avoid breaking old code*/
    rhs_slice_target = (object_ptr)&_70;
    RHS_Slice(_s_291, 1, 4);
    if (IS_ATOM_INT(_3mem_286)){
        poke_addr = (uint8_t *)_3mem_286;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_3mem_286)->dbl);
    }
    _1 = (object)SEQ_PTR(_70);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_70);
    _70 = NOVALUE;
L2: 

    /** machine.e:156	    return peek4u(mem)*/
    if (IS_ATOM_INT(_3mem_286)) {
        _71 = (object)*(uint32_t *)_3mem_286;
        if ((uintptr_t)_71 > (uintptr_t)MAXINT){
            _71 = NewDouble((eudouble)(uintptr_t)_71);
        }
    }
    else {
        _71 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_3mem_286)->dbl);
        if ((uintptr_t)_71 > (uintptr_t)MAXINT){
            _71 = NewDouble((eudouble)(uintptr_t)_71);
        }
    }
    DeRefDS(_s_291);
    return _71;
    ;
}


object  __stdcall _3int_to_bits(object _x_300, object _nbits_301)
{
    object _bits_302 = NOVALUE;
    object _mask_303 = NOVALUE;
    object _85 = NOVALUE;
    object _84 = NOVALUE;
    object _82 = NOVALUE;
    object _79 = NOVALUE;
    object _78 = NOVALUE;
    object _77 = NOVALUE;
    object _76 = NOVALUE;
    object _74 = NOVALUE;
    object _73 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nbits_301)) {
        _1 = (object)(DBL_PTR(_nbits_301)->dbl);
        DeRefDS(_nbits_301);
        _nbits_301 = _1;
    }

    /** machine.e:167	    bits = repeat(0, nbits)*/
    DeRef(_bits_302);
    _bits_302 = Repeat(0, _nbits_301);

    /** machine.e:168	    if integer(x) and nbits < 30 then*/
    if (IS_ATOM_INT(_x_300))
    _73 = 1;
    else if (IS_ATOM_DBL(_x_300))
    _73 = IS_ATOM_INT(DoubleToInt(_x_300));
    else
    _73 = 0;
    if (_73 == 0) {
        goto L1; // [14] 73
    }
    _76 = (_nbits_301 < 30);
    if (_76 == 0)
    {
        DeRef(_76);
        _76 = NOVALUE;
        goto L1; // [23] 73
    }
    else{
        DeRef(_76);
        _76 = NOVALUE;
    }

    /** machine.e:170		mask = 1*/
    _mask_303 = 1;

    /** machine.e:171		for i = 1 to nbits do*/
    _77 = _nbits_301;
    {
        object _i_311;
        _i_311 = 1;
L2: 
        if (_i_311 > _77){
            goto L3; // [36] 70
        }

        /** machine.e:172		    bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_300)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_x_300 & (uintptr_t)_mask_303;
                 _78 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_303;
            _78 = Dand_bits(DBL_PTR(_x_300), &temp_d);
        }
        if (IS_ATOM_INT(_78)) {
            _79 = (_78 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (eudouble)1;
            _79 = Dand(DBL_PTR(_78), &temp_d);
        }
        DeRef(_78);
        _78 = NOVALUE;
        _2 = (object)SEQ_PTR(_bits_302);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _bits_302 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_311);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _79;
        if( _1 != _79 ){
            DeRef(_1);
        }
        _79 = NOVALUE;

        /** machine.e:173		    mask *= 2*/
        _mask_303 = _mask_303 + _mask_303;

        /** machine.e:174		end for*/
        _i_311 = _i_311 + 1;
        goto L2; // [65] 43
L3: 
        ;
    }
    goto L4; // [70] 126
L1: 

    /** machine.e:177		if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_300, 0)){
        goto L5; // [75] 90
    }

    /** machine.e:178		    x += power(2, nbits) -- for 2's complement bit pattern*/
    _82 = power(2, _nbits_301);
    _0 = _x_300;
    if (IS_ATOM_INT(_x_300) && IS_ATOM_INT(_82)) {
        _x_300 = _x_300 + _82;
        if ((object)((uintptr_t)_x_300 + (uintptr_t)HIGH_BITS) >= 0){
            _x_300 = NewDouble((eudouble)_x_300);
        }
    }
    else {
        if (IS_ATOM_INT(_x_300)) {
            _x_300 = NewDouble((eudouble)_x_300 + DBL_PTR(_82)->dbl);
        }
        else {
            if (IS_ATOM_INT(_82)) {
                _x_300 = NewDouble(DBL_PTR(_x_300)->dbl + (eudouble)_82);
            }
            else
            _x_300 = NewDouble(DBL_PTR(_x_300)->dbl + DBL_PTR(_82)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_82);
    _82 = NOVALUE;
L5: 

    /** machine.e:180		for i = 1 to nbits do*/
    _84 = _nbits_301;
    {
        object _i_322;
        _i_322 = 1;
L6: 
        if (_i_322 > _84){
            goto L7; // [95] 125
        }

        /** machine.e:181		    bits[i] = remainder(x, 2) */
        if (IS_ATOM_INT(_x_300)) {
            _85 = (_x_300 % 2);
        }
        else {
            temp_d.dbl = (eudouble)2;
            _85 = Dremainder(DBL_PTR(_x_300), &temp_d);
        }
        _2 = (object)SEQ_PTR(_bits_302);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _bits_302 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_322);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _85;
        if( _1 != _85 ){
            DeRef(_1);
        }
        _85 = NOVALUE;

        /** machine.e:182		    x = floor(x / 2)*/
        _0 = _x_300;
        if (IS_ATOM_INT(_x_300)) {
            _x_300 = _x_300 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_300, 2);
            _x_300 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** machine.e:183		end for*/
        _i_322 = _i_322 + 1;
        goto L6; // [120] 102
L7: 
        ;
    }
L4: 

    /** machine.e:185	    return bits*/
    DeRef(_x_300);
    return _bits_302;
    ;
}


object  __stdcall _3bits_to_int(object _bits_328)
{
    object _value_329 = NOVALUE;
    object _p_330 = NOVALUE;
    object _88 = NOVALUE;
    object _87 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:192	    value = 0*/
    DeRef(_value_329);
    _value_329 = 0;

    /** machine.e:193	    p = 1*/
    DeRef(_p_330);
    _p_330 = 1;

    /** machine.e:194	    for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_328)){
            _87 = SEQ_PTR(_bits_328)->length;
    }
    else {
        _87 = 1;
    }
    {
        object _i_332;
        _i_332 = 1;
L1: 
        if (_i_332 > _87){
            goto L2; // [18] 54
        }

        /** machine.e:195		if bits[i] then*/
        _2 = (object)SEQ_PTR(_bits_328);
        _88 = (object)*(((s1_ptr)_2)->base + _i_332);
        if (_88 == 0) {
            _88 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_88) && DBL_PTR(_88)->dbl == 0.0){
                _88 = NOVALUE;
                goto L3; // [31] 41
            }
            _88 = NOVALUE;
        }
        _88 = NOVALUE;

        /** machine.e:196		    value += p*/
        _0 = _value_329;
        if (IS_ATOM_INT(_value_329) && IS_ATOM_INT(_p_330)) {
            _value_329 = _value_329 + _p_330;
            if ((object)((uintptr_t)_value_329 + (uintptr_t)HIGH_BITS) >= 0){
                _value_329 = NewDouble((eudouble)_value_329);
            }
        }
        else {
            if (IS_ATOM_INT(_value_329)) {
                _value_329 = NewDouble((eudouble)_value_329 + DBL_PTR(_p_330)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_330)) {
                    _value_329 = NewDouble(DBL_PTR(_value_329)->dbl + (eudouble)_p_330);
                }
                else
                _value_329 = NewDouble(DBL_PTR(_value_329)->dbl + DBL_PTR(_p_330)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** machine.e:198		p += p*/
        _0 = _p_330;
        if (IS_ATOM_INT(_p_330) && IS_ATOM_INT(_p_330)) {
            _p_330 = _p_330 + _p_330;
            if ((object)((uintptr_t)_p_330 + (uintptr_t)HIGH_BITS) >= 0){
                _p_330 = NewDouble((eudouble)_p_330);
            }
        }
        else {
            if (IS_ATOM_INT(_p_330)) {
                _p_330 = NewDouble((eudouble)_p_330 + DBL_PTR(_p_330)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_330)) {
                    _p_330 = NewDouble(DBL_PTR(_p_330)->dbl + (eudouble)_p_330);
                }
                else
                _p_330 = NewDouble(DBL_PTR(_p_330)->dbl + DBL_PTR(_p_330)->dbl);
            }
        }
        DeRef(_0);

        /** machine.e:199	    end for*/
        _i_332 = _i_332 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** machine.e:200	    return value*/
    DeRefDS(_bits_328);
    DeRef(_p_330);
    return _value_329;
    ;
}


void  __stdcall _3set_rand(object _seed_340)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_seed_340)) {
        _1 = (object)(DBL_PTR(_seed_340)->dbl);
        DeRefDS(_seed_340);
        _seed_340 = _1;
    }

    /** machine.e:207	    machine_proc(M_SET_RAND, seed)*/
    machine(35, _seed_340);

    /** machine.e:208	end procedure*/
    return;
    ;
}


void  __stdcall _3crash_message(object _msg_343)
{
    object _0, _1, _2;
    

    /** machine.e:216	    machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_343);

    /** machine.e:217	end procedure*/
    DeRefDS(_msg_343);
    return;
    ;
}


void  __stdcall _3crash_file(object _file_path_346)
{
    object _0, _1, _2;
    

    /** machine.e:222	    machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_346);

    /** machine.e:223	end procedure*/
    DeRefDS(_file_path_346);
    return;
    ;
}


void  __stdcall _3crash_routine(object _proc_349)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_349)) {
        _1 = (object)(DBL_PTR(_proc_349)->dbl);
        DeRefDS(_proc_349);
        _proc_349 = _1;
    }

    /** machine.e:228	    machine_proc(M_CRASH_ROUTINE, proc)*/
    machine(66, _proc_349);

    /** machine.e:229	end procedure*/
    return;
    ;
}


object  __stdcall _3atom_to_float64(object _a_352)
{
    object _91 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:234	    return machine_func(M_A_TO_F64, a)*/
    _91 = machine(46, _a_352);
    DeRef(_a_352);
    return _91;
    ;
}


object  __stdcall _3atom_to_float32(object _a_356)
{
    object _92 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:239	    return machine_func(M_A_TO_F32, a)*/
    _92 = machine(48, _a_356);
    DeRef(_a_356);
    return _92;
    ;
}


object  __stdcall _3float64_to_atom(object _ieee64_360)
{
    object _93 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:244	    return machine_func(M_F64_TO_A, ieee64)*/
    _93 = machine(47, _ieee64_360);
    DeRefDS(_ieee64_360);
    return _93;
    ;
}


object  __stdcall _3float32_to_atom(object _ieee32_364)
{
    object _94 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:249	    return machine_func(M_F32_TO_A, ieee32)*/
    _94 = machine(49, _ieee32_364);
    DeRefDS(_ieee32_364);
    return _94;
    ;
}


object  __stdcall _3allocate_string(object _s_368)
{
    object _mem_369 = NOVALUE;
    object _99 = NOVALUE;
    object _98 = NOVALUE;
    object _96 = NOVALUE;
    object _95 = NOVALUE;
    object _0, _1, _2;
    

    /** machine.e:256	    mem = machine_func(M_ALLOC, length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_368)){
            _95 = SEQ_PTR(_s_368)->length;
    }
    else {
        _95 = 1;
    }
    _96 = _95 + 1;
    _95 = NOVALUE;
    DeRef(_mem_369);
    _mem_369 = machine(16, _96);
    _96 = NOVALUE;

    /** machine.e:257	    if mem then*/
    if (_mem_369 == 0) {
        goto L1; // [18] 39
    }
    else {
        if (!IS_ATOM_INT(_mem_369) && DBL_PTR(_mem_369)->dbl == 0.0){
            goto L1; // [18] 39
        }
    }

    /** machine.e:258		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_369)){
        poke_addr = (uint8_t *)_mem_369;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_mem_369)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_368);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** machine.e:259		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_368)){
            _98 = SEQ_PTR(_s_368)->length;
    }
    else {
        _98 = 1;
    }
    if (IS_ATOM_INT(_mem_369)) {
        _99 = _mem_369 + _98;
        if ((object)((uintptr_t)_99 + (uintptr_t)HIGH_BITS) >= 0){
            _99 = NewDouble((eudouble)_99);
        }
    }
    else {
        _99 = NewDouble(DBL_PTR(_mem_369)->dbl + (eudouble)_98);
    }
    _98 = NOVALUE;
    if (IS_ATOM_INT(_99)){
        poke_addr = (uint8_t *)_99;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_99)->dbl);
    }
    *poke_addr = (uint8_t)0;
    DeRef(_99);
    _99 = NOVALUE;
L1: 

    /** machine.e:261	    return mem*/
    DeRefDS(_s_368);
    return _mem_369;
    ;
}


void  __stdcall _3register_block(object _block_addr_379, object _block_len_380)
{
    object _0, _1, _2;
    

    /** machine.e:270	end procedure*/
    return;
    ;
}


void  __stdcall _3unregister_block(object _block_addr_383)
{
    object _0, _1, _2;
    

    /** machine.e:273	end procedure*/
    return;
    ;
}


void  __stdcall _3check_all_blocks()
{
    object _0, _1, _2;
    

    /** machine.e:276	end procedure*/
    return;
    ;
}



// 0xCB3606FB
