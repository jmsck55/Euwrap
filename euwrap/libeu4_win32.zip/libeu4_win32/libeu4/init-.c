#include "include/euphoria.h"
#include "main-.h"

object _5;
object _121;
object _122;
object _124;
object _127;
object _131;
object _132;
object _133;
object _134;
object _135;
object _494;
object _495;

// 0x6A0A3F16
// Declaring file vars
object _3M_ALLOC_154 = 16;
object _3M_FREE_156 = 17;
object _3M_ALLOC_LOW_158 = 32;
object _3M_FREE_LOW_160 = 33;
object _3M_INTERRUPT_162 = 34;
object _3M_SET_RAND_164 = 35;
object _3M_USE_VESA_166 = 36;
object _3M_CRASH_MESSAGE_168 = 37;
object _3M_TICK_RATE_170 = 38;
object _3M_GET_VECTOR_172 = 39;
object _3M_SET_VECTOR_174 = 40;
object _3M_LOCK_MEMORY_176 = 41;
object _3M_A_TO_F64_178 = 46;
object _3M_F64_TO_A_180 = 47;
object _3M_A_TO_F32_182 = 48;
object _3M_F32_TO_A_184 = 49;
object _3M_CRASH_FILE_186 = 57;
object _3M_CRASH_ROUTINE_188 = 66;
object _3MAX_ADDR_202 = NOVALUE;
object _3LOW_ADDR_204 = NOVALUE;
object _3REG_LIST_SIZE_237 = 10;
object _3REG_DI_239 = 1;
object _3REG_SI_240 = 2;
object _3REG_BP_241 = 3;
object _3REG_BX_243 = 4;
object _3REG_DX_244 = 5;
object _3REG_CX_246 = 6;
object _3REG_AX_248 = 7;
object _3REG_FLAGS_250 = 8;
object _3REG_ES_251 = 9;
object _3REG_DS_253 = 10;
object _3mem_286 = NOVALUE;
object _3allocate_inlined_allocate_at_18_288 = NOVALUE;
object _3check_calls_376 = NOVALUE;
object _2always_linked_list_386 = NOVALUE;
object _2NULL_452 = 0;
object _2SIZE_OF_STRUCT_453 = 16;
object _2MAX_LENGTH_454 = 268435455;
object _2SIGN_MASK_456 = NOVALUE;
object _2SIGN_FLAG_458 = NOVALUE;
object _2DOUBLE_FLAG_459 = NOVALUE;
object _2INT_FLAG_461 = NOVALUE;
object _2UINT_FLAG_463 = NOVALUE;
object _2FLOAT_FLAG_465 = NOVALUE;
object _2CSTRING_467 = NOVALUE;
object _2CBYTES_468 = NOVALUE;
object _1VERSION_720 = 4;
object _1high_address_723 = NOVALUE;
object _1data_724 = NOVALUE;
object _1free_list_725 = NOVALUE;

// Declaring var array for cleanup
object_ptr _0var_cleanup[] = {
    &_3M_ALLOC_154, // 0
    &_3M_FREE_156, // 1
    &_3M_ALLOC_LOW_158, // 2
    &_3M_FREE_LOW_160, // 3
    &_3M_INTERRUPT_162, // 4
    &_3M_SET_RAND_164, // 5
    &_3M_USE_VESA_166, // 6
    &_3M_CRASH_MESSAGE_168, // 7
    &_3M_TICK_RATE_170, // 8
    &_3M_GET_VECTOR_172, // 9
    &_3M_SET_VECTOR_174, // 10
    &_3M_LOCK_MEMORY_176, // 11
    &_3M_A_TO_F64_178, // 12
    &_3M_F64_TO_A_180, // 13
    &_3M_A_TO_F32_182, // 14
    &_3M_F32_TO_A_184, // 15
    &_3M_CRASH_FILE_186, // 16
    &_3M_CRASH_ROUTINE_188, // 17
    &_3MAX_ADDR_202, // 18
    &_3LOW_ADDR_204, // 19
    &_3REG_LIST_SIZE_237, // 20
    &_3REG_DI_239, // 21
    &_3REG_SI_240, // 22
    &_3REG_BP_241, // 23
    &_3REG_BX_243, // 24
    &_3REG_DX_244, // 25
    &_3REG_CX_246, // 26
    &_3REG_AX_248, // 27
    &_3REG_FLAGS_250, // 28
    &_3REG_ES_251, // 29
    &_3REG_DS_253, // 30
    &_3mem_286, // 31
    &_3allocate_inlined_allocate_at_18_288, // 32
    &_3check_calls_376, // 33
    &_2always_linked_list_386, // 34
    &_2NULL_452, // 35
    &_2SIZE_OF_STRUCT_453, // 36
    &_2MAX_LENGTH_454, // 37
    &_2SIGN_MASK_456, // 38
    &_2SIGN_FLAG_458, // 39
    &_2DOUBLE_FLAG_459, // 40
    &_2INT_FLAG_461, // 41
    &_2UINT_FLAG_463, // 42
    &_2FLOAT_FLAG_465, // 43
    &_2CSTRING_467, // 44
    &_2CBYTES_468, // 45
    &_1VERSION_720, // 46
    &_1high_address_723, // 47
    &_1data_724, // 48
    &_1free_list_725, // 49
    0
};
char *_0var_cleanup_name[] = {
    "_3M_ALLOC_154", // 0
    "_3M_FREE_156", // 1
    "_3M_ALLOC_LOW_158", // 2
    "_3M_FREE_LOW_160", // 3
    "_3M_INTERRUPT_162", // 4
    "_3M_SET_RAND_164", // 5
    "_3M_USE_VESA_166", // 6
    "_3M_CRASH_MESSAGE_168", // 7
    "_3M_TICK_RATE_170", // 8
    "_3M_GET_VECTOR_172", // 9
    "_3M_SET_VECTOR_174", // 10
    "_3M_LOCK_MEMORY_176", // 11
    "_3M_A_TO_F64_178", // 12
    "_3M_F64_TO_A_180", // 13
    "_3M_A_TO_F32_182", // 14
    "_3M_F32_TO_A_184", // 15
    "_3M_CRASH_FILE_186", // 16
    "_3M_CRASH_ROUTINE_188", // 17
    "_3MAX_ADDR_202", // 18
    "_3LOW_ADDR_204", // 19
    "_3REG_LIST_SIZE_237", // 20
    "_3REG_DI_239", // 21
    "_3REG_SI_240", // 22
    "_3REG_BP_241", // 23
    "_3REG_BX_243", // 24
    "_3REG_DX_244", // 25
    "_3REG_CX_246", // 26
    "_3REG_AX_248", // 27
    "_3REG_FLAGS_250", // 28
    "_3REG_ES_251", // 29
    "_3REG_DS_253", // 30
    "_3mem_286", // 31
    "_3allocate_inlined_allocate_at_18_288", // 32
    "_3check_calls_376", // 33
    "_2always_linked_list_386", // 34
    "_2NULL_452", // 35
    "_2SIZE_OF_STRUCT_453", // 36
    "_2MAX_LENGTH_454", // 37
    "_2SIGN_MASK_456", // 38
    "_2SIGN_FLAG_458", // 39
    "_2DOUBLE_FLAG_459", // 40
    "_2INT_FLAG_461", // 41
    "_2UINT_FLAG_463", // 42
    "_2FLOAT_FLAG_465", // 43
    "_2CSTRING_467", // 44
    "_2CBYTES_468", // 45
    "_1VERSION_720", // 46
    "_1high_address_723", // 47
    "_1data_724", // 48
    "_1free_list_725", // 49
    0
};
void _0cleanup_vars(){
    int i;
    object x;
    for( i = 0; i < 50; ++i ){
        x = *_0var_cleanup[i];
        if( x >= NOVALUE ) /* do nothing */;
        else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {
            cleanup_double( DBL_PTR( x ) );
        }
        else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {
            cleanup_sequence( SEQ_PTR( x ) );
        }
    }
    for( i = 0; i < 50; ++i ){
        DeRef( *_0var_cleanup[i] );
        *_0var_cleanup[i] = NOVALUE;
    }
}

struct routine_list _00[] = {
  {"get_version", (object (*)())_1get_version, 0, 1, 0, 1, 6, 0},
  {"init", (object (*)())_1init, 1, 1, 0, 1, 6, 0},
  {"get_high_address", (object (*)())_1get_high_address, 2, 1, 0, 1, 6, 0},
  {"set_high_address", (object (*)())_1set_high_address, 3, 1, 1, 0, 5, 0},
  {"get_address", (object (*)())_1get_address, 4, 1, 2, 0, 5, 0},
  {"register_data", (object (*)())_1register_data, 5, 1, 1, 0, 5, 0},
  {"retval", (object (*)())_1retval, 6, 1, 1, 0, 5, 0},
  {"length_of_data", (object (*)())_1length_of_data, 7, 1, 0, 1, 6, 0},
  {"is_free", (object (*)())_1is_free, 8, 1, 1, 1, 6, 0},
  {"access_free_list", (object (*)())_1access_free_list, 9, 1, 0, 1, 6, 0},
  {"generic_free", (object (*)())_1generic_free, 10, 1, 2, 1, 6, 0},
  {"delete_linked_list", (object (*)())_1delete_linked_list, 11, 1, 1, 1, 6, 0},
  {"free_linked_lists", (object (*)())_1free_linked_lists, 12, 1, 3, 1, 6, 0},
  {"register_linked_list", (object (*)())_1register_linked_list, 13, 1, 2, 1, 6, 0},
  {"new_linked_list", (object (*)())_1new_linked_list, 14, 1, 2, 1, 6, 0},
  {"store_linked_list", (object (*)())_1store_linked_list, 15, 1, 3, 1, 6, 0},
  {"access_linked_list", (object (*)())_1access_linked_list, 16, 1, 1, 1, 6, 0},
  {"at_linked_list", (object (*)())_1at_linked_list, 17, 1, 2, 1, 6, 0},
  {"free_linked_list_dll", (object (*)())_1free_linked_list_dll, 18, 1, 2, 1, 6, 0},
  {"length_linked_list", (object (*)())_1length_linked_list, 19, 1, 1, 1, 6, 0},
  {"store_at_linked_list", (object (*)())_1store_at_linked_list, 20, 1, 4, 1, 6, 0},
  {"eu_repeat", (object (*)())_1eu_repeat, 21, 1, 2, 1, 6, 0},
  {"eu_mem_set", (object (*)())_1eu_mem_set, 22, 1, 4, 1, 6, 0},
  {"eu_mem_copy", (object (*)())_1eu_mem_copy, 23, 1, 5, 1, 6, 0},
  {"eu_add", (object (*)())_1eu_add, 24, 1, 2, 1, 6, 0},
  {"eu_subtract", (object (*)())_1eu_subtract, 25, 1, 2, 1, 6, 0},
  {"eu_multiply", (object (*)())_1eu_multiply, 26, 1, 2, 1, 6, 0},
  {"eu_divide", (object (*)())_1eu_divide, 27, 1, 2, 1, 6, 0},
  {"eu_negate", (object (*)())_1eu_negate, 28, 1, 1, 1, 6, 0},
  {"eu_not", (object (*)())_1eu_not, 29, 1, 1, 1, 6, 0},
  {"eu_equals", (object (*)())_1eu_equals, 30, 1, 2, 1, 6, 0},
  {"eu_and", (object (*)())_1eu_and, 31, 1, 2, 1, 6, 0},
  {"eu_or", (object (*)())_1eu_or, 32, 1, 2, 1, 6, 0},
  {"eu_xor", (object (*)())_1eu_xor, 33, 1, 2, 1, 6, 0},
  {"eu_question_mark", (object (*)())_1eu_question_mark, 34, 1, 1, 1, 6, 0},
  {"eu_abort", (object (*)())_1eu_abort, 35, 1, 1, 1, 6, 0},
  {"eu_and_bits", (object (*)())_1eu_and_bits, 36, 1, 2, 1, 6, 0},
  {"eu_append", (object (*)())_1eu_append, 37, 1, 2, 1, 6, 0},
  {"eu_arctan", (object (*)())_1eu_arctan, 38, 1, 1, 1, 6, 0},
  {"eu_atom", (object (*)())_1eu_atom, 39, 1, 1, 1, 6, 0},
  {"eu_c_func", (object (*)())_1eu_c_func, 40, 1, 2, 1, 6, 0},
  {"eu_c_proc", (object (*)())_1eu_c_proc, 41, 1, 2, 1, 6, 0},
  {"eu_call", (object (*)())_1eu_call, 42, 1, 2, 1, 6, 0},
  {"eu_clear_screen", (object (*)())_1eu_clear_screen, 43, 1, 0, 1, 6, 0},
  {"eu_close", (object (*)())_1eu_close, 44, 1, 1, 1, 6, 0},
  {"eu_command_line", (object (*)())_1eu_command_line, 45, 1, 0, 1, 6, 0},
  {"eu_compare", (object (*)())_1eu_compare, 46, 1, 2, 1, 6, 0},
  {"eu_concat", (object (*)())_1eu_concat, 47, 1, 2, 1, 6, 0},
  {"eu_cos", (object (*)())_1eu_cos, 48, 1, 1, 1, 6, 0},
  {"eu_date", (object (*)())_1eu_date, 49, 1, 0, 1, 6, 0},
  {"eu_equal", (object (*)())_1eu_equal, 50, 1, 2, 1, 6, 0},
  {"eu_find_from", (object (*)())_1eu_find_from, 51, 1, 3, 1, 6, 0},
  {"eu_find", (object (*)())_1eu_find, 52, 1, 3, 1, 6, 0},
  {"eu_floor", (object (*)())_1eu_floor, 53, 1, 1, 1, 6, 0},
  {"eu_integer_division", (object (*)())_1eu_integer_division, 54, 1, 2, 1, 6, 0},
  {"eu_get_key", (object (*)())_1eu_get_key, 55, 1, 0, 1, 6, 0},
  {"eu_getc", (object (*)())_1eu_getc, 56, 1, 1, 1, 6, 0},
  {"eu_getenv", (object (*)())_1eu_getenv, 57, 1, 1, 1, 6, 0},
  {"eu_gets", (object (*)())_1eu_gets, 58, 1, 1, 1, 6, 0},
  {"eu_integer", (object (*)())_1eu_integer, 59, 1, 1, 1, 6, 0},
  {"eu_length", (object (*)())_1eu_length, 60, 1, 1, 1, 6, 0},
  {"eu_log", (object (*)())_1eu_log, 61, 1, 1, 1, 6, 0},
  {"eu_machine_func", (object (*)())_1eu_machine_func, 62, 1, 2, 1, 6, 0},
  {"eu_machine_proc", (object (*)())_1eu_machine_proc, 63, 1, 2, 1, 6, 0},
  {"eu_match_from", (object (*)())_1eu_match_from, 64, 1, 3, 1, 6, 0},
  {"eu_match", (object (*)())_1eu_match, 65, 1, 3, 1, 6, 0},
  {"eu_not_bits", (object (*)())_1eu_not_bits, 66, 1, 1, 1, 6, 0},
  {"eu_object", (object (*)())_1eu_object, 67, 1, 1, 1, 6, 0},
  {"eu_open", (object (*)())_1eu_open, 68, 1, 2, 1, 6, 0},
  {"eu_open_str", (object (*)())_1eu_open_str, 69, 1, 3, 1, 6, 0},
  {"eu_or_bits", (object (*)())_1eu_or_bits, 70, 1, 2, 1, 6, 0},
  {"eu_peek", (object (*)())_1eu_peek, 71, 1, 1, 1, 6, 0},
  {"eu_peek4s", (object (*)())_1eu_peek4s, 72, 1, 1, 1, 6, 0},
  {"eu_peek4u", (object (*)())_1eu_peek4u, 73, 1, 1, 1, 6, 0},
  {"eu_platform", (object (*)())_1eu_platform, 74, 1, 0, 1, 6, 0},
  {"eu_poke", (object (*)())_1eu_poke, 75, 1, 2, 1, 6, 0},
  {"eu_poke4", (object (*)())_1eu_poke4, 76, 1, 2, 1, 6, 0},
  {"eu_position", (object (*)())_1eu_position, 77, 1, 2, 1, 6, 0},
  {"eu_power", (object (*)())_1eu_power, 78, 1, 2, 1, 6, 0},
  {"eu_prepend", (object (*)())_1eu_prepend, 79, 1, 2, 1, 6, 0},
  {"eu_print", (object (*)())_1eu_print, 80, 1, 2, 1, 6, 0},
  {"eu_printf", (object (*)())_1eu_printf, 81, 1, 3, 1, 6, 0},
  {"eu_puts", (object (*)())_1eu_puts, 82, 1, 2, 1, 6, 0},
  {"eu_rand", (object (*)())_1eu_rand, 83, 1, 1, 1, 6, 0},
  {"eu_remainder", (object (*)())_1eu_remainder, 84, 1, 2, 1, 6, 0},
  {"eu_sequence", (object (*)())_1eu_sequence, 85, 1, 1, 1, 6, 0},
  {"eu_sin", (object (*)())_1eu_sin, 86, 1, 1, 1, 6, 0},
  {"eu_sprintf", (object (*)())_1eu_sprintf, 87, 1, 2, 1, 6, 0},
  {"eu_sqrt", (object (*)())_1eu_sqrt, 88, 1, 1, 1, 6, 0},
  {"eu_subscript", (object (*)())_1eu_subscript, 89, 1, 3, 1, 6, 0},
  {"eu_system", (object (*)())_1eu_system, 90, 1, 2, 1, 6, 0},
  {"eu_system_exec", (object (*)())_1eu_system_exec, 91, 1, 2, 1, 6, 0},
  {"eu_tan", (object (*)())_1eu_tan, 92, 1, 1, 1, 6, 0},
  {"eu_time", (object (*)())_1eu_time, 93, 1, 0, 1, 6, 0},
  {"eu_xor_bits", (object (*)())_1eu_xor_bits, 94, 1, 2, 1, 6, 0},
  {"eu_hash", (object (*)())_1eu_hash, 95, 1, 2, 1, 6, 0},
  {"eu_head", (object (*)())_1eu_head, 96, 1, 2, 1, 6, 0},
  {"eu_include_paths", (object (*)())_1eu_include_paths, 97, 1, 1, 1, 6, 0},
  {"eu_insert", (object (*)())_1eu_insert, 98, 1, 3, 1, 6, 0},
  {"eu_peek2s", (object (*)())_1eu_peek2s, 99, 1, 1, 1, 6, 0},
  {"eu_peek2u", (object (*)())_1eu_peek2u, 100, 1, 1, 1, 6, 0},
  {"eu_peek8s", (object (*)())_1eu_peek8s, 101, 1, 1, 1, 6, 0},
  {"eu_peek8u", (object (*)())_1eu_peek8u, 102, 1, 1, 1, 6, 0},
  {"eu_peek_longs", (object (*)())_1eu_peek_longs, 103, 1, 1, 1, 6, 0},
  {"eu_peek_longu", (object (*)())_1eu_peek_longu, 104, 1, 1, 1, 6, 0},
  {"eu_peek_pointer", (object (*)())_1eu_peek_pointer, 105, 1, 1, 1, 6, 0},
  {"eu_peek_string", (object (*)())_1eu_peek_string, 106, 1, 1, 1, 6, 0},
  {"eu_peeks", (object (*)())_1eu_peeks, 107, 1, 1, 1, 6, 0},
  {"eu_poke2", (object (*)())_1eu_poke2, 108, 1, 2, 1, 6, 0},
  {"eu_poke8", (object (*)())_1eu_poke8, 109, 1, 2, 1, 6, 0},
  {"eu_poke_long", (object (*)())_1eu_poke_long, 110, 1, 2, 1, 6, 0},
  {"eu_poke_pointer", (object (*)())_1eu_poke_pointer, 111, 1, 2, 1, 6, 0},
  {"eu_remove", (object (*)())_1eu_remove, 112, 1, 3, 1, 6, 0},
  {"eu_replace", (object (*)())_1eu_replace, 113, 1, 4, 1, 6, 0},
  {"eu_splice", (object (*)())_1eu_splice, 114, 1, 3, 1, 6, 0},
  {"eu_tail", (object (*)())_1eu_tail, 115, 1, 2, 1, 6, 0},
  {"eu_call_func_std", (object (*)())_1eu_call_func_std, 116, 1, 2, 1, 6, 0},
  {"eu_call_func_val", (object (*)())_1eu_call_func_val, 117, 1, 2, 1, 6, 0},
  {"eu_call_func", (object (*)())_1eu_call_func, 118, 1, 2, 1, 6, 0},
  {"eu_call_proc", (object (*)())_1eu_call_proc, 119, 1, 2, 1, 6, 0},
  {"eu_routine_id", (object (*)())_1eu_routine_id, 120, 1, 1, 1, 6, 0},
  {"eu_routine_id_str", (object (*)())_1eu_routine_id_str, 121, 1, 2, 1, 6, 0},
  {"set_return_linked_list", (object (*)())_2set_return_linked_list, 122, 2, 1, 1, 13, 0},
  {"get_return_linked_list", (object (*)())_2get_return_linked_list, 123, 2, 0, 1, 13, 0},
  {"mystring", (object (*)())_2mystring, 124, 2, 1, 1, 13, 0},
  {"myarray", (object (*)())_2myarray, 125, 2, 1, 1, 13, 0},
  {"sequence_to_linked_list", (object (*)())_2sequence_to_linked_list, 126, 2, 1, 1, 13, 0},
  {"free_linked_list", (object (*)())_2free_linked_list, 127, 2, 1, 1, 13, 0},
  {"linked_list_to_sequence", (object (*)())_2linked_list_to_sequence, 128, 2, 1, 1, 13, 0},
  {"allocate", (object (*)())_3allocate, 135, 3, 1, 1, 6, 0},
  {"free", (object (*)())_3free, 136, 3, 1, 1, 6, 0},
  {"allocate_low", (object (*)())_3allocate_low, 137, 3, 1, 1, 6, 0},
  {"free_low", (object (*)())_3free_low, 138, 3, 1, 1, 6, 0},
  {"int_to_bytes", (object (*)())_3int_to_bytes, 139, 3, 1, 1, 6, 0},
  {"bytes_to_int", (object (*)())_3bytes_to_int, 140, 3, 1, 1, 6, 0},
  {"int_to_bits", (object (*)())_3int_to_bits, 141, 3, 2, 1, 6, 0},
  {"bits_to_int", (object (*)())_3bits_to_int, 142, 3, 1, 1, 6, 0},
  {"set_rand", (object (*)())_3set_rand, 143, 3, 1, 1, 6, 0},
  {"crash_message", (object (*)())_3crash_message, 144, 3, 1, 1, 6, 0},
  {"crash_file", (object (*)())_3crash_file, 145, 3, 1, 1, 6, 0},
  {"crash_routine", (object (*)())_3crash_routine, 146, 3, 1, 1, 6, 0},
  {"atom_to_float64", (object (*)())_3atom_to_float64, 147, 3, 1, 1, 6, 0},
  {"atom_to_float32", (object (*)())_3atom_to_float32, 148, 3, 1, 1, 6, 0},
  {"float64_to_atom", (object (*)())_3float64_to_atom, 149, 3, 1, 1, 6, 0},
  {"float32_to_atom", (object (*)())_3float32_to_atom, 150, 3, 1, 1, 6, 0},
  {"allocate_string", (object (*)())_3allocate_string, 151, 3, 1, 1, 6, 0},
  {"register_block", (object (*)())_3register_block, 152, 3, 2, 1, 6, 0},
  {"unregister_block", (object (*)())_3unregister_block, 153, 3, 1, 1, 6, 0},
  {"check_all_blocks", (object (*)())_3check_all_blocks, 154, 3, 0, 1, 6, 0},
  {"", 0, 999999999, 0, 0, 0, 0}
};

char ** _02;
object _0switches;
struct ns_list _01[] = {
  {"eu", 0, 0, 1},
  {"libeu", 1, 1, 1},
  {"list", 2, 2, 2},
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern char *string_ptr;
    extern double sqrt();
    setran(); /* initialize random generator seeds */
    _495 = NewString("C:\\Users\\Owner\\OneDrive\\projects\\euwrap\\libeu4_win32");
    _494 = NewString("C:\\Users\\Owner\\OneDrive\\euphoria-4.1.0-Windows-x86/include");
    _5 = NewString("");
    _122 = NewDouble((eudouble)-2.14748364800000000000e+009L);
    _121 = NewDouble((eudouble)2.14748364800000000000e+009L);
    _127 = NewDouble((eudouble)2.14748364700000000000e+009L);
    _124 = NewDouble((eudouble)4.29496729500000000000e+009L);
    _135 = NewDouble((eudouble)3.48966092800000000000e+009L);
    _134 = NewDouble((eudouble)2.95279001600000000000e+009L);
    _133 = NewDouble((eudouble)2.68435456000000000000e+009L);
    _132 = NewDouble((eudouble)2.41591910400000000000e+009L);
    _131 = NewDouble((eudouble)4.02653184000000000000e+009L);
	_2SIGN_MASK_456 = NewDouble( 4026531840.00000000000000000000L );
	_2SIGN_FLAG_458 = NewDouble( 2147483648.00000000000000000000L );
	_2DOUBLE_FLAG_459 = NewDouble( 2415919104.00000000000000000000L );
	_2INT_FLAG_461 = NewDouble( 2684354560.00000000000000000000L );
	_2UINT_FLAG_463 = NewDouble( 2952790016.00000000000000000000L );
	_2FLOAT_FLAG_465 = NewDouble( 3489660928.00000000000000000000L );
	_2CSTRING_467 = NewDouble( 4294967295.00000000000000000000L );
	_2CBYTES_468 = NewDouble( 2147483648.00000000000000000000L );
}
