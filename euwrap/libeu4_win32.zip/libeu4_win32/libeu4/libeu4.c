// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object  __stdcall _1get_version()
{
    object _0, _1, _2;
    

    /** libeu4.e:29		return VERSION*/
    return 4;
    ;
}
object get_version() __attribute__ ((alias ("_1get_version@0")));


void  __stdcall _1init()
{
    object _0, _1, _2;
    

    /** libeu4.e:40		high_address = 0*/
    _1high_address_723 = 0;

    /** libeu4.e:41		data = {} -- objects*/
    RefDS(_5);
    DeRef(_1data_724);
    _1data_724 = _5;

    /** libeu4.e:42		free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRefi(_1free_list_725);
    _1free_list_725 = _5;

    /** libeu4.e:43	end procedure*/
    return;
    ;
}
void init() __attribute__ ((alias ("_1init@0")));


object  __stdcall _1get_high_address()
{
    object _0, _1, _2;
    

    /** libeu4.e:47		return high_address*/
    return _1high_address_723;
    ;
}
object get_high_address() __attribute__ ((alias ("_1get_high_address@0")));


object _1set_high_address(object _ma_733)
{
    object _297 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:51		high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_733)) {
        if (65536 > 0 && _ma_733 >= 0) {
            _1high_address_723 = _ma_733 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_ma_733 / (eudouble)65536);
            _1high_address_723 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_733, 65536);
        _1high_address_723 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_723)) {
        _1 = (object)(DBL_PTR(_1high_address_723)->dbl);
        DeRefDS(_1high_address_723);
        _1high_address_723 = _1;
    }

    /** libeu4.e:52		return and_bits( ma, #0000FFFF )*/
    if (IS_ATOM_INT(_ma_733)) {
        {uintptr_t tu;
             tu = (uintptr_t)_ma_733 & (uintptr_t)65535;
             _297 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)65535;
        _297 = Dand_bits(DBL_PTR(_ma_733), &temp_d);
    }
    DeRef(_ma_733);
    return _297;
    ;
}


object _1get_address(object _low_740, object _high_741)
{
    object _299 = NOVALUE;
    object _298 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_740)) {
        _1 = (object)(DBL_PTR(_low_740)->dbl);
        DeRefDS(_low_740);
        _low_740 = _1;
    }
    if (!IS_ATOM_INT(_high_741)) {
        _1 = (object)(DBL_PTR(_high_741)->dbl);
        DeRefDS(_high_741);
        _high_741 = _1;
    }

    /** libeu4.e:56		return high * #00010000 + low*/
    _298 = NewDouble(_high_741 * (eudouble)65536);
    if (IS_ATOM_INT(_298)) {
        _299 = _298 + _low_740;
        if ((object)((uintptr_t)_299 + (uintptr_t)HIGH_BITS) >= 0){
            _299 = NewDouble((eudouble)_299);
        }
    }
    else {
        _299 = NewDouble(DBL_PTR(_298)->dbl + (eudouble)_low_740);
    }
    DeRef(_298);
    _298 = NOVALUE;
    return _299;
    ;
}


object _1register_data(object _ob_746)
{
    object _i_747 = NOVALUE;
    object _ret_748 = NOVALUE;
    object _a_749 = NOVALUE;
    object _s_750 = NOVALUE;
    object _311 = NOVALUE;
    object _308 = NOVALUE;
    object _306 = NOVALUE;
    object _305 = NOVALUE;
    object _304 = NOVALUE;
    object _302 = NOVALUE;
    object _300 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:63		if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_725)){
            _300 = SEQ_PTR(_1free_list_725)->length;
    }
    else {
        _300 = 1;
    }
    if (_300 == 0)
    {
        _300 = NOVALUE;
        goto L1; // [8] 106
    }
    else{
        _300 = NOVALUE;
    }

    /** libeu4.e:64			ret = free_list[1]*/
    _2 = (object)SEQ_PTR(_1free_list_725);
    _ret_748 = (object)*(((s1_ptr)_2)->base + 1);

    /** libeu4.e:65			free_list = free_list[2..length(free_list)]*/
    if (IS_SEQUENCE(_1free_list_725)){
            _302 = SEQ_PTR(_1free_list_725)->length;
    }
    else {
        _302 = 1;
    }
    rhs_slice_target = (object_ptr)&_1free_list_725;
    RHS_Slice(_1free_list_725, 2, _302);

    /** libeu4.e:66			if integer(ob) then*/
    if (IS_ATOM_INT(_ob_746))
    _304 = 1;
    else if (IS_ATOM_DBL(_ob_746))
    _304 = IS_ATOM_INT(DoubleToInt(_ob_746));
    else
    _304 = 0;
    if (_304 == 0)
    {
        _304 = NOVALUE;
        goto L2; // [38] 59
    }
    else{
        _304 = NOVALUE;
    }

    /** libeu4.e:67				i = ob*/
    Ref(_ob_746);
    _i_747 = _ob_746;
    if (!IS_ATOM_INT(_i_747)) {
        _1 = (object)(DBL_PTR(_i_747)->dbl);
        DeRefDS(_i_747);
        _i_747 = _1;
    }

    /** libeu4.e:68				data[ret] = i*/
    _2 = (object)SEQ_PTR(_1data_724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _1data_724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_748);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _i_747;
    DeRef(_1);
    goto L3; // [56] 99
L2: 

    /** libeu4.e:69			elsif atom(ob) then*/
    _305 = IS_ATOM(_ob_746);
    if (_305 == 0)
    {
        _305 = NOVALUE;
        goto L4; // [64] 83
    }
    else{
        _305 = NOVALUE;
    }

    /** libeu4.e:70				a = ob*/
    Ref(_ob_746);
    DeRef(_a_749);
    _a_749 = _ob_746;

    /** libeu4.e:71				data[ret] = a*/
    Ref(_a_749);
    _2 = (object)SEQ_PTR(_1data_724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _1data_724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_748);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _a_749;
    DeRef(_1);
    goto L3; // [80] 99
L4: 

    /** libeu4.e:73				s = ob*/
    Ref(_ob_746);
    DeRef(_s_750);
    _s_750 = _ob_746;

    /** libeu4.e:74				data[ret] = s*/
    RefDS(_s_750);
    _2 = (object)SEQ_PTR(_1data_724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _1data_724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_748);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_750;
    DeRef(_1);
L3: 

    /** libeu4.e:76			return ret*/
    DeRef(_ob_746);
    DeRef(_a_749);
    DeRef(_s_750);
    return _ret_748;
L1: 

    /** libeu4.e:78		if integer(ob) then*/
    if (IS_ATOM_INT(_ob_746))
    _306 = 1;
    else if (IS_ATOM_DBL(_ob_746))
    _306 = IS_ATOM_INT(DoubleToInt(_ob_746));
    else
    _306 = 0;
    if (_306 == 0)
    {
        _306 = NOVALUE;
        goto L5; // [111] 132
    }
    else{
        _306 = NOVALUE;
    }

    /** libeu4.e:79			i = ob*/
    Ref(_ob_746);
    _i_747 = _ob_746;
    if (!IS_ATOM_INT(_i_747)) {
        _1 = (object)(DBL_PTR(_i_747)->dbl);
        DeRefDS(_i_747);
        _i_747 = _1;
    }

    /** libeu4.e:80			data = append(data, i)*/
    Append(&_1data_724, _1data_724, _i_747);
    goto L6; // [129] 172
L5: 

    /** libeu4.e:81		elsif atom(ob) then*/
    _308 = IS_ATOM(_ob_746);
    if (_308 == 0)
    {
        _308 = NOVALUE;
        goto L7; // [137] 156
    }
    else{
        _308 = NOVALUE;
    }

    /** libeu4.e:82			a = ob*/
    Ref(_ob_746);
    DeRef(_a_749);
    _a_749 = _ob_746;

    /** libeu4.e:83			data = append(data, a)*/
    Ref(_a_749);
    Append(&_1data_724, _1data_724, _a_749);
    goto L6; // [153] 172
L7: 

    /** libeu4.e:85			s = ob*/
    Ref(_ob_746);
    DeRef(_s_750);
    _s_750 = _ob_746;

    /** libeu4.e:86			data = append(data, s)*/
    RefDS(_s_750);
    Append(&_1data_724, _1data_724, _s_750);
L6: 

    /** libeu4.e:88		return length(data)*/
    if (IS_SEQUENCE(_1data_724)){
            _311 = SEQ_PTR(_1data_724)->length;
    }
    else {
        _311 = 1;
    }
    DeRef(_ob_746);
    DeRef(_a_749);
    DeRef(_s_750);
    return _311;
    ;
}


object _1retval(object _ob_772)
{
    object _312 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_772);
    _312 = _1register_data(_ob_772);
    DeRef(_ob_772);
    return _312;
    ;
}


object  __stdcall _1length_of_data()
{
    object _313 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:96		return length(data)*/
    if (IS_SEQUENCE(_1data_724)){
            _313 = SEQ_PTR(_1data_724)->length;
    }
    else {
        _313 = 1;
    }
    return _313;
    ;
}
object length_of_data() __attribute__ ((alias ("_1length_of_data@0")));


object  __stdcall _1is_free(object _id_779)
{
    object _315 = NOVALUE;
    object _314 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_779)) {
        _1 = (object)(DBL_PTR(_id_779)->dbl);
        DeRefDS(_id_779);
        _id_779 = _1;
    }

    /** libeu4.e:100		return find(id, free_list) and 1 -- boolean*/
    _314 = find_from(_id_779, _1free_list_725, 1);
    _315 = (_314 != 0 && 1 != 0);
    _314 = NOVALUE;
    return _315;
    ;
}
object is_free() __attribute__ ((alias ("_1is_free@4")));


object  __stdcall _1access_free_list()
{
    object _set_high_address_inlined_set_high_address_at_41_792 = NOVALUE;
    object _ma_784 = NOVALUE;
    object _318 = NOVALUE;
    object _317 = NOVALUE;
    object _316 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:105		ma = 0*/
    DeRef(_ma_784);
    _ma_784 = 0;

    /** libeu4.e:106		if length(free_list) then*/
    if (IS_SEQUENCE(_1free_list_725)){
            _316 = SEQ_PTR(_1free_list_725)->length;
    }
    else {
        _316 = 1;
    }
    if (_316 == 0)
    {
        _316 = NOVALUE;
        goto L1; // [13] 39
    }
    else{
        _316 = NOVALUE;
    }

    /** libeu4.e:107			ma = allocate(length(free_list) * 4)*/
    if (IS_SEQUENCE(_1free_list_725)){
            _317 = SEQ_PTR(_1free_list_725)->length;
    }
    else {
        _317 = 1;
    }
    if (_317 == (short)_317){
        _318 = _317 * 4;
    }
    else{
        _318 = NewDouble(_317 * (eudouble)4);
    }
    _317 = NOVALUE;
    _ma_784 = _3allocate(_318);
    _318 = NOVALUE;

    /** libeu4.e:108			poke4(ma, free_list)*/
    if (IS_ATOM_INT(_ma_784)){
        poke4_addr = (uint32_t *)_ma_784;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_ma_784)->dbl);
    }
    _1 = (object)SEQ_PTR(_1free_list_725);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke4_addr++ = (int32_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
        }
    }
L1: 

    /** libeu4.e:111		return set_high_address(ma)*/

    /** libeu4.e:51		high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_784)) {
        if (65536 > 0 && _ma_784 >= 0) {
            _1high_address_723 = _ma_784 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_ma_784 / (eudouble)65536);
            _1high_address_723 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_784, 65536);
        _1high_address_723 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_723)) {
        _1 = (object)(DBL_PTR(_1high_address_723)->dbl);
        DeRefDS(_1high_address_723);
        _1high_address_723 = _1;
    }

    /** libeu4.e:52		return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_41_792);
    if (IS_ATOM_INT(_ma_784)) {
        {uintptr_t tu;
             tu = (uintptr_t)_ma_784 & (uintptr_t)65535;
             _set_high_address_inlined_set_high_address_at_41_792 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)65535;
        _set_high_address_inlined_set_high_address_at_41_792 = Dand_bits(DBL_PTR(_ma_784), &temp_d);
    }
    DeRef(_ma_784);
    return _set_high_address_inlined_set_high_address_at_41_792;
    ;
}
object access_free_list() __attribute__ ((alias ("_1access_free_list@0")));


void  __stdcall _1generic_free(object _low_795, object _high_796)
{
    object _ma_797 = NOVALUE;
    object _get_address_1__tmp_at6_800 = NOVALUE;
    object _get_address_inlined_get_address_at_6_799 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_795)) {
        _1 = (object)(DBL_PTR(_low_795)->dbl);
        DeRefDS(_low_795);
        _low_795 = _1;
    }
    if (!IS_ATOM_INT(_high_796)) {
        _1 = (object)(DBL_PTR(_high_796)->dbl);
        DeRefDS(_high_796);
        _high_796 = _1;
    }

    /** libeu4.e:117		ma = get_address(low, high)*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_800);
    _get_address_1__tmp_at6_800 = NewDouble(_high_796 * (eudouble)65536);
    DeRef(_ma_797);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_800)) {
        _ma_797 = _get_address_1__tmp_at6_800 + _low_795;
        if ((object)((uintptr_t)_ma_797 + (uintptr_t)HIGH_BITS) >= 0){
            _ma_797 = NewDouble((eudouble)_ma_797);
        }
    }
    else {
        _ma_797 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_800)->dbl + (eudouble)_low_795);
    }
    DeRef(_get_address_1__tmp_at6_800);
    _get_address_1__tmp_at6_800 = NOVALUE;

    /** libeu4.e:118		if ma then*/
    if (_ma_797 == 0) {
        goto L1; // [22] 31
    }
    else {
        if (!IS_ATOM_INT(_ma_797) && DBL_PTR(_ma_797)->dbl == 0.0){
            goto L1; // [22] 31
        }
    }

    /** libeu4.e:119			free(ma)*/
    Ref(_ma_797);
    _3free(_ma_797);
L1: 

    /** libeu4.e:121	end procedure*/
    DeRef(_ma_797);
    return;
    ;
}
void generic_free() __attribute__ ((alias ("_1generic_free@8")));


void  __stdcall _1delete_linked_list(object _id_805)
{
    object _is_free_1__tmp_at4_809 = NOVALUE;
    object _is_free_inlined_is_free_at_4_808 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_805)) {
        _1 = (object)(DBL_PTR(_id_805)->dbl);
        DeRefDS(_id_805);
        _id_805 = _1;
    }

    /** libeu4.e:124		if not is_free(id) then*/

    /** libeu4.e:100		return find(id, free_list) and 1 -- boolean*/
    _is_free_1__tmp_at4_809 = find_from(_id_805, _1free_list_725, 1);
    _is_free_inlined_is_free_at_4_808 = (_is_free_1__tmp_at4_809 != 0 && 1 != 0);
    if (_is_free_inlined_is_free_at_4_808 != 0)
    goto L1; // [21] 41

    /** libeu4.e:125			data[id] = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_1data_724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _1data_724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _id_805);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** libeu4.e:126			free_list = prepend(free_list, id)*/
    Prepend(&_1free_list_725, _1free_list_725, _id_805);
L1: 

    /** libeu4.e:128	end procedure*/
    return;
    ;
}
void delete_linked_list() __attribute__ ((alias ("_1delete_linked_list@4")));


void  __stdcall _1free_linked_lists(object _low_814, object _high_815, object _len_816)
{
    object _array_817 = NOVALUE;
    object _ma_818 = NOVALUE;
    object _get_address_1__tmp_at8_821 = NOVALUE;
    object _get_address_inlined_get_address_at_8_820 = NOVALUE;
    object _325 = NOVALUE;
    object _324 = NOVALUE;
    object _322 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_814)) {
        _1 = (object)(DBL_PTR(_low_814)->dbl);
        DeRefDS(_low_814);
        _low_814 = _1;
    }
    if (!IS_ATOM_INT(_high_815)) {
        _1 = (object)(DBL_PTR(_high_815)->dbl);
        DeRefDS(_high_815);
        _high_815 = _1;
    }
    if (!IS_ATOM_INT(_len_816)) {
        _1 = (object)(DBL_PTR(_len_816)->dbl);
        DeRefDS(_len_816);
        _len_816 = _1;
    }

    /** libeu4.e:134		ma = get_address(low, high)*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_821);
    _get_address_1__tmp_at8_821 = NewDouble(_high_815 * (eudouble)65536);
    DeRef(_ma_818);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_821)) {
        _ma_818 = _get_address_1__tmp_at8_821 + _low_814;
        if ((object)((uintptr_t)_ma_818 + (uintptr_t)HIGH_BITS) >= 0){
            _ma_818 = NewDouble((eudouble)_ma_818);
        }
    }
    else {
        _ma_818 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_821)->dbl + (eudouble)_low_814);
    }
    DeRef(_get_address_1__tmp_at8_821);
    _get_address_1__tmp_at8_821 = NOVALUE;

    /** libeu4.e:135		array = peek4u({ma, len})*/
    Ref(_ma_818);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ma_818;
    ((intptr_t *)_2)[2] = _len_816;
    _322 = MAKE_SEQ(_1);
    DeRef(_array_817);
    _1 = (object)SEQ_PTR(_322);
    peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _array_817 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        _1 = (object)*peek4_addr++;
        if ((uintptr_t)_1 > (uintptr_t)MAXINT){
            _1 = NewDouble((eudouble)(uintptr_t)_1);
        }
        *pokeptr_addr = _1;
    }
    DeRefDS(_322);
    _322 = NOVALUE;

    /** libeu4.e:136		for i = 1 to length(array) do*/
    if (IS_SEQUENCE(_array_817)){
            _324 = SEQ_PTR(_array_817)->length;
    }
    else {
        _324 = 1;
    }
    {
        object _i_825;
        _i_825 = 1;
L1: 
        if (_i_825 > _324){
            goto L2; // [38] 61
        }

        /** libeu4.e:137			delete_linked_list(array[i])*/
        _2 = (object)SEQ_PTR(_array_817);
        _325 = (object)*(((s1_ptr)_2)->base + _i_825);
        Ref(_325);
        _1delete_linked_list(_325);
        _325 = NOVALUE;

        /** libeu4.e:138		end for*/
        _i_825 = _i_825 + 1;
        goto L1; // [56] 45
L2: 
        ;
    }

    /** libeu4.e:139	end procedure*/
    DeRef(_array_817);
    DeRef(_ma_818);
    return;
    ;
}
void free_linked_lists() __attribute__ ((alias ("_1free_linked_lists@12")));


object  __stdcall _1register_linked_list(object _low_830, object _high_831)
{
    object _get_address_1__tmp_at6_835 = NOVALUE;
    object _get_address_inlined_get_address_at_6_834 = NOVALUE;
    object _327 = NOVALUE;
    object _326 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_830)) {
        _1 = (object)(DBL_PTR(_low_830)->dbl);
        DeRefDS(_low_830);
        _low_830 = _1;
    }
    if (!IS_ATOM_INT(_high_831)) {
        _1 = (object)(DBL_PTR(_high_831)->dbl);
        DeRefDS(_high_831);
        _high_831 = _1;
    }

    /** libeu4.e:143		return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_835);
    _get_address_1__tmp_at6_835 = NewDouble(_high_831 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_6_834);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_835)) {
        _get_address_inlined_get_address_at_6_834 = _get_address_1__tmp_at6_835 + _low_830;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_6_834 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_6_834 = NewDouble((eudouble)_get_address_inlined_get_address_at_6_834);
        }
    }
    else {
        _get_address_inlined_get_address_at_6_834 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_835)->dbl + (eudouble)_low_830);
    }
    DeRef(_get_address_1__tmp_at6_835);
    _get_address_1__tmp_at6_835 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_834);
    _326 = _2linked_list_to_sequence(_get_address_inlined_get_address_at_6_834);
    _327 = _1register_data(_326);
    _326 = NOVALUE;
    return _327;
    ;
}
object register_linked_list() __attribute__ ((alias ("_1register_linked_list@8")));


object  __stdcall _1new_linked_list(object _low_840, object _high_841)
{
    object _get_address_1__tmp_at6_845 = NOVALUE;
    object _get_address_inlined_get_address_at_6_844 = NOVALUE;
    object _329 = NOVALUE;
    object _328 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_840)) {
        _1 = (object)(DBL_PTR(_low_840)->dbl);
        DeRefDS(_low_840);
        _low_840 = _1;
    }
    if (!IS_ATOM_INT(_high_841)) {
        _1 = (object)(DBL_PTR(_high_841)->dbl);
        DeRefDS(_high_841);
        _high_841 = _1;
    }

    /** libeu4.e:146		return register_data(linked_list_to_sequence(get_address(low, high)))*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_845);
    _get_address_1__tmp_at6_845 = NewDouble(_high_841 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_6_844);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_845)) {
        _get_address_inlined_get_address_at_6_844 = _get_address_1__tmp_at6_845 + _low_840;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_6_844 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_6_844 = NewDouble((eudouble)_get_address_inlined_get_address_at_6_844);
        }
    }
    else {
        _get_address_inlined_get_address_at_6_844 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_845)->dbl + (eudouble)_low_840);
    }
    DeRef(_get_address_1__tmp_at6_845);
    _get_address_1__tmp_at6_845 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_844);
    _328 = _2linked_list_to_sequence(_get_address_inlined_get_address_at_6_844);
    _329 = _1register_data(_328);
    _328 = NOVALUE;
    return _329;
    ;
}
object new_linked_list() __attribute__ ((alias ("_1new_linked_list@8")));


void  __stdcall _1store_linked_list(object _id_850, object _low_851, object _high_852)
{
    object _get_address_1__tmp_at10_856 = NOVALUE;
    object _get_address_inlined_get_address_at_10_855 = NOVALUE;
    object _330 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_850)) {
        _1 = (object)(DBL_PTR(_id_850)->dbl);
        DeRefDS(_id_850);
        _id_850 = _1;
    }
    if (!IS_ATOM_INT(_low_851)) {
        _1 = (object)(DBL_PTR(_low_851)->dbl);
        DeRefDS(_low_851);
        _low_851 = _1;
    }
    if (!IS_ATOM_INT(_high_852)) {
        _1 = (object)(DBL_PTR(_high_852)->dbl);
        DeRefDS(_high_852);
        _high_852 = _1;
    }

    /** libeu4.e:150		data[id] = linked_list_to_sequence(get_address(low, high))*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_856);
    _get_address_1__tmp_at10_856 = NewDouble(_high_852 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_10_855);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_856)) {
        _get_address_inlined_get_address_at_10_855 = _get_address_1__tmp_at10_856 + _low_851;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_10_855 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_10_855 = NewDouble((eudouble)_get_address_inlined_get_address_at_10_855);
        }
    }
    else {
        _get_address_inlined_get_address_at_10_855 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_856)->dbl + (eudouble)_low_851);
    }
    DeRef(_get_address_1__tmp_at10_856);
    _get_address_1__tmp_at10_856 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_10_855);
    _330 = _2linked_list_to_sequence(_get_address_inlined_get_address_at_10_855);
    _2 = (object)SEQ_PTR(_1data_724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _1data_724 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _id_850);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _330;
    if( _1 != _330 ){
        DeRef(_1);
    }
    _330 = NOVALUE;

    /** libeu4.e:151	end procedure*/
    return;
    ;
}
void store_linked_list() __attribute__ ((alias ("_1store_linked_list@12")));


object  __stdcall _1access_linked_list(object _id_860)
{
    object _set_high_address_inlined_set_high_address_at_18_866 = NOVALUE;
    object _ma_inlined_set_high_address_at_15_865 = NOVALUE;
    object _332 = NOVALUE;
    object _331 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_860)) {
        _1 = (object)(DBL_PTR(_id_860)->dbl);
        DeRefDS(_id_860);
        _id_860 = _1;
    }

    /** libeu4.e:154		return set_high_address(sequence_to_linked_list(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _331 = (object)*(((s1_ptr)_2)->base + _id_860);
    Ref(_331);
    _332 = _2sequence_to_linked_list(_331);
    _331 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_15_865);
    _ma_inlined_set_high_address_at_15_865 = _332;
    _332 = NOVALUE;

    /** libeu4.e:51		high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_865)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_15_865 >= 0) {
            _1high_address_723 = _ma_inlined_set_high_address_at_15_865 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_ma_inlined_set_high_address_at_15_865 / (eudouble)65536);
            _1high_address_723 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_15_865, 65536);
        _1high_address_723 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_723)) {
        _1 = (object)(DBL_PTR(_1high_address_723)->dbl);
        DeRefDS(_1high_address_723);
        _1high_address_723 = _1;
    }

    /** libeu4.e:52		return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_18_866);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_15_865)) {
        {uintptr_t tu;
             tu = (uintptr_t)_ma_inlined_set_high_address_at_15_865 & (uintptr_t)65535;
             _set_high_address_inlined_set_high_address_at_18_866 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_18_866 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_15_865, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_15_865);
    _ma_inlined_set_high_address_at_15_865 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_18_866;
    ;
}
object access_linked_list() __attribute__ ((alias ("_1access_linked_list@4")));


object  __stdcall _1at_linked_list(object _id_869, object _index_870)
{
    object _set_high_address_inlined_set_high_address_at_24_877 = NOVALUE;
    object _ma_inlined_set_high_address_at_21_876 = NOVALUE;
    object _335 = NOVALUE;
    object _334 = NOVALUE;
    object _333 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_869)) {
        _1 = (object)(DBL_PTR(_id_869)->dbl);
        DeRefDS(_id_869);
        _id_869 = _1;
    }
    if (!IS_ATOM_INT(_index_870)) {
        _1 = (object)(DBL_PTR(_index_870)->dbl);
        DeRefDS(_index_870);
        _index_870 = _1;
    }

    /** libeu4.e:158		return set_high_address(sequence_to_linked_list(data[id][index]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _333 = (object)*(((s1_ptr)_2)->base + _id_869);
    _2 = (object)SEQ_PTR(_333);
    _334 = (object)*(((s1_ptr)_2)->base + _index_870);
    _333 = NOVALUE;
    Ref(_334);
    _335 = _2sequence_to_linked_list(_334);
    _334 = NOVALUE;
    DeRef(_ma_inlined_set_high_address_at_21_876);
    _ma_inlined_set_high_address_at_21_876 = _335;
    _335 = NOVALUE;

    /** libeu4.e:51		high_address = floor( ma / #00010000 )*/
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_876)) {
        if (65536 > 0 && _ma_inlined_set_high_address_at_21_876 >= 0) {
            _1high_address_723 = _ma_inlined_set_high_address_at_21_876 / 65536;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_ma_inlined_set_high_address_at_21_876 / (eudouble)65536);
            _1high_address_723 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _ma_inlined_set_high_address_at_21_876, 65536);
        _1high_address_723 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_1high_address_723)) {
        _1 = (object)(DBL_PTR(_1high_address_723)->dbl);
        DeRefDS(_1high_address_723);
        _1high_address_723 = _1;
    }

    /** libeu4.e:52		return and_bits( ma, #0000FFFF )*/
    DeRef(_set_high_address_inlined_set_high_address_at_24_877);
    if (IS_ATOM_INT(_ma_inlined_set_high_address_at_21_876)) {
        {uintptr_t tu;
             tu = (uintptr_t)_ma_inlined_set_high_address_at_21_876 & (uintptr_t)65535;
             _set_high_address_inlined_set_high_address_at_24_877 = MAKE_UINT(tu);
        }
    }
    else {
        _set_high_address_inlined_set_high_address_at_24_877 = binary_op(AND_BITS, _ma_inlined_set_high_address_at_21_876, 65535);
    }
    DeRef(_ma_inlined_set_high_address_at_21_876);
    _ma_inlined_set_high_address_at_21_876 = NOVALUE;
    return _set_high_address_inlined_set_high_address_at_24_877;
    ;
}
object at_linked_list() __attribute__ ((alias ("_1at_linked_list@8")));


void  __stdcall _1free_linked_list_dll(object _low_880, object _high_881)
{
    object _get_address_1__tmp_at6_885 = NOVALUE;
    object _get_address_inlined_get_address_at_6_884 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_880)) {
        _1 = (object)(DBL_PTR(_low_880)->dbl);
        DeRefDS(_low_880);
        _low_880 = _1;
    }
    if (!IS_ATOM_INT(_high_881)) {
        _1 = (object)(DBL_PTR(_high_881)->dbl);
        DeRefDS(_high_881);
        _high_881 = _1;
    }

    /** libeu4.e:162		free_linked_list(get_address(low, high))*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_885);
    _get_address_1__tmp_at6_885 = NewDouble(_high_881 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_6_884);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_885)) {
        _get_address_inlined_get_address_at_6_884 = _get_address_1__tmp_at6_885 + _low_880;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_6_884 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_6_884 = NewDouble((eudouble)_get_address_inlined_get_address_at_6_884);
        }
    }
    else {
        _get_address_inlined_get_address_at_6_884 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_885)->dbl + (eudouble)_low_880);
    }
    DeRef(_get_address_1__tmp_at6_885);
    _get_address_1__tmp_at6_885 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_6_884);
    _2free_linked_list(_get_address_inlined_get_address_at_6_884);

    /** libeu4.e:163	end procedure*/
    return;
    ;
}
void free_linked_list_dll() __attribute__ ((alias ("_1free_linked_list_dll@8")));


object  __stdcall _1length_linked_list(object _id_888)
{
    object _340 = NOVALUE;
    object _339 = NOVALUE;
    object _337 = NOVALUE;
    object _336 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_888)) {
        _1 = (object)(DBL_PTR(_id_888)->dbl);
        DeRefDS(_id_888);
        _id_888 = _1;
    }

    /** libeu4.e:166		if atom(data[id]) then*/
    _2 = (object)SEQ_PTR(_1data_724);
    _336 = (object)*(((s1_ptr)_2)->base + _id_888);
    _337 = IS_ATOM(_336);
    _336 = NOVALUE;
    if (_337 == 0)
    {
        _337 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _337 = NOVALUE;
    }

    /** libeu4.e:167			return -1*/
    return -1;
L1: 

    /** libeu4.e:169		return length(data[id])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _339 = (object)*(((s1_ptr)_2)->base + _id_888);
    if (IS_SEQUENCE(_339)){
            _340 = SEQ_PTR(_339)->length;
    }
    else {
        _340 = 1;
    }
    _339 = NOVALUE;
    _339 = NOVALUE;
    return _340;
    ;
}
object length_linked_list() __attribute__ ((alias ("_1length_linked_list@4")));


void  __stdcall _1store_at_linked_list(object _id_897, object _index_898, object _low_899, object _high_900)
{
    object _get_address_1__tmp_at17_906 = NOVALUE;
    object _get_address_inlined_get_address_at_17_905 = NOVALUE;
    object _343 = NOVALUE;
    object _341 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_id_897)) {
        _1 = (object)(DBL_PTR(_id_897)->dbl);
        DeRefDS(_id_897);
        _id_897 = _1;
    }
    if (!IS_ATOM_INT(_index_898)) {
        _1 = (object)(DBL_PTR(_index_898)->dbl);
        DeRefDS(_index_898);
        _index_898 = _1;
    }
    if (!IS_ATOM_INT(_low_899)) {
        _1 = (object)(DBL_PTR(_low_899)->dbl);
        DeRefDS(_low_899);
        _low_899 = _1;
    }
    if (!IS_ATOM_INT(_high_900)) {
        _1 = (object)(DBL_PTR(_high_900)->dbl);
        DeRefDS(_high_900);
        _high_900 = _1;
    }

    /** libeu4.e:173		data[id][index] = linked_list_to_sequence(get_address(low, high))*/
    _2 = (object)SEQ_PTR(_1data_724);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _1data_724 = MAKE_SEQ(_2);
    }
    _3 = (object)(_id_897 + ((s1_ptr)_2)->base);

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at17_906);
    _get_address_1__tmp_at17_906 = NewDouble(_high_900 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_17_905);
    if (IS_ATOM_INT(_get_address_1__tmp_at17_906)) {
        _get_address_inlined_get_address_at_17_905 = _get_address_1__tmp_at17_906 + _low_899;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_17_905 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_17_905 = NewDouble((eudouble)_get_address_inlined_get_address_at_17_905);
        }
    }
    else {
        _get_address_inlined_get_address_at_17_905 = NewDouble(DBL_PTR(_get_address_1__tmp_at17_906)->dbl + (eudouble)_low_899);
    }
    DeRef(_get_address_1__tmp_at17_906);
    _get_address_1__tmp_at17_906 = NOVALUE;
    Ref(_get_address_inlined_get_address_at_17_905);
    _343 = _2linked_list_to_sequence(_get_address_inlined_get_address_at_17_905);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_898);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _343;
    if( _1 != _343 ){
        DeRef(_1);
    }
    _343 = NOVALUE;
    _341 = NOVALUE;

    /** libeu4.e:174	end procedure*/
    return;
    ;
}
void store_at_linked_list() __attribute__ ((alias ("_1store_at_linked_list@16")));


object  __stdcall _1eu_repeat(object _id_910, object _len_911)
{
    object _retval_inlined_retval_at_19_916 = NOVALUE;
    object _ob_inlined_retval_at_16_915 = NOVALUE;
    object _345 = NOVALUE;
    object _344 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_910)) {
        _1 = (object)(DBL_PTR(_id_910)->dbl);
        DeRefDS(_id_910);
        _id_910 = _1;
    }
    if (!IS_ATOM_INT(_len_911)) {
        _1 = (object)(DBL_PTR(_len_911)->dbl);
        DeRefDS(_len_911);
        _len_911 = _1;
    }

    /** libeu4.e:180		return retval(repeat(data[id], len))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _344 = (object)*(((s1_ptr)_2)->base + _id_910);
    _345 = Repeat(_344, _len_911);
    _344 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_915);
    _ob_inlined_retval_at_16_915 = _345;
    _345 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_915);
    _0 = _retval_inlined_retval_at_19_916;
    _retval_inlined_retval_at_19_916 = _1register_data(_ob_inlined_retval_at_16_915);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_915);
    _ob_inlined_retval_at_16_915 = NOVALUE;
    return _retval_inlined_retval_at_19_916;
    ;
}
object eu_repeat() __attribute__ ((alias ("_1eu_repeat@8")));


void  __stdcall _1eu_mem_set(object _low_919, object _high_920, object _byte_val_921, object _how_many_922)
{
    object _get_address_1__tmp_at10_925 = NOVALUE;
    object _get_address_inlined_get_address_at_10_924 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_919)) {
        _1 = (object)(DBL_PTR(_low_919)->dbl);
        DeRefDS(_low_919);
        _low_919 = _1;
    }
    if (!IS_ATOM_INT(_high_920)) {
        _1 = (object)(DBL_PTR(_high_920)->dbl);
        DeRefDS(_high_920);
        _high_920 = _1;
    }
    if (!IS_ATOM_INT(_byte_val_921)) {
        _1 = (object)(DBL_PTR(_byte_val_921)->dbl);
        DeRefDS(_byte_val_921);
        _byte_val_921 = _1;
    }
    if (!IS_ATOM_INT(_how_many_922)) {
        _1 = (object)(DBL_PTR(_how_many_922)->dbl);
        DeRefDS(_how_many_922);
        _how_many_922 = _1;
    }

    /** libeu4.e:184		mem_set(get_address(low, high), byte_val, how_many)*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at10_925);
    _get_address_1__tmp_at10_925 = NewDouble(_high_920 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_10_924);
    if (IS_ATOM_INT(_get_address_1__tmp_at10_925)) {
        _get_address_inlined_get_address_at_10_924 = _get_address_1__tmp_at10_925 + _low_919;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_10_924 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_10_924 = NewDouble((eudouble)_get_address_inlined_get_address_at_10_924);
        }
    }
    else {
        _get_address_inlined_get_address_at_10_924 = NewDouble(DBL_PTR(_get_address_1__tmp_at10_925)->dbl + (eudouble)_low_919);
    }
    DeRef(_get_address_1__tmp_at10_925);
    _get_address_1__tmp_at10_925 = NOVALUE;
    memory_set(_get_address_inlined_get_address_at_10_924, _byte_val_921, _how_many_922);

    /** libeu4.e:185	end procedure*/
    return;
    ;
}
void eu_mem_set() __attribute__ ((alias ("_1eu_mem_set@16")));


void  __stdcall _1eu_mem_copy(object _dstlow_928, object _dsthigh_929, object _srclow_930, object _srchigh_931, object _len_932)
{
    object _get_address_1__tmp_at12_935 = NOVALUE;
    object _get_address_inlined_get_address_at_12_934 = NOVALUE;
    object _get_address_1__tmp_at25_938 = NOVALUE;
    object _get_address_inlined_get_address_at_25_937 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_dstlow_928)) {
        _1 = (object)(DBL_PTR(_dstlow_928)->dbl);
        DeRefDS(_dstlow_928);
        _dstlow_928 = _1;
    }
    if (!IS_ATOM_INT(_dsthigh_929)) {
        _1 = (object)(DBL_PTR(_dsthigh_929)->dbl);
        DeRefDS(_dsthigh_929);
        _dsthigh_929 = _1;
    }
    if (!IS_ATOM_INT(_srclow_930)) {
        _1 = (object)(DBL_PTR(_srclow_930)->dbl);
        DeRefDS(_srclow_930);
        _srclow_930 = _1;
    }
    if (!IS_ATOM_INT(_srchigh_931)) {
        _1 = (object)(DBL_PTR(_srchigh_931)->dbl);
        DeRefDS(_srchigh_931);
        _srchigh_931 = _1;
    }
    if (!IS_ATOM_INT(_len_932)) {
        _1 = (object)(DBL_PTR(_len_932)->dbl);
        DeRefDS(_len_932);
        _len_932 = _1;
    }

    /** libeu4.e:188		mem_copy(get_address(dstlow, dsthigh), get_address(srclow, srchigh), len)*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at12_935);
    _get_address_1__tmp_at12_935 = NewDouble(_dsthigh_929 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_12_934);
    if (IS_ATOM_INT(_get_address_1__tmp_at12_935)) {
        _get_address_inlined_get_address_at_12_934 = _get_address_1__tmp_at12_935 + _dstlow_928;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_12_934 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_12_934 = NewDouble((eudouble)_get_address_inlined_get_address_at_12_934);
        }
    }
    else {
        _get_address_inlined_get_address_at_12_934 = NewDouble(DBL_PTR(_get_address_1__tmp_at12_935)->dbl + (eudouble)_dstlow_928);
    }
    DeRef(_get_address_1__tmp_at12_935);
    _get_address_1__tmp_at12_935 = NOVALUE;

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at25_938);
    _get_address_1__tmp_at25_938 = NewDouble(_srchigh_931 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_25_937);
    if (IS_ATOM_INT(_get_address_1__tmp_at25_938)) {
        _get_address_inlined_get_address_at_25_937 = _get_address_1__tmp_at25_938 + _srclow_930;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_25_937 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_25_937 = NewDouble((eudouble)_get_address_inlined_get_address_at_25_937);
        }
    }
    else {
        _get_address_inlined_get_address_at_25_937 = NewDouble(DBL_PTR(_get_address_1__tmp_at25_938)->dbl + (eudouble)_srclow_930);
    }
    DeRef(_get_address_1__tmp_at25_938);
    _get_address_1__tmp_at25_938 = NOVALUE;
    memory_copy(_get_address_inlined_get_address_at_12_934, _get_address_inlined_get_address_at_25_937, _len_932);

    /** libeu4.e:189	end procedure*/
    return;
    ;
}
void eu_mem_copy() __attribute__ ((alias ("_1eu_mem_copy@20")));


object  __stdcall _1eu_add(object _id1_941, object _id2_942)
{
    object _retval_inlined_retval_at_25_948 = NOVALUE;
    object _ob_inlined_retval_at_22_947 = NOVALUE;
    object _348 = NOVALUE;
    object _347 = NOVALUE;
    object _346 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_941)) {
        _1 = (object)(DBL_PTR(_id1_941)->dbl);
        DeRefDS(_id1_941);
        _id1_941 = _1;
    }
    if (!IS_ATOM_INT(_id2_942)) {
        _1 = (object)(DBL_PTR(_id2_942)->dbl);
        DeRefDS(_id2_942);
        _id2_942 = _1;
    }

    /** libeu4.e:195		return retval(data[id1] + data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _346 = (object)*(((s1_ptr)_2)->base + _id1_941);
    _2 = (object)SEQ_PTR(_1data_724);
    _347 = (object)*(((s1_ptr)_2)->base + _id2_942);
    if (IS_ATOM_INT(_346) && IS_ATOM_INT(_347)) {
        _348 = _346 + _347;
        if ((object)((uintptr_t)_348 + (uintptr_t)HIGH_BITS) >= 0){
            _348 = NewDouble((eudouble)_348);
        }
    }
    else {
        _348 = binary_op(PLUS, _346, _347);
    }
    _346 = NOVALUE;
    _347 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_947);
    _ob_inlined_retval_at_22_947 = _348;
    _348 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_947);
    _0 = _retval_inlined_retval_at_25_948;
    _retval_inlined_retval_at_25_948 = _1register_data(_ob_inlined_retval_at_22_947);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_947);
    _ob_inlined_retval_at_22_947 = NOVALUE;
    return _retval_inlined_retval_at_25_948;
    ;
}
object eu_add() __attribute__ ((alias ("_1eu_add@8")));


object  __stdcall _1eu_subtract(object _id1_951, object _id2_952)
{
    object _retval_inlined_retval_at_25_958 = NOVALUE;
    object _ob_inlined_retval_at_22_957 = NOVALUE;
    object _351 = NOVALUE;
    object _350 = NOVALUE;
    object _349 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_951)) {
        _1 = (object)(DBL_PTR(_id1_951)->dbl);
        DeRefDS(_id1_951);
        _id1_951 = _1;
    }
    if (!IS_ATOM_INT(_id2_952)) {
        _1 = (object)(DBL_PTR(_id2_952)->dbl);
        DeRefDS(_id2_952);
        _id2_952 = _1;
    }

    /** libeu4.e:199		return retval(data[id1] - data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _349 = (object)*(((s1_ptr)_2)->base + _id1_951);
    _2 = (object)SEQ_PTR(_1data_724);
    _350 = (object)*(((s1_ptr)_2)->base + _id2_952);
    if (IS_ATOM_INT(_349) && IS_ATOM_INT(_350)) {
        _351 = _349 - _350;
        if ((object)((uintptr_t)_351 +(uintptr_t) HIGH_BITS) >= 0){
            _351 = NewDouble((eudouble)_351);
        }
    }
    else {
        _351 = binary_op(MINUS, _349, _350);
    }
    _349 = NOVALUE;
    _350 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_957);
    _ob_inlined_retval_at_22_957 = _351;
    _351 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_957);
    _0 = _retval_inlined_retval_at_25_958;
    _retval_inlined_retval_at_25_958 = _1register_data(_ob_inlined_retval_at_22_957);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_957);
    _ob_inlined_retval_at_22_957 = NOVALUE;
    return _retval_inlined_retval_at_25_958;
    ;
}
object eu_subtract() __attribute__ ((alias ("_1eu_subtract@8")));


object  __stdcall _1eu_multiply(object _id1_961, object _id2_962)
{
    object _retval_inlined_retval_at_25_968 = NOVALUE;
    object _ob_inlined_retval_at_22_967 = NOVALUE;
    object _354 = NOVALUE;
    object _353 = NOVALUE;
    object _352 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_961)) {
        _1 = (object)(DBL_PTR(_id1_961)->dbl);
        DeRefDS(_id1_961);
        _id1_961 = _1;
    }
    if (!IS_ATOM_INT(_id2_962)) {
        _1 = (object)(DBL_PTR(_id2_962)->dbl);
        DeRefDS(_id2_962);
        _id2_962 = _1;
    }

    /** libeu4.e:203		return retval(data[id1] * data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _352 = (object)*(((s1_ptr)_2)->base + _id1_961);
    _2 = (object)SEQ_PTR(_1data_724);
    _353 = (object)*(((s1_ptr)_2)->base + _id2_962);
    if (IS_ATOM_INT(_352) && IS_ATOM_INT(_353)) {
        if (_352 == (short)_352 && _353 <= INT15 && _353 >= -INT15){
            _354 = _352 * _353;
        }
        else{
            _354 = NewDouble(_352 * (eudouble)_353);
        }
    }
    else {
        _354 = binary_op(MULTIPLY, _352, _353);
    }
    _352 = NOVALUE;
    _353 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_967);
    _ob_inlined_retval_at_22_967 = _354;
    _354 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_967);
    _0 = _retval_inlined_retval_at_25_968;
    _retval_inlined_retval_at_25_968 = _1register_data(_ob_inlined_retval_at_22_967);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_967);
    _ob_inlined_retval_at_22_967 = NOVALUE;
    return _retval_inlined_retval_at_25_968;
    ;
}
object eu_multiply() __attribute__ ((alias ("_1eu_multiply@8")));


object  __stdcall _1eu_divide(object _id1_971, object _id2_972)
{
    object _retval_inlined_retval_at_25_978 = NOVALUE;
    object _ob_inlined_retval_at_22_977 = NOVALUE;
    object _357 = NOVALUE;
    object _356 = NOVALUE;
    object _355 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_971)) {
        _1 = (object)(DBL_PTR(_id1_971)->dbl);
        DeRefDS(_id1_971);
        _id1_971 = _1;
    }
    if (!IS_ATOM_INT(_id2_972)) {
        _1 = (object)(DBL_PTR(_id2_972)->dbl);
        DeRefDS(_id2_972);
        _id2_972 = _1;
    }

    /** libeu4.e:207		return retval(data[id1] / data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _355 = (object)*(((s1_ptr)_2)->base + _id1_971);
    _2 = (object)SEQ_PTR(_1data_724);
    _356 = (object)*(((s1_ptr)_2)->base + _id2_972);
    if (IS_ATOM_INT(_355) && IS_ATOM_INT(_356)) {
        _357 = (_355 % _356) ? NewDouble((eudouble)_355 / _356) : (_355 / _356);
    }
    else {
        _357 = binary_op(DIVIDE, _355, _356);
    }
    _355 = NOVALUE;
    _356 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_977);
    _ob_inlined_retval_at_22_977 = _357;
    _357 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_977);
    _0 = _retval_inlined_retval_at_25_978;
    _retval_inlined_retval_at_25_978 = _1register_data(_ob_inlined_retval_at_22_977);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_977);
    _ob_inlined_retval_at_22_977 = NOVALUE;
    return _retval_inlined_retval_at_25_978;
    ;
}
object eu_divide() __attribute__ ((alias ("_1eu_divide@8")));


object  __stdcall _1eu_negate(object _id_981)
{
    object _retval_inlined_retval_at_16_986 = NOVALUE;
    object _ob_inlined_retval_at_13_985 = NOVALUE;
    object _359 = NOVALUE;
    object _358 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_981)) {
        _1 = (object)(DBL_PTR(_id_981)->dbl);
        DeRefDS(_id_981);
        _id_981 = _1;
    }

    /** libeu4.e:211		return retval(-data[id])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _358 = (object)*(((s1_ptr)_2)->base + _id_981);
    if (IS_ATOM_INT(_358)) {
        if ((uintptr_t)_358 == (uintptr_t)HIGH_BITS){
            _359 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _359 = - _358;
        }
    }
    else {
        _359 = unary_op(UMINUS, _358);
    }
    _358 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_985);
    _ob_inlined_retval_at_13_985 = _359;
    _359 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_985);
    _0 = _retval_inlined_retval_at_16_986;
    _retval_inlined_retval_at_16_986 = _1register_data(_ob_inlined_retval_at_13_985);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_985);
    _ob_inlined_retval_at_13_985 = NOVALUE;
    return _retval_inlined_retval_at_16_986;
    ;
}
object eu_negate() __attribute__ ((alias ("_1eu_negate@4")));


object  __stdcall _1eu_not(object _id_989)
{
    object _retval_inlined_retval_at_16_994 = NOVALUE;
    object _ob_inlined_retval_at_13_993 = NOVALUE;
    object _361 = NOVALUE;
    object _360 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_989)) {
        _1 = (object)(DBL_PTR(_id_989)->dbl);
        DeRefDS(_id_989);
        _id_989 = _1;
    }

    /** libeu4.e:218		return retval(not data[id])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _360 = (object)*(((s1_ptr)_2)->base + _id_989);
    if (IS_ATOM_INT(_360)) {
        _361 = (_360 == 0);
    }
    else {
        _361 = unary_op(NOT, _360);
    }
    _360 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_993);
    _ob_inlined_retval_at_13_993 = _361;
    _361 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_993);
    _0 = _retval_inlined_retval_at_16_994;
    _retval_inlined_retval_at_16_994 = _1register_data(_ob_inlined_retval_at_13_993);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_993);
    _ob_inlined_retval_at_13_993 = NOVALUE;
    return _retval_inlined_retval_at_16_994;
    ;
}
object eu_not() __attribute__ ((alias ("_1eu_not@4")));


object  __stdcall _1eu_equals(object _id1_997, object _id2_998)
{
    object _retval_inlined_retval_at_25_1004 = NOVALUE;
    object _ob_inlined_retval_at_22_1003 = NOVALUE;
    object _364 = NOVALUE;
    object _363 = NOVALUE;
    object _362 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_997)) {
        _1 = (object)(DBL_PTR(_id1_997)->dbl);
        DeRefDS(_id1_997);
        _id1_997 = _1;
    }
    if (!IS_ATOM_INT(_id2_998)) {
        _1 = (object)(DBL_PTR(_id2_998)->dbl);
        DeRefDS(_id2_998);
        _id2_998 = _1;
    }

    /** libeu4.e:222		return retval(data[id1] = data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _362 = (object)*(((s1_ptr)_2)->base + _id1_997);
    _2 = (object)SEQ_PTR(_1data_724);
    _363 = (object)*(((s1_ptr)_2)->base + _id2_998);
    if (IS_ATOM_INT(_362) && IS_ATOM_INT(_363)) {
        _364 = (_362 == _363);
    }
    else {
        _364 = binary_op(EQUALS, _362, _363);
    }
    _362 = NOVALUE;
    _363 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1003);
    _ob_inlined_retval_at_22_1003 = _364;
    _364 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1003);
    _0 = _retval_inlined_retval_at_25_1004;
    _retval_inlined_retval_at_25_1004 = _1register_data(_ob_inlined_retval_at_22_1003);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1003);
    _ob_inlined_retval_at_22_1003 = NOVALUE;
    return _retval_inlined_retval_at_25_1004;
    ;
}
object eu_equals() __attribute__ ((alias ("_1eu_equals@8")));


object  __stdcall _1eu_and(object _id1_1007, object _id2_1008)
{
    object _retval_inlined_retval_at_25_1014 = NOVALUE;
    object _ob_inlined_retval_at_22_1013 = NOVALUE;
    object _367 = NOVALUE;
    object _366 = NOVALUE;
    object _365 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1007)) {
        _1 = (object)(DBL_PTR(_id1_1007)->dbl);
        DeRefDS(_id1_1007);
        _id1_1007 = _1;
    }
    if (!IS_ATOM_INT(_id2_1008)) {
        _1 = (object)(DBL_PTR(_id2_1008)->dbl);
        DeRefDS(_id2_1008);
        _id2_1008 = _1;
    }

    /** libeu4.e:226		return retval(data[id1] and data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _365 = (object)*(((s1_ptr)_2)->base + _id1_1007);
    _2 = (object)SEQ_PTR(_1data_724);
    _366 = (object)*(((s1_ptr)_2)->base + _id2_1008);
    if (IS_ATOM_INT(_365) && IS_ATOM_INT(_366)) {
        _367 = (_365 != 0 && _366 != 0);
    }
    else {
        _367 = binary_op(AND, _365, _366);
    }
    _365 = NOVALUE;
    _366 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1013);
    _ob_inlined_retval_at_22_1013 = _367;
    _367 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1013);
    _0 = _retval_inlined_retval_at_25_1014;
    _retval_inlined_retval_at_25_1014 = _1register_data(_ob_inlined_retval_at_22_1013);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1013);
    _ob_inlined_retval_at_22_1013 = NOVALUE;
    return _retval_inlined_retval_at_25_1014;
    ;
}
object eu_and() __attribute__ ((alias ("_1eu_and@8")));


object  __stdcall _1eu_or(object _id1_1017, object _id2_1018)
{
    object _retval_inlined_retval_at_25_1024 = NOVALUE;
    object _ob_inlined_retval_at_22_1023 = NOVALUE;
    object _370 = NOVALUE;
    object _369 = NOVALUE;
    object _368 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1017)) {
        _1 = (object)(DBL_PTR(_id1_1017)->dbl);
        DeRefDS(_id1_1017);
        _id1_1017 = _1;
    }
    if (!IS_ATOM_INT(_id2_1018)) {
        _1 = (object)(DBL_PTR(_id2_1018)->dbl);
        DeRefDS(_id2_1018);
        _id2_1018 = _1;
    }

    /** libeu4.e:230		return retval(data[id1] or data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _368 = (object)*(((s1_ptr)_2)->base + _id1_1017);
    _2 = (object)SEQ_PTR(_1data_724);
    _369 = (object)*(((s1_ptr)_2)->base + _id2_1018);
    if (IS_ATOM_INT(_368) && IS_ATOM_INT(_369)) {
        _370 = (_368 != 0 || _369 != 0);
    }
    else {
        _370 = binary_op(OR, _368, _369);
    }
    _368 = NOVALUE;
    _369 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1023);
    _ob_inlined_retval_at_22_1023 = _370;
    _370 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1023);
    _0 = _retval_inlined_retval_at_25_1024;
    _retval_inlined_retval_at_25_1024 = _1register_data(_ob_inlined_retval_at_22_1023);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1023);
    _ob_inlined_retval_at_22_1023 = NOVALUE;
    return _retval_inlined_retval_at_25_1024;
    ;
}
object eu_or() __attribute__ ((alias ("_1eu_or@8")));


object  __stdcall _1eu_xor(object _id1_1027, object _id2_1028)
{
    object _retval_inlined_retval_at_25_1034 = NOVALUE;
    object _ob_inlined_retval_at_22_1033 = NOVALUE;
    object _373 = NOVALUE;
    object _372 = NOVALUE;
    object _371 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1027)) {
        _1 = (object)(DBL_PTR(_id1_1027)->dbl);
        DeRefDS(_id1_1027);
        _id1_1027 = _1;
    }
    if (!IS_ATOM_INT(_id2_1028)) {
        _1 = (object)(DBL_PTR(_id2_1028)->dbl);
        DeRefDS(_id2_1028);
        _id2_1028 = _1;
    }

    /** libeu4.e:234		return retval(data[id1] xor data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _371 = (object)*(((s1_ptr)_2)->base + _id1_1027);
    _2 = (object)SEQ_PTR(_1data_724);
    _372 = (object)*(((s1_ptr)_2)->base + _id2_1028);
    if (IS_ATOM_INT(_371) && IS_ATOM_INT(_372)) {
        _373 = ((_371 != 0) != (_372 != 0));
    }
    else {
        _373 = binary_op(XOR, _371, _372);
    }
    _371 = NOVALUE;
    _372 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1033);
    _ob_inlined_retval_at_22_1033 = _373;
    _373 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1033);
    _0 = _retval_inlined_retval_at_25_1034;
    _retval_inlined_retval_at_25_1034 = _1register_data(_ob_inlined_retval_at_22_1033);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1033);
    _ob_inlined_retval_at_22_1033 = NOVALUE;
    return _retval_inlined_retval_at_25_1034;
    ;
}
object eu_xor() __attribute__ ((alias ("_1eu_xor@8")));


void  __stdcall _1eu_question_mark(object _id_1037)
{
    object _374 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1037)) {
        _1 = (object)(DBL_PTR(_id_1037)->dbl);
        DeRefDS(_id_1037);
        _id_1037 = _1;
    }

    /** libeu4.e:242		? data[id]*/
    _2 = (object)SEQ_PTR(_1data_724);
    _374 = (object)*(((s1_ptr)_2)->base + _id_1037);
    StdPrint(1, _374, 1);
    _374 = NOVALUE;

    /** libeu4.e:243	end procedure*/
    return;
    ;
}
void eu_question_mark() __attribute__ ((alias ("_1eu_question_mark@4")));


void  __stdcall _1eu_abort(object _ret_1041)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ret_1041)) {
        _1 = (object)(DBL_PTR(_ret_1041)->dbl);
        DeRefDS(_ret_1041);
        _ret_1041 = _1;
    }

    /** libeu4.e:246		abort(ret)*/
    UserCleanup(_ret_1041);

    /** libeu4.e:247	end procedure*/
    return;
    ;
}
void eu_abort() __attribute__ ((alias ("_1eu_abort@4")));


object  __stdcall _1eu_and_bits(object _id1_1044, object _id2_1045)
{
    object _retval_inlined_retval_at_25_1051 = NOVALUE;
    object _ob_inlined_retval_at_22_1050 = NOVALUE;
    object _377 = NOVALUE;
    object _376 = NOVALUE;
    object _375 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1044)) {
        _1 = (object)(DBL_PTR(_id1_1044)->dbl);
        DeRefDS(_id1_1044);
        _id1_1044 = _1;
    }
    if (!IS_ATOM_INT(_id2_1045)) {
        _1 = (object)(DBL_PTR(_id2_1045)->dbl);
        DeRefDS(_id2_1045);
        _id2_1045 = _1;
    }

    /** libeu4.e:250		return retval(and_bits(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _375 = (object)*(((s1_ptr)_2)->base + _id1_1044);
    _2 = (object)SEQ_PTR(_1data_724);
    _376 = (object)*(((s1_ptr)_2)->base + _id2_1045);
    if (IS_ATOM_INT(_375) && IS_ATOM_INT(_376)) {
        {uintptr_t tu;
             tu = (uintptr_t)_375 & (uintptr_t)_376;
             _377 = MAKE_UINT(tu);
        }
    }
    else {
        _377 = binary_op(AND_BITS, _375, _376);
    }
    _375 = NOVALUE;
    _376 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1050);
    _ob_inlined_retval_at_22_1050 = _377;
    _377 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1050);
    _0 = _retval_inlined_retval_at_25_1051;
    _retval_inlined_retval_at_25_1051 = _1register_data(_ob_inlined_retval_at_22_1050);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1050);
    _ob_inlined_retval_at_22_1050 = NOVALUE;
    return _retval_inlined_retval_at_25_1051;
    ;
}
object eu_and_bits() __attribute__ ((alias ("_1eu_and_bits@8")));


object  __stdcall _1eu_append(object _id1_1054, object _id2_1055)
{
    object _retval_inlined_retval_at_25_1061 = NOVALUE;
    object _ob_inlined_retval_at_22_1060 = NOVALUE;
    object _380 = NOVALUE;
    object _379 = NOVALUE;
    object _378 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1054)) {
        _1 = (object)(DBL_PTR(_id1_1054)->dbl);
        DeRefDS(_id1_1054);
        _id1_1054 = _1;
    }
    if (!IS_ATOM_INT(_id2_1055)) {
        _1 = (object)(DBL_PTR(_id2_1055)->dbl);
        DeRefDS(_id2_1055);
        _id2_1055 = _1;
    }

    /** libeu4.e:254		return retval(append(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _378 = (object)*(((s1_ptr)_2)->base + _id1_1054);
    _2 = (object)SEQ_PTR(_1data_724);
    _379 = (object)*(((s1_ptr)_2)->base + _id2_1055);
    Ref(_379);
    Append(&_380, _378, _379);
    _378 = NOVALUE;
    _379 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1060);
    _ob_inlined_retval_at_22_1060 = _380;
    _380 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1060);
    _0 = _retval_inlined_retval_at_25_1061;
    _retval_inlined_retval_at_25_1061 = _1register_data(_ob_inlined_retval_at_22_1060);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1060);
    _ob_inlined_retval_at_22_1060 = NOVALUE;
    return _retval_inlined_retval_at_25_1061;
    ;
}
object eu_append() __attribute__ ((alias ("_1eu_append@8")));


object  __stdcall _1eu_arctan(object _id_1064)
{
    object _retval_inlined_retval_at_16_1069 = NOVALUE;
    object _ob_inlined_retval_at_13_1068 = NOVALUE;
    object _382 = NOVALUE;
    object _381 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1064)) {
        _1 = (object)(DBL_PTR(_id_1064)->dbl);
        DeRefDS(_id_1064);
        _id_1064 = _1;
    }

    /** libeu4.e:258		return retval(arctan(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _381 = (object)*(((s1_ptr)_2)->base + _id_1064);
    if (IS_ATOM_INT(_381))
    _382 = e_arctan(_381);
    else
    _382 = unary_op(ARCTAN, _381);
    _381 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1068);
    _ob_inlined_retval_at_13_1068 = _382;
    _382 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1068);
    _0 = _retval_inlined_retval_at_16_1069;
    _retval_inlined_retval_at_16_1069 = _1register_data(_ob_inlined_retval_at_13_1068);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1068);
    _ob_inlined_retval_at_13_1068 = NOVALUE;
    return _retval_inlined_retval_at_16_1069;
    ;
}
object eu_arctan() __attribute__ ((alias ("_1eu_arctan@4")));


object  __stdcall _1eu_atom(object _id_1072)
{
    object _384 = NOVALUE;
    object _383 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1072)) {
        _1 = (object)(DBL_PTR(_id_1072)->dbl);
        DeRefDS(_id_1072);
        _id_1072 = _1;
    }

    /** libeu4.e:262		return atom(data[id]) -- boolean*/
    _2 = (object)SEQ_PTR(_1data_724);
    _383 = (object)*(((s1_ptr)_2)->base + _id_1072);
    _384 = IS_ATOM(_383);
    _383 = NOVALUE;
    return _384;
    ;
}
object eu_atom() __attribute__ ((alias ("_1eu_atom@4")));


object  __stdcall _1eu_c_func(object _rid_1077, object _id1_1078)
{
    object _retval_inlined_retval_at_20_1083 = NOVALUE;
    object _ob_inlined_retval_at_17_1082 = NOVALUE;
    object _386 = NOVALUE;
    object _385 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1077)) {
        _1 = (object)(DBL_PTR(_rid_1077)->dbl);
        DeRefDS(_rid_1077);
        _rid_1077 = _1;
    }
    if (!IS_ATOM_INT(_id1_1078)) {
        _1 = (object)(DBL_PTR(_id1_1078)->dbl);
        DeRefDS(_id1_1078);
        _id1_1078 = _1;
    }

    /** libeu4.e:266		return retval(c_func(rid, data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _385 = (object)*(((s1_ptr)_2)->base + _id1_1078);
    _386 = call_c(1, _rid_1077, _385);
    _385 = NOVALUE;
    DeRef(_ob_inlined_retval_at_17_1082);
    _ob_inlined_retval_at_17_1082 = _386;
    _386 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_17_1082);
    _0 = _retval_inlined_retval_at_20_1083;
    _retval_inlined_retval_at_20_1083 = _1register_data(_ob_inlined_retval_at_17_1082);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_17_1082);
    _ob_inlined_retval_at_17_1082 = NOVALUE;
    return _retval_inlined_retval_at_20_1083;
    ;
}
object eu_c_func() __attribute__ ((alias ("_1eu_c_func@8")));


void  __stdcall _1eu_c_proc(object _rid_1086, object _id1_1087)
{
    object _387 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1086)) {
        _1 = (object)(DBL_PTR(_rid_1086)->dbl);
        DeRefDS(_rid_1086);
        _rid_1086 = _1;
    }
    if (!IS_ATOM_INT(_id1_1087)) {
        _1 = (object)(DBL_PTR(_id1_1087)->dbl);
        DeRefDS(_id1_1087);
        _id1_1087 = _1;
    }

    /** libeu4.e:270		c_proc(rid, data[id1])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _387 = (object)*(((s1_ptr)_2)->base + _id1_1087);
    call_c(0, _rid_1086, _387);
    _387 = NOVALUE;

    /** libeu4.e:271	end procedure*/
    return;
    ;
}
void eu_c_proc() __attribute__ ((alias ("_1eu_c_proc@8")));


void  __stdcall _1eu_call(object _low_1091, object _high_1092)
{
    object _get_address_1__tmp_at6_1095 = NOVALUE;
    object _get_address_inlined_get_address_at_6_1094 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_1091)) {
        _1 = (object)(DBL_PTR(_low_1091)->dbl);
        DeRefDS(_low_1091);
        _low_1091 = _1;
    }
    if (!IS_ATOM_INT(_high_1092)) {
        _1 = (object)(DBL_PTR(_high_1092)->dbl);
        DeRefDS(_high_1092);
        _high_1092 = _1;
    }

    /** libeu4.e:274		call(get_address(low, high))*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_1095);
    _get_address_1__tmp_at6_1095 = NewDouble(_high_1092 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_6_1094);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_1095)) {
        _get_address_inlined_get_address_at_6_1094 = _get_address_1__tmp_at6_1095 + _low_1091;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_6_1094 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_6_1094 = NewDouble((eudouble)_get_address_inlined_get_address_at_6_1094);
        }
    }
    else {
        _get_address_inlined_get_address_at_6_1094 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_1095)->dbl + (eudouble)_low_1091);
    }
    DeRef(_get_address_1__tmp_at6_1095);
    _get_address_1__tmp_at6_1095 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_1094))
    _0 = (object)_get_address_inlined_get_address_at_6_1094;
    else
    _0 = (object)(uintptr_t)(DBL_PTR(_get_address_inlined_get_address_at_6_1094)->dbl);
    (*(void(*)())_0)();

    /** libeu4.e:275	end procedure*/
    return;
    ;
}
void eu_call() __attribute__ ((alias ("_1eu_call@8")));


void  __stdcall _1eu_clear_screen()
{
    object _0, _1, _2;
    

    /** libeu4.e:280		clear_screen()*/
    ClearScreen();

    /** libeu4.e:281	end procedure*/
    return;
    ;
}
void eu_clear_screen() __attribute__ ((alias ("_1eu_clear_screen@0")));


void  __stdcall _1eu_close(object _fn_id_1100)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1100)) {
        _1 = (object)(DBL_PTR(_fn_id_1100)->dbl);
        DeRefDS(_fn_id_1100);
        _fn_id_1100 = _1;
    }

    /** libeu4.e:284		close(fn_id)*/
    EClose(_fn_id_1100);

    /** libeu4.e:285	end procedure*/
    return;
    ;
}
void eu_close() __attribute__ ((alias ("_1eu_close@4")));


object  __stdcall _1eu_command_line()
{
    object _retval_inlined_retval_at_7_1106 = NOVALUE;
    object _ob_inlined_retval_at_4_1105 = NOVALUE;
    object _388 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:288		return retval(command_line())*/
    _388 = Command_Line();
    DeRef(_ob_inlined_retval_at_4_1105);
    _ob_inlined_retval_at_4_1105 = _388;
    _388 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_1105);
    _0 = _retval_inlined_retval_at_7_1106;
    _retval_inlined_retval_at_7_1106 = _1register_data(_ob_inlined_retval_at_4_1105);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_1105);
    _ob_inlined_retval_at_4_1105 = NOVALUE;
    return _retval_inlined_retval_at_7_1106;
    ;
}
object eu_command_line() __attribute__ ((alias ("_1eu_command_line@0")));


object  __stdcall _1eu_compare(object _id1_1109, object _id2_1110)
{
    object _391 = NOVALUE;
    object _390 = NOVALUE;
    object _389 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1109)) {
        _1 = (object)(DBL_PTR(_id1_1109)->dbl);
        DeRefDS(_id1_1109);
        _id1_1109 = _1;
    }
    if (!IS_ATOM_INT(_id2_1110)) {
        _1 = (object)(DBL_PTR(_id2_1110)->dbl);
        DeRefDS(_id2_1110);
        _id2_1110 = _1;
    }

    /** libeu4.e:292		return compare(data[id1], data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _389 = (object)*(((s1_ptr)_2)->base + _id1_1109);
    _2 = (object)SEQ_PTR(_1data_724);
    _390 = (object)*(((s1_ptr)_2)->base + _id2_1110);
    if (IS_ATOM_INT(_389) && IS_ATOM_INT(_390)){
        _391 = (_389 < _390) ? -1 : (_389 > _390);
    }
    else{
        _391 = compare(_389, _390);
    }
    _389 = NOVALUE;
    _390 = NOVALUE;
    return _391;
    ;
}
object eu_compare() __attribute__ ((alias ("_1eu_compare@8")));


object  __stdcall _1eu_concat(object _id1_1116, object _id2_1117)
{
    object _retval_inlined_retval_at_25_1123 = NOVALUE;
    object _ob_inlined_retval_at_22_1122 = NOVALUE;
    object _394 = NOVALUE;
    object _393 = NOVALUE;
    object _392 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1116)) {
        _1 = (object)(DBL_PTR(_id1_1116)->dbl);
        DeRefDS(_id1_1116);
        _id1_1116 = _1;
    }
    if (!IS_ATOM_INT(_id2_1117)) {
        _1 = (object)(DBL_PTR(_id2_1117)->dbl);
        DeRefDS(_id2_1117);
        _id2_1117 = _1;
    }

    /** libeu4.e:296		return retval(data[id1] & data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _392 = (object)*(((s1_ptr)_2)->base + _id1_1116);
    _2 = (object)SEQ_PTR(_1data_724);
    _393 = (object)*(((s1_ptr)_2)->base + _id2_1117);
    if (IS_SEQUENCE(_392) && IS_ATOM(_393)) {
        Ref(_393);
        Append(&_394, _392, _393);
    }
    else if (IS_ATOM(_392) && IS_SEQUENCE(_393)) {
        Ref(_392);
        Prepend(&_394, _393, _392);
    }
    else {
        Concat((object_ptr)&_394, _392, _393);
        _392 = NOVALUE;
    }
    _392 = NOVALUE;
    _393 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1122);
    _ob_inlined_retval_at_22_1122 = _394;
    _394 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1122);
    _0 = _retval_inlined_retval_at_25_1123;
    _retval_inlined_retval_at_25_1123 = _1register_data(_ob_inlined_retval_at_22_1122);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1122);
    _ob_inlined_retval_at_22_1122 = NOVALUE;
    return _retval_inlined_retval_at_25_1123;
    ;
}
object eu_concat() __attribute__ ((alias ("_1eu_concat@8")));


object  __stdcall _1eu_cos(object _id_1126)
{
    object _retval_inlined_retval_at_16_1131 = NOVALUE;
    object _ob_inlined_retval_at_13_1130 = NOVALUE;
    object _396 = NOVALUE;
    object _395 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1126)) {
        _1 = (object)(DBL_PTR(_id_1126)->dbl);
        DeRefDS(_id_1126);
        _id_1126 = _1;
    }

    /** libeu4.e:300		return retval(cos(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _395 = (object)*(((s1_ptr)_2)->base + _id_1126);
    if (IS_ATOM_INT(_395))
    _396 = e_cos(_395);
    else
    _396 = unary_op(COS, _395);
    _395 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1130);
    _ob_inlined_retval_at_13_1130 = _396;
    _396 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1130);
    _0 = _retval_inlined_retval_at_16_1131;
    _retval_inlined_retval_at_16_1131 = _1register_data(_ob_inlined_retval_at_13_1130);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1130);
    _ob_inlined_retval_at_13_1130 = NOVALUE;
    return _retval_inlined_retval_at_16_1131;
    ;
}
object eu_cos() __attribute__ ((alias ("_1eu_cos@4")));


object  __stdcall _1eu_date()
{
    object _retval_inlined_retval_at_7_1137 = NOVALUE;
    object _ob_inlined_retval_at_4_1136 = NOVALUE;
    object _397 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:304		return retval(date())*/
    _397 = Date();
    DeRefi(_ob_inlined_retval_at_4_1136);
    _ob_inlined_retval_at_4_1136 = _397;
    _397 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_1136);
    _0 = _retval_inlined_retval_at_7_1137;
    _retval_inlined_retval_at_7_1137 = _1register_data(_ob_inlined_retval_at_4_1136);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_4_1136);
    _ob_inlined_retval_at_4_1136 = NOVALUE;
    return _retval_inlined_retval_at_7_1137;
    ;
}
object eu_date() __attribute__ ((alias ("_1eu_date@0")));


object  __stdcall _1eu_equal(object _id1_1140, object _id2_1141)
{
    object _400 = NOVALUE;
    object _399 = NOVALUE;
    object _398 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1140)) {
        _1 = (object)(DBL_PTR(_id1_1140)->dbl);
        DeRefDS(_id1_1140);
        _id1_1140 = _1;
    }
    if (!IS_ATOM_INT(_id2_1141)) {
        _1 = (object)(DBL_PTR(_id2_1141)->dbl);
        DeRefDS(_id2_1141);
        _id2_1141 = _1;
    }

    /** libeu4.e:310		return equal(data[id1], data[id2]) -- boolean, returns 0 or 1*/
    _2 = (object)SEQ_PTR(_1data_724);
    _398 = (object)*(((s1_ptr)_2)->base + _id1_1140);
    _2 = (object)SEQ_PTR(_1data_724);
    _399 = (object)*(((s1_ptr)_2)->base + _id2_1141);
    if (_398 == _399)
    _400 = 1;
    else if (IS_ATOM_INT(_398) && IS_ATOM_INT(_399))
    _400 = 0;
    else
    _400 = (compare(_398, _399) == 0);
    _398 = NOVALUE;
    _399 = NOVALUE;
    return _400;
    ;
}
object eu_equal() __attribute__ ((alias ("_1eu_equal@8")));


object  __stdcall _1eu_find_from(object _id1_1147, object _id2_1148, object _start_1149)
{
    object _403 = NOVALUE;
    object _402 = NOVALUE;
    object _401 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1147)) {
        _1 = (object)(DBL_PTR(_id1_1147)->dbl);
        DeRefDS(_id1_1147);
        _id1_1147 = _1;
    }
    if (!IS_ATOM_INT(_id2_1148)) {
        _1 = (object)(DBL_PTR(_id2_1148)->dbl);
        DeRefDS(_id2_1148);
        _id2_1148 = _1;
    }
    if (!IS_ATOM_INT(_start_1149)) {
        _1 = (object)(DBL_PTR(_start_1149)->dbl);
        DeRefDS(_start_1149);
        _start_1149 = _1;
    }

    /** libeu4.e:314		return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (object)SEQ_PTR(_1data_724);
    _401 = (object)*(((s1_ptr)_2)->base + _id1_1147);
    _2 = (object)SEQ_PTR(_1data_724);
    _402 = (object)*(((s1_ptr)_2)->base + _id2_1148);
    _403 = find_from(_401, _402, _start_1149);
    _401 = NOVALUE;
    _402 = NOVALUE;
    return _403;
    ;
}
object eu_find_from() __attribute__ ((alias ("_1eu_find_from@12")));


object  __stdcall _1eu_find(object _id1_1155, object _id2_1156, object _start_1157)
{
    object _406 = NOVALUE;
    object _405 = NOVALUE;
    object _404 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1155)) {
        _1 = (object)(DBL_PTR(_id1_1155)->dbl);
        DeRefDS(_id1_1155);
        _id1_1155 = _1;
    }
    if (!IS_ATOM_INT(_id2_1156)) {
        _1 = (object)(DBL_PTR(_id2_1156)->dbl);
        DeRefDS(_id2_1156);
        _id2_1156 = _1;
    }
    if (!IS_ATOM_INT(_start_1157)) {
        _1 = (object)(DBL_PTR(_start_1157)->dbl);
        DeRefDS(_start_1157);
        _start_1157 = _1;
    }

    /** libeu4.e:318		return find(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (object)SEQ_PTR(_1data_724);
    _404 = (object)*(((s1_ptr)_2)->base + _id1_1155);
    _2 = (object)SEQ_PTR(_1data_724);
    _405 = (object)*(((s1_ptr)_2)->base + _id2_1156);
    _406 = find_from(_404, _405, _start_1157);
    _404 = NOVALUE;
    _405 = NOVALUE;
    return _406;
    ;
}
object eu_find() __attribute__ ((alias ("_1eu_find@12")));


object  __stdcall _1eu_floor(object _id1_1163)
{
    object _retval_inlined_retval_at_16_1168 = NOVALUE;
    object _ob_inlined_retval_at_13_1167 = NOVALUE;
    object _408 = NOVALUE;
    object _407 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1163)) {
        _1 = (object)(DBL_PTR(_id1_1163)->dbl);
        DeRefDS(_id1_1163);
        _id1_1163 = _1;
    }

    /** libeu4.e:322		return retval(floor(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _407 = (object)*(((s1_ptr)_2)->base + _id1_1163);
    if (IS_ATOM_INT(_407))
    _408 = e_floor(_407);
    else
    _408 = unary_op(FLOOR, _407);
    _407 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1167);
    _ob_inlined_retval_at_13_1167 = _408;
    _408 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1167);
    _0 = _retval_inlined_retval_at_16_1168;
    _retval_inlined_retval_at_16_1168 = _1register_data(_ob_inlined_retval_at_13_1167);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1167);
    _ob_inlined_retval_at_13_1167 = NOVALUE;
    return _retval_inlined_retval_at_16_1168;
    ;
}
object eu_floor() __attribute__ ((alias ("_1eu_floor@4")));


object  __stdcall _1eu_integer_division(object _id1_1171, object _id2_1172)
{
    object _retval_inlined_retval_at_25_1178 = NOVALUE;
    object _ob_inlined_retval_at_22_1177 = NOVALUE;
    object _411 = NOVALUE;
    object _410 = NOVALUE;
    object _409 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1171)) {
        _1 = (object)(DBL_PTR(_id1_1171)->dbl);
        DeRefDS(_id1_1171);
        _id1_1171 = _1;
    }
    if (!IS_ATOM_INT(_id2_1172)) {
        _1 = (object)(DBL_PTR(_id2_1172)->dbl);
        DeRefDS(_id2_1172);
        _id2_1172 = _1;
    }

    /** libeu4.e:325		return retval(floor(data[id1] / data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _409 = (object)*(((s1_ptr)_2)->base + _id1_1171);
    _2 = (object)SEQ_PTR(_1data_724);
    _410 = (object)*(((s1_ptr)_2)->base + _id2_1172);
    if (IS_ATOM_INT(_409) && IS_ATOM_INT(_410)) {
        if (_410 > 0 && _409 >= 0) {
            _411 = _409 / _410;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_409 / (eudouble)_410);
            if (_409 != MININT)
            _411 = (object)temp_dbl;
            else
            _411 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _409, _410);
        _411 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _409 = NOVALUE;
    _410 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1177);
    _ob_inlined_retval_at_22_1177 = _411;
    _411 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1177);
    _0 = _retval_inlined_retval_at_25_1178;
    _retval_inlined_retval_at_25_1178 = _1register_data(_ob_inlined_retval_at_22_1177);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1177);
    _ob_inlined_retval_at_22_1177 = NOVALUE;
    return _retval_inlined_retval_at_25_1178;
    ;
}
object eu_integer_division() __attribute__ ((alias ("_1eu_integer_division@8")));


object  __stdcall _1eu_get_key()
{
    object _412 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:329		return get_key() -- returns an integer*/
    show_console();
    _412 = get_key(0);
    return _412;
    ;
}
object eu_get_key() __attribute__ ((alias ("_1eu_get_key@0")));


object  __stdcall _1eu_getc(object _fn_id_1184)
{
    object _413 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1184)) {
        _1 = (object)(DBL_PTR(_fn_id_1184)->dbl);
        DeRefDS(_fn_id_1184);
        _fn_id_1184 = _1;
    }

    /** libeu4.e:333		return getc(fn_id) -- returns a character or byte*/
    if (_fn_id_1184 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_id_1184, EF_READ);
        last_r_file_no = _fn_id_1184;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _413 = getKBchar();
        }
        else{
            _413 = getc(last_r_file_ptr);
        }
    }
    else{
        _413 = getc(last_r_file_ptr);
    }
    return _413;
    ;
}
object eu_getc() __attribute__ ((alias ("_1eu_getc@4")));


object  __stdcall _1eu_getenv(object _id1_1188)
{
    object _retval_inlined_retval_at_16_1193 = NOVALUE;
    object _ob_inlined_retval_at_13_1192 = NOVALUE;
    object _415 = NOVALUE;
    object _414 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1188)) {
        _1 = (object)(DBL_PTR(_id1_1188)->dbl);
        DeRefDS(_id1_1188);
        _id1_1188 = _1;
    }

    /** libeu4.e:337		return retval(getenv(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _414 = (object)*(((s1_ptr)_2)->base + _id1_1188);
    _415 = EGetEnv(_414);
    _414 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_13_1192);
    _ob_inlined_retval_at_13_1192 = _415;
    _415 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1192);
    _0 = _retval_inlined_retval_at_16_1193;
    _retval_inlined_retval_at_16_1193 = _1register_data(_ob_inlined_retval_at_13_1192);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_13_1192);
    _ob_inlined_retval_at_13_1192 = NOVALUE;
    return _retval_inlined_retval_at_16_1193;
    ;
}
object eu_getenv() __attribute__ ((alias ("_1eu_getenv@4")));


object  __stdcall _1eu_gets(object _fn_id_1196)
{
    object _retval_inlined_retval_at_10_1200 = NOVALUE;
    object _ob_inlined_retval_at_7_1199 = NOVALUE;
    object _416 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1196)) {
        _1 = (object)(DBL_PTR(_fn_id_1196)->dbl);
        DeRefDS(_fn_id_1196);
        _fn_id_1196 = _1;
    }

    /** libeu4.e:341		return retval(gets(fn_id))*/
    _416 = EGets(_fn_id_1196);
    DeRefi(_ob_inlined_retval_at_7_1199);
    _ob_inlined_retval_at_7_1199 = _416;
    _416 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_7_1199);
    _0 = _retval_inlined_retval_at_10_1200;
    _retval_inlined_retval_at_10_1200 = _1register_data(_ob_inlined_retval_at_7_1199);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_7_1199);
    _ob_inlined_retval_at_7_1199 = NOVALUE;
    return _retval_inlined_retval_at_10_1200;
    ;
}
object eu_gets() __attribute__ ((alias ("_1eu_gets@4")));


object  __stdcall _1eu_integer(object _id_1203)
{
    object _418 = NOVALUE;
    object _417 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1203)) {
        _1 = (object)(DBL_PTR(_id_1203)->dbl);
        DeRefDS(_id_1203);
        _id_1203 = _1;
    }

    /** libeu4.e:345		return integer(data[id]) -- boolean*/
    _2 = (object)SEQ_PTR(_1data_724);
    _417 = (object)*(((s1_ptr)_2)->base + _id_1203);
    if (IS_ATOM_INT(_417))
    _418 = 1;
    else if (IS_ATOM_DBL(_417))
    _418 = IS_ATOM_INT(DoubleToInt(_417));
    else
    _418 = 0;
    _417 = NOVALUE;
    return _418;
    ;
}
object eu_integer() __attribute__ ((alias ("_1eu_integer@4")));


object  __stdcall _1eu_length(object _id_1208)
{
    object _420 = NOVALUE;
    object _419 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1208)) {
        _1 = (object)(DBL_PTR(_id_1208)->dbl);
        DeRefDS(_id_1208);
        _id_1208 = _1;
    }

    /** libeu4.e:349		return length(data[id]) -- small integer*/
    _2 = (object)SEQ_PTR(_1data_724);
    _419 = (object)*(((s1_ptr)_2)->base + _id_1208);
    if (IS_SEQUENCE(_419)){
            _420 = SEQ_PTR(_419)->length;
    }
    else {
        _420 = 1;
    }
    _419 = NOVALUE;
    _419 = NOVALUE;
    return _420;
    ;
}
object eu_length() __attribute__ ((alias ("_1eu_length@4")));


object  __stdcall _1eu_log(object _id_1213)
{
    object _retval_inlined_retval_at_16_1218 = NOVALUE;
    object _ob_inlined_retval_at_13_1217 = NOVALUE;
    object _422 = NOVALUE;
    object _421 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1213)) {
        _1 = (object)(DBL_PTR(_id_1213)->dbl);
        DeRefDS(_id_1213);
        _id_1213 = _1;
    }

    /** libeu4.e:353		return retval(log(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _421 = (object)*(((s1_ptr)_2)->base + _id_1213);
    if (IS_ATOM_INT(_421))
    _422 = e_log(_421);
    else
    _422 = unary_op(LOG, _421);
    _421 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1217);
    _ob_inlined_retval_at_13_1217 = _422;
    _422 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1217);
    _0 = _retval_inlined_retval_at_16_1218;
    _retval_inlined_retval_at_16_1218 = _1register_data(_ob_inlined_retval_at_13_1217);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1217);
    _ob_inlined_retval_at_13_1217 = NOVALUE;
    return _retval_inlined_retval_at_16_1218;
    ;
}
object eu_log() __attribute__ ((alias ("_1eu_log@4")));


object  __stdcall _1eu_machine_func(object _machine_id_1221, object _id1_1222)
{
    object _retval_inlined_retval_at_19_1227 = NOVALUE;
    object _ob_inlined_retval_at_16_1226 = NOVALUE;
    object _424 = NOVALUE;
    object _423 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_1221)) {
        _1 = (object)(DBL_PTR(_machine_id_1221)->dbl);
        DeRefDS(_machine_id_1221);
        _machine_id_1221 = _1;
    }
    if (!IS_ATOM_INT(_id1_1222)) {
        _1 = (object)(DBL_PTR(_id1_1222)->dbl);
        DeRefDS(_id1_1222);
        _id1_1222 = _1;
    }

    /** libeu4.e:358		return retval(machine_func(machine_id, data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _423 = (object)*(((s1_ptr)_2)->base + _id1_1222);
    _424 = machine(_machine_id_1221, _423);
    _423 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1226);
    _ob_inlined_retval_at_16_1226 = _424;
    _424 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1226);
    _0 = _retval_inlined_retval_at_19_1227;
    _retval_inlined_retval_at_19_1227 = _1register_data(_ob_inlined_retval_at_16_1226);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1226);
    _ob_inlined_retval_at_16_1226 = NOVALUE;
    return _retval_inlined_retval_at_19_1227;
    ;
}
object eu_machine_func() __attribute__ ((alias ("_1eu_machine_func@8")));


void  __stdcall _1eu_machine_proc(object _machine_id_1230, object _id1_1231)
{
    object _425 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_machine_id_1230)) {
        _1 = (object)(DBL_PTR(_machine_id_1230)->dbl);
        DeRefDS(_machine_id_1230);
        _machine_id_1230 = _1;
    }
    if (!IS_ATOM_INT(_id1_1231)) {
        _1 = (object)(DBL_PTR(_id1_1231)->dbl);
        DeRefDS(_id1_1231);
        _id1_1231 = _1;
    }

    /** libeu4.e:363		machine_proc(machine_id, data[id1])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _425 = (object)*(((s1_ptr)_2)->base + _id1_1231);
    machine(_machine_id_1230, _425);
    _425 = NOVALUE;

    /** libeu4.e:364	end procedure*/
    return;
    ;
}
void eu_machine_proc() __attribute__ ((alias ("_1eu_machine_proc@8")));


object  __stdcall _1eu_match_from(object _id1_1235, object _id2_1236, object _start_1237)
{
    object _428 = NOVALUE;
    object _427 = NOVALUE;
    object _426 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1235)) {
        _1 = (object)(DBL_PTR(_id1_1235)->dbl);
        DeRefDS(_id1_1235);
        _id1_1235 = _1;
    }
    if (!IS_ATOM_INT(_id2_1236)) {
        _1 = (object)(DBL_PTR(_id2_1236)->dbl);
        DeRefDS(_id2_1236);
        _id2_1236 = _1;
    }
    if (!IS_ATOM_INT(_start_1237)) {
        _1 = (object)(DBL_PTR(_start_1237)->dbl);
        DeRefDS(_start_1237);
        _start_1237 = _1;
    }

    /** libeu4.e:367		return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (object)SEQ_PTR(_1data_724);
    _426 = (object)*(((s1_ptr)_2)->base + _id1_1235);
    _2 = (object)SEQ_PTR(_1data_724);
    _427 = (object)*(((s1_ptr)_2)->base + _id2_1236);
    _428 = e_match_from(_426, _427, _start_1237);
    _426 = NOVALUE;
    _427 = NOVALUE;
    return _428;
    ;
}
object eu_match_from() __attribute__ ((alias ("_1eu_match_from@12")));


object  __stdcall _1eu_match(object _id1_1243, object _id2_1244, object _start_1245)
{
    object _431 = NOVALUE;
    object _430 = NOVALUE;
    object _429 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1243)) {
        _1 = (object)(DBL_PTR(_id1_1243)->dbl);
        DeRefDS(_id1_1243);
        _id1_1243 = _1;
    }
    if (!IS_ATOM_INT(_id2_1244)) {
        _1 = (object)(DBL_PTR(_id2_1244)->dbl);
        DeRefDS(_id2_1244);
        _id2_1244 = _1;
    }
    if (!IS_ATOM_INT(_start_1245)) {
        _1 = (object)(DBL_PTR(_start_1245)->dbl);
        DeRefDS(_start_1245);
        _start_1245 = _1;
    }

    /** libeu4.e:371		return match(data[id1], data[id2], start) -- returns a small integer*/
    _2 = (object)SEQ_PTR(_1data_724);
    _429 = (object)*(((s1_ptr)_2)->base + _id1_1243);
    _2 = (object)SEQ_PTR(_1data_724);
    _430 = (object)*(((s1_ptr)_2)->base + _id2_1244);
    _431 = e_match_from(_429, _430, _start_1245);
    _429 = NOVALUE;
    _430 = NOVALUE;
    return _431;
    ;
}
object eu_match() __attribute__ ((alias ("_1eu_match@12")));


object  __stdcall _1eu_not_bits(object _id1_1251)
{
    object _retval_inlined_retval_at_16_1256 = NOVALUE;
    object _ob_inlined_retval_at_13_1255 = NOVALUE;
    object _433 = NOVALUE;
    object _432 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1251)) {
        _1 = (object)(DBL_PTR(_id1_1251)->dbl);
        DeRefDS(_id1_1251);
        _id1_1251 = _1;
    }

    /** libeu4.e:377		return retval(not_bits(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _432 = (object)*(((s1_ptr)_2)->base + _id1_1251);
    if (IS_ATOM_INT(_432))
    _433 = not_bits(_432);
    else
    _433 = unary_op(NOT_BITS, _432);
    _432 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1255);
    _ob_inlined_retval_at_13_1255 = _433;
    _433 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1255);
    _0 = _retval_inlined_retval_at_16_1256;
    _retval_inlined_retval_at_16_1256 = _1register_data(_ob_inlined_retval_at_13_1255);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1255);
    _ob_inlined_retval_at_13_1255 = NOVALUE;
    return _retval_inlined_retval_at_16_1256;
    ;
}
object eu_not_bits() __attribute__ ((alias ("_1eu_not_bits@4")));


object  __stdcall _1eu_object(object _id_1259)
{
    object _435 = NOVALUE;
    object _434 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1259)) {
        _1 = (object)(DBL_PTR(_id_1259)->dbl);
        DeRefDS(_id_1259);
        _id_1259 = _1;
    }

    /** libeu4.e:381		return not find(id, free_list)*/
    _434 = find_from(_id_1259, _1free_list_725, 1);
    _435 = (_434 == 0);
    _434 = NOVALUE;
    return _435;
    ;
}
object eu_object() __attribute__ ((alias ("_1eu_object@4")));


object  __stdcall _1eu_open(object _id1_1264, object _id2_1265)
{
    object _438 = NOVALUE;
    object _437 = NOVALUE;
    object _436 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1264)) {
        _1 = (object)(DBL_PTR(_id1_1264)->dbl);
        DeRefDS(_id1_1264);
        _id1_1264 = _1;
    }
    if (!IS_ATOM_INT(_id2_1265)) {
        _1 = (object)(DBL_PTR(_id2_1265)->dbl);
        DeRefDS(_id2_1265);
        _id2_1265 = _1;
    }

    /** libeu4.e:385		return open(data[id1], data[id2]) -- returns a small integer*/
    _2 = (object)SEQ_PTR(_1data_724);
    _436 = (object)*(((s1_ptr)_2)->base + _id1_1264);
    _2 = (object)SEQ_PTR(_1data_724);
    _437 = (object)*(((s1_ptr)_2)->base + _id2_1265);
    _438 = EOpen(_436, _437, 0);
    _436 = NOVALUE;
    _437 = NOVALUE;
    return _438;
    ;
}
object eu_open() __attribute__ ((alias ("_1eu_open@8")));


object  __stdcall _1eu_open_str(object _low_1271, object _high_1272, object _did_1273)
{
    object _get_address_1__tmp_at8_1276 = NOVALUE;
    object _get_address_inlined_get_address_at_8_1275 = NOVALUE;
    object _441 = NOVALUE;
    object _440 = NOVALUE;
    object _439 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_1271)) {
        _1 = (object)(DBL_PTR(_low_1271)->dbl);
        DeRefDS(_low_1271);
        _low_1271 = _1;
    }
    if (!IS_ATOM_INT(_high_1272)) {
        _1 = (object)(DBL_PTR(_high_1272)->dbl);
        DeRefDS(_high_1272);
        _high_1272 = _1;
    }
    if (!IS_ATOM_INT(_did_1273)) {
        _1 = (object)(DBL_PTR(_did_1273)->dbl);
        DeRefDS(_did_1273);
        _did_1273 = _1;
    }

    /** libeu4.e:388		return open(peek_string(get_address(low, high)), data[did])*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at8_1276);
    _get_address_1__tmp_at8_1276 = NewDouble(_high_1272 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_8_1275);
    if (IS_ATOM_INT(_get_address_1__tmp_at8_1276)) {
        _get_address_inlined_get_address_at_8_1275 = _get_address_1__tmp_at8_1276 + _low_1271;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_8_1275 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_8_1275 = NewDouble((eudouble)_get_address_inlined_get_address_at_8_1275);
        }
    }
    else {
        _get_address_inlined_get_address_at_8_1275 = NewDouble(DBL_PTR(_get_address_1__tmp_at8_1276)->dbl + (eudouble)_low_1271);
    }
    DeRef(_get_address_1__tmp_at8_1276);
    _get_address_1__tmp_at8_1276 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_8_1275)) {
        _439 =  NewString((char *)_get_address_inlined_get_address_at_8_1275);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_8_1275)) {
        _439 = NewString((char *)(uintptr_t)(DBL_PTR(_get_address_inlined_get_address_at_8_1275)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_get_address_inlined_get_address_at_8_1275);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _439 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _2 = (object)SEQ_PTR(_1data_724);
    _440 = (object)*(((s1_ptr)_2)->base + _did_1273);
    _441 = EOpen(_439, _440, 0);
    DeRef(_439);
    _439 = NOVALUE;
    _440 = NOVALUE;
    return _441;
    ;
}
object eu_open_str() __attribute__ ((alias ("_1eu_open_str@12")));


object  __stdcall _1eu_or_bits(object _id1_1282, object _id2_1283)
{
    object _retval_inlined_retval_at_25_1289 = NOVALUE;
    object _ob_inlined_retval_at_22_1288 = NOVALUE;
    object _444 = NOVALUE;
    object _443 = NOVALUE;
    object _442 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1282)) {
        _1 = (object)(DBL_PTR(_id1_1282)->dbl);
        DeRefDS(_id1_1282);
        _id1_1282 = _1;
    }
    if (!IS_ATOM_INT(_id2_1283)) {
        _1 = (object)(DBL_PTR(_id2_1283)->dbl);
        DeRefDS(_id2_1283);
        _id2_1283 = _1;
    }

    /** libeu4.e:392		return retval(or_bits(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _442 = (object)*(((s1_ptr)_2)->base + _id1_1282);
    _2 = (object)SEQ_PTR(_1data_724);
    _443 = (object)*(((s1_ptr)_2)->base + _id2_1283);
    if (IS_ATOM_INT(_442) && IS_ATOM_INT(_443)) {
        {uintptr_t tu;
             tu = (uintptr_t)_442 | (uintptr_t)_443;
             _444 = MAKE_UINT(tu);
        }
    }
    else {
        _444 = binary_op(OR_BITS, _442, _443);
    }
    _442 = NOVALUE;
    _443 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1288);
    _ob_inlined_retval_at_22_1288 = _444;
    _444 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1288);
    _0 = _retval_inlined_retval_at_25_1289;
    _retval_inlined_retval_at_25_1289 = _1register_data(_ob_inlined_retval_at_22_1288);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1288);
    _ob_inlined_retval_at_22_1288 = NOVALUE;
    return _retval_inlined_retval_at_25_1289;
    ;
}
object eu_or_bits() __attribute__ ((alias ("_1eu_or_bits@8")));


object  __stdcall _1eu_peek(object _id1_1292)
{
    object _retval_inlined_retval_at_16_1297 = NOVALUE;
    object _ob_inlined_retval_at_13_1296 = NOVALUE;
    object _446 = NOVALUE;
    object _445 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1292)) {
        _1 = (object)(DBL_PTR(_id1_1292)->dbl);
        DeRefDS(_id1_1292);
        _id1_1292 = _1;
    }

    /** libeu4.e:396		return retval(peek(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _445 = (object)*(((s1_ptr)_2)->base + _id1_1292);
    if (IS_ATOM_INT(_445)) {
        _446 = *(uint8_t *)_445;
    }
    else if (IS_ATOM(_445)) {
        _446 = *(uint8_t *)(uintptr_t)(DBL_PTR(_445)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_445);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _446 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
    }
    _445 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1296);
    _ob_inlined_retval_at_13_1296 = _446;
    _446 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1296);
    _0 = _retval_inlined_retval_at_16_1297;
    _retval_inlined_retval_at_16_1297 = _1register_data(_ob_inlined_retval_at_13_1296);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1296);
    _ob_inlined_retval_at_13_1296 = NOVALUE;
    return _retval_inlined_retval_at_16_1297;
    ;
}
object eu_peek() __attribute__ ((alias ("_1eu_peek@4")));


object  __stdcall _1eu_peek4s(object _id1_1300)
{
    object _retval_inlined_retval_at_16_1305 = NOVALUE;
    object _ob_inlined_retval_at_13_1304 = NOVALUE;
    object _448 = NOVALUE;
    object _447 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1300)) {
        _1 = (object)(DBL_PTR(_id1_1300)->dbl);
        DeRefDS(_id1_1300);
        _id1_1300 = _1;
    }

    /** libeu4.e:400		return retval(peek4s(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _447 = (object)*(((s1_ptr)_2)->base + _id1_1300);
    if (IS_ATOM_INT(_447)) {
        _448 = (object)*(int32_t *)_447;
        if (_448 < MININT || _448 > MAXINT){
            _448 = NewDouble((eudouble)(object)_448);
        }
    }
    else if (IS_ATOM(_447)) {
        _448 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_447)->dbl);
        if (_448 < MININT || _448 > MAXINT){
            _448 = NewDouble((eudouble)(object)_448);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_447);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _448 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)(int32_t)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT){
                _1 = NewDouble((eudouble)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _447 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1304);
    _ob_inlined_retval_at_13_1304 = _448;
    _448 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1304);
    _0 = _retval_inlined_retval_at_16_1305;
    _retval_inlined_retval_at_16_1305 = _1register_data(_ob_inlined_retval_at_13_1304);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1304);
    _ob_inlined_retval_at_13_1304 = NOVALUE;
    return _retval_inlined_retval_at_16_1305;
    ;
}
object eu_peek4s() __attribute__ ((alias ("_1eu_peek4s@4")));


object  __stdcall _1eu_peek4u(object _id1_1308)
{
    object _retval_inlined_retval_at_16_1313 = NOVALUE;
    object _ob_inlined_retval_at_13_1312 = NOVALUE;
    object _450 = NOVALUE;
    object _449 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1308)) {
        _1 = (object)(DBL_PTR(_id1_1308)->dbl);
        DeRefDS(_id1_1308);
        _id1_1308 = _1;
    }

    /** libeu4.e:404		return retval(peek4u(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _449 = (object)*(((s1_ptr)_2)->base + _id1_1308);
    if (IS_ATOM_INT(_449)) {
        _450 = (object)*(uint32_t *)_449;
        if ((uintptr_t)_450 > (uintptr_t)MAXINT){
            _450 = NewDouble((eudouble)(uintptr_t)_450);
        }
    }
    else if (IS_ATOM(_449)) {
        _450 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_449)->dbl);
        if ((uintptr_t)_450 > (uintptr_t)MAXINT){
            _450 = NewDouble((eudouble)(uintptr_t)_450);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_449);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _450 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peek4_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _449 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1312);
    _ob_inlined_retval_at_13_1312 = _450;
    _450 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1312);
    _0 = _retval_inlined_retval_at_16_1313;
    _retval_inlined_retval_at_16_1313 = _1register_data(_ob_inlined_retval_at_13_1312);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1312);
    _ob_inlined_retval_at_13_1312 = NOVALUE;
    return _retval_inlined_retval_at_16_1313;
    ;
}
object eu_peek4u() __attribute__ ((alias ("_1eu_peek4u@4")));


object  __stdcall _1eu_platform()
{
    object _0, _1, _2;
    

    /** libeu4.e:409		return platform() -- returns an integer*/
    return 2;
    ;
}
object eu_platform() __attribute__ ((alias ("_1eu_platform@0")));


void  __stdcall _1eu_poke(object _id1_1318, object _id2_1319)
{
    object _452 = NOVALUE;
    object _451 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1318)) {
        _1 = (object)(DBL_PTR(_id1_1318)->dbl);
        DeRefDS(_id1_1318);
        _id1_1318 = _1;
    }
    if (!IS_ATOM_INT(_id2_1319)) {
        _1 = (object)(DBL_PTR(_id2_1319)->dbl);
        DeRefDS(_id2_1319);
        _id2_1319 = _1;
    }

    /** libeu4.e:413		poke(data[id1], data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _451 = (object)*(((s1_ptr)_2)->base + _id1_1318);
    _2 = (object)SEQ_PTR(_1data_724);
    _452 = (object)*(((s1_ptr)_2)->base + _id2_1319);
    if (IS_ATOM_INT(_451)){
        poke_addr = (uint8_t *)_451;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_451)->dbl);
    }
    if (IS_ATOM_INT(_452)) {
        *poke_addr = (uint8_t)_452;
    }
    else if (IS_ATOM(_452)) {
        *poke_addr = (uint8_t)DBL_PTR(_452)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_452);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _451 = NOVALUE;
    _452 = NOVALUE;

    /** libeu4.e:414	end procedure*/
    return;
    ;
}
void eu_poke() __attribute__ ((alias ("_1eu_poke@8")));


void  __stdcall _1eu_poke4(object _id1_1324, object _id2_1325)
{
    object _454 = NOVALUE;
    object _453 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1324)) {
        _1 = (object)(DBL_PTR(_id1_1324)->dbl);
        DeRefDS(_id1_1324);
        _id1_1324 = _1;
    }
    if (!IS_ATOM_INT(_id2_1325)) {
        _1 = (object)(DBL_PTR(_id2_1325)->dbl);
        DeRefDS(_id2_1325);
        _id2_1325 = _1;
    }

    /** libeu4.e:417		poke4(data[id1], data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _453 = (object)*(((s1_ptr)_2)->base + _id1_1324);
    _2 = (object)SEQ_PTR(_1data_724);
    _454 = (object)*(((s1_ptr)_2)->base + _id2_1325);
    if (IS_ATOM_INT(_453)){
        poke4_addr = (uint32_t *)_453;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_453)->dbl);
    }
    if (IS_ATOM_INT(_454)) {
        *poke4_addr = (uint32_t)_454;
    }
    else if (IS_ATOM(_454)) {
        *poke4_addr = (uint32_t)DBL_PTR(_454)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_454);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _453 = NOVALUE;
    _454 = NOVALUE;

    /** libeu4.e:418	end procedure*/
    return;
    ;
}
void eu_poke4() __attribute__ ((alias ("_1eu_poke4@8")));


void  __stdcall _1eu_position(object _row_1330, object _column_1331)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_row_1330)) {
        _1 = (object)(DBL_PTR(_row_1330)->dbl);
        DeRefDS(_row_1330);
        _row_1330 = _1;
    }
    if (!IS_ATOM_INT(_column_1331)) {
        _1 = (object)(DBL_PTR(_column_1331)->dbl);
        DeRefDS(_column_1331);
        _column_1331 = _1;
    }

    /** libeu4.e:421		position(row, column)*/
    Position(_row_1330, _column_1331);

    /** libeu4.e:422	end procedure*/
    return;
    ;
}
void eu_position() __attribute__ ((alias ("_1eu_position@8")));


object  __stdcall _1eu_power(object _id1_1334, object _id2_1335)
{
    object _retval_inlined_retval_at_25_1341 = NOVALUE;
    object _ob_inlined_retval_at_22_1340 = NOVALUE;
    object _457 = NOVALUE;
    object _456 = NOVALUE;
    object _455 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1334)) {
        _1 = (object)(DBL_PTR(_id1_1334)->dbl);
        DeRefDS(_id1_1334);
        _id1_1334 = _1;
    }
    if (!IS_ATOM_INT(_id2_1335)) {
        _1 = (object)(DBL_PTR(_id2_1335)->dbl);
        DeRefDS(_id2_1335);
        _id2_1335 = _1;
    }

    /** libeu4.e:425		return retval(power(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _455 = (object)*(((s1_ptr)_2)->base + _id1_1334);
    _2 = (object)SEQ_PTR(_1data_724);
    _456 = (object)*(((s1_ptr)_2)->base + _id2_1335);
    if (IS_ATOM_INT(_455) && IS_ATOM_INT(_456)) {
        _457 = power(_455, _456);
    }
    else {
        _457 = binary_op(POWER, _455, _456);
    }
    _455 = NOVALUE;
    _456 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1340);
    _ob_inlined_retval_at_22_1340 = _457;
    _457 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1340);
    _0 = _retval_inlined_retval_at_25_1341;
    _retval_inlined_retval_at_25_1341 = _1register_data(_ob_inlined_retval_at_22_1340);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1340);
    _ob_inlined_retval_at_22_1340 = NOVALUE;
    return _retval_inlined_retval_at_25_1341;
    ;
}
object eu_power() __attribute__ ((alias ("_1eu_power@8")));


object  __stdcall _1eu_prepend(object _id1_1344, object _id2_1345)
{
    object _retval_inlined_retval_at_25_1351 = NOVALUE;
    object _ob_inlined_retval_at_22_1350 = NOVALUE;
    object _460 = NOVALUE;
    object _459 = NOVALUE;
    object _458 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1344)) {
        _1 = (object)(DBL_PTR(_id1_1344)->dbl);
        DeRefDS(_id1_1344);
        _id1_1344 = _1;
    }
    if (!IS_ATOM_INT(_id2_1345)) {
        _1 = (object)(DBL_PTR(_id2_1345)->dbl);
        DeRefDS(_id2_1345);
        _id2_1345 = _1;
    }

    /** libeu4.e:429		return retval(prepend(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _458 = (object)*(((s1_ptr)_2)->base + _id1_1344);
    _2 = (object)SEQ_PTR(_1data_724);
    _459 = (object)*(((s1_ptr)_2)->base + _id2_1345);
    Ref(_459);
    Prepend(&_460, _458, _459);
    _458 = NOVALUE;
    _459 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1350);
    _ob_inlined_retval_at_22_1350 = _460;
    _460 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1350);
    _0 = _retval_inlined_retval_at_25_1351;
    _retval_inlined_retval_at_25_1351 = _1register_data(_ob_inlined_retval_at_22_1350);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1350);
    _ob_inlined_retval_at_22_1350 = NOVALUE;
    return _retval_inlined_retval_at_25_1351;
    ;
}
object eu_prepend() __attribute__ ((alias ("_1eu_prepend@8")));


void  __stdcall _1eu_print(object _fn_id_1354, object _id1_1355)
{
    object _461 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1354)) {
        _1 = (object)(DBL_PTR(_fn_id_1354)->dbl);
        DeRefDS(_fn_id_1354);
        _fn_id_1354 = _1;
    }
    if (!IS_ATOM_INT(_id1_1355)) {
        _1 = (object)(DBL_PTR(_id1_1355)->dbl);
        DeRefDS(_id1_1355);
        _id1_1355 = _1;
    }

    /** libeu4.e:433		print(fn_id, data[id1])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _461 = (object)*(((s1_ptr)_2)->base + _id1_1355);
    StdPrint(_fn_id_1354, _461, 0);
    _461 = NOVALUE;

    /** libeu4.e:434	end procedure*/
    return;
    ;
}
void eu_print() __attribute__ ((alias ("_1eu_print@8")));


void  __stdcall _1eu_printf(object _fn_id_1359, object _id1_1360, object _id2_1361)
{
    object _463 = NOVALUE;
    object _462 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1359)) {
        _1 = (object)(DBL_PTR(_fn_id_1359)->dbl);
        DeRefDS(_fn_id_1359);
        _fn_id_1359 = _1;
    }
    if (!IS_ATOM_INT(_id1_1360)) {
        _1 = (object)(DBL_PTR(_id1_1360)->dbl);
        DeRefDS(_id1_1360);
        _id1_1360 = _1;
    }
    if (!IS_ATOM_INT(_id2_1361)) {
        _1 = (object)(DBL_PTR(_id2_1361)->dbl);
        DeRefDS(_id2_1361);
        _id2_1361 = _1;
    }

    /** libeu4.e:437		printf(fn_id, data[id1], data[id2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _462 = (object)*(((s1_ptr)_2)->base + _id1_1360);
    _2 = (object)SEQ_PTR(_1data_724);
    _463 = (object)*(((s1_ptr)_2)->base + _id2_1361);
    EPrintf(_fn_id_1359, _462, _463);
    _462 = NOVALUE;
    _463 = NOVALUE;

    /** libeu4.e:438	end procedure*/
    return;
    ;
}
void eu_printf() __attribute__ ((alias ("_1eu_printf@12")));


void  __stdcall _1eu_puts(object _fn_id_1366, object _id1_1367)
{
    object _464 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id_1366)) {
        _1 = (object)(DBL_PTR(_fn_id_1366)->dbl);
        DeRefDS(_fn_id_1366);
        _fn_id_1366 = _1;
    }
    if (!IS_ATOM_INT(_id1_1367)) {
        _1 = (object)(DBL_PTR(_id1_1367)->dbl);
        DeRefDS(_id1_1367);
        _id1_1367 = _1;
    }

    /** libeu4.e:441		puts(fn_id, data[id1])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _464 = (object)*(((s1_ptr)_2)->base + _id1_1367);
    EPuts(_fn_id_1366, _464); // DJP 
    _464 = NOVALUE;

    /** libeu4.e:442	end procedure*/
    return;
    ;
}
void eu_puts() __attribute__ ((alias ("_1eu_puts@8")));


object  __stdcall _1eu_rand(object _id1_1371)
{
    object _retval_inlined_retval_at_16_1376 = NOVALUE;
    object _ob_inlined_retval_at_13_1375 = NOVALUE;
    object _466 = NOVALUE;
    object _465 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1371)) {
        _1 = (object)(DBL_PTR(_id1_1371)->dbl);
        DeRefDS(_id1_1371);
        _id1_1371 = _1;
    }

    /** libeu4.e:445		return retval(rand(data[id1]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _465 = (object)*(((s1_ptr)_2)->base + _id1_1371);
    if (IS_ATOM_INT(_465)) {
        _466 = good_rand() % ((uint32_t)_465) + 1;
    }
    else {
        _466 = unary_op(RAND, _465);
    }
    _465 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1375);
    _ob_inlined_retval_at_13_1375 = _466;
    _466 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1375);
    _0 = _retval_inlined_retval_at_16_1376;
    _retval_inlined_retval_at_16_1376 = _1register_data(_ob_inlined_retval_at_13_1375);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1375);
    _ob_inlined_retval_at_13_1375 = NOVALUE;
    return _retval_inlined_retval_at_16_1376;
    ;
}
object eu_rand() __attribute__ ((alias ("_1eu_rand@4")));


object  __stdcall _1eu_remainder(object _id1_1379, object _id2_1380)
{
    object _retval_inlined_retval_at_25_1386 = NOVALUE;
    object _ob_inlined_retval_at_22_1385 = NOVALUE;
    object _469 = NOVALUE;
    object _468 = NOVALUE;
    object _467 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1379)) {
        _1 = (object)(DBL_PTR(_id1_1379)->dbl);
        DeRefDS(_id1_1379);
        _id1_1379 = _1;
    }
    if (!IS_ATOM_INT(_id2_1380)) {
        _1 = (object)(DBL_PTR(_id2_1380)->dbl);
        DeRefDS(_id2_1380);
        _id2_1380 = _1;
    }

    /** libeu4.e:449		return retval(remainder(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _467 = (object)*(((s1_ptr)_2)->base + _id1_1379);
    _2 = (object)SEQ_PTR(_1data_724);
    _468 = (object)*(((s1_ptr)_2)->base + _id2_1380);
    if (IS_ATOM_INT(_467) && IS_ATOM_INT(_468)) {
        _469 = (_467 % _468);
    }
    else {
        _469 = binary_op(REMAINDER, _467, _468);
    }
    _467 = NOVALUE;
    _468 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1385);
    _ob_inlined_retval_at_22_1385 = _469;
    _469 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1385);
    _0 = _retval_inlined_retval_at_25_1386;
    _retval_inlined_retval_at_25_1386 = _1register_data(_ob_inlined_retval_at_22_1385);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1385);
    _ob_inlined_retval_at_22_1385 = NOVALUE;
    return _retval_inlined_retval_at_25_1386;
    ;
}
object eu_remainder() __attribute__ ((alias ("_1eu_remainder@8")));


object  __stdcall _1eu_sequence(object _id_1389)
{
    object _471 = NOVALUE;
    object _470 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1389)) {
        _1 = (object)(DBL_PTR(_id_1389)->dbl);
        DeRefDS(_id_1389);
        _id_1389 = _1;
    }

    /** libeu4.e:455		return sequence(data[id]) -- boolean*/
    _2 = (object)SEQ_PTR(_1data_724);
    _470 = (object)*(((s1_ptr)_2)->base + _id_1389);
    _471 = IS_SEQUENCE(_470);
    _470 = NOVALUE;
    return _471;
    ;
}
object eu_sequence() __attribute__ ((alias ("_1eu_sequence@4")));


object  __stdcall _1eu_sin(object _id_1394)
{
    object _retval_inlined_retval_at_16_1399 = NOVALUE;
    object _ob_inlined_retval_at_13_1398 = NOVALUE;
    object _473 = NOVALUE;
    object _472 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1394)) {
        _1 = (object)(DBL_PTR(_id_1394)->dbl);
        DeRefDS(_id_1394);
        _id_1394 = _1;
    }

    /** libeu4.e:459		return retval(sin(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _472 = (object)*(((s1_ptr)_2)->base + _id_1394);
    if (IS_ATOM_INT(_472))
    _473 = e_sin(_472);
    else
    _473 = unary_op(SIN, _472);
    _472 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1398);
    _ob_inlined_retval_at_13_1398 = _473;
    _473 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1398);
    _0 = _retval_inlined_retval_at_16_1399;
    _retval_inlined_retval_at_16_1399 = _1register_data(_ob_inlined_retval_at_13_1398);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1398);
    _ob_inlined_retval_at_13_1398 = NOVALUE;
    return _retval_inlined_retval_at_16_1399;
    ;
}
object eu_sin() __attribute__ ((alias ("_1eu_sin@4")));


object  __stdcall _1eu_sprintf(object _id1_1402, object _id2_1403)
{
    object _retval_inlined_retval_at_25_1409 = NOVALUE;
    object _ob_inlined_retval_at_22_1408 = NOVALUE;
    object _476 = NOVALUE;
    object _475 = NOVALUE;
    object _474 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1402)) {
        _1 = (object)(DBL_PTR(_id1_1402)->dbl);
        DeRefDS(_id1_1402);
        _id1_1402 = _1;
    }
    if (!IS_ATOM_INT(_id2_1403)) {
        _1 = (object)(DBL_PTR(_id2_1403)->dbl);
        DeRefDS(_id2_1403);
        _id2_1403 = _1;
    }

    /** libeu4.e:463		return retval(sprintf(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _474 = (object)*(((s1_ptr)_2)->base + _id1_1402);
    _2 = (object)SEQ_PTR(_1data_724);
    _475 = (object)*(((s1_ptr)_2)->base + _id2_1403);
    _476 = EPrintf(-9999999, _474, _475);
    _474 = NOVALUE;
    _475 = NOVALUE;
    DeRefi(_ob_inlined_retval_at_22_1408);
    _ob_inlined_retval_at_22_1408 = _476;
    _476 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_22_1408);
    _0 = _retval_inlined_retval_at_25_1409;
    _retval_inlined_retval_at_25_1409 = _1register_data(_ob_inlined_retval_at_22_1408);
    DeRef(_0);
    DeRefi(_ob_inlined_retval_at_22_1408);
    _ob_inlined_retval_at_22_1408 = NOVALUE;
    return _retval_inlined_retval_at_25_1409;
    ;
}
object eu_sprintf() __attribute__ ((alias ("_1eu_sprintf@8")));


object  __stdcall _1eu_sqrt(object _id_1412)
{
    object _retval_inlined_retval_at_16_1417 = NOVALUE;
    object _ob_inlined_retval_at_13_1416 = NOVALUE;
    object _478 = NOVALUE;
    object _477 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1412)) {
        _1 = (object)(DBL_PTR(_id_1412)->dbl);
        DeRefDS(_id_1412);
        _id_1412 = _1;
    }

    /** libeu4.e:467		return retval(sqrt(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _477 = (object)*(((s1_ptr)_2)->base + _id_1412);
    if (IS_ATOM_INT(_477))
    _478 = e_sqrt(_477);
    else
    _478 = unary_op(SQRT, _477);
    _477 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1416);
    _ob_inlined_retval_at_13_1416 = _478;
    _478 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1416);
    _0 = _retval_inlined_retval_at_16_1417;
    _retval_inlined_retval_at_16_1417 = _1register_data(_ob_inlined_retval_at_13_1416);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1416);
    _ob_inlined_retval_at_13_1416 = NOVALUE;
    return _retval_inlined_retval_at_16_1417;
    ;
}
object eu_sqrt() __attribute__ ((alias ("_1eu_sqrt@4")));


object  __stdcall _1eu_subscript(object _id_1420, object _start_1421, object _stop_1422)
{
    object _retval_inlined_retval_at_22_1427 = NOVALUE;
    object _ob_inlined_retval_at_19_1426 = NOVALUE;
    object _480 = NOVALUE;
    object _479 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1420)) {
        _1 = (object)(DBL_PTR(_id_1420)->dbl);
        DeRefDS(_id_1420);
        _id_1420 = _1;
    }
    if (!IS_ATOM_INT(_start_1421)) {
        _1 = (object)(DBL_PTR(_start_1421)->dbl);
        DeRefDS(_start_1421);
        _start_1421 = _1;
    }
    if (!IS_ATOM_INT(_stop_1422)) {
        _1 = (object)(DBL_PTR(_stop_1422)->dbl);
        DeRefDS(_stop_1422);
        _stop_1422 = _1;
    }

    /** libeu4.e:471		return retval(data[id][start..stop])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _479 = (object)*(((s1_ptr)_2)->base + _id_1420);
    rhs_slice_target = (object_ptr)&_480;
    RHS_Slice(_479, _start_1421, _stop_1422);
    _479 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_1426);
    _ob_inlined_retval_at_19_1426 = _480;
    _480 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_1426);
    _0 = _retval_inlined_retval_at_22_1427;
    _retval_inlined_retval_at_22_1427 = _1register_data(_ob_inlined_retval_at_19_1426);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_1426);
    _ob_inlined_retval_at_19_1426 = NOVALUE;
    return _retval_inlined_retval_at_22_1427;
    ;
}
object eu_subscript() __attribute__ ((alias ("_1eu_subscript@12")));


void  __stdcall _1eu_system(object _id1_1430, object _mode_1431)
{
    object _481 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1430)) {
        _1 = (object)(DBL_PTR(_id1_1430)->dbl);
        DeRefDS(_id1_1430);
        _id1_1430 = _1;
    }
    if (!IS_ATOM_INT(_mode_1431)) {
        _1 = (object)(DBL_PTR(_mode_1431)->dbl);
        DeRefDS(_mode_1431);
        _mode_1431 = _1;
    }

    /** libeu4.e:475		system(data[id1], mode)*/
    _2 = (object)SEQ_PTR(_1data_724);
    _481 = (object)*(((s1_ptr)_2)->base + _id1_1430);
    system_call(_481, _mode_1431);
    _481 = NOVALUE;

    /** libeu4.e:476	end procedure*/
    return;
    ;
}
void eu_system() __attribute__ ((alias ("_1eu_system@8")));


object  __stdcall _1eu_system_exec(object _id1_1435, object _mode_1436)
{
    object _483 = NOVALUE;
    object _482 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1435)) {
        _1 = (object)(DBL_PTR(_id1_1435)->dbl);
        DeRefDS(_id1_1435);
        _id1_1435 = _1;
    }
    if (!IS_ATOM_INT(_mode_1436)) {
        _1 = (object)(DBL_PTR(_mode_1436)->dbl);
        DeRefDS(_mode_1436);
        _mode_1436 = _1;
    }

    /** libeu4.e:479		return system_exec(data[id1], mode) -- returns the exit code from the called process.*/
    _2 = (object)SEQ_PTR(_1data_724);
    _482 = (object)*(((s1_ptr)_2)->base + _id1_1435);
    _483 = system_exec_call(_482, _mode_1436);
    _482 = NOVALUE;
    return _483;
    ;
}
object eu_system_exec() __attribute__ ((alias ("_1eu_system_exec@8")));


object  __stdcall _1eu_tan(object _id_1441)
{
    object _retval_inlined_retval_at_16_1446 = NOVALUE;
    object _ob_inlined_retval_at_13_1445 = NOVALUE;
    object _485 = NOVALUE;
    object _484 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_1441)) {
        _1 = (object)(DBL_PTR(_id_1441)->dbl);
        DeRefDS(_id_1441);
        _id_1441 = _1;
    }

    /** libeu4.e:483		return retval(tan(data[id]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _484 = (object)*(((s1_ptr)_2)->base + _id_1441);
    if (IS_ATOM_INT(_484))
    _485 = e_tan(_484);
    else
    _485 = unary_op(TAN, _484);
    _484 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1445);
    _ob_inlined_retval_at_13_1445 = _485;
    _485 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1445);
    _0 = _retval_inlined_retval_at_16_1446;
    _retval_inlined_retval_at_16_1446 = _1register_data(_ob_inlined_retval_at_13_1445);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1445);
    _ob_inlined_retval_at_13_1445 = NOVALUE;
    return _retval_inlined_retval_at_16_1446;
    ;
}
object eu_tan() __attribute__ ((alias ("_1eu_tan@4")));


object  __stdcall _1eu_time()
{
    object _retval_inlined_retval_at_7_1452 = NOVALUE;
    object _ob_inlined_retval_at_4_1451 = NOVALUE;
    object _486 = NOVALUE;
    object _0, _1, _2;
    

    /** libeu4.e:497		return retval(time())*/
    _486 = NewDouble(current_time());
    DeRef(_ob_inlined_retval_at_4_1451);
    _ob_inlined_retval_at_4_1451 = _486;
    _486 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_4_1451);
    _0 = _retval_inlined_retval_at_7_1452;
    _retval_inlined_retval_at_7_1452 = _1register_data(_ob_inlined_retval_at_4_1451);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_4_1451);
    _ob_inlined_retval_at_4_1451 = NOVALUE;
    return _retval_inlined_retval_at_7_1452;
    ;
}
object eu_time() __attribute__ ((alias ("_1eu_time@0")));


object  __stdcall _1eu_xor_bits(object _id1_1455, object _id2_1456)
{
    object _retval_inlined_retval_at_25_1462 = NOVALUE;
    object _ob_inlined_retval_at_22_1461 = NOVALUE;
    object _489 = NOVALUE;
    object _488 = NOVALUE;
    object _487 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1_1455)) {
        _1 = (object)(DBL_PTR(_id1_1455)->dbl);
        DeRefDS(_id1_1455);
        _id1_1455 = _1;
    }
    if (!IS_ATOM_INT(_id2_1456)) {
        _1 = (object)(DBL_PTR(_id2_1456)->dbl);
        DeRefDS(_id2_1456);
        _id2_1456 = _1;
    }

    /** libeu4.e:502		return retval(xor_bits(data[id1], data[id2]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _487 = (object)*(((s1_ptr)_2)->base + _id1_1455);
    _2 = (object)SEQ_PTR(_1data_724);
    _488 = (object)*(((s1_ptr)_2)->base + _id2_1456);
    if (IS_ATOM_INT(_487) && IS_ATOM_INT(_488)) {
        {uintptr_t tu;
             tu = (uintptr_t)_487 ^ (uintptr_t)_488;
             _489 = MAKE_UINT(tu);
        }
    }
    else {
        _489 = binary_op(XOR_BITS, _487, _488);
    }
    _487 = NOVALUE;
    _488 = NOVALUE;
    DeRef(_ob_inlined_retval_at_22_1461);
    _ob_inlined_retval_at_22_1461 = _489;
    _489 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_22_1461);
    _0 = _retval_inlined_retval_at_25_1462;
    _retval_inlined_retval_at_25_1462 = _1register_data(_ob_inlined_retval_at_22_1461);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_22_1461);
    _ob_inlined_retval_at_22_1461 = NOVALUE;
    return _retval_inlined_retval_at_25_1462;
    ;
}
object eu_xor_bits() __attribute__ ((alias ("_1eu_xor_bits@8")));


object  __stdcall _1eu_hash(object _did_1465, object _algorithm_1466)
{
    object _retval_inlined_retval_at_19_1471 = NOVALUE;
    object _ob_inlined_retval_at_16_1470 = NOVALUE;
    object _491 = NOVALUE;
    object _490 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1465)) {
        _1 = (object)(DBL_PTR(_did_1465)->dbl);
        DeRefDS(_did_1465);
        _did_1465 = _1;
    }
    if (!IS_ATOM_INT(_algorithm_1466)) {
        _1 = (object)(DBL_PTR(_algorithm_1466)->dbl);
        DeRefDS(_algorithm_1466);
        _algorithm_1466 = _1;
    }

    /** libeu4.e:511		return retval(hash(data[did], algorithm))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _490 = (object)*(((s1_ptr)_2)->base + _did_1465);
    _491 = calc_hash(_490, _algorithm_1466);
    _490 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1470);
    _ob_inlined_retval_at_16_1470 = _491;
    _491 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1470);
    _0 = _retval_inlined_retval_at_19_1471;
    _retval_inlined_retval_at_19_1471 = _1register_data(_ob_inlined_retval_at_16_1470);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1470);
    _ob_inlined_retval_at_16_1470 = NOVALUE;
    return _retval_inlined_retval_at_19_1471;
    ;
}
object eu_hash() __attribute__ ((alias ("_1eu_hash@8")));


object  __stdcall _1eu_head(object _did_1474, object _len_1475)
{
    object _retval_inlined_retval_at_19_1480 = NOVALUE;
    object _ob_inlined_retval_at_16_1479 = NOVALUE;
    object _493 = NOVALUE;
    object _492 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1474)) {
        _1 = (object)(DBL_PTR(_did_1474)->dbl);
        DeRefDS(_did_1474);
        _did_1474 = _1;
    }
    if (!IS_ATOM_INT(_len_1475)) {
        _1 = (object)(DBL_PTR(_len_1475)->dbl);
        DeRefDS(_len_1475);
        _len_1475 = _1;
    }

    /** libeu4.e:514		return retval(head(data[did], len))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _492 = (object)*(((s1_ptr)_2)->base + _did_1474);
    {
        int len = SEQ_PTR(_492)->length;
        int size = (IS_ATOM_INT(_len_1475)) ? _len_1475 : (object)(DBL_PTR(_len_1475)->dbl);
        if (size <= 0){
            DeRef( _493 );
            _493 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_492);
            DeRef(_493);
            _493 = _492;
        }
        else{
            Head(SEQ_PTR(_492),size+1,&_493);
        }
    }
    _492 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1479);
    _ob_inlined_retval_at_16_1479 = _493;
    _493 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_1479);
    _0 = _retval_inlined_retval_at_19_1480;
    _retval_inlined_retval_at_19_1480 = _1register_data(_ob_inlined_retval_at_16_1479);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1479);
    _ob_inlined_retval_at_16_1479 = NOVALUE;
    return _retval_inlined_retval_at_19_1480;
    ;
}
object eu_head() __attribute__ ((alias ("_1eu_head@8")));


object  __stdcall _1eu_include_paths(object _convert_1483)
{
    object _retval_inlined_retval_at_12_1489 = NOVALUE;
    object _ob_inlined_retval_at_9_1488 = NOVALUE;
    object _496 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_convert_1483)) {
        _1 = (object)(DBL_PTR(_convert_1483)->dbl);
        DeRefDS(_convert_1483);
        _convert_1483 = _1;
    }

    /** libeu4.e:517		return retval(include_paths(convert))*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_495);
    ((intptr_t*)_2)[1] = _495;
    RefDS(_494);
    ((intptr_t*)_2)[2] = _494;
    _496 = MAKE_SEQ(_1);
    DeRef(_ob_inlined_retval_at_9_1488);
    _ob_inlined_retval_at_9_1488 = _496;
    _496 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_9_1488);
    _0 = _retval_inlined_retval_at_12_1489;
    _retval_inlined_retval_at_12_1489 = _1register_data(_ob_inlined_retval_at_9_1488);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_9_1488);
    _ob_inlined_retval_at_9_1488 = NOVALUE;
    return _retval_inlined_retval_at_12_1489;
    ;
}
object eu_include_paths() __attribute__ ((alias ("_1eu_include_paths@4")));


object  __stdcall _1eu_insert(object _did1_1492, object _did2_1493, object _index_1494)
{
    object _retval_inlined_retval_at_28_1500 = NOVALUE;
    object _ob_inlined_retval_at_25_1499 = NOVALUE;
    object _499 = NOVALUE;
    object _498 = NOVALUE;
    object _497 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1492)) {
        _1 = (object)(DBL_PTR(_did1_1492)->dbl);
        DeRefDS(_did1_1492);
        _did1_1492 = _1;
    }
    if (!IS_ATOM_INT(_did2_1493)) {
        _1 = (object)(DBL_PTR(_did2_1493)->dbl);
        DeRefDS(_did2_1493);
        _did2_1493 = _1;
    }
    if (!IS_ATOM_INT(_index_1494)) {
        _1 = (object)(DBL_PTR(_index_1494)->dbl);
        DeRefDS(_index_1494);
        _index_1494 = _1;
    }

    /** libeu4.e:520		return retval(insert(data[did1], data[did2], index))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _497 = (object)*(((s1_ptr)_2)->base + _did1_1492);
    _2 = (object)SEQ_PTR(_1data_724);
    _498 = (object)*(((s1_ptr)_2)->base + _did2_1493);
    {
        s1_ptr assign_space;
        insert_pos = _index_1494;
        if (insert_pos <= 0){
            Prepend(&_499,_497,_498);
        }
        else if (insert_pos > SEQ_PTR(_497)->length) {
            Ref( _498 );
            Append(&_499,_497,_498);
        }
        else {
            Ref( _498 );
            RefDS( _497 );
            _499 = Insert(_497,_498,insert_pos);
        }
    }
    _497 = NOVALUE;
    _498 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_1499);
    _ob_inlined_retval_at_25_1499 = _499;
    _499 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_1499);
    _0 = _retval_inlined_retval_at_28_1500;
    _retval_inlined_retval_at_28_1500 = _1register_data(_ob_inlined_retval_at_25_1499);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_1499);
    _ob_inlined_retval_at_25_1499 = NOVALUE;
    return _retval_inlined_retval_at_28_1500;
    ;
}
object eu_insert() __attribute__ ((alias ("_1eu_insert@12")));


object  __stdcall _1eu_peek2s(object _did_1503)
{
    object _retval_inlined_retval_at_16_1508 = NOVALUE;
    object _ob_inlined_retval_at_13_1507 = NOVALUE;
    object _501 = NOVALUE;
    object _500 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1503)) {
        _1 = (object)(DBL_PTR(_did_1503)->dbl);
        DeRefDS(_did_1503);
        _did_1503 = _1;
    }

    /** libeu4.e:523		return retval(peek2s(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _500 = (object)*(((s1_ptr)_2)->base + _did_1503);
    if (IS_ATOM_INT(_500)) {
        _501 = *(int16_t *)_500;
    }
    else if (IS_ATOM(_500)) {
        _501 = *(int16_t *)(uintptr_t)(DBL_PTR(_500)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_500);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _501 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int16_t)*peek2_addr++;
        }
    }
    _500 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1507);
    _ob_inlined_retval_at_13_1507 = _501;
    _501 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1507);
    _0 = _retval_inlined_retval_at_16_1508;
    _retval_inlined_retval_at_16_1508 = _1register_data(_ob_inlined_retval_at_13_1507);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1507);
    _ob_inlined_retval_at_13_1507 = NOVALUE;
    return _retval_inlined_retval_at_16_1508;
    ;
}
object eu_peek2s() __attribute__ ((alias ("_1eu_peek2s@4")));


object  __stdcall _1eu_peek2u(object _did_1511)
{
    object _retval_inlined_retval_at_16_1516 = NOVALUE;
    object _ob_inlined_retval_at_13_1515 = NOVALUE;
    object _503 = NOVALUE;
    object _502 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1511)) {
        _1 = (object)(DBL_PTR(_did_1511)->dbl);
        DeRefDS(_did_1511);
        _did_1511 = _1;
    }

    /** libeu4.e:526		return retval(peek2u(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _502 = (object)*(((s1_ptr)_2)->base + _did_1511);
    if (IS_ATOM_INT(_502)) {
        _503 = *(uint16_t *)_502;
    }
    else if (IS_ATOM(_502)) {
        _503 = *(uint16_t *)(uintptr_t)(DBL_PTR(_502)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_502);
        peek2_addr = (uint16_t *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _503 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek2_addr++;
        }
    }
    _502 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1515);
    _ob_inlined_retval_at_13_1515 = _503;
    _503 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1515);
    _0 = _retval_inlined_retval_at_16_1516;
    _retval_inlined_retval_at_16_1516 = _1register_data(_ob_inlined_retval_at_13_1515);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1515);
    _ob_inlined_retval_at_13_1515 = NOVALUE;
    return _retval_inlined_retval_at_16_1516;
    ;
}
object eu_peek2u() __attribute__ ((alias ("_1eu_peek2u@4")));


object  __stdcall _1eu_peek8s(object _did_1519)
{
    object _retval_inlined_retval_at_16_1524 = NOVALUE;
    object _ob_inlined_retval_at_13_1523 = NOVALUE;
    object _505 = NOVALUE;
    object _504 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1519)) {
        _1 = (object)(DBL_PTR(_did_1519)->dbl);
        DeRefDS(_did_1519);
        _did_1519 = _1;
    }

    /** libeu4.e:529		return retval(peek8s(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _504 = (object)*(((s1_ptr)_2)->base + _did_1519);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_504)) {
            peek8_longlong = *(int64_t *)_504;
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _505 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _505 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_504)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_504)->dbl);
            if (peek8_longlong < (int64_t)MININT || peek8_longlong > (int64_t) MAXINT){
                _505 = NewDouble((eudouble) peek8_longlong);
            }
            else{
                _505 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_504);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _505 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if (peek8_longlong < (int64_t) MININT || peek8_longlong > (int64_t) MAXINT){
                    _1 = NewDouble((eudouble)peek8_longlong);
                }
                else{
                    _1 = (object)(int64_t) peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _504 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1523);
    _ob_inlined_retval_at_13_1523 = _505;
    _505 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1523);
    _0 = _retval_inlined_retval_at_16_1524;
    _retval_inlined_retval_at_16_1524 = _1register_data(_ob_inlined_retval_at_13_1523);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1523);
    _ob_inlined_retval_at_13_1523 = NOVALUE;
    return _retval_inlined_retval_at_16_1524;
    ;
}
object eu_peek8s() __attribute__ ((alias ("_1eu_peek8s@4")));


object  __stdcall _1eu_peek8u(object _did_1527)
{
    object _retval_inlined_retval_at_16_1532 = NOVALUE;
    object _ob_inlined_retval_at_13_1531 = NOVALUE;
    object _507 = NOVALUE;
    object _506 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1527)) {
        _1 = (object)(DBL_PTR(_did_1527)->dbl);
        DeRefDS(_did_1527);
        _did_1527 = _1;
    }

    /** libeu4.e:532		return retval(peek8u(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _506 = (object)*(((s1_ptr)_2)->base + _did_1527);
    {
        int64_t peek8_longlong;
        if (IS_ATOM_INT(_506)) {
            peek8_longlong = *(int64_t *)_506;
            if (peek8_longlong > (uint64_t)MAXINT){
                _507 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _507 = (object) peek8_longlong;
            }
        }
        else if (IS_ATOM(_506)) {
            peek8_longlong = *(int64_t *)(uintptr_t)(DBL_PTR(_506)->dbl);
            if (peek8_longlong > (uint64_t)MAXINT){
                _507 = NewDouble((eudouble)(uint64_t)peek8_longlong);
            }
            else{
                _507 = (object) peek8_longlong;
            }
        }
        else {
            _1 = (object)SEQ_PTR(_506);
            peek8_addr = (uint64_t *)get_pos_int("peek8s/peek8u", *(((s1_ptr)_1)->base+1));
            _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
            pokeptr_addr = (uintptr_t *)NewS1(_2);
            _507 = MAKE_SEQ(pokeptr_addr);
            pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
            while (--_2 >= 0) {
                pokeptr_addr++;
                peek8_longlong = *peek8_addr++;
                if ((uint64_t)peek8_longlong > (uint64_t)MAXINT){
                    _1 = NewDouble((eudouble) (uint64_t) peek8_longlong);
                }
                else{
                    _1 = (object)peek8_longlong;
                }
                *pokeptr_addr = _1;
            }
        }
    }
    _506 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1531);
    _ob_inlined_retval_at_13_1531 = _507;
    _507 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1531);
    _0 = _retval_inlined_retval_at_16_1532;
    _retval_inlined_retval_at_16_1532 = _1register_data(_ob_inlined_retval_at_13_1531);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1531);
    _ob_inlined_retval_at_13_1531 = NOVALUE;
    return _retval_inlined_retval_at_16_1532;
    ;
}
object eu_peek8u() __attribute__ ((alias ("_1eu_peek8u@4")));


object  __stdcall _1eu_peek_longs(object _did_1535)
{
    object _retval_inlined_retval_at_16_1540 = NOVALUE;
    object _ob_inlined_retval_at_13_1539 = NOVALUE;
    object _509 = NOVALUE;
    object _508 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1535)) {
        _1 = (object)(DBL_PTR(_did_1535)->dbl);
        DeRefDS(_did_1535);
        _did_1535 = _1;
    }

    /** libeu4.e:535		return retval(peek_longs(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _508 = (object)*(((s1_ptr)_2)->base + _did_1535);
    if (IS_ATOM_INT(_508)) {
        _509 = (object)*(int32_t *)_508;
        if (_509 < MININT || _509 > MAXINT){
            _509 = NewDouble((eudouble)(object)_509);
        }
    }
    else if (IS_ATOM(_508)) {
        _509 = (object)*(int32_t *)(uintptr_t)(DBL_PTR(_508)->dbl);
        if (_509 < MININT || _509 > MAXINT){
            _509 = NewDouble((eudouble)(object)_509);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_508);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _509 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)(int32_t)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT){
                _1 = NewDouble((eudouble)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _508 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1539);
    _ob_inlined_retval_at_13_1539 = _509;
    _509 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1539);
    _0 = _retval_inlined_retval_at_16_1540;
    _retval_inlined_retval_at_16_1540 = _1register_data(_ob_inlined_retval_at_13_1539);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1539);
    _ob_inlined_retval_at_13_1539 = NOVALUE;
    return _retval_inlined_retval_at_16_1540;
    ;
}
object eu_peek_longs() __attribute__ ((alias ("_1eu_peek_longs@4")));


object  __stdcall _1eu_peek_longu(object _did_1543)
{
    object _retval_inlined_retval_at_16_1548 = NOVALUE;
    object _ob_inlined_retval_at_13_1547 = NOVALUE;
    object _511 = NOVALUE;
    object _510 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1543)) {
        _1 = (object)(DBL_PTR(_did_1543)->dbl);
        DeRefDS(_did_1543);
        _did_1543 = _1;
    }

    /** libeu4.e:538		return retval(peek_longu(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _510 = (object)*(((s1_ptr)_2)->base + _did_1543);
    if (IS_ATOM_INT(_510)) {
        _511 = (object)*(uint32_t *)_510;
        if ((uintptr_t)_511 > (uintptr_t)MAXINT){
            _511 = NewDouble((eudouble)(uintptr_t)_511);
        }
    }
    else if (IS_ATOM(_510)) {
        _511 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_510)->dbl);
        if ((uintptr_t)_511 > (uintptr_t)MAXINT){
            _511 = NewDouble((eudouble)(uintptr_t)_511);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_510);
        peek4_addr = (uint32_t *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _511 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peek4_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _510 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1547);
    _ob_inlined_retval_at_13_1547 = _511;
    _511 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1547);
    _0 = _retval_inlined_retval_at_16_1548;
    _retval_inlined_retval_at_16_1548 = _1register_data(_ob_inlined_retval_at_13_1547);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1547);
    _ob_inlined_retval_at_13_1547 = NOVALUE;
    return _retval_inlined_retval_at_16_1548;
    ;
}
object eu_peek_longu() __attribute__ ((alias ("_1eu_peek_longu@4")));


object  __stdcall _1eu_peek_pointer(object _did_1551)
{
    object _retval_inlined_retval_at_16_1556 = NOVALUE;
    object _ob_inlined_retval_at_13_1555 = NOVALUE;
    object _513 = NOVALUE;
    object _512 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1551)) {
        _1 = (object)(DBL_PTR(_did_1551)->dbl);
        DeRefDS(_did_1551);
        _did_1551 = _1;
    }

    /** libeu4.e:541		return retval(peek_pointer(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _512 = (object)*(((s1_ptr)_2)->base + _did_1551);
    if (IS_ATOM_INT(_512)) {
        _513 = *(intptr_t *)_512;
        if ((uintptr_t)_513 > (uintptr_t)MAXINT){
            _513 = NewDouble((eudouble)(uintptr_t)_513);
        }
    }
    else if (IS_ATOM(_512)) {
        _513 = *(uintptr_t *)(uintptr_t)(DBL_PTR(_512)->dbl);
        if ((uintptr_t)_513 > (uintptr_t)MAXINT){
            _513 = NewDouble((eudouble)(uintptr_t)_513);
        }
    }
    else {
        _1 = (object)SEQ_PTR(_512);
        peekptr_addr = (uintptr_t *)get_pos_int("peek_pointer/peek_pointer", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _513 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            _1 = (object)*peekptr_addr++;
            if ((uintptr_t)_1 > (uintptr_t)MAXINT){
                _1 = NewDouble((eudouble)(uintptr_t)_1);
            }
            *pokeptr_addr = _1;
        }
    }
    _512 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1555);
    _ob_inlined_retval_at_13_1555 = _513;
    _513 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1555);
    _0 = _retval_inlined_retval_at_16_1556;
    _retval_inlined_retval_at_16_1556 = _1register_data(_ob_inlined_retval_at_13_1555);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1555);
    _ob_inlined_retval_at_13_1555 = NOVALUE;
    return _retval_inlined_retval_at_16_1556;
    ;
}
object eu_peek_pointer() __attribute__ ((alias ("_1eu_peek_pointer@4")));


object  __stdcall _1eu_peek_string(object _did_1559)
{
    object _retval_inlined_retval_at_16_1564 = NOVALUE;
    object _ob_inlined_retval_at_13_1563 = NOVALUE;
    object _515 = NOVALUE;
    object _514 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1559)) {
        _1 = (object)(DBL_PTR(_did_1559)->dbl);
        DeRefDS(_did_1559);
        _did_1559 = _1;
    }

    /** libeu4.e:544		return retval(peek_string(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _514 = (object)*(((s1_ptr)_2)->base + _did_1559);
    if (IS_ATOM_INT(_514)) {
        _515 =  NewString((char *)_514);
    }
    else if (IS_ATOM(_514)) {
        _515 = NewString((char *)(uintptr_t)(DBL_PTR(_514)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_514);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _515 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _514 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1563);
    _ob_inlined_retval_at_13_1563 = _515;
    _515 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1563);
    _0 = _retval_inlined_retval_at_16_1564;
    _retval_inlined_retval_at_16_1564 = _1register_data(_ob_inlined_retval_at_13_1563);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1563);
    _ob_inlined_retval_at_13_1563 = NOVALUE;
    return _retval_inlined_retval_at_16_1564;
    ;
}
object eu_peek_string() __attribute__ ((alias ("_1eu_peek_string@4")));


object  __stdcall _1eu_peeks(object _did_1567)
{
    object _retval_inlined_retval_at_16_1572 = NOVALUE;
    object _ob_inlined_retval_at_13_1571 = NOVALUE;
    object _517 = NOVALUE;
    object _516 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1567)) {
        _1 = (object)(DBL_PTR(_did_1567)->dbl);
        DeRefDS(_did_1567);
        _did_1567 = _1;
    }

    /** libeu4.e:547		return retval(peeks(data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _516 = (object)*(((s1_ptr)_2)->base + _did_1567);
    if (IS_ATOM_INT(_516)) {
        _517 = *(int8_t *)_516;
    }
    else if (IS_ATOM(_516)) {
        _517 = *(int8_t *)(uintptr_t)(DBL_PTR(_516)->dbl);
    }
    else {
        _1 = (object)SEQ_PTR(_516);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _517 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)(int8_t)*peek_addr++;
        }
    }
    _516 = NOVALUE;
    DeRef(_ob_inlined_retval_at_13_1571);
    _ob_inlined_retval_at_13_1571 = _517;
    _517 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_13_1571);
    _0 = _retval_inlined_retval_at_16_1572;
    _retval_inlined_retval_at_16_1572 = _1register_data(_ob_inlined_retval_at_13_1571);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_13_1571);
    _ob_inlined_retval_at_13_1571 = NOVALUE;
    return _retval_inlined_retval_at_16_1572;
    ;
}
object eu_peeks() __attribute__ ((alias ("_1eu_peeks@4")));


void  __stdcall _1eu_poke2(object _did1_1575, object _did2_1576)
{
    object _519 = NOVALUE;
    object _518 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1575)) {
        _1 = (object)(DBL_PTR(_did1_1575)->dbl);
        DeRefDS(_did1_1575);
        _did1_1575 = _1;
    }
    if (!IS_ATOM_INT(_did2_1576)) {
        _1 = (object)(DBL_PTR(_did2_1576)->dbl);
        DeRefDS(_did2_1576);
        _did2_1576 = _1;
    }

    /** libeu4.e:550		poke2(data[did1], data[did2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _518 = (object)*(((s1_ptr)_2)->base + _did1_1575);
    _2 = (object)SEQ_PTR(_1data_724);
    _519 = (object)*(((s1_ptr)_2)->base + _did2_1576);
    if (IS_ATOM_INT(_518)){
        poke2_addr = (uint16_t *)_518;
    }
    else {
        poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_518)->dbl);
    }
    if (IS_ATOM_INT(_519)) {
        *poke2_addr = (uint16_t)_519;
    }
    else if (IS_ATOM(_519)) {
        *poke2_addr = (uint16_t)DBL_PTR(_519)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_519);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke2_addr++ = (uint16_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke2_addr++ = (uint16_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _518 = NOVALUE;
    _519 = NOVALUE;

    /** libeu4.e:551	end procedure*/
    return;
    ;
}
void eu_poke2() __attribute__ ((alias ("_1eu_poke2@8")));


void  __stdcall _1eu_poke8(object _did1_1581, object _did2_1582)
{
    object _521 = NOVALUE;
    object _520 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1581)) {
        _1 = (object)(DBL_PTR(_did1_1581)->dbl);
        DeRefDS(_did1_1581);
        _did1_1581 = _1;
    }
    if (!IS_ATOM_INT(_did2_1582)) {
        _1 = (object)(DBL_PTR(_did2_1582)->dbl);
        DeRefDS(_did2_1582);
        _did2_1582 = _1;
    }

    /** libeu4.e:553		poke8(data[did1], data[did2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _520 = (object)*(((s1_ptr)_2)->base + _did1_1581);
    _2 = (object)SEQ_PTR(_1data_724);
    _521 = (object)*(((s1_ptr)_2)->base + _did2_1582);
    if (IS_ATOM_INT(_520)){
        poke8_addr = (uint64_t *)_520;
    }
    else {
        poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_520)->dbl);
    }
    if (IS_ATOM_INT(_521)) {
        *poke8_addr = (uint64_t)_521;
    }
    else if (IS_ATOM(_521)) {
        *poke8_addr = (uint64_t)DBL_PTR(_521)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_521);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke8_addr++ = (uint64_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke8_addr++ = (uint64_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _520 = NOVALUE;
    _521 = NOVALUE;

    /** libeu4.e:554	end procedure*/
    return;
    ;
}
void eu_poke8() __attribute__ ((alias ("_1eu_poke8@8")));


void  __stdcall _1eu_poke_long(object _did1_1587, object _did2_1588)
{
    object _523 = NOVALUE;
    object _522 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1587)) {
        _1 = (object)(DBL_PTR(_did1_1587)->dbl);
        DeRefDS(_did1_1587);
        _did1_1587 = _1;
    }
    if (!IS_ATOM_INT(_did2_1588)) {
        _1 = (object)(DBL_PTR(_did2_1588)->dbl);
        DeRefDS(_did2_1588);
        _did2_1588 = _1;
    }

    /** libeu4.e:556		poke_long(data[did1], data[did2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _522 = (object)*(((s1_ptr)_2)->base + _did1_1587);
    _2 = (object)SEQ_PTR(_1data_724);
    _523 = (object)*(((s1_ptr)_2)->base + _did2_1588);
    if (IS_ATOM_INT(_522)){
        poke4_addr = (uint32_t *)_522;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_522)->dbl);
    }
    if (IS_ATOM_INT(_523)) {
        *poke4_addr = (uint32_t)_523;
    }
    else if (IS_ATOM(_523)) {
        *poke4_addr = (uint32_t)DBL_PTR(_523)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_523);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke4_addr++ = (int32_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _522 = NOVALUE;
    _523 = NOVALUE;

    /** libeu4.e:557	end procedure*/
    return;
    ;
}
void eu_poke_long() __attribute__ ((alias ("_1eu_poke_long@8")));


void  __stdcall _1eu_poke_pointer(object _did1_1593, object _did2_1594)
{
    object _525 = NOVALUE;
    object _524 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1593)) {
        _1 = (object)(DBL_PTR(_did1_1593)->dbl);
        DeRefDS(_did1_1593);
        _did1_1593 = _1;
    }
    if (!IS_ATOM_INT(_did2_1594)) {
        _1 = (object)(DBL_PTR(_did2_1594)->dbl);
        DeRefDS(_did2_1594);
        _did2_1594 = _1;
    }

    /** libeu4.e:559		poke_pointer(data[did1], data[did2])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _524 = (object)*(((s1_ptr)_2)->base + _did1_1593);
    _2 = (object)SEQ_PTR(_1data_724);
    _525 = (object)*(((s1_ptr)_2)->base + _did2_1594);
    if (IS_ATOM_INT(_524)){
        pokeptr_addr = (uintptr_t *)_524;
    }
    else {
        pokeptr_addr = (uintptr_t *)(uintptr_t)(DBL_PTR(_524)->dbl);
    }
    if (IS_ATOM_INT(_525)) {
        *pokeptr_addr = (uintptr_t)_525;
    }
    else if (IS_ATOM(_525)) {
        *pokeptr_addr = (uintptr_t)DBL_PTR(_525)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_525);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *pokeptr_addr++ = (uintptr_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *pokeptr_addr++ = (uintptr_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    _524 = NOVALUE;
    _525 = NOVALUE;

    /** libeu4.e:560	end procedure*/
    return;
    ;
}
void eu_poke_pointer() __attribute__ ((alias ("_1eu_poke_pointer@8")));


object  __stdcall _1eu_remove(object _did_1599, object _start_1600, object _stop_1601)
{
    object _retval_inlined_retval_at_22_1606 = NOVALUE;
    object _ob_inlined_retval_at_19_1605 = NOVALUE;
    object _527 = NOVALUE;
    object _526 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1599)) {
        _1 = (object)(DBL_PTR(_did_1599)->dbl);
        DeRefDS(_did_1599);
        _did_1599 = _1;
    }
    if (!IS_ATOM_INT(_start_1600)) {
        _1 = (object)(DBL_PTR(_start_1600)->dbl);
        DeRefDS(_start_1600);
        _start_1600 = _1;
    }
    if (!IS_ATOM_INT(_stop_1601)) {
        _1 = (object)(DBL_PTR(_stop_1601)->dbl);
        DeRefDS(_stop_1601);
        _stop_1601 = _1;
    }

    /** libeu4.e:562		return retval(remove(data[did], start, stop))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _526 = (object)*(((s1_ptr)_2)->base + _did_1599);
    {
        s1_ptr assign_space = SEQ_PTR(_526);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_start_1600)) ? _start_1600 : (object)(DBL_PTR(_start_1600)->dbl);
        int stop = (IS_ATOM_INT(_stop_1601)) ? _stop_1601 : (object)(DBL_PTR(_stop_1601)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_526);
            DeRef(_527);
            _527 = _526;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_526), start, &_527 );
            }
            else Tail(SEQ_PTR(_526), stop+1, &_527);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_526), start, &_527);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_527);
            _527 = _1;
        }
    }
    _526 = NOVALUE;
    DeRef(_ob_inlined_retval_at_19_1605);
    _ob_inlined_retval_at_19_1605 = _527;
    _527 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_19_1605);
    _0 = _retval_inlined_retval_at_22_1606;
    _retval_inlined_retval_at_22_1606 = _1register_data(_ob_inlined_retval_at_19_1605);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_19_1605);
    _ob_inlined_retval_at_19_1605 = NOVALUE;
    return _retval_inlined_retval_at_22_1606;
    ;
}
object eu_remove() __attribute__ ((alias ("_1eu_remove@12")));


object  __stdcall _1eu_replace(object _did1_1609, object _did2_1610, object _start_1611, object _stop_1612)
{
    object _retval_inlined_retval_at_31_1618 = NOVALUE;
    object _ob_inlined_retval_at_28_1617 = NOVALUE;
    object _530 = NOVALUE;
    object _529 = NOVALUE;
    object _528 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1609)) {
        _1 = (object)(DBL_PTR(_did1_1609)->dbl);
        DeRefDS(_did1_1609);
        _did1_1609 = _1;
    }
    if (!IS_ATOM_INT(_did2_1610)) {
        _1 = (object)(DBL_PTR(_did2_1610)->dbl);
        DeRefDS(_did2_1610);
        _did2_1610 = _1;
    }
    if (!IS_ATOM_INT(_start_1611)) {
        _1 = (object)(DBL_PTR(_start_1611)->dbl);
        DeRefDS(_start_1611);
        _start_1611 = _1;
    }
    if (!IS_ATOM_INT(_stop_1612)) {
        _1 = (object)(DBL_PTR(_stop_1612)->dbl);
        DeRefDS(_stop_1612);
        _stop_1612 = _1;
    }

    /** libeu4.e:565		return retval(replace(data[did1], data[did2], start, stop))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _528 = (object)*(((s1_ptr)_2)->base + _did1_1609);
    _2 = (object)SEQ_PTR(_1data_724);
    _529 = (object)*(((s1_ptr)_2)->base + _did2_1610);
    {
        intptr_t p1 = _528;
        intptr_t p2 = _529;
        intptr_t p3 = _start_1611;
        intptr_t p4 = _stop_1612;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_530;
        Replace( &replace_params );
    }
    _528 = NOVALUE;
    _529 = NOVALUE;
    DeRef(_ob_inlined_retval_at_28_1617);
    _ob_inlined_retval_at_28_1617 = _530;
    _530 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_28_1617);
    _0 = _retval_inlined_retval_at_31_1618;
    _retval_inlined_retval_at_31_1618 = _1register_data(_ob_inlined_retval_at_28_1617);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_28_1617);
    _ob_inlined_retval_at_28_1617 = NOVALUE;
    return _retval_inlined_retval_at_31_1618;
    ;
}
object eu_replace() __attribute__ ((alias ("_1eu_replace@16")));


object  __stdcall _1eu_splice(object _did1_1621, object _did2_1622, object _index_1623)
{
    object _retval_inlined_retval_at_28_1629 = NOVALUE;
    object _ob_inlined_retval_at_25_1628 = NOVALUE;
    object _533 = NOVALUE;
    object _532 = NOVALUE;
    object _531 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1_1621)) {
        _1 = (object)(DBL_PTR(_did1_1621)->dbl);
        DeRefDS(_did1_1621);
        _did1_1621 = _1;
    }
    if (!IS_ATOM_INT(_did2_1622)) {
        _1 = (object)(DBL_PTR(_did2_1622)->dbl);
        DeRefDS(_did2_1622);
        _did2_1622 = _1;
    }
    if (!IS_ATOM_INT(_index_1623)) {
        _1 = (object)(DBL_PTR(_index_1623)->dbl);
        DeRefDS(_index_1623);
        _index_1623 = _1;
    }

    /** libeu4.e:568		return retval(splice(data[did1], data[did2], index))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _531 = (object)*(((s1_ptr)_2)->base + _did1_1621);
    _2 = (object)SEQ_PTR(_1data_724);
    _532 = (object)*(((s1_ptr)_2)->base + _did2_1622);
    {
        s1_ptr assign_space;
        insert_pos = _index_1623;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_532)) {
                Concat(&_533,_532,_531);
            }
            else{
                Prepend(&_533,_531,_532);
            }
        }
        else if (insert_pos > SEQ_PTR(_531)->length){
            if (IS_SEQUENCE(_532)) {
                Concat(&_533,_531,_532);
            }
            else{
                Append(&_533,_531,_532);
            }
        }
        else if (IS_SEQUENCE(_532)) {
            if( _533 != _531 || SEQ_PTR( _531 )->ref != 1 ){
                DeRef( _533 );
                RefDS( _531 );
            }
            assign_space = Add_internal_space( _531, insert_pos,((s1_ptr)SEQ_PTR(_532))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_532), _531 == _533 );
            _533 = MAKE_SEQ( assign_space );
        }
        else {
            if( _533 == _531 && SEQ_PTR( _531 )->ref == 1 ){
                _533 = Insert( _531, _532, insert_pos);
            }
            else {
                DeRef( _533 );
                RefDS( _531 );
                _533 = Insert( _531, _532, insert_pos);
            }
        }
    }
    _531 = NOVALUE;
    _532 = NOVALUE;
    DeRef(_ob_inlined_retval_at_25_1628);
    _ob_inlined_retval_at_25_1628 = _533;
    _533 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_25_1628);
    _0 = _retval_inlined_retval_at_28_1629;
    _retval_inlined_retval_at_28_1629 = _1register_data(_ob_inlined_retval_at_25_1628);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_25_1628);
    _ob_inlined_retval_at_25_1628 = NOVALUE;
    return _retval_inlined_retval_at_28_1629;
    ;
}
object eu_splice() __attribute__ ((alias ("_1eu_splice@12")));


object  __stdcall _1eu_tail(object _did_1632, object _len_1633)
{
    object _retval_inlined_retval_at_19_1638 = NOVALUE;
    object _ob_inlined_retval_at_16_1637 = NOVALUE;
    object _535 = NOVALUE;
    object _534 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1632)) {
        _1 = (object)(DBL_PTR(_did_1632)->dbl);
        DeRefDS(_did_1632);
        _did_1632 = _1;
    }
    if (!IS_ATOM_INT(_len_1633)) {
        _1 = (object)(DBL_PTR(_len_1633)->dbl);
        DeRefDS(_len_1633);
        _len_1633 = _1;
    }

    /** libeu4.e:571		return retval(tail(data[did], len))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _534 = (object)*(((s1_ptr)_2)->base + _did_1632);
    {
        int len = SEQ_PTR(_534)->length;
        int size = (IS_ATOM_INT(_len_1633)) ? _len_1633 : (object)(DBL_PTR(_len_1633)->dbl);
        if (size <= 0) {
            DeRef(_535);
            _535 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_534);
            DeRef(_535);
            _535 = _534;
        }
        else Tail(SEQ_PTR(_534), len-size+1, &_535);
    }
    _534 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1637);
    _ob_inlined_retval_at_16_1637 = _535;
    _535 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    RefDS(_ob_inlined_retval_at_16_1637);
    _0 = _retval_inlined_retval_at_19_1638;
    _retval_inlined_retval_at_19_1638 = _1register_data(_ob_inlined_retval_at_16_1637);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1637);
    _ob_inlined_retval_at_16_1637 = NOVALUE;
    return _retval_inlined_retval_at_19_1638;
    ;
}
object eu_tail() __attribute__ ((alias ("_1eu_tail@8")));


object  __stdcall _1eu_call_func_std(object _rid_1641, object _did_1642)
{
    object _retval_inlined_retval_at_19_1647 = NOVALUE;
    object _ob_inlined_retval_at_16_1646 = NOVALUE;
    object _537 = NOVALUE;
    object _536 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1641)) {
        _1 = (object)(DBL_PTR(_rid_1641)->dbl);
        DeRefDS(_rid_1641);
        _rid_1641 = _1;
    }
    if (!IS_ATOM_INT(_did_1642)) {
        _1 = (object)(DBL_PTR(_did_1642)->dbl);
        DeRefDS(_did_1642);
        _did_1642 = _1;
    }

    /** libeu4.e:579		return retval(call_func(rid, data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _536 = (object)*(((s1_ptr)_2)->base + _did_1642);
    _1 = (object)SEQ_PTR(_536);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_rid_1641].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_1641].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref( *(( (intptr_t*)_2) + 1) );
            if (_00[_rid_1641].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            break;
        case 2:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            if (_00[_rid_1641].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            break;
        case 3:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            if (_00[_rid_1641].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            break;
        case 4:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            if (_00[_rid_1641].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            break;
        case 5:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            Ref( *(( (intptr_t*)_2) + 5) );
            if (_00[_rid_1641].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            break;
    }
    _537 = _1;
    _536 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1646);
    _ob_inlined_retval_at_16_1646 = _537;
    _537 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1646);
    _0 = _retval_inlined_retval_at_19_1647;
    _retval_inlined_retval_at_19_1647 = _1register_data(_ob_inlined_retval_at_16_1646);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1646);
    _ob_inlined_retval_at_16_1646 = NOVALUE;
    return _retval_inlined_retval_at_19_1647;
    ;
}
object eu_call_func_std() __attribute__ ((alias ("_1eu_call_func_std@8")));


object  __stdcall _1eu_call_func_val(object _rid_1650, object _did_1651)
{
    object _retval_inlined_retval_at_19_1656 = NOVALUE;
    object _ob_inlined_retval_at_16_1655 = NOVALUE;
    object _539 = NOVALUE;
    object _538 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1650)) {
        _1 = (object)(DBL_PTR(_rid_1650)->dbl);
        DeRefDS(_rid_1650);
        _rid_1650 = _1;
    }
    if (!IS_ATOM_INT(_did_1651)) {
        _1 = (object)(DBL_PTR(_did_1651)->dbl);
        DeRefDS(_did_1651);
        _did_1651 = _1;
    }

    /** libeu4.e:583		return retval(call_func(rid, data[did]))*/
    _2 = (object)SEQ_PTR(_1data_724);
    _538 = (object)*(((s1_ptr)_2)->base + _did_1651);
    _1 = (object)SEQ_PTR(_538);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_rid_1650].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_1650].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref( *(( (intptr_t*)_2) + 1) );
            if (_00[_rid_1650].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            break;
        case 2:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            if (_00[_rid_1650].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            break;
        case 3:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            if (_00[_rid_1650].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            break;
        case 4:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            if (_00[_rid_1650].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            break;
        case 5:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            Ref( *(( (intptr_t*)_2) + 5) );
            if (_00[_rid_1650].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            break;
    }
    _539 = _1;
    _538 = NOVALUE;
    DeRef(_ob_inlined_retval_at_16_1655);
    _ob_inlined_retval_at_16_1655 = _539;
    _539 = NOVALUE;

    /** libeu4.e:91		return register_data(ob)*/
    Ref(_ob_inlined_retval_at_16_1655);
    _0 = _retval_inlined_retval_at_19_1656;
    _retval_inlined_retval_at_19_1656 = _1register_data(_ob_inlined_retval_at_16_1655);
    DeRef(_0);
    DeRef(_ob_inlined_retval_at_16_1655);
    _ob_inlined_retval_at_16_1655 = NOVALUE;
    return _retval_inlined_retval_at_19_1656;
    ;
}
object eu_call_func_val() __attribute__ ((alias ("_1eu_call_func_val@8")));


object  __stdcall _1eu_call_func(object _rid_1659, object _did_1660)
{
    object _i_1661 = NOVALUE;
    object _540 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1659)) {
        _1 = (object)(DBL_PTR(_rid_1659)->dbl);
        DeRefDS(_rid_1659);
        _rid_1659 = _1;
    }
    if (!IS_ATOM_INT(_did_1660)) {
        _1 = (object)(DBL_PTR(_did_1660)->dbl);
        DeRefDS(_did_1660);
        _did_1660 = _1;
    }

    /** libeu4.e:595		i = call_func(rid, data[did])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _540 = (object)*(((s1_ptr)_2)->base + _did_1660);
    _1 = (object)SEQ_PTR(_540);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_rid_1659].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_1659].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref( *(( (intptr_t*)_2) + 1) );
            if (_00[_rid_1659].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            break;
        case 2:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            if (_00[_rid_1659].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            break;
        case 3:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            if (_00[_rid_1659].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            break;
        case 4:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            if (_00[_rid_1659].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            break;
        case 5:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            Ref( *(( (intptr_t*)_2) + 5) );
            if (_00[_rid_1659].convention) {
                _1 = (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            else {
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            break;
    }
    _i_1661 = _1;
    _540 = NOVALUE;
    if (!IS_ATOM_INT(_i_1661)) {
        _1 = (object)(DBL_PTR(_i_1661)->dbl);
        DeRefDS(_i_1661);
        _i_1661 = _1;
    }

    /** libeu4.e:596		return i*/
    return _i_1661;
    ;
}
object eu_call_func() __attribute__ ((alias ("_1eu_call_func@8")));


void  __stdcall _1eu_call_proc(object _rid_1666, object _did_1667)
{
    object _542 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_1666)) {
        _1 = (object)(DBL_PTR(_rid_1666)->dbl);
        DeRefDS(_rid_1666);
        _rid_1666 = _1;
    }
    if (!IS_ATOM_INT(_did_1667)) {
        _1 = (object)(DBL_PTR(_did_1667)->dbl);
        DeRefDS(_did_1667);
        _did_1667 = _1;
    }

    /** libeu4.e:600		call_proc(rid, data[did])*/
    _2 = (object)SEQ_PTR(_1data_724);
    _542 = (object)*(((s1_ptr)_2)->base + _did_1667);
    _1 = (object)SEQ_PTR(_542);
    _2 = (object)((s1_ptr)_1)->base;
    _0 = (object)_00[_rid_1666].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            if (_00[_rid_1666].convention) {
                (*(intptr_t (__stdcall *)())_0)(
                                     );
            }
            else {
                (*(intptr_t (*)())_0)(
                                     );
            }
            break;
        case 1:
            Ref( *(( (intptr_t*)_2) + 1) );
            if (_00[_rid_1666].convention) {
                (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            else {
                (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
            }
            break;
        case 2:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            if (_00[_rid_1666].convention) {
                (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            else {
                (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
            }
            break;
        case 3:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            if (_00[_rid_1666].convention) {
                (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            else {
                (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
            }
            break;
        case 4:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            if (_00[_rid_1666].convention) {
                (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            else {
                (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
            }
            break;
        case 5:
            Ref( *(( (intptr_t*)_2) + 1) );
            Ref( *(( (intptr_t*)_2) + 2) );
            Ref( *(( (intptr_t*)_2) + 3) );
            Ref( *(( (intptr_t*)_2) + 4) );
            Ref( *(( (intptr_t*)_2) + 5) );
            if (_00[_rid_1666].convention) {
                (*(intptr_t (__stdcall *)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            else {
                (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
            }
            break;
    }
    _542 = NOVALUE;

    /** libeu4.e:601	end procedure*/
    return;
    ;
}
void eu_call_proc() __attribute__ ((alias ("_1eu_call_proc@8")));


object  __stdcall _1eu_routine_id(object _did_1671)
{
    object _544 = NOVALUE;
    object _543 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_did_1671)) {
        _1 = (object)(DBL_PTR(_did_1671)->dbl);
        DeRefDS(_did_1671);
        _did_1671 = _1;
    }

    /** libeu4.e:604		return routine_id(data[did]) -- this is the only time it uses a string*/
    _2 = (object)SEQ_PTR(_1data_724);
    _543 = (object)*(((s1_ptr)_2)->base + _did_1671);
    _544 = CRoutineId(156, 1, _543);
    _543 = NOVALUE;
    return _544;
    ;
}
object eu_routine_id() __attribute__ ((alias ("_1eu_routine_id@4")));


object  __stdcall _1eu_routine_id_str(object _low_1676, object _high_1677)
{
    object _get_address_1__tmp_at6_1680 = NOVALUE;
    object _get_address_inlined_get_address_at_6_1679 = NOVALUE;
    object _546 = NOVALUE;
    object _545 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_low_1676)) {
        _1 = (object)(DBL_PTR(_low_1676)->dbl);
        DeRefDS(_low_1676);
        _low_1676 = _1;
    }
    if (!IS_ATOM_INT(_high_1677)) {
        _1 = (object)(DBL_PTR(_high_1677)->dbl);
        DeRefDS(_high_1677);
        _high_1677 = _1;
    }

    /** libeu4.e:607		return routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string*/

    /** libeu4.e:56		return high * #00010000 + low*/
    DeRef(_get_address_1__tmp_at6_1680);
    _get_address_1__tmp_at6_1680 = NewDouble(_high_1677 * (eudouble)65536);
    DeRef(_get_address_inlined_get_address_at_6_1679);
    if (IS_ATOM_INT(_get_address_1__tmp_at6_1680)) {
        _get_address_inlined_get_address_at_6_1679 = _get_address_1__tmp_at6_1680 + _low_1676;
        if ((object)((uintptr_t)_get_address_inlined_get_address_at_6_1679 + (uintptr_t)HIGH_BITS) >= 0){
            _get_address_inlined_get_address_at_6_1679 = NewDouble((eudouble)_get_address_inlined_get_address_at_6_1679);
        }
    }
    else {
        _get_address_inlined_get_address_at_6_1679 = NewDouble(DBL_PTR(_get_address_1__tmp_at6_1680)->dbl + (eudouble)_low_1676);
    }
    DeRef(_get_address_1__tmp_at6_1680);
    _get_address_1__tmp_at6_1680 = NOVALUE;
    if (IS_ATOM_INT(_get_address_inlined_get_address_at_6_1679)) {
        _545 =  NewString((char *)_get_address_inlined_get_address_at_6_1679);
    }
    else if (IS_ATOM(_get_address_inlined_get_address_at_6_1679)) {
        _545 = NewString((char *)(uintptr_t)(DBL_PTR(_get_address_inlined_get_address_at_6_1679)->dbl));
    }
    else {
        _1 = (object)SEQ_PTR(_get_address_inlined_get_address_at_6_1679);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _545 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
        }
    }
    _546 = CRoutineId(157, 1, _545);
    DeRef(_545);
    _545 = NOVALUE;
    return _546;
    ;
}
object eu_routine_id_str() __attribute__ ((alias ("_1eu_routine_id_str@8")));



// 0xA01D96C4
