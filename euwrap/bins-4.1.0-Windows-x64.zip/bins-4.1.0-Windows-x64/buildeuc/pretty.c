// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _26pretty_out(object _text_7621)
{
    object _4109 = NOVALUE;
    object _4107 = NOVALUE;
    object _4105 = NOVALUE;
    object _4104 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:19		pretty_line &= text*/
    if (IS_SEQUENCE(_26pretty_line_7618) && IS_ATOM(_text_7621)) {
        Ref(_text_7621);
        Append(&_26pretty_line_7618, _26pretty_line_7618, _text_7621);
    }
    else if (IS_ATOM(_26pretty_line_7618) && IS_SEQUENCE(_text_7621)) {
    }
    else {
        Concat((object_ptr)&_26pretty_line_7618, _26pretty_line_7618, _text_7621);
    }

    /** pretty.e:20		if equal(text, '\n') and pretty_printing then*/
    if (_text_7621 == 10LL)
    _4104 = 1;
    else if (IS_ATOM_INT(_text_7621) && IS_ATOM_INT(10LL))
    _4104 = 0;
    else
    _4104 = (compare(_text_7621, 10LL) == 0);
    if (_4104 == 0) {
        goto L1; // [15] 50
    }
    goto L1; // [22] 50

    /** pretty.e:21			puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_7606, _26pretty_line_7618); // DJP 

    /** pretty.e:22			pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_26pretty_line_7618);
    _26pretty_line_7618 = _5;

    /** pretty.e:23			pretty_line_count += 1*/
    _26pretty_line_count_7611 = _26pretty_line_count_7611 + 1;
L1: 

    /** pretty.e:25		if atom(text) then*/
    _4107 = IS_ATOM(_text_7621);
    if (_4107 == 0)
    {
        _4107 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _4107 = NOVALUE;
    }

    /** pretty.e:26			pretty_chars += 1*/
    _26pretty_chars_7603 = _26pretty_chars_7603 + 1;
    goto L3; // [66] 81
L2: 

    /** pretty.e:28			pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_7621)){
            _4109 = SEQ_PTR(_text_7621)->length;
    }
    else {
        _4109 = 1;
    }
    _26pretty_chars_7603 = _26pretty_chars_7603 + _4109;
    _4109 = NOVALUE;
L3: 

    /** pretty.e:30	end procedure*/
    DeRef(_text_7621);
    return;
    ;
}


void _26cut_line(object _n_7635)
{
    object _4112 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:34		if not pretty_line_breaks then	*/
    if (_26pretty_line_breaks_7614 != 0)
    goto L1; // [7] 21

    /** pretty.e:35			pretty_chars = 0*/
    _26pretty_chars_7603 = 0LL;

    /** pretty.e:36			return*/
    return;
L1: 

    /** pretty.e:38		if pretty_chars + n > pretty_end_col then*/
    _4112 = _26pretty_chars_7603 + _n_7635;
    if ((object)((uintptr_t)_4112 + (uintptr_t)HIGH_BITS) >= 0){
        _4112 = NewDouble((eudouble)_4112);
    }
    if (binary_op_a(LESSEQ, _4112, _26pretty_end_col_7602)){
        DeRef(_4112);
        _4112 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_4112);
    _4112 = NOVALUE;

    /** pretty.e:39			pretty_out('\n')*/
    _26pretty_out(10LL);

    /** pretty.e:40			pretty_chars = 0*/
    _26pretty_chars_7603 = 0LL;
L2: 

    /** pretty.e:42	end procedure*/
    return;
    ;
}


void _26indent()
{
    object _4120 = NOVALUE;
    object _4119 = NOVALUE;
    object _4118 = NOVALUE;
    object _4117 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:46		if pretty_line_breaks = 0 then	*/
    if (_26pretty_line_breaks_7614 != 0LL)
    goto L1; // [5] 22

    /** pretty.e:47			pretty_chars = 0*/
    _26pretty_chars_7603 = 0LL;

    /** pretty.e:48			return*/
    return;
    goto L2; // [19] 85
L1: 

    /** pretty.e:49		elsif pretty_line_breaks = -1 then*/
    if (_26pretty_line_breaks_7614 != -1LL)
    goto L3; // [26] 38

    /** pretty.e:51			cut_line( 0 )*/
    _26cut_line(0LL);
    goto L2; // [35] 85
L3: 

    /** pretty.e:54			if pretty_chars > 0 then*/
    if (_26pretty_chars_7603 <= 0LL)
    goto L4; // [42] 57

    /** pretty.e:55				pretty_out('\n')*/
    _26pretty_out(10LL);

    /** pretty.e:56				pretty_chars = 0*/
    _26pretty_chars_7603 = 0LL;
L4: 

    /** pretty.e:58			pretty_out(repeat(' ', (pretty_start_col-1) + */
    _4117 = _26pretty_start_col_7604 - 1LL;
    if ((object)((uintptr_t)_4117 +(uintptr_t) HIGH_BITS) >= 0){
        _4117 = NewDouble((eudouble)_4117);
    }
    {
        int128_t p128 = (int128_t)_26pretty_level_7605 * (int128_t)_26pretty_indent_7608;
        if( p128 != (int128_t)(_4118 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _4118 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_4117) && IS_ATOM_INT(_4118)) {
        _4119 = _4117 + _4118;
    }
    else {
        if (IS_ATOM_INT(_4117)) {
            _4119 = NewDouble((eudouble)_4117 + DBL_PTR(_4118)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4118)) {
                _4119 = NewDouble(DBL_PTR(_4117)->dbl + (eudouble)_4118);
            }
            else
            _4119 = NewDouble(DBL_PTR(_4117)->dbl + DBL_PTR(_4118)->dbl);
        }
    }
    DeRef(_4117);
    _4117 = NOVALUE;
    DeRef(_4118);
    _4118 = NOVALUE;
    _4120 = Repeat(32LL, _4119);
    DeRef(_4119);
    _4119 = NOVALUE;
    _26pretty_out(_4120);
    _4120 = NOVALUE;
L2: 

    /** pretty.e:62	end procedure*/
    return;
    ;
}


object _26esc_char(object _a_7656)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_7656)) {
        _1 = (object)(DBL_PTR(_a_7656)->dbl);
        DeRefDS(_a_7656);
        _a_7656 = _1;
    }

    /** pretty.e:66		switch a do*/
    _0 = _a_7656;
    switch ( _0 ){ 

        /** pretty.e:67			case'\t' then*/
        case 9:

        /** pretty.e:68				return `\t`*/
        RefDS(_4123);
        return _4123;
        goto L1; // [20] 81

        /** pretty.e:70			case'\n' then*/
        case 10:

        /** pretty.e:71				return `\n`*/
        RefDS(_4124);
        return _4124;
        goto L1; // [32] 81

        /** pretty.e:73			case'\r' then*/
        case 13:

        /** pretty.e:74				return `\r`*/
        RefDS(_4125);
        return _4125;
        goto L1; // [44] 81

        /** pretty.e:76			case'\\' then*/
        case 92:

        /** pretty.e:77				return `\\`*/
        RefDS(_965);
        return _965;
        goto L1; // [56] 81

        /** pretty.e:79			case'"' then*/
        case 34:

        /** pretty.e:80				return `\"`*/
        RefDS(_4126);
        return _4126;
        goto L1; // [68] 81

        /** pretty.e:82			case else*/
        default:

        /** pretty.e:83				return a*/
        return _a_7656;
    ;}L1: 
    ;
}


void _26rPrint(object _a_7671)
{
    object _sbuff_7672 = NOVALUE;
    object _multi_line_7673 = NOVALUE;
    object _all_ascii_7674 = NOVALUE;
    object _4183 = NOVALUE;
    object _4182 = NOVALUE;
    object _4181 = NOVALUE;
    object _4180 = NOVALUE;
    object _4176 = NOVALUE;
    object _4175 = NOVALUE;
    object _4174 = NOVALUE;
    object _4173 = NOVALUE;
    object _4171 = NOVALUE;
    object _4170 = NOVALUE;
    object _4168 = NOVALUE;
    object _4167 = NOVALUE;
    object _4165 = NOVALUE;
    object _4164 = NOVALUE;
    object _4163 = NOVALUE;
    object _4162 = NOVALUE;
    object _4161 = NOVALUE;
    object _4160 = NOVALUE;
    object _4159 = NOVALUE;
    object _4158 = NOVALUE;
    object _4157 = NOVALUE;
    object _4156 = NOVALUE;
    object _4155 = NOVALUE;
    object _4154 = NOVALUE;
    object _4153 = NOVALUE;
    object _4152 = NOVALUE;
    object _4151 = NOVALUE;
    object _4150 = NOVALUE;
    object _4149 = NOVALUE;
    object _4145 = NOVALUE;
    object _4144 = NOVALUE;
    object _4143 = NOVALUE;
    object _4142 = NOVALUE;
    object _4141 = NOVALUE;
    object _4140 = NOVALUE;
    object _4138 = NOVALUE;
    object _4137 = NOVALUE;
    object _4133 = NOVALUE;
    object _4132 = NOVALUE;
    object _4131 = NOVALUE;
    object _4128 = NOVALUE;
    object _4127 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:92		if atom(a) then*/
    _4127 = IS_ATOM(_a_7671);
    if (_4127 == 0)
    {
        _4127 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _4127 = NOVALUE;
    }

    /** pretty.e:93			if integer(a) then*/
    if (IS_ATOM_INT(_a_7671))
    _4128 = 1;
    else if (IS_ATOM_DBL(_a_7671))
    _4128 = IS_ATOM_INT(DoubleToInt(_a_7671));
    else
    _4128 = 0;
    if (_4128 == 0)
    {
        _4128 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _4128 = NOVALUE;
    }

    /** pretty.e:94				sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_7672);
    _sbuff_7672 = EPrintf(-9999999, _26pretty_int_format_7617, _a_7671);

    /** pretty.e:95				if pretty_ascii then */
    if (_26pretty_ascii_7607 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** pretty.e:96					if pretty_ascii >= 3 then */
    if (_26pretty_ascii_7607 < 3LL)
    goto L4; // [36] 103

    /** pretty.e:98						if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_7671)) {
        _4131 = (_a_7671 >= _26pretty_ascii_min_7609);
    }
    else {
        _4131 = binary_op(GREATEREQ, _a_7671, _26pretty_ascii_min_7609);
    }
    if (IS_ATOM_INT(_4131)) {
        if (_4131 == 0) {
            _4132 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_4131)->dbl == 0.0) {
            _4132 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_7671)) {
        _4133 = (_a_7671 <= _26pretty_ascii_max_7610);
    }
    else {
        _4133 = binary_op(LESSEQ, _a_7671, _26pretty_ascii_max_7610);
    }
    DeRef(_4132);
    if (IS_ATOM_INT(_4133))
    _4132 = (_4133 != 0);
    else
    _4132 = DBL_PTR(_4133)->dbl != 0.0;
L5: 
    if (_4132 == 0)
    {
        _4132 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _4132 = NOVALUE;
    }

    /** pretty.e:99							sbuff = '\'' & a & '\''  -- display char only*/
    {
        object concat_list[3];

        concat_list[0] = 39LL;
        concat_list[1] = _a_7671;
        concat_list[2] = 39LL;
        Concat_N((object_ptr)&_sbuff_7672, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** pretty.e:101						elsif find(a, "\t\n\r\\") then*/
    _4137 = find_from(_a_7671, _4136, 1LL);
    if (_4137 == 0)
    {
        _4137 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _4137 = NOVALUE;
    }

    /** pretty.e:102							sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_7671);
    _4138 = _26esc_char(_a_7671);
    {
        object concat_list[3];

        concat_list[0] = 39LL;
        concat_list[1] = _4138;
        concat_list[2] = 39LL;
        Concat_N((object_ptr)&_sbuff_7672, concat_list, 3);
    }
    DeRef(_4138);
    _4138 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** pretty.e:107						if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_7671)) {
        _4140 = (_a_7671 >= _26pretty_ascii_min_7609);
    }
    else {
        _4140 = binary_op(GREATEREQ, _a_7671, _26pretty_ascii_min_7609);
    }
    if (IS_ATOM_INT(_4140)) {
        if (_4140 == 0) {
            DeRef(_4141);
            _4141 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_4140)->dbl == 0.0) {
            DeRef(_4141);
            _4141 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_7671)) {
        _4142 = (_a_7671 <= _26pretty_ascii_max_7610);
    }
    else {
        _4142 = binary_op(LESSEQ, _a_7671, _26pretty_ascii_max_7610);
    }
    DeRef(_4141);
    if (IS_ATOM_INT(_4142))
    _4141 = (_4142 != 0);
    else
    _4141 = DBL_PTR(_4142)->dbl != 0.0;
L7: 
    if (_4141 == 0) {
        goto L3; // [125] 166
    }
    _4144 = (_26pretty_ascii_7607 < 2LL);
    if (_4144 == 0)
    {
        DeRef(_4144);
        _4144 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_4144);
        _4144 = NOVALUE;
    }

    /** pretty.e:108							sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        object concat_list[3];

        concat_list[0] = 39LL;
        concat_list[1] = _a_7671;
        concat_list[2] = 39LL;
        Concat_N((object_ptr)&_4145, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_7672, _sbuff_7672, _4145);
    DeRefDS(_4145);
    _4145 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** pretty.e:113				sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_7672);
    _sbuff_7672 = EPrintf(-9999999, _26pretty_fp_format_7616, _a_7671);
L3: 

    /** pretty.e:115			pretty_out(sbuff)*/
    RefDS(_sbuff_7672);
    _26pretty_out(_sbuff_7672);
    goto L8; // [173] 535
L1: 

    /** pretty.e:119			cut_line(1)*/
    _26cut_line(1LL);

    /** pretty.e:120			multi_line = 0*/
    _multi_line_7673 = 0LL;

    /** pretty.e:121			all_ascii = pretty_ascii > 1*/
    _all_ascii_7674 = (_26pretty_ascii_7607 > 1LL);

    /** pretty.e:122			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7671)){
            _4149 = SEQ_PTR(_a_7671)->length;
    }
    else {
        _4149 = 1;
    }
    {
        object _i_7708;
        _i_7708 = 1LL;
L9: 
        if (_i_7708 > _4149){
            goto LA; // [199] 345
        }

        /** pretty.e:123				if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (object)SEQ_PTR(_a_7671);
        _4150 = (object)*(((s1_ptr)_2)->base + _i_7708);
        _4151 = IS_SEQUENCE(_4150);
        _4150 = NOVALUE;
        if (_4151 == 0) {
            goto LB; // [215] 249
        }
        _2 = (object)SEQ_PTR(_a_7671);
        _4153 = (object)*(((s1_ptr)_2)->base + _i_7708);
        if (IS_SEQUENCE(_4153)){
                _4154 = SEQ_PTR(_4153)->length;
        }
        else {
            _4154 = 1;
        }
        _4153 = NOVALUE;
        _4155 = (_4154 > 0LL);
        _4154 = NOVALUE;
        if (_4155 == 0)
        {
            DeRef(_4155);
            _4155 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_4155);
            _4155 = NOVALUE;
        }

        /** pretty.e:124					multi_line = 1*/
        _multi_line_7673 = 1LL;

        /** pretty.e:125					all_ascii = 0*/
        _all_ascii_7674 = 0LL;

        /** pretty.e:126					exit*/
        goto LA; // [246] 345
LB: 

        /** pretty.e:128				if not integer(a[i]) or*/
        _2 = (object)SEQ_PTR(_a_7671);
        _4156 = (object)*(((s1_ptr)_2)->base + _i_7708);
        if (IS_ATOM_INT(_4156))
        _4157 = 1;
        else if (IS_ATOM_DBL(_4156))
        _4157 = IS_ATOM_INT(DoubleToInt(_4156));
        else
        _4157 = 0;
        _4156 = NOVALUE;
        _4158 = (_4157 == 0);
        _4157 = NOVALUE;
        if (_4158 != 0) {
            _4159 = 1;
            goto LC; // [261] 313
        }
        _2 = (object)SEQ_PTR(_a_7671);
        _4160 = (object)*(((s1_ptr)_2)->base + _i_7708);
        if (IS_ATOM_INT(_4160)) {
            _4161 = (_4160 < _26pretty_ascii_min_7609);
        }
        else {
            _4161 = binary_op(LESS, _4160, _26pretty_ascii_min_7609);
        }
        _4160 = NOVALUE;
        if (IS_ATOM_INT(_4161)) {
            if (_4161 == 0) {
                DeRef(_4162);
                _4162 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_4161)->dbl == 0.0) {
                DeRef(_4162);
                _4162 = 0;
                goto LD; // [275] 309
            }
        }
        _4163 = (_26pretty_ascii_7607 < 2LL);
        if (_4163 != 0) {
            _4164 = 1;
            goto LE; // [285] 305
        }
        _2 = (object)SEQ_PTR(_a_7671);
        _4165 = (object)*(((s1_ptr)_2)->base + _i_7708);
        _4167 = find_from(_4165, _4166, 1LL);
        _4165 = NOVALUE;
        _4168 = (_4167 == 0);
        _4167 = NOVALUE;
        _4164 = (_4168 != 0);
LE: 
        DeRef(_4162);
        _4162 = (_4164 != 0);
LD: 
        _4159 = (_4162 != 0);
LC: 
        if (_4159 != 0) {
            goto LF; // [313] 332
        }
        _2 = (object)SEQ_PTR(_a_7671);
        _4170 = (object)*(((s1_ptr)_2)->base + _i_7708);
        if (IS_ATOM_INT(_4170)) {
            _4171 = (_4170 > _26pretty_ascii_max_7610);
        }
        else {
            _4171 = binary_op(GREATER, _4170, _26pretty_ascii_max_7610);
        }
        _4170 = NOVALUE;
        if (_4171 == 0) {
            DeRef(_4171);
            _4171 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_4171) && DBL_PTR(_4171)->dbl == 0.0){
                DeRef(_4171);
                _4171 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_4171);
            _4171 = NOVALUE;
        }
        DeRef(_4171);
        _4171 = NOVALUE;
LF: 

        /** pretty.e:132					all_ascii = 0*/
        _all_ascii_7674 = 0LL;
L10: 

        /** pretty.e:134			end for*/
        _i_7708 = _i_7708 + 1LL;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** pretty.e:136			if all_ascii then*/
    if (_all_ascii_7674 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** pretty.e:137				pretty_out('\"')*/
    _26pretty_out(34LL);
    goto L12; // [355] 364
L11: 

    /** pretty.e:139				pretty_out('{')*/
    _26pretty_out(123LL);
L12: 

    /** pretty.e:141			pretty_level += 1*/
    _26pretty_level_7605 = _26pretty_level_7605 + 1;

    /** pretty.e:142			for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7671)){
            _4173 = SEQ_PTR(_a_7671)->length;
    }
    else {
        _4173 = 1;
    }
    {
        object _i_7738;
        _i_7738 = 1LL;
L13: 
        if (_i_7738 > _4173){
            goto L14; // [377] 497
        }

        /** pretty.e:143				if multi_line then*/
        if (_multi_line_7673 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** pretty.e:144					indent()*/
        _26indent();
L15: 

        /** pretty.e:146				if all_ascii then*/
        if (_all_ascii_7674 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** pretty.e:147					pretty_out(esc_char(a[i]))*/
        _2 = (object)SEQ_PTR(_a_7671);
        _4174 = (object)*(((s1_ptr)_2)->base + _i_7738);
        Ref(_4174);
        _4175 = _26esc_char(_4174);
        _4174 = NOVALUE;
        _26pretty_out(_4175);
        _4175 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** pretty.e:149					rPrint(a[i])*/
        _2 = (object)SEQ_PTR(_a_7671);
        _4176 = (object)*(((s1_ptr)_2)->base + _i_7738);
        Ref(_4176);
        _26rPrint(_4176);
        _4176 = NOVALUE;
L17: 

        /** pretty.e:151				if pretty_line_count >= pretty_line_max then*/
        if (_26pretty_line_count_7611 < _26pretty_line_max_7612)
        goto L18; // [431] 459

        /** pretty.e:152					if not pretty_dots then*/
        if (_26pretty_dots_7613 != 0)
        goto L19; // [439] 448

        /** pretty.e:153						pretty_out(" ...")*/
        RefDS(_4179);
        _26pretty_out(_4179);
L19: 

        /** pretty.e:155					pretty_dots = 1*/
        _26pretty_dots_7613 = 1LL;

        /** pretty.e:156					return*/
        DeRef(_a_7671);
        DeRef(_sbuff_7672);
        DeRef(_4133);
        _4133 = NOVALUE;
        _4153 = NOVALUE;
        DeRef(_4131);
        _4131 = NOVALUE;
        DeRef(_4142);
        _4142 = NOVALUE;
        DeRef(_4168);
        _4168 = NOVALUE;
        DeRef(_4161);
        _4161 = NOVALUE;
        DeRef(_4163);
        _4163 = NOVALUE;
        DeRef(_4140);
        _4140 = NOVALUE;
        DeRef(_4158);
        _4158 = NOVALUE;
        return;
L18: 

        /** pretty.e:158				if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_7671)){
                _4180 = SEQ_PTR(_a_7671)->length;
        }
        else {
            _4180 = 1;
        }
        _4181 = (_i_7738 != _4180);
        _4180 = NOVALUE;
        if (_4181 == 0) {
            goto L1A; // [468] 490
        }
        _4183 = (_all_ascii_7674 == 0);
        if (_4183 == 0)
        {
            DeRef(_4183);
            _4183 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_4183);
            _4183 = NOVALUE;
        }

        /** pretty.e:159					pretty_out(',')*/
        _26pretty_out(44LL);

        /** pretty.e:160					cut_line(6)*/
        _26cut_line(6LL);
L1A: 

        /** pretty.e:162			end for*/
        _i_7738 = _i_7738 + 1LL;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** pretty.e:163			pretty_level -= 1*/
    _26pretty_level_7605 = _26pretty_level_7605 - 1LL;

    /** pretty.e:164			if multi_line then*/
    if (_multi_line_7673 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** pretty.e:165				indent()*/
    _26indent();
L1B: 

    /** pretty.e:167			if all_ascii then*/
    if (_all_ascii_7674 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** pretty.e:168				pretty_out('\"')*/
    _26pretty_out(34LL);
    goto L1D; // [525] 534
L1C: 

    /** pretty.e:170				pretty_out('}')*/
    _26pretty_out(125LL);
L1D: 
L8: 

    /** pretty.e:173	end procedure*/
    DeRef(_a_7671);
    DeRef(_sbuff_7672);
    DeRef(_4133);
    _4133 = NOVALUE;
    _4153 = NOVALUE;
    DeRef(_4131);
    _4131 = NOVALUE;
    DeRef(_4181);
    _4181 = NOVALUE;
    DeRef(_4142);
    _4142 = NOVALUE;
    DeRef(_4168);
    _4168 = NOVALUE;
    DeRef(_4161);
    _4161 = NOVALUE;
    DeRef(_4163);
    _4163 = NOVALUE;
    DeRef(_4140);
    _4140 = NOVALUE;
    DeRef(_4158);
    _4158 = NOVALUE;
    return;
    ;
}


void _26pretty(object _x_7777, object _options_7778)
{
    object _4190 = NOVALUE;
    object _4189 = NOVALUE;
    object _0, _1, _2;
    

    /** pretty.e:197		if length(options) < length( PRETTY_DEFAULT ) then*/
    _4189 = 10;
    _4190 = 10;

    /** pretty.e:202		pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_ascii_7607 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_26pretty_ascii_7607))
    _26pretty_ascii_7607 = (object)DBL_PTR(_26pretty_ascii_7607)->dbl;

    /** pretty.e:203		pretty_indent = options[INDENT]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_indent_7608 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_26pretty_indent_7608))
    _26pretty_indent_7608 = (object)DBL_PTR(_26pretty_indent_7608)->dbl;

    /** pretty.e:204		pretty_start_col = options[START_COLUMN]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_start_col_7604 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_26pretty_start_col_7604))
    _26pretty_start_col_7604 = (object)DBL_PTR(_26pretty_start_col_7604)->dbl;

    /** pretty.e:205		pretty_end_col = options[WRAP]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_end_col_7602 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_26pretty_end_col_7602))
    _26pretty_end_col_7602 = (object)DBL_PTR(_26pretty_end_col_7602)->dbl;

    /** pretty.e:206		pretty_int_format = options[INT_FORMAT]*/
    DeRef(_26pretty_int_format_7617);
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_int_format_7617 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_26pretty_int_format_7617);

    /** pretty.e:207		pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_26pretty_fp_format_7616);
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_fp_format_7616 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_26pretty_fp_format_7616);

    /** pretty.e:208		pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_ascii_min_7609 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (!IS_ATOM_INT(_26pretty_ascii_min_7609))
    _26pretty_ascii_min_7609 = (object)DBL_PTR(_26pretty_ascii_min_7609)->dbl;

    /** pretty.e:209		pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_ascii_max_7610 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_26pretty_ascii_max_7610))
    _26pretty_ascii_max_7610 = (object)DBL_PTR(_26pretty_ascii_max_7610)->dbl;

    /** pretty.e:210		pretty_line_max = options[MAX_LINES]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_line_max_7612 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_26pretty_line_max_7612))
    _26pretty_line_max_7612 = (object)DBL_PTR(_26pretty_line_max_7612)->dbl;

    /** pretty.e:211		pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (object)SEQ_PTR(_options_7778);
    _26pretty_line_breaks_7614 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (!IS_ATOM_INT(_26pretty_line_breaks_7614))
    _26pretty_line_breaks_7614 = (object)DBL_PTR(_26pretty_line_breaks_7614)->dbl;

    /** pretty.e:213		pretty_chars = pretty_start_col*/
    _26pretty_chars_7603 = _26pretty_start_col_7604;

    /** pretty.e:215		pretty_level = 0 */
    _26pretty_level_7605 = 0LL;

    /** pretty.e:216		pretty_line = ""*/
    RefDS(_5);
    DeRef(_26pretty_line_7618);
    _26pretty_line_7618 = _5;

    /** pretty.e:217		pretty_line_count = 0*/
    _26pretty_line_count_7611 = 0LL;

    /** pretty.e:218		pretty_dots = 0*/
    _26pretty_dots_7613 = 0LL;

    /** pretty.e:219		rPrint(x)*/
    Ref(_x_7777);
    _26rPrint(_x_7777);

    /** pretty.e:220	end procedure*/
    DeRef(_x_7777);
    DeRefDS(_options_7778);
    return;
    ;
}



// 0x11D9163E
