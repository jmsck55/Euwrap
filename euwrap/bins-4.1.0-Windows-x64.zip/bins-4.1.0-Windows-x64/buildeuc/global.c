// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _36set_target_integer_size(object _sizeof_pointer_21594)
{
    object _12233 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:297		if sizeof_pointer = 4 then*/
    if (_sizeof_pointer_21594 != 4LL)
    goto L1; // [5] 17

    /** global.e:298			TMAXINT = max_int32*/
    DeRef(_36TMAXINT_21588);
    _36TMAXINT_21588 = 1073741823LL;
    goto L2; // [14] 25
L1: 

    /** global.e:300			TMAXINT = max_int64*/
    Ref(_36max_int64_21577);
    DeRef(_36TMAXINT_21588);
    _36TMAXINT_21588 = _36max_int64_21577;
L2: 

    /** global.e:303		TMININT = -TMAXINT - 1*/
    if (IS_ATOM_INT(_36TMAXINT_21588)) {
        if ((uintptr_t)_36TMAXINT_21588 == (uintptr_t)HIGH_BITS){
            _12233 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _12233 = - _36TMAXINT_21588;
        }
    }
    else {
        _12233 = unary_op(UMINUS, _36TMAXINT_21588);
    }
    DeRef(_36TMININT_21589);
    if (IS_ATOM_INT(_12233)) {
        _36TMININT_21589 = _12233 - 1LL;
        if ((object)((uintptr_t)_36TMININT_21589 +(uintptr_t) HIGH_BITS) >= 0){
            _36TMININT_21589 = NewDouble((eudouble)_36TMININT_21589);
        }
    }
    else {
        _36TMININT_21589 = NewDouble(DBL_PTR(_12233)->dbl - (eudouble)1LL);
    }
    DeRef(_12233);
    _12233 = NOVALUE;

    /** global.e:304		TMAXINT_DBL = TMAXINT*/
    Ref(_36TMAXINT_21588);
    DeRef(_36TMAXINT_DBL_21591);
    _36TMAXINT_DBL_21591 = _36TMAXINT_21588;

    /** global.e:305		TMININT_DBL = TMININT*/
    Ref(_36TMININT_21589);
    DeRef(_36TMININT_DBL_21590);
    _36TMININT_DBL_21590 = _36TMININT_21589;

    /** global.e:306	end procedure*/
    return;
    ;
}


object _36is_integer(object _o_21602)
{
    object _12241 = NOVALUE;
    object _12240 = NOVALUE;
    object _12239 = NOVALUE;
    object _12237 = NOVALUE;
    object _12235 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:310		if not atom( o ) then*/
    _12235 = IS_ATOM(_o_21602);
    if (_12235 != 0)
    goto L1; // [6] 16
    _12235 = NOVALUE;

    /** global.e:311			return 0*/
    DeRef(_o_21602);
    return 0LL;
L1: 

    /** global.e:314		if o = floor( o ) then*/
    if (IS_ATOM_INT(_o_21602))
    _12237 = e_floor(_o_21602);
    else
    _12237 = unary_op(FLOOR, _o_21602);
    if (binary_op_a(NOTEQ, _o_21602, _12237)){
        DeRef(_12237);
        _12237 = NOVALUE;
        goto L2; // [21] 55
    }
    DeRef(_12237);
    _12237 = NOVALUE;

    /** global.e:315			if o <= TMAXINT and o >= TMININT then*/
    if (IS_ATOM_INT(_o_21602) && IS_ATOM_INT(_36TMAXINT_21588)) {
        _12239 = (_o_21602 <= _36TMAXINT_21588);
    }
    else {
        _12239 = binary_op(LESSEQ, _o_21602, _36TMAXINT_21588);
    }
    if (IS_ATOM_INT(_12239)) {
        if (_12239 == 0) {
            goto L3; // [33] 54
        }
    }
    else {
        if (DBL_PTR(_12239)->dbl == 0.0) {
            goto L3; // [33] 54
        }
    }
    if (IS_ATOM_INT(_o_21602) && IS_ATOM_INT(_36TMININT_21589)) {
        _12241 = (_o_21602 >= _36TMININT_21589);
    }
    else {
        _12241 = binary_op(GREATEREQ, _o_21602, _36TMININT_21589);
    }
    if (_12241 == 0) {
        DeRef(_12241);
        _12241 = NOVALUE;
        goto L3; // [44] 54
    }
    else {
        if (!IS_ATOM_INT(_12241) && DBL_PTR(_12241)->dbl == 0.0){
            DeRef(_12241);
            _12241 = NOVALUE;
            goto L3; // [44] 54
        }
        DeRef(_12241);
        _12241 = NOVALUE;
    }
    DeRef(_12241);
    _12241 = NOVALUE;

    /** global.e:316				return 1*/
    DeRef(_o_21602);
    DeRef(_12239);
    _12239 = NOVALUE;
    return 1LL;
L3: 
L2: 

    /** global.e:319		return 0*/
    DeRef(_o_21602);
    DeRef(_12239);
    _12239 = NOVALUE;
    return 0LL;
    ;
}


object _36symtab_index(object _x_21626)
{
    object _12257 = NOVALUE;
    object _12256 = NOVALUE;
    object _12255 = NOVALUE;
    object _12254 = NOVALUE;
    object _12253 = NOVALUE;
    object _12252 = NOVALUE;
    object _12250 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:337		if x = 0 then*/
    if (_x_21626 != 0LL)
    goto L1; // [5] 18

    /** global.e:338			return TRUE -- NULL value*/
    return _13TRUE_447;
L1: 

    /** global.e:340		if x < 0 or x > length(SymTab) then*/
    _12250 = (_x_21626 < 0LL);
    if (_12250 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_37SymTab_15637)){
            _12252 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _12252 = 1;
    }
    _12253 = (_x_21626 > _12252);
    _12252 = NOVALUE;
    if (_12253 == 0)
    {
        DeRef(_12253);
        _12253 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_12253);
        _12253 = NOVALUE;
    }
L2: 

    /** global.e:341			return FALSE*/
    DeRef(_12250);
    _12250 = NOVALUE;
    return _13FALSE_445;
L3: 

    /** global.e:343		return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _12254 = (object)*(((s1_ptr)_2)->base + _x_21626);
    if (IS_SEQUENCE(_12254)){
            _12255 = SEQ_PTR(_12254)->length;
    }
    else {
        _12255 = 1;
    }
    _12254 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36SIZEOF_VAR_ENTRY_21525;
    ((intptr_t*)_2)[2] = _36SIZEOF_ROUTINE_ENTRY_21522;
    ((intptr_t*)_2)[3] = _36SIZEOF_TEMP_ENTRY_21531;
    ((intptr_t*)_2)[4] = _36SIZEOF_BLOCK_ENTRY_21528;
    _12256 = MAKE_SEQ(_1);
    _12257 = find_from(_12255, _12256, 1LL);
    _12255 = NOVALUE;
    DeRefDS(_12256);
    _12256 = NOVALUE;
    _12254 = NOVALUE;
    DeRef(_12250);
    _12250 = NOVALUE;
    return _12257;
    ;
}



// 0x734DE1B1
