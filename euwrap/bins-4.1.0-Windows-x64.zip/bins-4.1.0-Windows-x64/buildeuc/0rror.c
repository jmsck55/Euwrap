// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _50screen_output(object _f_49601, object _msg_49602)
{
    object _0, _1, _2;
    

    /** error.e:44		puts(f, msg)*/
    EPuts(2LL, _msg_49602); // DJP 

    /** error.e:45	end procedure*/
    DeRefDS(_msg_49602);
    return;
    ;
}


void _50Warning(object _msg_49605, object _mask_49606, object _args_49607)
{
    object _orig_mask_49608 = NOVALUE;
    object _text_49609 = NOVALUE;
    object _w_name_49610 = NOVALUE;
    object _25504 = NOVALUE;
    object _25502 = NOVALUE;
    object _25500 = NOVALUE;
    object _25497 = NOVALUE;
    object _25492 = NOVALUE;
    object _25490 = NOVALUE;
    object _25489 = NOVALUE;
    object _25488 = NOVALUE;
    object _25487 = NOVALUE;
    object _25485 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:54		if display_warnings = 0 then*/

    /** error.e:58		if not Strict_is_on or Strict_Override then*/
    _25485 = (_36Strict_is_on_21828 == 0);
    if (_25485 != 0) {
        goto L1; // [26] 37
    }
    if (_36Strict_Override_21829 == 0)
    {
        goto L2; // [33] 56
    }
    else{
    }
L1: 

    /** error.e:59			if find(mask, strict_only_warnings) then*/
    _25487 = find_from(_mask_49606, _36strict_only_warnings_21826, 1LL);
    if (_25487 == 0)
    {
        _25487 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _25487 = NOVALUE;
    }

    /** error.e:60				return*/
    DeRef(_msg_49605);
    DeRefDS(_args_49607);
    DeRef(_text_49609);
    DeRef(_w_name_49610);
    DeRef(_25485);
    _25485 = NOVALUE;
    return;
L3: 
L2: 

    /** error.e:64		orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_49608 = _mask_49606;

    /** error.e:65		if Strict_is_on and Strict_Override = 0 then*/
    if (_36Strict_is_on_21828 == 0) {
        goto L4; // [65] 85
    }
    _25489 = (_36Strict_Override_21829 == 0LL);
    if (_25489 == 0)
    {
        DeRef(_25489);
        _25489 = NOVALUE;
        goto L4; // [76] 85
    }
    else{
        DeRef(_25489);
        _25489 = NOVALUE;
    }

    /** error.e:66			mask = 0*/
    _mask_49606 = 0LL;
L4: 

    /** error.e:69		if mask = 0 or and_bits(OpWarning, mask) then*/
    _25490 = (_mask_49606 == 0LL);
    if (_25490 != 0) {
        goto L5; // [91] 106
    }
    {uintptr_t tu;
         tu = (uintptr_t)_36OpWarning_21830 & (uintptr_t)_mask_49606;
         _25492 = MAKE_UINT(tu);
    }
    if (_25492 == 0) {
        DeRef(_25492);
        _25492 = NOVALUE;
        goto L6; // [102] 215
    }
    else {
        if (!IS_ATOM_INT(_25492) && DBL_PTR(_25492)->dbl == 0.0){
            DeRef(_25492);
            _25492 = NOVALUE;
            goto L6; // [102] 215
        }
        DeRef(_25492);
        _25492 = NOVALUE;
    }
    DeRef(_25492);
    _25492 = NOVALUE;
L5: 

    /** error.e:70			if orig_mask != 0 then*/
    if (_orig_mask_49608 == 0LL)
    goto L7; // [108] 122

    /** error.e:71				orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_49608 = find_from(_orig_mask_49608, _36warning_flags_21805, 1LL);
L7: 

    /** error.e:74			if orig_mask != 0 then*/
    if (_orig_mask_49608 == 0LL)
    goto L8; // [124] 145

    /** error.e:75				w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (object)SEQ_PTR(_36warning_names_21807);
    _25497 = (object)*(((s1_ptr)_2)->base + _orig_mask_49608);
    {
        object concat_list[3];

        concat_list[0] = _25498;
        concat_list[1] = _25497;
        concat_list[2] = _25496;
        Concat_N((object_ptr)&_w_name_49610, concat_list, 3);
    }
    _25497 = NOVALUE;
    goto L9; // [142] 153
L8: 

    /** error.e:77				w_name = "" -- not maskable*/
    RefDS(_22186);
    DeRef(_w_name_49610);
    _w_name_49610 = _22186;
L9: 

    /** error.e:80			if atom(msg) then*/
    _25500 = IS_ATOM(_msg_49605);
    if (_25500 == 0)
    {
        _25500 = NOVALUE;
        goto LA; // [158] 170
    }
    else{
        _25500 = NOVALUE;
    }

    /** error.e:81				msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_49605);
    RefDS(_args_49607);
    _0 = _msg_49605;
    _msg_49605 = _39GetMsgText(_msg_49605, 1LL, _args_49607);
    DeRef(_0);
LA: 

    /** error.e:84			text = GetMsgText(WARNING_1T2, 0, {w_name, msg})*/
    Ref(_msg_49605);
    RefDS(_w_name_49610);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _w_name_49610;
    ((intptr_t *)_2)[2] = _msg_49605;
    _25502 = MAKE_SEQ(_1);
    _0 = _text_49609;
    _text_49609 = _39GetMsgText(204LL, 0LL, _25502);
    DeRef(_0);
    _25502 = NOVALUE;

    /** error.e:85			if find(text, warning_list) then*/
    _25504 = find_from(_text_49609, _50warning_list_49598, 1LL);
    if (_25504 == 0)
    {
        _25504 = NOVALUE;
        goto LB; // [197] 206
    }
    else{
        _25504 = NOVALUE;
    }

    /** error.e:86				return -- duplicate*/
    DeRef(_msg_49605);
    DeRefDS(_args_49607);
    DeRefDS(_text_49609);
    DeRefDS(_w_name_49610);
    DeRef(_25485);
    _25485 = NOVALUE;
    DeRef(_25490);
    _25490 = NOVALUE;
    return;
LB: 

    /** error.e:89			warning_list = append(warning_list, text)*/
    RefDS(_text_49609);
    Append(&_50warning_list_49598, _50warning_list_49598, _text_49609);
L6: 

    /** error.e:91	end procedure*/
    DeRef(_msg_49605);
    DeRefDS(_args_49607);
    DeRef(_text_49609);
    DeRef(_w_name_49610);
    DeRef(_25485);
    _25485 = NOVALUE;
    DeRef(_25490);
    _25490 = NOVALUE;
    return;
    ;
}


object _50ShowWarnings()
{
    object _c_49675 = NOVALUE;
    object _errfile_49676 = NOVALUE;
    object _twf_49677 = NOVALUE;
    object _25543 = NOVALUE;
    object _25540 = NOVALUE;
    object _25539 = NOVALUE;
    object _25538 = NOVALUE;
    object _25537 = NOVALUE;
    object _25536 = NOVALUE;
    object _25535 = NOVALUE;
    object _25533 = NOVALUE;
    object _25532 = NOVALUE;
    object _25531 = NOVALUE;
    object _25529 = NOVALUE;
    object _25528 = NOVALUE;
    object _25527 = NOVALUE;
    object _25526 = NOVALUE;
    object _25524 = NOVALUE;
    object _25520 = NOVALUE;
    object _25518 = NOVALUE;
    object _25517 = NOVALUE;
    object _25516 = NOVALUE;
    object _25514 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:117		if display_warnings = 0 or length(warning_list) = 0 then*/
    _25514 = (1LL == 0LL);
    if (_25514 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_50warning_list_49598)){
            _25516 = SEQ_PTR(_50warning_list_49598)->length;
    }
    else {
        _25516 = 1;
    }
    _25517 = (_25516 == 0LL);
    _25516 = NOVALUE;
    if (_25517 == 0)
    {
        DeRef(_25517);
        _25517 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25517);
        _25517 = NOVALUE;
    }
L1: 

    /** error.e:118			return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49598)){
            _25518 = SEQ_PTR(_50warning_list_49598)->length;
    }
    else {
        _25518 = 1;
    }
    DeRef(_25514);
    _25514 = NOVALUE;
    return _25518;
L2: 

    /** error.e:121		if TempErrFile > 0 then*/
    if (_50TempErrFile_49587 <= 0LL)
    goto L3; // [43] 57

    /** error.e:122			errfile = TempErrFile*/
    _errfile_49676 = _50TempErrFile_49587;
    goto L4; // [54] 67
L3: 

    /** error.e:124			errfile = STDERR*/
    _errfile_49676 = 2LL;
L4: 

    /** error.e:127		if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_36TempWarningName_21773))
    _25520 = 1;
    else if (IS_ATOM_DBL(_36TempWarningName_21773))
    _25520 = IS_ATOM_INT(DoubleToInt(_36TempWarningName_21773));
    else
    _25520 = 0;
    if (_25520 != 0)
    goto L5; // [74] 183
    _25520 = NOVALUE;

    /** error.e:128			twf = open(TempWarningName,"w")*/
    _twf_49677 = EOpen(_36TempWarningName_21773, _22322, 0LL);

    /** error.e:129			if twf = -1 then*/
    if (_twf_49677 != -1LL)
    goto L6; // [88] 140

    /** error.e:130				ShowMsg(errfile, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21773);
    ((intptr_t*)_2)[1] = _36TempWarningName_21773;
    _25524 = MAKE_SEQ(_1);
    _39ShowMsg(_errfile_49676, 205LL, _25524, 1LL);
    _25524 = NOVALUE;

    /** error.e:131				if errfile != STDERR then*/
    if (_errfile_49676 == 2LL)
    goto L7; // [114] 177

    /** error.e:132					ShowMsg(STDERR, UNABLE_TO_CREATE_WARNING_FILE_1, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_36TempWarningName_21773);
    ((intptr_t*)_2)[1] = _36TempWarningName_21773;
    _25526 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 205LL, _25526, 1LL);
    _25526 = NOVALUE;
    goto L7; // [137] 177
L6: 

    /** error.e:135				for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49598)){
            _25527 = SEQ_PTR(_50warning_list_49598)->length;
    }
    else {
        _25527 = 1;
    }
    {
        object _i_49710;
        _i_49710 = 1LL;
L8: 
        if (_i_49710 > _25527){
            goto L9; // [147] 172
        }

        /** error.e:136					puts(twf, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49598);
        _25528 = (object)*(((s1_ptr)_2)->base + _i_49710);
        EPuts(_twf_49677, _25528); // DJP 
        _25528 = NOVALUE;

        /** error.e:137				end for*/
        _i_49710 = _i_49710 + 1LL;
        goto L8; // [167] 154
L9: 
        ;
    }

    /** error.e:138			    close(twf)*/
    EClose(_twf_49677);
L7: 

    /** error.e:140			TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_36TempWarningName_21773);
    _36TempWarningName_21773 = 99LL;
L5: 

    /** error.e:143		if batch_job = 0 or errfile != STDERR then*/
    _25529 = (_36batch_job_21772 == 0LL);
    if (_25529 != 0) {
        goto LA; // [191] 208
    }
    _25531 = (_errfile_49676 != 2LL);
    if (_25531 == 0)
    {
        DeRef(_25531);
        _25531 = NOVALUE;
        goto LB; // [204] 317
    }
    else{
        DeRef(_25531);
        _25531 = NOVALUE;
    }
LA: 

    /** error.e:144			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_50warning_list_49598)){
            _25532 = SEQ_PTR(_50warning_list_49598)->length;
    }
    else {
        _25532 = 1;
    }
    {
        object _i_49721;
        _i_49721 = 1LL;
LC: 
        if (_i_49721 > _25532){
            goto LD; // [215] 316
        }

        /** error.e:145				puts(errfile, warning_list[i])*/
        _2 = (object)SEQ_PTR(_50warning_list_49598);
        _25533 = (object)*(((s1_ptr)_2)->base + _i_49721);
        EPuts(_errfile_49676, _25533); // DJP 
        _25533 = NOVALUE;

        /** error.e:146				if errfile = STDERR then*/
        if (_errfile_49676 != 2LL)
        goto LE; // [239] 309

        /** error.e:147					if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25535 = (_i_49721 % 20LL);
        _25536 = (_25535 == 0LL);
        _25535 = NOVALUE;
        if (_25536 == 0) {
            _25537 = 0;
            goto LF; // [253] 267
        }
        _25538 = (_36batch_job_21772 == 0LL);
        _25537 = (_25538 != 0);
LF: 
        if (_25537 == 0) {
            goto L10; // [267] 308
        }
        _25540 = (_36test_only_21771 == 0LL);
        if (_25540 == 0)
        {
            DeRef(_25540);
            _25540 = NOVALUE;
            goto L10; // [278] 308
        }
        else{
            DeRef(_25540);
            _25540 = NOVALUE;
        }

        /** error.e:148						ShowMsg(errfile, PRESS_ENTER_TO_CONTINUE_Q_TO_QUIT)*/
        RefDS(_22186);
        _39ShowMsg(_errfile_49676, 206LL, _22186, 1LL);

        /** error.e:149						c = getc(0)*/
        if (0LL != last_r_file_no) {
            last_r_file_ptr = which_file(0LL, EF_READ);
            last_r_file_no = 0LL;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _c_49675 = getKBchar();
            }
            else{
                _c_49675 = getc(last_r_file_ptr);
            }
        }
        else{
            _c_49675 = getc(last_r_file_ptr);
        }

        /** error.e:150						if c = 'q' then*/
        if (_c_49675 != 113LL)
        goto L11; // [298] 307

        /** error.e:151							exit*/
        goto LD; // [304] 316
L11: 
L10: 
LE: 

        /** error.e:155			end for*/
        _i_49721 = _i_49721 + 1LL;
        goto LC; // [311] 222
LD: 
        ;
    }
LB: 

    /** error.e:158		return length(warning_list)*/
    if (IS_SEQUENCE(_50warning_list_49598)){
            _25543 = SEQ_PTR(_50warning_list_49598)->length;
    }
    else {
        _25543 = 1;
    }
    DeRef(_25529);
    _25529 = NOVALUE;
    DeRef(_25536);
    _25536 = NOVALUE;
    DeRef(_25514);
    _25514 = NOVALUE;
    DeRef(_25538);
    _25538 = NOVALUE;
    return _25543;
    ;
}


void _50ShowDefines(object _errfile_49744)
{
    object _c_49745 = NOVALUE;
    object _25557 = NOVALUE;
    object _25556 = NOVALUE;
    object _25554 = NOVALUE;
    object _25553 = NOVALUE;
    object _25550 = NOVALUE;
    object _25549 = NOVALUE;
    object _25548 = NOVALUE;
    object _25547 = NOVALUE;
    object _25546 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:164		if errfile=0 then*/
    if (_errfile_49744 != 0LL)
    goto L1; // [5] 19

    /** error.e:165			errfile = STDERR*/
    _errfile_49744 = 2LL;
L1: 

    /** error.e:168		puts(errfile, format("\n--- [1] ---\n", {GetMsgText(DEFINED_WORDS,0)}))*/
    RefDS(_22186);
    _25546 = _39GetMsgText(207LL, 0LL, _22186);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25546;
    _25547 = MAKE_SEQ(_1);
    _25546 = NOVALUE;
    RefDS(_25545);
    _25548 = _14format(_25545, _25547);
    _25547 = NOVALUE;
    EPuts(_errfile_49744, _25548); // DJP 
    DeRef(_25548);
    _25548 = NOVALUE;

    /** error.e:170		for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_36OpDefines_21836)){
            _25549 = SEQ_PTR(_36OpDefines_21836)->length;
    }
    else {
        _25549 = 1;
    }
    {
        object _i_49757;
        _i_49757 = 1LL;
L2: 
        if (_i_49757 > _25549){
            goto L3; // [48] 100
        }

        /** error.e:171			if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (object)SEQ_PTR(_36OpDefines_21836);
        _25550 = (object)*(((s1_ptr)_2)->base + _i_49757);
        RefDS(_25552);
        RefDS(_25551);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25551;
        ((intptr_t *)_2)[2] = _25552;
        _25553 = MAKE_SEQ(_1);
        _25554 = find_from(_25550, _25553, 1LL);
        _25550 = NOVALUE;
        DeRefDS(_25553);
        _25553 = NOVALUE;
        if (_25554 != 0LL)
        goto L4; // [72] 93

        /** error.e:172				printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (object)SEQ_PTR(_36OpDefines_21836);
        _25556 = (object)*(((s1_ptr)_2)->base + _i_49757);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_25556);
        ((intptr_t*)_2)[1] = _25556;
        _25557 = MAKE_SEQ(_1);
        _25556 = NOVALUE;
        EPrintf(_errfile_49744, _25438, _25557);
        DeRefDS(_25557);
        _25557 = NOVALUE;
L4: 

        /** error.e:174		end for*/
        _i_49757 = _i_49757 + 1LL;
        goto L2; // [95] 55
L3: 
        ;
    }

    /** error.e:175		puts(errfile, "-------------------\n")*/
    EPuts(_errfile_49744, _25558); // DJP 

    /** error.e:177	end procedure*/
    return;
    ;
}


void _50Cleanup(object _status_49774)
{
    object _w_49775 = NOVALUE;
    object _show_error_49776 = NOVALUE;
    object _25576 = NOVALUE;
    object _25575 = NOVALUE;
    object _25574 = NOVALUE;
    object _25573 = NOVALUE;
    object _25572 = NOVALUE;
    object _25571 = NOVALUE;
    object _25570 = NOVALUE;
    object _25569 = NOVALUE;
    object _25568 = NOVALUE;
    object _25567 = NOVALUE;
    object _25565 = NOVALUE;
    object _25564 = NOVALUE;
    object _25563 = NOVALUE;
    object _25562 = NOVALUE;
    object _25561 = NOVALUE;
    object _25559 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:182		integer w, show_error = 0*/
    _show_error_49776 = 0LL;

    /** error.e:184		ifdef EU_EX then*/

    /** error.e:190		show_error = 1*/
    _show_error_49776 = 1LL;

    /** error.e:196		if object(src_file) = 0 then*/
    if( NOVALUE == _36src_file_21884 ){
        _25559 = 0;
    }
    else{
        _25559 = 1;
    }
    if (_25559 != 0LL)
    goto L1; // [20] 34

    /** error.e:197			src_file = -1*/
    _36src_file_21884 = -1LL;
    goto L2; // [31] 86
L1: 

    /** error.e:198		elsif src_file >= 0 and (src_file != repl_file or not repl) then*/
    _25561 = (_36src_file_21884 >= 0LL);
    if (_25561 == 0) {
        goto L3; // [42] 85
    }
    _25563 = (_36src_file_21884 != 5555LL);
    if (_25563 != 0) {
        DeRef(_25564);
        _25564 = 1;
        goto L4; // [54] 67
    }
    _25565 = (0LL == 0);
    _25564 = (_25565 != 0);
L4: 
    if (_25564 == 0)
    {
        _25564 = NOVALUE;
        goto L3; // [68] 85
    }
    else{
        _25564 = NOVALUE;
    }

    /** error.e:199			close(src_file)*/
    EClose(_36src_file_21884);

    /** error.e:200			src_file = -1*/
    _36src_file_21884 = -1LL;
L3: 
L2: 

    /** error.e:203		w = ShowWarnings()*/
    _w_49775 = _50ShowWarnings();
    if (!IS_ATOM_INT(_w_49775)) {
        _1 = (object)(DBL_PTR(_w_49775)->dbl);
        DeRefDS(_w_49775);
        _w_49775 = _1;
    }

    /** error.e:204		if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25567 = (_36TRANSLATE_21361 == 0);
    if (_25567 == 0) {
        _25568 = 0;
        goto L5; // [100] 118
    }
    if (_36BIND_21364 != 0) {
        _25569 = 1;
        goto L6; // [106] 114
    }
    _25569 = (_show_error_49776 != 0);
L6: 
    _25568 = (_25569 != 0);
L5: 
    if (_25568 == 0) {
        goto L7; // [118] 179
    }
    if (_w_49775 != 0) {
        DeRef(_25571);
        _25571 = 1;
        goto L8; // [122] 132
    }
    _25571 = (_50Errors_49586 != 0);
L8: 
    if (_25571 == 0)
    {
        _25571 = NOVALUE;
        goto L7; // [133] 179
    }
    else{
        _25571 = NOVALUE;
    }

    /** error.e:205			if not batch_job and not test_only then*/
    _25572 = (_36batch_job_21772 == 0);
    if (_25572 == 0) {
        goto L9; // [143] 178
    }
    _25574 = (_36test_only_21771 == 0);
    if (_25574 == 0)
    {
        DeRef(_25574);
        _25574 = NOVALUE;
        goto L9; // [153] 178
    }
    else{
        DeRef(_25574);
        _25574 = NOVALUE;
    }

    /** error.e:206				screen_output(STDERR, GetMsgText(PRESS_ENTER,0))*/
    RefDS(_22186);
    _25575 = _39GetMsgText(208LL, 0LL, _22186);
    _50screen_output(2LL, _25575);
    _25575 = NOVALUE;

    /** error.e:207				getc(0) -- wait*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25576 = getKBchar();
        }
        else{
            _25576 = getc(last_r_file_ptr);
        }
    }
    else{
        _25576 = getc(last_r_file_ptr);
    }
L9: 
L7: 

    /** error.e:212		cleanup_open_includes()*/
    _62cleanup_open_includes();

    /** error.e:213		abort(status)*/
    UserCleanup(_status_49774);

    /** error.e:214	end procedure*/
    DeRef(_25572);
    _25572 = NOVALUE;
    DeRef(_25563);
    _25563 = NOVALUE;
    DeRef(_25567);
    _25567 = NOVALUE;
    DeRef(_25561);
    _25561 = NOVALUE;
    DeRef(_25565);
    _25565 = NOVALUE;
    return;
    ;
}


void _50OpenErrFile()
{
    object _25583 = NOVALUE;
    object _25582 = NOVALUE;
    object _25580 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:219	    if TempErrFile != -1 then*/
    if (_50TempErrFile_49587 == -1LL)
    goto L1; // [5] 19

    /** error.e:220			TempErrFile = open(TempErrName, "w")*/
    _50TempErrFile_49587 = EOpen(_50TempErrName_49588, _22322, 0LL);
L1: 

    /** error.e:223		if TempErrFile = -1 then*/
    if (_50TempErrFile_49587 != -1LL)
    goto L2; // [23] 66

    /** error.e:224			if length(TempErrName) > 0 then*/
    _25580 = 6;

    /** error.e:225				screen_output(STDERR, GetMsgText(CANT_CREATE_ERROR_MESSAGE_FILE_1, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_50TempErrName_49588);
    ((intptr_t*)_2)[1] = _50TempErrName_49588;
    _25582 = MAKE_SEQ(_1);
    _25583 = _39GetMsgText(209LL, 0LL, _25582);
    _25582 = NOVALUE;
    _50screen_output(2LL, _25583);
    _25583 = NOVALUE;

    /** error.e:227			abort(1) -- with no clean up*/
    UserCleanup(1LL);
L2: 

    /** error.e:229	end procedure*/
    return;
    ;
}


void _50ShowErr(object _f_49832)
{
    object _msg_inlined_screen_output_at_43_49845 = NOVALUE;
    object _25590 = NOVALUE;
    object _25589 = NOVALUE;
    object _25588 = NOVALUE;
    object _25586 = NOVALUE;
    object _25584 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:234		if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _25584 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _25584 = 1;
    }
    if (_25584 != 0LL)
    goto L1; // [10] 20

    /** error.e:235			return*/
    return;
L1: 

    /** error.e:238		if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (object)SEQ_PTR(_50ThisLine_49590);
    _25586 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25586, 26LL)){
        _25586 = NOVALUE;
        goto L2; // [30] 64
    }
    _25586 = NOVALUE;

    /** error.e:239			screen_output(f, GetMsgText(MSG_ENDOFFILE,0))*/
    RefDS(_22186);
    _25588 = _39GetMsgText(210LL, 0LL, _22186);
    DeRef(_msg_inlined_screen_output_at_43_49845);
    _msg_inlined_screen_output_at_43_49845 = _25588;
    _25588 = NOVALUE;

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49832, _msg_inlined_screen_output_at_43_49845); // DJP 

    /** error.e:45	end procedure*/
    goto L3; // [56] 59
L3: 
    DeRef(_msg_inlined_screen_output_at_43_49845);
    _msg_inlined_screen_output_at_43_49845 = NOVALUE;
    goto L4; // [61] 81
L2: 

    /** error.e:241			screen_output(f, ThisLine)*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49832, _50ThisLine_49590); // DJP 

    /** error.e:45	end procedure*/
    goto L5; // [77] 80
L5: 
L4: 

    /** error.e:244		for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25589 = _50bp_49594 - 2LL;
    if ((object)((uintptr_t)_25589 +(uintptr_t) HIGH_BITS) >= 0){
        _25589 = NewDouble((eudouble)_25589);
    }
    {
        object _i_49849;
        _i_49849 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_49849, _25589)){
            goto L7; // [89] 143
        }

        /** error.e:245			if ThisLine[i] = '\t' then*/
        _2 = (object)SEQ_PTR(_50ThisLine_49590);
        if (!IS_ATOM_INT(_i_49849)){
            _25590 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_49849)->dbl));
        }
        else{
            _25590 = (object)*(((s1_ptr)_2)->base + _i_49849);
        }
        if (binary_op_a(NOTEQ, _25590, 9LL)){
            _25590 = NOVALUE;
            goto L8; // [104] 123
        }
        _25590 = NOVALUE;

        /** error.e:246				screen_output(f, "\t")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49832, _24148); // DJP 

        /** error.e:45	end procedure*/
        goto L9; // [117] 136
        goto L9; // [120] 136
L8: 

        /** error.e:248				screen_output(f, " ")*/

        /** error.e:44		puts(f, msg)*/
        EPuts(_f_49832, _23572); // DJP 

        /** error.e:45	end procedure*/
        goto LA; // [132] 135
LA: 
L9: 

        /** error.e:250		end for*/
        _0 = _i_49849;
        if (IS_ATOM_INT(_i_49849)) {
            _i_49849 = _i_49849 + 1LL;
            if ((object)((uintptr_t)_i_49849 +(uintptr_t) HIGH_BITS) >= 0){
                _i_49849 = NewDouble((eudouble)_i_49849);
            }
        }
        else {
            _i_49849 = binary_op_a(PLUS, _i_49849, 1LL);
        }
        DeRef(_0);
        goto L6; // [138] 96
L7: 
        ;
        DeRef(_i_49849);
    }

    /** error.e:252		screen_output(f, "^\n\n")*/

    /** error.e:44		puts(f, msg)*/
    EPuts(_f_49832, _25592); // DJP 

    /** error.e:45	end procedure*/
    goto LB; // [152] 155
LB: 

    /** error.e:253	end procedure*/
    DeRef(_25589);
    _25589 = NOVALUE;
    return;
    ;
}


void _50CompileErr(object _msg_49861, object _args_49862, object _preproc_49863)
{
    object _errmsg_49864 = NOVALUE;
    object _25613 = NOVALUE;
    object _25609 = NOVALUE;
    object _25608 = NOVALUE;
    object _25607 = NOVALUE;
    object _25606 = NOVALUE;
    object _25605 = NOVALUE;
    object _25604 = NOVALUE;
    object _25602 = NOVALUE;
    object _25601 = NOVALUE;
    object _25599 = NOVALUE;
    object _25598 = NOVALUE;
    object _25597 = NOVALUE;
    object _25593 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:260		if integer(msg) then*/
    if (IS_ATOM_INT(_msg_49861))
    _25593 = 1;
    else if (IS_ATOM_DBL(_msg_49861))
    _25593 = IS_ATOM_INT(DoubleToInt(_msg_49861));
    else
    _25593 = 0;
    if (_25593 == 0)
    {
        _25593 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25593 = NOVALUE;
    }

    /** error.e:261			msg = GetMsgText(msg)*/
    Ref(_msg_49861);
    RefDS(_22186);
    _0 = _msg_49861;
    _msg_49861 = _39GetMsgText(_msg_49861, 1LL, _22186);
    DeRefi(_0);
L1: 

    /** error.e:264		msg = format(msg, args)*/
    Ref(_msg_49861);
    Ref(_args_49862);
    _0 = _msg_49861;
    _msg_49861 = _14format(_msg_49861, _args_49862);
    DeRef(_0);

    /** error.e:266		Errors += 1*/
    _50Errors_49586 = _50Errors_49586 + 1;

    /** error.e:267		if not preproc and length(known_files) then*/
    _25597 = (_preproc_49863 == 0);
    if (_25597 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _25599 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _25599 = 1;
    }
    if (_25599 == 0)
    {
        _25599 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25599 = NOVALUE;
    }

    /** error.e:268			errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25601 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25601);
    ((intptr_t*)_2)[1] = _25601;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    Ref(_msg_49861);
    ((intptr_t*)_2)[3] = _msg_49861;
    _25602 = MAKE_SEQ(_1);
    _25601 = NOVALUE;
    DeRef(_errmsg_49864);
    _errmsg_49864 = EPrintf(-9999999, _25600, _25602);
    DeRefDS(_25602);
    _25602 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** error.e:271			errmsg = msg*/
    Ref(_msg_49861);
    DeRef(_errmsg_49864);
    _errmsg_49864 = _msg_49861;

    /** error.e:272			if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_49861)){
            _25604 = SEQ_PTR(_msg_49861)->length;
    }
    else {
        _25604 = 1;
    }
    _25605 = (_25604 > 0LL);
    _25604 = NOVALUE;
    if (_25605 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_49861)){
            _25607 = SEQ_PTR(_msg_49861)->length;
    }
    else {
        _25607 = 1;
    }
    _2 = (object)SEQ_PTR(_msg_49861);
    _25608 = (object)*(((s1_ptr)_2)->base + _25607);
    if (IS_ATOM_INT(_25608)) {
        _25609 = (_25608 != 10LL);
    }
    else {
        _25609 = binary_op(NOTEQ, _25608, 10LL);
    }
    _25608 = NOVALUE;
    if (_25609 == 0) {
        DeRef(_25609);
        _25609 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25609) && DBL_PTR(_25609)->dbl == 0.0){
            DeRef(_25609);
            _25609 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25609);
        _25609 = NOVALUE;
    }
    DeRef(_25609);
    _25609 = NOVALUE;

    /** error.e:273				errmsg &= '\n'*/
    Append(&_errmsg_49864, _errmsg_49864, 10LL);
L4: 
L3: 

    /** error.e:277		if not preproc then*/
    if (_preproc_49863 != 0)
    goto L5; // [123] 131

    /** error.e:279			OpenErrFile() -- exits if error filename is ""*/
    _50OpenErrFile();
L5: 

    /** error.e:281		screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_49864);
    _50screen_output(2LL, _errmsg_49864);

    /** error.e:283		if not preproc then*/
    if (_preproc_49863 != 0)
    goto L6; // [143] 198

    /** error.e:284			ShowErr(STDERR)*/
    _50ShowErr(2LL);

    /** error.e:286			puts(TempErrFile, errmsg)*/
    EPuts(_50TempErrFile_49587, _errmsg_49864); // DJP 

    /** error.e:288			ShowErr(TempErrFile)*/
    _50ShowErr(_50TempErrFile_49587);

    /** error.e:290			ShowWarnings()*/
    _25613 = _50ShowWarnings();

    /** error.e:292			ShowDefines(TempErrFile)*/
    _50ShowDefines(_50TempErrFile_49587);

    /** error.e:294			close(TempErrFile)*/
    EClose(_50TempErrFile_49587);

    /** error.e:295			TempErrFile = -2*/
    _50TempErrFile_49587 = -2LL;

    /** error.e:296			ifdef CRASH_ON_ERROR then*/

    /** error.e:299			Cleanup(1)*/
    _50Cleanup(1LL);
L6: 

    /** error.e:302	end procedure*/
    DeRef(_msg_49861);
    DeRef(_args_49862);
    DeRef(_errmsg_49864);
    DeRef(_25605);
    _25605 = NOVALUE;
    DeRef(_25597);
    _25597 = NOVALUE;
    DeRef(_25613);
    _25613 = NOVALUE;
    return;
    ;
}


void _50InternalErr(object _msgno_49908, object _args_49909)
{
    object _msg_49910 = NOVALUE;
    object _25628 = NOVALUE;
    object _25627 = NOVALUE;
    object _25626 = NOVALUE;
    object _25625 = NOVALUE;
    object _25624 = NOVALUE;
    object _25623 = NOVALUE;
    object _25622 = NOVALUE;
    object _25621 = NOVALUE;
    object _25620 = NOVALUE;
    object _25619 = NOVALUE;
    object _25618 = NOVALUE;
    object _25615 = NOVALUE;
    object _0, _1, _2;
    

    /** error.e:316		if atom(args) then*/
    _25615 = 0;
    if (_25615 == 0)
    {
        _25615 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25615 = NOVALUE;
    }

    /** error.e:317			args = {args}*/
    _0 = _args_49909;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_args_49909);
    ((intptr_t*)_2)[1] = _args_49909;
    _args_49909 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** error.e:320		msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_49909);
    _0 = _msg_49910;
    _msg_49910 = _39GetMsgText(_msgno_49908, 1LL, _args_49909);
    DeRef(_0);

    /** error.e:321		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L2; // [32] 58
    }
    else{
    }

    /** error.e:322			screen_output(STDERR, GetMsgText(INTERNAL_ERRORT1, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_49910);
    ((intptr_t*)_2)[1] = _msg_49910;
    _25618 = MAKE_SEQ(_1);
    _25619 = _39GetMsgText(211LL, 1LL, _25618);
    _25618 = NOVALUE;
    _50screen_output(2LL, _25619);
    _25619 = NOVALUE;
    goto L3; // [55] 91
L2: 

    /** error.e:324			screen_output(STDERR, GetMsgText(INTERNAL_ERROR_AT_12T3, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25620 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_25620);
    ((intptr_t*)_2)[1] = _25620;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    RefDS(_msg_49910);
    ((intptr_t*)_2)[3] = _msg_49910;
    _25621 = MAKE_SEQ(_1);
    _25620 = NOVALUE;
    _25622 = _39GetMsgText(212LL, 1LL, _25621);
    _25621 = NOVALUE;
    _50screen_output(2LL, _25622);
    _25622 = NOVALUE;
L3: 

    /** error.e:327		if not batch_job and not test_only then*/
    _25623 = (_36batch_job_21772 == 0);
    if (_25623 == 0) {
        goto L4; // [98] 133
    }
    _25625 = (_36test_only_21771 == 0);
    if (_25625 == 0)
    {
        DeRef(_25625);
        _25625 = NOVALUE;
        goto L4; // [108] 133
    }
    else{
        DeRef(_25625);
        _25625 = NOVALUE;
    }

    /** error.e:328			screen_output(STDERR, GetMsgText(PRESS_ENTER, 0))*/
    RefDS(_22186);
    _25626 = _39GetMsgText(208LL, 0LL, _22186);
    _50screen_output(2LL, _25626);
    _25626 = NOVALUE;

    /** error.e:329			getc(0)*/
    if (0LL != last_r_file_no) {
        last_r_file_ptr = which_file(0LL, EF_READ);
        last_r_file_no = 0LL;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _25627 = getKBchar();
        }
        else{
            _25627 = getc(last_r_file_ptr);
        }
    }
    else{
        _25627 = getc(last_r_file_ptr);
    }
L4: 

    /** error.e:333		machine_proc(67, GetMsgText(FAILED_DUE_TO_INTERNAL_ERROR))*/
    RefDS(_22186);
    _25628 = _39GetMsgText(213LL, 1LL, _22186);
    machine(67LL, _25628);
    DeRef(_25628);
    _25628 = NOVALUE;

    /** error.e:334	end procedure*/
    DeRef(_args_49909);
    DeRef(_msg_49910);
    DeRef(_25623);
    _25623 = NOVALUE;
    return;
    ;
}



// 0x6656E39F
