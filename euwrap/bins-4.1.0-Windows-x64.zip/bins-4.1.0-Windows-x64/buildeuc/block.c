// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _65block_type_name(object _opcode_25438)
{
    object _14227 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_25438)) {
        _1 = (object)(DBL_PTR(_opcode_25438)->dbl);
        DeRefDS(_opcode_25438);
        _opcode_25438 = _1;
    }

    /** block.e:51		switch opcode do*/
    _0 = _opcode_25438;
    switch ( _0 ){ 

        /** block.e:52			case LOOP then*/
        case 422:

        /** block.e:53				return "LOOP"*/
        RefDS(_14225);
        return _14225;
        goto L1; // [20] 63

        /** block.e:54			case PROC then*/
        case 27:

        /** block.e:55				return "PROC"*/
        RefDS(_13132);
        return _13132;
        goto L1; // [32] 63

        /** block.e:56			case FUNC then*/
        case 501:

        /** block.e:57				return "FUNC"*/
        RefDS(_14226);
        return _14226;
        goto L1; // [44] 63

        /** block.e:58			case else*/
        default:

        /** block.e:59				return opnames[opcode]*/
        _2 = (object)SEQ_PTR(_61opnames_23205);
        _14227 = (object)*(((s1_ptr)_2)->base + _opcode_25438);
        RefDS(_14227);
        return _14227;
    ;}L1: 
    ;
}


void _65check_block(object _got_25454)
{
    object _expected_25455 = NOVALUE;
    object _14235 = NOVALUE;
    object _14234 = NOVALUE;
    object _14233 = NOVALUE;
    object _14229 = NOVALUE;
    object _14228 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:64		integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14228 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14228 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14229 = (object)*(((s1_ptr)_2)->base + _14228);
    _2 = (object)SEQ_PTR(_14229);
    _expected_25455 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_expected_25455)){
        _expected_25455 = (object)DBL_PTR(_expected_25455)->dbl;
    }
    _14229 = NOVALUE;

    /** block.e:65		if got = FUNC then*/
    if (_got_25454 != 501LL)
    goto L1; // [24] 38

    /** block.e:66			got = PROC*/
    _got_25454 = 27LL;
L1: 

    /** block.e:68		if got != expected then*/
    if (_got_25454 == _expected_25455)
    goto L2; // [40] 66

    /** block.e:69			CompileErr( EXPECTED_END_OF_1_BLOCK_NOT_2, {block_type_name( expected ), block_type_name( got)} )*/
    _14233 = _65block_type_name(_expected_25455);
    _14234 = _65block_type_name(_got_25454);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14233;
    ((intptr_t *)_2)[2] = _14234;
    _14235 = MAKE_SEQ(_1);
    _14234 = NOVALUE;
    _14233 = NOVALUE;
    _50CompileErr(79LL, _14235, 0LL);
    _14235 = NOVALUE;
L2: 

    /** block.e:71	end procedure*/
    return;
    ;
}


void _65Block_var(object _sym_25473)
{
    object _block_25474 = NOVALUE;
    object _14256 = NOVALUE;
    object _14255 = NOVALUE;
    object _14254 = NOVALUE;
    object _14252 = NOVALUE;
    object _14251 = NOVALUE;
    object _14249 = NOVALUE;
    object _14248 = NOVALUE;
    object _14247 = NOVALUE;
    object _14246 = NOVALUE;
    object _14245 = NOVALUE;
    object _14244 = NOVALUE;
    object _14243 = NOVALUE;
    object _14241 = NOVALUE;
    object _14239 = NOVALUE;
    object _14238 = NOVALUE;
    object _14236 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_25473)) {
        _1 = (object)(DBL_PTR(_sym_25473)->dbl);
        DeRefDS(_sym_25473);
        _sym_25473 = _1;
    }

    /** block.e:75		sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14236 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14236 = 1;
    }
    DeRef(_block_25474);
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _block_25474 = (object)*(((s1_ptr)_2)->base + _14236);
    Ref(_block_25474);

    /** block.e:76		block_stack[$] = 0*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14238 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14238 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _2 = (object)(((s1_ptr)_2)->base + _14238);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** block.e:77		if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14239 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14239 = 1;
    }
    if (_14239 <= 1LL)
    goto L1; // [34] 58

    /** block.e:79			SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25473 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_block_25474);
    _14243 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14243);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14243;
    if( _1 != _14243 ){
        DeRef(_1);
    }
    _14243 = NOVALUE;
    _14241 = NOVALUE;
L1: 

    /** block.e:82		if length(block[BLOCK_VARS]) then*/
    _2 = (object)SEQ_PTR(_block_25474);
    _14244 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14244)){
            _14245 = SEQ_PTR(_14244)->length;
    }
    else {
        _14245 = 1;
    }
    _14244 = NOVALUE;
    if (_14245 == 0)
    {
        _14245 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _14245 = NOVALUE;
    }

    /** block.e:83			SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25474);
    _14246 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14246)){
            _14247 = SEQ_PTR(_14246)->length;
    }
    else {
        _14247 = 1;
    }
    _2 = (object)SEQ_PTR(_14246);
    _14248 = (object)*(((s1_ptr)_2)->base + _14247);
    _14246 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14248))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14248)->dbl));
    else
    _3 = (object)(_14248 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21388))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21388)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21388);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25473;
    DeRef(_1);
    _14249 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** block.e:85			SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (object)SEQ_PTR(_block_25474);
    _14251 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14251))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14251)->dbl));
    else
    _3 = (object)(_14251 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21388))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21388)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21388);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_25473;
    DeRef(_1);
    _14252 = NOVALUE;
L3: 

    /** block.e:88		block[BLOCK_VARS] &= sym*/
    _2 = (object)SEQ_PTR(_block_25474);
    _14254 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_SEQUENCE(_14254) && IS_ATOM(_sym_25473)) {
        Append(&_14255, _14254, _sym_25473);
    }
    else if (IS_ATOM(_14254) && IS_SEQUENCE(_sym_25473)) {
    }
    else {
        Concat((object_ptr)&_14255, _14254, _sym_25473);
        _14254 = NOVALUE;
    }
    _14254 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25474);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25474 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14255;
    if( _1 != _14255 ){
        DeRef(_1);
    }
    _14255 = NOVALUE;

    /** block.e:90		block_stack[$] = block*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14256 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14256 = 1;
    }
    RefDS(_block_25474);
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _2 = (object)(((s1_ptr)_2)->base + _14256);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _block_25474;
    DeRef(_1);

    /** block.e:91		ifdef BDEBUG then*/

    /** block.e:96	end procedure*/
    DeRefDS(_block_25474);
    _14244 = NOVALUE;
    _14251 = NOVALUE;
    _14248 = NOVALUE;
    return;
    ;
}


void _65NewBlock(object _opcode_25508, object _block_label_25509)
{
    object _block_25527 = NOVALUE;
    object _14270 = NOVALUE;
    object _14269 = NOVALUE;
    object _14268 = NOVALUE;
    object _14266 = NOVALUE;
    object _14264 = NOVALUE;
    object _14263 = NOVALUE;
    object _14261 = NOVALUE;
    object _14260 = NOVALUE;
    object _14258 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:101		SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _14258 = Repeat(0LL, _36SIZEOF_BLOCK_ENTRY_21528);
    RefDS(_14258);
    Append(&_37SymTab_15637, _37SymTab_15637, _14258);
    DeRefDS(_14258);
    _14258 = NOVALUE;

    /** block.e:102		SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _14260 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _14260 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14260 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _14261 = NOVALUE;

    /** block.e:103		SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _14263 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _14263 = 1;
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14263 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FIRST_LINE_21421))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRST_LINE_21421)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FIRST_LINE_21421);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21764;
    DeRef(_1);
    _14264 = NOVALUE;

    /** block.e:105		sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _14266 = 6LL;
    DeRef(_block_25527);
    _block_25527 = Repeat(0LL, 6LL);
    _14266 = NOVALUE;

    /** block.e:106		block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _14268 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _14268 = 1;
    }
    _2 = (object)SEQ_PTR(_block_25527);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25527 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    *(intptr_t *)_2 = _14268;
    if( _1 != _14268 ){
    }
    _14268 = NOVALUE;

    /** block.e:107		block[BLOCK_OPCODE] = opcode*/
    _2 = (object)SEQ_PTR(_block_25527);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25527 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    *(intptr_t *)_2 = _opcode_25508;

    /** block.e:108		block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_25509);
    _2 = (object)SEQ_PTR(_block_25527);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25527 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    *(intptr_t *)_2 = _block_label_25509;

    /** block.e:109		block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21851)){
            _14269 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _14269 = 1;
    }
    _14270 = _14269 + 1;
    _14269 = NOVALUE;
    _2 = (object)SEQ_PTR(_block_25527);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25527 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14270;
    if( _1 != _14270 ){
        DeRef(_1);
    }
    _14270 = NOVALUE;

    /** block.e:110		block[BLOCK_VARS]   = {}*/
    RefDS(_5);
    _2 = (object)SEQ_PTR(_block_25527);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _block_25527 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5;
    DeRef(_1);

    /** block.e:112		block_stack = append( block_stack, block )*/
    RefDS(_block_25527);
    Append(&_65block_stack_25427, _65block_stack_25427, _block_25527);

    /** block.e:113		current_block = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _65current_block_25434 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _65current_block_25434 = 1;
    }

    /** block.e:114	end procedure*/
    DeRefi(_block_label_25509);
    DeRefDS(_block_25527);
    return;
    ;
}


void _65Start_block(object _opcode_25540, object _block_label_25541)
{
    object _last_block_25543 = NOVALUE;
    object _label_name_25571 = NOVALUE;
    object _14292 = NOVALUE;
    object _14291 = NOVALUE;
    object _14290 = NOVALUE;
    object _14287 = NOVALUE;
    object _14286 = NOVALUE;
    object _14284 = NOVALUE;
    object _14283 = NOVALUE;
    object _14282 = NOVALUE;
    object _14281 = NOVALUE;
    object _14280 = NOVALUE;
    object _14277 = NOVALUE;
    object _14275 = NOVALUE;
    object _14274 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:120		symtab_index last_block = current_block*/
    _last_block_25543 = _65current_block_25434;

    /** block.e:121		if opcode = FUNC then*/
    if (_opcode_25540 != 501LL)
    goto L1; // [16] 30

    /** block.e:122			opcode = PROC*/
    _opcode_25540 = 27LL;
L1: 

    /** block.e:124		NewBlock( opcode, block_label )*/
    Ref(_block_label_25541);
    _65NewBlock(_opcode_25540, _block_label_25541);

    /** block.e:126		if find(opcode, RTN_TOKS) then*/
    _14274 = find_from(_opcode_25540, _38RTN_TOKS_16291, 1LL);
    if (_14274 == 0)
    {
        _14274 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _14274 = NOVALUE;
    }

    /** block.e:127			SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_25541))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25541)->dbl));
    else
    _3 = (object)(_block_label_25541 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _65current_block_25434;
    DeRef(_1);
    _14275 = NOVALUE;

    /** block.e:128			SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25434 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_block_label_25541)){
        _14280 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_block_label_25541)->dbl));
    }
    else{
        _14280 = (object)*(((s1_ptr)_2)->base + _block_label_25541);
    }
    _2 = (object)SEQ_PTR(_14280);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _14281 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _14281 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _14280 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_14281);
    ((intptr_t*)_2)[1] = _14281;
    _14282 = MAKE_SEQ(_1);
    _14281 = NOVALUE;
    _14283 = EPrintf(-9999999, _14279, _14282);
    DeRefDS(_14282);
    _14282 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14283;
    if( _1 != _14283 ){
        DeRef(_1);
    }
    _14283 = NOVALUE;
    _14277 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** block.e:129		elsif current_block then*/
    if (_65current_block_25434 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** block.e:135			SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25434 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_BLOCK_21416))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21416)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_BLOCK_21416);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _last_block_25543;
    DeRef(_1);
    _14284 = NOVALUE;

    /** block.e:136			sequence label_name = ""*/
    RefDS(_5);
    DeRefi(_label_name_25571);
    _label_name_25571 = _5;

    /** block.e:137			if sequence(block_label) then*/
    _14286 = IS_SEQUENCE(_block_label_25541);
    if (_14286 == 0)
    {
        _14286 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _14286 = NOVALUE;
    }

    /** block.e:138				label_name = block_label*/
    Ref(_block_label_25541);
    DeRefDSi(_label_name_25571);
    _label_name_25571 = _block_label_25541;
L5: 

    /** block.e:141			SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25434 + ((s1_ptr)_2)->base);
    _14290 = _65block_type_name(_opcode_25540);
    RefDS(_label_name_25571);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14290;
    ((intptr_t *)_2)[2] = _label_name_25571;
    _14291 = MAKE_SEQ(_1);
    _14290 = NOVALUE;
    _14292 = EPrintf(-9999999, _14289, _14291);
    DeRefDS(_14291);
    _14291 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14292;
    if( _1 != _14292 ){
        DeRef(_1);
    }
    _14292 = NOVALUE;
    _14287 = NOVALUE;
L4: 
    DeRefi(_label_name_25571);
    _label_name_25571 = NOVALUE;
L3: 

    /** block.e:144		ifdef BDEBUG then*/

    /** block.e:153	end procedure*/
    DeRefi(_block_label_25541);
    return;
    ;
}


void _65block_label(object _label_name_25587)
{
    object _14306 = NOVALUE;
    object _14305 = NOVALUE;
    object _14304 = NOVALUE;
    object _14303 = NOVALUE;
    object _14302 = NOVALUE;
    object _14301 = NOVALUE;
    object _14299 = NOVALUE;
    object _14297 = NOVALUE;
    object _14296 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:157		block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14296 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14296 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25427 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14296 + ((s1_ptr)_2)->base);
    RefDS(_label_name_25587);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _label_name_25587;
    DeRef(_1);
    _14297 = NOVALUE;

    /** block.e:158		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_65current_block_25434 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14301 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14301 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14302 = (object)*(((s1_ptr)_2)->base + _14301);
    _2 = (object)SEQ_PTR(_14302);
    _14303 = (object)*(((s1_ptr)_2)->base + 2LL);
    _14302 = NOVALUE;
    Ref(_14303);
    _14304 = _65block_type_name(_14303);
    _14303 = NOVALUE;
    RefDS(_label_name_25587);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14304;
    ((intptr_t *)_2)[2] = _label_name_25587;
    _14305 = MAKE_SEQ(_1);
    _14304 = NOVALUE;
    _14306 = EPrintf(-9999999, _14289, _14305);
    DeRefDS(_14305);
    _14305 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14306;
    if( _1 != _14306 ){
        DeRef(_1);
    }
    _14306 = NOVALUE;
    _14299 = NOVALUE;

    /** block.e:160	end procedure*/
    DeRefDS(_label_name_25587);
    return;
    ;
}


object _65pop_block()
{
    object _block_25606 = NOVALUE;
    object _block_vars_25619 = NOVALUE;
    object _14335 = NOVALUE;
    object _14333 = NOVALUE;
    object _14332 = NOVALUE;
    object _14331 = NOVALUE;
    object _14330 = NOVALUE;
    object _14328 = NOVALUE;
    object _14327 = NOVALUE;
    object _14326 = NOVALUE;
    object _14325 = NOVALUE;
    object _14324 = NOVALUE;
    object _14323 = NOVALUE;
    object _14322 = NOVALUE;
    object _14321 = NOVALUE;
    object _14320 = NOVALUE;
    object _14319 = NOVALUE;
    object _14315 = NOVALUE;
    object _14314 = NOVALUE;
    object _14312 = NOVALUE;
    object _14311 = NOVALUE;
    object _14309 = NOVALUE;
    object _14307 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:164		if not length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14307 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14307 = 1;
    }
    if (_14307 != 0)
    goto L1; // [8] 18
    _14307 = NOVALUE;

    /** block.e:165			return 0*/
    DeRef(_block_25606);
    DeRef(_block_vars_25619);
    return 0LL;
L1: 

    /** block.e:168		sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14309 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14309 = 1;
    }
    DeRef(_block_25606);
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _block_25606 = (object)*(((s1_ptr)_2)->base + _14309);
    Ref(_block_25606);

    /** block.e:169		block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14311 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14311 = 1;
    }
    _14312 = _14311 - 1LL;
    _14311 = NOVALUE;
    rhs_slice_target = (object_ptr)&_65block_stack_25427;
    RHS_Slice(_65block_stack_25427, 1LL, _14312);

    /** block.e:170		SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (object)SEQ_PTR(_block_25606);
    _14314 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14314))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14314)->dbl));
    else
    _3 = (object)(_14314 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LAST_LINE_21426))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LAST_LINE_21426)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LAST_LINE_21426);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36gline_number_21764;
    DeRef(_1);
    _14315 = NOVALUE;

    /** block.e:172		ifdef BDEBUG then*/

    /** block.e:177		sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_25619);
    _2 = (object)SEQ_PTR(_block_25606);
    _block_vars_25619 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_block_vars_25619);

    /** block.e:178		for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_25619)){
            _14319 = SEQ_PTR(_block_vars_25619)->length;
    }
    else {
        _14319 = 1;
    }
    {
        object _sx_25622;
        _sx_25622 = 1LL;
L2: 
        if (_sx_25622 > _14319){
            goto L3; // [83] 172
        }

        /** block.e:180			if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (object)SEQ_PTR(_block_vars_25619);
        _14320 = (object)*(((s1_ptr)_2)->base + _sx_25622);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_14320)){
            _14321 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14320)->dbl));
        }
        else{
            _14321 = (object)*(((s1_ptr)_2)->base + _14320);
        }
        _2 = (object)SEQ_PTR(_14321);
        _14322 = (object)*(((s1_ptr)_2)->base + 3LL);
        _14321 = NOVALUE;
        if (IS_ATOM_INT(_14322)) {
            _14323 = (_14322 == 1LL);
        }
        else {
            _14323 = binary_op(EQUALS, _14322, 1LL);
        }
        _14322 = NOVALUE;
        if (IS_ATOM_INT(_14323)) {
            if (_14323 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_14323)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (object)SEQ_PTR(_block_vars_25619);
        _14325 = (object)*(((s1_ptr)_2)->base + _sx_25622);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_14325)){
            _14326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14325)->dbl));
        }
        else{
            _14326 = (object)*(((s1_ptr)_2)->base + _14325);
        }
        _2 = (object)SEQ_PTR(_14326);
        _14327 = (object)*(((s1_ptr)_2)->base + 4LL);
        _14326 = NOVALUE;
        if (IS_ATOM_INT(_14327)) {
            _14328 = (_14327 <= 5LL);
        }
        else {
            _14328 = binary_op(LESSEQ, _14327, 5LL);
        }
        _14327 = NOVALUE;
        if (_14328 == 0) {
            DeRef(_14328);
            _14328 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_14328) && DBL_PTR(_14328)->dbl == 0.0){
                DeRef(_14328);
                _14328 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_14328);
            _14328 = NOVALUE;
        }
        DeRef(_14328);
        _14328 = NOVALUE;

        /** block.e:182				ifdef BDEBUG then*/

        /** block.e:187				Hide( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25619);
        _14330 = (object)*(((s1_ptr)_2)->base + _sx_25622);
        Ref(_14330);
        _54Hide(_14330);
        _14330 = NOVALUE;

        /** block.e:188				LintCheck( block_vars[sx] )*/
        _2 = (object)SEQ_PTR(_block_vars_25619);
        _14331 = (object)*(((s1_ptr)_2)->base + _sx_25622);
        Ref(_14331);
        _54LintCheck(_14331);
        _14331 = NOVALUE;
L4: 

        /** block.e:191		end for*/
        _sx_25622 = _sx_25622 + 1LL;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** block.e:213		current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14332 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14332 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14333 = (object)*(((s1_ptr)_2)->base + _14332);
    _2 = (object)SEQ_PTR(_14333);
    _65current_block_25434 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_65current_block_25434)){
        _65current_block_25434 = (object)DBL_PTR(_65current_block_25434)->dbl;
    }
    _14333 = NOVALUE;

    /** block.e:214		return block[BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_block_25606);
    _14335 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14335);
    DeRefDS(_block_25606);
    DeRef(_block_vars_25619);
    DeRef(_14312);
    _14312 = NOVALUE;
    _14314 = NOVALUE;
    _14320 = NOVALUE;
    DeRef(_14323);
    _14323 = NOVALUE;
    _14325 = NOVALUE;
    return _14335;
    ;
}


object _65top_block(object _offset_25651)
{
    object _14343 = NOVALUE;
    object _14342 = NOVALUE;
    object _14341 = NOVALUE;
    object _14340 = NOVALUE;
    object _14339 = NOVALUE;
    object _14338 = NOVALUE;
    object _14336 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:219		if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14336 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14336 = 1;
    }
    if (_offset_25651 < _14336)
    goto L1; // [10] 35

    /** block.e:220			CompileErr(LEAVING_TOO_MANY_BLOCKS_1__2, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14338 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14338 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _offset_25651;
    ((intptr_t *)_2)[2] = _14338;
    _14339 = MAKE_SEQ(_1);
    _14338 = NOVALUE;
    _50CompileErr(107LL, _14339, 0LL);
    _14339 = NOVALUE;
    goto L2; // [32] 59
L1: 

    /** block.e:222			return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14340 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14340 = 1;
    }
    _14341 = _14340 - _offset_25651;
    _14340 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14342 = (object)*(((s1_ptr)_2)->base + _14341);
    _2 = (object)SEQ_PTR(_14342);
    _14343 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14342 = NOVALUE;
    Ref(_14343);
    _14341 = NOVALUE;
    return _14343;
L2: 
    ;
}


void _65End_block(object _opcode_25666)
{
    object _ix_25677 = NOVALUE;
    object _14351 = NOVALUE;
    object _14348 = NOVALUE;
    object _14347 = NOVALUE;
    object _14346 = NOVALUE;
    object _14345 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:229		if opcode = FUNC then*/

    /** block.e:232		check_block( opcode )*/
    _65check_block(_opcode_25666);

    /** block.e:233		if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14345 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14345 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14346 = (object)*(((s1_ptr)_2)->base + _14345);
    _2 = (object)SEQ_PTR(_14346);
    _14347 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14346 = NOVALUE;
    if (IS_SEQUENCE(_14347)){
            _14348 = SEQ_PTR(_14347)->length;
    }
    else {
        _14348 = 1;
    }
    _14347 = NOVALUE;
    if (_14348 != 0)
    goto L1; // [44] 64
    _14348 = NOVALUE;

    /** block.e:234			integer ix = 1*/
    _ix_25677 = 1LL;

    /** block.e:235			ix = pop_block()*/
    _ix_25677 = _65pop_block();
    if (!IS_ATOM_INT(_ix_25677)) {
        _1 = (object)(DBL_PTR(_ix_25677)->dbl);
        DeRefDS(_ix_25677);
        _ix_25677 = _1;
    }
    goto L2; // [61] 80
L1: 

    /** block.e:237			Push( pop_block() )*/
    _14351 = _65pop_block();
    _47Push(_14351);
    _14351 = NOVALUE;

    /** block.e:238			emit_op( EXIT_BLOCK )*/
    _47emit_op(206LL);
L2: 

    /** block.e:241	end procedure*/
    _14347 = NOVALUE;
    return;
    ;
}


object _65End_inline_block(object _opcode_25686)
{
    object _14358 = NOVALUE;
    object _14357 = NOVALUE;
    object _14356 = NOVALUE;
    object _14355 = NOVALUE;
    object _14354 = NOVALUE;
    object _14353 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:246		if opcode = FUNC then*/

    /** block.e:249		if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14353 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14353 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14354 = (object)*(((s1_ptr)_2)->base + _14353);
    _2 = (object)SEQ_PTR(_14354);
    _14355 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14354 = NOVALUE;
    if (IS_SEQUENCE(_14355)){
            _14356 = SEQ_PTR(_14355)->length;
    }
    else {
        _14356 = 1;
    }
    _14355 = NOVALUE;
    if (_14356 == 0)
    {
        _14356 = NOVALUE;
        goto L1; // [39] 60
    }
    else{
        _14356 = NOVALUE;
    }

    /** block.e:250			return { EXIT_BLOCK, pop_block() }*/
    _14357 = _65pop_block();
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206LL;
    ((intptr_t *)_2)[2] = _14357;
    _14358 = MAKE_SEQ(_1);
    _14357 = NOVALUE;
    _14355 = NOVALUE;
    return _14358;
    goto L2; // [57] 72
L1: 

    /** block.e:252			Drop_block( opcode )*/
    _65Drop_block(_opcode_25686);

    /** block.e:253			return {}*/
    RefDS(_5);
    DeRef(_14358);
    _14358 = NOVALUE;
    _14355 = NOVALUE;
    return _5;
L2: 
    ;
}


void _65Sibling_block(object _opcode_25703)
{
    object _0, _1, _2;
    

    /** block.e:261		End_block( opcode )*/
    _65End_block(_opcode_25703);

    /** block.e:262		Start_block( opcode )*/
    _65Start_block(_opcode_25703, 0LL);

    /** block.e:263	end procedure*/
    return;
    ;
}


void _65Leave_block(object _offset_25706)
{
    object _14364 = NOVALUE;
    object _14363 = NOVALUE;
    object _14362 = NOVALUE;
    object _14361 = NOVALUE;
    object _14360 = NOVALUE;
    object _14359 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_25706)) {
        _1 = (object)(DBL_PTR(_offset_25706)->dbl);
        DeRefDS(_offset_25706);
        _offset_25706 = _1;
    }

    /** block.e:268		if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14359 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14359 = 1;
    }
    _14360 = _14359 - _offset_25706;
    _14359 = NOVALUE;
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14361 = (object)*(((s1_ptr)_2)->base + _14360);
    _2 = (object)SEQ_PTR(_14361);
    _14362 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14361 = NOVALUE;
    if (IS_SEQUENCE(_14362)){
            _14363 = SEQ_PTR(_14362)->length;
    }
    else {
        _14363 = 1;
    }
    _14362 = NOVALUE;
    if (_14363 == 0)
    {
        _14363 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _14363 = NOVALUE;
    }

    /** block.e:269			Push( top_block( offset ) )*/
    _14364 = _65top_block(_offset_25706);
    _47Push(_14364);
    _14364 = NOVALUE;

    /** block.e:270			emit_op( EXIT_BLOCK )*/
    _47emit_op(206LL);
L1: 

    /** block.e:272	end procedure*/
    _14362 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    return;
    ;
}


void _65Leave_blocks(object _blocks_25726, object _block_type_25727)
{
    object _bx_25728 = NOVALUE;
    object _Block_opcode_3__tmp_at29_25735 = NOVALUE;
    object _Block_opcode_2__tmp_at29_25734 = NOVALUE;
    object _Block_opcode_1__tmp_at29_25733 = NOVALUE;
    object _Block_opcode_inlined_Block_opcode_at_29_25732 = NOVALUE;
    object _14377 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_25726)) {
        _1 = (object)(DBL_PTR(_blocks_25726)->dbl);
        DeRefDS(_blocks_25726);
        _blocks_25726 = _1;
    }

    /** block.e:284		integer bx = 0*/
    _bx_25728 = 0LL;

    /** block.e:285		while blocks do*/
L1: 
    if (_blocks_25726 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** block.e:286			Leave_block( bx )*/
    _65Leave_block(_bx_25728);

    /** block.e:288			if block_type then*/
    if (_block_type_25727 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** block.e:289				switch Block_opcode( bx ) do*/

    /** block.e:276		return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _Block_opcode_1__tmp_at29_25733 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_25733 = 1;
    }
    _Block_opcode_2__tmp_at29_25734 = _Block_opcode_1__tmp_at29_25733 - _bx_25728;
    DeRef(_Block_opcode_3__tmp_at29_25735);
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _Block_opcode_3__tmp_at29_25735 = (object)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_25734);
    Ref(_Block_opcode_3__tmp_at29_25735);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_25732);
    _2 = (object)SEQ_PTR(_Block_opcode_3__tmp_at29_25735);
    _Block_opcode_inlined_Block_opcode_at_29_25732 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_25732);
    DeRef(_Block_opcode_3__tmp_at29_25735);
    _Block_opcode_3__tmp_at29_25735 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_25732) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_25732)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25732)->dbl != (eudouble) ((object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25732)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (object) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_25732)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_25732;
    };
    switch ( _0 ){ 

        /** block.e:290					case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** block.e:291						if block_type = LOOP_BLOCK then*/
        if (_block_type_25727 != 1LL)
        goto L5; // [67] 108

        /** block.e:292							blocks -= 1*/
        _blocks_25726 = _blocks_25726 - 1LL;
        goto L5; // [78] 108

        /** block.e:294					case else*/
        default:
L4: 

        /** block.e:295						if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_25727 != 2LL)
        goto L6; // [86] 97

        /** block.e:296							blocks -= 1*/
        _blocks_25726 = _blocks_25726 - 1LL;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** block.e:300				blocks -= 1*/
    _blocks_25726 = _blocks_25726 - 1LL;
L5: 

    /** block.e:302			bx += 1*/
    _bx_25728 = _bx_25728 + 1;

    /** block.e:303		end while*/
    goto L1; // [116] 15
L2: 

    /** block.e:304		for i = 0 to blocks - 1 do*/
    _14377 = _blocks_25726 - 1LL;
    if ((object)((uintptr_t)_14377 +(uintptr_t) HIGH_BITS) >= 0){
        _14377 = NewDouble((eudouble)_14377);
    }
    {
        object _i_25753;
        _i_25753 = 0LL;
L7: 
        if (binary_op_a(GREATER, _i_25753, _14377)){
            goto L8; // [125] 144
        }

        /** block.e:305			Leave_block( i )*/
        Ref(_i_25753);
        _65Leave_block(_i_25753);

        /** block.e:306		end for*/
        _0 = _i_25753;
        if (IS_ATOM_INT(_i_25753)) {
            _i_25753 = _i_25753 + 1LL;
            if ((object)((uintptr_t)_i_25753 +(uintptr_t) HIGH_BITS) >= 0){
                _i_25753 = NewDouble((eudouble)_i_25753);
            }
        }
        else {
            _i_25753 = binary_op_a(PLUS, _i_25753, 1LL);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_25753);
    }

    /** block.e:307	end procedure*/
    DeRef(_14377);
    _14377 = NOVALUE;
    return;
    ;
}


void _65Drop_block(object _opcode_25757)
{
    object _x_25759 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:311		check_block( opcode )*/
    _65check_block(_opcode_25757);

    /** block.e:312		symtab_index x = pop_block()*/
    _x_25759 = _65pop_block();
    if (!IS_ATOM_INT(_x_25759)) {
        _1 = (object)(DBL_PTR(_x_25759)->dbl);
        DeRefDS(_x_25759);
        _x_25759 = _1;
    }

    /** block.e:313	end procedure*/
    return;
    ;
}


void _65Pop_block_var()
{
    object _sym_25764 = NOVALUE;
    object _block_sym_25771 = NOVALUE;
    object _14405 = NOVALUE;
    object _14404 = NOVALUE;
    object _14403 = NOVALUE;
    object _14402 = NOVALUE;
    object _14401 = NOVALUE;
    object _14400 = NOVALUE;
    object _14399 = NOVALUE;
    object _14398 = NOVALUE;
    object _14396 = NOVALUE;
    object _14395 = NOVALUE;
    object _14393 = NOVALUE;
    object _14392 = NOVALUE;
    object _14390 = NOVALUE;
    object _14387 = NOVALUE;
    object _14385 = NOVALUE;
    object _14384 = NOVALUE;
    object _14382 = NOVALUE;
    object _14381 = NOVALUE;
    object _14380 = NOVALUE;
    object _14379 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** block.e:316		symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14379 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14379 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14380 = (object)*(((s1_ptr)_2)->base + _14379);
    _2 = (object)SEQ_PTR(_14380);
    _14381 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14380 = NOVALUE;
    if (IS_SEQUENCE(_14381)){
            _14382 = SEQ_PTR(_14381)->length;
    }
    else {
        _14382 = 1;
    }
    _2 = (object)SEQ_PTR(_14381);
    _sym_25764 = (object)*(((s1_ptr)_2)->base + _14382);
    if (!IS_ATOM_INT(_sym_25764)){
        _sym_25764 = (object)DBL_PTR(_sym_25764)->dbl;
    }
    _14381 = NOVALUE;

    /** block.e:317		symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14384 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14384 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14385 = (object)*(((s1_ptr)_2)->base + _14384);
    _2 = (object)SEQ_PTR(_14385);
    _block_sym_25771 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_block_sym_25771)){
        _block_sym_25771 = (object)DBL_PTR(_block_sym_25771)->dbl;
    }
    _14385 = NOVALUE;

    /** block.e:318		while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _14387 = _54sym_next_in_block(_block_sym_25771);
    if (binary_op_a(EQUALS, _14387, _sym_25764)){
        DeRef(_14387);
        _14387 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_14387);
    _14387 = NOVALUE;

    /** block.e:319			block_sym = sym_next_in_block( block_sym )*/
    _block_sym_25771 = _54sym_next_in_block(_block_sym_25771);
    if (!IS_ATOM_INT(_block_sym_25771)) {
        _1 = (object)(DBL_PTR(_block_sym_25771)->dbl);
        DeRefDS(_block_sym_25771);
        _block_sym_25771 = _1;
    }

    /** block.e:320		end while*/
    goto L1; // [65] 47
L2: 

    /** block.e:322		SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_block_sym_25771 + ((s1_ptr)_2)->base);
    _14392 = _54sym_next_in_block(_sym_25764);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21388))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21388)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21388);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14392;
    if( _1 != _14392 ){
        DeRef(_1);
    }
    _14392 = NOVALUE;
    _14390 = NOVALUE;

    /** block.e:323		SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_25764 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21388))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21388)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21388);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _14393 = NOVALUE;

    /** block.e:325		block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14395 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14395 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _65block_stack_25427 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14395 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14398 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14398 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14399 = (object)*(((s1_ptr)_2)->base + _14398);
    _2 = (object)SEQ_PTR(_14399);
    _14400 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14399 = NOVALUE;
    if (IS_SEQUENCE(_65block_stack_25427)){
            _14401 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _14401 = 1;
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14402 = (object)*(((s1_ptr)_2)->base + _14401);
    _2 = (object)SEQ_PTR(_14402);
    _14403 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14402 = NOVALUE;
    if (IS_SEQUENCE(_14403)){
            _14404 = SEQ_PTR(_14403)->length;
    }
    else {
        _14404 = 1;
    }
    _14403 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_14400);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14404)) ? _14404 : (object)(DBL_PTR(_14404)->dbl);
        int stop = (IS_ATOM_INT(_14404)) ? _14404 : (object)(DBL_PTR(_14404)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_14400);
            DeRef(_14405);
            _14405 = _14400;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_14400), start, &_14405 );
            }
            else Tail(SEQ_PTR(_14400), stop+1, &_14405);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_14400), start, &_14405);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_14405);
            _14405 = _1;
        }
    }
    _14400 = NOVALUE;
    _14404 = NOVALUE;
    _14404 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14405;
    if( _1 != _14405 ){
        DeRef(_1);
    }
    _14405 = NOVALUE;
    _14396 = NOVALUE;

    /** block.e:327	end procedure*/
    _14403 = NOVALUE;
    return;
    ;
}


void _65Goto_block(object _from_block_25805, object _to_block_25807, object _pc_25808)
{
    object _code_25809 = NOVALUE;
    object _next_block_25811 = NOVALUE;
    object _14416 = NOVALUE;
    object _14413 = NOVALUE;
    object _14412 = NOVALUE;
    object _14411 = NOVALUE;
    object _14410 = NOVALUE;
    object _14409 = NOVALUE;
    object _14408 = NOVALUE;
    object _14407 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_25805)) {
        _1 = (object)(DBL_PTR(_from_block_25805)->dbl);
        DeRefDS(_from_block_25805);
        _from_block_25805 = _1;
    }
    if (!IS_ATOM_INT(_to_block_25807)) {
        _1 = (object)(DBL_PTR(_to_block_25807)->dbl);
        DeRefDS(_to_block_25807);
        _to_block_25807 = _1;
    }
    if (!IS_ATOM_INT(_pc_25808)) {
        _1 = (object)(DBL_PTR(_pc_25808)->dbl);
        DeRefDS(_pc_25808);
        _pc_25808 = _1;
    }

    /** block.e:330		sequence code = {}*/
    RefDS(_5);
    DeRefi(_code_25809);
    _code_25809 = _5;

    /** block.e:331		symtab_index next_block = sym_block( from_block )*/
    _next_block_25811 = _54sym_block(_from_block_25805);
    if (!IS_ATOM_INT(_next_block_25811)) {
        _1 = (object)(DBL_PTR(_next_block_25811)->dbl);
        DeRefDS(_next_block_25811);
        _next_block_25811 = _1;
    }

    /** block.e:332		while next_block */
L1: 
    if (_next_block_25811 == 0) {
        _14407 = 0;
        goto L2; // [27] 39
    }
    _14408 = (_from_block_25805 != _to_block_25807);
    _14407 = (_14408 != 0);
L2: 
    if (_14407 == 0) {
        goto L3; // [39] 93
    }
    _14410 = _54sym_token(_next_block_25811);
    _14411 = find_from(_14410, _38RTN_TOKS_16291, 1LL);
    DeRef(_14410);
    _14410 = NOVALUE;
    _14412 = (_14411 == 0);
    _14411 = NOVALUE;
    if (_14412 == 0)
    {
        DeRef(_14412);
        _14412 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_14412);
        _14412 = NOVALUE;
    }

    /** block.e:335			code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 206LL;
    ((intptr_t *)_2)[2] = _from_block_25805;
    _14413 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_25809, _code_25809, _14413);
    DeRefDS(_14413);
    _14413 = NOVALUE;

    /** block.e:336			from_block = next_block*/
    _from_block_25805 = _next_block_25811;

    /** block.e:337			next_block = sym_block( next_block )*/
    _next_block_25811 = _54sym_block(_next_block_25811);
    if (!IS_ATOM_INT(_next_block_25811)) {
        _1 = (object)(DBL_PTR(_next_block_25811)->dbl);
        DeRefDS(_next_block_25811);
        _next_block_25811 = _1;
    }

    /** block.e:338		end while*/
    goto L1; // [90] 27
L3: 

    /** block.e:340		if length(code) then*/
    if (IS_SEQUENCE(_code_25809)){
            _14416 = SEQ_PTR(_code_25809)->length;
    }
    else {
        _14416 = 1;
    }
    if (_14416 == 0)
    {
        _14416 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _14416 = NOVALUE;
    }

    /** block.e:341			if pc then*/
    if (_pc_25808 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** block.e:342				insert_code( code, pc )*/
    RefDS(_code_25809);
    _66insert_code(_code_25809, _pc_25808);
    goto L6; // [112] 126
L5: 

    /** block.e:344				Code &= code*/
    Concat((object_ptr)&_36Code_21851, _36Code_21851, _code_25809);
L6: 
L4: 

    /** block.e:348	end procedure*/
    DeRefi(_code_25809);
    DeRef(_14408);
    _14408 = NOVALUE;
    return;
    ;
}


object _65Least_block()
{
    object _ix_25839 = NOVALUE;
    object _sub_block_25842 = NOVALUE;
    object _14430 = NOVALUE;
    object _14429 = NOVALUE;
    object _14427 = NOVALUE;
    object _14426 = NOVALUE;
    object _14425 = NOVALUE;
    object _14424 = NOVALUE;
    object _14423 = NOVALUE;
    object _14422 = NOVALUE;
    object _14421 = NOVALUE;
    object _14420 = NOVALUE;
    object _0, _1, _2;
    

    /** block.e:358		integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_65block_stack_25427)){
            _ix_25839 = SEQ_PTR(_65block_stack_25427)->length;
    }
    else {
        _ix_25839 = 1;
    }

    /** block.e:359		symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_25842 = _54sym_block(_36CurrentSub_21767);
    if (!IS_ATOM_INT(_sub_block_25842)) {
        _1 = (object)(DBL_PTR(_sub_block_25842)->dbl);
        DeRefDS(_sub_block_25842);
        _sub_block_25842 = _1;
    }

    /** block.e:360		while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14420 = (object)*(((s1_ptr)_2)->base + _ix_25839);
    _2 = (object)SEQ_PTR(_14420);
    _14421 = (object)*(((s1_ptr)_2)->base + 6LL);
    _14420 = NOVALUE;
    if (IS_SEQUENCE(_14421)){
            _14422 = SEQ_PTR(_14421)->length;
    }
    else {
        _14422 = 1;
    }
    _14421 = NOVALUE;
    _14423 = (_14422 == 0);
    _14422 = NOVALUE;
    if (_14423 == 0) {
        goto L2; // [39] 72
    }
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14425 = (object)*(((s1_ptr)_2)->base + _ix_25839);
    _2 = (object)SEQ_PTR(_14425);
    _14426 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14425 = NOVALUE;
    if (IS_ATOM_INT(_14426)) {
        _14427 = (_14426 != _sub_block_25842);
    }
    else {
        _14427 = binary_op(NOTEQ, _14426, _sub_block_25842);
    }
    _14426 = NOVALUE;
    if (_14427 <= 0) {
        if (_14427 == 0) {
            DeRef(_14427);
            _14427 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_14427) && DBL_PTR(_14427)->dbl == 0.0){
                DeRef(_14427);
                _14427 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_14427);
            _14427 = NOVALUE;
        }
    }
    DeRef(_14427);
    _14427 = NOVALUE;

    /** block.e:362			ix -= 1	*/
    _ix_25839 = _ix_25839 - 1LL;

    /** block.e:363		end while*/
    goto L1; // [69] 23
L2: 

    /** block.e:364		return block_stack[ix][BLOCK_SYM]*/
    _2 = (object)SEQ_PTR(_65block_stack_25427);
    _14429 = (object)*(((s1_ptr)_2)->base + _ix_25839);
    _2 = (object)SEQ_PTR(_14429);
    _14430 = (object)*(((s1_ptr)_2)->base + 1LL);
    _14429 = NOVALUE;
    Ref(_14430);
    DeRef(_14423);
    _14423 = NOVALUE;
    _14421 = NOVALUE;
    return _14430;
    ;
}



// 0x4B46F948
