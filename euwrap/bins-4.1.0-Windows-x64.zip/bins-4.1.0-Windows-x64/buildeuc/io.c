// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _8get_integer32(object _fh_9953)
{
    object _c_9954 = NOVALUE;
    object _5594 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:525		c = getc(fh)*/
    if (_fh_9953 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9953, EF_READ);
        last_r_file_no = _fh_9953;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9954 = getKBchar();
        }
        else{
            _c_9954 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9954 = getc(last_r_file_ptr);
    }

    /** io.e:526		poke(mem0, c)*/
    if (IS_ATOM_INT(_8mem0_9943)){
        poke_addr = (uint8_t *)_8mem0_9943;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem0_9943)->dbl);
    }
    *poke_addr = (uint8_t)_c_9954;

    /** io.e:527		c = getc(fh)*/
    if (_fh_9953 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9953, EF_READ);
        last_r_file_no = _fh_9953;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9954 = getKBchar();
        }
        else{
            _c_9954 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9954 = getc(last_r_file_ptr);
    }

    /** io.e:528		poke(mem1, c)*/
    if (IS_ATOM_INT(_8mem1_9944)){
        poke_addr = (uint8_t *)_8mem1_9944;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem1_9944)->dbl);
    }
    *poke_addr = (uint8_t)_c_9954;

    /** io.e:529		c = getc(fh)*/
    if (_fh_9953 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9953, EF_READ);
        last_r_file_no = _fh_9953;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9954 = getKBchar();
        }
        else{
            _c_9954 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9954 = getc(last_r_file_ptr);
    }

    /** io.e:530		poke(mem2, c)*/
    if (IS_ATOM_INT(_8mem2_9945)){
        poke_addr = (uint8_t *)_8mem2_9945;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem2_9945)->dbl);
    }
    *poke_addr = (uint8_t)_c_9954;

    /** io.e:531		c = getc(fh)*/
    if (_fh_9953 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9953, EF_READ);
        last_r_file_no = _fh_9953;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9954 = getKBchar();
        }
        else{
            _c_9954 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9954 = getc(last_r_file_ptr);
    }

    /** io.e:532		if c = -1 then*/
    if (_c_9954 != -1LL)
    goto L1; // [46] 57

    /** io.e:533			return -1*/
    return -1LL;
L1: 

    /** io.e:535		poke(mem3, c)*/
    if (IS_ATOM_INT(_8mem3_9946)){
        poke_addr = (uint8_t *)_8mem3_9946;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem3_9946)->dbl);
    }
    *poke_addr = (uint8_t)_c_9954;

    /** io.e:536		return peek4u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9943)) {
        _5594 = (object)*(uint32_t *)_8mem0_9943;
        if ((uintptr_t)_5594 > (uintptr_t)MAXINT){
            _5594 = NewDouble((eudouble)(uintptr_t)_5594);
        }
    }
    else {
        _5594 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_8mem0_9943)->dbl);
        if ((uintptr_t)_5594 > (uintptr_t)MAXINT){
            _5594 = NewDouble((eudouble)(uintptr_t)_5594);
        }
    }
    return _5594;
    ;
}


object _8get_integer16(object _fh_9964)
{
    object _c_9965 = NOVALUE;
    object _5598 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:568		c = getc(fh)*/
    if (_fh_9964 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9964, EF_READ);
        last_r_file_no = _fh_9964;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9965 = getKBchar();
        }
        else{
            _c_9965 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9965 = getc(last_r_file_ptr);
    }

    /** io.e:569		poke(mem0, c)*/
    if (IS_ATOM_INT(_8mem0_9943)){
        poke_addr = (uint8_t *)_8mem0_9943;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem0_9943)->dbl);
    }
    *poke_addr = (uint8_t)_c_9965;

    /** io.e:570		c = getc(fh)*/
    if (_fh_9964 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9964, EF_READ);
        last_r_file_no = _fh_9964;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_9965 = getKBchar();
        }
        else{
            _c_9965 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_9965 = getc(last_r_file_ptr);
    }

    /** io.e:571		if c = -1 then*/
    if (_c_9965 != -1LL)
    goto L1; // [22] 33

    /** io.e:572			return -1*/
    return -1LL;
L1: 

    /** io.e:574		poke(mem1, c)*/
    if (IS_ATOM_INT(_8mem1_9944)){
        poke_addr = (uint8_t *)_8mem1_9944;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_8mem1_9944)->dbl);
    }
    *poke_addr = (uint8_t)_c_9965;

    /** io.e:575		return peek2u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9943)) {
        _5598 = *(uint16_t *)_8mem0_9943;
    }
    else {
        _5598 = *(uint16_t *)(uintptr_t)(DBL_PTR(_8mem0_9943)->dbl);
    }
    return _5598;
    ;
}


object _8seek(object _fn_10060, object _pos_10061)
{
    object _5644 = NOVALUE;
    object _5643 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_10061);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn_10060;
    ((intptr_t *)_2)[2] = _pos_10061;
    _5643 = MAKE_SEQ(_1);
    _5644 = machine(19LL, _5643);
    DeRefDS(_5643);
    _5643 = NOVALUE;
    DeRef(_pos_10061);
    return _5644;
    ;
}


object _8where(object _fn_10066)
{
    object _5645 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    _5645 = machine(20LL, _fn_10066);
    return _5645;
    ;
}


object _8read_lines(object _file_10085)
{
    object _fn_10086 = NOVALUE;
    object _ret_10087 = NOVALUE;
    object _y_10088 = NOVALUE;
    object _5667 = NOVALUE;
    object _5666 = NOVALUE;
    object _5665 = NOVALUE;
    object _5664 = NOVALUE;
    object _5659 = NOVALUE;
    object _5658 = NOVALUE;
    object _5656 = NOVALUE;
    object _5655 = NOVALUE;
    object _5654 = NOVALUE;
    object _5650 = NOVALUE;
    object _5649 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1127		if sequence(file) then*/
    _5649 = 1;
    if (_5649 == 0)
    {
        _5649 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _5649 = NOVALUE;
    }

    /** io.e:1128			if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_10085)){
            _5650 = SEQ_PTR(_file_10085)->length;
    }
    else {
        _5650 = 1;
    }
    if (_5650 != 0LL)
    goto L2; // [14] 26

    /** io.e:1129				fn = 0*/
    DeRef(_fn_10086);
    _fn_10086 = 0LL;
    goto L3; // [23] 43
L2: 

    /** io.e:1131				fn = open(file, "r")*/
    DeRef(_fn_10086);
    _fn_10086 = EOpen(_file_10085, _3921, 0LL);
    goto L3; // [34] 43
L1: 

    /** io.e:1134			fn = file*/
    Ref(_file_10085);
    DeRef(_fn_10086);
    _fn_10086 = _file_10085;
L3: 

    /** io.e:1136		if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_10086, 0LL)){
        goto L4; // [47] 56
    }
    DeRef(_file_10085);
    DeRef(_fn_10086);
    DeRef(_ret_10087);
    DeRefi(_y_10088);
    return -1LL;
L4: 

    /** io.e:1138		ret = {}*/
    RefDS(_5);
    DeRef(_ret_10087);
    _ret_10087 = _5;

    /** io.e:1139		while sequence(y) with entry do*/
    goto L5; // [63] 125
L6: 
    _5654 = IS_SEQUENCE(_y_10088);
    if (_5654 == 0)
    {
        _5654 = NOVALUE;
        goto L7; // [71] 135
    }
    else{
        _5654 = NOVALUE;
    }

    /** io.e:1140			if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_10088)){
            _5655 = SEQ_PTR(_y_10088)->length;
    }
    else {
        _5655 = 1;
    }
    _2 = (object)SEQ_PTR(_y_10088);
    _5656 = (object)*(((s1_ptr)_2)->base + _5655);
    if (_5656 != 10LL)
    goto L8; // [83] 104

    /** io.e:1141				y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_10088)){
            _5658 = SEQ_PTR(_y_10088)->length;
    }
    else {
        _5658 = 1;
    }
    _5659 = _5658 - 1LL;
    _5658 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_10088;
    RHS_Slice(_y_10088, 1LL, _5659);

    /** io.e:1142				ifdef UNIX then*/
L8: 

    /** io.e:1150			ret = append(ret, y)*/
    Ref(_y_10088);
    Append(&_ret_10087, _ret_10087, _y_10088);

    /** io.e:1151			if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_10086, 0LL)){
        goto L9; // [112] 122
    }

    /** io.e:1152				puts(2, '\n')*/
    EPuts(2LL, 10LL); // DJP 
L9: 

    /** io.e:1154		entry*/
L5: 

    /** io.e:1155			y = gets(fn)*/
    DeRefi(_y_10088);
    _y_10088 = EGets(_fn_10086);

    /** io.e:1156		end while*/
    goto L6; // [132] 66
L7: 

    /** io.e:1158		if sequence(file) and length(file) != 0 then*/
    _5664 = IS_SEQUENCE(_file_10085);
    if (_5664 == 0) {
        goto LA; // [140] 160
    }
    if (IS_SEQUENCE(_file_10085)){
            _5666 = SEQ_PTR(_file_10085)->length;
    }
    else {
        _5666 = 1;
    }
    _5667 = (_5666 != 0LL);
    _5666 = NOVALUE;
    if (_5667 == 0)
    {
        DeRef(_5667);
        _5667 = NOVALUE;
        goto LA; // [152] 160
    }
    else{
        DeRef(_5667);
        _5667 = NOVALUE;
    }

    /** io.e:1159			close(fn)*/
    if (IS_ATOM_INT(_fn_10086))
    EClose(_fn_10086);
    else
    EClose((object)DBL_PTR(_fn_10086)->dbl);
LA: 

    /** io.e:1162		return ret*/
    DeRef(_file_10085);
    DeRef(_fn_10086);
    DeRefi(_y_10088);
    _5656 = NOVALUE;
    DeRef(_5659);
    _5659 = NOVALUE;
    return _ret_10087;
    ;
}


object _8write_lines(object _file_10161, object _lines_10162)
{
    object _fn_10163 = NOVALUE;
    object _5697 = NOVALUE;
    object _5696 = NOVALUE;
    object _5695 = NOVALUE;
    object _5691 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1285		if sequence(file) then*/
    _5691 = 1;
    if (_5691 == 0)
    {
        _5691 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _5691 = NOVALUE;
    }

    /** io.e:1286	    	fn = open(file, "w")*/
    DeRef(_fn_10163);
    _fn_10163 = EOpen(_file_10161, _5692, 0LL);
    goto L2; // [18] 27
L1: 

    /** io.e:1288			fn = file*/
    Ref(_file_10161);
    DeRef(_fn_10163);
    _fn_10163 = _file_10161;
L2: 

    /** io.e:1290		if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_10163, 0LL)){
        goto L3; // [31] 40
    }
    DeRef(_file_10161);
    DeRefDS(_lines_10162);
    DeRef(_fn_10163);
    return -1LL;
L3: 

    /** io.e:1292		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_10162)){
            _5695 = SEQ_PTR(_lines_10162)->length;
    }
    else {
        _5695 = 1;
    }
    {
        object _i_10172;
        _i_10172 = 1LL;
L4: 
        if (_i_10172 > _5695){
            goto L5; // [45] 73
        }

        /** io.e:1293			puts(fn, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_10162);
        _5696 = (object)*(((s1_ptr)_2)->base + _i_10172);
        EPuts(_fn_10163, _5696); // DJP 
        _5696 = NOVALUE;

        /** io.e:1294			puts(fn, '\n')*/
        EPuts(_fn_10163, 10LL); // DJP 

        /** io.e:1295		end for*/
        _i_10172 = _i_10172 + 1LL;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** io.e:1297		if sequence(file) then*/
    _5697 = IS_SEQUENCE(_file_10161);
    if (_5697 == 0)
    {
        _5697 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _5697 = NOVALUE;
    }

    /** io.e:1298			close(fn)*/
    if (IS_ATOM_INT(_fn_10163))
    EClose(_fn_10163);
    else
    EClose((object)DBL_PTR(_fn_10163)->dbl);
L6: 

    /** io.e:1301		return 1*/
    DeRef(_file_10161);
    DeRefDS(_lines_10162);
    DeRef(_fn_10163);
    return 1LL;
    ;
}


object _8write_file(object _file_10248, object _data_10249, object _as_text_10250)
{
    object _fn_10251 = NOVALUE;
    object _5747 = NOVALUE;
    object _5742 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1496		if as_text != BINARY_MODE then*/

    /** io.e:1525		if sequence(file) then*/
    _5742 = 1;
    if (_5742 == 0)
    {
        _5742 = NOVALUE;
        goto L1; // [151] 181
    }
    else{
        _5742 = NOVALUE;
    }

    /** io.e:1526			if as_text = TEXT_MODE then*/

    /** io.e:1529				fn = open(file, "wb")*/
    _fn_10251 = EOpen(_file_10248, _3245, 0LL);
    goto L2; // [178] 189
L1: 

    /** io.e:1532			fn = file*/
    Ref(_file_10248);
    _fn_10251 = _file_10248;
    if (!IS_ATOM_INT(_fn_10251)) {
        _1 = (object)(DBL_PTR(_fn_10251)->dbl);
        DeRefDS(_fn_10251);
        _fn_10251 = _1;
    }
L2: 

    /** io.e:1534		if fn < 0 then return -1 end if*/
    if (_fn_10251 >= 0LL)
    goto L3; // [193] 202
    DeRefi(_file_10248);
    DeRefDS(_data_10249);
    return -1LL;
L3: 

    /** io.e:1536		puts(fn, data)*/
    EPuts(_fn_10251, _data_10249); // DJP 

    /** io.e:1538		if sequence(file) then*/
    _5747 = IS_SEQUENCE(_file_10248);
    if (_5747 == 0)
    {
        _5747 = NOVALUE;
        goto L4; // [212] 220
    }
    else{
        _5747 = NOVALUE;
    }

    /** io.e:1539			close(fn)*/
    EClose(_fn_10251);
L4: 

    /** io.e:1542		return 1*/
    DeRefi(_file_10248);
    DeRefDS(_data_10249);
    return 1LL;
    ;
}


void _8writef(object _fm_10291, object _data_10292, object _fn_10293, object _data_not_string_10294)
{
    object _real_fn_10295 = NOVALUE;
    object _close_fn_10296 = NOVALUE;
    object _out_style_10297 = NOVALUE;
    object _ts_10300 = NOVALUE;
    object _msg_inlined_crash_at_163_10325 = NOVALUE;
    object _data_inlined_crash_at_160_10324 = NOVALUE;
    object _5767 = NOVALUE;
    object _5765 = NOVALUE;
    object _5764 = NOVALUE;
    object _5763 = NOVALUE;
    object _5757 = NOVALUE;
    object _5756 = NOVALUE;
    object _5755 = NOVALUE;
    object _5754 = NOVALUE;
    object _5753 = NOVALUE;
    object _5752 = NOVALUE;
    object _5750 = NOVALUE;
    object _5749 = NOVALUE;
    object _5748 = NOVALUE;
    object _0, _1, _2;
    

    /** io.e:1608		integer real_fn = 0*/
    _real_fn_10295 = 0LL;

    /** io.e:1609		integer close_fn = 0*/
    _close_fn_10296 = 0LL;

    /** io.e:1610		sequence out_style = "w"*/
    RefDS(_5692);
    DeRefi(_out_style_10297);
    _out_style_10297 = _5692;

    /** io.e:1612		if integer(fm) then*/
    _5748 = 1;
    if (_5748 == 0)
    {
        _5748 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _5748 = NOVALUE;
    }

    /** io.e:1613			object ts*/

    /** io.e:1615			ts = fm*/
    _ts_10300 = _fm_10291;

    /** io.e:1616			fm = data*/
    RefDS(_data_10292);
    _fm_10291 = _data_10292;

    /** io.e:1617			data = fn*/
    RefDS(_fn_10293);
    DeRefDS(_data_10292);
    _data_10292 = _fn_10293;

    /** io.e:1618			fn = ts*/
    DeRefDS(_fn_10293);
    _fn_10293 = _ts_10300;
L1: 

    /** io.e:1621		if sequence(fn) then*/
    _5749 = IS_SEQUENCE(_fn_10293);
    if (_5749 == 0)
    {
        _5749 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _5749 = NOVALUE;
    }

    /** io.e:1622			if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_10293)){
            _5750 = SEQ_PTR(_fn_10293)->length;
    }
    else {
        _5750 = 1;
    }
    if (_5750 != 2LL)
    goto L3; // [64] 142

    /** io.e:1623				if sequence(fn[1]) then*/
    _2 = (object)SEQ_PTR(_fn_10293);
    _5752 = (object)*(((s1_ptr)_2)->base + 1LL);
    _5753 = IS_SEQUENCE(_5752);
    _5752 = NOVALUE;
    if (_5753 == 0)
    {
        _5753 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _5753 = NOVALUE;
    }

    /** io.e:1624					if equal(fn[2], 'a') then*/
    _2 = (object)SEQ_PTR(_fn_10293);
    _5754 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_5754 == 97LL)
    _5755 = 1;
    else if (IS_ATOM_INT(_5754) && IS_ATOM_INT(97LL))
    _5755 = 0;
    else
    _5755 = (compare(_5754, 97LL) == 0);
    _5754 = NOVALUE;
    if (_5755 == 0)
    {
        _5755 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _5755 = NOVALUE;
    }

    /** io.e:1625						out_style = "a"*/
    RefDS(_5698);
    DeRefi(_out_style_10297);
    _out_style_10297 = _5698;
    goto L6; // [100] 134
L5: 

    /** io.e:1626					elsif not equal(fn[2], "a") then*/
    _2 = (object)SEQ_PTR(_fn_10293);
    _5756 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_5756 == _5698)
    _5757 = 1;
    else if (IS_ATOM_INT(_5756) && IS_ATOM_INT(_5698))
    _5757 = 0;
    else
    _5757 = (compare(_5756, _5698) == 0);
    _5756 = NOVALUE;
    if (_5757 != 0)
    goto L7; // [113] 126
    _5757 = NOVALUE;

    /** io.e:1627						out_style = "w"*/
    RefDS(_5692);
    DeRefi(_out_style_10297);
    _out_style_10297 = _5692;
    goto L6; // [123] 134
L7: 

    /** io.e:1629						out_style = "a"*/
    RefDS(_5698);
    DeRefi(_out_style_10297);
    _out_style_10297 = _5698;
L6: 

    /** io.e:1631					fn = fn[1]*/
    _0 = _fn_10293;
    _2 = (object)SEQ_PTR(_fn_10293);
    _fn_10293 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_fn_10293);
    DeRef(_0);
L4: 
L3: 

    /** io.e:1634			real_fn = open(fn, out_style)*/
    _real_fn_10295 = EOpen(_fn_10293, _out_style_10297, 0LL);

    /** io.e:1636			if real_fn = -1 then*/
    if (_real_fn_10295 != -1LL)
    goto L8; // [151] 183

    /** io.e:1637				error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_fn_10293);
    ((intptr_t*)_2)[1] = _fn_10293;
    _5763 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_10324);
    _data_inlined_crash_at_160_10324 = _5763;
    _5763 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_10325);
    _msg_inlined_crash_at_163_10325 = EPrintf(-9999999, _5762, _data_inlined_crash_at_160_10324);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_163_10325);

    /** error.e:53	end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_10324);
    _data_inlined_crash_at_160_10324 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_10325);
    _msg_inlined_crash_at_163_10325 = NOVALUE;
L8: 

    /** io.e:1639			close_fn = 1*/
    _close_fn_10296 = 1LL;
    goto LA; // [188] 199
L2: 

    /** io.e:1641			real_fn = fn*/
    Ref(_fn_10293);
    _real_fn_10295 = _fn_10293;
    if (!IS_ATOM_INT(_real_fn_10295)) {
        _1 = (object)(DBL_PTR(_real_fn_10295)->dbl);
        DeRefDS(_real_fn_10295);
        _real_fn_10295 = _1;
    }
LA: 

    /** io.e:1644		if equal(data_not_string, 0) then*/
    if (_data_not_string_10294 == 0LL)
    _5764 = 1;
    else if (IS_ATOM_INT(_data_not_string_10294) && IS_ATOM_INT(0LL))
    _5764 = 0;
    else
    _5764 = (compare(_data_not_string_10294, 0LL) == 0);
    if (_5764 == 0)
    {
        _5764 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _5764 = NOVALUE;
    }

    /** io.e:1645			if types:t_display(data) then*/
    Ref(_data_10292);
    _5765 = _13t_display(_data_10292);
    if (_5765 == 0) {
        DeRef(_5765);
        _5765 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_5765) && DBL_PTR(_5765)->dbl == 0.0){
            DeRef(_5765);
            _5765 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_5765);
        _5765 = NOVALUE;
    }
    DeRef(_5765);
    _5765 = NOVALUE;

    /** io.e:1646				data = {data}*/
    _0 = _data_10292;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_data_10292);
    ((intptr_t*)_2)[1] = _data_10292;
    _data_10292 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /** io.e:1649	    puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_10291);
    Ref(_data_10292);
    _5767 = _14format(_fm_10291, _data_10292);
    EPuts(_real_fn_10295, _5767); // DJP 
    DeRef(_5767);
    _5767 = NOVALUE;

    /** io.e:1650	    if close_fn then*/
    if (_close_fn_10296 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /** io.e:1651	    	close(real_fn)*/
    EClose(_real_fn_10295);
LD: 

    /** io.e:1653	end procedure*/
    DeRef(_fm_10291);
    DeRef(_data_10292);
    DeRef(_fn_10293);
    DeRefi(_out_style_10297);
    return;
    ;
}



// 0xF80603CC
