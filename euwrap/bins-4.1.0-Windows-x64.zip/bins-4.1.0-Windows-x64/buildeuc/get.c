// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _6get_ch()
{
    object _6077 = NOVALUE;
    object _6076 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:47		if sequence(input_string) then*/
    _6076 = IS_SEQUENCE(_6input_string_10843);
    if (_6076 == 0)
    {
        _6076 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _6076 = NOVALUE;
    }

    /** get.e:48			if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_6input_string_10843)){
            _6077 = SEQ_PTR(_6input_string_10843)->length;
    }
    else {
        _6077 = 1;
    }
    if (_6string_next_10844 > _6077)
    goto L2; // [20] 47

    /** get.e:49				ch = input_string[string_next]*/
    _2 = (object)SEQ_PTR(_6input_string_10843);
    _6ch_10845 = (object)*(((s1_ptr)_2)->base + _6string_next_10844);
    if (!IS_ATOM_INT(_6ch_10845)){
        _6ch_10845 = (object)DBL_PTR(_6ch_10845)->dbl;
    }

    /** get.e:50				string_next += 1*/
    _6string_next_10844 = _6string_next_10844 + 1;
    goto L3; // [44] 81
L2: 

    /** get.e:52				ch = GET_EOF*/
    _6ch_10845 = -1LL;
    goto L3; // [53] 81
L1: 

    /** get.e:55			ch = getc(input_file)*/
    if (_6input_file_10842 != last_r_file_no) {
        last_r_file_ptr = which_file(_6input_file_10842, EF_READ);
        last_r_file_no = _6input_file_10842;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _6ch_10845 = getKBchar();
        }
        else{
            _6ch_10845 = getc(last_r_file_ptr);
        }
    }
    else{
        _6ch_10845 = getc(last_r_file_ptr);
    }

    /** get.e:56			if ch = GET_EOF then*/
    if (_6ch_10845 != -1LL)
    goto L4; // [67] 80

    /** get.e:57				string_next += 1*/
    _6string_next_10844 = _6string_next_10844 + 1;
L4: 
L3: 

    /** get.e:60	end procedure*/
    return;
    ;
}


object _6escape_char(object _c_10872)
{
    object _i_10873 = NOVALUE;
    object _6089 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:79		i = find(c, ESCAPE_CHARS)*/
    _i_10873 = find_from(_c_10872, _6ESCAPE_CHARS_10866, 1LL);

    /** get.e:80		if i = 0 then*/
    if (_i_10873 != 0LL)
    goto L1; // [12] 25

    /** get.e:81			return GET_FAIL*/
    return 1LL;
    goto L2; // [22] 36
L1: 

    /** get.e:83			return ESCAPED_CHARS[i]*/
    _2 = (object)SEQ_PTR(_6ESCAPED_CHARS_10868);
    _6089 = (object)*(((s1_ptr)_2)->base + _i_10873);
    Ref(_6089);
    return _6089;
L2: 
    ;
}


object _6get_qchar()
{
    object _c_10881 = NOVALUE;
    object _6098 = NOVALUE;
    object _6097 = NOVALUE;
    object _6095 = NOVALUE;
    object _6093 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:92		get_ch()*/
    _6get_ch();

    /** get.e:93		c = ch*/
    _c_10881 = _6ch_10845;

    /** get.e:94		if ch = '\\' then*/
    if (_6ch_10845 != 92LL)
    goto L1; // [16] 54

    /** get.e:95			get_ch()*/
    _6get_ch();

    /** get.e:96			c = escape_char(ch)*/
    _c_10881 = _6escape_char(_6ch_10845);
    if (!IS_ATOM_INT(_c_10881)) {
        _1 = (object)(DBL_PTR(_c_10881)->dbl);
        DeRefDS(_c_10881);
        _c_10881 = _1;
    }

    /** get.e:97			if c = GET_FAIL then*/
    if (_c_10881 != 1LL)
    goto L2; // [36] 74

    /** get.e:98				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6093 = MAKE_SEQ(_1);
    return _6093;
    goto L2; // [51] 74
L1: 

    /** get.e:100		elsif ch = '\'' then*/
    if (_6ch_10845 != 39LL)
    goto L3; // [58] 73

    /** get.e:101			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6095 = MAKE_SEQ(_1);
    DeRef(_6093);
    _6093 = NOVALUE;
    return _6095;
L3: 
L2: 

    /** get.e:103		get_ch()*/
    _6get_ch();

    /** get.e:104		if ch != '\'' then*/
    if (_6ch_10845 == 39LL)
    goto L4; // [82] 99

    /** get.e:105			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6097 = MAKE_SEQ(_1);
    DeRef(_6093);
    _6093 = NOVALUE;
    DeRef(_6095);
    _6095 = NOVALUE;
    return _6097;
    goto L5; // [96] 114
L4: 

    /** get.e:107			get_ch()*/
    _6get_ch();

    /** get.e:108			return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _c_10881;
    _6098 = MAKE_SEQ(_1);
    DeRef(_6093);
    _6093 = NOVALUE;
    DeRef(_6097);
    _6097 = NOVALUE;
    DeRef(_6095);
    _6095 = NOVALUE;
    return _6098;
L5: 
    ;
}


object _6get_heredoc(object _terminator_10898)
{
    object _text_10899 = NOVALUE;
    object _ends_at_10900 = NOVALUE;
    object _6113 = NOVALUE;
    object _6112 = NOVALUE;
    object _6111 = NOVALUE;
    object _6110 = NOVALUE;
    object _6109 = NOVALUE;
    object _6106 = NOVALUE;
    object _6104 = NOVALUE;
    object _6103 = NOVALUE;
    object _6102 = NOVALUE;
    object _6101 = NOVALUE;
    object _6099 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:113		sequence text = ""*/
    RefDS(_5);
    DeRefi(_text_10899);
    _text_10899 = _5;

    /** get.e:114		integer ends_at = 1 - length( terminator )*/
    if (IS_SEQUENCE(_terminator_10898)){
            _6099 = SEQ_PTR(_terminator_10898)->length;
    }
    else {
        _6099 = 1;
    }
    _ends_at_10900 = 1LL - _6099;
    _6099 = NOVALUE;

    /** get.e:115		while ends_at < 1 or not match( terminator, text, ends_at ) with entry do*/
    goto L1; // [21] 69
L2: 
    _6101 = (_ends_at_10900 < 1LL);
    if (_6101 != 0) {
        DeRef(_6102);
        _6102 = 1;
        goto L3; // [28] 44
    }
    _6103 = e_match_from(_terminator_10898, _text_10899, _ends_at_10900);
    _6104 = (_6103 == 0);
    _6103 = NOVALUE;
    _6102 = (_6104 != 0);
L3: 
    if (_6102 == 0)
    {
        _6102 = NOVALUE;
        goto L4; // [44] 92
    }
    else{
        _6102 = NOVALUE;
    }

    /** get.e:116			if ch = GET_EOF then*/
    if (_6ch_10845 != -1LL)
    goto L5; // [51] 66

    /** get.e:117				return { GET_FAIL, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6106 = MAKE_SEQ(_1);
    DeRefDSi(_terminator_10898);
    DeRefi(_text_10899);
    DeRef(_6104);
    _6104 = NOVALUE;
    DeRef(_6101);
    _6101 = NOVALUE;
    return _6106;
L5: 

    /** get.e:119		entry*/
L1: 

    /** get.e:120			get_ch()*/
    _6get_ch();

    /** get.e:121			text &= ch*/
    Append(&_text_10899, _text_10899, _6ch_10845);

    /** get.e:122			ends_at += 1*/
    _ends_at_10900 = _ends_at_10900 + 1;

    /** get.e:123		end while*/
    goto L2; // [89] 24
L4: 

    /** get.e:124		return { GET_SUCCESS, head( text, length( text ) - length( terminator ) ) }*/
    if (IS_SEQUENCE(_text_10899)){
            _6109 = SEQ_PTR(_text_10899)->length;
    }
    else {
        _6109 = 1;
    }
    if (IS_SEQUENCE(_terminator_10898)){
            _6110 = SEQ_PTR(_terminator_10898)->length;
    }
    else {
        _6110 = 1;
    }
    _6111 = _6109 - _6110;
    _6109 = NOVALUE;
    _6110 = NOVALUE;
    {
        int len = SEQ_PTR(_text_10899)->length;
        int size = (IS_ATOM_INT(_6111)) ? _6111 : (object)(DBL_PTR(_6111)->dbl);
        if (size <= 0){
            DeRef( _6112 );
            _6112 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_text_10899);
            DeRef(_6112);
            _6112 = _text_10899;
        }
        else{
            Head(SEQ_PTR(_text_10899),size+1,&_6112);
        }
    }
    _6111 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _6112;
    _6113 = MAKE_SEQ(_1);
    _6112 = NOVALUE;
    DeRefDSi(_terminator_10898);
    DeRefDSi(_text_10899);
    DeRef(_6104);
    _6104 = NOVALUE;
    DeRef(_6106);
    _6106 = NOVALUE;
    DeRef(_6101);
    _6101 = NOVALUE;
    return _6113;
    ;
}


object _6get_string()
{
    object _text_10920 = NOVALUE;
    object _6130 = NOVALUE;
    object _6126 = NOVALUE;
    object _6125 = NOVALUE;
    object _6122 = NOVALUE;
    object _6121 = NOVALUE;
    object _6120 = NOVALUE;
    object _6119 = NOVALUE;
    object _6117 = NOVALUE;
    object _6116 = NOVALUE;
    object _6114 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:132		text = ""*/
    RefDS(_5);
    DeRefi(_text_10920);
    _text_10920 = _5;

    /** get.e:133		while TRUE do*/
L1: 

    /** get.e:134			get_ch()*/
    _6get_ch();

    /** get.e:135			if ch = GET_EOF or ch = '\n' then*/
    _6114 = (_6ch_10845 == -1LL);
    if (_6114 != 0) {
        goto L2; // [25] 40
    }
    _6116 = (_6ch_10845 == 10LL);
    if (_6116 == 0)
    {
        DeRef(_6116);
        _6116 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_6116);
        _6116 = NOVALUE;
    }
L2: 

    /** get.e:136				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6117 = MAKE_SEQ(_1);
    DeRefi(_text_10920);
    DeRef(_6114);
    _6114 = NOVALUE;
    return _6117;
    goto L4; // [50] 164
L3: 

    /** get.e:137			elsif ch = '"' then*/
    if (_6ch_10845 != 34LL)
    goto L5; // [57] 121

    /** get.e:138				get_ch()*/
    _6get_ch();

    /** get.e:139				if length( text ) = 0 and ch = '"' then*/
    if (IS_SEQUENCE(_text_10920)){
            _6119 = SEQ_PTR(_text_10920)->length;
    }
    else {
        _6119 = 1;
    }
    _6120 = (_6119 == 0LL);
    _6119 = NOVALUE;
    if (_6120 == 0) {
        goto L6; // [74] 108
    }
    _6122 = (_6ch_10845 == 34LL);
    if (_6122 == 0)
    {
        DeRef(_6122);
        _6122 = NOVALUE;
        goto L6; // [85] 108
    }
    else{
        DeRef(_6122);
        _6122 = NOVALUE;
    }

    /** get.e:140					if ch = '"' then*/
    if (_6ch_10845 != 34LL)
    goto L7; // [92] 107

    /** get.e:141						return get_heredoc( `"""` )*/
    RefDS(_6124);
    _6125 = _6get_heredoc(_6124);
    DeRefi(_text_10920);
    DeRef(_6117);
    _6117 = NOVALUE;
    DeRef(_6120);
    _6120 = NOVALUE;
    DeRef(_6114);
    _6114 = NOVALUE;
    return _6125;
L7: 
L6: 

    /** get.e:144				return {GET_SUCCESS, text}*/
    RefDS(_text_10920);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _text_10920;
    _6126 = MAKE_SEQ(_1);
    DeRefDSi(_text_10920);
    DeRef(_6125);
    _6125 = NOVALUE;
    DeRef(_6117);
    _6117 = NOVALUE;
    DeRef(_6120);
    _6120 = NOVALUE;
    DeRef(_6114);
    _6114 = NOVALUE;
    return _6126;
    goto L4; // [118] 164
L5: 

    /** get.e:145			elsif ch = '\\' then*/
    if (_6ch_10845 != 92LL)
    goto L8; // [125] 163

    /** get.e:146				get_ch()*/
    _6get_ch();

    /** get.e:147				ch = escape_char(ch)*/
    _0 = _6escape_char(_6ch_10845);
    _6ch_10845 = _0;
    if (!IS_ATOM_INT(_6ch_10845)) {
        _1 = (object)(DBL_PTR(_6ch_10845)->dbl);
        DeRefDS(_6ch_10845);
        _6ch_10845 = _1;
    }

    /** get.e:148				if ch = GET_FAIL then*/
    if (_6ch_10845 != 1LL)
    goto L9; // [147] 162

    /** get.e:149					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6130 = MAKE_SEQ(_1);
    DeRefi(_text_10920);
    DeRef(_6125);
    _6125 = NOVALUE;
    DeRef(_6117);
    _6117 = NOVALUE;
    DeRef(_6126);
    _6126 = NOVALUE;
    DeRef(_6120);
    _6120 = NOVALUE;
    DeRef(_6114);
    _6114 = NOVALUE;
    return _6130;
L9: 
L8: 
L4: 

    /** get.e:152			text = text & ch*/
    Append(&_text_10920, _text_10920, _6ch_10845);

    /** get.e:153		end while*/
    goto L1; // [174] 13
    ;
}


object _6read_comment()
{
    object _6151 = NOVALUE;
    object _6150 = NOVALUE;
    object _6148 = NOVALUE;
    object _6146 = NOVALUE;
    object _6144 = NOVALUE;
    object _6143 = NOVALUE;
    object _6142 = NOVALUE;
    object _6140 = NOVALUE;
    object _6139 = NOVALUE;
    object _6138 = NOVALUE;
    object _6137 = NOVALUE;
    object _6136 = NOVALUE;
    object _6135 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:163		if atom(input_string) then*/
    _6135 = IS_ATOM(_6input_string_10843);
    if (_6135 == 0)
    {
        _6135 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _6135 = NOVALUE;
    }

    /** get.e:164			while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _6136 = (_6ch_10845 != 10LL);
    if (_6136 == 0) {
        _6137 = 0;
        goto L3; // [22] 36
    }
    _6138 = (_6ch_10845 != 13LL);
    _6137 = (_6138 != 0);
L3: 
    if (_6137 == 0) {
        goto L4; // [36] 59
    }
    _6140 = (_6ch_10845 != -1LL);
    if (_6140 == 0)
    {
        DeRef(_6140);
        _6140 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_6140);
        _6140 = NOVALUE;
    }

    /** get.e:165				get_ch()*/
    _6get_ch();

    /** get.e:166			end while*/
    goto L2; // [56] 16
L4: 

    /** get.e:167			get_ch()*/
    _6get_ch();

    /** get.e:168			if ch=-1 then*/
    if (_6ch_10845 != -1LL)
    goto L5; // [67] 84

    /** get.e:169				return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6142 = MAKE_SEQ(_1);
    DeRef(_6138);
    _6138 = NOVALUE;
    DeRef(_6136);
    _6136 = NOVALUE;
    return _6142;
    goto L6; // [81] 182
L5: 

    /** get.e:171				return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6143 = MAKE_SEQ(_1);
    DeRef(_6138);
    _6138 = NOVALUE;
    DeRef(_6142);
    _6142 = NOVALUE;
    DeRef(_6136);
    _6136 = NOVALUE;
    return _6143;
    goto L6; // [95] 182
L1: 

    /** get.e:174			for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_6input_string_10843)){
            _6144 = SEQ_PTR(_6input_string_10843)->length;
    }
    else {
        _6144 = 1;
    }
    {
        object _i_10970;
        _i_10970 = _6string_next_10844;
L7: 
        if (_i_10970 > _6144){
            goto L8; // [107] 171
        }

        /** get.e:175				ch=input_string[i]*/
        _2 = (object)SEQ_PTR(_6input_string_10843);
        _6ch_10845 = (object)*(((s1_ptr)_2)->base + _i_10970);
        if (!IS_ATOM_INT(_6ch_10845)){
            _6ch_10845 = (object)DBL_PTR(_6ch_10845)->dbl;
        }

        /** get.e:176				if ch='\n' or ch='\r' then*/
        _6146 = (_6ch_10845 == 10LL);
        if (_6146 != 0) {
            goto L9; // [132] 147
        }
        _6148 = (_6ch_10845 == 13LL);
        if (_6148 == 0)
        {
            DeRef(_6148);
            _6148 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_6148);
            _6148 = NOVALUE;
        }
L9: 

        /** get.e:177					string_next=i+1*/
        _6string_next_10844 = _i_10970 + 1;

        /** get.e:178					return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2LL;
        ((intptr_t *)_2)[2] = 0LL;
        _6150 = MAKE_SEQ(_1);
        DeRef(_6138);
        _6138 = NOVALUE;
        DeRef(_6143);
        _6143 = NOVALUE;
        DeRef(_6146);
        _6146 = NOVALUE;
        DeRef(_6142);
        _6142 = NOVALUE;
        DeRef(_6136);
        _6136 = NOVALUE;
        return _6150;
LA: 

        /** get.e:180			end for*/
        _i_10970 = _i_10970 + 1LL;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** get.e:181			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6151 = MAKE_SEQ(_1);
    DeRef(_6138);
    _6138 = NOVALUE;
    DeRef(_6143);
    _6143 = NOVALUE;
    DeRef(_6146);
    _6146 = NOVALUE;
    DeRef(_6142);
    _6142 = NOVALUE;
    DeRef(_6150);
    _6150 = NOVALUE;
    DeRef(_6136);
    _6136 = NOVALUE;
    return _6151;
L6: 
    ;
}


object _6get_number()
{
    object _sign_10982 = NOVALUE;
    object _e_sign_10983 = NOVALUE;
    object _ndigits_10984 = NOVALUE;
    object _hex_digit_10985 = NOVALUE;
    object _mantissa_10986 = NOVALUE;
    object _dec_10987 = NOVALUE;
    object _e_mag_10988 = NOVALUE;
    object _number_string_10989 = NOVALUE;
    object _6211 = NOVALUE;
    object _6209 = NOVALUE;
    object _6207 = NOVALUE;
    object _6206 = NOVALUE;
    object _6205 = NOVALUE;
    object _6204 = NOVALUE;
    object _6203 = NOVALUE;
    object _6202 = NOVALUE;
    object _6196 = NOVALUE;
    object _6194 = NOVALUE;
    object _6192 = NOVALUE;
    object _6187 = NOVALUE;
    object _6186 = NOVALUE;
    object _6184 = NOVALUE;
    object _6183 = NOVALUE;
    object _6182 = NOVALUE;
    object _6177 = NOVALUE;
    object _6176 = NOVALUE;
    object _6174 = NOVALUE;
    object _6173 = NOVALUE;
    object _6172 = NOVALUE;
    object _6171 = NOVALUE;
    object _6170 = NOVALUE;
    object _6169 = NOVALUE;
    object _6165 = NOVALUE;
    object _6161 = NOVALUE;
    object _6156 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:192		sequence number_string = { ch }*/
    _0 = _number_string_10989;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _6ch_10845;
    _number_string_10989 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** get.e:194		sign = +1*/
    _sign_10982 = 1LL;

    /** get.e:195		mantissa = 0*/
    DeRef(_mantissa_10986);
    _mantissa_10986 = 0LL;

    /** get.e:196		ndigits = 0*/
    _ndigits_10984 = 0LL;

    /** get.e:199		if ch = '-' then*/
    if (_6ch_10845 != 45LL)
    goto L1; // [28] 70

    /** get.e:200			sign = -1*/
    _sign_10982 = -1LL;

    /** get.e:201			get_ch()*/
    _6get_ch();

    /** get.e:202			number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:203			if ch='-' then*/
    if (_6ch_10845 != 45LL)
    goto L2; // [53] 92

    /** get.e:204				return read_comment()*/
    _6156 = _6read_comment();
    DeRef(_dec_10987);
    DeRefDSi(_number_string_10989);
    return _6156;
    goto L2; // [67] 92
L1: 

    /** get.e:206		elsif ch = '+' then*/
    if (_6ch_10845 != 43LL)
    goto L3; // [74] 91

    /** get.e:207			get_ch()*/
    _6get_ch();

    /** get.e:208			number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);
L3: 
L2: 

    /** get.e:212		if ch = '#' then*/
    if (_6ch_10845 != 35LL)
    goto L4; // [96] 210

    /** get.e:214			get_ch()*/
    _6get_ch();

    /** get.e:215			number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:216			while TRUE do*/
L5: 

    /** get.e:217				hex_digit = find(ch, HEX_DIGITS)-1*/
    _6161 = find_from(_6ch_10845, _6HEX_DIGITS_10825, 1LL);
    _hex_digit_10985 = _6161 - 1LL;
    _6161 = NOVALUE;

    /** get.e:218				if hex_digit >= 0 then*/
    if (_hex_digit_10985 < 0LL)
    goto L6; // [134] 169

    /** get.e:219					ndigits += 1*/
    _ndigits_10984 = _ndigits_10984 + 1;

    /** get.e:220					mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_10986)) {
        {
            int128_t p128 = (int128_t)_mantissa_10986 * (int128_t)16LL;
            if( p128 != (int128_t)(_6165 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _6165 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _6165 = NewDouble(DBL_PTR(_mantissa_10986)->dbl * (eudouble)16LL);
    }
    DeRef(_mantissa_10986);
    if (IS_ATOM_INT(_6165)) {
        _mantissa_10986 = _6165 + _hex_digit_10985;
        if ((object)((uintptr_t)_mantissa_10986 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_10986 = NewDouble((eudouble)_mantissa_10986);
        }
    }
    else {
        _mantissa_10986 = NewDouble(DBL_PTR(_6165)->dbl + (eudouble)_hex_digit_10985);
    }
    DeRef(_6165);
    _6165 = NOVALUE;

    /** get.e:221					get_ch()*/
    _6get_ch();

    /** get.e:222					number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);
    goto L5; // [166] 117
L6: 

    /** get.e:224					if ndigits > 0 then*/
    if (_ndigits_10984 <= 0LL)
    goto L7; // [171] 192

    /** get.e:225						return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_10986)) {
        {
            int128_t p128 = (int128_t)_sign_10982 * (int128_t)_mantissa_10986;
            if( p128 != (int128_t)(_6169 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _6169 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _6169 = NewDouble((eudouble)_sign_10982 * DBL_PTR(_mantissa_10986)->dbl);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _6169;
    _6170 = MAKE_SEQ(_1);
    _6169 = NOVALUE;
    DeRef(_mantissa_10986);
    DeRef(_dec_10987);
    DeRefi(_number_string_10989);
    DeRef(_6156);
    _6156 = NOVALUE;
    return _6170;
    goto L5; // [189] 117
L7: 

    /** get.e:227						return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6171 = MAKE_SEQ(_1);
    DeRef(_mantissa_10986);
    DeRef(_dec_10987);
    DeRefi(_number_string_10989);
    DeRef(_6156);
    _6156 = NOVALUE;
    DeRef(_6170);
    _6170 = NOVALUE;
    return _6171;

    /** get.e:230			end while*/
    goto L5; // [206] 117
L4: 

    /** get.e:234		while ch >= '0' and ch <= '9' do*/
L8: 
    _6172 = (_6ch_10845 >= 48LL);
    if (_6172 == 0) {
        goto L9; // [221] 274
    }
    _6174 = (_6ch_10845 <= 57LL);
    if (_6174 == 0)
    {
        DeRef(_6174);
        _6174 = NOVALUE;
        goto L9; // [232] 274
    }
    else{
        DeRef(_6174);
        _6174 = NOVALUE;
    }

    /** get.e:235			ndigits += 1*/
    _ndigits_10984 = _ndigits_10984 + 1;

    /** get.e:236			mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_10986)) {
        {
            int128_t p128 = (int128_t)_mantissa_10986 * (int128_t)10LL;
            if( p128 != (int128_t)(_6176 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _6176 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _6176 = NewDouble(DBL_PTR(_mantissa_10986)->dbl * (eudouble)10LL);
    }
    _6177 = _6ch_10845 - 48LL;
    if ((object)((uintptr_t)_6177 +(uintptr_t) HIGH_BITS) >= 0){
        _6177 = NewDouble((eudouble)_6177);
    }
    DeRef(_mantissa_10986);
    if (IS_ATOM_INT(_6176) && IS_ATOM_INT(_6177)) {
        _mantissa_10986 = _6176 + _6177;
        if ((object)((uintptr_t)_mantissa_10986 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_10986 = NewDouble((eudouble)_mantissa_10986);
        }
    }
    else {
        if (IS_ATOM_INT(_6176)) {
            _mantissa_10986 = NewDouble((eudouble)_6176 + DBL_PTR(_6177)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6177)) {
                _mantissa_10986 = NewDouble(DBL_PTR(_6176)->dbl + (eudouble)_6177);
            }
            else
            _mantissa_10986 = NewDouble(DBL_PTR(_6176)->dbl + DBL_PTR(_6177)->dbl);
        }
    }
    DeRef(_6176);
    _6176 = NOVALUE;
    DeRef(_6177);
    _6177 = NOVALUE;

    /** get.e:237			get_ch()*/
    _6get_ch();

    /** get.e:238			number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:239		end while*/
    goto L8; // [271] 215
L9: 

    /** get.e:241		if ch = '.' then*/
    if (_6ch_10845 != 46LL)
    goto LA; // [278] 370

    /** get.e:243			get_ch()*/
    _6get_ch();

    /** get.e:244			number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:245			dec = 10*/
    DeRef(_dec_10987);
    _dec_10987 = 10LL;

    /** get.e:246			while ch >= '0' and ch <= '9' do*/
LB: 
    _6182 = (_6ch_10845 >= 48LL);
    if (_6182 == 0) {
        goto LC; // [310] 369
    }
    _6184 = (_6ch_10845 <= 57LL);
    if (_6184 == 0)
    {
        DeRef(_6184);
        _6184 = NOVALUE;
        goto LC; // [321] 369
    }
    else{
        DeRef(_6184);
        _6184 = NOVALUE;
    }

    /** get.e:247				ndigits += 1*/
    _ndigits_10984 = _ndigits_10984 + 1;

    /** get.e:248				mantissa += (ch - '0') / dec*/
    _6186 = _6ch_10845 - 48LL;
    if ((object)((uintptr_t)_6186 +(uintptr_t) HIGH_BITS) >= 0){
        _6186 = NewDouble((eudouble)_6186);
    }
    if (IS_ATOM_INT(_6186) && IS_ATOM_INT(_dec_10987)) {
        _6187 = (_6186 % _dec_10987) ? NewDouble((eudouble)_6186 / _dec_10987) : (_6186 / _dec_10987);
    }
    else {
        if (IS_ATOM_INT(_6186)) {
            _6187 = NewDouble((eudouble)_6186 / DBL_PTR(_dec_10987)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_10987)) {
                _6187 = NewDouble(DBL_PTR(_6186)->dbl / (eudouble)_dec_10987);
            }
            else
            _6187 = NewDouble(DBL_PTR(_6186)->dbl / DBL_PTR(_dec_10987)->dbl);
        }
    }
    DeRef(_6186);
    _6186 = NOVALUE;
    _0 = _mantissa_10986;
    if (IS_ATOM_INT(_mantissa_10986) && IS_ATOM_INT(_6187)) {
        _mantissa_10986 = _mantissa_10986 + _6187;
        if ((object)((uintptr_t)_mantissa_10986 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_10986 = NewDouble((eudouble)_mantissa_10986);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_10986)) {
            _mantissa_10986 = NewDouble((eudouble)_mantissa_10986 + DBL_PTR(_6187)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6187)) {
                _mantissa_10986 = NewDouble(DBL_PTR(_mantissa_10986)->dbl + (eudouble)_6187);
            }
            else
            _mantissa_10986 = NewDouble(DBL_PTR(_mantissa_10986)->dbl + DBL_PTR(_6187)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6187);
    _6187 = NOVALUE;

    /** get.e:249				dec *= 10*/
    _0 = _dec_10987;
    if (IS_ATOM_INT(_dec_10987)) {
        {
            int128_t p128 = (int128_t)_dec_10987 * (int128_t)10LL;
            if( p128 != (int128_t)(_dec_10987 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _dec_10987 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _dec_10987 = NewDouble(DBL_PTR(_dec_10987)->dbl * (eudouble)10LL);
    }
    DeRef(_0);

    /** get.e:250				get_ch()*/
    _6get_ch();

    /** get.e:251				number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:252			end while*/
    goto LB; // [366] 304
LC: 
LA: 

    /** get.e:255		if ndigits = 0 then*/
    if (_ndigits_10984 != 0LL)
    goto LD; // [372] 387

    /** get.e:256			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6192 = MAKE_SEQ(_1);
    DeRef(_mantissa_10986);
    DeRef(_dec_10987);
    DeRefi(_number_string_10989);
    DeRef(_6182);
    _6182 = NOVALUE;
    DeRef(_6156);
    _6156 = NOVALUE;
    DeRef(_6170);
    _6170 = NOVALUE;
    DeRef(_6172);
    _6172 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    return _6192;
LD: 

    /** get.e:259		mantissa = sign * mantissa*/
    _0 = _mantissa_10986;
    if (IS_ATOM_INT(_mantissa_10986)) {
        {
            int128_t p128 = (int128_t)_sign_10982 * (int128_t)_mantissa_10986;
            if( p128 != (int128_t)(_mantissa_10986 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _mantissa_10986 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _mantissa_10986 = NewDouble((eudouble)_sign_10982 * DBL_PTR(_mantissa_10986)->dbl);
    }
    DeRef(_0);

    /** get.e:261		if ch = 'e' or ch = 'E' then*/
    _6194 = (_6ch_10845 == 101LL);
    if (_6194 != 0) {
        goto LE; // [401] 416
    }
    _6196 = (_6ch_10845 == 69LL);
    if (_6196 == 0)
    {
        DeRef(_6196);
        _6196 = NOVALUE;
        goto LF; // [412] 565
    }
    else{
        DeRef(_6196);
        _6196 = NOVALUE;
    }
LE: 

    /** get.e:264			get_ch()*/
    _6get_ch();

    /** get.e:265			number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:266			if ch = '-' then*/
    if (_6ch_10845 != 45LL)
    goto L10; // [432] 451

    /** get.e:267				get_ch()*/
    _6get_ch();

    /** get.e:268				number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);
    goto L11; // [448] 473
L10: 

    /** get.e:269			elsif ch = '+' then*/
    if (_6ch_10845 != 43LL)
    goto L12; // [455] 472

    /** get.e:270				get_ch()*/
    _6get_ch();

    /** get.e:271				number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);
L12: 
L11: 

    /** get.e:275			if ch >= '0' and ch <= '9' then*/
    _6202 = (_6ch_10845 >= 48LL);
    if (_6202 == 0) {
        goto L13; // [481] 546
    }
    _6204 = (_6ch_10845 <= 57LL);
    if (_6204 == 0)
    {
        DeRef(_6204);
        _6204 = NOVALUE;
        goto L13; // [492] 546
    }
    else{
        DeRef(_6204);
        _6204 = NOVALUE;
    }

    /** get.e:277				while ch >= '0' and ch <= '9' with entry do*/
    goto L14; // [497] 534
L15: 
    _6205 = (_6ch_10845 >= 48LL);
    if (_6205 == 0) {
        DeRef(_6206);
        _6206 = 0;
        goto L16; // [506] 520
    }
    _6207 = (_6ch_10845 <= 57LL);
    _6206 = (_6207 != 0);
L16: 
    if (_6206 == 0)
    {
        _6206 = NOVALUE;
        goto L17; // [520] 557
    }
    else{
        _6206 = NOVALUE;
    }

    /** get.e:278					number_string &= ch*/
    Append(&_number_string_10989, _number_string_10989, _6ch_10845);

    /** get.e:279				entry*/
L14: 

    /** get.e:280					get_ch()*/
    _6get_ch();

    /** get.e:281				end while*/
    goto L15; // [540] 500
    goto L17; // [543] 557
L13: 

    /** get.e:283				return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6209 = MAKE_SEQ(_1);
    DeRef(_mantissa_10986);
    DeRef(_dec_10987);
    DeRefi(_number_string_10989);
    DeRef(_6207);
    _6207 = NOVALUE;
    DeRef(_6205);
    _6205 = NOVALUE;
    DeRef(_6194);
    _6194 = NOVALUE;
    DeRef(_6182);
    _6182 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6202);
    _6202 = NOVALUE;
    DeRef(_6156);
    _6156 = NOVALUE;
    DeRef(_6170);
    _6170 = NOVALUE;
    DeRef(_6172);
    _6172 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    return _6209;
L17: 

    /** get.e:286			mantissa = scientific_to_atom( number_string )*/
    RefDS(_number_string_10989);
    _0 = _mantissa_10986;
    _mantissa_10986 = _28scientific_to_atom(_number_string_10989, 1LL);
    DeRef(_0);
LF: 

    /** get.e:289		return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_10986);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _mantissa_10986;
    _6211 = MAKE_SEQ(_1);
    DeRef(_mantissa_10986);
    DeRef(_dec_10987);
    DeRefi(_number_string_10989);
    DeRef(_6209);
    _6209 = NOVALUE;
    DeRef(_6207);
    _6207 = NOVALUE;
    DeRef(_6205);
    _6205 = NOVALUE;
    DeRef(_6194);
    _6194 = NOVALUE;
    DeRef(_6182);
    _6182 = NOVALUE;
    DeRef(_6192);
    _6192 = NOVALUE;
    DeRef(_6202);
    _6202 = NOVALUE;
    DeRef(_6156);
    _6156 = NOVALUE;
    DeRef(_6170);
    _6170 = NOVALUE;
    DeRef(_6172);
    _6172 = NOVALUE;
    DeRef(_6171);
    _6171 = NOVALUE;
    return _6211;
    ;
}


object _6Get()
{
    object _skip_blanks_1__tmp_at328_11116 = NOVALUE;
    object _skip_blanks_1__tmp_at177_11097 = NOVALUE;
    object _skip_blanks_1__tmp_at88_11088 = NOVALUE;
    object _s_11072 = NOVALUE;
    object _e_11073 = NOVALUE;
    object _e1_11074 = NOVALUE;
    object _6250 = NOVALUE;
    object _6249 = NOVALUE;
    object _6247 = NOVALUE;
    object _6244 = NOVALUE;
    object _6242 = NOVALUE;
    object _6240 = NOVALUE;
    object _6238 = NOVALUE;
    object _6235 = NOVALUE;
    object _6233 = NOVALUE;
    object _6229 = NOVALUE;
    object _6225 = NOVALUE;
    object _6222 = NOVALUE;
    object _6221 = NOVALUE;
    object _6219 = NOVALUE;
    object _6217 = NOVALUE;
    object _6215 = NOVALUE;
    object _6214 = NOVALUE;
    object _6212 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:300		while find(ch, white_space) do*/
L1: 
    _6212 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_6212 == 0)
    {
        _6212 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _6212 = NOVALUE;
    }

    /** get.e:301			get_ch()*/
    _6get_ch();

    /** get.e:302		end while*/
    goto L1; // [22] 6
L2: 

    /** get.e:304		if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10845 != -1LL)
    goto L3; // [29] 44

    /** get.e:305			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6214 = MAKE_SEQ(_1);
    DeRef(_s_11072);
    DeRef(_e_11073);
    return _6214;
L3: 

    /** get.e:308		while 1 do*/
L4: 

    /** get.e:309			if find(ch, START_NUMERIC) then*/
    _6215 = find_from(_6ch_10845, _6START_NUMERIC_10828, 1LL);
    if (_6215 == 0)
    {
        _6215 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _6215 = NOVALUE;
    }

    /** get.e:310				e = get_number()*/
    _0 = _e_11073;
    _e_11073 = _6get_number();
    DeRef(_0);

    /** get.e:311				if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (object)SEQ_PTR(_e_11073);
    _6217 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _6217, -2LL)){
        _6217 = NOVALUE;
        goto L6; // [76] 87
    }
    _6217 = NOVALUE;

    /** get.e:312					return e*/
    DeRef(_s_11072);
    DeRef(_6214);
    _6214 = NOVALUE;
    return _e_11073;
L6: 

    /** get.e:314				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_11088 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_skip_blanks_1__tmp_at88_11088 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L7; // [110] 94

    /** get.e:70	end procedure*/
    goto L8; // [115] 118
L8: 

    /** get.e:315				if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _6219 = (_6ch_10845 == -1LL);
    if (_6219 != 0) {
        goto L9; // [128] 143
    }
    _6221 = (_6ch_10845 == 125LL);
    if (_6221 == 0)
    {
        DeRef(_6221);
        _6221 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_6221);
        _6221 = NOVALUE;
    }
L9: 

    /** get.e:316					return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -2LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6222 = MAKE_SEQ(_1);
    DeRef(_s_11072);
    DeRef(_e_11073);
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    return _6222;
    goto L4; // [154] 49
L5: 

    /** get.e:318			elsif ch = '{' then*/
    if (_6ch_10845 != 123LL)
    goto LA; // [161] 465

    /** get.e:320				s = {}*/
    RefDS(_5);
    DeRef(_s_11072);
    _s_11072 = _5;

    /** get.e:321				get_ch()*/
    _6get_ch();

    /** get.e:322				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_11097 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_skip_blanks_1__tmp_at177_11097 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto LB; // [199] 183

    /** get.e:70	end procedure*/
    goto LC; // [204] 207
LC: 

    /** get.e:323				if ch = '}' then -- empty sequence*/
    if (_6ch_10845 != 125LL)
    goto LD; // [213] 232

    /** get.e:324					get_ch()*/
    _6get_ch();

    /** get.e:325					return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_11072);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _s_11072;
    _6225 = MAKE_SEQ(_1);
    DeRefDS(_s_11072);
    DeRef(_e_11073);
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _6225;
LD: 

    /** get.e:328				while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** get.e:329					while 1 do -- read zero or more comments and an element*/
LF: 

    /** get.e:330						e = Get() -- read next element, using standard function*/
    _0 = _e_11073;
    _e_11073 = _6Get();
    DeRef(_0);

    /** get.e:331						e1 = e[1]*/
    _2 = (object)SEQ_PTR(_e_11073);
    _e1_11074 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_e1_11074))
    _e1_11074 = (object)DBL_PTR(_e1_11074)->dbl;

    /** get.e:332						if e1 = GET_SUCCESS then*/
    if (_e1_11074 != 0LL)
    goto L10; // [257] 278

    /** get.e:333							s = append(s, e[2])*/
    _2 = (object)SEQ_PTR(_e_11073);
    _6229 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_6229);
    Append(&_s_11072, _s_11072, _6229);
    _6229 = NOVALUE;

    /** get.e:334							exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** get.e:335						elsif e1 != GET_IGNORE then*/
    if (_e1_11074 == -2LL)
    goto L12; // [280] 293

    /** get.e:336							return e*/
    DeRef(_s_11072);
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _e_11073;
    goto LF; // [290] 242
L12: 

    /** get.e:338						elsif ch='}' then*/
    if (_6ch_10845 != 125LL)
    goto LF; // [297] 242

    /** get.e:339							get_ch()*/
    _6get_ch();

    /** get.e:340							return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_11072);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _s_11072;
    _6233 = MAKE_SEQ(_1);
    DeRefDS(_s_11072);
    DeRef(_e_11073);
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _6233;

    /** get.e:342					end while*/
    goto LF; // [319] 242
L11: 

    /** get.e:344					while 1 do -- now read zero or more post element comments*/
L13: 

    /** get.e:345						skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_11116 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_skip_blanks_1__tmp_at328_11116 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L14; // [350] 334

    /** get.e:70	end procedure*/
    goto L15; // [355] 358
L15: 

    /** get.e:346						if ch = '}' then*/
    if (_6ch_10845 != 125LL)
    goto L16; // [364] 385

    /** get.e:347							get_ch()*/
    _6get_ch();

    /** get.e:348						return {GET_SUCCESS, s}*/
    RefDS(_s_11072);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _s_11072;
    _6235 = MAKE_SEQ(_1);
    DeRefDS(_s_11072);
    DeRef(_e_11073);
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _6235;
    goto L13; // [382] 327
L16: 

    /** get.e:349						elsif ch!='-' then*/
    if (_6ch_10845 == 45LL)
    goto L17; // [389] 400

    /** get.e:350							exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** get.e:352							e = get_number() -- reads anything starting with '-'*/
    _0 = _e_11073;
    _e_11073 = _6get_number();
    DeRef(_0);

    /** get.e:353							if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (object)SEQ_PTR(_e_11073);
    _6238 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _6238, -2LL)){
        _6238 = NOVALUE;
        goto L13; // [413] 327
    }
    _6238 = NOVALUE;

    /** get.e:354								return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6240 = MAKE_SEQ(_1);
    DeRef(_s_11072);
    DeRefDS(_e_11073);
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _6240;

    /** get.e:358				end while*/
    goto L13; // [431] 327
L18: 

    /** get.e:359					if ch != ',' then*/
    if (_6ch_10845 == 44LL)
    goto L19; // [438] 453

    /** get.e:360					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6242 = MAKE_SEQ(_1);
    DeRef(_s_11072);
    DeRef(_e_11073);
    DeRef(_6240);
    _6240 = NOVALUE;
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _6242;
L19: 

    /** get.e:362				get_ch() -- skip comma*/
    _6get_ch();

    /** get.e:363				end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** get.e:365			elsif ch = '\"' then*/
    if (_6ch_10845 != 34LL)
    goto L1A; // [469] 485

    /** get.e:366				return get_string()*/
    _6244 = _6get_string();
    DeRef(_s_11072);
    DeRef(_e_11073);
    DeRef(_6242);
    _6242 = NOVALUE;
    DeRef(_6240);
    _6240 = NOVALUE;
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    return _6244;
    goto L4; // [482] 49
L1A: 

    /** get.e:367			elsif ch = '`' then*/
    if (_6ch_10845 != 96LL)
    goto L1B; // [489] 506

    /** get.e:368				return get_heredoc("`")*/
    RefDS(_6246);
    _6247 = _6get_heredoc(_6246);
    DeRef(_s_11072);
    DeRef(_e_11073);
    DeRef(_6242);
    _6242 = NOVALUE;
    DeRef(_6240);
    _6240 = NOVALUE;
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    DeRef(_6244);
    _6244 = NOVALUE;
    return _6247;
    goto L4; // [503] 49
L1B: 

    /** get.e:369			elsif ch = '\'' then*/
    if (_6ch_10845 != 39LL)
    goto L1C; // [510] 526

    /** get.e:370				return get_qchar()*/
    _6249 = _6get_qchar();
    DeRef(_s_11072);
    DeRef(_e_11073);
    DeRef(_6242);
    _6242 = NOVALUE;
    DeRef(_6240);
    _6240 = NOVALUE;
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6247);
    _6247 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    DeRef(_6244);
    _6244 = NOVALUE;
    return _6249;
    goto L4; // [523] 49
L1C: 

    /** get.e:372				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _6250 = MAKE_SEQ(_1);
    DeRef(_s_11072);
    DeRef(_e_11073);
    DeRef(_6242);
    _6242 = NOVALUE;
    DeRef(_6240);
    _6240 = NOVALUE;
    DeRef(_6219);
    _6219 = NOVALUE;
    DeRef(_6247);
    _6247 = NOVALUE;
    DeRef(_6235);
    _6235 = NOVALUE;
    DeRef(_6233);
    _6233 = NOVALUE;
    DeRef(_6214);
    _6214 = NOVALUE;
    DeRef(_6249);
    _6249 = NOVALUE;
    DeRef(_6225);
    _6225 = NOVALUE;
    DeRef(_6222);
    _6222 = NOVALUE;
    DeRef(_6244);
    _6244 = NOVALUE;
    return _6250;

    /** get.e:376		end while*/
    goto L4; // [539] 49
    ;
}


object _6Get2()
{
    object _skip_blanks_1__tmp_at464_11217 = NOVALUE;
    object _skip_blanks_1__tmp_at233_11184 = NOVALUE;
    object _s_11146 = NOVALUE;
    object _e_11147 = NOVALUE;
    object _e1_11148 = NOVALUE;
    object _offset_11149 = NOVALUE;
    object _6350 = NOVALUE;
    object _6349 = NOVALUE;
    object _6348 = NOVALUE;
    object _6347 = NOVALUE;
    object _6346 = NOVALUE;
    object _6345 = NOVALUE;
    object _6344 = NOVALUE;
    object _6343 = NOVALUE;
    object _6342 = NOVALUE;
    object _6341 = NOVALUE;
    object _6340 = NOVALUE;
    object _6337 = NOVALUE;
    object _6336 = NOVALUE;
    object _6335 = NOVALUE;
    object _6334 = NOVALUE;
    object _6333 = NOVALUE;
    object _6332 = NOVALUE;
    object _6329 = NOVALUE;
    object _6328 = NOVALUE;
    object _6327 = NOVALUE;
    object _6326 = NOVALUE;
    object _6325 = NOVALUE;
    object _6324 = NOVALUE;
    object _6321 = NOVALUE;
    object _6320 = NOVALUE;
    object _6319 = NOVALUE;
    object _6318 = NOVALUE;
    object _6317 = NOVALUE;
    object _6315 = NOVALUE;
    object _6314 = NOVALUE;
    object _6313 = NOVALUE;
    object _6312 = NOVALUE;
    object _6311 = NOVALUE;
    object _6309 = NOVALUE;
    object _6306 = NOVALUE;
    object _6305 = NOVALUE;
    object _6304 = NOVALUE;
    object _6303 = NOVALUE;
    object _6302 = NOVALUE;
    object _6300 = NOVALUE;
    object _6299 = NOVALUE;
    object _6298 = NOVALUE;
    object _6297 = NOVALUE;
    object _6296 = NOVALUE;
    object _6294 = NOVALUE;
    object _6293 = NOVALUE;
    object _6292 = NOVALUE;
    object _6291 = NOVALUE;
    object _6290 = NOVALUE;
    object _6289 = NOVALUE;
    object _6286 = NOVALUE;
    object _6282 = NOVALUE;
    object _6281 = NOVALUE;
    object _6280 = NOVALUE;
    object _6279 = NOVALUE;
    object _6278 = NOVALUE;
    object _6275 = NOVALUE;
    object _6274 = NOVALUE;
    object _6273 = NOVALUE;
    object _6272 = NOVALUE;
    object _6271 = NOVALUE;
    object _6269 = NOVALUE;
    object _6268 = NOVALUE;
    object _6267 = NOVALUE;
    object _6266 = NOVALUE;
    object _6265 = NOVALUE;
    object _6264 = NOVALUE;
    object _6262 = NOVALUE;
    object _6260 = NOVALUE;
    object _6258 = NOVALUE;
    object _6257 = NOVALUE;
    object _6256 = NOVALUE;
    object _6255 = NOVALUE;
    object _6254 = NOVALUE;
    object _6252 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:392		offset = string_next-1*/
    _offset_11149 = _6string_next_10844 - 1LL;

    /** get.e:393		get_ch()*/
    _6get_ch();

    /** get.e:394		while find(ch, white_space) do*/
L1: 
    _6252 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_6252 == 0)
    {
        _6252 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _6252 = NOVALUE;
    }

    /** get.e:395			get_ch()*/
    _6get_ch();

    /** get.e:396		end while*/
    goto L1; // [34] 18
L2: 

    /** get.e:398		if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10845 != -1LL)
    goto L3; // [41] 75

    /** get.e:399			return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _6254 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6254 +(uintptr_t) HIGH_BITS) >= 0){
        _6254 = NewDouble((eudouble)_6254);
    }
    if (IS_ATOM_INT(_6254)) {
        _6255 = _6254 - _offset_11149;
        if ((object)((uintptr_t)_6255 +(uintptr_t) HIGH_BITS) >= 0){
            _6255 = NewDouble((eudouble)_6255);
        }
    }
    else {
        _6255 = NewDouble(DBL_PTR(_6254)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6254);
    _6254 = NOVALUE;
    _6256 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6256 +(uintptr_t) HIGH_BITS) >= 0){
        _6256 = NewDouble((eudouble)_6256);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = -1LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = _6255;
    ((intptr_t*)_2)[4] = _6256;
    _6257 = MAKE_SEQ(_1);
    _6256 = NOVALUE;
    _6255 = NOVALUE;
    DeRef(_s_11146);
    DeRef(_e_11147);
    return _6257;
L3: 

    /** get.e:402		leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _6258 = _6string_next_10844 - 2LL;
    if ((object)((uintptr_t)_6258 +(uintptr_t) HIGH_BITS) >= 0){
        _6258 = NewDouble((eudouble)_6258);
    }
    if (IS_ATOM_INT(_6258)) {
        _6leading_whitespace_11143 = _6258 - _offset_11149;
    }
    else {
        _6leading_whitespace_11143 = NewDouble(DBL_PTR(_6258)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6258);
    _6258 = NOVALUE;
    if (!IS_ATOM_INT(_6leading_whitespace_11143)) {
        _1 = (object)(DBL_PTR(_6leading_whitespace_11143)->dbl);
        DeRefDS(_6leading_whitespace_11143);
        _6leading_whitespace_11143 = _1;
    }

    /** get.e:404		while 1 do*/
L4: 

    /** get.e:405			if find(ch, START_NUMERIC) then*/
    _6260 = find_from(_6ch_10845, _6START_NUMERIC_10828, 1LL);
    if (_6260 == 0)
    {
        _6260 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _6260 = NOVALUE;
    }

    /** get.e:406				e = get_number()*/
    _0 = _e_11147;
    _e_11147 = _6get_number();
    DeRef(_0);

    /** get.e:407				if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (object)SEQ_PTR(_e_11147);
    _6262 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _6262, -2LL)){
        _6262 = NOVALUE;
        goto L6; // [121] 162
    }
    _6262 = NOVALUE;

    /** get.e:408					return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6264 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6264 +(uintptr_t) HIGH_BITS) >= 0){
        _6264 = NewDouble((eudouble)_6264);
    }
    if (IS_ATOM_INT(_6264)) {
        _6265 = _6264 - _offset_11149;
        if ((object)((uintptr_t)_6265 +(uintptr_t) HIGH_BITS) >= 0){
            _6265 = NewDouble((eudouble)_6265);
        }
    }
    else {
        _6265 = NewDouble(DBL_PTR(_6264)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6264);
    _6264 = NOVALUE;
    _6266 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6265)) {
        _6267 = _6265 - _6266;
        if ((object)((uintptr_t)_6267 +(uintptr_t) HIGH_BITS) >= 0){
            _6267 = NewDouble((eudouble)_6267);
        }
    }
    else {
        _6267 = NewDouble(DBL_PTR(_6265)->dbl - (eudouble)_6266);
    }
    DeRef(_6265);
    _6265 = NOVALUE;
    _6266 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6267;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11143;
    _6268 = MAKE_SEQ(_1);
    _6267 = NOVALUE;
    Concat((object_ptr)&_6269, _e_11147, _6268);
    DeRefDS(_6268);
    _6268 = NOVALUE;
    DeRef(_s_11146);
    DeRefDS(_e_11147);
    DeRef(_6257);
    _6257 = NOVALUE;
    return _6269;
L6: 

    /** get.e:410				get_ch()*/
    _6get_ch();

    /** get.e:411				if ch=-1 then*/
    if (_6ch_10845 != -1LL)
    goto L4; // [170] 94

    /** get.e:412					return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _6271 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6271 +(uintptr_t) HIGH_BITS) >= 0){
        _6271 = NewDouble((eudouble)_6271);
    }
    if (IS_ATOM_INT(_6271)) {
        _6272 = _6271 - _offset_11149;
        if ((object)((uintptr_t)_6272 +(uintptr_t) HIGH_BITS) >= 0){
            _6272 = NewDouble((eudouble)_6272);
        }
    }
    else {
        _6272 = NewDouble(DBL_PTR(_6271)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6271);
    _6271 = NOVALUE;
    _6273 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6272)) {
        _6274 = _6272 - _6273;
        if ((object)((uintptr_t)_6274 +(uintptr_t) HIGH_BITS) >= 0){
            _6274 = NewDouble((eudouble)_6274);
        }
    }
    else {
        _6274 = NewDouble(DBL_PTR(_6272)->dbl - (eudouble)_6273);
    }
    DeRef(_6272);
    _6272 = NOVALUE;
    _6273 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = -2LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = _6274;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6275 = MAKE_SEQ(_1);
    _6274 = NOVALUE;
    DeRef(_s_11146);
    DeRef(_e_11147);
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6275;
    goto L4; // [210] 94
L5: 

    /** get.e:415			elsif ch = '{' then*/
    if (_6ch_10845 != 123LL)
    goto L7; // [217] 676

    /** get.e:417				s = {}*/
    RefDS(_5);
    DeRef(_s_11146);
    _s_11146 = _5;

    /** get.e:418				get_ch()*/
    _6get_ch();

    /** get.e:419				skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_11184 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_skip_blanks_1__tmp_at233_11184 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L8; // [255] 239

    /** get.e:70	end procedure*/
    goto L9; // [260] 263
L9: 

    /** get.e:420				if ch = '}' then -- empty sequence*/
    if (_6ch_10845 != 125LL)
    goto LA; // [269] 313

    /** get.e:421					get_ch()*/
    _6get_ch();

    /** get.e:422					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _6278 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6278 +(uintptr_t) HIGH_BITS) >= 0){
        _6278 = NewDouble((eudouble)_6278);
    }
    if (IS_ATOM_INT(_6278)) {
        _6279 = _6278 - _offset_11149;
        if ((object)((uintptr_t)_6279 +(uintptr_t) HIGH_BITS) >= 0){
            _6279 = NewDouble((eudouble)_6279);
        }
    }
    else {
        _6279 = NewDouble(DBL_PTR(_6278)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6278);
    _6278 = NOVALUE;
    _6280 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6279)) {
        _6281 = _6279 - _6280;
        if ((object)((uintptr_t)_6281 +(uintptr_t) HIGH_BITS) >= 0){
            _6281 = NewDouble((eudouble)_6281);
        }
    }
    else {
        _6281 = NewDouble(DBL_PTR(_6279)->dbl - (eudouble)_6280);
    }
    DeRef(_6279);
    _6279 = NOVALUE;
    _6280 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    RefDS(_s_11146);
    ((intptr_t*)_2)[2] = _s_11146;
    ((intptr_t*)_2)[3] = _6281;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6282 = MAKE_SEQ(_1);
    _6281 = NOVALUE;
    DeRefDS(_s_11146);
    DeRef(_e_11147);
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6282;
LA: 

    /** get.e:425				while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** get.e:426					while 1 do -- read zero or more comments and an element*/
LC: 

    /** get.e:427						e = Get() -- read next element, using standard function*/
    _0 = _e_11147;
    _e_11147 = _6Get();
    DeRef(_0);

    /** get.e:428						e1 = e[1]*/
    _2 = (object)SEQ_PTR(_e_11147);
    _e1_11148 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_e1_11148))
    _e1_11148 = (object)DBL_PTR(_e1_11148)->dbl;

    /** get.e:429						if e1 = GET_SUCCESS then*/
    if (_e1_11148 != 0LL)
    goto LD; // [338] 359

    /** get.e:430							s = append(s, e[2])*/
    _2 = (object)SEQ_PTR(_e_11147);
    _6286 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_6286);
    Append(&_s_11146, _s_11146, _6286);
    _6286 = NOVALUE;

    /** get.e:431							exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** get.e:432						elsif e1 != GET_IGNORE then*/
    if (_e1_11148 == -2LL)
    goto LF; // [361] 404

    /** get.e:433							return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6289 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6289 +(uintptr_t) HIGH_BITS) >= 0){
        _6289 = NewDouble((eudouble)_6289);
    }
    if (IS_ATOM_INT(_6289)) {
        _6290 = _6289 - _offset_11149;
        if ((object)((uintptr_t)_6290 +(uintptr_t) HIGH_BITS) >= 0){
            _6290 = NewDouble((eudouble)_6290);
        }
    }
    else {
        _6290 = NewDouble(DBL_PTR(_6289)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6289);
    _6289 = NOVALUE;
    _6291 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6290)) {
        _6292 = _6290 - _6291;
        if ((object)((uintptr_t)_6292 +(uintptr_t) HIGH_BITS) >= 0){
            _6292 = NewDouble((eudouble)_6292);
        }
    }
    else {
        _6292 = NewDouble(DBL_PTR(_6290)->dbl - (eudouble)_6291);
    }
    DeRef(_6290);
    _6290 = NOVALUE;
    _6291 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6292;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11143;
    _6293 = MAKE_SEQ(_1);
    _6292 = NOVALUE;
    Concat((object_ptr)&_6294, _e_11147, _6293);
    DeRefDS(_6293);
    _6293 = NOVALUE;
    DeRef(_s_11146);
    DeRefDS(_e_11147);
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6294;
    goto LC; // [401] 323
LF: 

    /** get.e:435						elsif ch='}' then*/
    if (_6ch_10845 != 125LL)
    goto LC; // [408] 323

    /** get.e:436							get_ch()*/
    _6get_ch();

    /** get.e:437							return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _6296 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6296 +(uintptr_t) HIGH_BITS) >= 0){
        _6296 = NewDouble((eudouble)_6296);
    }
    if (IS_ATOM_INT(_6296)) {
        _6297 = _6296 - _offset_11149;
        if ((object)((uintptr_t)_6297 +(uintptr_t) HIGH_BITS) >= 0){
            _6297 = NewDouble((eudouble)_6297);
        }
    }
    else {
        _6297 = NewDouble(DBL_PTR(_6296)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6296);
    _6296 = NOVALUE;
    _6298 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6297)) {
        _6299 = _6297 - _6298;
        if ((object)((uintptr_t)_6299 +(uintptr_t) HIGH_BITS) >= 0){
            _6299 = NewDouble((eudouble)_6299);
        }
    }
    else {
        _6299 = NewDouble(DBL_PTR(_6297)->dbl - (eudouble)_6298);
    }
    DeRef(_6297);
    _6297 = NOVALUE;
    _6298 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    RefDS(_s_11146);
    ((intptr_t*)_2)[2] = _s_11146;
    ((intptr_t*)_2)[3] = _6299;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6300 = MAKE_SEQ(_1);
    _6299 = NOVALUE;
    DeRefDS(_s_11146);
    DeRef(_e_11147);
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6300;

    /** get.e:439					end while*/
    goto LC; // [455] 323
LE: 

    /** get.e:441					while 1 do -- now read zero or more post element comments*/
L10: 

    /** get.e:442						skip_blanks()*/

    /** get.e:67		while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_11217 = find_from(_6ch_10845, _6white_space_10861, 1LL);
    if (_skip_blanks_1__tmp_at464_11217 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** get.e:68			get_ch()*/
    _6get_ch();

    /** get.e:69		end while*/
    goto L11; // [486] 470

    /** get.e:70	end procedure*/
    goto L12; // [491] 494
L12: 

    /** get.e:443						if ch = '}' then*/
    if (_6ch_10845 != 125LL)
    goto L13; // [500] 546

    /** get.e:444							get_ch()*/
    _6get_ch();

    /** get.e:445						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6302 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6302 +(uintptr_t) HIGH_BITS) >= 0){
        _6302 = NewDouble((eudouble)_6302);
    }
    if (IS_ATOM_INT(_6302)) {
        _6303 = _6302 - _offset_11149;
        if ((object)((uintptr_t)_6303 +(uintptr_t) HIGH_BITS) >= 0){
            _6303 = NewDouble((eudouble)_6303);
        }
    }
    else {
        _6303 = NewDouble(DBL_PTR(_6302)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6302);
    _6302 = NOVALUE;
    _6304 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6303)) {
        _6305 = _6303 - _6304;
        if ((object)((uintptr_t)_6305 +(uintptr_t) HIGH_BITS) >= 0){
            _6305 = NewDouble((eudouble)_6305);
        }
    }
    else {
        _6305 = NewDouble(DBL_PTR(_6303)->dbl - (eudouble)_6304);
    }
    DeRef(_6303);
    _6303 = NOVALUE;
    _6304 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    RefDS(_s_11146);
    ((intptr_t*)_2)[2] = _s_11146;
    ((intptr_t*)_2)[3] = _6305;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6306 = MAKE_SEQ(_1);
    _6305 = NOVALUE;
    DeRefDS(_s_11146);
    DeRef(_e_11147);
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6306;
    goto L10; // [543] 463
L13: 

    /** get.e:446						elsif ch!='-' then*/
    if (_6ch_10845 == 45LL)
    goto L14; // [550] 561

    /** get.e:447							exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** get.e:449							e = get_number() -- reads anything starting with '-'*/
    _0 = _e_11147;
    _e_11147 = _6get_number();
    DeRef(_0);

    /** get.e:450							if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (object)SEQ_PTR(_e_11147);
    _6309 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _6309, -2LL)){
        _6309 = NOVALUE;
        goto L10; // [574] 463
    }
    _6309 = NOVALUE;

    /** get.e:451								return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _6311 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6311 +(uintptr_t) HIGH_BITS) >= 0){
        _6311 = NewDouble((eudouble)_6311);
    }
    if (IS_ATOM_INT(_6311)) {
        _6312 = _6311 - _offset_11149;
        if ((object)((uintptr_t)_6312 +(uintptr_t) HIGH_BITS) >= 0){
            _6312 = NewDouble((eudouble)_6312);
        }
    }
    else {
        _6312 = NewDouble(DBL_PTR(_6311)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6311);
    _6311 = NOVALUE;
    _6313 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6312)) {
        _6314 = _6312 - _6313;
        if ((object)((uintptr_t)_6314 +(uintptr_t) HIGH_BITS) >= 0){
            _6314 = NewDouble((eudouble)_6314);
        }
    }
    else {
        _6314 = NewDouble(DBL_PTR(_6312)->dbl - (eudouble)_6313);
    }
    DeRef(_6312);
    _6312 = NOVALUE;
    _6313 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = _6314;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6315 = MAKE_SEQ(_1);
    _6314 = NOVALUE;
    DeRef(_s_11146);
    DeRefDS(_e_11147);
    DeRef(_6306);
    _6306 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6315;

    /** get.e:455				end while*/
    goto L10; // [617] 463
L15: 

    /** get.e:456					if ch != ',' then*/
    if (_6ch_10845 == 44LL)
    goto L16; // [624] 664

    /** get.e:457					return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6317 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6317 +(uintptr_t) HIGH_BITS) >= 0){
        _6317 = NewDouble((eudouble)_6317);
    }
    if (IS_ATOM_INT(_6317)) {
        _6318 = _6317 - _offset_11149;
        if ((object)((uintptr_t)_6318 +(uintptr_t) HIGH_BITS) >= 0){
            _6318 = NewDouble((eudouble)_6318);
        }
    }
    else {
        _6318 = NewDouble(DBL_PTR(_6317)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6317);
    _6317 = NOVALUE;
    _6319 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6318)) {
        _6320 = _6318 - _6319;
        if ((object)((uintptr_t)_6320 +(uintptr_t) HIGH_BITS) >= 0){
            _6320 = NewDouble((eudouble)_6320);
        }
    }
    else {
        _6320 = NewDouble(DBL_PTR(_6318)->dbl - (eudouble)_6319);
    }
    DeRef(_6318);
    _6318 = NOVALUE;
    _6319 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = _6320;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6321 = MAKE_SEQ(_1);
    _6320 = NOVALUE;
    DeRef(_s_11146);
    DeRef(_e_11147);
    DeRef(_6306);
    _6306 = NOVALUE;
    DeRef(_6315);
    _6315 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6321;
L16: 

    /** get.e:459				get_ch() -- skip comma*/
    _6get_ch();

    /** get.e:460				end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** get.e:462			elsif ch = '\"' then*/
    if (_6ch_10845 != 34LL)
    goto L17; // [680] 730

    /** get.e:463				e = get_string()*/
    _0 = _e_11147;
    _e_11147 = _6get_string();
    DeRef(_0);

    /** get.e:464				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6324 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6324 +(uintptr_t) HIGH_BITS) >= 0){
        _6324 = NewDouble((eudouble)_6324);
    }
    if (IS_ATOM_INT(_6324)) {
        _6325 = _6324 - _offset_11149;
        if ((object)((uintptr_t)_6325 +(uintptr_t) HIGH_BITS) >= 0){
            _6325 = NewDouble((eudouble)_6325);
        }
    }
    else {
        _6325 = NewDouble(DBL_PTR(_6324)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6324);
    _6324 = NOVALUE;
    _6326 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6325)) {
        _6327 = _6325 - _6326;
        if ((object)((uintptr_t)_6327 +(uintptr_t) HIGH_BITS) >= 0){
            _6327 = NewDouble((eudouble)_6327);
        }
    }
    else {
        _6327 = NewDouble(DBL_PTR(_6325)->dbl - (eudouble)_6326);
    }
    DeRef(_6325);
    _6325 = NOVALUE;
    _6326 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6327;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11143;
    _6328 = MAKE_SEQ(_1);
    _6327 = NOVALUE;
    Concat((object_ptr)&_6329, _e_11147, _6328);
    DeRefDS(_6328);
    _6328 = NOVALUE;
    DeRef(_s_11146);
    DeRefDS(_e_11147);
    DeRef(_6306);
    _6306 = NOVALUE;
    DeRef(_6315);
    _6315 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6321);
    _6321 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    return _6329;
    goto L4; // [727] 94
L17: 

    /** get.e:465			elsif ch = '`' then*/
    if (_6ch_10845 != 96LL)
    goto L18; // [734] 785

    /** get.e:466				e = get_heredoc("`")*/
    RefDS(_6246);
    _0 = _e_11147;
    _e_11147 = _6get_heredoc(_6246);
    DeRef(_0);

    /** get.e:467				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6332 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6332 +(uintptr_t) HIGH_BITS) >= 0){
        _6332 = NewDouble((eudouble)_6332);
    }
    if (IS_ATOM_INT(_6332)) {
        _6333 = _6332 - _offset_11149;
        if ((object)((uintptr_t)_6333 +(uintptr_t) HIGH_BITS) >= 0){
            _6333 = NewDouble((eudouble)_6333);
        }
    }
    else {
        _6333 = NewDouble(DBL_PTR(_6332)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6332);
    _6332 = NOVALUE;
    _6334 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6333)) {
        _6335 = _6333 - _6334;
        if ((object)((uintptr_t)_6335 +(uintptr_t) HIGH_BITS) >= 0){
            _6335 = NewDouble((eudouble)_6335);
        }
    }
    else {
        _6335 = NewDouble(DBL_PTR(_6333)->dbl - (eudouble)_6334);
    }
    DeRef(_6333);
    _6333 = NOVALUE;
    _6334 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6335;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11143;
    _6336 = MAKE_SEQ(_1);
    _6335 = NOVALUE;
    Concat((object_ptr)&_6337, _e_11147, _6336);
    DeRefDS(_6336);
    _6336 = NOVALUE;
    DeRef(_s_11146);
    DeRefDS(_e_11147);
    DeRef(_6306);
    _6306 = NOVALUE;
    DeRef(_6315);
    _6315 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6321);
    _6321 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    DeRef(_6329);
    _6329 = NOVALUE;
    return _6337;
    goto L4; // [782] 94
L18: 

    /** get.e:468			elsif ch = '\'' then*/
    if (_6ch_10845 != 39LL)
    goto L19; // [789] 839

    /** get.e:469				e = get_qchar()*/
    _0 = _e_11147;
    _e_11147 = _6get_qchar();
    DeRef(_0);

    /** get.e:470				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6340 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6340 +(uintptr_t) HIGH_BITS) >= 0){
        _6340 = NewDouble((eudouble)_6340);
    }
    if (IS_ATOM_INT(_6340)) {
        _6341 = _6340 - _offset_11149;
        if ((object)((uintptr_t)_6341 +(uintptr_t) HIGH_BITS) >= 0){
            _6341 = NewDouble((eudouble)_6341);
        }
    }
    else {
        _6341 = NewDouble(DBL_PTR(_6340)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6340);
    _6340 = NOVALUE;
    _6342 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6341)) {
        _6343 = _6341 - _6342;
        if ((object)((uintptr_t)_6343 +(uintptr_t) HIGH_BITS) >= 0){
            _6343 = NewDouble((eudouble)_6343);
        }
    }
    else {
        _6343 = NewDouble(DBL_PTR(_6341)->dbl - (eudouble)_6342);
    }
    DeRef(_6341);
    _6341 = NOVALUE;
    _6342 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6343;
    ((intptr_t *)_2)[2] = _6leading_whitespace_11143;
    _6344 = MAKE_SEQ(_1);
    _6343 = NOVALUE;
    Concat((object_ptr)&_6345, _e_11147, _6344);
    DeRefDS(_6344);
    _6344 = NOVALUE;
    DeRef(_s_11146);
    DeRefDS(_e_11147);
    DeRef(_6306);
    _6306 = NOVALUE;
    DeRef(_6315);
    _6315 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6321);
    _6321 = NOVALUE;
    DeRef(_6337);
    _6337 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    DeRef(_6329);
    _6329 = NOVALUE;
    return _6345;
    goto L4; // [836] 94
L19: 

    /** get.e:472				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _6346 = _6string_next_10844 - 1LL;
    if ((object)((uintptr_t)_6346 +(uintptr_t) HIGH_BITS) >= 0){
        _6346 = NewDouble((eudouble)_6346);
    }
    if (IS_ATOM_INT(_6346)) {
        _6347 = _6346 - _offset_11149;
        if ((object)((uintptr_t)_6347 +(uintptr_t) HIGH_BITS) >= 0){
            _6347 = NewDouble((eudouble)_6347);
        }
    }
    else {
        _6347 = NewDouble(DBL_PTR(_6346)->dbl - (eudouble)_offset_11149);
    }
    DeRef(_6346);
    _6346 = NOVALUE;
    _6348 = (_6ch_10845 != -1LL);
    if (IS_ATOM_INT(_6347)) {
        _6349 = _6347 - _6348;
        if ((object)((uintptr_t)_6349 +(uintptr_t) HIGH_BITS) >= 0){
            _6349 = NewDouble((eudouble)_6349);
        }
    }
    else {
        _6349 = NewDouble(DBL_PTR(_6347)->dbl - (eudouble)_6348);
    }
    DeRef(_6347);
    _6347 = NOVALUE;
    _6348 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = _6349;
    ((intptr_t*)_2)[4] = _6leading_whitespace_11143;
    _6350 = MAKE_SEQ(_1);
    _6349 = NOVALUE;
    DeRef(_s_11146);
    DeRef(_e_11147);
    DeRef(_6306);
    _6306 = NOVALUE;
    DeRef(_6315);
    _6315 = NOVALUE;
    DeRef(_6300);
    _6300 = NOVALUE;
    DeRef(_6282);
    _6282 = NOVALUE;
    DeRef(_6294);
    _6294 = NOVALUE;
    DeRef(_6257);
    _6257 = NOVALUE;
    DeRef(_6345);
    _6345 = NOVALUE;
    DeRef(_6275);
    _6275 = NOVALUE;
    DeRef(_6321);
    _6321 = NOVALUE;
    DeRef(_6337);
    _6337 = NOVALUE;
    DeRef(_6269);
    _6269 = NOVALUE;
    DeRef(_6329);
    _6329 = NOVALUE;
    return _6350;

    /** get.e:476		end while*/
    goto L4; // [877] 94
    ;
}


object _6get_value(object _target_11285, object _start_point_11286, object _answer_type_11287)
{
    object _msg_inlined_crash_at_35_11298 = NOVALUE;
    object _data_inlined_crash_at_32_11297 = NOVALUE;
    object _where_inlined_where_at_76_11304 = NOVALUE;
    object _seek_1__tmp_at90_11309 = NOVALUE;
    object _seek_inlined_seek_at_90_11308 = NOVALUE;
    object _pos_inlined_seek_at_87_11307 = NOVALUE;
    object _msg_inlined_crash_at_108_11312 = NOVALUE;
    object _6366 = NOVALUE;
    object _6363 = NOVALUE;
    object _6362 = NOVALUE;
    object _6361 = NOVALUE;
    object _6357 = NOVALUE;
    object _6356 = NOVALUE;
    object _6355 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:488		if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _6355 = (_answer_type_11287 != _6GET_SHORT_ANSWER_11277);
    if (_6355 == 0) {
        goto L1; // [13] 55
    }
    _6357 = (_answer_type_11287 != _6GET_LONG_ANSWER_11280);
    if (_6357 == 0)
    {
        DeRef(_6357);
        _6357 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_6357);
        _6357 = NOVALUE;
    }

    /** get.e:489			error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_6360);
    RefDS(_6359);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6359;
    ((intptr_t *)_2)[2] = _6360;
    _6361 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_11297);
    _data_inlined_crash_at_32_11297 = _6361;
    _6361 = NOVALUE;

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_11298);
    _msg_inlined_crash_at_35_11298 = EPrintf(-9999999, _6358, _data_inlined_crash_at_32_11297);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_35_11298);

    /** error.e:53	end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_11297);
    _data_inlined_crash_at_32_11297 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_11298);
    _msg_inlined_crash_at_35_11298 = NOVALUE;
L1: 

    /** get.e:491		if atom(target) then -- get()*/
    _6362 = IS_ATOM(_target_11285);
    if (_6362 == 0)
    {
        _6362 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _6362 = NOVALUE;
    }

    /** get.e:492			input_file = target*/
    Ref(_target_11285);
    _6input_file_10842 = _target_11285;
    if (!IS_ATOM_INT(_6input_file_10842)) {
        _1 = (object)(DBL_PTR(_6input_file_10842)->dbl);
        DeRefDS(_6input_file_10842);
        _6input_file_10842 = _1;
    }

    /** get.e:493			if start_point then*/
    if (_start_point_11286 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** get.e:494				if io:seek(target, io:where(target)+start_point) then*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_11304);
    _where_inlined_where_at_76_11304 = machine(20LL, _target_11285);
    if (IS_ATOM_INT(_where_inlined_where_at_76_11304)) {
        _6363 = _where_inlined_where_at_76_11304 + _start_point_11286;
        if ((object)((uintptr_t)_6363 + (uintptr_t)HIGH_BITS) >= 0){
            _6363 = NewDouble((eudouble)_6363);
        }
    }
    else {
        _6363 = NewDouble(DBL_PTR(_where_inlined_where_at_76_11304)->dbl + (eudouble)_start_point_11286);
    }
    DeRef(_pos_inlined_seek_at_87_11307);
    _pos_inlined_seek_at_87_11307 = _6363;
    _6363 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_11307);
    Ref(_target_11285);
    DeRef(_seek_1__tmp_at90_11309);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _target_11285;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_87_11307;
    _seek_1__tmp_at90_11309 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_11308 = machine(19LL, _seek_1__tmp_at90_11309);
    DeRef(_pos_inlined_seek_at_87_11307);
    _pos_inlined_seek_at_87_11307 = NOVALUE;
    DeRef(_seek_1__tmp_at90_11309);
    _seek_1__tmp_at90_11309 = NOVALUE;
    if (_seek_inlined_seek_at_90_11308 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** get.e:495					error:crash("Initial seek() for get() failed!")*/

    /** error.e:51		msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_11312);
    _msg_inlined_crash_at_108_11312 = EPrintf(-9999999, _6364, _5);

    /** error.e:52		machine_proc(M_CRASH, msg)*/
    machine(67LL, _msg_inlined_crash_at_108_11312);

    /** error.e:53	end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_11312);
    _msg_inlined_crash_at_108_11312 = NOVALUE;
L5: 
L4: 

    /** get.e:498			string_next = 1*/
    _6string_next_10844 = 1LL;

    /** get.e:499			input_string = 0*/
    DeRef(_6input_string_10843);
    _6input_string_10843 = 0LL;
    goto L7; // [139] 153
L3: 

    /** get.e:501			input_string = target*/
    Ref(_target_11285);
    DeRef(_6input_string_10843);
    _6input_string_10843 = _target_11285;

    /** get.e:502			string_next = start_point*/
    _6string_next_10844 = _start_point_11286;
L7: 

    /** get.e:504		if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_11287 != _6GET_SHORT_ANSWER_11277)
    goto L8; // [157] 166

    /** get.e:505			get_ch()*/
    _6get_ch();
L8: 

    /** get.e:507		return call_func(answer_type, {})*/
    _0 = (object)_00[_answer_type_11287].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_6366);
    _6366 = _1;
    DeRef(_target_11285);
    DeRef(_6355);
    _6355 = NOVALUE;
    return _6366;
    ;
}


object _6value(object _st_11325, object _start_point_11326, object _answer_11327)
{
    object _6368 = NOVALUE;
    object _0, _1, _2;
    

    /** get.e:684		return get_value(st, start_point, answer)*/
    RefDS(_st_11325);
    _6368 = _6get_value(_st_11325, 1LL, _answer_11327);
    DeRefDS(_st_11325);
    return _6368;
    ;
}



// 0x42B69730
