// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _47Push(object _x_51615)
{
    object _26562 = NOVALUE;
    object _26560 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_51615)) {
        _1 = (object)(DBL_PTR(_x_51615)->dbl);
        DeRefDS(_x_51615);
        _x_51615 = _1;
    }

    /** emit.e:135		cgi += 1*/
    _47cgi_51376 = _47cgi_51376 + 1;

    /** emit.e:136		if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_47cg_stack_51375)){
            _26560 = SEQ_PTR(_47cg_stack_51375)->length;
    }
    else {
        _26560 = 1;
    }
    if (_47cgi_51376 <= _26560)
    goto L1; // [20] 37

    /** emit.e:137			cg_stack &= repeat(0, 400)*/
    _26562 = Repeat(0LL, 400LL);
    Concat((object_ptr)&_47cg_stack_51375, _47cg_stack_51375, _26562);
    DeRefDS(_26562);
    _26562 = NOVALUE;
L1: 

    /** emit.e:139		cg_stack[cgi] = x*/
    _2 = (object)SEQ_PTR(_47cg_stack_51375);
    _2 = (object)(((s1_ptr)_2)->base + _47cgi_51376);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _x_51615;
    DeRef(_1);

    /** emit.e:141	end procedure*/
    return;
    ;
}


object _47Top()
{
    object _26564 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:145		return cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_51375);
    _26564 = (object)*(((s1_ptr)_2)->base + _47cgi_51376);
    Ref(_26564);
    return _26564;
    ;
}


object _47Pop()
{
    object _t_51628 = NOVALUE;
    object _s_51634 = NOVALUE;
    object _26576 = NOVALUE;
    object _26574 = NOVALUE;
    object _26572 = NOVALUE;
    object _26569 = NOVALUE;
    object _26568 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:153		t = cg_stack[cgi]*/
    _2 = (object)SEQ_PTR(_47cg_stack_51375);
    _t_51628 = (object)*(((s1_ptr)_2)->base + _47cgi_51376);
    if (!IS_ATOM_INT(_t_51628)){
        _t_51628 = (object)DBL_PTR(_t_51628)->dbl;
    }

    /** emit.e:154		cgi -= 1*/
    _47cgi_51376 = _47cgi_51376 - 1LL;

    /** emit.e:155		if t > 0 then*/
    if (_t_51628 <= 0LL)
    goto L1; // [23] 116

    /** emit.e:156			symtab_index s = t -- for type checking*/
    _s_51634 = _t_51628;

    /** emit.e:157			if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26568 = (object)*(((s1_ptr)_2)->base + _t_51628);
    _2 = (object)SEQ_PTR(_26568);
    _26569 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26568 = NOVALUE;
    if (binary_op_a(NOTEQ, _26569, 3LL)){
        _26569 = NOVALUE;
        goto L2; // [50] 115
    }
    _26569 = NOVALUE;

    /** emit.e:158				if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_36use_private_list_21876 != 0LL)
    goto L3; // [58] 82

    /** emit.e:159					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51628 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26572 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** emit.e:163				elsif find(t, private_sym) = 0 then*/
    _26574 = find_from(_t_51628, _36private_sym_21875, 1LL);
    if (_26574 != 0LL)
    goto L5; // [91] 113

    /** emit.e:165					SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_t_51628 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26576 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** emit.e:169		return t*/
    return _t_51628;
    ;
}


void _47TempKeep(object _x_51662)
{
    object _26583 = NOVALUE;
    object _26582 = NOVALUE;
    object _26581 = NOVALUE;
    object _26580 = NOVALUE;
    object _26579 = NOVALUE;
    object _26578 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:173		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26578 = (_x_51662 > 0LL);
    if (_26578 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26580 = (object)*(((s1_ptr)_2)->base + _x_51662);
    _2 = (object)SEQ_PTR(_26580);
    _26581 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26580 = NOVALUE;
    if (IS_ATOM_INT(_26581)) {
        _26582 = (_26581 == 3LL);
    }
    else {
        _26582 = binary_op(EQUALS, _26581, 3LL);
    }
    _26581 = NOVALUE;
    if (_26582 == 0) {
        DeRef(_26582);
        _26582 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26582) && DBL_PTR(_26582)->dbl == 0.0){
            DeRef(_26582);
            _26582 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26582);
        _26582 = NOVALUE;
    }
    DeRef(_26582);
    _26582 = NOVALUE;

    /** emit.e:174			SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51662 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _26583 = NOVALUE;
L1: 

    /** emit.e:176	end procedure*/
    DeRef(_26578);
    _26578 = NOVALUE;
    return;
    ;
}


void _47TempFree(object _x_51680)
{
    object _26589 = NOVALUE;
    object _26587 = NOVALUE;
    object _26586 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** emit.e:179		if x > 0 then*/
    if (_x_51680 <= 0LL)
    goto L1; // [5] 53

    /** emit.e:180			if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26586 = (object)*(((s1_ptr)_2)->base + _x_51680);
    _2 = (object)SEQ_PTR(_26586);
    _26587 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26586 = NOVALUE;
    if (binary_op_a(NOTEQ, _26587, 3LL)){
        _26587 = NOVALUE;
        goto L2; // [25] 52
    }
    _26587 = NOVALUE;

    /** emit.e:181				SymTab[x][S_SCOPE] = FREE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51680 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _26589 = NOVALUE;

    /** emit.e:182				clear_temp( x )*/
    _47clear_temp(_x_51680);
L2: 
L1: 

    /** emit.e:185	end procedure*/
    return;
    ;
}


void _47TempInteger(object _x_51699)
{
    object _26596 = NOVALUE;
    object _26595 = NOVALUE;
    object _26594 = NOVALUE;
    object _26593 = NOVALUE;
    object _26592 = NOVALUE;
    object _26591 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_51699)) {
        _1 = (object)(DBL_PTR(_x_51699)->dbl);
        DeRefDS(_x_51699);
        _x_51699 = _1;
    }

    /** emit.e:188		if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26591 = (_x_51699 > 0LL);
    if (_26591 == 0) {
        goto L1; // [9] 53
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26593 = (object)*(((s1_ptr)_2)->base + _x_51699);
    _2 = (object)SEQ_PTR(_26593);
    _26594 = (object)*(((s1_ptr)_2)->base + 3LL);
    _26593 = NOVALUE;
    if (IS_ATOM_INT(_26594)) {
        _26595 = (_26594 == 3LL);
    }
    else {
        _26595 = binary_op(EQUALS, _26594, 3LL);
    }
    _26594 = NOVALUE;
    if (_26595 == 0) {
        DeRef(_26595);
        _26595 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26595) && DBL_PTR(_26595)->dbl == 0.0){
            DeRef(_26595);
            _26595 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26595);
        _26595 = NOVALUE;
    }
    DeRef(_26595);
    _26595 = NOVALUE;

    /** emit.e:189			SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_x_51699 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _26596 = NOVALUE;
L1: 

    /** emit.e:191	end procedure*/
    DeRef(_26591);
    _26591 = NOVALUE;
    return;
    ;
}


object _47LexName(object _t_51716, object _defname_51717)
{
    object _name_51719 = NOVALUE;
    object _26605 = NOVALUE;
    object _26603 = NOVALUE;
    object _26601 = NOVALUE;
    object _26600 = NOVALUE;
    object _26599 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_51716)) {
        _1 = (object)(DBL_PTR(_t_51716)->dbl);
        DeRefDS(_t_51716);
        _t_51716 = _1;
    }

    /** emit.e:197		for i = 1 to length(token_name) do*/
    _26599 = 80;
    {
        object _i_51721;
        _i_51721 = 1LL;
L1: 
        if (_i_51721 > 80LL){
            goto L2; // [12] 82
        }

        /** emit.e:198			if t = token_name[i][LEX_NUMBER] then*/
        _2 = (object)SEQ_PTR(_47token_name_51383);
        _26600 = (object)*(((s1_ptr)_2)->base + _i_51721);
        _2 = (object)SEQ_PTR(_26600);
        _26601 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26600 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_51716, _26601)){
            _26601 = NOVALUE;
            goto L3; // [31] 75
        }
        _26601 = NOVALUE;

        /** emit.e:199				name = token_name[i][LEX_NAME]*/
        _2 = (object)SEQ_PTR(_47token_name_51383);
        _26603 = (object)*(((s1_ptr)_2)->base + _i_51721);
        DeRef(_name_51719);
        _2 = (object)SEQ_PTR(_26603);
        _name_51719 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_name_51719);
        _26603 = NOVALUE;

        /** emit.e:200				if not find(' ', name) then*/
        _26605 = find_from(32LL, _name_51719, 1LL);
        if (_26605 != 0)
        goto L4; // [56] 68
        _26605 = NOVALUE;

        /** emit.e:201					name = "'" & name & "'"*/
        {
            object concat_list[3];

            concat_list[0] = _26607;
            concat_list[1] = _name_51719;
            concat_list[2] = _26607;
            Concat_N((object_ptr)&_name_51719, concat_list, 3);
        }
L4: 

        /** emit.e:203				return name*/
        DeRefDSi(_defname_51717);
        return _name_51719;
L3: 

        /** emit.e:205		end for*/
        _i_51721 = _i_51721 + 1LL;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** emit.e:206		return defname -- try to avoid this case*/
    DeRef(_name_51719);
    return _defname_51717;
    ;
}


void _47InitEmit()
{
    object _0, _1, _2;
    

    /** emit.e:212		cg_stack = repeat(0, 400)*/
    DeRef(_47cg_stack_51375);
    _47cg_stack_51375 = Repeat(0LL, 400LL);

    /** emit.e:213		cgi = 0*/
    _47cgi_51376 = 0LL;

    /** emit.e:214	end procedure*/
    return;
    ;
}


object _47IsInteger(object _sym_51740)
{
    object _mode_51741 = NOVALUE;
    object _t_51743 = NOVALUE;
    object _pt_51744 = NOVALUE;
    object _26630 = NOVALUE;
    object _26629 = NOVALUE;
    object _26627 = NOVALUE;
    object _26626 = NOVALUE;
    object _26625 = NOVALUE;
    object _26623 = NOVALUE;
    object _26622 = NOVALUE;
    object _26621 = NOVALUE;
    object _26620 = NOVALUE;
    object _26618 = NOVALUE;
    object _26614 = NOVALUE;
    object _26611 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_51740)) {
        _1 = (object)(DBL_PTR(_sym_51740)->dbl);
        DeRefDS(_sym_51740);
        _sym_51740 = _1;
    }

    /** emit.e:221		if sym < 1 then*/
    if (_sym_51740 >= 1LL)
    goto L1; // [5] 16

    /** emit.e:223			return 0*/
    return 0LL;
L1: 

    /** emit.e:226		mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26611 = (object)*(((s1_ptr)_2)->base + _sym_51740);
    _2 = (object)SEQ_PTR(_26611);
    _mode_51741 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_51741)){
        _mode_51741 = (object)DBL_PTR(_mode_51741)->dbl;
    }
    _26611 = NOVALUE;

    /** emit.e:227		if mode = M_NORMAL then*/
    if (_mode_51741 != 1LL)
    goto L2; // [36] 136

    /** emit.e:228			t = SymTab[sym][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26614 = (object)*(((s1_ptr)_2)->base + _sym_51740);
    _2 = (object)SEQ_PTR(_26614);
    _t_51743 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_t_51743)){
        _t_51743 = (object)DBL_PTR(_t_51743)->dbl;
    }
    _26614 = NOVALUE;

    /** emit.e:229			if t = integer_type then*/
    if (_t_51743 != _54integer_type_47138)
    goto L3; // [60] 73

    /** emit.e:230				return TRUE*/
    return _13TRUE_447;
L3: 

    /** emit.e:232			if t > 0 then*/
    if (_t_51743 <= 0LL)
    goto L4; // [75] 215

    /** emit.e:233				pt = SymTab[t][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26618 = (object)*(((s1_ptr)_2)->base + _t_51743);
    _2 = (object)SEQ_PTR(_26618);
    _pt_51744 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_pt_51744)){
        _pt_51744 = (object)DBL_PTR(_pt_51744)->dbl;
    }
    _26618 = NOVALUE;

    /** emit.e:234				if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_51744 == 0) {
        goto L4; // [97] 215
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26621 = (object)*(((s1_ptr)_2)->base + _pt_51744);
    _2 = (object)SEQ_PTR(_26621);
    _26622 = (object)*(((s1_ptr)_2)->base + 15LL);
    _26621 = NOVALUE;
    if (IS_ATOM_INT(_26622)) {
        _26623 = (_26622 == _54integer_type_47138);
    }
    else {
        _26623 = binary_op(EQUALS, _26622, _54integer_type_47138);
    }
    _26622 = NOVALUE;
    if (_26623 == 0) {
        DeRef(_26623);
        _26623 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26623) && DBL_PTR(_26623)->dbl == 0.0){
            DeRef(_26623);
            _26623 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26623);
        _26623 = NOVALUE;
    }
    DeRef(_26623);
    _26623 = NOVALUE;

    /** emit.e:235					return TRUE   -- usertype(integer x)*/
    return _13TRUE_447;
    goto L4; // [133] 215
L2: 

    /** emit.e:239		elsif mode = M_CONSTANT then*/
    if (_mode_51741 != 2LL)
    goto L5; // [140] 176

    /** emit.e:240			if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26625 = (object)*(((s1_ptr)_2)->base + _sym_51740);
    _2 = (object)SEQ_PTR(_26625);
    _26626 = (object)*(((s1_ptr)_2)->base + 1LL);
    _26625 = NOVALUE;
    if (IS_ATOM_INT(_26626))
    _26627 = 1;
    else if (IS_ATOM_DBL(_26626))
    _26627 = IS_ATOM_INT(DoubleToInt(_26626));
    else
    _26627 = 0;
    _26626 = NOVALUE;
    if (_26627 == 0)
    {
        _26627 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26627 = NOVALUE;
    }

    /** emit.e:241				return TRUE*/
    return _13TRUE_447;
    goto L4; // [173] 215
L5: 

    /** emit.e:244		elsif mode = M_TEMP then*/
    if (_mode_51741 != 3LL)
    goto L6; // [180] 214

    /** emit.e:245			if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _26629 = (object)*(((s1_ptr)_2)->base + _sym_51740);
    _2 = (object)SEQ_PTR(_26629);
    _26630 = (object)*(((s1_ptr)_2)->base + 5LL);
    _26629 = NOVALUE;
    if (binary_op_a(NOTEQ, _26630, 1LL)){
        _26630 = NOVALUE;
        goto L7; // [200] 213
    }
    _26630 = NOVALUE;

    /** emit.e:246				return TRUE*/
    return _13TRUE_447;
L7: 
L6: 
L4: 

    /** emit.e:250		return FALSE*/
    return _13FALSE_445;
    ;
}


void _47emit(object _val_51801)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_51801)) {
        _1 = (object)(DBL_PTR(_val_51801)->dbl);
        DeRefDS(_val_51801);
        _val_51801 = _1;
    }

    /** emit.e:260		Code = append(Code, val)*/
    Append(&_36Code_21851, _36Code_21851, _val_51801);

    /** emit.e:261	end procedure*/
    return;
    ;
}


void _47emit_opnd(object _opnd_51808)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_51808)) {
        _1 = (object)(DBL_PTR(_opnd_51808)->dbl);
        DeRefDS(_opnd_51808);
        _opnd_51808 = _1;
    }

    /** emit.e:271			Push(opnd)*/
    _47Push(_opnd_51808);

    /** emit.e:272			previous_op = -1  -- N.B.*/
    _36previous_op_21861 = -1LL;

    /** emit.e:273	end procedure*/
    return;
    ;
}


void _47emit_addr(object _x_51812)
{
    object _0, _1, _2;
    

    /** emit.e:277			Code = append(Code, x)*/
    Ref(_x_51812);
    Append(&_36Code_21851, _36Code_21851, _x_51812);

    /** emit.e:278	end procedure*/
    DeRef(_x_51812);
    return;
    ;
}


void _47emit_opcode(object _op_51818)
{
    object _0, _1, _2;
    

    /** emit.e:282		Code = append(Code, op)*/
    Append(&_36Code_21851, _36Code_21851, _op_51818);

    /** emit.e:283	end procedure*/
    return;
    ;
}


void _47emit_temp(object _tempsym_51852, object _referenced_51853)
{
    object _26661 = NOVALUE;
    object _26660 = NOVALUE;
    object _26659 = NOVALUE;
    object _26658 = NOVALUE;
    object _26657 = NOVALUE;
    object _26656 = NOVALUE;
    object _26655 = NOVALUE;
    object _26654 = NOVALUE;
    object _26653 = NOVALUE;
    object _26652 = NOVALUE;
    object _26651 = NOVALUE;
    object _26650 = NOVALUE;
    object _26649 = NOVALUE;
    object _26648 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:307		if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_36TRANSLATE_21361 != 0)
    goto L1; // [7] 129

    /** emit.e:308			if sequence(tempsym) then*/
    _26648 = IS_SEQUENCE(_tempsym_51852);
    if (_26648 == 0)
    {
        _26648 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26648 = NOVALUE;
    }

    /** emit.e:309				for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_51852)){
            _26649 = SEQ_PTR(_tempsym_51852)->length;
    }
    else {
        _26649 = 1;
    }
    {
        object _i_51860;
        _i_51860 = 1LL;
L3: 
        if (_i_51860 > _26649){
            goto L4; // [23] 50
        }

        /** emit.e:310					emit_temp( tempsym[i], referenced )*/
        _2 = (object)SEQ_PTR(_tempsym_51852);
        _26650 = (object)*(((s1_ptr)_2)->base + _i_51860);
        DeRef(_26651);
        _26651 = _referenced_51853;
        Ref(_26650);
        _47emit_temp(_26650, _26651);
        _26650 = NOVALUE;
        _26651 = NOVALUE;

        /** emit.e:311				end for*/
        _i_51860 = _i_51860 + 1LL;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** emit.e:313			elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_51852)) {
        _26652 = (_tempsym_51852 > 0LL);
    }
    else {
        _26652 = binary_op(GREATER, _tempsym_51852, 0LL);
    }
    if (IS_ATOM_INT(_26652)) {
        if (_26652 == 0) {
            DeRef(_26653);
            _26653 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26652)->dbl == 0.0) {
            DeRef(_26653);
            _26653 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_51852);
    _26654 = _54sym_mode(_tempsym_51852);
    if (IS_ATOM_INT(_26654)) {
        _26655 = (_26654 == 3LL);
    }
    else {
        _26655 = binary_op(EQUALS, _26654, 3LL);
    }
    DeRef(_26654);
    _26654 = NOVALUE;
    DeRef(_26653);
    if (IS_ATOM_INT(_26655))
    _26653 = (_26655 != 0);
    else
    _26653 = DBL_PTR(_26655)->dbl != 0.0;
L6: 
    if (_26653 == 0) {
        _26656 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_51852);
    _26657 = _47IsInteger(_tempsym_51852);
    if (IS_ATOM_INT(_26657)) {
        _26658 = (_26657 == 0);
    }
    else {
        _26658 = unary_op(NOT, _26657);
    }
    DeRef(_26657);
    _26657 = NOVALUE;
    if (IS_ATOM_INT(_26658))
    _26656 = (_26658 != 0);
    else
    _26656 = DBL_PTR(_26658)->dbl != 0.0;
L7: 
    if (_26656 == 0) {
        goto L8; // [92] 127
    }
    _26660 = find_from(_tempsym_51852, _47emitted_temps_51848, 1LL);
    _26661 = (_26660 == 0);
    _26660 = NOVALUE;
    if (_26661 == 0)
    {
        DeRef(_26661);
        _26661 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26661);
        _26661 = NOVALUE;
    }

    /** emit.e:319				emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_47emitted_temps_51848) && IS_ATOM(_tempsym_51852)) {
        Ref(_tempsym_51852);
        Append(&_47emitted_temps_51848, _47emitted_temps_51848, _tempsym_51852);
    }
    else if (IS_ATOM(_47emitted_temps_51848) && IS_SEQUENCE(_tempsym_51852)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51848, _47emitted_temps_51848, _tempsym_51852);
    }

    /** emit.e:320				emitted_temp_referenced &= referenced*/
    Append(&_47emitted_temp_referenced_51849, _47emitted_temp_referenced_51849, _referenced_51853);
L8: 
L5: 
L1: 

    /** emit.e:323	end procedure*/
    DeRef(_tempsym_51852);
    DeRef(_26658);
    _26658 = NOVALUE;
    DeRef(_26655);
    _26655 = NOVALUE;
    DeRef(_26652);
    _26652 = NOVALUE;
    return;
    ;
}


void _47flush_temps(object _except_for_51882)
{
    object _refs_51885 = NOVALUE;
    object _novalues_51886 = NOVALUE;
    object _sym_51891 = NOVALUE;
    object _26676 = NOVALUE;
    object _26675 = NOVALUE;
    object _26674 = NOVALUE;
    object _26673 = NOVALUE;
    object _26671 = NOVALUE;
    object _26667 = NOVALUE;
    object _26666 = NOVALUE;
    object _26664 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:332		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** emit.e:333			return*/
    DeRefDS(_except_for_51882);
    DeRef(_refs_51885);
    DeRefi(_novalues_51886);
    return;
L1: 

    /** emit.e:336		sequence*/

    /** emit.e:337			refs = {},*/
    RefDS(_22186);
    DeRef(_refs_51885);
    _refs_51885 = _22186;

    /** emit.e:338			novalues = {}*/
    RefDS(_22186);
    DeRefi(_novalues_51886);
    _novalues_51886 = _22186;

    /** emit.e:340		derefs = {}*/
    RefDS(_22186);
    DeRefi(_47derefs_51879);
    _47derefs_51879 = _22186;

    /** emit.e:341		for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_47emitted_temps_51848)){
            _26664 = SEQ_PTR(_47emitted_temps_51848)->length;
    }
    else {
        _26664 = 1;
    }
    {
        object _i_51888;
        _i_51888 = 1LL;
L2: 
        if (_i_51888 > _26664){
            goto L3; // [46] 119
        }

        /** emit.e:342			symtab_index sym = emitted_temps[i]*/
        _2 = (object)SEQ_PTR(_47emitted_temps_51848);
        _sym_51891 = (object)*(((s1_ptr)_2)->base + _i_51888);
        if (!IS_ATOM_INT(_sym_51891)){
            _sym_51891 = (object)DBL_PTR(_sym_51891)->dbl;
        }

        /** emit.e:344			if find( sym, except_for ) then*/
        _26666 = find_from(_sym_51891, _except_for_51882, 1LL);
        if (_26666 == 0)
        {
            _26666 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26666 = NOVALUE;
        }

        /** emit.e:345				continue*/
        goto L5; // [77] 114
L4: 

        /** emit.e:348			if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (object)SEQ_PTR(_47emitted_temp_referenced_51849);
        _26667 = (object)*(((s1_ptr)_2)->base + _i_51888);
        if (binary_op_a(NOTEQ, _26667, 1LL)){
            _26667 = NOVALUE;
            goto L6; // [88] 103
        }
        _26667 = NOVALUE;

        /** emit.e:349				derefs &= sym*/
        Append(&_47derefs_51879, _47derefs_51879, _sym_51891);
        goto L7; // [100] 110
L6: 

        /** emit.e:351				novalues &= sym*/
        Append(&_novalues_51886, _novalues_51886, _sym_51891);
L7: 

        /** emit.e:353		end for*/
L5: 
        _i_51888 = _i_51888 + 1LL;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** emit.e:355		if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_51882)){
            _26671 = SEQ_PTR(_except_for_51882)->length;
    }
    else {
        _26671 = 1;
    }
    if (_26671 != 0)
    goto L8; // [124] 132
    _26671 = NOVALUE;

    /** emit.e:356			clear_last()*/
    _47clear_last();
L8: 

    /** emit.e:359		for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_47derefs_51879)){
            _26673 = SEQ_PTR(_47derefs_51879)->length;
    }
    else {
        _26673 = 1;
    }
    {
        object _i_51906;
        _i_51906 = 1LL;
L9: 
        if (_i_51906 > _26673){
            goto LA; // [139] 171
        }

        /** emit.e:360			emit( DEREF_TEMP )*/
        _47emit(208LL);

        /** emit.e:361			emit( derefs[i] )*/
        _2 = (object)SEQ_PTR(_47derefs_51879);
        _26674 = (object)*(((s1_ptr)_2)->base + _i_51906);
        _47emit(_26674);
        _26674 = NOVALUE;

        /** emit.e:362		end for*/
        _i_51906 = _i_51906 + 1LL;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** emit.e:364		for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_51886)){
            _26675 = SEQ_PTR(_novalues_51886)->length;
    }
    else {
        _26675 = 1;
    }
    {
        object _i_51911;
        _i_51911 = 1LL;
LB: 
        if (_i_51911 > _26675){
            goto LC; // [176] 206
        }

        /** emit.e:365			emit( NOVALUE_TEMP )*/
        _47emit(209LL);

        /** emit.e:366			emit( novalues[i] )*/
        _2 = (object)SEQ_PTR(_novalues_51886);
        _26676 = (object)*(((s1_ptr)_2)->base + _i_51911);
        _47emit(_26676);
        _26676 = NOVALUE;

        /** emit.e:367		end for*/
        _i_51911 = _i_51911 + 1LL;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** emit.e:369		emitted_temps = {}*/
    RefDS(_22186);
    DeRef(_47emitted_temps_51848);
    _47emitted_temps_51848 = _22186;

    /** emit.e:370		emitted_temp_referenced = {}*/
    RefDS(_22186);
    DeRef(_47emitted_temp_referenced_51849);
    _47emitted_temp_referenced_51849 = _22186;

    /** emit.e:371	end procedure*/
    DeRefDS(_except_for_51882);
    DeRef(_refs_51885);
    DeRefi(_novalues_51886);
    return;
    ;
}


void _47flush_temp(object _temp_51918)
{
    object _except_for_51919 = NOVALUE;
    object _ix_51920 = NOVALUE;
    object _26678 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_51918)) {
        _1 = (object)(DBL_PTR(_temp_51918)->dbl);
        DeRefDS(_temp_51918);
        _temp_51918 = _1;
    }

    /** emit.e:374		sequence except_for = emitted_temps*/
    RefDS(_47emitted_temps_51848);
    DeRef(_except_for_51919);
    _except_for_51919 = _47emitted_temps_51848;

    /** emit.e:375		integer ix = find( temp, emitted_temps )*/
    _ix_51920 = find_from(_temp_51918, _47emitted_temps_51848, 1LL);

    /** emit.e:376		if ix then*/
    if (_ix_51920 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** emit.e:377			flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_51919);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51920)) ? _ix_51920 : (object)(DBL_PTR(_ix_51920)->dbl);
        int stop = (IS_ATOM_INT(_ix_51920)) ? _ix_51920 : (object)(DBL_PTR(_ix_51920)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
            RefDS(_except_for_51919);
            DeRef(_26678);
            _26678 = _except_for_51919;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_51919), start, &_26678 );
            }
            else Tail(SEQ_PTR(_except_for_51919), stop+1, &_26678);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_51919), start, &_26678);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26678);
            _26678 = _1;
        }
    }
    _47flush_temps(_26678);
    _26678 = NOVALUE;
L1: 

    /** emit.e:379	end procedure*/
    DeRef(_except_for_51919);
    return;
    ;
}


void _47check_for_temps()
{
    object _26685 = NOVALUE;
    object _26684 = NOVALUE;
    object _26683 = NOVALUE;
    object _26682 = NOVALUE;
    object _26680 = NOVALUE;
    object _26679 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:382		if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_36TRANSLATE_21361 != 0) {
        _26679 = 1;
        goto L1; // [5] 19
    }
    _26680 = (_47last_op_52257 < 1LL);
    _26679 = (_26680 != 0);
L1: 
    if (_26679 != 0) {
        goto L2; // [19] 34
    }
    _26682 = (_47last_pc_52258 < 1LL);
    if (_26682 == 0)
    {
        DeRef(_26682);
        _26682 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26682);
        _26682 = NOVALUE;
    }
L2: 

    /** emit.e:383			return*/
    DeRef(_26680);
    _26680 = NOVALUE;
    return;
L3: 

    /** emit.e:386		emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_36Code_21851);
    _26683 = _66current_op(_47last_pc_52258, _36Code_21851);
    _26684 = _66get_target_sym(_26683);
    _26683 = NOVALUE;
    _2 = (object)SEQ_PTR(_47op_temp_ref_52070);
    _26685 = (object)*(((s1_ptr)_2)->base + _47last_op_52257);
    _47emit_temp(_26684, _26685);
    _26684 = NOVALUE;
    _26685 = NOVALUE;

    /** emit.e:388	end procedure*/
    DeRef(_26680);
    _26680 = NOVALUE;
    return;
    ;
}


void _47clear_temp(object _tempsym_51945)
{
    object _ix_51946 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_51945)) {
        _1 = (object)(DBL_PTR(_tempsym_51945)->dbl);
        DeRefDS(_tempsym_51945);
        _tempsym_51945 = _1;
    }

    /** emit.e:391		integer ix = find( tempsym, emitted_temps )*/
    _ix_51946 = find_from(_tempsym_51945, _47emitted_temps_51848, 1LL);

    /** emit.e:392		if ix then*/
    if (_ix_51946 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** emit.e:393			emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temps_51848);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51946)) ? _ix_51946 : (object)(DBL_PTR(_ix_51946)->dbl);
        int stop = (IS_ATOM_INT(_ix_51946)) ? _ix_51946 : (object)(DBL_PTR(_ix_51946)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temps_51848), start, &_47emitted_temps_51848 );
            }
            else Tail(SEQ_PTR(_47emitted_temps_51848), stop+1, &_47emitted_temps_51848);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temps_51848), start, &_47emitted_temps_51848);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temps_51848 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temps_51848)->ref == 1));
        }
    }

    /** emit.e:394			emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_47emitted_temp_referenced_51849);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_51946)) ? _ix_51946 : (object)(DBL_PTR(_ix_51946)->dbl);
        int stop = (IS_ATOM_INT(_ix_51946)) ? _ix_51946 : (object)(DBL_PTR(_ix_51946)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_47emitted_temp_referenced_51849), start, &_47emitted_temp_referenced_51849 );
            }
            else Tail(SEQ_PTR(_47emitted_temp_referenced_51849), stop+1, &_47emitted_temp_referenced_51849);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_47emitted_temp_referenced_51849), start, &_47emitted_temp_referenced_51849);
        }
        else {
            assign_slice_seq = &assign_space;
            _47emitted_temp_referenced_51849 = Remove_elements(start, stop, (SEQ_PTR(_47emitted_temp_referenced_51849)->ref == 1));
        }
    }
L1: 

    /** emit.e:396	end procedure*/
    return;
    ;
}


object _47pop_temps()
{
    object _new_emitted_51953 = NOVALUE;
    object _new_referenced_51954 = NOVALUE;
    object _26689 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:402		sequence new_emitted  = emitted_temps*/
    RefDS(_47emitted_temps_51848);
    DeRef(_new_emitted_51953);
    _new_emitted_51953 = _47emitted_temps_51848;

    /** emit.e:403		sequence new_referenced = emitted_temp_referenced*/
    RefDS(_47emitted_temp_referenced_51849);
    DeRef(_new_referenced_51954);
    _new_referenced_51954 = _47emitted_temp_referenced_51849;

    /** emit.e:405		emitted_temps  = {}*/
    RefDS(_22186);
    DeRefDS(_47emitted_temps_51848);
    _47emitted_temps_51848 = _22186;

    /** emit.e:406		emitted_temp_referenced = {}*/
    RefDS(_22186);
    DeRefDS(_47emitted_temp_referenced_51849);
    _47emitted_temp_referenced_51849 = _22186;

    /** emit.e:407		return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_51954);
    RefDS(_new_emitted_51953);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _new_emitted_51953;
    ((intptr_t *)_2)[2] = _new_referenced_51954;
    _26689 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_51953);
    DeRefDS(_new_referenced_51954);
    return _26689;
    ;
}


object _47get_temps(object _add_to_51958)
{
    object _26694 = NOVALUE;
    object _26693 = NOVALUE;
    object _26692 = NOVALUE;
    object _26691 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:416		add_to[1] &= emitted_temps*/
    _2 = (object)SEQ_PTR(_add_to_51958);
    _26691 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_26691) && IS_ATOM(_47emitted_temps_51848)) {
    }
    else if (IS_ATOM(_26691) && IS_SEQUENCE(_47emitted_temps_51848)) {
        Ref(_26691);
        Prepend(&_26692, _47emitted_temps_51848, _26691);
    }
    else {
        Concat((object_ptr)&_26692, _26691, _47emitted_temps_51848);
        _26691 = NOVALUE;
    }
    _26691 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51958);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51958 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26692;
    if( _1 != _26692 ){
        DeRef(_1);
    }
    _26692 = NOVALUE;

    /** emit.e:417		add_to[2] &= emitted_temp_referenced*/
    _2 = (object)SEQ_PTR(_add_to_51958);
    _26693 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_26693) && IS_ATOM(_47emitted_temp_referenced_51849)) {
    }
    else if (IS_ATOM(_26693) && IS_SEQUENCE(_47emitted_temp_referenced_51849)) {
        Ref(_26693);
        Prepend(&_26694, _47emitted_temp_referenced_51849, _26693);
    }
    else {
        Concat((object_ptr)&_26694, _26693, _47emitted_temp_referenced_51849);
        _26693 = NOVALUE;
    }
    _26693 = NOVALUE;
    _2 = (object)SEQ_PTR(_add_to_51958);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _add_to_51958 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _26694;
    if( _1 != _26694 ){
        DeRef(_1);
    }
    _26694 = NOVALUE;

    /** emit.e:418		return add_to*/
    return _add_to_51958;
    ;
}


void _47push_temps(object _temps_51966)
{
    object _26697 = NOVALUE;
    object _26695 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:426		emitted_temps &= temps[1]*/
    _2 = (object)SEQ_PTR(_temps_51966);
    _26695 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_47emitted_temps_51848) && IS_ATOM(_26695)) {
        Ref(_26695);
        Append(&_47emitted_temps_51848, _47emitted_temps_51848, _26695);
    }
    else if (IS_ATOM(_47emitted_temps_51848) && IS_SEQUENCE(_26695)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temps_51848, _47emitted_temps_51848, _26695);
    }
    _26695 = NOVALUE;

    /** emit.e:427		emitted_temp_referenced &= temps[2]*/
    _2 = (object)SEQ_PTR(_temps_51966);
    _26697 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_47emitted_temp_referenced_51849) && IS_ATOM(_26697)) {
        Ref(_26697);
        Append(&_47emitted_temp_referenced_51849, _47emitted_temp_referenced_51849, _26697);
    }
    else if (IS_ATOM(_47emitted_temp_referenced_51849) && IS_SEQUENCE(_26697)) {
    }
    else {
        Concat((object_ptr)&_47emitted_temp_referenced_51849, _47emitted_temp_referenced_51849, _26697);
    }
    _26697 = NOVALUE;

    /** emit.e:428		flush_temps()*/
    RefDS(_22186);
    _47flush_temps(_22186);

    /** emit.e:429	end procedure*/
    DeRefDS(_temps_51966);
    return;
    ;
}


void _47backpatch(object _index_51973, object _val_51974)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_51973)) {
        _1 = (object)(DBL_PTR(_index_51973)->dbl);
        DeRefDS(_index_51973);
        _index_51973 = _1;
    }
    if (!IS_ATOM_INT(_val_51974)) {
        _1 = (object)(DBL_PTR(_val_51974)->dbl);
        DeRefDS(_val_51974);
        _val_51974 = _1;
    }

    /** emit.e:433			Code[index] = val*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_51973);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_51974;
    DeRef(_1);

    /** emit.e:434	end procedure*/
    return;
    ;
}


void _47cont11ii(object _op_52158, object _ii_52160)
{
    object _t_52161 = NOVALUE;
    object _source_52162 = NOVALUE;
    object _c_52163 = NOVALUE;
    object _26706 = NOVALUE;
    object _26705 = NOVALUE;
    object _26703 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:580		emit_opcode(op)*/
    _47emit_opcode(_op_52158);

    /** emit.e:581		source = Pop()*/
    _source_52162 = _47Pop();
    if (!IS_ATOM_INT(_source_52162)) {
        _1 = (object)(DBL_PTR(_source_52162)->dbl);
        DeRefDS(_source_52162);
        _source_52162 = _1;
    }

    /** emit.e:582		emit_addr(source)*/
    _47emit_addr(_source_52162);

    /** emit.e:583		assignable = TRUE*/
    _47assignable_51378 = _13TRUE_447;

    /** emit.e:584		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51976);
    _t_52161 = (object)*(((s1_ptr)_2)->base + _op_52158);

    /** emit.e:587		if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26703 = (_t_52161 == 1LL);
    if (_26703 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_52160 == 0) {
        _26705 = 0;
        goto L2; // [47] 59
    }
    _26706 = _47IsInteger(_source_52162);
    if (IS_ATOM_INT(_26706))
    _26705 = (_26706 != 0);
    else
    _26705 = DBL_PTR(_26706)->dbl != 0.0;
L2: 
    if (_26705 == 0)
    {
        _26705 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26705 = NOVALUE;
    }
L1: 

    /** emit.e:588			c = NewTempSym()*/
    _c_52163 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_52163)) {
        _1 = (object)(DBL_PTR(_c_52163)->dbl);
        DeRefDS(_c_52163);
        _c_52163 = _1;
    }

    /** emit.e:589			TempInteger(c)*/
    _47TempInteger(_c_52163);
    goto L4; // [77] 95
L3: 

    /** emit.e:591			c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_52163 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_52163)) {
        _1 = (object)(DBL_PTR(_c_52163)->dbl);
        DeRefDS(_c_52163);
        _c_52163 = _1;
    }

    /** emit.e:592			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_52163, 1LL);
L4: 

    /** emit.e:595		Push(c)*/
    _47Push(_c_52163);

    /** emit.e:596		emit_addr(c)*/
    _47emit_addr(_c_52163);

    /** emit.e:597	end procedure*/
    DeRef(_26706);
    _26706 = NOVALUE;
    DeRef(_26703);
    _26703 = NOVALUE;
    return;
    ;
}


void _47cont21d(object _op_52180, object _a_52181, object _b_52182, object _ii_52184)
{
    object _c_52185 = NOVALUE;
    object _t_52186 = NOVALUE;
    object _26716 = NOVALUE;
    object _26715 = NOVALUE;
    object _26714 = NOVALUE;
    object _26713 = NOVALUE;
    object _26711 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:602		assignable = TRUE*/
    _47assignable_51378 = _13TRUE_447;

    /** emit.e:603		t = op_result[op]*/
    _2 = (object)SEQ_PTR(_47op_result_51976);
    _t_52186 = (object)*(((s1_ptr)_2)->base + _op_52180);

    /** emit.e:604		if op = C_FUNC then*/
    if (_op_52180 != 133LL)
    goto L1; // [26] 38

    /** emit.e:605			emit_addr(CurrentSub)*/
    _47emit_addr(_36CurrentSub_21767);
L1: 

    /** emit.e:607		if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26711 = (_t_52186 == 1LL);
    if (_26711 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_52184 == 0) {
        _26713 = 0;
        goto L3; // [50] 62
    }
    _26714 = _47IsInteger(_a_52181);
    if (IS_ATOM_INT(_26714))
    _26713 = (_26714 != 0);
    else
    _26713 = DBL_PTR(_26714)->dbl != 0.0;
L3: 
    if (_26713 == 0) {
        DeRef(_26715);
        _26715 = 0;
        goto L4; // [62] 74
    }
    _26716 = _47IsInteger(_b_52182);
    if (IS_ATOM_INT(_26716))
    _26715 = (_26716 != 0);
    else
    _26715 = DBL_PTR(_26716)->dbl != 0.0;
L4: 
    if (_26715 == 0)
    {
        _26715 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26715 = NOVALUE;
    }
L2: 

    /** emit.e:608			c = NewTempSym()*/
    _c_52185 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_52185)) {
        _1 = (object)(DBL_PTR(_c_52185)->dbl);
        DeRefDS(_c_52185);
        _c_52185 = _1;
    }

    /** emit.e:609			TempInteger(c)*/
    _47TempInteger(_c_52185);
    goto L6; // [92] 110
L5: 

    /** emit.e:611			c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_52185 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_52185)) {
        _1 = (object)(DBL_PTR(_c_52185)->dbl);
        DeRefDS(_c_52185);
        _c_52185 = _1;
    }

    /** emit.e:612			emit_temp( c, NEW_REFERENCE )*/
    _47emit_temp(_c_52185, 1LL);
L6: 

    /** emit.e:614		Push(c)*/
    _47Push(_c_52185);

    /** emit.e:615		emit_addr(c)*/
    _47emit_addr(_c_52185);

    /** emit.e:616	end procedure*/
    DeRef(_26714);
    _26714 = NOVALUE;
    DeRef(_26711);
    _26711 = NOVALUE;
    DeRef(_26716);
    _26716 = NOVALUE;
    return;
    ;
}


void _47cont21ii(object _op_52208, object _ii_52210)
{
    object _a_52211 = NOVALUE;
    object _b_52212 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:621		b = Pop()*/
    _b_52212 = _47Pop();
    if (!IS_ATOM_INT(_b_52212)) {
        _1 = (object)(DBL_PTR(_b_52212)->dbl);
        DeRefDS(_b_52212);
        _b_52212 = _1;
    }

    /** emit.e:622		emit_opcode(op)*/
    _47emit_opcode(_op_52208);

    /** emit.e:623		a = Pop()*/
    _a_52211 = _47Pop();
    if (!IS_ATOM_INT(_a_52211)) {
        _1 = (object)(DBL_PTR(_a_52211)->dbl);
        DeRefDS(_a_52211);
        _a_52211 = _1;
    }

    /** emit.e:624		emit_addr(a)*/
    _47emit_addr(_a_52211);

    /** emit.e:625		emit_addr(b)*/
    _47emit_addr(_b_52212);

    /** emit.e:626		cont21d(op, a, b, ii)*/
    _47cont21d(_op_52208, _a_52211, _b_52212, _ii_52210);

    /** emit.e:627	end procedure*/
    return;
    ;
}


object _47good_string(object _elements_52217)
{
    object _obj_52218 = NOVALUE;
    object _ep_52220 = NOVALUE;
    object _e_52222 = NOVALUE;
    object _element_vals_52223 = NOVALUE;
    object _26739 = NOVALUE;
    object _26738 = NOVALUE;
    object _26737 = NOVALUE;
    object _26736 = NOVALUE;
    object _26735 = NOVALUE;
    object _26734 = NOVALUE;
    object _26733 = NOVALUE;
    object _26732 = NOVALUE;
    object _26731 = NOVALUE;
    object _26730 = NOVALUE;
    object _26729 = NOVALUE;
    object _26727 = NOVALUE;
    object _26724 = NOVALUE;
    object _26723 = NOVALUE;
    object _26722 = NOVALUE;
    object _26721 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:634		sequence element_vals*/

    /** emit.e:636		if TRANSLATE and length(elements) > 10000 then*/
    if (_36TRANSLATE_21361 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_52217)){
            _26722 = SEQ_PTR(_elements_52217)->length;
    }
    else {
        _26722 = 1;
    }
    _26723 = (_26722 > 10000LL);
    _26722 = NOVALUE;
    if (_26723 == 0)
    {
        DeRef(_26723);
        _26723 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26723);
        _26723 = NOVALUE;
    }

    /** emit.e:637			return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_52217);
    DeRef(_obj_52218);
    DeRef(_element_vals_52223);
    return -1LL;
L1: 

    /** emit.e:639		element_vals = {}*/
    RefDS(_22186);
    DeRef(_element_vals_52223);
    _element_vals_52223 = _22186;

    /** emit.e:640		for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_52217)){
            _26724 = SEQ_PTR(_elements_52217)->length;
    }
    else {
        _26724 = 1;
    }
    {
        object _i_52230;
        _i_52230 = 1LL;
L2: 
        if (_i_52230 > _26724){
            goto L3; // [43] 183
        }

        /** emit.e:641			ep = elements[i]*/
        _2 = (object)SEQ_PTR(_elements_52217);
        _ep_52220 = (object)*(((s1_ptr)_2)->base + _i_52230);
        if (!IS_ATOM_INT(_ep_52220)){
            _ep_52220 = (object)DBL_PTR(_ep_52220)->dbl;
        }

        /** emit.e:642			if ep < 1 then*/
        if (_ep_52220 >= 1LL)
        goto L4; // [60] 71

        /** emit.e:644				return -1*/
        DeRefDS(_elements_52217);
        DeRef(_obj_52218);
        DeRef(_element_vals_52223);
        return -1LL;
L4: 

        /** emit.e:646			e = ep*/
        _e_52222 = _ep_52220;

        /** emit.e:647			obj = SymTab[e][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26727 = (object)*(((s1_ptr)_2)->base + _e_52222);
        DeRef(_obj_52218);
        _2 = (object)SEQ_PTR(_26727);
        _obj_52218 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_obj_52218);
        _26727 = NOVALUE;

        /** emit.e:648			if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26729 = (object)*(((s1_ptr)_2)->base + _e_52222);
        _2 = (object)SEQ_PTR(_26729);
        _26730 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26729 = NOVALUE;
        if (IS_ATOM_INT(_26730)) {
            _26731 = (_26730 == 2LL);
        }
        else {
            _26731 = binary_op(EQUALS, _26730, 2LL);
        }
        _26730 = NOVALUE;
        if (IS_ATOM_INT(_26731)) {
            if (_26731 == 0) {
                DeRef(_26732);
                _26732 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26731)->dbl == 0.0) {
                DeRef(_26732);
                _26732 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_52218))
        _26733 = 1;
        else if (IS_ATOM_DBL(_obj_52218))
        _26733 = IS_ATOM_INT(DoubleToInt(_obj_52218));
        else
        _26733 = 0;
        DeRef(_26732);
        _26732 = (_26733 != 0);
L5: 
        if (_26732 == 0) {
            goto L6; // [123] 169
        }
        _26735 = (_36TRANSLATE_21361 == 0);
        if (_26735 != 0) {
            DeRef(_26736);
            _26736 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_52218)) {
            _26737 = (_obj_52218 >= 1LL);
        }
        else {
            _26737 = binary_op(GREATEREQ, _obj_52218, 1LL);
        }
        if (IS_ATOM_INT(_26737)) {
            if (_26737 == 0) {
                DeRef(_26738);
                _26738 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26737)->dbl == 0.0) {
                DeRef(_26738);
                _26738 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_52218)) {
            _26739 = (_obj_52218 <= 255LL);
        }
        else {
            _26739 = binary_op(LESSEQ, _obj_52218, 255LL);
        }
        DeRef(_26738);
        if (IS_ATOM_INT(_26739))
        _26738 = (_26739 != 0);
        else
        _26738 = DBL_PTR(_26739)->dbl != 0.0;
L8: 
        DeRef(_26736);
        _26736 = (_26738 != 0);
L7: 
        if (_26736 == 0)
        {
            _26736 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26736 = NOVALUE;
        }

        /** emit.e:653				element_vals = prepend(element_vals, obj)*/
        Ref(_obj_52218);
        Prepend(&_element_vals_52223, _element_vals_52223, _obj_52218);
        goto L9; // [166] 176
L6: 

        /** emit.e:655				return -1*/
        DeRefDS(_elements_52217);
        DeRef(_obj_52218);
        DeRef(_element_vals_52223);
        DeRef(_26739);
        _26739 = NOVALUE;
        DeRef(_26735);
        _26735 = NOVALUE;
        DeRef(_26737);
        _26737 = NOVALUE;
        DeRef(_26731);
        _26731 = NOVALUE;
        return -1LL;
L9: 

        /** emit.e:657		end for*/
        _i_52230 = _i_52230 + 1LL;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** emit.e:658		return element_vals*/
    DeRefDS(_elements_52217);
    DeRef(_obj_52218);
    DeRef(_26739);
    _26739 = NOVALUE;
    DeRef(_26735);
    _26735 = NOVALUE;
    DeRef(_26737);
    _26737 = NOVALUE;
    DeRef(_26731);
    _26731 = NOVALUE;
    return _element_vals_52223;
    ;
}


object _47Last_op()
{
    object _0, _1, _2;
    

    /** emit.e:664		return last_op*/
    return _47last_op_52257;
    ;
}


object _47Last_pc()
{
    object _0, _1, _2;
    

    /** emit.e:668		return last_pc*/
    return _47last_pc_52258;
    ;
}


void _47move_last_pc(object _amount_52265)
{
    object _0, _1, _2;
    

    /** emit.e:672		if last_pc > 0 then*/
    if (_47last_pc_52258 <= 0LL)
    goto L1; // [7] 20

    /** emit.e:673			last_pc += amount*/
    _47last_pc_52258 = _47last_pc_52258 + _amount_52265;
L1: 

    /** emit.e:675	end procedure*/
    return;
    ;
}


void _47clear_last()
{
    object _0, _1, _2;
    

    /** emit.e:678		last_op = 0*/
    _47last_op_52257 = 0LL;

    /** emit.e:679		last_pc = 0*/
    _47last_pc_52258 = 0LL;

    /** emit.e:680	end procedure*/
    return;
    ;
}


void _47clear_op()
{
    object _0, _1, _2;
    

    /** emit.e:683		previous_op = -1*/
    _36previous_op_21861 = -1LL;

    /** emit.e:684		assignable = FALSE*/
    _47assignable_51378 = _13FALSE_445;

    /** emit.e:685	end procedure*/
    return;
    ;
}


void _47inlined_function()
{
    object _0, _1, _2;
    

    /** emit.e:689		previous_op = PROC*/
    _36previous_op_21861 = 27LL;

    /** emit.e:690		assignable = TRUE*/
    _47assignable_51378 = _13TRUE_447;

    /** emit.e:691		inlined = TRUE*/
    _47inlined_52276 = _13TRUE_447;

    /** emit.e:692	end procedure*/
    return;
    ;
}


void _47add_inline_target(object _pc_52287)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52287)) {
        _1 = (object)(DBL_PTR(_pc_52287)->dbl);
        DeRefDS(_pc_52287);
        _pc_52287 = _1;
    }

    /** emit.e:696		inlined_targets &= pc*/
    Append(&_47inlined_targets_52284, _47inlined_targets_52284, _pc_52287);

    /** emit.e:697	end procedure*/
    return;
    ;
}


void _47clear_inline_targets()
{
    object _0, _1, _2;
    

    /** emit.e:700		inlined_targets = {}*/
    RefDS(_22186);
    DeRefi(_47inlined_targets_52284);
    _47inlined_targets_52284 = _22186;

    /** emit.e:701	end procedure*/
    return;
    ;
}


void _47emit_inline(object _code_52293)
{
    object _0, _1, _2;
    

    /** emit.e:704		last_pc = 0*/
    _47last_pc_52258 = 0LL;

    /** emit.e:705		last_op = 0*/
    _47last_op_52257 = 0LL;

    /** emit.e:706		Code &= code*/
    Concat((object_ptr)&_36Code_21851, _36Code_21851, _code_52293);

    /** emit.e:707	end procedure*/
    DeRefDS(_code_52293);
    return;
    ;
}


void _47emit_op(object _op_52298)
{
    object _a_52300 = NOVALUE;
    object _b_52301 = NOVALUE;
    object _c_52302 = NOVALUE;
    object _d_52303 = NOVALUE;
    object _source_52304 = NOVALUE;
    object _target_52305 = NOVALUE;
    object _subsym_52306 = NOVALUE;
    object _lhs_var_52308 = NOVALUE;
    object _ib_52309 = NOVALUE;
    object _ic_52310 = NOVALUE;
    object _n_52311 = NOVALUE;
    object _obj_52312 = NOVALUE;
    object _elements_52313 = NOVALUE;
    object _element_vals_52314 = NOVALUE;
    object _last_pc_backup_52315 = NOVALUE;
    object _last_op_backup_52316 = NOVALUE;
    object _temp_52325 = NOVALUE;
    object _real_op_52625 = NOVALUE;
    object _ref_52632 = NOVALUE;
    object _paths_52662 = NOVALUE;
    object _if_code_52742 = NOVALUE;
    object _if_code_52781 = NOVALUE;
    object _Top_inlined_Top_at_5482_53400 = NOVALUE;
    object _element_53471 = NOVALUE;
    object _Top_inlined_Top_at_7037_53618 = NOVALUE;
    object _31967 = NOVALUE;
    object _31966 = NOVALUE;
    object _27339 = NOVALUE;
    object _27338 = NOVALUE;
    object _27337 = NOVALUE;
    object _27333 = NOVALUE;
    object _27330 = NOVALUE;
    object _27328 = NOVALUE;
    object _27322 = NOVALUE;
    object _27321 = NOVALUE;
    object _27320 = NOVALUE;
    object _27318 = NOVALUE;
    object _27316 = NOVALUE;
    object _27315 = NOVALUE;
    object _27314 = NOVALUE;
    object _27313 = NOVALUE;
    object _27312 = NOVALUE;
    object _27311 = NOVALUE;
    object _27310 = NOVALUE;
    object _27309 = NOVALUE;
    object _27308 = NOVALUE;
    object _27307 = NOVALUE;
    object _27306 = NOVALUE;
    object _27304 = NOVALUE;
    object _27303 = NOVALUE;
    object _27302 = NOVALUE;
    object _27300 = NOVALUE;
    object _27299 = NOVALUE;
    object _27298 = NOVALUE;
    object _27297 = NOVALUE;
    object _27296 = NOVALUE;
    object _27295 = NOVALUE;
    object _27294 = NOVALUE;
    object _27293 = NOVALUE;
    object _27292 = NOVALUE;
    object _27289 = NOVALUE;
    object _27286 = NOVALUE;
    object _27285 = NOVALUE;
    object _27284 = NOVALUE;
    object _27283 = NOVALUE;
    object _27281 = NOVALUE;
    object _27279 = NOVALUE;
    object _27267 = NOVALUE;
    object _27259 = NOVALUE;
    object _27256 = NOVALUE;
    object _27255 = NOVALUE;
    object _27254 = NOVALUE;
    object _27253 = NOVALUE;
    object _27250 = NOVALUE;
    object _27249 = NOVALUE;
    object _27248 = NOVALUE;
    object _27247 = NOVALUE;
    object _27246 = NOVALUE;
    object _27245 = NOVALUE;
    object _27244 = NOVALUE;
    object _27243 = NOVALUE;
    object _27242 = NOVALUE;
    object _27241 = NOVALUE;
    object _27240 = NOVALUE;
    object _27238 = NOVALUE;
    object _27234 = NOVALUE;
    object _27233 = NOVALUE;
    object _27232 = NOVALUE;
    object _27231 = NOVALUE;
    object _27230 = NOVALUE;
    object _27229 = NOVALUE;
    object _27228 = NOVALUE;
    object _27227 = NOVALUE;
    object _27226 = NOVALUE;
    object _27225 = NOVALUE;
    object _27224 = NOVALUE;
    object _27222 = NOVALUE;
    object _27217 = NOVALUE;
    object _27216 = NOVALUE;
    object _27214 = NOVALUE;
    object _27213 = NOVALUE;
    object _27212 = NOVALUE;
    object _27210 = NOVALUE;
    object _27207 = NOVALUE;
    object _27203 = NOVALUE;
    object _27200 = NOVALUE;
    object _27199 = NOVALUE;
    object _27198 = NOVALUE;
    object _27197 = NOVALUE;
    object _27196 = NOVALUE;
    object _27195 = NOVALUE;
    object _27193 = NOVALUE;
    object _27192 = NOVALUE;
    object _27190 = NOVALUE;
    object _27189 = NOVALUE;
    object _27188 = NOVALUE;
    object _27187 = NOVALUE;
    object _27186 = NOVALUE;
    object _27185 = NOVALUE;
    object _27184 = NOVALUE;
    object _27183 = NOVALUE;
    object _27182 = NOVALUE;
    object _27181 = NOVALUE;
    object _27179 = NOVALUE;
    object _27178 = NOVALUE;
    object _27177 = NOVALUE;
    object _27176 = NOVALUE;
    object _27175 = NOVALUE;
    object _27174 = NOVALUE;
    object _27173 = NOVALUE;
    object _27172 = NOVALUE;
    object _27171 = NOVALUE;
    object _27170 = NOVALUE;
    object _27169 = NOVALUE;
    object _27168 = NOVALUE;
    object _27167 = NOVALUE;
    object _27166 = NOVALUE;
    object _27165 = NOVALUE;
    object _27163 = NOVALUE;
    object _27160 = NOVALUE;
    object _27159 = NOVALUE;
    object _27158 = NOVALUE;
    object _27157 = NOVALUE;
    object _27156 = NOVALUE;
    object _27155 = NOVALUE;
    object _27154 = NOVALUE;
    object _27153 = NOVALUE;
    object _27152 = NOVALUE;
    object _27151 = NOVALUE;
    object _27150 = NOVALUE;
    object _27149 = NOVALUE;
    object _27148 = NOVALUE;
    object _27147 = NOVALUE;
    object _27146 = NOVALUE;
    object _27144 = NOVALUE;
    object _27140 = NOVALUE;
    object _27138 = NOVALUE;
    object _27137 = NOVALUE;
    object _27135 = NOVALUE;
    object _27133 = NOVALUE;
    object _27131 = NOVALUE;
    object _27130 = NOVALUE;
    object _27128 = NOVALUE;
    object _27127 = NOVALUE;
    object _27126 = NOVALUE;
    object _27125 = NOVALUE;
    object _27124 = NOVALUE;
    object _27123 = NOVALUE;
    object _27122 = NOVALUE;
    object _27121 = NOVALUE;
    object _27120 = NOVALUE;
    object _27119 = NOVALUE;
    object _27118 = NOVALUE;
    object _27117 = NOVALUE;
    object _27116 = NOVALUE;
    object _27115 = NOVALUE;
    object _27114 = NOVALUE;
    object _27113 = NOVALUE;
    object _27112 = NOVALUE;
    object _27111 = NOVALUE;
    object _27110 = NOVALUE;
    object _27108 = NOVALUE;
    object _27106 = NOVALUE;
    object _27105 = NOVALUE;
    object _27103 = NOVALUE;
    object _27100 = NOVALUE;
    object _27099 = NOVALUE;
    object _27097 = NOVALUE;
    object _27096 = NOVALUE;
    object _27095 = NOVALUE;
    object _27093 = NOVALUE;
    object _27085 = NOVALUE;
    object _27084 = NOVALUE;
    object _27083 = NOVALUE;
    object _27082 = NOVALUE;
    object _27081 = NOVALUE;
    object _27080 = NOVALUE;
    object _27079 = NOVALUE;
    object _27078 = NOVALUE;
    object _27077 = NOVALUE;
    object _27076 = NOVALUE;
    object _27075 = NOVALUE;
    object _27074 = NOVALUE;
    object _27073 = NOVALUE;
    object _27072 = NOVALUE;
    object _27071 = NOVALUE;
    object _27070 = NOVALUE;
    object _27069 = NOVALUE;
    object _27068 = NOVALUE;
    object _27067 = NOVALUE;
    object _27066 = NOVALUE;
    object _27065 = NOVALUE;
    object _27064 = NOVALUE;
    object _27063 = NOVALUE;
    object _27062 = NOVALUE;
    object _27056 = NOVALUE;
    object _27055 = NOVALUE;
    object _27052 = NOVALUE;
    object _27049 = NOVALUE;
    object _27048 = NOVALUE;
    object _27047 = NOVALUE;
    object _27046 = NOVALUE;
    object _27045 = NOVALUE;
    object _27044 = NOVALUE;
    object _27043 = NOVALUE;
    object _27042 = NOVALUE;
    object _27041 = NOVALUE;
    object _27040 = NOVALUE;
    object _27038 = NOVALUE;
    object _27037 = NOVALUE;
    object _27036 = NOVALUE;
    object _27034 = NOVALUE;
    object _27032 = NOVALUE;
    object _27031 = NOVALUE;
    object _27030 = NOVALUE;
    object _27029 = NOVALUE;
    object _27028 = NOVALUE;
    object _27027 = NOVALUE;
    object _27026 = NOVALUE;
    object _27025 = NOVALUE;
    object _27024 = NOVALUE;
    object _27023 = NOVALUE;
    object _27021 = NOVALUE;
    object _27020 = NOVALUE;
    object _27018 = NOVALUE;
    object _27017 = NOVALUE;
    object _27016 = NOVALUE;
    object _27015 = NOVALUE;
    object _27014 = NOVALUE;
    object _27012 = NOVALUE;
    object _27011 = NOVALUE;
    object _27010 = NOVALUE;
    object _27009 = NOVALUE;
    object _27008 = NOVALUE;
    object _27007 = NOVALUE;
    object _27006 = NOVALUE;
    object _27005 = NOVALUE;
    object _27003 = NOVALUE;
    object _27002 = NOVALUE;
    object _27001 = NOVALUE;
    object _27000 = NOVALUE;
    object _26999 = NOVALUE;
    object _26997 = NOVALUE;
    object _26996 = NOVALUE;
    object _26994 = NOVALUE;
    object _26993 = NOVALUE;
    object _26992 = NOVALUE;
    object _26991 = NOVALUE;
    object _26990 = NOVALUE;
    object _26988 = NOVALUE;
    object _26986 = NOVALUE;
    object _26984 = NOVALUE;
    object _26983 = NOVALUE;
    object _26981 = NOVALUE;
    object _26980 = NOVALUE;
    object _26979 = NOVALUE;
    object _26978 = NOVALUE;
    object _26977 = NOVALUE;
    object _26976 = NOVALUE;
    object _26975 = NOVALUE;
    object _26974 = NOVALUE;
    object _26973 = NOVALUE;
    object _26972 = NOVALUE;
    object _26971 = NOVALUE;
    object _26970 = NOVALUE;
    object _26969 = NOVALUE;
    object _26968 = NOVALUE;
    object _26967 = NOVALUE;
    object _26966 = NOVALUE;
    object _26965 = NOVALUE;
    object _26962 = NOVALUE;
    object _26961 = NOVALUE;
    object _26959 = NOVALUE;
    object _26958 = NOVALUE;
    object _26957 = NOVALUE;
    object _26956 = NOVALUE;
    object _26955 = NOVALUE;
    object _26953 = NOVALUE;
    object _26951 = NOVALUE;
    object _26950 = NOVALUE;
    object _26949 = NOVALUE;
    object _26948 = NOVALUE;
    object _26947 = NOVALUE;
    object _26946 = NOVALUE;
    object _26945 = NOVALUE;
    object _26944 = NOVALUE;
    object _26943 = NOVALUE;
    object _26940 = NOVALUE;
    object _26939 = NOVALUE;
    object _26937 = NOVALUE;
    object _26936 = NOVALUE;
    object _26935 = NOVALUE;
    object _26934 = NOVALUE;
    object _26933 = NOVALUE;
    object _26930 = NOVALUE;
    object _26929 = NOVALUE;
    object _26928 = NOVALUE;
    object _26927 = NOVALUE;
    object _26926 = NOVALUE;
    object _26925 = NOVALUE;
    object _26924 = NOVALUE;
    object _26919 = NOVALUE;
    object _26918 = NOVALUE;
    object _26917 = NOVALUE;
    object _26915 = NOVALUE;
    object _26914 = NOVALUE;
    object _26912 = NOVALUE;
    object _26911 = NOVALUE;
    object _26906 = NOVALUE;
    object _26905 = NOVALUE;
    object _26904 = NOVALUE;
    object _26903 = NOVALUE;
    object _26902 = NOVALUE;
    object _26896 = NOVALUE;
    object _26895 = NOVALUE;
    object _26893 = NOVALUE;
    object _26892 = NOVALUE;
    object _26891 = NOVALUE;
    object _26890 = NOVALUE;
    object _26889 = NOVALUE;
    object _26888 = NOVALUE;
    object _26887 = NOVALUE;
    object _26886 = NOVALUE;
    object _26885 = NOVALUE;
    object _26884 = NOVALUE;
    object _26883 = NOVALUE;
    object _26881 = NOVALUE;
    object _26880 = NOVALUE;
    object _26879 = NOVALUE;
    object _26878 = NOVALUE;
    object _26877 = NOVALUE;
    object _26876 = NOVALUE;
    object _26875 = NOVALUE;
    object _26874 = NOVALUE;
    object _26873 = NOVALUE;
    object _26872 = NOVALUE;
    object _26871 = NOVALUE;
    object _26870 = NOVALUE;
    object _26869 = NOVALUE;
    object _26868 = NOVALUE;
    object _26866 = NOVALUE;
    object _26865 = NOVALUE;
    object _26864 = NOVALUE;
    object _26863 = NOVALUE;
    object _26860 = NOVALUE;
    object _26859 = NOVALUE;
    object _26858 = NOVALUE;
    object _26857 = NOVALUE;
    object _26855 = NOVALUE;
    object _26854 = NOVALUE;
    object _26853 = NOVALUE;
    object _26852 = NOVALUE;
    object _26850 = NOVALUE;
    object _26849 = NOVALUE;
    object _26848 = NOVALUE;
    object _26847 = NOVALUE;
    object _26846 = NOVALUE;
    object _26845 = NOVALUE;
    object _26844 = NOVALUE;
    object _26843 = NOVALUE;
    object _26842 = NOVALUE;
    object _26841 = NOVALUE;
    object _26840 = NOVALUE;
    object _26839 = NOVALUE;
    object _26838 = NOVALUE;
    object _26837 = NOVALUE;
    object _26835 = NOVALUE;
    object _26834 = NOVALUE;
    object _26833 = NOVALUE;
    object _26832 = NOVALUE;
    object _26831 = NOVALUE;
    object _26829 = NOVALUE;
    object _26828 = NOVALUE;
    object _26827 = NOVALUE;
    object _26826 = NOVALUE;
    object _26825 = NOVALUE;
    object _26821 = NOVALUE;
    object _26820 = NOVALUE;
    object _26819 = NOVALUE;
    object _26818 = NOVALUE;
    object _26817 = NOVALUE;
    object _26815 = NOVALUE;
    object _26814 = NOVALUE;
    object _26813 = NOVALUE;
    object _26812 = NOVALUE;
    object _26811 = NOVALUE;
    object _26810 = NOVALUE;
    object _26809 = NOVALUE;
    object _26808 = NOVALUE;
    object _26807 = NOVALUE;
    object _26806 = NOVALUE;
    object _26805 = NOVALUE;
    object _26804 = NOVALUE;
    object _26803 = NOVALUE;
    object _26802 = NOVALUE;
    object _26801 = NOVALUE;
    object _26800 = NOVALUE;
    object _26799 = NOVALUE;
    object _26798 = NOVALUE;
    object _26796 = NOVALUE;
    object _26795 = NOVALUE;
    object _26794 = NOVALUE;
    object _26793 = NOVALUE;
    object _26792 = NOVALUE;
    object _26791 = NOVALUE;
    object _26790 = NOVALUE;
    object _26789 = NOVALUE;
    object _26788 = NOVALUE;
    object _26786 = NOVALUE;
    object _26785 = NOVALUE;
    object _26784 = NOVALUE;
    object _26782 = NOVALUE;
    object _26781 = NOVALUE;
    object _26779 = NOVALUE;
    object _26777 = NOVALUE;
    object _26776 = NOVALUE;
    object _26775 = NOVALUE;
    object _26774 = NOVALUE;
    object _26773 = NOVALUE;
    object _26772 = NOVALUE;
    object _26768 = NOVALUE;
    object _26767 = NOVALUE;
    object _26766 = NOVALUE;
    object _26764 = NOVALUE;
    object _26763 = NOVALUE;
    object _26762 = NOVALUE;
    object _26761 = NOVALUE;
    object _26760 = NOVALUE;
    object _26759 = NOVALUE;
    object _26758 = NOVALUE;
    object _26757 = NOVALUE;
    object _26756 = NOVALUE;
    object _26755 = NOVALUE;
    object _26754 = NOVALUE;
    object _26753 = NOVALUE;
    object _26752 = NOVALUE;
    object _26751 = NOVALUE;
    object _26750 = NOVALUE;
    object _26745 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_52298)) {
        _1 = (object)(DBL_PTR(_op_52298)->dbl);
        DeRefDS(_op_52298);
        _op_52298 = _1;
    }

    /** emit.e:717		integer ib, ic, n*/

    /** emit.e:718		object obj*/

    /** emit.e:719		sequence elements*/

    /** emit.e:720		object element_vals*/

    /** emit.e:722		check_for_temps()*/
    _47check_for_temps();

    /** emit.e:723		integer last_pc_backup = last_pc*/
    _last_pc_backup_52315 = _47last_pc_52258;

    /** emit.e:724		integer last_op_backup = last_op*/
    _last_op_backup_52316 = _47last_op_52257;

    /** emit.e:726		last_op = op*/
    _47last_op_52257 = _op_52298;

    /** emit.e:727		last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_36Code_21851)){
            _26745 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _26745 = 1;
    }
    _47last_pc_52258 = _26745 + 1;
    _26745 = NOVALUE;

    /** emit.e:729		switch op label "EMIT" do*/
    _0 = _op_52298;
    switch ( _0 ){ 

        /** emit.e:730		case ASSIGN then*/
        case 18:

        /** emit.e:731			sequence temp = {}*/
        RefDS(_22186);
        DeRef(_temp_52325);
        _temp_52325 = _22186;

        /** emit.e:732			if not TRANSLATE and*/
        _26750 = (_36TRANSLATE_21361 == 0);
        if (_26750 == 0) {
            goto L1; // [70] 202
        }
        _26752 = (_36previous_op_21861 == 92LL);
        if (_26752 != 0) {
            DeRef(_26753);
            _26753 = 1;
            goto L2; // [82] 98
        }
        _26754 = (_36previous_op_21861 == 25LL);
        _26753 = (_26754 != 0);
L2: 
        if (_26753 == 0)
        {
            _26753 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26753 = NOVALUE;
        }

        /** emit.e:736				while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_36Code_21851)){
                _26755 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26755 = 1;
        }
        _26756 = _26755 - 1LL;
        _26755 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26757 = (object)*(((s1_ptr)_2)->base + _26756);
        if (IS_ATOM_INT(_26757)) {
            _26758 = (_26757 == 208LL);
        }
        else {
            _26758 = binary_op(EQUALS, _26757, 208LL);
        }
        _26757 = NOVALUE;
        if (IS_ATOM_INT(_26758)) {
            if (_26758 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26758)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_36Code_21851)){
                _26760 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26760 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26761 = (object)*(((s1_ptr)_2)->base + _26760);
        _26762 = find_from(_26761, _47derefs_51879, 1LL);
        _26761 = NOVALUE;
        if (_26762 == 0)
        {
            _26762 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26762 = NOVALUE;
        }

        /** emit.e:739					temp &= Code[$]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26763 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26763 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26764 = (object)*(((s1_ptr)_2)->base + _26763);
        if (IS_SEQUENCE(_temp_52325) && IS_ATOM(_26764)) {
            Ref(_26764);
            Append(&_temp_52325, _temp_52325, _26764);
        }
        else if (IS_ATOM(_temp_52325) && IS_SEQUENCE(_26764)) {
        }
        else {
            Concat((object_ptr)&_temp_52325, _temp_52325, _26764);
        }
        _26764 = NOVALUE;

        /** emit.e:740					Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26766 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26766 = 1;
        }
        _26767 = _26766 - 1LL;
        _26766 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21851)){
                _26768 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26768 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21851);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26767)) ? _26767 : (object)(DBL_PTR(_26767)->dbl);
            int stop = (IS_ATOM_INT(_26768)) ? _26768 : (object)(DBL_PTR(_26768)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21851), start, &_36Code_21851 );
                }
                else Tail(SEQ_PTR(_36Code_21851), stop+1, &_36Code_21851);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21851), start, &_36Code_21851);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21851 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21851)->ref == 1));
            }
        }
        _26767 = NOVALUE;
        _26768 = NOVALUE;

        /** emit.e:741					emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_52325);
        _47emit_temp(_temp_52325, 1LL);

        /** emit.e:742				end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** emit.e:746			source = Pop()*/
        _source_52304 = _47Pop();
        if (!IS_ATOM_INT(_source_52304)) {
            _1 = (object)(DBL_PTR(_source_52304)->dbl);
            DeRefDS(_source_52304);
            _source_52304 = _1;
        }

        /** emit.e:747			target = Pop()*/
        _target_52305 = _47Pop();
        if (!IS_ATOM_INT(_target_52305)) {
            _1 = (object)(DBL_PTR(_target_52305)->dbl);
            DeRefDS(_target_52305);
            _target_52305 = _1;
        }

        /** emit.e:748			if assignable then*/
        if (_47assignable_51378 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** emit.e:750				if inlined then*/
        if (_47inlined_52276 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** emit.e:751					inlined = 0*/
        _47inlined_52276 = 0LL;

        /** emit.e:752					if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_47inlined_targets_52284)){
                _26772 = SEQ_PTR(_47inlined_targets_52284)->length;
        }
        else {
            _26772 = 1;
        }
        if (_26772 == 0)
        {
            _26772 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26772 = NOVALUE;
        }

        /** emit.e:753						for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_47inlined_targets_52284)){
                _26773 = SEQ_PTR(_47inlined_targets_52284)->length;
        }
        else {
            _26773 = 1;
        }
        {
            object _i_52368;
            _i_52368 = 1LL;
L8: 
            if (_i_52368 > _26773){
                goto L9; // [252] 280
            }

            /** emit.e:754							Code[inlined_targets[i]] = target*/
            _2 = (object)SEQ_PTR(_47inlined_targets_52284);
            _26774 = (object)*(((s1_ptr)_2)->base + _i_52368);
            _2 = (object)SEQ_PTR(_36Code_21851);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _36Code_21851 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _26774);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _target_52305;
            DeRef(_1);

            /** emit.e:755						end for*/
            _i_52368 = _i_52368 + 1LL;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** emit.e:756						clear_inline_targets()*/

        /** emit.e:700		inlined_targets = {}*/
        RefDS(_22186);
        DeRefi(_47inlined_targets_52284);
        _47inlined_targets_52284 = _22186;

        /** emit.e:701	end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** emit.e:759					assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:760					clear_last()*/

        /** emit.e:678		last_op = 0*/
        _47last_op_52257 = 0LL;

        /** emit.e:679		last_pc = 0*/
        _47last_pc_52258 = 0LL;

        /** emit.e:680	end procedure*/
        goto LB; // [316] 319
LB: 

        /** emit.e:761					break "EMIT"*/
        DeRef(_temp_52325);
        _temp_52325 = NOVALUE;
        goto LC; // [323] 7739
L6: 

        /** emit.e:764				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26775 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26775 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26776 = (object)*(((s1_ptr)_2)->base + _26775);
        Ref(_26776);
        _47clear_temp(_26776);
        _26776 = NOVALUE;

        /** emit.e:765				Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26777 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26777 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_36Code_21851);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26777)) ? _26777 : (object)(DBL_PTR(_26777)->dbl);
            int stop = (IS_ATOM_INT(_26777)) ? _26777 : (object)(DBL_PTR(_26777)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_36Code_21851), start, &_36Code_21851 );
                }
                else Tail(SEQ_PTR(_36Code_21851), stop+1, &_36Code_21851);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_36Code_21851), start, &_36Code_21851);
            }
            else {
                assign_slice_seq = &assign_space;
                _36Code_21851 = Remove_elements(start, stop, (SEQ_PTR(_36Code_21851)->ref == 1));
            }
        }
        _26777 = NOVALUE;
        _26777 = NOVALUE;

        /** emit.e:766				op = previous_op -- keep same previous op*/
        _op_52298 = _36previous_op_21861;

        /** emit.e:767				if IsInteger(target) then*/
        _26779 = _47IsInteger(_target_52305);
        if (_26779 == 0) {
            DeRef(_26779);
            _26779 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26779) && DBL_PTR(_26779)->dbl == 0.0){
                DeRef(_26779);
                _26779 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26779);
            _26779 = NOVALUE;
        }
        DeRef(_26779);
        _26779 = NOVALUE;

        /** emit.e:768					if previous_op = RHS_SUBS then*/
        if (_36previous_op_21861 != 25LL)
        goto LE; // [381] 412

        /** emit.e:769						op = RHS_SUBS_I*/
        _op_52298 = 114LL;

        /** emit.e:770						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26781 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26781 = 1;
        }
        _26782 = _26781 - 2LL;
        _26781 = NOVALUE;
        _47backpatch(_26782, 114LL);
        _26782 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** emit.e:772					elsif previous_op = PLUS1 then*/
        if (_36previous_op_21861 != 93LL)
        goto L10; // [418] 449

        /** emit.e:773						op = PLUS1_I*/
        _op_52298 = 117LL;

        /** emit.e:774						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26784 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26784 = 1;
        }
        _26785 = _26784 - 2LL;
        _26784 = NOVALUE;
        _47backpatch(_26785, 117LL);
        _26785 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** emit.e:776					elsif previous_op = PLUS or previous_op = MINUS then*/
        _26786 = (_36previous_op_21861 == 11LL);
        if (_26786 != 0) {
            goto L11; // [459] 476
        }
        _26788 = (_36previous_op_21861 == 10LL);
        if (_26788 == 0)
        {
            DeRef(_26788);
            _26788 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26788);
            _26788 = NOVALUE;
        }
L11: 

        /** emit.e:777						if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26789 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26789 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26790 = (object)*(((s1_ptr)_2)->base + _26789);
        Ref(_26790);
        _26791 = _47IsInteger(_26790);
        _26790 = NOVALUE;
        if (IS_ATOM_INT(_26791)) {
            if (_26791 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26791)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_36Code_21851)){
                _26793 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26793 = 1;
        }
        _26794 = _26793 - 1LL;
        _26793 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26795 = (object)*(((s1_ptr)_2)->base + _26794);
        Ref(_26795);
        _26796 = _47IsInteger(_26795);
        _26795 = NOVALUE;
        if (_26796 == 0) {
            DeRef(_26796);
            _26796 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26796) && DBL_PTR(_26796)->dbl == 0.0){
                DeRef(_26796);
                _26796 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26796);
            _26796 = NOVALUE;
        }
        DeRef(_26796);
        _26796 = NOVALUE;

        /** emit.e:779							if previous_op = PLUS then*/
        if (_36previous_op_21861 != 11LL)
        goto L13; // [522] 538

        /** emit.e:780								op = PLUS_I*/
        _op_52298 = 115LL;
        goto L14; // [535] 548
L13: 

        /** emit.e:782								op = MINUS_I*/
        _op_52298 = 116LL;
L14: 

        /** emit.e:784							backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26798 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26798 = 1;
        }
        _26799 = _26798 - 2LL;
        _26798 = NOVALUE;
        _47backpatch(_26799, _op_52298);
        _26799 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** emit.e:790						if IsInteger(source) then*/
        _26800 = _47IsInteger(_source_52304);
        if (_26800 == 0) {
            DeRef(_26800);
            _26800 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26800) && DBL_PTR(_26800)->dbl == 0.0){
                DeRef(_26800);
                _26800 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26800);
            _26800 = NOVALUE;
        }
        DeRef(_26800);
        _26800 = NOVALUE;

        /** emit.e:791							op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_52298 = 113LL;
L15: 
LF: 
LD: 

        /** emit.e:795				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:796				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto L16; // [598] 743
L5: 

        /** emit.e:798				if IsInteger(source) and IsInteger(target) then*/
        _26801 = _47IsInteger(_source_52304);
        if (IS_ATOM_INT(_26801)) {
            if (_26801 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26801)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26803 = _47IsInteger(_target_52305);
        if (_26803 == 0) {
            DeRef(_26803);
            _26803 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26803) && DBL_PTR(_26803)->dbl == 0.0){
                DeRef(_26803);
                _26803 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26803);
            _26803 = NOVALUE;
        }
        DeRef(_26803);
        _26803 = NOVALUE;

        /** emit.e:799					op = ASSIGN_I*/
        _op_52298 = 113LL;
L17: 

        /** emit.e:801				if source > 0 and target > 0 and*/
        _26804 = (_source_52304 > 0LL);
        if (_26804 == 0) {
            _26805 = 0;
            goto L18; // [635] 647
        }
        _26806 = (_target_52305 > 0LL);
        _26805 = (_26806 != 0);
L18: 
        if (_26805 == 0) {
            _26807 = 0;
            goto L19; // [647] 673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26808 = (object)*(((s1_ptr)_2)->base + _source_52304);
        _2 = (object)SEQ_PTR(_26808);
        _26809 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26808 = NOVALUE;
        if (IS_ATOM_INT(_26809)) {
            _26810 = (_26809 == 2LL);
        }
        else {
            _26810 = binary_op(EQUALS, _26809, 2LL);
        }
        _26809 = NOVALUE;
        if (IS_ATOM_INT(_26810))
        _26807 = (_26810 != 0);
        else
        _26807 = DBL_PTR(_26810)->dbl != 0.0;
L19: 
        if (_26807 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26812 = (object)*(((s1_ptr)_2)->base + _target_52305);
        _2 = (object)SEQ_PTR(_26812);
        _26813 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26812 = NOVALUE;
        if (IS_ATOM_INT(_26813)) {
            _26814 = (_26813 == 2LL);
        }
        else {
            _26814 = binary_op(EQUALS, _26813, 2LL);
        }
        _26813 = NOVALUE;
        if (_26814 == 0) {
            DeRef(_26814);
            _26814 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26814) && DBL_PTR(_26814)->dbl == 0.0){
                DeRef(_26814);
                _26814 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26814);
            _26814 = NOVALUE;
        }
        DeRef(_26814);
        _26814 = NOVALUE;

        /** emit.e:806					SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_target_52305 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26817 = (object)*(((s1_ptr)_2)->base + _source_52304);
        _2 = (object)SEQ_PTR(_26817);
        _26818 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26817 = NOVALUE;
        Ref(_26818);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26818;
        if( _1 != _26818 ){
            DeRef(_1);
        }
        _26818 = NOVALUE;
        _26815 = NOVALUE;
L1A: 

        /** emit.e:809				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:810				emit_addr(source)*/
        _47emit_addr(_source_52304);

        /** emit.e:811				last_op = op*/
        _47last_op_52257 = _op_52298;
L16: 

        /** emit.e:814			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:815			emit_addr(target)*/
        _47emit_addr(_target_52305);

        /** emit.e:817			if length(temp) then*/
        if (IS_SEQUENCE(_temp_52325)){
                _26819 = SEQ_PTR(_temp_52325)->length;
        }
        else {
            _26819 = 1;
        }
        if (_26819 == 0)
        {
            _26819 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26819 = NOVALUE;
        }

        /** emit.e:819				for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_52325)){
                _26820 = SEQ_PTR(_temp_52325)->length;
        }
        else {
            _26820 = 1;
        }
        {
            object _i_52471;
            _i_52471 = 1LL;
L1C: 
            if (_i_52471 > _26820){
                goto L1D; // [768] 791
            }

            /** emit.e:820					flush_temp( temp[i] )*/
            _2 = (object)SEQ_PTR(_temp_52325);
            _26821 = (object)*(((s1_ptr)_2)->base + _i_52471);
            Ref(_26821);
            _47flush_temp(_26821);
            _26821 = NOVALUE;

            /** emit.e:821				end for*/
            _i_52471 = _i_52471 + 1LL;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_52325);
        _temp_52325 = NOVALUE;
        goto LC; // [794] 7739

        /** emit.e:824		case RHS_SUBS then*/
        case 25:

        /** emit.e:825			b = Pop() -- subscript*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:826			c = Pop() -- sequence*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:827			target = NewTempSym() -- target*/
        _target_52305 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_target_52305)) {
            _1 = (object)(DBL_PTR(_target_52305)->dbl);
            DeRefDS(_target_52305);
            _target_52305 = _1;
        }

        /** emit.e:828			if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26825 = (_c_52302 < 0LL);
        if (_26825 != 0) {
            _26826 = 1;
            goto L1E; // [828] 851
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26827 = (object)*(((s1_ptr)_2)->base + _c_52302);
        if (IS_SEQUENCE(_26827)){
                _26828 = SEQ_PTR(_26827)->length;
        }
        else {
            _26828 = 1;
        }
        _26827 = NOVALUE;
        _26829 = (_26828 < 15LL);
        _26828 = NOVALUE;
        _26826 = (_26829 != 0);
L1E: 
        if (_26826 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26831 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_26831);
        _26832 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26831 = NOVALUE;
        if (IS_ATOM_INT(_26832)) {
            _26833 = (_26832 < 0LL);
        }
        else {
            _26833 = binary_op(LESS, _26832, 0LL);
        }
        _26832 = NOVALUE;
        if (_26833 == 0) {
            DeRef(_26833);
            _26833 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26833) && DBL_PTR(_26833)->dbl == 0.0){
                DeRef(_26833);
                _26833 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26833);
            _26833 = NOVALUE;
        }
        DeRef(_26833);
        _26833 = NOVALUE;
L1F: 

        /** emit.e:830				op = RHS_SUBS_CHECK*/
        _op_52298 = 92LL;
        goto L21; // [885] 1049
L20: 

        /** emit.e:831			elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26834 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_26834);
        _26835 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26834 = NOVALUE;
        if (binary_op_a(NOTEQ, _26835, 1LL)){
            _26835 = NOVALUE;
            goto L22; // [904] 991
        }
        _26835 = NOVALUE;

        /** emit.e:832				if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26837 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_26837);
        _26838 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26837 = NOVALUE;
        if (IS_ATOM_INT(_26838)) {
            _26839 = (_26838 != _54sequence_type_47136);
        }
        else {
            _26839 = binary_op(NOTEQ, _26838, _54sequence_type_47136);
        }
        _26838 = NOVALUE;
        if (IS_ATOM_INT(_26839)) {
            if (_26839 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26839)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26841 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_26841);
        _26842 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26841 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_26842)){
            _26843 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26842)->dbl));
        }
        else{
            _26843 = (object)*(((s1_ptr)_2)->base + _26842);
        }
        _2 = (object)SEQ_PTR(_26843);
        _26844 = (object)*(((s1_ptr)_2)->base + 2LL);
        _26843 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_26844)){
            _26845 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26844)->dbl));
        }
        else{
            _26845 = (object)*(((s1_ptr)_2)->base + _26844);
        }
        _2 = (object)SEQ_PTR(_26845);
        _26846 = (object)*(((s1_ptr)_2)->base + 15LL);
        _26845 = NOVALUE;
        if (IS_ATOM_INT(_26846)) {
            _26847 = (_26846 != _54sequence_type_47136);
        }
        else {
            _26847 = binary_op(NOTEQ, _26846, _54sequence_type_47136);
        }
        _26846 = NOVALUE;
        if (_26847 == 0) {
            DeRef(_26847);
            _26847 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26847) && DBL_PTR(_26847)->dbl == 0.0){
                DeRef(_26847);
                _26847 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26847);
            _26847 = NOVALUE;
        }
        DeRef(_26847);
        _26847 = NOVALUE;

        /** emit.e:835					op = RHS_SUBS_CHECK*/
        _op_52298 = 92LL;
        goto L21; // [988] 1049
L22: 

        /** emit.e:837			elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26848 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_26848);
        _26849 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26848 = NOVALUE;
        if (IS_ATOM_INT(_26849)) {
            _26850 = (_26849 != 2LL);
        }
        else {
            _26850 = binary_op(NOTEQ, _26849, 2LL);
        }
        _26849 = NOVALUE;
        if (IS_ATOM_INT(_26850)) {
            if (_26850 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26850)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26852 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_26852);
        _26853 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26852 = NOVALUE;
        _26854 = IS_SEQUENCE(_26853);
        _26853 = NOVALUE;
        _26855 = (_26854 == 0);
        _26854 = NOVALUE;
        if (_26855 == 0)
        {
            DeRef(_26855);
            _26855 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26855);
            _26855 = NOVALUE;
        }
L23: 

        /** emit.e:839				op = RHS_SUBS_CHECK*/
        _op_52298 = 92LL;
L24: 
L21: 

        /** emit.e:841			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:842			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:843			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:844			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:845			Push(target)*/
        _47Push(_target_52305);

        /** emit.e:846			emit_addr(target)*/
        _47emit_addr(_target_52305);

        /** emit.e:847			emit_temp(target, NEW_REFERENCE)*/
        _47emit_temp(_target_52305, 1LL);

        /** emit.e:848			current_sequence = append(current_sequence, target)*/
        Append(&_47current_sequence_51368, _47current_sequence_51368, _target_52305);

        /** emit.e:849			flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26857 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26857 = 1;
        }
        _26858 = _26857 - 2LL;
        _26857 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26859 = (object)*(((s1_ptr)_2)->base + _26858);
        Ref(_26859);
        _47flush_temp(_26859);
        _26859 = NOVALUE;
        goto LC; // [1113] 7739

        /** emit.e:851		case PROC then -- procedure, function and type calls*/
        case 27:

        /** emit.e:853			assignable = FALSE -- assume for now*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:854			subsym = op_info1*/
        _subsym_52306 = _47op_info1_51360;

        /** emit.e:855			n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26860 = (object)*(((s1_ptr)_2)->base + _subsym_52306);
        _2 = (object)SEQ_PTR(_26860);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
            _n_52311 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
        }
        else{
            _n_52311 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
        }
        if (!IS_ATOM_INT(_n_52311)){
            _n_52311 = (object)DBL_PTR(_n_52311)->dbl;
        }
        _26860 = NOVALUE;

        /** emit.e:857			if subsym = CurrentSub then*/
        if (_subsym_52306 != _36CurrentSub_21767)
        goto L25; // [1155] 1340

        /** emit.e:860				for i = cgi-n+1 to cgi do*/
        _26863 = _47cgi_51376 - _n_52311;
        if ((object)((uintptr_t)_26863 +(uintptr_t) HIGH_BITS) >= 0){
            _26863 = NewDouble((eudouble)_26863);
        }
        if (IS_ATOM_INT(_26863)) {
            _26864 = _26863 + 1;
            if (_26864 > MAXINT){
                _26864 = NewDouble((eudouble)_26864);
            }
        }
        else
        _26864 = binary_op(PLUS, 1, _26863);
        DeRef(_26863);
        _26863 = NOVALUE;
        _26865 = _47cgi_51376;
        {
            object _i_52557;
            Ref(_26864);
            _i_52557 = _26864;
L26: 
            if (binary_op_a(GREATER, _i_52557, _26865)){
                goto L27; // [1176] 1339
            }

            /** emit.e:861					if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26866 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26866 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            if (binary_op_a(LESSEQ, _26866, 0LL)){
                _26866 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26866 = NOVALUE;

            /** emit.e:862						if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26868 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26868 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_26868)){
                _26869 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26868)->dbl));
            }
            else{
                _26869 = (object)*(((s1_ptr)_2)->base + _26868);
            }
            _2 = (object)SEQ_PTR(_26869);
            _26870 = (object)*(((s1_ptr)_2)->base + 4LL);
            _26869 = NOVALUE;
            if (IS_ATOM_INT(_26870)) {
                _26871 = (_26870 == 3LL);
            }
            else {
                _26871 = binary_op(EQUALS, _26870, 3LL);
            }
            _26870 = NOVALUE;
            if (IS_ATOM_INT(_26871)) {
                if (_26871 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26871)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26873 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26873 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_26873)){
                _26874 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_26873)->dbl));
            }
            else{
                _26874 = (object)*(((s1_ptr)_2)->base + _26873);
            }
            _2 = (object)SEQ_PTR(_26874);
            _26875 = (object)*(((s1_ptr)_2)->base + 16LL);
            _26874 = NOVALUE;
            if (IS_ATOM_INT(_26875) && IS_ATOM_INT(_i_52557)) {
                _26876 = (_26875 < _i_52557);
            }
            else {
                _26876 = binary_op(LESS, _26875, _i_52557);
            }
            _26875 = NOVALUE;
            if (_26876 == 0) {
                DeRef(_26876);
                _26876 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26876) && DBL_PTR(_26876)->dbl == 0.0){
                    DeRef(_26876);
                    _26876 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26876);
                _26876 = NOVALUE;
            }
            DeRef(_26876);
            _26876 = NOVALUE;

            /** emit.e:865							emit_opcode(ASSIGN)*/
            _47emit_opcode(18LL);

            /** emit.e:866							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26877 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            Ref(_26877);
            _47emit_addr(_26877);
            _26877 = NOVALUE;

            /** emit.e:867							cg_stack[i] = NewTempSym()*/
            _26878 = _54NewTempSym(0LL);
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _i_52557);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _26878;
            if( _1 != _26878 ){
                DeRef(_1);
            }
            _26878 = NOVALUE;

            /** emit.e:868							emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26879 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26879 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            Ref(_26879);
            _47emit_addr(_26879);
            _26879 = NOVALUE;

            /** emit.e:869							check_for_temps()*/
            _47check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** emit.e:870						elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26880 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            Ref(_26880);
            _26881 = _54sym_mode(_26880);
            _26880 = NOVALUE;
            if (binary_op_a(NOTEQ, _26881, 3LL)){
                DeRef(_26881);
                _26881 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26881);
            _26881 = NOVALUE;

            /** emit.e:871							emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52557)){
                _26883 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52557)->dbl));
            }
            else{
                _26883 = (object)*(((s1_ptr)_2)->base + _i_52557);
            }
            Ref(_26883);
            _47emit_temp(_26883, 1LL);
            _26883 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** emit.e:874				end for*/
            _0 = _i_52557;
            if (IS_ATOM_INT(_i_52557)) {
                _i_52557 = _i_52557 + 1LL;
                if ((object)((uintptr_t)_i_52557 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52557 = NewDouble((eudouble)_i_52557);
                }
            }
            else {
                _i_52557 = binary_op_a(PLUS, _i_52557, 1LL);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_52557);
        }
L25: 

        /** emit.e:877			if SymTab[subsym][S_DEPRECATED] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26884 = (object)*(((s1_ptr)_2)->base + _subsym_52306);
        _2 = (object)SEQ_PTR(_26884);
        _26885 = (object)*(((s1_ptr)_2)->base + 30LL);
        _26884 = NOVALUE;
        if (_26885 == 0) {
            _26885 = NOVALUE;
            goto L2C; // [1354] 1383
        }
        else {
            if (!IS_ATOM_INT(_26885) && DBL_PTR(_26885)->dbl == 0.0){
                _26885 = NOVALUE;
                goto L2C; // [1354] 1383
            }
            _26885 = NOVALUE;
        }
        _26885 = NOVALUE;

        /** emit.e:878				Warning(327, deprecated_warning_flag, { SymTab[subsym][S_NAME] })*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26886 = (object)*(((s1_ptr)_2)->base + _subsym_52306);
        _2 = (object)SEQ_PTR(_26886);
        if (!IS_ATOM_INT(_36S_NAME_21396)){
            _26887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
        }
        else{
            _26887 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
        }
        _26886 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_26887);
        ((intptr_t*)_2)[1] = _26887;
        _26888 = MAKE_SEQ(_1);
        _26887 = NOVALUE;
        _50Warning(327LL, 16384LL, _26888);
        _26888 = NOVALUE;
L2C: 

        /** emit.e:881			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:882			emit_addr(subsym)*/
        _47emit_addr(_subsym_52306);

        /** emit.e:883			for i = cgi-n+1 to cgi do*/
        _26889 = _47cgi_51376 - _n_52311;
        if ((object)((uintptr_t)_26889 +(uintptr_t) HIGH_BITS) >= 0){
            _26889 = NewDouble((eudouble)_26889);
        }
        if (IS_ATOM_INT(_26889)) {
            _26890 = _26889 + 1;
            if (_26890 > MAXINT){
                _26890 = NewDouble((eudouble)_26890);
            }
        }
        else
        _26890 = binary_op(PLUS, 1, _26889);
        DeRef(_26889);
        _26889 = NOVALUE;
        _26891 = _47cgi_51376;
        {
            object _i_52604;
            Ref(_26890);
            _i_52604 = _26890;
L2D: 
            if (binary_op_a(GREATER, _i_52604, _26891)){
                goto L2E; // [1410] 1447
            }

            /** emit.e:884				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52604)){
                _26892 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52604)->dbl));
            }
            else{
                _26892 = (object)*(((s1_ptr)_2)->base + _i_52604);
            }
            Ref(_26892);
            _47emit_addr(_26892);
            _26892 = NOVALUE;

            /** emit.e:885				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52604)){
                _26893 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52604)->dbl));
            }
            else{
                _26893 = (object)*(((s1_ptr)_2)->base + _i_52604);
            }
            Ref(_26893);
            _47emit_temp(_26893, 1LL);
            _26893 = NOVALUE;

            /** emit.e:886			end for*/
            _0 = _i_52604;
            if (IS_ATOM_INT(_i_52604)) {
                _i_52604 = _i_52604 + 1LL;
                if ((object)((uintptr_t)_i_52604 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52604 = NewDouble((eudouble)_i_52604);
                }
            }
            else {
                _i_52604 = binary_op_a(PLUS, _i_52604, 1LL);
            }
            DeRef(_0);
            goto L2D; // [1442] 1417
L2E: 
            ;
            DeRef(_i_52604);
        }

        /** emit.e:888			cgi -= n*/
        _47cgi_51376 = _47cgi_51376 - _n_52311;

        /** emit.e:890			if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26895 = (object)*(((s1_ptr)_2)->base + _subsym_52306);
        _2 = (object)SEQ_PTR(_26895);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _26896 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _26896 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        _26895 = NOVALUE;
        if (binary_op_a(EQUALS, _26896, 27LL)){
            _26896 = NOVALUE;
            goto LC; // [1471] 7739
        }
        _26896 = NOVALUE;

        /** emit.e:891				assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:892				c = NewTempSym() -- put final result in temp*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:893				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);

        /** emit.e:894				Push(c)*/
        _47Push(_c_52302);

        /** emit.e:896				emit_addr(c)*/
        _47emit_addr(_c_52302);
        goto LC; // [1507] 7739

        /** emit.e:900		case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** emit.e:901			assignable = FALSE -- assume for now*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:902			integer real_op*/

        /** emit.e:903			if op = PROC_FORWARD then*/
        if (_op_52298 != 195LL)
        goto L2F; // [1528] 1544

        /** emit.e:904				real_op = PROC*/
        _real_op_52625 = 27LL;
        goto L30; // [1541] 1554
L2F: 

        /** emit.e:906				real_op = FUNC*/
        _real_op_52625 = 501LL;
L30: 

        /** emit.e:908			integer ref*/

        /** emit.e:909			ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_52632 = _44new_forward_reference(_real_op_52625, _47op_info1_51360, _real_op_52625);
        if (!IS_ATOM_INT(_ref_52632)) {
            _1 = (object)(DBL_PTR(_ref_52632)->dbl);
            DeRefDS(_ref_52632);
            _ref_52632 = _1;
        }

        /** emit.e:910			n = Pop() -- number of known args*/
        _n_52311 = _47Pop();
        if (!IS_ATOM_INT(_n_52311)) {
            _1 = (object)(DBL_PTR(_n_52311)->dbl);
            DeRefDS(_n_52311);
            _n_52311 = _1;
        }

        /** emit.e:912			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:913			emit_addr(ref)*/
        _47emit_addr(_ref_52632);

        /** emit.e:914			emit_addr( n ) -- this changes to be the "next" instruction*/
        _47emit_addr(_n_52311);

        /** emit.e:915			for i = cgi-n+1 to cgi do*/
        _26902 = _47cgi_51376 - _n_52311;
        if ((object)((uintptr_t)_26902 +(uintptr_t) HIGH_BITS) >= 0){
            _26902 = NewDouble((eudouble)_26902);
        }
        if (IS_ATOM_INT(_26902)) {
            _26903 = _26902 + 1;
            if (_26903 > MAXINT){
                _26903 = NewDouble((eudouble)_26903);
            }
        }
        else
        _26903 = binary_op(PLUS, 1, _26902);
        DeRef(_26902);
        _26902 = NOVALUE;
        _26904 = _47cgi_51376;
        {
            object _i_52637;
            Ref(_26903);
            _i_52637 = _26903;
L31: 
            if (binary_op_a(GREATER, _i_52637, _26904)){
                goto L32; // [1609] 1646
            }

            /** emit.e:916				emit_addr(cg_stack[i])*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52637)){
                _26905 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52637)->dbl));
            }
            else{
                _26905 = (object)*(((s1_ptr)_2)->base + _i_52637);
            }
            Ref(_26905);
            _47emit_addr(_26905);
            _26905 = NOVALUE;

            /** emit.e:917				emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (object)SEQ_PTR(_47cg_stack_51375);
            if (!IS_ATOM_INT(_i_52637)){
                _26906 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_52637)->dbl));
            }
            else{
                _26906 = (object)*(((s1_ptr)_2)->base + _i_52637);
            }
            Ref(_26906);
            _47emit_temp(_26906, 1LL);
            _26906 = NOVALUE;

            /** emit.e:918			end for*/
            _0 = _i_52637;
            if (IS_ATOM_INT(_i_52637)) {
                _i_52637 = _i_52637 + 1LL;
                if ((object)((uintptr_t)_i_52637 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_52637 = NewDouble((eudouble)_i_52637);
                }
            }
            else {
                _i_52637 = binary_op_a(PLUS, _i_52637, 1LL);
            }
            DeRef(_0);
            goto L31; // [1641] 1616
L32: 
            ;
            DeRef(_i_52637);
        }

        /** emit.e:919			cgi -= n*/
        _47cgi_51376 = _47cgi_51376 - _n_52311;

        /** emit.e:921			if op != PROC_FORWARD then*/
        if (_op_52298 == 195LL)
        goto L33; // [1658] 1694

        /** emit.e:922				assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:923				c = NewTempSym() -- put final result in temp*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:924				Push(c)*/
        _47Push(_c_52302);

        /** emit.e:926				emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:927				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);
L33: 
        goto LC; // [1696] 7739

        /** emit.e:930		case WARNING then*/
        case 506:

        /** emit.e:931			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:932		    a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:933			Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26911 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_26911);
        _26912 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26911 = NOVALUE;
        Ref(_26912);
        RefDS(_22186);
        _50Warning(_26912, 64LL, _22186);
        _26912 = NOVALUE;
        goto LC; // [1737] 7739

        /** emit.e:935		case INCLUDE_PATHS then*/
        case 507:

        /** emit.e:936			sequence paths*/

        /** emit.e:938			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:939		    a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:940		    emit_opcode(RIGHT_BRACE_N)*/
        _47emit_opcode(31LL);

        /** emit.e:941		    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26914 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_26914);
        _26915 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26914 = NOVALUE;
        Ref(_26915);
        _0 = _paths_52662;
        _paths_52662 = _48Include_paths(_26915);
        DeRef(_0);
        _26915 = NOVALUE;

        /** emit.e:942		    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_52662)){
                _26917 = SEQ_PTR(_paths_52662)->length;
        }
        else {
            _26917 = 1;
        }
        _47emit(_26917);
        _26917 = NOVALUE;

        /** emit.e:943		    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_52662)){
                _26918 = SEQ_PTR(_paths_52662)->length;
        }
        else {
            _26918 = 1;
        }
        {
            object _i_52674;
            _i_52674 = _26918;
L34: 
            if (_i_52674 < 1LL){
                goto L35; // [1799] 1830
            }

            /** emit.e:944		        c = NewStringSym(paths[i])*/
            _2 = (object)SEQ_PTR(_paths_52662);
            _26919 = (object)*(((s1_ptr)_2)->base + _i_52674);
            Ref(_26919);
            _c_52302 = _54NewStringSym(_26919);
            _26919 = NOVALUE;
            if (!IS_ATOM_INT(_c_52302)) {
                _1 = (object)(DBL_PTR(_c_52302)->dbl);
                DeRefDS(_c_52302);
                _c_52302 = _1;
            }

            /** emit.e:945		        emit_addr(c)*/
            _47emit_addr(_c_52302);

            /** emit.e:946		    end for*/
            _i_52674 = _i_52674 + -1LL;
            goto L34; // [1825] 1806
L35: 
            ;
        }

        /** emit.e:947		    b = NewTempSym()*/
        _b_52301 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:948			emit_temp(b, NEW_REFERENCE)*/
        _47emit_temp(_b_52301, 1LL);

        /** emit.e:949		    Push(b)*/
        _47Push(_b_52301);

        /** emit.e:950		    emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:951			last_op = RIGHT_BRACE_N*/
        _47last_op_52257 = 31LL;

        /** emit.e:952			op = last_op*/
        _op_52298 = 31LL;
        DeRef(_paths_52662);
        _paths_52662 = NOVALUE;
        goto LC; // [1872] 7739

        /** emit.e:955		case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** emit.e:961			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:962			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:963			if op = UPDATE_GLOBALS then*/
        if (_op_52298 != 89LL)
        goto LC; // [1944] 7739

        /** emit.e:964				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:965				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto LC; // [1959] 7739

        /** emit.e:969		case IF, WHILE then*/
        case 20:
        case 47:

        /** emit.e:970			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:971			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:973			if previous_op >= LESS and previous_op <= NOT then*/
        _26924 = (_36previous_op_21861 >= 1LL);
        if (_26924 == 0) {
            goto L36; // [1991] 2283
        }
        _26926 = (_36previous_op_21861 <= 7LL);
        if (_26926 == 0)
        {
            DeRef(_26926);
            _26926 = NOVALUE;
            goto L36; // [2004] 2283
        }
        else{
            DeRef(_26926);
            _26926 = NOVALUE;
        }

        /** emit.e:974				clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26927 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26927 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26928 = (object)*(((s1_ptr)_2)->base + _26927);
        Ref(_26928);
        _47clear_temp(_26928);
        _26928 = NOVALUE;

        /** emit.e:975				Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26929 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26929 = 1;
        }
        _26930 = _26929 - 1LL;
        _26929 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21851;
        RHS_Slice(_36Code_21851, 1LL, _26930);

        /** emit.e:976				if previous_op = NOT then*/
        if (_36previous_op_21861 != 7LL)
        goto L37; // [2045] 2125

        /** emit.e:977					op = NOT_IFW*/
        _op_52298 = 108LL;

        /** emit.e:978					backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26933 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26933 = 1;
        }
        _26934 = _26933 - 1LL;
        _26933 = NOVALUE;
        _47backpatch(_26934, 108LL);
        _26934 = NOVALUE;

        /** emit.e:979					sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26935 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26935 = 1;
        }
        _26936 = _26935 - 1LL;
        _26935 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21851)){
                _26937 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26937 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52742;
        RHS_Slice(_36Code_21851, _26936, _26937);

        /** emit.e:980					Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26939 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26939 = 1;
        }
        _26940 = _26939 - 2LL;
        _26939 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21851;
        RHS_Slice(_36Code_21851, 1LL, _26940);

        /** emit.e:981					Code &= if_code*/
        Concat((object_ptr)&_36Code_21851, _36Code_21851, _if_code_52742);
        DeRefDS(_if_code_52742);
        _if_code_52742 = NOVALUE;
        goto L38; // [2122] 2270
L37: 

        /** emit.e:983					if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26943 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26943 = 1;
        }
        _26944 = _26943 - 1LL;
        _26943 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26945 = (object)*(((s1_ptr)_2)->base + _26944);
        Ref(_26945);
        _26946 = _47IsInteger(_26945);
        _26945 = NOVALUE;
        if (IS_ATOM_INT(_26946)) {
            if (_26946 == 0) {
                goto L39; // [2144] 2186
            }
        }
        else {
            if (DBL_PTR(_26946)->dbl == 0.0) {
                goto L39; // [2144] 2186
            }
        }
        if (IS_SEQUENCE(_36Code_21851)){
                _26948 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26948 = 1;
        }
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26949 = (object)*(((s1_ptr)_2)->base + _26948);
        Ref(_26949);
        _26950 = _47IsInteger(_26949);
        _26949 = NOVALUE;
        if (_26950 == 0) {
            DeRef(_26950);
            _26950 = NOVALUE;
            goto L39; // [2162] 2186
        }
        else {
            if (!IS_ATOM_INT(_26950) && DBL_PTR(_26950)->dbl == 0.0){
                DeRef(_26950);
                _26950 = NOVALUE;
                goto L39; // [2162] 2186
            }
            DeRef(_26950);
            _26950 = NOVALUE;
        }
        DeRef(_26950);
        _26950 = NOVALUE;

        /** emit.e:984						op = previous_op + LESS_IFW_I - LESS*/
        _26951 = _36previous_op_21861 + 119LL;
        if ((object)((uintptr_t)_26951 + (uintptr_t)HIGH_BITS) >= 0){
            _26951 = NewDouble((eudouble)_26951);
        }
        if (IS_ATOM_INT(_26951)) {
            _op_52298 = _26951 - 1LL;
        }
        else {
            _op_52298 = NewDouble(DBL_PTR(_26951)->dbl - (eudouble)1LL);
        }
        DeRef(_26951);
        _26951 = NOVALUE;
        if (!IS_ATOM_INT(_op_52298)) {
            _1 = (object)(DBL_PTR(_op_52298)->dbl);
            DeRefDS(_op_52298);
            _op_52298 = _1;
        }
        goto L3A; // [2183] 2205
L39: 

        /** emit.e:986						op = previous_op + LESS_IFW - LESS*/
        _26953 = _36previous_op_21861 + 102LL;
        if ((object)((uintptr_t)_26953 + (uintptr_t)HIGH_BITS) >= 0){
            _26953 = NewDouble((eudouble)_26953);
        }
        if (IS_ATOM_INT(_26953)) {
            _op_52298 = _26953 - 1LL;
        }
        else {
            _op_52298 = NewDouble(DBL_PTR(_26953)->dbl - (eudouble)1LL);
        }
        DeRef(_26953);
        _26953 = NOVALUE;
        if (!IS_ATOM_INT(_op_52298)) {
            _1 = (object)(DBL_PTR(_op_52298)->dbl);
            DeRefDS(_op_52298);
            _op_52298 = _1;
        }
L3A: 

        /** emit.e:989					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26955 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26955 = 1;
        }
        _26956 = _26955 - 2LL;
        _26955 = NOVALUE;
        _47backpatch(_26956, _op_52298);
        _26956 = NOVALUE;

        /** emit.e:991					sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26957 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26957 = 1;
        }
        _26958 = _26957 - 2LL;
        _26957 = NOVALUE;
        if (IS_SEQUENCE(_36Code_21851)){
                _26959 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26959 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_52781;
        RHS_Slice(_36Code_21851, _26958, _26959);

        /** emit.e:992					Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26961 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26961 = 1;
        }
        _26962 = _26961 - 3LL;
        _26961 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36Code_21851;
        RHS_Slice(_36Code_21851, 1LL, _26962);

        /** emit.e:993					Code &= if_code*/
        Concat((object_ptr)&_36Code_21851, _36Code_21851, _if_code_52781);
        DeRefDS(_if_code_52781);
        _if_code_52781 = NOVALUE;
L38: 

        /** emit.e:997				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;

        /** emit.e:998				last_op = op*/
        _47last_op_52257 = _op_52298;
        goto LC; // [2280] 7739
L36: 

        /** emit.e:1000			elsif op = WHILE and*/
        _26965 = (_op_52298 == 47LL);
        if (_26965 == 0) {
            _26966 = 0;
            goto L3B; // [2291] 2303
        }
        _26967 = (_a_52300 > 0LL);
        _26966 = (_26967 != 0);
L3B: 
        if (_26966 == 0) {
            _26968 = 0;
            goto L3C; // [2303] 2329
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26969 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_26969);
        _26970 = (object)*(((s1_ptr)_2)->base + 3LL);
        _26969 = NOVALUE;
        if (IS_ATOM_INT(_26970)) {
            _26971 = (_26970 == 2LL);
        }
        else {
            _26971 = binary_op(EQUALS, _26970, 2LL);
        }
        _26970 = NOVALUE;
        if (IS_ATOM_INT(_26971))
        _26968 = (_26971 != 0);
        else
        _26968 = DBL_PTR(_26971)->dbl != 0.0;
L3C: 
        if (_26968 == 0) {
            _26972 = 0;
            goto L3D; // [2329] 2352
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26973 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_26973);
        _26974 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26973 = NOVALUE;
        if (IS_ATOM_INT(_26974))
        _26975 = 1;
        else if (IS_ATOM_DBL(_26974))
        _26975 = IS_ATOM_INT(DoubleToInt(_26974));
        else
        _26975 = 0;
        _26974 = NOVALUE;
        _26972 = (_26975 != 0);
L3D: 
        if (_26972 == 0) {
            goto L3E; // [2352] 2401
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _26977 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_26977);
        _26978 = (object)*(((s1_ptr)_2)->base + 1LL);
        _26977 = NOVALUE;
        if (_26978 == 0LL)
        _26979 = 1;
        else if (IS_ATOM_INT(_26978) && IS_ATOM_INT(0LL))
        _26979 = 0;
        else
        _26979 = (compare(_26978, 0LL) == 0);
        _26978 = NOVALUE;
        _26980 = (_26979 == 0);
        _26979 = NOVALUE;
        if (_26980 == 0)
        {
            DeRef(_26980);
            _26980 = NOVALUE;
            goto L3E; // [2376] 2401
        }
        else{
            DeRef(_26980);
            _26980 = NOVALUE;
        }

        /** emit.e:1005				optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _47optimized_while_51362 = _13TRUE_447;

        /** emit.e:1006				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;

        /** emit.e:1007				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;
        goto LC; // [2398] 7739
L3E: 

        /** emit.e:1009				flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _a_52300;
        _26981 = MAKE_SEQ(_1);
        _47flush_temps(_26981);
        _26981 = NOVALUE;

        /** emit.e:1010				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1011				emit_addr(a)*/
        _47emit_addr(_a_52300);
        goto LC; // [2421] 7739

        /** emit.e:1016		case INTEGER_CHECK then*/
        case 96:

        /** emit.e:1017			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:1018			if previous_op = ASSIGN then*/
        if (_36previous_op_21861 != 18LL)
        goto L3F; // [2440] 2499

        /** emit.e:1019				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26983 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26983 = 1;
        }
        _26984 = _26983 - 1LL;
        _26983 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _c_52302 = (object)*(((s1_ptr)_2)->base + _26984);
        if (!IS_ATOM_INT(_c_52302)){
            _c_52302 = (object)DBL_PTR(_c_52302)->dbl;
        }

        /** emit.e:1020				if not IsInteger(c) then*/
        _26986 = _47IsInteger(_c_52302);
        if (IS_ATOM_INT(_26986)) {
            if (_26986 != 0){
                DeRef(_26986);
                _26986 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        else {
            if (DBL_PTR(_26986)->dbl != 0.0){
                DeRef(_26986);
                _26986 = NOVALUE;
                goto L40; // [2467] 2485
            }
        }
        DeRef(_26986);
        _26986 = NOVALUE;

        /** emit.e:1021					emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1022					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);
        goto L41; // [2482] 2556
L40: 

        /** emit.e:1024					last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1025					last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto L41; // [2496] 2556
L3F: 

        /** emit.e:1027			elsif previous_op = -1 or*/
        _26988 = (_36previous_op_21861 == -1LL);
        if (_26988 != 0) {
            goto L42; // [2507] 2530
        }
        _2 = (object)SEQ_PTR(_47op_result_51976);
        _26990 = (object)*(((s1_ptr)_2)->base + _36previous_op_21861);
        _26991 = (_26990 != 1LL);
        _26990 = NOVALUE;
        if (_26991 == 0)
        {
            DeRef(_26991);
            _26991 = NOVALUE;
            goto L43; // [2526] 2545
        }
        else{
            DeRef(_26991);
            _26991 = NOVALUE;
        }
L42: 

        /** emit.e:1029				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1030				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);
        goto L41; // [2542] 2556
L43: 

        /** emit.e:1032				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1033				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
L41: 

        /** emit.e:1035			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26992 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26992 = 1;
        }
        _26993 = _26992 - 1LL;
        _26992 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _26994 = (object)*(((s1_ptr)_2)->base + _26993);
        Ref(_26994);
        _47clear_temp(_26994);
        _26994 = NOVALUE;
        goto LC; // [2574] 7739

        /** emit.e:1037		case SEQUENCE_CHECK then*/
        case 97:

        /** emit.e:1038			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:1039			if previous_op = ASSIGN then*/
        if (_36previous_op_21861 != 18LL)
        goto L44; // [2593] 2720

        /** emit.e:1040				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _26996 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _26996 = 1;
        }
        _26997 = _26996 - 1LL;
        _26996 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _c_52302 = (object)*(((s1_ptr)_2)->base + _26997);
        if (!IS_ATOM_INT(_c_52302)){
            _c_52302 = (object)DBL_PTR(_c_52302)->dbl;
        }

        /** emit.e:1041				if c < 1 or*/
        _26999 = (_c_52302 < 1LL);
        if (_26999 != 0) {
            _27000 = 1;
            goto L45; // [2620] 2646
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27001 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27001);
        _27002 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27001 = NOVALUE;
        if (IS_ATOM_INT(_27002)) {
            _27003 = (_27002 != 2LL);
        }
        else {
            _27003 = binary_op(NOTEQ, _27002, 2LL);
        }
        _27002 = NOVALUE;
        if (IS_ATOM_INT(_27003))
        _27000 = (_27003 != 0);
        else
        _27000 = DBL_PTR(_27003)->dbl != 0.0;
L45: 
        if (_27000 != 0) {
            goto L46; // [2646] 2673
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27005 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27005);
        _27006 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27005 = NOVALUE;
        _27007 = IS_SEQUENCE(_27006);
        _27006 = NOVALUE;
        _27008 = (_27007 == 0);
        _27007 = NOVALUE;
        if (_27008 == 0)
        {
            DeRef(_27008);
            _27008 = NOVALUE;
            goto L47; // [2669] 2706
        }
        else{
            DeRef(_27008);
            _27008 = NOVALUE;
        }
L46: 

        /** emit.e:1044					emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1045					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);

        /** emit.e:1046					clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27009 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27009 = 1;
        }
        _27010 = _27009 - 1LL;
        _27009 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _27011 = (object)*(((s1_ptr)_2)->base + _27010);
        Ref(_27011);
        _47clear_temp(_27011);
        _27011 = NOVALUE;
        goto LC; // [2703] 7739
L47: 

        /** emit.e:1048					last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1049					last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto LC; // [2717] 7739
L44: 

        /** emit.e:1051			elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _27012 = (_36previous_op_21861 == -1LL);
        if (_27012 != 0) {
            goto L48; // [2728] 2751
        }
        _2 = (object)SEQ_PTR(_47op_result_51976);
        _27014 = (object)*(((s1_ptr)_2)->base + _36previous_op_21861);
        _27015 = (_27014 != 2LL);
        _27014 = NOVALUE;
        if (_27015 == 0)
        {
            DeRef(_27015);
            _27015 = NOVALUE;
            goto L49; // [2747] 2784
        }
        else{
            DeRef(_27015);
            _27015 = NOVALUE;
        }
L48: 

        /** emit.e:1052				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1053				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);

        /** emit.e:1054				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27016 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27016 = 1;
        }
        _27017 = _27016 - 1LL;
        _27016 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _27018 = (object)*(((s1_ptr)_2)->base + _27017);
        Ref(_27018);
        _47clear_temp(_27018);
        _27018 = NOVALUE;
        goto LC; // [2781] 7739
L49: 

        /** emit.e:1056				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1057				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto LC; // [2795] 7739

        /** emit.e:1061		case ATOM_CHECK then*/
        case 101:

        /** emit.e:1062			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:1063			if previous_op = ASSIGN then*/
        if (_36previous_op_21861 != 18LL)
        goto L4A; // [2814] 3015

        /** emit.e:1064				c = Code[$-1]*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27020 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27020 = 1;
        }
        _27021 = _27020 - 1LL;
        _27020 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _c_52302 = (object)*(((s1_ptr)_2)->base + _27021);
        if (!IS_ATOM_INT(_c_52302)){
            _c_52302 = (object)DBL_PTR(_c_52302)->dbl;
        }

        /** emit.e:1065				if c > 1*/
        _27023 = (_c_52302 > 1LL);
        if (_27023 == 0) {
            goto L4B; // [2841] 2964
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27025 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27025);
        _27026 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27025 = NOVALUE;
        if (IS_ATOM_INT(_27026)) {
            _27027 = (_27026 == 2LL);
        }
        else {
            _27027 = binary_op(EQUALS, _27026, 2LL);
        }
        _27026 = NOVALUE;
        if (_27027 == 0) {
            DeRef(_27027);
            _27027 = NOVALUE;
            goto L4B; // [2864] 2964
        }
        else {
            if (!IS_ATOM_INT(_27027) && DBL_PTR(_27027)->dbl == 0.0){
                DeRef(_27027);
                _27027 = NOVALUE;
                goto L4B; // [2864] 2964
            }
            DeRef(_27027);
            _27027 = NOVALUE;
        }
        DeRef(_27027);
        _27027 = NOVALUE;

        /** emit.e:1068					if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27028 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27028);
        _27029 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27028 = NOVALUE;
        _27030 = IS_SEQUENCE(_27029);
        _27029 = NOVALUE;
        if (_27030 == 0)
        {
            _27030 = NOVALUE;
            goto L4C; // [2884] 2915
        }
        else{
            _27030 = NOVALUE;
        }

        /** emit.e:1070						ThisLine = ExprLine*/
        RefDS(_45ExprLine_57470);
        DeRef(_50ThisLine_49590);
        _50ThisLine_49590 = _45ExprLine_57470;

        /** emit.e:1071						bp = expr_bp*/
        _50bp_49594 = _45expr_bp_57471;

        /** emit.e:1072						CompileErr( TYPE_CHECK_ERROR__ASSIGNING_A_SEQUENCE_TO_AN_ATOM)*/
        RefDS(_22186);
        _50CompileErr(346LL, _22186, 0LL);
        goto L4D; // [2912] 3094
L4C: 

        /** emit.e:1074					elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27031 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27031);
        _27032 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27031 = NOVALUE;
        if (binary_op_a(NOTEQ, _27032, _36NOVALUE_21613)){
            _27032 = NOVALUE;
            goto L4E; // [2931] 2950
        }
        _27032 = NOVALUE;

        /** emit.e:1075						emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1076						emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);
        goto L4D; // [2947] 3094
L4E: 

        /** emit.e:1078						last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1079						last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto L4D; // [2961] 3094
L4B: 

        /** emit.e:1082				elsif c < 1 */
        _27034 = (_c_52302 < 1LL);
        if (_27034 != 0) {
            goto L4F; // [2970] 2986
        }
        _27036 = _47IsInteger(_c_52302);
        if (IS_ATOM_INT(_27036)) {
            _27037 = (_27036 == 0);
        }
        else {
            _27037 = unary_op(NOT, _27036);
        }
        DeRef(_27036);
        _27036 = NOVALUE;
        if (_27037 == 0) {
            DeRef(_27037);
            _27037 = NOVALUE;
            goto L50; // [2982] 3001
        }
        else {
            if (!IS_ATOM_INT(_27037) && DBL_PTR(_27037)->dbl == 0.0){
                DeRef(_27037);
                _27037 = NOVALUE;
                goto L50; // [2982] 3001
            }
            DeRef(_27037);
            _27037 = NOVALUE;
        }
        DeRef(_27037);
        _27037 = NOVALUE;
L4F: 

        /** emit.e:1085					emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1086					emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);
        goto L4D; // [2998] 3094
L50: 

        /** emit.e:1089					last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1090					last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto L4D; // [3012] 3094
L4A: 

        /** emit.e:1092			elsif previous_op = -1 or*/
        _27038 = (_36previous_op_21861 == -1LL);
        if (_27038 != 0) {
            goto L51; // [3023] 3068
        }
        _2 = (object)SEQ_PTR(_47op_result_51976);
        _27040 = (object)*(((s1_ptr)_2)->base + _36previous_op_21861);
        _27041 = (_27040 != 1LL);
        _27040 = NOVALUE;
        if (_27041 == 0) {
            DeRef(_27042);
            _27042 = 0;
            goto L52; // [3041] 3063
        }
        _2 = (object)SEQ_PTR(_47op_result_51976);
        _27043 = (object)*(((s1_ptr)_2)->base + _36previous_op_21861);
        _27044 = (_27043 != 3LL);
        _27043 = NOVALUE;
        _27042 = (_27044 != 0);
L52: 
        if (_27042 == 0)
        {
            _27042 = NOVALUE;
            goto L53; // [3064] 3083
        }
        else{
            _27042 = NOVALUE;
        }
L51: 

        /** emit.e:1095				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1096				emit_addr(op_info1)*/
        _47emit_addr(_47op_info1_51360);
        goto L4D; // [3080] 3094
L53: 

        /** emit.e:1098				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1099				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
L4D: 

        /** emit.e:1101			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27045 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27045 = 1;
        }
        _27046 = _27045 - 1LL;
        _27045 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _27047 = (object)*(((s1_ptr)_2)->base + _27046);
        Ref(_27047);
        _47clear_temp(_27047);
        _27047 = NOVALUE;
        goto LC; // [3112] 7739

        /** emit.e:1103		case RIGHT_BRACE_N then*/
        case 31:

        /** emit.e:1105			n = op_info1*/
        _n_52311 = _47op_info1_51360;

        /** emit.e:1107			elements = {}*/
        RefDS(_22186);
        DeRef(_elements_52313);
        _elements_52313 = _22186;

        /** emit.e:1108			for i = 1 to n do*/
        _27048 = _n_52311;
        {
            object _i_52962;
            _i_52962 = 1LL;
L54: 
            if (_i_52962 > _27048){
                goto L55; // [3137] 3160
            }

            /** emit.e:1109				elements = append(elements, Pop())*/
            _27049 = _47Pop();
            Ref(_27049);
            Append(&_elements_52313, _elements_52313, _27049);
            DeRef(_27049);
            _27049 = NOVALUE;

            /** emit.e:1110			end for*/
            _i_52962 = _i_52962 + 1LL;
            goto L54; // [3155] 3144
L55: 
            ;
        }

        /** emit.e:1111			element_vals = good_string(elements)*/
        RefDS(_elements_52313);
        _0 = _element_vals_52314;
        _element_vals_52314 = _47good_string(_elements_52313);
        DeRef(_0);

        /** emit.e:1113			if sequence(element_vals) then*/
        _27052 = IS_SEQUENCE(_element_vals_52314);
        if (_27052 == 0)
        {
            _27052 = NOVALUE;
            goto L56; // [3171] 3202
        }
        else{
            _27052 = NOVALUE;
        }

        /** emit.e:1114				c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_52314);
        _c_52302 = _54NewStringSym(_element_vals_52314);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1115				assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:1116				last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1117				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto L57; // [3199] 3293
L56: 

        /** emit.e:1119				if n = 2 then*/
        if (_n_52311 != 2LL)
        goto L58; // [3204] 3227

        /** emit.e:1120					emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _47emit_opcode(85LL);

        /** emit.e:1121					last_op = RIGHT_BRACE_2*/
        _47last_op_52257 = 85LL;
        goto L59; // [3224] 3238
L58: 

        /** emit.e:1123					emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1124					emit(n)*/
        _47emit(_n_52311);
L59: 

        /** emit.e:1127				for i = 1 to n do*/
        _27055 = _n_52311;
        {
            object _i_52979;
            _i_52979 = 1LL;
L5A: 
            if (_i_52979 > _27055){
                goto L5B; // [3243] 3266
            }

            /** emit.e:1128					emit_addr(elements[i])*/
            _2 = (object)SEQ_PTR(_elements_52313);
            _27056 = (object)*(((s1_ptr)_2)->base + _i_52979);
            Ref(_27056);
            _47emit_addr(_27056);
            _27056 = NOVALUE;

            /** emit.e:1129				end for*/
            _i_52979 = _i_52979 + 1LL;
            goto L5A; // [3261] 3250
L5B: 
            ;
        }

        /** emit.e:1130				c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1131				emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1132				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);

        /** emit.e:1133				assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;
L57: 

        /** emit.e:1135			Push(c)*/
        _47Push(_c_52302);
        goto LC; // [3298] 7739

        /** emit.e:1138		case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** emit.e:1141			b = Pop() -- rhs value*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1142			a = Pop() -- subscript*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1143			c = Pop() -- sequence*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1144			if op = ASSIGN_SUBS then*/
        if (_op_52298 != 16LL)
        goto L5C; // [3333] 3525

        /** emit.e:1146				if (previous_op != LHS_SUBS) and*/
        _27062 = (_36previous_op_21861 != 95LL);
        if (_27062 == 0) {
            _27063 = 0;
            goto L5D; // [3347] 3359
        }
        _27064 = (_c_52302 > 0LL);
        _27063 = (_27064 != 0);
L5D: 
        if (_27063 == 0) {
            goto L5E; // [3359] 3497
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27066 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27066);
        _27067 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27066 = NOVALUE;
        if (IS_ATOM_INT(_27067)) {
            _27068 = (_27067 != 1LL);
        }
        else {
            _27068 = binary_op(NOTEQ, _27067, 1LL);
        }
        _27067 = NOVALUE;
        if (IS_ATOM_INT(_27068)) {
            if (_27068 != 0) {
                DeRef(_27069);
                _27069 = 1;
                goto L5F; // [3381] 3481
            }
        }
        else {
            if (DBL_PTR(_27068)->dbl != 0.0) {
                DeRef(_27069);
                _27069 = 1;
                goto L5F; // [3381] 3481
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27070 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27070);
        _27071 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27070 = NOVALUE;
        if (IS_ATOM_INT(_27071)) {
            _27072 = (_27071 != _54sequence_type_47136);
        }
        else {
            _27072 = binary_op(NOTEQ, _27071, _54sequence_type_47136);
        }
        _27071 = NOVALUE;
        if (IS_ATOM_INT(_27072)) {
            if (_27072 == 0) {
                DeRef(_27073);
                _27073 = 0;
                goto L60; // [3403] 3477
            }
        }
        else {
            if (DBL_PTR(_27072)->dbl == 0.0) {
                DeRef(_27073);
                _27073 = 0;
                goto L60; // [3403] 3477
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27074 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27074);
        _27075 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27074 = NOVALUE;
        if (IS_ATOM_INT(_27075)) {
            _27076 = (_27075 > 0LL);
        }
        else {
            _27076 = binary_op(GREATER, _27075, 0LL);
        }
        _27075 = NOVALUE;
        if (IS_ATOM_INT(_27076)) {
            if (_27076 == 0) {
                DeRef(_27077);
                _27077 = 0;
                goto L61; // [3423] 3473
            }
        }
        else {
            if (DBL_PTR(_27076)->dbl == 0.0) {
                DeRef(_27077);
                _27077 = 0;
                goto L61; // [3423] 3473
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27078 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27078);
        _27079 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27078 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27079)){
            _27080 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27079)->dbl));
        }
        else{
            _27080 = (object)*(((s1_ptr)_2)->base + _27079);
        }
        _2 = (object)SEQ_PTR(_27080);
        _27081 = (object)*(((s1_ptr)_2)->base + 2LL);
        _27080 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27081)){
            _27082 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27081)->dbl));
        }
        else{
            _27082 = (object)*(((s1_ptr)_2)->base + _27081);
        }
        _2 = (object)SEQ_PTR(_27082);
        _27083 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27082 = NOVALUE;
        if (IS_ATOM_INT(_27083)) {
            _27084 = (_27083 != _54sequence_type_47136);
        }
        else {
            _27084 = binary_op(NOTEQ, _27083, _54sequence_type_47136);
        }
        _27083 = NOVALUE;
        DeRef(_27077);
        if (IS_ATOM_INT(_27084))
        _27077 = (_27084 != 0);
        else
        _27077 = DBL_PTR(_27084)->dbl != 0.0;
L61: 
        DeRef(_27073);
        _27073 = (_27077 != 0);
L60: 
        DeRef(_27069);
        _27069 = (_27073 != 0);
L5F: 
        if (_27069 == 0)
        {
            _27069 = NOVALUE;
            goto L5E; // [3482] 3497
        }
        else{
            _27069 = NOVALUE;
        }

        /** emit.e:1153					op = ASSIGN_SUBS_CHECK*/
        _op_52298 = 84LL;
        goto L62; // [3494] 3517
L5E: 

        /** emit.e:1155					if IsInteger(b) then*/
        _27085 = _47IsInteger(_b_52301);
        if (_27085 == 0) {
            DeRef(_27085);
            _27085 = NOVALUE;
            goto L63; // [3503] 3516
        }
        else {
            if (!IS_ATOM_INT(_27085) && DBL_PTR(_27085)->dbl == 0.0){
                DeRef(_27085);
                _27085 = NOVALUE;
                goto L63; // [3503] 3516
            }
            DeRef(_27085);
            _27085 = NOVALUE;
        }
        DeRef(_27085);
        _27085 = NOVALUE;

        /** emit.e:1156						op = ASSIGN_SUBS_I*/
        _op_52298 = 118LL;
L63: 
L62: 

        /** emit.e:1159				emit_opcode(op)*/
        _47emit_opcode(_op_52298);
        goto L64; // [3522] 3551
L5C: 

        /** emit.e:1161			elsif op = PASSIGN_SUBS then*/
        if (_op_52298 != 162LL)
        goto L65; // [3529] 3543

        /** emit.e:1162				emit_opcode(PASSIGN_SUBS) -- always*/
        _47emit_opcode(162LL);
        goto L64; // [3540] 3551
L65: 

        /** emit.e:1165				emit_opcode(ASSIGN_SUBS) -- always*/
        _47emit_opcode(16LL);
L64: 

        /** emit.e:1169			emit_addr(c) -- sequence*/
        _47emit_addr(_c_52302);

        /** emit.e:1170			emit_addr(a) -- subscript*/
        _47emit_addr(_a_52300);

        /** emit.e:1171			emit_addr(b) -- rhs value*/
        _47emit_addr(_b_52301);

        /** emit.e:1172			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [3573] 7739

        /** emit.e:1174		case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** emit.e:1176			a = Pop() -- subs*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1177			lhs_var = Pop() -- sequence*/
        _lhs_var_52308 = _47Pop();
        if (!IS_ATOM_INT(_lhs_var_52308)) {
            _1 = (object)(DBL_PTR(_lhs_var_52308)->dbl);
            DeRefDS(_lhs_var_52308);
            _lhs_var_52308 = _1;
        }

        /** emit.e:1178			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1179			emit_addr(lhs_var)*/
        _47emit_addr(_lhs_var_52308);

        /** emit.e:1180			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1181			if op = LHS_SUBS then*/
        if (_op_52298 != 95LL)
        goto L66; // [3616] 3647

        /** emit.e:1182				TempKeep(lhs_var) -- should be lhs_target_temp*/
        _47TempKeep(_lhs_var_52308);

        /** emit.e:1183				emit_addr(lhs_target_temp)*/
        _47emit_addr(_47lhs_target_temp_51374);

        /** emit.e:1184				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_51374);

        /** emit.e:1185				emit_addr(0) -- place holder*/
        _47emit_addr(0LL);
        goto L67; // [3644] 3701
L66: 

        /** emit.e:1189				lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _54NewTempSym(0LL);
        _47lhs_target_temp_51374 = _0;
        if (!IS_ATOM_INT(_47lhs_target_temp_51374)) {
            _1 = (object)(DBL_PTR(_47lhs_target_temp_51374)->dbl);
            DeRefDS(_47lhs_target_temp_51374);
            _47lhs_target_temp_51374 = _1;
        }

        /** emit.e:1190				emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _47emit_addr(_47lhs_target_temp_51374);

        /** emit.e:1191				emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_target_temp_51374, 1LL);

        /** emit.e:1192				Push(lhs_target_temp)*/
        _47Push(_47lhs_target_temp_51374);

        /** emit.e:1193				lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _54NewTempSym(0LL);
        _47lhs_subs1_copy_temp_51373 = _0;
        if (!IS_ATOM_INT(_47lhs_subs1_copy_temp_51373)) {
            _1 = (object)(DBL_PTR(_47lhs_subs1_copy_temp_51373)->dbl);
            DeRefDS(_47lhs_subs1_copy_temp_51373);
            _47lhs_subs1_copy_temp_51373 = _1;
        }

        /** emit.e:1194				emit_addr(lhs_subs1_copy_temp)*/
        _47emit_addr(_47lhs_subs1_copy_temp_51373);

        /** emit.e:1195				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _47emit_temp(_47lhs_subs1_copy_temp_51373, 1LL);
L67: 

        /** emit.e:1198			current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_47current_sequence_51368, _47current_sequence_51368, _47lhs_target_temp_51374);

        /** emit.e:1199			assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [3718] 7739

        /** emit.e:1201		case PEEK_LONGS then*/
        case 436:

        /** emit.e:1202			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21905 != 0) {
            _27093 = 1;
            goto L68; // [3728] 3738
        }
        _27093 = (_46TWINDOWS_21906 != 0);
L68: 
        if (_27093 != 0) {
            goto L69; // [3738] 3762
        }
        if (_46IX86_64_21921 != 0) {
            DeRef(_27095);
            _27095 = 1;
            goto L6A; // [3744] 3754
        }
        _27095 = (_46TX86_64_21922 != 0);
L6A: 
        _27096 = (_27095 == 0);
        _27095 = NOVALUE;
        if (_27096 == 0)
        {
            DeRef(_27096);
            _27096 = NOVALUE;
            goto L6B; // [3758] 3774
        }
        else{
            DeRef(_27096);
            _27096 = NOVALUE;
        }
L69: 

        /** emit.e:1203				op = PEEK4S*/
        _op_52298 = 139LL;
        goto L6C; // [3771] 3784
L6B: 

        /** emit.e:1205				op = PEEK8S*/
        _op_52298 = 213LL;
L6C: 

        /** emit.e:1207			last_op = op*/
        _47last_op_52257 = _op_52298;

        /** emit.e:1208			cont11ii(op, TRUE )*/
        _47cont11ii(_op_52298, _13TRUE_447);
        goto LC; // [3797] 7739

        /** emit.e:1210		case PEEK_LONGU then*/
        case 435:

        /** emit.e:1211			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21905 != 0) {
            _27097 = 1;
            goto L6D; // [3807] 3817
        }
        _27097 = (_46TWINDOWS_21906 != 0);
L6D: 
        if (_27097 != 0) {
            goto L6E; // [3817] 3841
        }
        if (_46IX86_64_21921 != 0) {
            DeRef(_27099);
            _27099 = 1;
            goto L6F; // [3823] 3833
        }
        _27099 = (_46TX86_64_21922 != 0);
L6F: 
        _27100 = (_27099 == 0);
        _27099 = NOVALUE;
        if (_27100 == 0)
        {
            DeRef(_27100);
            _27100 = NOVALUE;
            goto L70; // [3837] 3853
        }
        else{
            DeRef(_27100);
            _27100 = NOVALUE;
        }
L6E: 

        /** emit.e:1212				op = PEEK4U*/
        _op_52298 = 140LL;
        goto L71; // [3850] 3863
L70: 

        /** emit.e:1214				op = PEEK8U*/
        _op_52298 = 214LL;
L71: 

        /** emit.e:1216			last_op = op*/
        _47last_op_52257 = _op_52298;

        /** emit.e:1217			cont11ii(op, TRUE )*/
        _47cont11ii(_op_52298, _13TRUE_447);
        goto LC; // [3876] 7739

        /** emit.e:1220		case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT, PEEK8U, PEEK8S, SIZEOF,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 214:
        case 213:
        case 217:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:
        case 216:

        /** emit.e:1222			cont11ii(op, TRUE)*/
        _47cont11ii(_op_52298, _13TRUE_447);
        goto LC; // [3918] 7739

        /** emit.e:1224		case UMINUS then*/
        case 12:

        /** emit.e:1226			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1228			if a > 0 then*/
        if (_a_52300 <= 0LL)
        goto L72; // [3933] 4180

        /** emit.e:1229				obj = SymTab[a][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27103 = (object)*(((s1_ptr)_2)->base + _a_52300);
        DeRef(_obj_52312);
        _2 = (object)SEQ_PTR(_27103);
        _obj_52312 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_obj_52312);
        _27103 = NOVALUE;

        /** emit.e:1230				if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27105 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27105);
        _27106 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27105 = NOVALUE;
        if (binary_op_a(NOTEQ, _27106, 2LL)){
            _27106 = NOVALUE;
            goto L73; // [3967] 4092
        }
        _27106 = NOVALUE;

        /** emit.e:1231					if is_integer(obj) then*/
        Ref(_obj_52312);
        _27108 = _36is_integer(_obj_52312);
        if (_27108 == 0) {
            DeRef(_27108);
            _27108 = NOVALUE;
            goto L74; // [3977] 4031
        }
        else {
            if (!IS_ATOM_INT(_27108) && DBL_PTR(_27108)->dbl == 0.0){
                DeRef(_27108);
                _27108 = NOVALUE;
                goto L74; // [3977] 4031
            }
            DeRef(_27108);
            _27108 = NOVALUE;
        }
        DeRef(_27108);
        _27108 = NOVALUE;

        /** emit.e:1232						if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_52312, _36MININT_21583)){
            goto L75; // [3984] 4005
        }

        /** emit.e:1233							Push(NewDoubleSym(-MININT))*/
        if (IS_ATOM_INT(_36MININT_21583)) {
            if ((uintptr_t)_36MININT_21583 == (uintptr_t)HIGH_BITS){
                _27110 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27110 = - _36MININT_21583;
            }
        }
        else {
            _27110 = unary_op(UMINUS, _36MININT_21583);
        }
        _27111 = _54NewDoubleSym(_27110);
        _27110 = NOVALUE;
        _47Push(_27111);
        _27111 = NOVALUE;
        goto L76; // [4002] 4018
L75: 

        /** emit.e:1235							Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_52312)) {
            if ((uintptr_t)_obj_52312 == (uintptr_t)HIGH_BITS){
                _27112 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27112 = - _obj_52312;
            }
        }
        else {
            _27112 = unary_op(UMINUS, _obj_52312);
        }
        _27113 = _54NewIntSym(_27112);
        _27112 = NOVALUE;
        _47Push(_27113);
        _27113 = NOVALUE;
L76: 

        /** emit.e:1237						last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;

        /** emit.e:1238						last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;
        goto LC; // [4028] 7739
L74: 

        /** emit.e:1240					elsif atom(obj) and obj != NOVALUE then*/
        _27114 = IS_ATOM(_obj_52312);
        if (_27114 == 0) {
            goto L77; // [4036] 4075
        }
        if (IS_ATOM_INT(_obj_52312) && IS_ATOM_INT(_36NOVALUE_21613)) {
            _27116 = (_obj_52312 != _36NOVALUE_21613);
        }
        else {
            _27116 = binary_op(NOTEQ, _obj_52312, _36NOVALUE_21613);
        }
        if (_27116 == 0) {
            DeRef(_27116);
            _27116 = NOVALUE;
            goto L77; // [4047] 4075
        }
        else {
            if (!IS_ATOM_INT(_27116) && DBL_PTR(_27116)->dbl == 0.0){
                DeRef(_27116);
                _27116 = NOVALUE;
                goto L77; // [4047] 4075
            }
            DeRef(_27116);
            _27116 = NOVALUE;
        }
        DeRef(_27116);
        _27116 = NOVALUE;

        /** emit.e:1245						Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_52312)) {
            if ((uintptr_t)_obj_52312 == (uintptr_t)HIGH_BITS){
                _27117 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27117 = - _obj_52312;
            }
        }
        else {
            _27117 = unary_op(UMINUS, _obj_52312);
        }
        _27118 = _54NewDoubleSym(_27117);
        _27117 = NOVALUE;
        _47Push(_27118);
        _27118 = NOVALUE;

        /** emit.e:1246						last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;

        /** emit.e:1247						last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;
        goto LC; // [4072] 7739
L77: 

        /** emit.e:1250						Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1251						cont11ii(op, FALSE)*/
        _47cont11ii(_op_52298, _13FALSE_445);
        goto LC; // [4089] 7739
L73: 

        /** emit.e:1254				elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_36TRANSLATE_21361 == 0) {
            _27119 = 0;
            goto L78; // [4096] 4122
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27120 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27120);
        _27121 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27120 = NOVALUE;
        if (IS_ATOM_INT(_27121)) {
            _27122 = (_27121 == 3LL);
        }
        else {
            _27122 = binary_op(EQUALS, _27121, 3LL);
        }
        _27121 = NOVALUE;
        if (IS_ATOM_INT(_27122))
        _27119 = (_27122 != 0);
        else
        _27119 = DBL_PTR(_27122)->dbl != 0.0;
L78: 
        if (_27119 == 0) {
            goto L79; // [4122] 4163
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27124 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27124);
        _27125 = (object)*(((s1_ptr)_2)->base + 36LL);
        _27124 = NOVALUE;
        if (IS_ATOM_INT(_27125)) {
            _27126 = (_27125 == 2LL);
        }
        else {
            _27126 = binary_op(EQUALS, _27125, 2LL);
        }
        _27125 = NOVALUE;
        if (_27126 == 0) {
            DeRef(_27126);
            _27126 = NOVALUE;
            goto L79; // [4145] 4163
        }
        else {
            if (!IS_ATOM_INT(_27126) && DBL_PTR(_27126)->dbl == 0.0){
                DeRef(_27126);
                _27126 = NOVALUE;
                goto L79; // [4145] 4163
            }
            DeRef(_27126);
            _27126 = NOVALUE;
        }
        DeRef(_27126);
        _27126 = NOVALUE;

        /** emit.e:1256					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_52312)) {
            if ((uintptr_t)_obj_52312 == (uintptr_t)HIGH_BITS){
                _27127 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _27127 = - _obj_52312;
            }
        }
        else {
            _27127 = unary_op(UMINUS, _obj_52312);
        }
        _27128 = _54NewDoubleSym(_27127);
        _27127 = NOVALUE;
        _47Push(_27128);
        _27128 = NOVALUE;
        goto LC; // [4160] 7739
L79: 

        /** emit.e:1259					Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1260					cont11ii(op, FALSE)*/
        _47cont11ii(_op_52298, _13FALSE_445);
        goto LC; // [4177] 7739
L72: 

        /** emit.e:1263				Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1264				cont11ii(op, FALSE)*/
        _47cont11ii(_op_52298, _13FALSE_445);
        goto LC; // [4194] 7739

        /** emit.e:1267		case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** emit.e:1268			cont11ii(op, FALSE)*/
        _47cont11ii(_op_52298, _13FALSE_445);
        goto LC; // [4226] 7739

        /** emit.e:1270		case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** emit.e:1271			cont11ii(op, FALSE)*/
        _47cont11ii(_op_52298, _13FALSE_445);
        goto LC; // [4246] 7739

        /** emit.e:1275		case ROUTINE_ID then*/
        case 134:

        /** emit.e:1276			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1277			source = Pop()*/
        _source_52304 = _47Pop();
        if (!IS_ATOM_INT(_source_52304)) {
            _1 = (object)(DBL_PTR(_source_52304)->dbl);
            DeRefDS(_source_52304);
            _source_52304 = _1;
        }

        /** emit.e:1278			if TRANSLATE then*/
        if (_36TRANSLATE_21361 == 0)
        {
            goto L7A; // [4268] 4312
        }
        else{
        }

        /** emit.e:1279				emit_addr(num_routines-1)*/
        _27130 = _36num_routines_21768 - 1LL;
        if ((object)((uintptr_t)_27130 +(uintptr_t) HIGH_BITS) >= 0){
            _27130 = NewDouble((eudouble)_27130);
        }
        _47emit_addr(_27130);
        _27130 = NOVALUE;

        /** emit.e:1280				last_routine_id = num_routines*/
        _47last_routine_id_51365 = _36num_routines_21768;

        /** emit.e:1281				last_max_params = max_params*/
        _47last_max_params_51367 = _47max_params_51366;

        /** emit.e:1282				MarkTargets(source, S_RI_TARGET)*/
        _31967 = _54MarkTargets(_source_52304, 53LL);
        DeRef(_31967);
        _31967 = NOVALUE;
        goto L7B; // [4309] 4349
L7A: 

        /** emit.e:1285				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21767);

        /** emit.e:1286				emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_37SymTab_15637)){
                _27131 = SEQ_PTR(_37SymTab_15637)->length;
        }
        else {
            _27131 = 1;
        }
        _47emit_addr(_27131);
        _27131 = NOVALUE;

        /** emit.e:1288				if BIND then*/
        if (_36BIND_21364 == 0)
        {
            goto L7C; // [4333] 4348
        }
        else{
        }

        /** emit.e:1290					MarkTargets(source, S_NREFS)*/
        _31966 = _54MarkTargets(_source_52304, 12LL);
        DeRef(_31966);
        _31966 = NOVALUE;
L7C: 
L7B: 

        /** emit.e:1294			emit_addr(source)*/
        _47emit_addr(_source_52304);

        /** emit.e:1295			emit_addr(current_file_no)  -- necessary at top level*/
        _47emit_addr(_36current_file_no_21759);

        /** emit.e:1296			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1297			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1298			TempInteger(c) -- result will always be an integer*/
        _47TempInteger(_c_52302);

        /** emit.e:1299			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1300			emit_addr(c)*/
        _47emit_addr(_c_52302);
        goto LC; // [4391] 7739

        /** emit.e:1305		case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** emit.e:1306			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1307			emit_addr(Pop())*/
        _27133 = _47Pop();
        _47emit_addr(_27133);
        _27133 = NOVALUE;

        /** emit.e:1308			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1309			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1310			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1311			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [4437] 7739

        /** emit.e:1315		case POKE_LONG then*/
        case 434:

        /** emit.e:1316			if IWINDOWS or TWINDOWS or not (IX86_64 or TX86_64) then*/
        if (_46IWINDOWS_21905 != 0) {
            _27135 = 1;
            goto L7D; // [4447] 4457
        }
        _27135 = (_46TWINDOWS_21906 != 0);
L7D: 
        if (_27135 != 0) {
            goto L7E; // [4457] 4481
        }
        if (_46IX86_64_21921 != 0) {
            DeRef(_27137);
            _27137 = 1;
            goto L7F; // [4463] 4473
        }
        _27137 = (_46TX86_64_21922 != 0);
L7F: 
        _27138 = (_27137 == 0);
        _27137 = NOVALUE;
        if (_27138 == 0)
        {
            DeRef(_27138);
            _27138 = NOVALUE;
            goto L80; // [4477] 4493
        }
        else{
            DeRef(_27138);
            _27138 = NOVALUE;
        }
L7E: 

        /** emit.e:1317				op = POKE4*/
        _op_52298 = 138LL;
        goto L81; // [4490] 4503
L80: 

        /** emit.e:1319				op = POKE8*/
        _op_52298 = 212LL;
L81: 

        /** emit.e:1321			last_op = op*/
        _47last_op_52257 = _op_52298;

        /** emit.e:1324		case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:
        case 212:
        case 215:

        /** emit.e:1326			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1328			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1329			emit_addr(Pop())*/
        _27140 = _47Pop();
        _47emit_addr(_27140);
        _27140 = NOVALUE;

        /** emit.e:1330			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1331			if op = C_PROC then*/
        if (_op_52298 != 132LL)
        goto L82; // [4565] 4577

        /** emit.e:1332				emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21767);
L82: 

        /** emit.e:1334			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [4584] 7739

        /** emit.e:1337		case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** emit.e:1339			cont21ii(op, TRUE)  -- both integer args => integer result*/
        _47cont21ii(_op_52298, _13TRUE_447);
        goto LC; // [4622] 7739

        /** emit.e:1341		case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** emit.e:1343			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1344			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1346			if b < 1 or a < 1 then*/
        _27144 = (_b_52301 < 1LL);
        if (_27144 != 0) {
            goto L83; // [4648] 4661
        }
        _27146 = (_a_52300 < 1LL);
        if (_27146 == 0)
        {
            DeRef(_27146);
            _27146 = NOVALUE;
            goto L84; // [4657] 4682
        }
        else{
            DeRef(_27146);
            _27146 = NOVALUE;
        }
L83: 

        /** emit.e:1347				Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1348				Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1349				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [4679] 7739
L84: 

        /** emit.e:1350			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27147 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27147);
        _27148 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27147 = NOVALUE;
        if (IS_ATOM_INT(_27148)) {
            _27149 = (_27148 == 2LL);
        }
        else {
            _27149 = binary_op(EQUALS, _27148, 2LL);
        }
        _27148 = NOVALUE;
        if (IS_ATOM_INT(_27149)) {
            if (_27149 == 0) {
                goto L85; // [4702] 4763
            }
        }
        else {
            if (DBL_PTR(_27149)->dbl == 0.0) {
                goto L85; // [4702] 4763
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27151 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27151);
        _27152 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27151 = NOVALUE;
        if (_27152 == 1LL)
        _27153 = 1;
        else if (IS_ATOM_INT(_27152) && IS_ATOM_INT(1LL))
        _27153 = 0;
        else
        _27153 = (compare(_27152, 1LL) == 0);
        _27152 = NOVALUE;
        if (_27153 == 0)
        {
            _27153 = NOVALUE;
            goto L85; // [4723] 4763
        }
        else{
            _27153 = NOVALUE;
        }

        /** emit.e:1351				op = PLUS1*/
        _op_52298 = 93LL;

        /** emit.e:1352				emit_opcode(op)*/
        _47emit_opcode(93LL);

        /** emit.e:1353				emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1354				emit_addr(0)*/
        _47emit_addr(0LL);

        /** emit.e:1355				cont21d(op, a, b, FALSE)*/
        _47cont21d(93LL, _a_52300, _b_52301, _13FALSE_445);
        goto LC; // [4760] 7739
L85: 

        /** emit.e:1356			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27154 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27154);
        _27155 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27154 = NOVALUE;
        if (IS_ATOM_INT(_27155)) {
            _27156 = (_27155 == 2LL);
        }
        else {
            _27156 = binary_op(EQUALS, _27155, 2LL);
        }
        _27155 = NOVALUE;
        if (IS_ATOM_INT(_27156)) {
            if (_27156 == 0) {
                goto L86; // [4783] 4844
            }
        }
        else {
            if (DBL_PTR(_27156)->dbl == 0.0) {
                goto L86; // [4783] 4844
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27158 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27158);
        _27159 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27158 = NOVALUE;
        if (_27159 == 1LL)
        _27160 = 1;
        else if (IS_ATOM_INT(_27159) && IS_ATOM_INT(1LL))
        _27160 = 0;
        else
        _27160 = (compare(_27159, 1LL) == 0);
        _27159 = NOVALUE;
        if (_27160 == 0)
        {
            _27160 = NOVALUE;
            goto L86; // [4804] 4844
        }
        else{
            _27160 = NOVALUE;
        }

        /** emit.e:1357				op = PLUS1*/
        _op_52298 = 93LL;

        /** emit.e:1358				emit_opcode(op)*/
        _47emit_opcode(93LL);

        /** emit.e:1359				emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1360				emit_addr(0)*/
        _47emit_addr(0LL);

        /** emit.e:1361				cont21d(op, a, b, FALSE)*/
        _47cont21d(93LL, _a_52300, _b_52301, _13FALSE_445);
        goto LC; // [4841] 7739
L86: 

        /** emit.e:1363				Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1364				Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1365				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [4863] 7739

        /** emit.e:1368		case rw:MULTIPLY then*/
        case 13:

        /** emit.e:1370			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1371			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1372			if a < 1 or b < 1 then*/
        _27163 = (_a_52300 < 1LL);
        if (_27163 != 0) {
            goto L87; // [4889] 4902
        }
        _27165 = (_b_52301 < 1LL);
        if (_27165 == 0)
        {
            DeRef(_27165);
            _27165 = NOVALUE;
            goto L88; // [4898] 4923
        }
        else{
            DeRef(_27165);
            _27165 = NOVALUE;
        }
L87: 

        /** emit.e:1373				Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1374				Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1375				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [4920] 7739
L88: 

        /** emit.e:1377			elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27166 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27166);
        _27167 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27166 = NOVALUE;
        if (IS_ATOM_INT(_27167)) {
            _27168 = (_27167 == 2LL);
        }
        else {
            _27168 = binary_op(EQUALS, _27167, 2LL);
        }
        _27167 = NOVALUE;
        if (IS_ATOM_INT(_27168)) {
            if (_27168 == 0) {
                goto L89; // [4943] 5004
            }
        }
        else {
            if (DBL_PTR(_27168)->dbl == 0.0) {
                goto L89; // [4943] 5004
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27170 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27170);
        _27171 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27170 = NOVALUE;
        if (_27171 == 2LL)
        _27172 = 1;
        else if (IS_ATOM_INT(_27171) && IS_ATOM_INT(2LL))
        _27172 = 0;
        else
        _27172 = (compare(_27171, 2LL) == 0);
        _27171 = NOVALUE;
        if (_27172 == 0)
        {
            _27172 = NOVALUE;
            goto L89; // [4964] 5004
        }
        else{
            _27172 = NOVALUE;
        }

        /** emit.e:1379				op = PLUS*/
        _op_52298 = 11LL;

        /** emit.e:1380				emit_opcode(op)*/
        _47emit_opcode(11LL);

        /** emit.e:1381				emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1382				emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1383				cont21d(op, a, b, FALSE)*/
        _47cont21d(11LL, _a_52300, _b_52301, _13FALSE_445);
        goto LC; // [5001] 7739
L89: 

        /** emit.e:1385			elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27173 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27173);
        _27174 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27173 = NOVALUE;
        if (IS_ATOM_INT(_27174)) {
            _27175 = (_27174 == 2LL);
        }
        else {
            _27175 = binary_op(EQUALS, _27174, 2LL);
        }
        _27174 = NOVALUE;
        if (IS_ATOM_INT(_27175)) {
            if (_27175 == 0) {
                goto L8A; // [5024] 5085
            }
        }
        else {
            if (DBL_PTR(_27175)->dbl == 0.0) {
                goto L8A; // [5024] 5085
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27177 = (object)*(((s1_ptr)_2)->base + _a_52300);
        _2 = (object)SEQ_PTR(_27177);
        _27178 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27177 = NOVALUE;
        if (_27178 == 2LL)
        _27179 = 1;
        else if (IS_ATOM_INT(_27178) && IS_ATOM_INT(2LL))
        _27179 = 0;
        else
        _27179 = (compare(_27178, 2LL) == 0);
        _27178 = NOVALUE;
        if (_27179 == 0)
        {
            _27179 = NOVALUE;
            goto L8A; // [5045] 5085
        }
        else{
            _27179 = NOVALUE;
        }

        /** emit.e:1386				op = PLUS*/
        _op_52298 = 11LL;

        /** emit.e:1387				emit_opcode(op)*/
        _47emit_opcode(11LL);

        /** emit.e:1388				emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1389				emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1390				cont21d(op, a, b, FALSE)*/
        _47cont21d(11LL, _a_52300, _b_52301, _13FALSE_445);
        goto LC; // [5082] 7739
L8A: 

        /** emit.e:1393				Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1394				Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1395				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [5104] 7739

        /** emit.e:1399		case rw:DIVIDE then*/
        case 14:

        /** emit.e:1400			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1401			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27181 = (_b_52301 > 0LL);
        if (_27181 == 0) {
            _27182 = 0;
            goto L8B; // [5123] 5149
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27183 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27183);
        _27184 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27183 = NOVALUE;
        if (IS_ATOM_INT(_27184)) {
            _27185 = (_27184 == 2LL);
        }
        else {
            _27185 = binary_op(EQUALS, _27184, 2LL);
        }
        _27184 = NOVALUE;
        if (IS_ATOM_INT(_27185))
        _27182 = (_27185 != 0);
        else
        _27182 = DBL_PTR(_27185)->dbl != 0.0;
L8B: 
        if (_27182 == 0) {
            goto L8C; // [5149] 5220
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27187 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27187);
        _27188 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27187 = NOVALUE;
        if (_27188 == 2LL)
        _27189 = 1;
        else if (IS_ATOM_INT(_27188) && IS_ATOM_INT(2LL))
        _27189 = 0;
        else
        _27189 = (compare(_27188, 2LL) == 0);
        _27188 = NOVALUE;
        if (_27189 == 0)
        {
            _27189 = NOVALUE;
            goto L8C; // [5170] 5220
        }
        else{
            _27189 = NOVALUE;
        }

        /** emit.e:1402				op = DIV2*/
        _op_52298 = 98LL;

        /** emit.e:1403				emit_opcode(op)*/
        _47emit_opcode(98LL);

        /** emit.e:1404				emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _27190 = _47Pop();
        _47emit_addr(_27190);
        _27190 = NOVALUE;

        /** emit.e:1405				a = 0*/
        _a_52300 = 0LL;

        /** emit.e:1406				emit_addr(0)*/
        _47emit_addr(0LL);

        /** emit.e:1407				cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _47cont21d(98LL, 0LL, _b_52301, _13FALSE_445);
        goto LC; // [5217] 7739
L8C: 

        /** emit.e:1409				Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1410				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [5234] 7739

        /** emit.e:1413		case FLOOR then*/
        case 83:

        /** emit.e:1414			if previous_op = rw:DIVIDE then*/
        if (_36previous_op_21861 != 14LL)
        goto L8D; // [5244] 5292

        /** emit.e:1415				op = FLOOR_DIV*/
        _op_52298 = 63LL;

        /** emit.e:1416				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27192 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27192 = 1;
        }
        _27193 = _27192 - 3LL;
        _27192 = NOVALUE;
        _47backpatch(_27193, 63LL);
        _27193 = NOVALUE;

        /** emit.e:1417				assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1418				last_op = op*/
        _47last_op_52257 = 63LL;

        /** emit.e:1419				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto LC; // [5289] 7739
L8D: 

        /** emit.e:1421			elsif previous_op = DIV2 then*/
        if (_36previous_op_21861 != 98LL)
        goto L8E; // [5298] 5385

        /** emit.e:1422				op = FLOOR_DIV2*/
        _op_52298 = 66LL;

        /** emit.e:1423				backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27195 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27195 = 1;
        }
        _27196 = _27195 - 3LL;
        _27195 = NOVALUE;
        _47backpatch(_27196, 66LL);
        _27196 = NOVALUE;

        /** emit.e:1424				assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1425				if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_36Code_21851)){
                _27197 = SEQ_PTR(_36Code_21851)->length;
        }
        else {
            _27197 = 1;
        }
        _27198 = _27197 - 2LL;
        _27197 = NOVALUE;
        _2 = (object)SEQ_PTR(_36Code_21851);
        _27199 = (object)*(((s1_ptr)_2)->base + _27198);
        Ref(_27199);
        _27200 = _47IsInteger(_27199);
        _27199 = NOVALUE;
        if (_27200 == 0) {
            DeRef(_27200);
            _27200 = NOVALUE;
            goto L8F; // [5352] 5372
        }
        else {
            if (!IS_ATOM_INT(_27200) && DBL_PTR(_27200)->dbl == 0.0){
                DeRef(_27200);
                _27200 = NOVALUE;
                goto L8F; // [5352] 5372
            }
            DeRef(_27200);
            _27200 = NOVALUE;
        }
        DeRef(_27200);
        _27200 = NOVALUE;

        /** emit.e:1426					TempInteger(Top()) --mark temp as integer type*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5482_53400);
        _2 = (object)SEQ_PTR(_47cg_stack_51375);
        _Top_inlined_Top_at_5482_53400 = (object)*(((s1_ptr)_2)->base + _47cgi_51376);
        Ref(_Top_inlined_Top_at_5482_53400);
        Ref(_Top_inlined_Top_at_5482_53400);
        _47TempInteger(_Top_inlined_Top_at_5482_53400);
L8F: 

        /** emit.e:1428				last_op = op*/
        _47last_op_52257 = _op_52298;

        /** emit.e:1429				last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto LC; // [5382] 7739
L8E: 

        /** emit.e:1431				cont11ii(op, TRUE)*/
        _47cont11ii(_op_52298, _13TRUE_447);
        goto LC; // [5394] 7739

        /** emit.e:1437		case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** emit.e:1440			cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [5438] 7739

        /** emit.e:1442		case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** emit.e:1443			c = Pop()*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1444			TempKeep(c)*/
        _47TempKeep(_c_52302);

        /** emit.e:1445			b = Pop()  -- remove SC1's temp*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1446			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1447			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;

        /** emit.e:1448			last_op = last_op_backup*/
        _47last_op_52257 = _last_op_backup_52316;

        /** emit.e:1449			last_pc = last_pc_backup*/
        _47last_pc_52258 = _last_pc_backup_52315;
        goto LC; // [5485] 7739

        /** emit.e:1452		case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** emit.e:1453			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1454			emit_addr(Pop())*/
        _27203 = _47Pop();
        _47emit_addr(_27203);
        _27203 = NOVALUE;

        /** emit.e:1455			c = Pop()*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1456			TempKeep(c)*/
        _47TempKeep(_c_52302);

        /** emit.e:1457			emit_addr(c) -- target*/
        _47emit_addr(_c_52302);

        /** emit.e:1458			TempInteger(c)*/
        _47TempInteger(_c_52302);

        /** emit.e:1459			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1460			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [5540] 7739

        /** emit.e:1463		case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** emit.e:1464			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1465			c = Pop()*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1466			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1467			emit_addr(Pop())*/
        _27207 = _47Pop();
        _47emit_addr(_27207);
        _27207 = NOVALUE;

        /** emit.e:1468			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1469			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1470			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [5594] 7739

        /** emit.e:1473		case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** emit.e:1474			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1475			c = Pop()*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1476			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1477			emit_addr(Pop())*/
        _27210 = _47Pop();
        _47emit_addr(_27210);
        _27210 = NOVALUE;

        /** emit.e:1478			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1479			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1480			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1481			if op = FIND or op = FIND_FROM or op = OPEN then*/
        _27212 = (_op_52298 == 77LL);
        if (_27212 != 0) {
            _27213 = 1;
            goto L90; // [5669] 5683
        }
        _27214 = (_op_52298 == 176LL);
        _27213 = (_27214 != 0);
L90: 
        if (_27213 != 0) {
            goto L91; // [5683] 5698
        }
        _27216 = (_op_52298 == 37LL);
        if (_27216 == 0)
        {
            DeRef(_27216);
            _27216 = NOVALUE;
            goto L92; // [5694] 5706
        }
        else{
            DeRef(_27216);
            _27216 = NOVALUE;
        }
L91: 

        /** emit.e:1482				TempInteger( c )*/
        _47TempInteger(_c_52302);
        goto L93; // [5703] 5713
L92: 

        /** emit.e:1484				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);
L93: 

        /** emit.e:1486			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1487			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1488			emit_addr(c)*/
        _47emit_addr(_c_52302);
        goto LC; // [5730] 7739

        /** emit.e:1491		case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** emit.e:1492			n = op_info1  -- number of items to concatenate*/
        _n_52311 = _47op_info1_51360;

        /** emit.e:1493			emit_opcode(CONCAT_N)*/
        _47emit_opcode(157LL);

        /** emit.e:1494			emit(n)*/
        _47emit(_n_52311);

        /** emit.e:1495			for i = 1 to n do*/
        _27217 = _n_52311;
        {
            object _i_53468;
            _i_53468 = 1LL;
L94: 
            if (_i_53468 > _27217){
                goto L95; // [5760] 5788
            }

            /** emit.e:1496				symtab_index element = Pop()*/
            _element_53471 = _47Pop();
            if (!IS_ATOM_INT(_element_53471)) {
                _1 = (object)(DBL_PTR(_element_53471)->dbl);
                DeRefDS(_element_53471);
                _element_53471 = _1;
            }

            /** emit.e:1497				emit_addr( element )  -- reverse order*/
            _47emit_addr(_element_53471);

            /** emit.e:1498			end for*/
            _i_53468 = _i_53468 + 1LL;
            goto L94; // [5783] 5767
L95: 
            ;
        }

        /** emit.e:1499			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1500			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1501			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);

        /** emit.e:1502			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1503			Push(c)*/
        _47Push(_c_52302);
        goto LC; // [5819] 7739

        /** emit.e:1505		case FOR then*/
        case 21:

        /** emit.e:1506			c = Pop() -- increment*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1507			TempKeep(c)*/
        _47TempKeep(_c_52302);

        /** emit.e:1508			ic = IsInteger(c)*/
        _ic_52310 = _47IsInteger(_c_52302);
        if (!IS_ATOM_INT(_ic_52310)) {
            _1 = (object)(DBL_PTR(_ic_52310)->dbl);
            DeRefDS(_ic_52310);
            _ic_52310 = _1;
        }

        /** emit.e:1509			if c < 1 or*/
        _27222 = (_c_52302 < 1LL);
        if (_27222 != 0) {
            goto L96; // [5851] 5930
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27224 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27224);
        _27225 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27224 = NOVALUE;
        if (IS_ATOM_INT(_27225)) {
            _27226 = (_27225 == 1LL);
        }
        else {
            _27226 = binary_op(EQUALS, _27225, 1LL);
        }
        _27225 = NOVALUE;
        if (IS_ATOM_INT(_27226)) {
            if (_27226 == 0) {
                DeRef(_27227);
                _27227 = 0;
                goto L97; // [5873] 5899
            }
        }
        else {
            if (DBL_PTR(_27226)->dbl == 0.0) {
                DeRef(_27227);
                _27227 = 0;
                goto L97; // [5873] 5899
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27228 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27228);
        _27229 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27228 = NOVALUE;
        if (IS_ATOM_INT(_27229)) {
            _27230 = (_27229 != 2LL);
        }
        else {
            _27230 = binary_op(NOTEQ, _27229, 2LL);
        }
        _27229 = NOVALUE;
        DeRef(_27227);
        if (IS_ATOM_INT(_27230))
        _27227 = (_27230 != 0);
        else
        _27227 = DBL_PTR(_27230)->dbl != 0.0;
L97: 
        if (_27227 == 0) {
            DeRef(_27231);
            _27231 = 0;
            goto L98; // [5899] 5925
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27232 = (object)*(((s1_ptr)_2)->base + _c_52302);
        _2 = (object)SEQ_PTR(_27232);
        _27233 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27232 = NOVALUE;
        if (IS_ATOM_INT(_27233)) {
            _27234 = (_27233 != 4LL);
        }
        else {
            _27234 = binary_op(NOTEQ, _27233, 4LL);
        }
        _27233 = NOVALUE;
        if (IS_ATOM_INT(_27234))
        _27231 = (_27234 != 0);
        else
        _27231 = DBL_PTR(_27234)->dbl != 0.0;
L98: 
        if (_27231 == 0)
        {
            _27231 = NOVALUE;
            goto L99; // [5926] 5967
        }
        else{
            _27231 = NOVALUE;
        }
L96: 

        /** emit.e:1514				emit_opcode(ASSIGN)*/
        _47emit_opcode(18LL);

        /** emit.e:1515				emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1516				c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1517				if ic then*/
        if (_ic_52310 == 0)
        {
            goto L9A; // [5952] 5961
        }
        else{
        }

        /** emit.e:1518					TempInteger( c )*/
        _47TempInteger(_c_52302);
L9A: 

        /** emit.e:1520				emit_addr(c)*/
        _47emit_addr(_c_52302);
L99: 

        /** emit.e:1522			b = Pop() -- limit*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1523			TempKeep(b)*/
        _47TempKeep(_b_52301);

        /** emit.e:1524			ib = IsInteger(b)*/
        _ib_52309 = _47IsInteger(_b_52301);
        if (!IS_ATOM_INT(_ib_52309)) {
            _1 = (object)(DBL_PTR(_ib_52309)->dbl);
            DeRefDS(_ib_52309);
            _ib_52309 = _1;
        }

        /** emit.e:1525			if b < 1 or*/
        _27238 = (_b_52301 < 1LL);
        if (_27238 != 0) {
            goto L9B; // [5993] 6072
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27240 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27240);
        _27241 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27240 = NOVALUE;
        if (IS_ATOM_INT(_27241)) {
            _27242 = (_27241 == 1LL);
        }
        else {
            _27242 = binary_op(EQUALS, _27241, 1LL);
        }
        _27241 = NOVALUE;
        if (IS_ATOM_INT(_27242)) {
            if (_27242 == 0) {
                DeRef(_27243);
                _27243 = 0;
                goto L9C; // [6015] 6041
            }
        }
        else {
            if (DBL_PTR(_27242)->dbl == 0.0) {
                DeRef(_27243);
                _27243 = 0;
                goto L9C; // [6015] 6041
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27244 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27244);
        _27245 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27244 = NOVALUE;
        if (IS_ATOM_INT(_27245)) {
            _27246 = (_27245 != 2LL);
        }
        else {
            _27246 = binary_op(NOTEQ, _27245, 2LL);
        }
        _27245 = NOVALUE;
        DeRef(_27243);
        if (IS_ATOM_INT(_27246))
        _27243 = (_27246 != 0);
        else
        _27243 = DBL_PTR(_27246)->dbl != 0.0;
L9C: 
        if (_27243 == 0) {
            DeRef(_27247);
            _27247 = 0;
            goto L9D; // [6041] 6067
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27248 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27248);
        _27249 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27248 = NOVALUE;
        if (IS_ATOM_INT(_27249)) {
            _27250 = (_27249 != 4LL);
        }
        else {
            _27250 = binary_op(NOTEQ, _27249, 4LL);
        }
        _27249 = NOVALUE;
        if (IS_ATOM_INT(_27250))
        _27247 = (_27250 != 0);
        else
        _27247 = DBL_PTR(_27250)->dbl != 0.0;
L9D: 
        if (_27247 == 0)
        {
            _27247 = NOVALUE;
            goto L9E; // [6068] 6109
        }
        else{
            _27247 = NOVALUE;
        }
L9B: 

        /** emit.e:1530				emit_opcode(ASSIGN)*/
        _47emit_opcode(18LL);

        /** emit.e:1531				emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1532				b = NewTempSym()*/
        _b_52301 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1533				if ib then*/
        if (_ib_52309 == 0)
        {
            goto L9F; // [6094] 6103
        }
        else{
        }

        /** emit.e:1534					TempInteger( b )*/
        _47TempInteger(_b_52301);
L9F: 

        /** emit.e:1536				emit_addr(b)*/
        _47emit_addr(_b_52301);
L9E: 

        /** emit.e:1538			a = Pop() -- initial value*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1539			if IsInteger(a) and ib and ic then*/
        _27253 = _47IsInteger(_a_52300);
        if (IS_ATOM_INT(_27253)) {
            if (_27253 == 0) {
                DeRef(_27254);
                _27254 = 0;
                goto LA0; // [6122] 6130
            }
        }
        else {
            if (DBL_PTR(_27253)->dbl == 0.0) {
                DeRef(_27254);
                _27254 = 0;
                goto LA0; // [6122] 6130
            }
        }
        DeRef(_27254);
        _27254 = (_ib_52309 != 0);
LA0: 
        if (_27254 == 0) {
            goto LA1; // [6130] 6169
        }
        if (_ic_52310 == 0)
        {
            goto LA1; // [6135] 6169
        }
        else{
        }

        /** emit.e:1540				SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_47op_info1_51360 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _54integer_type_47138;
        DeRef(_1);
        _27256 = NOVALUE;

        /** emit.e:1541				op = FOR_I*/
        _op_52298 = 125LL;
        goto LA2; // [6166] 6179
LA1: 

        /** emit.e:1543				op = FOR*/
        _op_52298 = 21LL;
LA2: 

        /** emit.e:1545			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1546			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1547			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1548			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1549			emit_addr(CurrentSub) -- in case recursion check is needed*/
        _47emit_addr(_36CurrentSub_21767);

        /** emit.e:1550			Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1551			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1552			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6223] 7739

        /** emit.e:1555		case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** emit.e:1556			emit_opcode(op) -- will be patched at runtime*/
        _47emit_opcode(_op_52298);

        /** emit.e:1557			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1558			emit_addr(op_info2) -- address of top of loop*/
        _47emit_addr(_47op_info2_51361);

        /** emit.e:1559			emit_addr(Pop())    -- limit*/
        _27259 = _47Pop();
        _47emit_addr(_27259);
        _27259 = NOVALUE;

        /** emit.e:1560			emit_addr(op_info1) -- loop var*/
        _47emit_addr(_47op_info1_51360);

        /** emit.e:1561			emit_addr(a)        -- increment - not always used -*/
        _47emit_addr(_a_52300);

        /** emit.e:1563			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6277] 7739

        /** emit.e:1566		case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** emit.e:1568			b = Pop()      -- rhs value, keep on stack*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1569			TempKeep(b)*/
        _47TempKeep(_b_52301);

        /** emit.e:1571			a = Pop()      -- subscript, keep on stack*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1572			TempKeep(a)*/
        _47TempKeep(_a_52300);

        /** emit.e:1574			c = Pop()      -- lhs sequence, keep on stack*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1575			TempKeep(c)*/
        _47TempKeep(_c_52302);

        /** emit.e:1577			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1578			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1579			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1581			d = NewTempSym()*/
        _d_52303 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_d_52303)) {
            _1 = (object)(DBL_PTR(_d_52303)->dbl);
            DeRefDS(_d_52303);
            _d_52303 = _1;
        }

        /** emit.e:1582			emit_addr(d)   -- place to store result*/
        _47emit_addr(_d_52303);

        /** emit.e:1583			emit_temp( d, NEW_REFERENCE )*/
        _47emit_temp(_d_52303, 1LL);

        /** emit.e:1585			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1586			Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1587			Push(d)*/
        _47Push(_d_52303);

        /** emit.e:1588			Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1589			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6382] 7739

        /** emit.e:1592		case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** emit.e:1593			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1594			b = Pop() -- rhs value*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1595			a = Pop() -- 2nd subs*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1596			c = Pop() -- 1st subs*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1597			emit_addr(Pop()) -- sequence*/
        _27267 = _47Pop();
        _47emit_addr(_27267);
        _27267 = NOVALUE;

        /** emit.e:1598			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1599			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1600			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1601			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6446] 7739

        /** emit.e:1604		case REPLACE then*/
        case 201:

        /** emit.e:1605			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1607			b = Pop()  -- source*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1608			a = Pop()  -- replacement*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1609			c = Pop()  -- start of replaced slice*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1610			d = Pop()  -- end of replaced slice*/
        _d_52303 = _47Pop();
        if (!IS_ATOM_INT(_d_52303)) {
            _1 = (object)(DBL_PTR(_d_52303)->dbl);
            DeRefDS(_d_52303);
            _d_52303 = _1;
        }

        /** emit.e:1611			emit_addr(d)*/
        _47emit_addr(_d_52303);

        /** emit.e:1612			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1613			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1614			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1616			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1617			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1618			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_52302);

        /** emit.e:1619			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);

        /** emit.e:1620			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;
        goto LC; // [6536] 7739

        /** emit.e:1623		case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** emit.e:1625			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1627			b = Pop()        -- rhs value not used*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1628			TempKeep(b)*/
        _47TempKeep(_b_52301);

        /** emit.e:1630			a = Pop()        -- 2nd subs*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1631			TempKeep(a)*/
        _47TempKeep(_a_52300);

        /** emit.e:1633			c = Pop()        -- 1st subs*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1634			TempKeep(c)*/
        _47TempKeep(_c_52302);

        /** emit.e:1636			d = Pop()*/
        _d_52303 = _47Pop();
        if (!IS_ATOM_INT(_d_52303)) {
            _1 = (object)(DBL_PTR(_d_52303)->dbl);
            DeRefDS(_d_52303);
            _d_52303 = _1;
        }

        /** emit.e:1637			TempKeep(d)      -- sequence*/
        _47TempKeep(_d_52303);

        /** emit.e:1639			emit_addr(d)*/
        _47emit_addr(_d_52303);

        /** emit.e:1640			Push(d)*/
        _47Push(_d_52303);

        /** emit.e:1642			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1643			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1645			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1646			Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1648			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1649			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1650			emit_addr(c)     -- place to store result*/
        _47emit_addr(_c_52302);

        /** emit.e:1651			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);

        /** emit.e:1653			Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1654			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6663] 7739

        /** emit.e:1657		case CALL_PROC then*/
        case 136:

        /** emit.e:1658			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1659			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1660			emit_addr(Pop())*/
        _27279 = _47Pop();
        _47emit_addr(_27279);
        _27279 = NOVALUE;

        /** emit.e:1661			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1662			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6701] 7739

        /** emit.e:1664		case CALL_FUNC then*/
        case 137:

        /** emit.e:1665			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1666			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1667			emit_addr(Pop())*/
        _27281 = _47Pop();
        _47emit_addr(_27281);
        _27281 = NOVALUE;

        /** emit.e:1668			emit_addr(b)*/
        _47emit_addr(_b_52301);

        /** emit.e:1669			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1670			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1671			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1672			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1673			emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);
        goto LC; // [6763] 7739

        /** emit.e:1675		case EXIT_BLOCK then*/
        case 206:

        /** emit.e:1676			emit_opcode( op )*/
        _47emit_opcode(_op_52298);

        /** emit.e:1677			emit_addr( Pop() )*/
        _27283 = _47Pop();
        _47emit_addr(_27283);
        _27283 = NOVALUE;

        /** emit.e:1678			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6789] 7739

        /** emit.e:1680		case RETURNP then*/
        case 29:

        /** emit.e:1681			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1682			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21767);

        /** emit.e:1683			emit_addr(top_block())*/
        _27284 = _65top_block(0LL);
        _47emit_addr(_27284);
        _27284 = NOVALUE;

        /** emit.e:1684			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6823] 7739

        /** emit.e:1686		case RETURNF then*/
        case 28:

        /** emit.e:1687			clear_temp( Top() )*/

        /** emit.e:145		return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_7037_53618);
        _2 = (object)SEQ_PTR(_47cg_stack_51375);
        _Top_inlined_Top_at_7037_53618 = (object)*(((s1_ptr)_2)->base + _47cgi_51376);
        Ref(_Top_inlined_Top_at_7037_53618);
        Ref(_Top_inlined_Top_at_7037_53618);
        _47clear_temp(_Top_inlined_Top_at_7037_53618);

        /** emit.e:1688			flush_temps()*/
        RefDS(_22186);
        _47flush_temps(_22186);

        /** emit.e:1689			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1690			emit_addr(CurrentSub)*/
        _47emit_addr(_36CurrentSub_21767);

        /** emit.e:1691			emit_addr(Least_block())*/
        _27285 = _65Least_block();
        _47emit_addr(_27285);
        _27285 = NOVALUE;

        /** emit.e:1692			emit_addr(Pop())*/
        _27286 = _47Pop();
        _47emit_addr(_27286);
        _27286 = NOVALUE;

        /** emit.e:1693			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6885] 7739

        /** emit.e:1695		case RETURNT then*/
        case 34:

        /** emit.e:1696			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1697			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [6903] 7739

        /** emit.e:1699		case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** emit.e:1701			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1702			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1703			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;

        /** emit.e:1704			if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_52298 != 79LL)
        goto LA3; // [6945] 6957

        /** emit.e:1705				TempInteger(c)*/
        _47TempInteger(_c_52302);
        goto LA4; // [6954] 6964
LA3: 

        /** emit.e:1707				emit_temp( c, NEW_REFERENCE )*/
        _47emit_temp(_c_52302, 1LL);
LA4: 

        /** emit.e:1709			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1710			emit_addr(c)*/
        _47emit_addr(_c_52302);
        goto LC; // [6974] 7739

        /** emit.e:1712		case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** emit.e:1713			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1714			emit_addr(Pop())*/
        _27289 = _47Pop();
        _47emit_addr(_27289);
        _27289 = NOVALUE;

        /** emit.e:1715			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7006] 7739

        /** emit.e:1717		case POWER then*/
        case 72:

        /** emit.e:1719			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1720			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1721			if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _27292 = (_b_52301 > 0LL);
        if (_27292 == 0) {
            _27293 = 0;
            goto LA5; // [7032] 7058
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27294 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27294);
        _27295 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27294 = NOVALUE;
        if (IS_ATOM_INT(_27295)) {
            _27296 = (_27295 == 2LL);
        }
        else {
            _27296 = binary_op(EQUALS, _27295, 2LL);
        }
        _27295 = NOVALUE;
        if (IS_ATOM_INT(_27296))
        _27293 = (_27296 != 0);
        else
        _27293 = DBL_PTR(_27296)->dbl != 0.0;
LA5: 
        if (_27293 == 0) {
            goto LA6; // [7058] 7115
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27298 = (object)*(((s1_ptr)_2)->base + _b_52301);
        _2 = (object)SEQ_PTR(_27298);
        _27299 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27298 = NOVALUE;
        if (_27299 == 2LL)
        _27300 = 1;
        else if (IS_ATOM_INT(_27299) && IS_ATOM_INT(2LL))
        _27300 = 0;
        else
        _27300 = (compare(_27299, 2LL) == 0);
        _27299 = NOVALUE;
        if (_27300 == 0)
        {
            _27300 = NOVALUE;
            goto LA6; // [7079] 7115
        }
        else{
            _27300 = NOVALUE;
        }

        /** emit.e:1723				op = rw:MULTIPLY*/
        _op_52298 = 13LL;

        /** emit.e:1724				emit_opcode(op)*/
        _47emit_opcode(13LL);

        /** emit.e:1725				emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1726				emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1727				cont21d(op, a, b, FALSE)*/
        _47cont21d(13LL, _a_52300, _b_52301, _13FALSE_445);
        goto LC; // [7112] 7739
LA6: 

        /** emit.e:1729				Push(a)*/
        _47Push(_a_52300);

        /** emit.e:1730				Push(b)*/
        _47Push(_b_52301);

        /** emit.e:1731				cont21ii(op, FALSE)*/
        _47cont21ii(_op_52298, _13FALSE_445);
        goto LC; // [7134] 7739

        /** emit.e:1735		case TYPE_CHECK then*/
        case 65:

        /** emit.e:1736			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1737			c = Pop()*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1738			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7159] 7739

        /** emit.e:1741		case DOLLAR then*/
        case -22:

        /** emit.e:1742			if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_47current_sequence_51368)){
                _27302 = SEQ_PTR(_47current_sequence_51368)->length;
        }
        else {
            _27302 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51368);
        _27303 = (object)*(((s1_ptr)_2)->base + _27302);
        if (IS_ATOM_INT(_27303)) {
            _27304 = (_27303 < 0LL);
        }
        else {
            _27304 = binary_op(LESS, _27303, 0LL);
        }
        _27303 = NOVALUE;
        if (IS_ATOM_INT(_27304)) {
            if (_27304 != 0) {
                goto LA7; // [7180] 7216
            }
        }
        else {
            if (DBL_PTR(_27304)->dbl != 0.0) {
                goto LA7; // [7180] 7216
            }
        }
        if (IS_SEQUENCE(_47current_sequence_51368)){
                _27306 = SEQ_PTR(_47current_sequence_51368)->length;
        }
        else {
            _27306 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51368);
        _27307 = (object)*(((s1_ptr)_2)->base + _27306);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27307)){
            _27308 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27307)->dbl));
        }
        else{
            _27308 = (object)*(((s1_ptr)_2)->base + _27307);
        }
        _2 = (object)SEQ_PTR(_27308);
        _27309 = (object)*(((s1_ptr)_2)->base + 4LL);
        _27308 = NOVALUE;
        if (IS_ATOM_INT(_27309)) {
            _27310 = (_27309 == 9LL);
        }
        else {
            _27310 = binary_op(EQUALS, _27309, 9LL);
        }
        _27309 = NOVALUE;
        if (_27310 == 0) {
            DeRef(_27310);
            _27310 = NOVALUE;
            goto LA8; // [7212] 7286
        }
        else {
            if (!IS_ATOM_INT(_27310) && DBL_PTR(_27310)->dbl == 0.0){
                DeRef(_27310);
                _27310 = NOVALUE;
                goto LA8; // [7212] 7286
            }
            DeRef(_27310);
            _27310 = NOVALUE;
        }
        DeRef(_27310);
        _27310 = NOVALUE;
LA7: 

        /** emit.e:1743				if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_51370 == 0) {
            goto LA9; // [7220] 7249
        }
        if (IS_SEQUENCE(_47current_sequence_51368)){
                _27312 = SEQ_PTR(_47current_sequence_51368)->length;
        }
        else {
            _27312 = 1;
        }
        _27313 = (_27312 == 1LL);
        _27312 = NOVALUE;
        if (_27313 == 0)
        {
            DeRef(_27313);
            _27313 = NOVALUE;
            goto LA9; // [7234] 7249
        }
        else{
            DeRef(_27313);
            _27313 = NOVALUE;
        }

        /** emit.e:1744					c = PLENGTH*/
        _c_52302 = 160LL;
        goto LAA; // [7246] 7259
LA9: 

        /** emit.e:1746					c = LENGTH*/
        _c_52302 = 42LL;
LAA: 

        /** emit.e:1748				c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_47current_sequence_51368)){
                _27314 = SEQ_PTR(_47current_sequence_51368)->length;
        }
        else {
            _27314 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51368);
        _27315 = (object)*(((s1_ptr)_2)->base + _27314);
        Ref(_27315);
        _27316 = _44new_forward_reference(-100LL, _27315, _c_52302);
        _27315 = NOVALUE;
        if (IS_ATOM_INT(_27316)) {
            if ((uintptr_t)_27316 == (uintptr_t)HIGH_BITS){
                _c_52302 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _c_52302 = - _27316;
            }
        }
        else {
            _c_52302 = unary_op(UMINUS, _27316);
        }
        DeRef(_27316);
        _27316 = NOVALUE;
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }
        goto LAB; // [7283] 7300
LA8: 

        /** emit.e:1750				c = current_sequence[$]*/
        if (IS_SEQUENCE(_47current_sequence_51368)){
                _27318 = SEQ_PTR(_47current_sequence_51368)->length;
        }
        else {
            _27318 = 1;
        }
        _2 = (object)SEQ_PTR(_47current_sequence_51368);
        _c_52302 = (object)*(((s1_ptr)_2)->base + _27318);
        if (!IS_ATOM_INT(_c_52302)){
            _c_52302 = (object)DBL_PTR(_c_52302)->dbl;
        }
LAB: 

        /** emit.e:1754			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_47lhs_ptr_51370 == 0) {
            goto LAC; // [7304] 7331
        }
        if (IS_SEQUENCE(_47current_sequence_51368)){
                _27321 = SEQ_PTR(_47current_sequence_51368)->length;
        }
        else {
            _27321 = 1;
        }
        _27322 = (_27321 == 1LL);
        _27321 = NOVALUE;
        if (_27322 == 0)
        {
            DeRef(_27322);
            _27322 = NOVALUE;
            goto LAC; // [7318] 7331
        }
        else{
            DeRef(_27322);
            _27322 = NOVALUE;
        }

        /** emit.e:1755				emit_opcode(PLENGTH)*/
        _47emit_opcode(160LL);
        goto LAD; // [7328] 7339
LAC: 

        /** emit.e:1757				emit_opcode(LENGTH)*/
        _47emit_opcode(42LL);
LAD: 

        /** emit.e:1760			emit_addr( c )*/
        _47emit_addr(_c_52302);

        /** emit.e:1762			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1763			TempInteger(c)*/
        _47TempInteger(_c_52302);

        /** emit.e:1764			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1765			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1766			assignable = FALSE -- it wouldn't be assigned anyway*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7374] 7739

        /** emit.e:1769		case TASK_SELF then*/
        case 170:

        /** emit.e:1770			c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1771			Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1772			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1773			emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1774			assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;
        goto LC; // [7410] 7739

        /** emit.e:1776		case SWITCH then*/
        case 185:

        /** emit.e:1777			emit_opcode( op )*/
        _47emit_opcode(_op_52298);

        /** emit.e:1778			c = Pop()*/
        _c_52302 = _47Pop();
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1779			b = Pop()*/
        _b_52301 = _47Pop();
        if (!IS_ATOM_INT(_b_52301)) {
            _1 = (object)(DBL_PTR(_b_52301)->dbl);
            DeRefDS(_b_52301);
            _b_52301 = _1;
        }

        /** emit.e:1780			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1781			emit_addr( a ) -- Switch Expr*/
        _47emit_addr(_a_52300);

        /** emit.e:1782			emit_addr( b ) -- Case values*/
        _47emit_addr(_b_52301);

        /** emit.e:1783			emit_addr( c ) -- Jump table*/
        _47emit_addr(_c_52302);

        /** emit.e:1785			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7464] 7739

        /** emit.e:1787		case CASE then*/
        case 186:

        /** emit.e:1789			emit_opcode( op )*/
        _47emit_opcode(_op_52298);

        /** emit.e:1790			emit( cg_stack[cgi] )  -- the case index*/
        _2 = (object)SEQ_PTR(_47cg_stack_51375);
        _27328 = (object)*(((s1_ptr)_2)->base + _47cgi_51376);
        Ref(_27328);
        _47emit(_27328);
        _27328 = NOVALUE;

        /** emit.e:1791			cgi -= 1*/
        _47cgi_51376 = _47cgi_51376 - 1LL;
        goto LC; // [7496] 7739

        /** emit.e:1794		case PLATFORM then*/
        case 155:

        /** emit.e:1795			if BIND and shroud_only then*/
        if (_36BIND_21364 == 0) {
            goto LAE; // [7506] 7554
        }
        if (_36shroud_only_21757 == 0)
        {
            goto LAE; // [7513] 7554
        }
        else{
        }

        /** emit.e:1797				c = NewTempSym()*/
        _c_52302 = _54NewTempSym(0LL);
        if (!IS_ATOM_INT(_c_52302)) {
            _1 = (object)(DBL_PTR(_c_52302)->dbl);
            DeRefDS(_c_52302);
            _c_52302 = _1;
        }

        /** emit.e:1798				TempInteger(c)*/
        _47TempInteger(_c_52302);

        /** emit.e:1799				Push(c)*/
        _47Push(_c_52302);

        /** emit.e:1800				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1801				emit_addr(c)*/
        _47emit_addr(_c_52302);

        /** emit.e:1802				assignable = TRUE*/
        _47assignable_51378 = _13TRUE_447;
        goto LC; // [7551] 7739
LAE: 

        /** emit.e:1806				n = host_platform()*/
        _n_52311 = _46host_platform();
        if (!IS_ATOM_INT(_n_52311)) {
            _1 = (object)(DBL_PTR(_n_52311)->dbl);
            DeRefDS(_n_52311);
            _n_52311 = _1;
        }

        /** emit.e:1807				Push(NewIntSym(n))*/
        _27333 = _54NewIntSym(_n_52311);
        _47Push(_27333);
        _27333 = NOVALUE;

        /** emit.e:1808				assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7578] 7739

        /** emit.e:1812		case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** emit.e:1813			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1814			emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1815			emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1816			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7610] 7739

        /** emit.e:1818		case TRACE then*/
        case 64:

        /** emit.e:1819			a = Pop()*/
        _a_52300 = _47Pop();
        if (!IS_ATOM_INT(_a_52300)) {
            _1 = (object)(DBL_PTR(_a_52300)->dbl);
            DeRefDS(_a_52300);
            _a_52300 = _1;
        }

        /** emit.e:1820			if OpTrace then*/
        if (_36OpTrace_21832 == 0)
        {
            goto LAF; // [7627] 7673
        }
        else{
        }

        /** emit.e:1822				emit_opcode(op)*/
        _47emit_opcode(_op_52298);

        /** emit.e:1823				emit_addr(a)*/
        _47emit_addr(_a_52300);

        /** emit.e:1824				if TRANSLATE then*/
        if (_36TRANSLATE_21361 == 0)
        {
            goto LB0; // [7644] 7672
        }
        else{
        }

        /** emit.e:1825					if not trace_called then*/
        if (_47trace_called_51363 != 0)
        goto LB1; // [7651] 7662

        /** emit.e:1826						Warning(217,0)*/
        RefDS(_22186);
        _50Warning(217LL, 0LL, _22186);
LB1: 

        /** emit.e:1828					trace_called = TRUE*/
        _47trace_called_51363 = _13TRUE_447;
LB0: 
LAF: 

        /** emit.e:1831			assignable = FALSE*/
        _47assignable_51378 = _13FALSE_445;
        goto LC; // [7680] 7739

        /** emit.e:1833		case REF_TEMP then*/
        case 207:

        /** emit.e:1835			emit_opcode( REF_TEMP )*/
        _47emit_opcode(207LL);

        /** emit.e:1836			emit_addr( Pop() )*/
        _27337 = _47Pop();
        _47emit_addr(_27337);
        _27337 = NOVALUE;
        goto LC; // [7701] 7739

        /** emit.e:1838		case DEREF_TEMP then*/
        case 208:

        /** emit.e:1839			emit_opcode( DEREF_TEMP )*/
        _47emit_opcode(208LL);

        /** emit.e:1840			emit_addr( Pop() )*/
        _27338 = _47Pop();
        _47emit_addr(_27338);
        _27338 = NOVALUE;
        goto LC; // [7722] 7739

        /** emit.e:1842		case else*/
        default:

        /** emit.e:1843			InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_52298;
        _27339 = MAKE_SEQ(_1);
        _50InternalErr(259LL, _27339);
        _27339 = NOVALUE;
    ;}LC: 

    /** emit.e:1847		previous_op = op*/
    _36previous_op_21861 = _op_52298;

    /** emit.e:1848		inlined = 0*/
    _47inlined_52276 = 0LL;

    /** emit.e:1850	end procedure*/
    DeRef(_obj_52312);
    DeRef(_elements_52313);
    DeRef(_element_vals_52314);
    DeRef(_27163);
    _27163 = NOVALUE;
    DeRef(_26946);
    _26946 = NOVALUE;
    DeRef(_26944);
    _26944 = NOVALUE;
    DeRef(_27017);
    _27017 = NOVALUE;
    DeRef(_27034);
    _27034 = NOVALUE;
    DeRef(_27068);
    _27068 = NOVALUE;
    DeRef(_26754);
    _26754 = NOVALUE;
    DeRef(_26890);
    _26890 = NOVALUE;
    DeRef(_26962);
    _26962 = NOVALUE;
    DeRef(_27292);
    _27292 = NOVALUE;
    DeRef(_26958);
    _26958 = NOVALUE;
    DeRef(_27076);
    _27076 = NOVALUE;
    _27081 = NOVALUE;
    DeRef(_26924);
    _26924 = NOVALUE;
    DeRef(_26794);
    _26794 = NOVALUE;
    _27079 = NOVALUE;
    DeRef(_26997);
    _26997 = NOVALUE;
    _26868 = NOVALUE;
    DeRef(_27122);
    _27122 = NOVALUE;
    DeRef(_26967);
    _26967 = NOVALUE;
    DeRef(_26864);
    _26864 = NOVALUE;
    _26827 = NOVALUE;
    DeRef(_26984);
    _26984 = NOVALUE;
    DeRef(_27214);
    _27214 = NOVALUE;
    DeRef(_27046);
    _27046 = NOVALUE;
    DeRef(_26930);
    _26930 = NOVALUE;
    DeRef(_27144);
    _27144 = NOVALUE;
    DeRef(_27250);
    _27250 = NOVALUE;
    DeRef(_26993);
    _26993 = NOVALUE;
    DeRef(_27010);
    _27010 = NOVALUE;
    DeRef(_27253);
    _27253 = NOVALUE;
    DeRef(_26756);
    _26756 = NOVALUE;
    DeRef(_27222);
    _27222 = NOVALUE;
    DeRef(_27041);
    _27041 = NOVALUE;
    DeRef(_27242);
    _27242 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_26786);
    _26786 = NOVALUE;
    DeRef(_26940);
    _26940 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27064);
    _27064 = NOVALUE;
    DeRef(_27156);
    _27156 = NOVALUE;
    DeRef(_26829);
    _26829 = NOVALUE;
    DeRef(_27003);
    _27003 = NOVALUE;
    DeRef(_26752);
    _26752 = NOVALUE;
    _26774 = NOVALUE;
    DeRef(_26903);
    _26903 = NOVALUE;
    DeRef(_27212);
    _27212 = NOVALUE;
    _26873 = NOVALUE;
    DeRef(_26858);
    _26858 = NOVALUE;
    DeRef(_26999);
    _26999 = NOVALUE;
    DeRef(_27149);
    _27149 = NOVALUE;
    DeRef(_26965);
    _26965 = NOVALUE;
    DeRef(_27185);
    _27185 = NOVALUE;
    DeRef(_27072);
    _27072 = NOVALUE;
    DeRef(_27062);
    _27062 = NOVALUE;
    DeRef(_26791);
    _26791 = NOVALUE;
    DeRef(_26850);
    _26850 = NOVALUE;
    DeRef(_27012);
    _27012 = NOVALUE;
    _26842 = NOVALUE;
    DeRef(_27296);
    _27296 = NOVALUE;
    DeRef(_26804);
    _26804 = NOVALUE;
    DeRef(_26971);
    _26971 = NOVALUE;
    DeRef(_27198);
    _27198 = NOVALUE;
    DeRef(_26801);
    _26801 = NOVALUE;
    DeRef(_27304);
    _27304 = NOVALUE;
    DeRef(_27175);
    _27175 = NOVALUE;
    DeRef(_27084);
    _27084 = NOVALUE;
    DeRef(_26750);
    _26750 = NOVALUE;
    DeRef(_27044);
    _27044 = NOVALUE;
    DeRef(_27246);
    _27246 = NOVALUE;
    DeRef(_26871);
    _26871 = NOVALUE;
    DeRef(_27181);
    _27181 = NOVALUE;
    DeRef(_27023);
    _27023 = NOVALUE;
    DeRef(_27168);
    _27168 = NOVALUE;
    DeRef(_27021);
    _27021 = NOVALUE;
    DeRef(_27234);
    _27234 = NOVALUE;
    DeRef(_26806);
    _26806 = NOVALUE;
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_26988);
    _26988 = NOVALUE;
    DeRef(_26839);
    _26839 = NOVALUE;
    DeRef(_26825);
    _26825 = NOVALUE;
    _26844 = NOVALUE;
    DeRef(_26810);
    _26810 = NOVALUE;
    DeRef(_26936);
    _26936 = NOVALUE;
    DeRef(_26758);
    _26758 = NOVALUE;
    _27307 = NOVALUE;
    DeRef(_27038);
    _27038 = NOVALUE;
    return;
    ;
}


void _47emit_assign_op(object _op_53777)
{
    object _0, _1, _2;
    

    /** emit.e:1854		if op = PLUS_EQUALS then*/
    if (_op_53777 != 515LL)
    goto L1; // [7] 21

    /** emit.e:1855			emit_op(PLUS)*/
    _47emit_op(11LL);
    goto L2; // [18] 86
L1: 

    /** emit.e:1856		elsif op = MINUS_EQUALS then*/
    if (_op_53777 != 516LL)
    goto L3; // [25] 39

    /** emit.e:1857			emit_op(MINUS)*/
    _47emit_op(10LL);
    goto L2; // [36] 86
L3: 

    /** emit.e:1858		elsif op = MULTIPLY_EQUALS then*/
    if (_op_53777 != 517LL)
    goto L4; // [43] 55

    /** emit.e:1859			emit_op(rw:MULTIPLY)*/
    _47emit_op(13LL);
    goto L2; // [52] 86
L4: 

    /** emit.e:1860		elsif op = DIVIDE_EQUALS then*/
    if (_op_53777 != 518LL)
    goto L5; // [59] 71

    /** emit.e:1861			emit_op(rw:DIVIDE)*/
    _47emit_op(14LL);
    goto L2; // [68] 86
L5: 

    /** emit.e:1862		elsif op = CONCAT_EQUALS then*/
    if (_op_53777 != 519LL)
    goto L6; // [75] 85

    /** emit.e:1863			emit_op(rw:CONCAT)*/
    _47emit_op(15LL);
L6: 
L2: 

    /** emit.e:1865	end procedure*/
    return;
    ;
}


void _47StartSourceLine(object _sl_53797, object _dup_ok_53798, object _emit_coverage_53799)
{
    object _line_span_53802 = NOVALUE;
    object _27361 = NOVALUE;
    object _27359 = NOVALUE;
    object _27358 = NOVALUE;
    object _27357 = NOVALUE;
    object _27356 = NOVALUE;
    object _27355 = NOVALUE;
    object _27353 = NOVALUE;
    object _27350 = NOVALUE;
    object _27348 = NOVALUE;
    object _27347 = NOVALUE;
    object _27346 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1873		if gline_number = LastLineNumber then*/
    if (_36gline_number_21764 != _62LastLineNumber_25871)
    goto L1; // [13] 66

    /** emit.e:1874			if length(LineTable) then*/
    if (IS_SEQUENCE(_36LineTable_21852)){
            _27346 = SEQ_PTR(_36LineTable_21852)->length;
    }
    else {
        _27346 = 1;
    }
    if (_27346 == 0)
    {
        _27346 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _27346 = NOVALUE;
    }

    /** emit.e:1875				if dup_ok then*/
    if (_dup_ok_53798 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** emit.e:1876					emit_op( STARTLINE )*/
    _47emit_op(58LL);

    /** emit.e:1877					emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21764);
L3: 

    /** emit.e:1879				return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** emit.e:1882				sl = FALSE -- top-level new statement to execute on same line*/
    _sl_53797 = _13FALSE_445;
L4: 
L1: 

    /** emit.e:1885		LastLineNumber = gline_number*/
    _62LastLineNumber_25871 = _36gline_number_21764;

    /** emit.e:1888		line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27347 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_27347);
    if (!IS_ATOM_INT(_36S_FIRSTLINE_21436)){
        _27348 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FIRSTLINE_21436)->dbl));
    }
    else{
        _27348 = (object)*(((s1_ptr)_2)->base + _36S_FIRSTLINE_21436);
    }
    _27347 = NOVALUE;
    if (IS_ATOM_INT(_27348)) {
        _line_span_53802 = _36gline_number_21764 - _27348;
    }
    else {
        _line_span_53802 = binary_op(MINUS, _36gline_number_21764, _27348);
    }
    _27348 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_53802)) {
        _1 = (object)(DBL_PTR(_line_span_53802)->dbl);
        DeRefDS(_line_span_53802);
        _line_span_53802 = _1;
    }

    /** emit.e:1889		while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_36LineTable_21852)){
            _27350 = SEQ_PTR(_36LineTable_21852)->length;
    }
    else {
        _27350 = 1;
    }
    if (_27350 >= _line_span_53802)
    goto L6; // [109] 128

    /** emit.e:1890			LineTable = append(LineTable, -1) -- filler*/
    Append(&_36LineTable_21852, _36LineTable_21852, -1LL);

    /** emit.e:1891		end while*/
    goto L5; // [125] 104
L6: 

    /** emit.e:1892		LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_36Code_21851)){
            _27353 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _27353 = 1;
    }
    Append(&_36LineTable_21852, _36LineTable_21852, _27353);
    _27353 = NOVALUE;

    /** emit.e:1894		if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_53797 == 0) {
        goto L7; // [145] 190
    }
    if (_36TRANSLATE_21361 != 0) {
        DeRef(_27356);
        _27356 = 1;
        goto L8; // [151] 171
    }
    if (_36OpTrace_21832 != 0) {
        _27357 = 1;
        goto L9; // [157] 167
    }
    _27357 = (_36OpProfileStatement_21834 != 0);
L9: 
    DeRef(_27356);
    _27356 = (_27357 != 0);
L8: 
    if (_27356 == 0)
    {
        _27356 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _27356 = NOVALUE;
    }

    /** emit.e:1896			emit_op(STARTLINE)*/
    _47emit_op(58LL);

    /** emit.e:1897			emit_addr(gline_number)*/
    _47emit_addr(_36gline_number_21764);
L7: 

    /** emit.e:1901		if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_53797 == 0) {
        _27358 = 0;
        goto LA; // [192] 206
    }
    _27359 = (_emit_coverage_53799 == 2LL);
    _27358 = (_27359 != 0);
LA: 
    if (_27358 != 0) {
        goto LB; // [206] 221
    }
    _27361 = (_emit_coverage_53799 == 3LL);
    if (_27361 == 0)
    {
        DeRef(_27361);
        _27361 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_27361);
        _27361 = NOVALUE;
    }
LB: 

    /** emit.e:1902			include_line( gline_number )*/
    _51include_line(_36gline_number_21764);
LC: 

    /** emit.e:1905	end procedure*/
    DeRef(_27359);
    _27359 = NOVALUE;
    return;
    ;
}


object _47has_forward_params(object _sym_53856)
{
    object _27367 = NOVALUE;
    object _27366 = NOVALUE;
    object _27365 = NOVALUE;
    object _27364 = NOVALUE;
    object _27363 = NOVALUE;
    object _27362 = NOVALUE;
    object _0, _1, _2;
    

    /** emit.e:1908		for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27362 = (object)*(((s1_ptr)_2)->base + _sym_53856);
    _2 = (object)SEQ_PTR(_27362);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _27363 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _27363 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _27362 = NOVALUE;
    if (IS_ATOM_INT(_27363)) {
        _27364 = _27363 - 1LL;
        if ((object)((uintptr_t)_27364 +(uintptr_t) HIGH_BITS) >= 0){
            _27364 = NewDouble((eudouble)_27364);
        }
    }
    else {
        _27364 = binary_op(MINUS, _27363, 1LL);
    }
    _27363 = NOVALUE;
    if (IS_ATOM_INT(_27364)) {
        _27365 = _47cgi_51376 - _27364;
        if ((object)((uintptr_t)_27365 +(uintptr_t) HIGH_BITS) >= 0){
            _27365 = NewDouble((eudouble)_27365);
        }
    }
    else {
        _27365 = binary_op(MINUS, _47cgi_51376, _27364);
    }
    DeRef(_27364);
    _27364 = NOVALUE;
    _27366 = _47cgi_51376;
    {
        object _i_53858;
        Ref(_27365);
        _i_53858 = _27365;
L1: 
        if (binary_op_a(GREATER, _i_53858, _27366)){
            goto L2; // [32] 65
        }

        /** emit.e:1909			if cg_stack[i] < 0 then*/
        _2 = (object)SEQ_PTR(_47cg_stack_51375);
        if (!IS_ATOM_INT(_i_53858)){
            _27367 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_53858)->dbl));
        }
        else{
            _27367 = (object)*(((s1_ptr)_2)->base + _i_53858);
        }
        if (binary_op_a(GREATEREQ, _27367, 0LL)){
            _27367 = NOVALUE;
            goto L3; // [47] 58
        }
        _27367 = NOVALUE;

        /** emit.e:1910				return 1*/
        DeRef(_i_53858);
        DeRef(_27365);
        _27365 = NOVALUE;
        return 1LL;
L3: 

        /** emit.e:1912		end for*/
        _0 = _i_53858;
        if (IS_ATOM_INT(_i_53858)) {
            _i_53858 = _i_53858 + 1LL;
            if ((object)((uintptr_t)_i_53858 +(uintptr_t) HIGH_BITS) >= 0){
                _i_53858 = NewDouble((eudouble)_i_53858);
            }
        }
        else {
            _i_53858 = binary_op_a(PLUS, _i_53858, 1LL);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_53858);
    }

    /** emit.e:1913		return 0*/
    DeRef(_27365);
    _27365 = NOVALUE;
    return 0LL;
    ;
}



// 0x531E95C0
