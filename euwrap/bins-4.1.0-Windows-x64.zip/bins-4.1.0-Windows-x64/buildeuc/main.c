// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _68GetSourceName()
{
    object _real_name_67268 = NOVALUE;
    object _fh_67269 = NOVALUE;
    object _has_extension_67271 = NOVALUE;
    object _33231 = NOVALUE;
    object _33229 = NOVALUE;
    object _33228 = NOVALUE;
    object _33225 = NOVALUE;
    object _33224 = NOVALUE;
    object _33223 = NOVALUE;
    object _33222 = NOVALUE;
    object _33221 = NOVALUE;
    object _33220 = NOVALUE;
    object _33217 = NOVALUE;
    object _33216 = NOVALUE;
    object _33214 = NOVALUE;
    object _33213 = NOVALUE;
    object _33212 = NOVALUE;
    object _33211 = NOVALUE;
    object _33210 = NOVALUE;
    object _33209 = NOVALUE;
    object _33206 = NOVALUE;
    object _33205 = NOVALUE;
    object _33202 = NOVALUE;
    object _33201 = NOVALUE;
    object _33198 = NOVALUE;
    object _33197 = NOVALUE;
    object _33194 = NOVALUE;
    object _33193 = NOVALUE;
    object _33192 = NOVALUE;
    object _33190 = NOVALUE;
    object _33189 = NOVALUE;
    object _33188 = NOVALUE;
    object _33186 = NOVALUE;
    object _33185 = NOVALUE;
    object _33184 = NOVALUE;
    object _33183 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:48		boolean has_extension = FALSE*/
    _has_extension_67271 = _13FALSE_445;

    /** main.e:50		if length(src_name) = 0 and not repl then*/
    if (IS_SEQUENCE(_49src_name_49947)){
            _33183 = SEQ_PTR(_49src_name_49947)->length;
    }
    else {
        _33183 = 1;
    }
    _33184 = (_33183 == 0LL);
    _33183 = NOVALUE;
    if (_33184 == 0) {
        goto L1; // [19] 45
    }
    _33186 = (0LL == 0);
    if (_33186 == 0)
    {
        DeRef(_33186);
        _33186 = NOVALUE;
        goto L1; // [29] 45
    }
    else{
        DeRef(_33186);
        _33186 = NOVALUE;
    }

    /** main.e:51			show_banner()*/
    _49show_banner();

    /** main.e:52			return -2 -- No source file*/
    DeRef(_real_name_67268);
    DeRef(_33184);
    _33184 = NOVALUE;
    return -2LL;
    goto L2; // [42] 143
L1: 

    /** main.e:53		elsif length(src_name) = 0 and repl then*/
    if (IS_SEQUENCE(_49src_name_49947)){
            _33188 = SEQ_PTR(_49src_name_49947)->length;
    }
    else {
        _33188 = 1;
    }
    _33189 = (_33188 == 0LL);
    _33188 = NOVALUE;
    if (_33189 == 0) {
        goto L3; // [56] 142
    }
    goto L3; // [63] 142

    /** main.e:54			known_files = append(known_files, "")*/
    RefDS(_22186);
    Append(&_37known_files_15638, _37known_files_15638, _22186);

    /** main.e:55			known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33192 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33192 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33193 = (object)*(((s1_ptr)_2)->base + _33192);
    _33194 = calc_hash(_33193, -5LL);
    _33193 = NOVALUE;
    Ref(_33194);
    Append(&_37known_files_hash_15639, _37known_files_hash_15639, _33194);
    DeRef(_33194);
    _33194 = NOVALUE;

    /** main.e:56			real_name = ""*/
    RefDS(_22186);
    DeRef(_real_name_67268);
    _real_name_67268 = _22186;

    /** main.e:57			finished_files &= 0*/
    Append(&_37finished_files_15640, _37finished_files_15640, 0LL);

    /** main.e:58			file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33197 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33197 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _33197;
    _33198 = MAKE_SEQ(_1);
    _33197 = NOVALUE;
    RefDS(_33198);
    Append(&_37file_include_depend_15641, _37file_include_depend_15641, _33198);
    DeRefDS(_33198);
    _33198 = NOVALUE;

    /** main.e:59			return repl_file*/
    DeRefDS(_real_name_67268);
    DeRef(_33184);
    _33184 = NOVALUE;
    DeRef(_33189);
    _33189 = NOVALUE;
    return 5555LL;
L3: 
L2: 

    /** main.e:62		ifdef WINDOWS then*/

    /** main.e:63			src_name = match_replace("/", src_name, "\\")*/
    RefDS(_23762);
    RefDS(_49src_name_49947);
    RefDS(_23885);
    _0 = _16match_replace(_23762, _49src_name_49947, _23885, 0LL);
    DeRefDS(_49src_name_49947);
    _49src_name_49947 = _0;

    /** main.e:66		for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_49src_name_49947)){
            _33201 = SEQ_PTR(_49src_name_49947)->length;
    }
    else {
        _33201 = 1;
    }
    {
        object _p_67311;
        _p_67311 = _33201;
L4: 
        if (_p_67311 < 1LL){
            goto L5; // [165] 229
        }

        /** main.e:67			if src_name[p] = '.' then*/
        _2 = (object)SEQ_PTR(_49src_name_49947);
        _33202 = (object)*(((s1_ptr)_2)->base + _p_67311);
        if (binary_op_a(NOTEQ, _33202, 46LL)){
            _33202 = NOVALUE;
            goto L6; // [180] 198
        }
        _33202 = NOVALUE;

        /** main.e:68			   has_extension = TRUE*/
        _has_extension_67271 = _13TRUE_447;

        /** main.e:69			   exit*/
        goto L5; // [193] 229
        goto L7; // [195] 222
L6: 

        /** main.e:70			elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_49src_name_49947);
        _33205 = (object)*(((s1_ptr)_2)->base + _p_67311);
        _33206 = find_from(_33205, _46SLASH_CHARS_21927, 1LL);
        _33205 = NOVALUE;
        if (_33206 == 0)
        {
            _33206 = NOVALUE;
            goto L8; // [213] 221
        }
        else{
            _33206 = NOVALUE;
        }

        /** main.e:71			   exit*/
        goto L5; // [218] 229
L8: 
L7: 

        /** main.e:73		end for*/
        _p_67311 = _p_67311 + -1LL;
        goto L4; // [224] 172
L5: 
        ;
    }

    /** main.e:75		if not has_extension then*/
    if (_has_extension_67271 != 0)
    goto L9; // [231] 336

    /** main.e:79			known_files = append(known_files, "")*/
    RefDS(_22186);
    Append(&_37known_files_15638, _37known_files_15638, _22186);

    /** main.e:82			for i = 1 to length( DEFAULT_EXTS ) do*/
    _33209 = 4;
    {
        object _i_67331;
        _i_67331 = 1LL;
LA: 
        if (_i_67331 > 4LL){
            goto LB; // [251] 316
        }

        /** main.e:83				known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_37known_files_15638)){
                _33210 = SEQ_PTR(_37known_files_15638)->length;
        }
        else {
            _33210 = 1;
        }
        _2 = (object)SEQ_PTR(_46DEFAULT_EXTS_21901);
        _33211 = (object)*(((s1_ptr)_2)->base + _i_67331);
        Concat((object_ptr)&_33212, _49src_name_49947, _33211);
        _33211 = NOVALUE;
        _2 = (object)SEQ_PTR(_37known_files_15638);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37known_files_15638 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _33210);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _33212;
        if( _1 != _33212 ){
            DeRef(_1);
        }
        _33212 = NOVALUE;

        /** main.e:84				real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_37known_files_15638)){
                _33213 = SEQ_PTR(_37known_files_15638)->length;
        }
        else {
            _33213 = 1;
        }
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _33214 = (object)*(((s1_ptr)_2)->base + _33213);
        Ref(_33214);
        _0 = _real_name_67268;
        _real_name_67268 = _48e_path_find(_33214);
        DeRef(_0);
        _33214 = NOVALUE;

        /** main.e:85				if sequence(real_name) then*/
        _33216 = IS_SEQUENCE(_real_name_67268);
        if (_33216 == 0)
        {
            _33216 = NOVALUE;
            goto LC; // [301] 309
        }
        else{
            _33216 = NOVALUE;
        }

        /** main.e:86					exit*/
        goto LB; // [306] 316
LC: 

        /** main.e:88			end for*/
        _i_67331 = _i_67331 + 1LL;
        goto LA; // [311] 258
LB: 
        ;
    }

    /** main.e:90			if atom(real_name) then*/
    _33217 = IS_ATOM(_real_name_67268);
    if (_33217 == 0)
    {
        _33217 = NOVALUE;
        goto LD; // [323] 372
    }
    else{
        _33217 = NOVALUE;
    }

    /** main.e:91				return -1*/
    DeRef(_real_name_67268);
    DeRef(_33184);
    _33184 = NOVALUE;
    DeRef(_33189);
    _33189 = NOVALUE;
    return -1LL;
    goto LD; // [333] 372
L9: 

    /** main.e:94			known_files = append(known_files, src_name)*/
    RefDS(_49src_name_49947);
    Append(&_37known_files_15638, _37known_files_15638, _49src_name_49947);

    /** main.e:95			real_name = e_path_find(src_name)*/
    RefDS(_49src_name_49947);
    _0 = _real_name_67268;
    _real_name_67268 = _48e_path_find(_49src_name_49947);
    DeRef(_0);

    /** main.e:96			if atom(real_name) then*/
    _33220 = IS_ATOM(_real_name_67268);
    if (_33220 == 0)
    {
        _33220 = NOVALUE;
        goto LE; // [361] 371
    }
    else{
        _33220 = NOVALUE;
    }

    /** main.e:97				return -1*/
    DeRef(_real_name_67268);
    DeRef(_33184);
    _33184 = NOVALUE;
    DeRef(_33189);
    _33189 = NOVALUE;
    return -1LL;
LE: 
LD: 

    /** main.e:100		known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33221 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33221 = 1;
    }
    Ref(_real_name_67268);
    _33222 = _17canonical_path(_real_name_67268, 0LL, 2LL);
    _2 = (object)SEQ_PTR(_37known_files_15638);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37known_files_15638 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _33221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _33222;
    if( _1 != _33222 ){
        DeRef(_1);
    }
    _33222 = NOVALUE;

    /** main.e:101		known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33223 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33223 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33224 = (object)*(((s1_ptr)_2)->base + _33223);
    _33225 = calc_hash(_33224, -5LL);
    _33224 = NOVALUE;
    Ref(_33225);
    Append(&_37known_files_hash_15639, _37known_files_hash_15639, _33225);
    DeRef(_33225);
    _33225 = NOVALUE;

    /** main.e:102		finished_files &= 0*/
    Append(&_37finished_files_15640, _37finished_files_15640, 0LL);

    /** main.e:103		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33228 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33228 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _33228;
    _33229 = MAKE_SEQ(_1);
    _33228 = NOVALUE;
    RefDS(_33229);
    Append(&_37file_include_depend_15641, _37file_include_depend_15641, _33229);
    DeRefDS(_33229);
    _33229 = NOVALUE;

    /** main.e:105		if file_exists(real_name) then*/
    Ref(_real_name_67268);
    _33231 = _17file_exists(_real_name_67268);
    if (_33231 == 0) {
        DeRef(_33231);
        _33231 = NOVALUE;
        goto LF; // [451] 475
    }
    else {
        if (!IS_ATOM_INT(_33231) && DBL_PTR(_33231)->dbl == 0.0){
            DeRef(_33231);
            _33231 = NOVALUE;
            goto LF; // [451] 475
        }
        DeRef(_33231);
        _33231 = NOVALUE;
    }
    DeRef(_33231);
    _33231 = NOVALUE;

    /** main.e:106			real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_67268);
    _0 = _real_name_67268;
    _real_name_67268 = _64maybe_preprocess(_real_name_67268);
    DeRef(_0);

    /** main.e:107			fh = open_locked(real_name)*/
    Ref(_real_name_67268);
    _fh_67269 = _37open_locked(_real_name_67268);
    if (!IS_ATOM_INT(_fh_67269)) {
        _1 = (object)(DBL_PTR(_fh_67269)->dbl);
        DeRefDS(_fh_67269);
        _fh_67269 = _1;
    }

    /** main.e:108			return fh*/
    DeRef(_real_name_67268);
    DeRef(_33184);
    _33184 = NOVALUE;
    DeRef(_33189);
    _33189 = NOVALUE;
    return _fh_67269;
LF: 

    /** main.e:111		return -1*/
    DeRef(_real_name_67268);
    DeRef(_33184);
    _33184 = NOVALUE;
    DeRef(_33189);
    _33189 = NOVALUE;
    return -1LL;
    ;
}


void _68main()
{
    object _argc_67400 = NOVALUE;
    object _argv_67401 = NOVALUE;
    object _33271 = NOVALUE;
    object _33270 = NOVALUE;
    object _33269 = NOVALUE;
    object _33268 = NOVALUE;
    object _33267 = NOVALUE;
    object _33266 = NOVALUE;
    object _33265 = NOVALUE;
    object _33264 = NOVALUE;
    object _33263 = NOVALUE;
    object _33262 = NOVALUE;
    object _33261 = NOVALUE;
    object _33258 = NOVALUE;
    object _33256 = NOVALUE;
    object _33254 = NOVALUE;
    object _33253 = NOVALUE;
    object _33252 = NOVALUE;
    object _33251 = NOVALUE;
    object _33250 = NOVALUE;
    object _33249 = NOVALUE;
    object _33248 = NOVALUE;
    object _33247 = NOVALUE;
    object _33243 = NOVALUE;
    object _0, _1, _2;
    

    /** main.e:131		argv = command_line()*/
    DeRef(_argv_67401);
    _argv_67401 = Command_Line();

    /** main.e:133		if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** main.e:134			argv = extract_options(argv)*/
    RefDS(_argv_67401);
    _0 = _argv_67401;
    _argv_67401 = _2extract_options(_argv_67401);
    DeRefDS(_0);
L1: 

    /** main.e:137		argc = length(argv)*/
    if (IS_SEQUENCE(_argv_67401)){
            _argc_67400 = SEQ_PTR(_argv_67401)->length;
    }
    else {
        _argc_67400 = 1;
    }

    /** main.e:139		Argv = argv*/
    RefDS(_argv_67401);
    DeRef(_36Argv_21770);
    _36Argv_21770 = _argv_67401;

    /** main.e:140		Argc = argc*/
    _36Argc_21769 = _argc_67400;

    /** main.e:142		TempErrName = "ex.err"*/
    RefDS(_33242);
    DeRefi(_50TempErrName_49588);
    _50TempErrName_49588 = _33242;

    /** main.e:143		TempWarningName = STDERR*/
    DeRef(_36TempWarningName_21773);
    _36TempWarningName_21773 = 2LL;

    /** main.e:144		display_warnings = 1*/
    _50display_warnings_49589 = 1LL;

    /** main.e:146		InitGlobals()*/
    _45InitGlobals();

    /** main.e:148		if TRANSLATE or BIND or INTERPRET then*/
    if (_36TRANSLATE_21361 != 0) {
        _33243 = 1;
        goto L2; // [69] 79
    }
    _33243 = (_36BIND_21364 != 0);
L2: 
    if (_33243 != 0) {
        goto L3; // [79] 90
    }
    if (_36INTERPRET_21358 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** main.e:149			InitBackEnd(0)*/
    _2InitBackEnd(0LL);
L4: 

    /** main.e:152		src_file = GetSourceName()*/
    _0 = _68GetSourceName();
    _36src_file_21884 = _0;
    if (!IS_ATOM_INT(_36src_file_21884)) {
        _1 = (object)(DBL_PTR(_36src_file_21884)->dbl);
        DeRefDS(_36src_file_21884);
        _36src_file_21884 = _1;
    }

    /** main.e:154		if src_file = -1 then*/
    if (_36src_file_21884 != -1LL)
    goto L5; // [107] 185

    /** main.e:156			screen_output(STDERR, GetMsgText(CANT_OPEN_1, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33247 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33247 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33248 = (object)*(((s1_ptr)_2)->base + _33247);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_33248);
    ((intptr_t*)_2)[1] = _33248;
    _33249 = MAKE_SEQ(_1);
    _33248 = NOVALUE;
    _33250 = _39GetMsgText(51LL, 0LL, _33249);
    _33249 = NOVALUE;
    _50screen_output(2LL, _33250);
    _33250 = NOVALUE;

    /** main.e:157			if not batch_job and not test_only then*/
    _33251 = (_36batch_job_21772 == 0);
    if (_33251 == 0) {
        goto L6; // [147] 177
    }
    _33253 = (_36test_only_21771 == 0);
    if (_33253 == 0)
    {
        DeRef(_33253);
        _33253 = NOVALUE;
        goto L6; // [157] 177
    }
    else{
        DeRef(_33253);
        _33253 = NOVALUE;
    }

    /** main.e:158				maybe_any_key(GetMsgText(PAUSED_PRESS_ANY_KEY,0), STDERR)*/
    RefDS(_22186);
    _33254 = _39GetMsgText(277LL, 0LL, _22186);
    _5maybe_any_key(_33254, 2LL);
    _33254 = NOVALUE;
L6: 

    /** main.e:160			Cleanup(1)*/
    _50Cleanup(1LL);
    goto L7; // [182] 230
L5: 

    /** main.e:162		elsif src_file >= 0 then*/
    if (_36src_file_21884 < 0LL)
    goto L8; // [189] 229

    /** main.e:163			main_path = known_files[$]*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33256 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33256 = 1;
    }
    DeRef(_36main_path_21883);
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _36main_path_21883 = (object)*(((s1_ptr)_2)->base + _33256);
    Ref(_36main_path_21883);

    /** main.e:164			if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_36main_path_21883)){
            _33258 = SEQ_PTR(_36main_path_21883)->length;
    }
    else {
        _33258 = 1;
    }
    if (_33258 != 0LL)
    goto L9; // [213] 228

    /** main.e:165				main_path = '.' & SLASH*/
    Concat((object_ptr)&_36main_path_21883, 46LL, 92LL);
L9: 
L8: 
L7: 

    /** main.e:171		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto LA; // [234] 243
    }
    else{
    }

    /** main.e:172			InitBackEnd(1)*/
    _2InitBackEnd(1LL);
LA: 

    /** main.e:175		CheckPlatform()*/
    _2CheckPlatform();

    /** main.e:177		InitSymTab()*/
    _54InitSymTab();

    /** main.e:178		InitEmit()*/
    _47InitEmit();

    /** main.e:179		InitLex()*/
    _62InitLex();

    /** main.e:180		InitParser()*/
    _45InitParser();

    /** main.e:184		eu_namespace()*/
    _62eu_namespace();

    /** main.e:186		ifdef TRANSLATOR then*/

    /** main.e:187			if keep and build_system_type = BUILD_DIRECT then*/
    if (_58keep_42896 == 0) {
        goto LB; // [273] 342
    }
    _33262 = (_56build_system_type_45701 == 3LL);
    if (_33262 == 0)
    {
        DeRef(_33262);
        _33262 = NOVALUE;
        goto LB; // [286] 342
    }
    else{
        DeRef(_33262);
        _33262 = NOVALUE;
    }

    /** main.e:188				if 0 and not quick_has_changed(known_files[$]) then*/
    if (0LL == 0) {
        goto LC; // [291] 341
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _33264 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33264 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33265 = (object)*(((s1_ptr)_2)->base + _33264);
    Ref(_33265);
    _33266 = _56quick_has_changed(_33265);
    _33265 = NOVALUE;
    if (IS_ATOM_INT(_33266)) {
        _33267 = (_33266 == 0);
    }
    else {
        _33267 = unary_op(NOT, _33266);
    }
    DeRef(_33266);
    _33266 = NOVALUE;
    if (_33267 == 0) {
        DeRef(_33267);
        _33267 = NOVALUE;
        goto LC; // [312] 341
    }
    else {
        if (!IS_ATOM_INT(_33267) && DBL_PTR(_33267)->dbl == 0.0){
            DeRef(_33267);
            _33267 = NOVALUE;
            goto LC; // [312] 341
        }
        DeRef(_33267);
        _33267 = NOVALUE;
    }
    DeRef(_33267);
    _33267 = NOVALUE;

    /** main.e:189					build_direct(1, known_files[$])*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _33268 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _33268 = 1;
    }
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _33269 = (object)*(((s1_ptr)_2)->base + _33268);
    Ref(_33269);
    _56build_direct(1LL, _33269);
    _33269 = NOVALUE;

    /** main.e:190					Cleanup(0)*/
    _50Cleanup(0LL);

    /** main.e:191					return*/
    DeRef(_argv_67401);
    DeRef(_33251);
    _33251 = NOVALUE;
    return;
LC: 
LB: 

    /** main.e:197		main_file()*/
    _62main_file();

    /** main.e:199		check_coverage()*/
    _51check_coverage();

    /** main.e:201		parser()*/
    _45parser();

    /** main.e:203		init_coverage()*/
    _51init_coverage();

    /** main.e:206		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto LD; // [362] 373
    }
    else{
    }

    /** main.e:207			BackEnd(0) -- translate IL to C*/
    _2BackEnd(0LL);
    goto LE; // [370] 460
LD: 

    /** main.e:209		elsif BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto LF; // [377] 387
    }
    else{
    }

    /** main.e:210			OutputIL()*/
    _2OutputIL();
    goto LE; // [384] 460
LF: 

    /** main.e:212		elsif INTERPRET and not test_only then*/
    if (_36INTERPRET_21358 == 0) {
        goto L10; // [391] 459
    }
    _33271 = (_36test_only_21771 == 0);
    if (_33271 == 0)
    {
        DeRef(_33271);
        _33271 = NOVALUE;
        goto L10; // [401] 459
    }
    else{
        DeRef(_33271);
        _33271 = NOVALUE;
    }

    /** main.e:213			ifdef not STDDEBUG then*/

    /** main.e:214				BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0LL);

    /** main.e:216			while repl do*/
L10: 
LE: 

    /** main.e:225		Cleanup(0) -- does warnings*/
    _50Cleanup(0LL);

    /** main.e:226	end procedure*/
    DeRef(_argv_67401);
    DeRef(_33251);
    _33251 = NOVALUE;
    return;
    ;
}



// 0x9C6C8056
