// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _39GetMsgText(object _MsgNum_21305, object _WithNum_21306, object _Args_21307)
{
    object _idx_21308 = NOVALUE;
    object _msgtext_21309 = NOVALUE;
    object _12148 = NOVALUE;
    object _12147 = NOVALUE;
    object _12143 = NOVALUE;
    object _12142 = NOVALUE;
    object _12140 = NOVALUE;
    object _12137 = NOVALUE;
    object _12135 = NOVALUE;
    object _12134 = NOVALUE;
    object _12133 = NOVALUE;
    object _12132 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:757		integer idx = 1*/
    _idx_21308 = 1LL;

    /** msgtext.e:761		msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    Ref(_MsgNum_21305);
    RefDS(_37LocalizeQual_15656);
    RefDS(_37LocalDB_15657);
    _0 = _msgtext_21309;
    _msgtext_21309 = _40get_text(_MsgNum_21305, _37LocalizeQual_15656, _37LocalDB_15657);
    DeRef(_0);

    /** msgtext.e:764		if atom(msgtext) then*/
    _12132 = IS_ATOM(_msgtext_21309);
    if (_12132 == 0)
    {
        _12132 = NOVALUE;
        goto L1; // [25] 100
    }
    else{
        _12132 = NOVALUE;
    }

    /** msgtext.e:765			for i = 1 to length(StdErrMsgs) do*/
    _12133 = 365;
    {
        object _i_21317;
        _i_21317 = 1LL;
L2: 
        if (_i_21317 > 365LL){
            goto L3; // [35] 75
        }

        /** msgtext.e:766				if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (object)SEQ_PTR(_39StdErrMsgs_20576);
        _12134 = (object)*(((s1_ptr)_2)->base + _i_21317);
        _2 = (object)SEQ_PTR(_12134);
        _12135 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12134 = NOVALUE;
        if (binary_op_a(NOTEQ, _12135, _MsgNum_21305)){
            _12135 = NOVALUE;
            goto L4; // [54] 68
        }
        _12135 = NOVALUE;

        /** msgtext.e:767					idx = i*/
        _idx_21308 = _i_21317;

        /** msgtext.e:768					exit*/
        goto L3; // [65] 75
L4: 

        /** msgtext.e:770			end for*/
        _i_21317 = _i_21317 + 1LL;
        goto L2; // [70] 42
L3: 
        ;
    }

    /** msgtext.e:771			msgtext = StdErrMsgs[idx][2]*/
    _2 = (object)SEQ_PTR(_39StdErrMsgs_20576);
    _12137 = (object)*(((s1_ptr)_2)->base + _idx_21308);
    DeRef(_msgtext_21309);
    _2 = (object)SEQ_PTR(_12137);
    _msgtext_21309 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_msgtext_21309);
    _12137 = NOVALUE;

    /** msgtext.e:772			if idx = 1 then*/
    if (_idx_21308 != 1LL)
    goto L5; // [89] 99

    /** msgtext.e:773				Args = MsgNum*/
    Ref(_MsgNum_21305);
    DeRef(_Args_21307);
    _Args_21307 = _MsgNum_21305;
L5: 
L1: 

    /** msgtext.e:777		if atom(Args) or length(Args) != 0 then*/
    _12140 = IS_ATOM(_Args_21307);
    if (_12140 != 0) {
        goto L6; // [105] 121
    }
    if (IS_SEQUENCE(_Args_21307)){
            _12142 = SEQ_PTR(_Args_21307)->length;
    }
    else {
        _12142 = 1;
    }
    _12143 = (_12142 != 0LL);
    _12142 = NOVALUE;
    if (_12143 == 0)
    {
        DeRef(_12143);
        _12143 = NOVALUE;
        goto L7; // [117] 129
    }
    else{
        DeRef(_12143);
        _12143 = NOVALUE;
    }
L6: 

    /** msgtext.e:778			msgtext = format(msgtext, Args)*/
    Ref(_msgtext_21309);
    Ref(_Args_21307);
    _0 = _msgtext_21309;
    _msgtext_21309 = _14format(_msgtext_21309, _Args_21307);
    DeRef(_0);
L7: 

    /** msgtext.e:781		if WithNum != 0 then*/
    if (_WithNum_21306 == 0LL)
    goto L8; // [131] 152

    /** msgtext.e:782			return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_21309);
    Ref(_MsgNum_21305);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _MsgNum_21305;
    ((intptr_t *)_2)[2] = _msgtext_21309;
    _12147 = MAKE_SEQ(_1);
    _12148 = EPrintf(-9999999, _12146, _12147);
    DeRefDS(_12147);
    _12147 = NOVALUE;
    DeRef(_MsgNum_21305);
    DeRef(_Args_21307);
    DeRef(_msgtext_21309);
    return _12148;
    goto L9; // [149] 159
L8: 

    /** msgtext.e:784			return msgtext*/
    DeRef(_MsgNum_21305);
    DeRef(_Args_21307);
    DeRef(_12148);
    _12148 = NOVALUE;
    return _msgtext_21309;
L9: 
    ;
}


void _39ShowMsg(object _Cons_21342, object _Msg_21343, object _Args_21344, object _NL_21345)
{
    object _12155 = NOVALUE;
    object _12154 = NOVALUE;
    object _12152 = NOVALUE;
    object _12150 = NOVALUE;
    object _12149 = NOVALUE;
    object _0, _1, _2;
    

    /** msgtext.e:790		if atom(Msg) then*/
    _12149 = 1;
    if (_12149 == 0)
    {
        _12149 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _12149 = NOVALUE;
    }

    /** msgtext.e:791			Msg = GetMsgText(floor(Msg), 0)*/
    _12150 = e_floor(_Msg_21343);
    RefDS(_5);
    _Msg_21343 = _39GetMsgText(_12150, 0LL, _5);
    _12150 = NOVALUE;
L1: 

    /** msgtext.e:794		if atom(Args) or length(Args) != 0 then*/
    _12152 = IS_ATOM(_Args_21344);
    if (_12152 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_21344)){
            _12154 = SEQ_PTR(_Args_21344)->length;
    }
    else {
        _12154 = 1;
    }
    _12155 = (_12154 != 0LL);
    _12154 = NOVALUE;
    if (_12155 == 0)
    {
        DeRef(_12155);
        _12155 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_12155);
        _12155 = NOVALUE;
    }
L2: 

    /** msgtext.e:795			Msg = format(Msg, Args)*/
    Ref(_Msg_21343);
    Ref(_Args_21344);
    _0 = _Msg_21343;
    _Msg_21343 = _14format(_Msg_21343, _Args_21344);
    DeRef(_0);
L3: 

    /** msgtext.e:798		puts(Cons, Msg)*/
    EPuts(_Cons_21342, _Msg_21343); // DJP 

    /** msgtext.e:800		if NL then*/
    if (_NL_21345 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** msgtext.e:801			puts(Cons, '\n')*/
    EPuts(_Cons_21342, 10LL); // DJP 
L4: 

    /** msgtext.e:804	end procedure*/
    DeRef(_Msg_21343);
    DeRef(_Args_21344);
    return;
    ;
}



// 0xA4BDDA4C
