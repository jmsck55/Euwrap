// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _17find_first_wildcard(object _name_6062, object _from_6063)
{
    object _asterisk_at_6064 = NOVALUE;
    object _question_at_6066 = NOVALUE;
    object _first_wildcard_at_6068 = NOVALUE;
    object _3168 = NOVALUE;
    object _3167 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:247		integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_6064 = find_from(42LL, _name_6062, 1LL);

    /** filesys.e:248		integer question_at = eu:find('?', name, from)*/
    _question_at_6066 = find_from(63LL, _name_6062, 1LL);

    /** filesys.e:249		integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_6068 = _asterisk_at_6064;

    /** filesys.e:250		if asterisk_at or question_at then*/
    if (_asterisk_at_6064 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_6066 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** filesys.e:253			if question_at and question_at < asterisk_at then*/
    if (_question_at_6066 == 0) {
        goto L3; // [37] 55
    }
    _3168 = (_question_at_6066 < _asterisk_at_6064);
    if (_3168 == 0)
    {
        DeRef(_3168);
        _3168 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3168);
        _3168 = NOVALUE;
    }

    /** filesys.e:254				first_wildcard_at = question_at*/
    _first_wildcard_at_6068 = _question_at_6066;
L3: 
L2: 

    /** filesys.e:257		return first_wildcard_at*/
    DeRefDS(_name_6062);
    return _first_wildcard_at_6068;
    ;
}


object _17dir(object _name_6076)
{
    object _3169 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    _3169 = machine(22LL, _name_6076);
    DeRefDS(_name_6076);
    return _3169;
    ;
}


object _17current_dir()
{
    object _3171 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    _3171 = machine(23LL, 0LL);
    return _3171;
    ;
}


object _17chdir(object _newdir_6084)
{
    object _3172 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _3172 = machine(63LL, _newdir_6084);
    DeRefDS(_newdir_6084);
    return _3172;
    ;
}


object _17create_directory(object _name_6178, object _mode_6179, object _mkparent_6181)
{
    object _pname_6182 = NOVALUE;
    object _ret_6183 = NOVALUE;
    object _pos_6184 = NOVALUE;
    object _3243 = NOVALUE;
    object _3240 = NOVALUE;
    object _3239 = NOVALUE;
    object _3238 = NOVALUE;
    object _3237 = NOVALUE;
    object _3234 = NOVALUE;
    object _3231 = NOVALUE;
    object _3230 = NOVALUE;
    object _3228 = NOVALUE;
    object _3227 = NOVALUE;
    object _3225 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:731		if length(name) = 0 then*/
    if (IS_SEQUENCE(_name_6178)){
            _3225 = SEQ_PTR(_name_6178)->length;
    }
    else {
        _3225 = 1;
    }
    if (_3225 != 0LL)
    goto L1; // [12] 23

    /** filesys.e:732			return 0 -- failed*/
    DeRefDS(_name_6178);
    DeRef(_pname_6182);
    DeRef(_ret_6183);
    return 0LL;
L1: 

    /** filesys.e:736		if name[$] = SLASH then*/
    if (IS_SEQUENCE(_name_6178)){
            _3227 = SEQ_PTR(_name_6178)->length;
    }
    else {
        _3227 = 1;
    }
    _2 = (object)SEQ_PTR(_name_6178);
    _3228 = (object)*(((s1_ptr)_2)->base + _3227);
    if (binary_op_a(NOTEQ, _3228, 92LL)){
        _3228 = NOVALUE;
        goto L2; // [32] 51
    }
    _3228 = NOVALUE;

    /** filesys.e:737			name = name[1 .. $-1]*/
    if (IS_SEQUENCE(_name_6178)){
            _3230 = SEQ_PTR(_name_6178)->length;
    }
    else {
        _3230 = 1;
    }
    _3231 = _3230 - 1LL;
    _3230 = NOVALUE;
    rhs_slice_target = (object_ptr)&_name_6178;
    RHS_Slice(_name_6178, 1LL, _3231);
L2: 

    /** filesys.e:740		if mkparent != 0 then*/
    if (_mkparent_6181 == 0LL)
    goto L3; // [53] 101

    /** filesys.e:741			pos = search:rfind(SLASH, name)*/
    if (IS_SEQUENCE(_name_6178)){
            _3234 = SEQ_PTR(_name_6178)->length;
    }
    else {
        _3234 = 1;
    }
    RefDS(_name_6178);
    _pos_6184 = _16rfind(92LL, _name_6178, _3234);
    _3234 = NOVALUE;
    if (!IS_ATOM_INT(_pos_6184)) {
        _1 = (object)(DBL_PTR(_pos_6184)->dbl);
        DeRefDS(_pos_6184);
        _pos_6184 = _1;
    }

    /** filesys.e:742			if pos != 0 then*/
    if (_pos_6184 == 0LL)
    goto L4; // [72] 100

    /** filesys.e:743				ret = create_directory(name[1.. pos-1], mode, mkparent)*/
    _3237 = _pos_6184 - 1LL;
    rhs_slice_target = (object_ptr)&_3238;
    RHS_Slice(_name_6178, 1LL, _3237);
    DeRef(_3239);
    _3239 = _mode_6179;
    DeRef(_3240);
    _3240 = _mkparent_6181;
    _0 = _ret_6183;
    _ret_6183 = _17create_directory(_3238, _3239, _3240);
    DeRef(_0);
    _3238 = NOVALUE;
    _3239 = NOVALUE;
    _3240 = NOVALUE;
L4: 
L3: 

    /** filesys.e:747		pname = machine:allocate_string(name)*/
    RefDS(_name_6178);
    _0 = _pname_6182;
    _pname_6182 = _9allocate_string(_name_6178, 0LL);
    DeRef(_0);

    /** filesys.e:749		ifdef UNIX then*/

    /** filesys.e:752			ret = c_func(xCreateDirectory, {pname, 0})*/
    Ref(_pname_6182);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pname_6182;
    ((intptr_t *)_2)[2] = 0LL;
    _3243 = MAKE_SEQ(_1);
    DeRef(_ret_6183);
    _ret_6183 = call_c(1, _17xCreateDirectory_6009, _3243);
    DeRefDS(_3243);
    _3243 = NOVALUE;

    /** filesys.e:753			mode = mode -- get rid of not used warning*/
    _mode_6179 = _mode_6179;

    /** filesys.e:756		return ret*/
    DeRefDS(_name_6178);
    DeRef(_pname_6182);
    DeRef(_3237);
    _3237 = NOVALUE;
    DeRef(_3231);
    _3231 = NOVALUE;
    return _ret_6183;
    ;
}


object _17delete_file(object _name_6220)
{
    object _pfilename_6221 = NOVALUE;
    object _success_6223 = NOVALUE;
    object _3249 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:802		atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_6220);
    _0 = _pfilename_6221;
    _pfilename_6221 = _9allocate_string(_name_6220, 0LL);
    DeRef(_0);

    /** filesys.e:803		integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pfilename_6221);
    ((intptr_t*)_2)[1] = _pfilename_6221;
    _3249 = MAKE_SEQ(_1);
    _success_6223 = call_c(1, _17xDeleteFile_6005, _3249);
    DeRefDS(_3249);
    _3249 = NOVALUE;
    if (!IS_ATOM_INT(_success_6223)) {
        _1 = (object)(DBL_PTR(_success_6223)->dbl);
        DeRefDS(_success_6223);
        _success_6223 = _1;
    }

    /** filesys.e:805		ifdef UNIX then*/

    /** filesys.e:809		machine:free(pfilename)*/
    Ref(_pfilename_6221);
    _9free(_pfilename_6221);

    /** filesys.e:811		return success*/
    DeRefDS(_name_6220);
    DeRef(_pfilename_6221);
    return _success_6223;
    ;
}


object _17curdir(object _drive_id_6228)
{
    object _lCurDir_6229 = NOVALUE;
    object _lOrigDir_6230 = NOVALUE;
    object _lDrive_6231 = NOVALUE;
    object _current_dir_inlined_current_dir_at_25_6236 = NOVALUE;
    object _chdir_inlined_chdir_at_55_6239 = NOVALUE;
    object _current_dir_inlined_current_dir_at_77_6242 = NOVALUE;
    object _chdir_inlined_chdir_at_109_6249 = NOVALUE;
    object _newdir_inlined_chdir_at_106_6248 = NOVALUE;
    object _3257 = NOVALUE;
    object _3256 = NOVALUE;
    object _3255 = NOVALUE;
    object _3253 = NOVALUE;
    object _3251 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_drive_id_6228)) {
        _1 = (object)(DBL_PTR(_drive_id_6228)->dbl);
        DeRefDS(_drive_id_6228);
        _drive_id_6228 = _1;
    }

    /** filesys.e:847		ifdef not LINUX then*/

    /** filesys.e:848		    sequence lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_6230);
    _lOrigDir_6230 = _5;

    /** filesys.e:849		    sequence lDrive*/

    /** filesys.e:851		    if t_alpha(drive_id) then*/
    _3251 = _13t_alpha(_drive_id_6228);
    if (_3251 == 0) {
        DeRef(_3251);
        _3251 = NOVALUE;
        goto L1; // [20] 75
    }
    else {
        if (!IS_ATOM_INT(_3251) && DBL_PTR(_3251)->dbl == 0.0){
            DeRef(_3251);
            _3251 = NOVALUE;
            goto L1; // [20] 75
        }
        DeRef(_3251);
        _3251 = NOVALUE;
    }
    DeRef(_3251);
    _3251 = NOVALUE;

    /** filesys.e:852			    lOrigDir =  current_dir()*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefDSi(_lOrigDir_6230);
    _lOrigDir_6230 = machine(23LL, 0LL);

    /** filesys.e:853			    lDrive = "  "*/
    RefDS(_150);
    DeRefi(_lDrive_6231);
    _lDrive_6231 = _150;

    /** filesys.e:854			    lDrive[1] = drive_id*/
    _2 = (object)SEQ_PTR(_lDrive_6231);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _lDrive_6231 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    *(intptr_t *)_2 = _drive_id_6228;

    /** filesys.e:855			    lDrive[2] = ':'*/
    _2 = (object)SEQ_PTR(_lDrive_6231);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _lDrive_6231 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    *(intptr_t *)_2 = 58LL;

    /** filesys.e:856			    if chdir(lDrive) = 0 then*/

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_55_6239 = machine(63LL, _lDrive_6231);
    if (_chdir_inlined_chdir_at_55_6239 != 0LL)
    goto L2; // [62] 74

    /** filesys.e:857			    	lOrigDir = ""*/
    RefDS(_5);
    DeRefi(_lOrigDir_6230);
    _lOrigDir_6230 = _5;
L2: 
L1: 

    /** filesys.e:862	    lCurDir = current_dir()*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_6229);
    _lCurDir_6229 = machine(23LL, 0LL);

    /** filesys.e:863		ifdef not LINUX then*/

    /** filesys.e:864			if length(lOrigDir) > 0 then*/
    if (IS_SEQUENCE(_lOrigDir_6230)){
            _3253 = SEQ_PTR(_lOrigDir_6230)->length;
    }
    else {
        _3253 = 1;
    }
    if (_3253 <= 0LL)
    goto L3; // [95] 121

    /** filesys.e:865		    	chdir(lOrigDir[1..2])*/
    rhs_slice_target = (object_ptr)&_3255;
    RHS_Slice(_lOrigDir_6230, 1LL, 2LL);
    DeRefi(_newdir_inlined_chdir_at_106_6248);
    _newdir_inlined_chdir_at_106_6248 = _3255;
    _3255 = NOVALUE;

    /** filesys.e:501		return machine_func(M_CHDIR, newdir)*/
    _chdir_inlined_chdir_at_109_6249 = machine(63LL, _newdir_inlined_chdir_at_106_6248);
    DeRefi(_newdir_inlined_chdir_at_106_6248);
    _newdir_inlined_chdir_at_106_6248 = NOVALUE;
L3: 

    /** filesys.e:870		if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_6229)){
            _3256 = SEQ_PTR(_lCurDir_6229)->length;
    }
    else {
        _3256 = 1;
    }
    _2 = (object)SEQ_PTR(_lCurDir_6229);
    _3257 = (object)*(((s1_ptr)_2)->base + _3256);
    if (_3257 == 92LL)
    goto L4; // [130] 141

    /** filesys.e:871			lCurDir &= SLASH*/
    Append(&_lCurDir_6229, _lCurDir_6229, 92LL);
L4: 

    /** filesys.e:874		return lCurDir*/
    DeRefi(_lOrigDir_6230);
    DeRefi(_lDrive_6231);
    _3257 = NOVALUE;
    return _lCurDir_6229;
    ;
}


object _17remove_directory(object _dir_name_6330, object _force_6331)
{
    object _pname_6332 = NOVALUE;
    object _ret_6333 = NOVALUE;
    object _files_6334 = NOVALUE;
    object _D_NAME_6335 = NOVALUE;
    object _D_ATTRIBUTES_6336 = NOVALUE;
    object _dir_inlined_dir_at_97_6357 = NOVALUE;
    object _3348 = NOVALUE;
    object _3344 = NOVALUE;
    object _3343 = NOVALUE;
    object _3342 = NOVALUE;
    object _3340 = NOVALUE;
    object _3339 = NOVALUE;
    object _3338 = NOVALUE;
    object _3337 = NOVALUE;
    object _3336 = NOVALUE;
    object _3335 = NOVALUE;
    object _3334 = NOVALUE;
    object _3333 = NOVALUE;
    object _3329 = NOVALUE;
    object _3327 = NOVALUE;
    object _3326 = NOVALUE;
    object _3325 = NOVALUE;
    object _3323 = NOVALUE;
    object _3322 = NOVALUE;
    object _3321 = NOVALUE;
    object _3319 = NOVALUE;
    object _3318 = NOVALUE;
    object _3316 = NOVALUE;
    object _3314 = NOVALUE;
    object _3312 = NOVALUE;
    object _3310 = NOVALUE;
    object _3309 = NOVALUE;
    object _3307 = NOVALUE;
    object _3306 = NOVALUE;
    object _3304 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1056		integer D_NAME = 1, D_ATTRIBUTES = 2*/
    _D_NAME_6335 = 1LL;
    _D_ATTRIBUTES_6336 = 2LL;

    /** filesys.e:1059	 	if length(dir_name) > 0 then*/
    if (IS_SEQUENCE(_dir_name_6330)){
            _3304 = SEQ_PTR(_dir_name_6330)->length;
    }
    else {
        _3304 = 1;
    }
    if (_3304 <= 0LL)
    goto L1; // [18] 51

    /** filesys.e:1060			if dir_name[$] = SLASH then*/
    if (IS_SEQUENCE(_dir_name_6330)){
            _3306 = SEQ_PTR(_dir_name_6330)->length;
    }
    else {
        _3306 = 1;
    }
    _2 = (object)SEQ_PTR(_dir_name_6330);
    _3307 = (object)*(((s1_ptr)_2)->base + _3306);
    if (binary_op_a(NOTEQ, _3307, 92LL)){
        _3307 = NOVALUE;
        goto L2; // [31] 50
    }
    _3307 = NOVALUE;

    /** filesys.e:1061				dir_name = dir_name[1 .. $-1]*/
    if (IS_SEQUENCE(_dir_name_6330)){
            _3309 = SEQ_PTR(_dir_name_6330)->length;
    }
    else {
        _3309 = 1;
    }
    _3310 = _3309 - 1LL;
    _3309 = NOVALUE;
    rhs_slice_target = (object_ptr)&_dir_name_6330;
    RHS_Slice(_dir_name_6330, 1LL, _3310);
L2: 
L1: 

    /** filesys.e:1065		if length(dir_name) = 0 then*/
    if (IS_SEQUENCE(_dir_name_6330)){
            _3312 = SEQ_PTR(_dir_name_6330)->length;
    }
    else {
        _3312 = 1;
    }
    if (_3312 != 0LL)
    goto L3; // [56] 67

    /** filesys.e:1066			return 0	-- nothing specified to delete.*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
L3: 

    /** filesys.e:1070		ifdef WINDOWS then*/

    /** filesys.e:1071			if length(dir_name) = 2 then*/
    if (IS_SEQUENCE(_dir_name_6330)){
            _3314 = SEQ_PTR(_dir_name_6330)->length;
    }
    else {
        _3314 = 1;
    }
    if (_3314 != 2LL)
    goto L4; // [74] 96

    /** filesys.e:1072				if dir_name[2] = ':' then*/
    _2 = (object)SEQ_PTR(_dir_name_6330);
    _3316 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _3316, 58LL)){
        _3316 = NOVALUE;
        goto L5; // [84] 95
    }
    _3316 = NOVALUE;

    /** filesys.e:1073					return 0 -- nothing specified to delete*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
L5: 
L4: 

    /** filesys.e:1078		files = dir(dir_name)*/

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    DeRef(_files_6334);
    _files_6334 = machine(22LL, _dir_name_6330);

    /** filesys.e:1079		if atom(files) then*/
    _3318 = IS_ATOM(_files_6334);
    if (_3318 == 0)
    {
        _3318 = NOVALUE;
        goto L6; // [112] 122
    }
    else{
        _3318 = NOVALUE;
    }

    /** filesys.e:1080			return 0*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
L6: 

    /** filesys.e:1082		if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_6334)){
            _3319 = SEQ_PTR(_files_6334)->length;
    }
    else {
        _3319 = 1;
    }
    if (_3319 >= 2LL)
    goto L7; // [127] 138

    /** filesys.e:1083			return 0	-- Supplied dir_name was not a directory*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
L7: 

    /** filesys.e:1085		ifdef WINDOWS then*/

    /** filesys.e:1087			if not equal(files[1][D_NAME], ".") then*/
    _2 = (object)SEQ_PTR(_files_6334);
    _3321 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3321);
    _3322 = (object)*(((s1_ptr)_2)->base + _D_NAME_6335);
    _3321 = NOVALUE;
    if (_3322 == _3170)
    _3323 = 1;
    else if (IS_ATOM_INT(_3322) && IS_ATOM_INT(_3170))
    _3323 = 0;
    else
    _3323 = (compare(_3322, _3170) == 0);
    _3322 = NOVALUE;
    if (_3323 != 0)
    goto L8; // [154] 164
    _3323 = NOVALUE;

    /** filesys.e:1088				return 0 -- Supplied name was not a directory*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
L8: 

    /** filesys.e:1090			if not eu:find('d', files[1][D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_files_6334);
    _3325 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3325);
    _3326 = (object)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_6336);
    _3325 = NOVALUE;
    _3327 = find_from(100LL, _3326, 1LL);
    _3326 = NOVALUE;
    if (_3327 != 0)
    goto L9; // [179] 189
    _3327 = NOVALUE;

    /** filesys.e:1091				return 0 -- Supplied name was not a directory*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
L9: 

    /** filesys.e:1093			if length(files) > 2 then*/
    if (IS_SEQUENCE(_files_6334)){
            _3329 = SEQ_PTR(_files_6334)->length;
    }
    else {
        _3329 = 1;
    }
    if (_3329 <= 2LL)
    goto LA; // [194] 211

    /** filesys.e:1094				if not force then*/
    if (_force_6331 != 0)
    goto LB; // [200] 210

    /** filesys.e:1095					return 0 -- Directory is not already emptied.*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_ret_6333);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return 0LL;
LB: 
LA: 

    /** filesys.e:1100		dir_name &= SLASH*/
    Append(&_dir_name_6330, _dir_name_6330, 92LL);

    /** filesys.e:1101		ifdef WINDOWS then*/

    /** filesys.e:1102			for i = 3 to length(files) do*/
    if (IS_SEQUENCE(_files_6334)){
            _3333 = SEQ_PTR(_files_6334)->length;
    }
    else {
        _3333 = 1;
    }
    {
        object _i_6380;
        _i_6380 = 3LL;
LC: 
        if (_i_6380 > _3333){
            goto LD; // [224] 316
        }

        /** filesys.e:1103				if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (object)SEQ_PTR(_files_6334);
        _3334 = (object)*(((s1_ptr)_2)->base + _i_6380);
        _2 = (object)SEQ_PTR(_3334);
        _3335 = (object)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_6336);
        _3334 = NOVALUE;
        _3336 = find_from(100LL, _3335, 1LL);
        _3335 = NOVALUE;
        if (_3336 == 0)
        {
            _3336 = NOVALUE;
            goto LE; // [246] 276
        }
        else{
            _3336 = NOVALUE;
        }

        /** filesys.e:1104					ret = remove_directory(dir_name & files[i][D_NAME] & SLASH, force)*/
        _2 = (object)SEQ_PTR(_files_6334);
        _3337 = (object)*(((s1_ptr)_2)->base + _i_6380);
        _2 = (object)SEQ_PTR(_3337);
        _3338 = (object)*(((s1_ptr)_2)->base + _D_NAME_6335);
        _3337 = NOVALUE;
        {
            object concat_list[3];

            concat_list[0] = 92LL;
            concat_list[1] = _3338;
            concat_list[2] = _dir_name_6330;
            Concat_N((object_ptr)&_3339, concat_list, 3);
        }
        _3338 = NOVALUE;
        DeRef(_3340);
        _3340 = _force_6331;
        _0 = _ret_6333;
        _ret_6333 = _17remove_directory(_3339, _3340);
        DeRef(_0);
        _3339 = NOVALUE;
        _3340 = NOVALUE;
        goto LF; // [273] 295
LE: 

        /** filesys.e:1107					ret = delete_file(dir_name & files[i][D_NAME])*/
        _2 = (object)SEQ_PTR(_files_6334);
        _3342 = (object)*(((s1_ptr)_2)->base + _i_6380);
        _2 = (object)SEQ_PTR(_3342);
        _3343 = (object)*(((s1_ptr)_2)->base + _D_NAME_6335);
        _3342 = NOVALUE;
        if (IS_SEQUENCE(_dir_name_6330) && IS_ATOM(_3343)) {
            Ref(_3343);
            Append(&_3344, _dir_name_6330, _3343);
        }
        else if (IS_ATOM(_dir_name_6330) && IS_SEQUENCE(_3343)) {
        }
        else {
            Concat((object_ptr)&_3344, _dir_name_6330, _3343);
        }
        _3343 = NOVALUE;
        _0 = _ret_6333;
        _ret_6333 = _17delete_file(_3344);
        DeRef(_0);
        _3344 = NOVALUE;
LF: 

        /** filesys.e:1109				if not ret then*/
        if (IS_ATOM_INT(_ret_6333)) {
            if (_ret_6333 != 0){
                goto L10; // [299] 309
            }
        }
        else {
            if (DBL_PTR(_ret_6333)->dbl != 0.0){
                goto L10; // [299] 309
            }
        }

        /** filesys.e:1110					return 0*/
        DeRefDS(_dir_name_6330);
        DeRef(_pname_6332);
        DeRef(_ret_6333);
        DeRef(_files_6334);
        DeRef(_3310);
        _3310 = NOVALUE;
        return 0LL;
L10: 

        /** filesys.e:1113			end for*/
        _i_6380 = _i_6380 + 1LL;
        goto LC; // [311] 231
LD: 
        ;
    }

    /** filesys.e:1129		pname = machine:allocate_string(dir_name)*/
    RefDS(_dir_name_6330);
    _0 = _pname_6332;
    _pname_6332 = _9allocate_string(_dir_name_6330, 0LL);
    DeRef(_0);

    /** filesys.e:1130		ret = c_func(xRemoveDirectory, {pname})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pname_6332);
    ((intptr_t*)_2)[1] = _pname_6332;
    _3348 = MAKE_SEQ(_1);
    DeRef(_ret_6333);
    _ret_6333 = call_c(1, _17xRemoveDirectory_6016, _3348);
    DeRefDS(_3348);
    _3348 = NOVALUE;

    /** filesys.e:1131		ifdef UNIX then*/

    /** filesys.e:1134		machine:free(pname)*/
    Ref(_pname_6332);
    _9free(_pname_6332);

    /** filesys.e:1135		return ret*/
    DeRefDS(_dir_name_6330);
    DeRef(_pname_6332);
    DeRef(_files_6334);
    DeRef(_3310);
    _3310 = NOVALUE;
    return _ret_6333;
    ;
}


object _17pathinfo(object _path_6408, object _std_slash_6409)
{
    object _slash_6410 = NOVALUE;
    object _period_6411 = NOVALUE;
    object _ch_6412 = NOVALUE;
    object _dir_name_6413 = NOVALUE;
    object _file_name_6414 = NOVALUE;
    object _file_ext_6415 = NOVALUE;
    object _file_full_6416 = NOVALUE;
    object _drive_id_6417 = NOVALUE;
    object _from_slash_6457 = NOVALUE;
    object _3382 = NOVALUE;
    object _3375 = NOVALUE;
    object _3374 = NOVALUE;
    object _3371 = NOVALUE;
    object _3370 = NOVALUE;
    object _3368 = NOVALUE;
    object _3367 = NOVALUE;
    object _3364 = NOVALUE;
    object _3363 = NOVALUE;
    object _3361 = NOVALUE;
    object _3357 = NOVALUE;
    object _3355 = NOVALUE;
    object _3354 = NOVALUE;
    object _3353 = NOVALUE;
    object _3352 = NOVALUE;
    object _3350 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1196		dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_6413);
    _dir_name_6413 = _5;

    /** filesys.e:1197		file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_6414);
    _file_name_6414 = _5;

    /** filesys.e:1198		file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_6415);
    _file_ext_6415 = _5;

    /** filesys.e:1199		file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_6416);
    _file_full_6416 = _5;

    /** filesys.e:1200		drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_6417);
    _drive_id_6417 = _5;

    /** filesys.e:1202		slash = 0*/
    _slash_6410 = 0LL;

    /** filesys.e:1203		period = 0*/
    _period_6411 = 0LL;

    /** filesys.e:1205		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6408)){
            _3350 = SEQ_PTR(_path_6408)->length;
    }
    else {
        _3350 = 1;
    }
    {
        object _i_6419;
        _i_6419 = _3350;
L1: 
        if (_i_6419 < 1LL){
            goto L2; // [55] 122
        }

        /** filesys.e:1206			ch = path[i]*/
        _2 = (object)SEQ_PTR(_path_6408);
        _ch_6412 = (object)*(((s1_ptr)_2)->base + _i_6419);
        if (!IS_ATOM_INT(_ch_6412))
        _ch_6412 = (object)DBL_PTR(_ch_6412)->dbl;

        /** filesys.e:1207			if period = 0 and ch = '.' then*/
        _3352 = (_period_6411 == 0LL);
        if (_3352 == 0) {
            goto L3; // [74] 94
        }
        _3354 = (_ch_6412 == 46LL);
        if (_3354 == 0)
        {
            DeRef(_3354);
            _3354 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3354);
            _3354 = NOVALUE;
        }

        /** filesys.e:1208				period = i*/
        _period_6411 = _i_6419;
        goto L4; // [91] 115
L3: 

        /** filesys.e:1209			elsif eu:find(ch, SLASHES) then*/
        _3355 = find_from(_ch_6412, _17SLASHES_6035, 1LL);
        if (_3355 == 0)
        {
            _3355 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _3355 = NOVALUE;
        }

        /** filesys.e:1210				slash = i*/
        _slash_6410 = _i_6419;

        /** filesys.e:1211				exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** filesys.e:1213		end for*/
        _i_6419 = _i_6419 + -1LL;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** filesys.e:1215		if slash > 0 then*/
    if (_slash_6410 <= 0LL)
    goto L6; // [124] 181

    /** filesys.e:1216			dir_name = path[1..slash-1]*/
    _3357 = _slash_6410 - 1LL;
    rhs_slice_target = (object_ptr)&_dir_name_6413;
    RHS_Slice(_path_6408, 1LL, _3357);

    /** filesys.e:1218			ifdef not UNIX then*/

    /** filesys.e:1219				ch = eu:find(':', dir_name)*/
    _ch_6412 = find_from(58LL, _dir_name_6413, 1LL);

    /** filesys.e:1220				if ch != 0 then*/
    if (_ch_6412 == 0LL)
    goto L7; // [150] 180

    /** filesys.e:1221					drive_id = dir_name[1..ch-1]*/
    _3361 = _ch_6412 - 1LL;
    rhs_slice_target = (object_ptr)&_drive_id_6417;
    RHS_Slice(_dir_name_6413, 1LL, _3361);

    /** filesys.e:1222					dir_name = dir_name[ch+1..$]*/
    _3363 = _ch_6412 + 1;
    if (IS_SEQUENCE(_dir_name_6413)){
            _3364 = SEQ_PTR(_dir_name_6413)->length;
    }
    else {
        _3364 = 1;
    }
    rhs_slice_target = (object_ptr)&_dir_name_6413;
    RHS_Slice(_dir_name_6413, _3363, _3364);
L7: 
L6: 

    /** filesys.e:1226		if period > 0 then*/
    if (_period_6411 <= 0LL)
    goto L8; // [183] 227

    /** filesys.e:1227			file_name = path[slash+1..period-1]*/
    _3367 = _slash_6410 + 1;
    if (_3367 > MAXINT){
        _3367 = NewDouble((eudouble)_3367);
    }
    _3368 = _period_6411 - 1LL;
    rhs_slice_target = (object_ptr)&_file_name_6414;
    RHS_Slice(_path_6408, _3367, _3368);

    /** filesys.e:1228			file_ext = path[period+1..$]*/
    _3370 = _period_6411 + 1;
    if (_3370 > MAXINT){
        _3370 = NewDouble((eudouble)_3370);
    }
    if (IS_SEQUENCE(_path_6408)){
            _3371 = SEQ_PTR(_path_6408)->length;
    }
    else {
        _3371 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_6415;
    RHS_Slice(_path_6408, _3370, _3371);

    /** filesys.e:1229			file_full = file_name & '.' & file_ext*/
    {
        object concat_list[3];

        concat_list[0] = _file_ext_6415;
        concat_list[1] = 46LL;
        concat_list[2] = _file_name_6414;
        Concat_N((object_ptr)&_file_full_6416, concat_list, 3);
    }
    goto L9; // [224] 249
L8: 

    /** filesys.e:1231			file_name = path[slash+1..$]*/
    _3374 = _slash_6410 + 1;
    if (_3374 > MAXINT){
        _3374 = NewDouble((eudouble)_3374);
    }
    if (IS_SEQUENCE(_path_6408)){
            _3375 = SEQ_PTR(_path_6408)->length;
    }
    else {
        _3375 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_6414;
    RHS_Slice(_path_6408, _3374, _3375);

    /** filesys.e:1232			file_full = file_name*/
    RefDS(_file_name_6414);
    DeRef(_file_full_6416);
    _file_full_6416 = _file_name_6414;
L9: 

    /** filesys.e:1235		if std_slash != 0 then*/
    if (_std_slash_6409 == 0LL)
    goto LA; // [251] 317

    /** filesys.e:1236			if std_slash < 0 then*/
    if (_std_slash_6409 >= 0LL)
    goto LB; // [257] 293

    /** filesys.e:1237				std_slash = SLASH*/
    _std_slash_6409 = 92LL;

    /** filesys.e:1238				ifdef UNIX then*/

    /** filesys.e:1241				sequence from_slash = "/"*/
    RefDS(_3152);
    DeRefi(_from_slash_6457);
    _from_slash_6457 = _3152;

    /** filesys.e:1243				dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_6457);
    RefDS(_dir_name_6413);
    _0 = _dir_name_6413;
    _dir_name_6413 = _16match_replace(_from_slash_6457, _dir_name_6413, 92LL, 0LL);
    DeRefDS(_0);
    DeRefDSi(_from_slash_6457);
    _from_slash_6457 = NOVALUE;
    goto LC; // [290] 316
LB: 

    /** filesys.e:1245				dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_964);
    RefDS(_dir_name_6413);
    _0 = _dir_name_6413;
    _dir_name_6413 = _16match_replace(_964, _dir_name_6413, _std_slash_6409, 0LL);
    DeRefDS(_0);

    /** filesys.e:1246				dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3152);
    RefDS(_dir_name_6413);
    _0 = _dir_name_6413;
    _dir_name_6413 = _16match_replace(_3152, _dir_name_6413, _std_slash_6409, 0LL);
    DeRefDS(_0);
LC: 
LA: 

    /** filesys.e:1250		return {dir_name, file_full, file_name, file_ext, drive_id }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_dir_name_6413);
    ((intptr_t*)_2)[1] = _dir_name_6413;
    RefDS(_file_full_6416);
    ((intptr_t*)_2)[2] = _file_full_6416;
    RefDS(_file_name_6414);
    ((intptr_t*)_2)[3] = _file_name_6414;
    RefDS(_file_ext_6415);
    ((intptr_t*)_2)[4] = _file_ext_6415;
    RefDS(_drive_id_6417);
    ((intptr_t*)_2)[5] = _drive_id_6417;
    _3382 = MAKE_SEQ(_1);
    DeRefDS(_path_6408);
    DeRefDS(_dir_name_6413);
    DeRefDS(_file_name_6414);
    DeRefDS(_file_ext_6415);
    DeRefDS(_file_full_6416);
    DeRefDS(_drive_id_6417);
    DeRef(_3357);
    _3357 = NOVALUE;
    DeRef(_3367);
    _3367 = NOVALUE;
    DeRef(_3374);
    _3374 = NOVALUE;
    DeRef(_3363);
    _3363 = NOVALUE;
    DeRef(_3361);
    _3361 = NOVALUE;
    DeRef(_3370);
    _3370 = NOVALUE;
    DeRef(_3368);
    _3368 = NOVALUE;
    DeRef(_3352);
    _3352 = NOVALUE;
    return _3382;
    ;
}


object _17dirname(object _path_6465, object _pcd_6466)
{
    object _data_6467 = NOVALUE;
    object _3387 = NOVALUE;
    object _3385 = NOVALUE;
    object _3384 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1279		data = pathinfo(path)*/
    RefDS(_path_6465);
    _0 = _data_6467;
    _data_6467 = _17pathinfo(_path_6465, 0LL);
    DeRef(_0);

    /** filesys.e:1280		if pcd then*/
    if (_pcd_6466 == 0)
    {
        goto L1; // [16] 40
    }
    else{
    }

    /** filesys.e:1281			if length(data[1]) = 0 then*/
    _2 = (object)SEQ_PTR(_data_6467);
    _3384 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_3384)){
            _3385 = SEQ_PTR(_3384)->length;
    }
    else {
        _3385 = 1;
    }
    _3384 = NOVALUE;
    if (_3385 != 0LL)
    goto L2; // [28] 39

    /** filesys.e:1282				return "."*/
    RefDS(_3170);
    DeRefDS(_path_6465);
    DeRefDS(_data_6467);
    _3384 = NOVALUE;
    return _3170;
L2: 
L1: 

    /** filesys.e:1285		return data[1]*/
    _2 = (object)SEQ_PTR(_data_6467);
    _3387 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_3387);
    DeRefDS(_path_6465);
    DeRefDS(_data_6467);
    _3384 = NOVALUE;
    return _3387;
    ;
}


object _17filebase(object _path_6494)
{
    object _data_6495 = NOVALUE;
    object _3396 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1375		data = pathinfo(path)*/
    RefDS(_path_6494);
    _0 = _data_6495;
    _data_6495 = _17pathinfo(_path_6494, 0LL);
    DeRef(_0);

    /** filesys.e:1377		return data[3]*/
    _2 = (object)SEQ_PTR(_data_6495);
    _3396 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_3396);
    DeRefDS(_path_6494);
    DeRefDS(_data_6495);
    return _3396;
    ;
}


object _17fileext(object _path_6500)
{
    object _data_6501 = NOVALUE;
    object _3398 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1403		data = pathinfo(path)*/
    RefDS(_path_6500);
    _0 = _data_6501;
    _data_6501 = _17pathinfo(_path_6500, 0LL);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    _2 = (object)SEQ_PTR(_data_6501);
    _3398 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_3398);
    DeRefDS(_path_6500);
    DeRefDS(_data_6501);
    return _3398;
    ;
}


object _17defaultext(object _path_6512, object _defext_6513)
{
    object _3413 = NOVALUE;
    object _3410 = NOVALUE;
    object _3408 = NOVALUE;
    object _3407 = NOVALUE;
    object _3406 = NOVALUE;
    object _3404 = NOVALUE;
    object _3403 = NOVALUE;
    object _3401 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1455		if length(defext) = 0 then*/
    _3401 = 3;

    /** filesys.e:1459		for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6512)){
            _3403 = SEQ_PTR(_path_6512)->length;
    }
    else {
        _3403 = 1;
    }
    {
        object _i_6518;
        _i_6518 = _3403;
L1: 
        if (_i_6518 < 1LL){
            goto L2; // [26] 95
        }

        /** filesys.e:1460			if path[i] = '.' then*/
        _2 = (object)SEQ_PTR(_path_6512);
        _3404 = (object)*(((s1_ptr)_2)->base + _i_6518);
        if (binary_op_a(NOTEQ, _3404, 46LL)){
            _3404 = NOVALUE;
            goto L3; // [39] 50
        }
        _3404 = NOVALUE;

        /** filesys.e:1462				return path*/
        DeRefDSi(_defext_6513);
        return _path_6512;
L3: 

        /** filesys.e:1464			if find(path[i], SLASHES) then*/
        _2 = (object)SEQ_PTR(_path_6512);
        _3406 = (object)*(((s1_ptr)_2)->base + _i_6518);
        _3407 = find_from(_3406, _17SLASHES_6035, 1LL);
        _3406 = NOVALUE;
        if (_3407 == 0)
        {
            _3407 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _3407 = NOVALUE;
        }

        /** filesys.e:1465				if i = length(path) then*/
        if (IS_SEQUENCE(_path_6512)){
                _3408 = SEQ_PTR(_path_6512)->length;
        }
        else {
            _3408 = 1;
        }
        if (_i_6518 != _3408)
        goto L2; // [69] 95

        /** filesys.e:1467					return path*/
        DeRefDSi(_defext_6513);
        return _path_6512;
        goto L5; // [79] 87

        /** filesys.e:1470					exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** filesys.e:1473		end for*/
        _i_6518 = _i_6518 + -1LL;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** filesys.e:1475		if defext[1] != '.' then*/
    _2 = (object)SEQ_PTR(_defext_6513);
    _3410 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3410 == 46LL)
    goto L6; // [101] 112

    /** filesys.e:1476			path &= '.'*/
    Append(&_path_6512, _path_6512, 46LL);
L6: 

    /** filesys.e:1479		return path & defext*/
    Concat((object_ptr)&_3413, _path_6512, _defext_6513);
    DeRefDS(_path_6512);
    DeRefDSi(_defext_6513);
    _3410 = NOVALUE;
    return _3413;
    ;
}


object _17absolute_path(object _filename_6537)
{
    object _3425 = NOVALUE;
    object _3424 = NOVALUE;
    object _3422 = NOVALUE;
    object _3420 = NOVALUE;
    object _3418 = NOVALUE;
    object _3417 = NOVALUE;
    object _3416 = NOVALUE;
    object _3414 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1514		if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_6537)){
            _3414 = SEQ_PTR(_filename_6537)->length;
    }
    else {
        _3414 = 1;
    }
    if (_3414 != 0LL)
    goto L1; // [8] 19

    /** filesys.e:1515			return 0*/
    DeRefDS(_filename_6537);
    return 0LL;
L1: 

    /** filesys.e:1518		if eu:find(filename[1], SLASHES) then*/
    _2 = (object)SEQ_PTR(_filename_6537);
    _3416 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3417 = find_from(_3416, _17SLASHES_6035, 1LL);
    _3416 = NOVALUE;
    if (_3417 == 0)
    {
        _3417 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _3417 = NOVALUE;
    }

    /** filesys.e:1519			return 1*/
    DeRefDS(_filename_6537);
    return 1LL;
L2: 

    /** filesys.e:1522		ifdef WINDOWS then*/

    /** filesys.e:1523			if length(filename) = 1 then*/
    if (IS_SEQUENCE(_filename_6537)){
            _3418 = SEQ_PTR(_filename_6537)->length;
    }
    else {
        _3418 = 1;
    }
    if (_3418 != 1LL)
    goto L3; // [47] 58

    /** filesys.e:1524				return 0*/
    DeRefDS(_filename_6537);
    return 0LL;
L3: 

    /** filesys.e:1527			if filename[2] != ':' then*/
    _2 = (object)SEQ_PTR(_filename_6537);
    _3420 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(EQUALS, _3420, 58LL)){
        _3420 = NOVALUE;
        goto L4; // [64] 75
    }
    _3420 = NOVALUE;

    /** filesys.e:1528				return 0*/
    DeRefDS(_filename_6537);
    return 0LL;
L4: 

    /** filesys.e:1531			if length(filename) < 3 then*/
    if (IS_SEQUENCE(_filename_6537)){
            _3422 = SEQ_PTR(_filename_6537)->length;
    }
    else {
        _3422 = 1;
    }
    if (_3422 >= 3LL)
    goto L5; // [80] 91

    /** filesys.e:1532				return 0*/
    DeRefDS(_filename_6537);
    return 0LL;
L5: 

    /** filesys.e:1535			if eu:find(filename[3], SLASHES) then*/
    _2 = (object)SEQ_PTR(_filename_6537);
    _3424 = (object)*(((s1_ptr)_2)->base + 3LL);
    _3425 = find_from(_3424, _17SLASHES_6035, 1LL);
    _3424 = NOVALUE;
    if (_3425 == 0)
    {
        _3425 = NOVALUE;
        goto L6; // [102] 112
    }
    else{
        _3425 = NOVALUE;
    }

    /** filesys.e:1536				return 1*/
    DeRefDS(_filename_6537);
    return 1LL;
L6: 

    /** filesys.e:1539		return 0*/
    DeRefDS(_filename_6537);
    return 0LL;
    ;
}


object _17canonical_path(object _path_in_6576, object _directory_given_6577, object _case_flags_6578)
{
    object _lPath_6579 = NOVALUE;
    object _lPosA_6580 = NOVALUE;
    object _lPosB_6581 = NOVALUE;
    object _lLevel_6582 = NOVALUE;
    object _lHome_6583 = NOVALUE;
    object _lDrive_6584 = NOVALUE;
    object _current_dir_inlined_current_dir_at_300_6644 = NOVALUE;
    object _driveid_inlined_driveid_at_307_6647 = NOVALUE;
    object _data_inlined_driveid_at_307_6646 = NOVALUE;
    object _wildcard_suffix_6649 = NOVALUE;
    object _first_wildcard_at_6650 = NOVALUE;
    object _last_slash_6653 = NOVALUE;
    object _sl_6725 = NOVALUE;
    object _short_name_6728 = NOVALUE;
    object _correct_name_6731 = NOVALUE;
    object _lower_name_6734 = NOVALUE;
    object _part_6750 = NOVALUE;
    object _list_6755 = NOVALUE;
    object _dir_inlined_dir_at_877_6759 = NOVALUE;
    object _name_inlined_dir_at_874_6758 = NOVALUE;
    object _supplied_name_6760 = NOVALUE;
    object _read_name_6779 = NOVALUE;
    object _read_name_6804 = NOVALUE;
    object _3647 = NOVALUE;
    object _3644 = NOVALUE;
    object _3640 = NOVALUE;
    object _3639 = NOVALUE;
    object _3637 = NOVALUE;
    object _3636 = NOVALUE;
    object _3635 = NOVALUE;
    object _3634 = NOVALUE;
    object _3633 = NOVALUE;
    object _3631 = NOVALUE;
    object _3630 = NOVALUE;
    object _3629 = NOVALUE;
    object _3628 = NOVALUE;
    object _3627 = NOVALUE;
    object _3626 = NOVALUE;
    object _3625 = NOVALUE;
    object _3624 = NOVALUE;
    object _3622 = NOVALUE;
    object _3621 = NOVALUE;
    object _3620 = NOVALUE;
    object _3619 = NOVALUE;
    object _3618 = NOVALUE;
    object _3617 = NOVALUE;
    object _3616 = NOVALUE;
    object _3615 = NOVALUE;
    object _3614 = NOVALUE;
    object _3612 = NOVALUE;
    object _3611 = NOVALUE;
    object _3610 = NOVALUE;
    object _3609 = NOVALUE;
    object _3608 = NOVALUE;
    object _3607 = NOVALUE;
    object _3606 = NOVALUE;
    object _3605 = NOVALUE;
    object _3604 = NOVALUE;
    object _3603 = NOVALUE;
    object _3602 = NOVALUE;
    object _3601 = NOVALUE;
    object _3600 = NOVALUE;
    object _3599 = NOVALUE;
    object _3598 = NOVALUE;
    object _3596 = NOVALUE;
    object _3595 = NOVALUE;
    object _3594 = NOVALUE;
    object _3593 = NOVALUE;
    object _3592 = NOVALUE;
    object _3590 = NOVALUE;
    object _3589 = NOVALUE;
    object _3588 = NOVALUE;
    object _3587 = NOVALUE;
    object _3586 = NOVALUE;
    object _3585 = NOVALUE;
    object _3584 = NOVALUE;
    object _3583 = NOVALUE;
    object _3582 = NOVALUE;
    object _3581 = NOVALUE;
    object _3580 = NOVALUE;
    object _3579 = NOVALUE;
    object _3578 = NOVALUE;
    object _3576 = NOVALUE;
    object _3575 = NOVALUE;
    object _3573 = NOVALUE;
    object _3572 = NOVALUE;
    object _3571 = NOVALUE;
    object _3570 = NOVALUE;
    object _3569 = NOVALUE;
    object _3567 = NOVALUE;
    object _3566 = NOVALUE;
    object _3565 = NOVALUE;
    object _3564 = NOVALUE;
    object _3563 = NOVALUE;
    object _3562 = NOVALUE;
    object _3560 = NOVALUE;
    object _3559 = NOVALUE;
    object _3558 = NOVALUE;
    object _3556 = NOVALUE;
    object _3555 = NOVALUE;
    object _3553 = NOVALUE;
    object _3552 = NOVALUE;
    object _3551 = NOVALUE;
    object _3549 = NOVALUE;
    object _3548 = NOVALUE;
    object _3546 = NOVALUE;
    object _3544 = NOVALUE;
    object _3542 = NOVALUE;
    object _3535 = NOVALUE;
    object _3532 = NOVALUE;
    object _3531 = NOVALUE;
    object _3530 = NOVALUE;
    object _3529 = NOVALUE;
    object _3523 = NOVALUE;
    object _3519 = NOVALUE;
    object _3518 = NOVALUE;
    object _3517 = NOVALUE;
    object _3516 = NOVALUE;
    object _3515 = NOVALUE;
    object _3513 = NOVALUE;
    object _3510 = NOVALUE;
    object _3509 = NOVALUE;
    object _3508 = NOVALUE;
    object _3507 = NOVALUE;
    object _3506 = NOVALUE;
    object _3505 = NOVALUE;
    object _3503 = NOVALUE;
    object _3502 = NOVALUE;
    object _3500 = NOVALUE;
    object _3498 = NOVALUE;
    object _3497 = NOVALUE;
    object _3496 = NOVALUE;
    object _3494 = NOVALUE;
    object _3493 = NOVALUE;
    object _3492 = NOVALUE;
    object _3491 = NOVALUE;
    object _3489 = NOVALUE;
    object _3487 = NOVALUE;
    object _3482 = NOVALUE;
    object _3480 = NOVALUE;
    object _3479 = NOVALUE;
    object _3478 = NOVALUE;
    object _3477 = NOVALUE;
    object _3476 = NOVALUE;
    object _3474 = NOVALUE;
    object _3473 = NOVALUE;
    object _3471 = NOVALUE;
    object _3470 = NOVALUE;
    object _3469 = NOVALUE;
    object _3468 = NOVALUE;
    object _3467 = NOVALUE;
    object _3466 = NOVALUE;
    object _3465 = NOVALUE;
    object _3462 = NOVALUE;
    object _3461 = NOVALUE;
    object _3459 = NOVALUE;
    object _3457 = NOVALUE;
    object _3455 = NOVALUE;
    object _3452 = NOVALUE;
    object _3451 = NOVALUE;
    object _3450 = NOVALUE;
    object _3449 = NOVALUE;
    object _3448 = NOVALUE;
    object _3446 = NOVALUE;
    object _3445 = NOVALUE;
    object _3444 = NOVALUE;
    object _3443 = NOVALUE;
    object _3442 = NOVALUE;
    object _3441 = NOVALUE;
    object _3440 = NOVALUE;
    object _3439 = NOVALUE;
    object _3438 = NOVALUE;
    object _3437 = NOVALUE;
    object _3436 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1607	    sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_6579);
    _lPath_6579 = _5;

    /** filesys.e:1608	    integer lPosA = -1*/
    _lPosA_6580 = -1LL;

    /** filesys.e:1609	    integer lPosB = -1*/
    _lPosB_6581 = -1LL;

    /** filesys.e:1610	    sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_6582);
    _lLevel_6582 = _5;

    /** filesys.e:1612	    path_in = path_in*/
    RefDS(_path_in_6576);
    DeRefDS(_path_in_6576);
    _path_in_6576 = _path_in_6576;

    /** filesys.e:1614		ifdef UNIX then*/

    /** filesys.e:1617		    sequence lDrive*/

    /** filesys.e:1619		    lPath = match_replace("/", path_in, SLASH)*/
    RefDS(_3152);
    RefDS(_path_in_6576);
    _0 = _lPath_6579;
    _lPath_6579 = _16match_replace(_3152, _path_in_6576, 92LL, 0LL);
    DeRefDS(_0);

    /** filesys.e:1623	    if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3436 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3436 = 1;
    }
    _3437 = (_3436 > 2LL);
    _3436 = NOVALUE;
    if (_3437 == 0) {
        _3438 = 0;
        goto L1; // [62] 78
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3439 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3439)) {
        _3440 = (_3439 == 34LL);
    }
    else {
        _3440 = binary_op(EQUALS, _3439, 34LL);
    }
    _3439 = NOVALUE;
    if (IS_ATOM_INT(_3440))
    _3438 = (_3440 != 0);
    else
    _3438 = DBL_PTR(_3440)->dbl != 0.0;
L1: 
    if (_3438 == 0) {
        DeRef(_3441);
        _3441 = 0;
        goto L2; // [78] 97
    }
    if (IS_SEQUENCE(_lPath_6579)){
            _3442 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3442 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3443 = (object)*(((s1_ptr)_2)->base + _3442);
    if (IS_ATOM_INT(_3443)) {
        _3444 = (_3443 == 34LL);
    }
    else {
        _3444 = binary_op(EQUALS, _3443, 34LL);
    }
    _3443 = NOVALUE;
    if (IS_ATOM_INT(_3444))
    _3441 = (_3444 != 0);
    else
    _3441 = DBL_PTR(_3444)->dbl != 0.0;
L2: 
    if (_3441 == 0)
    {
        _3441 = NOVALUE;
        goto L3; // [97] 115
    }
    else{
        _3441 = NOVALUE;
    }

    /** filesys.e:1624	        lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3445 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3445 = 1;
    }
    _3446 = _3445 - 1LL;
    _3445 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_6579;
    RHS_Slice(_lPath_6579, 2LL, _3446);
L3: 

    /** filesys.e:1628	    if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3448 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3448 = 1;
    }
    _3449 = (_3448 > 0LL);
    _3448 = NOVALUE;
    if (_3449 == 0) {
        DeRef(_3450);
        _3450 = 0;
        goto L4; // [124] 140
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3451 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3451)) {
        _3452 = (_3451 == 126LL);
    }
    else {
        _3452 = binary_op(EQUALS, _3451, 126LL);
    }
    _3451 = NOVALUE;
    if (IS_ATOM_INT(_3452))
    _3450 = (_3452 != 0);
    else
    _3450 = DBL_PTR(_3452)->dbl != 0.0;
L4: 
    if (_3450 == 0)
    {
        _3450 = NOVALUE;
        goto L5; // [140] 249
    }
    else{
        _3450 = NOVALUE;
    }

    /** filesys.e:1630			lHome = getenv("HOME")*/
    DeRef(_lHome_6583);
    _lHome_6583 = EGetEnv(_3453);

    /** filesys.e:1631			ifdef WINDOWS then*/

    /** filesys.e:1632				if atom(lHome) then*/
    _3455 = IS_ATOM(_lHome_6583);
    if (_3455 == 0)
    {
        _3455 = NOVALUE;
        goto L6; // [155] 171
    }
    else{
        _3455 = NOVALUE;
    }

    /** filesys.e:1633					lHome = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _3457 = EGetEnv(_3456);
    _3459 = EGetEnv(_3458);
    if (IS_SEQUENCE(_3457) && IS_ATOM(_3459)) {
        Ref(_3459);
        Append(&_lHome_6583, _3457, _3459);
    }
    else if (IS_ATOM(_3457) && IS_SEQUENCE(_3459)) {
        Ref(_3457);
        Prepend(&_lHome_6583, _3459, _3457);
    }
    else {
        Concat((object_ptr)&_lHome_6583, _3457, _3459);
        DeRef(_3457);
        _3457 = NOVALUE;
    }
    DeRef(_3457);
    _3457 = NOVALUE;
    DeRef(_3459);
    _3459 = NOVALUE;
L6: 

    /** filesys.e:1637			if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_6583)){
            _3461 = SEQ_PTR(_lHome_6583)->length;
    }
    else {
        _3461 = 1;
    }
    _2 = (object)SEQ_PTR(_lHome_6583);
    _3462 = (object)*(((s1_ptr)_2)->base + _3461);
    if (binary_op_a(EQUALS, _3462, 92LL)){
        _3462 = NOVALUE;
        goto L7; // [180] 191
    }
    _3462 = NOVALUE;

    /** filesys.e:1638				lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_6583) && IS_ATOM(92LL)) {
        Append(&_lHome_6583, _lHome_6583, 92LL);
    }
    else if (IS_ATOM(_lHome_6583) && IS_SEQUENCE(92LL)) {
    }
    else {
        Concat((object_ptr)&_lHome_6583, _lHome_6583, 92LL);
    }
L7: 

    /** filesys.e:1641			if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3465 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3465 = 1;
    }
    _3466 = (_3465 > 1LL);
    _3465 = NOVALUE;
    if (_3466 == 0) {
        goto L8; // [200] 233
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3468 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3468)) {
        _3469 = (_3468 == 92LL);
    }
    else {
        _3469 = binary_op(EQUALS, _3468, 92LL);
    }
    _3468 = NOVALUE;
    if (_3469 == 0) {
        DeRef(_3469);
        _3469 = NOVALUE;
        goto L8; // [213] 233
    }
    else {
        if (!IS_ATOM_INT(_3469) && DBL_PTR(_3469)->dbl == 0.0){
            DeRef(_3469);
            _3469 = NOVALUE;
            goto L8; // [213] 233
        }
        DeRef(_3469);
        _3469 = NOVALUE;
    }
    DeRef(_3469);
    _3469 = NOVALUE;

    /** filesys.e:1642				lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3470 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3470 = 1;
    }
    rhs_slice_target = (object_ptr)&_3471;
    RHS_Slice(_lPath_6579, 3LL, _3470);
    if (IS_SEQUENCE(_lHome_6583) && IS_ATOM(_3471)) {
    }
    else if (IS_ATOM(_lHome_6583) && IS_SEQUENCE(_3471)) {
        Ref(_lHome_6583);
        Prepend(&_lPath_6579, _3471, _lHome_6583);
    }
    else {
        Concat((object_ptr)&_lPath_6579, _lHome_6583, _3471);
    }
    DeRefDS(_3471);
    _3471 = NOVALUE;
    goto L9; // [230] 248
L8: 

    /** filesys.e:1644				lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3473 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3473 = 1;
    }
    rhs_slice_target = (object_ptr)&_3474;
    RHS_Slice(_lPath_6579, 2LL, _3473);
    if (IS_SEQUENCE(_lHome_6583) && IS_ATOM(_3474)) {
    }
    else if (IS_ATOM(_lHome_6583) && IS_SEQUENCE(_3474)) {
        Ref(_lHome_6583);
        Prepend(&_lPath_6579, _3474, _lHome_6583);
    }
    else {
        Concat((object_ptr)&_lPath_6579, _lHome_6583, _3474);
    }
    DeRefDS(_3474);
    _3474 = NOVALUE;
L9: 
L5: 

    /** filesys.e:1648		ifdef WINDOWS then*/

    /** filesys.e:1650		    if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3476 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3476 = 1;
    }
    _3477 = (_3476 > 1LL);
    _3476 = NOVALUE;
    if (_3477 == 0) {
        DeRef(_3478);
        _3478 = 0;
        goto LA; // [260] 276
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3479 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3479)) {
        _3480 = (_3479 == 58LL);
    }
    else {
        _3480 = binary_op(EQUALS, _3479, 58LL);
    }
    _3479 = NOVALUE;
    if (IS_ATOM_INT(_3480))
    _3478 = (_3480 != 0);
    else
    _3478 = DBL_PTR(_3480)->dbl != 0.0;
LA: 
    if (_3478 == 0)
    {
        _3478 = NOVALUE;
        goto LB; // [276] 299
    }
    else{
        _3478 = NOVALUE;
    }

    /** filesys.e:1651				lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_6584;
    RHS_Slice(_lPath_6579, 1LL, 2LL);

    /** filesys.e:1652				lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3482 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3482 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_6579;
    RHS_Slice(_lPath_6579, 3LL, _3482);
    goto LC; // [296] 333
LB: 

    /** filesys.e:1654				lDrive = driveid(current_dir()) & ':'*/

    /** filesys.e:465		return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_current_dir_inlined_current_dir_at_300_6644);
    _current_dir_inlined_current_dir_at_300_6644 = machine(23LL, 0LL);

    /** filesys.e:1429		data = pathinfo(path)*/
    RefDS(_current_dir_inlined_current_dir_at_300_6644);
    _0 = _data_inlined_driveid_at_307_6646;
    _data_inlined_driveid_at_307_6646 = _17pathinfo(_current_dir_inlined_current_dir_at_300_6644, 0LL);
    DeRef(_0);

    /** filesys.e:1430		return data[5]*/
    DeRef(_driveid_inlined_driveid_at_307_6647);
    _2 = (object)SEQ_PTR(_data_inlined_driveid_at_307_6646);
    _driveid_inlined_driveid_at_307_6647 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_driveid_inlined_driveid_at_307_6647);
    DeRef(_data_inlined_driveid_at_307_6646);
    _data_inlined_driveid_at_307_6646 = NOVALUE;
    if (IS_SEQUENCE(_driveid_inlined_driveid_at_307_6647) && IS_ATOM(58LL)) {
        Append(&_lDrive_6584, _driveid_inlined_driveid_at_307_6647, 58LL);
    }
    else if (IS_ATOM(_driveid_inlined_driveid_at_307_6647) && IS_SEQUENCE(58LL)) {
    }
    else {
        Concat((object_ptr)&_lDrive_6584, _driveid_inlined_driveid_at_307_6647, 58LL);
    }
LC: 

    /** filesys.e:1658		sequence wildcard_suffix*/

    /** filesys.e:1659		integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_6579);
    _first_wildcard_at_6650 = _17find_first_wildcard(_lPath_6579, 1LL);
    if (!IS_ATOM_INT(_first_wildcard_at_6650)) {
        _1 = (object)(DBL_PTR(_first_wildcard_at_6650)->dbl);
        DeRefDS(_first_wildcard_at_6650);
        _first_wildcard_at_6650 = _1;
    }

    /** filesys.e:1660		if first_wildcard_at then*/
    if (_first_wildcard_at_6650 == 0)
    {
        goto LD; // [346] 407
    }
    else{
    }

    /** filesys.e:1661			integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_6579);
    _last_slash_6653 = _16rfind(92LL, _lPath_6579, _first_wildcard_at_6650);
    if (!IS_ATOM_INT(_last_slash_6653)) {
        _1 = (object)(DBL_PTR(_last_slash_6653)->dbl);
        DeRefDS(_last_slash_6653);
        _last_slash_6653 = _1;
    }

    /** filesys.e:1662			if last_slash then*/
    if (_last_slash_6653 == 0)
    {
        goto LE; // [361] 387
    }
    else{
    }

    /** filesys.e:1663				wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3487 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3487 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_6649;
    RHS_Slice(_lPath_6579, _last_slash_6653, _3487);

    /** filesys.e:1664				lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3489 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3489 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6579);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_6653)) ? _last_slash_6653 : (object)(DBL_PTR(_last_slash_6653)->dbl);
        int stop = (IS_ATOM_INT(_3489)) ? _3489 : (object)(DBL_PTR(_3489)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6579), start, &_lPath_6579 );
            }
            else Tail(SEQ_PTR(_lPath_6579), stop+1, &_lPath_6579);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6579), start, &_lPath_6579);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6579 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6579)->ref == 1));
        }
    }
    _3489 = NOVALUE;
    goto LF; // [384] 402
LE: 

    /** filesys.e:1666				wildcard_suffix = lPath*/
    RefDS(_lPath_6579);
    DeRef(_wildcard_suffix_6649);
    _wildcard_suffix_6649 = _lPath_6579;

    /** filesys.e:1667				lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_6579);
    _lPath_6579 = _5;
LF: 
    goto L10; // [404] 415
LD: 

    /** filesys.e:1670			wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_6649);
    _wildcard_suffix_6649 = _5;
L10: 

    /** filesys.e:1674		if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3491 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3491 = 1;
    }
    _3492 = (_3491 == 0LL);
    _3491 = NOVALUE;
    if (_3492 != 0) {
        DeRef(_3493);
        _3493 = 1;
        goto L11; // [424] 444
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3494 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3496 = find_from(_3494, _3495, 1LL);
    _3494 = NOVALUE;
    _3497 = (_3496 == 0);
    _3496 = NOVALUE;
    _3493 = (_3497 != 0);
L11: 
    if (_3493 == 0)
    {
        _3493 = NOVALUE;
        goto L12; // [444] 545
    }
    else{
        _3493 = NOVALUE;
    }

    /** filesys.e:1675			ifdef UNIX then*/

    /** filesys.e:1678				if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_6584)){
            _3498 = SEQ_PTR(_lDrive_6584)->length;
    }
    else {
        _3498 = 1;
    }
    if (_3498 != 0LL)
    goto L13; // [456] 473

    /** filesys.e:1679					lPath = curdir() & lPath*/
    _3500 = _17curdir(0LL);
    if (IS_SEQUENCE(_3500) && IS_ATOM(_lPath_6579)) {
    }
    else if (IS_ATOM(_3500) && IS_SEQUENCE(_lPath_6579)) {
        Ref(_3500);
        Prepend(&_lPath_6579, _lPath_6579, _3500);
    }
    else {
        Concat((object_ptr)&_lPath_6579, _3500, _lPath_6579);
        DeRef(_3500);
        _3500 = NOVALUE;
    }
    DeRef(_3500);
    _3500 = NOVALUE;
    goto L14; // [470] 488
L13: 

    /** filesys.e:1681					lPath = curdir(lDrive[1]) & lPath*/
    _2 = (object)SEQ_PTR(_lDrive_6584);
    _3502 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_3502);
    _3503 = _17curdir(_3502);
    _3502 = NOVALUE;
    if (IS_SEQUENCE(_3503) && IS_ATOM(_lPath_6579)) {
    }
    else if (IS_ATOM(_3503) && IS_SEQUENCE(_lPath_6579)) {
        Ref(_3503);
        Prepend(&_lPath_6579, _lPath_6579, _3503);
    }
    else {
        Concat((object_ptr)&_lPath_6579, _3503, _lPath_6579);
        DeRef(_3503);
        _3503 = NOVALUE;
    }
    DeRef(_3503);
    _3503 = NOVALUE;
L14: 

    /** filesys.e:1684				if ( (length(lPath) > 1) and (lPath[2] = ':' ) ) then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3505 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3505 = 1;
    }
    _3506 = (_3505 > 1LL);
    _3505 = NOVALUE;
    if (_3506 == 0) {
        DeRef(_3507);
        _3507 = 0;
        goto L15; // [497] 513
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3508 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3508)) {
        _3509 = (_3508 == 58LL);
    }
    else {
        _3509 = binary_op(EQUALS, _3508, 58LL);
    }
    _3508 = NOVALUE;
    if (IS_ATOM_INT(_3509))
    _3507 = (_3509 != 0);
    else
    _3507 = DBL_PTR(_3509)->dbl != 0.0;
L15: 
    if (_3507 == 0)
    {
        _3507 = NOVALUE;
        goto L16; // [513] 544
    }
    else{
        _3507 = NOVALUE;
    }

    /** filesys.e:1685					if (length(lDrive) = 0) then*/
    if (IS_SEQUENCE(_lDrive_6584)){
            _3510 = SEQ_PTR(_lDrive_6584)->length;
    }
    else {
        _3510 = 1;
    }
    if (_3510 != 0LL)
    goto L17; // [521] 533

    /** filesys.e:1686						lDrive = lPath[1..2]*/
    rhs_slice_target = (object_ptr)&_lDrive_6584;
    RHS_Slice(_lPath_6579, 1LL, 2LL);
L17: 

    /** filesys.e:1688					lPath = lPath[3..$]*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3513 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3513 = 1;
    }
    rhs_slice_target = (object_ptr)&_lPath_6579;
    RHS_Slice(_lPath_6579, 3LL, _3513);
L16: 
L12: 

    /** filesys.e:1694		if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _3515 = (_directory_given_6577 != 0LL);
    if (_3515 == 0) {
        DeRef(_3516);
        _3516 = 0;
        goto L18; // [551] 570
    }
    if (IS_SEQUENCE(_lPath_6579)){
            _3517 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3517 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3518 = (object)*(((s1_ptr)_2)->base + _3517);
    if (IS_ATOM_INT(_3518)) {
        _3519 = (_3518 != 92LL);
    }
    else {
        _3519 = binary_op(NOTEQ, _3518, 92LL);
    }
    _3518 = NOVALUE;
    if (IS_ATOM_INT(_3519))
    _3516 = (_3519 != 0);
    else
    _3516 = DBL_PTR(_3519)->dbl != 0.0;
L18: 
    if (_3516 == 0)
    {
        _3516 = NOVALUE;
        goto L19; // [570] 580
    }
    else{
        _3516 = NOVALUE;
    }

    /** filesys.e:1695			lPath &= SLASH*/
    Append(&_lPath_6579, _lPath_6579, 92LL);
L19: 

    /** filesys.e:1699		lLevel = SLASH & '.' & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 92LL;
        concat_list[1] = 46LL;
        concat_list[2] = 92LL;
        Concat_N((object_ptr)&_lLevel_6582, concat_list, 3);
    }

    /** filesys.e:1700		lPosA = 1*/
    _lPosA_6580 = 1LL;

    /** filesys.e:1701		while( lPosA != 0 ) with entry do*/
    goto L1A; // [595] 616
L1B: 
    if (_lPosA_6580 == 0LL)
    goto L1C; // [598] 628

    /** filesys.e:1702			lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _3523 = _lPosA_6580 + 1;
    if (_3523 > MAXINT){
        _3523 = NewDouble((eudouble)_3523);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6579);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_6580)) ? _lPosA_6580 : (object)(DBL_PTR(_lPosA_6580)->dbl);
        int stop = (IS_ATOM_INT(_3523)) ? _3523 : (object)(DBL_PTR(_3523)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6579), start, &_lPath_6579 );
            }
            else Tail(SEQ_PTR(_lPath_6579), stop+1, &_lPath_6579);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6579), start, &_lPath_6579);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6579 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6579)->ref == 1));
        }
    }
    DeRef(_3523);
    _3523 = NOVALUE;

    /** filesys.e:1704		  entry*/
L1A: 

    /** filesys.e:1705			lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_6580 = e_match_from(_lLevel_6582, _lPath_6579, _lPosA_6580);

    /** filesys.e:1706		end while*/
    goto L1B; // [625] 598
L1C: 

    /** filesys.e:1709		lLevel = SLASH & ".." & SLASH*/
    {
        object concat_list[3];

        concat_list[0] = 92LL;
        concat_list[1] = _3201;
        concat_list[2] = 92LL;
        Concat_N((object_ptr)&_lLevel_6582, concat_list, 3);
    }

    /** filesys.e:1711		lPosB = 1*/
    _lPosB_6581 = 1LL;

    /** filesys.e:1712		while( lPosA != 0 ) with entry do*/
    goto L1D; // [643] 721
L1E: 
    if (_lPosA_6580 == 0LL)
    goto L1F; // [646] 733

    /** filesys.e:1714			lPosB = lPosA-1*/
    _lPosB_6581 = _lPosA_6580 - 1LL;

    /** filesys.e:1715			while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L20: 
    _3529 = (_lPosB_6581 > 0LL);
    if (_3529 == 0) {
        DeRef(_3530);
        _3530 = 0;
        goto L21; // [665] 681
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3531 = (object)*(((s1_ptr)_2)->base + _lPosB_6581);
    if (IS_ATOM_INT(_3531)) {
        _3532 = (_3531 != 92LL);
    }
    else {
        _3532 = binary_op(NOTEQ, _3531, 92LL);
    }
    _3531 = NOVALUE;
    if (IS_ATOM_INT(_3532))
    _3530 = (_3532 != 0);
    else
    _3530 = DBL_PTR(_3532)->dbl != 0.0;
L21: 
    if (_3530 == 0)
    {
        _3530 = NOVALUE;
        goto L22; // [681] 695
    }
    else{
        _3530 = NOVALUE;
    }

    /** filesys.e:1716				lPosB -= 1*/
    _lPosB_6581 = _lPosB_6581 - 1LL;

    /** filesys.e:1717			end while*/
    goto L20; // [692] 661
L22: 

    /** filesys.e:1718			if (lPosB <= 0) then*/
    if (_lPosB_6581 > 0LL)
    goto L23; // [697] 707

    /** filesys.e:1719				lPosB = 1*/
    _lPosB_6581 = 1LL;
L23: 

    /** filesys.e:1721			lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _3535 = _lPosA_6580 + 2LL;
    if ((object)((uintptr_t)_3535 + (uintptr_t)HIGH_BITS) >= 0){
        _3535 = NewDouble((eudouble)_3535);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6579);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_6581)) ? _lPosB_6581 : (object)(DBL_PTR(_lPosB_6581)->dbl);
        int stop = (IS_ATOM_INT(_3535)) ? _3535 : (object)(DBL_PTR(_3535)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6579), start, &_lPath_6579 );
            }
            else Tail(SEQ_PTR(_lPath_6579), stop+1, &_lPath_6579);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6579), start, &_lPath_6579);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6579 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6579)->ref == 1));
        }
    }
    DeRef(_3535);
    _3535 = NOVALUE;

    /** filesys.e:1723		  entry*/
L1D: 

    /** filesys.e:1724			lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_6580 = e_match_from(_lLevel_6582, _lPath_6579, _lPosB_6581);

    /** filesys.e:1725		end while*/
    goto L1E; // [730] 646
L1F: 

    /** filesys.e:1727		if case_flags = TO_LOWER then*/
    if (_case_flags_6578 != 1LL)
    goto L24; // [735] 750

    /** filesys.e:1728			lPath = lower( lPath )*/
    RefDS(_lPath_6579);
    _0 = _lPath_6579;
    _lPath_6579 = _14lower(_lPath_6579);
    DeRefDS(_0);
    goto L25; // [747] 1365
L24: 

    /** filesys.e:1730		elsif case_flags != AS_IS then*/
    if (_case_flags_6578 == 0LL)
    goto L26; // [752] 1362

    /** filesys.e:1731			sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_6579);
    _0 = _sl_6725;
    _sl_6725 = _16find_all(92LL, _lPath_6579, 1LL);
    DeRef(_0);

    /** filesys.e:1732			integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {uintptr_t tu;
         tu = (uintptr_t)4LL & (uintptr_t)_case_flags_6578;
         _3542 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3542)) {
        _short_name_6728 = (_3542 == 4LL);
    }
    else {
        _short_name_6728 = (DBL_PTR(_3542)->dbl == (eudouble)4LL);
    }
    DeRef(_3542);
    _3542 = NOVALUE;

    /** filesys.e:1733			integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {uintptr_t tu;
         tu = (uintptr_t)_case_flags_6578 & (uintptr_t)2LL;
         _3544 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3544)) {
        _correct_name_6731 = (_3544 == 2LL);
    }
    else {
        _correct_name_6731 = (DBL_PTR(_3544)->dbl == (eudouble)2LL);
    }
    DeRef(_3544);
    _3544 = NOVALUE;

    /** filesys.e:1734			integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {uintptr_t tu;
         tu = (uintptr_t)1LL & (uintptr_t)_case_flags_6578;
         _3546 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3546)) {
        _lower_name_6734 = (_3546 == 1LL);
    }
    else {
        _lower_name_6734 = (DBL_PTR(_3546)->dbl == (eudouble)1LL);
    }
    DeRef(_3546);
    _3546 = NOVALUE;

    /** filesys.e:1735			if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3548 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3548 = 1;
    }
    _2 = (object)SEQ_PTR(_lPath_6579);
    _3549 = (object)*(((s1_ptr)_2)->base + _3548);
    if (binary_op_a(EQUALS, _3549, 92LL)){
        _3549 = NOVALUE;
        goto L27; // [805] 827
    }
    _3549 = NOVALUE;

    /** filesys.e:1736				sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_6579)){
            _3551 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3551 = 1;
    }
    _3552 = _3551 + 1;
    _3551 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3552;
    _3553 = MAKE_SEQ(_1);
    _3552 = NOVALUE;
    Concat((object_ptr)&_sl_6725, _sl_6725, _3553);
    DeRefDS(_3553);
    _3553 = NOVALUE;
L27: 

    /** filesys.e:1739			for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_6725)){
            _3555 = SEQ_PTR(_sl_6725)->length;
    }
    else {
        _3555 = 1;
    }
    _3556 = _3555 - 1LL;
    _3555 = NOVALUE;
    {
        object _i_6746;
        _i_6746 = _3556;
L28: 
        if (_i_6746 < 1LL){
            goto L29; // [836] 1327
        }

        /** filesys.e:1740				ifdef WINDOWS then*/

        /** filesys.e:1741					sequence part = lDrive & lPath[1..sl[i]-1]*/
        _2 = (object)SEQ_PTR(_sl_6725);
        _3558 = (object)*(((s1_ptr)_2)->base + _i_6746);
        if (IS_ATOM_INT(_3558)) {
            _3559 = _3558 - 1LL;
        }
        else {
            _3559 = binary_op(MINUS, _3558, 1LL);
        }
        _3558 = NOVALUE;
        rhs_slice_target = (object_ptr)&_3560;
        RHS_Slice(_lPath_6579, 1LL, _3559);
        Concat((object_ptr)&_part_6750, _lDrive_6584, _3560);
        DeRefDS(_3560);
        _3560 = NOVALUE;

        /** filesys.e:1746				object list = dir( part & SLASH )*/
        Append(&_3562, _part_6750, 92LL);
        DeRef(_name_inlined_dir_at_874_6758);
        _name_inlined_dir_at_874_6758 = _3562;
        _3562 = NOVALUE;

        /** filesys.e:358		ifdef WINDOWS then*/

        /** filesys.e:359			return machine_func(M_DIR, name)*/
        DeRef(_list_6755);
        _list_6755 = machine(22LL, _name_inlined_dir_at_874_6758);
        DeRef(_name_inlined_dir_at_874_6758);
        _name_inlined_dir_at_874_6758 = NOVALUE;

        /** filesys.e:1747				sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (object)SEQ_PTR(_sl_6725);
        _3563 = (object)*(((s1_ptr)_2)->base + _i_6746);
        if (IS_ATOM_INT(_3563)) {
            _3564 = _3563 + 1;
            if (_3564 > MAXINT){
                _3564 = NewDouble((eudouble)_3564);
            }
        }
        else
        _3564 = binary_op(PLUS, 1, _3563);
        _3563 = NOVALUE;
        _3565 = _i_6746 + 1;
        _2 = (object)SEQ_PTR(_sl_6725);
        _3566 = (object)*(((s1_ptr)_2)->base + _3565);
        if (IS_ATOM_INT(_3566)) {
            _3567 = _3566 - 1LL;
        }
        else {
            _3567 = binary_op(MINUS, _3566, 1LL);
        }
        _3566 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_6760;
        RHS_Slice(_lPath_6579, _3564, _3567);

        /** filesys.e:1749				if atom(list) then*/
        _3569 = IS_ATOM(_list_6755);
        if (_3569 == 0)
        {
            _3569 = NOVALUE;
            goto L2A; // [922] 960
        }
        else{
            _3569 = NOVALUE;
        }

        /** filesys.e:1750					if lower_name then*/
        if (_lower_name_6734 == 0)
        {
            goto L2B; // [927] 953
        }
        else{
        }

        /** filesys.e:1751						lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_6725);
        _3570 = (object)*(((s1_ptr)_2)->base + _i_6746);
        if (IS_SEQUENCE(_lPath_6579)){
                _3571 = SEQ_PTR(_lPath_6579)->length;
        }
        else {
            _3571 = 1;
        }
        rhs_slice_target = (object_ptr)&_3572;
        RHS_Slice(_lPath_6579, _3570, _3571);
        _3573 = _14lower(_3572);
        _3572 = NOVALUE;
        if (IS_SEQUENCE(_part_6750) && IS_ATOM(_3573)) {
            Ref(_3573);
            Append(&_lPath_6579, _part_6750, _3573);
        }
        else if (IS_ATOM(_part_6750) && IS_SEQUENCE(_3573)) {
        }
        else {
            Concat((object_ptr)&_lPath_6579, _part_6750, _3573);
        }
        DeRef(_3573);
        _3573 = NOVALUE;
L2B: 

        /** filesys.e:1753					continue*/
        DeRef(_part_6750);
        _part_6750 = NOVALUE;
        DeRef(_list_6755);
        _list_6755 = NOVALUE;
        DeRef(_supplied_name_6760);
        _supplied_name_6760 = NOVALUE;
        goto L2C; // [957] 1322
L2A: 

        /** filesys.e:1757				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6755)){
                _3575 = SEQ_PTR(_list_6755)->length;
        }
        else {
            _3575 = 1;
        }
        {
            object _j_6777;
            _j_6777 = 1LL;
L2D: 
            if (_j_6777 > _3575){
                goto L2E; // [965] 1090
            }

            /** filesys.e:1758					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_6755);
            _3576 = (object)*(((s1_ptr)_2)->base + _j_6777);
            DeRef(_read_name_6779);
            _2 = (object)SEQ_PTR(_3576);
            _read_name_6779 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_read_name_6779);
            _3576 = NOVALUE;

            /** filesys.e:1759					if equal(read_name, supplied_name) then*/
            if (_read_name_6779 == _supplied_name_6760)
            _3578 = 1;
            else if (IS_ATOM_INT(_read_name_6779) && IS_ATOM_INT(_supplied_name_6760))
            _3578 = 0;
            else
            _3578 = (compare(_read_name_6779, _supplied_name_6760) == 0);
            if (_3578 == 0)
            {
                _3578 = NOVALUE;
                goto L2F; // [990] 1081
            }
            else{
                _3578 = NOVALUE;
            }

            /** filesys.e:1760						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6728 == 0) {
                goto L30; // [995] 1072
            }
            _2 = (object)SEQ_PTR(_list_6755);
            _3580 = (object)*(((s1_ptr)_2)->base + _j_6777);
            _2 = (object)SEQ_PTR(_3580);
            _3581 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3580 = NOVALUE;
            _3582 = IS_SEQUENCE(_3581);
            _3581 = NOVALUE;
            if (_3582 == 0)
            {
                _3582 = NOVALUE;
                goto L30; // [1011] 1072
            }
            else{
                _3582 = NOVALUE;
            }

            /** filesys.e:1761							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_6725);
            _3583 = (object)*(((s1_ptr)_2)->base + _i_6746);
            rhs_slice_target = (object_ptr)&_3584;
            RHS_Slice(_lPath_6579, 1LL, _3583);
            _2 = (object)SEQ_PTR(_list_6755);
            _3585 = (object)*(((s1_ptr)_2)->base + _j_6777);
            _2 = (object)SEQ_PTR(_3585);
            _3586 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3585 = NOVALUE;
            _3587 = _i_6746 + 1;
            _2 = (object)SEQ_PTR(_sl_6725);
            _3588 = (object)*(((s1_ptr)_2)->base + _3587);
            if (IS_SEQUENCE(_lPath_6579)){
                    _3589 = SEQ_PTR(_lPath_6579)->length;
            }
            else {
                _3589 = 1;
            }
            rhs_slice_target = (object_ptr)&_3590;
            RHS_Slice(_lPath_6579, _3588, _3589);
            {
                object concat_list[3];

                concat_list[0] = _3590;
                concat_list[1] = _3586;
                concat_list[2] = _3584;
                Concat_N((object_ptr)&_lPath_6579, concat_list, 3);
            }
            DeRefDS(_3590);
            _3590 = NOVALUE;
            _3586 = NOVALUE;
            DeRefDS(_3584);
            _3584 = NOVALUE;

            /** filesys.e:1762							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6725)){
                    _3592 = SEQ_PTR(_sl_6725)->length;
            }
            else {
                _3592 = 1;
            }
            if (IS_SEQUENCE(_lPath_6579)){
                    _3593 = SEQ_PTR(_lPath_6579)->length;
            }
            else {
                _3593 = 1;
            }
            _3594 = _3593 + 1;
            _3593 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_6725);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_6725 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _3592);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3594;
            if( _1 != _3594 ){
                DeRef(_1);
            }
            _3594 = NOVALUE;
L30: 

            /** filesys.e:1764						continue "partloop"*/
            DeRef(_read_name_6779);
            _read_name_6779 = NOVALUE;
            DeRef(_part_6750);
            _part_6750 = NOVALUE;
            DeRef(_list_6755);
            _list_6755 = NOVALUE;
            DeRef(_supplied_name_6760);
            _supplied_name_6760 = NOVALUE;
            goto L2C; // [1078] 1322
L2F: 
            DeRef(_read_name_6779);
            _read_name_6779 = NOVALUE;

            /** filesys.e:1766				end for*/
            _j_6777 = _j_6777 + 1LL;
            goto L2D; // [1085] 972
L2E: 
            ;
        }

        /** filesys.e:1770				for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6755)){
                _3595 = SEQ_PTR(_list_6755)->length;
        }
        else {
            _3595 = 1;
        }
        {
            object _j_6802;
            _j_6802 = 1LL;
L31: 
            if (_j_6802 > _3595){
                goto L32; // [1095] 1267
            }

            /** filesys.e:1771					sequence read_name = list[j][D_NAME]*/
            _2 = (object)SEQ_PTR(_list_6755);
            _3596 = (object)*(((s1_ptr)_2)->base + _j_6802);
            DeRef(_read_name_6804);
            _2 = (object)SEQ_PTR(_3596);
            _read_name_6804 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_read_name_6804);
            _3596 = NOVALUE;

            /** filesys.e:1772					if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_6804);
            _3598 = _14lower(_read_name_6804);
            RefDS(_supplied_name_6760);
            _3599 = _14lower(_supplied_name_6760);
            if (_3598 == _3599)
            _3600 = 1;
            else if (IS_ATOM_INT(_3598) && IS_ATOM_INT(_3599))
            _3600 = 0;
            else
            _3600 = (compare(_3598, _3599) == 0);
            DeRef(_3598);
            _3598 = NOVALUE;
            DeRef(_3599);
            _3599 = NOVALUE;
            if (_3600 == 0)
            {
                _3600 = NOVALUE;
                goto L33; // [1128] 1258
            }
            else{
                _3600 = NOVALUE;
            }

            /** filesys.e:1773						if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6728 == 0) {
                goto L34; // [1133] 1210
            }
            _2 = (object)SEQ_PTR(_list_6755);
            _3602 = (object)*(((s1_ptr)_2)->base + _j_6802);
            _2 = (object)SEQ_PTR(_3602);
            _3603 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3602 = NOVALUE;
            _3604 = IS_SEQUENCE(_3603);
            _3603 = NOVALUE;
            if (_3604 == 0)
            {
                _3604 = NOVALUE;
                goto L34; // [1149] 1210
            }
            else{
                _3604 = NOVALUE;
            }

            /** filesys.e:1774							lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_6725);
            _3605 = (object)*(((s1_ptr)_2)->base + _i_6746);
            rhs_slice_target = (object_ptr)&_3606;
            RHS_Slice(_lPath_6579, 1LL, _3605);
            _2 = (object)SEQ_PTR(_list_6755);
            _3607 = (object)*(((s1_ptr)_2)->base + _j_6802);
            _2 = (object)SEQ_PTR(_3607);
            _3608 = (object)*(((s1_ptr)_2)->base + 11LL);
            _3607 = NOVALUE;
            _3609 = _i_6746 + 1;
            _2 = (object)SEQ_PTR(_sl_6725);
            _3610 = (object)*(((s1_ptr)_2)->base + _3609);
            if (IS_SEQUENCE(_lPath_6579)){
                    _3611 = SEQ_PTR(_lPath_6579)->length;
            }
            else {
                _3611 = 1;
            }
            rhs_slice_target = (object_ptr)&_3612;
            RHS_Slice(_lPath_6579, _3610, _3611);
            {
                object concat_list[3];

                concat_list[0] = _3612;
                concat_list[1] = _3608;
                concat_list[2] = _3606;
                Concat_N((object_ptr)&_lPath_6579, concat_list, 3);
            }
            DeRefDS(_3612);
            _3612 = NOVALUE;
            _3608 = NOVALUE;
            DeRefDS(_3606);
            _3606 = NOVALUE;

            /** filesys.e:1775							sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6725)){
                    _3614 = SEQ_PTR(_sl_6725)->length;
            }
            else {
                _3614 = 1;
            }
            if (IS_SEQUENCE(_lPath_6579)){
                    _3615 = SEQ_PTR(_lPath_6579)->length;
            }
            else {
                _3615 = 1;
            }
            _3616 = _3615 + 1;
            _3615 = NOVALUE;
            _2 = (object)SEQ_PTR(_sl_6725);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _sl_6725 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _3614);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _3616;
            if( _1 != _3616 ){
                DeRef(_1);
            }
            _3616 = NOVALUE;
L34: 

            /** filesys.e:1777						if correct_name then*/
            if (_correct_name_6731 == 0)
            {
                goto L35; // [1212] 1249
            }
            else{
            }

            /** filesys.e:1778							lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (object)SEQ_PTR(_sl_6725);
            _3617 = (object)*(((s1_ptr)_2)->base + _i_6746);
            rhs_slice_target = (object_ptr)&_3618;
            RHS_Slice(_lPath_6579, 1LL, _3617);
            _3619 = _i_6746 + 1;
            _2 = (object)SEQ_PTR(_sl_6725);
            _3620 = (object)*(((s1_ptr)_2)->base + _3619);
            if (IS_SEQUENCE(_lPath_6579)){
                    _3621 = SEQ_PTR(_lPath_6579)->length;
            }
            else {
                _3621 = 1;
            }
            rhs_slice_target = (object_ptr)&_3622;
            RHS_Slice(_lPath_6579, _3620, _3621);
            {
                object concat_list[3];

                concat_list[0] = _3622;
                concat_list[1] = _read_name_6804;
                concat_list[2] = _3618;
                Concat_N((object_ptr)&_lPath_6579, concat_list, 3);
            }
            DeRefDS(_3622);
            _3622 = NOVALUE;
            DeRefDS(_3618);
            _3618 = NOVALUE;
L35: 

            /** filesys.e:1780						continue "partloop"*/
            DeRef(_read_name_6804);
            _read_name_6804 = NOVALUE;
            DeRef(_part_6750);
            _part_6750 = NOVALUE;
            DeRef(_list_6755);
            _list_6755 = NOVALUE;
            DeRef(_supplied_name_6760);
            _supplied_name_6760 = NOVALUE;
            goto L2C; // [1255] 1322
L33: 
            DeRef(_read_name_6804);
            _read_name_6804 = NOVALUE;

            /** filesys.e:1782				end for*/
            _j_6802 = _j_6802 + 1LL;
            goto L31; // [1262] 1102
L32: 
            ;
        }

        /** filesys.e:1786				if and_bits(TO_LOWER,case_flags) then*/
        {uintptr_t tu;
             tu = (uintptr_t)1LL & (uintptr_t)_case_flags_6578;
             _3624 = MAKE_UINT(tu);
        }
        if (_3624 == 0) {
            DeRef(_3624);
            _3624 = NOVALUE;
            goto L36; // [1273] 1312
        }
        else {
            if (!IS_ATOM_INT(_3624) && DBL_PTR(_3624)->dbl == 0.0){
                DeRef(_3624);
                _3624 = NOVALUE;
                goto L36; // [1273] 1312
            }
            DeRef(_3624);
            _3624 = NOVALUE;
        }
        DeRef(_3624);
        _3624 = NOVALUE;

        /** filesys.e:1787					lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (object)SEQ_PTR(_sl_6725);
        _3625 = (object)*(((s1_ptr)_2)->base + _i_6746);
        if (IS_ATOM_INT(_3625)) {
            _3626 = _3625 - 1LL;
        }
        else {
            _3626 = binary_op(MINUS, _3625, 1LL);
        }
        _3625 = NOVALUE;
        rhs_slice_target = (object_ptr)&_3627;
        RHS_Slice(_lPath_6579, 1LL, _3626);
        _2 = (object)SEQ_PTR(_sl_6725);
        _3628 = (object)*(((s1_ptr)_2)->base + _i_6746);
        if (IS_SEQUENCE(_lPath_6579)){
                _3629 = SEQ_PTR(_lPath_6579)->length;
        }
        else {
            _3629 = 1;
        }
        rhs_slice_target = (object_ptr)&_3630;
        RHS_Slice(_lPath_6579, _3628, _3629);
        _3631 = _14lower(_3630);
        _3630 = NOVALUE;
        if (IS_SEQUENCE(_3627) && IS_ATOM(_3631)) {
            Ref(_3631);
            Append(&_lPath_6579, _3627, _3631);
        }
        else if (IS_ATOM(_3627) && IS_SEQUENCE(_3631)) {
        }
        else {
            Concat((object_ptr)&_lPath_6579, _3627, _3631);
            DeRefDS(_3627);
            _3627 = NOVALUE;
        }
        DeRef(_3627);
        _3627 = NOVALUE;
        DeRef(_3631);
        _3631 = NOVALUE;
L36: 

        /** filesys.e:1789				exit*/
        DeRef(_part_6750);
        _part_6750 = NOVALUE;
        DeRef(_list_6755);
        _list_6755 = NOVALUE;
        DeRef(_supplied_name_6760);
        _supplied_name_6760 = NOVALUE;
        goto L29; // [1316] 1327

        /** filesys.e:1790			end for*/
L2C: 
        _i_6746 = _i_6746 + -1LL;
        goto L28; // [1322] 843
L29: 
        ;
    }

    /** filesys.e:1791			if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {uintptr_t tu;
         tu = (uintptr_t)2LL | (uintptr_t)1LL;
         _3633 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3633)) {
        {uintptr_t tu;
             tu = (uintptr_t)_case_flags_6578 & (uintptr_t)_3633;
             _3634 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)_case_flags_6578;
        _3634 = Dand_bits(&temp_d, DBL_PTR(_3633));
    }
    DeRef(_3633);
    _3633 = NOVALUE;
    if (IS_ATOM_INT(_3634)) {
        _3635 = (_3634 == 1LL);
    }
    else {
        _3635 = (DBL_PTR(_3634)->dbl == (eudouble)1LL);
    }
    DeRef(_3634);
    _3634 = NOVALUE;
    if (_3635 == 0) {
        goto L37; // [1341] 1361
    }
    if (IS_SEQUENCE(_lPath_6579)){
            _3637 = SEQ_PTR(_lPath_6579)->length;
    }
    else {
        _3637 = 1;
    }
    if (_3637 == 0)
    {
        _3637 = NOVALUE;
        goto L37; // [1349] 1361
    }
    else{
        _3637 = NOVALUE;
    }

    /** filesys.e:1792				lPath = lower(lPath)*/
    RefDS(_lPath_6579);
    _0 = _lPath_6579;
    _lPath_6579 = _14lower(_lPath_6579);
    DeRefDS(_0);
L37: 
L26: 
    DeRef(_sl_6725);
    _sl_6725 = NOVALUE;
L25: 

    /** filesys.e:1796		ifdef WINDOWS then*/

    /** filesys.e:1797			if and_bits(CORRECT,case_flags) then*/
    {uintptr_t tu;
         tu = (uintptr_t)2LL & (uintptr_t)_case_flags_6578;
         _3639 = MAKE_UINT(tu);
    }
    if (_3639 == 0) {
        DeRef(_3639);
        _3639 = NOVALUE;
        goto L38; // [1373] 1415
    }
    else {
        if (!IS_ATOM_INT(_3639) && DBL_PTR(_3639)->dbl == 0.0){
            DeRef(_3639);
            _3639 = NOVALUE;
            goto L38; // [1373] 1415
        }
        DeRef(_3639);
        _3639 = NOVALUE;
    }
    DeRef(_3639);
    _3639 = NOVALUE;

    /** filesys.e:1799				if or_bits(system_drive_case,'A') = 'a' then*/
    if (IS_ATOM_INT(_17system_drive_case_6562)) {
        {uintptr_t tu;
             tu = (uintptr_t)_17system_drive_case_6562 | (uintptr_t)65LL;
             _3640 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (eudouble)65LL;
        _3640 = Dor_bits(DBL_PTR(_17system_drive_case_6562), &temp_d);
    }
    if (binary_op_a(NOTEQ, _3640, 97LL)){
        DeRef(_3640);
        _3640 = NOVALUE;
        goto L39; // [1384] 1401
    }
    DeRef(_3640);
    _3640 = NOVALUE;

    /** filesys.e:1800					lDrive = lower(lDrive)*/
    RefDS(_lDrive_6584);
    _0 = _lDrive_6584;
    _lDrive_6584 = _14lower(_lDrive_6584);
    DeRefDS(_0);
    goto L3A; // [1398] 1436
L39: 

    /** filesys.e:1802					lDrive = upper(lDrive)*/
    RefDS(_lDrive_6584);
    _0 = _lDrive_6584;
    _lDrive_6584 = _14upper(_lDrive_6584);
    DeRefDS(_0);
    goto L3A; // [1412] 1436
L38: 

    /** filesys.e:1804			elsif and_bits(TO_LOWER,case_flags) then*/
    {uintptr_t tu;
         tu = (uintptr_t)1LL & (uintptr_t)_case_flags_6578;
         _3644 = MAKE_UINT(tu);
    }
    if (_3644 == 0) {
        DeRef(_3644);
        _3644 = NOVALUE;
        goto L3B; // [1421] 1435
    }
    else {
        if (!IS_ATOM_INT(_3644) && DBL_PTR(_3644)->dbl == 0.0){
            DeRef(_3644);
            _3644 = NOVALUE;
            goto L3B; // [1421] 1435
        }
        DeRef(_3644);
        _3644 = NOVALUE;
    }
    DeRef(_3644);
    _3644 = NOVALUE;

    /** filesys.e:1805				lDrive = lower(lDrive)*/
    RefDS(_lDrive_6584);
    _0 = _lDrive_6584;
    _lDrive_6584 = _14lower(_lDrive_6584);
    DeRefDS(_0);
L3B: 
L3A: 

    /** filesys.e:1807			lPath = lDrive & lPath*/
    Concat((object_ptr)&_lPath_6579, _lDrive_6584, _lPath_6579);

    /** filesys.e:1810		return lPath & wildcard_suffix*/
    Concat((object_ptr)&_3647, _lPath_6579, _wildcard_suffix_6649);
    DeRefDS(_path_in_6576);
    DeRefDS(_lPath_6579);
    DeRefi(_lLevel_6582);
    DeRef(_lHome_6583);
    DeRefDS(_lDrive_6584);
    DeRefDS(_wildcard_suffix_6649);
    DeRef(_3567);
    _3567 = NOVALUE;
    _3570 = NOVALUE;
    _3588 = NOVALUE;
    _3583 = NOVALUE;
    DeRef(_3532);
    _3532 = NOVALUE;
    DeRef(_3587);
    _3587 = NOVALUE;
    DeRef(_3609);
    _3609 = NOVALUE;
    DeRef(_3565);
    _3565 = NOVALUE;
    DeRef(_3440);
    _3440 = NOVALUE;
    _3628 = NOVALUE;
    _3617 = NOVALUE;
    _3610 = NOVALUE;
    _3620 = NOVALUE;
    DeRef(_3449);
    _3449 = NOVALUE;
    DeRef(_3437);
    _3437 = NOVALUE;
    DeRef(_3529);
    _3529 = NOVALUE;
    DeRef(_3492);
    _3492 = NOVALUE;
    DeRef(_3509);
    _3509 = NOVALUE;
    DeRef(_3446);
    _3446 = NOVALUE;
    DeRef(_3477);
    _3477 = NOVALUE;
    DeRef(_3497);
    _3497 = NOVALUE;
    DeRef(_3444);
    _3444 = NOVALUE;
    DeRef(_3480);
    _3480 = NOVALUE;
    DeRef(_3635);
    _3635 = NOVALUE;
    DeRef(_3506);
    _3506 = NOVALUE;
    DeRef(_3559);
    _3559 = NOVALUE;
    DeRef(_3519);
    _3519 = NOVALUE;
    DeRef(_3452);
    _3452 = NOVALUE;
    DeRef(_3619);
    _3619 = NOVALUE;
    DeRef(_3626);
    _3626 = NOVALUE;
    DeRef(_3515);
    _3515 = NOVALUE;
    DeRef(_3564);
    _3564 = NOVALUE;
    DeRef(_3466);
    _3466 = NOVALUE;
    DeRef(_3556);
    _3556 = NOVALUE;
    _3605 = NOVALUE;
    return _3647;
    ;
}


object _17fs_case(object _s_6875)
{
    object _3648 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1825		ifdef WINDOWS then*/

    /** filesys.e:1826			return lower(s)*/
    RefDS(_s_6875);
    _3648 = _14lower(_s_6875);
    DeRefDS(_s_6875);
    return _3648;
    ;
}


object _17abbreviate_path(object _orig_path_6880, object _base_paths_6881)
{
    object _expanded_path_6882 = NOVALUE;
    object _lowered_expanded_path_6892 = NOVALUE;
    object _3693 = NOVALUE;
    object _3692 = NOVALUE;
    object _3689 = NOVALUE;
    object _3688 = NOVALUE;
    object _3687 = NOVALUE;
    object _3686 = NOVALUE;
    object _3685 = NOVALUE;
    object _3683 = NOVALUE;
    object _3682 = NOVALUE;
    object _3681 = NOVALUE;
    object _3680 = NOVALUE;
    object _3679 = NOVALUE;
    object _3678 = NOVALUE;
    object _3677 = NOVALUE;
    object _3676 = NOVALUE;
    object _3675 = NOVALUE;
    object _3672 = NOVALUE;
    object _3671 = NOVALUE;
    object _3669 = NOVALUE;
    object _3668 = NOVALUE;
    object _3667 = NOVALUE;
    object _3666 = NOVALUE;
    object _3665 = NOVALUE;
    object _3664 = NOVALUE;
    object _3663 = NOVALUE;
    object _3662 = NOVALUE;
    object _3661 = NOVALUE;
    object _3660 = NOVALUE;
    object _3659 = NOVALUE;
    object _3658 = NOVALUE;
    object _3657 = NOVALUE;
    object _3654 = NOVALUE;
    object _3653 = NOVALUE;
    object _3652 = NOVALUE;
    object _3650 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:1881		expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_6880);
    _0 = _expanded_path_6882;
    _expanded_path_6882 = _17canonical_path(_orig_path_6880, 0LL, 0LL);
    DeRef(_0);

    /** filesys.e:1884		base_paths = append(base_paths, curdir())*/
    _3650 = _17curdir(0LL);
    Ref(_3650);
    Append(&_base_paths_6881, _base_paths_6881, _3650);
    DeRef(_3650);
    _3650 = NOVALUE;

    /** filesys.e:1886		for i = 1 to length(base_paths) do*/
    _3652 = 1;
    {
        object _i_6887;
        _i_6887 = 1LL;
L1: 
        if (_i_6887 > 1LL){
            goto L2; // [30] 60
        }

        /** filesys.e:1887			base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (object)SEQ_PTR(_base_paths_6881);
        _3653 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_3653);
        _3654 = _17canonical_path(_3653, 1LL, 0LL);
        _3653 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_6881);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _base_paths_6881 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3654;
        if( _1 != _3654 ){
            DeRef(_1);
        }
        _3654 = NOVALUE;

        /** filesys.e:1888		end for*/
        _i_6887 = 1LL + 1LL;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** filesys.e:1892		base_paths = fs_case(base_paths)*/
    RefDS(_base_paths_6881);
    _0 = _base_paths_6881;
    _base_paths_6881 = _17fs_case(_base_paths_6881);
    DeRefDS(_0);

    /** filesys.e:1893		sequence lowered_expanded_path = fs_case(expanded_path)*/
    RefDS(_expanded_path_6882);
    _0 = _lowered_expanded_path_6892;
    _lowered_expanded_path_6892 = _17fs_case(_expanded_path_6882);
    DeRef(_0);

    /** filesys.e:1896		for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_6881)){
            _3657 = SEQ_PTR(_base_paths_6881)->length;
    }
    else {
        _3657 = 1;
    }
    {
        object _i_6895;
        _i_6895 = 1LL;
L3: 
        if (_i_6895 > _3657){
            goto L4; // [81] 135
        }

        /** filesys.e:1897			if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (object)SEQ_PTR(_base_paths_6881);
        _3658 = (object)*(((s1_ptr)_2)->base + _i_6895);
        Ref(_3658);
        RefDS(_lowered_expanded_path_6892);
        _3659 = _16begins(_3658, _lowered_expanded_path_6892);
        _3658 = NOVALUE;
        if (_3659 == 0) {
            DeRef(_3659);
            _3659 = NOVALUE;
            goto L5; // [99] 128
        }
        else {
            if (!IS_ATOM_INT(_3659) && DBL_PTR(_3659)->dbl == 0.0){
                DeRef(_3659);
                _3659 = NOVALUE;
                goto L5; // [99] 128
            }
            DeRef(_3659);
            _3659 = NOVALUE;
        }
        DeRef(_3659);
        _3659 = NOVALUE;

        /** filesys.e:1899				return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (object)SEQ_PTR(_base_paths_6881);
        _3660 = (object)*(((s1_ptr)_2)->base + _i_6895);
        if (IS_SEQUENCE(_3660)){
                _3661 = SEQ_PTR(_3660)->length;
        }
        else {
            _3661 = 1;
        }
        _3660 = NOVALUE;
        _3662 = _3661 + 1;
        _3661 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6882)){
                _3663 = SEQ_PTR(_expanded_path_6882)->length;
        }
        else {
            _3663 = 1;
        }
        rhs_slice_target = (object_ptr)&_3664;
        RHS_Slice(_expanded_path_6882, _3662, _3663);
        DeRefDS(_orig_path_6880);
        DeRefDS(_base_paths_6881);
        DeRefDS(_expanded_path_6882);
        DeRefDS(_lowered_expanded_path_6892);
        _3660 = NOVALUE;
        _3662 = NOVALUE;
        return _3664;
L5: 

        /** filesys.e:1901		end for*/
        _i_6895 = _i_6895 + 1LL;
        goto L3; // [130] 88
L4: 
        ;
    }

    /** filesys.e:1904		ifdef WINDOWS then*/

    /** filesys.e:1906			if not equal(base_paths[$][1], lowered_expanded_path[1]) then*/
    if (IS_SEQUENCE(_base_paths_6881)){
            _3665 = SEQ_PTR(_base_paths_6881)->length;
    }
    else {
        _3665 = 1;
    }
    _2 = (object)SEQ_PTR(_base_paths_6881);
    _3666 = (object)*(((s1_ptr)_2)->base + _3665);
    _2 = (object)SEQ_PTR(_3666);
    _3667 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3666 = NOVALUE;
    _2 = (object)SEQ_PTR(_lowered_expanded_path_6892);
    _3668 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3667 == _3668)
    _3669 = 1;
    else if (IS_ATOM_INT(_3667) && IS_ATOM_INT(_3668))
    _3669 = 0;
    else
    _3669 = (compare(_3667, _3668) == 0);
    _3667 = NOVALUE;
    _3668 = NOVALUE;
    if (_3669 != 0)
    goto L6; // [158] 168
    _3669 = NOVALUE;

    /** filesys.e:1907				return orig_path*/
    DeRefDS(_base_paths_6881);
    DeRef(_expanded_path_6882);
    DeRefDS(_lowered_expanded_path_6892);
    _3660 = NOVALUE;
    DeRef(_3662);
    _3662 = NOVALUE;
    DeRef(_3664);
    _3664 = NOVALUE;
    return _orig_path_6880;
L6: 

    /** filesys.e:1912		base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_6881)){
            _3671 = SEQ_PTR(_base_paths_6881)->length;
    }
    else {
        _3671 = 1;
    }
    _2 = (object)SEQ_PTR(_base_paths_6881);
    _3672 = (object)*(((s1_ptr)_2)->base + _3671);
    Ref(_3672);
    _0 = _base_paths_6881;
    _base_paths_6881 = _23split(_3672, 92LL, 0LL, 0LL);
    DeRefDS(_0);
    _3672 = NOVALUE;

    /** filesys.e:1914		expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_6882);
    _0 = _expanded_path_6882;
    _expanded_path_6882 = _23split(_expanded_path_6882, 92LL, 0LL, 0LL);
    DeRefDS(_0);

    /** filesys.e:1915		lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_6892);
    _lowered_expanded_path_6892 = _5;

    /** filesys.e:1918		for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_6882)){
            _3675 = SEQ_PTR(_expanded_path_6882)->length;
    }
    else {
        _3675 = 1;
    }
    if (IS_SEQUENCE(_base_paths_6881)){
            _3676 = SEQ_PTR(_base_paths_6881)->length;
    }
    else {
        _3676 = 1;
    }
    _3677 = _3676 - 1LL;
    _3676 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _3675;
    ((intptr_t *)_2)[2] = _3677;
    _3678 = MAKE_SEQ(_1);
    _3677 = NOVALUE;
    _3675 = NOVALUE;
    _3679 = _20min(_3678);
    _3678 = NOVALUE;
    {
        object _i_6917;
        _i_6917 = 1LL;
L7: 
        if (binary_op_a(GREATER, _i_6917, _3679)){
            goto L8; // [224] 317
        }

        /** filesys.e:1919			if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (object)SEQ_PTR(_expanded_path_6882);
        if (!IS_ATOM_INT(_i_6917)){
            _3680 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_6917)->dbl));
        }
        else{
            _3680 = (object)*(((s1_ptr)_2)->base + _i_6917);
        }
        Ref(_3680);
        _3681 = _17fs_case(_3680);
        _3680 = NOVALUE;
        _2 = (object)SEQ_PTR(_base_paths_6881);
        if (!IS_ATOM_INT(_i_6917)){
            _3682 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_6917)->dbl));
        }
        else{
            _3682 = (object)*(((s1_ptr)_2)->base + _i_6917);
        }
        if (_3681 == _3682)
        _3683 = 1;
        else if (IS_ATOM_INT(_3681) && IS_ATOM_INT(_3682))
        _3683 = 0;
        else
        _3683 = (compare(_3681, _3682) == 0);
        DeRef(_3681);
        _3681 = NOVALUE;
        _3682 = NOVALUE;
        if (_3683 != 0)
        goto L9; // [249] 310
        _3683 = NOVALUE;

        /** filesys.e:1923				expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_6881)){
                _3685 = SEQ_PTR(_base_paths_6881)->length;
        }
        else {
            _3685 = 1;
        }
        if (IS_ATOM_INT(_i_6917)) {
            _3686 = _3685 - _i_6917;
        }
        else {
            _3686 = NewDouble((eudouble)_3685 - DBL_PTR(_i_6917)->dbl);
        }
        _3685 = NOVALUE;
        _3687 = Repeat(_3201, _3686);
        DeRef(_3686);
        _3686 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6882)){
                _3688 = SEQ_PTR(_expanded_path_6882)->length;
        }
        else {
            _3688 = 1;
        }
        rhs_slice_target = (object_ptr)&_3689;
        RHS_Slice(_expanded_path_6882, _i_6917, _3688);
        Concat((object_ptr)&_expanded_path_6882, _3687, _3689);
        DeRefDS(_3687);
        _3687 = NOVALUE;
        DeRef(_3687);
        _3687 = NOVALUE;
        DeRefDS(_3689);
        _3689 = NOVALUE;

        /** filesys.e:1924				expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_6882);
        _0 = _expanded_path_6882;
        _expanded_path_6882 = _23join(_expanded_path_6882, 92LL);
        DeRefDS(_0);

        /** filesys.e:1925				if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_6882)){
                _3692 = SEQ_PTR(_expanded_path_6882)->length;
        }
        else {
            _3692 = 1;
        }
        if (IS_SEQUENCE(_orig_path_6880)){
                _3693 = SEQ_PTR(_orig_path_6880)->length;
        }
        else {
            _3693 = 1;
        }
        if (_3692 >= _3693)
        goto L8; // [294] 317

        /** filesys.e:1927			  		return expanded_path*/
        DeRef(_i_6917);
        DeRefDS(_orig_path_6880);
        DeRefDS(_base_paths_6881);
        DeRef(_lowered_expanded_path_6892);
        _3660 = NOVALUE;
        DeRef(_3662);
        _3662 = NOVALUE;
        DeRef(_3664);
        _3664 = NOVALUE;
        DeRef(_3679);
        _3679 = NOVALUE;
        return _expanded_path_6882;

        /** filesys.e:1929				exit*/
        goto L8; // [307] 317
L9: 

        /** filesys.e:1931		end for*/
        _0 = _i_6917;
        if (IS_ATOM_INT(_i_6917)) {
            _i_6917 = _i_6917 + 1LL;
            if ((object)((uintptr_t)_i_6917 +(uintptr_t) HIGH_BITS) >= 0){
                _i_6917 = NewDouble((eudouble)_i_6917);
            }
        }
        else {
            _i_6917 = binary_op_a(PLUS, _i_6917, 1LL);
        }
        DeRef(_0);
        goto L7; // [312] 231
L8: 
        ;
        DeRef(_i_6917);
    }

    /** filesys.e:1934		return orig_path*/
    DeRefDS(_base_paths_6881);
    DeRef(_expanded_path_6882);
    DeRef(_lowered_expanded_path_6892);
    _3660 = NOVALUE;
    DeRef(_3662);
    _3662 = NOVALUE;
    DeRef(_3664);
    _3664 = NOVALUE;
    DeRef(_3679);
    _3679 = NOVALUE;
    return _orig_path_6880;
    ;
}


object _17file_type(object _filename_6977)
{
    object _dirfil_6978 = NOVALUE;
    object _dir_inlined_dir_at_64_6991 = NOVALUE;
    object _3734 = NOVALUE;
    object _3733 = NOVALUE;
    object _3732 = NOVALUE;
    object _3731 = NOVALUE;
    object _3730 = NOVALUE;
    object _3728 = NOVALUE;
    object _3727 = NOVALUE;
    object _3726 = NOVALUE;
    object _3725 = NOVALUE;
    object _3724 = NOVALUE;
    object _3723 = NOVALUE;
    object _3722 = NOVALUE;
    object _3720 = NOVALUE;
    object _3719 = NOVALUE;
    object _3718 = NOVALUE;
    object _3717 = NOVALUE;
    object _3716 = NOVALUE;
    object _3715 = NOVALUE;
    object _3713 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2040		if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _3713 = find_from(42LL, _filename_6977, 1LL);
    if (_3713 != 0) {
        goto L1; // [10] 24
    }
    _3715 = find_from(63LL, _filename_6977, 1LL);
    if (_3715 == 0)
    {
        _3715 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _3715 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_6977);
    DeRef(_dirfil_6978);
    return -1LL;
L2: 

    /** filesys.e:2042		ifdef WINDOWS then*/

    /** filesys.e:2043			if length(filename) = 2 and filename[2] = ':' then*/
    if (IS_SEQUENCE(_filename_6977)){
            _3716 = SEQ_PTR(_filename_6977)->length;
    }
    else {
        _3716 = 1;
    }
    _3717 = (_3716 == 2LL);
    _3716 = NOVALUE;
    if (_3717 == 0) {
        goto L3; // [40] 63
    }
    _2 = (object)SEQ_PTR(_filename_6977);
    _3719 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3719)) {
        _3720 = (_3719 == 58LL);
    }
    else {
        _3720 = binary_op(EQUALS, _3719, 58LL);
    }
    _3719 = NOVALUE;
    if (_3720 == 0) {
        DeRef(_3720);
        _3720 = NOVALUE;
        goto L3; // [53] 63
    }
    else {
        if (!IS_ATOM_INT(_3720) && DBL_PTR(_3720)->dbl == 0.0){
            DeRef(_3720);
            _3720 = NOVALUE;
            goto L3; // [53] 63
        }
        DeRef(_3720);
        _3720 = NOVALUE;
    }
    DeRef(_3720);
    _3720 = NOVALUE;

    /** filesys.e:2044				filename &= "\\"*/
    Concat((object_ptr)&_filename_6977, _filename_6977, _964);
L3: 

    /** filesys.e:2048		dirfil = dir(filename)*/

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    DeRef(_dirfil_6978);
    _dirfil_6978 = machine(22LL, _filename_6977);

    /** filesys.e:2049		if sequence(dirfil) then*/
    _3722 = IS_SEQUENCE(_dirfil_6978);
    if (_3722 == 0)
    {
        _3722 = NOVALUE;
        goto L4; // [79] 163
    }
    else{
        _3722 = NOVALUE;
    }

    /** filesys.e:2050			if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_6978)){
            _3723 = SEQ_PTR(_dirfil_6978)->length;
    }
    else {
        _3723 = 1;
    }
    _3724 = (_3723 > 1LL);
    _3723 = NOVALUE;
    if (_3724 != 0) {
        _3725 = 1;
        goto L5; // [91] 112
    }
    _2 = (object)SEQ_PTR(_dirfil_6978);
    _3726 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3726);
    _3727 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3726 = NOVALUE;
    _3728 = find_from(100LL, _3727, 1LL);
    _3727 = NOVALUE;
    _3725 = (_3728 != 0);
L5: 
    if (_3725 != 0) {
        goto L6; // [112] 144
    }
    if (IS_SEQUENCE(_filename_6977)){
            _3730 = SEQ_PTR(_filename_6977)->length;
    }
    else {
        _3730 = 1;
    }
    _3731 = (_3730 == 3LL);
    _3730 = NOVALUE;
    if (_3731 == 0) {
        DeRef(_3732);
        _3732 = 0;
        goto L7; // [123] 139
    }
    _2 = (object)SEQ_PTR(_filename_6977);
    _3733 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_3733)) {
        _3734 = (_3733 == 58LL);
    }
    else {
        _3734 = binary_op(EQUALS, _3733, 58LL);
    }
    _3733 = NOVALUE;
    if (IS_ATOM_INT(_3734))
    _3732 = (_3734 != 0);
    else
    _3732 = DBL_PTR(_3734)->dbl != 0.0;
L7: 
    if (_3732 == 0)
    {
        _3732 = NOVALUE;
        goto L8; // [140] 153
    }
    else{
        _3732 = NOVALUE;
    }
L6: 

    /** filesys.e:2051				return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_6977);
    DeRef(_dirfil_6978);
    DeRef(_3731);
    _3731 = NOVALUE;
    DeRef(_3734);
    _3734 = NOVALUE;
    DeRef(_3724);
    _3724 = NOVALUE;
    DeRef(_3717);
    _3717 = NOVALUE;
    return 2LL;
    goto L9; // [150] 170
L8: 

    /** filesys.e:2053				return FILETYPE_FILE*/
    DeRefDS(_filename_6977);
    DeRef(_dirfil_6978);
    DeRef(_3731);
    _3731 = NOVALUE;
    DeRef(_3734);
    _3734 = NOVALUE;
    DeRef(_3724);
    _3724 = NOVALUE;
    DeRef(_3717);
    _3717 = NOVALUE;
    return 1LL;
    goto L9; // [160] 170
L4: 

    /** filesys.e:2056			return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_6977);
    DeRef(_dirfil_6978);
    DeRef(_3731);
    _3731 = NOVALUE;
    DeRef(_3734);
    _3734 = NOVALUE;
    DeRef(_3724);
    _3724 = NOVALUE;
    DeRef(_3717);
    _3717 = NOVALUE;
    return 0LL;
L9: 
    ;
}


object _17file_exists(object _name_7025)
{
    object _pName_7028 = NOVALUE;
    object _r_7031 = NOVALUE;
    object _3739 = NOVALUE;
    object _3737 = NOVALUE;
    object _3735 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2103		if atom(name) then*/
    _3735 = IS_ATOM(_name_7025);
    if (_3735 == 0)
    {
        _3735 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _3735 = NOVALUE;
    }

    /** filesys.e:2104			return 0*/
    DeRef(_name_7025);
    DeRef(_pName_7028);
    DeRef(_r_7031);
    return 0LL;
L1: 

    /** filesys.e:2107		ifdef WINDOWS then*/

    /** filesys.e:2108			atom pName = allocate_string(name)*/
    Ref(_name_7025);
    _0 = _pName_7028;
    _pName_7028 = _9allocate_string(_name_7025, 0LL);
    DeRef(_0);

    /** filesys.e:2109			atom r = c_func(xGetFileAttributes, {pName})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_pName_7028);
    ((intptr_t*)_2)[1] = _pName_7028;
    _3737 = MAKE_SEQ(_1);
    DeRef(_r_7031);
    _r_7031 = call_c(1, _17xGetFileAttributes_6020, _3737);
    DeRefDS(_3737);
    _3737 = NOVALUE;

    /** filesys.e:2110			free(pName)*/
    Ref(_pName_7028);
    _9free(_pName_7028);

    /** filesys.e:2112			return r > 0*/
    if (IS_ATOM_INT(_r_7031)) {
        _3739 = (_r_7031 > 0LL);
    }
    else {
        _3739 = (DBL_PTR(_r_7031)->dbl > (eudouble)0LL);
    }
    DeRef(_name_7025);
    DeRef(_pName_7028);
    DeRef(_r_7031);
    return _3739;
    ;
}


object _17file_timestamp(object _fname_7038)
{
    object _d_7039 = NOVALUE;
    object _dir_inlined_dir_at_4_7041 = NOVALUE;
    object _3753 = NOVALUE;
    object _3752 = NOVALUE;
    object _3751 = NOVALUE;
    object _3750 = NOVALUE;
    object _3749 = NOVALUE;
    object _3748 = NOVALUE;
    object _3747 = NOVALUE;
    object _3746 = NOVALUE;
    object _3745 = NOVALUE;
    object _3744 = NOVALUE;
    object _3743 = NOVALUE;
    object _3742 = NOVALUE;
    object _3741 = NOVALUE;
    object _3740 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2139		object d = dir(fname)*/

    /** filesys.e:358		ifdef WINDOWS then*/

    /** filesys.e:359			return machine_func(M_DIR, name)*/
    DeRef(_d_7039);
    _d_7039 = machine(22LL, _fname_7038);

    /** filesys.e:2140		if atom(d) then return -1 end if*/
    _3740 = IS_ATOM(_d_7039);
    if (_3740 == 0)
    {
        _3740 = NOVALUE;
        goto L1; // [19] 27
    }
    else{
        _3740 = NOVALUE;
    }
    DeRefDS(_fname_7038);
    DeRef(_d_7039);
    return -1LL;
L1: 

    /** filesys.e:2142		return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (object)SEQ_PTR(_d_7039);
    _3741 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3741);
    _3742 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3741 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_7039);
    _3743 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3743);
    _3744 = (object)*(((s1_ptr)_2)->base + 5LL);
    _3743 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_7039);
    _3745 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3745);
    _3746 = (object)*(((s1_ptr)_2)->base + 6LL);
    _3745 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_7039);
    _3747 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3747);
    _3748 = (object)*(((s1_ptr)_2)->base + 7LL);
    _3747 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_7039);
    _3749 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3749);
    _3750 = (object)*(((s1_ptr)_2)->base + 8LL);
    _3749 = NOVALUE;
    _2 = (object)SEQ_PTR(_d_7039);
    _3751 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_3751);
    _3752 = (object)*(((s1_ptr)_2)->base + 9LL);
    _3751 = NOVALUE;
    Ref(_3742);
    Ref(_3744);
    Ref(_3746);
    Ref(_3748);
    Ref(_3750);
    Ref(_3752);
    _3753 = _18new(_3742, _3744, _3746, _3748, _3750, _3752);
    _3742 = NOVALUE;
    _3744 = NOVALUE;
    _3746 = NOVALUE;
    _3748 = NOVALUE;
    _3750 = NOVALUE;
    _3752 = NOVALUE;
    DeRefDS(_fname_7038);
    DeRef(_d_7039);
    return _3753;
    ;
}


object _17locate_file(object _filename_7172, object _search_list_7173, object _subdir_7174)
{
    object _extra_paths_7175 = NOVALUE;
    object _this_path_7176 = NOVALUE;
    object _3890 = NOVALUE;
    object _3889 = NOVALUE;
    object _3887 = NOVALUE;
    object _3885 = NOVALUE;
    object _3883 = NOVALUE;
    object _3882 = NOVALUE;
    object _3881 = NOVALUE;
    object _3879 = NOVALUE;
    object _3878 = NOVALUE;
    object _3877 = NOVALUE;
    object _3875 = NOVALUE;
    object _3874 = NOVALUE;
    object _3873 = NOVALUE;
    object _3870 = NOVALUE;
    object _3869 = NOVALUE;
    object _3867 = NOVALUE;
    object _3865 = NOVALUE;
    object _3864 = NOVALUE;
    object _3861 = NOVALUE;
    object _3856 = NOVALUE;
    object _3852 = NOVALUE;
    object _3846 = NOVALUE;
    object _3843 = NOVALUE;
    object _3840 = NOVALUE;
    object _3839 = NOVALUE;
    object _3835 = NOVALUE;
    object _3832 = NOVALUE;
    object _3830 = NOVALUE;
    object _3826 = NOVALUE;
    object _3824 = NOVALUE;
    object _3823 = NOVALUE;
    object _3821 = NOVALUE;
    object _3820 = NOVALUE;
    object _3817 = NOVALUE;
    object _3816 = NOVALUE;
    object _3813 = NOVALUE;
    object _3811 = NOVALUE;
    object _3810 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2525		if absolute_path(filename) then*/
    RefDS(_filename_7172);
    _3810 = _17absolute_path(_filename_7172);
    if (_3810 == 0) {
        DeRef(_3810);
        _3810 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_3810) && DBL_PTR(_3810)->dbl == 0.0){
            DeRef(_3810);
            _3810 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_3810);
        _3810 = NOVALUE;
    }
    DeRef(_3810);
    _3810 = NOVALUE;

    /** filesys.e:2526			return filename*/
    DeRefDS(_search_list_7173);
    DeRefDS(_subdir_7174);
    DeRef(_extra_paths_7175);
    DeRef(_this_path_7176);
    return _filename_7172;
L1: 

    /** filesys.e:2529		if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_7173)){
            _3811 = SEQ_PTR(_search_list_7173)->length;
    }
    else {
        _3811 = 1;
    }
    if (_3811 != 0LL)
    goto L2; // [28] 276

    /** filesys.e:2530			search_list = append(search_list, "." & SLASH)*/
    Append(&_3813, _3170, 92LL);
    RefDS(_3813);
    Append(&_search_list_7173, _search_list_7173, _3813);
    DeRefDS(_3813);
    _3813 = NOVALUE;

    /** filesys.e:2532			extra_paths = command_line()*/
    DeRef(_extra_paths_7175);
    _extra_paths_7175 = Command_Line();

    /** filesys.e:2533			extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (object)SEQ_PTR(_extra_paths_7175);
    _3816 = (object)*(((s1_ptr)_2)->base + 2LL);
    RefDS(_3816);
    _3817 = _17dirname(_3816, 0LL);
    _3816 = NOVALUE;
    _0 = _extra_paths_7175;
    _extra_paths_7175 = _17canonical_path(_3817, 1LL, 0LL);
    DeRefDS(_0);
    _3817 = NOVALUE;

    /** filesys.e:2534			search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_7175);
    Append(&_search_list_7173, _search_list_7173, _extra_paths_7175);

    /** filesys.e:2536			ifdef UNIX then*/

    /** filesys.e:2540				extra_paths = getenv("HOMEDRIVE") & getenv("HOMEPATH")*/
    _3820 = EGetEnv(_3456);
    _3821 = EGetEnv(_3458);
    if (IS_SEQUENCE(_3820) && IS_ATOM(_3821)) {
        Ref(_3821);
        Append(&_extra_paths_7175, _3820, _3821);
    }
    else if (IS_ATOM(_3820) && IS_SEQUENCE(_3821)) {
        Ref(_3820);
        Prepend(&_extra_paths_7175, _3821, _3820);
    }
    else {
        Concat((object_ptr)&_extra_paths_7175, _3820, _3821);
        DeRef(_3820);
        _3820 = NOVALUE;
    }
    DeRef(_3820);
    _3820 = NOVALUE;
    DeRef(_3821);
    _3821 = NOVALUE;

    /** filesys.e:2543			if sequence(extra_paths) then*/
    _3823 = 1;
    if (_3823 == 0)
    {
        _3823 = NOVALUE;
        goto L3; // [88] 102
    }
    else{
        _3823 = NOVALUE;
    }

    /** filesys.e:2544				search_list = append(search_list, extra_paths & SLASH)*/
    Append(&_3824, _extra_paths_7175, 92LL);
    RefDS(_3824);
    Append(&_search_list_7173, _search_list_7173, _3824);
    DeRefDS(_3824);
    _3824 = NOVALUE;
L3: 

    /** filesys.e:2547			search_list = append(search_list, ".." & SLASH)*/
    Append(&_3826, _3201, 92LL);
    RefDS(_3826);
    Append(&_search_list_7173, _search_list_7173, _3826);
    DeRefDS(_3826);
    _3826 = NOVALUE;

    /** filesys.e:2549			extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_7175);
    _extra_paths_7175 = EGetEnv(_3828);

    /** filesys.e:2550			if sequence(extra_paths) then*/
    _3830 = IS_SEQUENCE(_extra_paths_7175);
    if (_3830 == 0)
    {
        _3830 = NOVALUE;
        goto L4; // [122] 152
    }
    else{
        _3830 = NOVALUE;
    }

    /** filesys.e:2551				search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92LL;
        concat_list[1] = _3831;
        concat_list[2] = 92LL;
        concat_list[3] = _extra_paths_7175;
        Concat_N((object_ptr)&_3832, concat_list, 4);
    }
    RefDS(_3832);
    Append(&_search_list_7173, _search_list_7173, _3832);
    DeRefDS(_3832);
    _3832 = NOVALUE;

    /** filesys.e:2552				search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92LL;
        concat_list[1] = _3834;
        concat_list[2] = 92LL;
        concat_list[3] = _extra_paths_7175;
        Concat_N((object_ptr)&_3835, concat_list, 4);
    }
    RefDS(_3835);
    Append(&_search_list_7173, _search_list_7173, _3835);
    DeRefDS(_3835);
    _3835 = NOVALUE;
L4: 

    /** filesys.e:2555			extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_7175);
    _extra_paths_7175 = EGetEnv(_3837);

    /** filesys.e:2556			if sequence(extra_paths) then*/
    _3839 = IS_SEQUENCE(_extra_paths_7175);
    if (_3839 == 0)
    {
        _3839 = NOVALUE;
        goto L5; // [162] 202
    }
    else{
        _3839 = NOVALUE;
    }

    /** filesys.e:2557				search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_7175) && IS_ATOM(92LL)) {
        Append(&_3840, _extra_paths_7175, 92LL);
    }
    else if (IS_ATOM(_extra_paths_7175) && IS_SEQUENCE(92LL)) {
    }
    else {
        Concat((object_ptr)&_3840, _extra_paths_7175, 92LL);
    }
    RefDS(_3840);
    Append(&_search_list_7173, _search_list_7173, _3840);
    DeRefDS(_3840);
    _3840 = NOVALUE;

    /** filesys.e:2558				search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92LL;
        concat_list[1] = _3842;
        concat_list[2] = 92LL;
        concat_list[3] = _extra_paths_7175;
        Concat_N((object_ptr)&_3843, concat_list, 4);
    }
    RefDS(_3843);
    Append(&_search_list_7173, _search_list_7173, _3843);
    DeRefDS(_3843);
    _3843 = NOVALUE;

    /** filesys.e:2559				search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        object concat_list[4];

        concat_list[0] = 92LL;
        concat_list[1] = _3845;
        concat_list[2] = 92LL;
        concat_list[3] = _extra_paths_7175;
        Concat_N((object_ptr)&_3846, concat_list, 4);
    }
    RefDS(_3846);
    Append(&_search_list_7173, _search_list_7173, _3846);
    DeRefDS(_3846);
    _3846 = NOVALUE;
L5: 

    /** filesys.e:2562			ifdef UNIX then*/

    /** filesys.e:2568			search_list &= include_paths(1)*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_3851);
    ((intptr_t*)_2)[1] = _3851;
    RefDS(_3850);
    ((intptr_t*)_2)[2] = _3850;
    _3852 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_7173, _search_list_7173, _3852);
    DeRefDS(_3852);
    _3852 = NOVALUE;

    /** filesys.e:2571			extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_7175);
    _extra_paths_7175 = EGetEnv(_3854);

    /** filesys.e:2572			if sequence(extra_paths) then*/
    _3856 = IS_SEQUENCE(_extra_paths_7175);
    if (_3856 == 0)
    {
        _3856 = NOVALUE;
        goto L6; // [225] 244
    }
    else{
        _3856 = NOVALUE;
    }

    /** filesys.e:2573				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_7175);
    _0 = _extra_paths_7175;
    _extra_paths_7175 = _23split(_extra_paths_7175, 59LL, 0LL, 0LL);
    DeRefi(_0);

    /** filesys.e:2574				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_7173) && IS_ATOM(_extra_paths_7175)) {
        Ref(_extra_paths_7175);
        Append(&_search_list_7173, _search_list_7173, _extra_paths_7175);
    }
    else if (IS_ATOM(_search_list_7173) && IS_SEQUENCE(_extra_paths_7175)) {
    }
    else {
        Concat((object_ptr)&_search_list_7173, _search_list_7173, _extra_paths_7175);
    }
L6: 

    /** filesys.e:2577			extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_7175);
    _extra_paths_7175 = EGetEnv(_3859);

    /** filesys.e:2578			if sequence(extra_paths) then*/
    _3861 = IS_SEQUENCE(_extra_paths_7175);
    if (_3861 == 0)
    {
        _3861 = NOVALUE;
        goto L7; // [254] 301
    }
    else{
        _3861 = NOVALUE;
    }

    /** filesys.e:2579				extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_7175);
    _0 = _extra_paths_7175;
    _extra_paths_7175 = _23split(_extra_paths_7175, 59LL, 0LL, 0LL);
    DeRefi(_0);

    /** filesys.e:2580				search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_7173) && IS_ATOM(_extra_paths_7175)) {
        Ref(_extra_paths_7175);
        Append(&_search_list_7173, _search_list_7173, _extra_paths_7175);
    }
    else if (IS_ATOM(_search_list_7173) && IS_SEQUENCE(_extra_paths_7175)) {
    }
    else {
        Concat((object_ptr)&_search_list_7173, _search_list_7173, _extra_paths_7175);
    }
    goto L7; // [273] 301
L2: 

    /** filesys.e:2583			if integer(search_list[1]) then*/
    _2 = (object)SEQ_PTR(_search_list_7173);
    _3864 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_3864))
    _3865 = 1;
    else if (IS_ATOM_DBL(_3864))
    _3865 = IS_ATOM_INT(DoubleToInt(_3864));
    else
    _3865 = 0;
    _3864 = NOVALUE;
    if (_3865 == 0)
    {
        _3865 = NOVALUE;
        goto L8; // [285] 300
    }
    else{
        _3865 = NOVALUE;
    }

    /** filesys.e:2584				search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_7173);
    _0 = _search_list_7173;
    _search_list_7173 = _23split(_search_list_7173, 59LL, 0LL, 0LL);
    DeRefDS(_0);
L8: 
L7: 

    /** filesys.e:2588		if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_7174)){
            _3867 = SEQ_PTR(_subdir_7174)->length;
    }
    else {
        _3867 = 1;
    }
    if (_3867 <= 0LL)
    goto L9; // [306] 331

    /** filesys.e:2589			if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_7174)){
            _3869 = SEQ_PTR(_subdir_7174)->length;
    }
    else {
        _3869 = 1;
    }
    _2 = (object)SEQ_PTR(_subdir_7174);
    _3870 = (object)*(((s1_ptr)_2)->base + _3869);
    if (binary_op_a(EQUALS, _3870, 92LL)){
        _3870 = NOVALUE;
        goto LA; // [319] 330
    }
    _3870 = NOVALUE;

    /** filesys.e:2590				subdir &= SLASH*/
    Append(&_subdir_7174, _subdir_7174, 92LL);
LA: 
L9: 

    /** filesys.e:2594		for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_7173)){
            _3873 = SEQ_PTR(_search_list_7173)->length;
    }
    else {
        _3873 = 1;
    }
    {
        object _i_7252;
        _i_7252 = 1LL;
LB: 
        if (_i_7252 > _3873){
            goto LC; // [336] 459
        }

        /** filesys.e:2595			if length(search_list[i]) = 0 then*/
        _2 = (object)SEQ_PTR(_search_list_7173);
        _3874 = (object)*(((s1_ptr)_2)->base + _i_7252);
        if (IS_SEQUENCE(_3874)){
                _3875 = SEQ_PTR(_3874)->length;
        }
        else {
            _3875 = 1;
        }
        _3874 = NOVALUE;
        if (_3875 != 0LL)
        goto LD; // [352] 361

        /** filesys.e:2596				continue*/
        goto LE; // [358] 454
LD: 

        /** filesys.e:2599			if search_list[i][$] != SLASH then*/
        _2 = (object)SEQ_PTR(_search_list_7173);
        _3877 = (object)*(((s1_ptr)_2)->base + _i_7252);
        if (IS_SEQUENCE(_3877)){
                _3878 = SEQ_PTR(_3877)->length;
        }
        else {
            _3878 = 1;
        }
        _2 = (object)SEQ_PTR(_3877);
        _3879 = (object)*(((s1_ptr)_2)->base + _3878);
        _3877 = NOVALUE;
        if (binary_op_a(EQUALS, _3879, 92LL)){
            _3879 = NOVALUE;
            goto LF; // [374] 393
        }
        _3879 = NOVALUE;

        /** filesys.e:2600				search_list[i] &= SLASH*/
        _2 = (object)SEQ_PTR(_search_list_7173);
        _3881 = (object)*(((s1_ptr)_2)->base + _i_7252);
        if (IS_SEQUENCE(_3881) && IS_ATOM(92LL)) {
            Append(&_3882, _3881, 92LL);
        }
        else if (IS_ATOM(_3881) && IS_SEQUENCE(92LL)) {
        }
        else {
            Concat((object_ptr)&_3882, _3881, 92LL);
            _3881 = NOVALUE;
        }
        _3881 = NOVALUE;
        _2 = (object)SEQ_PTR(_search_list_7173);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _search_list_7173 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_7252);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _3882;
        if( _1 != _3882 ){
            DeRef(_1);
        }
        _3882 = NOVALUE;
LF: 

        /** filesys.e:2604			if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_7174)){
                _3883 = SEQ_PTR(_subdir_7174)->length;
        }
        else {
            _3883 = 1;
        }
        if (_3883 <= 0LL)
        goto L10; // [398] 417

        /** filesys.e:2605				this_path = search_list[i] & subdir & filename*/
        _2 = (object)SEQ_PTR(_search_list_7173);
        _3885 = (object)*(((s1_ptr)_2)->base + _i_7252);
        {
            object concat_list[3];

            concat_list[0] = _filename_7172;
            concat_list[1] = _subdir_7174;
            concat_list[2] = _3885;
            Concat_N((object_ptr)&_this_path_7176, concat_list, 3);
        }
        _3885 = NOVALUE;
        goto L11; // [414] 428
L10: 

        /** filesys.e:2607				this_path = search_list[i] & filename*/
        _2 = (object)SEQ_PTR(_search_list_7173);
        _3887 = (object)*(((s1_ptr)_2)->base + _i_7252);
        if (IS_SEQUENCE(_3887) && IS_ATOM(_filename_7172)) {
        }
        else if (IS_ATOM(_3887) && IS_SEQUENCE(_filename_7172)) {
            Ref(_3887);
            Prepend(&_this_path_7176, _filename_7172, _3887);
        }
        else {
            Concat((object_ptr)&_this_path_7176, _3887, _filename_7172);
            _3887 = NOVALUE;
        }
        _3887 = NOVALUE;
L11: 

        /** filesys.e:2610			if file_exists(this_path) then*/
        RefDS(_this_path_7176);
        _3889 = _17file_exists(_this_path_7176);
        if (_3889 == 0) {
            DeRef(_3889);
            _3889 = NOVALUE;
            goto L12; // [436] 452
        }
        else {
            if (!IS_ATOM_INT(_3889) && DBL_PTR(_3889)->dbl == 0.0){
                DeRef(_3889);
                _3889 = NOVALUE;
                goto L12; // [436] 452
            }
            DeRef(_3889);
            _3889 = NOVALUE;
        }
        DeRef(_3889);
        _3889 = NOVALUE;

        /** filesys.e:2611				return canonical_path(this_path)*/
        RefDS(_this_path_7176);
        _3890 = _17canonical_path(_this_path_7176, 0LL, 0LL);
        DeRefDS(_filename_7172);
        DeRefDS(_search_list_7173);
        DeRefDS(_subdir_7174);
        DeRef(_extra_paths_7175);
        DeRefDS(_this_path_7176);
        _3874 = NOVALUE;
        return _3890;
L12: 

        /** filesys.e:2614		end for*/
LE: 
        _i_7252 = _i_7252 + 1LL;
        goto LB; // [454] 343
LC: 
        ;
    }

    /** filesys.e:2615		return filename*/
    DeRefDS(_search_list_7173);
    DeRefDS(_subdir_7174);
    DeRef(_extra_paths_7175);
    DeRef(_this_path_7176);
    DeRef(_3890);
    _3890 = NOVALUE;
    _3874 = NOVALUE;
    return _filename_7172;
    ;
}


object _17count_files(object _orig_path_7330, object _dir_info_7331, object _inst_7332)
{
    object _pos_7333 = NOVALUE;
    object _ext_7334 = NOVALUE;
    object _fileext_inlined_fileext_at_223_7377 = NOVALUE;
    object _data_inlined_fileext_at_223_7376 = NOVALUE;
    object _path_inlined_fileext_at_220_7375 = NOVALUE;
    object _3987 = NOVALUE;
    object _3986 = NOVALUE;
    object _3985 = NOVALUE;
    object _3983 = NOVALUE;
    object _3982 = NOVALUE;
    object _3981 = NOVALUE;
    object _3980 = NOVALUE;
    object _3978 = NOVALUE;
    object _3977 = NOVALUE;
    object _3975 = NOVALUE;
    object _3974 = NOVALUE;
    object _3973 = NOVALUE;
    object _3972 = NOVALUE;
    object _3971 = NOVALUE;
    object _3970 = NOVALUE;
    object _3969 = NOVALUE;
    object _3967 = NOVALUE;
    object _3966 = NOVALUE;
    object _3964 = NOVALUE;
    object _3963 = NOVALUE;
    object _3962 = NOVALUE;
    object _3961 = NOVALUE;
    object _3960 = NOVALUE;
    object _3959 = NOVALUE;
    object _3958 = NOVALUE;
    object _3957 = NOVALUE;
    object _3956 = NOVALUE;
    object _3955 = NOVALUE;
    object _3954 = NOVALUE;
    object _3953 = NOVALUE;
    object _3952 = NOVALUE;
    object _3951 = NOVALUE;
    object _3949 = NOVALUE;
    object _3948 = NOVALUE;
    object _3947 = NOVALUE;
    object _3946 = NOVALUE;
    object _3944 = NOVALUE;
    object _3943 = NOVALUE;
    object _3942 = NOVALUE;
    object _3941 = NOVALUE;
    object _3940 = NOVALUE;
    object _3939 = NOVALUE;
    object _3938 = NOVALUE;
    object _3936 = NOVALUE;
    object _3935 = NOVALUE;
    object _3934 = NOVALUE;
    object _3933 = NOVALUE;
    object _3932 = NOVALUE;
    object _3931 = NOVALUE;
    object _3928 = NOVALUE;
    object _3927 = NOVALUE;
    object _3926 = NOVALUE;
    object _3925 = NOVALUE;
    object _3924 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** filesys.e:2777		integer pos = 0*/
    _pos_7333 = 0LL;

    /** filesys.e:2780		orig_path = orig_path*/
    RefDS(_orig_path_7330);
    DeRefDS(_orig_path_7330);
    _orig_path_7330 = _orig_path_7330;

    /** filesys.e:2781		if equal(dir_info[D_NAME], ".") then*/
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3924 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3924 == _3170)
    _3925 = 1;
    else if (IS_ATOM_INT(_3924) && IS_ATOM_INT(_3170))
    _3925 = 0;
    else
    _3925 = (compare(_3924, _3170) == 0);
    _3924 = NOVALUE;
    if (_3925 == 0)
    {
        _3925 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _3925 = NOVALUE;
    }

    /** filesys.e:2782			return 0*/
    DeRefDS(_orig_path_7330);
    DeRefDS(_dir_info_7331);
    DeRefDS(_inst_7332);
    DeRef(_ext_7334);
    return 0LL;
L1: 

    /** filesys.e:2784		if equal(dir_info[D_NAME], "..") then*/
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3926 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_3926 == _3201)
    _3927 = 1;
    else if (IS_ATOM_INT(_3926) && IS_ATOM_INT(_3201))
    _3927 = 0;
    else
    _3927 = (compare(_3926, _3201) == 0);
    _3926 = NOVALUE;
    if (_3927 == 0)
    {
        _3927 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _3927 = NOVALUE;
    }

    /** filesys.e:2785			return 0*/
    DeRefDS(_orig_path_7330);
    DeRefDS(_dir_info_7331);
    DeRefDS(_inst_7332);
    DeRef(_ext_7334);
    return 0LL;
L2: 

    /** filesys.e:2789		if inst[1] = 0 then -- count all is false*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3928 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _3928, 0LL)){
        _3928 = NOVALUE;
        goto L3; // [65] 112
    }
    _3928 = NOVALUE;

    /** filesys.e:2790			if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3931 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3932 = find_from(104LL, _3931, 1LL);
    _3931 = NOVALUE;
    if (_3932 == 0)
    {
        _3932 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3932 = NOVALUE;
    }

    /** filesys.e:2791				return 0*/
    DeRefDS(_orig_path_7330);
    DeRefDS(_dir_info_7331);
    DeRefDS(_inst_7332);
    DeRef(_ext_7334);
    return 0LL;
L4: 

    /** filesys.e:2794			if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3933 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3934 = find_from(115LL, _3933, 1LL);
    _3933 = NOVALUE;
    if (_3934 == 0)
    {
        _3934 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _3934 = NOVALUE;
    }

    /** filesys.e:2795				return 0*/
    DeRefDS(_orig_path_7330);
    DeRefDS(_dir_info_7331);
    DeRefDS(_inst_7332);
    DeRef(_ext_7334);
    return 0LL;
L5: 
L3: 

    /** filesys.e:2799		file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3935 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7327 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3935))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3935)->dbl));
    else
    _3 = (object)(_3935 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3938 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3939 = (object)*(((s1_ptr)_2)->base + 3LL);
    _3936 = NOVALUE;
    if (IS_ATOM_INT(_3939) && IS_ATOM_INT(_3938)) {
        _3940 = _3939 + _3938;
        if ((object)((uintptr_t)_3940 + (uintptr_t)HIGH_BITS) >= 0){
            _3940 = NewDouble((eudouble)_3940);
        }
    }
    else {
        _3940 = binary_op(PLUS, _3939, _3938);
    }
    _3939 = NOVALUE;
    _3938 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3940;
    if( _1 != _3940 ){
        DeRef(_1);
    }
    _3940 = NOVALUE;
    _3936 = NOVALUE;

    /** filesys.e:2800		if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3941 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3942 = find_from(100LL, _3941, 1LL);
    _3941 = NOVALUE;
    if (_3942 == 0)
    {
        _3942 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _3942 = NOVALUE;
    }

    /** filesys.e:2801			file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3943 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7327 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3943))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3943)->dbl));
    else
    _3 = (object)(_3943 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3946 = (object)*(((s1_ptr)_2)->base + 1LL);
    _3944 = NOVALUE;
    if (IS_ATOM_INT(_3946)) {
        _3947 = _3946 + 1;
        if (_3947 > MAXINT){
            _3947 = NewDouble((eudouble)_3947);
        }
    }
    else
    _3947 = binary_op(PLUS, 1, _3946);
    _3946 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3947;
    if( _1 != _3947 ){
        DeRef(_1);
    }
    _3947 = NOVALUE;
    _3944 = NOVALUE;
    goto L7; // [180] 464
L6: 

    /** filesys.e:2803			file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3948 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7327 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3948))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3948)->dbl));
    else
    _3 = (object)(_3948 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3951 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3949 = NOVALUE;
    if (IS_ATOM_INT(_3951)) {
        _3952 = _3951 + 1;
        if (_3952 > MAXINT){
            _3952 = NewDouble((eudouble)_3952);
        }
    }
    else
    _3952 = binary_op(PLUS, 1, _3951);
    _3951 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3952;
    if( _1 != _3952 ){
        DeRef(_1);
    }
    _3952 = NOVALUE;
    _3949 = NOVALUE;

    /** filesys.e:2804			ifdef not UNIX then*/

    /** filesys.e:2805				ext = fileext(lower(dir_info[D_NAME]))*/
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3953 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_3953);
    _3954 = _14lower(_3953);
    _3953 = NOVALUE;
    DeRef(_path_inlined_fileext_at_220_7375);
    _path_inlined_fileext_at_220_7375 = _3954;
    _3954 = NOVALUE;

    /** filesys.e:1403		data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_220_7375);
    _0 = _data_inlined_fileext_at_223_7376;
    _data_inlined_fileext_at_223_7376 = _17pathinfo(_path_inlined_fileext_at_220_7375, 0LL);
    DeRef(_0);

    /** filesys.e:1404		return data[4]*/
    DeRef(_ext_7334);
    _2 = (object)SEQ_PTR(_data_inlined_fileext_at_223_7376);
    _ext_7334 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_ext_7334);
    DeRef(_path_inlined_fileext_at_220_7375);
    _path_inlined_fileext_at_220_7375 = NOVALUE;
    DeRef(_data_inlined_fileext_at_223_7376);
    _data_inlined_fileext_at_223_7376 = NOVALUE;

    /** filesys.e:2810			pos = 0*/
    _pos_7333 = 0LL;

    /** filesys.e:2811			for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3955 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!IS_ATOM_INT(_3955)){
        _3956 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_3955)->dbl));
    }
    else{
        _3956 = (object)*(((s1_ptr)_2)->base + _3955);
    }
    _2 = (object)SEQ_PTR(_3956);
    _3957 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3956 = NOVALUE;
    if (IS_SEQUENCE(_3957)){
            _3958 = SEQ_PTR(_3957)->length;
    }
    else {
        _3958 = 1;
    }
    _3957 = NOVALUE;
    {
        object _i_7379;
        _i_7379 = 1LL;
L8: 
        if (_i_7379 > _3958){
            goto L9; // [269] 326
        }

        /** filesys.e:2812				if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (object)SEQ_PTR(_inst_7332);
        _3959 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_17file_counters_7327);
        if (!IS_ATOM_INT(_3959)){
            _3960 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_3959)->dbl));
        }
        else{
            _3960 = (object)*(((s1_ptr)_2)->base + _3959);
        }
        _2 = (object)SEQ_PTR(_3960);
        _3961 = (object)*(((s1_ptr)_2)->base + 4LL);
        _3960 = NOVALUE;
        _2 = (object)SEQ_PTR(_3961);
        _3962 = (object)*(((s1_ptr)_2)->base + _i_7379);
        _3961 = NOVALUE;
        _2 = (object)SEQ_PTR(_3962);
        _3963 = (object)*(((s1_ptr)_2)->base + 1LL);
        _3962 = NOVALUE;
        if (_3963 == _ext_7334)
        _3964 = 1;
        else if (IS_ATOM_INT(_3963) && IS_ATOM_INT(_ext_7334))
        _3964 = 0;
        else
        _3964 = (compare(_3963, _ext_7334) == 0);
        _3963 = NOVALUE;
        if (_3964 == 0)
        {
            _3964 = NOVALUE;
            goto LA; // [306] 319
        }
        else{
            _3964 = NOVALUE;
        }

        /** filesys.e:2813					pos = i*/
        _pos_7333 = _i_7379;

        /** filesys.e:2814					exit*/
        goto L9; // [316] 326
LA: 

        /** filesys.e:2816			end for*/
        _i_7379 = _i_7379 + 1LL;
        goto L8; // [321] 276
L9: 
        ;
    }

    /** filesys.e:2818			if pos = 0 then*/
    if (_pos_7333 != 0LL)
    goto LB; // [328] 389

    /** filesys.e:2819				file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3966 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7327 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3966))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3966)->dbl));
    else
    _3 = (object)(_3966 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_ext_7334);
    ((intptr_t*)_2)[1] = _ext_7334;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    _3969 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _3969;
    _3970 = MAKE_SEQ(_1);
    _3969 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3971 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3967 = NOVALUE;
    if (IS_SEQUENCE(_3971) && IS_ATOM(_3970)) {
    }
    else if (IS_ATOM(_3971) && IS_SEQUENCE(_3970)) {
        Ref(_3971);
        Prepend(&_3972, _3970, _3971);
    }
    else {
        Concat((object_ptr)&_3972, _3971, _3970);
        _3971 = NOVALUE;
    }
    _3971 = NOVALUE;
    DeRefDS(_3970);
    _3970 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3972;
    if( _1 != _3972 ){
        DeRef(_1);
    }
    _3972 = NOVALUE;
    _3967 = NOVALUE;

    /** filesys.e:2820				pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3973 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!IS_ATOM_INT(_3973)){
        _3974 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_3973)->dbl));
    }
    else{
        _3974 = (object)*(((s1_ptr)_2)->base + _3973);
    }
    _2 = (object)SEQ_PTR(_3974);
    _3975 = (object)*(((s1_ptr)_2)->base + 4LL);
    _3974 = NOVALUE;
    if (IS_SEQUENCE(_3975)){
            _pos_7333 = SEQ_PTR(_3975)->length;
    }
    else {
        _pos_7333 = 1;
    }
    _3975 = NOVALUE;
LB: 

    /** filesys.e:2823			file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3977 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7327 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3977))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3977)->dbl));
    else
    _3 = (object)(_3977 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4LL + ((s1_ptr)_2)->base);
    _3978 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_7333 + ((s1_ptr)_2)->base);
    _3978 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3980 = (object)*(((s1_ptr)_2)->base + 2LL);
    _3978 = NOVALUE;
    if (IS_ATOM_INT(_3980)) {
        _3981 = _3980 + 1;
        if (_3981 > MAXINT){
            _3981 = NewDouble((eudouble)_3981);
        }
    }
    else
    _3981 = binary_op(PLUS, 1, _3980);
    _3980 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3981;
    if( _1 != _3981 ){
        DeRef(_1);
    }
    _3981 = NOVALUE;
    _3978 = NOVALUE;

    /** filesys.e:2824			file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (object)SEQ_PTR(_inst_7332);
    _3982 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_17file_counters_7327);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _17file_counters_7327 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3982))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_3982)->dbl));
    else
    _3 = (object)(_3982 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(4LL + ((s1_ptr)_2)->base);
    _3983 = NOVALUE;
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pos_7333 + ((s1_ptr)_2)->base);
    _3983 = NOVALUE;
    _2 = (object)SEQ_PTR(_dir_info_7331);
    _3985 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _3986 = (object)*(((s1_ptr)_2)->base + 3LL);
    _3983 = NOVALUE;
    if (IS_ATOM_INT(_3986) && IS_ATOM_INT(_3985)) {
        _3987 = _3986 + _3985;
        if ((object)((uintptr_t)_3987 + (uintptr_t)HIGH_BITS) >= 0){
            _3987 = NewDouble((eudouble)_3987);
        }
    }
    else {
        _3987 = binary_op(PLUS, _3986, _3985);
    }
    _3986 = NOVALUE;
    _3985 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _3987;
    if( _1 != _3987 ){
        DeRef(_1);
    }
    _3987 = NOVALUE;
    _3983 = NOVALUE;
L7: 

    /** filesys.e:2827		return 0*/
    DeRefDS(_orig_path_7330);
    DeRefDS(_dir_info_7331);
    DeRefDS(_inst_7332);
    DeRef(_ext_7334);
    _3977 = NOVALUE;
    _3955 = NOVALUE;
    _3973 = NOVALUE;
    _3966 = NOVALUE;
    _3935 = NOVALUE;
    _3982 = NOVALUE;
    _3957 = NOVALUE;
    _3943 = NOVALUE;
    _3975 = NOVALUE;
    _3959 = NOVALUE;
    _3948 = NOVALUE;
    return 0LL;
    ;
}


object _17temp_file(object _temp_location_7437, object _temp_prefix_7438, object _temp_extn_7439, object _reserve_temp_7441)
{
    object _randname_7442 = NOVALUE;
    object _envtmp_7446 = NOVALUE;
    object _tdir_7465 = NOVALUE;
    object _5771 = NOVALUE;
    object _4039 = NOVALUE;
    object _4037 = NOVALUE;
    object _4035 = NOVALUE;
    object _4033 = NOVALUE;
    object _4032 = NOVALUE;
    object _4031 = NOVALUE;
    object _4027 = NOVALUE;
    object _4026 = NOVALUE;
    object _4025 = NOVALUE;
    object _4024 = NOVALUE;
    object _4021 = NOVALUE;
    object _4020 = NOVALUE;
    object _4019 = NOVALUE;
    object _4014 = NOVALUE;
    object _4011 = NOVALUE;
    object _4008 = NOVALUE;
    object _4004 = NOVALUE;
    object _0, _1, _2;
    

    /** filesys.e:2919		if length(temp_location) = 0 then*/
    if (IS_SEQUENCE(_temp_location_7437)){
            _4004 = SEQ_PTR(_temp_location_7437)->length;
    }
    else {
        _4004 = 1;
    }
    if (_4004 != 0LL)
    goto L1; // [14] 67

    /** filesys.e:2920			object envtmp*/

    /** filesys.e:2921			envtmp = getenv("TEMP")*/
    DeRefi(_envtmp_7446);
    _envtmp_7446 = EGetEnv(_4006);

    /** filesys.e:2922			if atom(envtmp) then*/
    _4008 = IS_ATOM(_envtmp_7446);
    if (_4008 == 0)
    {
        _4008 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _4008 = NOVALUE;
    }

    /** filesys.e:2923				envtmp = getenv("TMP")*/
    DeRefi(_envtmp_7446);
    _envtmp_7446 = EGetEnv(_4009);
L2: 

    /** filesys.e:2925			ifdef WINDOWS then			*/

    /** filesys.e:2926				if atom(envtmp) then*/
    _4011 = IS_ATOM(_envtmp_7446);
    if (_4011 == 0)
    {
        _4011 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _4011 = NOVALUE;
    }

    /** filesys.e:2927					envtmp = "C:\\temp\\"*/
    RefDS(_4012);
    DeRefi(_envtmp_7446);
    _envtmp_7446 = _4012;
L3: 

    /** filesys.e:2934			temp_location = envtmp*/
    Ref(_envtmp_7446);
    DeRefDS(_temp_location_7437);
    _temp_location_7437 = _envtmp_7446;
    DeRefi(_envtmp_7446);
    _envtmp_7446 = NOVALUE;
    goto L4; // [64] 161
L1: 

    /** filesys.e:2936			switch file_type(temp_location) do*/
    RefDS(_temp_location_7437);
    _4014 = _17file_type(_temp_location_7437);
    if (IS_SEQUENCE(_4014) ){
        goto L5; // [73] 150
    }
    if(!IS_ATOM_INT(_4014)){
        if( (DBL_PTR(_4014)->dbl != (eudouble) ((object) DBL_PTR(_4014)->dbl) ) ){
            goto L5; // [73] 150
        }
        _0 = (object) DBL_PTR(_4014)->dbl;
    }
    else {
        _0 = _4014;
    };
    DeRef(_4014);
    _4014 = NOVALUE;
    switch ( _0 ){ 

        /** filesys.e:2937				case FILETYPE_FILE then*/
        case 1:

        /** filesys.e:2938					temp_location = dirname(temp_location, 1)*/
        RefDS(_temp_location_7437);
        _0 = _temp_location_7437;
        _temp_location_7437 = _17dirname(_temp_location_7437, 1LL);
        DeRefDS(_0);
        goto L6; // [91] 160

        /** filesys.e:2940				case FILETYPE_DIRECTORY then*/
        case 2:

        /** filesys.e:2942					temp_location = temp_location*/
        RefDS(_temp_location_7437);
        DeRefDS(_temp_location_7437);
        _temp_location_7437 = _temp_location_7437;
        goto L6; // [104] 160

        /** filesys.e:2944				case FILETYPE_NOT_FOUND then*/
        case 0:

        /** filesys.e:2945					object tdir = dirname(temp_location, 1)*/
        RefDS(_temp_location_7437);
        _0 = _tdir_7465;
        _tdir_7465 = _17dirname(_temp_location_7437, 1LL);
        DeRef(_0);

        /** filesys.e:2946					if file_exists(tdir) then*/
        Ref(_tdir_7465);
        _4019 = _17file_exists(_tdir_7465);
        if (_4019 == 0) {
            DeRef(_4019);
            _4019 = NOVALUE;
            goto L7; // [123] 136
        }
        else {
            if (!IS_ATOM_INT(_4019) && DBL_PTR(_4019)->dbl == 0.0){
                DeRef(_4019);
                _4019 = NOVALUE;
                goto L7; // [123] 136
            }
            DeRef(_4019);
            _4019 = NOVALUE;
        }
        DeRef(_4019);
        _4019 = NOVALUE;

        /** filesys.e:2947						temp_location = tdir*/
        Ref(_tdir_7465);
        DeRefDS(_temp_location_7437);
        _temp_location_7437 = _tdir_7465;
        goto L8; // [133] 144
L7: 

        /** filesys.e:2949						temp_location = "."*/
        RefDS(_3170);
        DeRefDS(_temp_location_7437);
        _temp_location_7437 = _3170;
L8: 
        DeRef(_tdir_7465);
        _tdir_7465 = NOVALUE;
        goto L6; // [146] 160

        /** filesys.e:2952				case else*/
        default:
L5: 

        /** filesys.e:2953					temp_location = "."*/
        RefDS(_3170);
        DeRefDS(_temp_location_7437);
        _temp_location_7437 = _3170;
    ;}L6: 
L4: 

    /** filesys.e:2958		if temp_location[$] != SLASH then*/
    if (IS_SEQUENCE(_temp_location_7437)){
            _4020 = SEQ_PTR(_temp_location_7437)->length;
    }
    else {
        _4020 = 1;
    }
    _2 = (object)SEQ_PTR(_temp_location_7437);
    _4021 = (object)*(((s1_ptr)_2)->base + _4020);
    if (binary_op_a(EQUALS, _4021, 92LL)){
        _4021 = NOVALUE;
        goto L9; // [170] 181
    }
    _4021 = NOVALUE;

    /** filesys.e:2959			temp_location &= SLASH*/
    Append(&_temp_location_7437, _temp_location_7437, 92LL);
L9: 

    /** filesys.e:2962		if length(temp_extn) and temp_extn[1] != '.' then*/
    if (IS_SEQUENCE(_temp_extn_7439)){
            _4024 = SEQ_PTR(_temp_extn_7439)->length;
    }
    else {
        _4024 = 1;
    }
    if (_4024 == 0) {
        goto LA; // [186] 209
    }
    _2 = (object)SEQ_PTR(_temp_extn_7439);
    _4026 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_4026)) {
        _4027 = (_4026 != 46LL);
    }
    else {
        _4027 = binary_op(NOTEQ, _4026, 46LL);
    }
    _4026 = NOVALUE;
    if (_4027 == 0) {
        DeRef(_4027);
        _4027 = NOVALUE;
        goto LA; // [199] 209
    }
    else {
        if (!IS_ATOM_INT(_4027) && DBL_PTR(_4027)->dbl == 0.0){
            DeRef(_4027);
            _4027 = NOVALUE;
            goto LA; // [199] 209
        }
        DeRef(_4027);
        _4027 = NOVALUE;
    }
    DeRef(_4027);
    _4027 = NOVALUE;

    /** filesys.e:2963			temp_extn = '.' & temp_extn*/
    Prepend(&_temp_extn_7439, _temp_extn_7439, 46LL);
LA: 

    /** filesys.e:2966		while 1 do*/
LB: 

    /** filesys.e:2967			randname = sprintf("%s%s%06d%s", {temp_location, temp_prefix, rand(1_000_000) - 1, temp_extn})*/
    _4031 = good_rand() % ((uint32_t)1000000LL) + 1;
    _4032 = _4031 - 1LL;
    _4031 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_temp_location_7437);
    ((intptr_t*)_2)[1] = _temp_location_7437;
    RefDS(_temp_prefix_7438);
    ((intptr_t*)_2)[2] = _temp_prefix_7438;
    ((intptr_t*)_2)[3] = _4032;
    RefDS(_temp_extn_7439);
    ((intptr_t*)_2)[4] = _temp_extn_7439;
    _4033 = MAKE_SEQ(_1);
    _4032 = NOVALUE;
    DeRefi(_randname_7442);
    _randname_7442 = EPrintf(-9999999, _4029, _4033);
    DeRefDS(_4033);
    _4033 = NOVALUE;

    /** filesys.e:2968			if not file_exists( randname ) then*/
    RefDS(_randname_7442);
    _4035 = _17file_exists(_randname_7442);
    if (IS_ATOM_INT(_4035)) {
        if (_4035 != 0){
            DeRef(_4035);
            _4035 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    else {
        if (DBL_PTR(_4035)->dbl != 0.0){
            DeRef(_4035);
            _4035 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    DeRef(_4035);
    _4035 = NOVALUE;

    /** filesys.e:2969				exit*/
    goto LC; // [245] 253

    /** filesys.e:2971		end while*/
    goto LB; // [250] 214
LC: 

    /** filesys.e:2973		if reserve_temp then*/
    if (_reserve_temp_7441 == 0)
    {
        goto LD; // [255] 300
    }
    else{
    }

    /** filesys.e:2975			if not file_exists(temp_location) then*/
    RefDS(_temp_location_7437);
    _4037 = _17file_exists(_temp_location_7437);
    if (IS_ATOM_INT(_4037)) {
        if (_4037 != 0){
            DeRef(_4037);
            _4037 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    else {
        if (DBL_PTR(_4037)->dbl != 0.0){
            DeRef(_4037);
            _4037 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    DeRef(_4037);
    _4037 = NOVALUE;

    /** filesys.e:2976				if create_directory(temp_location) = 0 then*/
    RefDS(_temp_location_7437);
    _4039 = _17create_directory(_temp_location_7437, 448LL, 1LL);
    if (binary_op_a(NOTEQ, _4039, 0LL)){
        DeRef(_4039);
        _4039 = NOVALUE;
        goto LF; // [275] 286
    }
    DeRef(_4039);
    _4039 = NOVALUE;

    /** filesys.e:2977					return ""*/
    RefDS(_5);
    DeRefDS(_temp_location_7437);
    DeRefDSi(_temp_prefix_7438);
    DeRefDS(_temp_extn_7439);
    DeRefi(_randname_7442);
    return _5;
LF: 
LE: 

    /** filesys.e:2980			io:write_file(randname, "")*/
    RefDS(_randname_7442);
    RefDS(_5);
    _5771 = _8write_file(_randname_7442, _5, 1LL);
    DeRef(_5771);
    _5771 = NOVALUE;
LD: 

    /** filesys.e:2983		return randname*/
    DeRefDS(_temp_location_7437);
    DeRefDSi(_temp_prefix_7438);
    DeRefDS(_temp_extn_7439);
    return _randname_7442;
    ;
}



// 0x93C6FE97
