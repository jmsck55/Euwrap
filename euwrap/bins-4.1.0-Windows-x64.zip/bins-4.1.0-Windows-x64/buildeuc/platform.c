// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _46host_platform()
{
    object _0, _1, _2;
    

    /** platform.e:113		return ihost_platform*/
    return _46ihost_platform_21931;
    ;
}


void _46set_host_platform(object _plat_21938)
{
    object _12358 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:119		ihost_platform = floor(plat)*/
    _46ihost_platform_21931 = e_floor(_plat_21938);

    /** platform.e:121		TUNIX    = (find(ihost_platform, unices) != 0) */
    _12358 = find_from(_46ihost_platform_21931, _46unices_21934, 1LL);
    _46TUNIX_21910 = (_12358 != 0LL);
    _12358 = NOVALUE;

    /** platform.e:122		TWINDOWS = (ihost_platform = WIN32)*/
    _46TWINDOWS_21906 = (_46ihost_platform_21931 == 2LL);

    /** platform.e:123		TBSD     = (ihost_platform = UFREEBSD)*/
    _46TBSD_21912 = (_46ihost_platform_21931 == 8LL);

    /** platform.e:124		TOSX     = (ihost_platform = UOSX)*/
    _46TOSX_21914 = (_46ihost_platform_21931 == 4LL);

    /** platform.e:125		TLINUX   = (ihost_platform = ULINUX)*/
    _46TLINUX_21908 = (_46ihost_platform_21931 == 3LL);

    /** platform.e:126		TOPENBSD = (ihost_platform = UOPENBSD)*/
    _46TOPENBSD_21916 = (_46ihost_platform_21931 == 6LL);

    /** platform.e:127		TNETBSD  = (ihost_platform = UNETBSD)*/
    _46TNETBSD_21918 = (_46ihost_platform_21931 == 7LL);

    /** platform.e:128		IUNIX    = TUNIX*/
    _46IUNIX_21909 = _46TUNIX_21910;

    /** platform.e:129		IWINDOWS = TWINDOWS*/
    _46IWINDOWS_21905 = _46TWINDOWS_21906;

    /** platform.e:130		IBSD     = TBSD*/
    _46IBSD_21911 = _46TBSD_21912;

    /** platform.e:131		IOSX     = TOSX*/
    _46IOSX_21913 = _46TOSX_21914;

    /** platform.e:132		ILINUX   = TLINUX*/
    _46ILINUX_21907 = _46TLINUX_21908;

    /** platform.e:133		IOPENBSD = TOPENBSD*/
    _46IOPENBSD_21915 = _46TOPENBSD_21916;

    /** platform.e:134		INETBSD  = TNETBSD*/
    _46INETBSD_21917 = _46TNETBSD_21918;

    /** platform.e:136		if TUNIX then*/
    if (_46TUNIX_21910 == 0)
    {
        goto L1; // [148] 161
    }
    else{
    }

    /** platform.e:137			HOSTNL = "\n"*/
    RefDS(_9945);
    DeRefi(_46HOSTNL_21929);
    _46HOSTNL_21929 = _9945;
    goto L2; // [158] 169
L1: 

    /** platform.e:139			HOSTNL = "\r\n"*/
    RefDS(_12355);
    DeRefi(_46HOSTNL_21929);
    _46HOSTNL_21929 = _12355;
L2: 

    /** platform.e:141	end procedure*/
    return;
    ;
}


void _46set_target_arch(object _arch_21953)
{
    object _12375 = NOVALUE;
    object _12366 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:144		IX86    = 0*/
    _46IX86_21919 = 0LL;

    /** platform.e:145		TX86    = 0*/
    _46TX86_21920 = 0LL;

    /** platform.e:146		IX86_64 = 0*/
    _46IX86_64_21921 = 0LL;

    /** platform.e:147		TX86_64 = 0*/
    _46TX86_64_21922 = 0LL;

    /** platform.e:148		IARM    = 0*/
    _46IARM_21923 = 0LL;

    /** platform.e:149		TARM    = 0*/
    _46TARM_21924 = 0LL;

    /** platform.e:150		switch upper( arch ) do*/
    RefDS(_arch_21953);
    _12366 = _14upper(_arch_21953);
    _1 = find(_12366, _12367);
    DeRef(_12366);
    _12366 = NOVALUE;
    switch ( _1 ){ 

        /** platform.e:151			case "X86", "IX86" then*/
        case 1:
        case 2:

        /** platform.e:152				IX86    = 1*/
        _46IX86_21919 = 1LL;

        /** platform.e:153				TX86    = 1*/
        _46TX86_21920 = 1LL;

        /** platform.e:154				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21581 = 4LL;
        goto L1; // [67] 140

        /** platform.e:156			case "X86_64", "IX86_64" then*/
        case 3:
        case 4:

        /** platform.e:157				IX86_64 = 1*/
        _46IX86_64_21921 = 1LL;

        /** platform.e:158				TX86_64 = 1*/
        _46TX86_64_21922 = 1LL;

        /** platform.e:159				TARGET_SIZEOF_POINTER = 8*/
        _36TARGET_SIZEOF_POINTER_21581 = 8LL;
        goto L1; // [92] 140

        /** platform.e:161			case "ARM" then*/
        case 5:

        /** platform.e:162				IARM = 1*/
        _46IARM_21923 = 1LL;

        /** platform.e:163				TARM = 1*/
        _46TARM_21924 = 1LL;

        /** platform.e:164				TARGET_SIZEOF_POINTER = 4*/
        _36TARGET_SIZEOF_POINTER_21581 = 4LL;
        goto L1; // [115] 140

        /** platform.e:166			case else*/
        case 0:

        /** platform.e:167				ShowMsg( 2, UNKNOWN_ARCHITECTURE_1__SUPPORTED_ARCHITECTURES_ARE_2, { arch, "X86, X86_64, ARM" } )*/
        RefDS(_12374);
        RefDS(_arch_21953);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _arch_21953;
        ((intptr_t *)_2)[2] = _12374;
        _12375 = MAKE_SEQ(_1);
        _39ShowMsg(2LL, 357LL, _12375, 1LL);
        _12375 = NOVALUE;

        /** platform.e:168				abort( 1 )*/
        UserCleanup(1LL);
    ;}L1: 

    /** platform.e:170		set_target_integer_size( TARGET_SIZEOF_POINTER )	*/
    _36set_target_integer_size(_36TARGET_SIZEOF_POINTER_21581);

    /** platform.e:171	end procedure*/
    DeRefDS(_arch_21953);
    return;
    ;
}


object _46GetPlatformDefines(object _for_translator_21978)
{
    object _local_defines_21979 = NOVALUE;
    object _lcmds_21989 = NOVALUE;
    object _fh_21991 = NOVALUE;
    object _sk_22011 = NOVALUE;
    object _12500 = NOVALUE;
    object _12499 = NOVALUE;
    object _12497 = NOVALUE;
    object _12494 = NOVALUE;
    object _12493 = NOVALUE;
    object _12491 = NOVALUE;
    object _12490 = NOVALUE;
    object _12488 = NOVALUE;
    object _12485 = NOVALUE;
    object _12484 = NOVALUE;
    object _12482 = NOVALUE;
    object _12481 = NOVALUE;
    object _12479 = NOVALUE;
    object _12477 = NOVALUE;
    object _12475 = NOVALUE;
    object _12474 = NOVALUE;
    object _12472 = NOVALUE;
    object _12469 = NOVALUE;
    object _12467 = NOVALUE;
    object _12466 = NOVALUE;
    object _12464 = NOVALUE;
    object _12462 = NOVALUE;
    object _12460 = NOVALUE;
    object _12459 = NOVALUE;
    object _12457 = NOVALUE;
    object _12455 = NOVALUE;
    object _12453 = NOVALUE;
    object _12452 = NOVALUE;
    object _12450 = NOVALUE;
    object _12448 = NOVALUE;
    object _12446 = NOVALUE;
    object _12445 = NOVALUE;
    object _12443 = NOVALUE;
    object _12440 = NOVALUE;
    object _12438 = NOVALUE;
    object _12437 = NOVALUE;
    object _12435 = NOVALUE;
    object _12433 = NOVALUE;
    object _12431 = NOVALUE;
    object _12430 = NOVALUE;
    object _12427 = NOVALUE;
    object _12424 = NOVALUE;
    object _12421 = NOVALUE;
    object _12417 = NOVALUE;
    object _12416 = NOVALUE;
    object _12411 = NOVALUE;
    object _12410 = NOVALUE;
    object _12397 = NOVALUE;
    object _12394 = NOVALUE;
    object _12391 = NOVALUE;
    object _12390 = NOVALUE;
    object _12389 = NOVALUE;
    object _12385 = NOVALUE;
    object _12382 = NOVALUE;
    object _12379 = NOVALUE;
    object _12377 = NOVALUE;
    object _12376 = NOVALUE;
    object _0, _1, _2;
    

    /** platform.e:174		sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_21979);
    _local_defines_21979 = _5;

    /** platform.e:176		if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21905 == 0) {
        _12376 = 0;
        goto L1; // [14] 25
    }
    _12377 = (_for_translator_21978 == 0);
    _12376 = (_12377 != 0);
L1: 
    if (_12376 != 0) {
        goto L2; // [25] 44
    }
    if (_46TWINDOWS_21906 == 0) {
        DeRef(_12379);
        _12379 = 0;
        goto L3; // [31] 39
    }
    _12379 = (_for_translator_21978 != 0);
L3: 
    if (_12379 == 0)
    {
        _12379 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _12379 = NOVALUE;
    }
L2: 

    /** platform.e:177			local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_12381);
    RefDS(_12380);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12380;
    ((intptr_t *)_2)[2] = _12381;
    _12382 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12382);
    DeRefDS(_12382);
    _12382 = NOVALUE;

    /** platform.e:178			sequence lcmds = command_line()*/
    DeRef(_lcmds_21989);
    _lcmds_21989 = Command_Line();

    /** platform.e:181			integer fh*/

    /** platform.e:182			fh = open(lcmds[1], "rb")*/
    _2 = (object)SEQ_PTR(_lcmds_21989);
    _12385 = (object)*(((s1_ptr)_2)->base + 1LL);
    _fh_21991 = EOpen(_12385, _10266, 0LL);
    _12385 = NOVALUE;

    /** platform.e:183			if fh = -1 then*/
    if (_fh_21991 != -1LL)
    goto L5; // [73] 123

    /** platform.e:185	 			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (object)SEQ_PTR(_lcmds_21989);
    _12389 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_12389);
    _12390 = _14lower(_12389);
    _12389 = NOVALUE;
    _12391 = e_match_from(_12388, _12390, 1LL);
    DeRef(_12390);
    _12390 = NOVALUE;
    if (_12391 == 0LL)
    goto L6; // [92] 109

    /** platform.e:186	 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12393);
    ((intptr_t*)_2)[1] = _12393;
    _12394 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12394);
    DeRefDS(_12394);
    _12394 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /** platform.e:188	 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12396);
    ((intptr_t*)_2)[1] = _12396;
    _12397 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12397);
    DeRefDS(_12397);
    _12397 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** platform.e:191				atom sk*/

    /** platform.e:192				sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_22011;
    _sk_22011 = _8seek(_fh_21991, 24LL);
    DeRef(_0);

    /** platform.e:193				sk = get_integer16(fh)*/
    _0 = _sk_22011;
    _sk_22011 = _8get_integer16(_fh_21991);
    DeRef(_0);

    /** platform.e:194				if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_22011, 64LL)){
        goto L8; // [140] 259
    }

    /** platform.e:196					sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_22011;
    _sk_22011 = _8seek(_fh_21991, 60LL);
    DeRef(_0);

    /** platform.e:197					sk = get_integer32(fh)*/
    _0 = _sk_22011;
    _sk_22011 = _8get_integer32(_fh_21991);
    DeRef(_0);

    /** platform.e:198					sk = seek(fh, sk)*/
    Ref(_sk_22011);
    _0 = _sk_22011;
    _sk_22011 = _8seek(_fh_21991, _sk_22011);
    DeRef(_0);

    /** platform.e:199					sk = get_integer16(fh)*/
    _0 = _sk_22011;
    _sk_22011 = _8get_integer16(_fh_21991);
    DeRef(_0);

    /** platform.e:200					if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_22011, 17744LL)){
        goto L9; // [172] 221
    }

    /** platform.e:201						sk = get_integer16(fh)*/
    _0 = _sk_22011;
    _sk_22011 = _8get_integer16(_fh_21991);
    DeRef(_0);

    /** platform.e:202						if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_22011, 0LL)){
        goto LA; // [184] 212
    }

    /** platform.e:204							sk = seek(fh, where(fh) + 88 )*/
    _12410 = _8where(_fh_21991);
    if (IS_ATOM_INT(_12410)) {
        _12411 = _12410 + 88LL;
        if ((object)((uintptr_t)_12411 + (uintptr_t)HIGH_BITS) >= 0){
            _12411 = NewDouble((eudouble)_12411);
        }
    }
    else {
        _12411 = binary_op(PLUS, _12410, 88LL);
    }
    DeRef(_12410);
    _12410 = NOVALUE;
    _0 = _sk_22011;
    _sk_22011 = _8seek(_fh_21991, _12411);
    DeRef(_0);
    _12411 = NOVALUE;

    /** platform.e:205							sk = get_integer16(fh)*/
    _0 = _sk_22011;
    _sk_22011 = _8get_integer16(_fh_21991);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** platform.e:207							sk = 0	-- Don't know this format.*/
    DeRef(_sk_22011);
    _sk_22011 = 0LL;
    goto LB; // [218] 265
L9: 

    /** platform.e:209					elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_22011, 17742LL)){
        goto LC; // [223] 250
    }

    /** platform.e:211						sk = seek(fh, where(fh) + 54 )*/
    _12416 = _8where(_fh_21991);
    if (IS_ATOM_INT(_12416)) {
        _12417 = _12416 + 54LL;
        if ((object)((uintptr_t)_12417 + (uintptr_t)HIGH_BITS) >= 0){
            _12417 = NewDouble((eudouble)_12417);
        }
    }
    else {
        _12417 = binary_op(PLUS, _12416, 54LL);
    }
    DeRef(_12416);
    _12416 = NOVALUE;
    _0 = _sk_22011;
    _sk_22011 = _8seek(_fh_21991, _12417);
    DeRef(_0);
    _12417 = NOVALUE;

    /** platform.e:212						sk = getc(fh)*/
    DeRef(_sk_22011);
    if (_fh_21991 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_21991, EF_READ);
        last_r_file_no = _fh_21991;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _sk_22011 = getKBchar();
        }
        else{
            _sk_22011 = getc(last_r_file_ptr);
        }
    }
    else{
        _sk_22011 = getc(last_r_file_ptr);
    }
    goto LB; // [247] 265
LC: 

    /** platform.e:214						sk = 0*/
    DeRef(_sk_22011);
    _sk_22011 = 0LL;
    goto LB; // [256] 265
L8: 

    /** platform.e:217					sk = 0*/
    DeRef(_sk_22011);
    _sk_22011 = 0LL;
LB: 

    /** platform.e:219				if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_22011, 2LL)){
        goto LD; // [267] 284
    }

    /** platform.e:220					local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12393);
    ((intptr_t*)_2)[1] = _12393;
    _12421 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12421);
    DeRefDS(_12421);
    _12421 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** platform.e:221				elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_22011, 3LL)){
        goto LF; // [286] 303
    }

    /** platform.e:222					local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12396);
    ((intptr_t*)_2)[1] = _12396;
    _12424 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12424);
    DeRefDS(_12424);
    _12424 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** platform.e:224					local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12426);
    ((intptr_t*)_2)[1] = _12426;
    _12427 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12427);
    DeRefDS(_12427);
    _12427 = NOVALUE;
LE: 

    /** platform.e:226				close(fh)*/
    EClose(_fh_21991);
    DeRef(_sk_22011);
    _sk_22011 = NOVALUE;
L7: 
    DeRef(_lcmds_21989);
    _lcmds_21989 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** platform.e:229			local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_12396);
    Append(&_local_defines_21979, _local_defines_21979, _12396);

    /** platform.e:230			if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_46ILINUX_21907 == 0) {
        _12430 = 0;
        goto L11; // [336] 347
    }
    _12431 = (_for_translator_21978 == 0);
    _12430 = (_12431 != 0);
L11: 
    if (_12430 != 0) {
        goto L12; // [347] 366
    }
    if (_46TLINUX_21908 == 0) {
        DeRef(_12433);
        _12433 = 0;
        goto L13; // [353] 361
    }
    _12433 = (_for_translator_21978 != 0);
L13: 
    if (_12433 == 0)
    {
        _12433 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _12433 = NOVALUE;
    }
L12: 

    /** platform.e:231				local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_12434);
    RefDS(_12163);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12163;
    ((intptr_t *)_2)[2] = _12434;
    _12435 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12435);
    DeRefDS(_12435);
    _12435 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** platform.e:232			elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (_46IOSX_21913 == 0) {
        _12437 = 0;
        goto L16; // [383] 394
    }
    _12438 = (_for_translator_21978 == 0);
    _12437 = (_12438 != 0);
L16: 
    if (_12437 != 0) {
        goto L17; // [394] 413
    }
    if (_46TOSX_21914 == 0) {
        DeRef(_12440);
        _12440 = 0;
        goto L18; // [400] 408
    }
    _12440 = (_for_translator_21978 != 0);
L18: 
    if (_12440 == 0)
    {
        _12440 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _12440 = NOVALUE;
    }
L17: 

    /** platform.e:233				local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12163);
    ((intptr_t*)_2)[1] = _12163;
    RefDS(_12441);
    ((intptr_t*)_2)[2] = _12441;
    RefDS(_12442);
    ((intptr_t*)_2)[3] = _12442;
    _12443 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12443);
    DeRefDS(_12443);
    _12443 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** platform.e:234			elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (_46IOPENBSD_21915 == 0) {
        _12445 = 0;
        goto L1A; // [432] 443
    }
    _12446 = (_for_translator_21978 == 0);
    _12445 = (_12446 != 0);
L1A: 
    if (_12445 != 0) {
        goto L1B; // [443] 462
    }
    if (_46TOPENBSD_21916 == 0) {
        DeRef(_12448);
        _12448 = 0;
        goto L1C; // [449] 457
    }
    _12448 = (_for_translator_21978 != 0);
L1C: 
    if (_12448 == 0)
    {
        _12448 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _12448 = NOVALUE;
    }
L1B: 

    /** platform.e:235				local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12163);
    ((intptr_t*)_2)[1] = _12163;
    RefDS(_12441);
    ((intptr_t*)_2)[2] = _12441;
    RefDS(_12449);
    ((intptr_t*)_2)[3] = _12449;
    _12450 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12450);
    DeRefDS(_12450);
    _12450 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** platform.e:236			elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (_46INETBSD_21917 == 0) {
        _12452 = 0;
        goto L1E; // [481] 492
    }
    _12453 = (_for_translator_21978 == 0);
    _12452 = (_12453 != 0);
L1E: 
    if (_12452 != 0) {
        goto L1F; // [492] 511
    }
    if (_46TNETBSD_21918 == 0) {
        DeRef(_12455);
        _12455 = 0;
        goto L20; // [498] 506
    }
    _12455 = (_for_translator_21978 != 0);
L20: 
    if (_12455 == 0)
    {
        _12455 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _12455 = NOVALUE;
    }
L1F: 

    /** platform.e:237				local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12163);
    ((intptr_t*)_2)[1] = _12163;
    RefDS(_12441);
    ((intptr_t*)_2)[2] = _12441;
    RefDS(_12456);
    ((intptr_t*)_2)[3] = _12456;
    _12457 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12457);
    DeRefDS(_12457);
    _12457 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** platform.e:238			elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (_46IBSD_21911 == 0) {
        _12459 = 0;
        goto L22; // [530] 541
    }
    _12460 = (_for_translator_21978 == 0);
    _12459 = (_12460 != 0);
L22: 
    if (_12459 != 0) {
        goto L23; // [541] 560
    }
    if (_46TBSD_21912 == 0) {
        DeRef(_12462);
        _12462 = 0;
        goto L24; // [547] 555
    }
    _12462 = (_for_translator_21978 != 0);
L24: 
    if (_12462 == 0)
    {
        _12462 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _12462 = NOVALUE;
    }
L23: 

    /** platform.e:239				local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12163);
    ((intptr_t*)_2)[1] = _12163;
    RefDS(_12441);
    ((intptr_t*)_2)[2] = _12441;
    RefDS(_12463);
    ((intptr_t*)_2)[3] = _12463;
    _12464 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12464);
    DeRefDS(_12464);
    _12464 = NOVALUE;
L25: 
L15: 
L10: 

    /** platform.e:243		if (IX86 and not for_translator) or (TX86 and for_translator) then*/
    if (_46IX86_21919 == 0) {
        _12466 = 0;
        goto L26; // [579] 590
    }
    _12467 = (_for_translator_21978 == 0);
    _12466 = (_12467 != 0);
L26: 
    if (_12466 != 0) {
        goto L27; // [590] 609
    }
    if (_46TX86_21920 == 0) {
        DeRef(_12469);
        _12469 = 0;
        goto L28; // [596] 604
    }
    _12469 = (_for_translator_21978 != 0);
L28: 
    if (_12469 == 0)
    {
        _12469 = NOVALUE;
        goto L29; // [605] 624
    }
    else{
        _12469 = NOVALUE;
    }
L27: 

    /** platform.e:244			local_defines &= {"X86", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12369);
    ((intptr_t*)_2)[1] = _12369;
    RefDS(_12470);
    ((intptr_t*)_2)[2] = _12470;
    RefDS(_12471);
    ((intptr_t*)_2)[3] = _12471;
    _12472 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12472);
    DeRefDS(_12472);
    _12472 = NOVALUE;
    goto L2A; // [621] 777
L29: 

    /** platform.e:246		elsif (IX86_64 and not for_translator) or (TX86_64 and for_translator) then*/
    if (_46IX86_64_21921 == 0) {
        _12474 = 0;
        goto L2B; // [628] 639
    }
    _12475 = (_for_translator_21978 == 0);
    _12474 = (_12475 != 0);
L2B: 
    if (_12474 != 0) {
        goto L2C; // [639] 658
    }
    if (_46TX86_64_21922 == 0) {
        DeRef(_12477);
        _12477 = 0;
        goto L2D; // [645] 653
    }
    _12477 = (_for_translator_21978 != 0);
L2D: 
    if (_12477 == 0)
    {
        _12477 = NOVALUE;
        goto L2E; // [654] 729
    }
    else{
        _12477 = NOVALUE;
    }
L2C: 

    /** platform.e:247			local_defines &= {"X86_64", "BITS64"}*/
    RefDS(_12478);
    RefDS(_12371);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _12371;
    ((intptr_t *)_2)[2] = _12478;
    _12479 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12479);
    DeRefDS(_12479);
    _12479 = NOVALUE;

    /** platform.e:248			if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_46IWINDOWS_21905 == 0) {
        _12481 = 0;
        goto L2F; // [672] 683
    }
    _12482 = (_for_translator_21978 == 0);
    _12481 = (_12482 != 0);
L2F: 
    if (_12481 != 0) {
        goto L30; // [683] 702
    }
    if (_46TWINDOWS_21906 == 0) {
        DeRef(_12484);
        _12484 = 0;
        goto L31; // [689] 697
    }
    _12484 = (_for_translator_21978 != 0);
L31: 
    if (_12484 == 0)
    {
        _12484 = NOVALUE;
        goto L32; // [698] 715
    }
    else{
        _12484 = NOVALUE;
    }
L30: 

    /** platform.e:249				local_defines &= {"LONG32"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12471);
    ((intptr_t*)_2)[1] = _12471;
    _12485 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12485);
    DeRefDS(_12485);
    _12485 = NOVALUE;
    goto L2A; // [712] 777
L32: 

    /** platform.e:251				local_defines &= {"LONG64"}*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12487);
    ((intptr_t*)_2)[1] = _12487;
    _12488 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12488);
    DeRefDS(_12488);
    _12488 = NOVALUE;
    goto L2A; // [726] 777
L2E: 

    /** platform.e:253		elsif (IARM and not for_translator) or (TARM and for_translator) then*/
    if (_46IARM_21923 == 0) {
        _12490 = 0;
        goto L33; // [733] 744
    }
    _12491 = (_for_translator_21978 == 0);
    _12490 = (_12491 != 0);
L33: 
    if (_12490 != 0) {
        goto L34; // [744] 763
    }
    if (_46TARM_21924 == 0) {
        DeRef(_12493);
        _12493 = 0;
        goto L35; // [750] 758
    }
    _12493 = (_for_translator_21978 != 0);
L35: 
    if (_12493 == 0)
    {
        _12493 = NOVALUE;
        goto L36; // [759] 776
    }
    else{
        _12493 = NOVALUE;
    }
L34: 

    /** platform.e:254			local_defines &= {"ARM", "BITS32", "LONG32"}*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12373);
    ((intptr_t*)_2)[1] = _12373;
    RefDS(_12470);
    ((intptr_t*)_2)[2] = _12470;
    RefDS(_12471);
    ((intptr_t*)_2)[3] = _12471;
    _12494 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_21979, _local_defines_21979, _12494);
    DeRefDS(_12494);
    _12494 = NOVALUE;
L36: 
L2A: 

    /** platform.e:259		return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12496);
    ((intptr_t*)_2)[1] = _12496;
    _12497 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_12498);
    ((intptr_t*)_2)[1] = _12498;
    _12499 = MAKE_SEQ(_1);
    {
        object concat_list[3];

        concat_list[0] = _12499;
        concat_list[1] = _local_defines_21979;
        concat_list[2] = _12497;
        Concat_N((object_ptr)&_12500, concat_list, 3);
    }
    DeRefDS(_12499);
    _12499 = NOVALUE;
    DeRefDS(_12497);
    _12497 = NOVALUE;
    DeRefDS(_local_defines_21979);
    DeRef(_12482);
    _12482 = NOVALUE;
    DeRef(_12453);
    _12453 = NOVALUE;
    DeRef(_12475);
    _12475 = NOVALUE;
    DeRef(_12491);
    _12491 = NOVALUE;
    DeRef(_12467);
    _12467 = NOVALUE;
    DeRef(_12377);
    _12377 = NOVALUE;
    DeRef(_12431);
    _12431 = NOVALUE;
    DeRef(_12446);
    _12446 = NOVALUE;
    DeRef(_12460);
    _12460 = NOVALUE;
    DeRef(_12438);
    _12438 = NOVALUE;
    return _12500;
    ;
}



// 0x41A8448D
