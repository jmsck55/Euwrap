// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _54hashfn(object _name_47147)
{
    object _len_47148 = NOVALUE;
    object _val_47149 = NOVALUE;
    object _int_47150 = NOVALUE;
    object _24509 = NOVALUE;
    object _24508 = NOVALUE;
    object _24505 = NOVALUE;
    object _24504 = NOVALUE;
    object _24493 = NOVALUE;
    object _24489 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_47147)){
            _len_47148 = SEQ_PTR(_name_47147)->length;
    }
    else {
        _len_47148 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_47147);
    _val_47149 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_val_47149))
    _val_47149 = (object)DBL_PTR(_val_47149)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_47147)){
            _24489 = SEQ_PTR(_name_47147)->length;
    }
    else {
        _24489 = 1;
    }
    _2 = (object)SEQ_PTR(_name_47147);
    _int_47150 = (object)*(((s1_ptr)_2)->base + _24489);
    if (!IS_ATOM_INT(_int_47150))
    _int_47150 = (object)DBL_PTR(_int_47150)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_47150 = _int_47150 * 256LL;

    /** symtab.e:54		val *= 2*/
    _val_47149 = _val_47149 + _val_47149;

    /** symtab.e:55		val += int + len*/
    _24493 = _int_47150 + _len_47148;
    if ((object)((uintptr_t)_24493 + (uintptr_t)HIGH_BITS) >= 0){
        _24493 = NewDouble((eudouble)_24493);
    }
    if (IS_ATOM_INT(_24493)) {
        _val_47149 = _val_47149 + _24493;
    }
    else {
        _val_47149 = NewDouble((eudouble)_val_47149 + DBL_PTR(_24493)->dbl);
    }
    DeRef(_24493);
    _24493 = NOVALUE;
    if (!IS_ATOM_INT(_val_47149)) {
        _1 = (object)(DBL_PTR(_val_47149)->dbl);
        DeRefDS(_val_47149);
        _val_47149 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_47148 != 3LL)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_47149 = _val_47149 * 32LL;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47147);
    _int_47150 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_47150))
    _int_47150 = (object)DBL_PTR(_int_47150)->dbl;

    /** symtab.e:60			val += int*/
    _val_47149 = _val_47149 + _int_47150;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_47148 <= 3LL)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_47149 = _val_47149 * 32LL;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_47147);
    _int_47150 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_47150))
    _int_47150 = (object)DBL_PTR(_int_47150)->dbl;

    /** symtab.e:64			val += int*/
    _val_47149 = _val_47149 + _int_47150;

    /** symtab.e:66			val *= 32*/
    _val_47149 = _val_47149 * 32LL;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_47147)){
            _24504 = SEQ_PTR(_name_47147)->length;
    }
    else {
        _24504 = 1;
    }
    _24505 = _24504 - 1LL;
    _24504 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_47147);
    _int_47150 = (object)*(((s1_ptr)_2)->base + _24505);
    if (!IS_ATOM_INT(_int_47150))
    _int_47150 = (object)DBL_PTR(_int_47150)->dbl;

    /** symtab.e:68			val += int*/
    _val_47149 = _val_47149 + _int_47150;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24508 = (_val_47149 % 2003LL);
    _24509 = _24508 + 1;
    _24508 = NOVALUE;
    DeRefDS(_name_47147);
    DeRef(_24505);
    _24505 = NOVALUE;
    return _24509;
    ;
}


void _54remove_symbol(object _sym_47179)
{
    object _hash_47180 = NOVALUE;
    object _st_ptr_47181 = NOVALUE;
    object _24524 = NOVALUE;
    object _24523 = NOVALUE;
    object _24521 = NOVALUE;
    object _24520 = NOVALUE;
    object _24519 = NOVALUE;
    object _24517 = NOVALUE;
    object _24515 = NOVALUE;
    object _24514 = NOVALUE;
    object _24513 = NOVALUE;
    object _24510 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24510 = (object)*(((s1_ptr)_2)->base + _sym_47179);
    _2 = (object)SEQ_PTR(_24510);
    _hash_47180 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hash_47180)){
        _hash_47180 = (object)DBL_PTR(_hash_47180)->dbl;
    }
    _24510 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _st_ptr_47181 = (object)*(((s1_ptr)_2)->base + _hash_47180);
    if (!IS_ATOM_INT(_st_ptr_47181))
    _st_ptr_47181 = (object)DBL_PTR(_st_ptr_47181)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_47181 == 0) {
        goto L2; // [32] 65
    }
    _24514 = (_st_ptr_47181 != _sym_47179);
    if (_24514 == 0)
    {
        DeRef(_24514);
        _24514 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24514);
        _24514 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24515 = (object)*(((s1_ptr)_2)->base + _st_ptr_47181);
    _2 = (object)SEQ_PTR(_24515);
    _st_ptr_47181 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_47181)){
        _st_ptr_47181 = (object)DBL_PTR(_st_ptr_47181)->dbl;
    }
    _24515 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_47181 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _24517 = (object)*(((s1_ptr)_2)->base + _hash_47180);
    if (binary_op_a(NOTEQ, _st_ptr_47181, _24517)){
        _24517 = NOVALUE;
        goto L4; // [78] 105
    }
    _24517 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24519 = (object)*(((s1_ptr)_2)->base + _st_ptr_47181);
    _2 = (object)SEQ_PTR(_24519);
    _24520 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24519 = NOVALUE;
    Ref(_24520);
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _2 = (object)(((s1_ptr)_2)->base + _hash_47180);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24520;
    if( _1 != _24520 ){
        DeRef(_1);
    }
    _24520 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_47181 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24523 = (object)*(((s1_ptr)_2)->base + _sym_47179);
    _2 = (object)SEQ_PTR(_24523);
    _24524 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24523 = NOVALUE;
    Ref(_24524);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24524;
    if( _1 != _24524 ){
        DeRef(_1);
    }
    _24524 = NOVALUE;
    _24521 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _54NewBasicEntry(object _name_47213, object _varnum_47214, object _scope_47215, object _token_47216, object _hashval_47217, object _samehash_47219, object _type_sym_47221)
{
    object _new_47222 = NOVALUE;
    object _24533 = NOVALUE;
    object _24531 = NOVALUE;
    object _24530 = NOVALUE;
    object _24529 = NOVALUE;
    object _24528 = NOVALUE;
    object _24527 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_47222);
    _new_47222 = Repeat(0LL, _36SIZEOF_ROUTINE_ENTRY_21522);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_47222);
    _new_47222 = Repeat(0LL, _36SIZEOF_VAR_ENTRY_21525);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_47213);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21396))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21396);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_47213;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_47215;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21392))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21759;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _24527 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24527 = - _36NOVALUE_21613;
        }
    }
    else {
        _24527 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24527;
    if( _1 != _24527 ){
        DeRef(_1);
    }
    _24527 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _24528 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24528 = - _36NOVALUE_21613;
        }
    }
    else {
        _24528 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24528;
    if( _1 != _24528 ){
        DeRef(_1);
    }
    _24528 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _24529 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24529 = - _36NOVALUE_21613;
        }
    }
    else {
        _24529 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24529;
    if( _1 != _24529 ){
        DeRef(_1);
    }
    _24529 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13TRUE_447;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    Ref(_36MININT_21583);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MININT_21583;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _24530 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24530 = - _36NOVALUE_21613;
        }
    }
    else {
        _24530 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24530;
    if( _1 != _24530 ){
        DeRef(_1);
    }
    _24530 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    Ref(_36MAXINT_21582);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21582;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _24531 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24531 = - _36NOVALUE_21613;
        }
    }
    else {
        _24531 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24531;
    if( _1 != _24531 ){
        DeRef(_1);
    }
    _24531 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21401))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_47216;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_47214;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_47221;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_47217;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_47219;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_new_47222);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_47222 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_47222);
    Append(&_37SymTab_15637, _37SymTab_15637, _new_47222);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _24533 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _24533 = 1;
    }
    DeRefDS(_name_47213);
    DeRefDS(_new_47222);
    return _24533;
    ;
}


object _54NewEntry(object _name_47301, object _varnum_47302, object _scope_47303, object _token_47304, object _hashval_47305, object _samehash_47307, object _type_sym_47309)
{
    object _new_47311 = NOVALUE;
    object _24535 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_47303)) {
        _1 = (object)(DBL_PTR(_scope_47303)->dbl);
        DeRefDS(_scope_47303);
        _scope_47303 = _1;
    }
    if (!IS_ATOM_INT(_token_47304)) {
        _1 = (object)(DBL_PTR(_token_47304)->dbl);
        DeRefDS(_token_47304);
        _token_47304 = _1;
    }
    if (!IS_ATOM_INT(_samehash_47307)) {
        _1 = (object)(DBL_PTR(_samehash_47307)->dbl);
        DeRefDS(_samehash_47307);
        _samehash_47307 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_47301);
    _new_47311 = _54NewBasicEntry(_name_47301, _varnum_47302, _scope_47303, _token_47304, _hashval_47305, _samehash_47307, _type_sym_47309);
    if (!IS_ATOM_INT(_new_47311)) {
        _1 = (object)(DBL_PTR(_new_47311)->dbl);
        DeRefDS(_new_47311);
        _new_47311 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_54last_sym_47141 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_47141 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_47311;
    DeRef(_1);
    _24535 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _54last_sym_47141 = _new_47311;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_47309 >= 0LL)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _44register_forward_type(_54last_sym_47141, _type_sym_47309);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_47301);
    return _54last_sym_47141;
    ;
}


object _54tmp_alloc()
{
    object _new_entry_47326 = NOVALUE;
    object _24549 = NOVALUE;
    object _24547 = NOVALUE;
    object _24544 = NOVALUE;
    object _24541 = NOVALUE;
    object _24540 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_47326);
    _new_entry_47326 = Repeat(0LL, _36SIZEOF_TEMP_ENTRY_21531);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    *(intptr_t *)_2 = 4LL;

    /** symtab.e:194		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    *(intptr_t *)_2 = 16LL;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    Ref(_36MININT_21583);
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    *(intptr_t *)_2 = _36MININT_21583;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    Ref(_36MAXINT_21582);
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21582;
    DeRef(_1);

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_36temp_name_type_21845)){
            _24540 = SEQ_PTR(_36temp_name_type_21845)->length;
    }
    else {
        _24540 = 1;
    }
    _24541 = _24540 + 1;
    _24540 = NOVALUE;
    if (_24541 != 8087LL)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _24544 = MAKE_SEQ(_1);
    RefDS(_24544);
    Append(&_36temp_name_type_21845, _36temp_name_type_21845, _24544);
    DeRefDS(_24544);
    _24544 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_55TYPES_OBNL_46966);
    Append(&_36temp_name_type_21845, _36temp_name_type_21845, _55TYPES_OBNL_46966);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_36temp_name_type_21845)){
            _24547 = SEQ_PTR(_36temp_name_type_21845)->length;
    }
    else {
        _24547 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_47326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_47326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24547;
    if( _1 != _24547 ){
        DeRef(_1);
    }
    _24547 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_47326);
    Append(&_37SymTab_15637, _37SymTab_15637, _new_entry_47326);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _24549 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _24549 = 1;
    }
    DeRefDS(_new_entry_47326);
    DeRef(_24541);
    _24541 = NOVALUE;
    return _24549;
    ;
}


void _54DefinedYet(object _sym_47395)
{
    object _24569 = NOVALUE;
    object _24568 = NOVALUE;
    object _24567 = NOVALUE;
    object _24565 = NOVALUE;
    object _24564 = NOVALUE;
    object _24562 = NOVALUE;
    object _24561 = NOVALUE;
    object _24560 = NOVALUE;
    object _24559 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24559 = (object)*(((s1_ptr)_2)->base + _sym_47395);
    _2 = (object)SEQ_PTR(_24559);
    _24560 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24559 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9LL;
    ((intptr_t*)_2)[2] = 10LL;
    ((intptr_t*)_2)[3] = 7LL;
    _24561 = MAKE_SEQ(_1);
    _24562 = find_from(_24560, _24561, 1LL);
    _24560 = NOVALUE;
    DeRefDS(_24561);
    _24561 = NOVALUE;
    if (_24562 != 0)
    goto L1; // [34] 84
    _24562 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24564 = (object)*(((s1_ptr)_2)->base + _sym_47395);
    _2 = (object)SEQ_PTR(_24564);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _24565 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _24565 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _24564 = NOVALUE;
    if (binary_op_a(NOTEQ, _24565, _36current_file_no_21759)){
        _24565 = NOVALUE;
        goto L2; // [53] 83
    }
    _24565 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24567 = (object)*(((s1_ptr)_2)->base + _sym_47395);
    _2 = (object)SEQ_PTR(_24567);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _24568 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _24568 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _24567 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24568);
    ((intptr_t*)_2)[1] = _24568;
    _24569 = MAKE_SEQ(_1);
    _24568 = NOVALUE;
    _50CompileErr(31LL, _24569, 0LL);
    _24569 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _54name_ext(object _s_47423)
{
    object _24576 = NOVALUE;
    object _24575 = NOVALUE;
    object _24574 = NOVALUE;
    object _24573 = NOVALUE;
    object _24571 = NOVALUE;
    object _24570 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47423)){
            _24570 = SEQ_PTR(_s_47423)->length;
    }
    else {
        _24570 = 1;
    }
    {
        object _i_47425;
        _i_47425 = _24570;
L1: 
        if (_i_47425 < 1LL){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47423);
        _24571 = (object)*(((s1_ptr)_2)->base + _i_47425);
        _24573 = find_from(_24571, _24572, 1LL);
        _24571 = NOVALUE;
        if (_24573 == 0)
        {
            _24573 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24573 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24574 = _i_47425 + 1;
        if (IS_SEQUENCE(_s_47423)){
                _24575 = SEQ_PTR(_s_47423)->length;
        }
        else {
            _24575 = 1;
        }
        rhs_slice_target = (object_ptr)&_24576;
        RHS_Slice(_s_47423, _24574, _24575);
        DeRefDS(_s_47423);
        _24574 = NOVALUE;
        return _24576;
L3: 

        /** symtab.e:245		end for*/
        _i_47425 = _i_47425 + -1LL;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24576);
    _24576 = NOVALUE;
    DeRef(_24574);
    _24574 = NOVALUE;
    return _s_47423;
    ;
}


object _54NewStringSym(object _s_47442)
{
    object _p_47444 = NOVALUE;
    object _tp_47445 = NOVALUE;
    object _prev_47446 = NOVALUE;
    object _search_count_47447 = NOVALUE;
    object _24620 = NOVALUE;
    object _24618 = NOVALUE;
    object _24617 = NOVALUE;
    object _24616 = NOVALUE;
    object _24614 = NOVALUE;
    object _24613 = NOVALUE;
    object _24610 = NOVALUE;
    object _24608 = NOVALUE;
    object _24606 = NOVALUE;
    object _24605 = NOVALUE;
    object _24604 = NOVALUE;
    object _24602 = NOVALUE;
    object _24600 = NOVALUE;
    object _24598 = NOVALUE;
    object _24596 = NOVALUE;
    object _24593 = NOVALUE;
    object _24591 = NOVALUE;
    object _24590 = NOVALUE;
    object _24589 = NOVALUE;
    object _24587 = NOVALUE;
    object _24585 = NOVALUE;
    object _24584 = NOVALUE;
    object _24583 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47445 = _54literal_init_47140;

    /** symtab.e:259		prev = 0*/
    _prev_47446 = 0LL;

    /** symtab.e:260		search_count = 0*/
    _search_count_47447 = 0LL;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47445 == 0LL)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47447 = _search_count_47447 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47447, _54SEARCH_LIMIT_47434)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24583 = (object)*(((s1_ptr)_2)->base + _tp_47445);
    _2 = (object)SEQ_PTR(_24583);
    _24584 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24583 = NOVALUE;
    if (_s_47442 == _24584)
    _24585 = 1;
    else if (IS_ATOM_INT(_s_47442) && IS_ATOM_INT(_24584))
    _24585 = 0;
    else
    _24585 = (compare(_s_47442, _24584) == 0);
    _24584 = NOVALUE;
    if (_24585 == 0)
    {
        _24585 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24585 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47445 == _54literal_init_47140)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47446 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24589 = (object)*(((s1_ptr)_2)->base + _tp_47445);
    _2 = (object)SEQ_PTR(_24589);
    _24590 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24589 = NOVALUE;
    Ref(_24590);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24590;
    if( _1 != _24590 ){
        DeRef(_1);
    }
    _24590 = NOVALUE;
    _24587 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47445 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47140;
    DeRef(_1);
    _24591 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _54literal_init_47140 = _tp_47445;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47442);
    return _tp_47445;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47446 = _tp_47445;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24593 = (object)*(((s1_ptr)_2)->base + _tp_47445);
    _2 = (object)SEQ_PTR(_24593);
    _tp_47445 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47445)){
        _tp_47445 = (object)DBL_PTR(_tp_47445)->dbl;
    }
    _24593 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47444 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47444)) {
        _1 = (object)(DBL_PTR(_p_47444)->dbl);
        DeRefDS(_p_47444);
        _p_47444 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    RefDS(_s_47442);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47442;
    DeRef(_1);
    _24596 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24598 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _24600 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47442)){
            _24604 = SEQ_PTR(_s_47442)->length;
    }
    else {
        _24604 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24604;
    if( _1 != _24604 ){
        DeRef(_1);
    }
    _24604 = NOVALUE;
    _24602 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24605 = (object)*(((s1_ptr)_2)->base + _p_47444);
    _2 = (object)SEQ_PTR(_24605);
    _24606 = (object)*(((s1_ptr)_2)->base + 32LL);
    _24605 = NOVALUE;
    if (binary_op_a(LESSEQ, _24606, 0LL)){
        _24606 = NOVALUE;
        goto L7; // [265] 289
    }
    _24606 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24608 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _24610 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24613 = (object)*(((s1_ptr)_2)->base + _p_47444);
    _2 = (object)SEQ_PTR(_24613);
    _24614 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24613 = NOVALUE;
    RefDS(_24612);
    Ref(_24614);
    _55c_printf(_24612, _24614);
    _24614 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24616 = (object)*(((s1_ptr)_2)->base + _p_47444);
    _2 = (object)SEQ_PTR(_24616);
    _24617 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24616 = NOVALUE;
    RefDS(_24615);
    Ref(_24617);
    _55c_hprintf(_24615, _24617);
    _24617 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24618 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47444 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47140;
    DeRef(_1);
    _24620 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _54literal_init_47140 = _p_47444;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47442);
    return _p_47444;
    ;
}


object _54NewIntSym(object _int_val_47540)
{
    object _p_47542 = NOVALUE;
    object _x_47543 = NOVALUE;
    object _24644 = NOVALUE;
    object _24642 = NOVALUE;
    object _24638 = NOVALUE;
    object _24636 = NOVALUE;
    object _24634 = NOVALUE;
    object _24632 = NOVALUE;
    object _24630 = NOVALUE;
    object _24628 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47543 = find_from(_int_val_47540, _54lastintval_47142, 1LL);

    /** symtab.e:311		if x then*/
    if (_x_47543 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_54lastintsym_47143);
    _24628 = (object)*(((s1_ptr)_2)->base + _x_47543);
    DeRef(_int_val_47540);
    return _24628;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47542 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47542)) {
        _1 = (object)(DBL_PTR(_p_47542)->dbl);
        DeRefDS(_p_47542);
        _p_47542 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47542 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24630 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47542 + ((s1_ptr)_2)->base);
    Ref(_int_val_47540);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47540;
    DeRef(_1);
    _24632 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47542 + ((s1_ptr)_2)->base);
    Ref(_int_val_47540);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47540;
    DeRef(_1);
    _24634 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47542 + ((s1_ptr)_2)->base);
    Ref(_int_val_47540);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47540;
    DeRef(_1);
    _24636 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47542 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24638 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47540);
    Prepend(&_54lastintval_47142, _54lastintval_47142, _int_val_47540);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_54lastintsym_47143, _54lastintsym_47143, _p_47542);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_54lastintval_47142)){
            _24642 = SEQ_PTR(_54lastintval_47142)->length;
    }
    else {
        _24642 = 1;
    }
    if (binary_op_a(LESSEQ, _24642, _54SEARCH_LIMIT_47434)){
        _24642 = NOVALUE;
        goto L5; // [198] 218
    }
    _24642 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_54SEARCH_LIMIT_47434)) {
        _24644 = _54SEARCH_LIMIT_47434 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _54SEARCH_LIMIT_47434, 2);
        _24644 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_54lastintval_47142;
    RHS_Slice(_54lastintval_47142, 1LL, _24644);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47540);
    DeRef(_24644);
    _24644 = NOVALUE;
    _24628 = NOVALUE;
    return _p_47542;
L2: 
    ;
}


object _54NewDoubleSym(object _d_47592)
{
    object _p_47594 = NOVALUE;
    object _tp_47595 = NOVALUE;
    object _prev_47596 = NOVALUE;
    object _search_count_47597 = NOVALUE;
    object _24674 = NOVALUE;
    object _24673 = NOVALUE;
    object _24672 = NOVALUE;
    object _24671 = NOVALUE;
    object _24670 = NOVALUE;
    object _24668 = NOVALUE;
    object _24666 = NOVALUE;
    object _24664 = NOVALUE;
    object _24662 = NOVALUE;
    object _24659 = NOVALUE;
    object _24657 = NOVALUE;
    object _24656 = NOVALUE;
    object _24655 = NOVALUE;
    object _24653 = NOVALUE;
    object _24651 = NOVALUE;
    object _24650 = NOVALUE;
    object _24649 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47595 = _54literal_init_47140;

    /** symtab.e:347		prev = 0*/
    _prev_47596 = 0LL;

    /** symtab.e:348		search_count = 0*/
    _search_count_47597 = 0LL;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47595 == 0LL)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47597 = _search_count_47597 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47597, _54SEARCH_LIMIT_47434)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24649 = (object)*(((s1_ptr)_2)->base + _tp_47595);
    _2 = (object)SEQ_PTR(_24649);
    _24650 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24649 = NOVALUE;
    if (_d_47592 == _24650)
    _24651 = 1;
    else if (IS_ATOM_INT(_d_47592) && IS_ATOM_INT(_24650))
    _24651 = 0;
    else
    _24651 = (compare(_d_47592, _24650) == 0);
    _24650 = NOVALUE;
    if (_24651 == 0)
    {
        _24651 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24651 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47595 == _54literal_init_47140)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47596 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24655 = (object)*(((s1_ptr)_2)->base + _tp_47595);
    _2 = (object)SEQ_PTR(_24655);
    _24656 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24655 = NOVALUE;
    Ref(_24656);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24656;
    if( _1 != _24656 ){
        DeRef(_1);
    }
    _24656 = NOVALUE;
    _24653 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47595 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47140;
    DeRef(_1);
    _24657 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _54literal_init_47140 = _tp_47595;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47592);
    return _tp_47595;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47596 = _tp_47595;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24659 = (object)*(((s1_ptr)_2)->base + _tp_47595);
    _2 = (object)SEQ_PTR(_24659);
    _tp_47595 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47595)){
        _tp_47595 = (object)DBL_PTR(_tp_47595)->dbl;
    }
    _24659 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47594 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47594)) {
        _1 = (object)(DBL_PTR(_p_47594)->dbl);
        DeRefDS(_p_47594);
        _p_47594 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24662 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    Ref(_d_47592);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47592;
    DeRef(_1);
    _24664 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24666 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24668 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24670 = (object)*(((s1_ptr)_2)->base + _p_47594);
    _2 = (object)SEQ_PTR(_24670);
    _24671 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24670 = NOVALUE;
    RefDS(_24612);
    Ref(_24671);
    _55c_printf(_24612, _24671);
    _24671 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24672 = (object)*(((s1_ptr)_2)->base + _p_47594);
    _2 = (object)SEQ_PTR(_24672);
    _24673 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24672 = NOVALUE;
    RefDS(_24615);
    Ref(_24673);
    _55c_hprintf(_24615, _24673);
    _24673 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47594 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_47140;
    DeRef(_1);
    _24674 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _54literal_init_47140 = _p_47594;

    /** symtab.e:381		return p*/
    DeRef(_d_47592);
    return _p_47594;
    ;
}


object _54NewTempSym(object _inlining_47666)
{
    object _p_47668 = NOVALUE;
    object _q_47669 = NOVALUE;
    object _24723 = NOVALUE;
    object _24721 = NOVALUE;
    object _24719 = NOVALUE;
    object _24717 = NOVALUE;
    object _24715 = NOVALUE;
    object _24713 = NOVALUE;
    object _24712 = NOVALUE;
    object _24711 = NOVALUE;
    object _24709 = NOVALUE;
    object _24708 = NOVALUE;
    object _24707 = NOVALUE;
    object _24705 = NOVALUE;
    object _24703 = NOVALUE;
    object _24700 = NOVALUE;
    object _24699 = NOVALUE;
    object _24698 = NOVALUE;
    object _24696 = NOVALUE;
    object _24694 = NOVALUE;
    object _24693 = NOVALUE;
    object _24692 = NOVALUE;
    object _24690 = NOVALUE;
    object _24688 = NOVALUE;
    object _24683 = NOVALUE;
    object _24682 = NOVALUE;
    object _24681 = NOVALUE;
    object _24680 = NOVALUE;
    object _24679 = NOVALUE;
    object _24678 = NOVALUE;
    object _24676 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47666 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24676 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_24676);
    if (!IS_ATOM_INT(_36S_TEMPS_21441)){
        _p_47668 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21441)->dbl));
    }
    else{
        _p_47668 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21441);
    }
    if (!IS_ATOM_INT(_p_47668)){
        _p_47668 = (object)DBL_PTR(_p_47668)->dbl;
    }
    _24676 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24678 = (_p_47668 != 0LL);
    if (_24678 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24680 = (object)*(((s1_ptr)_2)->base + _p_47668);
    _2 = (object)SEQ_PTR(_24680);
    _24681 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24680 = NOVALUE;
    if (IS_ATOM_INT(_24681)) {
        _24682 = (_24681 != 0LL);
    }
    else {
        _24682 = binary_op(NOTEQ, _24681, 0LL);
    }
    _24681 = NOVALUE;
    if (_24682 <= 0) {
        if (_24682 == 0) {
            DeRef(_24682);
            _24682 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24682) && DBL_PTR(_24682)->dbl == 0.0){
                DeRef(_24682);
                _24682 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24682);
            _24682 = NOVALUE;
        }
    }
    DeRef(_24682);
    _24682 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24683 = (object)*(((s1_ptr)_2)->base + _p_47668);
    _2 = (object)SEQ_PTR(_24683);
    _p_47668 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47668)){
        _p_47668 = (object)DBL_PTR(_p_47668)->dbl;
    }
    _24683 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47668 = 0LL;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47668 != 0LL)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _54temps_allocated_47663 = _54temps_allocated_47663 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47668 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47668)) {
        _1 = (object)(DBL_PTR(_p_47668)->dbl);
        DeRefDS(_p_47668);
        _p_47668 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24688 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24692 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_24692);
    if (!IS_ATOM_INT(_36S_TEMPS_21441)){
        _24693 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21441)->dbl));
    }
    else{
        _24693 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21441);
    }
    _24692 = NOVALUE;
    Ref(_24693);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24693;
    if( _1 != _24693 ){
        DeRef(_1);
    }
    _24693 = NOVALUE;
    _24690 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21767 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21441))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21441)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21441);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47668;
    DeRef(_1);
    _24694 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47666 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21767 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456)){
        _24698 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    }
    else{
        _24698 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    }
    _24696 = NOVALUE;
    if (IS_ATOM_INT(_24698)) {
        _24699 = _24698 + 1;
        if (_24699 > MAXINT){
            _24699 = NewDouble((eudouble)_24699);
        }
    }
    else
    _24699 = binary_op(PLUS, 1, _24698);
    _24698 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24699;
    if( _1 != _24699 ){
        DeRef(_1);
    }
    _24699 = NOVALUE;
    _24696 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24700 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47669 = _54tmp_alloc();
    if (!IS_ATOM_INT(_q_47669)) {
        _1 = (object)(DBL_PTR(_q_47669)->dbl);
        DeRefDS(_q_47669);
        _q_47669 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47669 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24703 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47669 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24707 = (object)*(((s1_ptr)_2)->base + _p_47668);
    _2 = (object)SEQ_PTR(_24707);
    _24708 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24707 = NOVALUE;
    Ref(_24708);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24708;
    if( _1 != _24708 ){
        DeRef(_1);
    }
    _24708 = NOVALUE;
    _24705 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47669 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24711 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_24711);
    if (!IS_ATOM_INT(_36S_TEMPS_21441)){
        _24712 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21441)->dbl));
    }
    else{
        _24712 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21441);
    }
    _24711 = NOVALUE;
    Ref(_24712);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24712;
    if( _1 != _24712 ){
        DeRef(_1);
    }
    _24712 = NOVALUE;
    _24709 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21767 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21441))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21441)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21441);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47669;
    DeRef(_1);
    _24713 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47668 = _q_47669;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24715 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24717 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    _24719 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _24721 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47668 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24723 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24678);
    _24678 = NOVALUE;
    return _p_47668;
    ;
}


void _54InitSymTab()
{
    object _hashval_47785 = NOVALUE;
    object _len_47786 = NOVALUE;
    object _s_47788 = NOVALUE;
    object _st_index_47789 = NOVALUE;
    object _kname_47790 = NOVALUE;
    object _fixups_47791 = NOVALUE;
    object _si_47930 = NOVALUE;
    object _sj_47931 = NOVALUE;
    object _25309 = NOVALUE;
    object _25308 = NOVALUE;
    object _24838 = NOVALUE;
    object _24837 = NOVALUE;
    object _24836 = NOVALUE;
    object _24835 = NOVALUE;
    object _24834 = NOVALUE;
    object _24832 = NOVALUE;
    object _24831 = NOVALUE;
    object _24830 = NOVALUE;
    object _24829 = NOVALUE;
    object _24827 = NOVALUE;
    object _24825 = NOVALUE;
    object _24823 = NOVALUE;
    object _24822 = NOVALUE;
    object _24820 = NOVALUE;
    object _24818 = NOVALUE;
    object _24816 = NOVALUE;
    object _24815 = NOVALUE;
    object _24813 = NOVALUE;
    object _24812 = NOVALUE;
    object _24811 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24802 = NOVALUE;
    object _24801 = NOVALUE;
    object _24800 = NOVALUE;
    object _24798 = NOVALUE;
    object _24797 = NOVALUE;
    object _24796 = NOVALUE;
    object _24793 = NOVALUE;
    object _24791 = NOVALUE;
    object _24789 = NOVALUE;
    object _24788 = NOVALUE;
    object _24785 = NOVALUE;
    object _24784 = NOVALUE;
    object _24782 = NOVALUE;
    object _24780 = NOVALUE;
    object _24778 = NOVALUE;
    object _24776 = NOVALUE;
    object _24775 = NOVALUE;
    object _24774 = NOVALUE;
    object _24771 = NOVALUE;
    object _24770 = NOVALUE;
    object _24768 = NOVALUE;
    object _24767 = NOVALUE;
    object _24765 = NOVALUE;
    object _24764 = NOVALUE;
    object _24763 = NOVALUE;
    object _24761 = NOVALUE;
    object _24759 = NOVALUE;
    object _24758 = NOVALUE;
    object _24756 = NOVALUE;
    object _24755 = NOVALUE;
    object _24754 = NOVALUE;
    object _24752 = NOVALUE;
    object _24751 = NOVALUE;
    object _24750 = NOVALUE;
    object _24748 = NOVALUE;
    object _24747 = NOVALUE;
    object _24746 = NOVALUE;
    object _24744 = NOVALUE;
    object _24743 = NOVALUE;
    object _24742 = NOVALUE;
    object _24741 = NOVALUE;
    object _24740 = NOVALUE;
    object _24739 = NOVALUE;
    object _24738 = NOVALUE;
    object _24737 = NOVALUE;
    object _24736 = NOVALUE;
    object _24735 = NOVALUE;
    object _24733 = NOVALUE;
    object _24732 = NOVALUE;
    object _24731 = NOVALUE;
    object _24730 = NOVALUE;
    object _24726 = NOVALUE;
    object _24725 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_22186);
    DeRefi(_fixups_47791);
    _fixups_47791 = _22186;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23435)){
            _24725 = SEQ_PTR(_63keylist_23435)->length;
    }
    else {
        _24725 = 1;
    }
    {
        object _k_47793;
        _k_47793 = 1LL;
L1: 
        if (_k_47793 > _24725){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24726 = (object)*(((s1_ptr)_2)->base + _k_47793);
        DeRef(_kname_47790);
        _2 = (object)SEQ_PTR(_24726);
        _kname_47790 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_kname_47790);
        _24726 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47790)){
                _len_47786 = SEQ_PTR(_kname_47790)->length;
        }
        else {
            _len_47786 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47790);
        _hashval_47785 = _54hashfn(_kname_47790);
        if (!IS_ATOM_INT(_hashval_47785)) {
            _1 = (object)(DBL_PTR(_hashval_47785)->dbl);
            DeRefDS(_hashval_47785);
            _hashval_47785 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24730 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24730);
        _24731 = (object)*(((s1_ptr)_2)->base + 2LL);
        _24730 = NOVALUE;
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24732 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24732);
        _24733 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24732 = NOVALUE;
        RefDS(_kname_47790);
        Ref(_24731);
        Ref(_24733);
        _st_index_47789 = _54NewEntry(_kname_47790, 0LL, _24731, _24733, _hashval_47785, 0LL, 0LL);
        _24731 = NOVALUE;
        _24733 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47789)) {
            _1 = (object)(DBL_PTR(_st_index_47789)->dbl);
            DeRefDS(_st_index_47789);
            _st_index_47789 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24735 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24735);
        _24736 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24735 = NOVALUE;
        _24737 = find_from(_24736, _38RTN_TOKS_16291, 1LL);
        _24736 = NOVALUE;
        if (_24737 == 0)
        {
            _24737 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24737 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24738 = (object)*(((s1_ptr)_2)->base + _st_index_47789);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24739 = (object)*(((s1_ptr)_2)->base + _st_index_47789);
        if (IS_SEQUENCE(_24739)){
                _24740 = SEQ_PTR(_24739)->length;
        }
        else {
            _24740 = 1;
        }
        _24739 = NOVALUE;
        _24741 = _36SIZEOF_ROUTINE_ENTRY_21522 - _24740;
        _24740 = NOVALUE;
        _24742 = Repeat(0LL, _24741);
        _24741 = NOVALUE;
        if (IS_SEQUENCE(_24738) && IS_ATOM(_24742)) {
        }
        else if (IS_ATOM(_24738) && IS_SEQUENCE(_24742)) {
            Ref(_24738);
            Prepend(&_24743, _24742, _24738);
        }
        else {
            Concat((object_ptr)&_24743, _24738, _24742);
            _24738 = NOVALUE;
        }
        _24738 = NOVALUE;
        DeRefDS(_24742);
        _24742 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47789);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24743;
        if( _1 != _24743 ){
            DeRef(_1);
        }
        _24743 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24746 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24746);
        _24747 = (object)*(((s1_ptr)_2)->base + 5LL);
        _24746 = NOVALUE;
        Ref(_24747);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21447))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24747;
        if( _1 != _24747 ){
            DeRef(_1);
        }
        _24747 = NOVALUE;
        _24744 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24750 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24750);
        _24751 = (object)*(((s1_ptr)_2)->base + 4LL);
        _24750 = NOVALUE;
        Ref(_24751);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24751;
        if( _1 != _24751 ){
            DeRef(_1);
        }
        _24751 = NOVALUE;
        _24748 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24754 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24754);
        _24755 = (object)*(((s1_ptr)_2)->base + 6LL);
        _24754 = NOVALUE;
        Ref(_24755);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24755;
        if( _1 != _24755 ){
            DeRef(_1);
        }
        _24755 = NOVALUE;
        _24752 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
        RefDS(_22186);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _22186;
        DeRef(_1);
        _24756 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24758 = (object)*(((s1_ptr)_2)->base + _k_47793);
        if (IS_SEQUENCE(_24758)){
                _24759 = SEQ_PTR(_24758)->length;
        }
        else {
            _24759 = 1;
        }
        _24758 = NOVALUE;
        if (_24759 <= 6LL)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24763 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24763);
        _24764 = (object)*(((s1_ptr)_2)->base + 7LL);
        _24763 = NOVALUE;
        Ref(_24764);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21408))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24764;
        if( _1 != _24764 ){
            DeRef(_1);
        }
        _24764 = NOVALUE;
        _24761 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24767 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24767);
        _24768 = (object)*(((s1_ptr)_2)->base + 8LL);
        _24767 = NOVALUE;
        Ref(_24768);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24768;
        if( _1 != _24768 ){
            DeRef(_1);
        }
        _24768 = NOVALUE;
        _24765 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47791, _fixups_47791, _st_index_47789);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24770 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24770);
        _24771 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24770 = NOVALUE;
        if (binary_op_a(NOTEQ, _24771, 27LL)){
            _24771 = NOVALUE;
            goto L5; // [341] 365
        }
        _24771 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47790 == _24773)
        _24774 = 1;
        else if (IS_ATOM_INT(_kname_47790) && IS_ATOM_INT(_24773))
        _24774 = 0;
        else
        _24774 = (compare(_kname_47790, _24773) == 0);
        if (_24774 == 0)
        {
            _24774 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24774 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _36TopLevelSub_21766 = _st_index_47789;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _24775 = (object)*(((s1_ptr)_2)->base + _k_47793);
        _2 = (object)SEQ_PTR(_24775);
        _24776 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24775 = NOVALUE;
        if (binary_op_a(NOTEQ, _24776, 504LL)){
            _24776 = NOVALUE;
            goto L7; // [381] 461
        }
        _24776 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47790 == _23143)
        _24778 = 1;
        else if (IS_ATOM_INT(_kname_47790) && IS_ATOM_INT(_23143))
        _24778 = 0;
        else
        _24778 = (compare(_kname_47790, _23143) == 0);
        if (_24778 == 0)
        {
            _24778 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24778 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _54object_type_47132 = _st_index_47789;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47790 == _24779)
        _24780 = 1;
        else if (IS_ATOM_INT(_kname_47790) && IS_ATOM_INT(_24779))
        _24780 = 0;
        else
        _24780 = (compare(_kname_47790, _24779) == 0);
        if (_24780 == 0)
        {
            _24780 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24780 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _54atom_type_47134 = _st_index_47789;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47790 == _24781)
        _24782 = 1;
        else if (IS_ATOM_INT(_kname_47790) && IS_ATOM_INT(_24781))
        _24782 = 0;
        else
        _24782 = (compare(_kname_47790, _24781) == 0);
        if (_24782 == 0)
        {
            _24782 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24782 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _54integer_type_47138 = _st_index_47789;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47790 == _24783)
        _24784 = 1;
        else if (IS_ATOM_INT(_kname_47790) && IS_ATOM_INT(_24783))
        _24784 = 0;
        else
        _24784 = (compare(_kname_47790, _24783) == 0);
        if (_24784 == 0)
        {
            _24784 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24784 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _54sequence_type_47136 = _st_index_47789;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_54buckets_47128);
        _24785 = (object)*(((s1_ptr)_2)->base + _hashval_47785);
        if (binary_op_a(NOTEQ, _24785, 0LL)){
            _24785 = NOVALUE;
            goto LD; // [470] 485
        }
        _24785 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_54buckets_47128);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47785);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47789;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_47128);
        _s_47788 = (object)*(((s1_ptr)_2)->base + _hashval_47785);
        if (!IS_ATOM_INT(_s_47788)){
            _s_47788 = (object)DBL_PTR(_s_47788)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24788 = (object)*(((s1_ptr)_2)->base + _s_47788);
        _2 = (object)SEQ_PTR(_24788);
        _24789 = (object)*(((s1_ptr)_2)->base + 9LL);
        _24788 = NOVALUE;
        if (binary_op_a(EQUALS, _24789, 0LL)){
            _24789 = NOVALUE;
            goto L10; // [512] 537
        }
        _24789 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24791 = (object)*(((s1_ptr)_2)->base + _s_47788);
        _2 = (object)SEQ_PTR(_24791);
        _s_47788 = (object)*(((s1_ptr)_2)->base + 9LL);
        if (!IS_ATOM_INT(_s_47788)){
            _s_47788 = (object)DBL_PTR(_s_47788)->dbl;
        }
        _24791 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47788 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47789;
        DeRef(_1);
        _24793 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47793 = _k_47793 + 1LL;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _36file_start_sym_21765 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _36file_start_sym_21765 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _36CurrentSub_21767 = _36TopLevelSub_21766;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47791)){
            _24796 = SEQ_PTR(_fixups_47791)->length;
    }
    else {
        _24796 = 1;
    }
    {
        object _i_47935;
        _i_47935 = 1LL;
L11: 
        if (_i_47935 > _24796){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47791);
        _24797 = (object)*(((s1_ptr)_2)->base + _i_47935);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24798 = (object)*(((s1_ptr)_2)->base + _24797);
        DeRef(_si_47930);
        _2 = (object)SEQ_PTR(_24798);
        if (!IS_ATOM_INT(_36S_CODE_21408)){
            _si_47930 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
        }
        else{
            _si_47930 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
        }
        Ref(_si_47930);
        _24798 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47930)){
                _24800 = SEQ_PTR(_si_47930)->length;
        }
        else {
            _24800 = 1;
        }
        {
            object _j_47943;
            _j_47943 = 1LL;
L13: 
            if (_j_47943 > _24800){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47930);
            _24801 = (object)*(((s1_ptr)_2)->base + _j_47943);
            _24802 = IS_SEQUENCE(_24801);
            _24801 = NOVALUE;
            if (_24802 == 0)
            {
                _24802 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24802 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47931);
            _2 = (object)SEQ_PTR(_si_47930);
            _sj_47931 = (object)*(((s1_ptr)_2)->base + _j_47943);
            Ref(_sj_47931);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47931)){
                    _24804 = SEQ_PTR(_sj_47931)->length;
            }
            else {
                _24804 = 1;
            }
            {
                object _ij_47950;
                _ij_47950 = 1LL;
L16: 
                if (_ij_47950 > _24804){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47931);
                _24805 = (object)*(((s1_ptr)_2)->base + _ij_47950);
                _2 = (object)SEQ_PTR(_24805);
                _24806 = (object)*(((s1_ptr)_2)->base + 1LL);
                _24805 = NOVALUE;
                if (IS_SEQUENCE(_24806) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24806)){
                    if( (DBL_PTR(_24806)->dbl != (eudouble) ((object) DBL_PTR(_24806)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24806)->dbl;
                }
                else {
                    _0 = _24806;
                };
                _24806 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    _24809 = (object)*(((s1_ptr)_2)->base + _ij_47950);
                    _2 = (object)SEQ_PTR(_24809);
                    _24810 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24809 = NOVALUE;
                    Ref(_24810);
                    _24811 = _36is_integer(_24810);
                    _24810 = NOVALUE;
                    if (_24811 == 0) {
                        DeRef(_24811);
                        _24811 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24811) && DBL_PTR(_24811)->dbl == 0.0){
                            DeRef(_24811);
                            _24811 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24811);
                        _24811 = NOVALUE;
                    }
                    DeRef(_24811);
                    _24811 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    _24812 = (object)*(((s1_ptr)_2)->base + _ij_47950);
                    _2 = (object)SEQ_PTR(_24812);
                    _24813 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24812 = NOVALUE;
                    Ref(_24813);
                    _st_index_47789 = _54NewIntSym(_24813);
                    _24813 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47789)) {
                        _1 = (object)(DBL_PTR(_st_index_47789)->dbl);
                        DeRefDS(_st_index_47789);
                        _st_index_47789 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    _24815 = (object)*(((s1_ptr)_2)->base + _ij_47950);
                    _2 = (object)SEQ_PTR(_24815);
                    _24816 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24815 = NOVALUE;
                    Ref(_24816);
                    _st_index_47789 = _54NewDoubleSym(_24816);
                    _24816 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47789)) {
                        _1 = (object)(DBL_PTR(_st_index_47789)->dbl);
                        DeRefDS(_st_index_47789);
                        _st_index_47789 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15637);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15637 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24818 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47931 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47950 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47789;
                    DeRef(_1);
                    _24820 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    _24822 = (object)*(((s1_ptr)_2)->base + _ij_47950);
                    _2 = (object)SEQ_PTR(_24822);
                    _24823 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24822 = NOVALUE;
                    Ref(_24823);
                    _st_index_47789 = _54NewStringSym(_24823);
                    _24823 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47789)) {
                        _1 = (object)(DBL_PTR(_st_index_47789)->dbl);
                        DeRefDS(_st_index_47789);
                        _st_index_47789 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15637);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15637 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47789 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24825 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47931 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47950 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47789;
                    DeRef(_1);
                    _24827 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    _24829 = (object)*(((s1_ptr)_2)->base + _ij_47950);
                    _2 = (object)SEQ_PTR(_24829);
                    _24830 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24829 = NOVALUE;
                    Ref(_24830);
                    DeRef(_25308);
                    _25308 = _24830;
                    _25309 = _54hashfn(_25308);
                    _25308 = NOVALUE;
                    Ref(_24830);
                    _24831 = _54keyfind(_24830, -1LL, _36current_file_no_21759, 0LL, _25309);
                    _24830 = NOVALUE;
                    _25309 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47931);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47931 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_47950);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24831;
                    if( _1 != _24831 ){
                        DeRef(_1);
                    }
                    _24831 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47931);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47931 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47950 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47791);
                    _24834 = (object)*(((s1_ptr)_2)->base + _i_47935);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24835 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24832 = NOVALUE;
                    if (IS_SEQUENCE(_24835) && IS_ATOM(_24834)) {
                        Append(&_24836, _24835, _24834);
                    }
                    else if (IS_ATOM(_24835) && IS_SEQUENCE(_24834)) {
                    }
                    else {
                        Concat((object_ptr)&_24836, _24835, _24834);
                        _24835 = NOVALUE;
                    }
                    _24835 = NOVALUE;
                    _24834 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24836;
                    if( _1 != _24836 ){
                        DeRef(_1);
                    }
                    _24836 = NOVALUE;
                    _24832 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_47950 = _ij_47950 + 1LL;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47931);
            _2 = (object)SEQ_PTR(_si_47930);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47930 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47943);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47931;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47943 = _j_47943 + 1LL;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47791);
        _24837 = (object)*(((s1_ptr)_2)->base + _i_47935);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24837 + ((s1_ptr)_2)->base);
        RefDS(_si_47930);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21408))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47930;
        DeRef(_1);
        _24838 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47935 = _i_47935 + 1LL;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47790);
    DeRefi(_fixups_47791);
    DeRef(_si_47930);
    DeRef(_sj_47931);
    _24758 = NOVALUE;
    _24837 = NOVALUE;
    _24797 = NOVALUE;
    _24739 = NOVALUE;
    return;
    ;
}


void _54add_ref(object _tok_48019)
{
    object _s_48021 = NOVALUE;
    object _24854 = NOVALUE;
    object _24853 = NOVALUE;
    object _24851 = NOVALUE;
    object _24850 = NOVALUE;
    object _24849 = NOVALUE;
    object _24847 = NOVALUE;
    object _24846 = NOVALUE;
    object _24845 = NOVALUE;
    object _24844 = NOVALUE;
    object _24843 = NOVALUE;
    object _24842 = NOVALUE;
    object _24841 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48019);
    _s_48021 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_48021)){
        _s_48021 = (object)DBL_PTR(_s_48021)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24841 = (_s_48021 != _36CurrentSub_21767);
    if (_24841 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24843 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_24843);
    _24844 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24843 = NOVALUE;
    _24845 = find_from(_s_48021, _24844, 1LL);
    _24844 = NOVALUE;
    _24846 = (_24845 == 0);
    _24845 = NOVALUE;
    if (_24846 == 0)
    {
        DeRef(_24846);
        _24846 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24846);
        _24846 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48021 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24849 = (object)*(((s1_ptr)_2)->base + 12LL);
    _24847 = NOVALUE;
    if (IS_ATOM_INT(_24849)) {
        _24850 = _24849 + 1;
        if (_24850 > MAXINT){
            _24850 = NewDouble((eudouble)_24850);
        }
    }
    else
    _24850 = binary_op(PLUS, 1, _24849);
    _24849 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24850;
    if( _1 != _24850 ){
        DeRef(_1);
    }
    _24850 = NOVALUE;
    _24847 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21767 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24853 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24851 = NOVALUE;
    if (IS_SEQUENCE(_24853) && IS_ATOM(_s_48021)) {
        Append(&_24854, _24853, _s_48021);
    }
    else if (IS_ATOM(_24853) && IS_SEQUENCE(_s_48021)) {
    }
    else {
        Concat((object_ptr)&_24854, _24853, _s_48021);
        _24853 = NOVALUE;
    }
    _24853 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24854;
    if( _1 != _24854 ){
        DeRef(_1);
    }
    _24854 = NOVALUE;
    _24851 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_48019);
    DeRef(_24841);
    _24841 = NOVALUE;
    return;
    ;
}


void _54mark_all(object _attribute_48051)
{
    object _p_48054 = NOVALUE;
    object _sym_file_48061 = NOVALUE;
    object _scope_48078 = NOVALUE;
    object _24886 = NOVALUE;
    object _24885 = NOVALUE;
    object _24884 = NOVALUE;
    object _24882 = NOVALUE;
    object _24880 = NOVALUE;
    object _24879 = NOVALUE;
    object _24878 = NOVALUE;
    object _24877 = NOVALUE;
    object _24876 = NOVALUE;
    object _24874 = NOVALUE;
    object _24873 = NOVALUE;
    object _24872 = NOVALUE;
    object _24871 = NOVALUE;
    object _24867 = NOVALUE;
    object _24866 = NOVALUE;
    object _24865 = NOVALUE;
    object _24863 = NOVALUE;
    object _24862 = NOVALUE;
    object _24860 = NOVALUE;
    object _24858 = NOVALUE;
    object _24855 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_48048 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24855 = (object)*(((s1_ptr)_2)->base + _54just_mark_everything_from_48048);
    _2 = (object)SEQ_PTR(_24855);
    _p_48054 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_48054)){
        _p_48054 = (object)DBL_PTR(_p_48054)->dbl;
    }
    _24855 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_48054 == 0LL)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24858 = (object)*(((s1_ptr)_2)->base + _p_48054);
    _2 = (object)SEQ_PTR(_24858);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _sym_file_48061 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _sym_file_48061 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_sym_file_48061)){
        _sym_file_48061 = (object)DBL_PTR(_sym_file_48061)->dbl;
    }
    _24858 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _54just_mark_everything_from_48048 = _p_48054;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24860 = (_sym_file_48061 == _36current_file_no_21759);
    if (_24860 != 0) {
        goto L4; // [68] 84
    }
    Ref(_54recheck_routines_48121);
    _24862 = _29has(_54recheck_routines_48121, _sym_file_48061);
    if (_24862 == 0) {
        DeRef(_24862);
        _24862 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24862) && DBL_PTR(_24862)->dbl == 0.0){
            DeRef(_24862);
            _24862 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24862);
        _24862 = NOVALUE;
    }
    DeRef(_24862);
    _24862 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_48054 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24865 = (object)*(((s1_ptr)_2)->base + _attribute_48051);
    _24863 = NOVALUE;
    if (IS_ATOM_INT(_24865)) {
        _24866 = _24865 + 1;
        if (_24866 > MAXINT){
            _24866 = NewDouble((eudouble)_24866);
        }
    }
    else
    _24866 = binary_op(PLUS, 1, _24865);
    _24865 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48051);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24866;
    if( _1 != _24866 ){
        DeRef(_1);
    }
    _24866 = NOVALUE;
    _24863 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24867 = (object)*(((s1_ptr)_2)->base + _p_48054);
    _2 = (object)SEQ_PTR(_24867);
    _scope_48078 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48078)){
        _scope_48078 = (object)DBL_PTR(_scope_48078)->dbl;
    }
    _24867 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_48078;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _24871 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
        _2 = (object)SEQ_PTR(_24871);
        _24872 = (object)*(((s1_ptr)_2)->base + _sym_file_48061);
        _24871 = NOVALUE;
        if (IS_ATOM_INT(_24872)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_24872;
                 _24873 = MAKE_UINT(tu);
            }
        }
        else {
            _24873 = binary_op(AND_BITS, 6LL, _24872);
        }
        _24872 = NOVALUE;
        if (_24873 == 0) {
            DeRef(_24873);
            _24873 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24873) && DBL_PTR(_24873)->dbl == 0.0){
                DeRef(_24873);
                _24873 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24873);
            _24873 = NOVALUE;
        }
        DeRef(_24873);
        _24873 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48054 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24876 = (object)*(((s1_ptr)_2)->base + _attribute_48051);
        _24874 = NOVALUE;
        if (IS_ATOM_INT(_24876)) {
            _24877 = _24876 + 1;
            if (_24877 > MAXINT){
                _24877 = NewDouble((eudouble)_24877);
            }
        }
        else
        _24877 = binary_op(PLUS, 1, _24876);
        _24876 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48051);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24877;
        if( _1 != _24877 ){
            DeRef(_1);
        }
        _24877 = NOVALUE;
        _24874 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _24878 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
        _2 = (object)SEQ_PTR(_24878);
        _24879 = (object)*(((s1_ptr)_2)->base + _sym_file_48061);
        _24878 = NOVALUE;
        if (IS_ATOM_INT(_24879)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_24879;
                 _24880 = MAKE_UINT(tu);
            }
        }
        else {
            _24880 = binary_op(AND_BITS, 2LL, _24879);
        }
        _24879 = NOVALUE;
        if (IS_ATOM_INT(_24880)) {
            if (_24880 != 0){
                DeRef(_24880);
                _24880 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24880)->dbl != 0.0){
                DeRef(_24880);
                _24880 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24880);
        _24880 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_48054 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24884 = (object)*(((s1_ptr)_2)->base + _attribute_48051);
        _24882 = NOVALUE;
        if (IS_ATOM_INT(_24884)) {
            _24885 = _24884 + 1;
            if (_24885 > MAXINT){
                _24885 = NewDouble((eudouble)_24885);
            }
        }
        else
        _24885 = binary_op(PLUS, 1, _24884);
        _24884 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_48051);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24885;
        if( _1 != _24885 ){
            DeRef(_1);
        }
        _24885 = NOVALUE;
        _24882 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24886 = (object)*(((s1_ptr)_2)->base + _p_48054);
    _2 = (object)SEQ_PTR(_24886);
    _p_48054 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_48054)){
        _p_48054 = (object)DBL_PTR(_p_48054)->dbl;
    }
    _24886 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24860);
    _24860 = NOVALUE;
    return;
    ;
}


void _54mark_rechecks(object _file_no_48127)
{
    object _recheck_targets_48130 = NOVALUE;
    object _remaining_48134 = NOVALUE;
    object _marked_48138 = NOVALUE;
    object _24893 = NOVALUE;
    object _24891 = NOVALUE;
    object _24890 = NOVALUE;
    object _24889 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_48127)) {
        _1 = (object)(DBL_PTR(_file_no_48127)->dbl);
        DeRefDS(_file_no_48127);
        _file_no_48127 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_54recheck_routines_48121);
    RefDS(_22186);
    _0 = _recheck_targets_48130;
    _recheck_targets_48130 = _29get(_54recheck_routines_48121, _file_no_48127, _22186);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_48130)){
            _24889 = SEQ_PTR(_recheck_targets_48130)->length;
    }
    else {
        _24889 = 1;
    }
    if (_24889 == 0)
    {
        _24889 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24889 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_22186);
    DeRefi(_remaining_48134);
    _remaining_48134 = _22186;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_48130)){
            _24890 = SEQ_PTR(_recheck_targets_48130)->length;
    }
    else {
        _24890 = 1;
    }
    {
        object _i_48136;
        _i_48136 = _24890;
L2: 
        if (_i_48136 < 1LL){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_48138 = 0LL;

        /** symtab.e:589				if TRANSLATE then*/
        if (_36TRANSLATE_21361 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48130);
        _24891 = (object)*(((s1_ptr)_2)->base + _i_48136);
        Ref(_24891);
        _marked_48138 = _54MarkTargets(_24891, 53LL);
        _24891 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48138)) {
            _1 = (object)(DBL_PTR(_marked_48138)->dbl);
            DeRefDS(_marked_48138);
            _marked_48138 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_36BIND_21364 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_48130);
        _24893 = (object)*(((s1_ptr)_2)->base + _i_48136);
        Ref(_24893);
        _marked_48138 = _54MarkTargets(_24893, 12LL);
        _24893 = NOVALUE;
        if (!IS_ATOM_INT(_marked_48138)) {
            _1 = (object)(DBL_PTR(_marked_48138)->dbl);
            DeRefDS(_marked_48138);
            _marked_48138 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_48138 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_48134, _remaining_48134, _file_no_48127);
L7: 

        /** symtab.e:597			end for*/
        _i_48136 = _i_48136 + -1LL;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_54recheck_routines_48121);
    RefDS(_recheck_targets_48130);
    _29put(_54recheck_routines_48121, _file_no_48127, _recheck_targets_48130, 1LL, 0LL);
L1: 
    DeRefi(_remaining_48134);
    _remaining_48134 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_48130);
    return;
    ;
}


void _54mark_final_targets()
{
    object _size_1__tmp_at47_48166 = NOVALUE;
    object _size_inlined_size_at_47_48165 = NOVALUE;
    object _recheck_files_48167 = NOVALUE;
    object _24899 = NOVALUE;
    object _24898 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_48048 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _54mark_all(53LL);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _54mark_all(12LL);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_48166);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!IS_ATOM_INT(_54recheck_routines_48121)){
        _size_1__tmp_at47_48166 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_54recheck_routines_48121)->dbl));
    }
    else{
        _size_1__tmp_at47_48166 = (object)*(((s1_ptr)_2)->base + _54recheck_routines_48121);
    }
    Ref(_size_1__tmp_at47_48166);
    DeRef(_size_inlined_size_at_47_48165);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_48166);
    _size_inlined_size_at_47_48165 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_size_inlined_size_at_47_48165);
    DeRef(_size_1__tmp_at47_48166);
    _size_1__tmp_at47_48166 = NOVALUE;
    if (_size_inlined_size_at_47_48165 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_48165) && DBL_PTR(_size_inlined_size_at_47_48165)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_54recheck_routines_48121);
    _0 = _recheck_files_48167;
    _recheck_files_48167 = _29keys(_54recheck_routines_48121, 0LL);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_48167)){
            _24898 = SEQ_PTR(_recheck_files_48167)->length;
    }
    else {
        _24898 = 1;
    }
    {
        object _i_48170;
        _i_48170 = 1LL;
L5: 
        if (_i_48170 > _24898){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_48167);
        _24899 = (object)*(((s1_ptr)_2)->base + _i_48170);
        Ref(_24899);
        _54mark_rechecks(_24899);
        _24899 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_48170 = _i_48170 + 1LL;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_48167);
    _recheck_files_48167 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _54is_routine(object _sym_48176)
{
    object _tok_48177 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_48177 = _54sym_token(_sym_48176);
    if (!IS_ATOM_INT(_tok_48177)) {
        _1 = (object)(DBL_PTR(_tok_48177)->dbl);
        DeRefDS(_tok_48177);
        _tok_48177 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_48177;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1LL;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0LL;
    ;}L1: 
    ;
}


object _54is_visible(object _sym_48190, object _from_file_48191)
{
    object _scope_48192 = NOVALUE;
    object _sym_file_48195 = NOVALUE;
    object _visible_mask_48200 = NOVALUE;
    object _24911 = NOVALUE;
    object _24910 = NOVALUE;
    object _24909 = NOVALUE;
    object _24908 = NOVALUE;
    object _24904 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_48192 = _54sym_scope(_sym_48190);
    if (!IS_ATOM_INT(_scope_48192)) {
        _1 = (object)(DBL_PTR(_scope_48192)->dbl);
        DeRefDS(_scope_48192);
        _scope_48192 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24904 = (object)*(((s1_ptr)_2)->base + _sym_48190);
    _2 = (object)SEQ_PTR(_24904);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _sym_file_48195 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _sym_file_48195 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_sym_file_48195)){
        _sym_file_48195 = (object)DBL_PTR(_sym_file_48195)->dbl;
    }
    _24904 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_48192;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_48200 = 6LL;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_48200 = 2LL;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1LL;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24908 = (_from_file_48191 == _sym_file_48195);
        return _24908;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _24909 = (object)*(((s1_ptr)_2)->base + _from_file_48191);
    _2 = (object)SEQ_PTR(_24909);
    _24910 = (object)*(((s1_ptr)_2)->base + _sym_file_48195);
    _24909 = NOVALUE;
    if (IS_ATOM_INT(_24910)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_48200 & (uintptr_t)_24910;
             _24911 = MAKE_UINT(tu);
        }
    }
    else {
        _24911 = binary_op(AND_BITS, _visible_mask_48200, _24910);
    }
    _24910 = NOVALUE;
    DeRef(_24908);
    _24908 = NOVALUE;
    return _24911;
    ;
}


object _54MarkTargets(object _s_48220, object _attribute_48221)
{
    object _p_48223 = NOVALUE;
    object _sname_48224 = NOVALUE;
    object _string_48225 = NOVALUE;
    object _colon_48226 = NOVALUE;
    object _h_48227 = NOVALUE;
    object _scope_48228 = NOVALUE;
    object _found_48249 = NOVALUE;
    object _24959 = NOVALUE;
    object _24957 = NOVALUE;
    object _24956 = NOVALUE;
    object _24955 = NOVALUE;
    object _24954 = NOVALUE;
    object _24952 = NOVALUE;
    object _24951 = NOVALUE;
    object _24950 = NOVALUE;
    object _24949 = NOVALUE;
    object _24948 = NOVALUE;
    object _24946 = NOVALUE;
    object _24945 = NOVALUE;
    object _24944 = NOVALUE;
    object _24942 = NOVALUE;
    object _24940 = NOVALUE;
    object _24938 = NOVALUE;
    object _24937 = NOVALUE;
    object _24936 = NOVALUE;
    object _24935 = NOVALUE;
    object _24933 = NOVALUE;
    object _24932 = NOVALUE;
    object _24931 = NOVALUE;
    object _24930 = NOVALUE;
    object _24928 = NOVALUE;
    object _24927 = NOVALUE;
    object _24923 = NOVALUE;
    object _24922 = NOVALUE;
    object _24921 = NOVALUE;
    object _24920 = NOVALUE;
    object _24919 = NOVALUE;
    object _24918 = NOVALUE;
    object _24917 = NOVALUE;
    object _24916 = NOVALUE;
    object _24915 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48220)) {
        _1 = (object)(DBL_PTR(_s_48220)->dbl);
        DeRefDS(_s_48220);
        _s_48220 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24912 = (object)*(((s1_ptr)_2)->base + _s_48220);
    _2 = (object)SEQ_PTR(_24912);
    _24913 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24912 = NOVALUE;
    if (IS_ATOM_INT(_24913)) {
        _24914 = (_24913 == 3LL);
    }
    else {
        _24914 = binary_op(EQUALS, _24913, 3LL);
    }
    _24913 = NOVALUE;
    if (IS_ATOM_INT(_24914)) {
        if (_24914 != 0) {
            _24915 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24914)->dbl != 0.0) {
            _24915 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24916 = (object)*(((s1_ptr)_2)->base + _s_48220);
    _2 = (object)SEQ_PTR(_24916);
    _24917 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24916 = NOVALUE;
    if (IS_ATOM_INT(_24917)) {
        _24918 = (_24917 == 2LL);
    }
    else {
        _24918 = binary_op(EQUALS, _24917, 2LL);
    }
    _24917 = NOVALUE;
    DeRef(_24915);
    if (IS_ATOM_INT(_24918))
    _24915 = (_24918 != 0);
    else
    _24915 = DBL_PTR(_24918)->dbl != 0.0;
L1: 
    if (_24915 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24920 = (object)*(((s1_ptr)_2)->base + _s_48220);
    _2 = (object)SEQ_PTR(_24920);
    _24921 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24920 = NOVALUE;
    _24922 = IS_SEQUENCE(_24921);
    _24921 = NOVALUE;
    if (_24922 == 0)
    {
        _24922 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24922 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_48249 = 0LL;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24923 = (object)*(((s1_ptr)_2)->base + _s_48220);
    DeRef(_string_48225);
    _2 = (object)SEQ_PTR(_24923);
    _string_48225 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_string_48225);
    _24923 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_48226 = find_from(58LL, _string_48225, 1LL);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_48226 != 0LL)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_48225);
    DeRef(_sname_48224);
    _sname_48224 = _string_48225;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24927 = _colon_48226 + 1;
    if (_24927 > MAXINT){
        _24927 = NewDouble((eudouble)_24927);
    }
    if (IS_SEQUENCE(_string_48225)){
            _24928 = SEQ_PTR(_string_48225)->length;
    }
    else {
        _24928 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_48224;
    RHS_Slice(_string_48225, _24927, _24928);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_48224)){
            _24930 = SEQ_PTR(_sname_48224)->length;
    }
    else {
        _24930 = 1;
    }
    if (_24930 == 0) {
        _24931 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_48224);
    _24932 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24932)) {
        _24933 = (_24932 == 32LL);
    }
    else {
        _24933 = binary_op(EQUALS, _24932, 32LL);
    }
    _24932 = NOVALUE;
    if (IS_ATOM_INT(_24933))
    _24931 = (_24933 != 0);
    else
    _24931 = DBL_PTR(_24933)->dbl != 0.0;
L6: 
    if (_24931 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_48224);
    _24935 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24935)) {
        _24936 = (_24935 == 9LL);
    }
    else {
        _24936 = binary_op(EQUALS, _24935, 9LL);
    }
    _24935 = NOVALUE;
    if (_24936 <= 0) {
        if (_24936 == 0) {
            DeRef(_24936);
            _24936 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24936) && DBL_PTR(_24936)->dbl == 0.0){
                DeRef(_24936);
                _24936 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24936);
            _24936 = NOVALUE;
        }
    }
    DeRef(_24936);
    _24936 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_48224)){
            _24937 = SEQ_PTR(_sname_48224)->length;
    }
    else {
        _24937 = 1;
    }
    _24938 = _24937 - 1LL;
    _24937 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_48224)->length;
        int size = (IS_ATOM_INT(_24938)) ? _24938 : (object)(DBL_PTR(_24938)->dbl);
        if (size <= 0) {
            DeRef(_sname_48224);
            _sname_48224 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_48224);
            DeRef(_sname_48224);
            _sname_48224 = _sname_48224;
        }
        else Tail(SEQ_PTR(_sname_48224), len-size+1, &_sname_48224);
    }
    _24938 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_48224)){
            _24940 = SEQ_PTR(_sname_48224)->length;
    }
    else {
        _24940 = 1;
    }
    if (_24940 != 0LL)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_48224);
    DeRef(_string_48225);
    DeRef(_24933);
    _24933 = NOVALUE;
    DeRef(_24918);
    _24918 = NOVALUE;
    DeRef(_24914);
    _24914 = NOVALUE;
    DeRef(_24927);
    _24927 = NOVALUE;
    return 1LL;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_48224);
    _24942 = _54hashfn(_sname_48224);
    _2 = (object)SEQ_PTR(_54buckets_47128);
    if (!IS_ATOM_INT(_24942)){
        _h_48227 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24942)->dbl));
    }
    else{
        _h_48227 = (object)*(((s1_ptr)_2)->base + _24942);
    }
    if (!IS_ATOM_INT(_h_48227))
    _h_48227 = (object)DBL_PTR(_h_48227)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_48227 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24944 = (object)*(((s1_ptr)_2)->base + _h_48227);
    _2 = (object)SEQ_PTR(_24944);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _24945 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _24945 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _24944 = NOVALUE;
    if (_sname_48224 == _24945)
    _24946 = 1;
    else if (IS_ATOM_INT(_sname_48224) && IS_ATOM_INT(_24945))
    _24946 = 0;
    else
    _24946 = (compare(_sname_48224, _24945) == 0);
    _24945 = NOVALUE;
    if (_24946 == 0)
    {
        _24946 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24946 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_48221 != 12LL)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27LL;
    ((intptr_t *)_2)[2] = _h_48227;
    _24948 = MAKE_SEQ(_1);
    _54add_ref(_24948);
    _24948 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24949 = _54is_routine(_h_48227);
    if (IS_ATOM_INT(_24949)) {
        if (_24949 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24949)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24951 = _54is_visible(_h_48227, _36current_file_no_21759);
    if (_24951 == 0) {
        DeRef(_24951);
        _24951 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24951) && DBL_PTR(_24951)->dbl == 0.0){
            DeRef(_24951);
            _24951 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24951);
        _24951 = NOVALUE;
    }
    DeRef(_24951);
    _24951 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_48227 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24954 = (object)*(((s1_ptr)_2)->base + _attribute_48221);
    _24952 = NOVALUE;
    if (IS_ATOM_INT(_24954)) {
        _24955 = _24954 + 1;
        if (_24955 > MAXINT){
            _24955 = NewDouble((eudouble)_24955);
        }
    }
    else
    _24955 = binary_op(PLUS, 1, _24954);
    _24954 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_48221);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24955;
    if( _1 != _24955 ){
        DeRef(_1);
    }
    _24955 = NOVALUE;
    _24952 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24956 = (object)*(((s1_ptr)_2)->base + _h_48227);
    _2 = (object)SEQ_PTR(_24956);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _24957 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _24957 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _24956 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21759, _24957)){
        _24957 = NOVALUE;
        goto L10; // [347] 357
    }
    _24957 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_48249 = 1LL;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24959 = (object)*(((s1_ptr)_2)->base + _h_48227);
    _2 = (object)SEQ_PTR(_24959);
    _h_48227 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_h_48227)){
        _h_48227 = (object)DBL_PTR(_h_48227)->dbl;
    }
    _24959 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_48249 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_54recheck_routines_48121);
    _29put(_54recheck_routines_48121, _36current_file_no_21759, _s_48220, 6LL, 0LL);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_48224);
    DeRef(_string_48225);
    DeRef(_24933);
    _24933 = NOVALUE;
    DeRef(_24918);
    _24918 = NOVALUE;
    DeRef(_24914);
    _24914 = NOVALUE;
    DeRef(_24942);
    _24942 = NOVALUE;
    DeRef(_24949);
    _24949 = NOVALUE;
    DeRef(_24927);
    _24927 = NOVALUE;
    return _found_48249;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_54just_mark_everything_from_48048 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _54just_mark_everything_from_48048 = _36TopLevelSub_21766;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _54mark_all(_attribute_48221);

    /** symtab.e:700			return 1*/
    DeRef(_sname_48224);
    DeRef(_string_48225);
    DeRef(_24933);
    _24933 = NOVALUE;
    DeRef(_24918);
    _24918 = NOVALUE;
    DeRef(_24914);
    _24914 = NOVALUE;
    DeRef(_24942);
    _24942 = NOVALUE;
    DeRef(_24949);
    _24949 = NOVALUE;
    DeRef(_24927);
    _24927 = NOVALUE;
    return 1LL;
L12: 
    ;
}


void _54resolve_unincluded_globals(object _ok_48327)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _54Resolve_unincluded_globals_48324 = 1LL;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _54get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _54Resolve_unincluded_globals_48324;
    ;
}


object _54keyfind(object _word_48333, object _file_no_48334, object _scanning_file_48335, object _namespace_ok_48338, object _hashval_48339)
{
    object _msg_48341 = NOVALUE;
    object _b_name_48342 = NOVALUE;
    object _scope_48343 = NOVALUE;
    object _defined_48344 = NOVALUE;
    object _ix_48345 = NOVALUE;
    object _st_ptr_48347 = NOVALUE;
    object _st_builtin_48348 = NOVALUE;
    object _tok_48350 = NOVALUE;
    object _gtok_48351 = NOVALUE;
    object _any_symbol_48354 = NOVALUE;
    object _tok_file_48522 = NOVALUE;
    object _good_48529 = NOVALUE;
    object _include_type_48539 = NOVALUE;
    object _msg_file_48595 = NOVALUE;
    object _25154 = NOVALUE;
    object _25153 = NOVALUE;
    object _25151 = NOVALUE;
    object _25149 = NOVALUE;
    object _25148 = NOVALUE;
    object _25147 = NOVALUE;
    object _25146 = NOVALUE;
    object _25145 = NOVALUE;
    object _25143 = NOVALUE;
    object _25141 = NOVALUE;
    object _25140 = NOVALUE;
    object _25139 = NOVALUE;
    object _25138 = NOVALUE;
    object _25137 = NOVALUE;
    object _25136 = NOVALUE;
    object _25135 = NOVALUE;
    object _25134 = NOVALUE;
    object _25132 = NOVALUE;
    object _25131 = NOVALUE;
    object _25130 = NOVALUE;
    object _25129 = NOVALUE;
    object _25128 = NOVALUE;
    object _25127 = NOVALUE;
    object _25126 = NOVALUE;
    object _25125 = NOVALUE;
    object _25124 = NOVALUE;
    object _25123 = NOVALUE;
    object _25122 = NOVALUE;
    object _25121 = NOVALUE;
    object _25120 = NOVALUE;
    object _25119 = NOVALUE;
    object _25118 = NOVALUE;
    object _25117 = NOVALUE;
    object _25116 = NOVALUE;
    object _25114 = NOVALUE;
    object _25113 = NOVALUE;
    object _25110 = NOVALUE;
    object _25106 = NOVALUE;
    object _25104 = NOVALUE;
    object _25103 = NOVALUE;
    object _25102 = NOVALUE;
    object _25101 = NOVALUE;
    object _25100 = NOVALUE;
    object _25098 = NOVALUE;
    object _25097 = NOVALUE;
    object _25096 = NOVALUE;
    object _25095 = NOVALUE;
    object _25093 = NOVALUE;
    object _25090 = NOVALUE;
    object _25089 = NOVALUE;
    object _25088 = NOVALUE;
    object _25087 = NOVALUE;
    object _25085 = NOVALUE;
    object _25082 = NOVALUE;
    object _25081 = NOVALUE;
    object _25080 = NOVALUE;
    object _25079 = NOVALUE;
    object _25078 = NOVALUE;
    object _25077 = NOVALUE;
    object _25076 = NOVALUE;
    object _25073 = NOVALUE;
    object _25072 = NOVALUE;
    object _25070 = NOVALUE;
    object _25068 = NOVALUE;
    object _25066 = NOVALUE;
    object _25065 = NOVALUE;
    object _25064 = NOVALUE;
    object _25060 = NOVALUE;
    object _25059 = NOVALUE;
    object _25054 = NOVALUE;
    object _25052 = NOVALUE;
    object _25050 = NOVALUE;
    object _25049 = NOVALUE;
    object _25045 = NOVALUE;
    object _25044 = NOVALUE;
    object _25042 = NOVALUE;
    object _25041 = NOVALUE;
    object _25039 = NOVALUE;
    object _25038 = NOVALUE;
    object _25037 = NOVALUE;
    object _25036 = NOVALUE;
    object _25035 = NOVALUE;
    object _25033 = NOVALUE;
    object _25032 = NOVALUE;
    object _25031 = NOVALUE;
    object _25030 = NOVALUE;
    object _25029 = NOVALUE;
    object _25028 = NOVALUE;
    object _25027 = NOVALUE;
    object _25026 = NOVALUE;
    object _25025 = NOVALUE;
    object _25024 = NOVALUE;
    object _25023 = NOVALUE;
    object _25022 = NOVALUE;
    object _25021 = NOVALUE;
    object _25020 = NOVALUE;
    object _25019 = NOVALUE;
    object _25018 = NOVALUE;
    object _25017 = NOVALUE;
    object _25016 = NOVALUE;
    object _25015 = NOVALUE;
    object _25014 = NOVALUE;
    object _25013 = NOVALUE;
    object _25012 = NOVALUE;
    object _25010 = NOVALUE;
    object _25009 = NOVALUE;
    object _25007 = NOVALUE;
    object _25006 = NOVALUE;
    object _25005 = NOVALUE;
    object _25004 = NOVALUE;
    object _25003 = NOVALUE;
    object _25001 = NOVALUE;
    object _25000 = NOVALUE;
    object _24999 = NOVALUE;
    object _24997 = NOVALUE;
    object _24996 = NOVALUE;
    object _24995 = NOVALUE;
    object _24994 = NOVALUE;
    object _24993 = NOVALUE;
    object _24992 = NOVALUE;
    object _24991 = NOVALUE;
    object _24989 = NOVALUE;
    object _24988 = NOVALUE;
    object _24983 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _24978 = NOVALUE;
    object _24977 = NOVALUE;
    object _24976 = NOVALUE;
    object _24975 = NOVALUE;
    object _24974 = NOVALUE;
    object _24973 = NOVALUE;
    object _24972 = NOVALUE;
    object _24971 = NOVALUE;
    object _24970 = NOVALUE;
    object _24969 = NOVALUE;
    object _24968 = NOVALUE;
    object _24967 = NOVALUE;
    object _24966 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_48334)) {
        _1 = (object)(DBL_PTR(_file_no_48334)->dbl);
        DeRefDS(_file_no_48334);
        _file_no_48334 = _1;
    }
    if (!IS_ATOM_INT(_hashval_48339)) {
        _1 = (object)(DBL_PTR(_hashval_48339)->dbl);
        DeRefDS(_hashval_48339);
        _hashval_48339 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_22186);
    DeRef(_54dup_globals_48319);
    _54dup_globals_48319 = _22186;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_22186);
    DeRefi(_54dup_overrides_48320);
    _54dup_overrides_48320 = _22186;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_22186);
    DeRef(_54in_include_path_48321);
    _54in_include_path_48321 = _22186;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_22186);
    DeRef(_36symbol_resolution_warning_21864);
    _36symbol_resolution_warning_21864 = _22186;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_48348 = 0LL;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _st_ptr_48347 = (object)*(((s1_ptr)_2)->base + _hashval_48339);
    if (!IS_ATOM_INT(_st_ptr_48347)){
        _st_ptr_48347 = (object)DBL_PTR(_st_ptr_48347)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_48354 = (_namespace_ok_48338 == -1LL);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_48347 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24966 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_24966);
    _24967 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24966 = NOVALUE;
    if (IS_ATOM_INT(_24967)) {
        _24968 = (_24967 != 9LL);
    }
    else {
        _24968 = binary_op(NOTEQ, _24967, 9LL);
    }
    _24967 = NOVALUE;
    if (IS_ATOM_INT(_24968)) {
        if (_24968 == 0) {
            DeRef(_24969);
            _24969 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24968)->dbl == 0.0) {
            DeRef(_24969);
            _24969 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24970 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_24970);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _24971 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _24971 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _24970 = NOVALUE;
    if (_word_48333 == _24971)
    _24972 = 1;
    else if (IS_ATOM_INT(_word_48333) && IS_ATOM_INT(_24971))
    _24972 = 0;
    else
    _24972 = (compare(_word_48333, _24971) == 0);
    _24971 = NOVALUE;
    DeRef(_24969);
    _24969 = (_24972 != 0);
L3: 
    if (_24969 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_48354 != 0) {
        DeRef(_24974);
        _24974 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24975 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_24975);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _24976 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _24976 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _24975 = NOVALUE;
    if (IS_ATOM_INT(_24976)) {
        _24977 = (_24976 == 523LL);
    }
    else {
        _24977 = binary_op(EQUALS, _24976, 523LL);
    }
    _24976 = NOVALUE;
    if (IS_ATOM_INT(_24977)) {
        _24978 = (_namespace_ok_48338 == _24977);
    }
    else {
        _24978 = binary_op(EQUALS, _namespace_ok_48338, _24977);
    }
    DeRef(_24977);
    _24977 = NOVALUE;
    if (IS_ATOM_INT(_24978))
    _24974 = (_24978 != 0);
    else
    _24974 = DBL_PTR(_24978)->dbl != 0.0;
L5: 
    if (_24974 == 0)
    {
        _24974 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24974 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24979 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_24979);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _24980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _24980 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _24979 = NOVALUE;
    Ref(_24980);
    DeRef(_tok_48350);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24980;
    ((intptr_t *)_2)[2] = _st_ptr_48347;
    _tok_48350 = MAKE_SEQ(_1);
    _24980 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_48334 != -1LL)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24983 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_24983);
    _scope_48343 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48343)){
        _scope_48343 = (object)DBL_PTR(_scope_48343)->dbl;
    }
    _24983 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_48343;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_54dup_overrides_48320, _54dup_overrides_48320, _st_ptr_48347);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_48348 = _st_ptr_48347;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24988 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_24988);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _24989 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _24989 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _24988 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48335, _24989)){
            _24989 = NOVALUE;
            goto L8; // [250] 274
        }
        _24989 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_36BIND_21364 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_48350);
        _54add_ref(_tok_48350);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_48333);
        DeRef(_msg_48341);
        DeRef(_b_name_48342);
        DeRef(_gtok_48351);
        DeRef(_24978);
        _24978 = NOVALUE;
        DeRef(_24968);
        _24968 = NOVALUE;
        return _tok_48350;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_54Resolve_unincluded_globals_48324 != 0) {
            _24991 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        _24992 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        if (_24992 == 0) {
            _24993 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _24994 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24995 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_24995);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _24996 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _24996 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _24995 = NOVALUE;
        _2 = (object)SEQ_PTR(_24994);
        if (!IS_ATOM_INT(_24996)){
            _24997 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24996)->dbl));
        }
        else{
            _24997 = (object)*(((s1_ptr)_2)->base + _24996);
        }
        _24994 = NOVALUE;
        if (IS_ATOM_INT(_24997))
        _24993 = (_24997 != 0);
        else
        _24993 = DBL_PTR(_24997)->dbl != 0.0;
LB: 
        _24991 = (_24993 != 0);
LA: 
        if (_24991 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _24999 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_24999);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _25000 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _25000 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        _24999 = NOVALUE;
        if (IS_ATOM_INT(_25000)) {
            _25001 = (_25000 == 523LL);
        }
        else {
            _25001 = binary_op(EQUALS, _25000, 523LL);
        }
        _25000 = NOVALUE;
        if (_25001 == 0) {
            DeRef(_25001);
            _25001 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_25001) && DBL_PTR(_25001)->dbl == 0.0){
                DeRef(_25001);
                _25001 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_25001);
            _25001 = NOVALUE;
        }
        DeRef(_25001);
        _25001 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_48350);
        DeRef(_gtok_48351);
        _gtok_48351 = _tok_48350;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_54dup_globals_48319, _54dup_globals_48319, _st_ptr_48347);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25003 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25004 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25004);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25005 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25005 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25004 = NOVALUE;
        _2 = (object)SEQ_PTR(_25003);
        if (!IS_ATOM_INT(_25005)){
            _25006 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25005)->dbl));
        }
        else{
            _25006 = (object)*(((s1_ptr)_2)->base + _25005);
        }
        _25003 = NOVALUE;
        if (IS_ATOM_INT(_25006)) {
            _25007 = (_25006 != 0LL);
        }
        else {
            _25007 = binary_op(NOTEQ, _25006, 0LL);
        }
        _25006 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_48321) && IS_ATOM(_25007)) {
            Ref(_25007);
            Append(&_54in_include_path_48321, _54in_include_path_48321, _25007);
        }
        else if (IS_ATOM(_54in_include_path_48321) && IS_SEQUENCE(_25007)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_48321, _54in_include_path_48321, _25007);
        }
        DeRef(_25007);
        _25007 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25009 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25009);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25010 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25010 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25009 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48335, _25010)){
            _25010 = NOVALUE;
            goto LD; // [421] 445
        }
        _25010 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_36BIND_21364 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_48350);
        _54add_ref(_tok_48350);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_48333);
        DeRef(_msg_48341);
        DeRef(_b_name_48342);
        DeRef(_gtok_48351);
        _25005 = NOVALUE;
        _24992 = NOVALUE;
        _24996 = NOVALUE;
        DeRef(_24978);
        _24978 = NOVALUE;
        DeRef(_24968);
        _24968 = NOVALUE;
        _24997 = NOVALUE;
        return _tok_48350;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        _25012 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        if (_25012 != 0) {
            _25013 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_48338 == 0) {
            _25014 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25015 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25015);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _25016 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _25016 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        _25015 = NOVALUE;
        if (IS_ATOM_INT(_25016)) {
            _25017 = (_25016 == 523LL);
        }
        else {
            _25017 = binary_op(EQUALS, _25016, 523LL);
        }
        _25016 = NOVALUE;
        if (IS_ATOM_INT(_25017))
        _25014 = (_25017 != 0);
        else
        _25014 = DBL_PTR(_25017)->dbl != 0.0;
L10: 
        _25013 = (_25014 != 0);
LF: 
        if (_25013 == 0) {
            goto L7; // [487] 1011
        }
        _25019 = (_scope_48343 == 13LL);
        if (_25019 == 0) {
            _25020 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25021 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25022 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25022);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25023 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25023 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25022 = NOVALUE;
        _2 = (object)SEQ_PTR(_25021);
        if (!IS_ATOM_INT(_25023)){
            _25024 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25023)->dbl));
        }
        else{
            _25024 = (object)*(((s1_ptr)_2)->base + _25023);
        }
        _25021 = NOVALUE;
        if (IS_ATOM_INT(_25024)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_25024;
                 _25025 = MAKE_UINT(tu);
            }
        }
        else {
            _25025 = binary_op(AND_BITS, 6LL, _25024);
        }
        _25024 = NOVALUE;
        if (IS_ATOM_INT(_25025))
        _25020 = (_25025 != 0);
        else
        _25020 = DBL_PTR(_25025)->dbl != 0.0;
L11: 
        if (_25020 != 0) {
            DeRef(_25026);
            _25026 = 1;
            goto L12; // [533] 583
        }
        _25027 = (_scope_48343 == 11LL);
        if (_25027 == 0) {
            _25028 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25029 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25030 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25030);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25031 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25030 = NOVALUE;
        _2 = (object)SEQ_PTR(_25029);
        if (!IS_ATOM_INT(_25031)){
            _25032 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25031)->dbl));
        }
        else{
            _25032 = (object)*(((s1_ptr)_2)->base + _25031);
        }
        _25029 = NOVALUE;
        if (IS_ATOM_INT(_25032)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_25032;
                 _25033 = MAKE_UINT(tu);
            }
        }
        else {
            _25033 = binary_op(AND_BITS, 2LL, _25032);
        }
        _25032 = NOVALUE;
        if (IS_ATOM_INT(_25033))
        _25028 = (_25033 != 0);
        else
        _25028 = DBL_PTR(_25033)->dbl != 0.0;
L13: 
        DeRef(_25026);
        _25026 = (_25028 != 0);
L12: 
        if (_25026 == 0)
        {
            _25026 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _25026 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_48350);
        DeRef(_gtok_48351);
        _gtok_48351 = _tok_48350;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_54dup_globals_48319, _54dup_globals_48319, _st_ptr_48347);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _25035 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25036 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25036);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25037 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25037 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25036 = NOVALUE;
        _2 = (object)SEQ_PTR(_25035);
        if (!IS_ATOM_INT(_25037)){
            _25038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25037)->dbl));
        }
        else{
            _25038 = (object)*(((s1_ptr)_2)->base + _25037);
        }
        _25035 = NOVALUE;
        if (IS_ATOM_INT(_25038)) {
            _25039 = (_25038 != 0LL);
        }
        else {
            _25039 = binary_op(NOTEQ, _25038, 0LL);
        }
        _25038 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_48321) && IS_ATOM(_25039)) {
            Ref(_25039);
            Append(&_54in_include_path_48321, _54in_include_path_48321, _25039);
        }
        else if (IS_ATOM(_54in_include_path_48321) && IS_SEQUENCE(_25039)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_48321, _54in_include_path_48321, _25039);
        }
        DeRef(_25039);
        _25039 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25041 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
        _2 = (object)SEQ_PTR(_25041);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25042 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25042 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25041 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_48335, _25042)){
            _25042 = NOVALUE;
            goto L7; // [659] 1011
        }
        _25042 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_36BIND_21364 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_48350);
        _54add_ref(_tok_48350);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_48333);
        DeRef(_msg_48341);
        DeRef(_b_name_48342);
        DeRef(_gtok_48351);
        DeRef(_25019);
        _25019 = NOVALUE;
        DeRef(_25017);
        _25017 = NOVALUE;
        _25005 = NOVALUE;
        DeRef(_25025);
        _25025 = NOVALUE;
        _24992 = NOVALUE;
        _24996 = NOVALUE;
        _25023 = NOVALUE;
        DeRef(_25027);
        _25027 = NOVALUE;
        _25031 = NOVALUE;
        DeRef(_24978);
        _24978 = NOVALUE;
        _25037 = NOVALUE;
        DeRef(_24968);
        _24968 = NOVALUE;
        DeRef(_25033);
        _25033 = NOVALUE;
        _25012 = NOVALUE;
        _24997 = NOVALUE;
        return _tok_48350;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_36BIND_21364 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_48350);
        _54add_ref(_tok_48350);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_48333);
        DeRef(_msg_48341);
        DeRef(_b_name_48342);
        DeRef(_gtok_48351);
        DeRef(_25019);
        _25019 = NOVALUE;
        DeRef(_25017);
        _25017 = NOVALUE;
        _25005 = NOVALUE;
        DeRef(_25025);
        _25025 = NOVALUE;
        _24992 = NOVALUE;
        _24996 = NOVALUE;
        _25023 = NOVALUE;
        DeRef(_25027);
        _25027 = NOVALUE;
        _25031 = NOVALUE;
        DeRef(_24978);
        _24978 = NOVALUE;
        _25037 = NOVALUE;
        DeRef(_24968);
        _24968 = NOVALUE;
        DeRef(_25033);
        _25033 = NOVALUE;
        _25012 = NOVALUE;
        _24997 = NOVALUE;
        return _tok_48350;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_48350);
    _25044 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25044)){
        _25045 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25044)->dbl));
    }
    else{
        _25045 = (object)*(((s1_ptr)_2)->base + _25044);
    }
    _2 = (object)SEQ_PTR(_25045);
    _scope_48343 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_48343)){
        _scope_48343 = (object)DBL_PTR(_scope_48343)->dbl;
    }
    _25045 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_48334 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_48343 != 7LL)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_48350);
    _54add_ref(_tok_48350);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_gtok_48351);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _24997 = NOVALUE;
    return _tok_48350;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_48350);
    _25049 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25049)){
        _25050 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25049)->dbl));
    }
    else{
        _25050 = (object)*(((s1_ptr)_2)->base + _25049);
    }
    _2 = (object)SEQ_PTR(_25050);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _tok_file_48522 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _tok_file_48522 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_tok_file_48522)){
        _tok_file_48522 = (object)DBL_PTR(_tok_file_48522)->dbl;
    }
    _25050 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48529 = 0LL;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _25052 = (_scope_48343 == 3LL);
    if (_25052 != 0) {
        goto L19; // [807] 940
    }
    _25054 = (_scope_48343 == 7LL);
    if (_25054 == 0)
    {
        DeRef(_25054);
        _25054 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_25054);
        _25054 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_48334 != _tok_file_48522)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48529 = 1LL;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48539 = 0LL;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_48343;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_54Resolve_unincluded_globals_48324 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48539 = 7LL;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48539 = 6LL;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48522 == _file_no_48334)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48539 = 4LL;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48539 = 6LL;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _25059 = (object)*(((s1_ptr)_2)->base + _file_no_48334);
    _2 = (object)SEQ_PTR(_25059);
    _25060 = (object)*(((s1_ptr)_2)->base + _tok_file_48522);
    _25059 = NOVALUE;
    if (IS_ATOM_INT(_25060)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48539 & (uintptr_t)_25060;
             _good_48529 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48529 = binary_op(AND_BITS, _include_type_48539, _25060);
    }
    _25060 = NOVALUE;
    if (!IS_ATOM_INT(_good_48529)) {
        _1 = (object)(DBL_PTR(_good_48529)->dbl);
        DeRefDS(_good_48529);
        _good_48529 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48529 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_48334 != _tok_file_48522)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_48350);
    _54add_ref(_tok_48350);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_gtok_48351);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25052);
    _25052 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _25049 = NOVALUE;
    _24997 = NOVALUE;
    return _tok_48350;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_48350);
    DeRef(_gtok_48351);
    _gtok_48351 = _tok_48350;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_54dup_globals_48319, _54dup_globals_48319, _st_ptr_48347);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _25064 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
    _2 = (object)SEQ_PTR(_25064);
    _25065 = (object)*(((s1_ptr)_2)->base + _tok_file_48522);
    _25064 = NOVALUE;
    if (IS_ATOM_INT(_25065)) {
        _25066 = (_25065 != 0LL);
    }
    else {
        _25066 = binary_op(NOTEQ, _25065, 0LL);
    }
    _25065 = NOVALUE;
    if (IS_SEQUENCE(_54in_include_path_48321) && IS_ATOM(_25066)) {
        Ref(_25066);
        Append(&_54in_include_path_48321, _54in_include_path_48321, _25066);
    }
    else if (IS_ATOM(_54in_include_path_48321) && IS_SEQUENCE(_25066)) {
    }
    else {
        Concat((object_ptr)&_54in_include_path_48321, _54in_include_path_48321, _25066);
    }
    DeRef(_25066);
    _25066 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25068 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_25068);
    _st_ptr_48347 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_48347)){
        _st_ptr_48347 = (object)DBL_PTR(_st_ptr_48347)->dbl;
    }
    _25068 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_48320)){
            _25070 = SEQ_PTR(_54dup_overrides_48320)->length;
    }
    else {
        _25070 = 1;
    }
    if (_25070 == 0)
    {
        _25070 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _25070 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_54dup_overrides_48320);
    _st_ptr_48347 = (object)*(((s1_ptr)_2)->base + 1LL);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25072 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_25072);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _25073 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _25073 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _25072 = NOVALUE;
    Ref(_25073);
    DeRef(_tok_48350);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25073;
    ((intptr_t *)_2)[2] = _st_ptr_48347;
    _tok_48350 = MAKE_SEQ(_1);
    _25073 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_48350);
    _54add_ref(_tok_48350);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_gtok_48351);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25052);
    _25052 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _25049 = NOVALUE;
    _24997 = NOVALUE;
    return _tok_48350;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_48348 == 0LL)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25076 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25076 = 1;
    }
    if (_25076 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25078 = (object)*(((s1_ptr)_2)->base + _st_builtin_48348);
    _2 = (object)SEQ_PTR(_25078);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25079 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25079 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25078 = NOVALUE;
    _25080 = find_from(_25079, _54builtin_warnings_48323, 1LL);
    _25079 = NOVALUE;
    _25081 = (_25080 == 0LL);
    _25080 = NOVALUE;
    if (_25081 == 0)
    {
        DeRef(_25081);
        _25081 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_25081);
        _25081 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25082 = (object)*(((s1_ptr)_2)->base + _st_builtin_48348);
    DeRef(_b_name_48342);
    _2 = (object)SEQ_PTR(_25082);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _b_name_48342 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _b_name_48342 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    Ref(_b_name_48342);
    _25082 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_48342);
    Append(&_54builtin_warnings_48323, _54builtin_warnings_48323, _b_name_48342);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25085 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25085 = 1;
    }
    if (_25085 <= 1LL)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22381);
    DeRef(_msg_48341);
    _msg_48341 = _22381;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_22186);
    DeRef(_msg_48341);
    _msg_48341 = _22186;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25087 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25087 = 1;
    }
    {
        object _i_48606;
        _i_48606 = 1LL;
L2A: 
        if (_i_48606 > _25087){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_54dup_globals_48319);
        _25088 = (object)*(((s1_ptr)_2)->base + _i_48606);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_25088)){
            _25089 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25088)->dbl));
        }
        else{
            _25089 = (object)*(((s1_ptr)_2)->base + _25088);
        }
        _2 = (object)SEQ_PTR(_25089);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _25090 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _25090 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _25089 = NOVALUE;
        DeRef(_msg_file_48595);
        _2 = (object)SEQ_PTR(_37known_files_15638);
        if (!IS_ATOM_INT(_25090)){
            _msg_file_48595 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25090)->dbl));
        }
        else{
            _msg_file_48595 = (object)*(((s1_ptr)_2)->base + _25090);
        }
        Ref(_msg_file_48595);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22381;
            concat_list[1] = _msg_file_48595;
            concat_list[2] = _25092;
            Concat_N((object_ptr)&_25093, concat_list, 3);
        }
        Concat((object_ptr)&_msg_48341, _msg_48341, _25093);
        DeRefDS(_25093);
        _25093 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48606 = _i_48606 + 1LL;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25095 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_48342);
    ((intptr_t*)_2)[1] = _b_name_48342;
    Ref(_25095);
    ((intptr_t*)_2)[2] = _25095;
    RefDS(_msg_48341);
    ((intptr_t*)_2)[3] = _msg_48341;
    _25096 = MAKE_SEQ(_1);
    _25095 = NOVALUE;
    _50Warning(234LL, 8LL, _25096);
    _25096 = NOVALUE;
L27: 
    DeRef(_msg_file_48595);
    _msg_file_48595 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25097 = (object)*(((s1_ptr)_2)->base + _st_builtin_48348);
    _2 = (object)SEQ_PTR(_25097);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _25098 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _25098 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _25097 = NOVALUE;
    Ref(_25098);
    DeRef(_tok_48350);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25098;
    ((intptr_t *)_2)[2] = _st_builtin_48348;
    _tok_48350 = MAKE_SEQ(_1);
    _25098 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_48350);
    _54add_ref(_tok_48350);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_gtok_48351);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25052);
    _25052 = NOVALUE;
    _25090 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _25049 = NOVALUE;
    _25088 = NOVALUE;
    _24997 = NOVALUE;
    return _tok_48350;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25100 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25100 = 1;
    }
    _25101 = (_25100 > 1LL);
    _25100 = NOVALUE;
    if (_25101 == 0) {
        goto L2D; // [1333] 1452
    }
    _25103 = find_from(1LL, _54in_include_path_48321, 1LL);
    if (_25103 == 0)
    {
        _25103 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _25103 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_48345 = 1LL;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25104 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25104 = 1;
    }
    if (_ix_48345 > _25104)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_54in_include_path_48321);
    _25106 = (object)*(((s1_ptr)_2)->base + _ix_48345);
    if (_25106 == 0) {
        _25106 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_25106) && DBL_PTR(_25106)->dbl == 0.0){
            _25106 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _25106 = NOVALUE;
    }
    _25106 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_48345 = _ix_48345 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54dup_globals_48319);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48345)) ? _ix_48345 : (object)(DBL_PTR(_ix_48345)->dbl);
        int stop = (IS_ATOM_INT(_ix_48345)) ? _ix_48345 : (object)(DBL_PTR(_ix_48345)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54dup_globals_48319), start, &_54dup_globals_48319 );
            }
            else Tail(SEQ_PTR(_54dup_globals_48319), stop+1, &_54dup_globals_48319);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54dup_globals_48319), start, &_54dup_globals_48319);
        }
        else {
            assign_slice_seq = &assign_space;
            _54dup_globals_48319 = Remove_elements(start, stop, (SEQ_PTR(_54dup_globals_48319)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54in_include_path_48321);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_48345)) ? _ix_48345 : (object)(DBL_PTR(_ix_48345)->dbl);
        int stop = (IS_ATOM_INT(_ix_48345)) ? _ix_48345 : (object)(DBL_PTR(_ix_48345)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54in_include_path_48321), start, &_54in_include_path_48321 );
            }
            else Tail(SEQ_PTR(_54in_include_path_48321), stop+1, &_54in_include_path_48321);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54in_include_path_48321), start, &_54in_include_path_48321);
        }
        else {
            assign_slice_seq = &assign_space;
            _54in_include_path_48321 = Remove_elements(start, stop, (SEQ_PTR(_54in_include_path_48321)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25110 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25110 = 1;
    }
    if (_25110 != 1LL)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_54dup_globals_48319);
    _st_ptr_48347 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_st_ptr_48347)){
        _st_ptr_48347 = (object)DBL_PTR(_st_ptr_48347)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25113 = (object)*(((s1_ptr)_2)->base + _st_ptr_48347);
    _2 = (object)SEQ_PTR(_25113);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _25114 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _25114 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _25113 = NOVALUE;
    Ref(_25114);
    DeRef(_gtok_48351);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _25114;
    ((intptr_t *)_2)[2] = _st_ptr_48347;
    _gtok_48351 = MAKE_SEQ(_1);
    _25114 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25116 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25116 = 1;
    }
    _25117 = (_25116 == 1LL);
    _25116 = NOVALUE;
    if (_25117 == 0) {
        goto L32; // [1465] 1644
    }
    _25119 = (_st_builtin_48348 == 0LL);
    if (_25119 == 0)
    {
        DeRef(_25119);
        _25119 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_25119);
        _25119 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_48351);
    _54add_ref(_gtok_48351);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_54in_include_path_48321);
    _25120 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25120)) {
        _25121 = (_25120 == 0);
    }
    else {
        _25121 = unary_op(NOT, _25120);
    }
    _25120 = NOVALUE;
    if (IS_ATOM_INT(_25121)) {
        if (_25121 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_25121)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_48351);
    _25123 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25123)){
        _25124 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25123)->dbl));
    }
    else{
        _25124 = (object)*(((s1_ptr)_2)->base + _25123);
    }
    _2 = (object)SEQ_PTR(_25124);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _25125 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _25125 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _25124 = NOVALUE;
    Ref(_25125);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48335;
    ((intptr_t *)_2)[2] = _25125;
    _25126 = MAKE_SEQ(_1);
    _25125 = NOVALUE;
    _25127 = find_from(_25126, _54include_warnings_48322, 1LL);
    DeRefDS(_25126);
    _25126 = NOVALUE;
    _25128 = (_25127 == 0);
    _25127 = NOVALUE;
    if (_25128 == 0)
    {
        DeRef(_25128);
        _25128 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_25128);
        _25128 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_48351);
    _25129 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25129)){
        _25130 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25129)->dbl));
    }
    else{
        _25130 = (object)*(((s1_ptr)_2)->base + _25129);
    }
    _2 = (object)SEQ_PTR(_25130);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _25131 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _25131 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _25130 = NOVALUE;
    Ref(_25131);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_48335;
    ((intptr_t *)_2)[2] = _25131;
    _25132 = MAKE_SEQ(_1);
    _25131 = NOVALUE;
    RefDS(_25132);
    Prepend(&_54include_warnings_48322, _54include_warnings_48322, _25132);
    DeRefDS(_25132);
    _25132 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25134 = (object)*(((s1_ptr)_2)->base + _scanning_file_48335);
    Ref(_25134);
    _25135 = _54name_ext(_25134);
    _25134 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_48351);
    _25136 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_25136)){
        _25137 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25136)->dbl));
    }
    else{
        _25137 = (object)*(((s1_ptr)_2)->base + _25136);
    }
    _2 = (object)SEQ_PTR(_25137);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _25138 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _25138 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _25137 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15638);
    if (!IS_ATOM_INT(_25138)){
        _25139 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25138)->dbl));
    }
    else{
        _25139 = (object)*(((s1_ptr)_2)->base + _25138);
    }
    Ref(_25139);
    _25140 = _54name_ext(_25139);
    _25139 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25135;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    RefDS(_word_48333);
    ((intptr_t*)_2)[3] = _word_48333;
    ((intptr_t*)_2)[4] = _25140;
    _25141 = MAKE_SEQ(_1);
    _25140 = NOVALUE;
    _25135 = NOVALUE;
    _0 = _39GetMsgText(233LL, 0LL, _25141);
    DeRef(_36symbol_resolution_warning_21864);
    _36symbol_resolution_warning_21864 = _0;
    _25141 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_tok_48350);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25138 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25121);
    _25121 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25123 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25052);
    _25052 = NOVALUE;
    _25090 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _25129 = NOVALUE;
    _25049 = NOVALUE;
    DeRef(_25117);
    _25117 = NOVALUE;
    _25088 = NOVALUE;
    _24997 = NOVALUE;
    _25136 = NOVALUE;
    return _gtok_48351;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25143 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25143 = 1;
    }
    if (_25143 != 0LL)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_48344 = 9LL;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_36fwd_line_number_21761 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_50ForwardLine_49591);
    DeRef(_50last_ForwardLine_49593);
    _50last_ForwardLine_49593 = _50ForwardLine_49591;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _50last_forward_bp_49597 = _50forward_bp_49595;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _36last_fwd_line_number_21763 = _36fwd_line_number_21761;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_50ThisLine_49590);
    DeRef(_50ForwardLine_49591);
    _50ForwardLine_49591 = _50ThisLine_49590;

    /** symtab.e:1061			forward_bp = bp*/
    _50forward_bp_49595 = _50bp_49594;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _36fwd_line_number_21761 = _36line_number_21760;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_54dup_globals_48319)){
            _25145 = SEQ_PTR(_54dup_globals_48319)->length;
    }
    else {
        _25145 = 1;
    }
    if (_25145 == 0)
    {
        _25145 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _25145 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_48344 = 10LL;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_48320)){
            _25146 = SEQ_PTR(_54dup_overrides_48320)->length;
    }
    else {
        _25146 = 1;
    }
    if (_25146 == 0)
    {
        _25146 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _25146 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_48344 = 12LL;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_54No_new_entry_48330 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509LL;
    RefDS(_word_48333);
    ((intptr_t*)_2)[2] = _word_48333;
    ((intptr_t*)_2)[3] = _defined_48344;
    RefDS(_54dup_globals_48319);
    ((intptr_t*)_2)[4] = _54dup_globals_48319;
    _25147 = MAKE_SEQ(_1);
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_tok_48350);
    DeRef(_gtok_48351);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25138 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25121);
    _25121 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25123 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25052);
    _25052 = NOVALUE;
    _25090 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _25129 = NOVALUE;
    _25049 = NOVALUE;
    DeRef(_25117);
    _25117 = NOVALUE;
    _25088 = NOVALUE;
    _24997 = NOVALUE;
    _25136 = NOVALUE;
    return _25147;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _25148 = (object)*(((s1_ptr)_2)->base + _hashval_48339);
    RefDS(_word_48333);
    Ref(_25148);
    _25149 = _54NewEntry(_word_48333, 0LL, _defined_48344, -100LL, _hashval_48339, _25148, 0LL);
    _25148 = NOVALUE;
    DeRef(_tok_48350);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _25149;
    _tok_48350 = MAKE_SEQ(_1);
    _25149 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_48350);
    _25151 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_25151);
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_48339);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25151;
    if( _1 != _25151 ){
        DeRef(_1);
    }
    _25151 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_48334 == -1LL)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_48350);
    _25153 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_25153))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25153)->dbl));
    else
    _3 = (object)(_25153 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21392))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_48334;
    DeRef(_1);
    _25154 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_48333);
    DeRef(_msg_48341);
    DeRef(_b_name_48342);
    DeRef(_gtok_48351);
    DeRef(_25019);
    _25019 = NOVALUE;
    DeRef(_25017);
    _25017 = NOVALUE;
    _25138 = NOVALUE;
    _25153 = NOVALUE;
    _25005 = NOVALUE;
    DeRef(_25121);
    _25121 = NOVALUE;
    DeRef(_25025);
    _25025 = NOVALUE;
    _25044 = NOVALUE;
    _24992 = NOVALUE;
    _24996 = NOVALUE;
    _25023 = NOVALUE;
    DeRef(_25027);
    _25027 = NOVALUE;
    _25031 = NOVALUE;
    DeRef(_24978);
    _24978 = NOVALUE;
    _25123 = NOVALUE;
    _25037 = NOVALUE;
    DeRef(_25101);
    _25101 = NOVALUE;
    DeRef(_24968);
    _24968 = NOVALUE;
    DeRef(_25052);
    _25052 = NOVALUE;
    _25090 = NOVALUE;
    DeRef(_25033);
    _25033 = NOVALUE;
    _25012 = NOVALUE;
    _25129 = NOVALUE;
    _25049 = NOVALUE;
    DeRef(_25117);
    _25117 = NOVALUE;
    _25088 = NOVALUE;
    _24997 = NOVALUE;
    DeRef(_25147);
    _25147 = NOVALUE;
    _25136 = NOVALUE;
    return _tok_48350;
    ;
}


void _54Hide(object _s_48744)
{
    object _prev_48746 = NOVALUE;
    object _p_48747 = NOVALUE;
    object _25174 = NOVALUE;
    object _25173 = NOVALUE;
    object _25172 = NOVALUE;
    object _25170 = NOVALUE;
    object _25169 = NOVALUE;
    object _25168 = NOVALUE;
    object _25167 = NOVALUE;
    object _25166 = NOVALUE;
    object _25162 = NOVALUE;
    object _25161 = NOVALUE;
    object _25160 = NOVALUE;
    object _25159 = NOVALUE;
    object _25157 = NOVALUE;
    object _25156 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48744)) {
        _1 = (object)(DBL_PTR(_s_48744)->dbl);
        DeRefDS(_s_48744);
        _s_48744 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25156 = (object)*(((s1_ptr)_2)->base + _s_48744);
    _2 = (object)SEQ_PTR(_25156);
    _25157 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25156 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47128);
    if (!IS_ATOM_INT(_25157)){
        _p_48747 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25157)->dbl));
    }
    else{
        _p_48747 = (object)*(((s1_ptr)_2)->base + _25157);
    }
    if (!IS_ATOM_INT(_p_48747)){
        _p_48747 = (object)DBL_PTR(_p_48747)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48746 = 0LL;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _25159 = (_p_48747 != _s_48744);
    if (_25159 == 0) {
        goto L2; // [41] 81
    }
    _25161 = (_p_48747 != 0LL);
    if (_25161 == 0)
    {
        DeRef(_25161);
        _25161 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_25161);
        _25161 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48746 = _p_48747;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25162 = (object)*(((s1_ptr)_2)->base + _p_48747);
    _2 = (object)SEQ_PTR(_25162);
    _p_48747 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_p_48747)){
        _p_48747 = (object)DBL_PTR(_p_48747)->dbl;
    }
    _25162 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48747 != 0LL)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _25157 = NOVALUE;
    DeRef(_25159);
    _25159 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48746 != 0LL)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25166 = (object)*(((s1_ptr)_2)->base + _s_48744);
    _2 = (object)SEQ_PTR(_25166);
    _25167 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25166 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25168 = (object)*(((s1_ptr)_2)->base + _s_48744);
    _2 = (object)SEQ_PTR(_25168);
    _25169 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25168 = NOVALUE;
    Ref(_25169);
    _2 = (object)SEQ_PTR(_54buckets_47128);
    if (!IS_ATOM_INT(_25167))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25167)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25167);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25169;
    if( _1 != _25169 ){
        DeRef(_1);
    }
    _25169 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48746 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25172 = (object)*(((s1_ptr)_2)->base + _s_48744);
    _2 = (object)SEQ_PTR(_25172);
    _25173 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25172 = NOVALUE;
    Ref(_25173);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25173;
    if( _1 != _25173 ){
        DeRef(_1);
    }
    _25173 = NOVALUE;
    _25170 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48744 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _25174 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _25157 = NOVALUE;
    _25167 = NOVALUE;
    DeRef(_25159);
    _25159 = NOVALUE;
    return;
    ;
}


void _54Show(object _s_48789)
{
    object _p_48791 = NOVALUE;
    object _25186 = NOVALUE;
    object _25185 = NOVALUE;
    object _25183 = NOVALUE;
    object _25182 = NOVALUE;
    object _25180 = NOVALUE;
    object _25179 = NOVALUE;
    object _25177 = NOVALUE;
    object _25176 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25176 = (object)*(((s1_ptr)_2)->base + _s_48789);
    _2 = (object)SEQ_PTR(_25176);
    _25177 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25176 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47128);
    if (!IS_ATOM_INT(_25177)){
        _p_48791 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_25177)->dbl));
    }
    else{
        _p_48791 = (object)*(((s1_ptr)_2)->base + _25177);
    }
    if (!IS_ATOM_INT(_p_48791)){
        _p_48791 = (object)DBL_PTR(_p_48791)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25179 = (object)*(((s1_ptr)_2)->base + _s_48789);
    _2 = (object)SEQ_PTR(_25179);
    _25180 = (object)*(((s1_ptr)_2)->base + 9LL);
    _25179 = NOVALUE;
    if (IS_ATOM_INT(_25180)) {
        if (_25180 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_25180)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _25182 = (_p_48791 == _s_48789);
    if (_25182 == 0)
    {
        DeRef(_25182);
        _25182 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_25182);
        _25182 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _25177 = NOVALUE;
    _25180 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48789 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48791;
    DeRef(_1);
    _25183 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25185 = (object)*(((s1_ptr)_2)->base + _s_48789);
    _2 = (object)SEQ_PTR(_25185);
    _25186 = (object)*(((s1_ptr)_2)->base + 11LL);
    _25185 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47128);
    if (!IS_ATOM_INT(_25186))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_25186)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _25186);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48789;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _25177 = NOVALUE;
    _25180 = NOVALUE;
    _25186 = NOVALUE;
    return;
    ;
}


void _54hide_params(object _s_48815)
{
    object _param_48817 = NOVALUE;
    object _25189 = NOVALUE;
    object _25188 = NOVALUE;
    object _25187 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48817 = _s_48815;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25187 = (object)*(((s1_ptr)_2)->base + _s_48815);
    _2 = (object)SEQ_PTR(_25187);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _25188 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _25188 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _25187 = NOVALUE;
    {
        object _i_48819;
        _i_48819 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48819, _25188)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25189 = (object)*(((s1_ptr)_2)->base + _s_48815);
        _2 = (object)SEQ_PTR(_25189);
        _param_48817 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48817)){
            _param_48817 = (object)DBL_PTR(_param_48817)->dbl;
        }
        _25189 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _54Hide(_param_48817);

        /** symtab.e:1131		end for*/
        _0 = _i_48819;
        if (IS_ATOM_INT(_i_48819)) {
            _i_48819 = _i_48819 + 1LL;
            if ((object)((uintptr_t)_i_48819 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48819 = NewDouble((eudouble)_i_48819);
            }
        }
        else {
            _i_48819 = binary_op_a(PLUS, _i_48819, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48819);
    }

    /** symtab.e:1132	end procedure*/
    _25188 = NOVALUE;
    return;
    ;
}


void _54show_params(object _s_48831)
{
    object _param_48833 = NOVALUE;
    object _25193 = NOVALUE;
    object _25192 = NOVALUE;
    object _25191 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48833 = _s_48831;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25191 = (object)*(((s1_ptr)_2)->base + _s_48831);
    _2 = (object)SEQ_PTR(_25191);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _25192 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _25192 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _25191 = NOVALUE;
    {
        object _i_48835;
        _i_48835 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48835, _25192)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25193 = (object)*(((s1_ptr)_2)->base + _s_48831);
        _2 = (object)SEQ_PTR(_25193);
        _param_48833 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48833)){
            _param_48833 = (object)DBL_PTR(_param_48833)->dbl;
        }
        _25193 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _54Show(_param_48833);

        /** symtab.e:1139		end for*/
        _0 = _i_48835;
        if (IS_ATOM_INT(_i_48835)) {
            _i_48835 = _i_48835 + 1LL;
            if ((object)((uintptr_t)_i_48835 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48835 = NewDouble((eudouble)_i_48835);
            }
        }
        else {
            _i_48835 = binary_op_a(PLUS, _i_48835, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48835);
    }

    /** symtab.e:1140	end procedure*/
    _25192 = NOVALUE;
    return;
    ;
}


void _54LintCheck(object _s_48847)
{
    object _warn_level_48848 = NOVALUE;
    object _file_48849 = NOVALUE;
    object _vscope_48850 = NOVALUE;
    object _vname_48851 = NOVALUE;
    object _vusage_48852 = NOVALUE;
    object _25254 = NOVALUE;
    object _25253 = NOVALUE;
    object _25252 = NOVALUE;
    object _25251 = NOVALUE;
    object _25250 = NOVALUE;
    object _25249 = NOVALUE;
    object _25247 = NOVALUE;
    object _25246 = NOVALUE;
    object _25245 = NOVALUE;
    object _25244 = NOVALUE;
    object _25243 = NOVALUE;
    object _25242 = NOVALUE;
    object _25239 = NOVALUE;
    object _25238 = NOVALUE;
    object _25237 = NOVALUE;
    object _25236 = NOVALUE;
    object _25235 = NOVALUE;
    object _25234 = NOVALUE;
    object _25232 = NOVALUE;
    object _25230 = NOVALUE;
    object _25229 = NOVALUE;
    object _25227 = NOVALUE;
    object _25226 = NOVALUE;
    object _25224 = NOVALUE;
    object _25223 = NOVALUE;
    object _25222 = NOVALUE;
    object _25221 = NOVALUE;
    object _25219 = NOVALUE;
    object _25218 = NOVALUE;
    object _25214 = NOVALUE;
    object _25211 = NOVALUE;
    object _25210 = NOVALUE;
    object _25209 = NOVALUE;
    object _25208 = NOVALUE;
    object _25205 = NOVALUE;
    object _25204 = NOVALUE;
    object _25199 = NOVALUE;
    object _25197 = NOVALUE;
    object _25195 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48847)) {
        _1 = (object)(DBL_PTR(_s_48847)->dbl);
        DeRefDS(_s_48847);
        _s_48847 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25195 = (object)*(((s1_ptr)_2)->base + _s_48847);
    _2 = (object)SEQ_PTR(_25195);
    _vusage_48852 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_vusage_48852)){
        _vusage_48852 = (object)DBL_PTR(_vusage_48852)->dbl;
    }
    _25195 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25197 = (object)*(((s1_ptr)_2)->base + _s_48847);
    _2 = (object)SEQ_PTR(_25197);
    _vscope_48850 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_vscope_48850)){
        _vscope_48850 = (object)DBL_PTR(_vscope_48850)->dbl;
    }
    _25197 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25199 = (object)*(((s1_ptr)_2)->base + _s_48847);
    DeRef(_vname_48851);
    _2 = (object)SEQ_PTR(_25199);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _vname_48851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _vname_48851 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    Ref(_vname_48851);
    _25199 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48852;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48848 = 1LL;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48848 = 2LL;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48850 <= 5LL)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48848 = 0LL;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25204 = (object)*(((s1_ptr)_2)->base + _s_48847);
        _2 = (object)SEQ_PTR(_25204);
        _25205 = (object)*(((s1_ptr)_2)->base + 3LL);
        _25204 = NOVALUE;
        if (binary_op_a(NOTEQ, _25205, 2LL)){
            _25205 = NOVALUE;
            goto L1; // [110] 193
        }
        _25205 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_36Strict_is_on_21828 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48848 = 0LL;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25208 = (object)*(((s1_ptr)_2)->base + _s_48847);
        _2 = (object)SEQ_PTR(_25208);
        _25209 = (object)*(((s1_ptr)_2)->base + 16LL);
        _25208 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _25210 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
        _2 = (object)SEQ_PTR(_25210);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
            _25211 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
        }
        else{
            _25211 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
        }
        _25210 = NOVALUE;
        if (binary_op_a(LESS, _25209, _25211)){
            _25209 = NOVALUE;
            _25211 = NOVALUE;
            goto L3; // [163] 175
        }
        _25209 = NOVALUE;
        _25211 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48848 = 3LL;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48848 = 0LL;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48848 = 0LL;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48848 != 0LL)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48849);
    DeRef(_vname_48851);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _25214 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    Ref(_25214);
    RefDS(_22186);
    _0 = _file_48849;
    _file_48849 = _17abbreviate_path(_25214, _22186);
    DeRef(_0);
    _25214 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48848 != 3LL)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48850 != 5LL)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25218 = (object)*(((s1_ptr)_2)->base + _s_48847);
    _2 = (object)SEQ_PTR(_25218);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _25219 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _25219 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _25218 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21759, _25219)){
        _25219 = NOVALUE;
        goto L7; // [254] 602
    }
    _25219 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48851);
    RefDS(_file_48849);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48849;
    ((intptr_t *)_2)[2] = _vname_48851;
    _25221 = MAKE_SEQ(_1);
    _50Warning(226LL, 32LL, _25221);
    _25221 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25222 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25222);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25223 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25223 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25222 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48849);
    ((intptr_t*)_2)[1] = _file_48849;
    RefDS(_vname_48851);
    ((intptr_t*)_2)[2] = _vname_48851;
    Ref(_25223);
    ((intptr_t*)_2)[3] = _25223;
    _25224 = MAKE_SEQ(_1);
    _25223 = NOVALUE;
    _50Warning(227LL, 32LL, _25224);
    _25224 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48850 != 5LL)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25226 = (object)*(((s1_ptr)_2)->base + _s_48847);
    _2 = (object)SEQ_PTR(_25226);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _25227 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _25227 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _25226 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21759, _25227)){
        _25227 = NOVALUE;
        goto L9; // [332] 601
    }
    _25227 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25229 = (object)*(((s1_ptr)_2)->base + _s_48847);
    _2 = (object)SEQ_PTR(_25229);
    _25230 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25229 = NOVALUE;
    if (binary_op_a(NOTEQ, _25230, 2LL)){
        _25230 = NOVALUE;
        goto LA; // [352] 372
    }
    _25230 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48851);
    RefDS(_file_48849);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48849;
    ((intptr_t *)_2)[2] = _vname_48851;
    _25232 = MAKE_SEQ(_1);
    _50Warning(228LL, 16LL, _25232);
    _25232 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48848 != 1LL)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48851);
    RefDS(_file_48849);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48849;
    ((intptr_t *)_2)[2] = _vname_48851;
    _25234 = MAKE_SEQ(_1);
    _50Warning(229LL, 16LL, _25234);
    _25234 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48851);
    RefDS(_file_48849);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48849;
    ((intptr_t *)_2)[2] = _vname_48851;
    _25235 = MAKE_SEQ(_1);
    _50Warning(320LL, 16LL, _25235);
    _25235 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25236 = (object)*(((s1_ptr)_2)->base + _s_48847);
    _2 = (object)SEQ_PTR(_25236);
    _25237 = (object)*(((s1_ptr)_2)->base + 16LL);
    _25236 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25238 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25238);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _25239 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _25239 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _25238 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25237, _25239)){
        _25237 = NOVALUE;
        _25239 = NOVALUE;
        goto LC; // [440] 523
    }
    _25237 = NOVALUE;
    _25239 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48848 != 1LL)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_36Strict_is_on_21828 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25242 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25242);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25243 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25243 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25242 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48849);
    ((intptr_t*)_2)[1] = _file_48849;
    RefDS(_vname_48851);
    ((intptr_t*)_2)[2] = _vname_48851;
    Ref(_25243);
    ((intptr_t*)_2)[3] = _25243;
    _25244 = MAKE_SEQ(_1);
    _25243 = NOVALUE;
    _50Warning(230LL, 16LL, _25244);
    _25244 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25245 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25245);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25246 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25246 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25245 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48849);
    ((intptr_t*)_2)[1] = _file_48849;
    RefDS(_vname_48851);
    ((intptr_t*)_2)[2] = _vname_48851;
    Ref(_25246);
    ((intptr_t*)_2)[3] = _25246;
    _25247 = MAKE_SEQ(_1);
    _25246 = NOVALUE;
    _50Warning(321LL, 16LL, _25247);
    _25247 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48848 != 1LL)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_36Strict_is_on_21828 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25249 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25249);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25250 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25250 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25249 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48849);
    ((intptr_t*)_2)[1] = _file_48849;
    RefDS(_vname_48851);
    ((intptr_t*)_2)[2] = _vname_48851;
    Ref(_25250);
    ((intptr_t*)_2)[3] = _25250;
    _25251 = MAKE_SEQ(_1);
    _25250 = NOVALUE;
    _50Warning(231LL, 16LL, _25251);
    _25251 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25252 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25252);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25253 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25253 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25252 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48849);
    ((intptr_t*)_2)[1] = _file_48849;
    RefDS(_vname_48851);
    ((intptr_t*)_2)[2] = _vname_48851;
    Ref(_25253);
    ((intptr_t*)_2)[3] = _25253;
    _25254 = MAKE_SEQ(_1);
    _25253 = NOVALUE;
    _50Warning(322LL, 16LL, _25254);
    _25254 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48849);
    DeRef(_vname_48851);
    return;
    ;
}


void _54HideLocals()
{
    object _s_49018 = NOVALUE;
    object _25267 = NOVALUE;
    object _25265 = NOVALUE;
    object _25264 = NOVALUE;
    object _25263 = NOVALUE;
    object _25262 = NOVALUE;
    object _25261 = NOVALUE;
    object _25260 = NOVALUE;
    object _25259 = NOVALUE;
    object _25258 = NOVALUE;
    object _25257 = NOVALUE;
    object _25256 = NOVALUE;
    object _25255 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _54mark_rechecks(_36current_file_no_21759);

    /** symtab.e:1245		s = file_start_sym*/
    _s_49018 = _36file_start_sym_21765;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_49018 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25255 = (object)*(((s1_ptr)_2)->base + _s_49018);
    _2 = (object)SEQ_PTR(_25255);
    _25256 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25255 = NOVALUE;
    if (IS_ATOM_INT(_25256)) {
        _25257 = (_25256 == 5LL);
    }
    else {
        _25257 = binary_op(EQUALS, _25256, 5LL);
    }
    _25256 = NOVALUE;
    if (IS_ATOM_INT(_25257)) {
        if (_25257 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25257)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25259 = (object)*(((s1_ptr)_2)->base + _s_49018);
    _2 = (object)SEQ_PTR(_25259);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _25260 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _25260 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _25259 = NOVALUE;
    if (IS_ATOM_INT(_25260)) {
        _25261 = (_25260 == _36current_file_no_21759);
    }
    else {
        _25261 = binary_op(EQUALS, _25260, _36current_file_no_21759);
    }
    _25260 = NOVALUE;
    if (_25261 == 0) {
        DeRef(_25261);
        _25261 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25261) && DBL_PTR(_25261)->dbl == 0.0){
            DeRef(_25261);
            _25261 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25261);
        _25261 = NOVALUE;
    }
    DeRef(_25261);
    _25261 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25262 = (_65current_block_25434 == _65top_level_block_25435);
    if (_25262 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _54Hide(_s_49018);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25264 = (object)*(((s1_ptr)_2)->base + _s_49018);
    _2 = (object)SEQ_PTR(_25264);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _25265 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _25265 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _25264 = NOVALUE;
    if (binary_op_a(NOTEQ, _25265, -100LL)){
        _25265 = NOVALUE;
        goto L6; // [116] 126
    }
    _25265 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _54LintCheck(_s_49018);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25267 = (object)*(((s1_ptr)_2)->base + _s_49018);
    _2 = (object)SEQ_PTR(_25267);
    _s_49018 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_49018)){
        _s_49018 = (object)DBL_PTR(_s_49018)->dbl;
    }
    _25267 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25257);
    _25257 = NOVALUE;
    DeRef(_25262);
    _25262 = NOVALUE;
    return;
    ;
}


object _54sym_name(object _sym_49057)
{
    object _25270 = NOVALUE;
    object _25269 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49057)) {
        _1 = (object)(DBL_PTR(_sym_49057)->dbl);
        DeRefDS(_sym_49057);
        _sym_49057 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25269 = (object)*(((s1_ptr)_2)->base + _sym_49057);
    _2 = (object)SEQ_PTR(_25269);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _25270 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _25270 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _25269 = NOVALUE;
    Ref(_25270);
    return _25270;
    ;
}


object _54sym_token(object _sym_49065)
{
    object _25272 = NOVALUE;
    object _25271 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49065)) {
        _1 = (object)(DBL_PTR(_sym_49065)->dbl);
        DeRefDS(_sym_49065);
        _sym_49065 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25271 = (object)*(((s1_ptr)_2)->base + _sym_49065);
    _2 = (object)SEQ_PTR(_25271);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _25272 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _25272 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _25271 = NOVALUE;
    Ref(_25272);
    return _25272;
    ;
}


object _54sym_scope(object _sym_49073)
{
    object _25274 = NOVALUE;
    object _25273 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49073)) {
        _1 = (object)(DBL_PTR(_sym_49073)->dbl);
        DeRefDS(_sym_49073);
        _sym_49073 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25273 = (object)*(((s1_ptr)_2)->base + _sym_49073);
    _2 = (object)SEQ_PTR(_25273);
    _25274 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25273 = NOVALUE;
    Ref(_25274);
    return _25274;
    ;
}


object _54sym_mode(object _sym_49081)
{
    object _25276 = NOVALUE;
    object _25275 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49081)) {
        _1 = (object)(DBL_PTR(_sym_49081)->dbl);
        DeRefDS(_sym_49081);
        _sym_49081 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25275 = (object)*(((s1_ptr)_2)->base + _sym_49081);
    _2 = (object)SEQ_PTR(_25275);
    _25276 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25275 = NOVALUE;
    Ref(_25276);
    return _25276;
    ;
}


object _54sym_obj(object _sym_49089)
{
    object _25278 = NOVALUE;
    object _25277 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_49089)) {
        _1 = (object)(DBL_PTR(_sym_49089)->dbl);
        DeRefDS(_sym_49089);
        _sym_49089 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25277 = (object)*(((s1_ptr)_2)->base + _sym_49089);
    _2 = (object)SEQ_PTR(_25277);
    _25278 = (object)*(((s1_ptr)_2)->base + 1LL);
    _25277 = NOVALUE;
    Ref(_25278);
    return _25278;
    ;
}


object _54sym_next(object _sym_49097)
{
    object _25280 = NOVALUE;
    object _25279 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25279 = (object)*(((s1_ptr)_2)->base + _sym_49097);
    _2 = (object)SEQ_PTR(_25279);
    _25280 = (object)*(((s1_ptr)_2)->base + 2LL);
    _25279 = NOVALUE;
    Ref(_25280);
    return _25280;
    ;
}


object _54sym_block(object _sym_49105)
{
    object _25282 = NOVALUE;
    object _25281 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25281 = (object)*(((s1_ptr)_2)->base + _sym_49105);
    _2 = (object)SEQ_PTR(_25281);
    if (!IS_ATOM_INT(_36S_BLOCK_21416)){
        _25282 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21416)->dbl));
    }
    else{
        _25282 = (object)*(((s1_ptr)_2)->base + _36S_BLOCK_21416);
    }
    _25281 = NOVALUE;
    Ref(_25282);
    return _25282;
    ;
}


object _54sym_next_in_block(object _sym_49113)
{
    object _25284 = NOVALUE;
    object _25283 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25283 = (object)*(((s1_ptr)_2)->base + _sym_49113);
    _2 = (object)SEQ_PTR(_25283);
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21388)){
        _25284 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21388)->dbl));
    }
    else{
        _25284 = (object)*(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21388);
    }
    _25283 = NOVALUE;
    Ref(_25284);
    return _25284;
    ;
}


object _54sym_usage(object _sym_49121)
{
    object _25286 = NOVALUE;
    object _25285 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25285 = (object)*(((s1_ptr)_2)->base + _sym_49121);
    _2 = (object)SEQ_PTR(_25285);
    _25286 = (object)*(((s1_ptr)_2)->base + 5LL);
    _25285 = NOVALUE;
    Ref(_25286);
    return _25286;
    ;
}



// 0x3B115526
