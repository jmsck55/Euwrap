// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _66init_op_info()
{
    object _SHORT_CIRCUIT_24982 = NOVALUE;
    object _info_25027 = NOVALUE;
    object _14039 = NOVALUE;
    object _14038 = NOVALUE;
    object _14037 = NOVALUE;
    object _14036 = NOVALUE;
    object _14035 = NOVALUE;
    object _14034 = NOVALUE;
    object _14032 = NOVALUE;
    object _14031 = NOVALUE;
    object _14030 = NOVALUE;
    object _14029 = NOVALUE;
    object _14028 = NOVALUE;
    object _14027 = NOVALUE;
    object _14026 = NOVALUE;
    object _14025 = NOVALUE;
    object _14024 = NOVALUE;
    object _14023 = NOVALUE;
    object _14022 = NOVALUE;
    object _14021 = NOVALUE;
    object _14020 = NOVALUE;
    object _14019 = NOVALUE;
    object _14018 = NOVALUE;
    object _14017 = NOVALUE;
    object _14016 = NOVALUE;
    object _14015 = NOVALUE;
    object _14013 = NOVALUE;
    object _14012 = NOVALUE;
    object _14011 = NOVALUE;
    object _14010 = NOVALUE;
    object _14009 = NOVALUE;
    object _14008 = NOVALUE;
    object _14007 = NOVALUE;
    object _14006 = NOVALUE;
    object _14005 = NOVALUE;
    object _14004 = NOVALUE;
    object _14003 = NOVALUE;
    object _14002 = NOVALUE;
    object _14001 = NOVALUE;
    object _14000 = NOVALUE;
    object _13999 = NOVALUE;
    object _13998 = NOVALUE;
    object _13997 = NOVALUE;
    object _13996 = NOVALUE;
    object _13995 = NOVALUE;
    object _13994 = NOVALUE;
    object _13993 = NOVALUE;
    object _13992 = NOVALUE;
    object _13991 = NOVALUE;
    object _13990 = NOVALUE;
    object _13989 = NOVALUE;
    object _13988 = NOVALUE;
    object _13987 = NOVALUE;
    object _13986 = NOVALUE;
    object _13985 = NOVALUE;
    object _13984 = NOVALUE;
    object _13983 = NOVALUE;
    object _13982 = NOVALUE;
    object _13981 = NOVALUE;
    object _13980 = NOVALUE;
    object _13979 = NOVALUE;
    object _13978 = NOVALUE;
    object _13977 = NOVALUE;
    object _13976 = NOVALUE;
    object _13975 = NOVALUE;
    object _13974 = NOVALUE;
    object _13973 = NOVALUE;
    object _13972 = NOVALUE;
    object _13971 = NOVALUE;
    object _13970 = NOVALUE;
    object _13969 = NOVALUE;
    object _13968 = NOVALUE;
    object _13967 = NOVALUE;
    object _13966 = NOVALUE;
    object _13964 = NOVALUE;
    object _13963 = NOVALUE;
    object _13962 = NOVALUE;
    object _13961 = NOVALUE;
    object _13960 = NOVALUE;
    object _13959 = NOVALUE;
    object _13958 = NOVALUE;
    object _13957 = NOVALUE;
    object _13956 = NOVALUE;
    object _13955 = NOVALUE;
    object _13954 = NOVALUE;
    object _13953 = NOVALUE;
    object _13952 = NOVALUE;
    object _13951 = NOVALUE;
    object _13950 = NOVALUE;
    object _13949 = NOVALUE;
    object _13948 = NOVALUE;
    object _13947 = NOVALUE;
    object _13946 = NOVALUE;
    object _13945 = NOVALUE;
    object _13944 = NOVALUE;
    object _13943 = NOVALUE;
    object _13942 = NOVALUE;
    object _13941 = NOVALUE;
    object _13940 = NOVALUE;
    object _13939 = NOVALUE;
    object _13938 = NOVALUE;
    object _13937 = NOVALUE;
    object _13936 = NOVALUE;
    object _13935 = NOVALUE;
    object _13934 = NOVALUE;
    object _13933 = NOVALUE;
    object _13932 = NOVALUE;
    object _13931 = NOVALUE;
    object _13930 = NOVALUE;
    object _13929 = NOVALUE;
    object _13928 = NOVALUE;
    object _13927 = NOVALUE;
    object _13926 = NOVALUE;
    object _13925 = NOVALUE;
    object _13924 = NOVALUE;
    object _13923 = NOVALUE;
    object _13922 = NOVALUE;
    object _13921 = NOVALUE;
    object _13920 = NOVALUE;
    object _13919 = NOVALUE;
    object _13918 = NOVALUE;
    object _13917 = NOVALUE;
    object _13916 = NOVALUE;
    object _13915 = NOVALUE;
    object _13914 = NOVALUE;
    object _13913 = NOVALUE;
    object _13912 = NOVALUE;
    object _13911 = NOVALUE;
    object _13910 = NOVALUE;
    object _13909 = NOVALUE;
    object _13908 = NOVALUE;
    object _13907 = NOVALUE;
    object _13906 = NOVALUE;
    object _13905 = NOVALUE;
    object _13904 = NOVALUE;
    object _13903 = NOVALUE;
    object _13902 = NOVALUE;
    object _13901 = NOVALUE;
    object _13900 = NOVALUE;
    object _13899 = NOVALUE;
    object _13898 = NOVALUE;
    object _13897 = NOVALUE;
    object _13896 = NOVALUE;
    object _13895 = NOVALUE;
    object _13893 = NOVALUE;
    object _13892 = NOVALUE;
    object _13891 = NOVALUE;
    object _13890 = NOVALUE;
    object _13889 = NOVALUE;
    object _13888 = NOVALUE;
    object _13887 = NOVALUE;
    object _13886 = NOVALUE;
    object _13885 = NOVALUE;
    object _13884 = NOVALUE;
    object _13883 = NOVALUE;
    object _13882 = NOVALUE;
    object _13881 = NOVALUE;
    object _13880 = NOVALUE;
    object _13879 = NOVALUE;
    object _13878 = NOVALUE;
    object _13877 = NOVALUE;
    object _13876 = NOVALUE;
    object _13875 = NOVALUE;
    object _13874 = NOVALUE;
    object _13873 = NOVALUE;
    object _13872 = NOVALUE;
    object _13871 = NOVALUE;
    object _13870 = NOVALUE;
    object _13869 = NOVALUE;
    object _13868 = NOVALUE;
    object _13867 = NOVALUE;
    object _13865 = NOVALUE;
    object _13864 = NOVALUE;
    object _13863 = NOVALUE;
    object _13862 = NOVALUE;
    object _13861 = NOVALUE;
    object _13860 = NOVALUE;
    object _13859 = NOVALUE;
    object _13858 = NOVALUE;
    object _13857 = NOVALUE;
    object _13856 = NOVALUE;
    object _13855 = NOVALUE;
    object _13854 = NOVALUE;
    object _13853 = NOVALUE;
    object _13852 = NOVALUE;
    object _13851 = NOVALUE;
    object _13850 = NOVALUE;
    object _13849 = NOVALUE;
    object _13848 = NOVALUE;
    object _13847 = NOVALUE;
    object _13846 = NOVALUE;
    object _13845 = NOVALUE;
    object _13844 = NOVALUE;
    object _13843 = NOVALUE;
    object _13842 = NOVALUE;
    object _13841 = NOVALUE;
    object _13840 = NOVALUE;
    object _13839 = NOVALUE;
    object _13838 = NOVALUE;
    object _13837 = NOVALUE;
    object _13836 = NOVALUE;
    object _13835 = NOVALUE;
    object _13834 = NOVALUE;
    object _13833 = NOVALUE;
    object _13832 = NOVALUE;
    object _13831 = NOVALUE;
    object _13830 = NOVALUE;
    object _13829 = NOVALUE;
    object _13828 = NOVALUE;
    object _13827 = NOVALUE;
    object _13826 = NOVALUE;
    object _13825 = NOVALUE;
    object _13824 = NOVALUE;
    object _13823 = NOVALUE;
    object _13822 = NOVALUE;
    object _13821 = NOVALUE;
    object _13820 = NOVALUE;
    object _13818 = NOVALUE;
    object _13817 = NOVALUE;
    object _13816 = NOVALUE;
    object _13815 = NOVALUE;
    object _13814 = NOVALUE;
    object _13813 = NOVALUE;
    object _13812 = NOVALUE;
    object _13811 = NOVALUE;
    object _13810 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:44		op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_24555);
    _66op_info_24555 = Repeat(0LL, 218LL);

    /** shift.e:45		op_info_size_type = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_size_type_24561);
    _66op_info_size_type_24561 = Repeat(0LL, 218LL);

    /** shift.e:46		op_info_size = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_size_24562);
    _66op_info_size_24562 = Repeat(0LL, 218LL);

    /** shift.e:47		op_info_addr = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_addr_24563);
    _66op_info_addr_24563 = Repeat(0LL, 218LL);

    /** shift.e:48		op_info_target = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_target_24564);
    _66op_info_target_24564 = Repeat(0LL, 218LL);

    /** shift.e:49		op_info_sub = repeat( 0, MAX_OPCODE )*/
    DeRef(_66op_info_sub_24565);
    _66op_info_sub_24565 = Repeat(0LL, 218LL);

    /** shift.e:51		op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13810 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 126LL);
    *(intptr_t *)_2 = _13810;
    if( _1 != _13810 ){
    }
    _13810 = NOVALUE;

    /** shift.e:52		op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13811 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13811;
    if( _1 != _13811 ){
        DeRef(_1);
    }
    _13811 = NOVALUE;

    /** shift.e:53		op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13812 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 56LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13812;
    if( _1 != _13812 ){
        DeRef(_1);
    }
    _13812 = NOVALUE;

    /** shift.e:54		op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13813 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13813;
    if( _1 != _13813 ){
        DeRef(_1);
    }
    _13813 = NOVALUE;

    /** shift.e:55		op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13814 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 73LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13814;
    if( _1 != _13814 ){
        DeRef(_1);
    }
    _13814 = NOVALUE;

    /** shift.e:56		op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13815 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 18LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13815;
    if( _1 != _13815 ){
        DeRef(_1);
    }
    _13815 = NOVALUE;

    /** shift.e:57		op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13816 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 113LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13816;
    if( _1 != _13816 ){
        DeRef(_1);
    }
    _13816 = NOVALUE;

    /** shift.e:58		op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13817 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 150LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13817;
    if( _1 != _13817 ){
        DeRef(_1);
    }
    _13817 = NOVALUE;

    /** shift.e:59		op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13818 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 149LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13818;
    if( _1 != _13818 ){
        DeRef(_1);
    }
    _13818 = NOVALUE;

    /** shift.e:60		op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13820 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13820;
    if( _1 != _13820 ){
        DeRef(_1);
    }
    _13820 = NOVALUE;

    /** shift.e:61		op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13821 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13821;
    if( _1 != _13821 ){
        DeRef(_1);
    }
    _13821 = NOVALUE;

    /** shift.e:62		op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13822 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 84LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13822;
    if( _1 != _13822 ){
        DeRef(_1);
    }
    _13822 = NOVALUE;

    /** shift.e:63		op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13823 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 118LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13823;
    if( _1 != _13823 ){
        DeRef(_1);
    }
    _13823 = NOVALUE;

    /** shift.e:64		op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13824 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13824;
    if( _1 != _13824 ){
        DeRef(_1);
    }
    _13824 = NOVALUE;

    /** shift.e:65		op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13825 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 129LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13825;
    if( _1 != _13825 ){
        DeRef(_1);
    }
    _13825 = NOVALUE;

    /** shift.e:66		op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13826 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 136LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13826;
    if( _1 != _13826 ){
        DeRef(_1);
    }
    _13826 = NOVALUE;

    /** shift.e:67		op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13827 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 137LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13827;
    if( _1 != _13827 ){
        DeRef(_1);
    }
    _13827 = NOVALUE;

    /** shift.e:68		op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13828 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 186LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13828;
    if( _1 != _13828 ){
        DeRef(_1);
    }
    _13828 = NOVALUE;

    /** shift.e:69		op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13829 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 59LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13829;
    if( _1 != _13829 ){
        DeRef(_1);
    }
    _13829 = NOVALUE;

    /** shift.e:70		op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13830 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 86LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13830;
    if( _1 != _13830 ){
        DeRef(_1);
    }
    _13830 = NOVALUE;

    /** shift.e:71		op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13831 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 100LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13831;
    if( _1 != _13831 ){
        DeRef(_1);
    }
    _13831 = NOVALUE;

    /** shift.e:72		op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13832 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 76LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13832;
    if( _1 != _13832 ){
        DeRef(_1);
    }
    _13832 = NOVALUE;

    /** shift.e:73		op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13833 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13833;
    if( _1 != _13833 ){
        DeRef(_1);
    }
    _13833 = NOVALUE;

    /** shift.e:74		op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13834 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 81LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13834;
    if( _1 != _13834 ){
        DeRef(_1);
    }
    _13834 = NOVALUE;

    /** shift.e:75		op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13835 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 210LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13835;
    if( _1 != _13835 ){
        DeRef(_1);
    }
    _13835 = NOVALUE;

    /** shift.e:76		op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13836 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 211LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13836;
    if( _1 != _13836 ){
        DeRef(_1);
    }
    _13836 = NOVALUE;

    /** shift.e:77		op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_13430);
    ((intptr_t*)_2)[5] = _13430;
    _13837 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 133LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13837;
    if( _1 != _13837 ){
        DeRef(_1);
    }
    _13837 = NOVALUE;

    /** shift.e:78		op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[5] = _13430;
    _13838 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 132LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13838;
    if( _1 != _13838 ){
        DeRef(_1);
    }
    _13838 = NOVALUE;

    /** shift.e:79		op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13839 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 69LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13839;
    if( _1 != _13839 ){
        DeRef(_1);
    }
    _13839 = NOVALUE;

    /** shift.e:80		op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13840 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 204LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13840;
    if( _1 != _13840 ){
        DeRef(_1);
    }
    _13840 = NOVALUE;

    /** shift.e:81		op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13841 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 205LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13841;
    if( _1 != _13841 ){
        DeRef(_1);
    }
    _13841 = NOVALUE;

    /** shift.e:82		op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13842 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 98LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13842;
    if( _1 != _13842 ){
        DeRef(_1);
    }
    _13842 = NOVALUE;

    /** shift.e:83		op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13843 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13843;
    if( _1 != _13843 ){
        DeRef(_1);
    }
    _13843 = NOVALUE;

    /** shift.e:84		op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13844 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 23LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13844;
    if( _1 != _13844 ){
        DeRef(_1);
    }
    _13844 = NOVALUE;

    /** shift.e:85		op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13845 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 61LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13845;
    if( _1 != _13845 ){
        DeRef(_1);
    }
    _13845 = NOVALUE;

    /** shift.e:86		op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13846 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 206LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13846;
    if( _1 != _13846 ){
        DeRef(_1);
    }
    _13846 = NOVALUE;

    /** shift.e:87		op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13847 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 22LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13847;
    if( _1 != _13847 ){
        DeRef(_1);
    }
    _13847 = NOVALUE;

    /** shift.e:88		op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13848 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 184LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13848;
    if( _1 != _13848 ){
        DeRef(_1);
    }
    _13848 = NOVALUE;

    /** shift.e:89		op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13849 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 188LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13849;
    if( _1 != _13849 ){
        DeRef(_1);
    }
    _13849 = NOVALUE;

    /** shift.e:90		op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13850 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13850;
    if( _1 != _13850 ){
        DeRef(_1);
    }
    _13850 = NOVALUE;

    /** shift.e:91		op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13851 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13851;
    if( _1 != _13851 ){
        DeRef(_1);
    }
    _13851 = NOVALUE;

    /** shift.e:92		op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13852 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 50LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13852;
    if( _1 != _13852 ){
        DeRef(_1);
    }
    _13852 = NOVALUE;

    /** shift.e:93		op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13853 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13853;
    if( _1 != _13853 ){
        DeRef(_1);
    }
    _13853 = NOVALUE;

    /** shift.e:94		op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13854 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13854;
    if( _1 != _13854 ){
        DeRef(_1);
    }
    _13854 = NOVALUE;

    /** shift.e:95		op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13855 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 55LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13855;
    if( _1 != _13855 ){
        DeRef(_1);
    }
    _13855 = NOVALUE;

    /** shift.e:96		op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13856 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13856;
    if( _1 != _13856 ){
        DeRef(_1);
    }
    _13856 = NOVALUE;

    /** shift.e:97		op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13857 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 153LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13857;
    if( _1 != _13857 ){
        DeRef(_1);
    }
    _13857 = NOVALUE;

    /** shift.e:98		op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13858 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13858;
    if( _1 != _13858 ){
        DeRef(_1);
    }
    _13858 = NOVALUE;

    /** shift.e:99		op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13859 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 104LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13859;
    if( _1 != _13859 ){
        DeRef(_1);
    }
    _13859 = NOVALUE;

    /** shift.e:100		op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13860 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 121LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13860;
    if( _1 != _13860 ){
        DeRef(_1);
    }
    _13860 = NOVALUE;

    /** shift.e:101		op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13861 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 77LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13861;
    if( _1 != _13861 ){
        DeRef(_1);
    }
    _13861 = NOVALUE;

    /** shift.e:102		op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13862 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 176LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13862;
    if( _1 != _13862 ){
        DeRef(_1);
    }
    _13862 = NOVALUE;

    /** shift.e:103		op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13863 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 83LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13863;
    if( _1 != _13863 ){
        DeRef(_1);
    }
    _13863 = NOVALUE;

    /** shift.e:104		op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13864 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 63LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13864;
    if( _1 != _13864 ){
        DeRef(_1);
    }
    _13864 = NOVALUE;

    /** shift.e:105		op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13865 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 66LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13865;
    if( _1 != _13865 ){
        DeRef(_1);
    }
    _13865 = NOVALUE;

    /** shift.e:106		op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 7LL;
    RefDS(_13866);
    ((intptr_t*)_2)[3] = _13866;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13867 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 21LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13867;
    if( _1 != _13867 ){
        DeRef(_1);
    }
    _13867 = NOVALUE;

    /** shift.e:107		op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 7LL;
    RefDS(_13866);
    ((intptr_t*)_2)[3] = _13866;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13868 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 125LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13868;
    if( _1 != _13868 ){
        DeRef(_1);
    }
    _13868 = NOVALUE;

    /** shift.e:108		op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13869 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13869;
    if( _1 != _13869 ){
        DeRef(_1);
    }
    _13869 = NOVALUE;

    /** shift.e:109		op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13870 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 91LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13870;
    if( _1 != _13870 ){
        DeRef(_1);
    }
    _13870 = NOVALUE;

    /** shift.e:110		op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13871 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 17LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13871;
    if( _1 != _13871 ){
        DeRef(_1);
    }
    _13871 = NOVALUE;

    /** shift.e:111		op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13872 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 79LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13872;
    if( _1 != _13872 ){
        DeRef(_1);
    }
    _13872 = NOVALUE;

    /** shift.e:112		op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_13819);
    ((intptr_t*)_2)[3] = _13819;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13873 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 189LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13873;
    if( _1 != _13873 ){
        DeRef(_1);
    }
    _13873 = NOVALUE;

    /** shift.e:113		op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13874 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 109LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13874;
    if( _1 != _13874 ){
        DeRef(_1);
    }
    _13874 = NOVALUE;

    /** shift.e:114		op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13875 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13875;
    if( _1 != _13875 ){
        DeRef(_1);
    }
    _13875 = NOVALUE;

    /** shift.e:115		op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13876 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13876;
    if( _1 != _13876 ){
        DeRef(_1);
    }
    _13876 = NOVALUE;

    /** shift.e:116		op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13877 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13877;
    if( _1 != _13877 ){
        DeRef(_1);
    }
    _13877 = NOVALUE;

    /** shift.e:117		op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13878 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 103LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13878;
    if( _1 != _13878 ){
        DeRef(_1);
    }
    _13878 = NOVALUE;

    /** shift.e:118		op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13879 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 120LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13879;
    if( _1 != _13879 ){
        DeRef(_1);
    }
    _13879 = NOVALUE;

    /** shift.e:119		op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13880 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 107LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13880;
    if( _1 != _13880 ){
        DeRef(_1);
    }
    _13880 = NOVALUE;

    /** shift.e:120		op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13881 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 124LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13881;
    if( _1 != _13881 ){
        DeRef(_1);
    }
    _13881 = NOVALUE;

    /** shift.e:121		op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13882 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 194LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13882;
    if( _1 != _13882 ){
        DeRef(_1);
    }
    _13882 = NOVALUE;

    /** shift.e:122		op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13883 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 198LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13883;
    if( _1 != _13883 ){
        DeRef(_1);
    }
    _13883 = NOVALUE;

    /** shift.e:123		op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13493);
    ((intptr_t*)_2)[3] = _13493;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13884 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 20LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13884;
    if( _1 != _13884 ){
        DeRef(_1);
    }
    _13884 = NOVALUE;

    /** shift.e:124		op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13885 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 191LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13885;
    if( _1 != _13885 ){
        DeRef(_1);
    }
    _13885 = NOVALUE;

    /** shift.e:125		op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13886 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13886;
    if( _1 != _13886 ){
        DeRef(_1);
    }
    _13886 = NOVALUE;

    /** shift.e:126		op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13887 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13887;
    if( _1 != _13887 ){
        DeRef(_1);
    }
    _13887 = NOVALUE;

    /** shift.e:127		op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13888 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13888;
    if( _1 != _13888 ){
        DeRef(_1);
    }
    _13888 = NOVALUE;

    /** shift.e:128		op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13889 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 106LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13889;
    if( _1 != _13889 ){
        DeRef(_1);
    }
    _13889 = NOVALUE;

    /** shift.e:129		op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13890 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 123LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13890;
    if( _1 != _13890 ){
        DeRef(_1);
    }
    _13890 = NOVALUE;

    /** shift.e:130		op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13891 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 102LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13891;
    if( _1 != _13891 ){
        DeRef(_1);
    }
    _13891 = NOVALUE;

    /** shift.e:131		op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13892 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 119LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13892;
    if( _1 != _13892 ){
        DeRef(_1);
    }
    _13892 = NOVALUE;

    /** shift.e:132		op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13893 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 95LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13893;
    if( _1 != _13893 ){
        DeRef(_1);
    }
    _13893 = NOVALUE;

    /** shift.e:133		op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13894);
    ((intptr_t*)_2)[4] = _13894;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13895 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 161LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13895;
    if( _1 != _13895 ){
        DeRef(_1);
    }
    _13895 = NOVALUE;

    /** shift.e:134		op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13894);
    ((intptr_t*)_2)[4] = _13894;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13896 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 166LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13896;
    if( _1 != _13896 ){
        DeRef(_1);
    }
    _13896 = NOVALUE;

    /** shift.e:135		op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13897 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 74LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13897;
    if( _1 != _13897 ){
        DeRef(_1);
    }
    _13897 = NOVALUE;

    /** shift.e:136		op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13898 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 111LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13898;
    if( _1 != _13898 ){
        DeRef(_1);
    }
    _13898 = NOVALUE;

    /** shift.e:137		op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13899 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 112LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13899;
    if( _1 != _13899 ){
        DeRef(_1);
    }
    _13899 = NOVALUE;

    /** shift.e:138		op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13900 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 78LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13900;
    if( _1 != _13900 ){
        DeRef(_1);
    }
    _13900 = NOVALUE;

    /** shift.e:139		op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13901 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 177LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13901;
    if( _1 != _13901 ){
        DeRef(_1);
    }
    _13901 = NOVALUE;

    /** shift.e:140		op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13902 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 130LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13902;
    if( _1 != _13902 ){
        DeRef(_1);
    }
    _13902 = NOVALUE;

    /** shift.e:141		op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13903 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 131LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13903;
    if( _1 != _13903 ){
        DeRef(_1);
    }
    _13903 = NOVALUE;

    /** shift.e:142		op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13904 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13904;
    if( _1 != _13904 ){
        DeRef(_1);
    }
    _13904 = NOVALUE;

    /** shift.e:143		op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13905 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 116LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13905;
    if( _1 != _13905 ){
        DeRef(_1);
    }
    _13905 = NOVALUE;

    /** shift.e:144		op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13906 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13906;
    if( _1 != _13906 ){
        DeRef(_1);
    }
    _13906 = NOVALUE;

    /** shift.e:145		op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13907 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 159LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13907;
    if( _1 != _13907 ){
        DeRef(_1);
    }
    _13907 = NOVALUE;

    /** shift.e:146		op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13908 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 158LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13908;
    if( _1 != _13908 ){
        DeRef(_1);
    }
    _13908 = NOVALUE;

    /** shift.e:147		op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13909 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 110LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13909;
    if( _1 != _13909 ){
        DeRef(_1);
    }
    _13909 = NOVALUE;

    /** shift.e:148		op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13910 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 145LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13910;
    if( _1 != _13910 ){
        DeRef(_1);
    }
    _13910 = NOVALUE;

    /** shift.e:149		op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13911 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 148LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13911;
    if( _1 != _13911 ){
        DeRef(_1);
    }
    _13911 = NOVALUE;

    /** shift.e:150		op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13912 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 155LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13912;
    if( _1 != _13912 ){
        DeRef(_1);
    }
    _13912 = NOVALUE;

    /** shift.e:151		op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13913 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 156LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13913;
    if( _1 != _13913 ){
        DeRef(_1);
    }
    _13913 = NOVALUE;

    /** shift.e:153		op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13914 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 187LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13914;
    if( _1 != _13914 ){
        DeRef(_1);
    }
    _13914 = NOVALUE;

    /** shift.e:154		op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13915 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13915;
    if( _1 != _13915 ){
        DeRef(_1);
    }
    _13915 = NOVALUE;

    /** shift.e:155		op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13916 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13916;
    if( _1 != _13916 ){
        DeRef(_1);
    }
    _13916 = NOVALUE;

    /** shift.e:156		op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13917 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 105LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13917;
    if( _1 != _13917 ){
        DeRef(_1);
    }
    _13917 = NOVALUE;

    /** shift.e:157		op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13918 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 122LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13918;
    if( _1 != _13918 ){
        DeRef(_1);
    }
    _13918 = NOVALUE;

    /** shift.e:158		op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13919 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13919;
    if( _1 != _13919 ){
        DeRef(_1);
    }
    _13919 = NOVALUE;

    /** shift.e:159		op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13493);
    ((intptr_t*)_2)[3] = _13493;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13920 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 108LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13920;
    if( _1 != _13920 ){
        DeRef(_1);
    }
    _13920 = NOVALUE;

    /** shift.e:160		op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13921 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 37LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13921;
    if( _1 != _13921 ){
        DeRef(_1);
    }
    _13921 = NOVALUE;

    /** shift.e:161		op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13922 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 183LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13922;
    if( _1 != _13922 ){
        DeRef(_1);
    }
    _13922 = NOVALUE;

    /** shift.e:162		op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13923 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13923;
    if( _1 != _13923 ){
        DeRef(_1);
    }
    _13923 = NOVALUE;

    /** shift.e:163		op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13924 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13924;
    if( _1 != _13924 ){
        DeRef(_1);
    }
    _13924 = NOVALUE;

    /** shift.e:164		op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13925 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 165LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13925;
    if( _1 != _13925 ){
        DeRef(_1);
    }
    _13925 = NOVALUE;

    /** shift.e:165		op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13926 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 164LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13926;
    if( _1 != _13926 ){
        DeRef(_1);
    }
    _13926 = NOVALUE;

    /** shift.e:166		op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13927 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 163LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13927;
    if( _1 != _13927 ){
        DeRef(_1);
    }
    _13927 = NOVALUE;

    /** shift.e:167		op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13928 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 162LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13928;
    if( _1 != _13928 ){
        DeRef(_1);
    }
    _13928 = NOVALUE;

    /** shift.e:168		op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13929 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 182LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13929;
    if( _1 != _13929 ){
        DeRef(_1);
    }
    _13929 = NOVALUE;

    /** shift.e:169		op_info[PEEK8U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13930 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 214LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13930;
    if( _1 != _13930 ){
        DeRef(_1);
    }
    _13930 = NOVALUE;

    /** shift.e:170		op_info[PEEK8S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13931 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 213LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13931;
    if( _1 != _13931 ){
        DeRef(_1);
    }
    _13931 = NOVALUE;

    /** shift.e:171		op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13932 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 180LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13932;
    if( _1 != _13932 ){
        DeRef(_1);
    }
    _13932 = NOVALUE;

    /** shift.e:172		op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13933 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 179LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13933;
    if( _1 != _13933 ){
        DeRef(_1);
    }
    _13933 = NOVALUE;

    /** shift.e:173		op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13934 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 140LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13934;
    if( _1 != _13934 ){
        DeRef(_1);
    }
    _13934 = NOVALUE;

    /** shift.e:174		op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13935 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 139LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13935;
    if( _1 != _13935 ){
        DeRef(_1);
    }
    _13935 = NOVALUE;

    /** shift.e:175		op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13936 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 181LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13936;
    if( _1 != _13936 ){
        DeRef(_1);
    }
    _13936 = NOVALUE;

    /** shift.e:176		op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13937 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 127LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13937;
    if( _1 != _13937 ){
        DeRef(_1);
    }
    _13937 = NOVALUE;

    /** shift.e:177		op_info[SIZEOF              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13938 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 217LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13938;
    if( _1 != _13938 ){
        DeRef(_1);
    }
    _13938 = NOVALUE;

    /** shift.e:178		op_info[PEEK_POINTER        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13939 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 216LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13939;
    if( _1 != _13939 ){
        DeRef(_1);
    }
    _13939 = NOVALUE;

    /** shift.e:179		op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13940 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 160LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13940;
    if( _1 != _13940 ){
        DeRef(_1);
    }
    _13940 = NOVALUE;

    /** shift.e:180		op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13941 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13941;
    if( _1 != _13941 ){
        DeRef(_1);
    }
    _13941 = NOVALUE;

    /** shift.e:181		op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13942 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 115LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13942;
    if( _1 != _13942 ){
        DeRef(_1);
    }
    _13942 = NOVALUE;

    /** shift.e:182		op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13943 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 93LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13943;
    if( _1 != _13943 ){
        DeRef(_1);
    }
    _13943 = NOVALUE;

    /** shift.e:183		op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13944 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 117LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13944;
    if( _1 != _13944 ){
        DeRef(_1);
    }
    _13944 = NOVALUE;

    /** shift.e:184		op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13945 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 128LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13945;
    if( _1 != _13945 ){
        DeRef(_1);
    }
    _13945 = NOVALUE;

    /** shift.e:185		op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13946 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 178LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13946;
    if( _1 != _13946 ){
        DeRef(_1);
    }
    _13946 = NOVALUE;

    /** shift.e:186		op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13947 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 138LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13947;
    if( _1 != _13947 ){
        DeRef(_1);
    }
    _13947 = NOVALUE;

    /** shift.e:187		op_info[POKE8               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13948 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 212LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13948;
    if( _1 != _13948 ){
        DeRef(_1);
    }
    _13948 = NOVALUE;

    /** shift.e:188		op_info[POKE_POINTER        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13949 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 215LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13949;
    if( _1 != _13949 ){
        DeRef(_1);
    }
    _13949 = NOVALUE;

    /** shift.e:189		op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13950 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 60LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13950;
    if( _1 != _13950 ){
        DeRef(_1);
    }
    _13950 = NOVALUE;

    /** shift.e:190		op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13951 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 72LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13951;
    if( _1 != _13951 ){
        DeRef(_1);
    }
    _13951 = NOVALUE;

    /** shift.e:191		op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13952 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 57LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13952;
    if( _1 != _13952 ){
        DeRef(_1);
    }
    _13952 = NOVALUE;

    /** shift.e:192		op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13953 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 19LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13953;
    if( _1 != _13953 ){
        DeRef(_1);
    }
    _13953 = NOVALUE;

    /** shift.e:193		op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13954 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13954;
    if( _1 != _13954 ){
        DeRef(_1);
    }
    _13954 = NOVALUE;

    /** shift.e:194		op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13955 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 151LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13955;
    if( _1 != _13955 ){
        DeRef(_1);
    }
    _13955 = NOVALUE;

    /** shift.e:195		op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13956 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 87LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13956;
    if( _1 != _13956 ){
        DeRef(_1);
    }
    _13956 = NOVALUE;

    /** shift.e:196		op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13957 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 88LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13957;
    if( _1 != _13957 ){
        DeRef(_1);
    }
    _13957 = NOVALUE;

    /** shift.e:197		op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13958 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 90LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13958;
    if( _1 != _13958 ){
        DeRef(_1);
    }
    _13958 = NOVALUE;

    /** shift.e:198		op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13959 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13959;
    if( _1 != _13959 ){
        DeRef(_1);
    }
    _13959 = NOVALUE;

    /** shift.e:199		op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13960 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13960;
    if( _1 != _13960 ){
        DeRef(_1);
    }
    _13960 = NOVALUE;

    /** shift.e:200		op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13961 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 62LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13961;
    if( _1 != _13961 ){
        DeRef(_1);
    }
    _13961 = NOVALUE;

    /** shift.e:201		op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13962 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 71LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13962;
    if( _1 != _13962 ){
        DeRef(_1);
    }
    _13962 = NOVALUE;

    /** shift.e:202		op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13963 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 200LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13963;
    if( _1 != _13963 ){
        DeRef(_1);
    }
    _13963 = NOVALUE;

    /** shift.e:203		op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13964 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13964;
    if( _1 != _13964 ){
        DeRef(_1);
    }
    _13964 = NOVALUE;

    /** shift.e:204		op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 6LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13965);
    ((intptr_t*)_2)[4] = _13965;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13966 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 201LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13966;
    if( _1 != _13966 ){
        DeRef(_1);
    }
    _13966 = NOVALUE;

    /** shift.e:205		op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13967 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 28LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13967;
    if( _1 != _13967 ){
        DeRef(_1);
    }
    _13967 = NOVALUE;

    /** shift.e:206		op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13968 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13968;
    if( _1 != _13968 ){
        DeRef(_1);
    }
    _13968 = NOVALUE;

    /** shift.e:207		op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13969 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13969;
    if( _1 != _13969 ){
        DeRef(_1);
    }
    _13969 = NOVALUE;

    /** shift.e:208		op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13970 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13970;
    if( _1 != _13970 ){
        DeRef(_1);
    }
    _13970 = NOVALUE;

    /** shift.e:209		op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13971 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 25LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13971;
    if( _1 != _13971 ){
        DeRef(_1);
    }
    _13971 = NOVALUE;

    /** shift.e:210		op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13972 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 114LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13972;
    if( _1 != _13972 ){
        DeRef(_1);
    }
    _13972 = NOVALUE;

    /** shift.e:211		op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13973 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 92LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13973;
    if( _1 != _13973 ){
        DeRef(_1);
    }
    _13973 = NOVALUE;

    /** shift.e:212		op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13974 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 85LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13974;
    if( _1 != _13974 ){
        DeRef(_1);
    }
    _13974 = NOVALUE;

    /** shift.e:214		op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _13975 = 6LL - _36TRANSLATE_21361;
    _13976 = (_36TRANSLATE_21361 == 0);
    _13977 = 4LL + _13976;
    if ((object)((uintptr_t)_13977 + (uintptr_t)HIGH_BITS) >= 0){
        _13977 = NewDouble((eudouble)_13977);
    }
    _13976 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13977;
    _13978 = MAKE_SEQ(_1);
    _13977 = NOVALUE;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _13975;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _13978;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13979 = MAKE_SEQ(_1);
    _13978 = NOVALUE;
    _13975 = NOVALUE;
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 134LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13979;
    if( _1 != _13979 ){
        DeRef(_1);
    }
    _13979 = NOVALUE;

    /** shift.e:215		op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13980 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 144LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13980;
    if( _1 != _13980 ){
        DeRef(_1);
    }
    _13980 = NOVALUE;

    /** shift.e:216		op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13981 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 142LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13981;
    if( _1 != _13981 ){
        DeRef(_1);
    }
    _13981 = NOVALUE;

    /** shift.e:217		op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13982 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 80LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13982;
    if( _1 != _13982 ){
        DeRef(_1);
    }
    _13982 = NOVALUE;

    /** shift.e:218		op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13983 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 75LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13983;
    if( _1 != _13983 ){
        DeRef(_1);
    }
    _13983 = NOVALUE;

    /** shift.e:219		op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13653);
    ((intptr_t*)_2)[4] = _13653;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13984 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 190LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13984;
    if( _1 != _13984 ){
        DeRef(_1);
    }
    _13984 = NOVALUE;

    /** shift.e:220		op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13985 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13985;
    if( _1 != _13985 ){
        DeRef(_1);
    }
    _13985 = NOVALUE;

    /** shift.e:221		op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13986 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13986;
    if( _1 != _13986 ){
        DeRef(_1);
    }
    _13986 = NOVALUE;

    /** shift.e:222		op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13987 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 58LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13987;
    if( _1 != _13987 ){
        DeRef(_1);
    }
    _13987 = NOVALUE;

    /** shift.e:223		op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13653);
    ((intptr_t*)_2)[3] = _13653;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13988 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 185LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13988;
    if( _1 != _13988 ){
        DeRef(_1);
    }
    _13988 = NOVALUE;

    /** shift.e:224		op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13653);
    ((intptr_t*)_2)[3] = _13653;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13989 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 193LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13989;
    if( _1 != _13989 ){
        DeRef(_1);
    }
    _13989 = NOVALUE;

    /** shift.e:225		op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13653);
    ((intptr_t*)_2)[3] = _13653;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13990 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 192LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13990;
    if( _1 != _13990 ){
        DeRef(_1);
    }
    _13990 = NOVALUE;

    /** shift.e:226		op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 5LL;
    RefDS(_13653);
    ((intptr_t*)_2)[3] = _13653;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13991 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 202LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13991;
    if( _1 != _13991 ){
        DeRef(_1);
    }
    _13991 = NOVALUE;

    /** shift.e:227		op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13992 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 99LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13992;
    if( _1 != _13992 ){
        DeRef(_1);
    }
    _13992 = NOVALUE;

    /** shift.e:228		op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13993 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 154LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13993;
    if( _1 != _13993 ){
        DeRef(_1);
    }
    _13993 = NOVALUE;

    /** shift.e:229		op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13994 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 199LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13994;
    if( _1 != _13994 ){
        DeRef(_1);
    }
    _13994 = NOVALUE;

    /** shift.e:230		op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13995 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 82LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13995;
    if( _1 != _13995 ){
        DeRef(_1);
    }
    _13995 = NOVALUE;

    /** shift.e:231		op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13996 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 175LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13996;
    if( _1 != _13996 ){
        DeRef(_1);
    }
    _13996 = NOVALUE;

    /** shift.e:232		op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _13997 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 174LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13997;
    if( _1 != _13997 ){
        DeRef(_1);
    }
    _13997 = NOVALUE;

    /** shift.e:233		op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13998 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 167LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13998;
    if( _1 != _13998 ){
        DeRef(_1);
    }
    _13998 = NOVALUE;

    /** shift.e:234		op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _13999 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 172LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13999;
    if( _1 != _13999 ){
        DeRef(_1);
    }
    _13999 = NOVALUE;

    /** shift.e:235		op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14000 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 168LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14000;
    if( _1 != _14000 ){
        DeRef(_1);
    }
    _14000 = NOVALUE;

    /** shift.e:236		op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14001 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 170LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14001;
    if( _1 != _14001 ){
        DeRef(_1);
    }
    _14001 = NOVALUE;

    /** shift.e:237		op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14002 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 173LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14002;
    if( _1 != _14002 ){
        DeRef(_1);
    }
    _14002 = NOVALUE;

    /** shift.e:238		op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14003 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 171LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14003;
    if( _1 != _14003 ){
        DeRef(_1);
    }
    _14003 = NOVALUE;

    /** shift.e:239		op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14004 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 169LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14004;
    if( _1 != _14004 ){
        DeRef(_1);
    }
    _14004 = NOVALUE;

    /** shift.e:240		op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13819);
    ((intptr_t*)_2)[4] = _13819;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14005 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 70LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14005;
    if( _1 != _14005 ){
        DeRef(_1);
    }
    _14005 = NOVALUE;

    /** shift.e:241		op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14006 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 64LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14006;
    if( _1 != _14006 ){
        DeRef(_1);
    }
    _14006 = NOVALUE;

    /** shift.e:242		op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14007 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 65LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14007;
    if( _1 != _14007 ){
        DeRef(_1);
    }
    _14007 = NOVALUE;

    /** shift.e:243		op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14008 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14008;
    if( _1 != _14008 ){
        DeRef(_1);
    }
    _14008 = NOVALUE;

    /** shift.e:244		op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14009 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 89LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14009;
    if( _1 != _14009 ){
        DeRef(_1);
    }
    _14009 = NOVALUE;

    /** shift.e:245		op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_13493);
    ((intptr_t*)_2)[3] = _13493;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14010 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14010;
    if( _1 != _14010 ){
        DeRef(_1);
    }
    _14010 = NOVALUE;

    /** shift.e:246		op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14011 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 152LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14011;
    if( _1 != _14011 ){
        DeRef(_1);
    }
    _14011 = NOVALUE;

    /** shift.e:247		op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13430);
    ((intptr_t*)_2)[4] = _13430;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14012 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14012;
    if( _1 != _14012 ){
        DeRef(_1);
    }
    _14012 = NOVALUE;

    /** shift.e:249		op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14013 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 197LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14013;
    if( _1 != _14013 ){
        DeRef(_1);
    }
    _14013 = NOVALUE;

    /** shift.e:251		sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_24982;
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 4LL;
    RefDS(_13430);
    ((intptr_t*)_2)[3] = _13430;
    RefDSn(_5, 2);
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _SHORT_CIRCUIT_24982 = MAKE_SEQ(_1);
    DeRef(_0);

    /** shift.e:252		op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24982);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 146LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24982;
    DeRef(_1);

    /** shift.e:253		op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24982);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 147LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24982;
    DeRef(_1);

    /** shift.e:254		op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24982);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 141LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24982;
    DeRef(_1);

    /** shift.e:255		op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_24982);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 143LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _SHORT_CIRCUIT_24982;
    DeRef(_1);

    /** shift.e:257		op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14015 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 101LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14015;
    if( _1 != _14015 ){
        DeRef(_1);
    }
    _14015 = NOVALUE;

    /** shift.e:258		op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14016 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 96LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14016;
    if( _1 != _14016 ){
        DeRef(_1);
    }
    _14016 = NOVALUE;

    /** shift.e:259		op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14017 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 97LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14017;
    if( _1 != _14017 ){
        DeRef(_1);
    }
    _14017 = NOVALUE;

    /** shift.e:261		op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14018 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 94LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14018;
    if( _1 != _14018 ){
        DeRef(_1);
    }
    _14018 = NOVALUE;

    /** shift.e:262		op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14019 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 67LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14019;
    if( _1 != _14019 ){
        DeRef(_1);
    }
    _14019 = NOVALUE;

    /** shift.e:263		op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14020 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 68LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14020;
    if( _1 != _14020 ){
        DeRef(_1);
    }
    _14020 = NOVALUE;

    /** shift.e:264		op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    RefDS(_13493);
    ((intptr_t*)_2)[4] = _13493;
    RefDS(_5);
    ((intptr_t*)_2)[5] = _5;
    _14021 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14021;
    if( _1 != _14021 ){
        DeRef(_1);
    }
    _14021 = NOVALUE;

    /** shift.e:266		op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14022 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 135LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14022;
    if( _1 != _14022 ){
        DeRef(_1);
    }
    _14022 = NOVALUE;

    /** shift.e:268		op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14023 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 207LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14023;
    if( _1 != _14023 ){
        DeRef(_1);
    }
    _14023 = NOVALUE;

    /** shift.e:269		op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14024 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 208LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14024;
    if( _1 != _14024 ){
        DeRef(_1);
    }
    _14024 = NOVALUE;

    /** shift.e:270		op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 2LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14025 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 209LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14025;
    if( _1 != _14025 ){
        DeRef(_1);
    }
    _14025 = NOVALUE;

    /** shift.e:272		op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14026 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 195LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14026;
    if( _1 != _14026 ){
        DeRef(_1);
    }
    _14026 = NOVALUE;

    /** shift.e:273		op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14027 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 196LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14027;
    if( _1 != _14027 ){
        DeRef(_1);
    }
    _14027 = NOVALUE;

    /** shift.e:275		op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 3LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14028 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14028;
    if( _1 != _14028 ){
        DeRef(_1);
    }
    _14028 = NOVALUE;

    /** shift.e:276		op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14029 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 157LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14029;
    if( _1 != _14029 ){
        DeRef(_1);
    }
    _14029 = NOVALUE;

    /** shift.e:277		op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 2LL;
    ((intptr_t*)_2)[2] = 0LL;
    RefDSn(_5, 3);
    ((intptr_t*)_2)[3] = _5;
    ((intptr_t*)_2)[4] = _5;
    ((intptr_t*)_2)[5] = _5;
    _14030 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 27LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14030;
    if( _1 != _14030 ){
        DeRef(_1);
    }
    _14030 = NOVALUE;

    /** shift.e:278		op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (object)SEQ_PTR(_66op_info_24555);
    _14031 = (object)*(((s1_ptr)_2)->base + 27LL);
    Ref(_14031);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _66op_info_24555 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 203LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14031;
    if( _1 != _14031 ){
        DeRef(_1);
    }
    _14031 = NOVALUE;

    /** shift.e:281		for i = 1 to MAX_OPCODE do*/
    _14032 = 218LL;
    {
        object _i_25024;
        _i_25024 = 1LL;
L1: 
        if (_i_25024 > 218LL){
            goto L2; // [3959] 4052
        }

        /** shift.e:282			object info = op_info[i]*/
        DeRef(_info_25027);
        _2 = (object)SEQ_PTR(_66op_info_24555);
        _info_25027 = (object)*(((s1_ptr)_2)->base + _i_25024);
        Ref(_info_25027);

        /** shift.e:283			if sequence( info ) then*/
        _14034 = IS_SEQUENCE(_info_25027);
        if (_14034 == 0)
        {
            _14034 = NOVALUE;
            goto L3; // [3979] 4043
        }
        else{
            _14034 = NOVALUE;
        }

        /** shift.e:284				op_info_size_type[i] = info[OP_SIZE_TYPE]*/
        _2 = (object)SEQ_PTR(_info_25027);
        _14035 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_14035);
        _2 = (object)SEQ_PTR(_66op_info_size_type_24561);
        _2 = (object)(((s1_ptr)_2)->base + _i_25024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14035;
        if( _1 != _14035 ){
            DeRef(_1);
        }
        _14035 = NOVALUE;

        /** shift.e:285				op_info_size[i] = info[OP_SIZE]*/
        _2 = (object)SEQ_PTR(_info_25027);
        _14036 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_14036);
        _2 = (object)SEQ_PTR(_66op_info_size_24562);
        _2 = (object)(((s1_ptr)_2)->base + _i_25024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14036;
        if( _1 != _14036 ){
            DeRef(_1);
        }
        _14036 = NOVALUE;

        /** shift.e:286				op_info_addr[i] = info[OP_ADDR]*/
        _2 = (object)SEQ_PTR(_info_25027);
        _14037 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_14037);
        _2 = (object)SEQ_PTR(_66op_info_addr_24563);
        _2 = (object)(((s1_ptr)_2)->base + _i_25024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14037;
        if( _1 != _14037 ){
            DeRef(_1);
        }
        _14037 = NOVALUE;

        /** shift.e:287				op_info_target[i] = info[OP_TARGET]*/
        _2 = (object)SEQ_PTR(_info_25027);
        _14038 = (object)*(((s1_ptr)_2)->base + 4LL);
        Ref(_14038);
        _2 = (object)SEQ_PTR(_66op_info_target_24564);
        _2 = (object)(((s1_ptr)_2)->base + _i_25024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14038;
        if( _1 != _14038 ){
            DeRef(_1);
        }
        _14038 = NOVALUE;

        /** shift.e:288				op_info_sub[i] = info[OP_SUB]*/
        _2 = (object)SEQ_PTR(_info_25027);
        _14039 = (object)*(((s1_ptr)_2)->base + 5LL);
        Ref(_14039);
        _2 = (object)SEQ_PTR(_66op_info_sub_24565);
        _2 = (object)(((s1_ptr)_2)->base + _i_25024);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14039;
        if( _1 != _14039 ){
            DeRef(_1);
        }
        _14039 = NOVALUE;
L3: 
        DeRef(_info_25027);
        _info_25027 = NOVALUE;

        /** shift.e:290		end for*/
        _i_25024 = _i_25024 + 1LL;
        goto L1; // [4047] 3966
L2: 
        ;
    }

    /** shift.e:291	end procedure*/
    DeRef(_SHORT_CIRCUIT_24982);
    return;
    ;
}


object _66variable_op_size(object _pc_25038, object _op_25039, object _code_25040)
{
    object _int_25043 = NOVALUE;
    object _info_25049 = NOVALUE;
    object _14059 = NOVALUE;
    object _14056 = NOVALUE;
    object _14053 = NOVALUE;
    object _14050 = NOVALUE;
    object _14049 = NOVALUE;
    object _14048 = NOVALUE;
    object _14047 = NOVALUE;
    object _14046 = NOVALUE;
    object _14045 = NOVALUE;
    object _14043 = NOVALUE;
    object _14042 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:297		switch op do*/
    _0 = _op_25039;
    switch ( _0 ){ 

        /** shift.e:298			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:299				sequence info = SymTab[code[pc+1]]*/
        _14042 = _pc_25038 + 1;
        _2 = (object)SEQ_PTR(_code_25040);
        _14043 = (object)*(((s1_ptr)_2)->base + _14042);
        DeRef(_info_25049);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_14043)){
            _info_25049 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14043)->dbl));
        }
        else{
            _info_25049 = (object)*(((s1_ptr)_2)->base + _14043);
        }
        Ref(_info_25049);

        /** shift.e:300				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (object)SEQ_PTR(_info_25049);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
            _14045 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
        }
        else{
            _14045 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
        }
        if (IS_ATOM_INT(_14045)) {
            _14046 = _14045 + 2LL;
            if ((object)((uintptr_t)_14046 + (uintptr_t)HIGH_BITS) >= 0){
                _14046 = NewDouble((eudouble)_14046);
            }
        }
        else {
            _14046 = binary_op(PLUS, _14045, 2LL);
        }
        _14045 = NOVALUE;
        _2 = (object)SEQ_PTR(_info_25049);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _14047 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _14047 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        if (IS_ATOM_INT(_14047)) {
            _14048 = (_14047 != 27LL);
        }
        else {
            _14048 = binary_op(NOTEQ, _14047, 27LL);
        }
        _14047 = NOVALUE;
        if (IS_ATOM_INT(_14046) && IS_ATOM_INT(_14048)) {
            _14049 = _14046 + _14048;
            if ((object)((uintptr_t)_14049 + (uintptr_t)HIGH_BITS) >= 0){
                _14049 = NewDouble((eudouble)_14049);
            }
        }
        else {
            _14049 = binary_op(PLUS, _14046, _14048);
        }
        DeRef(_14046);
        _14046 = NOVALUE;
        DeRef(_14048);
        _14048 = NOVALUE;
        DeRefDS(_info_25049);
        DeRefDS(_code_25040);
        _14042 = NOVALUE;
        _14043 = NOVALUE;
        return _14049;
        goto L1; // [72] 157

        /** shift.e:302			case PROC_FORWARD then*/
        case 195:

        /** shift.e:303				int = code[pc+2]*/
        _14050 = _pc_25038 + 2LL;
        _2 = (object)SEQ_PTR(_code_25040);
        _int_25043 = (object)*(((s1_ptr)_2)->base + _14050);
        if (!IS_ATOM_INT(_int_25043))
        _int_25043 = (object)DBL_PTR(_int_25043)->dbl;

        /** shift.e:304				int += 3*/
        _int_25043 = _int_25043 + 3LL;
        goto L1; // [94] 157

        /** shift.e:305			case FUNC_FORWARD then*/
        case 196:

        /** shift.e:306				int = code[pc+2]*/
        _14053 = _pc_25038 + 2LL;
        _2 = (object)SEQ_PTR(_code_25040);
        _int_25043 = (object)*(((s1_ptr)_2)->base + _14053);
        if (!IS_ATOM_INT(_int_25043))
        _int_25043 = (object)DBL_PTR(_int_25043)->dbl;

        /** shift.e:307				int += 4*/
        _int_25043 = _int_25043 + 4LL;
        goto L1; // [116] 157

        /** shift.e:308			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:309				int = code[pc+1]*/
        _14056 = _pc_25038 + 1;
        _2 = (object)SEQ_PTR(_code_25040);
        _int_25043 = (object)*(((s1_ptr)_2)->base + _14056);
        if (!IS_ATOM_INT(_int_25043))
        _int_25043 = (object)DBL_PTR(_int_25043)->dbl;

        /** shift.e:310				int += 3*/
        _int_25043 = _int_25043 + 3LL;
        goto L1; // [140] 157

        /** shift.e:311			case else*/
        default:

        /** shift.e:312				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _op_25039;
        _14059 = MAKE_SEQ(_1);
        _50InternalErr(269LL, _14059);
        _14059 = NOVALUE;
    ;}L1: 

    /** shift.e:314		return int*/
    DeRefDS(_code_25040);
    DeRef(_14056);
    _14056 = NOVALUE;
    DeRef(_14050);
    _14050 = NOVALUE;
    DeRef(_14042);
    _14042 = NOVALUE;
    DeRef(_14053);
    _14053 = NOVALUE;
    _14043 = NOVALUE;
    DeRef(_14049);
    _14049 = NOVALUE;
    return _int_25043;
    ;
}


object _66op_size(object _pc_25083, object _code_25084)
{
    object _op_25087 = NOVALUE;
    object _int_25089 = NOVALUE;
    object _14064 = NOVALUE;
    object _14063 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:318		integer op = code[pc]*/
    _2 = (object)SEQ_PTR(_code_25084);
    _op_25087 = (object)*(((s1_ptr)_2)->base + _pc_25083);
    if (!IS_ATOM_INT(_op_25087))
    _op_25087 = (object)DBL_PTR(_op_25087)->dbl;

    /** shift.e:319		integer int = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_type_24561);
    _int_25089 = (object)*(((s1_ptr)_2)->base + _op_25087);
    if (!IS_ATOM_INT(_int_25089))
    _int_25089 = (object)DBL_PTR(_int_25089)->dbl;

    /** shift.e:321		if int = FIXED_SIZE then*/
    if (_int_25089 != 1LL)
    goto L1; // [21] 40

    /** shift.e:322			return op_info_size[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_24562);
    _14063 = (object)*(((s1_ptr)_2)->base + _op_25087);
    Ref(_14063);
    DeRefDS(_code_25084);
    return _14063;
    goto L2; // [37] 53
L1: 

    /** shift.e:324			return variable_op_size( pc, op, code )*/
    RefDS(_code_25084);
    _14064 = _66variable_op_size(_pc_25083, _op_25087, _code_25084);
    DeRefDS(_code_25084);
    _14063 = NOVALUE;
    return _14064;
L2: 
    ;
}


object _66advance(object _pc_25098, object _code_25099)
{
    object _size_25102 = NOVALUE;
    object _14066 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:329		integer size = op_size( pc, code )*/
    RefDS(_code_25099);
    _size_25102 = _66op_size(_pc_25098, _code_25099);
    if (!IS_ATOM_INT(_size_25102)) {
        _1 = (object)(DBL_PTR(_size_25102)->dbl);
        DeRefDS(_size_25102);
        _size_25102 = _1;
    }

    /** shift.e:330		return pc + size*/
    _14066 = _pc_25098 + _size_25102;
    if ((object)((uintptr_t)_14066 + (uintptr_t)HIGH_BITS) >= 0){
        _14066 = NewDouble((eudouble)_14066);
    }
    DeRefDS(_code_25099);
    return _14066;
    ;
}


void _66shift_switch(object _pc_25107, object _start_25108, object _amount_25109)
{
    object _addr_25110 = NOVALUE;
    object _jump_25142 = NOVALUE;
    object _14101 = NOVALUE;
    object _14100 = NOVALUE;
    object _14099 = NOVALUE;
    object _14098 = NOVALUE;
    object _14097 = NOVALUE;
    object _14096 = NOVALUE;
    object _14095 = NOVALUE;
    object _14094 = NOVALUE;
    object _14093 = NOVALUE;
    object _14092 = NOVALUE;
    object _14091 = NOVALUE;
    object _14089 = NOVALUE;
    object _14088 = NOVALUE;
    object _14087 = NOVALUE;
    object _14086 = NOVALUE;
    object _14085 = NOVALUE;
    object _14084 = NOVALUE;
    object _14083 = NOVALUE;
    object _14082 = NOVALUE;
    object _14080 = NOVALUE;
    object _14079 = NOVALUE;
    object _14078 = NOVALUE;
    object _14077 = NOVALUE;
    object _14076 = NOVALUE;
    object _14073 = NOVALUE;
    object _14071 = NOVALUE;
    object _14070 = NOVALUE;
    object _14069 = NOVALUE;
    object _14068 = NOVALUE;
    object _14067 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** shift.e:336		if sequence( Code[pc+4] ) then*/
    _14067 = _pc_25107 + 4LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14068 = (object)*(((s1_ptr)_2)->base + _14067);
    _14069 = IS_SEQUENCE(_14068);
    _14068 = NOVALUE;
    if (_14069 == 0)
    {
        _14069 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _14069 = NOVALUE;
    }

    /** shift.e:337			addr = Code[pc+4][2]*/
    _14070 = _pc_25107 + 4LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14071 = (object)*(((s1_ptr)_2)->base + _14070);
    _2 = (object)SEQ_PTR(_14071);
    _addr_25110 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_addr_25110)){
        _addr_25110 = (object)DBL_PTR(_addr_25110)->dbl;
    }
    _14071 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** shift.e:339			addr = Code[pc+4]*/
    _14073 = _pc_25107 + 4LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _addr_25110 = (object)*(((s1_ptr)_2)->base + _14073);
    if (!IS_ATOM_INT(_addr_25110)){
        _addr_25110 = (object)DBL_PTR(_addr_25110)->dbl;
    }
L2: 

    /** shift.e:343		if start < addr then*/
    if (_start_25108 >= _addr_25110)
    goto L3; // [65] 137

    /** shift.e:344			if sequence( Code[pc+4] ) then*/
    _14076 = _pc_25107 + 4LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14077 = (object)*(((s1_ptr)_2)->base + _14076);
    _14078 = IS_SEQUENCE(_14077);
    _14077 = NOVALUE;
    if (_14078 == 0)
    {
        _14078 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _14078 = NOVALUE;
    }

    /** shift.e:345				Code[pc+4][2] += amount*/
    _14079 = _pc_25107 + 4LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14079 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _14082 = (object)*(((s1_ptr)_2)->base + 2LL);
    _14080 = NOVALUE;
    if (IS_ATOM_INT(_14082)) {
        _14083 = _14082 + _amount_25109;
        if ((object)((uintptr_t)_14083 + (uintptr_t)HIGH_BITS) >= 0){
            _14083 = NewDouble((eudouble)_14083);
        }
    }
    else {
        _14083 = binary_op(PLUS, _14082, _amount_25109);
    }
    _14082 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14083;
    if( _1 != _14083 ){
        DeRef(_1);
    }
    _14083 = NOVALUE;
    _14080 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** shift.e:347				Code[pc+4] += amount*/
    _14084 = _pc_25107 + 4LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14085 = (object)*(((s1_ptr)_2)->base + _14084);
    if (IS_ATOM_INT(_14085)) {
        _14086 = _14085 + _amount_25109;
        if ((object)((uintptr_t)_14086 + (uintptr_t)HIGH_BITS) >= 0){
            _14086 = NewDouble((eudouble)_14086);
        }
    }
    else {
        _14086 = binary_op(PLUS, _14085, _amount_25109);
    }
    _14085 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14084);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14086;
    if( _1 != _14086 ){
        DeRef(_1);
    }
    _14086 = NOVALUE;
L5: 
L3: 

    /** shift.e:351		sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _14087 = _pc_25107 + 3LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14088 = (object)*(((s1_ptr)_2)->base + _14087);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_14088)){
        _14089 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14088)->dbl));
    }
    else{
        _14089 = (object)*(((s1_ptr)_2)->base + _14088);
    }
    DeRef(_jump_25142);
    _2 = (object)SEQ_PTR(_14089);
    _jump_25142 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_jump_25142);
    _14089 = NOVALUE;

    /** shift.e:352		for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_25142)){
            _14091 = SEQ_PTR(_jump_25142)->length;
    }
    else {
        _14091 = 1;
    }
    {
        object _i_25151;
        _i_25151 = 1LL;
L6: 
        if (_i_25151 > _14091){
            goto L7; // [168] 223
        }

        /** shift.e:353			if start > pc and start < pc + jump[i] then*/
        _14092 = (_start_25108 > _pc_25107);
        if (_14092 == 0) {
            goto L8; // [181] 216
        }
        _2 = (object)SEQ_PTR(_jump_25142);
        _14094 = (object)*(((s1_ptr)_2)->base + _i_25151);
        if (IS_ATOM_INT(_14094)) {
            _14095 = _pc_25107 + _14094;
            if ((object)((uintptr_t)_14095 + (uintptr_t)HIGH_BITS) >= 0){
                _14095 = NewDouble((eudouble)_14095);
            }
        }
        else {
            _14095 = binary_op(PLUS, _pc_25107, _14094);
        }
        _14094 = NOVALUE;
        if (IS_ATOM_INT(_14095)) {
            _14096 = (_start_25108 < _14095);
        }
        else {
            _14096 = binary_op(LESS, _start_25108, _14095);
        }
        DeRef(_14095);
        _14095 = NOVALUE;
        if (_14096 == 0) {
            DeRef(_14096);
            _14096 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_14096) && DBL_PTR(_14096)->dbl == 0.0){
                DeRef(_14096);
                _14096 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_14096);
            _14096 = NOVALUE;
        }
        DeRef(_14096);
        _14096 = NOVALUE;

        /** shift.e:354				jump[i] += amount*/
        _2 = (object)SEQ_PTR(_jump_25142);
        _14097 = (object)*(((s1_ptr)_2)->base + _i_25151);
        if (IS_ATOM_INT(_14097)) {
            _14098 = _14097 + _amount_25109;
            if ((object)((uintptr_t)_14098 + (uintptr_t)HIGH_BITS) >= 0){
                _14098 = NewDouble((eudouble)_14098);
            }
        }
        else {
            _14098 = binary_op(PLUS, _14097, _amount_25109);
        }
        _14097 = NOVALUE;
        _2 = (object)SEQ_PTR(_jump_25142);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _jump_25142 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_25151);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14098;
        if( _1 != _14098 ){
            DeRef(_1);
        }
        _14098 = NOVALUE;
L8: 

        /** shift.e:356		end for*/
        _i_25151 = _i_25151 + 1LL;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** shift.e:357		SymTab[Code[pc+3]][S_OBJ] = jump*/
    _14099 = _pc_25107 + 3LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14100 = (object)*(((s1_ptr)_2)->base + _14099);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14100))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14100)->dbl));
    else
    _3 = (object)(_14100 + ((s1_ptr)_2)->base);
    RefDS(_jump_25142);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_25142;
    DeRef(_1);
    _14101 = NOVALUE;

    /** shift.e:358	end procedure*/
    DeRefDS(_jump_25142);
    _14099 = NOVALUE;
    DeRef(_14073);
    _14073 = NOVALUE;
    DeRef(_14079);
    _14079 = NOVALUE;
    DeRef(_14076);
    _14076 = NOVALUE;
    DeRef(_14070);
    _14070 = NOVALUE;
    DeRef(_14084);
    _14084 = NOVALUE;
    DeRef(_14087);
    _14087 = NOVALUE;
    DeRef(_14092);
    _14092 = NOVALUE;
    DeRef(_14067);
    _14067 = NOVALUE;
    _14088 = NOVALUE;
    _14100 = NOVALUE;
    return;
    ;
}


void _66shift_addr(object _pc_25170, object _amount_25171, object _start_25172, object _bound_25173)
{
    object _int_25174 = NOVALUE;
    object _14116 = NOVALUE;
    object _14113 = NOVALUE;
    object _14109 = NOVALUE;
    object _14104 = NOVALUE;
    object _14103 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_25170)) {
        _1 = (object)(DBL_PTR(_pc_25170)->dbl);
        DeRefDS(_pc_25170);
        _pc_25170 = _1;
    }

    /** shift.e:362		if atom( Code[pc] ) then*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14103 = (object)*(((s1_ptr)_2)->base + _pc_25170);
    _14104 = IS_ATOM(_14103);
    _14103 = NOVALUE;
    if (_14104 == 0)
    {
        _14104 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _14104 = NOVALUE;
    }

    /** shift.e:363			int = Code[pc]*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    _int_25174 = (object)*(((s1_ptr)_2)->base + _pc_25170);
    if (!IS_ATOM_INT(_int_25174)){
        _int_25174 = (object)DBL_PTR(_int_25174)->dbl;
    }

    /** shift.e:364			if int >= start then*/
    if (_int_25174 < _start_25172)
    goto L2; // [35] 139

    /** shift.e:365				if int < bound then*/
    if (_int_25174 >= _bound_25173)
    goto L3; // [41] 56

    /** shift.e:366					Code[pc] = start*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_25170);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_25172;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** shift.e:368					int += amount*/
    _int_25174 = _int_25174 + _amount_25171;

    /** shift.e:369					Code[pc] = int*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_25170);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_25174;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** shift.e:373			int = Code[pc][2]*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    _14109 = (object)*(((s1_ptr)_2)->base + _pc_25170);
    _2 = (object)SEQ_PTR(_14109);
    _int_25174 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_25174)){
        _int_25174 = (object)DBL_PTR(_int_25174)->dbl;
    }
    _14109 = NOVALUE;

    /** shift.e:374			if int >= start then*/
    if (_int_25174 < _start_25172)
    goto L4; // [91] 138

    /** shift.e:375				if int < bound then*/
    if (_int_25174 >= _bound_25173)
    goto L5; // [97] 117

    /** shift.e:376					Code[pc][2] = start*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_25170 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_25172;
    DeRef(_1);
    _14113 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** shift.e:378					int += amount*/
    _int_25174 = _int_25174 + _amount_25171;

    /** shift.e:379					Code[pc][2] = int*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pc_25170 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_25174;
    DeRef(_1);
    _14116 = NOVALUE;
L6: 
L4: 
L2: 

    /** shift.e:383	end procedure*/
    return;
    ;
}


void _66shift(object _start_25207, object _amount_25208, object _bound_25209)
{
    object _int_25212 = NOVALUE;
    object _pc_25225 = NOVALUE;
    object _op_25226 = NOVALUE;
    object _finish_25227 = NOVALUE;
    object _len_25230 = NOVALUE;
    object _size_type_25255 = NOVALUE;
    object _14143 = NOVALUE;
    object _14141 = NOVALUE;
    object _14138 = NOVALUE;
    object _14136 = NOVALUE;
    object _14133 = NOVALUE;
    object _14132 = NOVALUE;
    object _14131 = NOVALUE;
    object _14129 = NOVALUE;
    object _14124 = NOVALUE;
    object _14119 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25207)) {
        _1 = (object)(DBL_PTR(_start_25207)->dbl);
        DeRefDS(_start_25207);
        _start_25207 = _1;
    }
    if (!IS_ATOM_INT(_amount_25208)) {
        _1 = (object)(DBL_PTR(_amount_25208)->dbl);
        DeRefDS(_amount_25208);
        _amount_25208 = _1;
    }
    if (!IS_ATOM_INT(_bound_25209)) {
        _1 = (object)(DBL_PTR(_bound_25209)->dbl);
        DeRefDS(_bound_25209);
        _bound_25209 = _1;
    }

    /** shift.e:388		if amount = 0 then*/
    if (_amount_25208 != 0LL)
    goto L1; // [9] 19

    /** shift.e:389			return*/
    return;
L1: 

    /** shift.e:392		integer int*/

    /** shift.e:393		for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_36LineTable_21852)){
            _14119 = SEQ_PTR(_36LineTable_21852)->length;
    }
    else {
        _14119 = 1;
    }
    {
        object _i_25214;
        _i_25214 = _14119;
L2: 
        if (_i_25214 < 1LL){
            goto L3; // [28] 84
        }

        /** shift.e:394			int = LineTable[i]*/
        _2 = (object)SEQ_PTR(_36LineTable_21852);
        _int_25212 = (object)*(((s1_ptr)_2)->base + _i_25214);
        if (!IS_ATOM_INT(_int_25212)){
            _int_25212 = (object)DBL_PTR(_int_25212)->dbl;
        }

        /** shift.e:395			if int > 0 then*/
        if (_int_25212 <= 0LL)
        goto L4; // [47] 77

        /** shift.e:396				if int < start then*/
        if (_int_25212 >= _start_25207)
        goto L5; // [53] 62

        /** shift.e:397					exit*/
        goto L3; // [59] 84
L5: 

        /** shift.e:399				int += amount*/
        _int_25212 = _int_25212 + _amount_25208;

        /** shift.e:400				LineTable[i] = int*/
        _2 = (object)SEQ_PTR(_36LineTable_21852);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36LineTable_21852 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_25214);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _int_25212;
        DeRef(_1);
L4: 

        /** shift.e:402		end for*/
        _i_25214 = _i_25214 + -1LL;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** shift.e:404		integer pc = 1*/
    _pc_25225 = 1LL;

    /** shift.e:405		integer op*/

    /** shift.e:406		integer finish = start + amount - 1*/
    _14124 = _start_25207 + _amount_25208;
    if ((object)((uintptr_t)_14124 + (uintptr_t)HIGH_BITS) >= 0){
        _14124 = NewDouble((eudouble)_14124);
    }
    if (IS_ATOM_INT(_14124)) {
        _finish_25227 = _14124 - 1LL;
    }
    else {
        _finish_25227 = NewDouble(DBL_PTR(_14124)->dbl - (eudouble)1LL);
    }
    DeRef(_14124);
    _14124 = NOVALUE;
    if (!IS_ATOM_INT(_finish_25227)) {
        _1 = (object)(DBL_PTR(_finish_25227)->dbl);
        DeRefDS(_finish_25227);
        _finish_25227 = _1;
    }

    /** shift.e:407		integer len = length( Code )*/
    if (IS_SEQUENCE(_36Code_21851)){
            _len_25230 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _len_25230 = 1;
    }

    /** shift.e:408		while pc <= len do*/
L6: 
    if (_pc_25225 > _len_25230)
    goto L7; // [115] 278

    /** shift.e:409			op = Code[pc]*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    _op_25226 = (object)*(((s1_ptr)_2)->base + _pc_25225);
    if (!IS_ATOM_INT(_op_25226)){
        _op_25226 = (object)DBL_PTR(_op_25226)->dbl;
    }

    /** shift.e:410			if pc < start or pc > finish then*/
    _14129 = (_pc_25225 < _start_25207);
    if (_14129 != 0) {
        goto L8; // [135] 148
    }
    _14131 = (_pc_25225 > _finish_25227);
    if (_14131 == 0)
    {
        DeRef(_14131);
        _14131 = NOVALUE;
        goto L9; // [144] 223
    }
    else{
        DeRef(_14131);
        _14131 = NOVALUE;
    }
L8: 

    /** shift.e:412				if length( op_info_addr[op] ) then*/
    _2 = (object)SEQ_PTR(_66op_info_addr_24563);
    _14132 = (object)*(((s1_ptr)_2)->base + _op_25226);
    if (IS_SEQUENCE(_14132)){
            _14133 = SEQ_PTR(_14132)->length;
    }
    else {
        _14133 = 1;
    }
    _14132 = NOVALUE;
    if (_14133 == 0)
    {
        _14133 = NOVALUE;
        goto LA; // [159] 222
    }
    else{
        _14133 = NOVALUE;
    }

    /** shift.e:414					switch op with fallthru do*/
    _0 = _op_25226;
    switch ( _0 ){ 

        /** shift.e:415						case SWITCH then*/
        case 185:
        case 193:
        case 192:
        case 202:

        /** shift.e:420							shift_switch( pc, start, amount )*/
        _66shift_switch(_pc_25225, _start_25207, _amount_25208);

        /** shift.e:421							break*/
        goto LB; // [188] 221

        /** shift.e:423						case else*/
        default:

        /** shift.e:424							int = op_info_addr[op][1]*/
        _2 = (object)SEQ_PTR(_66op_info_addr_24563);
        _14136 = (object)*(((s1_ptr)_2)->base + _op_25226);
        _2 = (object)SEQ_PTR(_14136);
        _int_25212 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_int_25212)){
            _int_25212 = (object)DBL_PTR(_int_25212)->dbl;
        }
        _14136 = NOVALUE;

        /** shift.e:425							shift_addr( pc + int, amount, start, bound )*/
        _14138 = _pc_25225 + _int_25212;
        if ((object)((uintptr_t)_14138 + (uintptr_t)HIGH_BITS) >= 0){
            _14138 = NewDouble((eudouble)_14138);
        }
        _66shift_addr(_14138, _amount_25208, _start_25207, _bound_25209);
        _14138 = NOVALUE;
    ;}LB: 
LA: 
L9: 

    /** shift.e:430			integer size_type = op_info_size_type[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_type_24561);
    _size_type_25255 = (object)*(((s1_ptr)_2)->base + _op_25226);
    if (!IS_ATOM_INT(_size_type_25255))
    _size_type_25255 = (object)DBL_PTR(_size_type_25255)->dbl;

    /** shift.e:431			if size_type = FIXED_SIZE then*/
    if (_size_type_25255 != 1LL)
    goto LC; // [233] 254

    /** shift.e:433				pc += op_info_size[op]*/
    _2 = (object)SEQ_PTR(_66op_info_size_24562);
    _14141 = (object)*(((s1_ptr)_2)->base + _op_25226);
    if (IS_ATOM_INT(_14141)) {
        _pc_25225 = _pc_25225 + _14141;
    }
    else {
        _pc_25225 = binary_op(PLUS, _pc_25225, _14141);
    }
    _14141 = NOVALUE;
    if (!IS_ATOM_INT(_pc_25225)) {
        _1 = (object)(DBL_PTR(_pc_25225)->dbl);
        DeRefDS(_pc_25225);
        _pc_25225 = _1;
    }
    goto LD; // [251] 271
LC: 

    /** shift.e:435				pc += variable_op_size( pc, op )*/
    RefDS(_36Code_21851);
    _14143 = _66variable_op_size(_pc_25225, _op_25226, _36Code_21851);
    if (IS_ATOM_INT(_14143)) {
        _pc_25225 = _pc_25225 + _14143;
    }
    else {
        _pc_25225 = binary_op(PLUS, _pc_25225, _14143);
    }
    DeRef(_14143);
    _14143 = NOVALUE;
    if (!IS_ATOM_INT(_pc_25225)) {
        _1 = (object)(DBL_PTR(_pc_25225)->dbl);
        DeRefDS(_pc_25225);
        _pc_25225 = _1;
    }
LD: 

    /** shift.e:437		end while*/
    goto L6; // [275] 115
L7: 

    /** shift.e:438		shift_fwd_refs( start, amount )*/
    _44shift_fwd_refs(_start_25207, _amount_25208);

    /** shift.e:439		move_last_pc( amount )*/
    _47move_last_pc(_amount_25208);

    /** shift.e:440	end procedure*/
    _14132 = NOVALUE;
    DeRef(_14129);
    _14129 = NOVALUE;
    return;
    ;
}


void _66insert_code(object _code_25269, object _index_25270)
{
    object _14146 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:443		Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_25270;
        if (insert_pos <= 0) {
            Concat(&_36Code_21851,_code_25269,_36Code_21851);
        }
        else if (insert_pos > SEQ_PTR(_36Code_21851)->length){
            Concat(&_36Code_21851,_36Code_21851,_code_25269);
        }
        else if (IS_SEQUENCE(_code_25269)) {
            if( _36Code_21851 != _36Code_21851 || SEQ_PTR( _36Code_21851 )->ref != 1 ){
                DeRef( _36Code_21851 );
                RefDS( _36Code_21851 );
            }
            assign_space = Add_internal_space( _36Code_21851, insert_pos,((s1_ptr)SEQ_PTR(_code_25269))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_25269), _36Code_21851 == _36Code_21851 );
            _36Code_21851 = MAKE_SEQ( assign_space );
        }
        else {
            if( _36Code_21851 == _36Code_21851 && SEQ_PTR( _36Code_21851 )->ref == 1 ){
                _36Code_21851 = Insert( _36Code_21851, _code_25269, insert_pos);
            }
            else {
                DeRef( _36Code_21851 );
                RefDS( _36Code_21851 );
                _36Code_21851 = Insert( _36Code_21851, _code_25269, insert_pos);
            }
        }
    }

    /** shift.e:444		shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_25269)){
            _14146 = SEQ_PTR(_code_25269)->length;
    }
    else {
        _14146 = 1;
    }
    _66shift(_index_25270, _14146, _index_25270);
    _14146 = NOVALUE;

    /** shift.e:445	end procedure*/
    DeRefDSi(_code_25269);
    return;
    ;
}


void _66replace_code(object _code_25277, object _start_25278, object _finish_25279)
{
    object _14151 = NOVALUE;
    object _14150 = NOVALUE;
    object _14149 = NOVALUE;
    object _14148 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_25278)) {
        _1 = (object)(DBL_PTR(_start_25278)->dbl);
        DeRefDS(_start_25278);
        _start_25278 = _1;
    }
    if (!IS_ATOM_INT(_finish_25279)) {
        _1 = (object)(DBL_PTR(_finish_25279)->dbl);
        DeRefDS(_finish_25279);
        _finish_25279 = _1;
    }

    /** shift.e:448		Code = replace( Code, code, start, finish )*/
    {
        intptr_t p1 = _36Code_21851;
        intptr_t p2 = _code_25277;
        intptr_t p3 = _start_25278;
        intptr_t p4 = _finish_25279;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_36Code_21851;
        Replace( &replace_params );
    }

    /** shift.e:449		shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_25277)){
            _14148 = SEQ_PTR(_code_25277)->length;
    }
    else {
        _14148 = 1;
    }
    _14149 = _finish_25279 - _start_25278;
    if ((object)((uintptr_t)_14149 +(uintptr_t) HIGH_BITS) >= 0){
        _14149 = NewDouble((eudouble)_14149);
    }
    if (IS_ATOM_INT(_14149)) {
        _14150 = _14149 + 1;
        if (_14150 > MAXINT){
            _14150 = NewDouble((eudouble)_14150);
        }
    }
    else
    _14150 = binary_op(PLUS, 1, _14149);
    DeRef(_14149);
    _14149 = NOVALUE;
    if (IS_ATOM_INT(_14150)) {
        _14151 = _14148 - _14150;
        if ((object)((uintptr_t)_14151 +(uintptr_t) HIGH_BITS) >= 0){
            _14151 = NewDouble((eudouble)_14151);
        }
    }
    else {
        _14151 = NewDouble((eudouble)_14148 - DBL_PTR(_14150)->dbl);
    }
    _14148 = NOVALUE;
    DeRef(_14150);
    _14150 = NOVALUE;
    _66shift(_start_25278, _14151, _finish_25279);
    _14151 = NOVALUE;

    /** shift.e:450	end procedure*/
    DeRefDS(_code_25277);
    return;
    ;
}


object _66current_op(object _pc_25289, object _code_25290)
{
    object _14159 = NOVALUE;
    object _14158 = NOVALUE;
    object _14157 = NOVALUE;
    object _14156 = NOVALUE;
    object _14155 = NOVALUE;
    object _14153 = NOVALUE;
    object _14152 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:456		if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_25290)){
            _14152 = SEQ_PTR(_code_25290)->length;
    }
    else {
        _14152 = 1;
    }
    _14153 = (_pc_25289 > _14152);
    _14152 = NOVALUE;
    if (_14153 != 0) {
        goto L1; // [14] 27
    }
    _14155 = (_pc_25289 < 1LL);
    if (_14155 == 0)
    {
        DeRef(_14155);
        _14155 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_14155);
        _14155 = NOVALUE;
    }
L1: 

    /** shift.e:457			return {}*/
    RefDS(_5);
    DeRefDS(_code_25290);
    DeRef(_14153);
    _14153 = NOVALUE;
    return _5;
L2: 

    /** shift.e:459		return code[pc..pc-1+op_size( pc, code )]*/
    _14156 = _pc_25289 - 1LL;
    if ((object)((uintptr_t)_14156 +(uintptr_t) HIGH_BITS) >= 0){
        _14156 = NewDouble((eudouble)_14156);
    }
    RefDS(_code_25290);
    _14157 = _66op_size(_pc_25289, _code_25290);
    if (IS_ATOM_INT(_14156) && IS_ATOM_INT(_14157)) {
        _14158 = _14156 + _14157;
    }
    else {
        _14158 = binary_op(PLUS, _14156, _14157);
    }
    DeRef(_14156);
    _14156 = NOVALUE;
    DeRef(_14157);
    _14157 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14159;
    RHS_Slice(_code_25290, _pc_25289, _14158);
    DeRefDS(_code_25290);
    DeRef(_14158);
    _14158 = NOVALUE;
    DeRef(_14153);
    _14153 = NOVALUE;
    return _14159;
    ;
}


object _66get_ops(object _pc_25304, object _offset_25305, object _num_ops_25306, object _code_25307)
{
    object _sign_25310 = NOVALUE;
    object _ops_25319 = NOVALUE;
    object _opx_25321 = NOVALUE;
    object _14176 = NOVALUE;
    object _14175 = NOVALUE;
    object _14171 = NOVALUE;
    object _14170 = NOVALUE;
    object _14169 = NOVALUE;
    object _14168 = NOVALUE;
    object _14167 = NOVALUE;
    object _14166 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:466		integer sign = offset >= 0*/
    _sign_25310 = (_offset_25305 >= 0LL);

    /** shift.e:467		if not sign then*/
    if (_sign_25310 != 0)
    goto L1; // [17] 33

    /** shift.e:468			offset = -offset*/
    _offset_25305 = - _offset_25305;

    /** shift.e:469			sign = -1*/
    _sign_25310 = -1LL;
L1: 

    /** shift.e:472		while offset do*/
L2: 
    if (_offset_25305 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** shift.e:473			pc = advance( pc )*/
    RefDS(_36Code_21851);
    _pc_25304 = _66advance(_pc_25304, _36Code_21851);
    if (!IS_ATOM_INT(_pc_25304)) {
        _1 = (object)(DBL_PTR(_pc_25304)->dbl);
        DeRefDS(_pc_25304);
        _pc_25304 = _1;
    }

    /** shift.e:474			offset -= sign*/
    _offset_25305 = _offset_25305 - _sign_25310;

    /** shift.e:475		end while*/
    goto L2; // [60] 38
L3: 

    /** shift.e:477		sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_25319);
    _ops_25319 = Repeat(0LL, _num_ops_25306);

    /** shift.e:478		integer opx = 1*/
    _opx_25321 = 1LL;

    /** shift.e:479		while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_25306 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_25307)){
            _14167 = SEQ_PTR(_code_25307)->length;
    }
    else {
        _14167 = 1;
    }
    _14168 = (_pc_25304 <= _14167);
    _14167 = NOVALUE;
    if (_14168 == 0)
    {
        DeRef(_14168);
        _14168 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_14168);
        _14168 = NOVALUE;
    }

    /** shift.e:480			ops[opx] = current_op( pc )*/
    RefDS(_36Code_21851);
    _14169 = _66current_op(_pc_25304, _36Code_21851);
    _2 = (object)SEQ_PTR(_ops_25319);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _ops_25319 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _opx_25321);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14169;
    if( _1 != _14169 ){
        DeRef(_1);
    }
    _14169 = NOVALUE;

    /** shift.e:481			pc += length( ops[opx] )*/
    _2 = (object)SEQ_PTR(_ops_25319);
    _14170 = (object)*(((s1_ptr)_2)->base + _opx_25321);
    if (IS_SEQUENCE(_14170)){
            _14171 = SEQ_PTR(_14170)->length;
    }
    else {
        _14171 = 1;
    }
    _14170 = NOVALUE;
    _pc_25304 = _pc_25304 + _14171;
    _14171 = NOVALUE;

    /** shift.e:482			opx += 1*/
    _opx_25321 = _opx_25321 + 1;

    /** shift.e:483			num_ops -= 1*/
    _num_ops_25306 = _num_ops_25306 - 1LL;

    /** shift.e:484		end while*/
    goto L4; // [134] 79
L5: 

    /** shift.e:485		if num_ops then*/
    if (_num_ops_25306 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** shift.e:486			ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_25319)){
            _14175 = SEQ_PTR(_ops_25319)->length;
    }
    else {
        _14175 = 1;
    }
    _14176 = _14175 - _num_ops_25306;
    if ((object)((uintptr_t)_14176 +(uintptr_t) HIGH_BITS) >= 0){
        _14176 = NewDouble((eudouble)_14176);
    }
    _14175 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_25319)->length;
        int size = (IS_ATOM_INT(_14176)) ? _14176 : (object)(DBL_PTR(_14176)->dbl);
        if (size <= 0){
            DeRef( _ops_25319 );
            _ops_25319 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_25319);
            DeRef(_ops_25319);
            _ops_25319 = _ops_25319;
        }
        else{
            Head(SEQ_PTR(_ops_25319),size+1,&_ops_25319);
        }
    }
    DeRef(_14176);
    _14176 = NOVALUE;
L6: 

    /** shift.e:488		return ops*/
    DeRefDS(_code_25307);
    _14170 = NOVALUE;
    return _ops_25319;
    ;
}


object _66find_ops(object _pc_25339, object _op_25340, object _code_25341)
{
    object _ops_25344 = NOVALUE;
    object _found_op_25348 = NOVALUE;
    object _14185 = NOVALUE;
    object _14183 = NOVALUE;
    object _14181 = NOVALUE;
    object _14178 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:492		sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_25344);
    _ops_25344 = _5;

    /** shift.e:493		while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_25341)){
            _14178 = SEQ_PTR(_code_25341)->length;
    }
    else {
        _14178 = 1;
    }
    if (_pc_25339 > _14178)
    goto L2; // [22] 74

    /** shift.e:494			sequence found_op = current_op( pc )*/
    RefDS(_36Code_21851);
    _0 = _found_op_25348;
    _found_op_25348 = _66current_op(_pc_25339, _36Code_21851);
    DeRef(_0);

    /** shift.e:495			if found_op[1] = op then*/
    _2 = (object)SEQ_PTR(_found_op_25348);
    _14181 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _14181, _op_25340)){
        _14181 = NOVALUE;
        goto L3; // [43] 58
    }
    _14181 = NOVALUE;

    /** shift.e:496				ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_25348);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pc_25339;
    ((intptr_t *)_2)[2] = _found_op_25348;
    _14183 = MAKE_SEQ(_1);
    RefDS(_14183);
    Append(&_ops_25344, _ops_25344, _14183);
    DeRefDS(_14183);
    _14183 = NOVALUE;
L3: 

    /** shift.e:498			pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_25348)){
            _14185 = SEQ_PTR(_found_op_25348)->length;
    }
    else {
        _14185 = 1;
    }
    _pc_25339 = _pc_25339 + _14185;
    _14185 = NOVALUE;
    DeRefDS(_found_op_25348);
    _found_op_25348 = NOVALUE;

    /** shift.e:499		end while*/
    goto L1; // [71] 19
L2: 

    /** shift.e:500		return ops*/
    DeRefDS(_code_25341);
    return _ops_25344;
    ;
}


object _66get_target_sym(object _opseq_25360)
{
    object _op_25364 = NOVALUE;
    object _info_25366 = NOVALUE;
    object _targets_25382 = NOVALUE;
    object _sub_25397 = NOVALUE;
    object _14217 = NOVALUE;
    object _14216 = NOVALUE;
    object _14215 = NOVALUE;
    object _14214 = NOVALUE;
    object _14213 = NOVALUE;
    object _14212 = NOVALUE;
    object _14211 = NOVALUE;
    object _14209 = NOVALUE;
    object _14205 = NOVALUE;
    object _14204 = NOVALUE;
    object _14203 = NOVALUE;
    object _14202 = NOVALUE;
    object _14200 = NOVALUE;
    object _14199 = NOVALUE;
    object _14198 = NOVALUE;
    object _14197 = NOVALUE;
    object _14194 = NOVALUE;
    object _14193 = NOVALUE;
    object _14191 = NOVALUE;
    object _14187 = NOVALUE;
    object _0, _1, _2;
    

    /** shift.e:509		if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_25360)){
            _14187 = SEQ_PTR(_opseq_25360)->length;
    }
    else {
        _14187 = 1;
    }
    if (_14187 != 0)
    goto L1; // [8] 18
    _14187 = NOVALUE;

    /** shift.e:510			return 0*/
    DeRefDS(_opseq_25360);
    DeRef(_info_25366);
    return 0LL;
L1: 

    /** shift.e:512		integer op = opseq[1]*/
    _2 = (object)SEQ_PTR(_opseq_25360);
    _op_25364 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_op_25364))
    _op_25364 = (object)DBL_PTR(_op_25364)->dbl;

    /** shift.e:513		sequence info = op_info[op]*/
    DeRef(_info_25366);
    _2 = (object)SEQ_PTR(_66op_info_24555);
    _info_25366 = (object)*(((s1_ptr)_2)->base + _op_25364);
    Ref(_info_25366);

    /** shift.e:515		if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_info_25366);
    _14191 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _14191, 1LL)){
        _14191 = NOVALUE;
        goto L2; // [40] 157
    }
    _14191 = NOVALUE;

    /** shift.e:516			switch length( info[OP_TARGET] ) do*/
    _2 = (object)SEQ_PTR(_info_25366);
    _14193 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_14193)){
            _14194 = SEQ_PTR(_14193)->length;
    }
    else {
        _14194 = 1;
    }
    _14193 = NOVALUE;
    _0 = _14194;
    _14194 = NOVALUE;
    switch ( _0 ){ 

        /** shift.e:517				case 0 then*/
        case 0:

        /** shift.e:518					break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** shift.e:520				case 1 then*/
        case 1:

        /** shift.e:521					return opseq[info[OP_TARGET][1]+1]*/
        _2 = (object)SEQ_PTR(_info_25366);
        _14197 = (object)*(((s1_ptr)_2)->base + 4LL);
        _2 = (object)SEQ_PTR(_14197);
        _14198 = (object)*(((s1_ptr)_2)->base + 1LL);
        _14197 = NOVALUE;
        if (IS_ATOM_INT(_14198)) {
            _14199 = _14198 + 1;
        }
        else
        _14199 = binary_op(PLUS, 1, _14198);
        _14198 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25360);
        if (!IS_ATOM_INT(_14199)){
            _14200 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14199)->dbl));
        }
        else{
            _14200 = (object)*(((s1_ptr)_2)->base + _14199);
        }
        Ref(_14200);
        DeRefDS(_opseq_25360);
        DeRefDS(_info_25366);
        DeRef(_14199);
        _14199 = NOVALUE;
        _14193 = NOVALUE;
        return _14200;
        goto L3; // [94] 152

        /** shift.e:523				case else*/
        default:

        /** shift.e:524					sequence targets = info[OP_TARGET]*/
        DeRef(_targets_25382);
        _2 = (object)SEQ_PTR(_info_25366);
        _targets_25382 = (object)*(((s1_ptr)_2)->base + 4LL);
        Ref(_targets_25382);

        /** shift.e:525					for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_25382)){
                _14202 = SEQ_PTR(_targets_25382)->length;
        }
        else {
            _14202 = 1;
        }
        {
            object _i_25385;
            _i_25385 = 1LL;
L4: 
            if (_i_25385 > _14202){
                goto L5; // [113] 145
            }

            /** shift.e:526						targets[i] = opseq[targets[i] + 1]*/
            _2 = (object)SEQ_PTR(_targets_25382);
            _14203 = (object)*(((s1_ptr)_2)->base + _i_25385);
            if (IS_ATOM_INT(_14203)) {
                _14204 = _14203 + 1;
            }
            else
            _14204 = binary_op(PLUS, 1, _14203);
            _14203 = NOVALUE;
            _2 = (object)SEQ_PTR(_opseq_25360);
            if (!IS_ATOM_INT(_14204)){
                _14205 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14204)->dbl));
            }
            else{
                _14205 = (object)*(((s1_ptr)_2)->base + _14204);
            }
            Ref(_14205);
            _2 = (object)SEQ_PTR(_targets_25382);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _targets_25382 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_25385);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14205;
            if( _1 != _14205 ){
                DeRef(_1);
            }
            _14205 = NOVALUE;

            /** shift.e:527					end for*/
            _i_25385 = _i_25385 + 1LL;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** shift.e:529					return targets*/
        DeRefDS(_opseq_25360);
        DeRef(_info_25366);
        _14200 = NOVALUE;
        DeRef(_14204);
        _14204 = NOVALUE;
        DeRef(_14199);
        _14199 = NOVALUE;
        _14193 = NOVALUE;
        return _targets_25382;
    ;}L3: 
    DeRef(_targets_25382);
    _targets_25382 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** shift.e:535			switch op do*/
    _0 = _op_25364;
    switch ( _0 ){ 

        /** shift.e:536				case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** shift.e:537					symtab_index sub = opseq[2]*/
        _2 = (object)SEQ_PTR(_opseq_25360);
        _sub_25397 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_sub_25397)){
            _sub_25397 = (object)DBL_PTR(_sub_25397)->dbl;
        }

        /** shift.e:538					if sym_token( sub ) = FUNC then*/
        _14209 = _54sym_token(_sub_25397);
        if (binary_op_a(NOTEQ, _14209, 501LL)){
            DeRef(_14209);
            _14209 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_14209);
        _14209 = NOVALUE;

        /** shift.e:539						return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25360)){
                _14211 = SEQ_PTR(_opseq_25360)->length;
        }
        else {
            _14211 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25360);
        _14212 = (object)*(((s1_ptr)_2)->base + _14211);
        Ref(_14212);
        DeRefDS(_opseq_25360);
        DeRef(_info_25366);
        _14200 = NOVALUE;
        DeRef(_14204);
        _14204 = NOVALUE;
        DeRef(_14199);
        _14199 = NOVALUE;
        _14193 = NOVALUE;
        return _14212;
L7: 
        goto L8; // [206] 252

        /** shift.e:542				case FUNC_FORWARD then*/
        case 196:

        /** shift.e:543					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_25360)){
                _14213 = SEQ_PTR(_opseq_25360)->length;
        }
        else {
            _14213 = 1;
        }
        _2 = (object)SEQ_PTR(_opseq_25360);
        _14214 = (object)*(((s1_ptr)_2)->base + _14213);
        Ref(_14214);
        DeRefDS(_opseq_25360);
        DeRef(_info_25366);
        _14200 = NOVALUE;
        _14212 = NOVALUE;
        DeRef(_14204);
        _14204 = NOVALUE;
        DeRef(_14199);
        _14199 = NOVALUE;
        _14193 = NOVALUE;
        return _14214;
        goto L8; // [225] 252

        /** shift.e:545				case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** shift.e:546					return opseq[opseq[2]+2]*/
        _2 = (object)SEQ_PTR(_opseq_25360);
        _14215 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_ATOM_INT(_14215)) {
            _14216 = _14215 + 2LL;
        }
        else {
            _14216 = binary_op(PLUS, _14215, 2LL);
        }
        _14215 = NOVALUE;
        _2 = (object)SEQ_PTR(_opseq_25360);
        if (!IS_ATOM_INT(_14216)){
            _14217 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14216)->dbl));
        }
        else{
            _14217 = (object)*(((s1_ptr)_2)->base + _14216);
        }
        Ref(_14217);
        DeRefDS(_opseq_25360);
        DeRef(_info_25366);
        _14200 = NOVALUE;
        _14214 = NOVALUE;
        DeRef(_14216);
        _14216 = NOVALUE;
        _14212 = NOVALUE;
        DeRef(_14204);
        _14204 = NOVALUE;
        DeRef(_14199);
        _14199 = NOVALUE;
        _14193 = NOVALUE;
        return _14217;
    ;}L8: 
L6: 

    /** shift.e:551		return 0*/
    DeRefDS(_opseq_25360);
    DeRef(_info_25366);
    _14200 = NOVALUE;
    _14217 = NOVALUE;
    _14214 = NOVALUE;
    DeRef(_14216);
    _14216 = NOVALUE;
    _14212 = NOVALUE;
    DeRef(_14204);
    _14204 = NOVALUE;
    DeRef(_14199);
    _14199 = NOVALUE;
    _14193 = NOVALUE;
    return 0LL;
    ;
}



// 0xE27B0CA1
