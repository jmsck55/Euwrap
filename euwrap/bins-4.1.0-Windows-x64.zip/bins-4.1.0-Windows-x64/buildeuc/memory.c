// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _11deallocate(object _addr_378)
{
    object _0, _1, _2;
    

    /** memory.e:71		ifdef DATA_EXECUTE then*/

    /** memory.e:82	   	machine_proc( memconst:M_FREE, addr)*/
    machine(17LL, _addr_378);

    /** memory.e:83	end procedure*/
    DeRef(_addr_378);
    return;
    ;
}


object _11prepare_block(object _addr_404, object _a_405, object _protection_406)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_405)) {
        _1 = (object)(DBL_PTR(_a_405)->dbl);
        DeRefDS(_a_405);
        _a_405 = _1;
    }

    /** memory.e:134		return addr*/
    return _addr_404;
    ;
}



// 0xF5093C05
