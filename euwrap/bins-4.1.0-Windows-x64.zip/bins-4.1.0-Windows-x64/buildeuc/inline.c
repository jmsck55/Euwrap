// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _67advance(object _pc_53902, object _code_53903)
{
    object _27371 = NOVALUE;
    object _27369 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:63		prev_pc = pc*/
    _67prev_pc_53885 = _pc_53902;

    /** inline.e:64		if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_53903)){
            _27369 = SEQ_PTR(_code_53903)->length;
    }
    else {
        _27369 = 1;
    }
    if (_pc_53902 <= _27369)
    goto L1; // [15] 26

    /** inline.e:65			return pc*/
    DeRefDS(_code_53903);
    return _pc_53902;
L1: 

    /** inline.e:67		return shift:advance( pc, code )*/
    RefDS(_code_53903);
    _27371 = _66advance(_pc_53902, _code_53903);
    DeRefDS(_code_53903);
    return _27371;
    ;
}


void _67shift(object _start_53910, object _amount_53911, object _bound_53912)
{
    object _temp_LineTable_53913 = NOVALUE;
    object _temp_Code_53915 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_53911)) {
        _1 = (object)(DBL_PTR(_amount_53911)->dbl);
        DeRefDS(_amount_53911);
        _amount_53911 = _1;
    }

    /** inline.e:72			temp_LineTable = LineTable,*/
    RefDS(_36LineTable_21852);
    DeRef(_temp_LineTable_53913);
    _temp_LineTable_53913 = _36LineTable_21852;

    /** inline.e:73			temp_Code = Code*/
    RefDS(_36Code_21851);
    DeRef(_temp_Code_53915);
    _temp_Code_53915 = _36Code_21851;

    /** inline.e:74		LineTable = {}*/
    RefDS(_22186);
    DeRefDS(_36LineTable_21852);
    _36LineTable_21852 = _22186;

    /** inline.e:75		Code = inline_code*/
    RefDS(_67inline_code_53877);
    DeRefDS(_36Code_21851);
    _36Code_21851 = _67inline_code_53877;

    /** inline.e:76		inline_code = {}*/
    RefDS(_22186);
    DeRefDS(_67inline_code_53877);
    _67inline_code_53877 = _22186;

    /** inline.e:78		shift:shift( start, amount, bound )*/
    _66shift(_start_53910, _amount_53911, _bound_53912);

    /** inline.e:80		LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_53913);
    DeRefDS(_36LineTable_21852);
    _36LineTable_21852 = _temp_LineTable_53913;

    /** inline.e:81		inline_code = Code*/
    RefDS(_36Code_21851);
    DeRefDS(_67inline_code_53877);
    _67inline_code_53877 = _36Code_21851;

    /** inline.e:82		Code = temp_Code*/
    RefDS(_temp_Code_53915);
    DeRefDS(_36Code_21851);
    _36Code_21851 = _temp_Code_53915;

    /** inline.e:83	end procedure*/
    DeRefDS(_temp_LineTable_53913);
    DeRefDS(_temp_Code_53915);
    return;
    ;
}


void _67replace_code(object _code_53930, object _start_53931, object _finish_53932)
{
    object _27378 = NOVALUE;
    object _27377 = NOVALUE;
    object _27376 = NOVALUE;
    object _27375 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_53932)) {
        _1 = (object)(DBL_PTR(_finish_53932)->dbl);
        DeRefDS(_finish_53932);
        _finish_53932 = _1;
    }

    /** inline.e:92		inline_code = replace( inline_code, code, start, finish )*/
    {
        intptr_t p1 = _67inline_code_53877;
        intptr_t p2 = _code_53930;
        intptr_t p3 = _start_53931;
        intptr_t p4 = _finish_53932;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_67inline_code_53877;
        Replace( &replace_params );
    }

    /** inline.e:93		shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_53930)){
            _27375 = SEQ_PTR(_code_53930)->length;
    }
    else {
        _27375 = 1;
    }
    _27376 = _finish_53932 - _start_53931;
    if ((object)((uintptr_t)_27376 +(uintptr_t) HIGH_BITS) >= 0){
        _27376 = NewDouble((eudouble)_27376);
    }
    if (IS_ATOM_INT(_27376)) {
        _27377 = _27376 + 1;
        if (_27377 > MAXINT){
            _27377 = NewDouble((eudouble)_27377);
        }
    }
    else
    _27377 = binary_op(PLUS, 1, _27376);
    DeRef(_27376);
    _27376 = NOVALUE;
    if (IS_ATOM_INT(_27377)) {
        _27378 = _27375 - _27377;
        if ((object)((uintptr_t)_27378 +(uintptr_t) HIGH_BITS) >= 0){
            _27378 = NewDouble((eudouble)_27378);
        }
    }
    else {
        _27378 = NewDouble((eudouble)_27375 - DBL_PTR(_27377)->dbl);
    }
    _27375 = NOVALUE;
    DeRef(_27377);
    _27377 = NOVALUE;
    _67shift(_start_53931, _27378, _finish_53932);
    _27378 = NOVALUE;

    /** inline.e:94	end procedure*/
    DeRefDS(_code_53930);
    return;
    ;
}


void _67defer()
{
    object _dx_53940 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:101		integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_53940 = find_from(_67inline_sub_53891, _67deferred_inline_decisions_53893, 1LL);

    /** inline.e:102		if not dx then*/
    if (_dx_53940 != 0)
    goto L1; // [14] 36

    /** inline.e:103			deferred_inline_decisions &= inline_sub*/
    Append(&_67deferred_inline_decisions_53893, _67deferred_inline_decisions_53893, _67inline_sub_53891);

    /** inline.e:104			deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_22186);
    Append(&_67deferred_inline_calls_53894, _67deferred_inline_calls_53894, _22186);
L1: 

    /** inline.e:106	end procedure*/
    return;
    ;
}


object _67new_inline_temp(object _sym_53949)
{
    object _27384 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:110		inline_temps &= sym*/
    Append(&_67inline_temps_53879, _67inline_temps_53879, _sym_53949);

    /** inline.e:111		return length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53879)){
            _27384 = SEQ_PTR(_67inline_temps_53879)->length;
    }
    else {
        _27384 = 1;
    }
    return _27384;
    ;
}


object _67get_inline_temp(object _sym_53955)
{
    object _temp_num_53956 = NOVALUE;
    object _27388 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:117		integer temp_num = find( sym, inline_params )*/
    _temp_num_53956 = find_from(_sym_53955, _67inline_params_53882, 1LL);

    /** inline.e:118		if temp_num then*/
    if (_temp_num_53956 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** inline.e:119			return temp_num*/
    return _temp_num_53956;
L1: 

    /** inline.e:122		temp_num = find( sym, proc_vars )*/
    _temp_num_53956 = find_from(_sym_53955, _67proc_vars_53878, 1LL);

    /** inline.e:123		if temp_num then*/
    if (_temp_num_53956 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** inline.e:124			return temp_num*/
    return _temp_num_53956;
L2: 

    /** inline.e:127		temp_num = find( sym, inline_temps )*/
    _temp_num_53956 = find_from(_sym_53955, _67inline_temps_53879, 1LL);

    /** inline.e:128		if temp_num then*/
    if (_temp_num_53956 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** inline.e:129			return temp_num*/
    return _temp_num_53956;
L3: 

    /** inline.e:132		return new_inline_temp( sym )*/
    _27388 = _67new_inline_temp(_sym_53955);
    return _27388;
    ;
}


object _67generic_symbol(object _sym_53967)
{
    object _inline_type_53968 = NOVALUE;
    object _px_53969 = NOVALUE;
    object _eentry_53976 = NOVALUE;
    object _27397 = NOVALUE;
    object _27396 = NOVALUE;
    object _27395 = NOVALUE;
    object _27394 = NOVALUE;
    object _27392 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:137		integer px = find( sym, inline_params )*/
    _px_53969 = find_from(_sym_53967, _67inline_params_53882, 1LL);

    /** inline.e:138		if px then*/
    if (_px_53969 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** inline.e:139			inline_type = INLINE_PARAM*/
    _inline_type_53968 = 1LL;
    goto L2; // [22] 100
L1: 

    /** inline.e:141			px = find( sym, proc_vars )*/
    _px_53969 = find_from(_sym_53967, _67proc_vars_53878, 1LL);

    /** inline.e:142			if px then*/
    if (_px_53969 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** inline.e:143				inline_type = INLINE_VAR*/
    _inline_type_53968 = 6LL;
    goto L4; // [44] 99
L3: 

    /** inline.e:145				sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53976);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_53976 = (object)*(((s1_ptr)_2)->base + _sym_53967);
    Ref(_eentry_53976);

    /** inline.e:146				if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _27392 = _67is_literal(_sym_53967);
    if (IS_ATOM_INT(_27392)) {
        if (_27392 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_27392)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (object)SEQ_PTR(_eentry_53976);
    _27394 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_27394)) {
        _27395 = (_27394 > 3LL);
    }
    else {
        _27395 = binary_op(GREATER, _27394, 3LL);
    }
    _27394 = NOVALUE;
    if (_27395 == 0) {
        DeRef(_27395);
        _27395 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_27395) && DBL_PTR(_27395)->dbl == 0.0){
            DeRef(_27395);
            _27395 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_27395);
        _27395 = NOVALUE;
    }
    DeRef(_27395);
    _27395 = NOVALUE;
L5: 

    /** inline.e:147					return sym*/
    DeRef(_eentry_53976);
    DeRef(_27392);
    _27392 = NOVALUE;
    return _sym_53967;
L6: 

    /** inline.e:149				inline_type = INLINE_TEMP*/
    _inline_type_53968 = 2LL;
    DeRef(_eentry_53976);
    _eentry_53976 = NOVALUE;
L4: 
L2: 

    /** inline.e:153		return { inline_type, get_inline_temp( sym ) }*/
    _27396 = _67get_inline_temp(_sym_53967);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _inline_type_53968;
    ((intptr_t *)_2)[2] = _27396;
    _27397 = MAKE_SEQ(_1);
    _27396 = NOVALUE;
    DeRef(_27392);
    _27392 = NOVALUE;
    return _27397;
    ;
}


object _67adjust_symbol(object _pc_53991)
{
    object _sym_53993 = NOVALUE;
    object _eentry_53999 = NOVALUE;
    object _27405 = NOVALUE;
    object _27403 = NOVALUE;
    object _27402 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53991)) {
        _1 = (object)(DBL_PTR(_pc_53991)->dbl);
        DeRefDS(_pc_53991);
        _pc_53991 = _1;
    }

    /** inline.e:160		symtab_index sym = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _sym_53993 = (object)*(((s1_ptr)_2)->base + _pc_53991);
    if (!IS_ATOM_INT(_sym_53993)){
        _sym_53993 = (object)DBL_PTR(_sym_53993)->dbl;
    }

    /** inline.e:161		if sym < 0 then*/
    if (_sym_53993 >= 0LL)
    goto L1; // [15] 28

    /** inline.e:162			return 0*/
    DeRef(_eentry_53999);
    return 0LL;
    goto L2; // [25] 41
L1: 

    /** inline.e:163		elsif not sym then*/
    if (_sym_53993 != 0)
    goto L3; // [30] 40

    /** inline.e:165			return 1*/
    DeRef(_eentry_53999);
    return 1LL;
L3: 
L2: 

    /** inline.e:168		sequence eentry = SymTab[sym]*/
    DeRef(_eentry_53999);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_53999 = (object)*(((s1_ptr)_2)->base + _sym_53993);
    Ref(_eentry_53999);

    /** inline.e:169		if is_literal( sym ) then*/
    _27402 = _67is_literal(_sym_53993);
    if (_27402 == 0) {
        DeRef(_27402);
        _27402 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_27402) && DBL_PTR(_27402)->dbl == 0.0){
            DeRef(_27402);
            _27402 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_27402);
        _27402 = NOVALUE;
    }
    DeRef(_27402);
    _27402 = NOVALUE;

    /** inline.e:170			return 1*/
    DeRefDS(_eentry_53999);
    return 1LL;
    goto L5; // [66] 95
L4: 

    /** inline.e:172		elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_eentry_53999);
    _27403 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (binary_op_a(NOTEQ, _27403, 9LL)){
        _27403 = NOVALUE;
        goto L6; // [79] 94
    }
    _27403 = NOVALUE;

    /** inline.e:173			defer()*/
    _67defer();

    /** inline.e:174			return 0*/
    DeRefDS(_eentry_53999);
    return 0LL;
L6: 
L5: 

    /** inline.e:177		inline_code[pc] = generic_symbol( sym )*/
    _27405 = _67generic_symbol(_sym_53993);
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_53991);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27405;
    if( _1 != _27405 ){
        DeRef(_1);
    }
    _27405 = NOVALUE;

    /** inline.e:178		return 1*/
    DeRef(_eentry_53999);
    return 1LL;
    ;
}


object _67check_for_param(object _pc_54013)
{
    object _px_54014 = NOVALUE;
    object _27408 = NOVALUE;
    object _27406 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54013)) {
        _1 = (object)(DBL_PTR(_pc_54013)->dbl);
        DeRefDS(_pc_54013);
        _pc_54013 = _1;
    }

    /** inline.e:182		integer px = find( inline_code[pc], inline_params )*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27406 = (object)*(((s1_ptr)_2)->base + _pc_54013);
    _px_54014 = find_from(_27406, _67inline_params_53882, 1LL);
    _27406 = NOVALUE;

    /** inline.e:183		if px then*/
    if (_px_54014 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** inline.e:184			if not find( px, assigned_params ) then*/
    _27408 = find_from(_px_54014, _67assigned_params_53883, 1LL);
    if (_27408 != 0)
    goto L2; // [32] 44
    _27408 = NOVALUE;

    /** inline.e:185				assigned_params &= px*/
    Append(&_67assigned_params_53883, _67assigned_params_53883, _px_54014);
L2: 

    /** inline.e:187			return 1*/
    return 1LL;
L1: 

    /** inline.e:189		return 0*/
    return 0LL;
    ;
}


void _67check_target(object _pc_54024, object _op_54025)
{
    object _targets_54026 = NOVALUE;
    object _27417 = NOVALUE;
    object _27416 = NOVALUE;
    object _27415 = NOVALUE;
    object _27414 = NOVALUE;
    object _27413 = NOVALUE;
    object _27411 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:194		sequence targets = op_info[op][OP_TARGET]*/
    _2 = (object)SEQ_PTR(_66op_info_24555);
    _27411 = (object)*(((s1_ptr)_2)->base + _op_54025);
    DeRef(_targets_54026);
    _2 = (object)SEQ_PTR(_27411);
    _targets_54026 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_targets_54026);
    _27411 = NOVALUE;

    /** inline.e:196		if length( targets ) then*/
    if (IS_SEQUENCE(_targets_54026)){
            _27413 = SEQ_PTR(_targets_54026)->length;
    }
    else {
        _27413 = 1;
    }
    if (_27413 == 0)
    {
        _27413 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _27413 = NOVALUE;
    }

    /** inline.e:197		for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_54026)){
            _27414 = SEQ_PTR(_targets_54026)->length;
    }
    else {
        _27414 = 1;
    }
    {
        object _i_54034;
        _i_54034 = 1LL;
L2: 
        if (_i_54034 > _27414){
            goto L3; // [34] 71
        }

        /** inline.e:198				if check_for_param( pc + targets[i] ) then*/
        _2 = (object)SEQ_PTR(_targets_54026);
        _27415 = (object)*(((s1_ptr)_2)->base + _i_54034);
        if (IS_ATOM_INT(_27415)) {
            _27416 = _pc_54024 + _27415;
            if ((object)((uintptr_t)_27416 + (uintptr_t)HIGH_BITS) >= 0){
                _27416 = NewDouble((eudouble)_27416);
            }
        }
        else {
            _27416 = binary_op(PLUS, _pc_54024, _27415);
        }
        _27415 = NOVALUE;
        _27417 = _67check_for_param(_27416);
        _27416 = NOVALUE;
        if (_27417 == 0) {
            DeRef(_27417);
            _27417 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_27417) && DBL_PTR(_27417)->dbl == 0.0){
                DeRef(_27417);
                _27417 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_27417);
            _27417 = NOVALUE;
        }
        DeRef(_27417);
        _27417 = NOVALUE;

        /** inline.e:199					return*/
        DeRefDS(_targets_54026);
        return;
L4: 

        /** inline.e:201			end for*/
        _i_54034 = _i_54034 + 1LL;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** inline.e:203	end procedure*/
    DeRef(_targets_54026);
    return;
    ;
}


object _67adjust_il(object _pc_54042, object _op_54043)
{
    object _addr_54051 = NOVALUE;
    object _sub_54057 = NOVALUE;
    object _27442 = NOVALUE;
    object _27441 = NOVALUE;
    object _27440 = NOVALUE;
    object _27439 = NOVALUE;
    object _27438 = NOVALUE;
    object _27437 = NOVALUE;
    object _27436 = NOVALUE;
    object _27434 = NOVALUE;
    object _27433 = NOVALUE;
    object _27432 = NOVALUE;
    object _27431 = NOVALUE;
    object _27430 = NOVALUE;
    object _27429 = NOVALUE;
    object _27428 = NOVALUE;
    object _27427 = NOVALUE;
    object _27425 = NOVALUE;
    object _27424 = NOVALUE;
    object _27422 = NOVALUE;
    object _27421 = NOVALUE;
    object _27420 = NOVALUE;
    object _27419 = NOVALUE;
    object _27418 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:208		for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (object)SEQ_PTR(_66op_info_24555);
    _27418 = (object)*(((s1_ptr)_2)->base + _op_54043);
    _2 = (object)SEQ_PTR(_27418);
    _27419 = (object)*(((s1_ptr)_2)->base + 2LL);
    _27418 = NOVALUE;
    if (IS_ATOM_INT(_27419)) {
        _27420 = _27419 - 1LL;
        if ((object)((uintptr_t)_27420 +(uintptr_t) HIGH_BITS) >= 0){
            _27420 = NewDouble((eudouble)_27420);
        }
    }
    else {
        _27420 = binary_op(MINUS, _27419, 1LL);
    }
    _27419 = NOVALUE;
    {
        object _i_54045;
        _i_54045 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_54045, _27420)){
            goto L2; // [23] 214
        }

        /** inline.e:210			integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (object)SEQ_PTR(_66op_info_24555);
        _27421 = (object)*(((s1_ptr)_2)->base + _op_54043);
        _2 = (object)SEQ_PTR(_27421);
        _27422 = (object)*(((s1_ptr)_2)->base + 3LL);
        _27421 = NOVALUE;
        _addr_54051 = find_from(_i_54045, _27422, 1LL);
        _27422 = NOVALUE;

        /** inline.e:211			integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (object)SEQ_PTR(_66op_info_24555);
        _27424 = (object)*(((s1_ptr)_2)->base + _op_54043);
        _2 = (object)SEQ_PTR(_27424);
        _27425 = (object)*(((s1_ptr)_2)->base + 5LL);
        _27424 = NOVALUE;
        _sub_54057 = find_from(_i_54045, _27425, 1LL);
        _27425 = NOVALUE;

        /** inline.e:212			if addr then*/
        if (_addr_54051 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** inline.e:213				if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_54045)) {
            _27427 = _pc_54042 + _i_54045;
        }
        else {
            _27427 = NewDouble((eudouble)_pc_54042 + DBL_PTR(_i_54045)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        if (!IS_ATOM_INT(_27427)){
            _27428 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27427)->dbl));
        }
        else{
            _27428 = (object)*(((s1_ptr)_2)->base + _27427);
        }
        if (IS_ATOM_INT(_27428))
        _27429 = 1;
        else if (IS_ATOM_DBL(_27428))
        _27429 = IS_ATOM_INT(DoubleToInt(_27428));
        else
        _27429 = 0;
        _27428 = NOVALUE;
        if (_27429 == 0)
        {
            _27429 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _27429 = NOVALUE;
        }

        /** inline.e:214					inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_54045)) {
            _27430 = _pc_54042 + _i_54045;
            if ((object)((uintptr_t)_27430 + (uintptr_t)HIGH_BITS) >= 0){
                _27430 = NewDouble((eudouble)_27430);
            }
        }
        else {
            _27430 = NewDouble((eudouble)_pc_54042 + DBL_PTR(_i_54045)->dbl);
        }
        if (IS_ATOM_INT(_i_54045)) {
            _27431 = _pc_54042 + _i_54045;
        }
        else {
            _27431 = NewDouble((eudouble)_pc_54042 + DBL_PTR(_i_54045)->dbl);
        }
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        if (!IS_ATOM_INT(_27431)){
            _27432 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27431)->dbl));
        }
        else{
            _27432 = (object)*(((s1_ptr)_2)->base + _27431);
        }
        Ref(_27432);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 4LL;
        ((intptr_t *)_2)[2] = _27432;
        _27433 = MAKE_SEQ(_1);
        _27432 = NOVALUE;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53877 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27430))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27430)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27430);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27433;
        if( _1 != _27433 ){
            DeRef(_1);
        }
        _27433 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** inline.e:217			elsif sub then*/
        if (_sub_54057 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** inline.e:218				inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_54045)) {
            _27434 = _pc_54042 + _i_54045;
        }
        else {
            _27434 = NewDouble((eudouble)_pc_54042 + DBL_PTR(_i_54045)->dbl);
        }
        RefDS(_27435);
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53877 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27434))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27434)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _27434);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27435;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** inline.e:220				if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27436 = (_op_54043 != 58LL);
        if (_27436 == 0) {
            _27437 = 0;
            goto L6; // [149] 163
        }
        _27438 = (_op_54043 != 210LL);
        _27437 = (_27438 != 0);
L6: 
        if (_27437 == 0) {
            goto L7; // [163] 204
        }
        _27440 = (_op_54043 != 211LL);
        if (_27440 == 0)
        {
            DeRef(_27440);
            _27440 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27440);
            _27440 = NOVALUE;
        }

        /** inline.e:221					check_target( pc, op )*/
        _67check_target(_pc_54042, _op_54043);

        /** inline.e:222					if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_54045)) {
            _27441 = _pc_54042 + _i_54045;
            if ((object)((uintptr_t)_27441 + (uintptr_t)HIGH_BITS) >= 0){
                _27441 = NewDouble((eudouble)_27441);
            }
        }
        else {
            _27441 = NewDouble((eudouble)_pc_54042 + DBL_PTR(_i_54045)->dbl);
        }
        _27442 = _67adjust_symbol(_27441);
        _27441 = NOVALUE;
        if (IS_ATOM_INT(_27442)) {
            if (_27442 != 0){
                DeRef(_27442);
                _27442 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27442)->dbl != 0.0){
                DeRef(_27442);
                _27442 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27442);
        _27442 = NOVALUE;

        /** inline.e:223						return 0*/
        DeRef(_i_54045);
        DeRef(_27434);
        _27434 = NOVALUE;
        DeRef(_27431);
        _27431 = NOVALUE;
        DeRef(_27427);
        _27427 = NOVALUE;
        DeRef(_27436);
        _27436 = NOVALUE;
        DeRef(_27438);
        _27438 = NOVALUE;
        DeRef(_27420);
        _27420 = NOVALUE;
        DeRef(_27430);
        _27430 = NOVALUE;
        return 0LL;
L8: 
L7: 
L4: 

        /** inline.e:227		end for*/
        _0 = _i_54045;
        if (IS_ATOM_INT(_i_54045)) {
            _i_54045 = _i_54045 + 1LL;
            if ((object)((uintptr_t)_i_54045 +(uintptr_t) HIGH_BITS) >= 0){
                _i_54045 = NewDouble((eudouble)_i_54045);
            }
        }
        else {
            _i_54045 = binary_op_a(PLUS, _i_54045, 1LL);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_54045);
    }

    /** inline.e:228		return 1*/
    DeRef(_27434);
    _27434 = NOVALUE;
    DeRef(_27431);
    _27431 = NOVALUE;
    DeRef(_27427);
    _27427 = NOVALUE;
    DeRef(_27436);
    _27436 = NOVALUE;
    DeRef(_27438);
    _27438 = NOVALUE;
    DeRef(_27420);
    _27420 = NOVALUE;
    DeRef(_27430);
    _27430 = NOVALUE;
    return 1LL;
    ;
}


object _67is_temp(object _sym_54092)
{
    object _27453 = NOVALUE;
    object _27452 = NOVALUE;
    object _27451 = NOVALUE;
    object _27450 = NOVALUE;
    object _27449 = NOVALUE;
    object _27448 = NOVALUE;
    object _27447 = NOVALUE;
    object _27446 = NOVALUE;
    object _27445 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:232		if sym <= 0 then*/
    if (_sym_54092 > 0LL)
    goto L1; // [5] 16

    /** inline.e:233			return 0*/
    return 0LL;
L1: 

    /** inline.e:236		return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27445 = (object)*(((s1_ptr)_2)->base + _sym_54092);
    _2 = (object)SEQ_PTR(_27445);
    _27446 = (object)*(((s1_ptr)_2)->base + 3LL);
    _27445 = NOVALUE;
    if (IS_ATOM_INT(_27446)) {
        _27447 = (_27446 == 3LL);
    }
    else {
        _27447 = binary_op(EQUALS, _27446, 3LL);
    }
    _27446 = NOVALUE;
    _27448 = (_36TRANSLATE_21361 == 0);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27449 = (object)*(((s1_ptr)_2)->base + _sym_54092);
    _2 = (object)SEQ_PTR(_27449);
    _27450 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27449 = NOVALUE;
    if (_36NOVALUE_21613 == _27450)
    _27451 = 1;
    else if (IS_ATOM_INT(_36NOVALUE_21613) && IS_ATOM_INT(_27450))
    _27451 = 0;
    else
    _27451 = (compare(_36NOVALUE_21613, _27450) == 0);
    _27450 = NOVALUE;
    _27452 = (_27448 != 0 || _27451 != 0);
    _27448 = NOVALUE;
    _27451 = NOVALUE;
    if (IS_ATOM_INT(_27447)) {
        _27453 = (_27447 != 0 && _27452 != 0);
    }
    else {
        _27453 = binary_op(AND, _27447, _27452);
    }
    DeRef(_27447);
    _27447 = NOVALUE;
    _27452 = NOVALUE;
    return _27453;
    ;
}


object _67is_literal(object _sym_54114)
{
    object _mode_54117 = NOVALUE;
    object _27468 = NOVALUE;
    object _27467 = NOVALUE;
    object _27466 = NOVALUE;
    object _27465 = NOVALUE;
    object _27464 = NOVALUE;
    object _27463 = NOVALUE;
    object _27461 = NOVALUE;
    object _27460 = NOVALUE;
    object _27459 = NOVALUE;
    object _27458 = NOVALUE;
    object _27457 = NOVALUE;
    object _27455 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:240		if sym <= 0 then*/
    if (_sym_54114 > 0LL)
    goto L1; // [5] 16

    /** inline.e:241			return 0*/
    return 0LL;
L1: 

    /** inline.e:244		integer mode = SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27455 = (object)*(((s1_ptr)_2)->base + _sym_54114);
    _2 = (object)SEQ_PTR(_27455);
    _mode_54117 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_54117)){
        _mode_54117 = (object)DBL_PTR(_mode_54117)->dbl;
    }
    _27455 = NOVALUE;

    /** inline.e:245		if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27457 = (_mode_54117 == 2LL);
    if (_27457 == 0) {
        _27458 = 0;
        goto L2; // [40] 66
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27459 = (object)*(((s1_ptr)_2)->base + _sym_54114);
    _2 = (object)SEQ_PTR(_27459);
    _27460 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27459 = NOVALUE;
    if (IS_ATOM_INT(_36NOVALUE_21613) && IS_ATOM_INT(_27460)){
        _27461 = (_36NOVALUE_21613 < _27460) ? -1 : (_36NOVALUE_21613 > _27460);
    }
    else{
        _27461 = compare(_36NOVALUE_21613, _27460);
    }
    _27460 = NOVALUE;
    _27458 = (_27461 != 0);
L2: 
    if (_27458 != 0) {
        goto L3; // [66] 117
    }
    if (_36TRANSLATE_21361 == 0) {
        _27463 = 0;
        goto L4; // [72] 86
    }
    _27464 = (_mode_54117 == 3LL);
    _27463 = (_27464 != 0);
L4: 
    if (_27463 == 0) {
        DeRef(_27465);
        _27465 = 0;
        goto L5; // [86] 112
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27466 = (object)*(((s1_ptr)_2)->base + _sym_54114);
    _2 = (object)SEQ_PTR(_27466);
    _27467 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27466 = NOVALUE;
    if (IS_ATOM_INT(_27467) && IS_ATOM_INT(_36NOVALUE_21613)){
        _27468 = (_27467 < _36NOVALUE_21613) ? -1 : (_27467 > _36NOVALUE_21613);
    }
    else{
        _27468 = compare(_27467, _36NOVALUE_21613);
    }
    _27467 = NOVALUE;
    _27465 = (_27468 != 0);
L5: 
    if (_27465 == 0)
    {
        _27465 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27465 = NOVALUE;
    }
L3: 

    /** inline.e:247			return 1*/
    DeRef(_27457);
    _27457 = NOVALUE;
    DeRef(_27464);
    _27464 = NOVALUE;
    return 1LL;
    goto L7; // [123] 133
L6: 

    /** inline.e:249			return 0*/
    DeRef(_27457);
    _27457 = NOVALUE;
    DeRef(_27464);
    _27464 = NOVALUE;
    return 0LL;
L7: 
    ;
}


object _67returnf(object _pc_54164)
{
    object _retsym_54166 = NOVALUE;
    object _code_54199 = NOVALUE;
    object _ret_pc_54200 = NOVALUE;
    object _code_54245 = NOVALUE;
    object _ret_pc_54259 = NOVALUE;
    object _27541 = NOVALUE;
    object _27540 = NOVALUE;
    object _27538 = NOVALUE;
    object _27536 = NOVALUE;
    object _27535 = NOVALUE;
    object _27533 = NOVALUE;
    object _27532 = NOVALUE;
    object _27530 = NOVALUE;
    object _27529 = NOVALUE;
    object _27528 = NOVALUE;
    object _27526 = NOVALUE;
    object _27525 = NOVALUE;
    object _27523 = NOVALUE;
    object _27521 = NOVALUE;
    object _27520 = NOVALUE;
    object _27518 = NOVALUE;
    object _27517 = NOVALUE;
    object _27515 = NOVALUE;
    object _27514 = NOVALUE;
    object _27513 = NOVALUE;
    object _27511 = NOVALUE;
    object _27510 = NOVALUE;
    object _27509 = NOVALUE;
    object _27508 = NOVALUE;
    object _27507 = NOVALUE;
    object _27505 = NOVALUE;
    object _27504 = NOVALUE;
    object _27503 = NOVALUE;
    object _27502 = NOVALUE;
    object _27500 = NOVALUE;
    object _27498 = NOVALUE;
    object _27497 = NOVALUE;
    object _27496 = NOVALUE;
    object _27495 = NOVALUE;
    object _27494 = NOVALUE;
    object _27493 = NOVALUE;
    object _27492 = NOVALUE;
    object _27491 = NOVALUE;
    object _27490 = NOVALUE;
    object _27488 = NOVALUE;
    object _27487 = NOVALUE;
    object _27486 = NOVALUE;
    object _27484 = NOVALUE;
    object _27483 = NOVALUE;
    object _27482 = NOVALUE;
    object _27481 = NOVALUE;
    object _27480 = NOVALUE;
    object _27479 = NOVALUE;
    object _27477 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:259		symtab_index retsym = inline_code[pc+3]*/
    _27477 = _pc_54164 + 3LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _retsym_54166 = (object)*(((s1_ptr)_2)->base + _27477);
    if (!IS_ATOM_INT(_retsym_54166)){
        _retsym_54166 = (object)DBL_PTR(_retsym_54166)->dbl;
    }

    /** inline.e:260		if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27479 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27479 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27480 = (object)*(((s1_ptr)_2)->base + _27479);
    if (_27480 == 43LL)
    _27481 = 1;
    else if (IS_ATOM_INT(_27480) && IS_ATOM_INT(43LL))
    _27481 = 0;
    else
    _27481 = (compare(_27480, 43LL) == 0);
    _27480 = NOVALUE;
    if (_27481 == 0)
    {
        _27481 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27481 = NOVALUE;
    }

    /** inline.e:261			if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** inline.e:262				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27482 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27482 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27482);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159LL;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** inline.e:263			elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27483 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53891);
    _2 = (object)SEQ_PTR(_27483);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _27484 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _27484 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _27483 = NOVALUE;
    if (binary_op_a(NOTEQ, _27484, 27LL)){
        _27484 = NOVALUE;
        goto L4; // [78] 100
    }
    _27484 = NOVALUE;

    /** inline.e:264				replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27486 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27486 = 1;
    }
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27487 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27487 = 1;
    }
    RefDS(_22186);
    _67replace_code(_22186, _27486, _27487);
    _27486 = NOVALUE;
    _27487 = NOVALUE;
L4: 
L3: 
L1: 

    /** inline.e:270		if is_temp( retsym ) */
    _27488 = _67is_temp(_retsym_54166);
    if (IS_ATOM_INT(_27488)) {
        if (_27488 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27488)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27490 = _67is_literal(_retsym_54166);
    if (IS_ATOM_INT(_27490)) {
        _27491 = (_27490 == 0);
    }
    else {
        _27491 = unary_op(NOT, _27490);
    }
    DeRef(_27490);
    _27490 = NOVALUE;
    if (IS_ATOM_INT(_27491)) {
        if (_27491 == 0) {
            DeRef(_27492);
            _27492 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27491)->dbl == 0.0) {
            DeRef(_27492);
            _27492 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27493 = (object)*(((s1_ptr)_2)->base + _retsym_54166);
    _2 = (object)SEQ_PTR(_27493);
    _27494 = (object)*(((s1_ptr)_2)->base + 4LL);
    _27493 = NOVALUE;
    if (IS_ATOM_INT(_27494)) {
        _27495 = (_27494 <= 3LL);
    }
    else {
        _27495 = binary_op(LESSEQ, _27494, 3LL);
    }
    _27494 = NOVALUE;
    DeRef(_27492);
    if (IS_ATOM_INT(_27495))
    _27492 = (_27495 != 0);
    else
    _27492 = DBL_PTR(_27495)->dbl != 0.0;
L6: 
    if (_27492 == 0)
    {
        _27492 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27492 = NOVALUE;
    }
L5: 

    /** inline.e:272			sequence code = {}*/
    RefDS(_22186);
    DeRef(_code_54199);
    _code_54199 = _22186;

    /** inline.e:274			integer ret_pc = 0*/
    _ret_pc_54200 = 0LL;

    /** inline.e:276			if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27496 = find_from(_retsym_54166, _67inline_params_53882, 1LL);
    if (_27496 != 0) {
        DeRef(_27497);
        _27497 = 1;
        goto L8; // [171] 186
    }
    _27498 = find_from(_retsym_54166, _67proc_vars_53878, 1LL);
    _27497 = (_27498 != 0);
L8: 
    if (_27497 != 0)
    goto L9; // [186] 206
    _27497 = NOVALUE;

    /** inline.e:277				ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27500 = _67generic_symbol(_retsym_54166);
    RefDS(_67inline_code_53877);
    _ret_pc_54200 = _16rfind(_27500, _67inline_code_53877, _pc_54164);
    _27500 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_54200)) {
        _1 = (object)(DBL_PTR(_ret_pc_54200)->dbl);
        DeRefDS(_ret_pc_54200);
        _ret_pc_54200 = _1;
    }
L9: 

    /** inline.e:281			if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_54200 == 0) {
        goto LA; // [208] 277
    }
    _27503 = _ret_pc_54200 - 1LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27504 = (object)*(((s1_ptr)_2)->base + _27503);
    if (IS_ATOM_INT(_27504) && IS_ATOM_INT(30LL)){
        _27505 = (_27504 < 30LL) ? -1 : (_27504 > 30LL);
    }
    else{
        _27505 = compare(_27504, 30LL);
    }
    _27504 = NOVALUE;
    if (_27505 == 0)
    {
        _27505 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27505 = NOVALUE;
    }

    /** inline.e:282				inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27506);
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ret_pc_54200);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27506;
    DeRef(_1);

    /** inline.e:284				if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27507 = _ret_pc_54200 - 1LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27508 = (object)*(((s1_ptr)_2)->base + _27507);
    if (_27508 == 207LL)
    _27509 = 1;
    else if (IS_ATOM_INT(_27508) && IS_ATOM_INT(207LL))
    _27509 = 0;
    else
    _27509 = (compare(_27508, 207LL) == 0);
    _27508 = NOVALUE;
    if (_27509 == 0)
    {
        _27509 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27509 = NOVALUE;
    }

    /** inline.e:287					inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27510 = _ret_pc_54200 - 2LL;
    RefDS(_27506);
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27510);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27506;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** inline.e:290				code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27511 = _67generic_symbol(_retsym_54166);
    _0 = _code_54199;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    ((intptr_t*)_2)[2] = _27511;
    RefDS(_27506);
    ((intptr_t*)_2)[3] = _27506;
    _code_54199 = MAKE_SEQ(_1);
    DeRef(_0);
    _27511 = NOVALUE;
LB: 

    /** inline.e:293			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27513 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27513 = 1;
    }
    _27514 = 3LL + _36TRANSLATE_21361;
    _27515 = _27513 - _27514;
    _27513 = NOVALUE;
    _27514 = NOVALUE;
    if (_pc_54164 == _27515)
    goto LC; // [309] 330

    /** inline.e:294				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27517 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23LL;
    ((intptr_t *)_2)[2] = _27517;
    _27518 = MAKE_SEQ(_1);
    _27517 = NOVALUE;
    Concat((object_ptr)&_code_54199, _code_54199, _27518);
    DeRefDS(_27518);
    _27518 = NOVALUE;
LC: 

    /** inline.e:298			replace_code( code, pc, pc + 3 )*/
    _27520 = _pc_54164 + 3LL;
    if ((object)((uintptr_t)_27520 + (uintptr_t)HIGH_BITS) >= 0){
        _27520 = NewDouble((eudouble)_27520);
    }
    RefDS(_code_54199);
    _67replace_code(_code_54199, _pc_54164, _27520);
    _27520 = NOVALUE;

    /** inline.e:299			ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27521 = MAKE_SEQ(_1);
    _ret_pc_54200 = find_from(_27521, _67inline_code_53877, _pc_54164);
    DeRefDS(_27521);
    _27521 = NOVALUE;

    /** inline.e:300			if ret_pc then*/
    if (_ret_pc_54200 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** inline.e:301				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_54200 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27525 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27525 = 1;
    }
    _27526 = _27525 + 1;
    _27525 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27526;
    if( _1 != _27526 ){
        DeRef(_1);
    }
    _27526 = NOVALUE;
    _27523 = NOVALUE;
LD: 

    /** inline.e:303			return 1*/
    DeRef(_code_54199);
    DeRef(_27503);
    _27503 = NOVALUE;
    DeRef(_27510);
    _27510 = NOVALUE;
    DeRef(_27488);
    _27488 = NOVALUE;
    DeRef(_27507);
    _27507 = NOVALUE;
    DeRef(_27495);
    _27495 = NOVALUE;
    DeRef(_27515);
    _27515 = NOVALUE;
    DeRef(_27491);
    _27491 = NOVALUE;
    DeRef(_27477);
    _27477 = NOVALUE;
    return 1LL;
    goto LE; // [390] 502
L7: 

    /** inline.e:306			sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_54245;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    ((intptr_t*)_2)[2] = _retsym_54166;
    RefDS(_27506);
    ((intptr_t*)_2)[3] = _27506;
    _code_54245 = MAKE_SEQ(_1);
    DeRef(_0);

    /** inline.e:307			if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27528 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27528 = 1;
    }
    _27529 = 3LL + _36TRANSLATE_21361;
    _27530 = _27528 - _27529;
    _27528 = NOVALUE;
    _27529 = NOVALUE;
    if (_pc_54164 == _27530)
    goto LF; // [420] 441

    /** inline.e:308				code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27532 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23LL;
    ((intptr_t *)_2)[2] = _27532;
    _27533 = MAKE_SEQ(_1);
    _27532 = NOVALUE;
    Concat((object_ptr)&_code_54245, _code_54245, _27533);
    DeRefDS(_27533);
    _27533 = NOVALUE;
LF: 

    /** inline.e:312			replace_code( code, pc, pc + 3 )*/
    _27535 = _pc_54164 + 3LL;
    if ((object)((uintptr_t)_27535 + (uintptr_t)HIGH_BITS) >= 0){
        _27535 = NewDouble((eudouble)_27535);
    }
    RefDS(_code_54245);
    _67replace_code(_code_54245, _pc_54164, _27535);
    _27535 = NOVALUE;

    /** inline.e:313			integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = -1LL;
    _27536 = MAKE_SEQ(_1);
    _ret_pc_54259 = find_from(_27536, _67inline_code_53877, _pc_54164);
    DeRefDS(_27536);
    _27536 = NOVALUE;

    /** inline.e:314			if ret_pc then*/
    if (_ret_pc_54259 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** inline.e:315				inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ret_pc_54259 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27540 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27540 = 1;
    }
    _27541 = _27540 + 1;
    _27540 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27541;
    if( _1 != _27541 ){
        DeRef(_1);
    }
    _27541 = NOVALUE;
    _27538 = NOVALUE;
L10: 

    /** inline.e:317			return 1*/
    DeRef(_code_54245);
    DeRef(_27503);
    _27503 = NOVALUE;
    DeRef(_27510);
    _27510 = NOVALUE;
    DeRef(_27530);
    _27530 = NOVALUE;
    DeRef(_27488);
    _27488 = NOVALUE;
    DeRef(_27507);
    _27507 = NOVALUE;
    DeRef(_27495);
    _27495 = NOVALUE;
    DeRef(_27515);
    _27515 = NOVALUE;
    DeRef(_27491);
    _27491 = NOVALUE;
    DeRef(_27477);
    _27477 = NOVALUE;
    return 1LL;
LE: 

    /** inline.e:319		return 0*/
    DeRef(_27503);
    _27503 = NOVALUE;
    DeRef(_27510);
    _27510 = NOVALUE;
    DeRef(_27530);
    _27530 = NOVALUE;
    DeRef(_27488);
    _27488 = NOVALUE;
    DeRef(_27507);
    _27507 = NOVALUE;
    DeRef(_27495);
    _27495 = NOVALUE;
    DeRef(_27515);
    _27515 = NOVALUE;
    DeRef(_27491);
    _27491 = NOVALUE;
    DeRef(_27477);
    _27477 = NOVALUE;
    return 0LL;
    ;
}


object _67inline_op(object _pc_54269)
{
    object _op_54270 = NOVALUE;
    object _code_54275 = NOVALUE;
    object _stlen_54308 = NOVALUE;
    object _file_54313 = NOVALUE;
    object _ok_54318 = NOVALUE;
    object _original_table_54341 = NOVALUE;
    object _jump_table_54345 = NOVALUE;
    object _27602 = NOVALUE;
    object _27601 = NOVALUE;
    object _27600 = NOVALUE;
    object _27599 = NOVALUE;
    object _27598 = NOVALUE;
    object _27597 = NOVALUE;
    object _27596 = NOVALUE;
    object _27595 = NOVALUE;
    object _27594 = NOVALUE;
    object _27593 = NOVALUE;
    object _27592 = NOVALUE;
    object _27591 = NOVALUE;
    object _27588 = NOVALUE;
    object _27587 = NOVALUE;
    object _27586 = NOVALUE;
    object _27585 = NOVALUE;
    object _27583 = NOVALUE;
    object _27581 = NOVALUE;
    object _27580 = NOVALUE;
    object _27578 = NOVALUE;
    object _27574 = NOVALUE;
    object _27573 = NOVALUE;
    object _27572 = NOVALUE;
    object _27571 = NOVALUE;
    object _27570 = NOVALUE;
    object _27569 = NOVALUE;
    object _27566 = NOVALUE;
    object _27565 = NOVALUE;
    object _27563 = NOVALUE;
    object _27562 = NOVALUE;
    object _27560 = NOVALUE;
    object _27558 = NOVALUE;
    object _27557 = NOVALUE;
    object _27556 = NOVALUE;
    object _27555 = NOVALUE;
    object _27554 = NOVALUE;
    object _27553 = NOVALUE;
    object _27552 = NOVALUE;
    object _27550 = NOVALUE;
    object _27549 = NOVALUE;
    object _27548 = NOVALUE;
    object _27546 = NOVALUE;
    object _27545 = NOVALUE;
    object _27544 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:324		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _op_54270 = (object)*(((s1_ptr)_2)->base + _pc_54269);
    if (!IS_ATOM_INT(_op_54270))
    _op_54270 = (object)DBL_PTR(_op_54270)->dbl;

    /** inline.e:326		if op = RETURNP then*/
    if (_op_54270 != 29LL)
    goto L1; // [15] 150

    /** inline.e:333			sequence code = ""*/
    RefDS(_22186);
    DeRef(_code_54275);
    _code_54275 = _22186;

    /** inline.e:335			if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27544 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27544 = 1;
    }
    _27545 = _27544 - 1LL;
    _27544 = NOVALUE;
    _27546 = _27545 - _36TRANSLATE_21361;
    _27545 = NOVALUE;
    if (_pc_54269 == _27546)
    goto L2; // [43] 92

    /** inline.e:336				code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27548 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27548 = 1;
    }
    _27549 = _27548 + 1;
    _27548 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = _27549;
    _27550 = MAKE_SEQ(_1);
    _27549 = NOVALUE;
    DeRefDS(_code_54275);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 23LL;
    ((intptr_t *)_2)[2] = _27550;
    _code_54275 = MAKE_SEQ(_1);
    _27550 = NOVALUE;

    /** inline.e:337				if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** inline.e:338					inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27552 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27552 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27552);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159LL;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** inline.e:341			elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_36TRANSLATE_21361 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27554 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27554 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27555 = (object)*(((s1_ptr)_2)->base + _27554);
    if (IS_ATOM_INT(_27555)) {
        _27556 = (_27555 == 43LL);
    }
    else {
        _27556 = binary_op(EQUALS, _27555, 43LL);
    }
    _27555 = NOVALUE;
    if (_27556 == 0) {
        DeRef(_27556);
        _27556 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27556) && DBL_PTR(_27556)->dbl == 0.0){
            DeRef(_27556);
            _27556 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27556);
        _27556 = NOVALUE;
    }
    DeRef(_27556);
    _27556 = NOVALUE;

    /** inline.e:342				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27557 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27557 = 1;
    }
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27557);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 159LL;
    DeRef(_1);
L4: 
L3: 

    /** inline.e:344			replace_code( code, pc, pc + 2 )*/
    _27558 = _pc_54269 + 2LL;
    if ((object)((uintptr_t)_27558 + (uintptr_t)HIGH_BITS) >= 0){
        _27558 = NewDouble((eudouble)_27558);
    }
    RefDS(_code_54275);
    _67replace_code(_code_54275, _pc_54269, _27558);
    _27558 = NOVALUE;
    DeRefDS(_code_54275);
    _code_54275 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** inline.e:346		elsif op = RETURNF then*/
    if (_op_54270 != 28LL)
    goto L6; // [154] 171

    /** inline.e:347			return returnf( pc )*/
    _27560 = _67returnf(_pc_54269);
    DeRef(_27546);
    _27546 = NOVALUE;
    return _27560;
    goto L5; // [168] 526
L6: 

    /** inline.e:349		elsif op = ROUTINE_ID then*/
    if (_op_54270 != 134LL)
    goto L7; // [175] 273

    /** inline.e:351			integer*/

    /** inline.e:352				stlen = inline_code[pc+2+TRANSLATE],*/
    _27562 = _pc_54269 + 2LL;
    if ((object)((uintptr_t)_27562 + (uintptr_t)HIGH_BITS) >= 0){
        _27562 = NewDouble((eudouble)_27562);
    }
    if (IS_ATOM_INT(_27562)) {
        _27563 = _27562 + _36TRANSLATE_21361;
    }
    else {
        _27563 = NewDouble(DBL_PTR(_27562)->dbl + (eudouble)_36TRANSLATE_21361);
    }
    DeRef(_27562);
    _27562 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!IS_ATOM_INT(_27563)){
        _stlen_54308 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27563)->dbl));
    }
    else{
        _stlen_54308 = (object)*(((s1_ptr)_2)->base + _27563);
    }
    if (!IS_ATOM_INT(_stlen_54308))
    _stlen_54308 = (object)DBL_PTR(_stlen_54308)->dbl;

    /** inline.e:353				file  = inline_code[pc+4+TRANSLATE],*/
    _27565 = _pc_54269 + 4LL;
    if ((object)((uintptr_t)_27565 + (uintptr_t)HIGH_BITS) >= 0){
        _27565 = NewDouble((eudouble)_27565);
    }
    if (IS_ATOM_INT(_27565)) {
        _27566 = _27565 + _36TRANSLATE_21361;
    }
    else {
        _27566 = NewDouble(DBL_PTR(_27565)->dbl + (eudouble)_36TRANSLATE_21361);
    }
    DeRef(_27565);
    _27565 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!IS_ATOM_INT(_27566)){
        _file_54313 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27566)->dbl));
    }
    else{
        _file_54313 = (object)*(((s1_ptr)_2)->base + _27566);
    }
    if (!IS_ATOM_INT(_file_54313))
    _file_54313 = (object)DBL_PTR(_file_54313)->dbl;

    /** inline.e:354				ok    = adjust_il( pc, op )*/
    _ok_54318 = _67adjust_il(_pc_54269, _op_54270);
    if (!IS_ATOM_INT(_ok_54318)) {
        _1 = (object)(DBL_PTR(_ok_54318)->dbl);
        DeRefDS(_ok_54318);
        _ok_54318 = _1;
    }

    /** inline.e:355			inline_code[pc+2+TRANSLATE] = stlen*/
    _27569 = _pc_54269 + 2LL;
    if ((object)((uintptr_t)_27569 + (uintptr_t)HIGH_BITS) >= 0){
        _27569 = NewDouble((eudouble)_27569);
    }
    if (IS_ATOM_INT(_27569)) {
        _27570 = _27569 + _36TRANSLATE_21361;
    }
    else {
        _27570 = NewDouble(DBL_PTR(_27569)->dbl + (eudouble)_36TRANSLATE_21361);
    }
    DeRef(_27569);
    _27569 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27570))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27570)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27570);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _stlen_54308;
    DeRef(_1);

    /** inline.e:356			inline_code[pc+4+TRANSLATE] = file*/
    _27571 = _pc_54269 + 4LL;
    if ((object)((uintptr_t)_27571 + (uintptr_t)HIGH_BITS) >= 0){
        _27571 = NewDouble((eudouble)_27571);
    }
    if (IS_ATOM_INT(_27571)) {
        _27572 = _27571 + _36TRANSLATE_21361;
    }
    else {
        _27572 = NewDouble(DBL_PTR(_27571)->dbl + (eudouble)_36TRANSLATE_21361);
    }
    DeRef(_27571);
    _27571 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27572))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_27572)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _27572);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_54313;
    DeRef(_1);

    /** inline.e:358			return ok*/
    DeRef(_27572);
    _27572 = NOVALUE;
    DeRef(_27563);
    _27563 = NOVALUE;
    DeRef(_27546);
    _27546 = NOVALUE;
    DeRef(_27566);
    _27566 = NOVALUE;
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27560);
    _27560 = NOVALUE;
    return _ok_54318;
    goto L5; // [270] 526
L7: 

    /** inline.e:360		elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (object)SEQ_PTR(_66op_info_24555);
    _27573 = (object)*(((s1_ptr)_2)->base + _op_54270);
    _2 = (object)SEQ_PTR(_27573);
    _27574 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27573 = NOVALUE;
    if (binary_op_a(NOTEQ, _27574, 1LL)){
        _27574 = NOVALUE;
        goto L8; // [289] 397
    }
    _27574 = NOVALUE;

    /** inline.e:361			switch op do*/
    _0 = _op_54270;
    switch ( _0 ){ 

        /** inline.e:362				case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** inline.e:364					symtab_index original_table = inline_code[pc + 3]*/
        _27578 = _pc_54269 + 3LL;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _original_table_54341 = (object)*(((s1_ptr)_2)->base + _27578);
        if (!IS_ATOM_INT(_original_table_54341)){
            _original_table_54341 = (object)DBL_PTR(_original_table_54341)->dbl;
        }

        /** inline.e:365					symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_37SymTab_15637)){
                _27580 = SEQ_PTR(_37SymTab_15637)->length;
        }
        else {
            _27580 = 1;
        }
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2LL;
        ((intptr_t *)_2)[2] = _27580;
        _27581 = MAKE_SEQ(_1);
        _27580 = NOVALUE;
        _jump_table_54345 = _54NewStringSym(_27581);
        _27581 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_54345)) {
            _1 = (object)(DBL_PTR(_jump_table_54345)->dbl);
            DeRefDS(_jump_table_54345);
            _jump_table_54345 = _1;
        }

        /** inline.e:366					SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_jump_table_54345 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27585 = (object)*(((s1_ptr)_2)->base + _original_table_54341);
        _2 = (object)SEQ_PTR(_27585);
        _27586 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27585 = NOVALUE;
        Ref(_27586);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27586;
        if( _1 != _27586 ){
            DeRef(_1);
        }
        _27586 = NOVALUE;
        _27583 = NOVALUE;

        /** inline.e:367					inline_code[pc+3] = jump_table*/
        _27587 = _pc_54269 + 3LL;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53877 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27587);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _jump_table_54345;
        DeRef(_1);
    ;}
    /** inline.e:369			return adjust_il( pc, op )*/
    _27588 = _67adjust_il(_pc_54269, _op_54270);
    DeRef(_27572);
    _27572 = NOVALUE;
    DeRef(_27578);
    _27578 = NOVALUE;
    DeRef(_27563);
    _27563 = NOVALUE;
    DeRef(_27546);
    _27546 = NOVALUE;
    DeRef(_27566);
    _27566 = NOVALUE;
    DeRef(_27587);
    _27587 = NOVALUE;
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27560);
    _27560 = NOVALUE;
    return _27588;
    goto L5; // [394] 526
L8: 

    /** inline.e:372			switch op with fallthru do*/
    _0 = _op_54270;
    switch ( _0 ){ 

        /** inline.e:373				case REF_TEMP then*/
        case 207:

        /** inline.e:374					inline_code[pc+1] = {INLINE_TARGET}*/
        _27591 = _pc_54269 + 1;
        RefDS(_27506);
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67inline_code_53877 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _27591);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _27506;
        DeRef(_1);

        /** inline.e:376				case CONCAT_N then*/
        case 157:
        case 31:

        /** inline.e:379					if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27592 = _pc_54269 + 2LL;
        if ((object)((uintptr_t)_27592 + (uintptr_t)HIGH_BITS) >= 0){
            _27592 = NewDouble((eudouble)_27592);
        }
        _27593 = _pc_54269 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27594 = (object)*(((s1_ptr)_2)->base + _27593);
        if (IS_ATOM_INT(_27592) && IS_ATOM_INT(_27594)) {
            _27595 = _27592 + _27594;
            if ((object)((uintptr_t)_27595 + (uintptr_t)HIGH_BITS) >= 0){
                _27595 = NewDouble((eudouble)_27595);
            }
        }
        else {
            _27595 = binary_op(PLUS, _27592, _27594);
        }
        DeRef(_27592);
        _27592 = NOVALUE;
        _27594 = NOVALUE;
        _27596 = _67check_for_param(_27595);
        _27595 = NOVALUE;
        if (_27596 == 0) {
            DeRef(_27596);
            _27596 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27596) && DBL_PTR(_27596)->dbl == 0.0){
                DeRef(_27596);
                _27596 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27596);
            _27596 = NOVALUE;
        }
        DeRef(_27596);
        _27596 = NOVALUE;
L9: 

        /** inline.e:383					for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27597 = _pc_54269 + 2LL;
        if ((object)((uintptr_t)_27597 + (uintptr_t)HIGH_BITS) >= 0){
            _27597 = NewDouble((eudouble)_27597);
        }
        _27598 = _pc_54269 + 2LL;
        if ((object)((uintptr_t)_27598 + (uintptr_t)HIGH_BITS) >= 0){
            _27598 = NewDouble((eudouble)_27598);
        }
        _27599 = _pc_54269 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27600 = (object)*(((s1_ptr)_2)->base + _27599);
        if (IS_ATOM_INT(_27598) && IS_ATOM_INT(_27600)) {
            _27601 = _27598 + _27600;
            if ((object)((uintptr_t)_27601 + (uintptr_t)HIGH_BITS) >= 0){
                _27601 = NewDouble((eudouble)_27601);
            }
        }
        else {
            _27601 = binary_op(PLUS, _27598, _27600);
        }
        DeRef(_27598);
        _27598 = NOVALUE;
        _27600 = NOVALUE;
        {
            object _i_54377;
            Ref(_27597);
            _i_54377 = _27597;
LA: 
            if (binary_op_a(GREATER, _i_54377, _27601)){
                goto LB; // [478] 508
            }

            /** inline.e:384						if not adjust_symbol( i ) then*/
            Ref(_i_54377);
            _27602 = _67adjust_symbol(_i_54377);
            if (IS_ATOM_INT(_27602)) {
                if (_27602 != 0){
                    DeRef(_27602);
                    _27602 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27602)->dbl != 0.0){
                    DeRef(_27602);
                    _27602 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27602);
            _27602 = NOVALUE;

            /** inline.e:385							return 0*/
            DeRef(_i_54377);
            DeRef(_27572);
            _27572 = NOVALUE;
            DeRef(_27578);
            _27578 = NOVALUE;
            DeRef(_27563);
            _27563 = NOVALUE;
            DeRef(_27546);
            _27546 = NOVALUE;
            DeRef(_27593);
            _27593 = NOVALUE;
            DeRef(_27566);
            _27566 = NOVALUE;
            DeRef(_27587);
            _27587 = NOVALUE;
            DeRef(_27591);
            _27591 = NOVALUE;
            DeRef(_27597);
            _27597 = NOVALUE;
            DeRef(_27570);
            _27570 = NOVALUE;
            DeRef(_27599);
            _27599 = NOVALUE;
            DeRef(_27601);
            _27601 = NOVALUE;
            DeRef(_27588);
            _27588 = NOVALUE;
            DeRef(_27560);
            _27560 = NOVALUE;
            return 0LL;
LC: 

            /** inline.e:388					end for*/
            _0 = _i_54377;
            if (IS_ATOM_INT(_i_54377)) {
                _i_54377 = _i_54377 + 1LL;
                if ((object)((uintptr_t)_i_54377 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54377 = NewDouble((eudouble)_i_54377);
                }
            }
            else {
                _i_54377 = binary_op_a(PLUS, _i_54377, 1LL);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_54377);
        }

        /** inline.e:389					return 1*/
        DeRef(_27572);
        _27572 = NOVALUE;
        DeRef(_27578);
        _27578 = NOVALUE;
        DeRef(_27563);
        _27563 = NOVALUE;
        DeRef(_27546);
        _27546 = NOVALUE;
        DeRef(_27593);
        _27593 = NOVALUE;
        DeRef(_27566);
        _27566 = NOVALUE;
        DeRef(_27587);
        _27587 = NOVALUE;
        DeRef(_27591);
        _27591 = NOVALUE;
        DeRef(_27597);
        _27597 = NOVALUE;
        DeRef(_27570);
        _27570 = NOVALUE;
        DeRef(_27599);
        _27599 = NOVALUE;
        DeRef(_27601);
        _27601 = NOVALUE;
        DeRef(_27588);
        _27588 = NOVALUE;
        DeRef(_27560);
        _27560 = NOVALUE;
        return 1LL;

        /** inline.e:390				case else*/
        default:

        /** inline.e:391					return 0*/
        DeRef(_27572);
        _27572 = NOVALUE;
        DeRef(_27578);
        _27578 = NOVALUE;
        DeRef(_27563);
        _27563 = NOVALUE;
        DeRef(_27546);
        _27546 = NOVALUE;
        DeRef(_27593);
        _27593 = NOVALUE;
        DeRef(_27566);
        _27566 = NOVALUE;
        DeRef(_27587);
        _27587 = NOVALUE;
        DeRef(_27591);
        _27591 = NOVALUE;
        DeRef(_27597);
        _27597 = NOVALUE;
        DeRef(_27570);
        _27570 = NOVALUE;
        DeRef(_27599);
        _27599 = NOVALUE;
        DeRef(_27601);
        _27601 = NOVALUE;
        DeRef(_27588);
        _27588 = NOVALUE;
        DeRef(_27560);
        _27560 = NOVALUE;
        return 0LL;
    ;}L5: 

    /** inline.e:394		return 1*/
    DeRef(_27572);
    _27572 = NOVALUE;
    DeRef(_27578);
    _27578 = NOVALUE;
    DeRef(_27563);
    _27563 = NOVALUE;
    DeRef(_27546);
    _27546 = NOVALUE;
    DeRef(_27593);
    _27593 = NOVALUE;
    DeRef(_27566);
    _27566 = NOVALUE;
    DeRef(_27587);
    _27587 = NOVALUE;
    DeRef(_27591);
    _27591 = NOVALUE;
    DeRef(_27597);
    _27597 = NOVALUE;
    DeRef(_27570);
    _27570 = NOVALUE;
    DeRef(_27599);
    _27599 = NOVALUE;
    DeRef(_27601);
    _27601 = NOVALUE;
    DeRef(_27588);
    _27588 = NOVALUE;
    DeRef(_27560);
    _27560 = NOVALUE;
    return 1LL;
    ;
}


void _67restore_code()
{
    object _27604 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:399		if length( temp_code ) then*/
    if (IS_SEQUENCE(_67temp_code_54387)){
            _27604 = SEQ_PTR(_67temp_code_54387)->length;
    }
    else {
        _27604 = 1;
    }
    if (_27604 == 0)
    {
        _27604 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27604 = NOVALUE;
    }

    /** inline.e:400			Code = temp_code*/
    RefDS(_67temp_code_54387);
    DeRef(_36Code_21851);
    _36Code_21851 = _67temp_code_54387;
L1: 

    /** inline.e:402	end procedure*/
    return;
    ;
}


void _67check_inline(object _sub_54396)
{
    object _pc_54425 = NOVALUE;
    object _s_54427 = NOVALUE;
    object _backpatch_op_54465 = NOVALUE;
    object _op_54469 = NOVALUE;
    object _rtn_idx_54480 = NOVALUE;
    object _args_54485 = NOVALUE;
    object _args_54517 = NOVALUE;
    object _values_54546 = NOVALUE;
    object _27691 = NOVALUE;
    object _27690 = NOVALUE;
    object _27688 = NOVALUE;
    object _27685 = NOVALUE;
    object _27683 = NOVALUE;
    object _27682 = NOVALUE;
    object _27681 = NOVALUE;
    object _27679 = NOVALUE;
    object _27678 = NOVALUE;
    object _27677 = NOVALUE;
    object _27676 = NOVALUE;
    object _27675 = NOVALUE;
    object _27674 = NOVALUE;
    object _27673 = NOVALUE;
    object _27672 = NOVALUE;
    object _27671 = NOVALUE;
    object _27669 = NOVALUE;
    object _27668 = NOVALUE;
    object _27667 = NOVALUE;
    object _27666 = NOVALUE;
    object _27665 = NOVALUE;
    object _27663 = NOVALUE;
    object _27662 = NOVALUE;
    object _27661 = NOVALUE;
    object _27660 = NOVALUE;
    object _27659 = NOVALUE;
    object _27657 = NOVALUE;
    object _27656 = NOVALUE;
    object _27655 = NOVALUE;
    object _27654 = NOVALUE;
    object _27653 = NOVALUE;
    object _27652 = NOVALUE;
    object _27651 = NOVALUE;
    object _27650 = NOVALUE;
    object _27649 = NOVALUE;
    object _27648 = NOVALUE;
    object _27647 = NOVALUE;
    object _27646 = NOVALUE;
    object _27645 = NOVALUE;
    object _27644 = NOVALUE;
    object _27642 = NOVALUE;
    object _27639 = NOVALUE;
    object _27634 = NOVALUE;
    object _27632 = NOVALUE;
    object _27629 = NOVALUE;
    object _27628 = NOVALUE;
    object _27627 = NOVALUE;
    object _27626 = NOVALUE;
    object _27625 = NOVALUE;
    object _27624 = NOVALUE;
    object _27623 = NOVALUE;
    object _27622 = NOVALUE;
    object _27620 = NOVALUE;
    object _27618 = NOVALUE;
    object _27617 = NOVALUE;
    object _27615 = NOVALUE;
    object _27613 = NOVALUE;
    object _27611 = NOVALUE;
    object _27609 = NOVALUE;
    object _27608 = NOVALUE;
    object _27607 = NOVALUE;
    object _27606 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:411		if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_36OpTrace_21832 != 0) {
        goto L1; // [7] 34
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27606 = (object)*(((s1_ptr)_2)->base + _sub_54396);
    _2 = (object)SEQ_PTR(_27606);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _27607 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _27607 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _27606 = NOVALUE;
    if (IS_ATOM_INT(_27607)) {
        _27608 = (_27607 == 504LL);
    }
    else {
        _27608 = binary_op(EQUALS, _27607, 504LL);
    }
    _27607 = NOVALUE;
    if (_27608 == 0) {
        DeRef(_27608);
        _27608 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27608) && DBL_PTR(_27608)->dbl == 0.0){
            DeRef(_27608);
            _27608 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27608);
        _27608 = NOVALUE;
    }
    DeRef(_27608);
    _27608 = NOVALUE;
L1: 

    /** inline.e:412			return*/
    DeRefi(_backpatch_op_54465);
    return;
L2: 

    /** inline.e:414		inline_sub      = sub*/
    _67inline_sub_53891 = _sub_54396;

    /** inline.e:415		if get_fwdref_count() then*/
    _27609 = _44get_fwdref_count();
    if (_27609 == 0) {
        DeRef(_27609);
        _27609 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27609) && DBL_PTR(_27609)->dbl == 0.0){
            DeRef(_27609);
            _27609 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27609);
        _27609 = NOVALUE;
    }
    DeRef(_27609);
    _27609 = NOVALUE;

    /** inline.e:416			defer()*/
    _67defer();

    /** inline.e:417			return*/
    DeRefi(_backpatch_op_54465);
    return;
L3: 

    /** inline.e:419		temp_code = ""*/
    RefDS(_22186);
    DeRef(_67temp_code_54387);
    _67temp_code_54387 = _22186;

    /** inline.e:420		if sub != CurrentSub then*/
    if (_sub_54396 == _36CurrentSub_21767)
    goto L4; // [76] 99

    /** inline.e:421			Code = SymTab[sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27611 = (object)*(((s1_ptr)_2)->base + _sub_54396);
    DeRef(_36Code_21851);
    _2 = (object)SEQ_PTR(_27611);
    if (!IS_ATOM_INT(_36S_CODE_21408)){
        _36Code_21851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    }
    else{
        _36Code_21851 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
    }
    Ref(_36Code_21851);
    _27611 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** inline.e:423			temp_code = Code*/
    RefDS(_36Code_21851);
    DeRef(_67temp_code_54387);
    _67temp_code_54387 = _36Code_21851;
L5: 

    /** inline.e:426		if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_36Code_21851)){
            _27613 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _27613 = 1;
    }
    if (_27613 <= _36OpInline_21837)
    goto L6; // [118] 128

    /** inline.e:427			return*/
    DeRefi(_backpatch_op_54465);
    return;
L6: 

    /** inline.e:430		inline_code     = Code*/
    RefDS(_36Code_21851);
    DeRef(_67inline_code_53877);
    _67inline_code_53877 = _36Code_21851;

    /** inline.e:431		return_gotos    = 0*/
    _67return_gotos_53886 = 0LL;

    /** inline.e:432		prev_pc         = 1*/
    _67prev_pc_53885 = 1LL;

    /** inline.e:433		proc_vars       = {}*/
    RefDS(_22186);
    DeRefi(_67proc_vars_53878);
    _67proc_vars_53878 = _22186;

    /** inline.e:434		inline_temps    = {}*/
    RefDS(_22186);
    DeRef(_67inline_temps_53879);
    _67inline_temps_53879 = _22186;

    /** inline.e:435		inline_params   = {}*/
    RefDS(_22186);
    DeRefi(_67inline_params_53882);
    _67inline_params_53882 = _22186;

    /** inline.e:436		assigned_params = {}*/
    RefDS(_22186);
    DeRef(_67assigned_params_53883);
    _67assigned_params_53883 = _22186;

    /** inline.e:438		integer pc = 1*/
    _pc_54425 = 1LL;

    /** inline.e:439		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27615 = (object)*(((s1_ptr)_2)->base + _sub_54396);
    _2 = (object)SEQ_PTR(_27615);
    _s_54427 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_54427)){
        _s_54427 = (object)DBL_PTR(_s_54427)->dbl;
    }
    _27615 = NOVALUE;

    /** inline.e:440		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27617 = (object)*(((s1_ptr)_2)->base + _sub_54396);
    _2 = (object)SEQ_PTR(_27617);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _27618 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _27618 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _27617 = NOVALUE;
    {
        object _p_54433;
        _p_54433 = 1LL;
L7: 
        if (binary_op_a(GREATER, _p_54433, _27618)){
            goto L8; // [210] 248
        }

        /** inline.e:441			inline_params &= s*/
        Append(&_67inline_params_53882, _67inline_params_53882, _s_54427);

        /** inline.e:442			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27620 = (object)*(((s1_ptr)_2)->base + _s_54427);
        _2 = (object)SEQ_PTR(_27620);
        _s_54427 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_54427)){
            _s_54427 = (object)DBL_PTR(_s_54427)->dbl;
        }
        _27620 = NOVALUE;

        /** inline.e:443		end for*/
        _0 = _p_54433;
        if (IS_ATOM_INT(_p_54433)) {
            _p_54433 = _p_54433 + 1LL;
            if ((object)((uintptr_t)_p_54433 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54433 = NewDouble((eudouble)_p_54433);
            }
        }
        else {
            _p_54433 = binary_op_a(PLUS, _p_54433, 1LL);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_54433);
    }

    /** inline.e:445		while s != 0 and */
L9: 
    _27622 = (_s_54427 != 0LL);
    if (_27622 == 0) {
        goto LA; // [257] 335
    }
    _27624 = _54sym_scope(_s_54427);
    if (IS_ATOM_INT(_27624)) {
        _27625 = (_27624 <= 3LL);
    }
    else {
        _27625 = binary_op(LESSEQ, _27624, 3LL);
    }
    DeRef(_27624);
    _27624 = NOVALUE;
    if (IS_ATOM_INT(_27625)) {
        if (_27625 != 0) {
            DeRef(_27626);
            _27626 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27625)->dbl != 0.0) {
            DeRef(_27626);
            _27626 = 1;
            goto LB; // [271] 289
        }
    }
    _27627 = _54sym_scope(_s_54427);
    if (IS_ATOM_INT(_27627)) {
        _27628 = (_27627 == 9LL);
    }
    else {
        _27628 = binary_op(EQUALS, _27627, 9LL);
    }
    DeRef(_27627);
    _27627 = NOVALUE;
    DeRef(_27626);
    if (IS_ATOM_INT(_27628))
    _27626 = (_27628 != 0);
    else
    _27626 = DBL_PTR(_27628)->dbl != 0.0;
LB: 
    if (_27626 == 0)
    {
        _27626 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27626 = NOVALUE;
    }

    /** inline.e:447			if sym_scope( s ) != SC_UNDEFINED then*/
    _27629 = _54sym_scope(_s_54427);
    if (binary_op_a(EQUALS, _27629, 9LL)){
        DeRef(_27629);
        _27629 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27629);
    _27629 = NOVALUE;

    /** inline.e:448				proc_vars &= s*/
    Append(&_67proc_vars_53878, _67proc_vars_53878, _s_54427);
LC: 

    /** inline.e:451			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27632 = (object)*(((s1_ptr)_2)->base + _s_54427);
    _2 = (object)SEQ_PTR(_27632);
    _s_54427 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_54427)){
        _s_54427 = (object)DBL_PTR(_s_54427)->dbl;
    }
    _27632 = NOVALUE;

    /** inline.e:452		end while*/
    goto L9; // [332] 253
LA: 

    /** inline.e:453		sequence backpatch_op = {}*/
    RefDS(_22186);
    DeRefi(_backpatch_op_54465);
    _backpatch_op_54465 = _22186;

    /** inline.e:454		while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27634 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27634 = 1;
    }
    if (_pc_54425 >= _27634)
    goto LE; // [352] 869

    /** inline.e:456			integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _op_54469 = (object)*(((s1_ptr)_2)->base + _pc_54425);
    if (!IS_ATOM_INT(_op_54469))
    _op_54469 = (object)DBL_PTR(_op_54469)->dbl;

    /** inline.e:457			switch op do*/
    _0 = _op_54469;
    switch ( _0 ){ 

        /** inline.e:458				case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** inline.e:459					defer()*/
        _67defer();

        /** inline.e:460					restore_code()*/
        _67restore_code();

        /** inline.e:461					return*/
        DeRefi(_backpatch_op_54465);
        DeRef(_27625);
        _27625 = NOVALUE;
        DeRef(_27628);
        _27628 = NOVALUE;
        _27618 = NOVALUE;
        DeRef(_27622);
        _27622 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** inline.e:463				case PROC, FUNC then*/
        case 27:
        case 501:

        /** inline.e:464					symtab_index rtn_idx = inline_code[pc+1]*/
        _27639 = _pc_54425 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _rtn_idx_54480 = (object)*(((s1_ptr)_2)->base + _27639);
        if (!IS_ATOM_INT(_rtn_idx_54480)){
            _rtn_idx_54480 = (object)DBL_PTR(_rtn_idx_54480)->dbl;
        }

        /** inline.e:465					if rtn_idx = sub then*/
        if (_rtn_idx_54480 != _sub_54396)
        goto L10; // [414] 428

        /** inline.e:467						restore_code()*/
        _67restore_code();

        /** inline.e:468						return*/
        DeRefi(_backpatch_op_54465);
        DeRef(_27625);
        _27625 = NOVALUE;
        DeRef(_27628);
        _27628 = NOVALUE;
        _27639 = NOVALUE;
        _27618 = NOVALUE;
        DeRef(_27622);
        _27622 = NOVALUE;
        return;
L10: 

        /** inline.e:471					integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27642 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54480);
        _2 = (object)SEQ_PTR(_27642);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
            _args_54485 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
        }
        else{
            _args_54485 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
        }
        if (!IS_ATOM_INT(_args_54485)){
            _args_54485 = (object)DBL_PTR(_args_54485)->dbl;
        }
        _27642 = NOVALUE;

        /** inline.e:472					if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27644 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54480);
        _2 = (object)SEQ_PTR(_27644);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _27645 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _27645 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        _27644 = NOVALUE;
        if (IS_ATOM_INT(_27645)) {
            _27646 = (_27645 != 27LL);
        }
        else {
            _27646 = binary_op(NOTEQ, _27645, 27LL);
        }
        _27645 = NOVALUE;
        if (IS_ATOM_INT(_27646)) {
            if (_27646 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27646)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27648 = _pc_54425 + _args_54485;
        if ((object)((uintptr_t)_27648 + (uintptr_t)HIGH_BITS) >= 0){
            _27648 = NewDouble((eudouble)_27648);
        }
        if (IS_ATOM_INT(_27648)) {
            _27649 = _27648 + 2LL;
            if ((object)((uintptr_t)_27649 + (uintptr_t)HIGH_BITS) >= 0){
                _27649 = NewDouble((eudouble)_27649);
            }
        }
        else {
            _27649 = NewDouble(DBL_PTR(_27648)->dbl + (eudouble)2LL);
        }
        DeRef(_27648);
        _27648 = NOVALUE;
        _27650 = _67check_for_param(_27649);
        _27649 = NOVALUE;
        if (_27650 == 0) {
            DeRef(_27650);
            _27650 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27650) && DBL_PTR(_27650)->dbl == 0.0){
                DeRef(_27650);
                _27650 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27650);
            _27650 = NOVALUE;
        }
        DeRef(_27650);
        _27650 = NOVALUE;
L11: 

        /** inline.e:475					for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27651 = _args_54485 + 1;
        if (_27651 > MAXINT){
            _27651 = NewDouble((eudouble)_27651);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27652 = (object)*(((s1_ptr)_2)->base + _rtn_idx_54480);
        _2 = (object)SEQ_PTR(_27652);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _27653 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _27653 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        _27652 = NOVALUE;
        if (IS_ATOM_INT(_27653)) {
            _27654 = (_27653 != 27LL);
        }
        else {
            _27654 = binary_op(NOTEQ, _27653, 27LL);
        }
        _27653 = NOVALUE;
        if (IS_ATOM_INT(_27651) && IS_ATOM_INT(_27654)) {
            _27655 = _27651 + _27654;
            if ((object)((uintptr_t)_27655 + (uintptr_t)HIGH_BITS) >= 0){
                _27655 = NewDouble((eudouble)_27655);
            }
        }
        else {
            _27655 = binary_op(PLUS, _27651, _27654);
        }
        DeRef(_27651);
        _27651 = NOVALUE;
        DeRef(_27654);
        _27654 = NOVALUE;
        {
            object _i_54502;
            _i_54502 = 2LL;
L12: 
            if (binary_op_a(GREATER, _i_54502, _27655)){
                goto L13; // [513] 550
            }

            /** inline.e:476						if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_54502)) {
                _27656 = _pc_54425 + _i_54502;
                if ((object)((uintptr_t)_27656 + (uintptr_t)HIGH_BITS) >= 0){
                    _27656 = NewDouble((eudouble)_27656);
                }
            }
            else {
                _27656 = NewDouble((eudouble)_pc_54425 + DBL_PTR(_i_54502)->dbl);
            }
            _27657 = _67adjust_symbol(_27656);
            _27656 = NOVALUE;
            if (IS_ATOM_INT(_27657)) {
                if (_27657 != 0){
                    DeRef(_27657);
                    _27657 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27657)->dbl != 0.0){
                    DeRef(_27657);
                    _27657 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27657);
            _27657 = NOVALUE;

            /** inline.e:477							defer()*/
            _67defer();

            /** inline.e:478							return*/
            DeRef(_i_54502);
            DeRefi(_backpatch_op_54465);
            DeRef(_27625);
            _27625 = NOVALUE;
            DeRef(_27628);
            _27628 = NOVALUE;
            DeRef(_27646);
            _27646 = NOVALUE;
            DeRef(_27639);
            _27639 = NOVALUE;
            DeRef(_27655);
            _27655 = NOVALUE;
            _27618 = NOVALUE;
            DeRef(_27622);
            _27622 = NOVALUE;
            return;
L14: 

            /** inline.e:480					end for*/
            _0 = _i_54502;
            if (IS_ATOM_INT(_i_54502)) {
                _i_54502 = _i_54502 + 1LL;
                if ((object)((uintptr_t)_i_54502 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_54502 = NewDouble((eudouble)_i_54502);
                }
            }
            else {
                _i_54502 = binary_op_a(PLUS, _i_54502, 1LL);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_54502);
        }
        goto LF; // [552] 851

        /** inline.e:482				case RIGHT_BRACE_N then*/
        case 31:

        /** inline.e:484					sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27659 = _pc_54425 + 2LL;
        if ((object)((uintptr_t)_27659 + (uintptr_t)HIGH_BITS) >= 0){
            _27659 = NewDouble((eudouble)_27659);
        }
        _27660 = _pc_54425 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27661 = (object)*(((s1_ptr)_2)->base + _27660);
        if (IS_ATOM_INT(_27661)) {
            _27662 = _27661 + _pc_54425;
            if ((object)((uintptr_t)_27662 + (uintptr_t)HIGH_BITS) >= 0){
                _27662 = NewDouble((eudouble)_27662);
            }
        }
        else {
            _27662 = binary_op(PLUS, _27661, _pc_54425);
        }
        _27661 = NOVALUE;
        if (IS_ATOM_INT(_27662)) {
            _27663 = _27662 + 1;
        }
        else
        _27663 = binary_op(PLUS, 1, _27662);
        DeRef(_27662);
        _27662 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_54517;
        RHS_Slice(_67inline_code_53877, _27659, _27663);

        /** inline.e:486					for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_54517)){
                _27665 = SEQ_PTR(_args_54517)->length;
        }
        else {
            _27665 = 1;
        }
        _27666 = _27665 - 1LL;
        _27665 = NOVALUE;
        {
            object _i_54525;
            _i_54525 = 1LL;
L15: 
            if (_i_54525 > _27666){
                goto L16; // [598] 644
            }

            /** inline.e:487						if find( args[i], args, i + 1 ) then*/
            _2 = (object)SEQ_PTR(_args_54517);
            _27667 = (object)*(((s1_ptr)_2)->base + _i_54525);
            _27668 = _i_54525 + 1;
            _27669 = find_from(_27667, _args_54517, _27668);
            _27667 = NOVALUE;
            _27668 = NOVALUE;
            if (_27669 == 0)
            {
                _27669 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27669 = NOVALUE;
            }

            /** inline.e:488							defer()*/
            _67defer();

            /** inline.e:489							restore_code()*/
            _67restore_code();

            /** inline.e:490							return*/
            DeRefDS(_args_54517);
            DeRefi(_backpatch_op_54465);
            DeRef(_27625);
            _27625 = NOVALUE;
            DeRef(_27628);
            _27628 = NOVALUE;
            DeRef(_27659);
            _27659 = NOVALUE;
            DeRef(_27646);
            _27646 = NOVALUE;
            DeRef(_27639);
            _27639 = NOVALUE;
            DeRef(_27666);
            _27666 = NOVALUE;
            DeRef(_27655);
            _27655 = NOVALUE;
            _27618 = NOVALUE;
            DeRef(_27622);
            _27622 = NOVALUE;
            DeRef(_27660);
            _27660 = NOVALUE;
            DeRef(_27663);
            _27663 = NOVALUE;
            return;
L17: 

            /** inline.e:492					end for*/
            _i_54525 = _i_54525 + 1LL;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** inline.e:493					goto "inline op"*/
        DeRef(_args_54517);
        _args_54517 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** inline.e:495				case RIGHT_BRACE_2 then*/
        case 85:

        /** inline.e:496					if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27671 = _pc_54425 + 1;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27672 = (object)*(((s1_ptr)_2)->base + _27671);
        _27673 = _pc_54425 + 2LL;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27674 = (object)*(((s1_ptr)_2)->base + _27673);
        if (_27672 == _27674)
        _27675 = 1;
        else if (IS_ATOM_INT(_27672) && IS_ATOM_INT(_27674))
        _27675 = 0;
        else
        _27675 = (compare(_27672, _27674) == 0);
        _27672 = NOVALUE;
        _27674 = NOVALUE;
        if (_27675 == 0)
        {
            _27675 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27675 = NOVALUE;
        }

        /** inline.e:497						defer()*/
        _67defer();

        /** inline.e:498						restore_code()*/
        _67restore_code();

        /** inline.e:499						return*/
        DeRefi(_backpatch_op_54465);
        DeRef(_27625);
        _27625 = NOVALUE;
        DeRef(_27628);
        _27628 = NOVALUE;
        _27673 = NOVALUE;
        DeRef(_27659);
        _27659 = NOVALUE;
        DeRef(_27646);
        _27646 = NOVALUE;
        _27671 = NOVALUE;
        DeRef(_27639);
        _27639 = NOVALUE;
        DeRef(_27666);
        _27666 = NOVALUE;
        DeRef(_27655);
        _27655 = NOVALUE;
        _27618 = NOVALUE;
        DeRef(_27622);
        _27622 = NOVALUE;
        DeRef(_27660);
        _27660 = NOVALUE;
        DeRef(_27663);
        _27663 = NOVALUE;
        return;
L19: 

        /** inline.e:501					goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** inline.e:503				case EXIT_BLOCK then*/
        case 206:

        /** inline.e:504					replace_code( "", pc, pc + 1 )*/
        _27676 = _pc_54425 + 1;
        if (_27676 > MAXINT){
            _27676 = NewDouble((eudouble)_27676);
        }
        RefDS(_22186);
        _67replace_code(_22186, _pc_54425, _27676);
        _27676 = NOVALUE;

        /** inline.e:505					continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** inline.e:507				case SWITCH_RT then*/
        case 202:

        /** inline.e:508					sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27677 = _pc_54425 + 2LL;
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27678 = (object)*(((s1_ptr)_2)->base + _27677);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_27678)){
            _27679 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27678)->dbl));
        }
        else{
            _27679 = (object)*(((s1_ptr)_2)->base + _27678);
        }
        DeRef(_values_54546);
        _2 = (object)SEQ_PTR(_27679);
        _values_54546 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_values_54546);
        _27679 = NOVALUE;

        /** inline.e:509					for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_54546)){
                _27681 = SEQ_PTR(_values_54546)->length;
        }
        else {
            _27681 = 1;
        }
        {
            object _i_54554;
            _i_54554 = 1LL;
L1A: 
            if (_i_54554 > _27681){
                goto L1B; // [771] 811
            }

            /** inline.e:510						if sequence( values[i] ) then*/
            _2 = (object)SEQ_PTR(_values_54546);
            _27682 = (object)*(((s1_ptr)_2)->base + _i_54554);
            _27683 = IS_SEQUENCE(_27682);
            _27682 = NOVALUE;
            if (_27683 == 0)
            {
                _27683 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27683 = NOVALUE;
            }

            /** inline.e:512							defer()*/
            _67defer();

            /** inline.e:513							restore_code()*/
            _67restore_code();

            /** inline.e:514							return*/
            DeRefDS(_values_54546);
            DeRefi(_backpatch_op_54465);
            DeRef(_27625);
            _27625 = NOVALUE;
            DeRef(_27677);
            _27677 = NOVALUE;
            DeRef(_27628);
            _27628 = NOVALUE;
            DeRef(_27673);
            _27673 = NOVALUE;
            DeRef(_27659);
            _27659 = NOVALUE;
            DeRef(_27646);
            _27646 = NOVALUE;
            DeRef(_27671);
            _27671 = NOVALUE;
            _27678 = NOVALUE;
            DeRef(_27639);
            _27639 = NOVALUE;
            DeRef(_27666);
            _27666 = NOVALUE;
            DeRef(_27655);
            _27655 = NOVALUE;
            _27618 = NOVALUE;
            DeRef(_27622);
            _27622 = NOVALUE;
            DeRef(_27660);
            _27660 = NOVALUE;
            DeRef(_27663);
            _27663 = NOVALUE;
            return;
L1C: 

            /** inline.e:516					end for*/
            _i_54554 = _i_54554 + 1LL;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** inline.e:517					backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_54465, _backpatch_op_54465, _pc_54425);
        DeRef(_values_54546);
        _values_54546 = NOVALUE;

        /** inline.e:520				case else*/
        default:

        /** inline.e:521				label "inline op"*/
G18:

        /** inline.e:522					if not inline_op( pc ) then*/
        _27685 = _67inline_op(_pc_54425);
        if (IS_ATOM_INT(_27685)) {
            if (_27685 != 0){
                DeRef(_27685);
                _27685 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27685)->dbl != 0.0){
                DeRef(_27685);
                _27685 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27685);
        _27685 = NOVALUE;

        /** inline.e:524						defer()*/
        _67defer();

        /** inline.e:525						restore_code()*/
        _67restore_code();

        /** inline.e:526						return*/
        DeRefi(_backpatch_op_54465);
        DeRef(_27625);
        _27625 = NOVALUE;
        DeRef(_27677);
        _27677 = NOVALUE;
        DeRef(_27628);
        _27628 = NOVALUE;
        DeRef(_27673);
        _27673 = NOVALUE;
        DeRef(_27659);
        _27659 = NOVALUE;
        DeRef(_27646);
        _27646 = NOVALUE;
        DeRef(_27671);
        _27671 = NOVALUE;
        _27678 = NOVALUE;
        DeRef(_27639);
        _27639 = NOVALUE;
        DeRef(_27666);
        _27666 = NOVALUE;
        DeRef(_27655);
        _27655 = NOVALUE;
        _27618 = NOVALUE;
        DeRef(_27622);
        _27622 = NOVALUE;
        DeRef(_27660);
        _27660 = NOVALUE;
        DeRef(_27663);
        _27663 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** inline.e:530			pc = advance( pc, inline_code )*/
    RefDS(_67inline_code_53877);
    _pc_54425 = _67advance(_pc_54425, _67inline_code_53877);
    if (!IS_ATOM_INT(_pc_54425)) {
        _1 = (object)(DBL_PTR(_pc_54425)->dbl);
        DeRefDS(_pc_54425);
        _pc_54425 = _1;
    }

    /** inline.e:532		end while*/
    goto LD; // [866] 347
LE: 

    /** inline.e:534		SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sub_54396 + ((s1_ptr)_2)->base);
    RefDS(_67assigned_params_53883);
    _27690 = _24sort(_67assigned_params_53883, 1LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27690;
    RefDS(_67inline_code_53877);
    ((intptr_t*)_2)[2] = _67inline_code_53877;
    RefDS(_backpatch_op_54465);
    ((intptr_t*)_2)[3] = _backpatch_op_54465;
    _27691 = MAKE_SEQ(_1);
    _27690 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 29LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27691;
    if( _1 != _27691 ){
        DeRef(_1);
    }
    _27691 = NOVALUE;
    _27688 = NOVALUE;

    /** inline.e:535		restore_code()*/
    _67restore_code();

    /** inline.e:536	end procedure*/
    DeRefDSi(_backpatch_op_54465);
    DeRef(_27625);
    _27625 = NOVALUE;
    DeRef(_27677);
    _27677 = NOVALUE;
    DeRef(_27628);
    _27628 = NOVALUE;
    DeRef(_27673);
    _27673 = NOVALUE;
    DeRef(_27659);
    _27659 = NOVALUE;
    DeRef(_27646);
    _27646 = NOVALUE;
    DeRef(_27671);
    _27671 = NOVALUE;
    _27678 = NOVALUE;
    DeRef(_27639);
    _27639 = NOVALUE;
    DeRef(_27666);
    _27666 = NOVALUE;
    DeRef(_27655);
    _27655 = NOVALUE;
    _27618 = NOVALUE;
    DeRef(_27622);
    _27622 = NOVALUE;
    DeRef(_27660);
    _27660 = NOVALUE;
    DeRef(_27663);
    _27663 = NOVALUE;
    return;
    ;
}


void _67replace_temp(object _pc_54574)
{
    object _temp_num_54575 = NOVALUE;
    object _needed_54578 = NOVALUE;
    object _27704 = NOVALUE;
    object _27703 = NOVALUE;
    object _27702 = NOVALUE;
    object _27701 = NOVALUE;
    object _27699 = NOVALUE;
    object _27697 = NOVALUE;
    object _27694 = NOVALUE;
    object _27692 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:539		integer temp_num = inline_code[pc][2]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27692 = (object)*(((s1_ptr)_2)->base + _pc_54574);
    _2 = (object)SEQ_PTR(_27692);
    _temp_num_54575 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_temp_num_54575)){
        _temp_num_54575 = (object)DBL_PTR(_temp_num_54575)->dbl;
    }
    _27692 = NOVALUE;

    /** inline.e:540		integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_53879)){
            _27694 = SEQ_PTR(_67inline_temps_53879)->length;
    }
    else {
        _27694 = 1;
    }
    _needed_54578 = _temp_num_54575 - _27694;
    _27694 = NOVALUE;

    /** inline.e:541		if needed > 0 then*/
    if (_needed_54578 <= 0LL)
    goto L1; // [30] 47

    /** inline.e:542			inline_temps &= repeat( 0, needed )*/
    _27697 = Repeat(0LL, _needed_54578);
    Concat((object_ptr)&_67inline_temps_53879, _67inline_temps_53879, _27697);
    DeRefDS(_27697);
    _27697 = NOVALUE;
L1: 

    /** inline.e:545		if not inline_temps[temp_num] then*/
    _2 = (object)SEQ_PTR(_67inline_temps_53879);
    _27699 = (object)*(((s1_ptr)_2)->base + _temp_num_54575);
    if (IS_ATOM_INT(_27699)) {
        if (_27699 != 0){
            _27699 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27699)->dbl != 0.0){
            _27699 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27699 = NOVALUE;

    /** inline.e:546			if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** inline.e:547				inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((uintptr_t)_temp_num_54575 == (uintptr_t)HIGH_BITS){
        _27701 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27701 = - _temp_num_54575;
    }
    _27702 = _67new_inline_var(_27701, 0LL);
    _27701 = NOVALUE;
    _2 = (object)SEQ_PTR(_67inline_temps_53879);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53879 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54575);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27702;
    if( _1 != _27702 ){
        DeRef(_1);
    }
    _27702 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** inline.e:549				inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27703 = _54NewTempSym(_13TRUE_447);
    _2 = (object)SEQ_PTR(_67inline_temps_53879);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_temps_53879 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp_num_54575);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27703;
    if( _1 != _27703 ){
        DeRef(_1);
    }
    _27703 = NOVALUE;
L4: 
L2: 

    /** inline.e:554		inline_code[pc] = inline_temps[temp_num]*/
    _2 = (object)SEQ_PTR(_67inline_temps_53879);
    _27704 = (object)*(((s1_ptr)_2)->base + _temp_num_54575);
    Ref(_27704);
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54574);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27704;
    if( _1 != _27704 ){
        DeRef(_1);
    }
    _27704 = NOVALUE;

    /** inline.e:555	end procedure*/
    return;
    ;
}


object _67get_param_sym(object _pc_54600)
{
    object _il_54601 = NOVALUE;
    object _px_54609 = NOVALUE;
    object _27711 = NOVALUE;
    object _27708 = NOVALUE;
    object _27707 = NOVALUE;
    object _27706 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:558		object il = inline_code[pc]*/
    DeRef(_il_54601);
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _il_54601 = (object)*(((s1_ptr)_2)->base + _pc_54600);
    Ref(_il_54601);

    /** inline.e:559		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54601))
    _27706 = 1;
    else if (IS_ATOM_DBL(_il_54601))
    _27706 = IS_ATOM_INT(DoubleToInt(_il_54601));
    else
    _27706 = 0;
    if (_27706 == 0)
    {
        _27706 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27706 = NOVALUE;
    }

    /** inline.e:560			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27707 = (object)*(((s1_ptr)_2)->base + _pc_54600);
    Ref(_27707);
    DeRef(_il_54601);
    return _27707;
    goto L2; // [31] 53
L1: 

    /** inline.e:562		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54601)){
            _27708 = SEQ_PTR(_il_54601)->length;
    }
    else {
        _27708 = 1;
    }
    if (_27708 != 1LL)
    goto L3; // [39] 52

    /** inline.e:563			return inline_target*/
    DeRef(_il_54601);
    _27707 = NOVALUE;
    return _67inline_target_53884;
L3: 
L2: 

    /** inline.e:567		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54601);
    _px_54609 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_px_54609)){
        _px_54609 = (object)DBL_PTR(_px_54609)->dbl;
    }

    /** inline.e:568		return passed_params[px]*/
    _2 = (object)SEQ_PTR(_67passed_params_53880);
    _27711 = (object)*(((s1_ptr)_2)->base + _px_54609);
    Ref(_27711);
    DeRef(_il_54601);
    _27707 = NOVALUE;
    return _27711;
    ;
}


object _67get_original_sym(object _pc_54614)
{
    object _il_54615 = NOVALUE;
    object _px_54623 = NOVALUE;
    object _27718 = NOVALUE;
    object _27715 = NOVALUE;
    object _27714 = NOVALUE;
    object _27713 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54614)) {
        _1 = (object)(DBL_PTR(_pc_54614)->dbl);
        DeRefDS(_pc_54614);
        _pc_54614 = _1;
    }

    /** inline.e:572		object il = inline_code[pc]*/
    DeRef(_il_54615);
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _il_54615 = (object)*(((s1_ptr)_2)->base + _pc_54614);
    Ref(_il_54615);

    /** inline.e:573		if integer( il ) then*/
    if (IS_ATOM_INT(_il_54615))
    _27713 = 1;
    else if (IS_ATOM_DBL(_il_54615))
    _27713 = IS_ATOM_INT(DoubleToInt(_il_54615));
    else
    _27713 = 0;
    if (_27713 == 0)
    {
        _27713 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27713 = NOVALUE;
    }

    /** inline.e:574			return inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27714 = (object)*(((s1_ptr)_2)->base + _pc_54614);
    Ref(_27714);
    DeRef(_il_54615);
    return _27714;
    goto L2; // [31] 53
L1: 

    /** inline.e:576		elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_54615)){
            _27715 = SEQ_PTR(_il_54615)->length;
    }
    else {
        _27715 = 1;
    }
    if (_27715 != 1LL)
    goto L3; // [39] 52

    /** inline.e:577			return inline_target*/
    DeRef(_il_54615);
    _27714 = NOVALUE;
    return _67inline_target_53884;
L3: 
L2: 

    /** inline.e:581		integer px = il[2]*/
    _2 = (object)SEQ_PTR(_il_54615);
    _px_54623 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_px_54623)){
        _px_54623 = (object)DBL_PTR(_px_54623)->dbl;
    }

    /** inline.e:582		return original_params[px]*/
    _2 = (object)SEQ_PTR(_67original_params_53881);
    _27718 = (object)*(((s1_ptr)_2)->base + _px_54623);
    Ref(_27718);
    DeRef(_il_54615);
    _27714 = NOVALUE;
    return _27718;
    ;
}


void _67replace_var(object _pc_54632)
{
    object _27722 = NOVALUE;
    object _27721 = NOVALUE;
    object _27720 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:590		inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27720 = (object)*(((s1_ptr)_2)->base + _pc_54632);
    _2 = (object)SEQ_PTR(_27720);
    _27721 = (object)*(((s1_ptr)_2)->base + 2LL);
    _27720 = NOVALUE;
    _2 = (object)SEQ_PTR(_67proc_vars_53878);
    if (!IS_ATOM_INT(_27721)){
        _27722 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27721)->dbl));
    }
    else{
        _27722 = (object)*(((s1_ptr)_2)->base + _27721);
    }
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _pc_54632);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27722;
    if( _1 != _27722 ){
        DeRef(_1);
    }
    _27722 = NOVALUE;

    /** inline.e:591	end procedure*/
    _27721 = NOVALUE;
    return;
    ;
}


void _67fix_switch_rt(object _pc_54638)
{
    object _value_table_54640 = NOVALUE;
    object _jump_table_54647 = NOVALUE;
    object _27742 = NOVALUE;
    object _27741 = NOVALUE;
    object _27740 = NOVALUE;
    object _27739 = NOVALUE;
    object _27738 = NOVALUE;
    object _27737 = NOVALUE;
    object _27735 = NOVALUE;
    object _27734 = NOVALUE;
    object _27733 = NOVALUE;
    object _27732 = NOVALUE;
    object _27731 = NOVALUE;
    object _27729 = NOVALUE;
    object _27727 = NOVALUE;
    object _27726 = NOVALUE;
    object _27724 = NOVALUE;
    object _27723 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:594		symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _27723 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _27723 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _27723;
    _27724 = MAKE_SEQ(_1);
    _27723 = NOVALUE;
    _value_table_54640 = _54NewStringSym(_27724);
    _27724 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_54640)) {
        _1 = (object)(DBL_PTR(_value_table_54640)->dbl);
        DeRefDS(_value_table_54640);
        _value_table_54640 = _1;
    }

    /** inline.e:595		symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_37SymTab_15637)){
            _27726 = SEQ_PTR(_37SymTab_15637)->length;
    }
    else {
        _27726 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = _27726;
    _27727 = MAKE_SEQ(_1);
    _27726 = NOVALUE;
    _jump_table_54647 = _54NewStringSym(_27727);
    _27727 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_54647)) {
        _1 = (object)(DBL_PTR(_jump_table_54647)->dbl);
        DeRefDS(_jump_table_54647);
        _jump_table_54647 = _1;
    }

    /** inline.e:597		SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_value_table_54640 + ((s1_ptr)_2)->base);
    _27731 = _pc_54638 + 2LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27732 = (object)*(((s1_ptr)_2)->base + _27731);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_27732)){
        _27733 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27732)->dbl));
    }
    else{
        _27733 = (object)*(((s1_ptr)_2)->base + _27732);
    }
    _2 = (object)SEQ_PTR(_27733);
    _27734 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27733 = NOVALUE;
    Ref(_27734);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27734;
    if( _1 != _27734 ){
        DeRef(_1);
    }
    _27734 = NOVALUE;
    _27729 = NOVALUE;

    /** inline.e:598		SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_jump_table_54647 + ((s1_ptr)_2)->base);
    _27737 = _pc_54638 + 3LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _27738 = (object)*(((s1_ptr)_2)->base + _27737);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_27738)){
        _27739 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_27738)->dbl));
    }
    else{
        _27739 = (object)*(((s1_ptr)_2)->base + _27738);
    }
    _2 = (object)SEQ_PTR(_27739);
    _27740 = (object)*(((s1_ptr)_2)->base + 1LL);
    _27739 = NOVALUE;
    Ref(_27740);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27740;
    if( _1 != _27740 ){
        DeRef(_1);
    }
    _27740 = NOVALUE;
    _27735 = NOVALUE;

    /** inline.e:600		inline_code[pc+2] = value_table*/
    _27741 = _pc_54638 + 2LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27741);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _value_table_54640;
    DeRef(_1);

    /** inline.e:601		inline_code[pc+3] = jump_table*/
    _27742 = _pc_54638 + 3LL;
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67inline_code_53877 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27742);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _jump_table_54647;
    DeRef(_1);

    /** inline.e:603	end procedure*/
    _27731 = NOVALUE;
    _27737 = NOVALUE;
    _27741 = NOVALUE;
    _27732 = NOVALUE;
    _27742 = NOVALUE;
    _27738 = NOVALUE;
    return;
    ;
}


void _67fixup_special_op(object _pc_54677)
{
    object _op_54678 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_54677)) {
        _1 = (object)(DBL_PTR(_pc_54677)->dbl);
        DeRefDS(_pc_54677);
        _pc_54677 = _1;
    }

    /** inline.e:606		integer op = inline_code[pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _op_54678 = (object)*(((s1_ptr)_2)->base + _pc_54677);
    if (!IS_ATOM_INT(_op_54678))
    _op_54678 = (object)DBL_PTR(_op_54678)->dbl;

    /** inline.e:607		switch op with fallthru do*/
    _0 = _op_54678;
    switch ( _0 ){ 

        /** inline.e:608			case SWITCH_RT then*/
        case 202:

        /** inline.e:609				fix_switch_rt( pc )*/
        _67fix_switch_rt(_pc_54677);

        /** inline.e:610				break*/
        goto L1; // [29] 32
    ;}L1: 

    /** inline.e:612	end procedure*/
    return;
    ;
}


object _67new_inline_var(object _ps_54689, object _reuse_54690)
{
    object _var_54692 = NOVALUE;
    object _vtype_54693 = NOVALUE;
    object _name_54694 = NOVALUE;
    object _s_54696 = NOVALUE;
    object _27805 = NOVALUE;
    object _27804 = NOVALUE;
    object _27802 = NOVALUE;
    object _27799 = NOVALUE;
    object _27798 = NOVALUE;
    object _27796 = NOVALUE;
    object _27793 = NOVALUE;
    object _27792 = NOVALUE;
    object _27791 = NOVALUE;
    object _27789 = NOVALUE;
    object _27784 = NOVALUE;
    object _27779 = NOVALUE;
    object _27778 = NOVALUE;
    object _27777 = NOVALUE;
    object _27776 = NOVALUE;
    object _27773 = NOVALUE;
    object _27771 = NOVALUE;
    object _27768 = NOVALUE;
    object _27763 = NOVALUE;
    object _27762 = NOVALUE;
    object _27761 = NOVALUE;
    object _27760 = NOVALUE;
    object _27759 = NOVALUE;
    object _27756 = NOVALUE;
    object _27755 = NOVALUE;
    object _27754 = NOVALUE;
    object _27753 = NOVALUE;
    object _27752 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_54689)) {
        _1 = (object)(DBL_PTR(_ps_54689)->dbl);
        DeRefDS(_ps_54689);
        _ps_54689 = _1;
    }

    /** inline.e:622			var = 0, */
    _var_54692 = 0LL;

    /** inline.e:624		sequence name*/

    /** inline.e:627		if reuse then*/

    /** inline.e:631		if not var then*/

    /** inline.e:632			if ps > 0 then*/
    if (_ps_54689 <= 0LL)
    goto L1; // [45] 222

    /** inline.e:633				s = ps*/
    _s_54696 = _ps_54689;

    /** inline.e:634				if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** inline.e:635					name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27752 = (object)*(((s1_ptr)_2)->base + _s_54696);
    _2 = (object)SEQ_PTR(_27752);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27753 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27753 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27752 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27754 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53891);
    _2 = (object)SEQ_PTR(_27754);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27755 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27755 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27754 = NOVALUE;
    Ref(_27755);
    Ref(_27753);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27753;
    ((intptr_t *)_2)[2] = _27755;
    _27756 = MAKE_SEQ(_1);
    _27755 = NOVALUE;
    _27753 = NOVALUE;
    DeRefi(_name_54694);
    _name_54694 = EPrintf(-9999999, _27751, _27756);
    DeRefDS(_27756);
    _27756 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** inline.e:637					name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27759 = (object)*(((s1_ptr)_2)->base + _s_54696);
    _2 = (object)SEQ_PTR(_27759);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27760 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27760 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27759 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27761 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53891);
    _2 = (object)SEQ_PTR(_27761);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27762 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27762 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27761 = NOVALUE;
    Ref(_27762);
    Ref(_27760);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27760;
    ((intptr_t *)_2)[2] = _27762;
    _27763 = MAKE_SEQ(_1);
    _27762 = NOVALUE;
    _27760 = NOVALUE;
    DeRefi(_name_54694);
    _name_54694 = EPrintf(-9999999, _27758, _27763);
    DeRefDS(_27763);
    _27763 = NOVALUE;
L3: 

    /** inline.e:640				if reuse then*/
    if (_reuse_54690 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** inline.e:641					if not TRANSLATE then*/
    if (_36TRANSLATE_21361 != 0)
    goto L5; // [148] 203

    /** inline.e:642						name &= ")"*/
    Concat((object_ptr)&_name_54694, _name_54694, _26528);
    goto L5; // [160] 203
L4: 

    /** inline.e:645					if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** inline.e:646						name &= sprintf( "_at_%d", inline_start)*/
    _27768 = EPrintf(-9999999, _27767, _67inline_start_53889);
    Concat((object_ptr)&_name_54694, _name_54694, _27768);
    DeRefDS(_27768);
    _27768 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** inline.e:648						name &= sprintf( " at %d)", inline_start)*/
    _27771 = EPrintf(-9999999, _27770, _67inline_start_53889);
    Concat((object_ptr)&_name_54694, _name_54694, _27771);
    DeRefDS(_27771);
    _27771 = NOVALUE;
L7: 
L5: 

    /** inline.e:652				vtype = SymTab[s][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27773 = (object)*(((s1_ptr)_2)->base + _s_54696);
    _2 = (object)SEQ_PTR(_27773);
    _vtype_54693 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_vtype_54693)){
        _vtype_54693 = (object)DBL_PTR(_vtype_54693)->dbl;
    }
    _27773 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** inline.e:654				name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27776 = (object)*(((s1_ptr)_2)->base + _67inline_sub_53891);
    _2 = (object)SEQ_PTR(_27776);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27777 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27776 = NOVALUE;
    if ((uintptr_t)_ps_54689 == (uintptr_t)HIGH_BITS){
        _27778 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _27778 = - _ps_54689;
    }
    Ref(_27777);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _27777;
    ((intptr_t *)_2)[2] = _27778;
    _27779 = MAKE_SEQ(_1);
    _27778 = NOVALUE;
    _27777 = NOVALUE;
    DeRefi(_name_54694);
    _name_54694 = EPrintf(-9999999, _27775, _27779);
    DeRefDS(_27779);
    _27779 = NOVALUE;

    /** inline.e:655				if reuse then*/
    if (_reuse_54690 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** inline.e:656					name &= "__tmp"*/
    Concat((object_ptr)&_name_54694, _name_54694, _27781);
    goto LA; // [260] 276
L9: 

    /** inline.e:658					name &= sprintf( "__tmp_at%d", inline_start)*/
    _27784 = EPrintf(-9999999, _27783, _67inline_start_53889);
    Concat((object_ptr)&_name_54694, _name_54694, _27784);
    DeRefDS(_27784);
    _27784 = NOVALUE;
LA: 

    /** inline.e:660				vtype = object_type*/
    _vtype_54693 = _54object_type_47132;
L8: 

    /** inline.e:662			if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21767 != _36TopLevelSub_21766)
    goto LB; // [292] 325

    /** inline.e:663				var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54694);
    _var_54692 = _54NewEntry(_name_54694, _67varnum_53888, 5LL, -100LL, 2004LL, 0LL, _vtype_54693);
    if (!IS_ATOM_INT(_var_54692)) {
        _1 = (object)(DBL_PTR(_var_54692)->dbl);
        DeRefDS(_var_54692);
        _var_54692 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** inline.e:666				var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_54694);
    _var_54692 = _54NewBasicEntry(_name_54694, _67varnum_53888, 3LL, -100LL, 2004LL, 0LL, _vtype_54693);
    if (!IS_ATOM_INT(_var_54692)) {
        _1 = (object)(DBL_PTR(_var_54692)->dbl);
        DeRefDS(_var_54692);
        _var_54692 = _1;
    }

    /** inline.e:667				SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54692 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27791 = (object)*(((s1_ptr)_2)->base + _67last_param_53892);
    _2 = (object)SEQ_PTR(_27791);
    _27792 = (object)*(((s1_ptr)_2)->base + 2LL);
    _27791 = NOVALUE;
    Ref(_27792);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27792;
    if( _1 != _27792 ){
        DeRef(_1);
    }
    _27792 = NOVALUE;
    _27789 = NOVALUE;

    /** inline.e:668				SymTab[last_param][S_NEXT] = var*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67last_param_53892 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _var_54692;
    DeRef(_1);
    _27793 = NOVALUE;

    /** inline.e:669				if last_param = last_sym then*/
    if (_67last_param_53892 != _54last_sym_47141)
    goto LD; // [403] 415

    /** inline.e:670					last_sym = var*/
    _54last_sym_47141 = _var_54692;
LD: 
LC: 

    /** inline.e:673			if deferred_inlining then*/
    if (_67deferred_inlining_53887 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** inline.e:674				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21767 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456)){
        _27798 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    }
    else{
        _27798 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    }
    _27796 = NOVALUE;
    if (IS_ATOM_INT(_27798)) {
        _27799 = _27798 + 1;
        if (_27799 > MAXINT){
            _27799 = NewDouble((eudouble)_27799);
        }
    }
    else
    _27799 = binary_op(PLUS, 1, _27798);
    _27798 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27799;
    if( _1 != _27799 ){
        DeRef(_1);
    }
    _27799 = NOVALUE;
    _27796 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** inline.e:676				if param_num != -1 then*/
    if (_45param_num_55361 == -1LL)
    goto L10; // [455] 470

    /** inline.e:677					param_num += 1*/
    _45param_num_55361 = _45param_num_55361 + 1LL;
L10: 
LF: 

    /** inline.e:680			SymTab[var][S_USAGE] = U_USED*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_var_54692 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _27802 = NOVALUE;

    /** inline.e:681			if reuse then*/
    if (_reuse_54690 == 0)
    {
        goto L11; // [490] 511
    }
    else{
    }

    /** inline.e:682				map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36CurrentSub_21767;
    ((intptr_t *)_2)[2] = _ps_54689;
    _27804 = MAKE_SEQ(_1);
    Ref(_67inline_var_map_53896);
    _29nested_put(_67inline_var_map_53896, _27804, _var_54692, 1LL, 0LL);
    _27804 = NOVALUE;
L11: 

    /** inline.e:686		Block_var( var )*/
    _65Block_var(_var_54692);

    /** inline.e:687		if BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L12; // [521] 536
    }
    else{
    }

    /** inline.e:688			add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _var_54692;
    _27805 = MAKE_SEQ(_1);
    _54add_ref(_27805);
    _27805 = NOVALUE;
L12: 

    /** inline.e:690		return var*/
    DeRefi(_name_54694);
    return _var_54692;
    ;
}


object _67get_inlined_code(object _sub_54826, object _start_54827, object _deferred_54828)
{
    object _is_proc_54829 = NOVALUE;
    object _backpatches_54847 = NOVALUE;
    object _prolog_54853 = NOVALUE;
    object _epilog_54854 = NOVALUE;
    object _s_54870 = NOVALUE;
    object _last_sym_54893 = NOVALUE;
    object _int_sym_54920 = NOVALUE;
    object _param_54928 = NOVALUE;
    object _ax_54931 = NOVALUE;
    object _var_54938 = NOVALUE;
    object _final_target_54953 = NOVALUE;
    object _var_54972 = NOVALUE;
    object _create_target_var_54985 = NOVALUE;
    object _check_pc_55008 = NOVALUE;
    object _op_55012 = NOVALUE;
    object _sym_55021 = NOVALUE;
    object _check_result_55026 = NOVALUE;
    object _inline_type_55104 = NOVALUE;
    object _replace_param_1__tmp_at1343_55115 = NOVALUE;
    object _27959 = NOVALUE;
    object _27958 = NOVALUE;
    object _27957 = NOVALUE;
    object _27956 = NOVALUE;
    object _27955 = NOVALUE;
    object _27954 = NOVALUE;
    object _27953 = NOVALUE;
    object _27952 = NOVALUE;
    object _27950 = NOVALUE;
    object _27947 = NOVALUE;
    object _27944 = NOVALUE;
    object _27943 = NOVALUE;
    object _27942 = NOVALUE;
    object _27941 = NOVALUE;
    object _27940 = NOVALUE;
    object _27939 = NOVALUE;
    object _27938 = NOVALUE;
    object _27937 = NOVALUE;
    object _27933 = NOVALUE;
    object _27932 = NOVALUE;
    object _27931 = NOVALUE;
    object _27930 = NOVALUE;
    object _27926 = NOVALUE;
    object _27925 = NOVALUE;
    object _27924 = NOVALUE;
    object _27923 = NOVALUE;
    object _27922 = NOVALUE;
    object _27921 = NOVALUE;
    object _27920 = NOVALUE;
    object _27918 = NOVALUE;
    object _27917 = NOVALUE;
    object _27916 = NOVALUE;
    object _27915 = NOVALUE;
    object _27914 = NOVALUE;
    object _27913 = NOVALUE;
    object _27912 = NOVALUE;
    object _27911 = NOVALUE;
    object _27910 = NOVALUE;
    object _27909 = NOVALUE;
    object _27908 = NOVALUE;
    object _27906 = NOVALUE;
    object _27905 = NOVALUE;
    object _27903 = NOVALUE;
    object _27902 = NOVALUE;
    object _27900 = NOVALUE;
    object _27899 = NOVALUE;
    object _27896 = NOVALUE;
    object _27895 = NOVALUE;
    object _27893 = NOVALUE;
    object _27891 = NOVALUE;
    object _27886 = NOVALUE;
    object _27882 = NOVALUE;
    object _27879 = NOVALUE;
    object _27875 = NOVALUE;
    object _27868 = NOVALUE;
    object _27867 = NOVALUE;
    object _27866 = NOVALUE;
    object _27865 = NOVALUE;
    object _27864 = NOVALUE;
    object _27863 = NOVALUE;
    object _27862 = NOVALUE;
    object _27860 = NOVALUE;
    object _27855 = NOVALUE;
    object _27852 = NOVALUE;
    object _27847 = NOVALUE;
    object _27846 = NOVALUE;
    object _27844 = NOVALUE;
    object _27843 = NOVALUE;
    object _27842 = NOVALUE;
    object _27839 = NOVALUE;
    object _27838 = NOVALUE;
    object _27837 = NOVALUE;
    object _27836 = NOVALUE;
    object _27835 = NOVALUE;
    object _27834 = NOVALUE;
    object _27833 = NOVALUE;
    object _27831 = NOVALUE;
    object _27830 = NOVALUE;
    object _27829 = NOVALUE;
    object _27827 = NOVALUE;
    object _27825 = NOVALUE;
    object _27824 = NOVALUE;
    object _27823 = NOVALUE;
    object _27822 = NOVALUE;
    object _27821 = NOVALUE;
    object _27820 = NOVALUE;
    object _27819 = NOVALUE;
    object _27816 = NOVALUE;
    object _27815 = NOVALUE;
    object _27813 = NOVALUE;
    object _27812 = NOVALUE;
    object _27810 = NOVALUE;
    object _27809 = NOVALUE;
    object _27807 = NOVALUE;
    object _27806 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_start_54827)) {
        _1 = (object)(DBL_PTR(_start_54827)->dbl);
        DeRefDS(_start_54827);
        _start_54827 = _1;
    }

    /** inline.e:694		integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27806 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27806);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _27807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _27807 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _27806 = NOVALUE;
    if (IS_ATOM_INT(_27807)) {
        _is_proc_54829 = (_27807 == 27LL);
    }
    else {
        _is_proc_54829 = binary_op(EQUALS, _27807, 27LL);
    }
    _27807 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_54829)) {
        _1 = (object)(DBL_PTR(_is_proc_54829)->dbl);
        DeRefDS(_is_proc_54829);
        _is_proc_54829 = _1;
    }

    /** inline.e:695		clear_inline_targets()*/
    _47clear_inline_targets();

    /** inline.e:697		inline_temps = {}*/
    RefDS(_22186);
    DeRef(_67inline_temps_53879);
    _67inline_temps_53879 = _22186;

    /** inline.e:698		inline_params = {}*/
    RefDS(_22186);
    DeRefi(_67inline_params_53882);
    _67inline_params_53882 = _22186;

    /** inline.e:699		assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27809 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27809);
    _27810 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27809 = NOVALUE;
    DeRef(_67assigned_params_53883);
    _2 = (object)SEQ_PTR(_27810);
    _67assigned_params_53883 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_67assigned_params_53883);
    _27810 = NOVALUE;

    /** inline.e:700		inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27812 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27812);
    _27813 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27812 = NOVALUE;
    DeRef(_67inline_code_53877);
    _2 = (object)SEQ_PTR(_27813);
    _67inline_code_53877 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_67inline_code_53877);
    _27813 = NOVALUE;

    /** inline.e:701		sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27815 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27815);
    _27816 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27815 = NOVALUE;
    DeRef(_backpatches_54847);
    _2 = (object)SEQ_PTR(_27816);
    _backpatches_54847 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_backpatches_54847);
    _27816 = NOVALUE;

    /** inline.e:703		passed_params = {}*/
    RefDS(_22186);
    DeRef(_67passed_params_53880);
    _67passed_params_53880 = _22186;

    /** inline.e:704		original_params = {}*/
    RefDS(_22186);
    DeRef(_67original_params_53881);
    _67original_params_53881 = _22186;

    /** inline.e:705		proc_vars = {}*/
    RefDS(_22186);
    DeRefi(_67proc_vars_53878);
    _67proc_vars_53878 = _22186;

    /** inline.e:706		sequence prolog = {}*/
    RefDS(_22186);
    DeRefi(_prolog_54853);
    _prolog_54853 = _22186;

    /** inline.e:707		sequence epilog = {}*/
    RefDS(_22186);
    DeRef(_epilog_54854);
    _epilog_54854 = _22186;

    /** inline.e:709		Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27819 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27819);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27820 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27820 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27819 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27821 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_27821);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27822 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27822 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27821 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27820);
    ((intptr_t*)_2)[1] = _27820;
    Ref(_27822);
    ((intptr_t*)_2)[2] = _27822;
    ((intptr_t*)_2)[3] = _start_54827;
    _27823 = MAKE_SEQ(_1);
    _27822 = NOVALUE;
    _27820 = NOVALUE;
    _27824 = EPrintf(-9999999, _27818, _27823);
    DeRefDS(_27823);
    _27823 = NOVALUE;
    _65Start_block(206LL, _27824);
    _27824 = NOVALUE;

    /** inline.e:712		symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27825 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27825);
    _s_54870 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_54870)){
        _s_54870 = (object)DBL_PTR(_s_54870)->dbl;
    }
    _27825 = NOVALUE;

    /** inline.e:714		varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27827 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_27827);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _67varnum_53888 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _67varnum_53888 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    if (!IS_ATOM_INT(_67varnum_53888)){
        _67varnum_53888 = (object)DBL_PTR(_67varnum_53888)->dbl;
    }
    _27827 = NOVALUE;

    /** inline.e:715		inline_start = start*/
    _67inline_start_53889 = _start_54827;

    /** inline.e:717		last_param = CurrentSub*/
    _67last_param_53892 = _36CurrentSub_21767;

    /** inline.e:718		for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27829 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_27829);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _27830 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _27830 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _27829 = NOVALUE;
    {
        object _p_54882;
        _p_54882 = 1LL;
L1: 
        if (binary_op_a(GREATER, _p_54882, _27830)){
            goto L2; // [250] 282
        }

        /** inline.e:719			last_param = SymTab[last_param][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27831 = (object)*(((s1_ptr)_2)->base + _67last_param_53892);
        _2 = (object)SEQ_PTR(_27831);
        _67last_param_53892 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_67last_param_53892)){
            _67last_param_53892 = (object)DBL_PTR(_67last_param_53892)->dbl;
        }
        _27831 = NOVALUE;

        /** inline.e:720		end for*/
        _0 = _p_54882;
        if (IS_ATOM_INT(_p_54882)) {
            _p_54882 = _p_54882 + 1LL;
            if ((object)((uintptr_t)_p_54882 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54882 = NewDouble((eudouble)_p_54882);
            }
        }
        else {
            _p_54882 = binary_op_a(PLUS, _p_54882, 1LL);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_54882);
    }

    /** inline.e:722		symtab_index last_sym = last_param*/
    _last_sym_54893 = _67last_param_53892;

    /** inline.e:723		while last_sym and */
L3: 
    if (_last_sym_54893 == 0) {
        goto L4; // [296] 368
    }
    _27834 = _54sym_scope(_last_sym_54893);
    if (IS_ATOM_INT(_27834)) {
        _27835 = (_27834 <= 3LL);
    }
    else {
        _27835 = binary_op(LESSEQ, _27834, 3LL);
    }
    DeRef(_27834);
    _27834 = NOVALUE;
    if (IS_ATOM_INT(_27835)) {
        if (_27835 != 0) {
            DeRef(_27836);
            _27836 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27835)->dbl != 0.0) {
            DeRef(_27836);
            _27836 = 1;
            goto L5; // [310] 328
        }
    }
    _27837 = _54sym_scope(_last_sym_54893);
    if (IS_ATOM_INT(_27837)) {
        _27838 = (_27837 == 9LL);
    }
    else {
        _27838 = binary_op(EQUALS, _27837, 9LL);
    }
    DeRef(_27837);
    _27837 = NOVALUE;
    DeRef(_27836);
    if (IS_ATOM_INT(_27838))
    _27836 = (_27838 != 0);
    else
    _27836 = DBL_PTR(_27838)->dbl != 0.0;
L5: 
    if (_27836 == 0)
    {
        _27836 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27836 = NOVALUE;
    }

    /** inline.e:725			last_param = last_sym*/
    _67last_param_53892 = _last_sym_54893;

    /** inline.e:726			last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27839 = (object)*(((s1_ptr)_2)->base + _last_sym_54893);
    _2 = (object)SEQ_PTR(_27839);
    _last_sym_54893 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_last_sym_54893)){
        _last_sym_54893 = (object)DBL_PTR(_last_sym_54893)->dbl;
    }
    _27839 = NOVALUE;

    /** inline.e:727			varnum += 1*/
    _67varnum_53888 = _67varnum_53888 + 1;

    /** inline.e:728		end while*/
    goto L3; // [365] 296
L4: 

    /** inline.e:729		for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27842 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27842);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _27843 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _27843 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _27842 = NOVALUE;
    {
        object _p_54911;
        Ref(_27843);
        _p_54911 = _27843;
L6: 
        if (binary_op_a(LESS, _p_54911, 1LL)){
            goto L7; // [382] 407
        }

        /** inline.e:730			passed_params = prepend( passed_params, Pop() )*/
        _27844 = _47Pop();
        Ref(_27844);
        Prepend(&_67passed_params_53880, _67passed_params_53880, _27844);
        DeRef(_27844);
        _27844 = NOVALUE;

        /** inline.e:731		end for*/
        _0 = _p_54911;
        if (IS_ATOM_INT(_p_54911)) {
            _p_54911 = _p_54911 + -1LL;
            if ((object)((uintptr_t)_p_54911 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54911 = NewDouble((eudouble)_p_54911);
            }
        }
        else {
            _p_54911 = binary_op_a(PLUS, _p_54911, -1LL);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_54911);
    }

    /** inline.e:733		original_params = passed_params*/
    RefDS(_67passed_params_53880);
    DeRef(_67original_params_53881);
    _67original_params_53881 = _67passed_params_53880;

    /** inline.e:735		symtab_index int_sym = 0*/
    _int_sym_54920 = 0LL;

    /** inline.e:736		for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27846 = (object)*(((s1_ptr)_2)->base + _sub_54826);
    _2 = (object)SEQ_PTR(_27846);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _27847 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _27847 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _27846 = NOVALUE;
    {
        object _p_54922;
        _p_54922 = 1LL;
L8: 
        if (binary_op_a(GREATER, _p_54922, _27847)){
            goto L9; // [437] 575
        }

        /** inline.e:737			symtab_index param = passed_params[p]*/
        _2 = (object)SEQ_PTR(_67passed_params_53880);
        if (!IS_ATOM_INT(_p_54922)){
            _param_54928 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54922)->dbl));
        }
        else{
            _param_54928 = (object)*(((s1_ptr)_2)->base + _p_54922);
        }
        if (!IS_ATOM_INT(_param_54928)){
            _param_54928 = (object)DBL_PTR(_param_54928)->dbl;
        }

        /** inline.e:738			inline_params &= s*/
        Append(&_67inline_params_53882, _67inline_params_53882, _s_54870);

        /** inline.e:739			integer ax = find( p, assigned_params )*/
        _ax_54931 = find_from(_p_54922, _67assigned_params_53883, 1LL);

        /** inline.e:740			if ax or is_temp( param ) then*/
        if (_ax_54931 != 0) {
            goto LA; // [473] 486
        }
        _27852 = _67is_temp(_param_54928);
        if (_27852 == 0) {
            DeRef(_27852);
            _27852 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27852) && DBL_PTR(_27852)->dbl == 0.0){
                DeRef(_27852);
                _27852 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27852);
            _27852 = NOVALUE;
        }
        DeRef(_27852);
        _27852 = NOVALUE;
LA: 

        /** inline.e:743				varnum += 1*/
        _67varnum_53888 = _67varnum_53888 + 1;

        /** inline.e:744				symtab_index var = new_inline_var( s, 0 )*/
        _var_54938 = _67new_inline_var(_s_54870, 0LL);
        if (!IS_ATOM_INT(_var_54938)) {
            _1 = (object)(DBL_PTR(_var_54938)->dbl);
            DeRefDS(_var_54938);
            _var_54938 = _1;
        }

        /** inline.e:745				prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 18LL;
        ((intptr_t*)_2)[2] = _param_54928;
        ((intptr_t*)_2)[3] = _var_54938;
        _27855 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_54853, _prolog_54853, _27855);
        DeRefDS(_27855);
        _27855 = NOVALUE;

        /** inline.e:746				if not int_sym then*/
        if (_int_sym_54920 != 0)
        goto LC; // [519] 531

        /** inline.e:747					int_sym = NewIntSym( 0 )*/
        _int_sym_54920 = _54NewIntSym(0LL);
        if (!IS_ATOM_INT(_int_sym_54920)) {
            _1 = (object)(DBL_PTR(_int_sym_54920)->dbl);
            DeRefDS(_int_sym_54920);
            _int_sym_54920 = _1;
        }
LC: 

        /** inline.e:750				inline_start += 3*/
        _67inline_start_53889 = _67inline_start_53889 + 3LL;

        /** inline.e:751				passed_params[p] = var*/
        _2 = (object)SEQ_PTR(_67passed_params_53880);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _67passed_params_53880 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_54922))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_p_54922)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _p_54922);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _var_54938;
        DeRef(_1);
LB: 

        /** inline.e:753			s = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27860 = (object)*(((s1_ptr)_2)->base + _s_54870);
        _2 = (object)SEQ_PTR(_27860);
        _s_54870 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_54870)){
            _s_54870 = (object)DBL_PTR(_s_54870)->dbl;
        }
        _27860 = NOVALUE;

        /** inline.e:755		end for*/
        _0 = _p_54922;
        if (IS_ATOM_INT(_p_54922)) {
            _p_54922 = _p_54922 + 1LL;
            if ((object)((uintptr_t)_p_54922 +(uintptr_t) HIGH_BITS) >= 0){
                _p_54922 = NewDouble((eudouble)_p_54922);
            }
        }
        else {
            _p_54922 = binary_op_a(PLUS, _p_54922, 1LL);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_54922);
    }

    /** inline.e:757		symtab_index final_target = 0*/
    _final_target_54953 = 0LL;

    /** inline.e:758		while s and */
LD: 
    if (_s_54870 == 0) {
        goto LE; // [587] 699
    }
    _27863 = _54sym_scope(_s_54870);
    if (IS_ATOM_INT(_27863)) {
        _27864 = (_27863 <= 3LL);
    }
    else {
        _27864 = binary_op(LESSEQ, _27863, 3LL);
    }
    DeRef(_27863);
    _27863 = NOVALUE;
    if (IS_ATOM_INT(_27864)) {
        if (_27864 != 0) {
            DeRef(_27865);
            _27865 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27864)->dbl != 0.0) {
            DeRef(_27865);
            _27865 = 1;
            goto LF; // [601] 619
        }
    }
    _27866 = _54sym_scope(_s_54870);
    if (IS_ATOM_INT(_27866)) {
        _27867 = (_27866 == 9LL);
    }
    else {
        _27867 = binary_op(EQUALS, _27866, 9LL);
    }
    DeRef(_27866);
    _27866 = NOVALUE;
    DeRef(_27865);
    if (IS_ATOM_INT(_27867))
    _27865 = (_27867 != 0);
    else
    _27865 = DBL_PTR(_27867)->dbl != 0.0;
LF: 
    if (_27865 == 0)
    {
        _27865 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27865 = NOVALUE;
    }

    /** inline.e:760			if sym_scope( s ) != SC_UNDEFINED then*/
    _27868 = _54sym_scope(_s_54870);
    if (binary_op_a(EQUALS, _27868, 9LL)){
        DeRef(_27868);
        _27868 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27868);
    _27868 = NOVALUE;

    /** inline.e:763				varnum += 1*/
    _67varnum_53888 = _67varnum_53888 + 1;

    /** inline.e:764				symtab_index var = new_inline_var( s, 0 )*/
    _var_54972 = _67new_inline_var(_s_54870, 0LL);
    if (!IS_ATOM_INT(_var_54972)) {
        _1 = (object)(DBL_PTR(_var_54972)->dbl);
        DeRefDS(_var_54972);
        _var_54972 = _1;
    }

    /** inline.e:765				proc_vars &= var*/
    Append(&_67proc_vars_53878, _67proc_vars_53878, _var_54972);

    /** inline.e:766				if int_sym = 0 then*/
    if (_int_sym_54920 != 0LL)
    goto L11; // [662] 675

    /** inline.e:767					int_sym = NewIntSym( 0 )*/
    _int_sym_54920 = _54NewIntSym(0LL);
    if (!IS_ATOM_INT(_int_sym_54920)) {
        _1 = (object)(DBL_PTR(_int_sym_54920)->dbl);
        DeRefDS(_int_sym_54920);
        _int_sym_54920 = _1;
    }
L11: 
L10: 

    /** inline.e:770			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27875 = (object)*(((s1_ptr)_2)->base + _s_54870);
    _2 = (object)SEQ_PTR(_27875);
    _s_54870 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_54870)){
        _s_54870 = (object)DBL_PTR(_s_54870)->dbl;
    }
    _27875 = NOVALUE;

    /** inline.e:771		end while*/
    goto LD; // [696] 587
LE: 

    /** inline.e:773		if not is_proc then*/
    if (_is_proc_54829 != 0)
    goto L12; // [701] 831

    /** inline.e:774			integer create_target_var = 1*/
    _create_target_var_54985 = 1LL;

    /** inline.e:775			if deferred then*/
    if (_deferred_54828 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** inline.e:776				inline_target = Pop()*/
    _0 = _47Pop();
    _67inline_target_53884 = _0;
    if (!IS_ATOM_INT(_67inline_target_53884)) {
        _1 = (object)(DBL_PTR(_67inline_target_53884)->dbl);
        DeRefDS(_67inline_target_53884);
        _67inline_target_53884 = _1;
    }

    /** inline.e:777				if is_temp( inline_target ) then*/
    _27879 = _67is_temp(_67inline_target_53884);
    if (_27879 == 0) {
        DeRef(_27879);
        _27879 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27879) && DBL_PTR(_27879)->dbl == 0.0){
            DeRef(_27879);
            _27879 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27879);
        _27879 = NOVALUE;
    }
    DeRef(_27879);
    _27879 = NOVALUE;

    /** inline.e:778					final_target = inline_target*/
    _final_target_54953 = _67inline_target_53884;
    goto L15; // [741] 750
L14: 

    /** inline.e:780					create_target_var = 0*/
    _create_target_var_54985 = 0LL;
L15: 
L13: 

    /** inline.e:784			if create_target_var then*/
    if (_create_target_var_54985 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** inline.e:785				varnum += 1*/
    _67varnum_53888 = _67varnum_53888 + 1;

    /** inline.e:786				if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** inline.e:787					inline_target = new_inline_var( sub, 0 )*/
    _0 = _67new_inline_var(_sub_54826, 0LL);
    _67inline_target_53884 = _0;
    if (!IS_ATOM_INT(_67inline_target_53884)) {
        _1 = (object)(DBL_PTR(_67inline_target_53884)->dbl);
        DeRefDS(_67inline_target_53884);
        _67inline_target_53884 = _1;
    }

    /** inline.e:788					SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_67inline_target_53884 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54object_type_47132;
    DeRef(_1);
    _27882 = NOVALUE;

    /** inline.e:789					Pop_block_var()*/
    _65Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** inline.e:791					inline_target = NewTempSym()*/
    _0 = _54NewTempSym(0LL);
    _67inline_target_53884 = _0;
    if (!IS_ATOM_INT(_67inline_target_53884)) {
        _1 = (object)(DBL_PTR(_67inline_target_53884)->dbl);
        DeRefDS(_67inline_target_53884);
        _67inline_target_53884 = _1;
    }
L18: 
L16: 

    /** inline.e:794			proc_vars &= inline_target*/
    Append(&_67proc_vars_53878, _67proc_vars_53878, _67inline_target_53884);
    goto L19; // [828] 837
L12: 

    /** inline.e:796			inline_target = 0*/
    _67inline_target_53884 = 0LL;
L19: 

    /** inline.e:800		integer check_pc = 1*/
    _check_pc_55008 = 1LL;

    /** inline.e:802		while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27886 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27886 = 1;
    }
    if (_27886 <= _check_pc_55008)
    goto L1B; // [852] 1218

    /** inline.e:803			integer op = inline_code[check_pc]*/
    _2 = (object)SEQ_PTR(_67inline_code_53877);
    _op_55012 = (object)*(((s1_ptr)_2)->base + _check_pc_55008);
    if (!IS_ATOM_INT(_op_55012))
    _op_55012 = (object)DBL_PTR(_op_55012)->dbl;

    /** inline.e:805			switch op with fallthru do*/
    _0 = _op_55012;
    switch ( _0 ){ 

        /** inline.e:806				case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** inline.e:809					symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27891 = _check_pc_55008 + 1;
        if (_27891 > MAXINT){
            _27891 = NewDouble((eudouble)_27891);
        }
        _sym_55021 = _67get_original_sym(_27891);
        _27891 = NOVALUE;
        if (!IS_ATOM_INT(_sym_55021)) {
            _1 = (object)(DBL_PTR(_sym_55021)->dbl);
            DeRefDS(_sym_55021);
            _sym_55021 = _1;
        }

        /** inline.e:810					if is_literal( sym ) then*/
        _27893 = _67is_literal(_sym_55021);
        if (_27893 == 0) {
            DeRef(_27893);
            _27893 = NOVALUE;
            goto L1C; // [897] 1012
        }
        else {
            if (!IS_ATOM_INT(_27893) && DBL_PTR(_27893)->dbl == 0.0){
                DeRef(_27893);
                _27893 = NOVALUE;
                goto L1C; // [897] 1012
            }
            DeRef(_27893);
            _27893 = NOVALUE;
        }
        DeRef(_27893);
        _27893 = NOVALUE;

        /** inline.e:811						integer check_result*/

        /** inline.e:813						if op = INTEGER_CHECK then*/
        if (_op_55012 != 96LL)
        goto L1D; // [906] 930

        /** inline.e:814							check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27895 = (object)*(((s1_ptr)_2)->base + _sym_55021);
        _2 = (object)SEQ_PTR(_27895);
        _27896 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27895 = NOVALUE;
        if (IS_ATOM_INT(_27896))
        _check_result_55026 = 1;
        else if (IS_ATOM_DBL(_27896))
        _check_result_55026 = IS_ATOM_INT(DoubleToInt(_27896));
        else
        _check_result_55026 = 0;
        _27896 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** inline.e:815						elsif op = SEQUENCE_CHECK then*/
        if (_op_55012 != 97LL)
        goto L1F; // [934] 958

        /** inline.e:816							check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27899 = (object)*(((s1_ptr)_2)->base + _sym_55021);
        _2 = (object)SEQ_PTR(_27899);
        _27900 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27899 = NOVALUE;
        _check_result_55026 = IS_SEQUENCE(_27900);
        _27900 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** inline.e:818							check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27902 = (object)*(((s1_ptr)_2)->base + _sym_55021);
        _2 = (object)SEQ_PTR(_27902);
        _27903 = (object)*(((s1_ptr)_2)->base + 1LL);
        _27902 = NOVALUE;
        _check_result_55026 = IS_ATOM(_27903);
        _27903 = NOVALUE;
L1E: 

        /** inline.e:821						if check_result then*/
        if (_check_result_55026 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** inline.e:822							replace_code( {}, check_pc, check_pc+1 )*/
        _27905 = _check_pc_55008 + 1;
        if (_27905 > MAXINT){
            _27905 = NewDouble((eudouble)_27905);
        }
        RefDS(_22186);
        _67replace_code(_22186, _check_pc_55008, _27905);
        _27905 = NOVALUE;
        goto L21; // [994] 1007
L20: 

        /** inline.e:826							CompileErr(TYPE_CHECK_ERROR_WHEN_INLINING_LITERAL)*/
        RefDS(_22186);
        _50CompileErr(146LL, _22186, 0LL);
L21: 
        goto L22; // [1009] 1174
L1C: 

        /** inline.e:829					elsif not is_temp( sym ) then*/
        _27906 = _67is_temp(_sym_55021);
        if (IS_ATOM_INT(_27906)) {
            if (_27906 != 0){
                DeRef(_27906);
                _27906 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        else {
            if (DBL_PTR(_27906)->dbl != 0.0){
                DeRef(_27906);
                _27906 = NOVALUE;
                goto L23; // [1018] 1167
            }
        }
        DeRef(_27906);
        _27906 = NOVALUE;

        /** inline.e:831						if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27908 = (_op_55012 == 96LL);
        if (_27908 == 0) {
            _27909 = 0;
            goto L24; // [1029] 1055
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27910 = (object)*(((s1_ptr)_2)->base + _sym_55021);
        _2 = (object)SEQ_PTR(_27910);
        _27911 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27910 = NOVALUE;
        if (IS_ATOM_INT(_27911)) {
            _27912 = (_27911 == _54integer_type_47138);
        }
        else {
            _27912 = binary_op(EQUALS, _27911, _54integer_type_47138);
        }
        _27911 = NOVALUE;
        if (IS_ATOM_INT(_27912))
        _27909 = (_27912 != 0);
        else
        _27909 = DBL_PTR(_27912)->dbl != 0.0;
L24: 
        if (_27909 != 0) {
            _27913 = 1;
            goto L25; // [1055] 1095
        }
        _27914 = (_op_55012 == 97LL);
        if (_27914 == 0) {
            _27915 = 0;
            goto L26; // [1065] 1091
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27916 = (object)*(((s1_ptr)_2)->base + _sym_55021);
        _2 = (object)SEQ_PTR(_27916);
        _27917 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27916 = NOVALUE;
        if (IS_ATOM_INT(_27917)) {
            _27918 = (_27917 == _54sequence_type_47136);
        }
        else {
            _27918 = binary_op(EQUALS, _27917, _54sequence_type_47136);
        }
        _27917 = NOVALUE;
        if (IS_ATOM_INT(_27918))
        _27915 = (_27918 != 0);
        else
        _27915 = DBL_PTR(_27918)->dbl != 0.0;
L26: 
        _27913 = (_27915 != 0);
L25: 
        if (_27913 != 0) {
            goto L27; // [1095] 1143
        }
        _27920 = (_op_55012 == 101LL);
        if (_27920 == 0) {
            DeRef(_27921);
            _27921 = 0;
            goto L28; // [1105] 1138
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27922 = (object)*(((s1_ptr)_2)->base + _sym_55021);
        _2 = (object)SEQ_PTR(_27922);
        _27923 = (object)*(((s1_ptr)_2)->base + 15LL);
        _27922 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _54integer_type_47138;
        ((intptr_t *)_2)[2] = _54atom_type_47134;
        _27924 = MAKE_SEQ(_1);
        _27925 = find_from(_27923, _27924, 1LL);
        _27923 = NOVALUE;
        DeRefDS(_27924);
        _27924 = NOVALUE;
        _27921 = (_27925 != 0);
L28: 
        if (_27921 == 0)
        {
            _27921 = NOVALUE;
            goto L29; // [1139] 1157
        }
        else{
            _27921 = NOVALUE;
        }
L27: 

        /** inline.e:834							replace_code( {}, check_pc, check_pc+1 )*/
        _27926 = _check_pc_55008 + 1;
        if (_27926 > MAXINT){
            _27926 = NewDouble((eudouble)_27926);
        }
        RefDS(_22186);
        _67replace_code(_22186, _check_pc_55008, _27926);
        _27926 = NOVALUE;
        goto L22; // [1154] 1174
L29: 

        /** inline.e:837							check_pc += 2*/
        _check_pc_55008 = _check_pc_55008 + 2LL;
        goto L22; // [1164] 1174
L23: 

        /** inline.e:841						check_pc += 2*/
        _check_pc_55008 = _check_pc_55008 + 2LL;
L22: 

        /** inline.e:843					continue*/
        goto L1A; // [1180] 847

        /** inline.e:844				case STARTLINE then*/
        case 58:

        /** inline.e:845					check_pc += 2*/
        _check_pc_55008 = _check_pc_55008 + 2LL;

        /** inline.e:846					continue*/
        goto L1A; // [1198] 847

        /** inline.e:848				case else*/
        default:

        /** inline.e:849					exit*/
        goto L1B; // [1208] 1218
    ;}
    /** inline.e:851		end while*/
    goto L1A; // [1215] 847
L1B: 

    /** inline.e:853		for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27930 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27930 = 1;
    }
    {
        object _pc_55099;
        _pc_55099 = 1LL;
L2A: 
        if (_pc_55099 > _27930){
            goto L2B; // [1225] 1422
        }

        /** inline.e:854			if sequence( inline_code[pc] ) then*/
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27931 = (object)*(((s1_ptr)_2)->base + _pc_55099);
        _27932 = IS_SEQUENCE(_27931);
        _27931 = NOVALUE;
        if (_27932 == 0)
        {
            _27932 = NOVALUE;
            goto L2C; // [1243] 1413
        }
        else{
            _27932 = NOVALUE;
        }

        /** inline.e:855				integer inline_type = inline_code[pc][1]*/
        _2 = (object)SEQ_PTR(_67inline_code_53877);
        _27933 = (object)*(((s1_ptr)_2)->base + _pc_55099);
        _2 = (object)SEQ_PTR(_27933);
        _inline_type_55104 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_inline_type_55104)){
            _inline_type_55104 = (object)DBL_PTR(_inline_type_55104)->dbl;
        }
        _27933 = NOVALUE;

        /** inline.e:856				switch inline_type do*/
        _0 = _inline_type_55104;
        switch ( _0 ){ 

            /** inline.e:857					case INLINE_SUB then*/
            case 5:

            /** inline.e:858						inline_code[pc] = CurrentSub*/
            _2 = (object)SEQ_PTR(_67inline_code_53877);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53877 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55099);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36CurrentSub_21767;
            DeRef(_1);
            goto L2D; // [1281] 1412

            /** inline.e:860					case INLINE_VAR then*/
            case 6:

            /** inline.e:861						replace_var( pc )*/
            _67replace_var(_pc_55099);

            /** inline.e:862						break*/
            goto L2D; // [1294] 1412
            goto L2D; // [1296] 1412

            /** inline.e:863					case INLINE_TEMP then*/
            case 2:

            /** inline.e:864						replace_temp( pc )*/
            _67replace_temp(_pc_55099);
            goto L2D; // [1307] 1412

            /** inline.e:866					case INLINE_PARAM then*/
            case 1:

            /** inline.e:867						replace_param( pc )*/

            /** inline.e:586		inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1343_55115;
            _replace_param_1__tmp_at1343_55115 = _67get_param_sym(_pc_55099);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1343_55115);
            _2 = (object)SEQ_PTR(_67inline_code_53877);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53877 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55099);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _replace_param_1__tmp_at1343_55115;
            DeRef(_1);

            /** inline.e:587	end procedure*/
            goto L2E; // [1329] 1332
L2E: 
            DeRef(_replace_param_1__tmp_at1343_55115);
            _replace_param_1__tmp_at1343_55115 = NOVALUE;
            goto L2D; // [1334] 1412

            /** inline.e:869					case INLINE_ADDR then*/
            case 4:

            /** inline.e:870						inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (object)SEQ_PTR(_67inline_code_53877);
            _27937 = (object)*(((s1_ptr)_2)->base + _pc_55099);
            _2 = (object)SEQ_PTR(_27937);
            _27938 = (object)*(((s1_ptr)_2)->base + 2LL);
            _27937 = NOVALUE;
            if (IS_ATOM_INT(_27938)) {
                _27939 = _67inline_start_53889 + _27938;
                if ((object)((uintptr_t)_27939 + (uintptr_t)HIGH_BITS) >= 0){
                    _27939 = NewDouble((eudouble)_27939);
                }
            }
            else {
                _27939 = binary_op(PLUS, _67inline_start_53889, _27938);
            }
            _27938 = NOVALUE;
            _2 = (object)SEQ_PTR(_67inline_code_53877);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53877 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55099);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _27939;
            if( _1 != _27939 ){
                DeRef(_1);
            }
            _27939 = NOVALUE;
            goto L2D; // [1364] 1412

            /** inline.e:872					case INLINE_TARGET then*/
            case 3:

            /** inline.e:873						inline_code[pc] = inline_target*/
            _2 = (object)SEQ_PTR(_67inline_code_53877);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _67inline_code_53877 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _pc_55099);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _67inline_target_53884;
            DeRef(_1);

            /** inline.e:874						add_inline_target( pc + inline_start )*/
            _27940 = _pc_55099 + _67inline_start_53889;
            if ((object)((uintptr_t)_27940 + (uintptr_t)HIGH_BITS) >= 0){
                _27940 = NewDouble((eudouble)_27940);
            }
            _47add_inline_target(_27940);
            _27940 = NOVALUE;

            /** inline.e:875						break*/
            goto L2D; // [1393] 1412
            goto L2D; // [1395] 1412

            /** inline.e:877					case else*/
            default:

            /** inline.e:878						InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _inline_type_55104;
            _27941 = MAKE_SEQ(_1);
            _50InternalErr(265LL, _27941);
            _27941 = NOVALUE;
        ;}L2D: 
L2C: 

        /** inline.e:881		end for*/
        _pc_55099 = _pc_55099 + 1LL;
        goto L2A; // [1417] 1232
L2B: 
        ;
    }

    /** inline.e:883		for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_54847)){
            _27942 = SEQ_PTR(_backpatches_54847)->length;
    }
    else {
        _27942 = 1;
    }
    {
        object _i_55127;
        _i_55127 = 1LL;
L2F: 
        if (_i_55127 > _27942){
            goto L30; // [1427] 1450
        }

        /** inline.e:884			fixup_special_op( backpatches[i] )*/
        _2 = (object)SEQ_PTR(_backpatches_54847);
        _27943 = (object)*(((s1_ptr)_2)->base + _i_55127);
        Ref(_27943);
        _67fixup_special_op(_27943);
        _27943 = NOVALUE;

        /** inline.e:885		end for*/
        _i_55127 = _i_55127 + 1LL;
        goto L2F; // [1445] 1434
L30: 
        ;
    }

    /** inline.e:887		epilog &= End_inline_block( EXIT_BLOCK )*/
    _27944 = _65End_inline_block(206LL);
    if (IS_SEQUENCE(_epilog_54854) && IS_ATOM(_27944)) {
        Ref(_27944);
        Append(&_epilog_54854, _epilog_54854, _27944);
    }
    else if (IS_ATOM(_epilog_54854) && IS_SEQUENCE(_27944)) {
    }
    else {
        Concat((object_ptr)&_epilog_54854, _epilog_54854, _27944);
    }
    DeRef(_27944);
    _27944 = NOVALUE;

    /** inline.e:889		if is_proc then*/
    if (_is_proc_54829 == 0)
    {
        goto L31; // [1464] 1474
    }
    else{
    }

    /** inline.e:890			clear_op()*/
    _47clear_op();
    goto L32; // [1471] 1597
L31: 

    /** inline.e:892			if not deferred then*/
    if (_deferred_54828 != 0)
    goto L33; // [1476] 1491

    /** inline.e:893				Push( inline_target )*/
    _47Push(_67inline_target_53884);

    /** inline.e:894				inlined_function()*/
    _47inlined_function();
L33: 

    /** inline.e:897			if final_target then*/
    if (_final_target_54953 == 0)
    {
        goto L34; // [1493] 1523
    }
    else{
    }

    /** inline.e:898				epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 18LL;
    ((intptr_t*)_2)[2] = _67inline_target_53884;
    ((intptr_t*)_2)[3] = _final_target_54953;
    _27947 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54854, _epilog_54854, _27947);
    DeRefDS(_27947);
    _27947 = NOVALUE;

    /** inline.e:899				emit_temp( final_target, NEW_REFERENCE )*/
    _47emit_temp(_final_target_54953, 1LL);
    goto L35; // [1520] 1596
L34: 

    /** inline.e:905				emit_temp( inline_target, NEW_REFERENCE )*/
    _47emit_temp(_67inline_target_53884, 1LL);

    /** inline.e:906				if not TRANSLATE then*/
    if (_36TRANSLATE_21361 != 0)
    goto L36; // [1537] 1595

    /** inline.e:907					epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 23LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 30LL;
    ((intptr_t*)_2)[4] = _67inline_target_53884;
    _27950 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_54854, _epilog_54854, _27950);
    DeRefDS(_27950);
    _27950 = NOVALUE;

    /** inline.e:908					epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_54854)){
            _27952 = SEQ_PTR(_epilog_54854)->length;
    }
    else {
        _27952 = 1;
    }
    _27953 = _27952 - 2LL;
    _27952 = NOVALUE;
    if (IS_SEQUENCE(_67inline_code_53877)){
            _27954 = SEQ_PTR(_67inline_code_53877)->length;
    }
    else {
        _27954 = 1;
    }
    if (IS_SEQUENCE(_epilog_54854)){
            _27955 = SEQ_PTR(_epilog_54854)->length;
    }
    else {
        _27955 = 1;
    }
    _27956 = _27954 + _27955;
    if ((object)((uintptr_t)_27956 + (uintptr_t)HIGH_BITS) >= 0){
        _27956 = NewDouble((eudouble)_27956);
    }
    _27954 = NOVALUE;
    _27955 = NOVALUE;
    if (IS_ATOM_INT(_27956)) {
        _27957 = _27956 + _67inline_start_53889;
        if ((object)((uintptr_t)_27957 + (uintptr_t)HIGH_BITS) >= 0){
            _27957 = NewDouble((eudouble)_27957);
        }
    }
    else {
        _27957 = NewDouble(DBL_PTR(_27956)->dbl + (eudouble)_67inline_start_53889);
    }
    DeRef(_27956);
    _27956 = NOVALUE;
    if (IS_ATOM_INT(_27957)) {
        _27958 = _27957 + 1;
        if (_27958 > MAXINT){
            _27958 = NewDouble((eudouble)_27958);
        }
    }
    else
    _27958 = binary_op(PLUS, 1, _27957);
    DeRef(_27957);
    _27957 = NOVALUE;
    _2 = (object)SEQ_PTR(_epilog_54854);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _epilog_54854 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _27953);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27958;
    if( _1 != _27958 ){
        DeRef(_1);
    }
    _27958 = NOVALUE;
L36: 
L35: 
L32: 

    /** inline.e:914		return prolog & inline_code & epilog*/
    {
        object concat_list[3];

        concat_list[0] = _epilog_54854;
        concat_list[1] = _67inline_code_53877;
        concat_list[2] = _prolog_54853;
        Concat_N((object_ptr)&_27959, concat_list, 3);
    }
    DeRef(_backpatches_54847);
    DeRefDSi(_prolog_54853);
    DeRefDS(_epilog_54854);
    DeRef(_27864);
    _27864 = NOVALUE;
    DeRef(_27867);
    _27867 = NOVALUE;
    _27830 = NOVALUE;
    DeRef(_27908);
    _27908 = NOVALUE;
    _27843 = NOVALUE;
    DeRef(_27914);
    _27914 = NOVALUE;
    DeRef(_27918);
    _27918 = NOVALUE;
    DeRef(_27835);
    _27835 = NOVALUE;
    _27847 = NOVALUE;
    DeRef(_27953);
    _27953 = NOVALUE;
    DeRef(_27912);
    _27912 = NOVALUE;
    DeRef(_27920);
    _27920 = NOVALUE;
    DeRef(_27838);
    _27838 = NOVALUE;
    return _27959;
    ;
}


void _67defer_call()
{
    object _defer_55167 = NOVALUE;
    object _27962 = NOVALUE;
    object _27961 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:918		integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_55167 = find_from(_67inline_sub_53891, _67deferred_inline_decisions_53893, 1LL);

    /** inline.e:919		if defer then*/
    if (_defer_55167 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** inline.e:921			deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53894);
    _27961 = (object)*(((s1_ptr)_2)->base + _defer_55167);
    if (IS_SEQUENCE(_27961) && IS_ATOM(_36CurrentSub_21767)) {
        Append(&_27962, _27961, _36CurrentSub_21767);
    }
    else if (IS_ATOM(_27961) && IS_SEQUENCE(_36CurrentSub_21767)) {
    }
    else {
        Concat((object_ptr)&_27962, _27961, _36CurrentSub_21767);
        _27961 = NOVALUE;
    }
    _27961 = NOVALUE;
    _2 = (object)SEQ_PTR(_67deferred_inline_calls_53894);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _67deferred_inline_calls_53894 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _defer_55167);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _27962;
    if( _1 != _27962 ){
        DeRef(_1);
    }
    _27962 = NOVALUE;
L1: 

    /** inline.e:923	end procedure*/
    return;
    ;
}


void _67emit_or_inline()
{
    object _sub_55176 = NOVALUE;
    object _code_55207 = NOVALUE;
    object _27974 = NOVALUE;
    object _27973 = NOVALUE;
    object _27971 = NOVALUE;
    object _27970 = NOVALUE;
    object _27969 = NOVALUE;
    object _27967 = NOVALUE;
    object _27966 = NOVALUE;
    object _27965 = NOVALUE;
    object _27964 = NOVALUE;
    object _27963 = NOVALUE;
    object _0, _1, _2;
    

    /** inline.e:928		symtab_index sub = op_info1*/
    _sub_55176 = _47op_info1_51360;

    /** inline.e:929		inline_sub = sub*/
    _67inline_sub_53891 = _sub_55176;

    /** inline.e:931		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27963 = (object)*(((s1_ptr)_2)->base + _sub_55176);
    _2 = (object)SEQ_PTR(_27963);
    _27964 = (object)*(((s1_ptr)_2)->base + 30LL);
    _27963 = NOVALUE;
    if (_27964 == 0) {
        _27964 = NOVALUE;
        goto L1; // [31] 60
    }
    else {
        if (!IS_ATOM_INT(_27964) && DBL_PTR(_27964)->dbl == 0.0){
            _27964 = NOVALUE;
            goto L1; // [31] 60
        }
        _27964 = NOVALUE;
    }
    _27964 = NOVALUE;

    /** inline.e:932			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27965 = (object)*(((s1_ptr)_2)->base + _sub_55176);
    _2 = (object)SEQ_PTR(_27965);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _27966 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _27966 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _27965 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_27966);
    ((intptr_t*)_2)[1] = _27966;
    _27967 = MAKE_SEQ(_1);
    _27966 = NOVALUE;
    _50Warning(327LL, 16384LL, _27967);
    _27967 = NOVALUE;
L1: 

    /** inline.e:935		if Parser_mode != PAM_NORMAL then*/
    if (_36Parser_mode_21868 == 0LL)
    goto L2; // [66] 85

    /** inline.e:938			emit_op( PROC )*/
    _47emit_op(27LL);

    /** inline.e:939			return*/
    DeRef(_code_55207);
    return;
    goto L3; // [82] 133
L2: 

    /** inline.e:941		elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _27969 = (object)*(((s1_ptr)_2)->base + _sub_55176);
    _2 = (object)SEQ_PTR(_27969);
    _27970 = (object)*(((s1_ptr)_2)->base + 29LL);
    _27969 = NOVALUE;
    _27971 = IS_ATOM(_27970);
    _27970 = NOVALUE;
    if (_27971 != 0) {
        goto L4; // [102] 115
    }
    _27973 = _47has_forward_params(_sub_55176);
    if (_27973 == 0) {
        DeRef(_27973);
        _27973 = NOVALUE;
        goto L5; // [111] 132
    }
    else {
        if (!IS_ATOM_INT(_27973) && DBL_PTR(_27973)->dbl == 0.0){
            DeRef(_27973);
            _27973 = NOVALUE;
            goto L5; // [111] 132
        }
        DeRef(_27973);
        _27973 = NOVALUE;
    }
    DeRef(_27973);
    _27973 = NOVALUE;
L4: 

    /** inline.e:942			defer_call()*/
    _67defer_call();

    /** inline.e:943			emit_op( PROC )*/
    _47emit_op(27LL);

    /** inline.e:944			return*/
    DeRef(_code_55207);
    return;
L5: 
L3: 

    /** inline.e:947		sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_36Code_21851)){
            _27974 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _27974 = 1;
    }
    _0 = _code_55207;
    _code_55207 = _67get_inlined_code(_sub_55176, _27974, 0LL);
    DeRef(_0);
    _27974 = NOVALUE;

    /** inline.e:948		emit_inline( code )*/
    RefDS(_code_55207);
    _47emit_inline(_code_55207);

    /** inline.e:949		clear_last()*/
    _47clear_last();

    /** inline.e:951	end procedure*/
    DeRefDS(_code_55207);
    return;
    ;
}


void _67inline_deferred_calls()
{
    object _sub_55221 = NOVALUE;
    object _ix_55233 = NOVALUE;
    object _calling_sub_55235 = NOVALUE;
    object _code_55257 = NOVALUE;
    object _calls_55258 = NOVALUE;
    object _is_func_55262 = NOVALUE;
    object _offset_55269 = NOVALUE;
    object _op_55280 = NOVALUE;
    object _size_55283 = NOVALUE;
    object _28036 = NOVALUE;
    object _28034 = NOVALUE;
    object _28032 = NOVALUE;
    object _28031 = NOVALUE;
    object _28030 = NOVALUE;
    object _28028 = NOVALUE;
    object _28027 = NOVALUE;
    object _28026 = NOVALUE;
    object _28025 = NOVALUE;
    object _28024 = NOVALUE;
    object _28023 = NOVALUE;
    object _28022 = NOVALUE;
    object _28021 = NOVALUE;
    object _28020 = NOVALUE;
    object _28019 = NOVALUE;
    object _28017 = NOVALUE;
    object _28016 = NOVALUE;
    object _28015 = NOVALUE;
    object _28014 = NOVALUE;
    object _28012 = NOVALUE;
    object _28011 = NOVALUE;
    object _28010 = NOVALUE;
    object _28008 = NOVALUE;
    object _28006 = NOVALUE;
    object _28004 = NOVALUE;
    object _28002 = NOVALUE;
    object _28001 = NOVALUE;
    object _28000 = NOVALUE;
    object _27999 = NOVALUE;
    object _27997 = NOVALUE;
    object _27996 = NOVALUE;
    object _27993 = NOVALUE;
    object _27991 = NOVALUE;
    object _27989 = NOVALUE;
    object _27987 = NOVALUE;
    object _27985 = NOVALUE;
    object _27984 = NOVALUE;
    object _27983 = NOVALUE;
    object _27982 = NOVALUE;
    object _27981 = NOVALUE;
    object _27980 = NOVALUE;
    object _27978 = NOVALUE;
    object _27977 = NOVALUE;
    object _27976 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** inline.e:957		deferred_inlining = 1*/
    _67deferred_inlining_53887 = 1LL;

    /** inline.e:958		for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_67deferred_inline_decisions_53893)){
            _27976 = SEQ_PTR(_67deferred_inline_decisions_53893)->length;
    }
    else {
        _27976 = 1;
    }
    {
        object _i_55216;
        _i_55216 = 1LL;
L1: 
        if (_i_55216 > _27976){
            goto L2; // [13] 506
        }

        /** inline.e:960			if length( deferred_inline_calls[i] ) then*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53894);
        _27977 = (object)*(((s1_ptr)_2)->base + _i_55216);
        if (IS_SEQUENCE(_27977)){
                _27978 = SEQ_PTR(_27977)->length;
        }
        else {
            _27978 = 1;
        }
        _27977 = NOVALUE;
        if (_27978 == 0)
        {
            _27978 = NOVALUE;
            goto L3; // [31] 497
        }
        else{
            _27978 = NOVALUE;
        }

        /** inline.e:962				integer sub = deferred_inline_decisions[i]*/
        _2 = (object)SEQ_PTR(_67deferred_inline_decisions_53893);
        _sub_55221 = (object)*(((s1_ptr)_2)->base + _i_55216);

        /** inline.e:963				check_inline( sub )*/
        _67check_inline(_sub_55221);

        /** inline.e:964				if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _27980 = (object)*(((s1_ptr)_2)->base + _sub_55221);
        _2 = (object)SEQ_PTR(_27980);
        _27981 = (object)*(((s1_ptr)_2)->base + 29LL);
        _27980 = NOVALUE;
        _27982 = IS_ATOM(_27981);
        _27981 = NOVALUE;
        if (_27982 == 0)
        {
            _27982 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27982 = NOVALUE;
        }

        /** inline.e:965					continue*/
        goto L5; // [71] 501
L4: 

        /** inline.e:967				for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (object)SEQ_PTR(_67deferred_inline_calls_53894);
        _27983 = (object)*(((s1_ptr)_2)->base + _i_55216);
        if (IS_SEQUENCE(_27983)){
                _27984 = SEQ_PTR(_27983)->length;
        }
        else {
            _27984 = 1;
        }
        _27983 = NOVALUE;
        {
            object _cx_55230;
            _cx_55230 = 1LL;
L6: 
            if (_cx_55230 > _27984){
                goto L7; // [85] 496
            }

            /** inline.e:968					integer ix = 1*/
            _ix_55233 = 1LL;

            /** inline.e:969					symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (object)SEQ_PTR(_67deferred_inline_calls_53894);
            _27985 = (object)*(((s1_ptr)_2)->base + _i_55216);
            _2 = (object)SEQ_PTR(_27985);
            _calling_sub_55235 = (object)*(((s1_ptr)_2)->base + _cx_55230);
            if (!IS_ATOM_INT(_calling_sub_55235)){
                _calling_sub_55235 = (object)DBL_PTR(_calling_sub_55235)->dbl;
            }
            _27985 = NOVALUE;

            /** inline.e:970					CurrentSub = calling_sub*/
            _36CurrentSub_21767 = _calling_sub_55235;

            /** inline.e:971					Code = SymTab[calling_sub][S_CODE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _27987 = (object)*(((s1_ptr)_2)->base + _calling_sub_55235);
            DeRef(_36Code_21851);
            _2 = (object)SEQ_PTR(_27987);
            if (!IS_ATOM_INT(_36S_CODE_21408)){
                _36Code_21851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
            }
            else{
                _36Code_21851 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
            }
            Ref(_36Code_21851);
            _27987 = NOVALUE;

            /** inline.e:972					LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _27989 = (object)*(((s1_ptr)_2)->base + _calling_sub_55235);
            DeRef(_36LineTable_21852);
            _2 = (object)SEQ_PTR(_27989);
            if (!IS_ATOM_INT(_36S_LINETAB_21431)){
                _36LineTable_21852 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
            }
            else{
                _36LineTable_21852 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21431);
            }
            Ref(_36LineTable_21852);
            _27989 = NOVALUE;

            /** inline.e:973					SymTab[calling_sub][S_CODE] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55235 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21408))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0LL;
            DeRef(_1);
            _27991 = NOVALUE;

            /** inline.e:974					SymTab[calling_sub][S_LINETAB] = 0*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55235 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21431))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21431);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 0LL;
            DeRef(_1);
            _27993 = NOVALUE;

            /** inline.e:975					sequence code = {}*/
            RefDS(_22186);
            DeRef(_code_55257);
            _code_55257 = _22186;

            /** inline.e:977					sequence calls = find_ops( 1, PROC )*/
            RefDS(_36Code_21851);
            _0 = _calls_55258;
            _calls_55258 = _66find_ops(1LL, 27LL, _36Code_21851);
            DeRef(_0);

            /** inline.e:978					integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _27996 = (object)*(((s1_ptr)_2)->base + _sub_55221);
            _2 = (object)SEQ_PTR(_27996);
            if (!IS_ATOM_INT(_36S_TOKEN_21401)){
                _27997 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
            }
            else{
                _27997 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
            }
            _27996 = NOVALUE;
            if (IS_ATOM_INT(_27997)) {
                _is_func_55262 = (_27997 != 27LL);
            }
            else {
                _is_func_55262 = binary_op(NOTEQ, _27997, 27LL);
            }
            _27997 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_55262)) {
                _1 = (object)(DBL_PTR(_is_func_55262)->dbl);
                DeRefDS(_is_func_55262);
                _is_func_55262 = _1;
            }

            /** inline.e:979					integer offset = 0*/
            _offset_55269 = 0LL;

            /** inline.e:980					for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_55258)){
                    _27999 = SEQ_PTR(_calls_55258)->length;
            }
            else {
                _27999 = 1;
            }
            {
                object _o_55271;
                _o_55271 = 1LL;
L8: 
                if (_o_55271 > _27999){
                    goto L9; // [233] 453
                }

                /** inline.e:981						if calls[o][2][2] = sub then*/
                _2 = (object)SEQ_PTR(_calls_55258);
                _28000 = (object)*(((s1_ptr)_2)->base + _o_55271);
                _2 = (object)SEQ_PTR(_28000);
                _28001 = (object)*(((s1_ptr)_2)->base + 2LL);
                _28000 = NOVALUE;
                _2 = (object)SEQ_PTR(_28001);
                _28002 = (object)*(((s1_ptr)_2)->base + 2LL);
                _28001 = NOVALUE;
                if (binary_op_a(NOTEQ, _28002, _sub_55221)){
                    _28002 = NOVALUE;
                    goto LA; // [254] 444
                }
                _28002 = NOVALUE;

                /** inline.e:982							ix = calls[o][1]*/
                _2 = (object)SEQ_PTR(_calls_55258);
                _28004 = (object)*(((s1_ptr)_2)->base + _o_55271);
                _2 = (object)SEQ_PTR(_28004);
                _ix_55233 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (!IS_ATOM_INT(_ix_55233)){
                    _ix_55233 = (object)DBL_PTR(_ix_55233)->dbl;
                }
                _28004 = NOVALUE;

                /** inline.e:983							sequence op = calls[o][2]*/
                _2 = (object)SEQ_PTR(_calls_55258);
                _28006 = (object)*(((s1_ptr)_2)->base + _o_55271);
                DeRef(_op_55280);
                _2 = (object)SEQ_PTR(_28006);
                _op_55280 = (object)*(((s1_ptr)_2)->base + 2LL);
                Ref(_op_55280);
                _28006 = NOVALUE;

                /** inline.e:984							integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_55280)){
                        _28008 = SEQ_PTR(_op_55280)->length;
                }
                else {
                    _28008 = 1;
                }
                _size_55283 = _28008 - 1LL;
                _28008 = NOVALUE;

                /** inline.e:985							if is_func then*/
                if (_is_func_55262 == 0)
                {
                    goto LB; // [293] 319
                }
                else{
                }

                /** inline.e:987								Push( op[$] )*/
                if (IS_SEQUENCE(_op_55280)){
                        _28010 = SEQ_PTR(_op_55280)->length;
                }
                else {
                    _28010 = 1;
                }
                _2 = (object)SEQ_PTR(_op_55280);
                _28011 = (object)*(((s1_ptr)_2)->base + _28010);
                Ref(_28011);
                _47Push(_28011);
                _28011 = NOVALUE;

                /** inline.e:988								op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_55280)){
                        _28012 = SEQ_PTR(_op_55280)->length;
                }
                else {
                    _28012 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_55280);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_28012)) ? _28012 : (object)(DBL_PTR(_28012)->dbl);
                    int stop = (IS_ATOM_INT(_28012)) ? _28012 : (object)(DBL_PTR(_28012)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<1) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_55280), start, &_op_55280 );
                        }
                        else Tail(SEQ_PTR(_op_55280), stop+1, &_op_55280);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_55280), start, &_op_55280);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_55280 = Remove_elements(start, stop, (SEQ_PTR(_op_55280)->ref == 1));
                    }
                }
                _28012 = NOVALUE;
                _28012 = NOVALUE;
LB: 

                /** inline.e:992							for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_55280)){
                        _28014 = SEQ_PTR(_op_55280)->length;
                }
                else {
                    _28014 = 1;
                }
                {
                    object _p_55293;
                    _p_55293 = 3LL;
LC: 
                    if (_p_55293 > _28014){
                        goto LD; // [324] 347
                    }

                    /** inline.e:993								Push( op[p] )*/
                    _2 = (object)SEQ_PTR(_op_55280);
                    _28015 = (object)*(((s1_ptr)_2)->base + _p_55293);
                    Ref(_28015);
                    _47Push(_28015);
                    _28015 = NOVALUE;

                    /** inline.e:994							end for*/
                    _p_55293 = _p_55293 + 1LL;
                    goto LC; // [342] 331
LD: 
                    ;
                }

                /** inline.e:995							code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _28016 = _ix_55233 + _offset_55269;
                if ((object)((uintptr_t)_28016 + (uintptr_t)HIGH_BITS) >= 0){
                    _28016 = NewDouble((eudouble)_28016);
                }
                if (IS_ATOM_INT(_28016)) {
                    _28017 = _28016 - 1LL;
                    if ((object)((uintptr_t)_28017 +(uintptr_t) HIGH_BITS) >= 0){
                        _28017 = NewDouble((eudouble)_28017);
                    }
                }
                else {
                    _28017 = NewDouble(DBL_PTR(_28016)->dbl - (eudouble)1LL);
                }
                DeRef(_28016);
                _28016 = NOVALUE;
                _0 = _code_55257;
                _code_55257 = _67get_inlined_code(_sub_55221, _28017, 1LL);
                DeRef(_0);
                _28017 = NOVALUE;

                /** inline.e:996							shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_55257)){
                        _28019 = SEQ_PTR(_code_55257)->length;
                }
                else {
                    _28019 = 1;
                }
                _28020 = Repeat(159LL, _28019);
                _28019 = NOVALUE;
                _28021 = _ix_55233 + _offset_55269;
                if ((object)((uintptr_t)_28021 + (uintptr_t)HIGH_BITS) >= 0){
                    _28021 = NewDouble((eudouble)_28021);
                }
                _28022 = _ix_55233 + _offset_55269;
                if ((object)((uintptr_t)_28022 + (uintptr_t)HIGH_BITS) >= 0){
                    _28022 = NewDouble((eudouble)_28022);
                }
                if (IS_ATOM_INT(_28022)) {
                    _28023 = _28022 + _size_55283;
                    if ((object)((uintptr_t)_28023 + (uintptr_t)HIGH_BITS) >= 0){
                        _28023 = NewDouble((eudouble)_28023);
                    }
                }
                else {
                    _28023 = NewDouble(DBL_PTR(_28022)->dbl + (eudouble)_size_55283);
                }
                DeRef(_28022);
                _28022 = NOVALUE;
                _66replace_code(_28020, _28021, _28023);
                _28020 = NOVALUE;
                _28021 = NOVALUE;
                _28023 = NOVALUE;

                /** inline.e:999							Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _28024 = _ix_55233 + _offset_55269;
                if ((object)((uintptr_t)_28024 + (uintptr_t)HIGH_BITS) >= 0){
                    _28024 = NewDouble((eudouble)_28024);
                }
                _28025 = _ix_55233 + _offset_55269;
                if ((object)((uintptr_t)_28025 + (uintptr_t)HIGH_BITS) >= 0){
                    _28025 = NewDouble((eudouble)_28025);
                }
                if (IS_SEQUENCE(_code_55257)){
                        _28026 = SEQ_PTR(_code_55257)->length;
                }
                else {
                    _28026 = 1;
                }
                if (IS_ATOM_INT(_28025)) {
                    _28027 = _28025 + _28026;
                    if ((object)((uintptr_t)_28027 + (uintptr_t)HIGH_BITS) >= 0){
                        _28027 = NewDouble((eudouble)_28027);
                    }
                }
                else {
                    _28027 = NewDouble(DBL_PTR(_28025)->dbl + (eudouble)_28026);
                }
                DeRef(_28025);
                _28025 = NOVALUE;
                _28026 = NOVALUE;
                if (IS_ATOM_INT(_28027)) {
                    _28028 = _28027 - 1LL;
                    if ((object)((uintptr_t)_28028 +(uintptr_t) HIGH_BITS) >= 0){
                        _28028 = NewDouble((eudouble)_28028);
                    }
                }
                else {
                    _28028 = NewDouble(DBL_PTR(_28027)->dbl - (eudouble)1LL);
                }
                DeRef(_28027);
                _28027 = NOVALUE;
                {
                    intptr_t p1 = _36Code_21851;
                    intptr_t p2 = _code_55257;
                    intptr_t p3 = _28024;
                    intptr_t p4 = _28028;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_36Code_21851;
                    Replace( &replace_params );
                }
                DeRef(_28024);
                _28024 = NOVALUE;
                DeRef(_28028);
                _28028 = NOVALUE;

                /** inline.e:1000							offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_55257)){
                        _28030 = SEQ_PTR(_code_55257)->length;
                }
                else {
                    _28030 = 1;
                }
                _28031 = _28030 - _size_55283;
                if ((object)((uintptr_t)_28031 +(uintptr_t) HIGH_BITS) >= 0){
                    _28031 = NewDouble((eudouble)_28031);
                }
                _28030 = NOVALUE;
                if (IS_ATOM_INT(_28031)) {
                    _28032 = _28031 - 1LL;
                    if ((object)((uintptr_t)_28032 +(uintptr_t) HIGH_BITS) >= 0){
                        _28032 = NewDouble((eudouble)_28032);
                    }
                }
                else {
                    _28032 = NewDouble(DBL_PTR(_28031)->dbl - (eudouble)1LL);
                }
                DeRef(_28031);
                _28031 = NOVALUE;
                if (IS_ATOM_INT(_28032)) {
                    _offset_55269 = _offset_55269 + _28032;
                }
                else {
                    _offset_55269 = NewDouble((eudouble)_offset_55269 + DBL_PTR(_28032)->dbl);
                }
                DeRef(_28032);
                _28032 = NOVALUE;
                if (!IS_ATOM_INT(_offset_55269)) {
                    _1 = (object)(DBL_PTR(_offset_55269)->dbl);
                    DeRefDS(_offset_55269);
                    _offset_55269 = _1;
                }
LA: 
                DeRef(_op_55280);
                _op_55280 = NOVALUE;

                /** inline.e:1003					end for*/
                _o_55271 = _o_55271 + 1LL;
                goto L8; // [448] 240
L9: 
                ;
            }

            /** inline.e:1004					SymTab[calling_sub][S_CODE] = Code*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55235 + ((s1_ptr)_2)->base);
            RefDS(_36Code_21851);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_CODE_21408))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36Code_21851;
            DeRef(_1);
            _28034 = NOVALUE;

            /** inline.e:1005					SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_calling_sub_55235 + ((s1_ptr)_2)->base);
            RefDS(_36LineTable_21852);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_36S_LINETAB_21431))
            _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
            else
            _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21431);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _36LineTable_21852;
            DeRef(_1);
            _28036 = NOVALUE;
            DeRef(_code_55257);
            _code_55257 = NOVALUE;
            DeRef(_calls_55258);
            _calls_55258 = NOVALUE;

            /** inline.e:1006				end for*/
            _cx_55230 = _cx_55230 + 1LL;
            goto L6; // [491] 92
L7: 
            ;
        }
L3: 

        /** inline.e:1008		end for*/
L5: 
        _i_55216 = _i_55216 + 1LL;
        goto L1; // [501] 20
L2: 
        ;
    }

    /** inline.e:1009	end procedure*/
    _27977 = NOVALUE;
    _27983 = NOVALUE;
    return;
    ;
}



// 0x4F58B940
