// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _49add_options(object _new_options_50079)
{
    object _0, _1, _2;
    

    /** cominit.e:65		options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 16LL;
        if (insert_pos <= 0) {
            Concat(&_49options_50075,_new_options_50079,_49options_50075);
        }
        else if (insert_pos > SEQ_PTR(_49options_50075)->length){
            Concat(&_49options_50075,_49options_50075,_new_options_50079);
        }
        else if (IS_SEQUENCE(_new_options_50079)) {
            if( _49options_50075 != _49options_50075 || SEQ_PTR( _49options_50075 )->ref != 1 ){
                DeRef( _49options_50075 );
                RefDS( _49options_50075 );
            }
            assign_space = Add_internal_space( _49options_50075, insert_pos,((s1_ptr)SEQ_PTR(_new_options_50079))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_50079), _49options_50075 == _49options_50075 );
            _49options_50075 = MAKE_SEQ( assign_space );
        }
        else {
            if( _49options_50075 == _49options_50075 && SEQ_PTR( _49options_50075 )->ref == 1 ){
                _49options_50075 = Insert( _49options_50075, _new_options_50079, insert_pos);
            }
            else {
                DeRef( _49options_50075 );
                RefDS( _49options_50075 );
                _49options_50075 = Insert( _49options_50075, _new_options_50079, insert_pos);
            }
        }
    }

    /** cominit.e:67	end procedure*/
    DeRefDS(_new_options_50079);
    return;
    ;
}


object _49get_options()
{
    object _0, _1, _2;
    

    /** cominit.e:73		return options*/
    RefDS(_49options_50075);
    return _49options_50075;
    ;
}


object _49get_switches()
{
    object _0, _1, _2;
    

    /** cominit.e:87		return switches*/
    RefDS(_49switches_49948);
    return _49switches_49948;
    ;
}


void _49show_copyrights()
{
    object _notices_50089 = NOVALUE;
    object _25711 = NOVALUE;
    object _25710 = NOVALUE;
    object _25708 = NOVALUE;
    object _25707 = NOVALUE;
    object _25706 = NOVALUE;
    object _25705 = NOVALUE;
    object _25703 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:94		sequence notices = all_copyrights()*/
    _0 = _notices_50089;
    _notices_50089 = _33all_copyrights();
    DeRef(_0);

    /** cominit.e:95		for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_50089)){
            _25703 = SEQ_PTR(_notices_50089)->length;
    }
    else {
        _25703 = 1;
    }
    {
        object _i_50093;
        _i_50093 = 1LL;
L1: 
        if (_i_50093 > _25703){
            goto L2; // [13] 60
        }

        /** cominit.e:96			printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (object)SEQ_PTR(_notices_50089);
        _25705 = (object)*(((s1_ptr)_2)->base + _i_50093);
        _2 = (object)SEQ_PTR(_25705);
        _25706 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25705 = NOVALUE;
        _2 = (object)SEQ_PTR(_notices_50089);
        _25707 = (object)*(((s1_ptr)_2)->base + _i_50093);
        _2 = (object)SEQ_PTR(_25707);
        _25708 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25707 = NOVALUE;
        RefDS(_22381);
        Ref(_25708);
        RefDS(_25709);
        _25710 = _16match_replace(_22381, _25708, _25709, 0LL);
        _25708 = NOVALUE;
        Ref(_25706);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _25706;
        ((intptr_t *)_2)[2] = _25710;
        _25711 = MAKE_SEQ(_1);
        _25710 = NOVALUE;
        _25706 = NOVALUE;
        EPrintf(2LL, _25704, _25711);
        DeRefDS(_25711);
        _25711 = NOVALUE;

        /** cominit.e:97		end for*/
        _i_50093 = _i_50093 + 1LL;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** cominit.e:98	end procedure*/
    DeRef(_notices_50089);
    return;
    ;
}


void _49show_banner()
{
    object _version_type_inlined_version_type_at_220_50162 = NOVALUE;
    object _version_string_short_1__tmp_at204_50160 = NOVALUE;
    object _version_string_short_inlined_version_string_short_at_204_50159 = NOVALUE;
    object _version_revision_inlined_version_revision_at_133_50140 = NOVALUE;
    object _platform_name_inlined_platform_name_at_94_50132 = NOVALUE;
    object _prod_name_50106 = NOVALUE;
    object _memory_type_50107 = NOVALUE;
    object _misc_info_50129 = NOVALUE;
    object _EuConsole_50144 = NOVALUE;
    object _25736 = NOVALUE;
    object _25735 = NOVALUE;
    object _25734 = NOVALUE;
    object _25731 = NOVALUE;
    object _25730 = NOVALUE;
    object _25726 = NOVALUE;
    object _25725 = NOVALUE;
    object _25724 = NOVALUE;
    object _25722 = NOVALUE;
    object _25720 = NOVALUE;
    object _25719 = NOVALUE;
    object _25718 = NOVALUE;
    object _25713 = NOVALUE;
    object _25712 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:109		if INTERPRET and not BIND then*/
    if (_36INTERPRET_21358 == 0) {
        goto L1; // [5] 33
    }
    _25713 = (_36BIND_21364 == 0);
    if (_25713 == 0)
    {
        DeRef(_25713);
        _25713 = NOVALUE;
        goto L1; // [15] 33
    }
    else{
        DeRef(_25713);
        _25713 = NOVALUE;
    }

    /** cominit.e:110			prod_name = GetMsgText(EUPHORIA_INTERPRETER,0)*/
    RefDS(_22186);
    _0 = _prod_name_50106;
    _prod_name_50106 = _39GetMsgText(270LL, 0LL, _22186);
    DeRef(_0);
    goto L2; // [30] 76
L1: 

    /** cominit.e:112		elsif TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L3; // [37] 55
    }
    else{
    }

    /** cominit.e:113			prod_name = GetMsgText(EUPHORIA_TO_C_TRANSLATOR,0)*/
    RefDS(_22186);
    _0 = _prod_name_50106;
    _prod_name_50106 = _39GetMsgText(271LL, 0LL, _22186);
    DeRef(_0);
    goto L2; // [52] 76
L3: 

    /** cominit.e:115		elsif BIND then*/
    if (_36BIND_21364 == 0)
    {
        goto L4; // [59] 75
    }
    else{
    }

    /** cominit.e:116			prod_name = GetMsgText(EUPHORIA_BINDER,0)*/
    RefDS(_22186);
    _0 = _prod_name_50106;
    _prod_name_50106 = _39GetMsgText(272LL, 0LL, _22186);
    DeRef(_0);
L4: 
L2: 

    /** cominit.e:119		ifdef EU_MANAGED_MEM then*/

    /** cominit.e:122			memory_type = GetMsgText(USING_SYSTEM_MEMORY,0)*/
    RefDS(_22186);
    _0 = _memory_type_50107;
    _memory_type_50107 = _39GetMsgText(274LL, 0LL, _22186);
    DeRef(_0);

    /** cominit.e:125		sequence misc_info = {*/
    _25718 = _33arch_bits();

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_6769);
    DeRefi(_platform_name_inlined_platform_name_at_94_50132);
    _platform_name_inlined_platform_name_at_94_50132 = _6769;
    _25719 = _33version_date(0LL);
    _25720 = _33version_node(0LL);
    _0 = _misc_info_50129;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _25718;
    RefDS(_platform_name_inlined_platform_name_at_94_50132);
    ((intptr_t*)_2)[2] = _platform_name_inlined_platform_name_at_94_50132;
    RefDS(_memory_type_50107);
    ((intptr_t*)_2)[3] = _memory_type_50107;
    RefDS(_22186);
    ((intptr_t*)_2)[4] = _22186;
    ((intptr_t*)_2)[5] = _25719;
    ((intptr_t*)_2)[6] = _25720;
    _misc_info_50129 = MAKE_SEQ(_1);
    DeRef(_0);
    _25720 = NOVALUE;
    _25719 = NOVALUE;
    _25718 = NOVALUE;

    /** cominit.e:134		if info:is_developmental then*/
    if (_33is_developmental_12087 == 0)
    {
        goto L5; // [126] 160
    }
    else{
    }

    /** cominit.e:135			misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25722 = 6;

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_133_50140);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _version_revision_inlined_version_revision_at_133_50140 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_133_50140);
    _25724 = _33version_node(0LL);
    Ref(_version_revision_inlined_version_revision_at_133_50140);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _version_revision_inlined_version_revision_at_133_50140;
    ((intptr_t *)_2)[2] = _25724;
    _25725 = MAKE_SEQ(_1);
    _25724 = NOVALUE;
    _25726 = EPrintf(-9999999, _25723, _25725);
    DeRefDS(_25725);
    _25725 = NOVALUE;
    _2 = (object)SEQ_PTR(_misc_info_50129);
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25726;
    if( _1 != _25726 ){
        DeRef(_1);
    }
    _25726 = NOVALUE;
L5: 

    /** cominit.e:138		object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_50144);
    _EuConsole_50144 = EGetEnv(_25727);

    /** cominit.e:139		if equal(EuConsole, "1") then*/
    if (_EuConsole_50144 == _25729)
    _25730 = 1;
    else if (IS_ATOM_INT(_EuConsole_50144) && IS_ATOM_INT(_25729))
    _25730 = 0;
    else
    _25730 = (compare(_EuConsole_50144, _25729) == 0);
    if (_25730 == 0)
    {
        _25730 = NOVALUE;
        goto L6; // [171] 191
    }
    else{
        _25730 = NOVALUE;
    }

    /** cominit.e:140			misc_info[4] = GetMsgText(EUCONSOLE,0)*/
    RefDS(_22186);
    _25731 = _39GetMsgText(275LL, 0LL, _22186);
    _2 = (object)SEQ_PTR(_misc_info_50129);
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _25731;
    if( _1 != _25731 ){
        DeRef(_1);
    }
    _25731 = NOVALUE;
    goto L7; // [188] 199
L6: 

    /** cominit.e:142			misc_info = remove(misc_info, 4)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_50129);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        int stop = (IS_ATOM_INT(4LL)) ? 4LL : (object)(DBL_PTR(4LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_50129), start, &_misc_info_50129 );
            }
            else Tail(SEQ_PTR(_misc_info_50129), stop+1, &_misc_info_50129);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_50129), start, &_misc_info_50129);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_50129 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_50129)->ref == 1));
        }
    }
L7: 

    /** cominit.e:145		screen_output(STDERR, sprintf("%s v%s %s\n   %s %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** info.e:261		return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at204_50160;
    RHS_Slice(_33version_info_12085, 1LL, 3LL);
    DeRefi(_version_string_short_inlined_version_string_short_at_204_50159);
    _version_string_short_inlined_version_string_short_at_204_50159 = EPrintf(-9999999, _6827, _version_string_short_1__tmp_at204_50160);
    DeRef(_version_string_short_1__tmp_at204_50160);
    _version_string_short_1__tmp_at204_50160 = NOVALUE;

    /** info.e:202		return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_220_50162);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _version_type_inlined_version_type_at_220_50162 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_version_type_inlined_version_type_at_220_50162);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_prod_name_50106);
    ((intptr_t*)_2)[1] = _prod_name_50106;
    RefDS(_version_string_short_inlined_version_string_short_at_204_50159);
    ((intptr_t*)_2)[2] = _version_string_short_inlined_version_string_short_at_204_50159;
    Ref(_version_type_inlined_version_type_at_220_50162);
    ((intptr_t*)_2)[3] = _version_type_inlined_version_type_at_220_50162;
    _25734 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25735, _25734, _misc_info_50129);
    DeRefDS(_25734);
    _25734 = NOVALUE;
    DeRef(_25734);
    _25734 = NOVALUE;
    _25736 = EPrintf(-9999999, _25733, _25735);
    DeRefDS(_25735);
    _25735 = NOVALUE;
    _50screen_output(2LL, _25736);
    _25736 = NOVALUE;

    /** cominit.e:147	end procedure*/
    DeRefDS(_prod_name_50106);
    DeRef(_memory_type_50107);
    DeRefDS(_misc_info_50129);
    DeRefi(_EuConsole_50144);
    return;
    ;
}


object _49find_opt(object _name_type_50174, object _opt_50175, object _opts_50176)
{
    object _o_50180 = NOVALUE;
    object _has_case_50182 = NOVALUE;
    object _25749 = NOVALUE;
    object _25748 = NOVALUE;
    object _25747 = NOVALUE;
    object _25746 = NOVALUE;
    object _25745 = NOVALUE;
    object _25744 = NOVALUE;
    object _25743 = NOVALUE;
    object _25742 = NOVALUE;
    object _25741 = NOVALUE;
    object _25739 = NOVALUE;
    object _25737 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:172		for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_50176)){
            _25737 = SEQ_PTR(_opts_50176)->length;
    }
    else {
        _25737 = 1;
    }
    {
        object _i_50178;
        _i_50178 = 1LL;
L1: 
        if (_i_50178 > _25737){
            goto L2; // [12] 113
        }

        /** cominit.e:173			sequence o = opts[i]		*/
        DeRef(_o_50180);
        _2 = (object)SEQ_PTR(_opts_50176);
        _o_50180 = (object)*(((s1_ptr)_2)->base + _i_50178);
        Ref(_o_50180);

        /** cominit.e:174			integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (object)SEQ_PTR(_o_50180);
        _25739 = (object)*(((s1_ptr)_2)->base + 4LL);
        _has_case_50182 = find_from(99LL, _25739, 1LL);
        _25739 = NOVALUE;

        /** cominit.e:176			if has_case and equal(o[name_type], opt) then*/
        if (_has_case_50182 == 0) {
            goto L3; // [42] 67
        }
        _2 = (object)SEQ_PTR(_o_50180);
        _25742 = (object)*(((s1_ptr)_2)->base + _name_type_50174);
        if (_25742 == _opt_50175)
        _25743 = 1;
        else if (IS_ATOM_INT(_25742) && IS_ATOM_INT(_opt_50175))
        _25743 = 0;
        else
        _25743 = (compare(_25742, _opt_50175) == 0);
        _25742 = NOVALUE;
        if (_25743 == 0)
        {
            _25743 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25743 = NOVALUE;
        }

        /** cominit.e:177				return o*/
        DeRefDS(_opt_50175);
        DeRefDS(_opts_50176);
        return _o_50180;
        goto L4; // [64] 104
L3: 

        /** cominit.e:178			elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25744 = (_has_case_50182 == 0);
        if (_25744 == 0) {
            goto L5; // [72] 103
        }
        _2 = (object)SEQ_PTR(_o_50180);
        _25746 = (object)*(((s1_ptr)_2)->base + _name_type_50174);
        Ref(_25746);
        _25747 = _14lower(_25746);
        _25746 = NOVALUE;
        RefDS(_opt_50175);
        _25748 = _14lower(_opt_50175);
        if (_25747 == _25748)
        _25749 = 1;
        else if (IS_ATOM_INT(_25747) && IS_ATOM_INT(_25748))
        _25749 = 0;
        else
        _25749 = (compare(_25747, _25748) == 0);
        DeRef(_25747);
        _25747 = NOVALUE;
        DeRef(_25748);
        _25748 = NOVALUE;
        if (_25749 == 0)
        {
            _25749 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25749 = NOVALUE;
        }

        /** cominit.e:179				return o*/
        DeRefDS(_opt_50175);
        DeRefDS(_opts_50176);
        DeRef(_25744);
        _25744 = NOVALUE;
        return _o_50180;
L5: 
L4: 
        DeRef(_o_50180);
        _o_50180 = NOVALUE;

        /** cominit.e:181		end for*/
        _i_50178 = _i_50178 + 1LL;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** cominit.e:183		return {}*/
    RefDS(_22186);
    DeRefDS(_opt_50175);
    DeRefDS(_opts_50176);
    DeRef(_25744);
    _25744 = NOVALUE;
    return _22186;
    ;
}


object _49merge_parameters(object _a_50199, object _b_50200, object _opts_50201, object _dedupe_50202)
{
    object _i_50203 = NOVALUE;
    object _opt_50207 = NOVALUE;
    object _this_opt_50213 = NOVALUE;
    object _bi_50214 = NOVALUE;
    object _beginLen_50274 = NOVALUE;
    object _first_extra_50296 = NOVALUE;
    object _opt_50300 = NOVALUE;
    object _this_opt_50305 = NOVALUE;
    object _25843 = NOVALUE;
    object _25842 = NOVALUE;
    object _25839 = NOVALUE;
    object _25838 = NOVALUE;
    object _25837 = NOVALUE;
    object _25835 = NOVALUE;
    object _25834 = NOVALUE;
    object _25833 = NOVALUE;
    object _25832 = NOVALUE;
    object _25830 = NOVALUE;
    object _25829 = NOVALUE;
    object _25827 = NOVALUE;
    object _25826 = NOVALUE;
    object _25825 = NOVALUE;
    object _25824 = NOVALUE;
    object _25823 = NOVALUE;
    object _25822 = NOVALUE;
    object _25821 = NOVALUE;
    object _25819 = NOVALUE;
    object _25816 = NOVALUE;
    object _25815 = NOVALUE;
    object _25810 = NOVALUE;
    object _25808 = NOVALUE;
    object _25807 = NOVALUE;
    object _25806 = NOVALUE;
    object _25805 = NOVALUE;
    object _25804 = NOVALUE;
    object _25803 = NOVALUE;
    object _25802 = NOVALUE;
    object _25801 = NOVALUE;
    object _25797 = NOVALUE;
    object _25796 = NOVALUE;
    object _25795 = NOVALUE;
    object _25794 = NOVALUE;
    object _25793 = NOVALUE;
    object _25792 = NOVALUE;
    object _25791 = NOVALUE;
    object _25790 = NOVALUE;
    object _25789 = NOVALUE;
    object _25788 = NOVALUE;
    object _25787 = NOVALUE;
    object _25786 = NOVALUE;
    object _25785 = NOVALUE;
    object _25784 = NOVALUE;
    object _25783 = NOVALUE;
    object _25781 = NOVALUE;
    object _25780 = NOVALUE;
    object _25779 = NOVALUE;
    object _25778 = NOVALUE;
    object _25777 = NOVALUE;
    object _25776 = NOVALUE;
    object _25775 = NOVALUE;
    object _25774 = NOVALUE;
    object _25772 = NOVALUE;
    object _25771 = NOVALUE;
    object _25770 = NOVALUE;
    object _25769 = NOVALUE;
    object _25767 = NOVALUE;
    object _25766 = NOVALUE;
    object _25765 = NOVALUE;
    object _25764 = NOVALUE;
    object _25763 = NOVALUE;
    object _25762 = NOVALUE;
    object _25761 = NOVALUE;
    object _25759 = NOVALUE;
    object _25758 = NOVALUE;
    object _25756 = NOVALUE;
    object _25753 = NOVALUE;
    object _25750 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:199		integer i = 1*/
    _i_50203 = 1LL;

    /** cominit.e:201		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_50199)){
            _25750 = SEQ_PTR(_a_50199)->length;
    }
    else {
        _25750 = 1;
    }
    if (_i_50203 > _25750)
    goto L2; // [22] 465

    /** cominit.e:202			sequence opt = a[i]*/
    DeRef(_opt_50207);
    _2 = (object)SEQ_PTR(_a_50199);
    _opt_50207 = (object)*(((s1_ptr)_2)->base + _i_50203);
    Ref(_opt_50207);

    /** cominit.e:203			if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_50207)){
            _25753 = SEQ_PTR(_opt_50207)->length;
    }
    else {
        _25753 = 1;
    }
    if (_25753 >= 2LL)
    goto L3; // [39] 56

    /** cominit.e:204				i += 1*/
    _i_50203 = _i_50203 + 1;

    /** cominit.e:205				continue*/
    DeRefDS(_opt_50207);
    _opt_50207 = NOVALUE;
    DeRef(_this_opt_50213);
    _this_opt_50213 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** cominit.e:208			sequence this_opt = {}*/
    RefDS(_22186);
    DeRef(_this_opt_50213);
    _this_opt_50213 = _22186;

    /** cominit.e:209			integer bi = 0*/
    _bi_50214 = 0LL;

    /** cominit.e:211			if opt[2] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50207);
    _25756 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25756, 45LL)){
        _25756 = NOVALUE;
        goto L4; // [74] 149
    }
    _25756 = NOVALUE;

    /** cominit.e:214				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50207)){
            _25758 = SEQ_PTR(_opt_50207)->length;
    }
    else {
        _25758 = 1;
    }
    rhs_slice_target = (object_ptr)&_25759;
    RHS_Slice(_opt_50207, 3LL, _25758);
    RefDS(_opts_50201);
    _0 = _this_opt_50213;
    _this_opt_50213 = _49find_opt(2LL, _25759, _opts_50201);
    DeRefDS(_0);
    _25759 = NOVALUE;

    /** cominit.e:216				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50200)){
            _25761 = SEQ_PTR(_b_50200)->length;
    }
    else {
        _25761 = 1;
    }
    {
        object _j_50222;
        _j_50222 = 1LL;
L5: 
        if (_j_50222 > _25761){
            goto L6; // [101] 146
        }

        /** cominit.e:217					if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (object)SEQ_PTR(_b_50200);
        _25762 = (object)*(((s1_ptr)_2)->base + _j_50222);
        Ref(_25762);
        _25763 = _14lower(_25762);
        _25762 = NOVALUE;
        RefDS(_opt_50207);
        _25764 = _14lower(_opt_50207);
        if (_25763 == _25764)
        _25765 = 1;
        else if (IS_ATOM_INT(_25763) && IS_ATOM_INT(_25764))
        _25765 = 0;
        else
        _25765 = (compare(_25763, _25764) == 0);
        DeRef(_25763);
        _25763 = NOVALUE;
        DeRef(_25764);
        _25764 = NOVALUE;
        if (_25765 == 0)
        {
            _25765 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25765 = NOVALUE;
        }

        /** cominit.e:218						bi = j*/
        _bi_50214 = _j_50222;

        /** cominit.e:219						exit*/
        goto L6; // [136] 146
L7: 

        /** cominit.e:221				end for*/
        _j_50222 = _j_50222 + 1LL;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** cominit.e:223			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50207);
    _25766 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25766)) {
        _25767 = (_25766 == 45LL);
    }
    else {
        _25767 = binary_op(EQUALS, _25766, 45LL);
    }
    _25766 = NOVALUE;
    if (IS_ATOM_INT(_25767)) {
        if (_25767 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25767)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (object)SEQ_PTR(_opt_50207);
    _25769 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25769)) {
        _25770 = (_25769 == 47LL);
    }
    else {
        _25770 = binary_op(EQUALS, _25769, 47LL);
    }
    _25769 = NOVALUE;
    if (_25770 == 0) {
        DeRef(_25770);
        _25770 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25770) && DBL_PTR(_25770)->dbl == 0.0){
            DeRef(_25770);
            _25770 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25770);
        _25770 = NOVALUE;
    }
    DeRef(_25770);
    _25770 = NOVALUE;
L9: 

    /** cominit.e:226				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50207)){
            _25771 = SEQ_PTR(_opt_50207)->length;
    }
    else {
        _25771 = 1;
    }
    rhs_slice_target = (object_ptr)&_25772;
    RHS_Slice(_opt_50207, 2LL, _25771);
    RefDS(_opts_50201);
    _0 = _this_opt_50213;
    _this_opt_50213 = _49find_opt(1LL, _25772, _opts_50201);
    DeRef(_0);
    _25772 = NOVALUE;

    /** cominit.e:228				for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_50200)){
            _25774 = SEQ_PTR(_b_50200)->length;
    }
    else {
        _25774 = 1;
    }
    {
        object _j_50239;
        _j_50239 = 1LL;
LB: 
        if (_j_50239 > _25774){
            goto LC; // [199] 290
        }

        /** cominit.e:229					if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (object)SEQ_PTR(_b_50200);
        _25775 = (object)*(((s1_ptr)_2)->base + _j_50239);
        Ref(_25775);
        _25776 = _14lower(_25775);
        _25775 = NOVALUE;
        if (IS_SEQUENCE(_opt_50207)){
                _25777 = SEQ_PTR(_opt_50207)->length;
        }
        else {
            _25777 = 1;
        }
        rhs_slice_target = (object_ptr)&_25778;
        RHS_Slice(_opt_50207, 2LL, _25777);
        _25779 = _14lower(_25778);
        _25778 = NOVALUE;
        if (IS_SEQUENCE(45LL) && IS_ATOM(_25779)) {
        }
        else if (IS_ATOM(45LL) && IS_SEQUENCE(_25779)) {
            Prepend(&_25780, _25779, 45LL);
        }
        else {
            Concat((object_ptr)&_25780, 45LL, _25779);
        }
        DeRef(_25779);
        _25779 = NOVALUE;
        if (_25776 == _25780)
        _25781 = 1;
        else if (IS_ATOM_INT(_25776) && IS_ATOM_INT(_25780))
        _25781 = 0;
        else
        _25781 = (compare(_25776, _25780) == 0);
        DeRef(_25776);
        _25776 = NOVALUE;
        DeRefDS(_25780);
        _25780 = NOVALUE;
        if (_25781 != 0) {
            goto LD; // [236] 273
        }
        _2 = (object)SEQ_PTR(_b_50200);
        _25783 = (object)*(((s1_ptr)_2)->base + _j_50239);
        Ref(_25783);
        _25784 = _14lower(_25783);
        _25783 = NOVALUE;
        if (IS_SEQUENCE(_opt_50207)){
                _25785 = SEQ_PTR(_opt_50207)->length;
        }
        else {
            _25785 = 1;
        }
        rhs_slice_target = (object_ptr)&_25786;
        RHS_Slice(_opt_50207, 2LL, _25785);
        _25787 = _14lower(_25786);
        _25786 = NOVALUE;
        if (IS_SEQUENCE(47LL) && IS_ATOM(_25787)) {
        }
        else if (IS_ATOM(47LL) && IS_SEQUENCE(_25787)) {
            Prepend(&_25788, _25787, 47LL);
        }
        else {
            Concat((object_ptr)&_25788, 47LL, _25787);
        }
        DeRef(_25787);
        _25787 = NOVALUE;
        if (_25784 == _25788)
        _25789 = 1;
        else if (IS_ATOM_INT(_25784) && IS_ATOM_INT(_25788))
        _25789 = 0;
        else
        _25789 = (compare(_25784, _25788) == 0);
        DeRef(_25784);
        _25784 = NOVALUE;
        DeRefDS(_25788);
        _25788 = NOVALUE;
        if (_25789 == 0)
        {
            _25789 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25789 = NOVALUE;
        }
LD: 

        /** cominit.e:232						bi = j*/
        _bi_50214 = _j_50239;

        /** cominit.e:233						exit*/
        goto LC; // [280] 290
LE: 

        /** cominit.e:235				end for*/
        _j_50239 = _j_50239 + 1LL;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** cominit.e:243			if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_50213)){
            _25790 = SEQ_PTR(_this_opt_50213)->length;
    }
    else {
        _25790 = 1;
    }
    if (_25790 == 0) {
        goto LF; // [297] 451
    }
    _2 = (object)SEQ_PTR(_this_opt_50213);
    _25792 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25793 = find_from(42LL, _25792, 1LL);
    _25792 = NOVALUE;
    _25794 = (_25793 == 0);
    _25793 = NOVALUE;
    if (_25794 == 0)
    {
        DeRef(_25794);
        _25794 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25794);
        _25794 = NOVALUE;
    }

    /** cominit.e:244				if bi then*/
    if (_bi_50214 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** cominit.e:245					if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50213);
    _25795 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25796 = find_from(112LL, _25795, 1LL);
    _25795 = NOVALUE;
    if (_25796 == 0)
    {
        _25796 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25796 = NOVALUE;
    }

    /** cominit.e:247						a = remove(a, i, i + 1)*/
    _25797 = _i_50203 + 1;
    if (_25797 > MAXINT){
        _25797 = NewDouble((eudouble)_25797);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_50199);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50203)) ? _i_50203 : (object)(DBL_PTR(_i_50203)->dbl);
        int stop = (IS_ATOM_INT(_25797)) ? _25797 : (object)(DBL_PTR(_25797)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50199), start, &_a_50199 );
            }
            else Tail(SEQ_PTR(_a_50199), stop+1, &_a_50199);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50199), start, &_a_50199);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50199 = Remove_elements(start, stop, (SEQ_PTR(_a_50199)->ref == 1));
        }
    }
    DeRef(_25797);
    _25797 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** cominit.e:250						a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_50199);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_50203)) ? _i_50203 : (object)(DBL_PTR(_i_50203)->dbl);
        int stop = (IS_ATOM_INT(_i_50203)) ? _i_50203 : (object)(DBL_PTR(_i_50203)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_50199), start, &_a_50199 );
            }
            else Tail(SEQ_PTR(_a_50199), stop+1, &_a_50199);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_50199), start, &_a_50199);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_50199 = Remove_elements(start, stop, (SEQ_PTR(_a_50199)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** cominit.e:265					integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_50199)){
            _beginLen_50274 = SEQ_PTR(_a_50199)->length;
    }
    else {
        _beginLen_50274 = 1;
    }

    /** cominit.e:267					if dedupe = 0 and i < beginLen then*/
    _25801 = (_dedupe_50202 == 0LL);
    if (_25801 == 0) {
        goto L13; // [376] 438
    }
    _25803 = (_i_50203 < _beginLen_50274);
    if (_25803 == 0)
    {
        DeRef(_25803);
        _25803 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25803);
        _25803 = NOVALUE;
    }

    /** cominit.e:268						a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25804 = _i_50203 + 1;
    if (_25804 > MAXINT){
        _25804 = NewDouble((eudouble)_25804);
    }
    if (IS_SEQUENCE(_a_50199)){
            _25805 = SEQ_PTR(_a_50199)->length;
    }
    else {
        _25805 = 1;
    }
    rhs_slice_target = (object_ptr)&_25806;
    RHS_Slice(_a_50199, _25804, _25805);
    rhs_slice_target = (object_ptr)&_25807;
    RHS_Slice(_a_50199, 1LL, _i_50203);
    RefDS(_opts_50201);
    DeRef(_25808);
    _25808 = _opts_50201;
    _0 = _a_50199;
    _a_50199 = _49merge_parameters(_25806, _25807, _25808, 1LL);
    DeRefDS(_0);
    _25806 = NOVALUE;
    _25807 = NOVALUE;
    _25808 = NOVALUE;

    /** cominit.e:270						if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_50199)){
            _25810 = SEQ_PTR(_a_50199)->length;
    }
    else {
        _25810 = 1;
    }
    if (_beginLen_50274 != _25810)
    goto L14; // [424] 445

    /** cominit.e:272							i += 1*/
    _i_50203 = _i_50203 + 1;
    goto L14; // [435] 445
L13: 

    /** cominit.e:276						i += 1*/
    _i_50203 = _i_50203 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** cominit.e:282				i += 1*/
    _i_50203 = _i_50203 + 1;
L12: 
    DeRef(_opt_50207);
    _opt_50207 = NOVALUE;
    DeRef(_this_opt_50213);
    _this_opt_50213 = NOVALUE;

    /** cominit.e:284		end while*/
    goto L1; // [462] 19
L2: 

    /** cominit.e:286		if dedupe then*/
    if (_dedupe_50202 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** cominit.e:287			return b & a*/
    Concat((object_ptr)&_25815, _b_50200, _a_50199);
    DeRefDS(_a_50199);
    DeRefDS(_b_50200);
    DeRefDS(_opts_50201);
    DeRef(_25767);
    _25767 = NOVALUE;
    DeRef(_25801);
    _25801 = NOVALUE;
    DeRef(_25804);
    _25804 = NOVALUE;
    return _25815;
L15: 

    /** cominit.e:290		integer first_extra = 0*/
    _first_extra_50296 = 0LL;

    /** cominit.e:292		i = 1*/
    _i_50203 = 1LL;

    /** cominit.e:295		while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_50200)){
            _25816 = SEQ_PTR(_b_50200)->length;
    }
    else {
        _25816 = 1;
    }
    if (_i_50203 > _25816)
    goto L17; // [499] 692

    /** cominit.e:296			sequence opt = b[i]*/
    DeRef(_opt_50300);
    _2 = (object)SEQ_PTR(_b_50200);
    _opt_50300 = (object)*(((s1_ptr)_2)->base + _i_50203);
    Ref(_opt_50300);

    /** cominit.e:299			if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_50300)){
            _25819 = SEQ_PTR(_opt_50300)->length;
    }
    else {
        _25819 = 1;
    }
    if (_25819 > 1LL)
    goto L18; // [516] 532

    /** cominit.e:300				first_extra = i*/
    _first_extra_50296 = _i_50203;

    /** cominit.e:301				exit*/
    DeRefDS(_opt_50300);
    _opt_50300 = NOVALUE;
    DeRef(_this_opt_50305);
    _this_opt_50305 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** cominit.e:304			sequence this_opt = {}*/
    RefDS(_22186);
    DeRef(_this_opt_50305);
    _this_opt_50305 = _22186;

    /** cominit.e:305			if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (object)SEQ_PTR(_opt_50300);
    _25821 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25821)) {
        _25822 = (_25821 == 45LL);
    }
    else {
        _25822 = binary_op(EQUALS, _25821, 45LL);
    }
    _25821 = NOVALUE;
    if (IS_ATOM_INT(_25822)) {
        if (_25822 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25822)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (object)SEQ_PTR(_opt_50300);
    _25824 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25824)) {
        _25825 = (_25824 == 45LL);
    }
    else {
        _25825 = binary_op(EQUALS, _25824, 45LL);
    }
    _25824 = NOVALUE;
    if (_25825 == 0) {
        DeRef(_25825);
        _25825 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25825) && DBL_PTR(_25825)->dbl == 0.0){
            DeRef(_25825);
            _25825 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25825);
        _25825 = NOVALUE;
    }
    DeRef(_25825);
    _25825 = NOVALUE;

    /** cominit.e:306				this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_50300)){
            _25826 = SEQ_PTR(_opt_50300)->length;
    }
    else {
        _25826 = 1;
    }
    rhs_slice_target = (object_ptr)&_25827;
    RHS_Slice(_opt_50300, 3LL, _25826);
    RefDS(_opts_50201);
    _0 = _this_opt_50305;
    _this_opt_50305 = _49find_opt(2LL, _25827, _opts_50201);
    DeRef(_0);
    _25827 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** cominit.e:307			elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (object)SEQ_PTR(_opt_50300);
    _25829 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25829)) {
        _25830 = (_25829 == 45LL);
    }
    else {
        _25830 = binary_op(EQUALS, _25829, 45LL);
    }
    _25829 = NOVALUE;
    if (IS_ATOM_INT(_25830)) {
        if (_25830 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25830)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (object)SEQ_PTR(_opt_50300);
    _25832 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_25832)) {
        _25833 = (_25832 == 47LL);
    }
    else {
        _25833 = binary_op(EQUALS, _25832, 47LL);
    }
    _25832 = NOVALUE;
    if (_25833 == 0) {
        DeRef(_25833);
        _25833 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25833) && DBL_PTR(_25833)->dbl == 0.0){
            DeRef(_25833);
            _25833 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25833);
        _25833 = NOVALUE;
    }
    DeRef(_25833);
    _25833 = NOVALUE;
L1B: 

    /** cominit.e:308				this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_50300)){
            _25834 = SEQ_PTR(_opt_50300)->length;
    }
    else {
        _25834 = 1;
    }
    rhs_slice_target = (object_ptr)&_25835;
    RHS_Slice(_opt_50300, 2LL, _25834);
    RefDS(_opts_50201);
    _0 = _this_opt_50305;
    _this_opt_50305 = _49find_opt(1LL, _25835, _opts_50201);
    DeRef(_0);
    _25835 = NOVALUE;
L1C: 
L1A: 

    /** cominit.e:311			if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_50305)){
            _25837 = SEQ_PTR(_this_opt_50305)->length;
    }
    else {
        _25837 = 1;
    }
    if (_25837 == 0)
    {
        _25837 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25837 = NOVALUE;
    }

    /** cominit.e:312				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (object)SEQ_PTR(_this_opt_50305);
    _25838 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25839 = find_from(112LL, _25838, 1LL);
    _25838 = NOVALUE;
    if (_25839 == 0)
    {
        _25839 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25839 = NOVALUE;
    }

    /** cominit.e:313					i += 1*/
    _i_50203 = _i_50203 + 1;
    goto L1E; // [664] 679
L1D: 

    /** cominit.e:316				first_extra = i*/
    _first_extra_50296 = _i_50203;

    /** cominit.e:317				exit*/
    DeRef(_opt_50300);
    _opt_50300 = NOVALUE;
    DeRef(_this_opt_50305);
    _this_opt_50305 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** cominit.e:320			i += 1*/
    _i_50203 = _i_50203 + 1;
    DeRef(_opt_50300);
    _opt_50300 = NOVALUE;
    DeRef(_this_opt_50305);
    _this_opt_50305 = NOVALUE;

    /** cominit.e:321		end while*/
    goto L16; // [689] 496
L17: 

    /** cominit.e:323		if first_extra then*/
    if (_first_extra_50296 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** cominit.e:324			return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_50296;
        if (insert_pos <= 0) {
            Concat(&_25842,_a_50199,_b_50200);
        }
        else if (insert_pos > SEQ_PTR(_b_50200)->length){
            Concat(&_25842,_b_50200,_a_50199);
        }
        else if (IS_SEQUENCE(_a_50199)) {
            if( _25842 != _b_50200 || SEQ_PTR( _b_50200 )->ref != 1 ){
                DeRef( _25842 );
                RefDS( _b_50200 );
            }
            assign_space = Add_internal_space( _b_50200, insert_pos,((s1_ptr)SEQ_PTR(_a_50199))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_50199), _b_50200 == _25842 );
            _25842 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25842 == _b_50200 && SEQ_PTR( _b_50200 )->ref == 1 ){
                _25842 = Insert( _b_50200, _a_50199, insert_pos);
            }
            else {
                DeRef( _25842 );
                RefDS( _b_50200 );
                _25842 = Insert( _b_50200, _a_50199, insert_pos);
            }
        }
    }
    DeRefDS(_a_50199);
    DeRefDS(_b_50200);
    DeRefDS(_opts_50201);
    DeRef(_25767);
    _25767 = NOVALUE;
    DeRef(_25801);
    _25801 = NOVALUE;
    DeRef(_25815);
    _25815 = NOVALUE;
    DeRef(_25830);
    _25830 = NOVALUE;
    DeRef(_25822);
    _25822 = NOVALUE;
    DeRef(_25804);
    _25804 = NOVALUE;
    return _25842;
L1F: 

    /** cominit.e:328		return b & a*/
    Concat((object_ptr)&_25843, _b_50200, _a_50199);
    DeRefDS(_a_50199);
    DeRefDS(_b_50200);
    DeRefDS(_opts_50201);
    DeRef(_25767);
    _25767 = NOVALUE;
    DeRef(_25842);
    _25842 = NOVALUE;
    DeRef(_25801);
    _25801 = NOVALUE;
    DeRef(_25815);
    _25815 = NOVALUE;
    DeRef(_25830);
    _25830 = NOVALUE;
    DeRef(_25822);
    _25822 = NOVALUE;
    DeRef(_25804);
    _25804 = NOVALUE;
    return _25843;
    ;
}


object _49validate_opt(object _opt_type_50338, object _arg_50339, object _args_50340, object _ix_50341)
{
    object _opt_50342 = NOVALUE;
    object _this_opt_50350 = NOVALUE;
    object _25862 = NOVALUE;
    object _25861 = NOVALUE;
    object _25860 = NOVALUE;
    object _25859 = NOVALUE;
    object _25858 = NOVALUE;
    object _25856 = NOVALUE;
    object _25855 = NOVALUE;
    object _25854 = NOVALUE;
    object _25853 = NOVALUE;
    object _25852 = NOVALUE;
    object _25850 = NOVALUE;
    object _25847 = NOVALUE;
    object _25845 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:336		if opt_type = SHORTNAME then*/
    if (_opt_type_50338 != 1LL)
    goto L1; // [11] 28

    /** cominit.e:337			opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_50339)){
            _25845 = SEQ_PTR(_arg_50339)->length;
    }
    else {
        _25845 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50342;
    RHS_Slice(_arg_50339, 2LL, _25845);
    goto L2; // [25] 39
L1: 

    /** cominit.e:339			opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_50339)){
            _25847 = SEQ_PTR(_arg_50339)->length;
    }
    else {
        _25847 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_50342;
    RHS_Slice(_arg_50339, 3LL, _25847);
L2: 

    /** cominit.e:342		sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_50342);
    RefDS(_49options_50075);
    _0 = _this_opt_50350;
    _this_opt_50350 = _49find_opt(_opt_type_50338, _opt_50342, _49options_50075);
    DeRef(_0);

    /** cominit.e:343		if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_50350)){
            _25850 = SEQ_PTR(_this_opt_50350)->length;
    }
    else {
        _25850 = 1;
    }
    if (_25850 != 0)
    goto L3; // [58] 72
    _25850 = NOVALUE;

    /** cominit.e:345			return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _25852 = MAKE_SEQ(_1);
    DeRefDS(_arg_50339);
    DeRefDS(_args_50340);
    DeRefDS(_opt_50342);
    DeRefDS(_this_opt_50350);
    return _25852;
L3: 

    /** cominit.e:348		if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (object)SEQ_PTR(_this_opt_50350);
    _25853 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25854 = find_from(112LL, _25853, 1LL);
    _25853 = NOVALUE;
    if (_25854 == 0)
    {
        _25854 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25854 = NOVALUE;
    }

    /** cominit.e:349			if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_50340)){
            _25855 = SEQ_PTR(_args_50340)->length;
    }
    else {
        _25855 = 1;
    }
    _25856 = _25855 - 1LL;
    _25855 = NOVALUE;
    if (_ix_50341 != _25856)
    goto L5; // [97] 117

    /** cominit.e:351				CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_arg_50339);
    ((intptr_t*)_2)[1] = _arg_50339;
    _25858 = MAKE_SEQ(_1);
    _50CompileErr(353LL, _25858, 0LL);
    _25858 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** cominit.e:353				return { ix, ix + 2 }*/
    _25859 = _ix_50341 + 2LL;
    if ((object)((uintptr_t)_25859 + (uintptr_t)HIGH_BITS) >= 0){
        _25859 = NewDouble((eudouble)_25859);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50341;
    ((intptr_t *)_2)[2] = _25859;
    _25860 = MAKE_SEQ(_1);
    _25859 = NOVALUE;
    DeRefDS(_arg_50339);
    DeRefDS(_args_50340);
    DeRef(_opt_50342);
    DeRef(_this_opt_50350);
    DeRef(_25856);
    _25856 = NOVALUE;
    DeRef(_25852);
    _25852 = NOVALUE;
    return _25860;
    goto L6; // [132] 150
L4: 

    /** cominit.e:356			return { ix, ix + 1 }*/
    _25861 = _ix_50341 + 1;
    if (_25861 > MAXINT){
        _25861 = NewDouble((eudouble)_25861);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _ix_50341;
    ((intptr_t *)_2)[2] = _25861;
    _25862 = MAKE_SEQ(_1);
    _25861 = NOVALUE;
    DeRefDS(_arg_50339);
    DeRefDS(_args_50340);
    DeRef(_opt_50342);
    DeRef(_this_opt_50350);
    DeRef(_25860);
    _25860 = NOVALUE;
    DeRef(_25856);
    _25856 = NOVALUE;
    DeRef(_25852);
    _25852 = NOVALUE;
    return _25862;
L6: 
    ;
}


object _49find_next_opt(object _ix_50375, object _args_50376)
{
    object _arg_50380 = NOVALUE;
    object _25884 = NOVALUE;
    object _25883 = NOVALUE;
    object _25881 = NOVALUE;
    object _25880 = NOVALUE;
    object _25879 = NOVALUE;
    object _25878 = NOVALUE;
    object _25877 = NOVALUE;
    object _25876 = NOVALUE;
    object _25875 = NOVALUE;
    object _25874 = NOVALUE;
    object _25872 = NOVALUE;
    object _25870 = NOVALUE;
    object _25868 = NOVALUE;
    object _25866 = NOVALUE;
    object _25863 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:374		while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_50376)){
            _25863 = SEQ_PTR(_args_50376)->length;
    }
    else {
        _25863 = 1;
    }
    if (_ix_50375 >= _25863)
    goto L2; // [13] 157

    /** cominit.e:375			sequence arg = args[ix]*/
    DeRef(_arg_50380);
    _2 = (object)SEQ_PTR(_args_50376);
    _arg_50380 = (object)*(((s1_ptr)_2)->base + _ix_50375);
    Ref(_arg_50380);

    /** cominit.e:376			if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_50380)){
            _25866 = SEQ_PTR(_arg_50380)->length;
    }
    else {
        _25866 = 1;
    }
    if (_25866 <= 1LL)
    goto L3; // [30] 129

    /** cominit.e:377				if arg[1] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50380);
    _25868 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _25868, 45LL)){
        _25868 = NOVALUE;
        goto L4; // [40] 111
    }
    _25868 = NOVALUE;

    /** cominit.e:378					if arg[2] = '-' then*/
    _2 = (object)SEQ_PTR(_arg_50380);
    _25870 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(NOTEQ, _25870, 45LL)){
        _25870 = NOVALUE;
        goto L5; // [50] 94
    }
    _25870 = NOVALUE;

    /** cominit.e:380						if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_50380)){
            _25872 = SEQ_PTR(_arg_50380)->length;
    }
    else {
        _25872 = 1;
    }
    if (_25872 != 2LL)
    goto L6; // [59] 78

    /** cominit.e:382							return { 0, ix - 1 }*/
    _25874 = _ix_50375 - 1LL;
    if ((object)((uintptr_t)_25874 +(uintptr_t) HIGH_BITS) >= 0){
        _25874 = NewDouble((eudouble)_25874);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25874;
    _25875 = MAKE_SEQ(_1);
    _25874 = NOVALUE;
    DeRefDS(_arg_50380);
    DeRefDS(_args_50376);
    return _25875;
L6: 

    /** cominit.e:385						return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_50380);
    RefDS(_args_50376);
    _25876 = _49validate_opt(2LL, _arg_50380, _args_50376, _ix_50375);
    DeRefDS(_arg_50380);
    DeRefDS(_args_50376);
    DeRef(_25875);
    _25875 = NOVALUE;
    return _25876;
    goto L7; // [91] 144
L5: 

    /** cominit.e:389						return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_50380);
    RefDS(_args_50376);
    _25877 = _49validate_opt(1LL, _arg_50380, _args_50376, _ix_50375);
    DeRefDS(_arg_50380);
    DeRefDS(_args_50376);
    DeRef(_25876);
    _25876 = NOVALUE;
    DeRef(_25875);
    _25875 = NOVALUE;
    return _25877;
    goto L7; // [108] 144
L4: 

    /** cominit.e:393					return {0, ix-1}*/
    _25878 = _ix_50375 - 1LL;
    if ((object)((uintptr_t)_25878 +(uintptr_t) HIGH_BITS) >= 0){
        _25878 = NewDouble((eudouble)_25878);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25878;
    _25879 = MAKE_SEQ(_1);
    _25878 = NOVALUE;
    DeRef(_arg_50380);
    DeRefDS(_args_50376);
    DeRef(_25876);
    _25876 = NOVALUE;
    DeRef(_25875);
    _25875 = NOVALUE;
    DeRef(_25877);
    _25877 = NOVALUE;
    return _25879;
    goto L7; // [126] 144
L3: 

    /** cominit.e:397				return { 0, ix-1 }*/
    _25880 = _ix_50375 - 1LL;
    if ((object)((uintptr_t)_25880 +(uintptr_t) HIGH_BITS) >= 0){
        _25880 = NewDouble((eudouble)_25880);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25880;
    _25881 = MAKE_SEQ(_1);
    _25880 = NOVALUE;
    DeRef(_arg_50380);
    DeRefDS(_args_50376);
    DeRef(_25879);
    _25879 = NOVALUE;
    DeRef(_25876);
    _25876 = NOVALUE;
    DeRef(_25875);
    _25875 = NOVALUE;
    DeRef(_25877);
    _25877 = NOVALUE;
    return _25881;
L7: 

    /** cominit.e:400			ix += 1*/
    _ix_50375 = _ix_50375 + 1;
    DeRef(_arg_50380);
    _arg_50380 = NOVALUE;

    /** cominit.e:401		end while*/
    goto L1; // [154] 10
L2: 

    /** cominit.e:402		return {0, ix-1}*/
    _25883 = _ix_50375 - 1LL;
    if ((object)((uintptr_t)_25883 +(uintptr_t) HIGH_BITS) >= 0){
        _25883 = NewDouble((eudouble)_25883);
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = _25883;
    _25884 = MAKE_SEQ(_1);
    _25883 = NOVALUE;
    DeRefDS(_args_50376);
    DeRef(_25879);
    _25879 = NOVALUE;
    DeRef(_25876);
    _25876 = NOVALUE;
    DeRef(_25881);
    _25881 = NOVALUE;
    DeRef(_25875);
    _25875 = NOVALUE;
    DeRef(_25877);
    _25877 = NOVALUE;
    return _25884;
    ;
}


object _49expand_config_options(object _args_50410)
{
    object _idx_50411 = NOVALUE;
    object _next_idx_50412 = NOVALUE;
    object _files_50413 = NOVALUE;
    object _cmd_1_2_50414 = NOVALUE;
    object _25907 = NOVALUE;
    object _25906 = NOVALUE;
    object _25905 = NOVALUE;
    object _25904 = NOVALUE;
    object _25903 = NOVALUE;
    object _25902 = NOVALUE;
    object _25901 = NOVALUE;
    object _25900 = NOVALUE;
    object _25899 = NOVALUE;
    object _25894 = NOVALUE;
    object _25892 = NOVALUE;
    object _25891 = NOVALUE;
    object _25890 = NOVALUE;
    object _25888 = NOVALUE;
    object _25887 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:410		integer idx = 1*/
    _idx_50411 = 1LL;

    /** cominit.e:412		sequence files = {}*/
    RefDS(_22186);
    DeRef(_files_50413);
    _files_50413 = _22186;

    /** cominit.e:413		sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_50414;
    RHS_Slice(_args_50410, 1LL, 2LL);

    /** cominit.e:414		args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_50410);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(2LL)) ? 2LL : (object)(DBL_PTR(2LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50410), start, &_args_50410 );
            }
            else Tail(SEQ_PTR(_args_50410), stop+1, &_args_50410);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50410), start, &_args_50410);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50410 = Remove_elements(start, stop, (SEQ_PTR(_args_50410)->ref == 1));
        }
    }

    /** cominit.e:416		while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_50411 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** cominit.e:417			if equal(upper(args[idx]), "-C") then*/
    _2 = (object)SEQ_PTR(_args_50410);
    _25887 = (object)*(((s1_ptr)_2)->base + _idx_50411);
    Ref(_25887);
    _25888 = _14upper(_25887);
    _25887 = NOVALUE;
    if (_25888 == _25889)
    _25890 = 1;
    else if (IS_ATOM_INT(_25888) && IS_ATOM_INT(_25889))
    _25890 = 0;
    else
    _25890 = (compare(_25888, _25889) == 0);
    DeRef(_25888);
    _25888 = NOVALUE;
    if (_25890 == 0)
    {
        _25890 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25890 = NOVALUE;
    }

    /** cominit.e:418				files = append( files, args[idx+1] )*/
    _25891 = _idx_50411 + 1;
    _2 = (object)SEQ_PTR(_args_50410);
    _25892 = (object)*(((s1_ptr)_2)->base + _25891);
    Ref(_25892);
    Append(&_files_50413, _files_50413, _25892);
    _25892 = NOVALUE;

    /** cominit.e:419				args = remove( args, idx, idx + 1 )*/
    _25894 = _idx_50411 + 1;
    if (_25894 > MAXINT){
        _25894 = NewDouble((eudouble)_25894);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_50410);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_50411)) ? _idx_50411 : (object)(DBL_PTR(_idx_50411)->dbl);
        int stop = (IS_ATOM_INT(_25894)) ? _25894 : (object)(DBL_PTR(_25894)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_50410), start, &_args_50410 );
            }
            else Tail(SEQ_PTR(_args_50410), stop+1, &_args_50410);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_50410), start, &_args_50410);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_50410 = Remove_elements(start, stop, (SEQ_PTR(_args_50410)->ref == 1));
        }
    }
    DeRef(_25894);
    _25894 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** cominit.e:422				idx = next_idx[2]*/
    _2 = (object)SEQ_PTR(_next_idx_50412);
    _idx_50411 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_idx_50411))
    _idx_50411 = (object)DBL_PTR(_idx_50411)->dbl;
L5: 

    /** cominit.e:424		entry*/
L1: 

    /** cominit.e:425			next_idx = find_next_opt( idx, args )*/
    RefDS(_args_50410);
    _0 = _next_idx_50412;
    _next_idx_50412 = _49find_next_opt(_idx_50411, _args_50410);
    DeRef(_0);

    /** cominit.e:426			idx = next_idx[1]*/
    _2 = (object)SEQ_PTR(_next_idx_50412);
    _idx_50411 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_idx_50411))
    _idx_50411 = (object)DBL_PTR(_idx_50411)->dbl;

    /** cominit.e:427		end while*/
    goto L2; // [111] 34
L3: 

    /** cominit.e:428		return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_50413);
    _25899 = _48GetDefaultArgs(_files_50413);
    _2 = (object)SEQ_PTR(_next_idx_50412);
    _25900 = (object)*(((s1_ptr)_2)->base + 2LL);
    rhs_slice_target = (object_ptr)&_25901;
    RHS_Slice(_args_50410, 1LL, _25900);
    RefDS(_49options_50075);
    _25902 = _49merge_parameters(_25899, _25901, _49options_50075, 1LL);
    _25899 = NOVALUE;
    _25901 = NOVALUE;
    _2 = (object)SEQ_PTR(_next_idx_50412);
    _25903 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_25903)) {
        _25904 = _25903 + 1;
        if (_25904 > MAXINT){
            _25904 = NewDouble((eudouble)_25904);
        }
    }
    else
    _25904 = binary_op(PLUS, 1, _25903);
    _25903 = NOVALUE;
    if (IS_SEQUENCE(_args_50410)){
            _25905 = SEQ_PTR(_args_50410)->length;
    }
    else {
        _25905 = 1;
    }
    rhs_slice_target = (object_ptr)&_25906;
    RHS_Slice(_args_50410, _25904, _25905);
    {
        object concat_list[3];

        concat_list[0] = _25906;
        concat_list[1] = _25902;
        concat_list[2] = _cmd_1_2_50414;
        Concat_N((object_ptr)&_25907, concat_list, 3);
    }
    DeRefDS(_25906);
    _25906 = NOVALUE;
    DeRef(_25902);
    _25902 = NOVALUE;
    DeRefDS(_args_50410);
    DeRefDS(_next_idx_50412);
    DeRefDS(_files_50413);
    DeRefDS(_cmd_1_2_50414);
    DeRef(_25891);
    _25891 = NOVALUE;
    _25900 = NOVALUE;
    DeRef(_25904);
    _25904 = NOVALUE;
    return _25907;
    ;
}


void _49handle_common_options(object _opts_50445)
{
    object _opt_keys_50446 = NOVALUE;
    object _option_w_50448 = NOVALUE;
    object _key_50452 = NOVALUE;
    object _val_50454 = NOVALUE;
    object _this_warn_50500 = NOVALUE;
    object _auto_add_warn_50502 = NOVALUE;
    object _n_50508 = NOVALUE;
    object _this_warn_50531 = NOVALUE;
    object _auto_add_warn_50533 = NOVALUE;
    object _n_50539 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_617_50575 = NOVALUE;
    object _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589 = NOVALUE;
    object _prompt_inlined_maybe_any_key_at_693_50588 = NOVALUE;
    object _25966 = NOVALUE;
    object _25965 = NOVALUE;
    object _25963 = NOVALUE;
    object _25961 = NOVALUE;
    object _25959 = NOVALUE;
    object _25958 = NOVALUE;
    object _25957 = NOVALUE;
    object _25956 = NOVALUE;
    object _25955 = NOVALUE;
    object _25954 = NOVALUE;
    object _25953 = NOVALUE;
    object _25952 = NOVALUE;
    object _25950 = NOVALUE;
    object _25948 = NOVALUE;
    object _25947 = NOVALUE;
    object _25946 = NOVALUE;
    object _25941 = NOVALUE;
    object _25939 = NOVALUE;
    object _25937 = NOVALUE;
    object _25934 = NOVALUE;
    object _25933 = NOVALUE;
    object _25928 = NOVALUE;
    object _25926 = NOVALUE;
    object _25924 = NOVALUE;
    object _25922 = NOVALUE;
    object _25921 = NOVALUE;
    object _25920 = NOVALUE;
    object _25919 = NOVALUE;
    object _25918 = NOVALUE;
    object _25917 = NOVALUE;
    object _25915 = NOVALUE;
    object _25914 = NOVALUE;
    object _25909 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:435		sequence opt_keys = m:keys(opts)*/
    Ref(_opts_50445);
    _0 = _opt_keys_50446;
    _opt_keys_50446 = _29keys(_opts_50445, 0LL);
    DeRef(_0);

    /** cominit.e:436		integer option_w = 0*/
    _option_w_50448 = 0LL;

    /** cominit.e:438		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_50446)){
            _25909 = SEQ_PTR(_opt_keys_50446)->length;
    }
    else {
        _25909 = 1;
    }
    {
        object _idx_50450;
        _idx_50450 = 1LL;
L1: 
        if (_idx_50450 > _25909){
            goto L2; // [20] 795
        }

        /** cominit.e:439			sequence key = opt_keys[idx]*/
        DeRef(_key_50452);
        _2 = (object)SEQ_PTR(_opt_keys_50446);
        _key_50452 = (object)*(((s1_ptr)_2)->base + _idx_50450);
        Ref(_key_50452);

        /** cominit.e:440			object val = m:get(opts, key)*/
        Ref(_opts_50445);
        RefDS(_key_50452);
        _0 = _val_50454;
        _val_50454 = _29get(_opts_50445, _key_50452, 0LL);
        DeRef(_0);

        /** cominit.e:442			switch key do*/
        _1 = find(_key_50452, _25912);
        switch ( _1 ){ 

            /** cominit.e:443				case "i" then*/
            case 1:

            /** cominit.e:444					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50454)){
                    _25914 = SEQ_PTR(_val_50454)->length;
            }
            else {
                _25914 = 1;
            }
            {
                object _i_50460;
                _i_50460 = 1LL;
L3: 
                if (_i_50460 > _25914){
                    goto L4; // [59] 82
                }

                /** cominit.e:445						add_include_directory(val[i])*/
                _2 = (object)SEQ_PTR(_val_50454);
                _25915 = (object)*(((s1_ptr)_2)->base + _i_50460);
                Ref(_25915);
                _48add_include_directory(_25915);
                _25915 = NOVALUE;

                /** cominit.e:446					end for*/
                _i_50460 = _i_50460 + 1LL;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 786

            /** cominit.e:448				case "d" then*/
            case 2:

            /** cominit.e:449					OpDefines &= val*/
            if (IS_SEQUENCE(_36OpDefines_21836) && IS_ATOM(_val_50454)) {
                Ref(_val_50454);
                Append(&_36OpDefines_21836, _36OpDefines_21836, _val_50454);
            }
            else if (IS_ATOM(_36OpDefines_21836) && IS_SEQUENCE(_val_50454)) {
            }
            else {
                Concat((object_ptr)&_36OpDefines_21836, _36OpDefines_21836, _val_50454);
            }
            goto L5; // [98] 786

            /** cominit.e:451				case "batch" then*/
            case 3:

            /** cominit.e:452					batch_job = 1*/
            _36batch_job_21772 = 1LL;
            goto L5; // [111] 786

            /** cominit.e:454				case "test" then*/
            case 4:

            /** cominit.e:455					test_only = 1*/
            _36test_only_21771 = 1LL;
            goto L5; // [124] 786

            /** cominit.e:457				case "strict" then*/
            case 5:

            /** cominit.e:458					Strict_is_on = 1*/
            _36Strict_is_on_21828 = 1LL;
            goto L5; // [137] 786

            /** cominit.e:460				case "p" then*/
            case 6:

            /** cominit.e:461					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50454)){
                    _25917 = SEQ_PTR(_val_50454)->length;
            }
            else {
                _25917 = 1;
            }
            {
                object _i_50475;
                _i_50475 = 1LL;
L6: 
                if (_i_50475 > _25917){
                    goto L7; // [148] 173
                }

                /** cominit.e:462						add_preprocessor(val[i])*/
                _2 = (object)SEQ_PTR(_val_50454);
                _25918 = (object)*(((s1_ptr)_2)->base + _i_50475);
                Ref(_25918);
                _64add_preprocessor(_25918, 0LL, 0LL);
                _25918 = NOVALUE;

                /** cominit.e:463					end for*/
                _i_50475 = _i_50475 + 1LL;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 786

            /** cominit.e:465				case "pf" then*/
            case 7:

            /** cominit.e:466					force_preprocessor = 1*/
            _37force_preprocessor_15655 = 1LL;
            goto L5; // [186] 786

            /** cominit.e:468				case "l" then*/
            case 8:

            /** cominit.e:469					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50454)){
                    _25919 = SEQ_PTR(_val_50454)->length;
            }
            else {
                _25919 = 1;
            }
            {
                object _i_50483;
                _i_50483 = 1LL;
L8: 
                if (_i_50483 > _25919){
                    goto L9; // [197] 238
                }

                /** cominit.e:470						LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (object)SEQ_PTR(_val_50454);
                _25920 = (object)*(((s1_ptr)_2)->base + _i_50483);
                Ref(_25920);
                _25921 = _14lower(_25920);
                _25920 = NOVALUE;
                RefDS(_22186);
                RefDS(_5);
                _25922 = _23filter(_25921, _23STDFLTR_ALPHA_5152, _22186, _5);
                _25921 = NOVALUE;
                Ref(_25922);
                Append(&_37LocalizeQual_15656, _37LocalizeQual_15656, _25922);
                DeRef(_25922);
                _25922 = NOVALUE;

                /** cominit.e:471					end for*/
                _i_50483 = _i_50483 + 1LL;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 786

            /** cominit.e:473				case "ldb" then*/
            case 9:

            /** cominit.e:474					LocalDB = val*/
            Ref(_val_50454);
            DeRef(_37LocalDB_15657);
            _37LocalDB_15657 = _val_50454;
            goto L5; // [251] 786

            /** cominit.e:476				case "w" then*/
            case 10:

            /** cominit.e:477					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50454)){
                    _25924 = SEQ_PTR(_val_50454)->length;
            }
            else {
                _25924 = 1;
            }
            {
                object _i_50498;
                _i_50498 = 1LL;
LA: 
                if (_i_50498 > _25924){
                    goto LB; // [262] 392
                }

                /** cominit.e:478						sequence this_warn = val[i]*/
                DeRef(_this_warn_50500);
                _2 = (object)SEQ_PTR(_val_50454);
                _this_warn_50500 = (object)*(((s1_ptr)_2)->base + _i_50498);
                Ref(_this_warn_50500);

                /** cominit.e:479						integer auto_add_warn = 0*/
                _auto_add_warn_50502 = 0LL;

                /** cominit.e:480						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50500);
                _25926 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _25926, 43LL)){
                    _25926 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25926 = NOVALUE;

                /** cominit.e:481							auto_add_warn = 1*/
                _auto_add_warn_50502 = 1LL;

                /** cominit.e:482							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50500)){
                        _25928 = SEQ_PTR(_this_warn_50500)->length;
                }
                else {
                    _25928 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50500;
                RHS_Slice(_this_warn_50500, 2LL, _25928);
LC: 

                /** cominit.e:484						integer n = find(this_warn, warning_names)*/
                _n_50508 = find_from(_this_warn_50500, _36warning_names_21807, 1LL);

                /** cominit.e:485						if n != 0 then*/
                if (_n_50508 == 0LL)
                goto LD; // [319] 383

                /** cominit.e:486							if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_50502 != 0) {
                    goto LE; // [325] 338
                }
                _25933 = (_option_w_50448 == 1LL);
                if (_25933 == 0)
                {
                    DeRef(_25933);
                    _25933 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25933);
                    _25933 = NOVALUE;
                }
LE: 

                /** cominit.e:487								OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (object)SEQ_PTR(_36warning_flags_21805);
                _25934 = (object)*(((s1_ptr)_2)->base + _n_50508);
                {uintptr_t tu;
                     tu = (uintptr_t)_36OpWarning_21830 | (uintptr_t)_25934;
                     _36OpWarning_21830 = MAKE_UINT(tu);
                }
                _25934 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21830)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21830)->dbl);
                    DeRefDS(_36OpWarning_21830);
                    _36OpWarning_21830 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** cominit.e:489								option_w = 1*/
                _option_w_50448 = 1LL;

                /** cominit.e:490								OpWarning = warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21805);
                _36OpWarning_21830 = (object)*(((s1_ptr)_2)->base + _n_50508);
L10: 

                /** cominit.e:493							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21831 = _36OpWarning_21830;
LD: 
                DeRef(_this_warn_50500);
                _this_warn_50500 = NOVALUE;

                /** cominit.e:495					end for*/
                _i_50498 = _i_50498 + 1LL;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 786

            /** cominit.e:497				case "x" then*/
            case 11:

            /** cominit.e:498					for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_50454)){
                    _25937 = SEQ_PTR(_val_50454)->length;
            }
            else {
                _25937 = 1;
            }
            {
                object _i_50529;
                _i_50529 = 1LL;
L11: 
                if (_i_50529 > _25937){
                    goto L12; // [403] 542
                }

                /** cominit.e:499						sequence this_warn = val[i]*/
                DeRef(_this_warn_50531);
                _2 = (object)SEQ_PTR(_val_50454);
                _this_warn_50531 = (object)*(((s1_ptr)_2)->base + _i_50529);
                Ref(_this_warn_50531);

                /** cominit.e:500						integer auto_add_warn = 0*/
                _auto_add_warn_50533 = 0LL;

                /** cominit.e:501						if this_warn[1] = '+' then*/
                _2 = (object)SEQ_PTR(_this_warn_50531);
                _25939 = (object)*(((s1_ptr)_2)->base + 1LL);
                if (binary_op_a(NOTEQ, _25939, 43LL)){
                    _25939 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25939 = NOVALUE;

                /** cominit.e:502							auto_add_warn = 1*/
                _auto_add_warn_50533 = 1LL;

                /** cominit.e:503							this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_50531)){
                        _25941 = SEQ_PTR(_this_warn_50531)->length;
                }
                else {
                    _25941 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_50531;
                RHS_Slice(_this_warn_50531, 2LL, _25941);
L13: 

                /** cominit.e:505						integer n = find(this_warn, warning_names)*/
                _n_50539 = find_from(_this_warn_50531, _36warning_names_21807, 1LL);

                /** cominit.e:506						if n != 0 then*/
                if (_n_50539 == 0LL)
                goto L14; // [460] 533

                /** cominit.e:507							if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_50533 != 0) {
                    goto L15; // [466] 479
                }
                _25946 = (_option_w_50448 == -1LL);
                if (_25946 == 0)
                {
                    DeRef(_25946);
                    _25946 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25946);
                    _25946 = NOVALUE;
                }
L15: 

                /** cominit.e:508								OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (object)SEQ_PTR(_36warning_flags_21805);
                _25947 = (object)*(((s1_ptr)_2)->base + _n_50539);
                _25948 = not_bits(_25947);
                _25947 = NOVALUE;
                if (IS_ATOM_INT(_25948)) {
                    {uintptr_t tu;
                         tu = (uintptr_t)_36OpWarning_21830 & (uintptr_t)_25948;
                         _36OpWarning_21830 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (eudouble)_36OpWarning_21830;
                    _36OpWarning_21830 = Dand_bits(&temp_d, DBL_PTR(_25948));
                }
                DeRef(_25948);
                _25948 = NOVALUE;
                if (!IS_ATOM_INT(_36OpWarning_21830)) {
                    _1 = (object)(DBL_PTR(_36OpWarning_21830)->dbl);
                    DeRefDS(_36OpWarning_21830);
                    _36OpWarning_21830 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** cominit.e:510								option_w = -1*/
                _option_w_50448 = -1LL;

                /** cominit.e:511								OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (object)SEQ_PTR(_36warning_flags_21805);
                _25950 = (object)*(((s1_ptr)_2)->base + _n_50539);
                _36OpWarning_21830 = 32767LL - _25950;
                _25950 = NOVALUE;
L17: 

                /** cominit.e:514							prev_OpWarning = OpWarning*/
                _36prev_OpWarning_21831 = _36OpWarning_21830;
L14: 
                DeRef(_this_warn_50531);
                _this_warn_50531 = NOVALUE;

                /** cominit.e:516					end for*/
                _i_50529 = _i_50529 + 1LL;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 786

            /** cominit.e:518				case "wf" then*/
            case 12:

            /** cominit.e:519					TempWarningName = val*/
            Ref(_val_50454);
            DeRef(_36TempWarningName_21773);
            _36TempWarningName_21773 = _val_50454;

            /** cominit.e:520				  	error:warning_file(TempWarningName)*/
            Ref(_36TempWarningName_21773);
            _7warning_file(_36TempWarningName_21773);
            goto L5; // [560] 786

            /** cominit.e:522				case "v", "version" then*/
            case 13:
            case 14:

            /** cominit.e:523					show_banner()*/
            _49show_banner();

            /** cominit.e:524					if not batch_job and not test_only then*/
            _25952 = (_36batch_job_21772 == 0);
            if (_25952 == 0) {
                goto L18; // [579] 634
            }
            _25954 = (_36test_only_21771 == 0);
            if (_25954 == 0)
            {
                DeRef(_25954);
                _25954 = NOVALUE;
                goto L18; // [589] 634
            }
            else{
                DeRef(_25954);
                _25954 = NOVALUE;
            }

            /** cominit.e:525						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22186);
            _25955 = _39GetMsgText(278LL, 0LL, _22186);
            DeRef(_prompt_inlined_maybe_any_key_at_617_50575);
            _prompt_inlined_maybe_any_key_at_617_50575 = _25955;
            _25955 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576 != 0){
                    goto L19; // [616] 631
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576)->dbl != 0.0){
                    goto L19; // [616] 631
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_617_50575);
            _5any_key(_prompt_inlined_maybe_any_key_at_617_50575, 2LL);

            /** console.e:926	end procedure*/
            goto L19; // [628] 631
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_617_50575);
            _prompt_inlined_maybe_any_key_at_617_50575 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_620_50576 = NOVALUE;
L18: 

            /** cominit.e:528					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [638] 786

            /** cominit.e:530				case "copyright" then*/
            case 15:

            /** cominit.e:531					show_copyrights()*/
            _49show_copyrights();

            /** cominit.e:532					if not batch_job and not test_only then*/
            _25956 = (_36batch_job_21772 == 0);
            if (_25956 == 0) {
                goto L1A; // [655] 710
            }
            _25958 = (_36test_only_21771 == 0);
            if (_25958 == 0)
            {
                DeRef(_25958);
                _25958 = NOVALUE;
                goto L1A; // [665] 710
            }
            else{
                DeRef(_25958);
                _25958 = NOVALUE;
            }

            /** cominit.e:533						console:maybe_any_key(GetMsgText(MSG_PRESS_ANY_KEY_AND_WINDOW_WILL_CLOSE,0), 2)*/
            RefDS(_22186);
            _25959 = _39GetMsgText(278LL, 0LL, _22186);
            DeRef(_prompt_inlined_maybe_any_key_at_693_50588);
            _prompt_inlined_maybe_any_key_at_693_50588 = _25959;
            _25959 = NOVALUE;

            /** console.e:923		if not has_console() then*/

            /** console.e:59		return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589 = machine(99LL, 0LL);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589 != 0){
                    goto L1B; // [692] 707
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589)->dbl != 0.0){
                    goto L1B; // [692] 707
                }
            }

            /** console.e:924			any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_693_50588);
            _5any_key(_prompt_inlined_maybe_any_key_at_693_50588, 2LL);

            /** console.e:926	end procedure*/
            goto L1B; // [704] 707
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_693_50588);
            _prompt_inlined_maybe_any_key_at_693_50588 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_696_50589 = NOVALUE;
L1A: 

            /** cominit.e:535					abort(0)*/
            UserCleanup(0LL);
            goto L5; // [714] 786

            /** cominit.e:537				case "eudir" then*/
            case 16:

            /** cominit.e:538					set_eudir( val )*/
            Ref(_val_50454);
            _37set_eudir(_val_50454);
            goto L5; // [725] 786

            /** cominit.e:540				case "trace-lines" then*/
            case 17:

            /** cominit.e:541					val = value( val )*/
            Ref(_val_50454);
            _0 = _val_50454;
            _val_50454 = _6value(_val_50454, 1LL, _6GET_SHORT_ANSWER_11277);
            DeRef(_0);

            /** cominit.e:542					if val[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_val_50454);
            _25961 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _25961, 0LL)){
                _25961 = NOVALUE;
                goto L1C; // [749] 767
            }
            _25961 = NOVALUE;

            /** cominit.e:543						trace_lines = floor( val[2] )*/
            _2 = (object)SEQ_PTR(_val_50454);
            _25963 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (IS_ATOM_INT(_25963))
            _36trace_lines_64935 = e_floor(_25963);
            else
            _36trace_lines_64935 = unary_op(FLOOR, _25963);
            _25963 = NOVALUE;
            if (!IS_ATOM_INT(_36trace_lines_64935)) {
                _1 = (object)(DBL_PTR(_36trace_lines_64935)->dbl);
                DeRefDS(_36trace_lines_64935);
                _36trace_lines_64935 = _1;
            }
            goto L1D; // [764] 785
L1C: 

            /** cominit.e:545						puts(2, GetMsgText( BAD_TRACE_LINES ) )*/
            RefDS(_22186);
            _25965 = _39GetMsgText(604LL, 1LL, _22186);
            EPuts(2LL, _25965); // DJP 
            DeRef(_25965);
            _25965 = NOVALUE;

            /** cominit.e:546						abort( 1 )*/
            UserCleanup(1LL);
L1D: 
        ;}L5: 
        DeRef(_key_50452);
        _key_50452 = NOVALUE;
        DeRef(_val_50454);
        _val_50454 = NOVALUE;

        /** cominit.e:549		end for*/
        _idx_50450 = _idx_50450 + 1LL;
        goto L1; // [790] 27
L2: 
        ;
    }

    /** cominit.e:551		if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_37LocalizeQual_15656)){
            _25966 = SEQ_PTR(_37LocalizeQual_15656)->length;
    }
    else {
        _25966 = 1;
    }
    if (_25966 != 0LL)
    goto L1E; // [802] 815

    /** cominit.e:552			LocalizeQual = {"en"}*/
    _0 = _37LocalizeQual_15656;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_25968);
    ((intptr_t*)_2)[1] = _25968;
    _37LocalizeQual_15656 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1E: 

    /** cominit.e:554	end procedure*/
    DeRef(_opts_50445);
    DeRef(_opt_keys_50446);
    DeRef(_25952);
    _25952 = NOVALUE;
    DeRef(_25956);
    _25956 = NOVALUE;
    return;
    ;
}


void _49finalize_command_line(object _opts_50615)
{
    object _extras_50622 = NOVALUE;
    object _pairs_50627 = NOVALUE;
    object _pair_50632 = NOVALUE;
    object _25998 = NOVALUE;
    object _25996 = NOVALUE;
    object _25993 = NOVALUE;
    object _25992 = NOVALUE;
    object _25991 = NOVALUE;
    object _25990 = NOVALUE;
    object _25989 = NOVALUE;
    object _25988 = NOVALUE;
    object _25987 = NOVALUE;
    object _25986 = NOVALUE;
    object _25985 = NOVALUE;
    object _25984 = NOVALUE;
    object _25983 = NOVALUE;
    object _25982 = NOVALUE;
    object _25981 = NOVALUE;
    object _25980 = NOVALUE;
    object _25979 = NOVALUE;
    object _25978 = NOVALUE;
    object _25977 = NOVALUE;
    object _25976 = NOVALUE;
    object _25974 = NOVALUE;
    object _25971 = NOVALUE;
    object _0, _1, _2;
    

    /** cominit.e:562		if Strict_is_on then -- overrides any -W/-X switches*/
    if (_36Strict_is_on_21828 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** cominit.e:563			OpWarning = all_warning_flag*/
    _36OpWarning_21830 = 32767LL;

    /** cominit.e:564			prev_OpWarning = OpWarning*/
    _36prev_OpWarning_21831 = 32767LL;
L1: 

    /** cominit.e:569		sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_50615);
    RefDS(_4EXTRAS_14407);
    _0 = _extras_50622;
    _extras_50622 = _29get(_opts_50615, _4EXTRAS_14407, 0LL);
    DeRef(_0);

    /** cominit.e:570		if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_50622)){
            _25971 = SEQ_PTR(_extras_50622)->length;
    }
    else {
        _25971 = 1;
    }
    if (_25971 <= 0LL)
    goto L2; // [44] 270

    /** cominit.e:571			sequence pairs = m:pairs( opts )*/
    Ref(_opts_50615);
    _0 = _pairs_50627;
    _pairs_50627 = _29pairs(_opts_50615, 0LL);
    DeRef(_0);

    /** cominit.e:573			for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_50627)){
            _25974 = SEQ_PTR(_pairs_50627)->length;
    }
    else {
        _25974 = 1;
    }
    {
        object _i_50630;
        _i_50630 = 1LL;
L3: 
        if (_i_50630 > _25974){
            goto L4; // [62] 237
        }

        /** cominit.e:574				sequence pair = pairs[i]*/
        DeRef(_pair_50632);
        _2 = (object)SEQ_PTR(_pairs_50627);
        _pair_50632 = (object)*(((s1_ptr)_2)->base + _i_50630);
        Ref(_pair_50632);

        /** cominit.e:575				if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (object)SEQ_PTR(_pair_50632);
        _25976 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (_25976 == _4EXTRAS_14407)
        _25977 = 1;
        else if (IS_ATOM_INT(_25976) && IS_ATOM_INT(_4EXTRAS_14407))
        _25977 = 0;
        else
        _25977 = (compare(_25976, _4EXTRAS_14407) == 0);
        _25976 = NOVALUE;
        if (_25977 == 0)
        {
            _25977 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25977 = NOVALUE;
        }

        /** cominit.e:576					continue*/
        DeRefDS(_pair_50632);
        _pair_50632 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** cominit.e:578				pair[1] = prepend( pair[1], '-' )*/
        _2 = (object)SEQ_PTR(_pair_50632);
        _25978 = (object)*(((s1_ptr)_2)->base + 1LL);
        Prepend(&_25979, _25978, 45LL);
        _25978 = NOVALUE;
        _2 = (object)SEQ_PTR(_pair_50632);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pair_50632 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _25979;
        if( _1 != _25979 ){
            DeRef(_1);
        }
        _25979 = NOVALUE;

        /** cominit.e:579				if sequence( pair[2] ) then*/
        _2 = (object)SEQ_PTR(_pair_50632);
        _25980 = (object)*(((s1_ptr)_2)->base + 2LL);
        _25981 = IS_SEQUENCE(_25980);
        _25980 = NOVALUE;
        if (_25981 == 0)
        {
            _25981 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25981 = NOVALUE;
        }

        /** cominit.e:580					if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (object)SEQ_PTR(_pair_50632);
        _25982 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_25982)){
                _25983 = SEQ_PTR(_25982)->length;
        }
        else {
            _25983 = 1;
        }
        _25982 = NOVALUE;
        if (_25983 == 0) {
            goto L8; // [134] 203
        }
        _2 = (object)SEQ_PTR(_pair_50632);
        _25985 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_25985);
        _25986 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25985 = NOVALUE;
        _25987 = IS_SEQUENCE(_25986);
        _25986 = NOVALUE;
        if (_25987 == 0)
        {
            _25987 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25987 = NOVALUE;
        }

        /** cominit.e:581						for j = 1 to length( pair[2] ) do*/
        _2 = (object)SEQ_PTR(_pair_50632);
        _25988 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (IS_SEQUENCE(_25988)){
                _25989 = SEQ_PTR(_25988)->length;
        }
        else {
            _25989 = 1;
        }
        _25988 = NOVALUE;
        {
            object _j_50650;
            _j_50650 = 1LL;
L9: 
            if (_j_50650 > _25989){
                goto LA; // [162] 200
            }

            /** cominit.e:582							switches &= { pair[1], pair[2][j] }*/
            _2 = (object)SEQ_PTR(_pair_50632);
            _25990 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_pair_50632);
            _25991 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_25991);
            _25992 = (object)*(((s1_ptr)_2)->base + _j_50650);
            _25991 = NOVALUE;
            Ref(_25992);
            Ref(_25990);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _25990;
            ((intptr_t *)_2)[2] = _25992;
            _25993 = MAKE_SEQ(_1);
            _25992 = NOVALUE;
            _25990 = NOVALUE;
            Concat((object_ptr)&_49switches_49948, _49switches_49948, _25993);
            DeRefDS(_25993);
            _25993 = NOVALUE;

            /** cominit.e:583						end for*/
            _j_50650 = _j_50650 + 1LL;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** cominit.e:585						switches &= pair*/
        Concat((object_ptr)&_49switches_49948, _49switches_49948, _pair_50632);
        goto LB; // [212] 228
L7: 

        /** cominit.e:588					switches = append( switches, pair[1] )*/
        _2 = (object)SEQ_PTR(_pair_50632);
        _25996 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_25996);
        Append(&_49switches_49948, _49switches_49948, _25996);
        _25996 = NOVALUE;
LB: 
        DeRef(_pair_50632);
        _pair_50632 = NOVALUE;

        /** cominit.e:590			end for*/
L6: 
        _i_50630 = _i_50630 + 1LL;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** cominit.e:592			Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25998;
    RHS_Slice(_36Argv_21770, 2LL, 3LL);
    Concat((object_ptr)&_36Argv_21770, _25998, _extras_50622);
    DeRefDS(_25998);
    _25998 = NOVALUE;
    DeRef(_25998);
    _25998 = NOVALUE;

    /** cominit.e:593			Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21770)){
            _36Argc_21769 = SEQ_PTR(_36Argv_21770)->length;
    }
    else {
        _36Argc_21769 = 1;
    }

    /** cominit.e:595			src_name = extras[1]*/
    DeRef(_49src_name_49947);
    _2 = (object)SEQ_PTR(_extras_50622);
    _49src_name_49947 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_49src_name_49947);
L2: 
    DeRef(_pairs_50627);
    _pairs_50627 = NOVALUE;

    /** cominit.e:597	end procedure*/
    DeRef(_opts_50615);
    DeRef(_extras_50622);
    _25988 = NOVALUE;
    _25982 = NOVALUE;
    return;
    ;
}



// 0x39E8897A
