// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _56find_file(object _fname_45627)
{
    object _23766 = NOVALUE;
    object _23765 = NOVALUE;
    object _23764 = NOVALUE;
    object _23763 = NOVALUE;
    object _23761 = NOVALUE;
    object _23760 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:30		for i = 1 to length(inc_dirs) do*/
    _23760 = 3;
    {
        object _i_45629;
        _i_45629 = 1LL;
L1: 
        if (_i_45629 > 3LL){
            goto L2; // [10] 64
        }

        /** buildsys.e:31			if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45619);
        _23761 = (object)*(((s1_ptr)_2)->base + _i_45629);
        {
            object concat_list[3];

            concat_list[0] = _fname_45627;
            concat_list[1] = _23762;
            concat_list[2] = _23761;
            Concat_N((object_ptr)&_23763, concat_list, 3);
        }
        _23761 = NOVALUE;
        _23764 = _17file_exists(_23763);
        _23763 = NOVALUE;
        if (_23764 == 0) {
            DeRef(_23764);
            _23764 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23764) && DBL_PTR(_23764)->dbl == 0.0){
                DeRef(_23764);
                _23764 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23764);
            _23764 = NOVALUE;
        }
        DeRef(_23764);
        _23764 = NOVALUE;

        /** buildsys.e:32				return inc_dirs[i] & "/" & fname*/
        _2 = (object)SEQ_PTR(_56inc_dirs_45619);
        _23765 = (object)*(((s1_ptr)_2)->base + _i_45629);
        {
            object concat_list[3];

            concat_list[0] = _fname_45627;
            concat_list[1] = _23762;
            concat_list[2] = _23765;
            Concat_N((object_ptr)&_23766, concat_list, 3);
        }
        _23765 = NOVALUE;
        DeRefDS(_fname_45627);
        return _23766;
L3: 

        /** buildsys.e:34		end for*/
        _i_45629 = _i_45629 + 1LL;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** buildsys.e:36		return 0*/
    DeRefDS(_fname_45627);
    DeRef(_23766);
    _23766 = NOVALUE;
    return 0LL;
    ;
}


object _56find_all_includes(object _fname_45641, object _includes_45642)
{
    object _lines_45643 = NOVALUE;
    object _m_45649 = NOVALUE;
    object _full_fname_45654 = NOVALUE;
    object _23779 = NOVALUE;
    object _23777 = NOVALUE;
    object _23775 = NOVALUE;
    object _23774 = NOVALUE;
    object _23772 = NOVALUE;
    object _23771 = NOVALUE;
    object _23769 = NOVALUE;
    object _23768 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:40		sequence lines = read_lines(fname)*/
    RefDS(_fname_45641);
    _0 = _lines_45643;
    _lines_45643 = _8read_lines(_fname_45641);
    DeRef(_0);

    /** buildsys.e:42		for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_45643)){
            _23768 = SEQ_PTR(_lines_45643)->length;
    }
    else {
        _23768 = 1;
    }
    {
        object _i_45647;
        _i_45647 = 1LL;
L1: 
        if (_i_45647 > _23768){
            goto L2; // [18] 113
        }

        /** buildsys.e:43			object m = regex:matches(re_include, lines[i])*/
        _2 = (object)SEQ_PTR(_lines_45643);
        _23769 = (object)*(((s1_ptr)_2)->base + _i_45647);
        Ref(_56re_include_45616);
        Ref(_23769);
        _0 = _m_45649;
        _m_45649 = _52matches(_56re_include_45616, _23769, 1LL, 0LL);
        DeRef(_0);
        _23769 = NOVALUE;

        /** buildsys.e:44			if sequence(m) then*/
        _23771 = IS_SEQUENCE(_m_45649);
        if (_23771 == 0)
        {
            _23771 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23771 = NOVALUE;
        }

        /** buildsys.e:45				object full_fname = find_file(m[3])*/
        _2 = (object)SEQ_PTR(_m_45649);
        _23772 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_23772);
        _0 = _full_fname_45654;
        _full_fname_45654 = _56find_file(_23772);
        DeRef(_0);
        _23772 = NOVALUE;

        /** buildsys.e:46				if sequence(full_fname) then*/
        _23774 = IS_SEQUENCE(_full_fname_45654);
        if (_23774 == 0)
        {
            _23774 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23774 = NOVALUE;
        }

        /** buildsys.e:47					if eu:find(full_fname, includes) = 0 then*/
        _23775 = find_from(_full_fname_45654, _includes_45642, 1LL);
        if (_23775 != 0LL)
        goto L5; // [73] 100

        /** buildsys.e:48						includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_full_fname_45654);
        ((intptr_t*)_2)[1] = _full_fname_45654;
        _23777 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_45642, _includes_45642, _23777);
        DeRefDS(_23777);
        _23777 = NOVALUE;

        /** buildsys.e:49						includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_45642);
        DeRef(_23779);
        _23779 = _includes_45642;
        Ref(_full_fname_45654);
        _0 = _includes_45642;
        _includes_45642 = _56find_all_includes(_full_fname_45654, _23779);
        DeRefDS(_0);
        _23779 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_45654);
        _full_fname_45654 = NOVALUE;
        DeRef(_m_45649);
        _m_45649 = NOVALUE;

        /** buildsys.e:53		end for*/
        _i_45647 = _i_45647 + 1LL;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** buildsys.e:55		return includes*/
    DeRefDS(_fname_45641);
    DeRef(_lines_45643);
    return _includes_45642;
    ;
}


object _56quick_has_changed(object _fname_45668)
{
    object _d1_45669 = NOVALUE;
    object _all_files_45679 = NOVALUE;
    object _d2_45685 = NOVALUE;
    object _diff_2__tmp_at88_45695 = NOVALUE;
    object _diff_1__tmp_at88_45694 = NOVALUE;
    object _diff_inlined_diff_at_88_45693 = NOVALUE;
    object _23791 = NOVALUE;
    object _23789 = NOVALUE;
    object _23788 = NOVALUE;
    object _23786 = NOVALUE;
    object _23785 = NOVALUE;
    object _23783 = NOVALUE;
    object _23781 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:59		object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_45668);
    _23781 = _17filebase(_fname_45668);
    {
        object concat_list[3];

        concat_list[0] = _23782;
        concat_list[1] = _23781;
        concat_list[2] = _58output_dir_42903;
        Concat_N((object_ptr)&_23783, concat_list, 3);
    }
    DeRef(_23781);
    _23781 = NOVALUE;
    _0 = _d1_45669;
    _d1_45669 = _17file_timestamp(_23783);
    DeRef(_0);
    _23783 = NOVALUE;

    /** buildsys.e:61		if atom(d1) then*/
    _23785 = IS_ATOM(_d1_45669);
    if (_23785 == 0)
    {
        _23785 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23785 = NOVALUE;
    }

    /** buildsys.e:62			return 1*/
    DeRefDS(_fname_45668);
    DeRef(_d1_45669);
    DeRef(_all_files_45679);
    return 1LL;
L1: 

    /** buildsys.e:65		sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_45668);
    RefDS(_22186);
    _23786 = _56find_all_includes(_fname_45668, _22186);
    RefDS(_fname_45668);
    Append(&_all_files_45679, _23786, _fname_45668);
    DeRef(_23786);
    _23786 = NOVALUE;

    /** buildsys.e:66		for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_45679)){
            _23788 = SEQ_PTR(_all_files_45679)->length;
    }
    else {
        _23788 = 1;
    }
    {
        object _i_45683;
        _i_45683 = 1LL;
L2: 
        if (_i_45683 > _23788){
            goto L3; // [52] 123
        }

        /** buildsys.e:67			object d2 = file_timestamp(all_files[i])*/
        _2 = (object)SEQ_PTR(_all_files_45679);
        _23789 = (object)*(((s1_ptr)_2)->base + _i_45683);
        Ref(_23789);
        _0 = _d2_45685;
        _d2_45685 = _17file_timestamp(_23789);
        DeRef(_0);
        _23789 = NOVALUE;

        /** buildsys.e:68			if atom(d2) then*/
        _23791 = IS_ATOM(_d2_45685);
        if (_23791 == 0)
        {
            _23791 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23791 = NOVALUE;
        }

        /** buildsys.e:69				return 1*/
        DeRef(_d2_45685);
        DeRefDS(_fname_45668);
        DeRef(_d1_45669);
        DeRefDS(_all_files_45679);
        return 1LL;
L4: 

        /** buildsys.e:71			if datetime:diff(d1, d2) > 0 then*/

        /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_45685);
        _0 = _diff_1__tmp_at88_45694;
        _diff_1__tmp_at88_45694 = _18datetimeToSeconds(_d2_45685);
        DeRef(_0);
        Ref(_d1_45669);
        _0 = _diff_2__tmp_at88_45695;
        _diff_2__tmp_at88_45695 = _18datetimeToSeconds(_d1_45669);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_45693);
        if (IS_ATOM_INT(_diff_1__tmp_at88_45694) && IS_ATOM_INT(_diff_2__tmp_at88_45695)) {
            _diff_inlined_diff_at_88_45693 = _diff_1__tmp_at88_45694 - _diff_2__tmp_at88_45695;
            if ((object)((uintptr_t)_diff_inlined_diff_at_88_45693 +(uintptr_t) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_45693 = NewDouble((eudouble)_diff_inlined_diff_at_88_45693);
            }
        }
        else {
            _diff_inlined_diff_at_88_45693 = binary_op(MINUS, _diff_1__tmp_at88_45694, _diff_2__tmp_at88_45695);
        }
        DeRef(_diff_1__tmp_at88_45694);
        _diff_1__tmp_at88_45694 = NOVALUE;
        DeRef(_diff_2__tmp_at88_45695);
        _diff_2__tmp_at88_45695 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_45693, 0LL)){
            goto L5; // [103] 114
        }

        /** buildsys.e:72				return 1*/
        DeRef(_d2_45685);
        DeRefDS(_fname_45668);
        DeRef(_d1_45669);
        DeRef(_all_files_45679);
        return 1LL;
L5: 
        DeRef(_d2_45685);
        _d2_45685 = NOVALUE;

        /** buildsys.e:74		end for*/
        _i_45683 = _i_45683 + 1LL;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** buildsys.e:76		return 0*/
    DeRefDS(_fname_45668);
    DeRef(_d1_45669);
    DeRef(_all_files_45679);
    return 0LL;
    ;
}


void _56update_checksum(object _raw_data_45741)
{
    object _23799 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:213		cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23799 = calc_hash(_raw_data_45741, -5LL);
    _0 = _56cfile_check_45722;
    if (IS_ATOM_INT(_56cfile_check_45722) && IS_ATOM_INT(_23799)) {
        {uintptr_t tu;
             tu = (uintptr_t)_56cfile_check_45722 ^ (uintptr_t)_23799;
             _56cfile_check_45722 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_56cfile_check_45722)) {
            temp_d.dbl = (eudouble)_56cfile_check_45722;
            _56cfile_check_45722 = Dxor_bits(&temp_d, DBL_PTR(_23799));
        }
        else {
            if (IS_ATOM_INT(_23799)) {
                temp_d.dbl = (eudouble)_23799;
                _56cfile_check_45722 = Dxor_bits(DBL_PTR(_56cfile_check_45722), &temp_d);
            }
            else
            _56cfile_check_45722 = Dxor_bits(DBL_PTR(_56cfile_check_45722), DBL_PTR(_23799));
        }
    }
    DeRef(_0);
    DeRef(_23799);
    _23799 = NOVALUE;

    /** buildsys.e:214	end procedure*/
    DeRef(_raw_data_45741);
    return;
    ;
}


void _56write_checksum(object _file_45746)
{
    object _0, _1, _2;
    

    /** buildsys.e:219		printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_45746, _23801, _56cfile_check_45722);

    /** buildsys.e:220		cfile_check = 0*/
    DeRef(_56cfile_check_45722);
    _56cfile_check_45722 = 0LL;

    /** buildsys.e:221	end procedure*/
    return;
    ;
}


object _56find_file_element(object _needle_45750, object _files_45751)
{
    object _23817 = NOVALUE;
    object _23816 = NOVALUE;
    object _23815 = NOVALUE;
    object _23814 = NOVALUE;
    object _23813 = NOVALUE;
    object _23812 = NOVALUE;
    object _23811 = NOVALUE;
    object _23810 = NOVALUE;
    object _23809 = NOVALUE;
    object _23808 = NOVALUE;
    object _23807 = NOVALUE;
    object _23806 = NOVALUE;
    object _23805 = NOVALUE;
    object _23804 = NOVALUE;
    object _23803 = NOVALUE;
    object _23802 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:228		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45751)){
            _23802 = SEQ_PTR(_files_45751)->length;
    }
    else {
        _23802 = 1;
    }
    {
        object _j_45753;
        _j_45753 = 1LL;
L1: 
        if (_j_45753 > _23802){
            goto L2; // [10] 50
        }

        /** buildsys.e:229			if equal(files[j][D_NAME],needle) then*/
        _2 = (object)SEQ_PTR(_files_45751);
        _23803 = (object)*(((s1_ptr)_2)->base + _j_45753);
        _2 = (object)SEQ_PTR(_23803);
        _23804 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23803 = NOVALUE;
        if (_23804 == _needle_45750)
        _23805 = 1;
        else if (IS_ATOM_INT(_23804) && IS_ATOM_INT(_needle_45750))
        _23805 = 0;
        else
        _23805 = (compare(_23804, _needle_45750) == 0);
        _23804 = NOVALUE;
        if (_23805 == 0)
        {
            _23805 = NOVALUE;
            goto L3; // [33] 43
        }
        else{
            _23805 = NOVALUE;
        }

        /** buildsys.e:230				return j*/
        DeRefDS(_needle_45750);
        DeRefDS(_files_45751);
        return _j_45753;
L3: 

        /** buildsys.e:232		end for*/
        _j_45753 = _j_45753 + 1LL;
        goto L1; // [45] 17
L2: 
        ;
    }

    /** buildsys.e:233		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45751)){
            _23806 = SEQ_PTR(_files_45751)->length;
    }
    else {
        _23806 = 1;
    }
    {
        object _j_45761;
        _j_45761 = 1LL;
L4: 
        if (_j_45761 > _23806){
            goto L5; // [55] 103
        }

        /** buildsys.e:234			if equal(lower(files[j][D_NAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45751);
        _23807 = (object)*(((s1_ptr)_2)->base + _j_45761);
        _2 = (object)SEQ_PTR(_23807);
        _23808 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23807 = NOVALUE;
        Ref(_23808);
        _23809 = _14lower(_23808);
        _23808 = NOVALUE;
        RefDS(_needle_45750);
        _23810 = _14lower(_needle_45750);
        if (_23809 == _23810)
        _23811 = 1;
        else if (IS_ATOM_INT(_23809) && IS_ATOM_INT(_23810))
        _23811 = 0;
        else
        _23811 = (compare(_23809, _23810) == 0);
        DeRef(_23809);
        _23809 = NOVALUE;
        DeRef(_23810);
        _23810 = NOVALUE;
        if (_23811 == 0)
        {
            _23811 = NOVALUE;
            goto L6; // [86] 96
        }
        else{
            _23811 = NOVALUE;
        }

        /** buildsys.e:235				return j*/
        DeRefDS(_needle_45750);
        DeRefDS(_files_45751);
        return _j_45761;
L6: 

        /** buildsys.e:237		end for*/
        _j_45761 = _j_45761 + 1LL;
        goto L4; // [98] 62
L5: 
        ;
    }

    /** buildsys.e:239		for j = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_45751)){
            _23812 = SEQ_PTR(_files_45751)->length;
    }
    else {
        _23812 = 1;
    }
    {
        object _j_45773;
        _j_45773 = 1LL;
L7: 
        if (_j_45773 > _23812){
            goto L8; // [108] 156
        }

        /** buildsys.e:240			if equal(lower(files[j][D_ALTNAME]),lower(needle)) then*/
        _2 = (object)SEQ_PTR(_files_45751);
        _23813 = (object)*(((s1_ptr)_2)->base + _j_45773);
        _2 = (object)SEQ_PTR(_23813);
        _23814 = (object)*(((s1_ptr)_2)->base + 11LL);
        _23813 = NOVALUE;
        Ref(_23814);
        _23815 = _14lower(_23814);
        _23814 = NOVALUE;
        RefDS(_needle_45750);
        _23816 = _14lower(_needle_45750);
        if (_23815 == _23816)
        _23817 = 1;
        else if (IS_ATOM_INT(_23815) && IS_ATOM_INT(_23816))
        _23817 = 0;
        else
        _23817 = (compare(_23815, _23816) == 0);
        DeRef(_23815);
        _23815 = NOVALUE;
        DeRef(_23816);
        _23816 = NOVALUE;
        if (_23817 == 0)
        {
            _23817 = NOVALUE;
            goto L9; // [139] 149
        }
        else{
            _23817 = NOVALUE;
        }

        /** buildsys.e:241				return j*/
        DeRefDS(_needle_45750);
        DeRefDS(_files_45751);
        return _j_45773;
L9: 

        /** buildsys.e:243		end for*/
        _j_45773 = _j_45773 + 1LL;
        goto L7; // [151] 115
L8: 
        ;
    }

    /** buildsys.e:244		return 0*/
    DeRefDS(_needle_45750);
    DeRefDS(_files_45751);
    return 0LL;
    ;
}


object _56adjust_for_command_line_passing(object _long_path_45794)
{
    object _slash_45795 = NOVALUE;
    object _longs_45803 = NOVALUE;
    object _short_path_45809 = NOVALUE;
    object _files_45815 = NOVALUE;
    object _file_location_45818 = NOVALUE;
    object _23856 = NOVALUE;
    object _23855 = NOVALUE;
    object _23853 = NOVALUE;
    object _23852 = NOVALUE;
    object _23850 = NOVALUE;
    object _23849 = NOVALUE;
    object _23847 = NOVALUE;
    object _23846 = NOVALUE;
    object _23843 = NOVALUE;
    object _23842 = NOVALUE;
    object _23840 = NOVALUE;
    object _23839 = NOVALUE;
    object _23838 = NOVALUE;
    object _23837 = NOVALUE;
    object _23836 = NOVALUE;
    object _23834 = NOVALUE;
    object _23833 = NOVALUE;
    object _23831 = NOVALUE;
    object _23829 = NOVALUE;
    object _23827 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:310		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45705 != 1LL)
    goto L1; // [7] 19

    /** buildsys.e:311			slash = '/'*/
    _slash_45795 = 47LL;
    goto L2; // [16] 45
L1: 

    /** buildsys.e:312		elsif compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45705 != 2LL)
    goto L3; // [23] 35

    /** buildsys.e:313			slash = '\\'*/
    _slash_45795 = 92LL;
    goto L2; // [32] 45
L3: 

    /** buildsys.e:315			slash = SLASH*/
    _slash_45795 = 92LL;
L2: 

    /** buildsys.e:317		ifdef UNIX then*/

    /** buildsys.e:320			long_path = regex:find_replace(quote_pattern, long_path, "")*/
    Ref(_56quote_pattern_45787);
    RefDS(_long_path_45794);
    RefDS(_22186);
    _0 = _long_path_45794;
    _long_path_45794 = _52find_replace(_56quote_pattern_45787, _long_path_45794, _22186, 1LL, 0LL);
    DeRefDS(_0);

    /** buildsys.e:321			sequence longs = split( slash_pattern, long_path )*/
    Ref(_56slash_pattern_45784);
    RefDS(_long_path_45794);
    _0 = _longs_45803;
    _longs_45803 = _52split(_56slash_pattern_45784, _long_path_45794, 1LL, 0LL);
    DeRef(_0);

    /** buildsys.e:322			if length(longs)=0 then*/
    if (IS_SEQUENCE(_longs_45803)){
            _23827 = SEQ_PTR(_longs_45803)->length;
    }
    else {
        _23827 = 1;
    }
    if (_23827 != 0LL)
    goto L4; // [79] 90

    /** buildsys.e:323				return long_path*/
    DeRefDS(_longs_45803);
    DeRef(_short_path_45809);
    return _long_path_45794;
L4: 

    /** buildsys.e:325			sequence short_path = longs[1] & slash*/
    _2 = (object)SEQ_PTR(_longs_45803);
    _23829 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_23829) && IS_ATOM(_slash_45795)) {
        Append(&_short_path_45809, _23829, _slash_45795);
    }
    else if (IS_ATOM(_23829) && IS_SEQUENCE(_slash_45795)) {
    }
    else {
        Concat((object_ptr)&_short_path_45809, _23829, _slash_45795);
        _23829 = NOVALUE;
    }
    _23829 = NOVALUE;

    /** buildsys.e:326			for i = 2 to length(longs) do*/
    if (IS_SEQUENCE(_longs_45803)){
            _23831 = SEQ_PTR(_longs_45803)->length;
    }
    else {
        _23831 = 1;
    }
    {
        object _i_45813;
        _i_45813 = 2LL;
L5: 
        if (_i_45813 > _23831){
            goto L6; // [107] 266
        }

        /** buildsys.e:327				object files = dir(short_path)*/
        RefDS(_short_path_45809);
        _0 = _files_45815;
        _files_45815 = _17dir(_short_path_45809);
        DeRef(_0);

        /** buildsys.e:328				integer file_location = 0*/
        _file_location_45818 = 0LL;

        /** buildsys.e:329				if sequence(files) then*/
        _23833 = IS_SEQUENCE(_files_45815);
        if (_23833 == 0)
        {
            _23833 = NOVALUE;
            goto L7; // [130] 147
        }
        else{
            _23833 = NOVALUE;
        }

        /** buildsys.e:330					file_location = find_file_element(longs[i], files)*/
        _2 = (object)SEQ_PTR(_longs_45803);
        _23834 = (object)*(((s1_ptr)_2)->base + _i_45813);
        Ref(_23834);
        Ref(_files_45815);
        _file_location_45818 = _56find_file_element(_23834, _files_45815);
        _23834 = NOVALUE;
        if (!IS_ATOM_INT(_file_location_45818)) {
            _1 = (object)(DBL_PTR(_file_location_45818)->dbl);
            DeRefDS(_file_location_45818);
            _file_location_45818 = _1;
        }
L7: 

        /** buildsys.e:332				if file_location then*/
        if (_file_location_45818 == 0)
        {
            goto L8; // [149] 215
        }
        else{
        }

        /** buildsys.e:333					if sequence(files[file_location][D_ALTNAME]) then*/
        _2 = (object)SEQ_PTR(_files_45815);
        _23836 = (object)*(((s1_ptr)_2)->base + _file_location_45818);
        _2 = (object)SEQ_PTR(_23836);
        _23837 = (object)*(((s1_ptr)_2)->base + 11LL);
        _23836 = NOVALUE;
        _23838 = IS_SEQUENCE(_23837);
        _23837 = NOVALUE;
        if (_23838 == 0)
        {
            _23838 = NOVALUE;
            goto L9; // [167] 189
        }
        else{
            _23838 = NOVALUE;
        }

        /** buildsys.e:334						short_path &= files[file_location][D_ALTNAME]*/
        _2 = (object)SEQ_PTR(_files_45815);
        _23839 = (object)*(((s1_ptr)_2)->base + _file_location_45818);
        _2 = (object)SEQ_PTR(_23839);
        _23840 = (object)*(((s1_ptr)_2)->base + 11LL);
        _23839 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45809) && IS_ATOM(_23840)) {
            Ref(_23840);
            Append(&_short_path_45809, _short_path_45809, _23840);
        }
        else if (IS_ATOM(_short_path_45809) && IS_SEQUENCE(_23840)) {
        }
        else {
            Concat((object_ptr)&_short_path_45809, _short_path_45809, _23840);
        }
        _23840 = NOVALUE;
        goto LA; // [186] 206
L9: 

        /** buildsys.e:336						short_path &= files[file_location][D_NAME]*/
        _2 = (object)SEQ_PTR(_files_45815);
        _23842 = (object)*(((s1_ptr)_2)->base + _file_location_45818);
        _2 = (object)SEQ_PTR(_23842);
        _23843 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23842 = NOVALUE;
        if (IS_SEQUENCE(_short_path_45809) && IS_ATOM(_23843)) {
            Ref(_23843);
            Append(&_short_path_45809, _short_path_45809, _23843);
        }
        else if (IS_ATOM(_short_path_45809) && IS_SEQUENCE(_23843)) {
        }
        else {
            Concat((object_ptr)&_short_path_45809, _short_path_45809, _23843);
        }
        _23843 = NOVALUE;
LA: 

        /** buildsys.e:338					short_path &= slash*/
        Append(&_short_path_45809, _short_path_45809, _slash_45795);
        goto LB; // [212] 257
L8: 

        /** buildsys.e:340					if not find(' ',longs[i]) then*/
        _2 = (object)SEQ_PTR(_longs_45803);
        _23846 = (object)*(((s1_ptr)_2)->base + _i_45813);
        _23847 = find_from(32LL, _23846, 1LL);
        _23846 = NOVALUE;
        if (_23847 != 0)
        goto LC; // [226] 250
        _23847 = NOVALUE;

        /** buildsys.e:341						short_path &= longs[i] & slash*/
        _2 = (object)SEQ_PTR(_longs_45803);
        _23849 = (object)*(((s1_ptr)_2)->base + _i_45813);
        if (IS_SEQUENCE(_23849) && IS_ATOM(_slash_45795)) {
            Append(&_23850, _23849, _slash_45795);
        }
        else if (IS_ATOM(_23849) && IS_SEQUENCE(_slash_45795)) {
        }
        else {
            Concat((object_ptr)&_23850, _23849, _slash_45795);
            _23849 = NOVALUE;
        }
        _23849 = NOVALUE;
        Concat((object_ptr)&_short_path_45809, _short_path_45809, _23850);
        DeRefDS(_23850);
        _23850 = NOVALUE;

        /** buildsys.e:342						continue*/
        DeRef(_files_45815);
        _files_45815 = NOVALUE;
        goto LD; // [247] 261
LC: 

        /** buildsys.e:344					return 0*/
        DeRef(_files_45815);
        DeRefDS(_long_path_45794);
        DeRef(_longs_45803);
        DeRef(_short_path_45809);
        return 0LL;
LB: 
        DeRef(_files_45815);
        _files_45815 = NOVALUE;

        /** buildsys.e:346			end for -- i*/
LD: 
        _i_45813 = _i_45813 + 1LL;
        goto L5; // [261] 114
L6: 
        ;
    }

    /** buildsys.e:347			if short_path[$] = slash then*/
    if (IS_SEQUENCE(_short_path_45809)){
            _23852 = SEQ_PTR(_short_path_45809)->length;
    }
    else {
        _23852 = 1;
    }
    _2 = (object)SEQ_PTR(_short_path_45809);
    _23853 = (object)*(((s1_ptr)_2)->base + _23852);
    if (binary_op_a(NOTEQ, _23853, _slash_45795)){
        _23853 = NOVALUE;
        goto LE; // [275] 294
    }
    _23853 = NOVALUE;

    /** buildsys.e:348				short_path = short_path[1..$-1]*/
    if (IS_SEQUENCE(_short_path_45809)){
            _23855 = SEQ_PTR(_short_path_45809)->length;
    }
    else {
        _23855 = 1;
    }
    _23856 = _23855 - 1LL;
    _23855 = NOVALUE;
    rhs_slice_target = (object_ptr)&_short_path_45809;
    RHS_Slice(_short_path_45809, 1LL, _23856);
LE: 

    /** buildsys.e:350			return short_path*/
    DeRefDS(_long_path_45794);
    DeRef(_longs_45803);
    DeRef(_23856);
    _23856 = NOVALUE;
    return _short_path_45809;
    ;
}


object _56adjust_for_build_file(object _long_path_45856)
{
    object _short_path_45857 = NOVALUE;
    object _23864 = NOVALUE;
    object _23863 = NOVALUE;
    object _23862 = NOVALUE;
    object _23861 = NOVALUE;
    object _23860 = NOVALUE;
    object _23859 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:355	    object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_45856);
    _0 = _short_path_45857;
    _short_path_45857 = _56adjust_for_command_line_passing(_long_path_45856);
    DeRef(_0);

    /** buildsys.e:356	    if atom(short_path) then*/
    _23859 = IS_ATOM(_short_path_45857);
    if (_23859 == 0)
    {
        _23859 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23859 = NOVALUE;
    }

    /** buildsys.e:357	    	return short_path*/
    DeRefDS(_long_path_45856);
    return _short_path_45857;
L1: 

    /** buildsys.e:359		if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23860 = (_56compiler_type_45705 == 1LL);
    if (_23860 == 0) {
        _23861 = 0;
        goto L2; // [32] 46
    }
    _23862 = (_56build_system_type_45701 != 3LL);
    _23861 = (_23862 != 0);
L2: 
    if (_23861 == 0) {
        goto L3; // [46] 69
    }
    if (_46TWINDOWS_21906 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** buildsys.e:360			return windows_to_mingw_path(short_path)*/
    Ref(_short_path_45857);
    _23864 = _56windows_to_mingw_path(_short_path_45857);
    DeRefDS(_long_path_45856);
    DeRef(_short_path_45857);
    DeRef(_23862);
    _23862 = NOVALUE;
    DeRef(_23860);
    _23860 = NOVALUE;
    return _23864;
    goto L4; // [66] 76
L3: 

    /** buildsys.e:362			return short_path*/
    DeRefDS(_long_path_45856);
    DeRef(_23862);
    _23862 = NOVALUE;
    DeRef(_23864);
    _23864 = NOVALUE;
    DeRef(_23860);
    _23860 = NOVALUE;
    return _short_path_45857;
L4: 
    ;
}


object _56setup_build()
{
    object _c_exe_45872 = NOVALUE;
    object _c_flags_45873 = NOVALUE;
    object _l_exe_45874 = NOVALUE;
    object _l_flags_45875 = NOVALUE;
    object _obj_ext_45876 = NOVALUE;
    object _exe_ext_45877 = NOVALUE;
    object _l_flags_begin_45878 = NOVALUE;
    object _rc_comp_45879 = NOVALUE;
    object _l_names_45880 = NOVALUE;
    object _l_ext_45881 = NOVALUE;
    object _t_slash_45882 = NOVALUE;
    object _eudir_45924 = NOVALUE;
    object _compile_dir_45982 = NOVALUE;
    object _bits_45993 = NOVALUE;
    object _m_flag_46003 = NOVALUE;
    object _24021 = NOVALUE;
    object _24019 = NOVALUE;
    object _24018 = NOVALUE;
    object _24017 = NOVALUE;
    object _24015 = NOVALUE;
    object _24014 = NOVALUE;
    object _24013 = NOVALUE;
    object _24010 = NOVALUE;
    object _24009 = NOVALUE;
    object _24006 = NOVALUE;
    object _24005 = NOVALUE;
    object _23998 = NOVALUE;
    object _23997 = NOVALUE;
    object _23992 = NOVALUE;
    object _23991 = NOVALUE;
    object _23986 = NOVALUE;
    object _23985 = NOVALUE;
    object _23982 = NOVALUE;
    object _23981 = NOVALUE;
    object _23969 = NOVALUE;
    object _23968 = NOVALUE;
    object _23953 = NOVALUE;
    object _23952 = NOVALUE;
    object _23949 = NOVALUE;
    object _23944 = NOVALUE;
    object _23942 = NOVALUE;
    object _23941 = NOVALUE;
    object _23940 = NOVALUE;
    object _23939 = NOVALUE;
    object _23935 = NOVALUE;
    object _23934 = NOVALUE;
    object _23920 = NOVALUE;
    object _23919 = NOVALUE;
    object _23916 = NOVALUE;
    object _23904 = NOVALUE;
    object _23900 = NOVALUE;
    object _23897 = NOVALUE;
    object _23896 = NOVALUE;
    object _23895 = NOVALUE;
    object _23892 = NOVALUE;
    object _23891 = NOVALUE;
    object _23890 = NOVALUE;
    object _23887 = NOVALUE;
    object _23883 = NOVALUE;
    object _23882 = NOVALUE;
    object _23880 = NOVALUE;
    object _23879 = NOVALUE;
    object _23878 = NOVALUE;
    object _23877 = NOVALUE;
    object _23870 = NOVALUE;
    object _23869 = NOVALUE;
    object _23868 = NOVALUE;
    object _23867 = NOVALUE;
    object _23866 = NOVALUE;
    object _23865 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:373			c_exe   = "",*/
    RefDS(_22186);
    DeRef(_c_exe_45872);
    _c_exe_45872 = _22186;

    /** buildsys.e:374			c_flags = "",*/
    RefDS(_22186);
    DeRef(_c_flags_45873);
    _c_flags_45873 = _22186;

    /** buildsys.e:375			l_exe   = "",*/
    RefDS(_22186);
    DeRef(_l_exe_45874);
    _l_exe_45874 = _22186;

    /** buildsys.e:376			l_flags = "",*/
    RefDS(_22186);
    DeRef(_l_flags_45875);
    _l_flags_45875 = _22186;

    /** buildsys.e:377			obj_ext = "",*/
    RefDS(_22186);
    DeRefi(_obj_ext_45876);
    _obj_ext_45876 = _22186;

    /** buildsys.e:378			exe_ext = "",*/
    RefDS(_22186);
    DeRefi(_exe_ext_45877);
    _exe_ext_45877 = _22186;

    /** buildsys.e:379			l_flags_begin = "",*/
    RefDS(_22186);
    DeRefi(_l_flags_begin_45878);
    _l_flags_begin_45878 = _22186;

    /** buildsys.e:380			rc_comp = "",*/
    RefDS(_22186);
    DeRef(_rc_comp_45879);
    _rc_comp_45879 = _22186;

    /** buildsys.e:385		if dll_option*/
    if (_58dll_option_42889 == 0) {
        _23865 = 0;
        goto L1; // [61] 78
    }
    if (IS_SEQUENCE(_58user_pic_library_42902)){
            _23866 = SEQ_PTR(_58user_pic_library_42902)->length;
    }
    else {
        _23866 = 1;
    }
    _23867 = (_23866 > 0LL);
    _23866 = NOVALUE;
    _23865 = (_23867 != 0);
L1: 
    if (_23865 == 0) {
        goto L2; // [78] 101
    }
    _23869 = (_46TWINDOWS_21906 == 0);
    if (_23869 == 0)
    {
        DeRef(_23869);
        _23869 = NOVALUE;
        goto L2; // [88] 101
    }
    else{
        DeRef(_23869);
        _23869 = NOVALUE;
    }

    /** buildsys.e:388			user_library = user_pic_library*/
    RefDS(_58user_pic_library_42902);
    DeRef(_58user_library_42901);
    _58user_library_42901 = _58user_pic_library_42902;
L2: 

    /** buildsys.e:391		if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_58user_library_42901)){
            _23870 = SEQ_PTR(_58user_library_42901)->length;
    }
    else {
        _23870 = 1;
    }
    if (_23870 != 0LL)
    goto L3; // [108] 366

    /** buildsys.e:392			if debug_option then*/
    if (_58debug_option_42899 == 0)
    {
        goto L4; // [116] 128
    }
    else{
    }

    /** buildsys.e:393				l_names = { "eudbg", "eu" }*/
    RefDS(_23873);
    RefDS(_23872);
    DeRef(_l_names_45880);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23872;
    ((intptr_t *)_2)[2] = _23873;
    _l_names_45880 = MAKE_SEQ(_1);
    goto L5; // [125] 135
L4: 

    /** buildsys.e:395				l_names = { "eu", "eudbg" }*/
    RefDS(_23872);
    RefDS(_23873);
    DeRef(_l_names_45880);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _23873;
    ((intptr_t *)_2)[2] = _23872;
    _l_names_45880 = MAKE_SEQ(_1);
L5: 

    /** buildsys.e:400			if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_46TUNIX_21910 != 0) {
        goto L6; // [139] 154
    }
    _23877 = (_56compiler_type_45705 == 1LL);
    if (_23877 == 0)
    {
        DeRef(_23877);
        _23877 = NOVALUE;
        goto L7; // [150] 224
    }
    else{
        DeRef(_23877);
        _23877 = NOVALUE;
    }
L6: 

    /** buildsys.e:401				l_ext = "a"*/
    RefDS(_22467);
    DeRefi(_l_ext_45881);
    _l_ext_45881 = _22467;

    /** buildsys.e:402				t_slash = "/"*/
    RefDS(_23762);
    DeRefi(_t_slash_45882);
    _t_slash_45882 = _23762;

    /** buildsys.e:403				if dll_option and not TWINDOWS then*/
    if (_58dll_option_42889 == 0) {
        goto L8; // [172] 247
    }
    _23879 = (_46TWINDOWS_21906 == 0);
    if (_23879 == 0)
    {
        DeRef(_23879);
        _23879 = NOVALUE;
        goto L8; // [182] 247
    }
    else{
        DeRef(_23879);
        _23879 = NOVALUE;
    }

    /** buildsys.e:404					for i = 1 to length( l_names ) do*/
    if (IS_SEQUENCE(_l_names_45880)){
            _23880 = SEQ_PTR(_l_names_45880)->length;
    }
    else {
        _23880 = 1;
    }
    {
        object _i_45915;
        _i_45915 = 1LL;
L9: 
        if (_i_45915 > _23880){
            goto LA; // [192] 220
        }

        /** buildsys.e:406						l_names[i] &= "so"*/
        _2 = (object)SEQ_PTR(_l_names_45880);
        _23882 = (object)*(((s1_ptr)_2)->base + _i_45915);
        if (IS_SEQUENCE(_23882) && IS_ATOM(_23881)) {
        }
        else if (IS_ATOM(_23882) && IS_SEQUENCE(_23881)) {
            Ref(_23882);
            Prepend(&_23883, _23881, _23882);
        }
        else {
            Concat((object_ptr)&_23883, _23882, _23881);
            _23882 = NOVALUE;
        }
        _23882 = NOVALUE;
        _2 = (object)SEQ_PTR(_l_names_45880);
        _2 = (object)(((s1_ptr)_2)->base + _i_45915);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23883;
        if( _1 != _23883 ){
            DeRef(_1);
        }
        _23883 = NOVALUE;

        /** buildsys.e:407					end for*/
        _i_45915 = _i_45915 + 1LL;
        goto L9; // [215] 199
LA: 
        ;
    }
    goto L8; // [221] 247
L7: 

    /** buildsys.e:409			elsif TWINDOWS then*/
    if (_46TWINDOWS_21906 == 0)
    {
        goto LB; // [228] 246
    }
    else{
    }

    /** buildsys.e:410				l_ext = "lib"*/
    RefDS(_23884);
    DeRefi(_l_ext_45881);
    _l_ext_45881 = _23884;

    /** buildsys.e:411				t_slash = "\\"*/
    RefDS(_23885);
    DeRefi(_t_slash_45882);
    _t_slash_45882 = _23885;
LB: 
L8: 

    /** buildsys.e:414			object eudir = get_eucompiledir()*/
    _0 = _eudir_45924;
    _eudir_45924 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:415			if not file_exists(eudir) then*/
    Ref(_eudir_45924);
    _23887 = _17file_exists(_eudir_45924);
    if (IS_ATOM_INT(_23887)) {
        if (_23887 != 0){
            DeRef(_23887);
            _23887 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    else {
        if (DBL_PTR(_23887)->dbl != 0.0){
            DeRef(_23887);
            _23887 = NOVALUE;
            goto LC; // [258] 279
        }
    }
    DeRef(_23887);
    _23887 = NOVALUE;

    /** buildsys.e:416				printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23890 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23890;
    _23891 = MAKE_SEQ(_1);
    _23890 = NOVALUE;
    EPrintf(2LL, _23889, _23891);
    DeRefDS(_23891);
    _23891 = NOVALUE;

    /** buildsys.e:417				abort(1)*/
    UserCleanup(1LL);
LC: 

    /** buildsys.e:419			for tk = 1 to length(l_names) label "translation kind" do*/
    if (IS_SEQUENCE(_l_names_45880)){
            _23892 = SEQ_PTR(_l_names_45880)->length;
    }
    else {
        _23892 = 1;
    }
    {
        object _tk_45936;
        _tk_45936 = 1LL;
LD: 
        if (_tk_45936 > _23892){
            goto LE; // [286] 365
        }

        /** buildsys.e:420				user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (object)SEQ_PTR(_l_names_45880);
        _23895 = (object)*(((s1_ptr)_2)->base + _tk_45936);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        RefDSn(_t_slash_45882, 2);
        ((intptr_t*)_2)[1] = _t_slash_45882;
        ((intptr_t*)_2)[2] = _t_slash_45882;
        Ref(_23895);
        ((intptr_t*)_2)[3] = _23895;
        RefDS(_l_ext_45881);
        ((intptr_t*)_2)[4] = _l_ext_45881;
        _23896 = MAKE_SEQ(_1);
        _23895 = NOVALUE;
        _23897 = EPrintf(-9999999, _23894, _23896);
        DeRefDS(_23896);
        _23896 = NOVALUE;
        if (IS_SEQUENCE(_eudir_45924) && IS_ATOM(_23897)) {
        }
        else if (IS_ATOM(_eudir_45924) && IS_SEQUENCE(_23897)) {
            Ref(_eudir_45924);
            Prepend(&_58user_library_42901, _23897, _eudir_45924);
        }
        else {
            Concat((object_ptr)&_58user_library_42901, _eudir_45924, _23897);
        }
        DeRefDS(_23897);
        _23897 = NOVALUE;

        /** buildsys.e:421				if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_46TUNIX_21910 != 0) {
            goto LF; // [324] 339
        }
        _23900 = (_56compiler_type_45705 == 1LL);
        if (_23900 == 0)
        {
            DeRef(_23900);
            _23900 = NOVALUE;
            goto L10; // [335] 342
        }
        else{
            DeRef(_23900);
            _23900 = NOVALUE;
        }
LF: 

        /** buildsys.e:422					ifdef UNIX then*/
L10: 

        /** buildsys.e:436				if file_exists(user_library) then*/
        RefDS(_58user_library_42901);
        _23904 = _17file_exists(_58user_library_42901);
        if (_23904 == 0) {
            DeRef(_23904);
            _23904 = NOVALUE;
            goto L11; // [350] 358
        }
        else {
            if (!IS_ATOM_INT(_23904) && DBL_PTR(_23904)->dbl == 0.0){
                DeRef(_23904);
                _23904 = NOVALUE;
                goto L11; // [350] 358
            }
            DeRef(_23904);
            _23904 = NOVALUE;
        }
        DeRef(_23904);
        _23904 = NOVALUE;

        /** buildsys.e:437					exit "translation kind"*/
        goto LE; // [355] 365
L11: 

        /** buildsys.e:439			end for -- tk*/
        _tk_45936 = _tk_45936 + 1LL;
        goto LD; // [360] 293
LE: 
        ;
    }
L3: 
    DeRef(_eudir_45924);
    _eudir_45924 = NOVALUE;

    /** buildsys.e:441		user_library = adjust_for_build_file(user_library)*/
    RefDS(_58user_library_42901);
    _0 = _56adjust_for_build_file(_58user_library_42901);
    DeRefDS(_58user_library_42901);
    _58user_library_42901 = _0;

    /** buildsys.e:443		if TWINDOWS then*/
    if (_46TWINDOWS_21906 == 0)
    {
        goto L12; // [382] 437
    }
    else{
    }

    /** buildsys.e:444			if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45705 != 2LL)
    goto L13; // [389] 402

    /** buildsys.e:445				c_flags &= " /dEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23907);
    goto L14; // [399] 409
L13: 

    /** buildsys.e:447				c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23909);
L14: 

    /** buildsys.e:450			if dll_option then*/
    if (_58dll_option_42889 == 0)
    {
        goto L15; // [413] 426
    }
    else{
    }

    /** buildsys.e:451				exe_ext = ".dll"*/
    RefDS(_23911);
    DeRefi(_exe_ext_45877);
    _exe_ext_45877 = _23911;
    goto L16; // [423] 478
L15: 

    /** buildsys.e:453				exe_ext = ".exe"*/
    RefDS(_23912);
    DeRefi(_exe_ext_45877);
    _exe_ext_45877 = _23912;
    goto L16; // [434] 478
L12: 

    /** buildsys.e:455		elsif TOSX then*/
    if (_46TOSX_21914 == 0)
    {
        goto L17; // [441] 462
    }
    else{
    }

    /** buildsys.e:456			if dll_option then*/
    if (_58dll_option_42889 == 0)
    {
        goto L16; // [448] 478
    }
    else{
    }

    /** buildsys.e:457				exe_ext = ".dylib"*/
    RefDS(_23913);
    DeRefi(_exe_ext_45877);
    _exe_ext_45877 = _23913;
    goto L16; // [459] 478
L17: 

    /** buildsys.e:460			if dll_option then*/
    if (_58dll_option_42889 == 0)
    {
        goto L18; // [466] 477
    }
    else{
    }

    /** buildsys.e:461				exe_ext = ".so"*/
    RefDS(_23914);
    DeRefi(_exe_ext_45877);
    _exe_ext_45877 = _23914;
L18: 
L16: 

    /** buildsys.e:465		object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_45982;
    _compile_dir_45982 = _58get_eucompiledir();
    DeRef(_0);

    /** buildsys.e:466		if not file_exists(compile_dir) then*/
    Ref(_compile_dir_45982);
    _23916 = _17file_exists(_compile_dir_45982);
    if (IS_ATOM_INT(_23916)) {
        if (_23916 != 0){
            DeRef(_23916);
            _23916 = NOVALUE;
            goto L19; // [489] 510
        }
    }
    else {
        if (DBL_PTR(_23916)->dbl != 0.0){
            DeRef(_23916);
            _23916 = NOVALUE;
            goto L19; // [489] 510
        }
    }
    DeRef(_23916);
    _23916 = NOVALUE;

    /** buildsys.e:467			printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23919 = _58get_eucompiledir();
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _23919;
    _23920 = MAKE_SEQ(_1);
    _23919 = NOVALUE;
    EPrintf(2LL, _23918, _23920);
    DeRefDS(_23920);
    _23920 = NOVALUE;

    /** buildsys.e:468			abort(1)*/
    UserCleanup(1LL);
L19: 

    /** buildsys.e:471		integer bits = 32*/
    _bits_45993 = 32LL;

    /** buildsys.e:472		if TX86_64 then*/
    if (_46TX86_64_21922 == 0)
    {
        goto L1A; // [519] 528
    }
    else{
    }

    /** buildsys.e:473			bits = 64*/
    _bits_45993 = 64LL;
L1A: 

    /** buildsys.e:476		switch compiler_type do*/
    _0 = _56compiler_type_45705;
    switch ( _0 ){ 

        /** buildsys.e:477			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:478				c_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_c_exe_45872, _56compiler_prefix_45706, _23923);

        /** buildsys.e:479				l_exe = compiler_prefix & "gcc"*/
        Concat((object_ptr)&_l_exe_45874, _56compiler_prefix_45706, _23923);

        /** buildsys.e:480				obj_ext = "o"*/
        RefDS(_23926);
        DeRefi(_obj_ext_45876);
        _obj_ext_45876 = _23926;

        /** buildsys.e:482				sequence m_flag = ""*/
        RefDS(_22186);
        DeRefi(_m_flag_46003);
        _m_flag_46003 = _22186;

        /** buildsys.e:483				if not TARM then*/
        if (_46TARM_21924 != 0)
        goto L1B; // [575] 585

        /** buildsys.e:485					m_flag = sprintf( "-m%d", bits )*/
        DeRefDSi(_m_flag_46003);
        _m_flag_46003 = EPrintf(-9999999, _23928, _bits_45993);
L1B: 

        /** buildsys.e:488				if debug_option then*/
        if (_58debug_option_42899 == 0)
        {
            goto L1C; // [589] 601
        }
        else{
        }

        /** buildsys.e:489					c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23930);
        goto L1D; // [598] 608
L1C: 

        /** buildsys.e:491					c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23932);
L1D: 

        /** buildsys.e:494				if dll_option and not TWINDOWS then*/
        if (_58dll_option_42889 == 0) {
            goto L1E; // [612] 632
        }
        _23935 = (_46TWINDOWS_21906 == 0);
        if (_23935 == 0)
        {
            DeRef(_23935);
            _23935 = NOVALUE;
            goto L1E; // [622] 632
        }
        else{
            DeRef(_23935);
            _23935 = NOVALUE;
        }

        /** buildsys.e:495					c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23936);
L1E: 

        /** buildsys.e:498				c_flags &= sprintf(" -c -w -fsigned-char -O2 %s -I%s -ffast-math",*/
        _23939 = _58get_eucompiledir();
        _23940 = _56adjust_for_build_file(_23939);
        _23939 = NOVALUE;
        RefDS(_m_flag_46003);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _m_flag_46003;
        ((intptr_t *)_2)[2] = _23940;
        _23941 = MAKE_SEQ(_1);
        _23940 = NOVALUE;
        _23942 = EPrintf(-9999999, _23938, _23941);
        DeRefDS(_23941);
        _23941 = NOVALUE;
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23942);
        DeRefDS(_23942);
        _23942 = NOVALUE;

        /** buildsys.e:501				if TWINDOWS and mno_cygwin then*/
        if (_46TWINDOWS_21906 == 0) {
            goto L1F; // [657] 674
        }
        if (_56mno_cygwin_45729 == 0)
        {
            goto L1F; // [664] 674
        }
        else{
        }

        /** buildsys.e:504					c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23945);
L1F: 

        /** buildsys.e:507				if build_system_type != BUILD_DIRECT then*/
        if (_56build_system_type_45701 == 3LL)
        goto L20; // [678] 695

        /** buildsys.e:508					l_flags = sprintf( " $(RUNTIME_LIBRARY) %s", { m_flag })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_m_flag_46003);
        ((intptr_t*)_2)[1] = _m_flag_46003;
        _23949 = MAKE_SEQ(_1);
        DeRef(_l_flags_45875);
        _l_flags_45875 = EPrintf(-9999999, _23948, _23949);
        DeRefDS(_23949);
        _23949 = NOVALUE;
        goto L21; // [692] 712
L20: 

        /** buildsys.e:510					l_flags = sprintf( " %s %s",*/
        RefDS(_58user_library_42901);
        _23952 = _56adjust_for_command_line_passing(_58user_library_42901);
        RefDS(_m_flag_46003);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23952;
        ((intptr_t *)_2)[2] = _m_flag_46003;
        _23953 = MAKE_SEQ(_1);
        _23952 = NOVALUE;
        DeRef(_l_flags_45875);
        _l_flags_45875 = EPrintf(-9999999, _23951, _23953);
        DeRefDS(_23953);
        _23953 = NOVALUE;
L21: 

        /** buildsys.e:514				if dll_option then*/
        if (_58dll_option_42889 == 0)
        {
            goto L22; // [716] 726
        }
        else{
        }

        /** buildsys.e:515					l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23955);
L22: 

        /** buildsys.e:518				if TLINUX then*/
        if (_46TLINUX_21908 == 0)
        {
            goto L23; // [730] 742
        }
        else{
        }

        /** buildsys.e:519					l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23957);
        goto L24; // [739] 811
L23: 

        /** buildsys.e:520				elsif TBSD then*/
        if (_46TBSD_21912 == 0)
        {
            goto L25; // [746] 758
        }
        else{
        }

        /** buildsys.e:521					l_flags &= " -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23959);
        goto L24; // [755] 811
L25: 

        /** buildsys.e:522				elsif TOSX then*/
        if (_46TOSX_21914 == 0)
        {
            goto L26; // [762] 774
        }
        else{
        }

        /** buildsys.e:523					l_flags &= " -lresolv"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23961);
        goto L24; // [771] 811
L26: 

        /** buildsys.e:524				elsif TWINDOWS then*/
        if (_46TWINDOWS_21906 == 0)
        {
            goto L27; // [778] 810
        }
        else{
        }

        /** buildsys.e:525					if mno_cygwin then*/
        if (_56mno_cygwin_45729 == 0)
        {
            goto L28; // [785] 795
        }
        else{
        }

        /** buildsys.e:527						l_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23945);
L28: 

        /** buildsys.e:529					if not con_option then*/
        if (_58con_option_42891 != 0)
        goto L29; // [799] 809

        /** buildsys.e:532						l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23965);
L29: 
L27: 
L24: 

        /** buildsys.e:537				rc_comp = compiler_prefix & "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23968 = _17current_dir();
        _23969 = _56adjust_for_build_file(_23968);
        _23968 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _23970;
            concat_list[1] = _23969;
            concat_list[2] = _23967;
            concat_list[3] = _56compiler_prefix_45706;
            Concat_N((object_ptr)&_rc_comp_45879, concat_list, 4);
        }
        DeRef(_23969);
        _23969 = NOVALUE;
        DeRefi(_m_flag_46003);
        _m_flag_46003 = NOVALUE;
        goto L2A; // [831] 1037

        /** buildsys.e:539			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:540				c_exe = compiler_prefix & "wcc386"*/
        Concat((object_ptr)&_c_exe_45872, _56compiler_prefix_45706, _23972);

        /** buildsys.e:541				l_exe = compiler_prefix & "wlink"*/
        Concat((object_ptr)&_l_exe_45874, _56compiler_prefix_45706, _23974);

        /** buildsys.e:542				obj_ext = "obj"*/
        RefDS(_23976);
        DeRefi(_obj_ext_45876);
        _obj_ext_45876 = _23976;

        /** buildsys.e:544				if debug_option then*/
        if (_58debug_option_42899 == 0)
        {
            goto L2B; // [864] 881
        }
        else{
        }

        /** buildsys.e:545					c_flags = " /d3"*/
        RefDS(_23977);
        DeRef(_c_flags_45873);
        _c_flags_45873 = _23977;

        /** buildsys.e:546					l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_45878, _l_flags_begin_45878, _23978);
L2B: 

        /** buildsys.e:549				l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42904;
        _23981 = MAKE_SEQ(_1);
        _23982 = EPrintf(-9999999, _23980, _23981);
        DeRefDS(_23981);
        _23981 = NOVALUE;
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23982);
        DeRefDS(_23982);
        _23982 = NOVALUE;

        /** buildsys.e:550				l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _58total_stack_size_42904;
        _23985 = MAKE_SEQ(_1);
        _23986 = EPrintf(-9999999, _23984, _23985);
        DeRefDS(_23985);
        _23985 = NOVALUE;
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23986);
        DeRefDS(_23986);
        _23986 = NOVALUE;

        /** buildsys.e:551				l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23988);

        /** buildsys.e:553				if dll_option then*/
        if (_58dll_option_42889 == 0)
        {
            goto L2C; // [923] 949
        }
        else{
        }

        /** buildsys.e:554					c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_45982);
        _23991 = _56adjust_for_build_file(_compile_dir_45982);
        if (IS_SEQUENCE(_23990) && IS_ATOM(_23991)) {
            Ref(_23991);
            Append(&_23992, _23990, _23991);
        }
        else if (IS_ATOM(_23990) && IS_SEQUENCE(_23991)) {
        }
        else {
            Concat((object_ptr)&_23992, _23990, _23991);
        }
        DeRef(_23991);
        _23991 = NOVALUE;
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23992);
        DeRefDS(_23992);
        _23992 = NOVALUE;

        /** buildsys.e:555					l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _23994);
        goto L2D; // [946] 987
L2C: 

        /** buildsys.e:557					c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_45982);
        _23997 = _56adjust_for_build_file(_compile_dir_45982);
        if (IS_SEQUENCE(_23996) && IS_ATOM(_23997)) {
            Ref(_23997);
            Append(&_23998, _23996, _23997);
        }
        else if (IS_ATOM(_23996) && IS_SEQUENCE(_23997)) {
        }
        else {
            Concat((object_ptr)&_23998, _23996, _23997);
        }
        DeRef(_23997);
        _23997 = NOVALUE;
        Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _23998);
        DeRefDS(_23998);
        _23998 = NOVALUE;

        /** buildsys.e:558					if con_option then*/
        if (_58con_option_42891 == 0)
        {
            goto L2E; // [967] 979
        }
        else{
        }

        /** buildsys.e:560						l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_45875, _24000, _l_flags_45875);
        goto L2F; // [976] 986
L2E: 

        /** buildsys.e:562						l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_45875, _24002, _l_flags_45875);
L2F: 
L2D: 

        /** buildsys.e:566				l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58user_library_42901);
        ((intptr_t*)_2)[1] = _58user_library_42901;
        _24005 = MAKE_SEQ(_1);
        _24006 = EPrintf(-9999999, _24004, _24005);
        DeRefDS(_24005);
        _24005 = NOVALUE;
        Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _24006);
        DeRefDS(_24006);
        _24006 = NOVALUE;

        /** buildsys.e:570				rc_comp = compiler_prefix &"wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _24009 = _17current_dir();
        _24010 = _56adjust_for_build_file(_24009);
        _24009 = NOVALUE;
        {
            object concat_list[4];

            concat_list[0] = _24011;
            concat_list[1] = _24010;
            concat_list[2] = _24008;
            concat_list[3] = _56compiler_prefix_45706;
            Concat_N((object_ptr)&_rc_comp_45879, concat_list, 4);
        }
        DeRef(_24010);
        _24010 = NOVALUE;
        goto L2A; // [1021] 1037

        /** buildsys.e:571			case else*/
        default:

        /** buildsys.e:572				CompileErr(COMPILER_IS_UNKNOWN)*/
        RefDS(_22186);
        _50CompileErr(43LL, _22186, 0LL);
    ;}L2A: 

    /** buildsys.e:575		if length(cflags) then*/
    if (IS_SEQUENCE(_56cflags_45723)){
            _24013 = SEQ_PTR(_56cflags_45723)->length;
    }
    else {
        _24013 = 1;
    }
    if (_24013 == 0)
    {
        _24013 = NOVALUE;
        goto L30; // [1044] 1057
    }
    else{
        _24013 = NOVALUE;
    }

    /** buildsys.e:577			c_flags = cflags*/
    RefDS(_56cflags_45723);
    DeRef(_c_flags_45873);
    _c_flags_45873 = _56cflags_45723;
L30: 

    /** buildsys.e:580		if length(extra_cflags) then*/
    if (IS_SEQUENCE(_56extra_cflags_45724)){
            _24014 = SEQ_PTR(_56extra_cflags_45724)->length;
    }
    else {
        _24014 = 1;
    }
    if (_24014 == 0)
    {
        _24014 = NOVALUE;
        goto L31; // [1064] 1080
    }
    else{
        _24014 = NOVALUE;
    }

    /** buildsys.e:581			c_flags &= " " & extra_cflags*/
    Concat((object_ptr)&_24015, _23572, _56extra_cflags_45724);
    Concat((object_ptr)&_c_flags_45873, _c_flags_45873, _24015);
    DeRefDS(_24015);
    _24015 = NOVALUE;
L31: 

    /** buildsys.e:584		if length(lflags) then*/
    if (IS_SEQUENCE(_56lflags_45725)){
            _24017 = SEQ_PTR(_56lflags_45725)->length;
    }
    else {
        _24017 = 1;
    }
    if (_24017 == 0)
    {
        _24017 = NOVALUE;
        goto L32; // [1087] 1107
    }
    else{
        _24017 = NOVALUE;
    }

    /** buildsys.e:585			l_flags = lflags*/
    RefDS(_56lflags_45725);
    DeRef(_l_flags_45875);
    _l_flags_45875 = _56lflags_45725;

    /** buildsys.e:586			l_flags_begin = ""*/
    RefDS(_22186);
    DeRefi(_l_flags_begin_45878);
    _l_flags_begin_45878 = _22186;
L32: 

    /** buildsys.e:589		if length(extra_lflags) then*/
    if (IS_SEQUENCE(_56extra_lflags_45726)){
            _24018 = SEQ_PTR(_56extra_lflags_45726)->length;
    }
    else {
        _24018 = 1;
    }
    if (_24018 == 0)
    {
        _24018 = NOVALUE;
        goto L33; // [1114] 1130
    }
    else{
        _24018 = NOVALUE;
    }

    /** buildsys.e:590			l_flags &= " " & extra_lflags*/
    Concat((object_ptr)&_24019, _23572, _56extra_lflags_45726);
    Concat((object_ptr)&_l_flags_45875, _l_flags_45875, _24019);
    DeRefDS(_24019);
    _24019 = NOVALUE;
L33: 

    /** buildsys.e:593		return { */
    _1 = NewS1(9);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_c_exe_45872);
    ((intptr_t*)_2)[1] = _c_exe_45872;
    RefDS(_c_flags_45873);
    ((intptr_t*)_2)[2] = _c_flags_45873;
    RefDS(_l_exe_45874);
    ((intptr_t*)_2)[3] = _l_exe_45874;
    RefDS(_l_flags_45875);
    ((intptr_t*)_2)[4] = _l_flags_45875;
    RefDS(_obj_ext_45876);
    ((intptr_t*)_2)[5] = _obj_ext_45876;
    RefDS(_exe_ext_45877);
    ((intptr_t*)_2)[6] = _exe_ext_45877;
    RefDS(_l_flags_begin_45878);
    ((intptr_t*)_2)[7] = _l_flags_begin_45878;
    RefDS(_rc_comp_45879);
    ((intptr_t*)_2)[8] = _rc_comp_45879;
    RefDS(_58user_library_42901);
    ((intptr_t*)_2)[9] = _58user_library_42901;
    _24021 = MAKE_SEQ(_1);
    DeRefDS(_c_exe_45872);
    DeRefDS(_c_flags_45873);
    DeRefDS(_l_exe_45874);
    DeRefDS(_l_flags_45875);
    DeRefDSi(_obj_ext_45876);
    DeRefDSi(_exe_ext_45877);
    DeRefDSi(_l_flags_begin_45878);
    DeRefDS(_rc_comp_45879);
    DeRef(_l_names_45880);
    DeRefi(_l_ext_45881);
    DeRefi(_t_slash_45882);
    DeRef(_compile_dir_45982);
    DeRef(_23867);
    _23867 = NOVALUE;
    return _24021;
    ;
}


void _56ensure_exename(object _ext_46150)
{
    object _24028 = NOVALUE;
    object _24027 = NOVALUE;
    object _24026 = NOVALUE;
    object _24025 = NOVALUE;
    object _24023 = NOVALUE;
    object _24022 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:602		if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24022 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24022)){
            _24023 = SEQ_PTR(_24022)->length;
    }
    else {
        _24023 = 1;
    }
    _24022 = NOVALUE;
    if (_24023 != 0LL)
    goto L1; // [16] 67

    /** buildsys.e:603			exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _24025 = _17current_dir();
    {
        object concat_list[4];

        concat_list[0] = _ext_46150;
        concat_list[1] = _58file0_44847;
        concat_list[2] = 92LL;
        concat_list[3] = _24025;
        Concat_N((object_ptr)&_24026, concat_list, 4);
    }
    DeRef(_24025);
    _24025 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24026;
    if( _1 != _24026 ){
        DeRef(_1);
    }
    _24026 = NOVALUE;

    /** buildsys.e:604			exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24027 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24027);
    _24028 = _56adjust_for_command_line_passing(_24027);
    _24027 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24028;
    if( _1 != _24028 ){
        DeRef(_1);
    }
    _24028 = NOVALUE;
L1: 

    /** buildsys.e:606	end procedure*/
    DeRefDS(_ext_46150);
    _24022 = NOVALUE;
    return;
    ;
}


void _56write_objlink_file()
{
    object _settings_46168 = NOVALUE;
    object _fh_46170 = NOVALUE;
    object _s_46218 = NOVALUE;
    object _24077 = NOVALUE;
    object _24075 = NOVALUE;
    object _24074 = NOVALUE;
    object _24073 = NOVALUE;
    object _24072 = NOVALUE;
    object _24071 = NOVALUE;
    object _24070 = NOVALUE;
    object _24069 = NOVALUE;
    object _24068 = NOVALUE;
    object _24067 = NOVALUE;
    object _24066 = NOVALUE;
    object _24065 = NOVALUE;
    object _24064 = NOVALUE;
    object _24062 = NOVALUE;
    object _24061 = NOVALUE;
    object _24060 = NOVALUE;
    object _24059 = NOVALUE;
    object _24057 = NOVALUE;
    object _24056 = NOVALUE;
    object _24055 = NOVALUE;
    object _24054 = NOVALUE;
    object _24053 = NOVALUE;
    object _24052 = NOVALUE;
    object _24051 = NOVALUE;
    object _24050 = NOVALUE;
    object _24049 = NOVALUE;
    object _24046 = NOVALUE;
    object _24045 = NOVALUE;
    object _24042 = NOVALUE;
    object _24041 = NOVALUE;
    object _24040 = NOVALUE;
    object _24039 = NOVALUE;
    object _24038 = NOVALUE;
    object _24036 = NOVALUE;
    object _24035 = NOVALUE;
    object _24034 = NOVALUE;
    object _24031 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:612		sequence settings = setup_build()*/
    _0 = _settings_46168;
    _settings_46168 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:613		integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24030;
        concat_list[1] = _58file0_44847;
        concat_list[2] = _58output_dir_42903;
        Concat_N((object_ptr)&_24031, concat_list, 3);
    }
    _fh_46170 = EOpen(_24031, _24032, 0LL);
    DeRefDS(_24031);
    _24031 = NOVALUE;

    /** buildsys.e:615		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46168);
    _24034 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24034);
    _56ensure_exename(_24034);
    _24034 = NOVALUE;

    /** buildsys.e:617		if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (object)SEQ_PTR(_settings_46168);
    _24035 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_24035)){
            _24036 = SEQ_PTR(_24035)->length;
    }
    else {
        _24036 = 1;
    }
    _24035 = NOVALUE;
    if (_24036 <= 0LL)
    goto L1; // [43] 63

    /** buildsys.e:618			puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (object)SEQ_PTR(_settings_46168);
    _24038 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_24038) && IS_ATOM(_46HOSTNL_21929)) {
    }
    else if (IS_ATOM(_24038) && IS_SEQUENCE(_46HOSTNL_21929)) {
        Ref(_24038);
        Prepend(&_24039, _46HOSTNL_21929, _24038);
    }
    else {
        Concat((object_ptr)&_24039, _24038, _46HOSTNL_21929);
        _24038 = NOVALUE;
    }
    _24038 = NOVALUE;
    EPuts(_fh_46170, _24039); // DJP 
    DeRefDS(_24039);
    _24039 = NOVALUE;
L1: 

    /** buildsys.e:621		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24040 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24040 = 1;
    }
    {
        object _i_46186;
        _i_46186 = 1LL;
L2: 
        if (_i_46186 > _24040){
            goto L3; // [70] 132
        }

        /** buildsys.e:622			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24041 = (object)*(((s1_ptr)_2)->base + _i_46186);
        _24042 = e_match_from(_23332, _24041, 1LL);
        _24041 = NOVALUE;
        if (_24042 == 0)
        {
            _24042 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _24042 = NOVALUE;
        }

        /** buildsys.e:623				if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45705 != 2LL)
        goto L5; // [97] 107

        /** buildsys.e:624					puts(fh, "FILE ")*/
        EPuts(_fh_46170, _24044); // DJP 
L5: 

        /** buildsys.e:627				puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24045 = (object)*(((s1_ptr)_2)->base + _i_46186);
        Concat((object_ptr)&_24046, _24045, _46HOSTNL_21929);
        _24045 = NOVALUE;
        _24045 = NOVALUE;
        EPuts(_fh_46170, _24046); // DJP 
        DeRefDS(_24046);
        _24046 = NOVALUE;
L4: 

        /** buildsys.e:629		end for*/
        _i_46186 = _i_46186 + 1LL;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** buildsys.e:631		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45705 != 2LL)
    goto L6; // [136] 165

    /** buildsys.e:632			printf(fh, "NAME '%s'" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24049, _24048, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24050 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24050);
    ((intptr_t*)_2)[1] = _24050;
    _24051 = MAKE_SEQ(_1);
    _24050 = NOVALUE;
    EPrintf(_fh_46170, _24049, _24051);
    DeRefDS(_24049);
    _24049 = NOVALUE;
    DeRefDS(_24051);
    _24051 = NOVALUE;
L6: 

    /** buildsys.e:635		puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (object)SEQ_PTR(_settings_46168);
    _24052 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_SEQUENCE(_24052) && IS_ATOM(_46HOSTNL_21929)) {
    }
    else if (IS_ATOM(_24052) && IS_SEQUENCE(_46HOSTNL_21929)) {
        Ref(_24052);
        Prepend(&_24053, _46HOSTNL_21929, _24052);
    }
    else {
        Concat((object_ptr)&_24053, _24052, _46HOSTNL_21929);
        _24052 = NOVALUE;
    }
    _24052 = NOVALUE;
    RefDS(_3922);
    _24054 = _14trim(_24053, _3922, 0LL);
    _24053 = NOVALUE;
    EPuts(_fh_46170, _24054); // DJP 
    DeRef(_24054);
    _24054 = NOVALUE;

    /** buildsys.e:637		if compiler_type = COMPILER_WATCOM and dll_option then*/
    _24055 = (_56compiler_type_45705 == 2LL);
    if (_24055 == 0) {
        goto L7; // [194] 361
    }
    if (_58dll_option_42889 == 0)
    {
        goto L7; // [201] 361
    }
    else{
    }

    /** buildsys.e:638			puts(fh, HOSTNL)*/
    EPuts(_fh_46170, _46HOSTNL_21929); // DJP 

    /** buildsys.e:640			object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _24057 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    DeRef(_s_46218);
    _2 = (object)SEQ_PTR(_24057);
    _s_46218 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_46218);
    _24057 = NOVALUE;

    /** buildsys.e:641			while s do*/
L8: 
    if (_s_46218 <= 0) {
        if (_s_46218 == 0) {
            goto L9; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_46218) && DBL_PTR(_s_46218)->dbl == 0.0){
                goto L9; // [232] 360
            }
        }
    }

    /** buildsys.e:642				if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46218)){
        _24059 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46218)->dbl));
    }
    else{
        _24059 = (object)*(((s1_ptr)_2)->base + _s_46218);
    }
    _2 = (object)SEQ_PTR(_24059);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _24060 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _24060 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _24059 = NOVALUE;
    _24061 = find_from(_24060, _38RTN_TOKS_16291, 1LL);
    _24060 = NOVALUE;
    if (_24061 == 0)
    {
        _24061 = NOVALUE;
        goto LA; // [256] 341
    }
    else{
        _24061 = NOVALUE;
    }

    /** buildsys.e:643					if is_exported( s ) then*/
    Ref(_s_46218);
    _24062 = _58is_exported(_s_46218);
    if (_24062 == 0) {
        DeRef(_24062);
        _24062 = NOVALUE;
        goto LB; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_24062) && DBL_PTR(_24062)->dbl == 0.0){
            DeRef(_24062);
            _24062 = NOVALUE;
            goto LB; // [265] 340
        }
        DeRef(_24062);
        _24062 = NOVALUE;
    }
    DeRef(_24062);
    _24062 = NOVALUE;

    /** buildsys.e:644						printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_24064, _24063, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46218)){
        _24065 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46218)->dbl));
    }
    else{
        _24065 = (object)*(((s1_ptr)_2)->base + _s_46218);
    }
    _2 = (object)SEQ_PTR(_24065);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _24066 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _24066 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _24065 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46218)){
        _24067 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46218)->dbl));
    }
    else{
        _24067 = (object)*(((s1_ptr)_2)->base + _s_46218);
    }
    _2 = (object)SEQ_PTR(_24067);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _24068 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _24068 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _24067 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46218)){
        _24069 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46218)->dbl));
    }
    else{
        _24069 = (object)*(((s1_ptr)_2)->base + _s_46218);
    }
    _2 = (object)SEQ_PTR(_24069);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _24070 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _24070 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _24069 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46218)){
        _24071 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46218)->dbl));
    }
    else{
        _24071 = (object)*(((s1_ptr)_2)->base + _s_46218);
    }
    _2 = (object)SEQ_PTR(_24071);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _24072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _24072 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _24071 = NOVALUE;
    if (IS_ATOM_INT(_24072)) {
        {
            int128_t p128 = (int128_t)_24072 * (int128_t)4LL;
            if( p128 != (int128_t)(_24073 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _24073 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _24073 = binary_op(MULTIPLY, _24072, 4LL);
    }
    _24072 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24066);
    ((intptr_t*)_2)[1] = _24066;
    Ref(_24068);
    ((intptr_t*)_2)[2] = _24068;
    Ref(_24070);
    ((intptr_t*)_2)[3] = _24070;
    ((intptr_t*)_2)[4] = _24073;
    _24074 = MAKE_SEQ(_1);
    _24073 = NOVALUE;
    _24070 = NOVALUE;
    _24068 = NOVALUE;
    _24066 = NOVALUE;
    EPrintf(_fh_46170, _24064, _24074);
    DeRefDS(_24064);
    _24064 = NOVALUE;
    DeRefDS(_24074);
    _24074 = NOVALUE;
LB: 
LA: 

    /** buildsys.e:649				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_s_46218)){
        _24075 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_s_46218)->dbl));
    }
    else{
        _24075 = (object)*(((s1_ptr)_2)->base + _s_46218);
    }
    DeRef(_s_46218);
    _2 = (object)SEQ_PTR(_24075);
    _s_46218 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_s_46218);
    _24075 = NOVALUE;

    /** buildsys.e:650			end while*/
    goto L8; // [357] 232
L9: 
L7: 
    DeRef(_s_46218);
    _s_46218 = NOVALUE;

    /** buildsys.e:653		close(fh)*/
    EClose(_fh_46170);

    /** buildsys.e:655		generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_24077, _58file0_44847, _24030);
    RefDS(_24077);
    Append(&_58generated_files_42893, _58generated_files_42893, _24077);
    DeRefDS(_24077);
    _24077 = NOVALUE;

    /** buildsys.e:656	end procedure*/
    DeRef(_settings_46168);
    _24035 = NOVALUE;
    DeRef(_24055);
    _24055 = NOVALUE;
    return;
    ;
}


void _56write_makefile_srcobj_list(object _fh_46267)
{
    object _file_count_46297 = NOVALUE;
    object _24109 = NOVALUE;
    object _24108 = NOVALUE;
    object _24107 = NOVALUE;
    object _24105 = NOVALUE;
    object _24104 = NOVALUE;
    object _24103 = NOVALUE;
    object _24101 = NOVALUE;
    object _24100 = NOVALUE;
    object _24098 = NOVALUE;
    object _24097 = NOVALUE;
    object _24096 = NOVALUE;
    object _24095 = NOVALUE;
    object _24094 = NOVALUE;
    object _24093 = NOVALUE;
    object _24091 = NOVALUE;
    object _24090 = NOVALUE;
    object _24089 = NOVALUE;
    object _24085 = NOVALUE;
    object _24084 = NOVALUE;
    object _24083 = NOVALUE;
    object _24082 = NOVALUE;
    object _24081 = NOVALUE;
    object _24080 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:660		printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_58file0_44847);
    _24080 = _14upper(_58file0_44847);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24080;
    _24081 = MAKE_SEQ(_1);
    _24080 = NOVALUE;
    EPrintf(_fh_46267, _24079, _24081);
    DeRefDS(_24081);
    _24081 = NOVALUE;

    /** buildsys.e:661		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24082 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24082 = 1;
    }
    {
        object _i_46274;
        _i_46274 = 1LL;
L1: 
        if (_i_46274 > _24082){
            goto L2; // [26] 94
        }

        /** buildsys.e:662			if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24083 = (object)*(((s1_ptr)_2)->base + _i_46274);
        if (IS_SEQUENCE(_24083)){
                _24084 = SEQ_PTR(_24083)->length;
        }
        else {
            _24084 = 1;
        }
        _2 = (object)SEQ_PTR(_24083);
        _24085 = (object)*(((s1_ptr)_2)->base + _24084);
        _24083 = NOVALUE;
        if (binary_op_a(NOTEQ, _24085, 99LL)){
            _24085 = NOVALUE;
            goto L3; // [48] 87
        }
        _24085 = NOVALUE;

        /** buildsys.e:663				if i > 1 then*/
        if (_i_46274 <= 1LL)
        goto L4; // [54] 71

        /** buildsys.e:664					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21929);
        ((intptr_t*)_2)[1] = _46HOSTNL_21929;
        _24089 = MAKE_SEQ(_1);
        EPrintf(_fh_46267, _24088, _24089);
        DeRefDS(_24089);
        _24089 = NOVALUE;
L4: 

        /** buildsys.e:666				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24090 = (object)*(((s1_ptr)_2)->base + _i_46274);
        Concat((object_ptr)&_24091, _23572, _24090);
        _24090 = NOVALUE;
        EPuts(_fh_46267, _24091); // DJP 
        DeRefDS(_24091);
        _24091 = NOVALUE;
L3: 

        /** buildsys.e:668		end for*/
        _i_46274 = _i_46274 + 1LL;
        goto L1; // [89] 33
L2: 
        ;
    }

    /** buildsys.e:669		puts(fh, HOSTNL)*/
    EPuts(_fh_46267, _46HOSTNL_21929); // DJP 

    /** buildsys.e:671		printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_58file0_44847);
    _24093 = _14upper(_58file0_44847);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24093;
    _24094 = MAKE_SEQ(_1);
    _24093 = NOVALUE;
    EPrintf(_fh_46267, _24092, _24094);
    DeRefDS(_24094);
    _24094 = NOVALUE;

    /** buildsys.e:672		integer file_count = 0*/
    _file_count_46297 = 0LL;

    /** buildsys.e:673		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24095 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24095 = 1;
    }
    {
        object _i_46299;
        _i_46299 = 1LL;
L5: 
        if (_i_46299 > _24095){
            goto L6; // [129] 199
        }

        /** buildsys.e:674			if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24096 = (object)*(((s1_ptr)_2)->base + _i_46299);
        _24097 = e_match_from(_23332, _24096, 1LL);
        _24096 = NOVALUE;
        if (_24097 == 0)
        {
            _24097 = NOVALUE;
            goto L7; // [149] 192
        }
        else{
            _24097 = NOVALUE;
        }

        /** buildsys.e:675				if file_count then*/
        if (_file_count_46297 == 0)
        {
            goto L8; // [154] 170
        }
        else{
        }

        /** buildsys.e:676					printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21929);
        ((intptr_t*)_2)[1] = _46HOSTNL_21929;
        _24098 = MAKE_SEQ(_1);
        EPrintf(_fh_46267, _24088, _24098);
        DeRefDS(_24098);
        _24098 = NOVALUE;
L8: 

        /** buildsys.e:678				file_count += 1*/
        _file_count_46297 = _file_count_46297 + 1;

        /** buildsys.e:679				puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24100 = (object)*(((s1_ptr)_2)->base + _i_46299);
        Concat((object_ptr)&_24101, _23572, _24100);
        _24100 = NOVALUE;
        EPuts(_fh_46267, _24101); // DJP 
        DeRefDS(_24101);
        _24101 = NOVALUE;
L7: 

        /** buildsys.e:681		end for*/
        _i_46299 = _i_46299 + 1LL;
        goto L5; // [194] 136
L6: 
        ;
    }

    /** buildsys.e:682		puts(fh, HOSTNL)*/
    EPuts(_fh_46267, _46HOSTNL_21929); // DJP 

    /** buildsys.e:684		printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_58file0_44847);
    _24103 = _14upper(_58file0_44847);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24103;
    _24104 = MAKE_SEQ(_1);
    _24103 = NOVALUE;
    EPrintf(_fh_46267, _24102, _24104);
    DeRefDS(_24104);
    _24104 = NOVALUE;

    /** buildsys.e:685		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24105 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24105 = 1;
    }
    {
        object _i_46320;
        _i_46320 = 1LL;
L9: 
        if (_i_46320 > _24105){
            goto LA; // [229] 277
        }

        /** buildsys.e:686			if i > 1 then*/
        if (_i_46320 <= 1LL)
        goto LB; // [238] 255

        /** buildsys.e:687				printf(fh, " \\%s\t", { HOSTNL }  )*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_46HOSTNL_21929);
        ((intptr_t*)_2)[1] = _46HOSTNL_21929;
        _24107 = MAKE_SEQ(_1);
        EPrintf(_fh_46267, _24088, _24107);
        DeRefDS(_24107);
        _24107 = NOVALUE;
LB: 

        /** buildsys.e:689			puts(fh, " " & generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24108 = (object)*(((s1_ptr)_2)->base + _i_46320);
        Concat((object_ptr)&_24109, _23572, _24108);
        _24108 = NOVALUE;
        EPuts(_fh_46267, _24109); // DJP 
        DeRefDS(_24109);
        _24109 = NOVALUE;

        /** buildsys.e:690		end for*/
        _i_46320 = _i_46320 + 1LL;
        goto L9; // [272] 236
LA: 
        ;
    }

    /** buildsys.e:691		puts(fh, HOSTNL)*/
    EPuts(_fh_46267, _46HOSTNL_21929); // DJP 

    /** buildsys.e:692	end procedure*/
    return;
    ;
}


object _56windows_to_mingw_path(object _s_46333)
{
    object _24111 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:701		ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** buildsys.e:711		return search:find_replace('\\',s,'/')*/
    RefDS(_s_46333);
    _24111 = _16find_replace(92LL, _s_46333, 47LL, 0LL);
    DeRefDS(_s_46333);
    return _24111;
    ;
}


void _56write_makefile_full()
{
    object _settings_46338 = NOVALUE;
    object _fh_46341 = NOVALUE;
    object _24238 = NOVALUE;
    object _24236 = NOVALUE;
    object _24234 = NOVALUE;
    object _24233 = NOVALUE;
    object _24232 = NOVALUE;
    object _24231 = NOVALUE;
    object _24230 = NOVALUE;
    object _24228 = NOVALUE;
    object _24227 = NOVALUE;
    object _24225 = NOVALUE;
    object _24224 = NOVALUE;
    object _24223 = NOVALUE;
    object _24222 = NOVALUE;
    object _24220 = NOVALUE;
    object _24219 = NOVALUE;
    object _24217 = NOVALUE;
    object _24216 = NOVALUE;
    object _24214 = NOVALUE;
    object _24213 = NOVALUE;
    object _24212 = NOVALUE;
    object _24211 = NOVALUE;
    object _24210 = NOVALUE;
    object _24209 = NOVALUE;
    object _24208 = NOVALUE;
    object _24207 = NOVALUE;
    object _24205 = NOVALUE;
    object _24204 = NOVALUE;
    object _24203 = NOVALUE;
    object _24202 = NOVALUE;
    object _24201 = NOVALUE;
    object _24200 = NOVALUE;
    object _24199 = NOVALUE;
    object _24198 = NOVALUE;
    object _24197 = NOVALUE;
    object _24196 = NOVALUE;
    object _24195 = NOVALUE;
    object _24194 = NOVALUE;
    object _24193 = NOVALUE;
    object _24191 = NOVALUE;
    object _24190 = NOVALUE;
    object _24188 = NOVALUE;
    object _24186 = NOVALUE;
    object _24184 = NOVALUE;
    object _24183 = NOVALUE;
    object _24182 = NOVALUE;
    object _24181 = NOVALUE;
    object _24180 = NOVALUE;
    object _24179 = NOVALUE;
    object _24178 = NOVALUE;
    object _24177 = NOVALUE;
    object _24176 = NOVALUE;
    object _24175 = NOVALUE;
    object _24174 = NOVALUE;
    object _24173 = NOVALUE;
    object _24172 = NOVALUE;
    object _24171 = NOVALUE;
    object _24169 = NOVALUE;
    object _24168 = NOVALUE;
    object _24167 = NOVALUE;
    object _24166 = NOVALUE;
    object _24165 = NOVALUE;
    object _24164 = NOVALUE;
    object _24163 = NOVALUE;
    object _24162 = NOVALUE;
    object _24161 = NOVALUE;
    object _24159 = NOVALUE;
    object _24158 = NOVALUE;
    object _24157 = NOVALUE;
    object _24156 = NOVALUE;
    object _24154 = NOVALUE;
    object _24153 = NOVALUE;
    object _24152 = NOVALUE;
    object _24151 = NOVALUE;
    object _24150 = NOVALUE;
    object _24149 = NOVALUE;
    object _24147 = NOVALUE;
    object _24146 = NOVALUE;
    object _24145 = NOVALUE;
    object _24144 = NOVALUE;
    object _24143 = NOVALUE;
    object _24142 = NOVALUE;
    object _24141 = NOVALUE;
    object _24139 = NOVALUE;
    object _24138 = NOVALUE;
    object _24137 = NOVALUE;
    object _24136 = NOVALUE;
    object _24133 = NOVALUE;
    object _24132 = NOVALUE;
    object _24131 = NOVALUE;
    object _24128 = NOVALUE;
    object _24127 = NOVALUE;
    object _24126 = NOVALUE;
    object _24124 = NOVALUE;
    object _24123 = NOVALUE;
    object _24122 = NOVALUE;
    object _24120 = NOVALUE;
    object _24119 = NOVALUE;
    object _24118 = NOVALUE;
    object _24115 = NOVALUE;
    object _24113 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:718		sequence settings = setup_build()*/
    _0 = _settings_46338;
    _settings_46338 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:720		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46338);
    _24113 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24113);
    _56ensure_exename(_24113);
    _24113 = NOVALUE;

    /** buildsys.e:722		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24114;
        concat_list[1] = _58file0_44847;
        concat_list[2] = _58output_dir_42903;
        Concat_N((object_ptr)&_24115, concat_list, 3);
    }
    _fh_46341 = EOpen(_24115, _24032, 0LL);
    DeRefDS(_24115);
    _24115 = NOVALUE;

    /** buildsys.e:724		printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_24118, _24117, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_settings_46338);
    _24119 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24119);
    ((intptr_t*)_2)[1] = _24119;
    _24120 = MAKE_SEQ(_1);
    _24119 = NOVALUE;
    EPrintf(_fh_46341, _24118, _24120);
    DeRefDS(_24118);
    _24118 = NOVALUE;
    DeRefDS(_24120);
    _24120 = NOVALUE;

    /** buildsys.e:725		printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_24122, _24121, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_settings_46338);
    _24123 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24123);
    ((intptr_t*)_2)[1] = _24123;
    _24124 = MAKE_SEQ(_1);
    _24123 = NOVALUE;
    EPrintf(_fh_46341, _24122, _24124);
    DeRefDS(_24122);
    _24122 = NOVALUE;
    DeRefDS(_24124);
    _24124 = NOVALUE;

    /** buildsys.e:726		printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_24126, _24125, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_settings_46338);
    _24127 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24127);
    ((intptr_t*)_2)[1] = _24127;
    _24128 = MAKE_SEQ(_1);
    _24127 = NOVALUE;
    EPrintf(_fh_46341, _24126, _24128);
    DeRefDS(_24126);
    _24126 = NOVALUE;
    DeRefDS(_24128);
    _24128 = NOVALUE;

    /** buildsys.e:728		if compiler_type = COMPILER_GCC then*/
    if (_56compiler_type_45705 != 1LL)
    goto L1; // [98] 125

    /** buildsys.e:729			printf(fh, "LFLAGS = %s" & HOSTNL, { settings[SETUP_LFLAGS] })*/
    Concat((object_ptr)&_24131, _24130, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_settings_46338);
    _24132 = (object)*(((s1_ptr)_2)->base + 4LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24132);
    ((intptr_t*)_2)[1] = _24132;
    _24133 = MAKE_SEQ(_1);
    _24132 = NOVALUE;
    EPrintf(_fh_46341, _24131, _24133);
    DeRefDS(_24131);
    _24131 = NOVALUE;
    DeRefDS(_24133);
    _24133 = NOVALUE;
    goto L2; // [122] 130
L1: 

    /** buildsys.e:731			write_objlink_file()*/
    _56write_objlink_file();
L2: 

    /** buildsys.e:734		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_46341);

    /** buildsys.e:735		puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:737		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45705 != 2LL)
    goto L3; // [146] 575

    /** buildsys.e:738			printf(fh, "\"%s\" : $(%s_OBJECTS) %s" & HOSTNL, { */
    Concat((object_ptr)&_24136, _24135, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24137 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_58file0_44847);
    _24138 = _14upper(_58file0_44847);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24137);
    ((intptr_t*)_2)[1] = _24137;
    ((intptr_t*)_2)[2] = _24138;
    RefDS(_58user_library_42901);
    ((intptr_t*)_2)[3] = _58user_library_42901;
    _24139 = MAKE_SEQ(_1);
    _24138 = NOVALUE;
    _24137 = NOVALUE;
    EPrintf(_fh_46341, _24136, _24139);
    DeRefDS(_24136);
    _24136 = NOVALUE;
    DeRefDS(_24139);
    _24139 = NOVALUE;

    /** buildsys.e:741			printf(fh, "\t$(LINKER) @%s.lnk" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24141, _24140, _46HOSTNL_21929);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44847);
    ((intptr_t*)_2)[1] = _58file0_44847;
    _24142 = MAKE_SEQ(_1);
    EPrintf(_fh_46341, _24141, _24142);
    DeRefDS(_24141);
    _24141 = NOVALUE;
    DeRefDS(_24142);
    _24142 = NOVALUE;

    /** buildsys.e:742			if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24143 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24143)){
            _24144 = SEQ_PTR(_24143)->length;
    }
    else {
        _24144 = 1;
    }
    _24143 = NOVALUE;
    if (_24144 == 0) {
        goto L4; // [215] 277
    }
    _2 = (object)SEQ_PTR(_settings_46338);
    _24146 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24146)){
            _24147 = SEQ_PTR(_24146)->length;
    }
    else {
        _24147 = 1;
    }
    _24146 = NOVALUE;
    if (_24147 == 0)
    {
        _24147 = NOVALUE;
        goto L4; // [227] 277
    }
    else{
        _24147 = NOVALUE;
    }

    /** buildsys.e:743				writef(fh, "\t" & settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46338);
    _24149 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24148) && IS_ATOM(_24149)) {
        Ref(_24149);
        Append(&_24150, _24148, _24149);
    }
    else if (IS_ATOM(_24148) && IS_SEQUENCE(_24149)) {
    }
    else {
        Concat((object_ptr)&_24150, _24148, _24149);
    }
    _24149 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24151 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24152 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24153 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24151);
    ((intptr_t*)_2)[1] = _24151;
    Ref(_24152);
    ((intptr_t*)_2)[2] = _24152;
    Ref(_24153);
    ((intptr_t*)_2)[3] = _24153;
    _24154 = MAKE_SEQ(_1);
    _24153 = NOVALUE;
    _24152 = NOVALUE;
    _24151 = NOVALUE;
    _8writef(_fh_46341, _24150, _24154, 0LL);
    _24150 = NOVALUE;
    _24154 = NOVALUE;
L4: 

    /** buildsys.e:745			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:746			printf(fh, "%s-clean : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24156, _24155, _46HOSTNL_21929);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44847);
    ((intptr_t*)_2)[1] = _58file0_44847;
    _24157 = MAKE_SEQ(_1);
    EPrintf(_fh_46341, _24156, _24157);
    DeRefDS(_24156);
    _24156 = NOVALUE;
    DeRefDS(_24157);
    _24157 = NOVALUE;

    /** buildsys.e:747			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24158 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24158)){
            _24159 = SEQ_PTR(_24158)->length;
    }
    else {
        _24159 = 1;
    }
    _24158 = NOVALUE;
    if (_24159 == 0)
    {
        _24159 = NOVALUE;
        goto L5; // [315] 343
    }
    else{
        _24159 = NOVALUE;
    }

    /** buildsys.e:748				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24161, _24160, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24162 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24162);
    ((intptr_t*)_2)[1] = _24162;
    _24163 = MAKE_SEQ(_1);
    _24162 = NOVALUE;
    EPrintf(_fh_46341, _24161, _24163);
    DeRefDS(_24161);
    _24161 = NOVALUE;
    DeRefDS(_24163);
    _24163 = NOVALUE;
L5: 

    /** buildsys.e:750			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24164 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24164 = 1;
    }
    {
        object _i_46423;
        _i_46423 = 1LL;
L6: 
        if (_i_46423 > _24164){
            goto L7; // [350] 403
        }

        /** buildsys.e:751				if match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24165 = (object)*(((s1_ptr)_2)->base + _i_46423);
        _24166 = e_match_from(_23332, _24165, 1LL);
        _24165 = NOVALUE;
        if (_24166 == 0)
        {
            _24166 = NOVALUE;
            goto L8; // [370] 396
        }
        else{
            _24166 = NOVALUE;
        }

        /** buildsys.e:752					printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_24167, _24160, _46HOSTNL_21929);
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24168 = (object)*(((s1_ptr)_2)->base + _i_46423);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24168);
        ((intptr_t*)_2)[1] = _24168;
        _24169 = MAKE_SEQ(_1);
        _24168 = NOVALUE;
        EPrintf(_fh_46341, _24167, _24169);
        DeRefDS(_24167);
        _24167 = NOVALUE;
        DeRefDS(_24169);
        _24169 = NOVALUE;
L8: 

        /** buildsys.e:754			end for*/
        _i_46423 = _i_46423 + 1LL;
        goto L6; // [398] 357
L7: 
        ;
    }

    /** buildsys.e:755			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:756			printf(fh, "%s-clean-all : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24171, _24170, _46HOSTNL_21929);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44847);
    ((intptr_t*)_2)[1] = _58file0_44847;
    _24172 = MAKE_SEQ(_1);
    EPrintf(_fh_46341, _24171, _24172);
    DeRefDS(_24171);
    _24171 = NOVALUE;
    DeRefDS(_24172);
    _24172 = NOVALUE;

    /** buildsys.e:757			printf(fh, "\tdel \"%s\"" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24173, _24160, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24174 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24174);
    ((intptr_t*)_2)[1] = _24174;
    _24175 = MAKE_SEQ(_1);
    _24174 = NOVALUE;
    EPrintf(_fh_46341, _24173, _24175);
    DeRefDS(_24173);
    _24173 = NOVALUE;
    DeRefDS(_24175);
    _24175 = NOVALUE;

    /** buildsys.e:758			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24176 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24176)){
            _24177 = SEQ_PTR(_24176)->length;
    }
    else {
        _24177 = 1;
    }
    _24176 = NOVALUE;
    if (_24177 == 0)
    {
        _24177 = NOVALUE;
        goto L9; // [465] 493
    }
    else{
        _24177 = NOVALUE;
    }

    /** buildsys.e:759				printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24178, _24160, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24179 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24179);
    ((intptr_t*)_2)[1] = _24179;
    _24180 = MAKE_SEQ(_1);
    _24179 = NOVALUE;
    EPrintf(_fh_46341, _24178, _24180);
    DeRefDS(_24178);
    _24178 = NOVALUE;
    DeRefDS(_24180);
    _24180 = NOVALUE;
L9: 

    /** buildsys.e:761			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24181 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24181 = 1;
    }
    {
        object _i_46456;
        _i_46456 = 1LL;
LA: 
        if (_i_46456 > _24181){
            goto LB; // [500] 536
        }

        /** buildsys.e:762				printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_24182, _24160, _46HOSTNL_21929);
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24183 = (object)*(((s1_ptr)_2)->base + _i_46456);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24183);
        ((intptr_t*)_2)[1] = _24183;
        _24184 = MAKE_SEQ(_1);
        _24183 = NOVALUE;
        EPrintf(_fh_46341, _24182, _24184);
        DeRefDS(_24182);
        _24182 = NOVALUE;
        DeRefDS(_24184);
        _24184 = NOVALUE;

        /** buildsys.e:763			end for*/
        _i_46456 = _i_46456 + 1LL;
        goto LA; // [531] 507
LB: 
        ;
    }

    /** buildsys.e:764			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:765			puts(fh, ".c.obj : .autodepend" & HOSTNL)*/
    Concat((object_ptr)&_24186, _24185, _46HOSTNL_21929);
    EPuts(_fh_46341, _24186); // DJP 
    DeRefDS(_24186);
    _24186 = NOVALUE;

    /** buildsys.e:766			puts(fh, "\t$(CC) $(CFLAGS) $<" & HOSTNL)*/
    Concat((object_ptr)&_24188, _24187, _46HOSTNL_21929);
    EPuts(_fh_46341, _24188); // DJP 
    DeRefDS(_24188);
    _24188 = NOVALUE;

    /** buildsys.e:767			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 
    goto LC; // [572] 933
L3: 

    /** buildsys.e:770			printf(fh, "RUNTIME_LIBRARY=%s\n", { settings[SETUP_RUNTIME_LIBRARY] } )*/
    _2 = (object)SEQ_PTR(_settings_46338);
    _24190 = (object)*(((s1_ptr)_2)->base + 9LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24190);
    ((intptr_t*)_2)[1] = _24190;
    _24191 = MAKE_SEQ(_1);
    _24190 = NOVALUE;
    EPrintf(_fh_46341, _24189, _24191);
    DeRefDS(_24191);
    _24191 = NOVALUE;

    /** buildsys.e:771			printf(fh, "%s: $(%s_OBJECTS) $(RUNTIME_LIBRARY) %s " & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24193, _24192, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24194 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24194);
    _24195 = _56adjust_for_build_file(_24194);
    _24194 = NOVALUE;
    RefDS(_58file0_44847);
    _24196 = _14upper(_58file0_44847);
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24197 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24195;
    ((intptr_t*)_2)[2] = _24196;
    Ref(_24197);
    ((intptr_t*)_2)[3] = _24197;
    _24198 = MAKE_SEQ(_1);
    _24197 = NOVALUE;
    _24196 = NOVALUE;
    _24195 = NOVALUE;
    EPrintf(_fh_46341, _24193, _24198);
    DeRefDS(_24193);
    _24193 = NOVALUE;
    DeRefDS(_24198);
    _24198 = NOVALUE;

    /** buildsys.e:772			if length(rc_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24199 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24199)){
            _24200 = SEQ_PTR(_24199)->length;
    }
    else {
        _24200 = 1;
    }
    _24199 = NOVALUE;
    if (_24200 == 0)
    {
        _24200 = NOVALUE;
        goto LD; // [646] 690
    }
    else{
        _24200 = NOVALUE;
    }

    /** buildsys.e:773				writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46338);
    _24201 = (object)*(((s1_ptr)_2)->base + 8LL);
    {
        object concat_list[3];

        concat_list[0] = _46HOSTNL_21929;
        concat_list[1] = _24201;
        concat_list[2] = _24148;
        Concat_N((object_ptr)&_24202, concat_list, 3);
    }
    _24201 = NOVALUE;
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24203 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24204 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24204);
    Ref(_24203);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24203;
    ((intptr_t *)_2)[2] = _24204;
    _24205 = MAKE_SEQ(_1);
    _24204 = NOVALUE;
    _24203 = NOVALUE;
    _8writef(_fh_46341, _24202, _24205, 0LL);
    _24202 = NOVALUE;
    _24205 = NOVALUE;
LD: 

    /** buildsys.e:775			printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_24207, _24206, _46HOSTNL_21929);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24208 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_58file0_44847);
    _24209 = _14upper(_58file0_44847);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24210 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24210)){
            _24211 = SEQ_PTR(_24210)->length;
    }
    else {
        _24211 = 1;
    }
    _24210 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24212 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24212);
    RefDS(_22186);
    _24213 = _57iif(_24211, _24212, _22186);
    _24211 = NOVALUE;
    _24212 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24208);
    ((intptr_t*)_2)[1] = _24208;
    ((intptr_t*)_2)[2] = _24209;
    ((intptr_t*)_2)[3] = _24213;
    _24214 = MAKE_SEQ(_1);
    _24213 = NOVALUE;
    _24209 = NOVALUE;
    _24208 = NOVALUE;
    EPrintf(_fh_46341, _24207, _24214);
    DeRefDS(_24207);
    _24207 = NOVALUE;
    DeRefDS(_24214);
    _24214 = NOVALUE;

    /** buildsys.e:777			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:778			printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24216, _24215, _46HOSTNL_21929);
    RefDS(_58file0_44847);
    RefDS(_58file0_44847);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44847;
    ((intptr_t *)_2)[2] = _58file0_44847;
    _24217 = MAKE_SEQ(_1);
    EPrintf(_fh_46341, _24216, _24217);
    DeRefDS(_24216);
    _24216 = NOVALUE;
    DeRefDS(_24217);
    _24217 = NOVALUE;

    /** buildsys.e:779			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:780			printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_24219, _24218, _46HOSTNL_21929);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_58file0_44847);
    ((intptr_t*)_2)[1] = _58file0_44847;
    _24220 = MAKE_SEQ(_1);
    EPrintf(_fh_46341, _24219, _24220);
    DeRefDS(_24219);
    _24219 = NOVALUE;
    DeRefDS(_24220);
    _24220 = NOVALUE;

    /** buildsys.e:781			printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_24222, _24221, _46HOSTNL_21929);
    RefDS(_58file0_44847);
    _24223 = _14upper(_58file0_44847);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24224 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24224);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24223;
    ((intptr_t *)_2)[2] = _24224;
    _24225 = MAKE_SEQ(_1);
    _24224 = NOVALUE;
    _24223 = NOVALUE;
    EPrintf(_fh_46341, _24222, _24225);
    DeRefDS(_24222);
    _24222 = NOVALUE;
    DeRefDS(_24225);
    _24225 = NOVALUE;

    /** buildsys.e:782			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:783			printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_24227, _24226, _46HOSTNL_21929);
    RefDS(_58file0_44847);
    RefDS(_58file0_44847);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _58file0_44847;
    ((intptr_t *)_2)[2] = _58file0_44847;
    _24228 = MAKE_SEQ(_1);
    EPrintf(_fh_46341, _24227, _24228);
    DeRefDS(_24227);
    _24227 = NOVALUE;
    DeRefDS(_24228);
    _24228 = NOVALUE;

    /** buildsys.e:784			printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_24230, _24229, _46HOSTNL_21929);
    RefDS(_58file0_44847);
    _24231 = _14upper(_58file0_44847);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24232 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24233 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24231;
    Ref(_24232);
    ((intptr_t*)_2)[2] = _24232;
    Ref(_24233);
    ((intptr_t*)_2)[3] = _24233;
    _24234 = MAKE_SEQ(_1);
    _24233 = NOVALUE;
    _24232 = NOVALUE;
    _24231 = NOVALUE;
    EPrintf(_fh_46341, _24230, _24234);
    DeRefDS(_24230);
    _24230 = NOVALUE;
    DeRefDS(_24234);
    _24234 = NOVALUE;

    /** buildsys.e:785			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 

    /** buildsys.e:786			puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_24236, _24235, _46HOSTNL_21929);
    EPuts(_fh_46341, _24236); // DJP 
    DeRefDS(_24236);
    _24236 = NOVALUE;

    /** buildsys.e:787			puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_24238, _24237, _46HOSTNL_21929);
    EPuts(_fh_46341, _24238); // DJP 
    DeRefDS(_24238);
    _24238 = NOVALUE;

    /** buildsys.e:788			puts(fh, HOSTNL)*/
    EPuts(_fh_46341, _46HOSTNL_21929); // DJP 
LC: 

    /** buildsys.e:791		close(fh)*/
    EClose(_fh_46341);

    /** buildsys.e:792	end procedure*/
    DeRef(_settings_46338);
    _24143 = NOVALUE;
    _24176 = NOVALUE;
    _24146 = NOVALUE;
    _24210 = NOVALUE;
    _24158 = NOVALUE;
    _24199 = NOVALUE;
    return;
    ;
}


void _56write_makefile_partial()
{
    object _settings_46567 = NOVALUE;
    object _fh_46569 = NOVALUE;
    object _24240 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:798		sequence settings = setup_build()*/
    _0 = _settings_46567;
    _settings_46567 = _56setup_build();
    DeRef(_0);

    /** buildsys.e:799		integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        object concat_list[3];

        concat_list[0] = _24114;
        concat_list[1] = _58file0_44847;
        concat_list[2] = _58output_dir_42903;
        Concat_N((object_ptr)&_24240, concat_list, 3);
    }
    _fh_46569 = EOpen(_24240, _24032, 0LL);
    DeRefDS(_24240);
    _24240 = NOVALUE;

    /** buildsys.e:801		write_makefile_srcobj_list(fh)*/
    _56write_makefile_srcobj_list(_fh_46569);

    /** buildsys.e:803		close(fh)*/
    EClose(_fh_46569);

    /** buildsys.e:804	end procedure*/
    DeRefDS(_settings_46567);
    return;
    ;
}


void _56build_direct(object _link_only_46576, object _the_file0_46577)
{
    object _cmd_46583 = NOVALUE;
    object _objs_46584 = NOVALUE;
    object _settings_46585 = NOVALUE;
    object _cwd_46587 = NOVALUE;
    object _status_46590 = NOVALUE;
    object _link_files_46621 = NOVALUE;
    object _pdone_46647 = NOVALUE;
    object _files_46698 = NOVALUE;
    object _31976 = NOVALUE;
    object _31975 = NOVALUE;
    object _31974 = NOVALUE;
    object _31973 = NOVALUE;
    object _31972 = NOVALUE;
    object _31971 = NOVALUE;
    object _31970 = NOVALUE;
    object _24388 = NOVALUE;
    object _24387 = NOVALUE;
    object _24385 = NOVALUE;
    object _24384 = NOVALUE;
    object _24383 = NOVALUE;
    object _24382 = NOVALUE;
    object _24381 = NOVALUE;
    object _24380 = NOVALUE;
    object _24379 = NOVALUE;
    object _24378 = NOVALUE;
    object _24376 = NOVALUE;
    object _24375 = NOVALUE;
    object _24374 = NOVALUE;
    object _24373 = NOVALUE;
    object _24369 = NOVALUE;
    object _24368 = NOVALUE;
    object _24367 = NOVALUE;
    object _24366 = NOVALUE;
    object _24365 = NOVALUE;
    object _24364 = NOVALUE;
    object _24363 = NOVALUE;
    object _24362 = NOVALUE;
    object _24361 = NOVALUE;
    object _24360 = NOVALUE;
    object _24359 = NOVALUE;
    object _24358 = NOVALUE;
    object _24357 = NOVALUE;
    object _24356 = NOVALUE;
    object _24355 = NOVALUE;
    object _24352 = NOVALUE;
    object _24351 = NOVALUE;
    object _24350 = NOVALUE;
    object _24349 = NOVALUE;
    object _24346 = NOVALUE;
    object _24344 = NOVALUE;
    object _24343 = NOVALUE;
    object _24342 = NOVALUE;
    object _24341 = NOVALUE;
    object _24340 = NOVALUE;
    object _24339 = NOVALUE;
    object _24336 = NOVALUE;
    object _24335 = NOVALUE;
    object _24331 = NOVALUE;
    object _24330 = NOVALUE;
    object _24329 = NOVALUE;
    object _24325 = NOVALUE;
    object _24324 = NOVALUE;
    object _24323 = NOVALUE;
    object _24322 = NOVALUE;
    object _24321 = NOVALUE;
    object _24320 = NOVALUE;
    object _24319 = NOVALUE;
    object _24318 = NOVALUE;
    object _24317 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _24314 = NOVALUE;
    object _24312 = NOVALUE;
    object _24311 = NOVALUE;
    object _24310 = NOVALUE;
    object _24309 = NOVALUE;
    object _24308 = NOVALUE;
    object _24306 = NOVALUE;
    object _24305 = NOVALUE;
    object _24304 = NOVALUE;
    object _24303 = NOVALUE;
    object _24302 = NOVALUE;
    object _24300 = NOVALUE;
    object _24298 = NOVALUE;
    object _24297 = NOVALUE;
    object _24296 = NOVALUE;
    object _24295 = NOVALUE;
    object _24293 = NOVALUE;
    object _24292 = NOVALUE;
    object _24291 = NOVALUE;
    object _24288 = NOVALUE;
    object _24287 = NOVALUE;
    object _24286 = NOVALUE;
    object _24285 = NOVALUE;
    object _24284 = NOVALUE;
    object _24283 = NOVALUE;
    object _24282 = NOVALUE;
    object _24281 = NOVALUE;
    object _24280 = NOVALUE;
    object _24279 = NOVALUE;
    object _24276 = NOVALUE;
    object _24275 = NOVALUE;
    object _24272 = NOVALUE;
    object _24270 = NOVALUE;
    object _24269 = NOVALUE;
    object _24268 = NOVALUE;
    object _24267 = NOVALUE;
    object _24264 = NOVALUE;
    object _24263 = NOVALUE;
    object _24262 = NOVALUE;
    object _24261 = NOVALUE;
    object _24259 = NOVALUE;
    object _24258 = NOVALUE;
    object _24257 = NOVALUE;
    object _24256 = NOVALUE;
    object _24255 = NOVALUE;
    object _24252 = NOVALUE;
    object _24246 = NOVALUE;
    object _24242 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:810		if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_46577)){
            _24242 = SEQ_PTR(_the_file0_46577)->length;
    }
    else {
        _24242 = 1;
    }
    if (_24242 == 0)
    {
        _24242 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _24242 = NOVALUE;
    }

    /** buildsys.e:811			file0 = filebase(the_file0)*/
    RefDS(_the_file0_46577);
    _0 = _17filebase(_the_file0_46577);
    DeRef(_58file0_44847);
    _58file0_44847 = _0;
L1: 

    /** buildsys.e:813		sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_22186);
    DeRef(_objs_46584);
    _objs_46584 = _22186;
    _0 = _settings_46585;
    _settings_46585 = _56setup_build();
    DeRef(_0);
    _0 = _cwd_46587;
    _cwd_46587 = _17current_dir();
    DeRef(_0);

    /** buildsys.e:814		integer status*/

    /** buildsys.e:816		ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (object)SEQ_PTR(_settings_46585);
    _24246 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_24246);
    _56ensure_exename(_24246);
    _24246 = NOVALUE;

    /** buildsys.e:818		if not link_only then*/
    if (_link_only_46576 != 0)
    goto L2; // [52] 124

    /** buildsys.e:819			switch compiler_type do*/
    _0 = _56compiler_type_45705;
    switch ( _0 ){ 

        /** buildsys.e:820				case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:821					if not silent then*/
        if (_36silent_21878 != 0)
        goto L3; // [72] 123

        /** buildsys.e:822						ShowMsg(1, COMPILING_WITH_1, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24251);
        ((intptr_t*)_2)[1] = _24251;
        _24252 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 176LL, _24252, 1LL);
        _24252 = NOVALUE;
        goto L3; // [90] 123

        /** buildsys.e:825				case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:826					write_objlink_file()*/
        _56write_objlink_file();

        /** buildsys.e:828					if not silent then*/
        if (_36silent_21878 != 0)
        goto L4; // [104] 122

        /** buildsys.e:829						ShowMsg(1, COMPILING_WITH_1, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24254);
        ((intptr_t*)_2)[1] = _24254;
        _24255 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 176LL, _24255, 1LL);
        _24255 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** buildsys.e:834		if sequence(output_dir) and length(output_dir) > 0 then*/
    _24256 = 1;
    if (_24256 == 0) {
        goto L5; // [131] 159
    }
    if (IS_SEQUENCE(_58output_dir_42903)){
            _24258 = SEQ_PTR(_58output_dir_42903)->length;
    }
    else {
        _24258 = 1;
    }
    _24259 = (_24258 > 0LL);
    _24258 = NOVALUE;
    if (_24259 == 0)
    {
        DeRef(_24259);
        _24259 = NOVALUE;
        goto L5; // [145] 159
    }
    else{
        DeRef(_24259);
        _24259 = NOVALUE;
    }

    /** buildsys.e:835			chdir(output_dir)*/
    RefDS(_58output_dir_42903);
    _31976 = _17chdir(_58output_dir_42903);
    DeRef(_31976);
    _31976 = NOVALUE;
L5: 

    /** buildsys.e:838		sequence link_files = {}*/
    RefDS(_22186);
    DeRef(_link_files_46621);
    _link_files_46621 = _22186;

    /** buildsys.e:840		if not link_only then*/
    if (_link_only_46576 != 0)
    goto L6; // [168] 482

    /** buildsys.e:841			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24261 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24261 = 1;
    }
    {
        object _i_46625;
        _i_46625 = 1LL;
L7: 
        if (_i_46625 > _24261){
            goto L8; // [178] 479
        }

        /** buildsys.e:842				if generated_files[i][$] = 'c' then*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24262 = (object)*(((s1_ptr)_2)->base + _i_46625);
        if (IS_SEQUENCE(_24262)){
                _24263 = SEQ_PTR(_24262)->length;
        }
        else {
            _24263 = 1;
        }
        _2 = (object)SEQ_PTR(_24262);
        _24264 = (object)*(((s1_ptr)_2)->base + _24263);
        _24262 = NOVALUE;
        if (binary_op_a(NOTEQ, _24264, 99LL)){
            _24264 = NOVALUE;
            goto L9; // [200] 438
        }
        _24264 = NOVALUE;

        /** buildsys.e:843					cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (object)SEQ_PTR(_settings_46585);
        _24267 = (object)*(((s1_ptr)_2)->base + 1LL);
        _2 = (object)SEQ_PTR(_settings_46585);
        _24268 = (object)*(((s1_ptr)_2)->base + 2LL);
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24269 = (object)*(((s1_ptr)_2)->base + _i_46625);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24267);
        ((intptr_t*)_2)[1] = _24267;
        Ref(_24268);
        ((intptr_t*)_2)[2] = _24268;
        RefDS(_24269);
        ((intptr_t*)_2)[3] = _24269;
        _24270 = MAKE_SEQ(_1);
        _24269 = NOVALUE;
        _24268 = NOVALUE;
        _24267 = NOVALUE;
        DeRef(_cmd_46583);
        _cmd_46583 = EPrintf(-9999999, _24266, _24270);
        DeRefDS(_24270);
        _24270 = NOVALUE;

        /** buildsys.e:846					link_files = append(link_files, generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24272 = (object)*(((s1_ptr)_2)->base + _i_46625);
        RefDS(_24272);
        Append(&_link_files_46621, _link_files_46621, _24272);
        _24272 = NOVALUE;

        /** buildsys.e:848					if not silent then*/
        if (_36silent_21878 != 0)
        goto LA; // [246] 374

        /** buildsys.e:849						atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_58generated_files_42893)){
                _24275 = SEQ_PTR(_58generated_files_42893)->length;
        }
        else {
            _24275 = 1;
        }
        _24276 = (_i_46625 % _24275) ? NewDouble((eudouble)_i_46625 / _24275) : (_i_46625 / _24275);
        _24275 = NOVALUE;
        DeRef(_pdone_46647);
        if (IS_ATOM_INT(_24276)) {
            {
                int128_t p128 = (int128_t)100LL * (int128_t)_24276;
                if( p128 != (int128_t)(_pdone_46647 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _pdone_46647 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _pdone_46647 = NewDouble((eudouble)100LL * DBL_PTR(_24276)->dbl);
        }
        DeRef(_24276);
        _24276 = NOVALUE;

        /** buildsys.e:850						if not verbose then*/
        if (_36verbose_21881 != 0)
        goto LB; // [268] 358

        /** buildsys.e:853							if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0LL == 0) {
            _24279 = 0;
            goto LC; // [273] 291
        }
        _2 = (object)SEQ_PTR(_58outdated_files_42894);
        _24280 = (object)*(((s1_ptr)_2)->base + _i_46625);
        if (IS_ATOM_INT(_24280)) {
            _24281 = (_24280 == 0LL);
        }
        else {
            _24281 = binary_op(EQUALS, _24280, 0LL);
        }
        _24280 = NOVALUE;
        if (IS_ATOM_INT(_24281))
        _24279 = (_24281 != 0);
        else
        _24279 = DBL_PTR(_24281)->dbl != 0.0;
LC: 
        if (_24279 == 0) {
            goto LD; // [291] 334
        }
        _24283 = (_56force_build_45727 == 0LL);
        if (_24283 == 0)
        {
            DeRef(_24283);
            _24283 = NOVALUE;
            goto LD; // [302] 334
        }
        else{
            DeRef(_24283);
            _24283 = NOVALUE;
        }

        /** buildsys.e:854								ShowMsg(1, SKIPPING__130_2_UPTODATE, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24284 = (object)*(((s1_ptr)_2)->base + _i_46625);
        RefDS(_24284);
        Ref(_pdone_46647);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46647;
        ((intptr_t *)_2)[2] = _24284;
        _24285 = MAKE_SEQ(_1);
        _24284 = NOVALUE;
        _39ShowMsg(1LL, 325LL, _24285, 1LL);
        _24285 = NOVALUE;

        /** buildsys.e:855								continue*/
        DeRef(_pdone_46647);
        _pdone_46647 = NOVALUE;
        goto LE; // [329] 474
        goto LF; // [331] 373
LD: 

        /** buildsys.e:857								ShowMsg(1, COMPILING_130_2, { pdone, generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24286 = (object)*(((s1_ptr)_2)->base + _i_46625);
        RefDS(_24286);
        Ref(_pdone_46647);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46647;
        ((intptr_t *)_2)[2] = _24286;
        _24287 = MAKE_SEQ(_1);
        _24286 = NOVALUE;
        _39ShowMsg(1LL, 163LL, _24287, 1LL);
        _24287 = NOVALUE;
        goto LF; // [355] 373
LB: 

        /** buildsys.e:860							ShowMsg(1, COMPILING_130_2, { pdone, cmd })*/
        RefDS(_cmd_46583);
        Ref(_pdone_46647);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _pdone_46647;
        ((intptr_t *)_2)[2] = _cmd_46583;
        _24288 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 163LL, _24288, 1LL);
        _24288 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_46647);
        _pdone_46647 = NOVALUE;

        /** buildsys.e:865					status = system_exec(cmd, 0)*/
        _status_46590 = system_exec_call(_cmd_46583, 0LL);

        /** buildsys.e:866					if status != 0 then*/
        if (_status_46590 == 0LL)
        goto L10; // [384] 472

        /** buildsys.e:867						ShowMsg(2, COULDNT_COMPILE_FILE_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24291 = (object)*(((s1_ptr)_2)->base + _i_46625);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24291);
        ((intptr_t*)_2)[1] = _24291;
        _24292 = MAKE_SEQ(_1);
        _24291 = NOVALUE;
        _39ShowMsg(2LL, 164LL, _24292, 1LL);
        _24292 = NOVALUE;

        /** buildsys.e:868						ShowMsg(2, STATUS_1_COMMAND_2, { status, cmd })*/
        RefDS(_cmd_46583);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _status_46590;
        ((intptr_t *)_2)[2] = _cmd_46583;
        _24293 = MAKE_SEQ(_1);
        _39ShowMsg(2LL, 165LL, _24293, 1LL);
        _24293 = NOVALUE;

        /** buildsys.e:869						goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [435] 472
L9: 

        /** buildsys.e:871				elsif match(".o", generated_files[i]) then*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24295 = (object)*(((s1_ptr)_2)->base + _i_46625);
        _24296 = e_match_from(_23332, _24295, 1LL);
        _24295 = NOVALUE;
        if (_24296 == 0)
        {
            _24296 = NOVALUE;
            goto L12; // [451] 471
        }
        else{
            _24296 = NOVALUE;
        }

        /** buildsys.e:872					objs &= " " & generated_files[i]*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24297 = (object)*(((s1_ptr)_2)->base + _i_46625);
        Concat((object_ptr)&_24298, _23572, _24297);
        _24297 = NOVALUE;
        Concat((object_ptr)&_objs_46584, _objs_46584, _24298);
        DeRefDS(_24298);
        _24298 = NOVALUE;
L12: 
L10: 

        /** buildsys.e:874			end for*/
LE: 
        _i_46625 = _i_46625 + 1LL;
        goto L7; // [474] 185
L8: 
        ;
    }
    goto L13; // [479] 541
L6: 

    /** buildsys.e:876			object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_24300, _58file0_44847, _23782);
    _0 = _files_46698;
    _files_46698 = _8read_lines(_24300);
    DeRef(_0);
    _24300 = NOVALUE;

    /** buildsys.e:877			for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_46698)){
            _24302 = SEQ_PTR(_files_46698)->length;
    }
    else {
        _24302 = 1;
    }
    {
        object _i_46704;
        _i_46704 = 1LL;
L14: 
        if (_i_46704 > _24302){
            goto L15; // [499] 538
        }

        /** buildsys.e:878				objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (object)SEQ_PTR(_files_46698);
        _24303 = (object)*(((s1_ptr)_2)->base + _i_46704);
        Ref(_24303);
        _24304 = _17filebase(_24303);
        _24303 = NOVALUE;
        _2 = (object)SEQ_PTR(_settings_46585);
        _24305 = (object)*(((s1_ptr)_2)->base + 5LL);
        {
            object concat_list[4];

            concat_list[0] = _24305;
            concat_list[1] = _23371;
            concat_list[2] = _24304;
            concat_list[3] = _23572;
            Concat_N((object_ptr)&_24306, concat_list, 4);
        }
        _24305 = NOVALUE;
        DeRef(_24304);
        _24304 = NOVALUE;
        Concat((object_ptr)&_objs_46584, _objs_46584, _24306);
        DeRefDS(_24306);
        _24306 = NOVALUE;

        /** buildsys.e:879			end for*/
        _i_46704 = _i_46704 + 1LL;
        goto L14; // [533] 506
L15: 
        ;
    }
    DeRef(_files_46698);
    _files_46698 = NOVALUE;
L13: 

    /** buildsys.e:882		if keep and not link_only and length(link_files) then*/
    if (_58keep_42896 == 0) {
        _24308 = 0;
        goto L16; // [545] 556
    }
    _24309 = (_link_only_46576 == 0);
    _24308 = (_24309 != 0);
L16: 
    if (_24308 == 0) {
        goto L17; // [556] 585
    }
    if (IS_SEQUENCE(_link_files_46621)){
            _24311 = SEQ_PTR(_link_files_46621)->length;
    }
    else {
        _24311 = 1;
    }
    if (_24311 == 0)
    {
        _24311 = NOVALUE;
        goto L17; // [564] 585
    }
    else{
        _24311 = NOVALUE;
    }

    /** buildsys.e:883			write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_24312, _58file0_44847, _23782);
    RefDS(_link_files_46621);
    _31975 = _8write_lines(_24312, _link_files_46621);
    _24312 = NOVALUE;
    DeRef(_31975);
    _31975 = NOVALUE;
    goto L18; // [582] 609
L17: 

    /** buildsys.e:884		elsif keep = 0 then*/
    if (_58keep_42896 != 0LL)
    goto L19; // [589] 608

    /** buildsys.e:886			delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_24314, _58file0_44847, _23782);
    _31974 = _17delete_file(_24314);
    _24314 = NOVALUE;
    DeRef(_31974);
    _31974 = NOVALUE;
L19: 
L18: 

    /** buildsys.e:890		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24315 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24315)){
            _24316 = SEQ_PTR(_24315)->length;
    }
    else {
        _24316 = 1;
    }
    _24315 = NOVALUE;
    if (_24316 == 0) {
        _24317 = 0;
        goto L1A; // [622] 637
    }
    _2 = (object)SEQ_PTR(_settings_46585);
    _24318 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24318)){
            _24319 = SEQ_PTR(_24318)->length;
    }
    else {
        _24319 = 1;
    }
    _24318 = NOVALUE;
    _24317 = (_24319 != 0);
L1A: 
    if (_24317 == 0) {
        goto L1B; // [637] 742
    }
    _24321 = (_56compiler_type_45705 == 1LL);
    if (_24321 == 0)
    {
        DeRef(_24321);
        _24321 = NOVALUE;
        goto L1B; // [648] 742
    }
    else{
        DeRef(_24321);
        _24321 = NOVALUE;
    }

    /** buildsys.e:891			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46585);
    _24322 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24323 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24324 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24324);
    Ref(_24323);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24323;
    ((intptr_t *)_2)[2] = _24324;
    _24325 = MAKE_SEQ(_1);
    _24324 = NOVALUE;
    _24323 = NOVALUE;
    Ref(_24322);
    _0 = _cmd_46583;
    _cmd_46583 = _14format(_24322, _24325);
    DeRef(_0);
    _24322 = NOVALUE;
    _24325 = NOVALUE;

    /** buildsys.e:892			status = system_exec(cmd, 0)*/
    _status_46590 = system_exec_call(_cmd_46583, 0LL);

    /** buildsys.e:893			if status != 0 then*/
    if (_status_46590 == 0LL)
    goto L1C; // [692] 741

    /** buildsys.e:894				ShowMsg(2, UNABLE_TO_COMPILE_RESOURCE_FILE_1, { rc_file[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24329 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24329);
    ((intptr_t*)_2)[1] = _24329;
    _24330 = MAKE_SEQ(_1);
    _24329 = NOVALUE;
    _39ShowMsg(2LL, 350LL, _24330, 1LL);
    _24330 = NOVALUE;

    /** buildsys.e:895				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46583);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46590;
    ((intptr_t *)_2)[2] = _cmd_46583;
    _24331 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 169LL, _24331, 1LL);
    _24331 = NOVALUE;

    /** buildsys.e:897				goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** buildsys.e:901		switch compiler_type do*/
    _0 = _56compiler_type_45705;
    switch ( _0 ){ 

        /** buildsys.e:902			case COMPILER_WATCOM then*/
        case 2:

        /** buildsys.e:903				cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (object)SEQ_PTR(_settings_46585);
        _24335 = (object)*(((s1_ptr)_2)->base + 3LL);
        RefDS(_58file0_44847);
        Ref(_24335);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _24335;
        ((intptr_t *)_2)[2] = _58file0_44847;
        _24336 = MAKE_SEQ(_1);
        _24335 = NOVALUE;
        DeRef(_cmd_46583);
        _cmd_46583 = EPrintf(-9999999, _24334, _24336);
        DeRefDS(_24336);
        _24336 = NOVALUE;
        goto L1D; // [771] 848

        /** buildsys.e:905			case COMPILER_GCC then*/
        case 1:

        /** buildsys.e:906				cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (object)SEQ_PTR(_settings_46585);
        _24339 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_56exe_name_45708);
        _24340 = (object)*(((s1_ptr)_2)->base + 11LL);
        Ref(_24340);
        _24341 = _56adjust_for_build_file(_24340);
        _24340 = NOVALUE;
        _2 = (object)SEQ_PTR(_56res_file_45720);
        _24342 = (object)*(((s1_ptr)_2)->base + 11LL);
        _2 = (object)SEQ_PTR(_settings_46585);
        _24343 = (object)*(((s1_ptr)_2)->base + 4LL);
        _1 = NewS1(5);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_24339);
        ((intptr_t*)_2)[1] = _24339;
        ((intptr_t*)_2)[2] = _24341;
        RefDS(_objs_46584);
        ((intptr_t*)_2)[3] = _objs_46584;
        Ref(_24342);
        ((intptr_t*)_2)[4] = _24342;
        Ref(_24343);
        ((intptr_t*)_2)[5] = _24343;
        _24344 = MAKE_SEQ(_1);
        _24343 = NOVALUE;
        _24342 = NOVALUE;
        _24341 = NOVALUE;
        _24339 = NOVALUE;
        DeRef(_cmd_46583);
        _cmd_46583 = EPrintf(-9999999, _24338, _24344);
        DeRefDS(_24344);
        _24344 = NOVALUE;
        goto L1D; // [819] 848

        /** buildsys.e:915			case else*/
        default:

        /** buildsys.e:916				ShowMsg(2, UNKNOWN_COMPILER_TYPE_1, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _56compiler_type_45705;
        _24346 = MAKE_SEQ(_1);
        _39ShowMsg(2LL, 167LL, _24346, 1LL);
        _24346 = NOVALUE;

        /** buildsys.e:918				goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** buildsys.e:921		if not silent then*/
    if (_36silent_21878 != 0)
    goto L1E; // [852] 910

    /** buildsys.e:922			if not verbose then*/
    if (_36verbose_21881 != 0)
    goto L1F; // [859] 892

    /** buildsys.e:923				ShowMsg(1, LINKING_100_1, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24349 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24349);
    RefDS(_22186);
    _24350 = _17abbreviate_path(_24349, _22186);
    _24349 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24350;
    _24351 = MAKE_SEQ(_1);
    _24350 = NOVALUE;
    _39ShowMsg(1LL, 166LL, _24351, 1LL);
    _24351 = NOVALUE;
    goto L20; // [889] 909
L1F: 

    /** buildsys.e:925				ShowMsg(1, LINKING_100_1, { cmd })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_cmd_46583);
    ((intptr_t*)_2)[1] = _cmd_46583;
    _24352 = MAKE_SEQ(_1);
    _39ShowMsg(1LL, 166LL, _24352, 1LL);
    _24352 = NOVALUE;
L20: 
L1E: 

    /** buildsys.e:929		status = system_exec(cmd, 0)*/
    _status_46590 = system_exec_call(_cmd_46583, 0LL);

    /** buildsys.e:930		if status != 0 then*/
    if (_status_46590 == 0LL)
    goto L21; // [920] 967

    /** buildsys.e:931			ShowMsg(2, UNABLE_TO_LINK_1, { exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24355 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24355);
    ((intptr_t*)_2)[1] = _24355;
    _24356 = MAKE_SEQ(_1);
    _24355 = NOVALUE;
    _39ShowMsg(2LL, 168LL, _24356, 1LL);
    _24356 = NOVALUE;

    /** buildsys.e:932			ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46583);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46590;
    ((intptr_t *)_2)[2] = _cmd_46583;
    _24357 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 169LL, _24357, 1LL);
    _24357 = NOVALUE;

    /** buildsys.e:934			goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** buildsys.e:938		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24358 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24358)){
            _24359 = SEQ_PTR(_24358)->length;
    }
    else {
        _24359 = 1;
    }
    _24358 = NOVALUE;
    if (_24359 == 0) {
        _24360 = 0;
        goto L22; // [980] 995
    }
    _2 = (object)SEQ_PTR(_settings_46585);
    _24361 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (IS_SEQUENCE(_24361)){
            _24362 = SEQ_PTR(_24361)->length;
    }
    else {
        _24362 = 1;
    }
    _24361 = NOVALUE;
    _24360 = (_24362 != 0);
L22: 
    if (_24360 == 0) {
        goto L23; // [995] 1118
    }
    _24364 = (_56compiler_type_45705 == 2LL);
    if (_24364 == 0)
    {
        DeRef(_24364);
        _24364 = NOVALUE;
        goto L23; // [1006] 1118
    }
    else{
        DeRef(_24364);
        _24364 = NOVALUE;
    }

    /** buildsys.e:939			cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (object)SEQ_PTR(_settings_46585);
    _24365 = (object)*(((s1_ptr)_2)->base + 8LL);
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24366 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24367 = (object)*(((s1_ptr)_2)->base + 11LL);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24368 = (object)*(((s1_ptr)_2)->base + 11LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24366);
    ((intptr_t*)_2)[1] = _24366;
    Ref(_24367);
    ((intptr_t*)_2)[2] = _24367;
    Ref(_24368);
    ((intptr_t*)_2)[3] = _24368;
    _24369 = MAKE_SEQ(_1);
    _24368 = NOVALUE;
    _24367 = NOVALUE;
    _24366 = NOVALUE;
    Ref(_24365);
    _0 = _cmd_46583;
    _cmd_46583 = _14format(_24365, _24369);
    DeRef(_0);
    _24365 = NOVALUE;
    _24369 = NOVALUE;

    /** buildsys.e:940			status = system_exec(cmd, 0)*/
    _status_46590 = system_exec_call(_cmd_46583, 0LL);

    /** buildsys.e:941			if status != 0 then*/
    if (_status_46590 == 0LL)
    goto L24; // [1060] 1117

    /** buildsys.e:942				ShowMsg(2, UNABLE_TO_LINK_RESOURCE_FILE_1_INTO_EXECUTABLE_2, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _24373 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _24374 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_24374);
    Ref(_24373);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24373;
    ((intptr_t *)_2)[2] = _24374;
    _24375 = MAKE_SEQ(_1);
    _24374 = NOVALUE;
    _24373 = NOVALUE;
    _39ShowMsg(2LL, 187LL, _24375, 1LL);
    _24375 = NOVALUE;

    /** buildsys.e:943				ShowMsg(2, STATUS_1_COMMAND_2_A, { status, cmd })*/
    RefDS(_cmd_46583);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _status_46590;
    ((intptr_t *)_2)[2] = _cmd_46583;
    _24376 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 169LL, _24376, 1LL);
    _24376 = NOVALUE;

    /** buildsys.e:945				goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** buildsys.e:949	label "build_direct_cleanup"*/
G11:

    /** buildsys.e:950		if keep = 0 then*/
    if (_58keep_42896 != 0LL)
    goto L25; // [1126] 1277

    /** buildsys.e:951			for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_58generated_files_42893)){
            _24378 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _24378 = 1;
    }
    {
        object _i_46840;
        _i_46840 = 1LL;
L26: 
        if (_i_46840 > _24378){
            goto L27; // [1137] 1193
        }

        /** buildsys.e:952				if verbose then*/
        if (_36verbose_21881 == 0)
        {
            goto L28; // [1148] 1172
        }
        else{
        }

        /** buildsys.e:953					ShowMsg(1, DELETING_1, { generated_files[i] })*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24379 = (object)*(((s1_ptr)_2)->base + _i_46840);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_24379);
        ((intptr_t*)_2)[1] = _24379;
        _24380 = MAKE_SEQ(_1);
        _24379 = NOVALUE;
        _39ShowMsg(1LL, 347LL, _24380, 1LL);
        _24380 = NOVALUE;
L28: 

        /** buildsys.e:955				delete_file(generated_files[i])*/
        _2 = (object)SEQ_PTR(_58generated_files_42893);
        _24381 = (object)*(((s1_ptr)_2)->base + _i_46840);
        RefDS(_24381);
        _31973 = _17delete_file(_24381);
        _24381 = NOVALUE;
        DeRef(_31973);
        _31973 = NOVALUE;

        /** buildsys.e:956			end for*/
        _i_46840 = _i_46840 + 1LL;
        goto L26; // [1188] 1144
L27: 
        ;
    }

    /** buildsys.e:958			if length(res_file[D_ALTNAME]) then*/
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24382 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (IS_SEQUENCE(_24382)){
            _24383 = SEQ_PTR(_24382)->length;
    }
    else {
        _24383 = 1;
    }
    _24382 = NOVALUE;
    if (_24383 == 0)
    {
        _24383 = NOVALUE;
        goto L29; // [1206] 1226
    }
    else{
        _24383 = NOVALUE;
    }

    /** buildsys.e:959				delete_file(res_file[D_ALTNAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _24384 = (object)*(((s1_ptr)_2)->base + 11LL);
    Ref(_24384);
    _31972 = _17delete_file(_24384);
    _24384 = NOVALUE;
    DeRef(_31972);
    _31972 = NOVALUE;
L29: 

    /** buildsys.e:962			if remove_output_dir then*/
    if (_56remove_output_dir_45728 == 0)
    {
        goto L2A; // [1230] 1276
    }
    else{
    }

    /** buildsys.e:963				chdir(cwd)*/
    RefDS(_cwd_46587);
    _31971 = _17chdir(_cwd_46587);
    DeRef(_31971);
    _31971 = NOVALUE;

    /** buildsys.e:966				if not remove_directory(output_dir) then*/
    RefDS(_58output_dir_42903);
    _24385 = _17remove_directory(_58output_dir_42903, 0LL);
    if (IS_ATOM_INT(_24385)) {
        if (_24385 != 0){
            DeRef(_24385);
            _24385 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    else {
        if (DBL_PTR(_24385)->dbl != 0.0){
            DeRef(_24385);
            _24385 = NOVALUE;
            goto L2B; // [1250] 1275
        }
    }
    DeRef(_24385);
    _24385 = NOVALUE;

    /** buildsys.e:967					ShowMsg(2, COULD_NOT_REMOVE_DIRECTORY_1, { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42903);
    RefDS(_22186);
    _24387 = _17abbreviate_path(_58output_dir_42903, _22186);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24387;
    _24388 = MAKE_SEQ(_1);
    _24387 = NOVALUE;
    _39ShowMsg(2LL, 194LL, _24388, 1LL);
    _24388 = NOVALUE;
L2B: 
L2A: 
L25: 

    /** buildsys.e:972		chdir(cwd)*/
    RefDS(_cwd_46587);
    _31970 = _17chdir(_cwd_46587);
    DeRef(_31970);
    _31970 = NOVALUE;

    /** buildsys.e:973	end procedure*/
    DeRefDS(_the_file0_46577);
    DeRef(_cmd_46583);
    DeRef(_objs_46584);
    DeRef(_settings_46585);
    DeRefDS(_cwd_46587);
    DeRef(_link_files_46621);
    _24361 = NOVALUE;
    _24315 = NOVALUE;
    DeRef(_24309);
    _24309 = NOVALUE;
    _24358 = NOVALUE;
    DeRef(_24281);
    _24281 = NOVALUE;
    _24318 = NOVALUE;
    _24382 = NOVALUE;
    return;
    ;
}


void _56write_buildfile()
{
    object _make_command_46882 = NOVALUE;
    object _settings_46927 = NOVALUE;
    object _24411 = NOVALUE;
    object _24410 = NOVALUE;
    object _24406 = NOVALUE;
    object _24405 = NOVALUE;
    object _24404 = NOVALUE;
    object _24402 = NOVALUE;
    object _24401 = NOVALUE;
    object _24400 = NOVALUE;
    object _24399 = NOVALUE;
    object _24398 = NOVALUE;
    object _24397 = NOVALUE;
    object _24396 = NOVALUE;
    object _24395 = NOVALUE;
    object _0, _1, _2;
    

    /** buildsys.e:982		switch build_system_type do*/
    _0 = _56build_system_type_45701;
    switch ( _0 ){ 

        /** buildsys.e:983			case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** buildsys.e:984				write_makefile_full()*/
        _56write_makefile_full();

        /** buildsys.e:986				if not silent then*/
        if (_36silent_21878 != 0)
        goto L1; // [22] 142

        /** buildsys.e:987					sequence make_command*/

        /** buildsys.e:988					if compiler_type = COMPILER_WATCOM then*/
        if (_56compiler_type_45705 != 2LL)
        goto L2; // [31] 45

        /** buildsys.e:989						make_command = "wmake /f "*/
        RefDS(_24393);
        DeRefi(_make_command_46882);
        _make_command_46882 = _24393;
        goto L3; // [42] 53
L2: 

        /** buildsys.e:991						make_command = "make -f "*/
        RefDS(_24394);
        DeRefi(_make_command_46882);
        _make_command_46882 = _24394;
L3: 

        /** buildsys.e:994					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24395 = _36cfile_count_21841 + 2LL;
        if ((object)((uintptr_t)_24395 + (uintptr_t)HIGH_BITS) >= 0){
            _24395 = NewDouble((eudouble)_24395);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24395;
        _24396 = MAKE_SEQ(_1);
        _24395 = NOVALUE;
        _39ShowMsg(1LL, 170LL, _24396, 1LL);
        _24396 = NOVALUE;

        /** buildsys.e:996					if sequence(output_dir) and length(output_dir) > 0 then*/
        _24397 = 1;
        if (_24397 == 0) {
            goto L4; // [80] 122
        }
        if (IS_SEQUENCE(_58output_dir_42903)){
                _24399 = SEQ_PTR(_58output_dir_42903)->length;
        }
        else {
            _24399 = 1;
        }
        _24400 = (_24399 > 0LL);
        _24399 = NOVALUE;
        if (_24400 == 0)
        {
            DeRef(_24400);
            _24400 = NOVALUE;
            goto L4; // [94] 122
        }
        else{
            DeRef(_24400);
            _24400 = NOVALUE;
        }

        /** buildsys.e:997						ShowMsg(1, TO_BUILD_YOUR_PROJECT_CHANGE_DIRECTORY_TO_1_AND_TYPE_23MAK, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58output_dir_42903);
        ((intptr_t*)_2)[1] = _58output_dir_42903;
        RefDS(_make_command_46882);
        ((intptr_t*)_2)[2] = _make_command_46882;
        RefDS(_58file0_44847);
        ((intptr_t*)_2)[3] = _58file0_44847;
        _24401 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 174LL, _24401, 1LL);
        _24401 = NOVALUE;
        goto L5; // [119] 141
L4: 

        /** buildsys.e:999						ShowMsg(1, TO_BUILD_YOUR_PROJECT_TYPE_12MAK, { make_command, file0 })*/
        RefDS(_58file0_44847);
        RefDS(_make_command_46882);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _make_command_46882;
        ((intptr_t *)_2)[2] = _58file0_44847;
        _24402 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 172LL, _24402, 1LL);
        _24402 = NOVALUE;
L5: 
L1: 
        DeRefi(_make_command_46882);
        _make_command_46882 = NOVALUE;
        goto L6; // [144] 277

        /** buildsys.e:1003			case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** buildsys.e:1004				write_makefile_partial()*/
        _56write_makefile_partial();

        /** buildsys.e:1006				if not silent then*/
        if (_36silent_21878 != 0)
        goto L6; // [158] 277

        /** buildsys.e:1007					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24404 = _36cfile_count_21841 + 2LL;
        if ((object)((uintptr_t)_24404 + (uintptr_t)HIGH_BITS) >= 0){
            _24404 = NewDouble((eudouble)_24404);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24404;
        _24405 = MAKE_SEQ(_1);
        _24404 = NOVALUE;
        _39ShowMsg(1LL, 170LL, _24405, 1LL);
        _24405 = NOVALUE;

        /** buildsys.e:1008					ShowMsg(1, TO_BUILD_YOUR_PROJECT_INCLUDE_1MAK_INTO_A_LARGER_MAKEFILE_PROJECT, { file0 })*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_58file0_44847);
        ((intptr_t*)_2)[1] = _58file0_44847;
        _24406 = MAKE_SEQ(_1);
        _39ShowMsg(1LL, 173LL, _24406, 1LL);
        _24406 = NOVALUE;
        goto L6; // [198] 277

        /** buildsys.e:1011			case BUILD_DIRECT then*/
        case 3:

        /** buildsys.e:1012				build_direct()*/
        RefDS(_22186);
        _56build_direct(0LL, _22186);

        /** buildsys.e:1014				if not silent then*/
        if (_36silent_21878 != 0)
        goto L7; // [214] 225

        /** buildsys.e:1015					sequence settings = setup_build()*/
        _0 = _settings_46927;
        _settings_46927 = _56setup_build();
        DeRef(_0);
L7: 
        DeRef(_settings_46927);
        _settings_46927 = NOVALUE;
        goto L6; // [227] 277

        /** buildsys.e:1019			case BUILD_NONE then*/
        case 0:

        /** buildsys.e:1020				if not silent then*/
        if (_36silent_21878 != 0)
        goto L6; // [237] 277

        /** buildsys.e:1021					ShowMsg(1, MSG_1C_FILES_WERE_CREATED, { cfile_count + 2 })*/
        _24410 = _36cfile_count_21841 + 2LL;
        if ((object)((uintptr_t)_24410 + (uintptr_t)HIGH_BITS) >= 0){
            _24410 = NewDouble((eudouble)_24410);
        }
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _24410;
        _24411 = MAKE_SEQ(_1);
        _24410 = NOVALUE;
        _39ShowMsg(1LL, 170LL, _24411, 1LL);
        _24411 = NOVALUE;
        goto L6; // [261] 277

        /** buildsys.e:1026			case else*/
        default:

        /** buildsys.e:1027				CompileErr(UNKNOWN_BUILD_FILE_TYPE)*/
        RefDS(_22186);
        _50CompileErr(151LL, _22186, 0LL);
    ;}L6: 

    /** buildsys.e:1029	end procedure*/
    return;
    ;
}



// 0x85BAF8AB
