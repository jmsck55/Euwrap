// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _52new(object _pattern_22482, object _options_22483)
{
    object _12705 = NOVALUE;
    object _12704 = NOVALUE;
    object _12702 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:723		if sequence(options) then */
    _12702 = 0;
    if (_12702 == 0)
    {
        _12702 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12702 = NOVALUE;
    }

    /** regex.e:724			options = math:or_all(options) */
    _options_22483 = _20or_all(_options_22483);
L1: 

    /** regex.e:730		return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_22483);
    Ref(_pattern_22482);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pattern_22482;
    ((intptr_t *)_2)[2] = _options_22483;
    _12704 = MAKE_SEQ(_1);
    _12705 = machine(68LL, _12704);
    DeRefDS(_12704);
    _12704 = NOVALUE;
    DeRefi(_pattern_22482);
    DeRef(_options_22483);
    return _12705;
    ;
}


object _52get_ovector_size(object _ex_22502, object _maxsize_22503)
{
    object _m_22504 = NOVALUE;
    object _12713 = NOVALUE;
    object _12710 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:804		integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22502);
    ((intptr_t*)_2)[1] = _ex_22502;
    _12710 = MAKE_SEQ(_1);
    _m_22504 = machine(97LL, _12710);
    DeRefDS(_12710);
    _12710 = NOVALUE;
    if (!IS_ATOM_INT(_m_22504)) {
        _1 = (object)(DBL_PTR(_m_22504)->dbl);
        DeRefDS(_m_22504);
        _m_22504 = _1;
    }

    /** regex.e:805		if (m > maxsize) then*/
    if (_m_22504 <= 30LL)
    goto L1; // [17] 28

    /** regex.e:806			return maxsize*/
    DeRef(_ex_22502);
    return 30LL;
L1: 

    /** regex.e:809		return m+1*/
    _12713 = _m_22504 + 1;
    if (_12713 > MAXINT){
        _12713 = NewDouble((eudouble)_12713);
    }
    DeRef(_ex_22502);
    return _12713;
    ;
}


object _52find(object _re_22512, object _haystack_22514, object _from_22515, object _options_22516, object _size_22517)
{
    object _12720 = NOVALUE;
    object _12719 = NOVALUE;
    object _12718 = NOVALUE;
    object _12715 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22517)) {
        _1 = (object)(DBL_PTR(_size_22517)->dbl);
        DeRefDS(_size_22517);
        _size_22517 = _1;
    }

    /** regex.e:872		if sequence(options) then */
    _12715 = IS_SEQUENCE(_options_22516);
    if (_12715 == 0)
    {
        _12715 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12715 = NOVALUE;
    }

    /** regex.e:873			options = math:or_all(options) */
    Ref(_options_22516);
    _0 = _options_22516;
    _options_22516 = _20or_all(_options_22516);
    DeRef(_0);
L1: 

    /** regex.e:876		if size < 0 then*/
    if (_size_22517 >= 0LL)
    goto L2; // [22] 32

    /** regex.e:877			size = 0*/
    _size_22517 = 0LL;
L2: 

    /** regex.e:880		return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22514)){
            _12718 = SEQ_PTR(_haystack_22514)->length;
    }
    else {
        _12718 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22512);
    ((intptr_t*)_2)[1] = _re_22512;
    Ref(_haystack_22514);
    ((intptr_t*)_2)[2] = _haystack_22514;
    ((intptr_t*)_2)[3] = _12718;
    Ref(_options_22516);
    ((intptr_t*)_2)[4] = _options_22516;
    ((intptr_t*)_2)[5] = _from_22515;
    ((intptr_t*)_2)[6] = _size_22517;
    _12719 = MAKE_SEQ(_1);
    _12718 = NOVALUE;
    _12720 = machine(70LL, _12719);
    DeRefDS(_12719);
    _12719 = NOVALUE;
    DeRef(_re_22512);
    DeRef(_haystack_22514);
    DeRef(_options_22516);
    return _12720;
    ;
}


object _52find_all(object _re_22529, object _haystack_22531, object _from_22532, object _options_22533, object _size_22534)
{
    object _result_22541 = NOVALUE;
    object _results_22542 = NOVALUE;
    object _pHaystack_22543 = NOVALUE;
    object _12733 = NOVALUE;
    object _12732 = NOVALUE;
    object _12730 = NOVALUE;
    object _12728 = NOVALUE;
    object _12726 = NOVALUE;
    object _12722 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22534)) {
        _1 = (object)(DBL_PTR(_size_22534)->dbl);
        DeRefDS(_size_22534);
        _size_22534 = _1;
    }

    /** regex.e:917		if sequence(options) then */
    _12722 = IS_SEQUENCE(_options_22533);
    if (_12722 == 0)
    {
        _12722 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12722 = NOVALUE;
    }

    /** regex.e:918			options = math:or_all(options) */
    Ref(_options_22533);
    _0 = _options_22533;
    _options_22533 = _20or_all(_options_22533);
    DeRef(_0);
L1: 

    /** regex.e:921		if size < 0 then*/
    if (_size_22534 >= 0LL)
    goto L2; // [22] 32

    /** regex.e:922			size = 0*/
    _size_22534 = 0LL;
L2: 

    /** regex.e:925		object result*/

    /** regex.e:926		sequence results = {}*/
    RefDS(_5);
    DeRef(_results_22542);
    _results_22542 = _5;

    /** regex.e:927		atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_22531);
    _0 = _pHaystack_22543;
    _pHaystack_22543 = _9allocate_string(_haystack_22531, 0LL);
    DeRef(_0);

    /** regex.e:928		while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _12726 = IS_SEQUENCE(_result_22541);
    if (_12726 == 0)
    {
        _12726 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _12726 = NOVALUE;
    }

    /** regex.e:929			results = append(results, result)*/
    Ref(_result_22541);
    Append(&_results_22542, _results_22542, _result_22541);

    /** regex.e:930			from = math:max(result) + 1*/
    Ref(_result_22541);
    _12728 = _20max(_result_22541);
    if (IS_ATOM_INT(_12728)) {
        _from_22532 = _12728 + 1;
    }
    else
    { // coercing _from_22532 to an integer 1
        _from_22532 = 1+(object)(DBL_PTR(_12728)->dbl);
        if( !IS_ATOM_INT(_from_22532) ){
            _from_22532 = (object)DBL_PTR(_from_22532)->dbl;
        }
    }
    DeRef(_12728);
    _12728 = NOVALUE;

    /** regex.e:932			if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_22531)){
            _12730 = SEQ_PTR(_haystack_22531)->length;
    }
    else {
        _12730 = 1;
    }
    if (_from_22532 <= _12730)
    goto L6; // [82] 91

    /** regex.e:933				exit*/
    goto L5; // [88] 117
L6: 

    /** regex.e:935		entry*/
L3: 

    /** regex.e:936			result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22531)){
            _12732 = SEQ_PTR(_haystack_22531)->length;
    }
    else {
        _12732 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22529);
    ((intptr_t*)_2)[1] = _re_22529;
    Ref(_pHaystack_22543);
    ((intptr_t*)_2)[2] = _pHaystack_22543;
    ((intptr_t*)_2)[3] = _12732;
    Ref(_options_22533);
    ((intptr_t*)_2)[4] = _options_22533;
    ((intptr_t*)_2)[5] = _from_22532;
    ((intptr_t*)_2)[6] = _size_22534;
    _12733 = MAKE_SEQ(_1);
    _12732 = NOVALUE;
    DeRef(_result_22541);
    _result_22541 = machine(70LL, _12733);
    DeRefDS(_12733);
    _12733 = NOVALUE;

    /** regex.e:937		end while*/
    goto L4; // [114] 53
L5: 

    /** regex.e:939		machine:free(pHaystack)*/
    Ref(_pHaystack_22543);
    _9free(_pHaystack_22543);

    /** regex.e:941		return results*/
    DeRef(_re_22529);
    DeRef(_haystack_22531);
    DeRef(_options_22533);
    DeRef(_result_22541);
    DeRef(_pHaystack_22543);
    return _results_22542;
    ;
}


object _52matches(object _re_22592, object _haystack_22594, object _from_22595, object _options_22596)
{
    object _str_offsets_22600 = NOVALUE;
    object _match_data_22602 = NOVALUE;
    object _tmp_22612 = NOVALUE;
    object _12774 = NOVALUE;
    object _12773 = NOVALUE;
    object _12772 = NOVALUE;
    object _12771 = NOVALUE;
    object _12770 = NOVALUE;
    object _12768 = NOVALUE;
    object _12767 = NOVALUE;
    object _12766 = NOVALUE;
    object _12765 = NOVALUE;
    object _12763 = NOVALUE;
    object _12762 = NOVALUE;
    object _12761 = NOVALUE;
    object _12760 = NOVALUE;
    object _12758 = NOVALUE;
    object _12757 = NOVALUE;
    object _12756 = NOVALUE;
    object _12753 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1038		if sequence(options) then */
    _12753 = 0;
    if (_12753 == 0)
    {
        _12753 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12753 = NOVALUE;
    }

    /** regex.e:1039			options = math:or_all(options) */
    _options_22596 = _20or_all(0LL);
L1: 

    /** regex.e:1041		integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_22596)) {
        {uintptr_t tu;
             tu = (uintptr_t)201326592LL & (uintptr_t)_options_22596;
             _str_offsets_22600 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_22600 = binary_op(AND_BITS, 201326592LL, _options_22596);
    }
    if (!IS_ATOM_INT(_str_offsets_22600)) {
        _1 = (object)(DBL_PTR(_str_offsets_22600)->dbl);
        DeRefDS(_str_offsets_22600);
        _str_offsets_22600 = _1;
    }

    /** regex.e:1042		object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12756 = not_bits(201326592LL);
    if (IS_ATOM_INT(_options_22596) && IS_ATOM_INT(_12756)) {
        {uintptr_t tu;
             tu = (uintptr_t)_options_22596 & (uintptr_t)_12756;
             _12757 = MAKE_UINT(tu);
        }
    }
    else {
        _12757 = binary_op(AND_BITS, _options_22596, _12756);
    }
    DeRef(_12756);
    _12756 = NOVALUE;
    Ref(_re_22592);
    _12758 = _52get_ovector_size(_re_22592, 30LL);
    Ref(_re_22592);
    Ref(_haystack_22594);
    _0 = _match_data_22602;
    _match_data_22602 = _52find(_re_22592, _haystack_22594, _from_22595, _12757, _12758);
    DeRef(_0);
    _12757 = NOVALUE;
    _12758 = NOVALUE;

    /** regex.e:1044		if atom(match_data) then */
    _12760 = IS_ATOM(_match_data_22602);
    if (_12760 == 0)
    {
        _12760 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12760 = NOVALUE;
    }

    /** regex.e:1045			return ERROR_NOMATCH */
    DeRef(_re_22592);
    DeRef(_haystack_22594);
    DeRef(_options_22596);
    DeRef(_match_data_22602);
    return -1LL;
L2: 

    /** regex.e:1048		for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_22602)){
            _12761 = SEQ_PTR(_match_data_22602)->length;
    }
    else {
        _12761 = 1;
    }
    {
        object _i_22610;
        _i_22610 = 1LL;
L3: 
        if (_i_22610 > _12761){
            goto L4; // [68] 181
        }

        /** regex.e:1049			sequence tmp*/

        /** regex.e:1050			if match_data[i][1] = 0 then*/
        _2 = (object)SEQ_PTR(_match_data_22602);
        _12762 = (object)*(((s1_ptr)_2)->base + _i_22610);
        _2 = (object)SEQ_PTR(_12762);
        _12763 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12762 = NOVALUE;
        if (binary_op_a(NOTEQ, _12763, 0LL)){
            _12763 = NOVALUE;
            goto L5; // [87] 101
        }
        _12763 = NOVALUE;

        /** regex.e:1051				tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_22612);
        _tmp_22612 = _5;
        goto L6; // [98] 125
L5: 

        /** regex.e:1053				tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (object)SEQ_PTR(_match_data_22602);
        _12765 = (object)*(((s1_ptr)_2)->base + _i_22610);
        _2 = (object)SEQ_PTR(_12765);
        _12766 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12765 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22602);
        _12767 = (object)*(((s1_ptr)_2)->base + _i_22610);
        _2 = (object)SEQ_PTR(_12767);
        _12768 = (object)*(((s1_ptr)_2)->base + 2LL);
        _12767 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_22612;
        RHS_Slice(_haystack_22594, _12766, _12768);
L6: 

        /** regex.e:1055			if str_offsets then*/
        if (_str_offsets_22600 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** regex.e:1056				match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (object)SEQ_PTR(_match_data_22602);
        _12770 = (object)*(((s1_ptr)_2)->base + _i_22610);
        _2 = (object)SEQ_PTR(_12770);
        _12771 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12770 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22602);
        _12772 = (object)*(((s1_ptr)_2)->base + _i_22610);
        _2 = (object)SEQ_PTR(_12772);
        _12773 = (object)*(((s1_ptr)_2)->base + 2LL);
        _12772 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_tmp_22612);
        ((intptr_t*)_2)[1] = _tmp_22612;
        Ref(_12771);
        ((intptr_t*)_2)[2] = _12771;
        Ref(_12773);
        ((intptr_t*)_2)[3] = _12773;
        _12774 = MAKE_SEQ(_1);
        _12773 = NOVALUE;
        _12771 = NOVALUE;
        _2 = (object)SEQ_PTR(_match_data_22602);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22602 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22610);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12774;
        if( _1 != _12774 ){
            DeRef(_1);
        }
        _12774 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** regex.e:1058				match_data[i] = tmp*/
        RefDS(_tmp_22612);
        _2 = (object)SEQ_PTR(_match_data_22602);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _match_data_22602 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22610);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tmp_22612;
        DeRef(_1);
L8: 
        DeRef(_tmp_22612);
        _tmp_22612 = NOVALUE;

        /** regex.e:1060		end for*/
        _i_22610 = _i_22610 + 1LL;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** regex.e:1062		return match_data*/
    DeRef(_re_22592);
    DeRef(_haystack_22594);
    DeRef(_options_22596);
    _12766 = NOVALUE;
    _12768 = NOVALUE;
    return _match_data_22602;
    ;
}


object _52split(object _re_22679, object _text_22681, object _from_22682, object _options_22683)
{
    object _12800 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1198		return split_limit(re, text, 0, from, options)*/
    Ref(_re_22679);
    RefDS(_text_22681);
    _12800 = _52split_limit(_re_22679, _text_22681, 0LL, 1LL, 0LL);
    DeRef(_re_22679);
    DeRefDS(_text_22681);
    return _12800;
    ;
}


object _52split_limit(object _re_22688, object _text_22690, object _limit_22691, object _from_22692, object _options_22693)
{
    object _match_data_22697 = NOVALUE;
    object _result_22700 = NOVALUE;
    object _last_22701 = NOVALUE;
    object _a_22712 = NOVALUE;
    object _12826 = NOVALUE;
    object _12825 = NOVALUE;
    object _12824 = NOVALUE;
    object _12822 = NOVALUE;
    object _12820 = NOVALUE;
    object _12819 = NOVALUE;
    object _12818 = NOVALUE;
    object _12817 = NOVALUE;
    object _12816 = NOVALUE;
    object _12813 = NOVALUE;
    object _12812 = NOVALUE;
    object _12811 = NOVALUE;
    object _12808 = NOVALUE;
    object _12807 = NOVALUE;
    object _12805 = NOVALUE;
    object _12803 = NOVALUE;
    object _12801 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1202		if sequence(options) then */
    _12801 = 0;
    if (_12801 == 0)
    {
        _12801 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12801 = NOVALUE;
    }

    /** regex.e:1203			options = math:or_all(options) */
    _options_22693 = _20or_all(0LL);
L1: 

    /** regex.e:1205		sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_22688);
    _12803 = _52get_ovector_size(_re_22688, 30LL);
    Ref(_re_22688);
    Ref(_text_22690);
    Ref(_options_22693);
    _0 = _match_data_22697;
    _match_data_22697 = _52find_all(_re_22688, _text_22690, _from_22692, _options_22693, _12803);
    DeRef(_0);
    _12803 = NOVALUE;

    /** regex.e:1206		integer last = 1*/
    _last_22701 = 1LL;

    /** regex.e:1208		if limit = 0 or limit > length(match_data) then*/
    _12805 = (_limit_22691 == 0LL);
    if (_12805 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_22697)){
            _12807 = SEQ_PTR(_match_data_22697)->length;
    }
    else {
        _12807 = 1;
    }
    _12808 = (_limit_22691 > _12807);
    _12807 = NOVALUE;
    if (_12808 == 0)
    {
        DeRef(_12808);
        _12808 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12808);
        _12808 = NOVALUE;
    }
L2: 

    /** regex.e:1209			limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_22697)){
            _limit_22691 = SEQ_PTR(_match_data_22697)->length;
    }
    else {
        _limit_22691 = 1;
    }
L3: 

    /** regex.e:1212		result = repeat(0, limit)*/
    DeRef(_result_22700);
    _result_22700 = Repeat(0LL, _limit_22691);

    /** regex.e:1214		for i = 1 to limit do*/
    _12811 = _limit_22691;
    {
        object _i_22710;
        _i_22710 = 1LL;
L4: 
        if (_i_22710 > _12811){
            goto L5; // [81] 164
        }

        /** regex.e:1215			integer a*/

        /** regex.e:1216			a = match_data[i][1][1]*/
        _2 = (object)SEQ_PTR(_match_data_22697);
        _12812 = (object)*(((s1_ptr)_2)->base + _i_22710);
        _2 = (object)SEQ_PTR(_12812);
        _12813 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12812 = NOVALUE;
        _2 = (object)SEQ_PTR(_12813);
        _a_22712 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_a_22712)){
            _a_22712 = (object)DBL_PTR(_a_22712)->dbl;
        }
        _12813 = NOVALUE;

        /** regex.e:1217			if a = 0 then*/
        if (_a_22712 != 0LL)
        goto L6; // [108] 121

        /** regex.e:1218				result[i] = ""*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_result_22700);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _result_22700 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** regex.e:1220				result[i] = text[last..a - 1]*/
        _12816 = _a_22712 - 1LL;
        rhs_slice_target = (object_ptr)&_12817;
        RHS_Slice(_text_22690, _last_22701, _12816);
        _2 = (object)SEQ_PTR(_result_22700);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _result_22700 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22710);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12817;
        if( _1 != _12817 ){
            DeRef(_1);
        }
        _12817 = NOVALUE;

        /** regex.e:1221				last = match_data[i][1][2] + 1*/
        _2 = (object)SEQ_PTR(_match_data_22697);
        _12818 = (object)*(((s1_ptr)_2)->base + _i_22710);
        _2 = (object)SEQ_PTR(_12818);
        _12819 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12818 = NOVALUE;
        _2 = (object)SEQ_PTR(_12819);
        _12820 = (object)*(((s1_ptr)_2)->base + 2LL);
        _12819 = NOVALUE;
        if (IS_ATOM_INT(_12820)) {
            _last_22701 = _12820 + 1;
        }
        else
        { // coercing _last_22701 to an integer 1
            _last_22701 = 1+(object)(DBL_PTR(_12820)->dbl);
            if( !IS_ATOM_INT(_last_22701) ){
                _last_22701 = (object)DBL_PTR(_last_22701)->dbl;
            }
        }
        _12820 = NOVALUE;
L7: 

        /** regex.e:1223		end for*/
        _i_22710 = _i_22710 + 1LL;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** regex.e:1225		if last < length(text) then*/
    if (IS_SEQUENCE(_text_22690)){
            _12822 = SEQ_PTR(_text_22690)->length;
    }
    else {
        _12822 = 1;
    }
    if (_last_22701 >= _12822)
    goto L8; // [169] 192

    /** regex.e:1226			result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_22690)){
            _12824 = SEQ_PTR(_text_22690)->length;
    }
    else {
        _12824 = 1;
    }
    rhs_slice_target = (object_ptr)&_12825;
    RHS_Slice(_text_22690, _last_22701, _12824);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12825;
    _12826 = MAKE_SEQ(_1);
    _12825 = NOVALUE;
    Concat((object_ptr)&_result_22700, _result_22700, _12826);
    DeRefDS(_12826);
    _12826 = NOVALUE;
L8: 

    /** regex.e:1229		return result*/
    DeRef(_re_22688);
    DeRef(_text_22690);
    DeRef(_options_22693);
    DeRef(_match_data_22697);
    DeRef(_12805);
    _12805 = NOVALUE;
    DeRef(_12816);
    _12816 = NOVALUE;
    return _result_22700;
    ;
}


object _52find_replace(object _ex_22734, object _text_22736, object _replacement_22737, object _from_22738, object _options_22739)
{
    object _12828 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1280		return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_22734);
    RefDS(_text_22736);
    RefDS(_replacement_22737);
    _12828 = _52find_replace_limit(_ex_22734, _text_22736, _replacement_22737, -1LL, 1LL, 0LL);
    DeRef(_ex_22734);
    DeRefDS(_text_22736);
    DeRefDS(_replacement_22737);
    return _12828;
    ;
}


object _52find_replace_limit(object _ex_22744, object _text_22746, object _replacement_22747, object _limit_22748, object _from_22749, object _options_22750)
{
    object _12832 = NOVALUE;
    object _12831 = NOVALUE;
    object _12829 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1312		if sequence(options) then */
    _12829 = 0;
    if (_12829 == 0)
    {
        _12829 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12829 = NOVALUE;
    }

    /** regex.e:1313			options = math:or_all(options) */
    _options_22750 = _20or_all(0LL);
L1: 

    /** regex.e:1316	    return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22744);
    ((intptr_t*)_2)[1] = _ex_22744;
    Ref(_text_22746);
    ((intptr_t*)_2)[2] = _text_22746;
    RefDS(_replacement_22747);
    ((intptr_t*)_2)[3] = _replacement_22747;
    Ref(_options_22750);
    ((intptr_t*)_2)[4] = _options_22750;
    ((intptr_t*)_2)[5] = _from_22749;
    ((intptr_t*)_2)[6] = _limit_22748;
    _12831 = MAKE_SEQ(_1);
    _12832 = machine(71LL, _12831);
    DeRefDS(_12831);
    _12831 = NOVALUE;
    DeRef(_ex_22744);
    DeRef(_text_22746);
    DeRefDS(_replacement_22747);
    DeRef(_options_22750);
    return _12832;
    ;
}



// 0x0BEDEC8F
