// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _24sort(object _x_4007, object _order_4008)
{
    object _gap_4009 = NOVALUE;
    object _j_4010 = NOVALUE;
    object _first_4011 = NOVALUE;
    object _last_4012 = NOVALUE;
    object _tempi_4013 = NOVALUE;
    object _tempj_4014 = NOVALUE;
    object _1967 = NOVALUE;
    object _1963 = NOVALUE;
    object _1960 = NOVALUE;
    object _1956 = NOVALUE;
    object _1953 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:72		if order >= 0 then*/

    /** sort.e:73			order = -1*/
    _order_4008 = -1LL;
    goto L1; // [16] 25

    /** sort.e:75			order = 1*/
    _order_4008 = 1LL;
L1: 

    /** sort.e:79		last = length(x)*/
    if (IS_SEQUENCE(_x_4007)){
            _last_4012 = SEQ_PTR(_x_4007)->length;
    }
    else {
        _last_4012 = 1;
    }

    /** sort.e:80		gap = floor(last / 10) + 1*/
    if (10LL > 0 && _last_4012 >= 0) {
        _1953 = _last_4012 / 10LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_4012 / (eudouble)10LL);
        _1953 = (object)temp_dbl;
    }
    _gap_4009 = _1953 + 1;
    _1953 = NOVALUE;

    /** sort.e:81		while 1 do*/
L2: 

    /** sort.e:82			first = gap + 1*/
    _first_4011 = _gap_4009 + 1;

    /** sort.e:83			for i = first to last do*/
    _1956 = _last_4012;
    {
        object _i_4024;
        _i_4024 = _first_4011;
L3: 
        if (_i_4024 > _1956){
            goto L4; // [56] 152
        }

        /** sort.e:84				tempi = x[i]*/
        DeRef(_tempi_4013);
        _2 = (object)SEQ_PTR(_x_4007);
        _tempi_4013 = (object)*(((s1_ptr)_2)->base + _i_4024);
        Ref(_tempi_4013);

        /** sort.e:85				j = i - gap*/
        _j_4010 = _i_4024 - _gap_4009;

        /** sort.e:86				while 1 do*/
L5: 

        /** sort.e:87					tempj = x[j]*/
        DeRef(_tempj_4014);
        _2 = (object)SEQ_PTR(_x_4007);
        _tempj_4014 = (object)*(((s1_ptr)_2)->base + _j_4010);
        Ref(_tempj_4014);

        /** sort.e:88					if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_4013) && IS_ATOM_INT(_tempj_4014)){
            _1960 = (_tempi_4013 < _tempj_4014) ? -1 : (_tempi_4013 > _tempj_4014);
        }
        else{
            _1960 = compare(_tempi_4013, _tempj_4014);
        }
        if (_1960 == _order_4008)
        goto L6; // [92] 107

        /** sort.e:89						j += gap*/
        _j_4010 = _j_4010 + _gap_4009;

        /** sort.e:90						exit*/
        goto L7; // [104] 139
L6: 

        /** sort.e:92					x[j+gap] = tempj*/
        _1963 = _j_4010 + _gap_4009;
        Ref(_tempj_4014);
        _2 = (object)SEQ_PTR(_x_4007);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_4007 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1963);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_4014;
        DeRef(_1);

        /** sort.e:93					if j <= gap then*/
        if (_j_4010 > _gap_4009)
        goto L8; // [119] 128

        /** sort.e:94						exit*/
        goto L7; // [125] 139
L8: 

        /** sort.e:96					j -= gap*/
        _j_4010 = _j_4010 - _gap_4009;

        /** sort.e:97				end while*/
        goto L5; // [136] 80
L7: 

        /** sort.e:98				x[j] = tempi*/
        Ref(_tempi_4013);
        _2 = (object)SEQ_PTR(_x_4007);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_4007 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_4010);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_4013;
        DeRef(_1);

        /** sort.e:99			end for*/
        _i_4024 = _i_4024 + 1LL;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** sort.e:100			if gap = 1 then*/
    if (_gap_4009 != 1LL)
    goto L9; // [154] 167

    /** sort.e:101				return x*/
    DeRef(_tempi_4013);
    DeRef(_tempj_4014);
    DeRef(_1963);
    _1963 = NOVALUE;
    return _x_4007;
    goto L2; // [164] 45
L9: 

    /** sort.e:103				gap = floor(gap / 7) + 1*/
    if (7LL > 0 && _gap_4009 >= 0) {
        _1967 = _gap_4009 / 7LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_4009 / (eudouble)7LL);
        _1967 = (object)temp_dbl;
    }
    _gap_4009 = _1967 + 1;
    _1967 = NOVALUE;

    /** sort.e:105		end while*/
    goto L2; // [180] 45
    ;
}


object _24custom_sort(object _custom_compare_4045, object _x_4046, object _data_4047, object _order_4048)
{
    object _gap_4049 = NOVALUE;
    object _j_4050 = NOVALUE;
    object _first_4051 = NOVALUE;
    object _last_4052 = NOVALUE;
    object _tempi_4053 = NOVALUE;
    object _tempj_4054 = NOVALUE;
    object _result_4055 = NOVALUE;
    object _args_4056 = NOVALUE;
    object _1995 = NOVALUE;
    object _1991 = NOVALUE;
    object _1988 = NOVALUE;
    object _1986 = NOVALUE;
    object _1985 = NOVALUE;
    object _1980 = NOVALUE;
    object _1977 = NOVALUE;
    object _1973 = NOVALUE;
    object _1971 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:253		sequence args = {0, 0}*/
    DeRef(_args_4056);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _args_4056 = MAKE_SEQ(_1);

    /** sort.e:255		if order >= 0 then*/

    /** sort.e:256			order = -1*/
    _order_4048 = -1LL;
    goto L1; // [24] 33

    /** sort.e:258			order = 1*/
    _order_4048 = 1LL;
L1: 

    /** sort.e:261		if atom(data) then*/
    _1971 = IS_ATOM(_data_4047);
    if (_1971 == 0)
    {
        _1971 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _1971 = NOVALUE;
    }

    /** sort.e:262			args &= data*/
    if (IS_SEQUENCE(_args_4056) && IS_ATOM(_data_4047)) {
        Ref(_data_4047);
        Append(&_args_4056, _args_4056, _data_4047);
    }
    else if (IS_ATOM(_args_4056) && IS_SEQUENCE(_data_4047)) {
    }
    else {
        Concat((object_ptr)&_args_4056, _args_4056, _data_4047);
    }
    goto L3; // [47] 70
L2: 

    /** sort.e:263		elsif length(data) then*/
    _1973 = 0;
L3: 

    /** sort.e:267		last = length(x)*/
    if (IS_SEQUENCE(_x_4046)){
            _last_4052 = SEQ_PTR(_x_4046)->length;
    }
    else {
        _last_4052 = 1;
    }

    /** sort.e:268		gap = floor(last / 10) + 1*/
    if (10LL > 0 && _last_4052 >= 0) {
        _1977 = _last_4052 / 10LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_last_4052 / (eudouble)10LL);
        _1977 = (object)temp_dbl;
    }
    _gap_4049 = _1977 + 1;
    _1977 = NOVALUE;

    /** sort.e:269		while 1 do*/
L4: 

    /** sort.e:270			first = gap + 1*/
    _first_4051 = _gap_4049 + 1;

    /** sort.e:271			for i = first to last do*/
    _1980 = _last_4052;
    {
        object _i_4074;
        _i_4074 = _first_4051;
L5: 
        if (_i_4074 > _1980){
            goto L6; // [101] 240
        }

        /** sort.e:272				tempi = x[i]*/
        DeRef(_tempi_4053);
        _2 = (object)SEQ_PTR(_x_4046);
        _tempi_4053 = (object)*(((s1_ptr)_2)->base + _i_4074);
        Ref(_tempi_4053);

        /** sort.e:273				args[1] = tempi*/
        Ref(_tempi_4053);
        _2 = (object)SEQ_PTR(_args_4056);
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_4053;
        DeRef(_1);

        /** sort.e:274				j = i - gap*/
        _j_4050 = _i_4074 - _gap_4049;

        /** sort.e:275				while 1 do*/
L7: 

        /** sort.e:276					tempj = x[j]*/
        DeRef(_tempj_4054);
        _2 = (object)SEQ_PTR(_x_4046);
        _tempj_4054 = (object)*(((s1_ptr)_2)->base + _j_4050);
        Ref(_tempj_4054);

        /** sort.e:277					args[2] = tempj*/
        Ref(_tempj_4054);
        _2 = (object)SEQ_PTR(_args_4056);
        _2 = (object)(((s1_ptr)_2)->base + 2LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_4054;
        DeRef(_1);

        /** sort.e:278					result = call_func(custom_compare, args)*/
        _1 = (object)SEQ_PTR(_args_4056);
        _2 = (object)((s1_ptr)_1)->base;
        _0 = (object)_00[_custom_compare_4045].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(intptr_t (*)())_0)(
                                     );
                break;
            case 1:
                Ref( *(( (intptr_t*)_2) + 1) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1)
                                     );
                break;
            case 2:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2)
                                     );
                break;
            case 3:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3)
                                     );
                break;
            case 4:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4)
                                     );
                break;
            case 5:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5)
                                     );
                break;
            case 6:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6)
                                     );
                break;
            case 7:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7)
                                     );
                break;
            case 8:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8)
                                     );
                break;
            case 9:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9)
                                     );
                break;
            case 10:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10)
                                     );
                break;
            case 11:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11)
                                     );
                break;
            case 12:
                Ref( *(( (intptr_t*)_2) + 1) );
                Ref( *(( (intptr_t*)_2) + 2) );
                Ref( *(( (intptr_t*)_2) + 3) );
                Ref( *(( (intptr_t*)_2) + 4) );
                Ref( *(( (intptr_t*)_2) + 5) );
                Ref( *(( (intptr_t*)_2) + 6) );
                Ref( *(( (intptr_t*)_2) + 7) );
                Ref( *(( (intptr_t*)_2) + 8) );
                Ref( *(( (intptr_t*)_2) + 9) );
                Ref( *(( (intptr_t*)_2) + 10) );
                Ref( *(( (intptr_t*)_2) + 11) );
                Ref( *(( (intptr_t*)_2) + 12) );
                _1 = (*(intptr_t (*)())_0)(
                                    *( ((intptr_t *)_2) + 1), 
                                    *( ((intptr_t *)_2) + 2), 
                                    *( ((intptr_t *)_2) + 3), 
                                    *( ((intptr_t *)_2) + 4), 
                                    *( ((intptr_t *)_2) + 5), 
                                    *( ((intptr_t *)_2) + 6), 
                                    *( ((intptr_t *)_2) + 7), 
                                    *( ((intptr_t *)_2) + 8), 
                                    *( ((intptr_t *)_2) + 9), 
                                    *( ((intptr_t *)_2) + 10), 
                                    *( ((intptr_t *)_2) + 11), 
                                    *( ((intptr_t *)_2) + 12)
                                     );
                break;
        }
        DeRef(_result_4055);
        _result_4055 = _1;

        /** sort.e:279					if sequence(result) then*/
        _1985 = IS_SEQUENCE(_result_4055);
        if (_1985 == 0)
        {
            _1985 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _1985 = NOVALUE;
        }

        /** sort.e:280						args[3] = result[2]*/
        _2 = (object)SEQ_PTR(_result_4055);
        _1986 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_1986);
        _2 = (object)SEQ_PTR(_args_4056);
        _2 = (object)(((s1_ptr)_2)->base + 3LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1986;
        if( _1 != _1986 ){
            DeRef(_1);
        }
        _1986 = NOVALUE;

        /** sort.e:281						result = result[1]*/
        _0 = _result_4055;
        _2 = (object)SEQ_PTR(_result_4055);
        _result_4055 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_result_4055);
        DeRef(_0);
L8: 

        /** sort.e:283					if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_4055) && IS_ATOM_INT(0LL)){
            _1988 = (_result_4055 < 0LL) ? -1 : (_result_4055 > 0LL);
        }
        else{
            _1988 = compare(_result_4055, 0LL);
        }
        if (_1988 == _order_4048)
        goto L9; // [180] 195

        /** sort.e:284						j += gap*/
        _j_4050 = _j_4050 + _gap_4049;

        /** sort.e:285						exit*/
        goto LA; // [192] 227
L9: 

        /** sort.e:287					x[j+gap] = tempj*/
        _1991 = _j_4050 + _gap_4049;
        Ref(_tempj_4054);
        _2 = (object)SEQ_PTR(_x_4046);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_4046 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _1991);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempj_4054;
        DeRef(_1);

        /** sort.e:288					if j <= gap then*/
        if (_j_4050 > _gap_4049)
        goto LB; // [207] 216

        /** sort.e:289						exit*/
        goto LA; // [213] 227
LB: 

        /** sort.e:291					j -= gap*/
        _j_4050 = _j_4050 - _gap_4049;

        /** sort.e:292				end while*/
        goto L7; // [224] 131
LA: 

        /** sort.e:293				x[j] = tempi*/
        Ref(_tempi_4053);
        _2 = (object)SEQ_PTR(_x_4046);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _x_4046 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _j_4050);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _tempi_4053;
        DeRef(_1);

        /** sort.e:294			end for*/
        _i_4074 = _i_4074 + 1LL;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** sort.e:295			if gap = 1 then*/
    if (_gap_4049 != 1LL)
    goto LC; // [242] 255

    /** sort.e:296				return x*/
    DeRef(_data_4047);
    DeRef(_tempi_4053);
    DeRef(_tempj_4054);
    DeRef(_result_4055);
    DeRef(_args_4056);
    DeRef(_1991);
    _1991 = NOVALUE;
    return _x_4046;
    goto L4; // [252] 90
LC: 

    /** sort.e:298				gap = floor(gap / 7) + 1*/
    if (7LL > 0 && _gap_4049 >= 0) {
        _1995 = _gap_4049 / 7LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_gap_4049 / (eudouble)7LL);
        _1995 = (object)temp_dbl;
    }
    _gap_4049 = _1995 + 1;
    _1995 = NOVALUE;

    /** sort.e:300		end while*/
    goto L4; // [268] 90
    ;
}


object _24column_compare(object _a_4100, object _b_4101, object _cols_4102)
{
    object _sign_4103 = NOVALUE;
    object _column_4104 = NOVALUE;
    object _2018 = NOVALUE;
    object _2016 = NOVALUE;
    object _2015 = NOVALUE;
    object _2014 = NOVALUE;
    object _2013 = NOVALUE;
    object _2012 = NOVALUE;
    object _2011 = NOVALUE;
    object _2009 = NOVALUE;
    object _2008 = NOVALUE;
    object _2007 = NOVALUE;
    object _2005 = NOVALUE;
    object _2003 = NOVALUE;
    object _2000 = NOVALUE;
    object _1998 = NOVALUE;
    object _1997 = NOVALUE;
    object _0, _1, _2;
    

    /** sort.e:309		for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_4102)){
            _1997 = SEQ_PTR(_cols_4102)->length;
    }
    else {
        _1997 = 1;
    }
    {
        object _i_4106;
        _i_4106 = 1LL;
L1: 
        if (_i_4106 > _1997){
            goto L2; // [6] 176
        }

        /** sort.e:310			if cols[i] < 0 then*/
        _2 = (object)SEQ_PTR(_cols_4102);
        _1998 = (object)*(((s1_ptr)_2)->base + _i_4106);
        if (binary_op_a(GREATEREQ, _1998, 0LL)){
            _1998 = NOVALUE;
            goto L3; // [19] 42
        }
        _1998 = NOVALUE;

        /** sort.e:311				sign = -1*/
        _sign_4103 = -1LL;

        /** sort.e:312				column = -cols[i]*/
        _2 = (object)SEQ_PTR(_cols_4102);
        _2000 = (object)*(((s1_ptr)_2)->base + _i_4106);
        if (IS_ATOM_INT(_2000)) {
            if ((uintptr_t)_2000 == (uintptr_t)HIGH_BITS){
                _column_4104 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _column_4104 = - _2000;
            }
        }
        else {
            _column_4104 = unary_op(UMINUS, _2000);
        }
        _2000 = NOVALUE;
        if (!IS_ATOM_INT(_column_4104)) {
            _1 = (object)(DBL_PTR(_column_4104)->dbl);
            DeRefDS(_column_4104);
            _column_4104 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** sort.e:314				sign = 1*/
        _sign_4103 = 1LL;

        /** sort.e:315				column = cols[i]*/
        _2 = (object)SEQ_PTR(_cols_4102);
        _column_4104 = (object)*(((s1_ptr)_2)->base + _i_4106);
        if (!IS_ATOM_INT(_column_4104)){
            _column_4104 = (object)DBL_PTR(_column_4104)->dbl;
        }
L4: 

        /** sort.e:317			if column <= length(a) then*/
        if (IS_SEQUENCE(_a_4100)){
                _2003 = SEQ_PTR(_a_4100)->length;
        }
        else {
            _2003 = 1;
        }
        if (_column_4104 > _2003)
        goto L5; // [63] 137

        /** sort.e:318				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_4101)){
                _2005 = SEQ_PTR(_b_4101)->length;
        }
        else {
            _2005 = 1;
        }
        if (_column_4104 > _2005)
        goto L6; // [72] 121

        /** sort.e:319					if not equal(a[column], b[column]) then*/
        _2 = (object)SEQ_PTR(_a_4100);
        _2007 = (object)*(((s1_ptr)_2)->base + _column_4104);
        _2 = (object)SEQ_PTR(_b_4101);
        _2008 = (object)*(((s1_ptr)_2)->base + _column_4104);
        if (_2007 == _2008)
        _2009 = 1;
        else if (IS_ATOM_INT(_2007) && IS_ATOM_INT(_2008))
        _2009 = 0;
        else
        _2009 = (compare(_2007, _2008) == 0);
        _2007 = NOVALUE;
        _2008 = NOVALUE;
        if (_2009 != 0)
        goto L7; // [90] 169
        _2009 = NOVALUE;

        /** sort.e:320						return sign * eu:compare(a[column], b[column])*/
        _2 = (object)SEQ_PTR(_a_4100);
        _2011 = (object)*(((s1_ptr)_2)->base + _column_4104);
        _2 = (object)SEQ_PTR(_b_4101);
        _2012 = (object)*(((s1_ptr)_2)->base + _column_4104);
        if (IS_ATOM_INT(_2011) && IS_ATOM_INT(_2012)){
            _2013 = (_2011 < _2012) ? -1 : (_2011 > _2012);
        }
        else{
            _2013 = compare(_2011, _2012);
        }
        _2011 = NOVALUE;
        _2012 = NOVALUE;
        {
            int128_t p128 = (int128_t)_sign_4103 * (int128_t)_2013;
            if( p128 != (int128_t)(_2014 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _2014 = NewDouble( (eudouble)p128 );
            }
        }
        _2013 = NOVALUE;
        DeRef(_a_4100);
        DeRef(_b_4101);
        DeRef(_cols_4102);
        return _2014;
        goto L7; // [118] 169
L6: 

        /** sort.e:323					return sign * -1*/
        {
            int128_t p128 = (int128_t)_sign_4103 * (int128_t)-1LL;
            if( p128 != (int128_t)(_2015 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _2015 = NewDouble( (eudouble)p128 );
            }
        }
        DeRef(_a_4100);
        DeRef(_b_4101);
        DeRef(_cols_4102);
        DeRef(_2014);
        _2014 = NOVALUE;
        return _2015;
        goto L7; // [134] 169
L5: 

        /** sort.e:326				if column <= length(b) then*/
        if (IS_SEQUENCE(_b_4101)){
                _2016 = SEQ_PTR(_b_4101)->length;
        }
        else {
            _2016 = 1;
        }
        if (_column_4104 > _2016)
        goto L8; // [142] 161

        /** sort.e:327					return sign * 1*/
        _2018 = _sign_4103 * 1LL;
        DeRef(_a_4100);
        DeRef(_b_4101);
        DeRef(_cols_4102);
        DeRef(_2015);
        _2015 = NOVALUE;
        DeRef(_2014);
        _2014 = NOVALUE;
        return _2018;
        goto L9; // [158] 168
L8: 

        /** sort.e:329					return 0*/
        DeRef(_a_4100);
        DeRef(_b_4101);
        DeRef(_cols_4102);
        DeRef(_2015);
        _2015 = NOVALUE;
        DeRef(_2014);
        _2014 = NOVALUE;
        DeRef(_2018);
        _2018 = NOVALUE;
        return 0LL;
L9: 
L7: 

        /** sort.e:332		end for*/
        _i_4106 = _i_4106 + 1LL;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** sort.e:333		return 0*/
    DeRef(_a_4100);
    DeRef(_b_4101);
    DeRef(_cols_4102);
    DeRef(_2015);
    _2015 = NOVALUE;
    DeRef(_2014);
    _2014 = NOVALUE;
    DeRef(_2018);
    _2018 = NOVALUE;
    return 0LL;
    ;
}



// 0x524EBCF3
