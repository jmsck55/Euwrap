// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _15int_to_bytes(object _x_1875, object _size_1876)
{
    object _791 = NOVALUE;
    object _790 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:68		switch size do*/
    _0 = _size_1876;
    switch ( _0 ){ 

        /** convert.e:69			case 1 then*/
        case 1:

        /** convert.e:70				poke( mem, x )*/
        if (IS_ATOM_INT(_15mem_1871)){
            poke_addr = (uint8_t *)_15mem_1871;
        }
        else {
            poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_15mem_1871)->dbl);
        }
        if (IS_ATOM_INT(_x_1875)) {
            *poke_addr = (uint8_t)_x_1875;
        }
        else {
            *poke_addr = (uint8_t)DBL_PTR(_x_1875)->dbl;
        }
        goto L1; // [21] 73

        /** convert.e:71			case 2 then*/
        case 2:

        /** convert.e:72				poke2( mem, x )*/
        if (IS_ATOM_INT(_15mem_1871)){
            poke2_addr = (uint16_t *)_15mem_1871;
        }
        else {
            poke2_addr = (uint16_t *)(uintptr_t)(DBL_PTR(_15mem_1871)->dbl);
        }
        if (IS_ATOM_INT(_x_1875)) {
            *poke2_addr = (uint16_t)_x_1875;
        }
        else {
            *poke2_addr = (uint16_t)DBL_PTR(_x_1875)->dbl;
        }
        goto L1; // [34] 73

        /** convert.e:73			case 4 then*/
        case 4:

        /** convert.e:74				poke4( mem, x )*/
        if (IS_ATOM_INT(_15mem_1871)){
            poke4_addr = (uint32_t *)_15mem_1871;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_15mem_1871)->dbl);
        }
        if (IS_ATOM_INT(_x_1875)) {
            *poke4_addr = (uint32_t)_x_1875;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_1875)->dbl;
        }
        goto L1; // [47] 73

        /** convert.e:75			case 8 then*/
        case 8:

        /** convert.e:76				poke8( mem, x )*/
        if (IS_ATOM_INT(_15mem_1871)){
            poke8_addr = (uint64_t *)_15mem_1871;
        }
        else {
            poke8_addr = (uint64_t *)(uintptr_t)(DBL_PTR(_15mem_1871)->dbl);
        }
        if (IS_ATOM_INT(_x_1875)) {
            *poke8_addr = (uint64_t)_x_1875;
        }
        else {
            *poke8_addr = (uint64_t)DBL_PTR(_x_1875)->dbl;
        }
        goto L1; // [60] 73

        /** convert.e:77			case else*/
        default:

        /** convert.e:78				return {}*/
        RefDS(_5);
        DeRef(_x_1875);
        return _5;
    ;}L1: 

    /** convert.e:80		return peek( mem & size )*/
    Concat((object_ptr)&_790, _15mem_1871, _size_1876);
    _1 = (object)SEQ_PTR(_790);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _791 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_790);
    _790 = NOVALUE;
    DeRef(_x_1875);
    return _791;
    ;
}


object _15int_to_bits(object _x_1914, object _nbits_1915)
{
    object _bits_1916 = NOVALUE;
    object _mask_1917 = NOVALUE;
    object _817 = NOVALUE;
    object _816 = NOVALUE;
    object _814 = NOVALUE;
    object _811 = NOVALUE;
    object _810 = NOVALUE;
    object _809 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:167		if nbits < 1 then*/
    if (_nbits_1915 >= 1LL)
    goto L1; // [5] 16

    /** convert.e:168			return {}*/
    RefDS(_5);
    DeRef(_x_1914);
    DeRef(_bits_1916);
    DeRef(_mask_1917);
    return _5;
L1: 

    /** convert.e:170		bits = repeat(0, nbits)*/
    DeRef(_bits_1916);
    _bits_1916 = Repeat(0LL, _nbits_1915);

    /** convert.e:171		if nbits <= 32 then*/
    if (_nbits_1915 > 32LL)
    goto L2; // [24] 75

    /** convert.e:173			mask = 1*/
    DeRef(_mask_1917);
    _mask_1917 = 1LL;

    /** convert.e:174			for i = 1 to nbits do*/
    _809 = _nbits_1915;
    {
        object _i_1924;
        _i_1924 = 1LL;
L3: 
        if (_i_1924 > _809){
            goto L4; // [38] 72
        }

        /** convert.e:175				bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_1914) && IS_ATOM_INT(_mask_1917)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_x_1914 & (uintptr_t)_mask_1917;
                 _810 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_1914)) {
                temp_d.dbl = (eudouble)_x_1914;
                _810 = Dand_bits(&temp_d, DBL_PTR(_mask_1917));
            }
            else {
                if (IS_ATOM_INT(_mask_1917)) {
                    temp_d.dbl = (eudouble)_mask_1917;
                    _810 = Dand_bits(DBL_PTR(_x_1914), &temp_d);
                }
                else
                _810 = Dand_bits(DBL_PTR(_x_1914), DBL_PTR(_mask_1917));
            }
        }
        if (IS_ATOM_INT(_810)) {
            _811 = (_810 != 0 && 1LL != 0);
        }
        else {
            temp_d.dbl = (eudouble)1LL;
            _811 = Dand(DBL_PTR(_810), &temp_d);
        }
        DeRef(_810);
        _810 = NOVALUE;
        _2 = (object)SEQ_PTR(_bits_1916);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _bits_1916 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_1924);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _811;
        if( _1 != _811 ){
            DeRef(_1);
        }
        _811 = NOVALUE;

        /** convert.e:176				mask *= 2*/
        _0 = _mask_1917;
        if (IS_ATOM_INT(_mask_1917) && IS_ATOM_INT(_mask_1917)) {
            _mask_1917 = _mask_1917 + _mask_1917;
            if ((object)((uintptr_t)_mask_1917 + (uintptr_t)HIGH_BITS) >= 0){
                _mask_1917 = NewDouble((eudouble)_mask_1917);
            }
        }
        else {
            if (IS_ATOM_INT(_mask_1917)) {
                _mask_1917 = NewDouble((eudouble)_mask_1917 + DBL_PTR(_mask_1917)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_1917)) {
                    _mask_1917 = NewDouble(DBL_PTR(_mask_1917)->dbl + (eudouble)_mask_1917);
                }
                else
                _mask_1917 = NewDouble(DBL_PTR(_mask_1917)->dbl + DBL_PTR(_mask_1917)->dbl);
            }
        }
        DeRef(_0);

        /** convert.e:177			end for*/
        _i_1924 = _i_1924 + 1LL;
        goto L3; // [67] 45
L4: 
        ;
    }
    goto L5; // [72] 128
L2: 

    /** convert.e:180			if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_1914, 0LL)){
        goto L6; // [77] 92
    }

    /** convert.e:181				x += power(2, nbits) -- for 2's complement bit pattern*/
    _814 = power(2LL, _nbits_1915);
    _0 = _x_1914;
    if (IS_ATOM_INT(_x_1914) && IS_ATOM_INT(_814)) {
        _x_1914 = _x_1914 + _814;
        if ((object)((uintptr_t)_x_1914 + (uintptr_t)HIGH_BITS) >= 0){
            _x_1914 = NewDouble((eudouble)_x_1914);
        }
    }
    else {
        if (IS_ATOM_INT(_x_1914)) {
            _x_1914 = NewDouble((eudouble)_x_1914 + DBL_PTR(_814)->dbl);
        }
        else {
            if (IS_ATOM_INT(_814)) {
                _x_1914 = NewDouble(DBL_PTR(_x_1914)->dbl + (eudouble)_814);
            }
            else
            _x_1914 = NewDouble(DBL_PTR(_x_1914)->dbl + DBL_PTR(_814)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_814);
    _814 = NOVALUE;
L6: 

    /** convert.e:183			for i = 1 to nbits do*/
    _816 = _nbits_1915;
    {
        object _i_1935;
        _i_1935 = 1LL;
L7: 
        if (_i_1935 > _816){
            goto L8; // [97] 127
        }

        /** convert.e:184				bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_1914)) {
            _817 = (_x_1914 % 2LL);
        }
        else {
            temp_d.dbl = (eudouble)2LL;
            _817 = Dremainder(DBL_PTR(_x_1914), &temp_d);
        }
        _2 = (object)SEQ_PTR(_bits_1916);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _bits_1916 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_1935);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _817;
        if( _1 != _817 ){
            DeRef(_1);
        }
        _817 = NOVALUE;

        /** convert.e:185				x = floor(x / 2)*/
        _0 = _x_1914;
        if (IS_ATOM_INT(_x_1914)) {
            _x_1914 = _x_1914 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_1914, 2);
            _x_1914 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** convert.e:186			end for*/
        _i_1935 = _i_1935 + 1LL;
        goto L7; // [122] 104
L8: 
        ;
    }
L5: 

    /** convert.e:188		return bits*/
    DeRef(_x_1914);
    DeRef(_mask_1917);
    return _bits_1916;
    ;
}


object _15bits_to_int(object _bits_1941)
{
    object _value_1942 = NOVALUE;
    object _p_1943 = NOVALUE;
    object _820 = NOVALUE;
    object _819 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:225		value = 0*/
    DeRef(_value_1942);
    _value_1942 = 0LL;

    /** convert.e:226		p = 1*/
    DeRef(_p_1943);
    _p_1943 = 1LL;

    /** convert.e:227		for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_1941)){
            _819 = SEQ_PTR(_bits_1941)->length;
    }
    else {
        _819 = 1;
    }
    {
        object _i_1945;
        _i_1945 = 1LL;
L1: 
        if (_i_1945 > _819){
            goto L2; // [18] 54
        }

        /** convert.e:228			if bits[i] then*/
        _2 = (object)SEQ_PTR(_bits_1941);
        _820 = (object)*(((s1_ptr)_2)->base + _i_1945);
        if (_820 == 0) {
            _820 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_820) && DBL_PTR(_820)->dbl == 0.0){
                _820 = NOVALUE;
                goto L3; // [31] 41
            }
            _820 = NOVALUE;
        }
        _820 = NOVALUE;

        /** convert.e:229				value += p*/
        _0 = _value_1942;
        if (IS_ATOM_INT(_value_1942) && IS_ATOM_INT(_p_1943)) {
            _value_1942 = _value_1942 + _p_1943;
            if ((object)((uintptr_t)_value_1942 + (uintptr_t)HIGH_BITS) >= 0){
                _value_1942 = NewDouble((eudouble)_value_1942);
            }
        }
        else {
            if (IS_ATOM_INT(_value_1942)) {
                _value_1942 = NewDouble((eudouble)_value_1942 + DBL_PTR(_p_1943)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1943)) {
                    _value_1942 = NewDouble(DBL_PTR(_value_1942)->dbl + (eudouble)_p_1943);
                }
                else
                _value_1942 = NewDouble(DBL_PTR(_value_1942)->dbl + DBL_PTR(_p_1943)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** convert.e:231			p += p*/
        _0 = _p_1943;
        if (IS_ATOM_INT(_p_1943) && IS_ATOM_INT(_p_1943)) {
            _p_1943 = _p_1943 + _p_1943;
            if ((object)((uintptr_t)_p_1943 + (uintptr_t)HIGH_BITS) >= 0){
                _p_1943 = NewDouble((eudouble)_p_1943);
            }
        }
        else {
            if (IS_ATOM_INT(_p_1943)) {
                _p_1943 = NewDouble((eudouble)_p_1943 + DBL_PTR(_p_1943)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1943)) {
                    _p_1943 = NewDouble(DBL_PTR(_p_1943)->dbl + (eudouble)_p_1943);
                }
                else
                _p_1943 = NewDouble(DBL_PTR(_p_1943)->dbl + DBL_PTR(_p_1943)->dbl);
            }
        }
        DeRef(_0);

        /** convert.e:232		end for*/
        _i_1945 = _i_1945 + 1LL;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** convert.e:233		return value*/
    DeRefDS(_bits_1941);
    DeRef(_p_1943);
    return _value_1942;
    ;
}


object _15atom_to_float64(object _a_1953)
{
    object _823 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:262		return machine_func(M_A_TO_F64, a)*/
    _823 = machine(46LL, _a_1953);
    DeRef(_a_1953);
    return _823;
    ;
}


object _15atom_to_float80(object _a_1957)
{
    object _824 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:268		return machine_func(M_A_TO_F80, a)*/
    _824 = machine(105LL, _a_1957);
    DeRef(_a_1957);
    return _824;
    ;
}


object _15float80_to_atom(object _bytes_1961)
{
    object _825 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:274		return machine_func(M_F80_TO_A, bytes )*/
    _825 = machine(101LL, _bytes_1961);
    DeRefDS(_bytes_1961);
    return _825;
    ;
}


object _15atom_to_float32(object _a_1965)
{
    object _826 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:312		return machine_func(M_A_TO_F32, a)*/
    _826 = machine(48LL, _a_1965);
    DeRef(_a_1965);
    return _826;
    ;
}


object _15float64_to_atom(object _ieee64_1969)
{
    object _827 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
    _827 = machine(47LL, _ieee64_1969);
    DeRefDS(_ieee64_1969);
    return _827;
    ;
}


object _15float32_to_atom(object _ieee32_1973)
{
    object _828 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
    _828 = machine(49LL, _ieee32_1973);
    DeRefDS(_ieee32_1973);
    return _828;
    ;
}


object _15to_number(object _text_in_2052, object _return_bad_pos_2053)
{
    object _lDotFound_2054 = NOVALUE;
    object _lSignFound_2055 = NOVALUE;
    object _lCharValue_2056 = NOVALUE;
    object _lBadPos_2057 = NOVALUE;
    object _lLeftSize_2058 = NOVALUE;
    object _lRightSize_2059 = NOVALUE;
    object _lLeftValue_2060 = NOVALUE;
    object _lRightValue_2061 = NOVALUE;
    object _lBase_2062 = NOVALUE;
    object _lPercent_2063 = NOVALUE;
    object _lResult_2064 = NOVALUE;
    object _lDigitCount_2065 = NOVALUE;
    object _lCurrencyFound_2066 = NOVALUE;
    object _lLastDigit_2067 = NOVALUE;
    object _lChar_2068 = NOVALUE;
    object _950 = NOVALUE;
    object _949 = NOVALUE;
    object _942 = NOVALUE;
    object _940 = NOVALUE;
    object _939 = NOVALUE;
    object _934 = NOVALUE;
    object _933 = NOVALUE;
    object _932 = NOVALUE;
    object _931 = NOVALUE;
    object _930 = NOVALUE;
    object _929 = NOVALUE;
    object _925 = NOVALUE;
    object _921 = NOVALUE;
    object _913 = NOVALUE;
    object _902 = NOVALUE;
    object _901 = NOVALUE;
    object _895 = NOVALUE;
    object _893 = NOVALUE;
    object _887 = NOVALUE;
    object _886 = NOVALUE;
    object _885 = NOVALUE;
    object _884 = NOVALUE;
    object _883 = NOVALUE;
    object _882 = NOVALUE;
    object _881 = NOVALUE;
    object _880 = NOVALUE;
    object _879 = NOVALUE;
    object _871 = NOVALUE;
    object _870 = NOVALUE;
    object _869 = NOVALUE;
    object _0, _1, _2;
    

    /** convert.e:593		integer lDotFound = 0*/
    _lDotFound_2054 = 0LL;

    /** convert.e:594		integer lSignFound = 2*/
    _lSignFound_2055 = 2LL;

    /** convert.e:596		integer lBadPos = 0*/
    _lBadPos_2057 = 0LL;

    /** convert.e:597		atom    lLeftSize = 0*/
    DeRef(_lLeftSize_2058);
    _lLeftSize_2058 = 0LL;

    /** convert.e:598		atom    lRightSize = 1*/
    DeRef(_lRightSize_2059);
    _lRightSize_2059 = 1LL;

    /** convert.e:599		atom    lLeftValue = 0*/
    DeRef(_lLeftValue_2060);
    _lLeftValue_2060 = 0LL;

    /** convert.e:600		atom    lRightValue = 0*/
    DeRef(_lRightValue_2061);
    _lRightValue_2061 = 0LL;

    /** convert.e:601		integer lBase = 10*/
    _lBase_2062 = 10LL;

    /** convert.e:602		integer lPercent = 1*/
    _lPercent_2063 = 1LL;

    /** convert.e:604		integer lDigitCount = 0*/
    _lDigitCount_2065 = 0LL;

    /** convert.e:605		integer lCurrencyFound = 0*/
    _lCurrencyFound_2066 = 0LL;

    /** convert.e:606		integer lLastDigit = 0*/
    _lLastDigit_2067 = 0LL;

    /** convert.e:609		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_2052)){
            _869 = SEQ_PTR(_text_in_2052)->length;
    }
    else {
        _869 = 1;
    }
    {
        object _i_2070;
        _i_2070 = 1LL;
L1: 
        if (_i_2070 > _869){
            goto L2; // [70] 672
        }

        /** convert.e:610			if not integer(text_in[i]) then*/
        _2 = (object)SEQ_PTR(_text_in_2052);
        _870 = (object)*(((s1_ptr)_2)->base + _i_2070);
        if (IS_ATOM_INT(_870))
        _871 = 1;
        else if (IS_ATOM_DBL(_870))
        _871 = IS_ATOM_INT(DoubleToInt(_870));
        else
        _871 = 0;
        _870 = NOVALUE;
        if (_871 != 0)
        goto L3; // [86] 94
        _871 = NOVALUE;

        /** convert.e:611				exit*/
        goto L2; // [91] 672
L3: 

        /** convert.e:614			lChar = text_in[i]*/
        _2 = (object)SEQ_PTR(_text_in_2052);
        _lChar_2068 = (object)*(((s1_ptr)_2)->base + _i_2070);
        if (!IS_ATOM_INT(_lChar_2068))
        _lChar_2068 = (object)DBL_PTR(_lChar_2068)->dbl;

        /** convert.e:615			switch lChar do*/
        _0 = _lChar_2068;
        switch ( _0 ){ 

            /** convert.e:616				case '-' then*/
            case 45:

            /** convert.e:617					if lSignFound = 2 then*/
            if (_lSignFound_2055 != 2LL)
            goto L4; // [113] 130

            /** convert.e:618						lSignFound = -1*/
            _lSignFound_2055 = -1LL;

            /** convert.e:619						lLastDigit = lDigitCount*/
            _lLastDigit_2067 = _lDigitCount_2065;
            goto L5; // [127] 654
L4: 

            /** convert.e:621						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [136] 654

            /** convert.e:624				case '+' then*/
            case 43:

            /** convert.e:625					if lSignFound = 2 then*/
            if (_lSignFound_2055 != 2LL)
            goto L6; // [144] 161

            /** convert.e:626						lSignFound = 1*/
            _lSignFound_2055 = 1LL;

            /** convert.e:627						lLastDigit = lDigitCount*/
            _lLastDigit_2067 = _lDigitCount_2065;
            goto L5; // [158] 654
L6: 

            /** convert.e:629						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [167] 654

            /** convert.e:632				case '#' then*/
            case 35:

            /** convert.e:633					if lDigitCount = 0 and lBase = 10 then*/
            _879 = (_lDigitCount_2065 == 0LL);
            if (_879 == 0) {
                goto L7; // [179] 199
            }
            _881 = (_lBase_2062 == 10LL);
            if (_881 == 0)
            {
                DeRef(_881);
                _881 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_881);
                _881 = NOVALUE;
            }

            /** convert.e:634						lBase = 16*/
            _lBase_2062 = 16LL;
            goto L5; // [196] 654
L7: 

            /** convert.e:636						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [205] 654

            /** convert.e:639				case '@' then*/
            case 64:

            /** convert.e:640					if lDigitCount = 0  and lBase = 10 then*/
            _882 = (_lDigitCount_2065 == 0LL);
            if (_882 == 0) {
                goto L8; // [217] 237
            }
            _884 = (_lBase_2062 == 10LL);
            if (_884 == 0)
            {
                DeRef(_884);
                _884 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_884);
                _884 = NOVALUE;
            }

            /** convert.e:641						lBase = 8*/
            _lBase_2062 = 8LL;
            goto L5; // [234] 654
L8: 

            /** convert.e:643						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [243] 654

            /** convert.e:646				case '!' then*/
            case 33:

            /** convert.e:647					if lDigitCount = 0  and lBase = 10 then*/
            _885 = (_lDigitCount_2065 == 0LL);
            if (_885 == 0) {
                goto L9; // [255] 275
            }
            _887 = (_lBase_2062 == 10LL);
            if (_887 == 0)
            {
                DeRef(_887);
                _887 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_887);
                _887 = NOVALUE;
            }

            /** convert.e:648						lBase = 2*/
            _lBase_2062 = 2LL;
            goto L5; // [272] 654
L9: 

            /** convert.e:650						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [281] 654

            /** convert.e:653				case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** convert.e:654					if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_2066 != 0LL)
            goto LA; // [297] 314

            /** convert.e:655						lCurrencyFound = 1*/
            _lCurrencyFound_2066 = 1LL;

            /** convert.e:656						lLastDigit = lDigitCount*/
            _lLastDigit_2067 = _lDigitCount_2065;
            goto L5; // [311] 654
LA: 

            /** convert.e:658						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [320] 654

            /** convert.e:661				case '_' then -- grouping character*/
            case 95:

            /** convert.e:662					if lDigitCount = 0 or lLastDigit != 0 then*/
            _893 = (_lDigitCount_2065 == 0LL);
            if (_893 != 0) {
                goto LB; // [332] 345
            }
            _895 = (_lLastDigit_2067 != 0LL);
            if (_895 == 0)
            {
                DeRef(_895);
                _895 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_895);
                _895 = NOVALUE;
            }
LB: 

            /** convert.e:663						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [351] 654

            /** convert.e:666				case '.', ',' then*/
            case 46:
            case 44:

            /** convert.e:667					if lLastDigit = 0 then*/
            if (_lLastDigit_2067 != 0LL)
            goto LC; // [361] 400

            /** convert.e:668						if decimal_mark = lChar then*/
            if (46LL != _lChar_2068)
            goto L5; // [369] 654

            /** convert.e:669							if lDotFound = 0 then*/
            if (_lDotFound_2054 != 0LL)
            goto LD; // [375] 387

            /** convert.e:670								lDotFound = 1*/
            _lDotFound_2054 = 1LL;
            goto L5; // [384] 654
LD: 

            /** convert.e:672								lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** convert.e:678						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [406] 654

            /** convert.e:681				case '%' then*/
            case 37:

            /** convert.e:682					lLastDigit = lDigitCount*/
            _lLastDigit_2067 = _lDigitCount_2065;

            /** convert.e:683					if lPercent = 1 then*/
            if (_lPercent_2063 != 1LL)
            goto LE; // [419] 431

            /** convert.e:684						lPercent = 100*/
            _lPercent_2063 = 100LL;
            goto L5; // [428] 654
LE: 

            /** convert.e:686						if text_in[i-1] = '%' then*/
            _901 = _i_2070 - 1LL;
            _2 = (object)SEQ_PTR(_text_in_2052);
            _902 = (object)*(((s1_ptr)_2)->base + _901);
            if (binary_op_a(NOTEQ, _902, 37LL)){
                _902 = NOVALUE;
                goto LF; // [441] 456
            }
            _902 = NOVALUE;

            /** convert.e:687							lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_2063 = _lPercent_2063 * 10LL;
            goto L5; // [453] 654
LF: 

            /** convert.e:689							lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [463] 654

            /** convert.e:693				case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** convert.e:694					if lDigitCount = 0 then*/
            if (_lDigitCount_2065 != 0LL)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** convert.e:697						lLastDigit = i*/
            _lLastDigit_2067 = _i_2070;
            goto L5; // [488] 654

            /** convert.e:700				case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** convert.e:703		            lCharValue = find(lChar, vDigits) - 1*/
            _913 = find_from(_lChar_2068, _15vDigits_2038, 1LL);
            _lCharValue_2056 = _913 - 1LL;
            _913 = NOVALUE;

            /** convert.e:704		            if lCharValue > 15 then*/
            if (_lCharValue_2056 <= 15LL)
            goto L11; // [549] 560

            /** convert.e:705		            	lCharValue -= 6*/
            _lCharValue_2056 = _lCharValue_2056 - 6LL;
L11: 

            /** convert.e:708		            if lCharValue >= lBase then*/
            if (_lCharValue_2056 < _lBase_2062)
            goto L12; // [562] 574

            /** convert.e:709		                lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [571] 654
L12: 

            /** convert.e:711		            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_2067 == 0LL)
            goto L13; // [576] 588

            /** convert.e:712						lBadPos = i*/
            _lBadPos_2057 = _i_2070;
            goto L5; // [585] 654
L13: 

            /** convert.e:714					elsif lDotFound = 1 then*/
            if (_lDotFound_2054 != 1LL)
            goto L14; // [590] 619

            /** convert.e:715						lRightSize *= lBase*/
            _0 = _lRightSize_2059;
            if (IS_ATOM_INT(_lRightSize_2059)) {
                {
                    int128_t p128 = (int128_t)_lRightSize_2059 * (int128_t)_lBase_2062;
                    if( p128 != (int128_t)(_lRightSize_2059 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                        _lRightSize_2059 = NewDouble( (eudouble)p128 );
                    }
                }
            }
            else {
                _lRightSize_2059 = NewDouble(DBL_PTR(_lRightSize_2059)->dbl * (eudouble)_lBase_2062);
            }
            DeRef(_0);

            /** convert.e:716						lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_2061)) {
                {
                    int128_t p128 = (int128_t)_lRightValue_2061 * (int128_t)_lBase_2062;
                    if( p128 != (int128_t)(_921 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                        _921 = NewDouble( (eudouble)p128 );
                    }
                }
            }
            else {
                _921 = NewDouble(DBL_PTR(_lRightValue_2061)->dbl * (eudouble)_lBase_2062);
            }
            DeRef(_lRightValue_2061);
            if (IS_ATOM_INT(_921)) {
                _lRightValue_2061 = _921 + _lCharValue_2056;
                if ((object)((uintptr_t)_lRightValue_2061 + (uintptr_t)HIGH_BITS) >= 0){
                    _lRightValue_2061 = NewDouble((eudouble)_lRightValue_2061);
                }
            }
            else {
                _lRightValue_2061 = NewDouble(DBL_PTR(_921)->dbl + (eudouble)_lCharValue_2056);
            }
            DeRef(_921);
            _921 = NOVALUE;

            /** convert.e:717						lDigitCount += 1*/
            _lDigitCount_2065 = _lDigitCount_2065 + 1;
            goto L5; // [616] 654
L14: 

            /** convert.e:719						lLeftSize += 1*/
            _0 = _lLeftSize_2058;
            if (IS_ATOM_INT(_lLeftSize_2058)) {
                _lLeftSize_2058 = _lLeftSize_2058 + 1;
                if (_lLeftSize_2058 > MAXINT){
                    _lLeftSize_2058 = NewDouble((eudouble)_lLeftSize_2058);
                }
            }
            else
            _lLeftSize_2058 = binary_op(PLUS, 1, _lLeftSize_2058);
            DeRef(_0);

            /** convert.e:720						lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_2060)) {
                {
                    int128_t p128 = (int128_t)_lLeftValue_2060 * (int128_t)_lBase_2062;
                    if( p128 != (int128_t)(_925 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                        _925 = NewDouble( (eudouble)p128 );
                    }
                }
            }
            else {
                _925 = NewDouble(DBL_PTR(_lLeftValue_2060)->dbl * (eudouble)_lBase_2062);
            }
            DeRef(_lLeftValue_2060);
            if (IS_ATOM_INT(_925)) {
                _lLeftValue_2060 = _925 + _lCharValue_2056;
                if ((object)((uintptr_t)_lLeftValue_2060 + (uintptr_t)HIGH_BITS) >= 0){
                    _lLeftValue_2060 = NewDouble((eudouble)_lLeftValue_2060);
                }
            }
            else {
                _lLeftValue_2060 = NewDouble(DBL_PTR(_925)->dbl + (eudouble)_lCharValue_2056);
            }
            DeRef(_925);
            _925 = NOVALUE;

            /** convert.e:721						lDigitCount += 1*/
            _lDigitCount_2065 = _lDigitCount_2065 + 1;
            goto L5; // [642] 654

            /** convert.e:724				case else*/
            default:

            /** convert.e:725					lBadPos = i*/
            _lBadPos_2057 = _i_2070;
        ;}L5: 

        /** convert.e:729			if lBadPos != 0 then*/
        if (_lBadPos_2057 == 0LL)
        goto L15; // [656] 665

        /** convert.e:730				exit*/
        goto L2; // [662] 672
L15: 

        /** convert.e:732		end for*/
        _i_2070 = _i_2070 + 1LL;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** convert.e:736		if lBadPos = 0 and lDigitCount = 0 then*/
    _929 = (_lBadPos_2057 == 0LL);
    if (_929 == 0) {
        goto L16; // [678] 696
    }
    _931 = (_lDigitCount_2065 == 0LL);
    if (_931 == 0)
    {
        DeRef(_931);
        _931 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_931);
        _931 = NOVALUE;
    }

    /** convert.e:737			lBadPos = 1*/
    _lBadPos_2057 = 1LL;
L16: 

    /** convert.e:740		if return_bad_pos = 0 and lBadPos != 0 then*/
    _932 = (_return_bad_pos_2053 == 0LL);
    if (_932 == 0) {
        goto L17; // [702] 721
    }
    _934 = (_lBadPos_2057 != 0LL);
    if (_934 == 0)
    {
        DeRef(_934);
        _934 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_934);
        _934 = NOVALUE;
    }

    /** convert.e:741			return 0*/
    DeRefDS(_text_in_2052);
    DeRef(_lLeftSize_2058);
    DeRef(_lRightSize_2059);
    DeRef(_lLeftValue_2060);
    DeRef(_lRightValue_2061);
    DeRef(_lResult_2064);
    DeRef(_879);
    _879 = NOVALUE;
    DeRef(_932);
    _932 = NOVALUE;
    DeRef(_929);
    _929 = NOVALUE;
    DeRef(_882);
    _882 = NOVALUE;
    DeRef(_885);
    _885 = NOVALUE;
    DeRef(_893);
    _893 = NOVALUE;
    DeRef(_901);
    _901 = NOVALUE;
    return 0LL;
L17: 

    /** convert.e:744		if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_2061, 0LL)){
        goto L18; // [723] 751
    }

    /** convert.e:746		    if lPercent != 1 then*/
    if (_lPercent_2063 == 1LL)
    goto L19; // [729] 742

    /** convert.e:747				lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_2064);
    if (IS_ATOM_INT(_lLeftValue_2060)) {
        _lResult_2064 = (_lLeftValue_2060 % _lPercent_2063) ? NewDouble((eudouble)_lLeftValue_2060 / _lPercent_2063) : (_lLeftValue_2060 / _lPercent_2063);
    }
    else {
        _lResult_2064 = NewDouble(DBL_PTR(_lLeftValue_2060)->dbl / (eudouble)_lPercent_2063);
    }
    goto L1A; // [739] 786
L19: 

    /** convert.e:749		        lResult = lLeftValue*/
    Ref(_lLeftValue_2060);
    DeRef(_lResult_2064);
    _lResult_2064 = _lLeftValue_2060;
    goto L1A; // [748] 786
L18: 

    /** convert.e:752		    if lPercent != 1 then*/
    if (_lPercent_2063 == 1LL)
    goto L1B; // [753] 774

    /** convert.e:753		        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_2061) && IS_ATOM_INT(_lRightSize_2059)) {
        _939 = (_lRightValue_2061 % _lRightSize_2059) ? NewDouble((eudouble)_lRightValue_2061 / _lRightSize_2059) : (_lRightValue_2061 / _lRightSize_2059);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2061)) {
            _939 = NewDouble((eudouble)_lRightValue_2061 / DBL_PTR(_lRightSize_2059)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2059)) {
                _939 = NewDouble(DBL_PTR(_lRightValue_2061)->dbl / (eudouble)_lRightSize_2059);
            }
            else
            _939 = NewDouble(DBL_PTR(_lRightValue_2061)->dbl / DBL_PTR(_lRightSize_2059)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_2060) && IS_ATOM_INT(_939)) {
        _940 = _lLeftValue_2060 + _939;
        if ((object)((uintptr_t)_940 + (uintptr_t)HIGH_BITS) >= 0){
            _940 = NewDouble((eudouble)_940);
        }
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2060)) {
            _940 = NewDouble((eudouble)_lLeftValue_2060 + DBL_PTR(_939)->dbl);
        }
        else {
            if (IS_ATOM_INT(_939)) {
                _940 = NewDouble(DBL_PTR(_lLeftValue_2060)->dbl + (eudouble)_939);
            }
            else
            _940 = NewDouble(DBL_PTR(_lLeftValue_2060)->dbl + DBL_PTR(_939)->dbl);
        }
    }
    DeRef(_939);
    _939 = NOVALUE;
    DeRef(_lResult_2064);
    if (IS_ATOM_INT(_940)) {
        _lResult_2064 = (_940 % _lPercent_2063) ? NewDouble((eudouble)_940 / _lPercent_2063) : (_940 / _lPercent_2063);
    }
    else {
        _lResult_2064 = NewDouble(DBL_PTR(_940)->dbl / (eudouble)_lPercent_2063);
    }
    DeRef(_940);
    _940 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** convert.e:755		        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_2061) && IS_ATOM_INT(_lRightSize_2059)) {
        _942 = (_lRightValue_2061 % _lRightSize_2059) ? NewDouble((eudouble)_lRightValue_2061 / _lRightSize_2059) : (_lRightValue_2061 / _lRightSize_2059);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2061)) {
            _942 = NewDouble((eudouble)_lRightValue_2061 / DBL_PTR(_lRightSize_2059)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2059)) {
                _942 = NewDouble(DBL_PTR(_lRightValue_2061)->dbl / (eudouble)_lRightSize_2059);
            }
            else
            _942 = NewDouble(DBL_PTR(_lRightValue_2061)->dbl / DBL_PTR(_lRightSize_2059)->dbl);
        }
    }
    DeRef(_lResult_2064);
    if (IS_ATOM_INT(_lLeftValue_2060) && IS_ATOM_INT(_942)) {
        _lResult_2064 = _lLeftValue_2060 + _942;
        if ((object)((uintptr_t)_lResult_2064 + (uintptr_t)HIGH_BITS) >= 0){
            _lResult_2064 = NewDouble((eudouble)_lResult_2064);
        }
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2060)) {
            _lResult_2064 = NewDouble((eudouble)_lLeftValue_2060 + DBL_PTR(_942)->dbl);
        }
        else {
            if (IS_ATOM_INT(_942)) {
                _lResult_2064 = NewDouble(DBL_PTR(_lLeftValue_2060)->dbl + (eudouble)_942);
            }
            else
            _lResult_2064 = NewDouble(DBL_PTR(_lLeftValue_2060)->dbl + DBL_PTR(_942)->dbl);
        }
    }
    DeRef(_942);
    _942 = NOVALUE;
L1C: 
L1A: 

    /** convert.e:759		if lSignFound < 0 then*/
    if (_lSignFound_2055 >= 0LL)
    goto L1D; // [788] 800

    /** convert.e:760			lResult = -lResult*/
    _0 = _lResult_2064;
    if (IS_ATOM_INT(_lResult_2064)) {
        if ((uintptr_t)_lResult_2064 == (uintptr_t)HIGH_BITS){
            _lResult_2064 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _lResult_2064 = - _lResult_2064;
        }
    }
    else {
        _lResult_2064 = unary_op(UMINUS, _lResult_2064);
    }
    DeRef(_0);
L1D: 

    /** convert.e:763		if return_bad_pos = 0 then*/
    if (_return_bad_pos_2053 != 0LL)
    goto L1E; // [802] 815

    /** convert.e:764			return lResult*/
    DeRefDS(_text_in_2052);
    DeRef(_lLeftSize_2058);
    DeRef(_lRightSize_2059);
    DeRef(_lLeftValue_2060);
    DeRef(_lRightValue_2061);
    DeRef(_879);
    _879 = NOVALUE;
    DeRef(_932);
    _932 = NOVALUE;
    DeRef(_929);
    _929 = NOVALUE;
    DeRef(_882);
    _882 = NOVALUE;
    DeRef(_885);
    _885 = NOVALUE;
    DeRef(_893);
    _893 = NOVALUE;
    DeRef(_901);
    _901 = NOVALUE;
    return _lResult_2064;
L1E: 

    /** convert.e:767		if return_bad_pos = -1 then*/
    if (_return_bad_pos_2053 != -1LL)
    goto L1F; // [817] 850

    /** convert.e:768			if lBadPos = 0 then*/
    if (_lBadPos_2057 != 0LL)
    goto L20; // [823] 838

    /** convert.e:769				return lResult*/
    DeRefDS(_text_in_2052);
    DeRef(_lLeftSize_2058);
    DeRef(_lRightSize_2059);
    DeRef(_lLeftValue_2060);
    DeRef(_lRightValue_2061);
    DeRef(_879);
    _879 = NOVALUE;
    DeRef(_932);
    _932 = NOVALUE;
    DeRef(_929);
    _929 = NOVALUE;
    DeRef(_882);
    _882 = NOVALUE;
    DeRef(_885);
    _885 = NOVALUE;
    DeRef(_893);
    _893 = NOVALUE;
    DeRef(_901);
    _901 = NOVALUE;
    return _lResult_2064;
    goto L21; // [835] 849
L20: 

    /** convert.e:771				return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _lBadPos_2057;
    _949 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2052);
    DeRef(_lLeftSize_2058);
    DeRef(_lRightSize_2059);
    DeRef(_lLeftValue_2060);
    DeRef(_lRightValue_2061);
    DeRef(_lResult_2064);
    DeRef(_879);
    _879 = NOVALUE;
    DeRef(_932);
    _932 = NOVALUE;
    DeRef(_929);
    _929 = NOVALUE;
    DeRef(_882);
    _882 = NOVALUE;
    DeRef(_885);
    _885 = NOVALUE;
    DeRef(_893);
    _893 = NOVALUE;
    DeRef(_901);
    _901 = NOVALUE;
    return _949;
L21: 
L1F: 

    /** convert.e:775		return {lResult, lBadPos}*/
    Ref(_lResult_2064);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _lResult_2064;
    ((intptr_t *)_2)[2] = _lBadPos_2057;
    _950 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2052);
    DeRef(_lLeftSize_2058);
    DeRef(_lRightSize_2059);
    DeRef(_lLeftValue_2060);
    DeRef(_lRightValue_2061);
    DeRef(_lResult_2064);
    DeRef(_879);
    _879 = NOVALUE;
    DeRef(_932);
    _932 = NOVALUE;
    DeRef(_929);
    _929 = NOVALUE;
    DeRef(_882);
    _882 = NOVALUE;
    DeRef(_885);
    _885 = NOVALUE;
    DeRef(_949);
    _949 = NOVALUE;
    DeRef(_893);
    _893 = NOVALUE;
    DeRef(_901);
    _901 = NOVALUE;
    return _950;
    ;
}



// 0x30B2B216
