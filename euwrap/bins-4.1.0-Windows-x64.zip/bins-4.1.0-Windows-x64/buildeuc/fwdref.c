// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _44clear_fwd_refs()
{
    object _0, _1, _2;
    

    /** fwdref.e:70		fwdref_count = 0*/
    _44fwdref_count_63213 = 0LL;

    /** fwdref.e:71	end procedure*/
    return;
    ;
}


object _44get_fwdref_count()
{
    object _0, _1, _2;
    

    /** fwdref.e:74		return fwdref_count*/
    return _44fwdref_count_63213;
    ;
}


void _44set_glabel_block(object _ref_63220, object _block_63222)
{
    object _31097 = NOVALUE;
    object _31096 = NOVALUE;
    object _31094 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63220)) {
        _1 = (object)(DBL_PTR(_ref_63220)->dbl);
        DeRefDS(_ref_63220);
        _ref_63220 = _1;
    }
    if (!IS_ATOM_INT(_block_63222)) {
        _1 = (object)(DBL_PTR(_block_63222)->dbl);
        DeRefDS(_block_63222);
        _block_63222 = _1;
    }

    /** fwdref.e:78		forward_references[ref][FR_DATA] &= block*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63220 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31096 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31094 = NOVALUE;
    if (IS_SEQUENCE(_31096) && IS_ATOM(_block_63222)) {
        Append(&_31097, _31096, _block_63222);
    }
    else if (IS_ATOM(_31096) && IS_SEQUENCE(_block_63222)) {
    }
    else {
        Concat((object_ptr)&_31097, _31096, _block_63222);
        _31096 = NOVALUE;
    }
    _31096 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31097;
    if( _1 != _31097 ){
        DeRef(_1);
    }
    _31097 = NOVALUE;
    _31094 = NOVALUE;

    /** fwdref.e:79	end procedure*/
    return;
    ;
}


void _44replace_code(object _code_63234, object _start_63235, object _finish_63236, object _subprog_63237)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_63236)) {
        _1 = (object)(DBL_PTR(_finish_63236)->dbl);
        DeRefDS(_finish_63236);
        _finish_63236 = _1;
    }
    if (!IS_ATOM_INT(_subprog_63237)) {
        _1 = (object)(DBL_PTR(_subprog_63237)->dbl);
        DeRefDS(_subprog_63237);
        _subprog_63237 = _1;
    }

    /** fwdref.e:88		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_63237;

    /** fwdref.e:89		shift:replace_code( code, start, finish )*/
    RefDS(_code_63234);
    _66replace_code(_code_63234, _start_63235, _finish_63236);

    /** fwdref.e:90		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:91	end procedure*/
    DeRefDS(_code_63234);
    return;
    ;
}


void _44resolved_reference(object _ref_63240)
{
    object _file_63241 = NOVALUE;
    object _subprog_63244 = NOVALUE;
    object _tx_63247 = NOVALUE;
    object _ax_63248 = NOVALUE;
    object _sp_63249 = NOVALUE;
    object _r_63264 = NOVALUE;
    object _r_63282 = NOVALUE;
    object _31121 = NOVALUE;
    object _31120 = NOVALUE;
    object _31119 = NOVALUE;
    object _31117 = NOVALUE;
    object _31114 = NOVALUE;
    object _31112 = NOVALUE;
    object _31110 = NOVALUE;
    object _31109 = NOVALUE;
    object _31107 = NOVALUE;
    object _31105 = NOVALUE;
    object _31103 = NOVALUE;
    object _31102 = NOVALUE;
    object _31100 = NOVALUE;
    object _31098 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:95			file    = forward_references[ref][FR_FILE],*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31098 = (object)*(((s1_ptr)_2)->base + _ref_63240);
    _2 = (object)SEQ_PTR(_31098);
    _file_63241 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_63241)){
        _file_63241 = (object)DBL_PTR(_file_63241)->dbl;
    }
    _31098 = NOVALUE;

    /** fwdref.e:96			subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31100 = (object)*(((s1_ptr)_2)->base + _ref_63240);
    _2 = (object)SEQ_PTR(_31100);
    _subprog_63244 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_subprog_63244)){
        _subprog_63244 = (object)DBL_PTR(_subprog_63244)->dbl;
    }
    _31100 = NOVALUE;

    /** fwdref.e:99			tx = 0,*/
    _tx_63247 = 0LL;

    /** fwdref.e:100			ax = 0,*/
    _ax_63248 = 0LL;

    /** fwdref.e:101			sp = 0*/
    _sp_63249 = 0LL;

    /** fwdref.e:103		if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31102 = (object)*(((s1_ptr)_2)->base + _ref_63240);
    _2 = (object)SEQ_PTR(_31102);
    _31103 = (object)*(((s1_ptr)_2)->base + 4LL);
    _31102 = NOVALUE;
    if (binary_op_a(NOTEQ, _31103, _36TopLevelSub_21766)){
        _31103 = NOVALUE;
        goto L1; // [60] 80
    }
    _31103 = NOVALUE;

    /** fwdref.e:104			tx = find( ref, toplevel_references[file] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    _31105 = (object)*(((s1_ptr)_2)->base + _file_63241);
    _tx_63247 = find_from(_ref_63240, _31105, 1LL);
    _31105 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** fwdref.e:106			sp = find( subprog, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31107 = (object)*(((s1_ptr)_2)->base + _file_63241);
    _sp_63249 = find_from(_subprog_63244, _31107, 1LL);
    _31107 = NOVALUE;

    /** fwdref.e:107			ax = find( ref, active_references[file][sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _31109 = (object)*(((s1_ptr)_2)->base + _file_63241);
    _2 = (object)SEQ_PTR(_31109);
    _31110 = (object)*(((s1_ptr)_2)->base + _sp_63249);
    _31109 = NOVALUE;
    _ax_63248 = find_from(_ref_63240, _31110, 1LL);
    _31110 = NOVALUE;
L2: 

    /** fwdref.e:110		if ax then*/
    if (_ax_63248 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** fwdref.e:111			sequence r = active_references[file][sp] */
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _31112 = (object)*(((s1_ptr)_2)->base + _file_63241);
    DeRef(_r_63264);
    _2 = (object)SEQ_PTR(_31112);
    _r_63264 = (object)*(((s1_ptr)_2)->base + _sp_63249);
    Ref(_r_63264);
    _31112 = NOVALUE;

    /** fwdref.e:112			active_references[file][sp] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63195 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63241 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31114 = NOVALUE;

    /** fwdref.e:113			r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63264);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_63248)) ? _ax_63248 : (object)(DBL_PTR(_ax_63248)->dbl);
        int stop = (IS_ATOM_INT(_ax_63248)) ? _ax_63248 : (object)(DBL_PTR(_ax_63248)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63264), start, &_r_63264 );
            }
            else Tail(SEQ_PTR(_r_63264), stop+1, &_r_63264);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63264), start, &_r_63264);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63264 = Remove_elements(start, stop, (SEQ_PTR(_r_63264)->ref == 1));
        }
    }

    /** fwdref.e:114			active_references[file][sp] = r*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63195 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_63241 + ((s1_ptr)_2)->base);
    RefDS(_r_63264);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_63249);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63264;
    DeRef(_1);
    _31117 = NOVALUE;

    /** fwdref.e:116			if not length( active_references[file][sp] ) then*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _31119 = (object)*(((s1_ptr)_2)->base + _file_63241);
    _2 = (object)SEQ_PTR(_31119);
    _31120 = (object)*(((s1_ptr)_2)->base + _sp_63249);
    _31119 = NOVALUE;
    if (IS_SEQUENCE(_31120)){
            _31121 = SEQ_PTR(_31120)->length;
    }
    else {
        _31121 = 1;
    }
    _31120 = NOVALUE;
    if (_31121 != 0)
    goto L4; // [178] 248
    _31121 = NOVALUE;

    /** fwdref.e:117				r = active_references[file]*/
    DeRefDS(_r_63264);
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _r_63264 = (object)*(((s1_ptr)_2)->base + _file_63241);
    Ref(_r_63264);

    /** fwdref.e:118				active_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63195 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:119				r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63264);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63249)) ? _sp_63249 : (object)(DBL_PTR(_sp_63249)->dbl);
        int stop = (IS_ATOM_INT(_sp_63249)) ? _sp_63249 : (object)(DBL_PTR(_sp_63249)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63264), start, &_r_63264 );
            }
            else Tail(SEQ_PTR(_r_63264), stop+1, &_r_63264);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63264), start, &_r_63264);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63264 = Remove_elements(start, stop, (SEQ_PTR(_r_63264)->ref == 1));
        }
    }

    /** fwdref.e:120				active_references[file] = r*/
    RefDS(_r_63264);
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63195 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63264;
    DeRef(_1);

    /** fwdref.e:122				r = active_subprogs[file]*/
    DeRefDS(_r_63264);
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _r_63264 = (object)*(((s1_ptr)_2)->base + _file_63241);
    Ref(_r_63264);

    /** fwdref.e:123				active_subprogs[file] = 0*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_63194 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:124				r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63264);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_63249)) ? _sp_63249 : (object)(DBL_PTR(_sp_63249)->dbl);
        int stop = (IS_ATOM_INT(_sp_63249)) ? _sp_63249 : (object)(DBL_PTR(_sp_63249)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63264), start, &_r_63264 );
            }
            else Tail(SEQ_PTR(_r_63264), stop+1, &_r_63264);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63264), start, &_r_63264);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63264 = Remove_elements(start, stop, (SEQ_PTR(_r_63264)->ref == 1));
        }
    }

    /** fwdref.e:125				active_subprogs[file] = r*/
    RefDS(_r_63264);
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_63194 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63264;
    DeRef(_1);
L4: 
    DeRef(_r_63264);
    _r_63264 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** fwdref.e:127		elsif tx then*/
    if (_tx_63247 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** fwdref.e:128			sequence r = toplevel_references[file]*/
    DeRef(_r_63282);
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    _r_63282 = (object)*(((s1_ptr)_2)->base + _file_63241);
    Ref(_r_63282);

    /** fwdref.e:129			toplevel_references[file] = 0*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_63196 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:130			r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_63282);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_63247)) ? _tx_63247 : (object)(DBL_PTR(_tx_63247)->dbl);
        int stop = (IS_ATOM_INT(_tx_63247)) ? _tx_63247 : (object)(DBL_PTR(_tx_63247)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_63282), start, &_r_63282 );
            }
            else Tail(SEQ_PTR(_r_63282), stop+1, &_r_63282);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_63282), start, &_r_63282);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_63282 = Remove_elements(start, stop, (SEQ_PTR(_r_63282)->ref == 1));
        }
    }

    /** fwdref.e:131			toplevel_references[file] = r*/
    RefDS(_r_63282);
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_63196 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_63241);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_63282;
    DeRef(_1);
    DeRefDS(_r_63282);
    _r_63282 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** fwdref.e:134			InternalErr( 260 )*/
    RefDS(_22186);
    _50InternalErr(260LL, _22186);
L5: 

    /** fwdref.e:136		inactive_references &= ref*/
    Append(&_44inactive_references_63197, _44inactive_references_63197, _ref_63240);

    /** fwdref.e:137		forward_references[ref] = 0*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_63240);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** fwdref.e:138	end procedure*/
    _31120 = NOVALUE;
    return;
    ;
}


void _44set_code(object _ref_63296)
{
    object _31146 = NOVALUE;
    object _31144 = NOVALUE;
    object _31143 = NOVALUE;
    object _31142 = NOVALUE;
    object _31141 = NOVALUE;
    object _31139 = NOVALUE;
    object _31137 = NOVALUE;
    object _31135 = NOVALUE;
    object _31133 = NOVALUE;
    object _31130 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:146		patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31130 = (object)*(((s1_ptr)_2)->base + _ref_63296);
    _2 = (object)SEQ_PTR(_31130);
    _44patch_code_sub_63291 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_44patch_code_sub_63291)){
        _44patch_code_sub_63291 = (object)DBL_PTR(_44patch_code_sub_63291)->dbl;
    }
    _31130 = NOVALUE;

    /** fwdref.e:147		if patch_code_sub != CurrentSub then*/
    if (_44patch_code_sub_63291 == _36CurrentSub_21767)
    goto L1; // [23] 136

    /** fwdref.e:149			patch_code_temp = Code*/
    RefDS(_36Code_21851);
    DeRef(_44patch_code_temp_63288);
    _44patch_code_temp_63288 = _36Code_21851;

    /** fwdref.e:150			patch_linetab_temp = LineTable*/
    RefDS(_36LineTable_21852);
    DeRef(_44patch_linetab_temp_63289);
    _44patch_linetab_temp_63289 = _36LineTable_21852;

    /** fwdref.e:152			Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31133 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_63291);
    DeRefDS(_36Code_21851);
    _2 = (object)SEQ_PTR(_31133);
    if (!IS_ATOM_INT(_36S_CODE_21408)){
        _36Code_21851 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    }
    else{
        _36Code_21851 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
    }
    Ref(_36Code_21851);
    _31133 = NOVALUE;

    /** fwdref.e:153			SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63291 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21408))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31135 = NOVALUE;

    /** fwdref.e:154			LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31137 = (object)*(((s1_ptr)_2)->base + _44patch_code_sub_63291);
    DeRefDS(_36LineTable_21852);
    _2 = (object)SEQ_PTR(_31137);
    if (!IS_ATOM_INT(_36S_LINETAB_21431)){
        _36LineTable_21852 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
    }
    else{
        _36LineTable_21852 = (object)*(((s1_ptr)_2)->base + _36S_LINETAB_21431);
    }
    Ref(_36LineTable_21852);
    _31137 = NOVALUE;

    /** fwdref.e:155			SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63291 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21431))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21431);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31139 = NOVALUE;

    /** fwdref.e:157			patch_current_sub = CurrentSub*/
    _44patch_current_sub_63293 = _36CurrentSub_21767;

    /** fwdref.e:158			CurrentSub = patch_code_sub*/
    _36CurrentSub_21767 = _44patch_code_sub_63291;
    goto L2; // [133] 203
L1: 

    /** fwdref.e:160			patch_current_sub = patch_code_sub*/
    _44patch_current_sub_63293 = _44patch_code_sub_63291;

    /** fwdref.e:161			if sequence( SymTab[patch_current_sub][S_CODE] ) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31141 = (object)*(((s1_ptr)_2)->base + _44patch_current_sub_63293);
    _2 = (object)SEQ_PTR(_31141);
    if (!IS_ATOM_INT(_36S_CODE_21408)){
        _31142 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    }
    else{
        _31142 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
    }
    _31141 = NOVALUE;
    _31143 = IS_SEQUENCE(_31142);
    _31142 = NOVALUE;
    if (_31143 == 0)
    {
        _31143 = NOVALUE;
        goto L3; // [164] 202
    }
    else{
        _31143 = NOVALUE;
    }

    /** fwdref.e:162				SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63291 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21408))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31144 = NOVALUE;

    /** fwdref.e:163				SymTab[patch_code_sub][S_LINETAB] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63291 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21431))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21431);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _31146 = NOVALUE;
L3: 
L2: 

    /** fwdref.e:166	end procedure*/
    return;
    ;
}


void _44reset_code()
{
    object _31151 = NOVALUE;
    object _31149 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:169		if patch_code_sub != patch_current_sub then*/
    if (_44patch_code_sub_63291 == _44patch_current_sub_63293)
    goto L1; // [7] 77

    /** fwdref.e:171			SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63291 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21851);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21408))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21851;
    DeRef(_1);
    _31149 = NOVALUE;

    /** fwdref.e:172			SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_44patch_code_sub_63291 + ((s1_ptr)_2)->base);
    RefDS(_36LineTable_21852);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_LINETAB_21431))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_LINETAB_21431)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_LINETAB_21431);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36LineTable_21852;
    DeRef(_1);
    _31151 = NOVALUE;

    /** fwdref.e:175			CurrentSub = patch_current_sub*/
    _36CurrentSub_21767 = _44patch_current_sub_63293;

    /** fwdref.e:176			Code = patch_code_temp*/
    RefDS(_44patch_code_temp_63288);
    DeRefDS(_36Code_21851);
    _36Code_21851 = _44patch_code_temp_63288;

    /** fwdref.e:177			LineTable = patch_linetab_temp*/
    RefDS(_44patch_linetab_temp_63289);
    DeRefDS(_36LineTable_21852);
    _36LineTable_21852 = _44patch_linetab_temp_63289;
L1: 

    /** fwdref.e:181		patch_code_temp = {}*/
    RefDS(_22186);
    DeRef(_44patch_code_temp_63288);
    _44patch_code_temp_63288 = _22186;

    /** fwdref.e:182		patch_linetab_temp = {}*/
    RefDS(_22186);
    DeRef(_44patch_linetab_temp_63289);
    _44patch_linetab_temp_63289 = _22186;

    /** fwdref.e:183	end procedure*/
    return;
    ;
}


void _44set_data(object _ref_63358, object _data_63359)
{
    object _31153 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63358 + ((s1_ptr)_2)->base);
    Ref(_data_63359);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_63359;
    DeRef(_1);
    _31153 = NOVALUE;

    /** fwdref.e:187	end procedure*/
    DeRef(_data_63359);
    return;
    ;
}


void _44add_data(object _ref_63364, object _data_63365)
{
    object _31159 = NOVALUE;
    object _31158 = NOVALUE;
    object _31157 = NOVALUE;
    object _31155 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63364)) {
        _1 = (object)(DBL_PTR(_ref_63364)->dbl);
        DeRefDS(_ref_63364);
        _ref_63364 = _1;
    }

    /** fwdref.e:190		forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63364 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31157 = (object)*(((s1_ptr)_2)->base + _ref_63364);
    _2 = (object)SEQ_PTR(_31157);
    _31158 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31157 = NOVALUE;
    Ref(_data_63365);
    Append(&_31159, _31158, _data_63365);
    _31158 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31159;
    if( _1 != _31159 ){
        DeRef(_1);
    }
    _31159 = NOVALUE;
    _31155 = NOVALUE;

    /** fwdref.e:191	end procedure*/
    DeRef(_data_63365);
    return;
    ;
}


void _44set_line(object _ref_63373, object _line_no_63374, object _this_line_63375, object _bp_63376)
{
    object _31164 = NOVALUE;
    object _31162 = NOVALUE;
    object _31160 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_63373)) {
        _1 = (object)(DBL_PTR(_ref_63373)->dbl);
        DeRefDS(_ref_63373);
        _ref_63373 = _1;
    }

    /** fwdref.e:194		forward_references[ref][FR_LINE] = line_no*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63373 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _line_no_63374;
    DeRef(_1);
    _31160 = NOVALUE;

    /** fwdref.e:195		forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63373 + ((s1_ptr)_2)->base);
    RefDS(_this_line_63375);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _this_line_63375;
    DeRef(_1);
    _31162 = NOVALUE;

    /** fwdref.e:196		forward_references[ref][FR_BP] = bp*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_63373 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bp_63376;
    DeRef(_1);
    _31164 = NOVALUE;

    /** fwdref.e:198	end procedure*/
    DeRefDS(_this_line_63375);
    return;
    ;
}


void _44add_private_symbol(object _sym_63388, object _name_63389)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_63388)) {
        _1 = (object)(DBL_PTR(_sym_63388)->dbl);
        DeRefDS(_sym_63388);
        _sym_63388 = _1;
    }

    /** fwdref.e:206		fwd_private_sym &= sym*/
    Append(&_44fwd_private_sym_63383, _44fwd_private_sym_63383, _sym_63388);

    /** fwdref.e:207		fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_63389);
    Append(&_44fwd_private_name_63384, _44fwd_private_name_63384, _name_63389);

    /** fwdref.e:209	end procedure*/
    DeRefDS(_name_63389);
    return;
    ;
}


void _44patch_forward_goto(object _tok_63397, object _ref_63398)
{
    object _fr_63399 = NOVALUE;
    object _31180 = NOVALUE;
    object _31179 = NOVALUE;
    object _31178 = NOVALUE;
    object _31177 = NOVALUE;
    object _31176 = NOVALUE;
    object _31175 = NOVALUE;
    object _31174 = NOVALUE;
    object _31173 = NOVALUE;
    object _31171 = NOVALUE;
    object _31170 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:217		sequence fr = forward_references[ref]*/
    DeRef(_fr_63399);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63399 = (object)*(((s1_ptr)_2)->base + _ref_63398);
    Ref(_fr_63399);

    /** fwdref.e:218		set_code( ref )*/
    _44set_code(_ref_63398);

    /** fwdref.e:220		shifting_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63399);
    _44shifting_sub_63212 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_44shifting_sub_63212))
    _44shifting_sub_63212 = (object)DBL_PTR(_44shifting_sub_63212)->dbl;

    /** fwdref.e:222		if length( fr[FR_DATA] ) = 2 then*/
    _2 = (object)SEQ_PTR(_fr_63399);
    _31170 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_31170)){
            _31171 = SEQ_PTR(_31170)->length;
    }
    else {
        _31171 = 1;
    }
    _31170 = NOVALUE;
    if (_31171 != 2LL)
    goto L1; // [33] 64

    /** fwdref.e:223			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63398);

    /** fwdref.e:224			CompileErr( UNKNOWN_LABEL_1, { fr[FR_DATA][2] })*/
    _2 = (object)SEQ_PTR(_fr_63399);
    _31173 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31173);
    _31174 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31173 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31174);
    ((intptr_t*)_2)[1] = _31174;
    _31175 = MAKE_SEQ(_1);
    _31174 = NOVALUE;
    _50CompileErr(156LL, _31175, 0LL);
    _31175 = NOVALUE;
L1: 

    /** fwdref.e:227		Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (object)SEQ_PTR(_fr_63399);
    _31176 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31176);
    _31177 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31176 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63399);
    _31178 = (object)*(((s1_ptr)_2)->base + 12LL);
    _2 = (object)SEQ_PTR(_31178);
    _31179 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31178 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63399);
    _31180 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_31177);
    Ref(_31179);
    Ref(_31180);
    _65Goto_block(_31177, _31179, _31180);
    _31177 = NOVALUE;
    _31179 = NOVALUE;
    _31180 = NOVALUE;

    /** fwdref.e:229		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:231		reset_code()*/
    _44reset_code();

    /** fwdref.e:232		resolved_reference( ref )*/
    _44resolved_reference(_ref_63398);

    /** fwdref.e:233	end procedure*/
    DeRefDS(_fr_63399);
    _31170 = NOVALUE;
    return;
    ;
}


void _44patch_forward_call(object _tok_63421, object _ref_63422)
{
    object _fr_63423 = NOVALUE;
    object _sub_63426 = NOVALUE;
    object _defarg_63432 = NOVALUE;
    object _paramsym_63436 = NOVALUE;
    object _old_63439 = NOVALUE;
    object _tx_63443 = NOVALUE;
    object _code_sub_63453 = NOVALUE;
    object _args_63455 = NOVALUE;
    object _is_func_63460 = NOVALUE;
    object _real_file_63474 = NOVALUE;
    object _code_63478 = NOVALUE;
    object _temp_sub_63480 = NOVALUE;
    object _pc_63482 = NOVALUE;
    object _next_pc_63484 = NOVALUE;
    object _supplied_args_63485 = NOVALUE;
    object _name_63488 = NOVALUE;
    object _old_temps_allocated_63524 = NOVALUE;
    object _temp_target_63533 = NOVALUE;
    object _converted_code_63536 = NOVALUE;
    object _target_63552 = NOVALUE;
    object _has_defaults_63558 = NOVALUE;
    object _goto_target_63559 = NOVALUE;
    object _defarg_63562 = NOVALUE;
    object _code_len_63563 = NOVALUE;
    object _extra_default_args_63565 = NOVALUE;
    object _param_sym_63568 = NOVALUE;
    object _params_63569 = NOVALUE;
    object _orig_code_63571 = NOVALUE;
    object _orig_linetable_63572 = NOVALUE;
    object _ar_sp_63576 = NOVALUE;
    object _pre_refs_63580 = NOVALUE;
    object _old_fwd_params_63595 = NOVALUE;
    object _temp_shifting_sub_63636 = NOVALUE;
    object _new_code_63640 = NOVALUE;
    object _routine_type_63649 = NOVALUE;
    object _31939 = NOVALUE;
    object _31321 = NOVALUE;
    object _31320 = NOVALUE;
    object _31319 = NOVALUE;
    object _31317 = NOVALUE;
    object _31316 = NOVALUE;
    object _31315 = NOVALUE;
    object _31314 = NOVALUE;
    object _31313 = NOVALUE;
    object _31312 = NOVALUE;
    object _31311 = NOVALUE;
    object _31310 = NOVALUE;
    object _31309 = NOVALUE;
    object _31308 = NOVALUE;
    object _31307 = NOVALUE;
    object _31306 = NOVALUE;
    object _31305 = NOVALUE;
    object _31303 = NOVALUE;
    object _31302 = NOVALUE;
    object _31301 = NOVALUE;
    object _31300 = NOVALUE;
    object _31299 = NOVALUE;
    object _31298 = NOVALUE;
    object _31297 = NOVALUE;
    object _31296 = NOVALUE;
    object _31294 = NOVALUE;
    object _31291 = NOVALUE;
    object _31290 = NOVALUE;
    object _31289 = NOVALUE;
    object _31288 = NOVALUE;
    object _31284 = NOVALUE;
    object _31283 = NOVALUE;
    object _31282 = NOVALUE;
    object _31281 = NOVALUE;
    object _31280 = NOVALUE;
    object _31278 = NOVALUE;
    object _31277 = NOVALUE;
    object _31276 = NOVALUE;
    object _31275 = NOVALUE;
    object _31274 = NOVALUE;
    object _31273 = NOVALUE;
    object _31271 = NOVALUE;
    object _31270 = NOVALUE;
    object _31268 = NOVALUE;
    object _31267 = NOVALUE;
    object _31266 = NOVALUE;
    object _31265 = NOVALUE;
    object _31263 = NOVALUE;
    object _31261 = NOVALUE;
    object _31260 = NOVALUE;
    object _31259 = NOVALUE;
    object _31257 = NOVALUE;
    object _31256 = NOVALUE;
    object _31254 = NOVALUE;
    object _31252 = NOVALUE;
    object _31249 = NOVALUE;
    object _31245 = NOVALUE;
    object _31243 = NOVALUE;
    object _31242 = NOVALUE;
    object _31240 = NOVALUE;
    object _31239 = NOVALUE;
    object _31238 = NOVALUE;
    object _31237 = NOVALUE;
    object _31235 = NOVALUE;
    object _31234 = NOVALUE;
    object _31233 = NOVALUE;
    object _31232 = NOVALUE;
    object _31231 = NOVALUE;
    object _31229 = NOVALUE;
    object _31228 = NOVALUE;
    object _31227 = NOVALUE;
    object _31226 = NOVALUE;
    object _31225 = NOVALUE;
    object _31224 = NOVALUE;
    object _31223 = NOVALUE;
    object _31222 = NOVALUE;
    object _31221 = NOVALUE;
    object _31220 = NOVALUE;
    object _31219 = NOVALUE;
    object _31218 = NOVALUE;
    object _31217 = NOVALUE;
    object _31216 = NOVALUE;
    object _31214 = NOVALUE;
    object _31213 = NOVALUE;
    object _31212 = NOVALUE;
    object _31211 = NOVALUE;
    object _31210 = NOVALUE;
    object _31207 = NOVALUE;
    object _31203 = NOVALUE;
    object _31202 = NOVALUE;
    object _31201 = NOVALUE;
    object _31200 = NOVALUE;
    object _31199 = NOVALUE;
    object _31198 = NOVALUE;
    object _31196 = NOVALUE;
    object _31193 = NOVALUE;
    object _31191 = NOVALUE;
    object _31190 = NOVALUE;
    object _31188 = NOVALUE;
    object _31185 = NOVALUE;
    object _31184 = NOVALUE;
    object _31183 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:242		sequence fr = forward_references[ref]*/
    DeRef(_fr_63423);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63423 = (object)*(((s1_ptr)_2)->base + _ref_63422);
    Ref(_fr_63423);

    /** fwdref.e:243		symtab_index sub = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63421);
    _sub_63426 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sub_63426)){
        _sub_63426 = (object)DBL_PTR(_sub_63426)->dbl;
    }

    /** fwdref.e:245		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _31183 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31184 = IS_SEQUENCE(_31183);
    _31183 = NOVALUE;
    if (_31184 == 0)
    {
        _31184 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _31184 = NOVALUE;
    }

    /** fwdref.e:246			sequence defarg = fr[FR_DATA][1]*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _31185 = (object)*(((s1_ptr)_2)->base + 12LL);
    DeRef(_defarg_63432);
    _2 = (object)SEQ_PTR(_31185);
    _defarg_63432 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_defarg_63432);
    _31185 = NOVALUE;

    /** fwdref.e:247			symtab_index paramsym = defarg[2]*/
    _2 = (object)SEQ_PTR(_defarg_63432);
    _paramsym_63436 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_paramsym_63436)){
        _paramsym_63436 = (object)DBL_PTR(_paramsym_63436)->dbl;
    }

    /** fwdref.e:248			token old = { RECORDED, defarg[3] }*/
    _2 = (object)SEQ_PTR(_defarg_63432);
    _31188 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_31188);
    DeRef(_old_63439);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _31188;
    _old_63439 = MAKE_SEQ(_1);
    _31188 = NOVALUE;

    /** fwdref.e:249			integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31190 = (object)*(((s1_ptr)_2)->base + _paramsym_63436);
    _2 = (object)SEQ_PTR(_31190);
    if (!IS_ATOM_INT(_36S_CODE_21408)){
        _31191 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    }
    else{
        _31191 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
    }
    _31190 = NOVALUE;
    _tx_63443 = find_from(_old_63439, _31191, 1LL);
    _31191 = NOVALUE;

    /** fwdref.e:250			SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_paramsym_63436 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21408))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    else
    _3 = (object)(_36S_CODE_21408 + ((s1_ptr)_2)->base);
    _31193 = NOVALUE;
    Ref(_tok_63421);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _tx_63443);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _tok_63421;
    DeRef(_1);
    _31193 = NOVALUE;

    /** fwdref.e:251			resolved_reference( ref )*/
    _44resolved_reference(_ref_63422);

    /** fwdref.e:252			return*/
    DeRefDS(_defarg_63432);
    DeRefDS(_old_63439);
    DeRef(_tok_63421);
    DeRefDS(_fr_63423);
    DeRef(_code_63478);
    DeRef(_name_63488);
    DeRef(_params_63569);
    DeRef(_orig_code_63571);
    DeRef(_orig_linetable_63572);
    DeRef(_old_fwd_params_63595);
    DeRef(_new_code_63640);
    return;
L1: 
    DeRef(_defarg_63432);
    _defarg_63432 = NOVALUE;
    DeRef(_old_63439);
    _old_63439 = NOVALUE;

    /** fwdref.e:255		integer code_sub = fr[FR_SUBPROG]*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _code_sub_63453 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_code_sub_63453))
    _code_sub_63453 = (object)DBL_PTR(_code_sub_63453)->dbl;

    /** fwdref.e:257		integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31196 = (object)*(((s1_ptr)_2)->base + _sub_63426);
    _2 = (object)SEQ_PTR(_31196);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _args_63455 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _args_63455 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    if (!IS_ATOM_INT(_args_63455)){
        _args_63455 = (object)DBL_PTR(_args_63455)->dbl;
    }
    _31196 = NOVALUE;

    /** fwdref.e:258		integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31198 = (object)*(((s1_ptr)_2)->base + _sub_63426);
    _2 = (object)SEQ_PTR(_31198);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _31199 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _31199 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _31198 = NOVALUE;
    if (IS_ATOM_INT(_31199)) {
        _31200 = (_31199 == 501LL);
    }
    else {
        _31200 = binary_op(EQUALS, _31199, 501LL);
    }
    _31199 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31201 = (object)*(((s1_ptr)_2)->base + _sub_63426);
    _2 = (object)SEQ_PTR(_31201);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _31202 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _31202 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _31201 = NOVALUE;
    if (IS_ATOM_INT(_31202)) {
        _31203 = (_31202 == 504LL);
    }
    else {
        _31203 = binary_op(EQUALS, _31202, 504LL);
    }
    _31202 = NOVALUE;
    if (IS_ATOM_INT(_31200) && IS_ATOM_INT(_31203)) {
        _is_func_63460 = (_31200 != 0 || _31203 != 0);
    }
    else {
        _is_func_63460 = binary_op(OR, _31200, _31203);
    }
    DeRef(_31200);
    _31200 = NOVALUE;
    DeRef(_31203);
    _31203 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_63460)) {
        _1 = (object)(DBL_PTR(_is_func_63460)->dbl);
        DeRefDS(_is_func_63460);
        _is_func_63460 = _1;
    }

    /** fwdref.e:260		integer real_file = current_file_no*/
    _real_file_63474 = _36current_file_no_21759;

    /** fwdref.e:261		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _36current_file_no_21759 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21759)){
        _36current_file_no_21759 = (object)DBL_PTR(_36current_file_no_21759)->dbl;
    }

    /** fwdref.e:263		set_code( ref )*/
    _44set_code(_ref_63422);

    /** fwdref.e:264		sequence code = Code*/
    RefDS(_36Code_21851);
    DeRef(_code_63478);
    _code_63478 = _36Code_21851;

    /** fwdref.e:265		integer temp_sub = CurrentSub*/
    _temp_sub_63480 = _36CurrentSub_21767;

    /** fwdref.e:267		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _pc_63482 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63482))
    _pc_63482 = (object)DBL_PTR(_pc_63482)->dbl;

    /** fwdref.e:268		integer next_pc = pc*/
    _next_pc_63484 = _pc_63482;

    /** fwdref.e:269		integer supplied_args = code[pc+2]*/
    _31207 = _pc_63482 + 2LL;
    _2 = (object)SEQ_PTR(_code_63478);
    _supplied_args_63485 = (object)*(((s1_ptr)_2)->base + _31207);
    if (!IS_ATOM_INT(_supplied_args_63485))
    _supplied_args_63485 = (object)DBL_PTR(_supplied_args_63485)->dbl;

    /** fwdref.e:270		sequence name = fr[FR_NAME]*/
    DeRef(_name_63488);
    _2 = (object)SEQ_PTR(_fr_63423);
    _name_63488 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_63488);

    /** fwdref.e:272		if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    _31210 = (object)*(((s1_ptr)_2)->base + _pc_63482);
    if (IS_ATOM_INT(_31210)) {
        _31211 = (_31210 != 196LL);
    }
    else {
        _31211 = binary_op(NOTEQ, _31210, 196LL);
    }
    _31210 = NOVALUE;
    if (IS_ATOM_INT(_31211)) {
        if (_31211 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_31211)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (object)SEQ_PTR(_36Code_21851);
    _31213 = (object)*(((s1_ptr)_2)->base + _pc_63482);
    if (IS_ATOM_INT(_31213)) {
        _31214 = (_31213 != 195LL);
    }
    else {
        _31214 = binary_op(NOTEQ, _31213, 195LL);
    }
    _31213 = NOVALUE;
    if (_31214 == 0) {
        DeRef(_31214);
        _31214 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_31214) && DBL_PTR(_31214)->dbl == 0.0){
            DeRef(_31214);
            _31214 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_31214);
        _31214 = NOVALUE;
    }
    DeRef(_31214);
    _31214 = NOVALUE;

    /** fwdref.e:273			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63422);

    /** fwdref.e:274			CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31216 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _2 = (object)SEQ_PTR(_fr_63423);
    _31217 = (object)*(((s1_ptr)_2)->base + 4LL);
    Ref(_31217);
    _31218 = _54sym_name(_31217);
    _31217 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63423);
    _31219 = (object)*(((s1_ptr)_2)->base + 6LL);
    _2 = (object)SEQ_PTR(_fr_63423);
    _31220 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31216);
    ((intptr_t*)_2)[1] = _31216;
    ((intptr_t*)_2)[2] = _31218;
    Ref(_31219);
    ((intptr_t*)_2)[3] = _31219;
    Ref(_31220);
    ((intptr_t*)_2)[4] = _31220;
    _31221 = MAKE_SEQ(_1);
    _31220 = NOVALUE;
    _31219 = NOVALUE;
    _31218 = NOVALUE;
    _31216 = NOVALUE;
    RefDS(_31215);
    _50CompileErr(_31215, _31221, 0LL);
    _31221 = NOVALUE;
L2: 

    /** fwdref.e:278		if SymTab[sub][S_DEPRECATED] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31222 = (object)*(((s1_ptr)_2)->base + _sub_63426);
    _2 = (object)SEQ_PTR(_31222);
    _31223 = (object)*(((s1_ptr)_2)->base + 30LL);
    _31222 = NOVALUE;
    if (_31223 == 0) {
        _31223 = NOVALUE;
        goto L3; // [346] 375
    }
    else {
        if (!IS_ATOM_INT(_31223) && DBL_PTR(_31223)->dbl == 0.0){
            _31223 = NOVALUE;
            goto L3; // [346] 375
        }
        _31223 = NOVALUE;
    }
    _31223 = NOVALUE;

    /** fwdref.e:279			Warning(327, deprecated_warning_flag, { SymTab[sub][S_NAME] })*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31224 = (object)*(((s1_ptr)_2)->base + _sub_63426);
    _2 = (object)SEQ_PTR(_31224);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _31225 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _31225 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _31224 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31225);
    ((intptr_t*)_2)[1] = _31225;
    _31226 = MAKE_SEQ(_1);
    _31225 = NOVALUE;
    _50Warning(327LL, 16384LL, _31226);
    _31226 = NOVALUE;
L3: 

    /** fwdref.e:282		integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_63524 = _54temps_allocated_47663;

    /** fwdref.e:283		temps_allocated = 0*/
    _54temps_allocated_47663 = 0LL;

    /** fwdref.e:285		if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_63460 == 0) {
        goto L4; // [393] 481
    }
    _2 = (object)SEQ_PTR(_fr_63423);
    _31228 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31228)) {
        _31229 = (_31228 == 27LL);
    }
    else {
        _31229 = binary_op(EQUALS, _31228, 27LL);
    }
    _31228 = NOVALUE;
    if (_31229 == 0) {
        DeRef(_31229);
        _31229 = NOVALUE;
        goto L4; // [408] 481
    }
    else {
        if (!IS_ATOM_INT(_31229) && DBL_PTR(_31229)->dbl == 0.0){
            DeRef(_31229);
            _31229 = NOVALUE;
            goto L4; // [408] 481
        }
        DeRef(_31229);
        _31229 = NOVALUE;
    }
    DeRef(_31229);
    _31229 = NOVALUE;

    /** fwdref.e:288			symtab_index temp_target = NewTempSym()*/
    _temp_target_63533 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_temp_target_63533)) {
        _1 = (object)(DBL_PTR(_temp_target_63533)->dbl);
        DeRefDS(_temp_target_63533);
        _temp_target_63533 = _1;
    }

    /** fwdref.e:289			sequence converted_code = */
    _31231 = _pc_63482 + 1;
    if (_31231 > MAXINT){
        _31231 = NewDouble((eudouble)_31231);
    }
    _31232 = _pc_63482 + 2LL;
    if ((object)((uintptr_t)_31232 + (uintptr_t)HIGH_BITS) >= 0){
        _31232 = NewDouble((eudouble)_31232);
    }
    if (IS_ATOM_INT(_31232)) {
        _31233 = _31232 + _supplied_args_63485;
    }
    else {
        _31233 = NewDouble(DBL_PTR(_31232)->dbl + (eudouble)_supplied_args_63485);
    }
    DeRef(_31232);
    _31232 = NOVALUE;
    rhs_slice_target = (object_ptr)&_31234;
    RHS_Slice(_36Code_21851, _31231, _31233);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 208LL;
    ((intptr_t *)_2)[2] = _temp_target_63533;
    _31235 = MAKE_SEQ(_1);
    {
        object concat_list[4];

        concat_list[0] = _31235;
        concat_list[1] = _temp_target_63533;
        concat_list[2] = _31234;
        concat_list[3] = 196LL;
        Concat_N((object_ptr)&_converted_code_63536, concat_list, 4);
    }
    DeRefDS(_31235);
    _31235 = NOVALUE;
    DeRefDS(_31234);
    _31234 = NOVALUE;

    /** fwdref.e:295			replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _31237 = _pc_63482 + 2LL;
    if ((object)((uintptr_t)_31237 + (uintptr_t)HIGH_BITS) >= 0){
        _31237 = NewDouble((eudouble)_31237);
    }
    if (IS_ATOM_INT(_31237)) {
        _31238 = _31237 + _supplied_args_63485;
        if ((object)((uintptr_t)_31238 + (uintptr_t)HIGH_BITS) >= 0){
            _31238 = NewDouble((eudouble)_31238);
        }
    }
    else {
        _31238 = NewDouble(DBL_PTR(_31237)->dbl + (eudouble)_supplied_args_63485);
    }
    DeRef(_31237);
    _31237 = NOVALUE;
    RefDS(_converted_code_63536);
    _44replace_code(_converted_code_63536, _pc_63482, _31238, _code_sub_63453);
    _31238 = NOVALUE;

    /** fwdref.e:297			code = Code*/
    RefDS(_36Code_21851);
    DeRef(_code_63478);
    _code_63478 = _36Code_21851;
L4: 
    DeRef(_converted_code_63536);
    _converted_code_63536 = NOVALUE;

    /** fwdref.e:299		next_pc +=*/
    _31239 = 3LL + _supplied_args_63485;
    if ((object)((uintptr_t)_31239 + (uintptr_t)HIGH_BITS) >= 0){
        _31239 = NewDouble((eudouble)_31239);
    }
    if (IS_ATOM_INT(_31239)) {
        _31240 = _31239 + _is_func_63460;
        if ((object)((uintptr_t)_31240 + (uintptr_t)HIGH_BITS) >= 0){
            _31240 = NewDouble((eudouble)_31240);
        }
    }
    else {
        _31240 = NewDouble(DBL_PTR(_31239)->dbl + (eudouble)_is_func_63460);
    }
    DeRef(_31239);
    _31239 = NOVALUE;
    if (IS_ATOM_INT(_31240)) {
        _next_pc_63484 = _next_pc_63484 + _31240;
    }
    else {
        _next_pc_63484 = NewDouble((eudouble)_next_pc_63484 + DBL_PTR(_31240)->dbl);
    }
    DeRef(_31240);
    _31240 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_63484)) {
        _1 = (object)(DBL_PTR(_next_pc_63484)->dbl);
        DeRefDS(_next_pc_63484);
        _next_pc_63484 = _1;
    }

    /** fwdref.e:303		integer target*/

    /** fwdref.e:304		if is_func then*/
    if (_is_func_63460 == 0)
    {
        goto L5; // [503] 525
    }
    else{
    }

    /** fwdref.e:305			target = Code[pc + 3 + supplied_args]*/
    _31242 = _pc_63482 + 3LL;
    if ((object)((uintptr_t)_31242 + (uintptr_t)HIGH_BITS) >= 0){
        _31242 = NewDouble((eudouble)_31242);
    }
    if (IS_ATOM_INT(_31242)) {
        _31243 = _31242 + _supplied_args_63485;
    }
    else {
        _31243 = NewDouble(DBL_PTR(_31242)->dbl + (eudouble)_supplied_args_63485);
    }
    DeRef(_31242);
    _31242 = NOVALUE;
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!IS_ATOM_INT(_31243)){
        _target_63552 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31243)->dbl));
    }
    else{
        _target_63552 = (object)*(((s1_ptr)_2)->base + _31243);
    }
    if (!IS_ATOM_INT(_target_63552)){
        _target_63552 = (object)DBL_PTR(_target_63552)->dbl;
    }
L5: 

    /** fwdref.e:307		integer has_defaults = 0*/
    _has_defaults_63558 = 0LL;

    /** fwdref.e:308		integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_63478)){
            _31245 = SEQ_PTR(_code_63478)->length;
    }
    else {
        _31245 = 1;
    }
    _goto_target_63559 = _31245 + 1;
    _31245 = NOVALUE;

    /** fwdref.e:309		integer defarg = 0*/
    _defarg_63562 = 0LL;

    /** fwdref.e:310		integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_63478)){
            _code_len_63563 = SEQ_PTR(_code_63478)->length;
    }
    else {
        _code_len_63563 = 1;
    }

    /** fwdref.e:312		integer extra_default_args = 0*/
    _extra_default_args_63565 = 0LL;

    /** fwdref.e:313		set_dont_read( 1 )*/
    _62set_dont_read(1LL);

    /** fwdref.e:314		reset_private_lists()*/

    /** fwdref.e:212		fwd_private_sym  = {}*/
    RefDS(_22186);
    DeRefi(_44fwd_private_sym_63383);
    _44fwd_private_sym_63383 = _22186;

    /** fwdref.e:213		fwd_private_name = {}*/
    RefDS(_22186);
    DeRef(_44fwd_private_name_63384);
    _44fwd_private_name_63384 = _22186;

    /** fwdref.e:214	end procedure*/
    goto L6; // [577] 580
L6: 

    /** fwdref.e:315		integer param_sym = sub*/
    _param_sym_63568 = _sub_63426;

    /** fwdref.e:316		sequence params = repeat( 0, args )*/
    DeRef(_params_63569);
    _params_63569 = Repeat(0LL, _args_63455);

    /** fwdref.e:317		sequence orig_code = code*/
    RefDS(_code_63478);
    DeRef(_orig_code_63571);
    _orig_code_63571 = _code_63478;

    /** fwdref.e:318		sequence orig_linetable = LineTable*/
    RefDS(_36LineTable_21852);
    DeRef(_orig_linetable_63572);
    _orig_linetable_63572 = _36LineTable_21852;

    /** fwdref.e:319		LineTable = {}*/
    RefDS(_22186);
    DeRefDS(_36LineTable_21852);
    _36LineTable_21852 = _22186;

    /** fwdref.e:320		Code = {}*/
    RefDS(_22186);
    DeRef(_36Code_21851);
    _36Code_21851 = _22186;

    /** fwdref.e:323		integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31249 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _ar_sp_63576 = find_from(_code_sub_63453, _31249, 1LL);
    _31249 = NOVALUE;

    /** fwdref.e:324		integer pre_refs*/

    /** fwdref.e:326		if code_sub = TopLevelSub then*/
    if (_code_sub_63453 != _36TopLevelSub_21766)
    goto L7; // [644] 664

    /** fwdref.e:327			pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    _31252 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_31252)){
            _pre_refs_63580 = SEQ_PTR(_31252)->length;
    }
    else {
        _pre_refs_63580 = 1;
    }
    _31252 = NOVALUE;
    goto L8; // [661] 697
L7: 

    /** fwdref.e:329			ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31254 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _ar_sp_63576 = find_from(_code_sub_63453, _31254, 1LL);
    _31254 = NOVALUE;

    /** fwdref.e:330			pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _31256 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _2 = (object)SEQ_PTR(_31256);
    _31257 = (object)*(((s1_ptr)_2)->base + _ar_sp_63576);
    _31256 = NOVALUE;
    if (IS_SEQUENCE(_31257)){
            _pre_refs_63580 = SEQ_PTR(_31257)->length;
    }
    else {
        _pre_refs_63580 = 1;
    }
    _31257 = NOVALUE;
L8: 

    /** fwdref.e:333		sequence old_fwd_params = {}*/
    RefDS(_22186);
    DeRef(_old_fwd_params_63595);
    _old_fwd_params_63595 = _22186;

    /** fwdref.e:334		for i = pc + 3 to pc + args + 2 do*/
    _31259 = _pc_63482 + 3LL;
    if ((object)((uintptr_t)_31259 + (uintptr_t)HIGH_BITS) >= 0){
        _31259 = NewDouble((eudouble)_31259);
    }
    _31260 = _pc_63482 + _args_63455;
    if ((object)((uintptr_t)_31260 + (uintptr_t)HIGH_BITS) >= 0){
        _31260 = NewDouble((eudouble)_31260);
    }
    if (IS_ATOM_INT(_31260)) {
        _31261 = _31260 + 2LL;
        if ((object)((uintptr_t)_31261 + (uintptr_t)HIGH_BITS) >= 0){
            _31261 = NewDouble((eudouble)_31261);
        }
    }
    else {
        _31261 = NewDouble(DBL_PTR(_31260)->dbl + (eudouble)2LL);
    }
    DeRef(_31260);
    _31260 = NOVALUE;
    {
        object _i_63597;
        Ref(_31259);
        _i_63597 = _31259;
L9: 
        if (binary_op_a(GREATER, _i_63597, _31261)){
            goto LA; // [718] 879
        }

        /** fwdref.e:335			defarg += 1*/
        _defarg_63562 = _defarg_63562 + 1;

        /** fwdref.e:336			param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _31263 = (object)*(((s1_ptr)_2)->base + _param_sym_63568);
        _2 = (object)SEQ_PTR(_31263);
        _param_sym_63568 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_sym_63568)){
            _param_sym_63568 = (object)DBL_PTR(_param_sym_63568)->dbl;
        }
        _31263 = NOVALUE;

        /** fwdref.e:337			if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _31265 = (_defarg_63562 > _supplied_args_63485);
        if (_31265 != 0) {
            _31266 = 1;
            goto LB; // [753] 768
        }
        if (IS_SEQUENCE(_code_63478)){
                _31267 = SEQ_PTR(_code_63478)->length;
        }
        else {
            _31267 = 1;
        }
        if (IS_ATOM_INT(_i_63597)) {
            _31268 = (_i_63597 > _31267);
        }
        else {
            _31268 = (DBL_PTR(_i_63597)->dbl > (eudouble)_31267);
        }
        _31267 = NOVALUE;
        _31266 = (_31268 != 0);
LB: 
        if (_31266 != 0) {
            goto LC; // [768] 784
        }
        _2 = (object)SEQ_PTR(_code_63478);
        if (!IS_ATOM_INT(_i_63597)){
            _31270 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63597)->dbl));
        }
        else{
            _31270 = (object)*(((s1_ptr)_2)->base + _i_63597);
        }
        if (IS_ATOM_INT(_31270)) {
            _31271 = (_31270 == 0);
        }
        else {
            _31271 = unary_op(NOT, _31270);
        }
        _31270 = NOVALUE;
        if (_31271 == 0) {
            DeRef(_31271);
            _31271 = NOVALUE;
            goto LD; // [780] 834
        }
        else {
            if (!IS_ATOM_INT(_31271) && DBL_PTR(_31271)->dbl == 0.0){
                DeRef(_31271);
                _31271 = NOVALUE;
                goto LD; // [780] 834
            }
            DeRef(_31271);
            _31271 = NOVALUE;
        }
        DeRef(_31271);
        _31271 = NOVALUE;
LC: 

        /** fwdref.e:339				has_defaults = 1*/
        _has_defaults_63558 = 1LL;

        /** fwdref.e:340				extra_default_args += 1*/
        _extra_default_args_63565 = _extra_default_args_63565 + 1;

        /** fwdref.e:345				show_params( sub )*/
        _54show_params(_sub_63426);

        /** fwdref.e:346				set_error_info( ref )*/
        _44set_error_info(_ref_63422);

        /** fwdref.e:347				Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_44fwd_private_name_63384);
        RefDS(_44fwd_private_sym_63383);
        _45Parse_default_arg(_sub_63426, _defarg_63562, _44fwd_private_name_63384, _44fwd_private_sym_63383);

        /** fwdref.e:348				hide_params( sub )*/
        _54hide_params(_sub_63426);

        /** fwdref.e:349				params[defarg] = Pop()*/
        _31273 = _47Pop();
        _2 = (object)SEQ_PTR(_params_63569);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63562);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31273;
        if( _1 != _31273 ){
            DeRef(_1);
        }
        _31273 = NOVALUE;
        goto LE; // [831] 872
LD: 

        /** fwdref.e:351				extra_default_args = 0*/
        _extra_default_args_63565 = 0LL;

        /** fwdref.e:352				add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (object)SEQ_PTR(_code_63478);
        if (!IS_ATOM_INT(_i_63597)){
            _31274 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63597)->dbl));
        }
        else{
            _31274 = (object)*(((s1_ptr)_2)->base + _i_63597);
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _31275 = (object)*(((s1_ptr)_2)->base + _param_sym_63568);
        _2 = (object)SEQ_PTR(_31275);
        if (!IS_ATOM_INT(_36S_NAME_21396)){
            _31276 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
        }
        else{
            _31276 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
        }
        _31275 = NOVALUE;
        Ref(_31274);
        Ref(_31276);
        _44add_private_symbol(_31274, _31276);
        _31274 = NOVALUE;
        _31276 = NOVALUE;

        /** fwdref.e:353				params[defarg] = code[i]*/
        _2 = (object)SEQ_PTR(_code_63478);
        if (!IS_ATOM_INT(_i_63597)){
            _31277 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63597)->dbl));
        }
        else{
            _31277 = (object)*(((s1_ptr)_2)->base + _i_63597);
        }
        Ref(_31277);
        _2 = (object)SEQ_PTR(_params_63569);
        _2 = (object)(((s1_ptr)_2)->base + _defarg_63562);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31277;
        if( _1 != _31277 ){
            DeRef(_1);
        }
        _31277 = NOVALUE;
LE: 

        /** fwdref.e:355		end for*/
        _0 = _i_63597;
        if (IS_ATOM_INT(_i_63597)) {
            _i_63597 = _i_63597 + 1LL;
            if ((object)((uintptr_t)_i_63597 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63597 = NewDouble((eudouble)_i_63597);
            }
        }
        else {
            _i_63597 = binary_op_a(PLUS, _i_63597, 1LL);
        }
        DeRef(_0);
        goto L9; // [874] 725
LA: 
        ;
        DeRef(_i_63597);
    }

    /** fwdref.e:357		SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_code_sub_63453 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456)){
        _31280 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    }
    else{
        _31280 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    }
    _31278 = NOVALUE;
    if (IS_ATOM_INT(_31280)) {
        _31281 = _31280 + _54temps_allocated_47663;
        if ((object)((uintptr_t)_31281 + (uintptr_t)HIGH_BITS) >= 0){
            _31281 = NewDouble((eudouble)_31281);
        }
    }
    else {
        _31281 = binary_op(PLUS, _31280, _54temps_allocated_47663);
    }
    _31280 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31281;
    if( _1 != _31281 ){
        DeRef(_1);
    }
    _31281 = NOVALUE;
    _31278 = NOVALUE;

    /** fwdref.e:358		temps_allocated = old_temps_allocated*/
    _54temps_allocated_47663 = _old_temps_allocated_63524;

    /** fwdref.e:363		integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_63636 = _44shifting_sub_63212;

    /** fwdref.e:364		shift( -pc, pc-1 )*/
    if ((uintptr_t)_pc_63482 == (uintptr_t)HIGH_BITS){
        _31282 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31282 = - _pc_63482;
    }
    _31283 = _pc_63482 - 1LL;
    if ((object)((uintptr_t)_31283 +(uintptr_t) HIGH_BITS) >= 0){
        _31283 = NewDouble((eudouble)_31283);
    }
    Ref(_31282);
    DeRef(_31939);
    _31939 = _31282;
    _66shift(_31282, _31283, _31939);
    _31282 = NOVALUE;
    _31283 = NOVALUE;
    _31939 = NOVALUE;

    /** fwdref.e:366		sequence new_code = Code*/
    RefDS(_36Code_21851);
    DeRef(_new_code_63640);
    _new_code_63640 = _36Code_21851;

    /** fwdref.e:367		Code = orig_code*/
    RefDS(_orig_code_63571);
    DeRefDS(_36Code_21851);
    _36Code_21851 = _orig_code_63571;

    /** fwdref.e:368		orig_code = {}*/
    RefDS(_22186);
    DeRefDS(_orig_code_63571);
    _orig_code_63571 = _22186;

    /** fwdref.e:369		LineTable = orig_linetable*/
    RefDS(_orig_linetable_63572);
    DeRef(_36LineTable_21852);
    _36LineTable_21852 = _orig_linetable_63572;

    /** fwdref.e:370		orig_linetable = {}*/
    RefDS(_22186);
    DeRefDS(_orig_linetable_63572);
    _orig_linetable_63572 = _22186;

    /** fwdref.e:371		set_dont_read( 0 )*/
    _62set_dont_read(0LL);

    /** fwdref.e:372		current_file_no = real_file*/
    _36current_file_no_21759 = _real_file_63474;

    /** fwdref.e:374		if args != ( supplied_args + extra_default_args ) then*/
    _31284 = _supplied_args_63485 + _extra_default_args_63565;
    if ((object)((uintptr_t)_31284 + (uintptr_t)HIGH_BITS) >= 0){
        _31284 = NewDouble((eudouble)_31284);
    }
    if (binary_op_a(EQUALS, _args_63455, _31284)){
        DeRef(_31284);
        _31284 = NOVALUE;
        goto LF; // [990] 1070
    }
    DeRef(_31284);
    _31284 = NOVALUE;

    /** fwdref.e:375			sequence routine_type*/

    /** fwdref.e:377			if is_func then */
    if (_is_func_63460 == 0)
    {
        goto L10; // [998] 1011
    }
    else{
    }

    /** fwdref.e:378				routine_type = "function"*/
    RefDS(_26461);
    DeRefi(_routine_type_63649);
    _routine_type_63649 = _26461;
    goto L11; // [1008] 1019
L10: 

    /** fwdref.e:380				routine_type = "procedure"*/
    RefDS(_26515);
    DeRefi(_routine_type_63649);
    _routine_type_63649 = _26515;
L11: 

    /** fwdref.e:382			current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _36current_file_no_21759 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21759)){
        _36current_file_no_21759 = (object)DBL_PTR(_36current_file_no_21759)->dbl;
    }

    /** fwdref.e:383			line_number = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63423);
    _36line_number_21760 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36line_number_21760)){
        _36line_number_21760 = (object)DBL_PTR(_36line_number_21760)->dbl;
    }

    /** fwdref.e:384			CompileErr( WRONG_NUMBER_OF_ARGUMENTS_SUPPLIED_FOR_FORWARD_REFERENCET1_2_3_4__EXPECTED_5_BUT_FOUND_6,*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31288 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _31289 = _supplied_args_63485 + _extra_default_args_63565;
    if ((object)((uintptr_t)_31289 + (uintptr_t)HIGH_BITS) >= 0){
        _31289 = NewDouble((eudouble)_31289);
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_31288);
    ((intptr_t*)_2)[1] = _31288;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    RefDS(_routine_type_63649);
    ((intptr_t*)_2)[3] = _routine_type_63649;
    RefDS(_name_63488);
    ((intptr_t*)_2)[4] = _name_63488;
    ((intptr_t*)_2)[5] = _args_63455;
    ((intptr_t*)_2)[6] = _31289;
    _31290 = MAKE_SEQ(_1);
    _31289 = NOVALUE;
    _31288 = NOVALUE;
    _50CompileErr(158LL, _31290, 0LL);
    _31290 = NOVALUE;
LF: 
    DeRefi(_routine_type_63649);
    _routine_type_63649 = NOVALUE;

    /** fwdref.e:388		new_code &= PROC & sub & params*/
    {
        object concat_list[3];

        concat_list[0] = _params_63569;
        concat_list[1] = _sub_63426;
        concat_list[2] = 27LL;
        Concat_N((object_ptr)&_31291, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_63640, _new_code_63640, _31291);
    DeRefDS(_31291);
    _31291 = NOVALUE;

    /** fwdref.e:389		if is_func then*/
    if (_is_func_63460 == 0)
    {
        goto L12; // [1088] 1100
    }
    else{
    }

    /** fwdref.e:390			new_code &= target*/
    Append(&_new_code_63640, _new_code_63640, _target_63552);
L12: 

    /** fwdref.e:393		replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _31294 = _next_pc_63484 - 1LL;
    if ((object)((uintptr_t)_31294 +(uintptr_t) HIGH_BITS) >= 0){
        _31294 = NewDouble((eudouble)_31294);
    }
    RefDS(_new_code_63640);
    _44replace_code(_new_code_63640, _pc_63482, _31294, _code_sub_63453);
    _31294 = NOVALUE;

    /** fwdref.e:395		if code_sub = TopLevelSub then*/
    if (_code_sub_63453 != _36TopLevelSub_21766)
    goto L13; // [1116] 1197

    /** fwdref.e:396			for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _31296 = _pre_refs_63580 + 1;
    if (_31296 > MAXINT){
        _31296 = NewDouble((eudouble)_31296);
    }
    _2 = (object)SEQ_PTR(_fr_63423);
    _31297 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    if (!IS_ATOM_INT(_31297)){
        _31298 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31297)->dbl));
    }
    else{
        _31298 = (object)*(((s1_ptr)_2)->base + _31297);
    }
    if (IS_SEQUENCE(_31298)){
            _31299 = SEQ_PTR(_31298)->length;
    }
    else {
        _31299 = 1;
    }
    _31298 = NOVALUE;
    {
        object _i_63674;
        Ref(_31296);
        _i_63674 = _31296;
L14: 
        if (binary_op_a(GREATER, _i_63674, _31299)){
            goto L15; // [1141] 1194
        }

        /** fwdref.e:397				forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63423);
        _31300 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_44toplevel_references_63196);
        if (!IS_ATOM_INT(_31300)){
            _31301 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31300)->dbl));
        }
        else{
            _31301 = (object)*(((s1_ptr)_2)->base + _31300);
        }
        _2 = (object)SEQ_PTR(_31301);
        if (!IS_ATOM_INT(_i_63674)){
            _31302 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63674)->dbl));
        }
        else{
            _31302 = (object)*(((s1_ptr)_2)->base + _i_63674);
        }
        _31301 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63193 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31302))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31302)->dbl));
        else
        _3 = (object)(_31302 + ((s1_ptr)_2)->base);
        _31305 = _pc_63482 - 1LL;
        if ((object)((uintptr_t)_31305 +(uintptr_t) HIGH_BITS) >= 0){
            _31305 = NewDouble((eudouble)_31305);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31306 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31303 = NOVALUE;
        if (IS_ATOM_INT(_31306) && IS_ATOM_INT(_31305)) {
            _31307 = _31306 + _31305;
            if ((object)((uintptr_t)_31307 + (uintptr_t)HIGH_BITS) >= 0){
                _31307 = NewDouble((eudouble)_31307);
            }
        }
        else {
            _31307 = binary_op(PLUS, _31306, _31305);
        }
        _31306 = NOVALUE;
        DeRef(_31305);
        _31305 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31307;
        if( _1 != _31307 ){
            DeRef(_1);
        }
        _31307 = NOVALUE;
        _31303 = NOVALUE;

        /** fwdref.e:398			end for*/
        _0 = _i_63674;
        if (IS_ATOM_INT(_i_63674)) {
            _i_63674 = _i_63674 + 1LL;
            if ((object)((uintptr_t)_i_63674 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63674 = NewDouble((eudouble)_i_63674);
            }
        }
        else {
            _i_63674 = binary_op_a(PLUS, _i_63674, 1LL);
        }
        DeRef(_0);
        goto L14; // [1189] 1148
L15: 
        ;
        DeRef(_i_63674);
    }
    goto L16; // [1194] 1280
L13: 

    /** fwdref.e:400			for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _31308 = _pre_refs_63580 + 1;
    if (_31308 > MAXINT){
        _31308 = NewDouble((eudouble)_31308);
    }
    _2 = (object)SEQ_PTR(_fr_63423);
    _31309 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!IS_ATOM_INT(_31309)){
        _31310 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31309)->dbl));
    }
    else{
        _31310 = (object)*(((s1_ptr)_2)->base + _31309);
    }
    _2 = (object)SEQ_PTR(_31310);
    _31311 = (object)*(((s1_ptr)_2)->base + _ar_sp_63576);
    _31310 = NOVALUE;
    if (IS_SEQUENCE(_31311)){
            _31312 = SEQ_PTR(_31311)->length;
    }
    else {
        _31312 = 1;
    }
    _31311 = NOVALUE;
    {
        object _i_63689;
        Ref(_31308);
        _i_63689 = _31308;
L17: 
        if (binary_op_a(GREATER, _i_63689, _31312)){
            goto L18; // [1222] 1279
        }

        /** fwdref.e:401				forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (object)SEQ_PTR(_fr_63423);
        _31313 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_44active_references_63195);
        if (!IS_ATOM_INT(_31313)){
            _31314 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31313)->dbl));
        }
        else{
            _31314 = (object)*(((s1_ptr)_2)->base + _31313);
        }
        _2 = (object)SEQ_PTR(_31314);
        _31315 = (object)*(((s1_ptr)_2)->base + _ar_sp_63576);
        _31314 = NOVALUE;
        _2 = (object)SEQ_PTR(_31315);
        if (!IS_ATOM_INT(_i_63689)){
            _31316 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_63689)->dbl));
        }
        else{
            _31316 = (object)*(((s1_ptr)_2)->base + _i_63689);
        }
        _31315 = NOVALUE;
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63193 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31316))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31316)->dbl));
        else
        _3 = (object)(_31316 + ((s1_ptr)_2)->base);
        _31319 = _pc_63482 - 1LL;
        if ((object)((uintptr_t)_31319 +(uintptr_t) HIGH_BITS) >= 0){
            _31319 = NewDouble((eudouble)_31319);
        }
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _31320 = (object)*(((s1_ptr)_2)->base + 5LL);
        _31317 = NOVALUE;
        if (IS_ATOM_INT(_31320) && IS_ATOM_INT(_31319)) {
            _31321 = _31320 + _31319;
            if ((object)((uintptr_t)_31321 + (uintptr_t)HIGH_BITS) >= 0){
                _31321 = NewDouble((eudouble)_31321);
            }
        }
        else {
            _31321 = binary_op(PLUS, _31320, _31319);
        }
        _31320 = NOVALUE;
        DeRef(_31319);
        _31319 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31321;
        if( _1 != _31321 ){
            DeRef(_1);
        }
        _31321 = NOVALUE;
        _31317 = NOVALUE;

        /** fwdref.e:402			end for*/
        _0 = _i_63689;
        if (IS_ATOM_INT(_i_63689)) {
            _i_63689 = _i_63689 + 1LL;
            if ((object)((uintptr_t)_i_63689 +(uintptr_t) HIGH_BITS) >= 0){
                _i_63689 = NewDouble((eudouble)_i_63689);
            }
        }
        else {
            _i_63689 = binary_op_a(PLUS, _i_63689, 1LL);
        }
        DeRef(_0);
        goto L17; // [1274] 1229
L18: 
        ;
        DeRef(_i_63689);
    }
L16: 

    /** fwdref.e:405		reset_code()*/
    _44reset_code();

    /** fwdref.e:408		resolved_reference( ref )*/
    _44resolved_reference(_ref_63422);

    /** fwdref.e:409	end procedure*/
    DeRef(_tok_63421);
    DeRef(_fr_63423);
    DeRef(_code_63478);
    DeRef(_name_63488);
    DeRef(_params_63569);
    DeRef(_orig_code_63571);
    DeRef(_orig_linetable_63572);
    DeRef(_old_fwd_params_63595);
    DeRef(_new_code_63640);
    _31257 = NOVALUE;
    DeRef(_31296);
    _31296 = NOVALUE;
    DeRef(_31243);
    _31243 = NOVALUE;
    DeRef(_31233);
    _31233 = NOVALUE;
    _31316 = NOVALUE;
    DeRef(_31207);
    _31207 = NOVALUE;
    _31311 = NOVALUE;
    DeRef(_31261);
    _31261 = NOVALUE;
    _31252 = NOVALUE;
    _31309 = NOVALUE;
    DeRef(_31265);
    _31265 = NOVALUE;
    _31298 = NOVALUE;
    DeRef(_31308);
    _31308 = NOVALUE;
    DeRef(_31259);
    _31259 = NOVALUE;
    DeRef(_31268);
    _31268 = NOVALUE;
    DeRef(_31211);
    _31211 = NOVALUE;
    _31302 = NOVALUE;
    _31313 = NOVALUE;
    DeRef(_31231);
    _31231 = NOVALUE;
    _31297 = NOVALUE;
    _31300 = NOVALUE;
    return;
    ;
}


void _44set_error_info(object _ref_63706)
{
    object _fr_63707 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:412		sequence fr = forward_references[ref]*/
    DeRef(_fr_63707);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63707 = (object)*(((s1_ptr)_2)->base + _ref_63706);
    Ref(_fr_63707);

    /** fwdref.e:413		ThisLine        = fr[FR_THISLINE]*/
    DeRef(_50ThisLine_49590);
    _2 = (object)SEQ_PTR(_fr_63707);
    _50ThisLine_49590 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_50ThisLine_49590);

    /** fwdref.e:414		bp              = fr[FR_BP]*/
    _2 = (object)SEQ_PTR(_fr_63707);
    _50bp_49594 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_50bp_49594)){
        _50bp_49594 = (object)DBL_PTR(_50bp_49594)->dbl;
    }

    /** fwdref.e:415		line_number     = fr[FR_LINE]*/
    _2 = (object)SEQ_PTR(_fr_63707);
    _36line_number_21760 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36line_number_21760)){
        _36line_number_21760 = (object)DBL_PTR(_36line_number_21760)->dbl;
    }

    /** fwdref.e:416		current_file_no = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_63707);
    _36current_file_no_21759 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21759)){
        _36current_file_no_21759 = (object)DBL_PTR(_36current_file_no_21759)->dbl;
    }

    /** fwdref.e:417	end procedure*/
    DeRefDS(_fr_63707);
    return;
    ;
}


void _44patch_forward_variable(object _tok_63720, object _ref_63721)
{
    object _fr_63722 = NOVALUE;
    object _sym_63725 = NOVALUE;
    object _pc_63778 = NOVALUE;
    object _vx_63782 = NOVALUE;
    object _d_63799 = NOVALUE;
    object _param_63809 = NOVALUE;
    object _old_63812 = NOVALUE;
    object _new_63817 = NOVALUE;
    object _31378 = NOVALUE;
    object _31377 = NOVALUE;
    object _31376 = NOVALUE;
    object _31374 = NOVALUE;
    object _31371 = NOVALUE;
    object _31369 = NOVALUE;
    object _31368 = NOVALUE;
    object _31367 = NOVALUE;
    object _31366 = NOVALUE;
    object _31364 = NOVALUE;
    object _31363 = NOVALUE;
    object _31362 = NOVALUE;
    object _31361 = NOVALUE;
    object _31360 = NOVALUE;
    object _31358 = NOVALUE;
    object _31356 = NOVALUE;
    object _31353 = NOVALUE;
    object _31352 = NOVALUE;
    object _31351 = NOVALUE;
    object _31349 = NOVALUE;
    object _31348 = NOVALUE;
    object _31347 = NOVALUE;
    object _31346 = NOVALUE;
    object _31344 = NOVALUE;
    object _31342 = NOVALUE;
    object _31341 = NOVALUE;
    object _31340 = NOVALUE;
    object _31339 = NOVALUE;
    object _31338 = NOVALUE;
    object _31337 = NOVALUE;
    object _31336 = NOVALUE;
    object _31335 = NOVALUE;
    object _31334 = NOVALUE;
    object _31333 = NOVALUE;
    object _31332 = NOVALUE;
    object _31331 = NOVALUE;
    object _31330 = NOVALUE;
    object _31329 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:421		sequence fr = forward_references[ref]*/
    DeRef(_fr_63722);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63722 = (object)*(((s1_ptr)_2)->base + _ref_63721);
    Ref(_fr_63722);

    /** fwdref.e:422		symtab_index sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63720);
    _sym_63725 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_63725)){
        _sym_63725 = (object)DBL_PTR(_sym_63725)->dbl;
    }

    /** fwdref.e:424		if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31329 = (object)*(((s1_ptr)_2)->base + _sym_63725);
    _2 = (object)SEQ_PTR(_31329);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _31330 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _31330 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _31329 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63722);
    _31331 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31330) && IS_ATOM_INT(_31331)) {
        _31332 = (_31330 == _31331);
    }
    else {
        _31332 = binary_op(EQUALS, _31330, _31331);
    }
    _31330 = NOVALUE;
    _31331 = NOVALUE;
    if (IS_ATOM_INT(_31332)) {
        if (_31332 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_31332)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (object)SEQ_PTR(_fr_63722);
    _31334 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31334)) {
        _31335 = (_31334 == _36TopLevelSub_21766);
    }
    else {
        _31335 = binary_op(EQUALS, _31334, _36TopLevelSub_21766);
    }
    _31334 = NOVALUE;
    if (_31335 == 0) {
        DeRef(_31335);
        _31335 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_31335) && DBL_PTR(_31335)->dbl == 0.0){
            DeRef(_31335);
            _31335 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_31335);
        _31335 = NOVALUE;
    }
    DeRef(_31335);
    _31335 = NOVALUE;

    /** fwdref.e:426			return*/
    DeRef(_tok_63720);
    DeRef(_fr_63722);
    DeRef(_31332);
    _31332 = NOVALUE;
    return;
L1: 

    /** fwdref.e:429		if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_fr_63722);
    _31336 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (IS_ATOM_INT(_31336)) {
        _31337 = (_31336 == 18LL);
    }
    else {
        _31337 = binary_op(EQUALS, _31336, 18LL);
    }
    _31336 = NOVALUE;
    if (IS_ATOM_INT(_31337)) {
        if (_31337 == 0) {
            goto L2; // [81] 122
        }
    }
    else {
        if (DBL_PTR(_31337)->dbl == 0.0) {
            goto L2; // [81] 122
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31339 = (object)*(((s1_ptr)_2)->base + _sym_63725);
    _2 = (object)SEQ_PTR(_31339);
    _31340 = (object)*(((s1_ptr)_2)->base + 3LL);
    _31339 = NOVALUE;
    if (IS_ATOM_INT(_31340)) {
        _31341 = (_31340 == 2LL);
    }
    else {
        _31341 = binary_op(EQUALS, _31340, 2LL);
    }
    _31340 = NOVALUE;
    if (_31341 == 0) {
        DeRef(_31341);
        _31341 = NOVALUE;
        goto L2; // [104] 122
    }
    else {
        if (!IS_ATOM_INT(_31341) && DBL_PTR(_31341)->dbl == 0.0){
            DeRef(_31341);
            _31341 = NOVALUE;
            goto L2; // [104] 122
        }
        DeRef(_31341);
        _31341 = NOVALUE;
    }
    DeRef(_31341);
    _31341 = NOVALUE;

    /** fwdref.e:430			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63721);

    /** fwdref.e:431			CompileErr( MAY_NOT_CHANGE_THE_VALUE_OF_A_CONSTANT)*/
    RefDS(_22186);
    _50CompileErr(110LL, _22186, 0LL);
L2: 

    /** fwdref.e:434		if fr[FR_OP] = ASSIGN then*/
    _2 = (object)SEQ_PTR(_fr_63722);
    _31342 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31342, 18LL)){
        _31342 = NOVALUE;
        goto L3; // [130] 170
    }
    _31342 = NOVALUE;

    /** fwdref.e:435			SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63725 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31346 = (object)*(((s1_ptr)_2)->base + _sym_63725);
    _2 = (object)SEQ_PTR(_31346);
    _31347 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31346 = NOVALUE;
    if (IS_ATOM_INT(_31347)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_31347;
             _31348 = MAKE_UINT(tu);
        }
    }
    else {
        _31348 = binary_op(OR_BITS, 2LL, _31347);
    }
    _31347 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31348;
    if( _1 != _31348 ){
        DeRef(_1);
    }
    _31348 = NOVALUE;
    _31344 = NOVALUE;
    goto L4; // [167] 204
L3: 

    /** fwdref.e:437			SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_63725 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31351 = (object)*(((s1_ptr)_2)->base + _sym_63725);
    _2 = (object)SEQ_PTR(_31351);
    _31352 = (object)*(((s1_ptr)_2)->base + 5LL);
    _31351 = NOVALUE;
    if (IS_ATOM_INT(_31352)) {
        {uintptr_t tu;
             tu = (uintptr_t)1LL | (uintptr_t)_31352;
             _31353 = MAKE_UINT(tu);
        }
    }
    else {
        _31353 = binary_op(OR_BITS, 1LL, _31352);
    }
    _31352 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31353;
    if( _1 != _31353 ){
        DeRef(_1);
    }
    _31353 = NOVALUE;
    _31349 = NOVALUE;
L4: 

    /** fwdref.e:440		set_code( ref )*/
    _44set_code(_ref_63721);

    /** fwdref.e:441		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63722);
    _pc_63778 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_63778))
    _pc_63778 = (object)DBL_PTR(_pc_63778)->dbl;

    /** fwdref.e:442		if pc < 1 then*/
    if (_pc_63778 >= 1LL)
    goto L5; // [217] 227

    /** fwdref.e:443			pc = 1*/
    _pc_63778 = 1LL;
L5: 

    /** fwdref.e:445		integer vx = find( -ref, Code, pc )*/
    if ((uintptr_t)_ref_63721 == (uintptr_t)HIGH_BITS){
        _31356 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31356 = - _ref_63721;
    }
    _vx_63782 = find_from(_31356, _36Code_21851, _pc_63778);
    DeRef(_31356);
    _31356 = NOVALUE;

    /** fwdref.e:446		if vx then*/
    if (_vx_63782 == 0)
    {
        goto L6; // [241] 283
    }
    else{
    }

    /** fwdref.e:447			while vx do*/
L7: 
    if (_vx_63782 == 0)
    {
        goto L8; // [249] 277
    }
    else{
    }

    /** fwdref.e:450				Code[vx] = sym*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _vx_63782);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_63725;
    DeRef(_1);

    /** fwdref.e:451				vx = find( -ref, Code, vx )*/
    if ((uintptr_t)_ref_63721 == (uintptr_t)HIGH_BITS){
        _31358 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31358 = - _ref_63721;
    }
    _vx_63782 = find_from(_31358, _36Code_21851, _vx_63782);
    DeRef(_31358);
    _31358 = NOVALUE;

    /** fwdref.e:452			end while*/
    goto L7; // [274] 249
L8: 

    /** fwdref.e:453			resolved_reference( ref )*/
    _44resolved_reference(_ref_63721);
L6: 

    /** fwdref.e:456		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63722);
    _31360 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31361 = IS_SEQUENCE(_31360);
    _31360 = NOVALUE;
    if (_31361 == 0)
    {
        _31361 = NOVALUE;
        goto L9; // [292] 424
    }
    else{
        _31361 = NOVALUE;
    }

    /** fwdref.e:457			for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (object)SEQ_PTR(_fr_63722);
    _31362 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_SEQUENCE(_31362)){
            _31363 = SEQ_PTR(_31362)->length;
    }
    else {
        _31363 = 1;
    }
    _31362 = NOVALUE;
    {
        object _i_63796;
        _i_63796 = 1LL;
LA: 
        if (_i_63796 > _31363){
            goto LB; // [304] 418
        }

        /** fwdref.e:458				object d = fr[FR_DATA][i]*/
        _2 = (object)SEQ_PTR(_fr_63722);
        _31364 = (object)*(((s1_ptr)_2)->base + 12LL);
        DeRef(_d_63799);
        _2 = (object)SEQ_PTR(_31364);
        _d_63799 = (object)*(((s1_ptr)_2)->base + _i_63796);
        Ref(_d_63799);
        _31364 = NOVALUE;

        /** fwdref.e:459				if sequence( d ) and d[1] = PAM_RECORD then*/
        _31366 = IS_SEQUENCE(_d_63799);
        if (_31366 == 0) {
            goto LC; // [326] 407
        }
        _2 = (object)SEQ_PTR(_d_63799);
        _31368 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31368)) {
            _31369 = (_31368 == 1LL);
        }
        else {
            _31369 = binary_op(EQUALS, _31368, 1LL);
        }
        _31368 = NOVALUE;
        if (_31369 == 0) {
            DeRef(_31369);
            _31369 = NOVALUE;
            goto LC; // [341] 407
        }
        else {
            if (!IS_ATOM_INT(_31369) && DBL_PTR(_31369)->dbl == 0.0){
                DeRef(_31369);
                _31369 = NOVALUE;
                goto LC; // [341] 407
            }
            DeRef(_31369);
            _31369 = NOVALUE;
        }
        DeRef(_31369);
        _31369 = NOVALUE;

        /** fwdref.e:461					symtab_index param = d[2]*/
        _2 = (object)SEQ_PTR(_d_63799);
        _param_63809 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_63809)){
            _param_63809 = (object)DBL_PTR(_param_63809)->dbl;
        }

        /** fwdref.e:462					token old = {RECORDED, d[3]}*/
        _2 = (object)SEQ_PTR(_d_63799);
        _31371 = (object)*(((s1_ptr)_2)->base + 3LL);
        Ref(_31371);
        DeRef(_old_63812);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 508LL;
        ((intptr_t *)_2)[2] = _31371;
        _old_63812 = MAKE_SEQ(_1);
        _31371 = NOVALUE;

        /** fwdref.e:463					token new = {VARIABLE, sym}*/
        DeRefi(_new_63817);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -100LL;
        ((intptr_t *)_2)[2] = _sym_63725;
        _new_63817 = MAKE_SEQ(_1);

        /** fwdref.e:464					SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_param_63809 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _31376 = (object)*(((s1_ptr)_2)->base + _param_63809);
        _2 = (object)SEQ_PTR(_31376);
        if (!IS_ATOM_INT(_36S_CODE_21408)){
            _31377 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
        }
        else{
            _31377 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
        }
        _31376 = NOVALUE;
        RefDS(_old_63812);
        Ref(_31377);
        RefDS(_new_63817);
        _31378 = _16find_replace(_old_63812, _31377, _new_63817, 0LL);
        _31377 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21408))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31378;
        if( _1 != _31378 ){
            DeRef(_1);
        }
        _31378 = NOVALUE;
        _31374 = NOVALUE;
LC: 
        DeRef(_old_63812);
        _old_63812 = NOVALUE;
        DeRefi(_new_63817);
        _new_63817 = NOVALUE;
        DeRef(_d_63799);
        _d_63799 = NOVALUE;

        /** fwdref.e:466			end for*/
        _i_63796 = _i_63796 + 1LL;
        goto LA; // [413] 311
LB: 
        ;
    }

    /** fwdref.e:467			resolved_reference( ref )*/
    _44resolved_reference(_ref_63721);
L9: 

    /** fwdref.e:469		reset_code()*/
    _44reset_code();

    /** fwdref.e:470	end procedure*/
    DeRef(_tok_63720);
    DeRef(_fr_63722);
    DeRef(_31337);
    _31337 = NOVALUE;
    DeRef(_31332);
    _31332 = NOVALUE;
    _31362 = NOVALUE;
    return;
    ;
}


void _44patch_forward_init_check(object _tok_63833, object _ref_63834)
{
    object _fr_63835 = NOVALUE;
    object _31386 = NOVALUE;
    object _31385 = NOVALUE;
    object _31384 = NOVALUE;
    object _31382 = NOVALUE;
    object _31381 = NOVALUE;
    object _31380 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:474		sequence fr = forward_references[ref]*/
    DeRef(_fr_63835);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63835 = (object)*(((s1_ptr)_2)->base + _ref_63834);
    Ref(_fr_63835);

    /** fwdref.e:475		set_code( ref )*/
    _44set_code(_ref_63834);

    /** fwdref.e:476		if sequence( fr[FR_DATA] ) then*/
    _2 = (object)SEQ_PTR(_fr_63835);
    _31380 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31381 = IS_SEQUENCE(_31380);
    _31380 = NOVALUE;
    if (_31381 == 0)
    {
        _31381 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _31381 = NOVALUE;
    }

    /** fwdref.e:478			resolved_reference( ref )*/
    _44resolved_reference(_ref_63834);
    goto L2; // [35] 85
L1: 

    /** fwdref.e:479		elsif fr[FR_PC] > 0 then*/
    _2 = (object)SEQ_PTR(_fr_63835);
    _31382 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(LESSEQ, _31382, 0LL)){
        _31382 = NOVALUE;
        goto L3; // [44] 78
    }
    _31382 = NOVALUE;

    /** fwdref.e:480			Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_fr_63835);
    _31384 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_31384)) {
        _31385 = _31384 + 1;
        if (_31385 > MAXINT){
            _31385 = NewDouble((eudouble)_31385);
        }
    }
    else
    _31385 = binary_op(PLUS, 1, _31384);
    _31384 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_63833);
    _31386 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31386);
    _2 = (object)SEQ_PTR(_36Code_21851);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36Code_21851 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31385))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31385)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _31385);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31386;
    if( _1 != _31386 ){
        DeRef(_1);
    }
    _31386 = NOVALUE;

    /** fwdref.e:481			resolved_reference( ref )*/
    _44resolved_reference(_ref_63834);
    goto L2; // [75] 85
L3: 

    /** fwdref.e:483			forward_error( tok, ref )*/
    Ref(_tok_63833);
    _44forward_error(_tok_63833, _ref_63834);
L2: 

    /** fwdref.e:485		reset_code()*/
    _44reset_code();

    /** fwdref.e:486	end procedure*/
    DeRef(_tok_63833);
    DeRef(_fr_63835);
    DeRef(_31385);
    _31385 = NOVALUE;
    return;
    ;
}


object _44expected_name(object _id_63852)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_63852)) {
        _1 = (object)(DBL_PTR(_id_63852)->dbl);
        DeRefDS(_id_63852);
        _id_63852 = _1;
    }

    /** fwdref.e:491		switch id with fallthru do*/
    _0 = _id_63852;
    switch ( _0 ){ 

        /** fwdref.e:492			case PROC then*/
        case 27:
        case 195:

        /** fwdref.e:494				return "a procedure"*/
        RefDS(_26513);
        return _26513;

        /** fwdref.e:496			case FUNC then*/
        case 501:
        case 196:

        /** fwdref.e:498				return "a function"*/
        RefDS(_26459);
        return _26459;

        /** fwdref.e:500			case VARIABLE then*/
        case -100:

        /** fwdref.e:501				return "a variable, constant or enum"*/
        RefDS(_31389);
        return _31389;

        /** fwdref.e:502			case else*/
        default:

        /** fwdref.e:503				return "something"*/
        RefDS(_31390);
        return _31390;
    ;}    ;
}


void _44patch_forward_type(object _tok_63869, object _ref_63870)
{
    object _fr_63871 = NOVALUE;
    object _syms_63873 = NOVALUE;
    object _31402 = NOVALUE;
    object _31401 = NOVALUE;
    object _31399 = NOVALUE;
    object _31398 = NOVALUE;
    object _31397 = NOVALUE;
    object _31395 = NOVALUE;
    object _31394 = NOVALUE;
    object _31393 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:510		sequence fr = forward_references[ref]*/
    DeRef(_fr_63871);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63871 = (object)*(((s1_ptr)_2)->base + _ref_63870);
    Ref(_fr_63871);

    /** fwdref.e:511		sequence syms = fr[FR_DATA]*/
    DeRef(_syms_63873);
    _2 = (object)SEQ_PTR(_fr_63871);
    _syms_63873 = (object)*(((s1_ptr)_2)->base + 12LL);
    Ref(_syms_63873);

    /** fwdref.e:512		for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_63873)){
            _31393 = SEQ_PTR(_syms_63873)->length;
    }
    else {
        _31393 = 1;
    }
    {
        object _i_63876;
        _i_63876 = 2LL;
L1: 
        if (_i_63876 > _31393){
            goto L2; // [26] 102
        }

        /** fwdref.e:513			SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (object)SEQ_PTR(_syms_63873);
        _31394 = (object)*(((s1_ptr)_2)->base + _i_63876);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31394))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31394)->dbl));
        else
        _3 = (object)(_31394 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63869);
        _31397 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31397);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 15LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31397;
        if( _1 != _31397 ){
            DeRef(_1);
        }
        _31397 = NOVALUE;
        _31395 = NOVALUE;

        /** fwdref.e:514			if TRANSLATE then*/
        if (_36TRANSLATE_21361 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** fwdref.e:515				SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (object)SEQ_PTR(_syms_63873);
        _31398 = (object)*(((s1_ptr)_2)->base + _i_63876);
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31398))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31398)->dbl));
        else
        _3 = (object)(_31398 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_tok_63869);
        _31401 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_31401);
        _31402 = _45CompileType(_31401);
        _31401 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 36LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31402;
        if( _1 != _31402 ){
            DeRef(_1);
        }
        _31402 = NOVALUE;
        _31399 = NOVALUE;
L3: 

        /** fwdref.e:517		end for*/
        _i_63876 = _i_63876 + 1LL;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** fwdref.e:518		resolved_reference( ref )*/
    _44resolved_reference(_ref_63870);

    /** fwdref.e:519	end procedure*/
    DeRef(_tok_63869);
    DeRef(_fr_63871);
    DeRef(_syms_63873);
    _31394 = NOVALUE;
    _31398 = NOVALUE;
    return;
    ;
}


void _44patch_forward_case(object _tok_63899, object _ref_63900)
{
    object _fr_63901 = NOVALUE;
    object _switch_pc_63903 = NOVALUE;
    object _case_sym_63906 = NOVALUE;
    object _case_values_63935 = NOVALUE;
    object _cx_63940 = NOVALUE;
    object _negative_63948 = NOVALUE;
    object _31440 = NOVALUE;
    object _31439 = NOVALUE;
    object _31438 = NOVALUE;
    object _31437 = NOVALUE;
    object _31436 = NOVALUE;
    object _31435 = NOVALUE;
    object _31433 = NOVALUE;
    object _31431 = NOVALUE;
    object _31430 = NOVALUE;
    object _31428 = NOVALUE;
    object _31427 = NOVALUE;
    object _31424 = NOVALUE;
    object _31422 = NOVALUE;
    object _31421 = NOVALUE;
    object _31420 = NOVALUE;
    object _31419 = NOVALUE;
    object _31418 = NOVALUE;
    object _31417 = NOVALUE;
    object _31416 = NOVALUE;
    object _31415 = NOVALUE;
    object _31414 = NOVALUE;
    object _31412 = NOVALUE;
    object _31411 = NOVALUE;
    object _31410 = NOVALUE;
    object _31409 = NOVALUE;
    object _31407 = NOVALUE;
    object _31405 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:522		sequence fr = forward_references[ref]*/
    DeRef(_fr_63901);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63901 = (object)*(((s1_ptr)_2)->base + _ref_63900);
    Ref(_fr_63901);

    /** fwdref.e:524		integer switch_pc = fr[FR_DATA]*/
    _2 = (object)SEQ_PTR(_fr_63901);
    _switch_pc_63903 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_switch_pc_63903))
    _switch_pc_63903 = (object)DBL_PTR(_switch_pc_63903)->dbl;

    /** fwdref.e:527		if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_fr_63901);
    _31405 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (binary_op_a(NOTEQ, _31405, _36TopLevelSub_21766)){
        _31405 = NOVALUE;
        goto L1; // [27] 48
    }
    _31405 = NOVALUE;

    /** fwdref.e:528			case_sym = Code[switch_pc + 2]*/
    _31407 = _switch_pc_63903 + 2LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _case_sym_63906 = (object)*(((s1_ptr)_2)->base + _31407);
    if (!IS_ATOM_INT(_case_sym_63906)){
        _case_sym_63906 = (object)DBL_PTR(_case_sym_63906)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** fwdref.e:530			case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (object)SEQ_PTR(_fr_63901);
    _31409 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31409)){
        _31410 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31409)->dbl));
    }
    else{
        _31410 = (object)*(((s1_ptr)_2)->base + _31409);
    }
    _2 = (object)SEQ_PTR(_31410);
    if (!IS_ATOM_INT(_36S_CODE_21408)){
        _31411 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    }
    else{
        _31411 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
    }
    _31410 = NOVALUE;
    _31412 = _switch_pc_63903 + 2LL;
    _2 = (object)SEQ_PTR(_31411);
    _case_sym_63906 = (object)*(((s1_ptr)_2)->base + _31412);
    if (!IS_ATOM_INT(_case_sym_63906)){
        _case_sym_63906 = (object)DBL_PTR(_case_sym_63906)->dbl;
    }
    _31411 = NOVALUE;
L2: 

    /** fwdref.e:533		if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (object)SEQ_PTR(_tok_63899);
    _31414 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31414)){
        _31415 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31414)->dbl));
    }
    else{
        _31415 = (object)*(((s1_ptr)_2)->base + _31414);
    }
    _2 = (object)SEQ_PTR(_31415);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _31416 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _31416 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _31415 = NOVALUE;
    _2 = (object)SEQ_PTR(_fr_63901);
    _31417 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_31416) && IS_ATOM_INT(_31417)) {
        _31418 = (_31416 == _31417);
    }
    else {
        _31418 = binary_op(EQUALS, _31416, _31417);
    }
    _31416 = NOVALUE;
    _31417 = NOVALUE;
    if (IS_ATOM_INT(_31418)) {
        if (_31418 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_31418)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (object)SEQ_PTR(_fr_63901);
    _31420 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_31420)) {
        _31421 = (_31420 == _36TopLevelSub_21766);
    }
    else {
        _31421 = binary_op(EQUALS, _31420, _36TopLevelSub_21766);
    }
    _31420 = NOVALUE;
    if (_31421 == 0) {
        DeRef(_31421);
        _31421 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_31421) && DBL_PTR(_31421)->dbl == 0.0){
            DeRef(_31421);
            _31421 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_31421);
        _31421 = NOVALUE;
    }
    DeRef(_31421);
    _31421 = NOVALUE;

    /** fwdref.e:534			return*/
    DeRef(_tok_63899);
    DeRef(_fr_63901);
    DeRef(_case_values_63935);
    DeRef(_31412);
    _31412 = NOVALUE;
    _31409 = NOVALUE;
    DeRef(_31407);
    _31407 = NOVALUE;
    _31414 = NOVALUE;
    DeRef(_31418);
    _31418 = NOVALUE;
    return;
L3: 

    /** fwdref.e:537		sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31422 = (object)*(((s1_ptr)_2)->base + _case_sym_63906);
    DeRef(_case_values_63935);
    _2 = (object)SEQ_PTR(_31422);
    _case_values_63935 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_case_values_63935);
    _31422 = NOVALUE;

    /** fwdref.e:539		integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ref_63900;
    _31424 = MAKE_SEQ(_1);
    _cx_63940 = find_from(_31424, _case_values_63935, 1LL);
    DeRefDS(_31424);
    _31424 = NOVALUE;

    /** fwdref.e:540		if not cx then*/
    if (_cx_63940 != 0)
    goto L4; // [160] 178

    /** fwdref.e:541			cx = find( { -ref }, case_values )*/
    if ((uintptr_t)_ref_63900 == (uintptr_t)HIGH_BITS){
        _31427 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31427 = - _ref_63900;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31427;
    _31428 = MAKE_SEQ(_1);
    _31427 = NOVALUE;
    _cx_63940 = find_from(_31428, _case_values_63935, 1LL);
    DeRefDS(_31428);
    _31428 = NOVALUE;
L4: 

    /** fwdref.e:544	 	ifdef DEBUG then	*/

    /** fwdref.e:551		integer negative = 0*/
    _negative_63948 = 0LL;

    /** fwdref.e:552		if case_values[cx][1] < 0 then*/
    _2 = (object)SEQ_PTR(_case_values_63935);
    _31430 = (object)*(((s1_ptr)_2)->base + _cx_63940);
    _2 = (object)SEQ_PTR(_31430);
    _31431 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31430 = NOVALUE;
    if (binary_op_a(GREATEREQ, _31431, 0LL)){
        _31431 = NOVALUE;
        goto L5; // [195] 224
    }
    _31431 = NOVALUE;

    /** fwdref.e:553			negative = 1*/
    _negative_63948 = 1LL;

    /** fwdref.e:554			case_values[cx][1] *= -1*/
    _2 = (object)SEQ_PTR(_case_values_63935);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63935 = MAKE_SEQ(_2);
    }
    _3 = (object)(_cx_63940 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31435 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31433 = NOVALUE;
    if (IS_ATOM_INT(_31435)) {
        {
            int128_t p128 = (int128_t)_31435 * (int128_t)-1LL;
            if( p128 != (int128_t)(_31436 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _31436 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _31436 = binary_op(MULTIPLY, _31435, -1LL);
    }
    _31435 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31436;
    if( _1 != _31436 ){
        DeRef(_1);
    }
    _31436 = NOVALUE;
    _31433 = NOVALUE;
L5: 

    /** fwdref.e:557		if negative then*/
    if (_negative_63948 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** fwdref.e:558			case_values[cx] = - tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63899);
    _31437 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_31437)) {
        if ((uintptr_t)_31437 == (uintptr_t)HIGH_BITS){
            _31438 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _31438 = - _31437;
        }
    }
    else {
        _31438 = unary_op(UMINUS, _31437);
    }
    _31437 = NOVALUE;
    _2 = (object)SEQ_PTR(_case_values_63935);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63935 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63940);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31438;
    if( _1 != _31438 ){
        DeRef(_1);
    }
    _31438 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** fwdref.e:560			case_values[cx] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63899);
    _31439 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_31439);
    _2 = (object)SEQ_PTR(_case_values_63935);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _case_values_63935 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _cx_63940);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31439;
    if( _1 != _31439 ){
        DeRef(_1);
    }
    _31439 = NOVALUE;
L7: 

    /** fwdref.e:562		SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_case_sym_63906 + ((s1_ptr)_2)->base);
    RefDS(_case_values_63935);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _case_values_63935;
    DeRef(_1);
    _31440 = NOVALUE;

    /** fwdref.e:563		resolved_reference( ref )*/
    _44resolved_reference(_ref_63900);

    /** fwdref.e:564	end procedure*/
    DeRef(_tok_63899);
    DeRef(_fr_63901);
    DeRefDS(_case_values_63935);
    DeRef(_31412);
    _31412 = NOVALUE;
    _31409 = NOVALUE;
    DeRef(_31407);
    _31407 = NOVALUE;
    _31414 = NOVALUE;
    DeRef(_31418);
    _31418 = NOVALUE;
    return;
    ;
}


void _44patch_forward_type_check(object _tok_63971, object _ref_63972)
{
    object _fr_63973 = NOVALUE;
    object _which_type_63976 = NOVALUE;
    object _var_63978 = NOVALUE;
    object _pc_64011 = NOVALUE;
    object _with_type_check_64013 = NOVALUE;
    object _c_64043 = NOVALUE;
    object _subprog_inlined_insert_code_at_332_64052 = NOVALUE;
    object _code_inlined_insert_code_at_329_64051 = NOVALUE;
    object _subprog_inlined_insert_code_at_415_64068 = NOVALUE;
    object _code_inlined_insert_code_at_412_64067 = NOVALUE;
    object _subprog_inlined_insert_code_at_477_64078 = NOVALUE;
    object _code_inlined_insert_code_at_474_64077 = NOVALUE;
    object _subprog_inlined_insert_code_at_539_64088 = NOVALUE;
    object _code_inlined_insert_code_at_536_64087 = NOVALUE;
    object _start_pc_64095 = NOVALUE;
    object _subprog_inlined_insert_code_at_647_64112 = NOVALUE;
    object _code_inlined_insert_code_at_644_64111 = NOVALUE;
    object _c_64115 = NOVALUE;
    object _subprog_inlined_insert_code_at_741_64131 = NOVALUE;
    object _code_inlined_insert_code_at_738_64130 = NOVALUE;
    object _start_pc_64142 = NOVALUE;
    object _subprog_inlined_insert_code_at_886_64162 = NOVALUE;
    object _code_inlined_insert_code_at_883_64161 = NOVALUE;
    object _subprog_inlined_insert_code_at_987_64183 = NOVALUE;
    object _code_inlined_insert_code_at_984_64182 = NOVALUE;
    object _31530 = NOVALUE;
    object _31529 = NOVALUE;
    object _31528 = NOVALUE;
    object _31527 = NOVALUE;
    object _31526 = NOVALUE;
    object _31525 = NOVALUE;
    object _31524 = NOVALUE;
    object _31522 = NOVALUE;
    object _31520 = NOVALUE;
    object _31519 = NOVALUE;
    object _31518 = NOVALUE;
    object _31517 = NOVALUE;
    object _31516 = NOVALUE;
    object _31515 = NOVALUE;
    object _31514 = NOVALUE;
    object _31512 = NOVALUE;
    object _31511 = NOVALUE;
    object _31510 = NOVALUE;
    object _31509 = NOVALUE;
    object _31508 = NOVALUE;
    object _31507 = NOVALUE;
    object _31505 = NOVALUE;
    object _31504 = NOVALUE;
    object _31503 = NOVALUE;
    object _31502 = NOVALUE;
    object _31500 = NOVALUE;
    object _31499 = NOVALUE;
    object _31496 = NOVALUE;
    object _31495 = NOVALUE;
    object _31493 = NOVALUE;
    object _31492 = NOVALUE;
    object _31491 = NOVALUE;
    object _31490 = NOVALUE;
    object _31489 = NOVALUE;
    object _31488 = NOVALUE;
    object _31486 = NOVALUE;
    object _31485 = NOVALUE;
    object _31482 = NOVALUE;
    object _31481 = NOVALUE;
    object _31478 = NOVALUE;
    object _31477 = NOVALUE;
    object _31473 = NOVALUE;
    object _31472 = NOVALUE;
    object _31470 = NOVALUE;
    object _31469 = NOVALUE;
    object _31467 = NOVALUE;
    object _31466 = NOVALUE;
    object _31463 = NOVALUE;
    object _31460 = NOVALUE;
    object _31458 = NOVALUE;
    object _31455 = NOVALUE;
    object _31454 = NOVALUE;
    object _31451 = NOVALUE;
    object _31446 = NOVALUE;
    object _31445 = NOVALUE;
    object _31443 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:568		sequence fr = forward_references[ref]*/
    DeRef(_fr_63973);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _fr_63973 = (object)*(((s1_ptr)_2)->base + _ref_63972);
    Ref(_fr_63973);

    /** fwdref.e:572		if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_fr_63973);
    _31443 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31443, 197LL)){
        _31443 = NOVALUE;
        goto L1; // [21] 86
    }
    _31443 = NOVALUE;

    /** fwdref.e:573			which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (object)SEQ_PTR(_tok_63971);
    _31445 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31445)){
        _31446 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31445)->dbl));
    }
    else{
        _31446 = (object)*(((s1_ptr)_2)->base + _31445);
    }
    _2 = (object)SEQ_PTR(_31446);
    _which_type_63976 = (object)*(((s1_ptr)_2)->base + 15LL);
    if (!IS_ATOM_INT(_which_type_63976)){
        _which_type_63976 = (object)DBL_PTR(_which_type_63976)->dbl;
    }
    _31446 = NOVALUE;

    /** fwdref.e:574			if not which_type then*/
    if (_which_type_63976 != 0)
    goto L2; // [49] 72

    /** fwdref.e:575				which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63971);
    _which_type_63976 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_63976)){
        _which_type_63976 = (object)DBL_PTR(_which_type_63976)->dbl;
    }

    /** fwdref.e:576				var = 0*/
    _var_63978 = 0LL;
    goto L3; // [69] 144
L2: 

    /** fwdref.e:578				var = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63971);
    _var_63978 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_var_63978)){
        _var_63978 = (object)DBL_PTR(_var_63978)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** fwdref.e:582		elsif fr[FR_OP] = TYPE then*/
    _2 = (object)SEQ_PTR(_fr_63973);
    _31451 = (object)*(((s1_ptr)_2)->base + 10LL);
    if (binary_op_a(NOTEQ, _31451, 504LL)){
        _31451 = NOVALUE;
        goto L4; // [94] 118
    }
    _31451 = NOVALUE;

    /** fwdref.e:583			which_type = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_63971);
    _which_type_63976 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_which_type_63976)){
        _which_type_63976 = (object)DBL_PTR(_which_type_63976)->dbl;
    }

    /** fwdref.e:584			var = 0*/
    _var_63978 = 0LL;
    goto L3; // [115] 144
L4: 

    /** fwdref.e:587			prep_forward_error( ref )*/
    _44prep_forward_error(_ref_63972);

    /** fwdref.e:588			InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (object)SEQ_PTR(_fr_63973);
    _31454 = (object)*(((s1_ptr)_2)->base + 10LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 65LL;
    ((intptr_t*)_2)[2] = 197LL;
    Ref(_31454);
    ((intptr_t*)_2)[3] = _31454;
    _31455 = MAKE_SEQ(_1);
    _31454 = NOVALUE;
    _50InternalErr(262LL, _31455);
    _31455 = NOVALUE;
L3: 

    /** fwdref.e:591		if which_type < 0 then*/
    if (_which_type_63976 >= 0LL)
    goto L5; // [148] 158

    /** fwdref.e:593			return*/
    DeRef(_tok_63971);
    DeRef(_fr_63973);
    _31445 = NOVALUE;
    return;
L5: 

    /** fwdref.e:596		set_code( ref )*/
    _44set_code(_ref_63972);

    /** fwdref.e:598		integer pc = fr[FR_PC]*/
    _2 = (object)SEQ_PTR(_fr_63973);
    _pc_64011 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_pc_64011))
    _pc_64011 = (object)DBL_PTR(_pc_64011)->dbl;

    /** fwdref.e:599		integer with_type_check = Code[pc + 2]*/
    _31458 = _pc_64011 + 2LL;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _with_type_check_64013 = (object)*(((s1_ptr)_2)->base + _31458);
    if (!IS_ATOM_INT(_with_type_check_64013)){
        _with_type_check_64013 = (object)DBL_PTR(_with_type_check_64013)->dbl;
    }

    /** fwdref.e:601		if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (object)SEQ_PTR(_36Code_21851);
    _31460 = (object)*(((s1_ptr)_2)->base + _pc_64011);
    if (binary_op_a(EQUALS, _31460, 197LL)){
        _31460 = NOVALUE;
        goto L6; // [193] 204
    }
    _31460 = NOVALUE;

    /** fwdref.e:602			forward_error( tok, ref )*/
    Ref(_tok_63971);
    _44forward_error(_tok_63971, _ref_63972);
L6: 

    /** fwdref.e:604		if not var then*/
    if (_var_63978 != 0)
    goto L7; // [208] 226

    /** fwdref.e:606			var = Code[pc+1]*/
    _31463 = _pc_64011 + 1;
    _2 = (object)SEQ_PTR(_36Code_21851);
    _var_63978 = (object)*(((s1_ptr)_2)->base + _31463);
    if (!IS_ATOM_INT(_var_63978)){
        _var_63978 = (object)DBL_PTR(_var_63978)->dbl;
    }
L7: 

    /** fwdref.e:609		if var < 0 then*/
    if (_var_63978 >= 0LL)
    goto L8; // [228] 238

    /** fwdref.e:611			return*/
    DeRef(_tok_63971);
    DeRef(_fr_63973);
    _31445 = NOVALUE;
    DeRef(_31463);
    _31463 = NOVALUE;
    DeRef(_31458);
    _31458 = NOVALUE;
    return;
L8: 

    /** fwdref.e:615		replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _31466 = _pc_64011 + 2LL;
    if ((object)((uintptr_t)_31466 + (uintptr_t)HIGH_BITS) >= 0){
        _31466 = NewDouble((eudouble)_31466);
    }
    _2 = (object)SEQ_PTR(_fr_63973);
    _31467 = (object)*(((s1_ptr)_2)->base + 4LL);
    RefDS(_22186);
    Ref(_31467);
    _44replace_code(_22186, _pc_64011, _31466, _31467);
    _31466 = NOVALUE;
    _31467 = NOVALUE;

    /** fwdref.e:617		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** fwdref.e:618			if with_type_check then*/
    if (_with_type_check_64013 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** fwdref.e:619				if which_type != object_type then*/
    if (_which_type_63976 == _54object_type_47132)
    goto LA; // [270] 771

    /** fwdref.e:620					if SymTab[which_type][S_EFFECT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31469 = (object)*(((s1_ptr)_2)->base + _which_type_63976);
    _2 = (object)SEQ_PTR(_31469);
    _31470 = (object)*(((s1_ptr)_2)->base + 23LL);
    _31469 = NOVALUE;
    if (_31470 == 0) {
        _31470 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_31470) && DBL_PTR(_31470)->dbl == 0.0){
            _31470 = NOVALUE;
            goto LB; // [288] 357
        }
        _31470 = NOVALUE;
    }
    _31470 = NOVALUE;

    /** fwdref.e:622						integer c = NewTempSym()*/
    _c_64043 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_64043)) {
        _1 = (object)(DBL_PTR(_c_64043)->dbl);
        DeRefDS(_c_64043);
        _c_64043 = _1;
    }

    /** fwdref.e:623						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_63976;
    ((intptr_t*)_2)[3] = _var_63978;
    ((intptr_t*)_2)[4] = _c_64043;
    ((intptr_t*)_2)[5] = 65LL;
    _31472 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31473 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_329_64051);
    _code_inlined_insert_code_at_329_64051 = _31472;
    _31472 = NOVALUE;
    Ref(_31473);
    DeRef(_subprog_inlined_insert_code_at_332_64052);
    _subprog_inlined_insert_code_at_332_64052 = _31473;
    _31473 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_64052)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_332_64052)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_64052);
        _subprog_inlined_insert_code_at_332_64052 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_332_64052;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_64051);
    _66insert_code(_code_inlined_insert_code_at_329_64051, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_64051);
    _code_inlined_insert_code_at_329_64051 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_64052);
    _subprog_inlined_insert_code_at_332_64052 = NOVALUE;

    /** fwdref.e:624						pc += 5*/
    _pc_64011 = _pc_64011 + 5LL;
LB: 
    goto LA; // [361] 771
L9: 

    /** fwdref.e:630			if with_type_check then*/
    if (_with_type_check_64013 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** fwdref.e:632				if which_type = object_type then*/
    if (_which_type_63976 != _54object_type_47132)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** fwdref.e:636					if which_type = integer_type then*/
    if (_which_type_63976 != _54integer_type_47138)
    goto L10; // [384] 442

    /** fwdref.e:637						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63978;
    _31477 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31478 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_412_64067);
    _code_inlined_insert_code_at_412_64067 = _31477;
    _31477 = NOVALUE;
    Ref(_31478);
    DeRef(_subprog_inlined_insert_code_at_415_64068);
    _subprog_inlined_insert_code_at_415_64068 = _31478;
    _31478 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_64068)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_415_64068)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_64068);
        _subprog_inlined_insert_code_at_415_64068 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_415_64068;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_64067);
    _66insert_code(_code_inlined_insert_code_at_412_64067, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_64067);
    _code_inlined_insert_code_at_412_64067 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_64068);
    _subprog_inlined_insert_code_at_415_64068 = NOVALUE;

    /** fwdref.e:638						pc += 2*/
    _pc_64011 = _pc_64011 + 2LL;
    goto L12; // [439] 768
L10: 

    /** fwdref.e:640					elsif which_type = sequence_type then*/
    if (_which_type_63976 != _54sequence_type_47136)
    goto L13; // [446] 504

    /** fwdref.e:641						insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_63978;
    _31481 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31482 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_474_64077);
    _code_inlined_insert_code_at_474_64077 = _31481;
    _31481 = NOVALUE;
    Ref(_31482);
    DeRef(_subprog_inlined_insert_code_at_477_64078);
    _subprog_inlined_insert_code_at_477_64078 = _31482;
    _31482 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_64078)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_477_64078)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_64078);
        _subprog_inlined_insert_code_at_477_64078 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_477_64078;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_64077);
    _66insert_code(_code_inlined_insert_code_at_474_64077, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_64077);
    _code_inlined_insert_code_at_474_64077 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_64078);
    _subprog_inlined_insert_code_at_477_64078 = NOVALUE;

    /** fwdref.e:642						pc += 2*/
    _pc_64011 = _pc_64011 + 2LL;
    goto L12; // [501] 768
L13: 

    /** fwdref.e:644					elsif which_type = atom_type then*/
    if (_which_type_63976 != _54atom_type_47134)
    goto L15; // [508] 566

    /** fwdref.e:645						insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 101LL;
    ((intptr_t *)_2)[2] = _var_63978;
    _31485 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31486 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_536_64087);
    _code_inlined_insert_code_at_536_64087 = _31485;
    _31485 = NOVALUE;
    Ref(_31486);
    DeRef(_subprog_inlined_insert_code_at_539_64088);
    _subprog_inlined_insert_code_at_539_64088 = _31486;
    _31486 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_64088)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_539_64088)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_64088);
        _subprog_inlined_insert_code_at_539_64088 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_539_64088;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_64087);
    _66insert_code(_code_inlined_insert_code_at_536_64087, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_64087);
    _code_inlined_insert_code_at_536_64087 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_64088);
    _subprog_inlined_insert_code_at_539_64088 = NOVALUE;

    /** fwdref.e:646						pc += 2*/
    _pc_64011 = _pc_64011 + 2LL;
    goto L12; // [563] 768
L15: 

    /** fwdref.e:648					elsif SymTab[which_type][S_NEXT] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31488 = (object)*(((s1_ptr)_2)->base + _which_type_63976);
    _2 = (object)SEQ_PTR(_31488);
    _31489 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31488 = NOVALUE;
    if (_31489 == 0) {
        _31489 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_31489) && DBL_PTR(_31489)->dbl == 0.0){
            _31489 = NOVALUE;
            goto L17; // [580] 765
        }
        _31489 = NOVALUE;
    }
    _31489 = NOVALUE;

    /** fwdref.e:649						integer start_pc = pc*/
    _start_pc_64095 = _pc_64011;

    /** fwdref.e:652						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31490 = (object)*(((s1_ptr)_2)->base + _which_type_63976);
    _2 = (object)SEQ_PTR(_31490);
    _31491 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31490 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31491)){
        _31492 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31491)->dbl));
    }
    else{
        _31492 = (object)*(((s1_ptr)_2)->base + _31491);
    }
    _2 = (object)SEQ_PTR(_31492);
    _31493 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31492 = NOVALUE;
    if (binary_op_a(NOTEQ, _31493, _54integer_type_47138)){
        _31493 = NOVALUE;
        goto L18; // [616] 672
    }
    _31493 = NOVALUE;

    /** fwdref.e:654							insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63978;
    _31495 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31496 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_644_64111);
    _code_inlined_insert_code_at_644_64111 = _31495;
    _31495 = NOVALUE;
    Ref(_31496);
    DeRef(_subprog_inlined_insert_code_at_647_64112);
    _subprog_inlined_insert_code_at_647_64112 = _31496;
    _31496 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_64112)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_647_64112)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_64112);
        _subprog_inlined_insert_code_at_647_64112 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_647_64112;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_64111);
    _66insert_code(_code_inlined_insert_code_at_644_64111, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_64111);
    _code_inlined_insert_code_at_644_64111 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_64112);
    _subprog_inlined_insert_code_at_647_64112 = NOVALUE;

    /** fwdref.e:656							pc += 2*/
    _pc_64011 = _pc_64011 + 2LL;
L18: 

    /** fwdref.e:658						symtab_index c = NewTempSym()*/
    _c_64115 = _54NewTempSym(0LL);
    if (!IS_ATOM_INT(_c_64115)) {
        _1 = (object)(DBL_PTR(_c_64115)->dbl);
        DeRefDS(_c_64115);
        _c_64115 = _1;
    }

    /** fwdref.e:659						SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_fr_63973);
    _31499 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_31499))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31499)->dbl));
    else
    _3 = (object)(_31499 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456)){
        _31502 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    }
    else{
        _31502 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    }
    _31500 = NOVALUE;
    if (IS_ATOM_INT(_31502)) {
        _31503 = _31502 + 1;
        if (_31503 > MAXINT){
            _31503 = NewDouble((eudouble)_31503);
        }
    }
    else
    _31503 = binary_op(PLUS, 1, _31502);
    _31502 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21456))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21456)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21456);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31503;
    if( _1 != _31503 ){
        DeRef(_1);
    }
    _31503 = NOVALUE;
    _31500 = NOVALUE;

    /** fwdref.e:660						insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 27LL;
    ((intptr_t*)_2)[2] = _which_type_63976;
    ((intptr_t*)_2)[3] = _var_63978;
    ((intptr_t*)_2)[4] = _c_64115;
    ((intptr_t*)_2)[5] = 65LL;
    _31504 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31505 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_738_64130);
    _code_inlined_insert_code_at_738_64130 = _31504;
    _31504 = NOVALUE;
    Ref(_31505);
    DeRef(_subprog_inlined_insert_code_at_741_64131);
    _subprog_inlined_insert_code_at_741_64131 = _31505;
    _31505 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_64131)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_741_64131)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_64131);
        _subprog_inlined_insert_code_at_741_64131 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_741_64131;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_64130);
    _66insert_code(_code_inlined_insert_code_at_738_64130, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_64130);
    _code_inlined_insert_code_at_738_64130 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_64131);
    _subprog_inlined_insert_code_at_741_64131 = NOVALUE;

    /** fwdref.e:661						pc += 4*/
    _pc_64011 = _pc_64011 + 4LL;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** fwdref.e:668		if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_36TRANSLATE_21361 != 0) {
        _31507 = 1;
        goto L1B; // [775] 786
    }
    _31508 = (_with_type_check_64013 == 0);
    _31507 = (_31508 != 0);
L1B: 
    if (_31507 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31510 = (object)*(((s1_ptr)_2)->base + _which_type_63976);
    _2 = (object)SEQ_PTR(_31510);
    _31511 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31510 = NOVALUE;
    if (_31511 == 0) {
        _31511 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_31511) && DBL_PTR(_31511)->dbl == 0.0){
            _31511 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _31511 = NOVALUE;
    }
    _31511 = NOVALUE;

    /** fwdref.e:669			integer start_pc = pc*/
    _start_pc_64142 = _pc_64011;

    /** fwdref.e:671			if which_type = sequence_type or*/
    _31512 = (_which_type_63976 == _54sequence_type_47136);
    if (_31512 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31514 = (object)*(((s1_ptr)_2)->base + _which_type_63976);
    _2 = (object)SEQ_PTR(_31514);
    _31515 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31514 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31515)){
        _31516 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31515)->dbl));
    }
    else{
        _31516 = (object)*(((s1_ptr)_2)->base + _31515);
    }
    _2 = (object)SEQ_PTR(_31516);
    _31517 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31516 = NOVALUE;
    if (IS_ATOM_INT(_31517)) {
        _31518 = (_31517 == _54sequence_type_47136);
    }
    else {
        _31518 = binary_op(EQUALS, _31517, _54sequence_type_47136);
    }
    _31517 = NOVALUE;
    if (_31518 == 0) {
        DeRef(_31518);
        _31518 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_31518) && DBL_PTR(_31518)->dbl == 0.0){
            DeRef(_31518);
            _31518 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_31518);
        _31518 = NOVALUE;
    }
    DeRef(_31518);
    _31518 = NOVALUE;
L1D: 

    /** fwdref.e:674				insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 97LL;
    ((intptr_t *)_2)[2] = _var_63978;
    _31519 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31520 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_883_64161);
    _code_inlined_insert_code_at_883_64161 = _31519;
    _31519 = NOVALUE;
    Ref(_31520);
    DeRef(_subprog_inlined_insert_code_at_886_64162);
    _subprog_inlined_insert_code_at_886_64162 = _31520;
    _31520 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_64162)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_886_64162)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_64162);
        _subprog_inlined_insert_code_at_886_64162 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_886_64162;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_64161);
    _66insert_code(_code_inlined_insert_code_at_883_64161, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_64161);
    _code_inlined_insert_code_at_883_64161 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_64162);
    _subprog_inlined_insert_code_at_886_64162 = NOVALUE;

    /** fwdref.e:675				pc += 2*/
    _pc_64011 = _pc_64011 + 2LL;
    goto L20; // [909] 1012
L1E: 

    /** fwdref.e:677			elsif which_type = integer_type or*/
    _31522 = (_which_type_63976 == _54integer_type_47138);
    if (_31522 != 0) {
        goto L21; // [920] 959
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31524 = (object)*(((s1_ptr)_2)->base + _which_type_63976);
    _2 = (object)SEQ_PTR(_31524);
    _31525 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31524 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_31525)){
        _31526 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31525)->dbl));
    }
    else{
        _31526 = (object)*(((s1_ptr)_2)->base + _31525);
    }
    _2 = (object)SEQ_PTR(_31526);
    _31527 = (object)*(((s1_ptr)_2)->base + 15LL);
    _31526 = NOVALUE;
    if (IS_ATOM_INT(_31527)) {
        _31528 = (_31527 == _54integer_type_47138);
    }
    else {
        _31528 = binary_op(EQUALS, _31527, _54integer_type_47138);
    }
    _31527 = NOVALUE;
    if (_31528 == 0) {
        DeRef(_31528);
        _31528 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_31528) && DBL_PTR(_31528)->dbl == 0.0){
            DeRef(_31528);
            _31528 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_31528);
        _31528 = NOVALUE;
    }
    DeRef(_31528);
    _31528 = NOVALUE;
L21: 

    /** fwdref.e:680				insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 96LL;
    ((intptr_t *)_2)[2] = _var_63978;
    _31529 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(_fr_63973);
    _31530 = (object)*(((s1_ptr)_2)->base + 4LL);
    DeRefi(_code_inlined_insert_code_at_984_64182);
    _code_inlined_insert_code_at_984_64182 = _31529;
    _31529 = NOVALUE;
    Ref(_31530);
    DeRef(_subprog_inlined_insert_code_at_987_64183);
    _subprog_inlined_insert_code_at_987_64183 = _31530;
    _31530 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_64183)) {
        _1 = (object)(DBL_PTR(_subprog_inlined_insert_code_at_987_64183)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_64183);
        _subprog_inlined_insert_code_at_987_64183 = _1;
    }

    /** fwdref.e:82		shifting_sub = subprog*/
    _44shifting_sub_63212 = _subprog_inlined_insert_code_at_987_64183;

    /** fwdref.e:83		shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_64182);
    _66insert_code(_code_inlined_insert_code_at_984_64182, _pc_64011);

    /** fwdref.e:84		shifting_sub = 0*/
    _44shifting_sub_63212 = 0LL;

    /** fwdref.e:85	end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_64182);
    _code_inlined_insert_code_at_984_64182 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_64183);
    _subprog_inlined_insert_code_at_987_64183 = NOVALUE;

    /** fwdref.e:681				pc += 4*/
    _pc_64011 = _pc_64011 + 4LL;
L22: 
L20: 
L1C: 

    /** fwdref.e:686		resolved_reference( ref )*/
    _44resolved_reference(_ref_63972);

    /** fwdref.e:687		reset_code()*/
    _44reset_code();

    /** fwdref.e:688	end procedure*/
    DeRef(_tok_63971);
    DeRef(_fr_63973);
    DeRef(_31522);
    _31522 = NOVALUE;
    _31445 = NOVALUE;
    _31525 = NOVALUE;
    _31515 = NOVALUE;
    _31499 = NOVALUE;
    DeRef(_31463);
    _31463 = NOVALUE;
    DeRef(_31512);
    _31512 = NOVALUE;
    DeRef(_31458);
    _31458 = NOVALUE;
    DeRef(_31508);
    _31508 = NOVALUE;
    _31491 = NOVALUE;
    return;
    ;
}


void _44prep_forward_error(object _ref_64187)
{
    object _31538 = NOVALUE;
    object _31536 = NOVALUE;
    object _31534 = NOVALUE;
    object _31532 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_64187)) {
        _1 = (object)(DBL_PTR(_ref_64187)->dbl);
        DeRefDS(_ref_64187);
        _ref_64187 = _1;
    }

    /** fwdref.e:691		ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31532 = (object)*(((s1_ptr)_2)->base + _ref_64187);
    DeRef(_50ThisLine_49590);
    _2 = (object)SEQ_PTR(_31532);
    _50ThisLine_49590 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_50ThisLine_49590);
    _31532 = NOVALUE;

    /** fwdref.e:692		bp = forward_references[ref][FR_BP]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31534 = (object)*(((s1_ptr)_2)->base + _ref_64187);
    _2 = (object)SEQ_PTR(_31534);
    _50bp_49594 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_50bp_49594)){
        _50bp_49594 = (object)DBL_PTR(_50bp_49594)->dbl;
    }
    _31534 = NOVALUE;

    /** fwdref.e:693		line_number = forward_references[ref][FR_LINE]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31536 = (object)*(((s1_ptr)_2)->base + _ref_64187);
    _2 = (object)SEQ_PTR(_31536);
    _36line_number_21760 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36line_number_21760)){
        _36line_number_21760 = (object)DBL_PTR(_36line_number_21760)->dbl;
    }
    _31536 = NOVALUE;

    /** fwdref.e:694		current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31538 = (object)*(((s1_ptr)_2)->base + _ref_64187);
    _2 = (object)SEQ_PTR(_31538);
    _36current_file_no_21759 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36current_file_no_21759)){
        _36current_file_no_21759 = (object)DBL_PTR(_36current_file_no_21759)->dbl;
    }
    _31538 = NOVALUE;

    /** fwdref.e:695	end procedure*/
    return;
    ;
}


void _44forward_error(object _tok_64203, object _ref_64204)
{
    object _31545 = NOVALUE;
    object _31544 = NOVALUE;
    object _31543 = NOVALUE;
    object _31542 = NOVALUE;
    object _31541 = NOVALUE;
    object _31540 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:698		prep_forward_error( ref )*/
    _44prep_forward_error(_ref_64204);

    /** fwdref.e:699		CompileErr(EXPECTED_1_NOT_2, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31540 = (object)*(((s1_ptr)_2)->base + _ref_64204);
    _2 = (object)SEQ_PTR(_31540);
    _31541 = (object)*(((s1_ptr)_2)->base + 1LL);
    _31540 = NOVALUE;
    Ref(_31541);
    _31542 = _44expected_name(_31541);
    _31541 = NOVALUE;
    _2 = (object)SEQ_PTR(_tok_64203);
    _31543 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_31543);
    _31544 = _44expected_name(_31543);
    _31543 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _31542;
    ((intptr_t *)_2)[2] = _31544;
    _31545 = MAKE_SEQ(_1);
    _31544 = NOVALUE;
    _31542 = NOVALUE;
    _50CompileErr(68LL, _31545, 0LL);
    _31545 = NOVALUE;

    /** fwdref.e:701	end procedure*/
    DeRef(_tok_64203);
    return;
    ;
}


object _44find_reference(object _fr_64216)
{
    object _name_64217 = NOVALUE;
    object _file_64219 = NOVALUE;
    object _ns_file_64221 = NOVALUE;
    object _ix_64222 = NOVALUE;
    object _ns_64225 = NOVALUE;
    object _ns_tok_64229 = NOVALUE;
    object _tok_64241 = NOVALUE;
    object _31556 = NOVALUE;
    object _31553 = NOVALUE;
    object _31551 = NOVALUE;
    object _31549 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:706		sequence name = fr[FR_NAME]*/
    DeRef(_name_64217);
    _2 = (object)SEQ_PTR(_fr_64216);
    _name_64217 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_name_64217);

    /** fwdref.e:707		integer file  = fr[FR_FILE]*/
    _2 = (object)SEQ_PTR(_fr_64216);
    _file_64219 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_file_64219))
    _file_64219 = (object)DBL_PTR(_file_64219)->dbl;

    /** fwdref.e:709		integer ns_file = -1*/
    _ns_file_64221 = -1LL;

    /** fwdref.e:710		integer ix = find( ':', name )*/
    _ix_64222 = find_from(58LL, _name_64217, 1LL);

    /** fwdref.e:711		if ix then*/
    if (_ix_64222 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** fwdref.e:712			sequence ns = name[1..ix-1]*/
    _31549 = _ix_64222 - 1LL;
    rhs_slice_target = (object_ptr)&_ns_64225;
    RHS_Slice(_name_64217, 1LL, _31549);

    /** fwdref.e:713			token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64216);
    _31551 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_ns_64225);
    Ref(_31551);
    _0 = _ns_tok_64229;
    _ns_tok_64229 = _54keyfind(_ns_64225, -1LL, _file_64219, 1LL, _31551);
    DeRef(_0);
    _31551 = NOVALUE;

    /** fwdref.e:714			if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (object)SEQ_PTR(_ns_tok_64229);
    _31553 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _31553, 523LL)){
        _31553 = NOVALUE;
        goto L2; // [69] 80
    }
    _31553 = NOVALUE;

    /** fwdref.e:715				return ns_tok*/
    DeRefDS(_ns_64225);
    DeRefDS(_fr_64216);
    DeRefDS(_name_64217);
    DeRef(_tok_64241);
    _31549 = NOVALUE;
    return _ns_tok_64229;
L2: 
    DeRef(_ns_64225);
    _ns_64225 = NOVALUE;
    DeRef(_ns_tok_64229);
    _ns_tok_64229 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** fwdref.e:718			ns_file = fr[FR_QUALIFIED]*/
    _2 = (object)SEQ_PTR(_fr_64216);
    _ns_file_64221 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_ns_file_64221))
    _ns_file_64221 = (object)DBL_PTR(_ns_file_64221)->dbl;
L3: 

    /** fwdref.e:721		No_new_entry = 1*/
    _54No_new_entry_48330 = 1LL;

    /** fwdref.e:722		object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (object)SEQ_PTR(_fr_64216);
    _31556 = (object)*(((s1_ptr)_2)->base + 11LL);
    RefDS(_name_64217);
    Ref(_31556);
    _0 = _tok_64241;
    _tok_64241 = _54keyfind(_name_64217, _ns_file_64221, _file_64219, 0LL, _31556);
    DeRef(_0);
    _31556 = NOVALUE;

    /** fwdref.e:723		No_new_entry = 0*/
    _54No_new_entry_48330 = 0LL;

    /** fwdref.e:724		return tok*/
    DeRefDS(_fr_64216);
    DeRefDS(_name_64217);
    DeRef(_31549);
    _31549 = NOVALUE;
    return _tok_64241;
    ;
}


void _44register_forward_type(object _sym_64249, object _ref_64250)
{
    object _31563 = NOVALUE;
    object _31562 = NOVALUE;
    object _31560 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:729		if ref < 0 then*/
    if (_ref_64250 >= 0LL)
    goto L1; // [7] 19

    /** fwdref.e:730			ref = -ref*/
    _ref_64250 = - _ref_64250;
L1: 

    /** fwdref.e:732		forward_references[ref][FR_DATA] &= sym*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64250 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31562 = (object)*(((s1_ptr)_2)->base + 12LL);
    _31560 = NOVALUE;
    if (IS_SEQUENCE(_31562) && IS_ATOM(_sym_64249)) {
        Append(&_31563, _31562, _sym_64249);
    }
    else if (IS_ATOM(_31562) && IS_SEQUENCE(_sym_64249)) {
    }
    else {
        Concat((object_ptr)&_31563, _31562, _sym_64249);
        _31562 = NOVALUE;
    }
    _31562 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31563;
    if( _1 != _31563 ){
        DeRef(_1);
    }
    _31563 = NOVALUE;
    _31560 = NOVALUE;

    /** fwdref.e:733	end procedure*/
    return;
    ;
}


object _44new_forward_reference(object _fwd_op_64280, object _sym_64282, object _op_64283)
{
    object _ref_64284 = NOVALUE;
    object _len_64285 = NOVALUE;
    object _hashval_64315 = NOVALUE;
    object _default_sym_64390 = NOVALUE;
    object _param_64393 = NOVALUE;
    object _set_data_2__tmp_at578_64410 = NOVALUE;
    object _set_data_1__tmp_at578_64409 = NOVALUE;
    object _data_inlined_set_data_at_575_64408 = NOVALUE;
    object _31649 = NOVALUE;
    object _31648 = NOVALUE;
    object _31647 = NOVALUE;
    object _31644 = NOVALUE;
    object _31642 = NOVALUE;
    object _31641 = NOVALUE;
    object _31639 = NOVALUE;
    object _31638 = NOVALUE;
    object _31637 = NOVALUE;
    object _31635 = NOVALUE;
    object _31633 = NOVALUE;
    object _31631 = NOVALUE;
    object _31628 = NOVALUE;
    object _31627 = NOVALUE;
    object _31625 = NOVALUE;
    object _31623 = NOVALUE;
    object _31621 = NOVALUE;
    object _31619 = NOVALUE;
    object _31618 = NOVALUE;
    object _31617 = NOVALUE;
    object _31615 = NOVALUE;
    object _31612 = NOVALUE;
    object _31610 = NOVALUE;
    object _31608 = NOVALUE;
    object _31607 = NOVALUE;
    object _31606 = NOVALUE;
    object _31605 = NOVALUE;
    object _31603 = NOVALUE;
    object _31600 = NOVALUE;
    object _31599 = NOVALUE;
    object _31598 = NOVALUE;
    object _31596 = NOVALUE;
    object _31595 = NOVALUE;
    object _31594 = NOVALUE;
    object _31593 = NOVALUE;
    object _31591 = NOVALUE;
    object _31590 = NOVALUE;
    object _31589 = NOVALUE;
    object _31588 = NOVALUE;
    object _31586 = NOVALUE;
    object _31583 = NOVALUE;
    object _31582 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_64282)) {
        _1 = (object)(DBL_PTR(_sym_64282)->dbl);
        DeRefDS(_sym_64282);
        _sym_64282 = _1;
    }

    /** fwdref.e:754			len = length( inactive_references )*/
    if (IS_SEQUENCE(_44inactive_references_63197)){
            _len_64285 = SEQ_PTR(_44inactive_references_63197)->length;
    }
    else {
        _len_64285 = 1;
    }

    /** fwdref.e:757		if len then*/
    if (_len_64285 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** fwdref.e:758			ref = inactive_references[len]*/
    _2 = (object)SEQ_PTR(_44inactive_references_63197);
    _ref_64284 = (object)*(((s1_ptr)_2)->base + _len_64285);
    if (!IS_ATOM_INT(_ref_64284))
    _ref_64284 = (object)DBL_PTR(_ref_64284)->dbl;

    /** fwdref.e:759			inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_44inactive_references_63197);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_64285)) ? _len_64285 : (object)(DBL_PTR(_len_64285)->dbl);
        int stop = (IS_ATOM_INT(_len_64285)) ? _len_64285 : (object)(DBL_PTR(_len_64285)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_44inactive_references_63197), start, &_44inactive_references_63197 );
            }
            else Tail(SEQ_PTR(_44inactive_references_63197), stop+1, &_44inactive_references_63197);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_44inactive_references_63197), start, &_44inactive_references_63197);
        }
        else {
            assign_slice_seq = &assign_space;
            _44inactive_references_63197 = Remove_elements(start, stop, (SEQ_PTR(_44inactive_references_63197)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** fwdref.e:761			forward_references &= 0*/
    Append(&_44forward_references_63193, _44forward_references_63193, 0LL);

    /** fwdref.e:762			ref = length( forward_references )*/
    if (IS_SEQUENCE(_44forward_references_63193)){
            _ref_64284 = SEQ_PTR(_44forward_references_63193)->length;
    }
    else {
        _ref_64284 = 1;
    }
L2: 

    /** fwdref.e:764		forward_references[ref] = repeat( 0, FR_SIZE )*/
    _31582 = Repeat(0LL, 12LL);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _ref_64284);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31582;
    if( _1 != _31582 ){
        DeRef(_1);
    }
    _31582 = NOVALUE;

    /** fwdref.e:766		forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _fwd_op_64280;
    DeRef(_1);
    _31583 = NOVALUE;

    /** fwdref.e:767		if sym < 0 then*/
    if (_sym_64282 >= 0LL)
    goto L3; // [84] 143

    /** fwdref.e:768			forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64282 == (uintptr_t)HIGH_BITS){
        _31588 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31588 = - _sym_64282;
    }
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!IS_ATOM_INT(_31588)){
        _31589 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31588)->dbl));
    }
    else{
        _31589 = (object)*(((s1_ptr)_2)->base + _31588);
    }
    _2 = (object)SEQ_PTR(_31589);
    _31590 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31589 = NOVALUE;
    Ref(_31590);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31590;
    if( _1 != _31590 ){
        DeRef(_1);
    }
    _31590 = NOVALUE;
    _31586 = NOVALUE;

    /** fwdref.e:769			forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_sym_64282 == (uintptr_t)HIGH_BITS){
        _31593 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _31593 = - _sym_64282;
    }
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!IS_ATOM_INT(_31593)){
        _31594 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31593)->dbl));
    }
    else{
        _31594 = (object)*(((s1_ptr)_2)->base + _31593);
    }
    _2 = (object)SEQ_PTR(_31594);
    _31595 = (object)*(((s1_ptr)_2)->base + 11LL);
    _31594 = NOVALUE;
    Ref(_31595);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31595;
    if( _1 != _31595 ){
        DeRef(_1);
    }
    _31595 = NOVALUE;
    _31591 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** fwdref.e:771			forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31598 = (object)*(((s1_ptr)_2)->base + _sym_64282);
    _2 = (object)SEQ_PTR(_31598);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _31599 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _31599 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _31598 = NOVALUE;
    Ref(_31599);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31599;
    if( _1 != _31599 ){
        DeRef(_1);
    }
    _31599 = NOVALUE;
    _31596 = NOVALUE;

    /** fwdref.e:772			integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31600 = (object)*(((s1_ptr)_2)->base + _sym_64282);
    _2 = (object)SEQ_PTR(_31600);
    _hashval_64315 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hashval_64315)){
        _hashval_64315 = (object)DBL_PTR(_hashval_64315)->dbl;
    }
    _31600 = NOVALUE;

    /** fwdref.e:773			if 0 = hashval then*/
    if (0LL != _hashval_64315)
    goto L5; // [186] 220

    /** fwdref.e:774				forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    _31605 = (object)*(((s1_ptr)_2)->base + _ref_64284);
    _2 = (object)SEQ_PTR(_31605);
    _31606 = (object)*(((s1_ptr)_2)->base + 2LL);
    _31605 = NOVALUE;
    Ref(_31606);
    _31607 = _54hashfn(_31606);
    _31606 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31607;
    if( _1 != _31607 ){
        DeRef(_1);
    }
    _31607 = NOVALUE;
    _31603 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** fwdref.e:776				forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_64315;
    DeRef(_1);
    _31608 = NOVALUE;

    /** fwdref.e:777				remove_symbol( sym )*/
    _54remove_symbol(_sym_64282);
L6: 
L4: 

    /** fwdref.e:782		forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21759;
    DeRef(_1);
    _31610 = NOVALUE;

    /** fwdref.e:783		forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36CurrentSub_21767;
    DeRef(_1);
    _31612 = NOVALUE;

    /** fwdref.e:785		if fwd_op != TYPE then*/
    if (_fwd_op_64280 == 504LL)
    goto L7; // [276] 303

    /** fwdref.e:786			forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_36Code_21851)){
            _31617 = SEQ_PTR(_36Code_21851)->length;
    }
    else {
        _31617 = 1;
    }
    _31618 = _31617 + 1;
    _31617 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31618;
    if( _1 != _31618 ){
        DeRef(_1);
    }
    _31618 = NOVALUE;
    _31615 = NOVALUE;
L7: 

    /** fwdref.e:789		forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36fwd_line_number_21761;
    DeRef(_1);
    _31619 = NOVALUE;

    /** fwdref.e:790		forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    Ref(_50ForwardLine_49591);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 7LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50ForwardLine_49591;
    DeRef(_1);
    _31621 = NOVALUE;

    /** fwdref.e:791		forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 8LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _50forward_bp_49595;
    DeRef(_1);
    _31623 = NOVALUE;

    /** fwdref.e:792		forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _31627 = _62get_qualified_fwd();
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31627;
    if( _1 != _31627 ){
        DeRef(_1);
    }
    _31627 = NOVALUE;
    _31625 = NOVALUE;

    /** fwdref.e:793		forward_references[ref][FR_OP]        = op*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _op_64283;
    DeRef(_1);
    _31628 = NOVALUE;

    /** fwdref.e:795		if op = GOTO then*/
    if (_op_64283 != 188LL)
    goto L8; // [381] 403

    /** fwdref.e:796			forward_references[ref][FR_DATA] = { sym }*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _sym_64282;
    _31633 = MAKE_SEQ(_1);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31633;
    if( _1 != _31633 ){
        DeRef(_1);
    }
    _31633 = NOVALUE;
    _31631 = NOVALUE;
L8: 

    /** fwdref.e:803		if CurrentSub = TopLevelSub then*/
    if (_36CurrentSub_21767 != _36TopLevelSub_21766)
    goto L9; // [409] 471

    /** fwdref.e:804			if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_44toplevel_references_63196)){
            _31635 = SEQ_PTR(_44toplevel_references_63196)->length;
    }
    else {
        _31635 = 1;
    }
    if (_31635 >= _36current_file_no_21759)
    goto LA; // [422] 450

    /** fwdref.e:805				toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_44toplevel_references_63196)){
            _31637 = SEQ_PTR(_44toplevel_references_63196)->length;
    }
    else {
        _31637 = 1;
    }
    _31638 = _36current_file_no_21759 - _31637;
    _31637 = NOVALUE;
    _31639 = Repeat(_22186, _31638);
    _31638 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_63196, _44toplevel_references_63196, _31639);
    DeRefDS(_31639);
    _31639 = NOVALUE;
LA: 

    /** fwdref.e:807			toplevel_references[current_file_no] &= ref*/
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    _31641 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_31641) && IS_ATOM(_ref_64284)) {
        Append(&_31642, _31641, _ref_64284);
    }
    else if (IS_ATOM(_31641) && IS_SEQUENCE(_ref_64284)) {
    }
    else {
        Concat((object_ptr)&_31642, _31641, _ref_64284);
        _31641 = NOVALUE;
    }
    _31641 = NOVALUE;
    _2 = (object)SEQ_PTR(_44toplevel_references_63196);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44toplevel_references_63196 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31642;
    if( _1 != _31642 ){
        DeRef(_1);
    }
    _31642 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** fwdref.e:809			add_active_reference( ref )*/
    _44add_active_reference(_ref_64284, _36current_file_no_21759);

    /** fwdref.e:811			if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21868 != 1LL)
    goto LC; // [485] 592

    /** fwdref.e:812				symtab_pointer default_sym = CurrentSub*/
    _default_sym_64390 = _36CurrentSub_21767;

    /** fwdref.e:813				symtab_pointer param = 0*/
    _param_64393 = 0LL;

    /** fwdref.e:814				while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_64390 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** fwdref.e:815					if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31644 = _54sym_scope(_default_sym_64390);
    if (binary_op_a(NOTEQ, _31644, 3LL)){
        DeRef(_31644);
        _31644 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31644);
    _31644 = NOVALUE;

    /** fwdref.e:816						param = default_sym*/
    _param_64393 = _default_sym_64390;
L10: 

    /** fwdref.e:818				entry*/
LD: 

    /** fwdref.e:819					default_sym = sym_next( default_sym )*/
    _default_sym_64390 = _54sym_next(_default_sym_64390);
    if (!IS_ATOM_INT(_default_sym_64390)) {
        _1 = (object)(DBL_PTR(_default_sym_64390)->dbl);
        DeRefDS(_default_sym_64390);
        _default_sym_64390 = _1;
    }

    /** fwdref.e:820				end while*/
    goto LE; // [546] 510
LF: 

    /** fwdref.e:821				set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_36Recorded_sym_21871)){
            _31647 = SEQ_PTR(_36Recorded_sym_21871)->length;
    }
    else {
        _31647 = 1;
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = _param_64393;
    ((intptr_t*)_2)[3] = _31647;
    _31648 = MAKE_SEQ(_1);
    _31647 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _31648;
    _31649 = MAKE_SEQ(_1);
    _31648 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_64408);
    _data_inlined_set_data_at_575_64408 = _31649;
    _31649 = NOVALUE;

    /** fwdref.e:186		forward_references[ref][FR_DATA] = data*/
    _2 = (object)SEQ_PTR(_44forward_references_63193);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44forward_references_63193 = MAKE_SEQ(_2);
    }
    _3 = (object)(_ref_64284 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_64408);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _data_inlined_set_data_at_575_64408;
    DeRef(_1);

    /** fwdref.e:187	end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_64408);
    _data_inlined_set_data_at_575_64408 = NOVALUE;
LC: 
LB: 

    /** fwdref.e:824		fwdref_count += 1*/
    _44fwdref_count_63213 = _44fwdref_count_63213 + 1;

    /** fwdref.e:826		ifdef EUDIS then*/

    /** fwdref.e:839		return ref*/
    DeRef(_31593);
    _31593 = NOVALUE;
    DeRef(_31588);
    _31588 = NOVALUE;
    return _ref_64284;
    ;
}


void _44add_active_reference(object _ref_64414, object _file_no_64415)
{
    object _sp_64429 = NOVALUE;
    object _31673 = NOVALUE;
    object _31672 = NOVALUE;
    object _31670 = NOVALUE;
    object _31669 = NOVALUE;
    object _31668 = NOVALUE;
    object _31666 = NOVALUE;
    object _31665 = NOVALUE;
    object _31664 = NOVALUE;
    object _31661 = NOVALUE;
    object _31659 = NOVALUE;
    object _31658 = NOVALUE;
    object _31657 = NOVALUE;
    object _31655 = NOVALUE;
    object _31654 = NOVALUE;
    object _31653 = NOVALUE;
    object _31651 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** fwdref.e:843		if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_44active_references_63195)){
            _31651 = SEQ_PTR(_44active_references_63195)->length;
    }
    else {
        _31651 = 1;
    }
    if (_31651 >= _file_no_64415)
    goto L1; // [12] 59

    /** fwdref.e:844			active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_44active_references_63195)){
            _31653 = SEQ_PTR(_44active_references_63195)->length;
    }
    else {
        _31653 = 1;
    }
    _31654 = _file_no_64415 - _31653;
    _31653 = NOVALUE;
    _31655 = Repeat(_22186, _31654);
    _31654 = NOVALUE;
    Concat((object_ptr)&_44active_references_63195, _44active_references_63195, _31655);
    DeRefDS(_31655);
    _31655 = NOVALUE;

    /** fwdref.e:845			active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_44active_subprogs_63194)){
            _31657 = SEQ_PTR(_44active_subprogs_63194)->length;
    }
    else {
        _31657 = 1;
    }
    _31658 = _file_no_64415 - _31657;
    _31657 = NOVALUE;
    _31659 = Repeat(_22186, _31658);
    _31658 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_63194, _44active_subprogs_63194, _31659);
    DeRefDS(_31659);
    _31659 = NOVALUE;
L1: 

    /** fwdref.e:847		integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31661 = (object)*(((s1_ptr)_2)->base + _file_no_64415);
    _sp_64429 = find_from(_36CurrentSub_21767, _31661, 1LL);
    _31661 = NOVALUE;

    /** fwdref.e:848		if not sp then*/
    if (_sp_64429 != 0)
    goto L2; // [76] 127

    /** fwdref.e:849			active_subprogs[file_no] &= CurrentSub*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31664 = (object)*(((s1_ptr)_2)->base + _file_no_64415);
    if (IS_SEQUENCE(_31664) && IS_ATOM(_36CurrentSub_21767)) {
        Append(&_31665, _31664, _36CurrentSub_21767);
    }
    else if (IS_ATOM(_31664) && IS_SEQUENCE(_36CurrentSub_21767)) {
    }
    else {
        Concat((object_ptr)&_31665, _31664, _36CurrentSub_21767);
        _31664 = NOVALUE;
    }
    _31664 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_subprogs_63194 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64415);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31665;
    if( _1 != _31665 ){
        DeRef(_1);
    }
    _31665 = NOVALUE;

    /** fwdref.e:850			sp = length( active_subprogs[file_no] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31666 = (object)*(((s1_ptr)_2)->base + _file_no_64415);
    if (IS_SEQUENCE(_31666)){
            _sp_64429 = SEQ_PTR(_31666)->length;
    }
    else {
        _sp_64429 = 1;
    }
    _31666 = NOVALUE;

    /** fwdref.e:852			active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _31668 = (object)*(((s1_ptr)_2)->base + _file_no_64415);
    RefDS(_22186);
    Append(&_31669, _31668, _22186);
    _31668 = NOVALUE;
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63195 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _file_no_64415);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31669;
    if( _1 != _31669 ){
        DeRef(_1);
    }
    _31669 = NOVALUE;
L2: 

    /** fwdref.e:854		active_references[file_no][sp] &= ref*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _44active_references_63195 = MAKE_SEQ(_2);
    }
    _3 = (object)(_file_no_64415 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _31672 = (object)*(((s1_ptr)_2)->base + _sp_64429);
    _31670 = NOVALUE;
    if (IS_SEQUENCE(_31672) && IS_ATOM(_ref_64414)) {
        Append(&_31673, _31672, _ref_64414);
    }
    else if (IS_ATOM(_31672) && IS_SEQUENCE(_ref_64414)) {
    }
    else {
        Concat((object_ptr)&_31673, _31672, _ref_64414);
        _31672 = NOVALUE;
    }
    _31672 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _sp_64429);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _31673;
    if( _1 != _31673 ){
        DeRef(_1);
    }
    _31673 = NOVALUE;
    _31670 = NOVALUE;

    /** fwdref.e:855	end procedure*/
    _31666 = NOVALUE;
    return;
    ;
}


object _44resolve_file(object _refs_64466, object _report_errors_64467, object _unincluded_ok_64468)
{
    object _errors_64469 = NOVALUE;
    object _ref_64473 = NOVALUE;
    object _fr_64475 = NOVALUE;
    object _tok_64488 = NOVALUE;
    object _code_sub_64496 = NOVALUE;
    object _fr_type_64498 = NOVALUE;
    object _sym_tok_64500 = NOVALUE;
    object _31727 = NOVALUE;
    object _31726 = NOVALUE;
    object _31725 = NOVALUE;
    object _31724 = NOVALUE;
    object _31723 = NOVALUE;
    object _31722 = NOVALUE;
    object _31717 = NOVALUE;
    object _31716 = NOVALUE;
    object _31715 = NOVALUE;
    object _31713 = NOVALUE;
    object _31712 = NOVALUE;
    object _31709 = NOVALUE;
    object _31708 = NOVALUE;
    object _31707 = NOVALUE;
    object _31703 = NOVALUE;
    object _31702 = NOVALUE;
    object _31694 = NOVALUE;
    object _31692 = NOVALUE;
    object _31691 = NOVALUE;
    object _31690 = NOVALUE;
    object _31689 = NOVALUE;
    object _31688 = NOVALUE;
    object _31687 = NOVALUE;
    object _31684 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:864		sequence errors = {}*/
    RefDS(_22186);
    DeRefi(_errors_64469);
    _errors_64469 = _22186;

    /** fwdref.e:865		for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64466)){
            _31684 = SEQ_PTR(_refs_64466)->length;
    }
    else {
        _31684 = 1;
    }
    {
        object _ar_64471;
        _ar_64471 = _31684;
L1: 
        if (_ar_64471 < 1LL){
            goto L2; // [19] 481
        }

        /** fwdref.e:866			integer ref = refs[ar]*/
        _2 = (object)SEQ_PTR(_refs_64466);
        _ref_64473 = (object)*(((s1_ptr)_2)->base + _ar_64471);
        if (!IS_ATOM_INT(_ref_64473))
        _ref_64473 = (object)DBL_PTR(_ref_64473)->dbl;

        /** fwdref.e:868			sequence fr = forward_references[ref]*/
        DeRef(_fr_64475);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        _fr_64475 = (object)*(((s1_ptr)_2)->base + _ref_64473);
        Ref(_fr_64475);

        /** fwdref.e:869			if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (object)SEQ_PTR(_fr_64475);
        _31687 = (object)*(((s1_ptr)_2)->base + 3LL);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!IS_ATOM_INT(_31687)){
            _31688 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31687)->dbl));
        }
        else{
            _31688 = (object)*(((s1_ptr)_2)->base + _31687);
        }
        _2 = (object)SEQ_PTR(_31688);
        _31689 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
        _31688 = NOVALUE;
        if (IS_ATOM_INT(_31689)) {
            _31690 = (_31689 == 0LL);
        }
        else {
            _31690 = binary_op(EQUALS, _31689, 0LL);
        }
        _31689 = NOVALUE;
        if (IS_ATOM_INT(_31690)) {
            if (_31690 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31690)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31692 = (_unincluded_ok_64468 == 0);
        if (_31692 == 0)
        {
            DeRef(_31692);
            _31692 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31692);
            _31692 = NOVALUE;
        }

        /** fwdref.e:870				continue*/
        DeRef(_fr_64475);
        _fr_64475 = NOVALUE;
        DeRef(_tok_64488);
        _tok_64488 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** fwdref.e:873			token tok = find_reference( fr )*/
        RefDS(_fr_64475);
        _0 = _tok_64488;
        _tok_64488 = _44find_reference(_fr_64475);
        DeRef(_0);

        /** fwdref.e:874			if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64488);
        _31694 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31694, 509LL)){
            _31694 = NOVALUE;
            goto L5; // [100] 117
        }
        _31694 = NOVALUE;

        /** fwdref.e:875				errors &= ref*/
        Append(&_errors_64469, _errors_64469, _ref_64473);

        /** fwdref.e:876				continue*/
        DeRefDS(_fr_64475);
        _fr_64475 = NOVALUE;
        DeRef(_tok_64488);
        _tok_64488 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** fwdref.e:880			integer code_sub = fr[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_fr_64475);
        _code_sub_64496 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_code_sub_64496))
        _code_sub_64496 = (object)DBL_PTR(_code_sub_64496)->dbl;

        /** fwdref.e:881			integer fr_type  = fr[FR_TYPE]*/
        _2 = (object)SEQ_PTR(_fr_64475);
        _fr_type_64498 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_fr_type_64498))
        _fr_type_64498 = (object)DBL_PTR(_fr_type_64498)->dbl;

        /** fwdref.e:882			integer sym_tok*/

        /** fwdref.e:884			switch fr_type label "fr_type" do*/
        _0 = _fr_type_64498;
        switch ( _0 ){ 

            /** fwdref.e:885				case PROC, FUNC then*/
            case 27:
            case 501:

            /** fwdref.e:887					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64488);
            _31702 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_31702)){
                _31703 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31702)->dbl));
            }
            else{
                _31703 = (object)*(((s1_ptr)_2)->base + _31702);
            }
            _2 = (object)SEQ_PTR(_31703);
            if (!IS_ATOM_INT(_36S_TOKEN_21401)){
                _sym_tok_64500 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
            }
            else{
                _sym_tok_64500 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
            }
            if (!IS_ATOM_INT(_sym_tok_64500)){
                _sym_tok_64500 = (object)DBL_PTR(_sym_tok_64500)->dbl;
            }
            _31703 = NOVALUE;

            /** fwdref.e:888					if sym_tok = TYPE then*/
            if (_sym_tok_64500 != 504LL)
            goto L6; // [170] 184

            /** fwdref.e:889						sym_tok = FUNC*/
            _sym_tok_64500 = 501LL;
L6: 

            /** fwdref.e:891					if sym_tok != fr_type then*/
            if (_sym_tok_64500 == _fr_type_64498)
            goto L7; // [186] 220

            /** fwdref.e:892						if sym_tok != FUNC and fr_type != PROC then*/
            _31707 = (_sym_tok_64500 != 501LL);
            if (_31707 == 0) {
                goto L8; // [198] 219
            }
            _31709 = (_fr_type_64498 != 27LL);
            if (_31709 == 0)
            {
                DeRef(_31709);
                _31709 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31709);
                _31709 = NOVALUE;
            }

            /** fwdref.e:893							forward_error( tok, ref )*/
            Ref(_tok_64488);
            _44forward_error(_tok_64488, _ref_64473);
L8: 
L7: 

            /** fwdref.e:896					switch sym_tok do*/
            _0 = _sym_tok_64500;
            switch ( _0 ){ 

                /** fwdref.e:897						case PROC, FUNC then*/
                case 27:
                case 501:

                /** fwdref.e:898							patch_forward_call( tok, ref )*/
                Ref(_tok_64488);
                _44patch_forward_call(_tok_64488, _ref_64473);

                /** fwdref.e:899							break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** fwdref.e:901						case else*/
                default:

                /** fwdref.e:902							forward_error( tok, ref )*/
                Ref(_tok_64488);
                _44forward_error(_tok_64488, _ref_64473);
            ;}            goto L9; // [256] 446

            /** fwdref.e:906				case VARIABLE then*/
            case -100:

            /** fwdref.e:907					sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (object)SEQ_PTR(_tok_64488);
            _31712 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_31712)){
                _31713 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31712)->dbl));
            }
            else{
                _31713 = (object)*(((s1_ptr)_2)->base + _31712);
            }
            _2 = (object)SEQ_PTR(_31713);
            if (!IS_ATOM_INT(_36S_TOKEN_21401)){
                _sym_tok_64500 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
            }
            else{
                _sym_tok_64500 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
            }
            if (!IS_ATOM_INT(_sym_tok_64500)){
                _sym_tok_64500 = (object)DBL_PTR(_sym_tok_64500)->dbl;
            }
            _31713 = NOVALUE;

            /** fwdref.e:908					if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (object)SEQ_PTR(_tok_64488);
            _31715 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!IS_ATOM_INT(_31715)){
                _31716 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31715)->dbl));
            }
            else{
                _31716 = (object)*(((s1_ptr)_2)->base + _31715);
            }
            _2 = (object)SEQ_PTR(_31716);
            _31717 = (object)*(((s1_ptr)_2)->base + 4LL);
            _31716 = NOVALUE;
            if (binary_op_a(NOTEQ, _31717, 9LL)){
                _31717 = NOVALUE;
                goto LA; // [306] 323
            }
            _31717 = NOVALUE;

            /** fwdref.e:909						errors &= ref*/
            Append(&_errors_64469, _errors_64469, _ref_64473);

            /** fwdref.e:910						continue*/
            DeRef(_fr_64475);
            _fr_64475 = NOVALUE;
            DeRef(_tok_64488);
            _tok_64488 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** fwdref.e:913					switch sym_tok do*/
            _0 = _sym_tok_64500;
            switch ( _0 ){ 

                /** fwdref.e:914						case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** fwdref.e:915							patch_forward_variable( tok, ref )*/
                Ref(_tok_64488);
                _44patch_forward_variable(_tok_64488, _ref_64473);

                /** fwdref.e:916							break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** fwdref.e:917						case else*/
                default:

                /** fwdref.e:918							forward_error( tok, ref )*/
                Ref(_tok_64488);
                _44forward_error(_tok_64488, _ref_64473);
            ;}            goto L9; // [361] 446

            /** fwdref.e:921				case TYPE_CHECK then*/
            case 65:

            /** fwdref.e:922					patch_forward_type_check( tok, ref )*/
            Ref(_tok_64488);
            _44patch_forward_type_check(_tok_64488, _ref_64473);
            goto L9; // [373] 446

            /** fwdref.e:924				case GLOBAL_INIT_CHECK then*/
            case 109:

            /** fwdref.e:925					patch_forward_init_check( tok, ref )*/
            Ref(_tok_64488);
            _44patch_forward_init_check(_tok_64488, _ref_64473);
            goto L9; // [385] 446

            /** fwdref.e:927				case CASE then*/
            case 186:

            /** fwdref.e:928					patch_forward_case( tok, ref )*/
            Ref(_tok_64488);
            _44patch_forward_case(_tok_64488, _ref_64473);
            goto L9; // [397] 446

            /** fwdref.e:930				case TYPE then*/
            case 504:

            /** fwdref.e:931					patch_forward_type( tok, ref )*/
            Ref(_tok_64488);
            _44patch_forward_type(_tok_64488, _ref_64473);
            goto L9; // [409] 446

            /** fwdref.e:933				case GOTO then*/
            case 188:

            /** fwdref.e:934					patch_forward_goto( tok, ref )*/
            Ref(_tok_64488);
            _44patch_forward_goto(_tok_64488, _ref_64473);
            goto L9; // [421] 446

            /** fwdref.e:936				case else*/
            default:

            /** fwdref.e:938					InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (object)SEQ_PTR(_fr_64475);
            _31722 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_fr_64475);
            _31723 = (object)*(((s1_ptr)_2)->base + 2LL);
            Ref(_31723);
            Ref(_31722);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _31722;
            ((intptr_t *)_2)[2] = _31723;
            _31724 = MAKE_SEQ(_1);
            _31723 = NOVALUE;
            _31722 = NOVALUE;
            _50InternalErr(263LL, _31724);
            _31724 = NOVALUE;
        ;}L9: 

        /** fwdref.e:940			if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_64467 == 0) {
            goto LB; // [448] 472
        }
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        _31726 = (object)*(((s1_ptr)_2)->base + _ref_64473);
        _31727 = IS_SEQUENCE(_31726);
        _31726 = NOVALUE;
        if (_31727 == 0)
        {
            _31727 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31727 = NOVALUE;
        }

        /** fwdref.e:941				errors &= ref*/
        Append(&_errors_64469, _errors_64469, _ref_64473);
LB: 
        DeRef(_fr_64475);
        _fr_64475 = NOVALUE;
        DeRef(_tok_64488);
        _tok_64488 = NOVALUE;

        /** fwdref.e:944		end for*/
L4: 
        _ar_64471 = _ar_64471 + -1LL;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** fwdref.e:945		return errors*/
    DeRefDS(_refs_64466);
    DeRef(_31707);
    _31707 = NOVALUE;
    DeRef(_31690);
    _31690 = NOVALUE;
    _31702 = NOVALUE;
    _31687 = NOVALUE;
    _31712 = NOVALUE;
    _31715 = NOVALUE;
    return _errors_64469;
    ;
}


object _44file_name_based_symindex_compare(object _si1_64578, object _si2_64579)
{
    object _fn1_64600 = NOVALUE;
    object _fn2_64605 = NOVALUE;
    object _31756 = NOVALUE;
    object _31755 = NOVALUE;
    object _31754 = NOVALUE;
    object _31753 = NOVALUE;
    object _31752 = NOVALUE;
    object _31751 = NOVALUE;
    object _31750 = NOVALUE;
    object _31749 = NOVALUE;
    object _31748 = NOVALUE;
    object _31747 = NOVALUE;
    object _31746 = NOVALUE;
    object _31745 = NOVALUE;
    object _31743 = NOVALUE;
    object _31741 = NOVALUE;
    object _31740 = NOVALUE;
    object _31739 = NOVALUE;
    object _31738 = NOVALUE;
    object _31737 = NOVALUE;
    object _31736 = NOVALUE;
    object _31735 = NOVALUE;
    object _31734 = NOVALUE;
    object _31733 = NOVALUE;
    object _31732 = NOVALUE;
    object _31730 = NOVALUE;
    object _31729 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_64578)) {
        _1 = (object)(DBL_PTR(_si1_64578)->dbl);
        DeRefDS(_si1_64578);
        _si1_64578 = _1;
    }
    if (!IS_ATOM_INT(_si2_64579)) {
        _1 = (object)(DBL_PTR(_si2_64579)->dbl);
        DeRefDS(_si2_64579);
        _si2_64579 = _1;
    }

    /** fwdref.e:949		if not symtab_index(si1) or not symtab_index(si2) then*/
    _31729 = _36symtab_index(_si1_64578);
    if (IS_ATOM_INT(_31729)) {
        _31730 = (_31729 == 0);
    }
    else {
        _31730 = unary_op(NOT, _31729);
    }
    DeRef(_31729);
    _31729 = NOVALUE;
    if (IS_ATOM_INT(_31730)) {
        if (_31730 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31730)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31732 = _36symtab_index(_si2_64579);
    if (IS_ATOM_INT(_31732)) {
        _31733 = (_31732 == 0);
    }
    else {
        _31733 = unary_op(NOT, _31732);
    }
    DeRef(_31732);
    _31732 = NOVALUE;
    if (_31733 == 0) {
        DeRef(_31733);
        _31733 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31733) && DBL_PTR(_31733)->dbl == 0.0){
            DeRef(_31733);
            _31733 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31733);
        _31733 = NOVALUE;
    }
    DeRef(_31733);
    _31733 = NOVALUE;
L1: 

    /** fwdref.e:950			return 1 -- put non symbols last*/
    DeRef(_31730);
    _31730 = NOVALUE;
    return 1LL;
L2: 

    /** fwdref.e:952		if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31734 = (object)*(((s1_ptr)_2)->base + _si1_64578);
    if (IS_SEQUENCE(_31734)){
            _31735 = SEQ_PTR(_31734)->length;
    }
    else {
        _31735 = 1;
    }
    _31734 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21392)) {
        _31736 = (_36S_FILE_NO_21392 <= _31735);
    }
    else {
        _31736 = binary_op(LESSEQ, _36S_FILE_NO_21392, _31735);
    }
    _31735 = NOVALUE;
    if (IS_ATOM_INT(_31736)) {
        if (_31736 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31736)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31738 = (object)*(((s1_ptr)_2)->base + _si2_64579);
    if (IS_SEQUENCE(_31738)){
            _31739 = SEQ_PTR(_31738)->length;
    }
    else {
        _31739 = 1;
    }
    _31738 = NOVALUE;
    if (IS_ATOM_INT(_36S_FILE_NO_21392)) {
        _31740 = (_36S_FILE_NO_21392 <= _31739);
    }
    else {
        _31740 = binary_op(LESSEQ, _36S_FILE_NO_21392, _31739);
    }
    _31739 = NOVALUE;
    if (_31740 == 0) {
        DeRef(_31740);
        _31740 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31740) && DBL_PTR(_31740)->dbl == 0.0){
            DeRef(_31740);
            _31740 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31740);
        _31740 = NOVALUE;
    }
    DeRef(_31740);
    _31740 = NOVALUE;

    /** fwdref.e:953			integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31741 = (object)*(((s1_ptr)_2)->base + _si1_64578);
    _2 = (object)SEQ_PTR(_31741);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _fn1_64600 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _fn1_64600 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_fn1_64600)){
        _fn1_64600 = (object)DBL_PTR(_fn1_64600)->dbl;
    }
    _31741 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31743 = (object)*(((s1_ptr)_2)->base + _si2_64579);
    _2 = (object)SEQ_PTR(_31743);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _fn2_64605 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _fn2_64605 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_fn2_64605)){
        _fn2_64605 = (object)DBL_PTR(_fn2_64605)->dbl;
    }
    _31743 = NOVALUE;

    /** fwdref.e:954			if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64600;
    ((intptr_t *)_2)[2] = _fn2_64605;
    _31745 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_37known_files_15638)){
            _31746 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31746 = 1;
    }
    _31747 = binary_op(GREATER, _31745, _31746);
    DeRefDS(_31745);
    _31745 = NOVALUE;
    _31746 = NOVALUE;
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _fn1_64600;
    ((intptr_t *)_2)[2] = _fn2_64605;
    _31748 = MAKE_SEQ(_1);
    _31749 = binary_op(LESSEQ, _31748, 0LL);
    DeRefDS(_31748);
    _31748 = NOVALUE;
    _31750 = binary_op(OR, _31747, _31749);
    DeRefDS(_31747);
    _31747 = NOVALUE;
    DeRefDS(_31749);
    _31749 = NOVALUE;
    _31751 = find_from(1LL, _31750, 1LL);
    DeRefDS(_31750);
    _31750 = NOVALUE;
    if (_31751 == 0)
    {
        _31751 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31751 = NOVALUE;
    }

    /** fwdref.e:956				return 1*/
    _31738 = NOVALUE;
    _31734 = NOVALUE;
    DeRef(_31736);
    _31736 = NOVALUE;
    DeRef(_31730);
    _31730 = NOVALUE;
    return 1LL;
L4: 

    /** fwdref.e:958			return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31752 = (object)*(((s1_ptr)_2)->base + _fn1_64600);
    Ref(_31752);
    RefDS(_22186);
    _31753 = _17abbreviate_path(_31752, _22186);
    _31752 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _31754 = (object)*(((s1_ptr)_2)->base + _fn2_64605);
    Ref(_31754);
    RefDS(_22186);
    _31755 = _17abbreviate_path(_31754, _22186);
    _31754 = NOVALUE;
    if (IS_ATOM_INT(_31753) && IS_ATOM_INT(_31755)){
        _31756 = (_31753 < _31755) ? -1 : (_31753 > _31755);
    }
    else{
        _31756 = compare(_31753, _31755);
    }
    DeRef(_31753);
    _31753 = NOVALUE;
    DeRef(_31755);
    _31755 = NOVALUE;
    _31738 = NOVALUE;
    _31734 = NOVALUE;
    DeRef(_31736);
    _31736 = NOVALUE;
    DeRef(_31730);
    _31730 = NOVALUE;
    return _31756;
    goto L5; // [183] 193
L3: 

    /** fwdref.e:961			return 1 -- put non-names last*/
    _31738 = NOVALUE;
    _31734 = NOVALUE;
    DeRef(_31736);
    _31736 = NOVALUE;
    DeRef(_31730);
    _31730 = NOVALUE;
    return 1LL;
L5: 
    ;
}


void _44Resolve_forward_references(object _report_errors_64631)
{
    object _errors_64632 = NOVALUE;
    object _unincluded_ok_64633 = NOVALUE;
    object _msg_64694 = NOVALUE;
    object _errloc_64695 = NOVALUE;
    object _ref_64700 = NOVALUE;
    object _tok_64716 = NOVALUE;
    object _THIS_SCOPE_64718 = NOVALUE;
    object _THESE_GLOBALS_64719 = NOVALUE;
    object _syms_64777 = NOVALUE;
    object _s_64798 = NOVALUE;
    object _31889 = NOVALUE;
    object _31888 = NOVALUE;
    object _31887 = NOVALUE;
    object _31885 = NOVALUE;
    object _31880 = NOVALUE;
    object _31877 = NOVALUE;
    object _31875 = NOVALUE;
    object _31874 = NOVALUE;
    object _31873 = NOVALUE;
    object _31872 = NOVALUE;
    object _31871 = NOVALUE;
    object _31870 = NOVALUE;
    object _31869 = NOVALUE;
    object _31867 = NOVALUE;
    object _31866 = NOVALUE;
    object _31865 = NOVALUE;
    object _31863 = NOVALUE;
    object _31861 = NOVALUE;
    object _31860 = NOVALUE;
    object _31859 = NOVALUE;
    object _31858 = NOVALUE;
    object _31857 = NOVALUE;
    object _31856 = NOVALUE;
    object _31853 = NOVALUE;
    object _31849 = NOVALUE;
    object _31848 = NOVALUE;
    object _31847 = NOVALUE;
    object _31846 = NOVALUE;
    object _31845 = NOVALUE;
    object _31844 = NOVALUE;
    object _31841 = NOVALUE;
    object _31840 = NOVALUE;
    object _31839 = NOVALUE;
    object _31838 = NOVALUE;
    object _31837 = NOVALUE;
    object _31836 = NOVALUE;
    object _31833 = NOVALUE;
    object _31832 = NOVALUE;
    object _31831 = NOVALUE;
    object _31830 = NOVALUE;
    object _31829 = NOVALUE;
    object _31828 = NOVALUE;
    object _31827 = NOVALUE;
    object _31826 = NOVALUE;
    object _31825 = NOVALUE;
    object _31824 = NOVALUE;
    object _31821 = NOVALUE;
    object _31819 = NOVALUE;
    object _31816 = NOVALUE;
    object _31814 = NOVALUE;
    object _31812 = NOVALUE;
    object _31811 = NOVALUE;
    object _31809 = NOVALUE;
    object _31808 = NOVALUE;
    object _31807 = NOVALUE;
    object _31806 = NOVALUE;
    object _31805 = NOVALUE;
    object _31803 = NOVALUE;
    object _31802 = NOVALUE;
    object _31800 = NOVALUE;
    object _31799 = NOVALUE;
    object _31797 = NOVALUE;
    object _31796 = NOVALUE;
    object _31794 = NOVALUE;
    object _31793 = NOVALUE;
    object _31792 = NOVALUE;
    object _31791 = NOVALUE;
    object _31790 = NOVALUE;
    object _31789 = NOVALUE;
    object _31788 = NOVALUE;
    object _31787 = NOVALUE;
    object _31786 = NOVALUE;
    object _31785 = NOVALUE;
    object _31784 = NOVALUE;
    object _31783 = NOVALUE;
    object _31782 = NOVALUE;
    object _31781 = NOVALUE;
    object _31780 = NOVALUE;
    object _31779 = NOVALUE;
    object _31777 = NOVALUE;
    object _31776 = NOVALUE;
    object _31775 = NOVALUE;
    object _31774 = NOVALUE;
    object _31772 = NOVALUE;
    object _31771 = NOVALUE;
    object _31769 = NOVALUE;
    object _31768 = NOVALUE;
    object _31767 = NOVALUE;
    object _31766 = NOVALUE;
    object _31764 = NOVALUE;
    object _31763 = NOVALUE;
    object _31762 = NOVALUE;
    object _31761 = NOVALUE;
    object _31759 = NOVALUE;
    object _31758 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:966		sequence errors = {}*/
    RefDS(_22186);
    DeRef(_errors_64632);
    _errors_64632 = _22186;

    /** fwdref.e:967		integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_64633 = _54get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_64633)) {
        _1 = (object)(DBL_PTR(_unincluded_ok_64633)->dbl);
        DeRefDS(_unincluded_ok_64633);
        _unincluded_ok_64633 = _1;
    }

    /** fwdref.e:969		if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44active_references_63195)){
            _31758 = SEQ_PTR(_44active_references_63195)->length;
    }
    else {
        _31758 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _31759 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31759 = 1;
    }
    if (_31758 >= _31759)
    goto L1; // [29] 86

    /** fwdref.e:970			active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _31761 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31761 = 1;
    }
    if (IS_SEQUENCE(_44active_references_63195)){
            _31762 = SEQ_PTR(_44active_references_63195)->length;
    }
    else {
        _31762 = 1;
    }
    _31763 = _31761 - _31762;
    _31761 = NOVALUE;
    _31762 = NOVALUE;
    _31764 = Repeat(_22186, _31763);
    _31763 = NOVALUE;
    Concat((object_ptr)&_44active_references_63195, _44active_references_63195, _31764);
    DeRefDS(_31764);
    _31764 = NOVALUE;

    /** fwdref.e:971			active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _31766 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31766 = 1;
    }
    if (IS_SEQUENCE(_44active_subprogs_63194)){
            _31767 = SEQ_PTR(_44active_subprogs_63194)->length;
    }
    else {
        _31767 = 1;
    }
    _31768 = _31766 - _31767;
    _31766 = NOVALUE;
    _31767 = NOVALUE;
    _31769 = Repeat(_22186, _31768);
    _31768 = NOVALUE;
    Concat((object_ptr)&_44active_subprogs_63194, _44active_subprogs_63194, _31769);
    DeRefDS(_31769);
    _31769 = NOVALUE;
L1: 

    /** fwdref.e:974		if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_44toplevel_references_63196)){
            _31771 = SEQ_PTR(_44toplevel_references_63196)->length;
    }
    else {
        _31771 = 1;
    }
    if (IS_SEQUENCE(_37known_files_15638)){
            _31772 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31772 = 1;
    }
    if (_31771 >= _31772)
    goto L2; // [98] 129

    /** fwdref.e:975			toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _31774 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _31774 = 1;
    }
    if (IS_SEQUENCE(_44toplevel_references_63196)){
            _31775 = SEQ_PTR(_44toplevel_references_63196)->length;
    }
    else {
        _31775 = 1;
    }
    _31776 = _31774 - _31775;
    _31774 = NOVALUE;
    _31775 = NOVALUE;
    _31777 = Repeat(_22186, _31776);
    _31776 = NOVALUE;
    Concat((object_ptr)&_44toplevel_references_63196, _44toplevel_references_63196, _31777);
    DeRefDS(_31777);
    _31777 = NOVALUE;
L2: 

    /** fwdref.e:978		for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_44active_subprogs_63194)){
            _31779 = SEQ_PTR(_44active_subprogs_63194)->length;
    }
    else {
        _31779 = 1;
    }
    {
        object _i_64665;
        _i_64665 = 1LL;
L3: 
        if (_i_64665 > _31779){
            goto L4; // [136] 280
        }

        /** fwdref.e:979			if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (object)SEQ_PTR(_44active_subprogs_63194);
        _31780 = (object)*(((s1_ptr)_2)->base + _i_64665);
        if (IS_SEQUENCE(_31780)){
                _31781 = SEQ_PTR(_31780)->length;
        }
        else {
            _31781 = 1;
        }
        _31780 = NOVALUE;
        if (_31781 != 0) {
            _31782 = 1;
            goto L5; // [154] 171
        }
        _2 = (object)SEQ_PTR(_44toplevel_references_63196);
        _31783 = (object)*(((s1_ptr)_2)->base + _i_64665);
        if (IS_SEQUENCE(_31783)){
                _31784 = SEQ_PTR(_31783)->length;
        }
        else {
            _31784 = 1;
        }
        _31783 = NOVALUE;
        _31782 = (_31784 != 0);
L5: 
        if (_31782 == 0) {
            goto L6; // [171] 273
        }
        _31786 = (_i_64665 == _36current_file_no_21759);
        if (_31786 != 0) {
            _31787 = 1;
            goto L7; // [181] 195
        }
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        _31788 = (object)*(((s1_ptr)_2)->base + _i_64665);
        _31787 = (_31788 != 0);
L7: 
        if (_31787 != 0) {
            DeRef(_31789);
            _31789 = 1;
            goto L8; // [195] 203
        }
        _31789 = (_unincluded_ok_64633 != 0);
L8: 
        if (_31789 == 0)
        {
            _31789 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31789 = NOVALUE;
        }

        /** fwdref.e:982				for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (object)SEQ_PTR(_44active_references_63195);
        _31790 = (object)*(((s1_ptr)_2)->base + _i_64665);
        if (IS_SEQUENCE(_31790)){
                _31791 = SEQ_PTR(_31790)->length;
        }
        else {
            _31791 = 1;
        }
        _31790 = NOVALUE;
        {
            object _j_64681;
            _j_64681 = _31791;
L9: 
            if (_j_64681 < 1LL){
                goto LA; // [218] 254
            }

            /** fwdref.e:983					errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (object)SEQ_PTR(_44active_references_63195);
            _31792 = (object)*(((s1_ptr)_2)->base + _i_64665);
            _2 = (object)SEQ_PTR(_31792);
            _31793 = (object)*(((s1_ptr)_2)->base + _j_64681);
            _31792 = NOVALUE;
            Ref(_31793);
            _31794 = _44resolve_file(_31793, _report_errors_64631, _unincluded_ok_64633);
            _31793 = NOVALUE;
            if (IS_SEQUENCE(_errors_64632) && IS_ATOM(_31794)) {
                Ref(_31794);
                Append(&_errors_64632, _errors_64632, _31794);
            }
            else if (IS_ATOM(_errors_64632) && IS_SEQUENCE(_31794)) {
            }
            else {
                Concat((object_ptr)&_errors_64632, _errors_64632, _31794);
            }
            DeRef(_31794);
            _31794 = NOVALUE;

            /** fwdref.e:984				end for*/
            _j_64681 = _j_64681 + -1LL;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** fwdref.e:985				errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_63196);
        _31796 = (object)*(((s1_ptr)_2)->base + _i_64665);
        Ref(_31796);
        _31797 = _44resolve_file(_31796, _report_errors_64631, _unincluded_ok_64633);
        _31796 = NOVALUE;
        if (IS_SEQUENCE(_errors_64632) && IS_ATOM(_31797)) {
            Ref(_31797);
            Append(&_errors_64632, _errors_64632, _31797);
        }
        else if (IS_ATOM(_errors_64632) && IS_SEQUENCE(_31797)) {
        }
        else {
            Concat((object_ptr)&_errors_64632, _errors_64632, _31797);
        }
        DeRef(_31797);
        _31797 = NOVALUE;
L6: 

        /** fwdref.e:987		end for*/
        _i_64665 = _i_64665 + 1LL;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** fwdref.e:989		if report_errors and length( errors ) then*/
    if (_report_errors_64631 == 0) {
        goto LB; // [282] 856
    }
    if (IS_SEQUENCE(_errors_64632)){
            _31800 = SEQ_PTR(_errors_64632)->length;
    }
    else {
        _31800 = 1;
    }
    if (_31800 == 0)
    {
        _31800 = NOVALUE;
        goto LB; // [290] 856
    }
    else{
        _31800 = NOVALUE;
    }

    /** fwdref.e:990			sequence msg = ""*/
    RefDS(_22186);
    DeRefi(_msg_64694);
    _msg_64694 = _22186;

    /** fwdref.e:991			sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31801);
    DeRefi(_errloc_64695);
    _errloc_64695 = _31801;

    /** fwdref.e:993			for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_64632)){
            _31802 = SEQ_PTR(_errors_64632)->length;
    }
    else {
        _31802 = 1;
    }
    {
        object _e_64698;
        _e_64698 = _31802;
LC: 
        if (_e_64698 < 1LL){
            goto LD; // [312] 828
        }

        /** fwdref.e:994				sequence ref = forward_references[errors[e]]*/
        _2 = (object)SEQ_PTR(_errors_64632);
        _31803 = (object)*(((s1_ptr)_2)->base + _e_64698);
        DeRef(_ref_64700);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!IS_ATOM_INT(_31803)){
            _ref_64700 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31803)->dbl));
        }
        else{
            _ref_64700 = (object)*(((s1_ptr)_2)->base + _31803);
        }
        Ref(_ref_64700);

        /** fwdref.e:995				if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (object)SEQ_PTR(_ref_64700);
        _31805 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31805)) {
            _31806 = (_31805 == 65LL);
        }
        else {
            _31806 = binary_op(EQUALS, _31805, 65LL);
        }
        _31805 = NOVALUE;
        if (IS_ATOM_INT(_31806)) {
            if (_31806 == 0) {
                DeRef(_31807);
                _31807 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31806)->dbl == 0.0) {
                DeRef(_31807);
                _31807 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (object)SEQ_PTR(_ref_64700);
        _31808 = (object)*(((s1_ptr)_2)->base + 10LL);
        if (IS_ATOM_INT(_31808)) {
            _31809 = (_31808 == 65LL);
        }
        else {
            _31809 = binary_op(EQUALS, _31808, 65LL);
        }
        _31808 = NOVALUE;
        DeRef(_31807);
        if (IS_ATOM_INT(_31809))
        _31807 = (_31809 != 0);
        else
        _31807 = DBL_PTR(_31809)->dbl != 0.0;
LE: 
        if (_31807 != 0) {
            goto LF; // [363] 382
        }
        _2 = (object)SEQ_PTR(_ref_64700);
        _31811 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31811)) {
            _31812 = (_31811 == 109LL);
        }
        else {
            _31812 = binary_op(EQUALS, _31811, 109LL);
        }
        _31811 = NOVALUE;
        if (_31812 == 0) {
            DeRef(_31812);
            _31812 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31812) && DBL_PTR(_31812)->dbl == 0.0){
                DeRef(_31812);
                _31812 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31812);
            _31812 = NOVALUE;
        }
        DeRef(_31812);
        _31812 = NOVALUE;
LF: 

        /** fwdref.e:997					continue*/
        DeRef(_ref_64700);
        _ref_64700 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** fwdref.e:1001					object tok = find_reference(ref)*/
        RefDS(_ref_64700);
        _0 = _tok_64716;
        _tok_64716 = _44find_reference(_ref_64700);
        DeRef(_0);

        /** fwdref.e:1002					integer THIS_SCOPE = 3*/
        _THIS_SCOPE_64718 = 3LL;

        /** fwdref.e:1003					integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_64719 = 4LL;

        /** fwdref.e:1004					if tok[T_ID] = IGNORED then*/
        _2 = (object)SEQ_PTR(_tok_64716);
        _31814 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(NOTEQ, _31814, 509LL)){
            _31814 = NOVALUE;
            goto L13; // [417] 760
        }
        _31814 = NOVALUE;

        /** fwdref.e:1006						switch tok[THIS_SCOPE] do*/
        _2 = (object)SEQ_PTR(_tok_64716);
        _31816 = (object)*(((s1_ptr)_2)->base + 3LL);
        if (IS_SEQUENCE(_31816) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31816)){
            if( (DBL_PTR(_31816)->dbl != (eudouble) ((object) DBL_PTR(_31816)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (object) DBL_PTR(_31816)->dbl;
        }
        else {
            _0 = _31816;
        };
        _31816 = NOVALUE;
        switch ( _0 ){ 

            /** fwdref.e:1007							case SC_UNDEFINED then*/
            case 9:

            /** fwdref.e:1008								if ref[FR_QUALIFIED] != -1 then*/
            _2 = (object)SEQ_PTR(_ref_64700);
            _31819 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(EQUALS, _31819, -1LL)){
                _31819 = NOVALUE;
                goto L15; // [442] 556
            }
            _31819 = NOVALUE;

            /** fwdref.e:1009									if ref[FR_QUALIFIED] > 0 then*/
            _2 = (object)SEQ_PTR(_ref_64700);
            _31821 = (object)*(((s1_ptr)_2)->base + 9LL);
            if (binary_op_a(LESSEQ, _31821, 0LL)){
                _31821 = NOVALUE;
                goto L16; // [452] 517
            }
            _31821 = NOVALUE;

            /** fwdref.e:1011										errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (object)SEQ_PTR(_ref_64700);
            _31824 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64700);
            _31825 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31825)){
                _31826 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31825)->dbl));
            }
            else{
                _31826 = (object)*(((s1_ptr)_2)->base + _31825);
            }
            Ref(_31826);
            RefDS(_22186);
            _31827 = _17abbreviate_path(_31826, _22186);
            _31826 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64700);
            _31828 = (object)*(((s1_ptr)_2)->base + 6LL);
            _2 = (object)SEQ_PTR(_ref_64700);
            _31829 = (object)*(((s1_ptr)_2)->base + 9LL);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31829)){
                _31830 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31829)->dbl));
            }
            else{
                _31830 = (object)*(((s1_ptr)_2)->base + _31829);
            }
            Ref(_31830);
            RefDS(_22186);
            _31831 = _17abbreviate_path(_31830, _22186);
            _31830 = NOVALUE;
            _31832 = _16find_replace(92LL, _31831, 47LL, 0LL);
            _31831 = NOVALUE;
            _1 = NewS1(4);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31824);
            ((intptr_t*)_2)[1] = _31824;
            ((intptr_t*)_2)[2] = _31827;
            Ref(_31828);
            ((intptr_t*)_2)[3] = _31828;
            ((intptr_t*)_2)[4] = _31832;
            _31833 = MAKE_SEQ(_1);
            _31832 = NOVALUE;
            _31828 = NOVALUE;
            _31827 = NOVALUE;
            _31824 = NOVALUE;
            DeRefi(_errloc_64695);
            _errloc_64695 = EPrintf(-9999999, _31823, _31833);
            DeRefDS(_31833);
            _31833 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** fwdref.e:1016										errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (object)SEQ_PTR(_ref_64700);
            _31836 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64700);
            _31837 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31837)){
                _31838 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31837)->dbl));
            }
            else{
                _31838 = (object)*(((s1_ptr)_2)->base + _31837);
            }
            Ref(_31838);
            RefDS(_22186);
            _31839 = _17abbreviate_path(_31838, _22186);
            _31838 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64700);
            _31840 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31836);
            ((intptr_t*)_2)[1] = _31836;
            ((intptr_t*)_2)[2] = _31839;
            Ref(_31840);
            ((intptr_t*)_2)[3] = _31840;
            _31841 = MAKE_SEQ(_1);
            _31840 = NOVALUE;
            _31839 = NOVALUE;
            _31836 = NOVALUE;
            DeRefi(_errloc_64695);
            _errloc_64695 = EPrintf(-9999999, _31835, _31841);
            DeRefDS(_31841);
            _31841 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** fwdref.e:1021									errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (object)SEQ_PTR(_ref_64700);
            _31844 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64700);
            _31845 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31845)){
                _31846 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31845)->dbl));
            }
            else{
                _31846 = (object)*(((s1_ptr)_2)->base + _31845);
            }
            Ref(_31846);
            RefDS(_22186);
            _31847 = _17abbreviate_path(_31846, _22186);
            _31846 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64700);
            _31848 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31844);
            ((intptr_t*)_2)[1] = _31844;
            ((intptr_t*)_2)[2] = _31847;
            Ref(_31848);
            ((intptr_t*)_2)[3] = _31848;
            _31849 = MAKE_SEQ(_1);
            _31848 = NOVALUE;
            _31847 = NOVALUE;
            _31844 = NOVALUE;
            DeRefi(_errloc_64695);
            _errloc_64695 = EPrintf(-9999999, _31843, _31849);
            DeRefDS(_31849);
            _31849 = NOVALUE;
            goto L17; // [592] 759

            /** fwdref.e:1024							case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** fwdref.e:1025								sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_64777);
            _2 = (object)SEQ_PTR(_tok_64716);
            _syms_64777 = (object)*(((s1_ptr)_2)->base + _THESE_GLOBALS_64719);
            Ref(_syms_64777);

            /** fwdref.e:1026								syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31853 = CRoutineId(1385, 44, _31852);
            RefDS(_syms_64777);
            RefDS(_22186);
            _0 = _syms_64777;
            _syms_64777 = _24custom_sort(_31853, _syms_64777, _22186, 1LL);
            DeRefDS(_0);
            _31853 = NOVALUE;

            /** fwdref.e:1027								errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (object)SEQ_PTR(_ref_64700);
            _31856 = (object)*(((s1_ptr)_2)->base + 2LL);
            _2 = (object)SEQ_PTR(_ref_64700);
            _31857 = (object)*(((s1_ptr)_2)->base + 3LL);
            _2 = (object)SEQ_PTR(_37known_files_15638);
            if (!IS_ATOM_INT(_31857)){
                _31858 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31857)->dbl));
            }
            else{
                _31858 = (object)*(((s1_ptr)_2)->base + _31857);
            }
            Ref(_31858);
            RefDS(_22186);
            _31859 = _17abbreviate_path(_31858, _22186);
            _31858 = NOVALUE;
            _2 = (object)SEQ_PTR(_ref_64700);
            _31860 = (object)*(((s1_ptr)_2)->base + 6LL);
            _1 = NewS1(3);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_31856);
            ((intptr_t*)_2)[1] = _31856;
            ((intptr_t*)_2)[2] = _31859;
            Ref(_31860);
            ((intptr_t*)_2)[3] = _31860;
            _31861 = MAKE_SEQ(_1);
            _31860 = NOVALUE;
            _31859 = NOVALUE;
            _31856 = NOVALUE;
            DeRefi(_errloc_64695);
            _errloc_64695 = EPrintf(-9999999, _31855, _31861);
            DeRefDS(_31861);
            _31861 = NOVALUE;

            /** fwdref.e:1029								for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_64777)){
                    _31863 = SEQ_PTR(_syms_64777)->length;
            }
            else {
                _31863 = 1;
            }
            {
                object _si_64795;
                _si_64795 = 1LL;
L18: 
                if (_si_64795 > _31863){
                    goto L19; // [664] 750
                }

                /** fwdref.e:1030									symtab_index s = syms[si] */
                _2 = (object)SEQ_PTR(_syms_64777);
                _s_64798 = (object)*(((s1_ptr)_2)->base + _si_64795);
                if (!IS_ATOM_INT(_s_64798)){
                    _s_64798 = (object)DBL_PTR(_s_64798)->dbl;
                }

                /** fwdref.e:1031									if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (object)SEQ_PTR(_ref_64700);
                _31865 = (object)*(((s1_ptr)_2)->base + 2LL);
                _31866 = _54sym_name(_s_64798);
                if (_31865 == _31866)
                _31867 = 1;
                else if (IS_ATOM_INT(_31865) && IS_ATOM_INT(_31866))
                _31867 = 0;
                else
                _31867 = (compare(_31865, _31866) == 0);
                _31865 = NOVALUE;
                DeRef(_31866);
                _31866 = NOVALUE;
                if (_31867 == 0)
                {
                    _31867 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31867 = NOVALUE;
                }

                /** fwdref.e:1032										errloc &= sprintf("\t\tin %s\n", */
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _31869 = (object)*(((s1_ptr)_2)->base + _s_64798);
                _2 = (object)SEQ_PTR(_31869);
                if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
                    _31870 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
                }
                else{
                    _31870 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
                }
                _31869 = NOVALUE;
                _2 = (object)SEQ_PTR(_37known_files_15638);
                if (!IS_ATOM_INT(_31870)){
                    _31871 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31870)->dbl));
                }
                else{
                    _31871 = (object)*(((s1_ptr)_2)->base + _31870);
                }
                Ref(_31871);
                RefDS(_22186);
                _31872 = _17abbreviate_path(_31871, _22186);
                _31871 = NOVALUE;
                _31873 = _16find_replace(92LL, _31872, 47LL, 0LL);
                _31872 = NOVALUE;
                _1 = NewS1(1);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t*)_2)[1] = _31873;
                _31874 = MAKE_SEQ(_1);
                _31873 = NOVALUE;
                _31875 = EPrintf(-9999999, _31868, _31874);
                DeRefDS(_31874);
                _31874 = NOVALUE;
                Concat((object_ptr)&_errloc_64695, _errloc_64695, _31875);
                DeRefDS(_31875);
                _31875 = NOVALUE;
L1A: 

                /** fwdref.e:1035								end for*/
                _si_64795 = _si_64795 + 1LL;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_64777);
            _syms_64777 = NOVALUE;
            goto L17; // [752] 759

            /** fwdref.e:1036							case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** fwdref.e:1040					if not match(errloc, msg) then*/
        _31877 = e_match_from(_errloc_64695, _msg_64694, 1LL);
        if (_31877 != 0)
        goto L1B; // [767] 786
        _31877 = NOVALUE;

        /** fwdref.e:1041						msg &= errloc*/
        Concat((object_ptr)&_msg_64694, _msg_64694, _errloc_64695);

        /** fwdref.e:1042						prep_forward_error( errors[e] )*/
        _2 = (object)SEQ_PTR(_errors_64632);
        _31880 = (object)*(((s1_ptr)_2)->base + _e_64698);
        Ref(_31880);
        _44prep_forward_error(_31880);
        _31880 = NOVALUE;
L1B: 
        DeRef(_tok_64716);
        _tok_64716 = NOVALUE;
L12: 

        /** fwdref.e:1045				ThisLine    = ref[FR_THISLINE]*/
        DeRef(_50ThisLine_49590);
        _2 = (object)SEQ_PTR(_ref_64700);
        _50ThisLine_49590 = (object)*(((s1_ptr)_2)->base + 7LL);
        Ref(_50ThisLine_49590);

        /** fwdref.e:1046				bp          = ref[FR_BP]*/
        _2 = (object)SEQ_PTR(_ref_64700);
        _50bp_49594 = (object)*(((s1_ptr)_2)->base + 8LL);
        if (!IS_ATOM_INT(_50bp_49594)){
            _50bp_49594 = (object)DBL_PTR(_50bp_49594)->dbl;
        }

        /** fwdref.e:1047				CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (object)SEQ_PTR(_ref_64700);
        _36CurrentSub_21767 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (!IS_ATOM_INT(_36CurrentSub_21767)){
            _36CurrentSub_21767 = (object)DBL_PTR(_36CurrentSub_21767)->dbl;
        }

        /** fwdref.e:1048				line_number = ref[FR_LINE]*/
        _2 = (object)SEQ_PTR(_ref_64700);
        _36line_number_21760 = (object)*(((s1_ptr)_2)->base + 6LL);
        if (!IS_ATOM_INT(_36line_number_21760)){
            _36line_number_21760 = (object)DBL_PTR(_36line_number_21760)->dbl;
        }
        DeRefDS(_ref_64700);
        _ref_64700 = NOVALUE;

        /** fwdref.e:1049			end for*/
L11: 
        _e_64698 = _e_64698 + -1LL;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** fwdref.e:1050			if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_64694)){
            _31885 = SEQ_PTR(_msg_64694)->length;
    }
    else {
        _31885 = 1;
    }
    if (_31885 <= 0LL)
    goto L1C; // [833] 851

    /** fwdref.e:1051				CompileErr( ERRORS_RESOLVING_THE_FOLLOWING_REFERENCES1, {msg} )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_msg_64694);
    ((intptr_t*)_2)[1] = _msg_64694;
    _31887 = MAKE_SEQ(_1);
    _50CompileErr(74LL, _31887, 0LL);
    _31887 = NOVALUE;
L1C: 
    DeRefi(_msg_64694);
    _msg_64694 = NOVALUE;
    DeRefi(_errloc_64695);
    _errloc_64695 = NOVALUE;
    goto L1D; // [853] 901
LB: 

    /** fwdref.e:1053		elsif report_errors and not repl then*/
    if (_report_errors_64631 == 0) {
        goto L1E; // [858] 900
    }
    _31889 = (0LL == 0);
    if (_31889 == 0)
    {
        DeRef(_31889);
        _31889 = NOVALUE;
        goto L1E; // [868] 900
    }
    else{
        DeRef(_31889);
        _31889 = NOVALUE;
    }

    /** fwdref.e:1055			forward_references  = {}*/
    RefDS(_22186);
    DeRef(_44forward_references_63193);
    _44forward_references_63193 = _22186;

    /** fwdref.e:1056			active_references   = {}*/
    RefDS(_22186);
    DeRef(_44active_references_63195);
    _44active_references_63195 = _22186;

    /** fwdref.e:1057			toplevel_references = {}*/
    RefDS(_22186);
    DeRef(_44toplevel_references_63196);
    _44toplevel_references_63196 = _22186;

    /** fwdref.e:1058			inactive_references = {}*/
    RefDS(_22186);
    DeRef(_44inactive_references_63197);
    _44inactive_references_63197 = _22186;
L1E: 
L1D: 

    /** fwdref.e:1060		clear_last()*/
    _47clear_last();

    /** fwdref.e:1061	end procedure*/
    DeRef(_errors_64632);
    _31829 = NOVALUE;
    _31870 = NOVALUE;
    DeRef(_31809);
    _31809 = NOVALUE;
    _31788 = NOVALUE;
    DeRef(_31806);
    _31806 = NOVALUE;
    _31780 = NOVALUE;
    _31825 = NOVALUE;
    _31790 = NOVALUE;
    _31803 = NOVALUE;
    _31845 = NOVALUE;
    _31837 = NOVALUE;
    DeRef(_31786);
    _31786 = NOVALUE;
    _31857 = NOVALUE;
    _31783 = NOVALUE;
    return;
    ;
}


void _44shift_these(object _refs_64846, object _pc_64847, object _amount_64848)
{
    object _fr_64852 = NOVALUE;
    object _31907 = NOVALUE;
    object _31906 = NOVALUE;
    object _31905 = NOVALUE;
    object _31904 = NOVALUE;
    object _31903 = NOVALUE;
    object _31902 = NOVALUE;
    object _31901 = NOVALUE;
    object _31900 = NOVALUE;
    object _31899 = NOVALUE;
    object _31898 = NOVALUE;
    object _31896 = NOVALUE;
    object _31894 = NOVALUE;
    object _31893 = NOVALUE;
    object _31891 = NOVALUE;
    object _31890 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1064		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64846)){
            _31890 = SEQ_PTR(_refs_64846)->length;
    }
    else {
        _31890 = 1;
    }
    {
        object _i_64850;
        _i_64850 = _31890;
L1: 
        if (_i_64850 < 1LL){
            goto L2; // [12] 147
        }

        /** fwdref.e:1065			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64846);
        _31891 = (object)*(((s1_ptr)_2)->base + _i_64850);
        DeRef(_fr_64852);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!IS_ATOM_INT(_31891)){
            _fr_64852 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31891)->dbl));
        }
        else{
            _fr_64852 = (object)*(((s1_ptr)_2)->base + _31891);
        }
        Ref(_fr_64852);

        /** fwdref.e:1066			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64846);
        _31893 = (object)*(((s1_ptr)_2)->base + _i_64850);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63193 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31893))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31893)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31893);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1067			if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (object)SEQ_PTR(_fr_64852);
        _31894 = (object)*(((s1_ptr)_2)->base + 4LL);
        if (binary_op_a(NOTEQ, _31894, _44shifting_sub_63212)){
            _31894 = NOVALUE;
            goto L3; // [53] 126
        }
        _31894 = NOVALUE;

        /** fwdref.e:1068				if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64852);
        _31896 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31896, _pc_64847)){
            _31896 = NOVALUE;
            goto L4; // [63] 125
        }
        _31896 = NOVALUE;

        /** fwdref.e:1069					fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64852);
        _31898 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31898)) {
            _31899 = _31898 + _amount_64848;
            if ((object)((uintptr_t)_31899 + (uintptr_t)HIGH_BITS) >= 0){
                _31899 = NewDouble((eudouble)_31899);
            }
        }
        else {
            _31899 = binary_op(PLUS, _31898, _amount_64848);
        }
        _31898 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64852);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64852 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31899;
        if( _1 != _31899 ){
            DeRef(_1);
        }
        _31899 = NOVALUE;

        /** fwdref.e:1070					if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64852);
        _31900 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31900)) {
            _31901 = (_31900 == 186LL);
        }
        else {
            _31901 = binary_op(EQUALS, _31900, 186LL);
        }
        _31900 = NOVALUE;
        if (IS_ATOM_INT(_31901)) {
            if (_31901 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31901)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (object)SEQ_PTR(_fr_64852);
        _31903 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31903)) {
            _31904 = (_31903 >= _pc_64847);
        }
        else {
            _31904 = binary_op(GREATEREQ, _31903, _pc_64847);
        }
        _31903 = NOVALUE;
        if (_31904 == 0) {
            DeRef(_31904);
            _31904 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31904) && DBL_PTR(_31904)->dbl == 0.0){
                DeRef(_31904);
                _31904 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31904);
            _31904 = NOVALUE;
        }
        DeRef(_31904);
        _31904 = NOVALUE;

        /** fwdref.e:1073						fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64852);
        _31905 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31905)) {
            _31906 = _31905 + _amount_64848;
            if ((object)((uintptr_t)_31906 + (uintptr_t)HIGH_BITS) >= 0){
                _31906 = NewDouble((eudouble)_31906);
            }
        }
        else {
            _31906 = binary_op(PLUS, _31905, _amount_64848);
        }
        _31905 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64852);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64852 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31906;
        if( _1 != _31906 ){
            DeRef(_1);
        }
        _31906 = NOVALUE;
L5: 
L4: 
L3: 

        /** fwdref.e:1077			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64846);
        _31907 = (object)*(((s1_ptr)_2)->base + _i_64850);
        RefDS(_fr_64852);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63193 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31907))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31907)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31907);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64852;
        DeRef(_1);
        DeRefDS(_fr_64852);
        _fr_64852 = NOVALUE;

        /** fwdref.e:1078		end for*/
        _i_64850 = _i_64850 + -1LL;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** fwdref.e:1079	end procedure*/
    DeRefDS(_refs_64846);
    _31907 = NOVALUE;
    DeRef(_31901);
    _31901 = NOVALUE;
    _31891 = NOVALUE;
    _31893 = NOVALUE;
    return;
    ;
}


void _44shift_top(object _refs_64876, object _pc_64877, object _amount_64878)
{
    object _fr_64882 = NOVALUE;
    object _31923 = NOVALUE;
    object _31922 = NOVALUE;
    object _31921 = NOVALUE;
    object _31920 = NOVALUE;
    object _31919 = NOVALUE;
    object _31918 = NOVALUE;
    object _31917 = NOVALUE;
    object _31916 = NOVALUE;
    object _31915 = NOVALUE;
    object _31914 = NOVALUE;
    object _31912 = NOVALUE;
    object _31911 = NOVALUE;
    object _31909 = NOVALUE;
    object _31908 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1083		for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_64876)){
            _31908 = SEQ_PTR(_refs_64876)->length;
    }
    else {
        _31908 = 1;
    }
    {
        object _i_64880;
        _i_64880 = _31908;
L1: 
        if (_i_64880 < 1LL){
            goto L2; // [12] 134
        }

        /** fwdref.e:1084			sequence fr = forward_references[refs[i]]*/
        _2 = (object)SEQ_PTR(_refs_64876);
        _31909 = (object)*(((s1_ptr)_2)->base + _i_64880);
        DeRef(_fr_64882);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!IS_ATOM_INT(_31909)){
            _fr_64882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_31909)->dbl));
        }
        else{
            _fr_64882 = (object)*(((s1_ptr)_2)->base + _31909);
        }
        Ref(_fr_64882);

        /** fwdref.e:1085			forward_references[refs[i]] = 0*/
        _2 = (object)SEQ_PTR(_refs_64876);
        _31911 = (object)*(((s1_ptr)_2)->base + _i_64880);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63193 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31911))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31911)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31911);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);

        /** fwdref.e:1086			if fr[FR_PC] >= pc then*/
        _2 = (object)SEQ_PTR(_fr_64882);
        _31912 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (binary_op_a(LESS, _31912, _pc_64877)){
            _31912 = NOVALUE;
            goto L3; // [51] 113
        }
        _31912 = NOVALUE;

        /** fwdref.e:1087				fr[FR_PC] += amount*/
        _2 = (object)SEQ_PTR(_fr_64882);
        _31914 = (object)*(((s1_ptr)_2)->base + 5LL);
        if (IS_ATOM_INT(_31914)) {
            _31915 = _31914 + _amount_64878;
            if ((object)((uintptr_t)_31915 + (uintptr_t)HIGH_BITS) >= 0){
                _31915 = NewDouble((eudouble)_31915);
            }
        }
        else {
            _31915 = binary_op(PLUS, _31914, _amount_64878);
        }
        _31914 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64882);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64882 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 5LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31915;
        if( _1 != _31915 ){
            DeRef(_1);
        }
        _31915 = NOVALUE;

        /** fwdref.e:1088				if fr[FR_TYPE] = CASE*/
        _2 = (object)SEQ_PTR(_fr_64882);
        _31916 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (IS_ATOM_INT(_31916)) {
            _31917 = (_31916 == 186LL);
        }
        else {
            _31917 = binary_op(EQUALS, _31916, 186LL);
        }
        _31916 = NOVALUE;
        if (IS_ATOM_INT(_31917)) {
            if (_31917 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31917)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (object)SEQ_PTR(_fr_64882);
        _31919 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31919)) {
            _31920 = (_31919 >= _pc_64877);
        }
        else {
            _31920 = binary_op(GREATEREQ, _31919, _pc_64877);
        }
        _31919 = NOVALUE;
        if (_31920 == 0) {
            DeRef(_31920);
            _31920 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31920) && DBL_PTR(_31920)->dbl == 0.0){
                DeRef(_31920);
                _31920 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31920);
            _31920 = NOVALUE;
        }
        DeRef(_31920);
        _31920 = NOVALUE;

        /** fwdref.e:1091					fr[FR_DATA] += amount*/
        _2 = (object)SEQ_PTR(_fr_64882);
        _31921 = (object)*(((s1_ptr)_2)->base + 12LL);
        if (IS_ATOM_INT(_31921)) {
            _31922 = _31921 + _amount_64878;
            if ((object)((uintptr_t)_31922 + (uintptr_t)HIGH_BITS) >= 0){
                _31922 = NewDouble((eudouble)_31922);
            }
        }
        else {
            _31922 = binary_op(PLUS, _31921, _amount_64878);
        }
        _31921 = NOVALUE;
        _2 = (object)SEQ_PTR(_fr_64882);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _fr_64882 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 12LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _31922;
        if( _1 != _31922 ){
            DeRef(_1);
        }
        _31922 = NOVALUE;
L4: 
L3: 

        /** fwdref.e:1094			forward_references[refs[i]] = fr*/
        _2 = (object)SEQ_PTR(_refs_64876);
        _31923 = (object)*(((s1_ptr)_2)->base + _i_64880);
        RefDS(_fr_64882);
        _2 = (object)SEQ_PTR(_44forward_references_63193);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _44forward_references_63193 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31923))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_31923)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _31923);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _fr_64882;
        DeRef(_1);
        DeRefDS(_fr_64882);
        _fr_64882 = NOVALUE;

        /** fwdref.e:1095		end for*/
        _i_64880 = _i_64880 + -1LL;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** fwdref.e:1096	end procedure*/
    DeRefDS(_refs_64876);
    _31923 = NOVALUE;
    DeRef(_31917);
    _31917 = NOVALUE;
    _31911 = NOVALUE;
    _31909 = NOVALUE;
    return;
    ;
}


void _44shift_fwd_refs(object _pc_64903, object _amount_64904)
{
    object _file_64915 = NOVALUE;
    object _sp_64920 = NOVALUE;
    object _31933 = NOVALUE;
    object _31932 = NOVALUE;
    object _31930 = NOVALUE;
    object _31928 = NOVALUE;
    object _31927 = NOVALUE;
    object _31926 = NOVALUE;
    object _0, _1, _2;
    

    /** fwdref.e:1099		if not shifting_sub then*/
    if (_44shifting_sub_63212 != 0)
    goto L1; // [9] 18

    /** fwdref.e:1100			return*/
    return;
L1: 

    /** fwdref.e:1103		if shifting_sub = TopLevelSub then*/
    if (_44shifting_sub_63212 != _36TopLevelSub_21766)
    goto L2; // [24] 65

    /** fwdref.e:1104			for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_44toplevel_references_63196)){
            _31926 = SEQ_PTR(_44toplevel_references_63196)->length;
    }
    else {
        _31926 = 1;
    }
    {
        object _file_64911;
        _file_64911 = 1LL;
L3: 
        if (_file_64911 > _31926){
            goto L4; // [35] 62
        }

        /** fwdref.e:1105				shift_top( toplevel_references[file], pc, amount )*/
        _2 = (object)SEQ_PTR(_44toplevel_references_63196);
        _31927 = (object)*(((s1_ptr)_2)->base + _file_64911);
        Ref(_31927);
        _44shift_top(_31927, _pc_64903, _amount_64904);
        _31927 = NOVALUE;

        /** fwdref.e:1106			end for*/
        _file_64911 = _file_64911 + 1LL;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** fwdref.e:1108			integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _31928 = (object)*(((s1_ptr)_2)->base + _44shifting_sub_63212);
    _2 = (object)SEQ_PTR(_31928);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _file_64915 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _file_64915 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_file_64915)){
        _file_64915 = (object)DBL_PTR(_file_64915)->dbl;
    }
    _31928 = NOVALUE;

    /** fwdref.e:1109			integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (object)SEQ_PTR(_44active_subprogs_63194);
    _31930 = (object)*(((s1_ptr)_2)->base + _file_64915);
    _sp_64920 = find_from(_44shifting_sub_63212, _31930, 1LL);
    _31930 = NOVALUE;

    /** fwdref.e:1110			shift_these( active_references[file][sp], pc, amount )*/
    _2 = (object)SEQ_PTR(_44active_references_63195);
    _31932 = (object)*(((s1_ptr)_2)->base + _file_64915);
    _2 = (object)SEQ_PTR(_31932);
    _31933 = (object)*(((s1_ptr)_2)->base + _sp_64920);
    _31932 = NOVALUE;
    Ref(_31933);
    _44shift_these(_31933, _pc_64903, _amount_64904);
    _31933 = NOVALUE;
L5: 

    /** fwdref.e:1112	end procedure*/
    return;
    ;
}



// 0x4320676D
