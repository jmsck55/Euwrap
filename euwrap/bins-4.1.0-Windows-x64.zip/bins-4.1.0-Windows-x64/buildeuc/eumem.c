// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _30malloc(object _mem_struct_p_11354, object _cleanup_p_11355)
{
    object _temp__11356 = NOVALUE;
    object _6382 = NOVALUE;
    object _6380 = NOVALUE;
    object _6379 = NOVALUE;
    object _6378 = NOVALUE;
    object _6374 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:51		if atom(mem_struct_p) then*/
    _6374 = IS_ATOM(_mem_struct_p_11354);
    if (_6374 == 0)
    {
        _6374 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _6374 = NOVALUE;
    }

    /** eumem.e:52			mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_11354;
    _mem_struct_p_11354 = Repeat(0LL, _mem_struct_p_11354);
    DeRef(_0);
L1: 

    /** eumem.e:54		if ram_free_list = 0 then*/
    if (_30ram_free_list_11350 != 0LL)
    goto L2; // [22] 72

    /** eumem.e:55			ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_11354);
    Append(&_30ram_space_11346, _30ram_space_11346, _mem_struct_p_11354);

    /** eumem.e:56			if cleanup_p then*/
    if (_cleanup_p_11355 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** eumem.e:57				return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_30ram_space_11346)){
            _6378 = SEQ_PTR(_30ram_space_11346)->length;
    }
    else {
        _6378 = 1;
    }
    _6379 = NewDouble( (eudouble) _6378 );
    _1 = (object) _00[_30free_rid_11351].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_30free_rid_11351].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _30free_rid_11351;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6379)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6379)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6379)) ){
        DeRefDS(_6379);
        _6379 = NewDouble( DBL_PTR(_6379)->dbl );
    }
    DBL_PTR(_6379)->cleanup = (cleanup_ptr)_1;
    _6378 = NOVALUE;
    DeRef(_mem_struct_p_11354);
    return _6379;
    goto L4; // [56] 71
L3: 

    /** eumem.e:59				return length(ram_space)*/
    if (IS_SEQUENCE(_30ram_space_11346)){
            _6380 = SEQ_PTR(_30ram_space_11346)->length;
    }
    else {
        _6380 = 1;
    }
    DeRef(_mem_struct_p_11354);
    DeRef(_6379);
    _6379 = NOVALUE;
    return _6380;
L4: 
L2: 

    /** eumem.e:63		temp_ = ram_free_list*/
    _temp__11356 = _30ram_free_list_11350;

    /** eumem.e:64		ram_free_list = ram_space[temp_]*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    _30ram_free_list_11350 = (object)*(((s1_ptr)_2)->base + _temp__11356);
    if (!IS_ATOM_INT(_30ram_free_list_11350))
    _30ram_free_list_11350 = (object)DBL_PTR(_30ram_free_list_11350)->dbl;

    /** eumem.e:65		ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_11354);
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _temp__11356);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _mem_struct_p_11354;
    DeRef(_1);

    /** eumem.e:67		if cleanup_p then*/
    if (_cleanup_p_11355 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** eumem.e:68			return delete_routine( temp_, free_rid )*/
    _6382 = NewDouble( (eudouble) _temp__11356 );
    _1 = (object) _00[_30free_rid_11351].cleanup;
    if( _1 == 0 ){
        _1 = (object) TransAlloc( sizeof(struct cleanup) );
        _00[_30free_rid_11351].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _30free_rid_11351;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6382)->cleanup != 0 ){
        _1 = (object) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6382)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6382)) ){
        DeRefDS(_6382);
        _6382 = NewDouble( DBL_PTR(_6382)->dbl );
    }
    DBL_PTR(_6382)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_11354);
    DeRef(_6379);
    _6379 = NOVALUE;
    return _6382;
    goto L6; // [112] 122
L5: 

    /** eumem.e:70			return temp_*/
    DeRef(_mem_struct_p_11354);
    DeRef(_6379);
    _6379 = NOVALUE;
    DeRef(_6382);
    _6382 = NOVALUE;
    return _temp__11356;
L6: 
    ;
}


void _30free(object _mem_p_11374)
{
    object _6385 = NOVALUE;
    object _6383 = NOVALUE;
    object _0, _1, _2;
    

    /** eumem.e:95		if object( ram_space ) then*/
    if( NOVALUE == _30ram_space_11346 ){
        _6383 = 0;
    }
    else{
        _6383 = 3;
    }
    if (_6383 == 0)
    {
        _6383 = NOVALUE;
        goto L1; // [6] 52
    }
    else{
        _6383 = NOVALUE;
    }

    /** eumem.e:96			if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_11374, 1LL)){
        goto L2; // [11] 19
    }
    DeRef(_mem_p_11374);
    return;
L2: 

    /** eumem.e:97			if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_30ram_space_11346)){
            _6385 = SEQ_PTR(_30ram_space_11346)->length;
    }
    else {
        _6385 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_11374, _6385)){
        _6385 = NOVALUE;
        goto L3; // [26] 34
    }
    _6385 = NOVALUE;
    DeRef(_mem_p_11374);
    return;
L3: 

    /** eumem.e:99			ram_space[mem_p] = ram_free_list*/
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_11374))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_mem_p_11374)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _mem_p_11374);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _30ram_free_list_11350;
    DeRef(_1);

    /** eumem.e:100			ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_11374))
    _30ram_free_list_11350 = e_floor(_mem_p_11374);
    else
    _30ram_free_list_11350 = unary_op(FLOOR, _mem_p_11374);
    if (!IS_ATOM_INT(_30ram_free_list_11350)) {
        _1 = (object)(DBL_PTR(_30ram_free_list_11350)->dbl);
        DeRefDS(_30ram_free_list_11350);
        _30ram_free_list_11350 = _1;
    }
L1: 

    /** eumem.e:102	end procedure*/
    DeRef(_mem_p_11374);
    return;
    ;
}



// 0x26B05CFF
