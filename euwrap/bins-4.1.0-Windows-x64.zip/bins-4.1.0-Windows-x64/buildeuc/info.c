// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _33arch_bits()
{
    object _6779 = NOVALUE;
    object _6778 = NOVALUE;
    object _6777 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:72		return sprintf( "%d-bit", 8 * sizeof( C_POINTER ) )*/
    _6777 = eu_sizeof( 50331649LL );
    {
        int128_t p128 = (int128_t)8LL * (int128_t)_6777;
        if( p128 != (int128_t)(_6778 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _6778 = NewDouble( (eudouble)p128 );
        }
    }
    _6777 = NOVALUE;
    _6779 = EPrintf(-9999999, _6776, _6778);
    DeRef(_6778);
    _6778 = NOVALUE;
    return _6779;
    ;
}


object _33version_major()
{
    object _6788 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:100		return version_info[MAJ_VER]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6788 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_6788);
    return _6788;
    ;
}


object _33version_minor()
{
    object _6789 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:112		return version_info[MIN_VER]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6789 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_6789);
    return _6789;
    ;
}


object _33version_patch()
{
    object _6790 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:124		return version_info[PAT_VER]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6790 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_6790);
    return _6790;
    ;
}


object _33version_node(object _full_12130)
{
    object _6797 = NOVALUE;
    object _6796 = NOVALUE;
    object _6795 = NOVALUE;
    object _6794 = NOVALUE;
    object _6793 = NOVALUE;
    object _6792 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:141		if full or length(version_info[NODE]) < 12 then*/
    if (0LL != 0) {
        goto L1; // [5] 27
    }
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6792 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_SEQUENCE(_6792)){
            _6793 = SEQ_PTR(_6792)->length;
    }
    else {
        _6793 = 1;
    }
    _6792 = NOVALUE;
    _6794 = (_6793 < 12LL);
    _6793 = NOVALUE;
    if (_6794 == 0)
    {
        DeRef(_6794);
        _6794 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_6794);
        _6794 = NOVALUE;
    }
L1: 

    /** info.e:142			return version_info[NODE]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6795 = (object)*(((s1_ptr)_2)->base + 5LL);
    Ref(_6795);
    _6792 = NOVALUE;
    return _6795;
L2: 

    /** info.e:145		return version_info[NODE][1..12]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6796 = (object)*(((s1_ptr)_2)->base + 5LL);
    rhs_slice_target = (object_ptr)&_6797;
    RHS_Slice(_6796, 1LL, 12LL);
    _6796 = NOVALUE;
    _6792 = NOVALUE;
    _6795 = NOVALUE;
    return _6797;
    ;
}


object _33version_date(object _full_12144)
{
    object _6806 = NOVALUE;
    object _6805 = NOVALUE;
    object _6804 = NOVALUE;
    object _6803 = NOVALUE;
    object _6802 = NOVALUE;
    object _6801 = NOVALUE;
    object _6799 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:181		if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_12144 != 0) {
        _6799 = 1;
        goto L1; // [5] 15
    }
    _6799 = (_33is_developmental_12087 != 0);
L1: 
    if (_6799 != 0) {
        goto L2; // [15] 37
    }
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6801 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (IS_SEQUENCE(_6801)){
            _6802 = SEQ_PTR(_6801)->length;
    }
    else {
        _6802 = 1;
    }
    _6801 = NOVALUE;
    _6803 = (_6802 < 10LL);
    _6802 = NOVALUE;
    if (_6803 == 0)
    {
        DeRef(_6803);
        _6803 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_6803);
        _6803 = NOVALUE;
    }
L2: 

    /** info.e:182			return version_info[REVISION_DATE]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6804 = (object)*(((s1_ptr)_2)->base + 7LL);
    Ref(_6804);
    _6801 = NOVALUE;
    return _6804;
L3: 

    /** info.e:185		return version_info[REVISION_DATE][1..10]*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6805 = (object)*(((s1_ptr)_2)->base + 7LL);
    rhs_slice_target = (object_ptr)&_6806;
    RHS_Slice(_6805, 1LL, 10LL);
    _6805 = NOVALUE;
    _6804 = NOVALUE;
    _6801 = NOVALUE;
    return _6806;
    ;
}


object _33version_string(object _full_12159)
{
    object _version_revision_inlined_version_revision_at_41_12168 = NOVALUE;
    object _6826 = NOVALUE;
    object _6825 = NOVALUE;
    object _6824 = NOVALUE;
    object _6823 = NOVALUE;
    object _6822 = NOVALUE;
    object _6821 = NOVALUE;
    object _6820 = NOVALUE;
    object _6819 = NOVALUE;
    object _6817 = NOVALUE;
    object _6816 = NOVALUE;
    object _6815 = NOVALUE;
    object _6814 = NOVALUE;
    object _6813 = NOVALUE;
    object _6812 = NOVALUE;
    object _6811 = NOVALUE;
    object _6810 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:225		if full or is_developmental then*/
    if (0LL != 0) {
        goto L1; // [5] 16
    }
    if (_33is_developmental_12087 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** info.e:226			return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6810 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6811 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6812 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6813 = (object)*(((s1_ptr)_2)->base + 4LL);

    /** info.e:157		return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_12168);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _version_revision_inlined_version_revision_at_41_12168 = (object)*(((s1_ptr)_2)->base + 6LL);
    Ref(_version_revision_inlined_version_revision_at_41_12168);
    _6814 = _33version_node(0LL);
    _6815 = _33version_date(_full_12159);
    _1 = NewS1(7);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_6810);
    ((intptr_t*)_2)[1] = _6810;
    Ref(_6811);
    ((intptr_t*)_2)[2] = _6811;
    Ref(_6812);
    ((intptr_t*)_2)[3] = _6812;
    Ref(_6813);
    ((intptr_t*)_2)[4] = _6813;
    Ref(_version_revision_inlined_version_revision_at_41_12168);
    ((intptr_t*)_2)[5] = _version_revision_inlined_version_revision_at_41_12168;
    ((intptr_t*)_2)[6] = _6814;
    ((intptr_t*)_2)[7] = _6815;
    _6816 = MAKE_SEQ(_1);
    _6815 = NOVALUE;
    _6814 = NOVALUE;
    _6813 = NOVALUE;
    _6812 = NOVALUE;
    _6811 = NOVALUE;
    _6810 = NOVALUE;
    _6817 = EPrintf(-9999999, _6809, _6816);
    DeRefDS(_6816);
    _6816 = NOVALUE;
    return _6817;
    goto L3; // [77] 132
L2: 

    /** info.e:236			return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6819 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6820 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6821 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_33version_info_12085);
    _6822 = (object)*(((s1_ptr)_2)->base + 4LL);
    _6823 = _33version_node(0LL);
    _6824 = _33version_date(_full_12159);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_6819);
    ((intptr_t*)_2)[1] = _6819;
    Ref(_6820);
    ((intptr_t*)_2)[2] = _6820;
    Ref(_6821);
    ((intptr_t*)_2)[3] = _6821;
    Ref(_6822);
    ((intptr_t*)_2)[4] = _6822;
    ((intptr_t*)_2)[5] = _6823;
    ((intptr_t*)_2)[6] = _6824;
    _6825 = MAKE_SEQ(_1);
    _6824 = NOVALUE;
    _6823 = NOVALUE;
    _6822 = NOVALUE;
    _6821 = NOVALUE;
    _6820 = NOVALUE;
    _6819 = NOVALUE;
    _6826 = EPrintf(-9999999, _6818, _6825);
    DeRefDS(_6825);
    _6825 = NOVALUE;
    DeRef(_6817);
    _6817 = NOVALUE;
    return _6826;
L3: 
    ;
}


object _33version_string_long(object _full_12190)
{
    object _platform_name_inlined_platform_name_at_8_12194 = NOVALUE;
    object _6833 = NOVALUE;
    object _6832 = NOVALUE;
    object _6830 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:284		return version_string(full) & " for " & platform_name() & " " & arch_bits()*/
    _6830 = _33version_string(0LL);

    /** info.e:48		ifdef WINDOWS then*/

    /** info.e:49			return "Windows"*/
    RefDS(_6769);
    DeRefi(_platform_name_inlined_platform_name_at_8_12194);
    _platform_name_inlined_platform_name_at_8_12194 = _6769;
    _6832 = _33arch_bits();
    {
        object concat_list[5];

        concat_list[0] = _6832;
        concat_list[1] = _2707;
        concat_list[2] = _platform_name_inlined_platform_name_at_8_12194;
        concat_list[3] = _6831;
        concat_list[4] = _6830;
        Concat_N((object_ptr)&_6833, concat_list, 5);
    }
    DeRef(_6832);
    _6832 = NOVALUE;
    DeRef(_6830);
    _6830 = NOVALUE;
    return _6833;
    ;
}


object _33all_copyrights()
{
    object _pcre_copyright_inlined_pcre_copyright_at_19_12216 = NOVALUE;
    object _euphoria_copyright_2__tmp_at2_12214 = NOVALUE;
    object _euphoria_copyright_1__tmp_at2_12213 = NOVALUE;
    object _euphoria_copyright_inlined_euphoria_copyright_at_2_12212 = NOVALUE;
    object _6842 = NOVALUE;
    object _0, _1, _2;
    

    /** info.e:355		return {*/

    /** info.e:309		return {*/
    _0 = _euphoria_copyright_1__tmp_at2_12213;
    _euphoria_copyright_1__tmp_at2_12213 = _33version_string_long(0LL);
    DeRef(_0);
    if (IS_SEQUENCE(_6834) && IS_ATOM(_euphoria_copyright_1__tmp_at2_12213)) {
        Ref(_euphoria_copyright_1__tmp_at2_12213);
        Append(&_euphoria_copyright_2__tmp_at2_12214, _6834, _euphoria_copyright_1__tmp_at2_12213);
    }
    else if (IS_ATOM(_6834) && IS_SEQUENCE(_euphoria_copyright_1__tmp_at2_12213)) {
    }
    else {
        Concat((object_ptr)&_euphoria_copyright_2__tmp_at2_12214, _6834, _euphoria_copyright_1__tmp_at2_12213);
    }
    RefDS(_6837);
    RefDS(_euphoria_copyright_2__tmp_at2_12214);
    DeRef(_euphoria_copyright_inlined_euphoria_copyright_at_2_12212);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_2__tmp_at2_12214;
    ((intptr_t *)_2)[2] = _6837;
    _euphoria_copyright_inlined_euphoria_copyright_at_2_12212 = MAKE_SEQ(_1);
    DeRef(_euphoria_copyright_1__tmp_at2_12213);
    _euphoria_copyright_1__tmp_at2_12213 = NOVALUE;
    DeRef(_euphoria_copyright_2__tmp_at2_12214);
    _euphoria_copyright_2__tmp_at2_12214 = NOVALUE;

    /** info.e:331		return {*/
    RefDS(_6840);
    RefDS(_6839);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_19_12216);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _6839;
    ((intptr_t *)_2)[2] = _6840;
    _pcre_copyright_inlined_pcre_copyright_at_19_12216 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_19_12216);
    RefDS(_euphoria_copyright_inlined_euphoria_copyright_at_2_12212);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _euphoria_copyright_inlined_euphoria_copyright_at_2_12212;
    ((intptr_t *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_19_12216;
    _6842 = MAKE_SEQ(_1);
    return _6842;
    ;
}



// 0x77D0F5FB
