// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _3extract_options(object _s_64989)
{
    object _0, _1, _2;
    

    /** traninit.e:69		return s*/
    return _s_64989;
    ;
}


void _3transoptions()
{
    object _tranopts_65176 = NOVALUE;
    object _opts_65188 = NOVALUE;
    object _opt_keys_65194 = NOVALUE;
    object _option_w_65196 = NOVALUE;
    object _key_65200 = NOVALUE;
    object _val_65202 = NOVALUE;
    object _tmp_65307 = NOVALUE;
    object _tmp_65327 = NOVALUE;
    object _filetype_65353 = NOVALUE;
    object _32208 = NOVALUE;
    object _32207 = NOVALUE;
    object _32206 = NOVALUE;
    object _32205 = NOVALUE;
    object _32203 = NOVALUE;
    object _32202 = NOVALUE;
    object _32201 = NOVALUE;
    object _32200 = NOVALUE;
    object _32199 = NOVALUE;
    object _32198 = NOVALUE;
    object _32193 = NOVALUE;
    object _32192 = NOVALUE;
    object _32191 = NOVALUE;
    object _32188 = NOVALUE;
    object _32187 = NOVALUE;
    object _32186 = NOVALUE;
    object _32185 = NOVALUE;
    object _32184 = NOVALUE;
    object _32181 = NOVALUE;
    object _32178 = NOVALUE;
    object _32177 = NOVALUE;
    object _32176 = NOVALUE;
    object _32175 = NOVALUE;
    object _32173 = NOVALUE;
    object _32170 = NOVALUE;
    object _32169 = NOVALUE;
    object _32168 = NOVALUE;
    object _32167 = NOVALUE;
    object _32166 = NOVALUE;
    object _32165 = NOVALUE;
    object _32164 = NOVALUE;
    object _32163 = NOVALUE;
    object _32162 = NOVALUE;
    object _32161 = NOVALUE;
    object _32160 = NOVALUE;
    object _32159 = NOVALUE;
    object _32158 = NOVALUE;
    object _32154 = NOVALUE;
    object _32151 = NOVALUE;
    object _32150 = NOVALUE;
    object _32149 = NOVALUE;
    object _32143 = NOVALUE;
    object _32140 = NOVALUE;
    object _32139 = NOVALUE;
    object _32137 = NOVALUE;
    object _32135 = NOVALUE;
    object _32131 = NOVALUE;
    object _32121 = NOVALUE;
    object _32119 = NOVALUE;
    object _32116 = NOVALUE;
    object _32114 = NOVALUE;
    object _32112 = NOVALUE;
    object _32111 = NOVALUE;
    object _32110 = NOVALUE;
    object _32109 = NOVALUE;
    object _32108 = NOVALUE;
    object _32103 = NOVALUE;
    object _32097 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:112		sequence tranopts = sort( get_options() )*/
    _32097 = _49get_options();
    _0 = _tranopts_65176;
    _tranopts_65176 = _24sort(_32097, 1LL);
    DeRef(_0);
    _32097 = NOVALUE;

    /** traninit.e:114		Argv = expand_config_options( Argv )*/
    RefDS(_36Argv_21770);
    _0 = _49expand_config_options(_36Argv_21770);
    DeRefDS(_36Argv_21770);
    _36Argv_21770 = _0;

    /** traninit.e:115		Argc = length(Argv)*/
    if (IS_SEQUENCE(_36Argv_21770)){
            _36Argc_21769 = SEQ_PTR(_36Argv_21770)->length;
    }
    else {
        _36Argc_21769 = 1;
    }

    /** traninit.e:117		map:map opts = cmd_parse( tranopts, NO_HELP_ON_ERROR, Argv)*/
    RefDS(_tranopts_65176);
    RefDS(_36Argv_21770);
    _0 = _opts_65188;
    _opts_65188 = _4cmd_parse(_tranopts_65176, 10LL, _36Argv_21770);
    DeRef(_0);

    /** traninit.e:119		handle_common_options(opts)*/
    Ref(_opts_65188);
    _49handle_common_options(_opts_65188);

    /** traninit.e:121		sequence opt_keys = map:keys(opts)*/
    Ref(_opts_65188);
    _0 = _opt_keys_65194;
    _opt_keys_65194 = _29keys(_opts_65188, 0LL);
    DeRef(_0);

    /** traninit.e:122		integer option_w = 0*/
    _option_w_65196 = 0LL;

    /** traninit.e:124		for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_65194)){
            _32103 = SEQ_PTR(_opt_keys_65194)->length;
    }
    else {
        _32103 = 1;
    }
    {
        object _idx_65198;
        _idx_65198 = 1LL;
L1: 
        if (_idx_65198 > _32103){
            goto L2; // [68] 884
        }

        /** traninit.e:126			sequence key = opt_keys[idx]*/
        DeRef(_key_65200);
        _2 = (object)SEQ_PTR(_opt_keys_65194);
        _key_65200 = (object)*(((s1_ptr)_2)->base + _idx_65198);
        Ref(_key_65200);

        /** traninit.e:127			object val = map:get(opts, key)*/
        Ref(_opts_65188);
        RefDS(_key_65200);
        _0 = _val_65202;
        _val_65202 = _29get(_opts_65188, _key_65200, 0LL);
        DeRef(_0);

        /** traninit.e:129			switch key do*/
        _1 = find(_key_65200, _32106);
        switch ( _1 ){ 

            /** traninit.e:130				case "silent" then*/
            case 1:

            /** traninit.e:131					silent = TRUE*/
            _36silent_21878 = _13TRUE_447;
            goto L3; // [109] 875

            /** traninit.e:133				case "verbose" then*/
            case 2:

            /** traninit.e:134					verbose = TRUE*/
            _36verbose_21881 = _13TRUE_447;
            goto L3; // [122] 875

            /** traninit.e:136				case "rc-file" then*/
            case 3:

            /** traninit.e:137					rc_file[D_NAME] = canonical_path(val)*/
            Ref(_val_65202);
            _32108 = _17canonical_path(_val_65202, 0LL, 0LL);
            _2 = (object)SEQ_PTR(_56rc_file_45714);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45714 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 1LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _32108;
            if( _1 != _32108 ){
                DeRef(_1);
            }
            _32108 = NOVALUE;

            /** traninit.e:138					rc_file[D_ALTNAME] = adjust_for_command_line_passing((rc_file[D_NAME]))*/
            _2 = (object)SEQ_PTR(_56rc_file_45714);
            _32109 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_32109);
            _32110 = _56adjust_for_command_line_passing(_32109);
            _32109 = NOVALUE;
            _2 = (object)SEQ_PTR(_56rc_file_45714);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _56rc_file_45714 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 11LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _32110;
            if( _1 != _32110 ){
                DeRef(_1);
            }
            _32110 = NOVALUE;

            /** traninit.e:139					if not file_exists(rc_file[D_NAME]) then*/
            _2 = (object)SEQ_PTR(_56rc_file_45714);
            _32111 = (object)*(((s1_ptr)_2)->base + 1LL);
            Ref(_32111);
            _32112 = _17file_exists(_32111);
            _32111 = NOVALUE;
            if (IS_ATOM_INT(_32112)) {
                if (_32112 != 0){
                    DeRef(_32112);
                    _32112 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            else {
                if (DBL_PTR(_32112)->dbl != 0.0){
                    DeRef(_32112);
                    _32112 = NOVALUE;
                    goto L3; // [180] 875
                }
            }
            DeRef(_32112);
            _32112 = NOVALUE;

            /** traninit.e:140						ShowMsg(2, RESOURCE_FILE_DOES_NOT_EXIST__1, { val })*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            Ref(_val_65202);
            ((intptr_t*)_2)[1] = _val_65202;
            _32114 = MAKE_SEQ(_1);
            _39ShowMsg(2LL, 349LL, _32114, 1LL);
            _32114 = NOVALUE;

            /** traninit.e:141						abort(1)*/
            UserCleanup(1LL);
            goto L3; // [202] 875

            /** traninit.e:144				case "cflags" then*/
            case 4:

            /** traninit.e:145					cflags = val*/
            Ref(_val_65202);
            DeRef(_56cflags_45723);
            _56cflags_45723 = _val_65202;
            goto L3; // [215] 875

            /** traninit.e:147				case "extra-cflags" then*/
            case 5:

            /** traninit.e:148					extra_cflags = val*/
            Ref(_val_65202);
            DeRef(_56extra_cflags_45724);
            _56extra_cflags_45724 = _val_65202;
            goto L3; // [228] 875

            /** traninit.e:150				case "lflags" then*/
            case 6:

            /** traninit.e:151					lflags = val*/
            Ref(_val_65202);
            DeRef(_56lflags_45725);
            _56lflags_45725 = _val_65202;
            goto L3; // [241] 875

            /** traninit.e:153				case "extra-lflags" then*/
            case 7:

            /** traninit.e:154					extra_lflags = val*/
            Ref(_val_65202);
            DeRef(_56extra_lflags_45726);
            _56extra_lflags_45726 = _val_65202;
            goto L3; // [254] 875

            /** traninit.e:156				case "wat" then*/
            case 8:

            /** traninit.e:157					compiler_type = COMPILER_WATCOM*/
            _56compiler_type_45705 = 2LL;
            goto L3; // [269] 875

            /** traninit.e:159				case "gcc" then*/
            case 9:

            /** traninit.e:160					compiler_type = COMPILER_GCC*/
            _56compiler_type_45705 = 1LL;
            goto L3; // [284] 875

            /** traninit.e:162				case "com" then*/
            case 10:

            /** traninit.e:163					compiler_dir = val*/
            Ref(_val_65202);
            DeRef(_56compiler_dir_45707);
            _56compiler_dir_45707 = _val_65202;
            goto L3; // [297] 875

            /** traninit.e:165				case "con" then*/
            case 11:

            /** traninit.e:166					con_option = TRUE*/
            _58con_option_42891 = _13TRUE_447;

            /** traninit.e:167					OpDefines &= { "CONSOLE" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_32115);
            ((intptr_t*)_2)[1] = _32115;
            _32116 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21836, _36OpDefines_21836, _32116);
            DeRefDS(_32116);
            _32116 = NOVALUE;
            goto L3; // [324] 875

            /** traninit.e:169				case "dll", "so" then*/
            case 12:
            case 13:

            /** traninit.e:170					dll_option = TRUE*/
            _58dll_option_42889 = _13TRUE_447;

            /** traninit.e:171					OpDefines &= { "EUC_DLL" }*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            RefDS(_32118);
            ((intptr_t*)_2)[1] = _32118;
            _32119 = MAKE_SEQ(_1);
            Concat((object_ptr)&_36OpDefines_21836, _36OpDefines_21836, _32119);
            DeRefDS(_32119);
            _32119 = NOVALUE;
            goto L3; // [353] 875

            /** traninit.e:173				case "plat" then*/
            case 14:

            /** traninit.e:174					switch upper(val) do*/
            Ref(_val_65202);
            _32121 = _14upper(_val_65202);
            _1 = find(_32121, _32122);
            DeRef(_32121);
            _32121 = NOVALUE;
            switch ( _1 ){ 

                /** traninit.e:178						case "WINDOWS" then*/
                case 1:

                /** traninit.e:179							set_host_platform( WIN32 )*/
                _46set_host_platform(2LL);
                goto L3; // [381] 875

                /** traninit.e:181						case "LINUX" then*/
                case 2:

                /** traninit.e:182							set_host_platform( ULINUX )*/
                _46set_host_platform(3LL);
                goto L3; // [394] 875

                /** traninit.e:184						case "FREEBSD" then*/
                case 3:

                /** traninit.e:185							set_host_platform( UFREEBSD )*/
                _46set_host_platform(8LL);
                goto L3; // [407] 875

                /** traninit.e:187						case "OSX" then*/
                case 4:

                /** traninit.e:188							set_host_platform( UOSX )*/
                _46set_host_platform(4LL);
                goto L3; // [420] 875

                /** traninit.e:190						case "OPENBSD" then*/
                case 5:

                /** traninit.e:191							set_host_platform( UOPENBSD )*/
                _46set_host_platform(6LL);
                goto L3; // [433] 875

                /** traninit.e:193						case "NETBSD" then*/
                case 6:

                /** traninit.e:194							set_host_platform( UNETBSD )*/
                _46set_host_platform(7LL);
                goto L3; // [446] 875

                /** traninit.e:196						case else*/
                case 0:

                /** traninit.e:197							ShowMsg(2, UNKNOWN_PLATFORM_1__SUPPORTED_PLATFORMS_ARE_2, { val, "WINDOWS, LINUX, FREEBSD, OSX, OPENBSD, NETBSD" })*/
                RefDS(_32130);
                Ref(_val_65202);
                _1 = NewS1(2);
                _2 = (object)((s1_ptr)_1)->base;
                ((intptr_t *)_2)[1] = _val_65202;
                ((intptr_t *)_2)[2] = _32130;
                _32131 = MAKE_SEQ(_1);
                _39ShowMsg(2LL, 201LL, _32131, 1LL);
                _32131 = NOVALUE;

                /** traninit.e:198							abort(1)*/
                UserCleanup(1LL);
            ;}            goto L3; // [471] 875

            /** traninit.e:201				case "lib" then*/
            case 15:

            /** traninit.e:202					user_library = canonical_path(val)*/
            Ref(_val_65202);
            _0 = _17canonical_path(_val_65202, 0LL, 0LL);
            DeRef(_58user_library_42901);
            _58user_library_42901 = _0;
            goto L3; // [487] 875

            /** traninit.e:204				case "lib-pic" then*/
            case 16:

            /** traninit.e:205					user_pic_library = canonical_path( val )*/
            Ref(_val_65202);
            _0 = _17canonical_path(_val_65202, 0LL, 0LL);
            DeRef(_58user_pic_library_42902);
            _58user_pic_library_42902 = _0;
            goto L3; // [503] 875

            /** traninit.e:207				case "stack" then*/
            case 17:

            /** traninit.e:208					sequence tmp = value(val)*/
            Ref(_val_65202);
            _0 = _tmp_65307;
            _tmp_65307 = _6value(_val_65202, 1LL, _6GET_SHORT_ANSWER_11277);
            DeRef(_0);

            /** traninit.e:209					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_65307);
            _32135 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _32135, 0LL)){
                _32135 = NOVALUE;
                goto L4; // [529] 561
            }
            _32135 = NOVALUE;

            /** traninit.e:210						if tmp[2] >= 16384 then*/
            _2 = (object)SEQ_PTR(_tmp_65307);
            _32137 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (binary_op_a(LESS, _32137, 16384LL)){
                _32137 = NOVALUE;
                goto L5; // [539] 560
            }
            _32137 = NOVALUE;

            /** traninit.e:211							total_stack_size = floor(tmp[2] / 4) * 4*/
            _2 = (object)SEQ_PTR(_tmp_65307);
            _32139 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (IS_ATOM_INT(_32139)) {
                if (4LL > 0 && _32139 >= 0) {
                    _32140 = _32139 / 4LL;
                }
                else {
                    temp_dbl = EUFLOOR((eudouble)_32139 / (eudouble)4LL);
                    if (_32139 != MININT)
                    _32140 = (object)temp_dbl;
                    else
                    _32140 = NewDouble(temp_dbl);
                }
            }
            else {
                _2 = binary_op(DIVIDE, _32139, 4LL);
                _32140 = unary_op(FLOOR, _2);
                DeRef(_2);
            }
            _32139 = NOVALUE;
            if (IS_ATOM_INT(_32140)) {
                _58total_stack_size_42904 = _32140 * 4LL;
            }
            else {
                _58total_stack_size_42904 = binary_op(MULTIPLY, _32140, 4LL);
            }
            DeRef(_32140);
            _32140 = NOVALUE;
            if (!IS_ATOM_INT(_58total_stack_size_42904)) {
                _1 = (object)(DBL_PTR(_58total_stack_size_42904)->dbl);
                DeRefDS(_58total_stack_size_42904);
                _58total_stack_size_42904 = _1;
            }
L5: 
L4: 
            DeRef(_tmp_65307);
            _tmp_65307 = NOVALUE;
            goto L3; // [563] 875

            /** traninit.e:215				case "debug" then*/
            case 18:

            /** traninit.e:216					debug_option = TRUE*/
            _58debug_option_42899 = _13TRUE_447;

            /** traninit.e:217					keep = TRUE -- you'll need the sources to debug*/
            _58keep_42896 = _13TRUE_447;
            goto L3; // [583] 875

            /** traninit.e:219				case "maxsize" then*/
            case 19:

            /** traninit.e:220					sequence tmp = value(val)*/
            Ref(_val_65202);
            _0 = _tmp_65327;
            _tmp_65327 = _6value(_val_65202, 1LL, _6GET_SHORT_ANSWER_11277);
            DeRef(_0);

            /** traninit.e:221					if tmp[1] = GET_SUCCESS then*/
            _2 = (object)SEQ_PTR(_tmp_65327);
            _32143 = (object)*(((s1_ptr)_2)->base + 1LL);
            if (binary_op_a(NOTEQ, _32143, 0LL)){
                _32143 = NOVALUE;
                goto L6; // [609] 624
            }
            _32143 = NOVALUE;

            /** traninit.e:222						max_cfile_size = tmp[2]*/
            _2 = (object)SEQ_PTR(_tmp_65327);
            _56max_cfile_size_45721 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_56max_cfile_size_45721)){
                _56max_cfile_size_45721 = (object)DBL_PTR(_56max_cfile_size_45721)->dbl;
            }
            goto L7; // [621] 639
L6: 

            /** traninit.e:224						ShowMsg(2, INVALID_MAXIMUM_FILE_SIZE)*/
            RefDS(_22186);
            _39ShowMsg(2LL, 202LL, _22186, 1LL);

            /** traninit.e:225						abort(1)*/
            UserCleanup(1LL);
L7: 
            DeRef(_tmp_65327);
            _tmp_65327 = NOVALUE;
            goto L3; // [641] 875

            /** traninit.e:228				case "keep" then*/
            case 20:

            /** traninit.e:229					keep = TRUE*/
            _58keep_42896 = _13TRUE_447;
            goto L3; // [654] 875

            /** traninit.e:231				case "makefile-partial" then*/
            case 21:

            /** traninit.e:232					build_system_type = BUILD_MAKEFILE_PARTIAL*/
            _56build_system_type_45701 = 1LL;
            goto L3; // [669] 875

            /** traninit.e:234				case "makefile" then*/
            case 22:

            /** traninit.e:235					build_system_type = BUILD_MAKEFILE_FULL*/
            _56build_system_type_45701 = 2LL;
            goto L3; // [684] 875

            /** traninit.e:237				case "nobuild" then*/
            case 23:

            /** traninit.e:238					build_system_type = BUILD_NONE*/
            _56build_system_type_45701 = 0LL;
            goto L3; // [699] 875

            /** traninit.e:240				case "build-dir" then*/
            case 24:

            /** traninit.e:241					output_dir = val*/
            Ref(_val_65202);
            DeRef(_58output_dir_42903);
            _58output_dir_42903 = _val_65202;

            /** traninit.e:242					integer filetype = file_type( output_dir )*/
            RefDS(_58output_dir_42903);
            _filetype_65353 = _17file_type(_58output_dir_42903);
            if (!IS_ATOM_INT(_filetype_65353)) {
                _1 = (object)(DBL_PTR(_filetype_65353)->dbl);
                DeRefDS(_filetype_65353);
                _filetype_65353 = _1;
            }

            /** traninit.e:244					if filetype = FILETYPE_FILE then*/
            if (_filetype_65353 != 1LL)
            goto L8; // [726] 747

            /** traninit.e:245						ShowMsg( 2, BUILDDIR_IS_FILE )*/
            RefDS(_22186);
            _39ShowMsg(2LL, 605LL, _22186, 1LL);

            /** traninit.e:246						abort(1)*/
            UserCleanup(1LL);
            goto L9; // [744] 771
L8: 

            /** traninit.e:247					elsif filetype = FILETYPE_UNDEFINED then*/
            if (_filetype_65353 != -1LL)
            goto LA; // [751] 770

            /** traninit.e:248						ShowMsg( 2, BUILDDIR_IS_UNDEFINED )*/
            RefDS(_22186);
            _39ShowMsg(2LL, 606LL, _22186, 1LL);

            /** traninit.e:249						abort(1)*/
            UserCleanup(1LL);
LA: 
L9: 

            /** traninit.e:251					if find(output_dir[$], "/\\") = 0 then*/
            if (IS_SEQUENCE(_58output_dir_42903)){
                    _32149 = SEQ_PTR(_58output_dir_42903)->length;
            }
            else {
                _32149 = 1;
            }
            _2 = (object)SEQ_PTR(_58output_dir_42903);
            _32150 = (object)*(((s1_ptr)_2)->base + _32149);
            _32151 = find_from(_32150, _24110, 1LL);
            _32150 = NOVALUE;
            if (_32151 != 0LL)
            goto LB; // [787] 802

            /** traninit.e:252						output_dir &= '/'*/
            Append(&_58output_dir_42903, _58output_dir_42903, 47LL);
LB: 
            goto L3; // [804] 875

            /** traninit.e:255				case "force-build" then*/
            case 25:

            /** traninit.e:256					force_build = 1*/
            _56force_build_45727 = 1LL;
            goto L3; // [817] 875

            /** traninit.e:258				case "o" then*/
            case 26:

            /** traninit.e:259					exe_name[D_NAME] = val*/
            Ref(_val_65202);
            _2 = (object)SEQ_PTR(_56exe_name_45708);
            _2 = (object)(((s1_ptr)_2)->base + 1LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _val_65202;
            DeRef(_1);
            goto L3; // [833] 875

            /** traninit.e:261				case "no-cygwin" then*/
            case 27:

            /** traninit.e:262					mno_cygwin = 1*/
            _56mno_cygwin_45729 = 1LL;
            goto L3; // [846] 875

            /** traninit.e:264				case "arch" then*/
            case 28:

            /** traninit.e:265					set_target_arch( upper( val ) )*/
            Ref(_val_65202);
            _32154 = _14upper(_val_65202);
            _46set_target_arch(_32154);
            _32154 = NOVALUE;
            goto L3; // [861] 875

            /** traninit.e:267				case "cc-prefix" then*/
            case 29:

            /** traninit.e:268					compiler_prefix = val*/
            Ref(_val_65202);
            DeRef(_56compiler_prefix_45706);
            _56compiler_prefix_45706 = _val_65202;
        ;}L3: 
        DeRef(_key_65200);
        _key_65200 = NOVALUE;
        DeRef(_val_65202);
        _val_65202 = NOVALUE;

        /** traninit.e:271		end for*/
        _idx_65198 = _idx_65198 + 1LL;
        goto L1; // [879] 75
L2: 
        ;
    }

    /** traninit.e:274		if dll_option then*/
    if (_58dll_option_42889 == 0)
    {
        goto LC; // [888] 925
    }
    else{
    }

    /** traninit.e:275			if TX86_64  then*/
    if (_46TX86_64_21922 == 0)
    {
        goto LD; // [895] 911
    }
    else{
    }

    /** traninit.e:277				user_pic_library = check_library( user_pic_library )*/
    RefDS(_58user_pic_library_42902);
    _0 = _3check_library(_58user_pic_library_42902);
    DeRefDS(_58user_pic_library_42902);
    _58user_pic_library_42902 = _0;
    goto LE; // [908] 936
LD: 

    /** traninit.e:279				user_library = check_library( user_library )*/
    RefDS(_58user_library_42901);
    _0 = _3check_library(_58user_library_42901);
    DeRefDS(_58user_library_42901);
    _58user_library_42901 = _0;
    goto LE; // [922] 936
LC: 

    /** traninit.e:282			user_library = check_library( user_library )*/
    RefDS(_58user_library_42901);
    _0 = _3check_library(_58user_library_42901);
    DeRefDS(_58user_library_42901);
    _58user_library_42901 = _0;
LE: 

    /** traninit.e:285		if length(exe_name[D_NAME]) and not absolute_path(exe_name[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _32158 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_32158)){
            _32159 = SEQ_PTR(_32158)->length;
    }
    else {
        _32159 = 1;
    }
    _32158 = NOVALUE;
    if (_32159 == 0) {
        goto LF; // [949] 1002
    }
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _32161 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32161);
    _32162 = _17absolute_path(_32161);
    _32161 = NOVALUE;
    if (IS_ATOM_INT(_32162)) {
        _32163 = (_32162 == 0);
    }
    else {
        _32163 = unary_op(NOT, _32162);
    }
    DeRef(_32162);
    _32162 = NOVALUE;
    if (_32163 == 0) {
        DeRef(_32163);
        _32163 = NOVALUE;
        goto LF; // [969] 1002
    }
    else {
        if (!IS_ATOM_INT(_32163) && DBL_PTR(_32163)->dbl == 0.0){
            DeRef(_32163);
            _32163 = NOVALUE;
            goto LF; // [969] 1002
        }
        DeRef(_32163);
        _32163 = NOVALUE;
    }
    DeRef(_32163);
    _32163 = NOVALUE;

    /** traninit.e:286			exe_name[D_NAME] = current_dir() & SLASH & exe_name[D_NAME]*/
    _32164 = _17current_dir();
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _32165 = (object)*(((s1_ptr)_2)->base + 1LL);
    {
        object concat_list[3];

        concat_list[0] = _32165;
        concat_list[1] = 92LL;
        concat_list[2] = _32164;
        Concat_N((object_ptr)&_32166, concat_list, 3);
    }
    _32165 = NOVALUE;
    DeRef(_32164);
    _32164 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32166;
    if( _1 != _32166 ){
        DeRef(_1);
    }
    _32166 = NOVALUE;
LF: 

    /** traninit.e:288		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _32167 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32167);
    _32168 = _56adjust_for_command_line_passing(_32167);
    _32167 = NOVALUE;
    _2 = (object)SEQ_PTR(_56exe_name_45708);
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32168;
    if( _1 != _32168 ){
        DeRef(_1);
    }
    _32168 = NOVALUE;

    /** traninit.e:290		if length(map:get(opts, OPT_EXTRAS)) = 0 then*/
    Ref(_opts_65188);
    RefDS(_4OPT_EXTRAS_14411);
    _32169 = _29get(_opts_65188, _4OPT_EXTRAS_14411, 0LL);
    if (IS_SEQUENCE(_32169)){
            _32170 = SEQ_PTR(_32169)->length;
    }
    else {
        _32170 = 1;
    }
    DeRef(_32169);
    _32169 = NOVALUE;
    if (_32170 != 0LL)
    goto L10; // [1037] 1060

    /** traninit.e:292			show_banner()*/
    _49show_banner();

    /** traninit.e:293			ShowMsg(2, ERROR_MUST_SPECIFY_THE_FILE_TO_BE_TRANSLATED_ON_THE_COMMAND_LINE)*/
    RefDS(_22186);
    _39ShowMsg(2LL, 203LL, _22186, 1LL);

    /** traninit.e:296			abort(1)*/
    UserCleanup(1LL);
L10: 

    /** traninit.e:299		OpDefines &= { "EUC" }*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_32172);
    ((intptr_t*)_2)[1] = _32172;
    _32173 = MAKE_SEQ(_1);
    Concat((object_ptr)&_36OpDefines_21836, _36OpDefines_21836, _32173);
    DeRefDS(_32173);
    _32173 = NOVALUE;

    /** traninit.e:301		if host_platform() = WIN32 and not con_option then*/
    _32175 = _46host_platform();
    if (IS_ATOM_INT(_32175)) {
        _32176 = (_32175 == 2LL);
    }
    else {
        _32176 = binary_op(EQUALS, _32175, 2LL);
    }
    DeRef(_32175);
    _32175 = NOVALUE;
    if (IS_ATOM_INT(_32176)) {
        if (_32176 == 0) {
            goto L11; // [1085] 1111
        }
    }
    else {
        if (DBL_PTR(_32176)->dbl == 0.0) {
            goto L11; // [1085] 1111
        }
    }
    _32178 = (_58con_option_42891 == 0);
    if (_32178 == 0)
    {
        DeRef(_32178);
        _32178 = NOVALUE;
        goto L11; // [1095] 1111
    }
    else{
        DeRef(_32178);
        _32178 = NOVALUE;
    }

    /** traninit.e:302			OpDefines = append( OpDefines, "GUI" )*/
    RefDS(_32179);
    Append(&_36OpDefines_21836, _36OpDefines_21836, _32179);
    goto L12; // [1108] 1135
L11: 

    /** traninit.e:303		elsif not find( "CONSOLE", OpDefines ) then*/
    _32181 = find_from(_32115, _36OpDefines_21836, 1LL);
    if (_32181 != 0)
    goto L13; // [1120] 1134
    _32181 = NOVALUE;

    /** traninit.e:304			OpDefines = append( OpDefines, "CONSOLE" )*/
    RefDS(_32115);
    Append(&_36OpDefines_21836, _36OpDefines_21836, _32115);
L13: 
L12: 

    /** traninit.e:307		ifdef not EUDIS then*/

    /** traninit.e:308			if build_system_type = BUILD_DIRECT and length(output_dir) = 0 then*/
    _32184 = (_56build_system_type_45701 == 3LL);
    if (_32184 == 0) {
        goto L14; // [1147] 1245
    }
    if (IS_SEQUENCE(_58output_dir_42903)){
            _32186 = SEQ_PTR(_58output_dir_42903)->length;
    }
    else {
        _32186 = 1;
    }
    _32187 = (_32186 == 0LL);
    _32186 = NOVALUE;
    if (_32187 == 0)
    {
        DeRef(_32187);
        _32187 = NOVALUE;
        goto L14; // [1161] 1245
    }
    else{
        DeRef(_32187);
        _32187 = NOVALUE;
    }

    /** traninit.e:309				output_dir = temp_file("." & SLASH, "build-", "")*/
    Append(&_32188, _23371, 92LL);
    RefDS(_32189);
    RefDS(_22186);
    _0 = _17temp_file(_32188, _32189, _22186, 0LL);
    DeRef(_58output_dir_42903);
    _58output_dir_42903 = _0;
    _32188 = NOVALUE;

    /** traninit.e:310				if find(output_dir[$], "/\\") = 0 then*/
    if (IS_SEQUENCE(_58output_dir_42903)){
            _32191 = SEQ_PTR(_58output_dir_42903)->length;
    }
    else {
        _32191 = 1;
    }
    _2 = (object)SEQ_PTR(_58output_dir_42903);
    _32192 = (object)*(((s1_ptr)_2)->base + _32191);
    _32193 = find_from(_32192, _24110, 1LL);
    _32192 = NOVALUE;
    if (_32193 != 0LL)
    goto L15; // [1197] 1212

    /** traninit.e:311					output_dir &= '/'*/
    Append(&_58output_dir_42903, _58output_dir_42903, 47LL);
L15: 

    /** traninit.e:314				if not silent then*/
    if (_36silent_21878 != 0)
    goto L16; // [1216] 1237

    /** traninit.e:315					printf(1, "Build directory: %s\n", { abbreviate_path(output_dir) })*/
    RefDS(_58output_dir_42903);
    RefDS(_22186);
    _32198 = _17abbreviate_path(_58output_dir_42903, _22186);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _32198;
    _32199 = MAKE_SEQ(_1);
    _32198 = NOVALUE;
    EPrintf(1LL, _32197, _32199);
    DeRefDS(_32199);
    _32199 = NOVALUE;
L16: 

    /** traninit.e:318				remove_output_dir = 1*/
    _56remove_output_dir_45728 = 1LL;
L14: 

    /** traninit.e:322		if length(rc_file[D_NAME]) then*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _32200 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_SEQUENCE(_32200)){
            _32201 = SEQ_PTR(_32200)->length;
    }
    else {
        _32201 = 1;
    }
    _32200 = NOVALUE;
    if (_32201 == 0)
    {
        _32201 = NOVALUE;
        goto L17; // [1258] 1320
    }
    else{
        _32201 = NOVALUE;
    }

    /** traninit.e:323			res_file[D_NAME] = canonical_path(output_dir & filebase(rc_file[D_NAME]) & ".res")*/
    _2 = (object)SEQ_PTR(_56rc_file_45714);
    _32202 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32202);
    _32203 = _17filebase(_32202);
    _32202 = NOVALUE;
    {
        object concat_list[3];

        concat_list[0] = _32204;
        concat_list[1] = _32203;
        concat_list[2] = _58output_dir_42903;
        Concat_N((object_ptr)&_32205, concat_list, 3);
    }
    DeRef(_32203);
    _32203 = NOVALUE;
    _32206 = _17canonical_path(_32205, 0LL, 0LL);
    _32205 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45720);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45720 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32206;
    if( _1 != _32206 ){
        DeRef(_1);
    }
    _32206 = NOVALUE;

    /** traninit.e:324			res_file[D_ALTNAME] = adjust_for_command_line_passing(res_file[D_NAME])*/
    _2 = (object)SEQ_PTR(_56res_file_45720);
    _32207 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_32207);
    _32208 = _56adjust_for_command_line_passing(_32207);
    _32207 = NOVALUE;
    _2 = (object)SEQ_PTR(_56res_file_45720);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _56res_file_45720 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32208;
    if( _1 != _32208 ){
        DeRef(_1);
    }
    _32208 = NOVALUE;
L17: 

    /** traninit.e:327		finalize_command_line(opts)*/
    Ref(_opts_65188);
    _49finalize_command_line(_opts_65188);

    /** traninit.e:328	end procedure*/
    DeRef(_tranopts_65176);
    DeRef(_opts_65188);
    DeRef(_opt_keys_65194);
    _32169 = NOVALUE;
    DeRef(_32176);
    _32176 = NOVALUE;
    DeRef(_32184);
    _32184 = NOVALUE;
    _32200 = NOVALUE;
    _32158 = NOVALUE;
    return;
    ;
}


void _3OpenCFiles()
{
    object _32270 = NOVALUE;
    object _32220 = NOVALUE;
    object _32214 = NOVALUE;
    object _32212 = NOVALUE;
    object _32211 = NOVALUE;
    object _32210 = NOVALUE;
    object _32209 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:333		if sequence(output_dir) and length(output_dir) > 0 then*/
    _32209 = 1;
    if (_32209 == 0) {
        goto L1; // [8] 38
    }
    if (IS_SEQUENCE(_58output_dir_42903)){
            _32211 = SEQ_PTR(_58output_dir_42903)->length;
    }
    else {
        _32211 = 1;
    }
    _32212 = (_32211 > 0LL);
    _32211 = NOVALUE;
    if (_32212 == 0)
    {
        DeRef(_32212);
        _32212 = NOVALUE;
        goto L1; // [22] 38
    }
    else{
        DeRef(_32212);
        _32212 = NOVALUE;
    }

    /** traninit.e:334			create_directory(output_dir)*/
    RefDS(_58output_dir_42903);
    _32270 = _17create_directory(_58output_dir_42903, 448LL, 1LL);
    DeRef(_32270);
    _32270 = NOVALUE;
L1: 

    /** traninit.e:337		c_code = open(output_dir & "init-.c", "w")*/
    Concat((object_ptr)&_32214, _58output_dir_42903, _32213);
    _55c_code_46972 = EOpen(_32214, _22322, 0LL);
    DeRefDS(_32214);
    _32214 = NOVALUE;

    /** traninit.e:338		if c_code = -1 then*/
    if (_55c_code_46972 != -1LL)
    goto L2; // [57] 71

    /** traninit.e:339			CompileErr(CANT_OPEN_INITC_FOR_OUTPUT)*/
    RefDS(_22186);
    _50CompileErr(55LL, _22186, 0LL);
L2: 

    /** traninit.e:342		add_file("init-.c")*/
    RefDS(_32213);
    RefDS(_22186);
    _58add_file(_32213, _22186);

    /** traninit.e:344		emit_c_output = TRUE*/
    _55emit_c_output_46969 = _13TRUE_447;

    /** traninit.e:346		c_puts("#include \"")*/
    RefDS(_32217);
    _55c_puts(_32217);

    /** traninit.e:347		c_puts("include/euphoria.h\"\n")*/
    RefDS(_32218);
    _55c_puts(_32218);

    /** traninit.e:349		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22328);
    _55c_puts(_22328);

    /** traninit.e:350		c_h = open(output_dir & "main-.h", "w")*/
    Concat((object_ptr)&_32220, _58output_dir_42903, _32219);
    _55c_h_46973 = EOpen(_32220, _22322, 0LL);
    DeRefDS(_32220);
    _32220 = NOVALUE;

    /** traninit.e:351		if c_h = -1 then*/
    if (_55c_h_46973 != -1LL)
    goto L3; // [118] 132

    /** traninit.e:352			CompileErr(CANT_OPEN_MAINH_FILE_FOR_OUTPUT)*/
    RefDS(_22186);
    _50CompileErr(47LL, _22186, 0LL);
L3: 

    /** traninit.e:354		c_hputs("#include \"include/euphoria.h\"\n")*/
    RefDS(_22327);
    _55c_hputs(_22327);

    /** traninit.e:356		add_file("main-.h")*/
    RefDS(_32219);
    RefDS(_22186);
    _58add_file(_32219, _22186);

    /** traninit.e:357	end procedure*/
    return;
    ;
}


void _3InitBackEnd(object _c_65564)
{
    object _32253 = NOVALUE;
    object _32252 = NOVALUE;
    object _32250 = NOVALUE;
    object _32249 = NOVALUE;
    object _32248 = NOVALUE;
    object _32247 = NOVALUE;
    object _32246 = NOVALUE;
    object _32243 = NOVALUE;
    object _32242 = NOVALUE;
    object _32239 = NOVALUE;
    object _32238 = NOVALUE;
    object _32235 = NOVALUE;
    object _32234 = NOVALUE;
    object _32232 = NOVALUE;
    object _32229 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_65564)) {
        _1 = (object)(DBL_PTR(_c_65564)->dbl);
        DeRefDS(_c_65564);
        _c_65564 = _1;
    }

    /** traninit.e:363		if c = 1 then*/
    if (_c_65564 != 1LL)
    goto L1; // [5] 19

    /** traninit.e:364			OpenCFiles()*/
    _3OpenCFiles();

    /** traninit.e:366			return*/
    return;
L1: 

    /** traninit.e:369		init_opcodes()*/
    _59init_opcodes();

    /** traninit.e:370		transoptions()*/
    _3transoptions();

    /** traninit.e:372		if compiler_type = COMPILER_UNKNOWN then*/
    if (_56compiler_type_45705 != 0LL)
    goto L2; // [33] 75

    /** traninit.e:373			if TWINDOWS then*/
    if (_46TWINDOWS_21906 == 0)
    {
        goto L3; // [41] 56
    }
    else{
    }

    /** traninit.e:374				compiler_type = COMPILER_WATCOM*/
    _56compiler_type_45705 = 2LL;
    goto L4; // [53] 74
L3: 

    /** traninit.e:375			elsif TUNIX then*/
    if (_46TUNIX_21910 == 0)
    {
        goto L5; // [60] 73
    }
    else{
    }

    /** traninit.e:376				compiler_type = COMPILER_GCC*/
    _56compiler_type_45705 = 1LL;
L5: 
L4: 
L2: 

    /** traninit.e:380		switch compiler_type do*/
    _0 = _56compiler_type_45705;
    switch ( _0 ){ 

        /** traninit.e:381		  	case COMPILER_GCC then*/
        case 1:

        /** traninit.e:383				break -- to avoid empty block warning*/
        goto L6; // [90] 334
        goto L6; // [92] 334

        /** traninit.e:385			case COMPILER_WATCOM then*/
        case 2:

        /** traninit.e:386				wat_path = getenv("WATCOM")*/
        DeRefi(_36wat_path_21840);
        _36wat_path_21840 = EGetEnv(_32227);

        /** traninit.e:388				if atom(wat_path) then*/
        _32229 = IS_ATOM(_36wat_path_21840);
        if (_32229 == 0)
        {
            _32229 = NOVALUE;
            goto L7; // [110] 148
        }
        else{
            _32229 = NOVALUE;
        }

        /** traninit.e:389					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45701 != 3LL)
        goto L8; // [119] 135

        /** traninit.e:392						CompileErr(WATCOM_ENVIRONMENT_VARIABLE_IS_NOT_SET)*/
        RefDS(_22186);
        _50CompileErr(159LL, _22186, 0LL);
        goto L6; // [132] 334
L8: 

        /** traninit.e:397						Warning(159, translator_warning_flag)*/
        RefDS(_22186);
        _50Warning(159LL, 128LL, _22186);
        goto L6; // [145] 334
L7: 

        /** traninit.e:399				elsif find(' ', wat_path) then*/
        _32232 = find_from(32LL, _36wat_path_21840, 1LL);
        if (_32232 == 0)
        {
            _32232 = NOVALUE;
            goto L9; // [157] 172
        }
        else{
            _32232 = NOVALUE;
        }

        /** traninit.e:400					Warning( 214, translator_warning_flag)*/
        RefDS(_22186);
        _50Warning(214LL, 128LL, _22186);
        goto L6; // [169] 334
L9: 

        /** traninit.e:401				elsif atom(getenv("INCLUDE")) then*/
        _32234 = EGetEnv(_32233);
        _32235 = IS_ATOM(_32234);
        DeRef(_32234);
        _32234 = NOVALUE;
        if (_32235 == 0)
        {
            _32235 = NOVALUE;
            goto LA; // [180] 195
        }
        else{
            _32235 = NOVALUE;
        }

        /** traninit.e:402					Warning( 215, translator_warning_flag )*/
        RefDS(_22186);
        _50Warning(215LL, 128LL, _22186);
        goto L6; // [192] 334
LA: 

        /** traninit.e:403				elsif not file_exists(wat_path & SLASH & "binnt" & SLASH & "wcc386.exe") then*/
        {
            object concat_list[5];

            concat_list[0] = _32237;
            concat_list[1] = 92LL;
            concat_list[2] = _32236;
            concat_list[3] = 92LL;
            concat_list[4] = _36wat_path_21840;
            Concat_N((object_ptr)&_32238, concat_list, 5);
        }
        _32239 = _17file_exists(_32238);
        _32238 = NOVALUE;
        if (IS_ATOM_INT(_32239)) {
            if (_32239 != 0){
                DeRef(_32239);
                _32239 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        else {
            if (DBL_PTR(_32239)->dbl != 0.0){
                DeRef(_32239);
                _32239 = NOVALUE;
                goto LB; // [215] 265
            }
        }
        DeRef(_32239);
        _32239 = NOVALUE;

        /** traninit.e:404					if build_system_type = BUILD_DIRECT then*/
        if (_56build_system_type_45701 != 3LL)
        goto LC; // [224] 246

        /** traninit.e:405						CompileErr( THERE_IS_NO_WATCOM_INSTALATION_UNDER_SPECIFIED_WATOM_PATH_1, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21840);
        ((intptr_t*)_2)[1] = _36wat_path_21840;
        _32242 = MAKE_SEQ(_1);
        _50CompileErr(352LL, _32242, 0LL);
        _32242 = NOVALUE;
        goto L6; // [243] 334
LC: 

        /** traninit.e:407						Warning( 352, translator_warning_flag, {wat_path})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_36wat_path_21840);
        ((intptr_t*)_2)[1] = _36wat_path_21840;
        _32243 = MAKE_SEQ(_1);
        _50Warning(352LL, 128LL, _32243);
        _32243 = NOVALUE;
        goto L6; // [262] 334
LB: 

        /** traninit.e:409				elsif match(upper(wat_path & "\\H;" & wat_path & "\\H\\NT"),*/
        {
            object concat_list[4];

            concat_list[0] = _32245;
            concat_list[1] = _36wat_path_21840;
            concat_list[2] = _32244;
            concat_list[3] = _36wat_path_21840;
            Concat_N((object_ptr)&_32246, concat_list, 4);
        }
        _32247 = _14upper(_32246);
        _32246 = NOVALUE;
        _32248 = EGetEnv(_32233);
        _32249 = _14upper(_32248);
        _32248 = NOVALUE;
        _32250 = e_match_from(_32247, _32249, 1LL);
        DeRef(_32247);
        _32247 = NOVALUE;
        DeRef(_32249);
        _32249 = NOVALUE;
        if (_32250 == 1LL)
        goto L6; // [294] 334

        /** traninit.e:412					Warning( 216, translator_warning_flag, {wat_path,getenv("INCLUDE")} )*/
        _32252 = EGetEnv(_32233);
        Ref(_36wat_path_21840);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _36wat_path_21840;
        ((intptr_t *)_2)[2] = _32252;
        _32253 = MAKE_SEQ(_1);
        _32252 = NOVALUE;
        _50Warning(216LL, 128LL, _32253);
        _32253 = NOVALUE;
        goto L6; // [318] 334

        /** traninit.e:415			case else*/
        default:

        /** traninit.e:416				CompileErr(UNKNOWN_COMPILER)*/
        RefDS(_22186);
        _50CompileErr(150LL, _22186, 0LL);
    ;}L6: 

    /** traninit.e:419	end procedure*/
    return;
    ;
}


void _3CheckPlatform()
{
    object _32259 = NOVALUE;
    object _32257 = NOVALUE;
    object _32256 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:425		OpDefines = eu:remove(OpDefines,*/
    _32256 = find_from(_25551, _36OpDefines_21836, 1LL);
    _32257 = find_from(_25552, _36OpDefines_21836, 1LL);
    {
        s1_ptr assign_space = SEQ_PTR(_36OpDefines_21836);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_32256)) ? _32256 : (object)(DBL_PTR(_32256)->dbl);
        int stop = (IS_ATOM_INT(_32257)) ? _32257 : (object)(DBL_PTR(_32257)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_36OpDefines_21836), start, &_36OpDefines_21836 );
            }
            else Tail(SEQ_PTR(_36OpDefines_21836), stop+1, &_36OpDefines_21836);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_36OpDefines_21836), start, &_36OpDefines_21836);
        }
        else {
            assign_slice_seq = &assign_space;
            _36OpDefines_21836 = Remove_elements(start, stop, (SEQ_PTR(_36OpDefines_21836)->ref == 1));
        }
    }
    _32256 = NOVALUE;
    _32257 = NOVALUE;

    /** traninit.e:428		OpDefines &= GetPlatformDefines(1)*/
    _32259 = _46GetPlatformDefines(1LL);
    if (IS_SEQUENCE(_36OpDefines_21836) && IS_ATOM(_32259)) {
        Ref(_32259);
        Append(&_36OpDefines_21836, _36OpDefines_21836, _32259);
    }
    else if (IS_ATOM(_36OpDefines_21836) && IS_SEQUENCE(_32259)) {
    }
    else {
        Concat((object_ptr)&_36OpDefines_21836, _36OpDefines_21836, _32259);
    }
    DeRef(_32259);
    _32259 = NOVALUE;

    /** traninit.e:429	end procedure*/
    return;
    ;
}


object _3check_library(object _lib_65681)
{
    object _32269 = NOVALUE;
    object _32268 = NOVALUE;
    object _32266 = NOVALUE;
    object _32264 = NOVALUE;
    object _32263 = NOVALUE;
    object _0, _1, _2;
    

    /** traninit.e:433		if equal( lib, "" ) then*/
    if (_lib_65681 == _22186)
    _32263 = 1;
    else if (IS_ATOM_INT(_lib_65681) && IS_ATOM_INT(_22186))
    _32263 = 0;
    else
    _32263 = (compare(_lib_65681, _22186) == 0);
    if (_32263 == 0)
    {
        _32263 = NOVALUE;
        goto L1; // [9] 19
    }
    else{
        _32263 = NOVALUE;
    }

    /** traninit.e:434			return ""*/
    RefDS(_22186);
    DeRefDS(_lib_65681);
    return _22186;
L1: 

    /** traninit.e:437		if not file_exists( lib ) then*/
    RefDS(_lib_65681);
    _32264 = _17file_exists(_lib_65681);
    if (IS_ATOM_INT(_32264)) {
        if (_32264 != 0){
            DeRef(_32264);
            _32264 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    else {
        if (DBL_PTR(_32264)->dbl != 0.0){
            DeRef(_32264);
            _32264 = NOVALUE;
            goto L2; // [25] 69
        }
    }
    DeRef(_32264);
    _32264 = NOVALUE;

    /** traninit.e:438			ShowMsg(2, USER_SUPPLIED_LIBRARY_DOES_NOT_EXIST__1, { lib })*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_lib_65681);
    ((intptr_t*)_2)[1] = _lib_65681;
    _32266 = MAKE_SEQ(_1);
    _39ShowMsg(2LL, 348LL, _32266, 1LL);
    _32266 = NOVALUE;

    /** traninit.e:439			if force_build or build_system_type = BUILD_DIRECT then*/
    if (_56force_build_45727 != 0) {
        goto L3; // [46] 63
    }
    _32268 = (_56build_system_type_45701 == 3LL);
    if (_32268 == 0)
    {
        DeRef(_32268);
        _32268 = NOVALUE;
        goto L4; // [59] 68
    }
    else{
        DeRef(_32268);
        _32268 = NOVALUE;
    }
L3: 

    /** traninit.e:440				abort(1)*/
    UserCleanup(1LL);
L4: 
L2: 

    /** traninit.e:443		return canonical_path( lib )*/
    RefDS(_lib_65681);
    _32269 = _17canonical_path(_lib_65681, 0LL, 0LL);
    DeRefDS(_lib_65681);
    return _32269;
    ;
}



// 0xF86FF900
