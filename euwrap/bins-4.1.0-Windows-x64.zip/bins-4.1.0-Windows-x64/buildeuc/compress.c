// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _60compress(object _x_22877)
{
    object _x4_22878 = NOVALUE;
    object _s_22879 = NOVALUE;
    object _12938 = NOVALUE;
    object _12937 = NOVALUE;
    object _12936 = NOVALUE;
    object _12934 = NOVALUE;
    object _12933 = NOVALUE;
    object _12931 = NOVALUE;
    object _12929 = NOVALUE;
    object _12928 = NOVALUE;
    object _12927 = NOVALUE;
    object _12926 = NOVALUE;
    object _12924 = NOVALUE;
    object _12922 = NOVALUE;
    object _12920 = NOVALUE;
    object _12918 = NOVALUE;
    object _12917 = NOVALUE;
    object _12916 = NOVALUE;
    object _12914 = NOVALUE;
    object _12913 = NOVALUE;
    object _12912 = NOVALUE;
    object _12911 = NOVALUE;
    object _12910 = NOVALUE;
    object _12909 = NOVALUE;
    object _12908 = NOVALUE;
    object _12907 = NOVALUE;
    object _12906 = NOVALUE;
    object _12905 = NOVALUE;
    object _12903 = NOVALUE;
    object _12902 = NOVALUE;
    object _12901 = NOVALUE;
    object _12900 = NOVALUE;
    object _12899 = NOVALUE;
    object _12898 = NOVALUE;
    object _12896 = NOVALUE;
    object _12895 = NOVALUE;
    object _12894 = NOVALUE;
    object _12893 = NOVALUE;
    object _12892 = NOVALUE;
    object _12891 = NOVALUE;
    object _12890 = NOVALUE;
    object _12889 = NOVALUE;
    object _12888 = NOVALUE;
    object _0, _1, _2;
    

    /** compress.e:59		if integer(x) then*/
    if (IS_ATOM_INT(_x_22877))
    _12888 = 1;
    else if (IS_ATOM_DBL(_x_22877))
    _12888 = IS_ATOM_INT(DoubleToInt(_x_22877));
    else
    _12888 = 0;
    if (_12888 == 0)
    {
        _12888 = NOVALUE;
        goto L1; // [6] 220
    }
    else{
        _12888 = NOVALUE;
    }

    /** compress.e:60			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_22877)) {
        _12889 = (_x_22877 >= -2LL);
    }
    else {
        _12889 = binary_op(GREATEREQ, _x_22877, -2LL);
    }
    if (IS_ATOM_INT(_12889)) {
        if (_12889 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12889)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_22877)) {
        _12891 = (_x_22877 <= 244LL);
    }
    else {
        _12891 = binary_op(LESSEQ, _x_22877, 244LL);
    }
    if (_12891 == 0) {
        DeRef(_12891);
        _12891 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12891) && DBL_PTR(_12891)->dbl == 0.0){
            DeRef(_12891);
            _12891 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12891);
        _12891 = NOVALUE;
    }
    DeRef(_12891);
    _12891 = NOVALUE;

    /** compress.e:61				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_22877)) {
        _12892 = _x_22877 - -2LL;
        if ((object)((uintptr_t)_12892 +(uintptr_t) HIGH_BITS) >= 0){
            _12892 = NewDouble((eudouble)_12892);
        }
    }
    else {
        _12892 = binary_op(MINUS, _x_22877, -2LL);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12892;
    _12893 = MAKE_SEQ(_1);
    _12892 = NOVALUE;
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12889);
    _12889 = NOVALUE;
    return _12893;
    goto L3; // [41] 389
L2: 

    /** compress.e:63			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_22877)) {
        _12894 = (_x_22877 >= _60MIN2B_22851);
    }
    else {
        _12894 = binary_op(GREATEREQ, _x_22877, _60MIN2B_22851);
    }
    if (IS_ATOM_INT(_12894)) {
        if (_12894 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12894)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_22877)) {
        _12896 = (_x_22877 <= 32767LL);
    }
    else {
        _12896 = binary_op(LESSEQ, _x_22877, 32767LL);
    }
    if (_12896 == 0) {
        DeRef(_12896);
        _12896 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12896) && DBL_PTR(_12896)->dbl == 0.0){
            DeRef(_12896);
            _12896 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12896);
        _12896 = NOVALUE;
    }
    DeRef(_12896);
    _12896 = NOVALUE;

    /** compress.e:64				x -= MIN2B*/
    _0 = _x_22877;
    if (IS_ATOM_INT(_x_22877)) {
        _x_22877 = _x_22877 - _60MIN2B_22851;
        if ((object)((uintptr_t)_x_22877 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22877 = NewDouble((eudouble)_x_22877);
        }
    }
    else {
        _x_22877 = binary_op(MINUS, _x_22877, _60MIN2B_22851);
    }
    DeRef(_0);

    /** compress.e:65				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_22877)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22877 & (uintptr_t)255LL;
             _12898 = MAKE_UINT(tu);
        }
    }
    else {
        _12898 = binary_op(AND_BITS, _x_22877, 255LL);
    }
    if (IS_ATOM_INT(_x_22877)) {
        if (256LL > 0 && _x_22877 >= 0) {
            _12899 = _x_22877 / 256LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22877 / (eudouble)256LL);
            if (_x_22877 != MININT)
            _12899 = (object)temp_dbl;
            else
            _12899 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22877, 256LL);
        _12899 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 247LL;
    ((intptr_t*)_2)[2] = _12898;
    ((intptr_t*)_2)[3] = _12899;
    _12900 = MAKE_SEQ(_1);
    _12899 = NOVALUE;
    _12898 = NOVALUE;
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    return _12900;
    goto L3; // [94] 389
L4: 

    /** compress.e:67			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_22877)) {
        _12901 = (_x_22877 >= _60MIN3B_22857);
    }
    else {
        _12901 = binary_op(GREATEREQ, _x_22877, _60MIN3B_22857);
    }
    if (IS_ATOM_INT(_12901)) {
        if (_12901 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12901)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_22877)) {
        _12903 = (_x_22877 <= 8388607LL);
    }
    else {
        _12903 = binary_op(LESSEQ, _x_22877, 8388607LL);
    }
    if (_12903 == 0) {
        DeRef(_12903);
        _12903 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12903) && DBL_PTR(_12903)->dbl == 0.0){
            DeRef(_12903);
            _12903 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12903);
        _12903 = NOVALUE;
    }
    DeRef(_12903);
    _12903 = NOVALUE;

    /** compress.e:68				x -= MIN3B*/
    _0 = _x_22877;
    if (IS_ATOM_INT(_x_22877)) {
        _x_22877 = _x_22877 - _60MIN3B_22857;
        if ((object)((uintptr_t)_x_22877 +(uintptr_t) HIGH_BITS) >= 0){
            _x_22877 = NewDouble((eudouble)_x_22877);
        }
    }
    else {
        _x_22877 = binary_op(MINUS, _x_22877, _60MIN3B_22857);
    }
    DeRef(_0);

    /** compress.e:69				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_22877)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_22877 & (uintptr_t)255LL;
             _12905 = MAKE_UINT(tu);
        }
    }
    else {
        _12905 = binary_op(AND_BITS, _x_22877, 255LL);
    }
    if (IS_ATOM_INT(_x_22877)) {
        if (256LL > 0 && _x_22877 >= 0) {
            _12906 = _x_22877 / 256LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22877 / (eudouble)256LL);
            if (_x_22877 != MININT)
            _12906 = (object)temp_dbl;
            else
            _12906 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22877, 256LL);
        _12906 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12906)) {
        {uintptr_t tu;
             tu = (uintptr_t)_12906 & (uintptr_t)255LL;
             _12907 = MAKE_UINT(tu);
        }
    }
    else {
        _12907 = binary_op(AND_BITS, _12906, 255LL);
    }
    DeRef(_12906);
    _12906 = NOVALUE;
    if (IS_ATOM_INT(_x_22877)) {
        if (65536LL > 0 && _x_22877 >= 0) {
            _12908 = _x_22877 / 65536LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_22877 / (eudouble)65536LL);
            if (_x_22877 != MININT)
            _12908 = (object)temp_dbl;
            else
            _12908 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_22877, 65536LL);
        _12908 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 248LL;
    ((intptr_t*)_2)[2] = _12905;
    ((intptr_t*)_2)[3] = _12907;
    ((intptr_t*)_2)[4] = _12908;
    _12909 = MAKE_SEQ(_1);
    _12908 = NOVALUE;
    _12907 = NOVALUE;
    _12905 = NOVALUE;
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12909;
    goto L3; // [156] 389
L5: 

    /** compress.e:71			elsif x >= MIN4B and x <= MAX4B then*/
    if (IS_ATOM_INT(_x_22877)) {
        _12910 = (_x_22877 >= _60MIN4B_22863);
    }
    else {
        _12910 = binary_op(GREATEREQ, _x_22877, _60MIN4B_22863);
    }
    if (IS_ATOM_INT(_12910)) {
        if (_12910 == 0) {
            goto L6; // [167] 199
        }
    }
    else {
        if (DBL_PTR(_12910)->dbl == 0.0) {
            goto L6; // [167] 199
        }
    }
    if (IS_ATOM_INT(_x_22877)) {
        _12912 = (_x_22877 <= 2147483647LL);
    }
    else {
        _12912 = binary_op(LESSEQ, _x_22877, 2147483647LL);
    }
    if (_12912 == 0) {
        DeRef(_12912);
        _12912 = NOVALUE;
        goto L6; // [178] 199
    }
    else {
        if (!IS_ATOM_INT(_12912) && DBL_PTR(_12912)->dbl == 0.0){
            DeRef(_12912);
            _12912 = NOVALUE;
            goto L6; // [178] 199
        }
        DeRef(_12912);
        _12912 = NOVALUE;
    }
    DeRef(_12912);
    _12912 = NOVALUE;

    /** compress.e:72				return I4B & int_to_bytes(x)*/
    Ref(_x_22877);
    _12913 = _15int_to_bytes(_x_22877, 4LL);
    if (IS_SEQUENCE(249LL) && IS_ATOM(_12913)) {
    }
    else if (IS_ATOM(249LL) && IS_SEQUENCE(_12913)) {
        Prepend(&_12914, _12913, 249LL);
    }
    else {
        Concat((object_ptr)&_12914, 249LL, _12913);
    }
    DeRef(_12913);
    _12913 = NOVALUE;
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12909);
    _12909 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12914;
    goto L3; // [196] 389
L6: 

    /** compress.e:75				ifdef EU4_0 then*/

    /** compress.e:79					return I8B & int_to_bytes(x, 8)*/
    Ref(_x_22877);
    _12916 = _15int_to_bytes(_x_22877, 8LL);
    if (IS_SEQUENCE(250LL) && IS_ATOM(_12916)) {
    }
    else if (IS_ATOM(250LL) && IS_SEQUENCE(_12916)) {
        Prepend(&_12917, _12916, 250LL);
    }
    else {
        Concat((object_ptr)&_12917, 250LL, _12916);
    }
    DeRef(_12916);
    _12916 = NOVALUE;
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12914);
    _12914 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12909);
    _12909 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12917;
    goto L3; // [217] 389
L1: 

    /** compress.e:83		elsif atom(x) then*/
    _12918 = IS_ATOM(_x_22877);
    if (_12918 == 0)
    {
        _12918 = NOVALUE;
        goto L7; // [225] 309
    }
    else{
        _12918 = NOVALUE;
    }

    /** compress.e:85			x4 = atom_to_float32(x)*/
    Ref(_x_22877);
    _0 = _x4_22878;
    _x4_22878 = _15atom_to_float32(_x_22877);
    DeRef(_0);

    /** compress.e:86			if x = float32_to_atom(x4) then*/
    RefDS(_x4_22878);
    _12920 = _15float32_to_atom(_x4_22878);
    if (binary_op_a(NOTEQ, _x_22877, _12920)){
        DeRef(_12920);
        _12920 = NOVALUE;
        goto L8; // [242] 259
    }
    DeRef(_12920);
    _12920 = NOVALUE;

    /** compress.e:88				return F4B & x4*/
    Prepend(&_12922, _x4_22878, 251LL);
    DeRef(_x_22877);
    DeRefDS(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12917);
    _12917 = NOVALUE;
    DeRef(_12914);
    _12914 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12909);
    _12909 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12922;
    goto L3; // [256] 389
L8: 

    /** compress.e:90				x4 = atom_to_float64( x )*/
    Ref(_x_22877);
    _0 = _x4_22878;
    _x4_22878 = _15atom_to_float64(_x_22877);
    DeRef(_0);

    /** compress.e:91				if x = float64_to_atom( x4 ) then*/
    RefDS(_x4_22878);
    _12924 = _15float64_to_atom(_x4_22878);
    if (binary_op_a(NOTEQ, _x_22877, _12924)){
        DeRef(_12924);
        _12924 = NOVALUE;
        goto L9; // [273] 290
    }
    DeRef(_12924);
    _12924 = NOVALUE;

    /** compress.e:92					return F8B & x4*/
    Prepend(&_12926, _x4_22878, 252LL);
    DeRef(_x_22877);
    DeRefDS(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12917);
    _12917 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12914);
    _12914 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12909);
    _12909 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12926;
    goto L3; // [287] 389
L9: 

    /** compress.e:94					return F10B & atom_to_float80( x )*/
    Ref(_x_22877);
    _12927 = _15atom_to_float80(_x_22877);
    if (IS_SEQUENCE(253LL) && IS_ATOM(_12927)) {
    }
    else if (IS_ATOM(253LL) && IS_SEQUENCE(_12927)) {
        Prepend(&_12928, _12927, 253LL);
    }
    else {
        Concat((object_ptr)&_12928, 253LL, _12927);
    }
    DeRef(_12927);
    _12927 = NOVALUE;
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_s_22879);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12917);
    _12917 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12914);
    _12914 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12926);
    _12926 = NOVALUE;
    DeRef(_12909);
    _12909 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _12928;
    goto L3; // [306] 389
L7: 

    /** compress.e:100			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_22877)){
            _12929 = SEQ_PTR(_x_22877)->length;
    }
    else {
        _12929 = 1;
    }
    if (_12929 > 255LL)
    goto LA; // [314] 330

    /** compress.e:101				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_22877)){
            _12931 = SEQ_PTR(_x_22877)->length;
    }
    else {
        _12931 = 1;
    }
    DeRef(_s_22879);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254LL;
    ((intptr_t *)_2)[2] = _12931;
    _s_22879 = MAKE_SEQ(_1);
    _12931 = NOVALUE;
    goto LB; // [327] 345
LA: 

    /** compress.e:103				s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_22877)){
            _12933 = SEQ_PTR(_x_22877)->length;
    }
    else {
        _12933 = 1;
    }
    _12934 = _15int_to_bytes(_12933, 4LL);
    _12933 = NOVALUE;
    if (IS_SEQUENCE(255LL) && IS_ATOM(_12934)) {
    }
    else if (IS_ATOM(255LL) && IS_SEQUENCE(_12934)) {
        Prepend(&_s_22879, _12934, 255LL);
    }
    else {
        Concat((object_ptr)&_s_22879, 255LL, _12934);
    }
    DeRef(_12934);
    _12934 = NOVALUE;
LB: 

    /** compress.e:105			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_22877)){
            _12936 = SEQ_PTR(_x_22877)->length;
    }
    else {
        _12936 = 1;
    }
    {
        object _i_22951;
        _i_22951 = 1LL;
LC: 
        if (_i_22951 > _12936){
            goto LD; // [350] 380
        }

        /** compress.e:106				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_22877);
        _12937 = (object)*(((s1_ptr)_2)->base + _i_22951);
        Ref(_12937);
        _12938 = _60compress(_12937);
        _12937 = NOVALUE;
        if (IS_SEQUENCE(_s_22879) && IS_ATOM(_12938)) {
            Ref(_12938);
            Append(&_s_22879, _s_22879, _12938);
        }
        else if (IS_ATOM(_s_22879) && IS_SEQUENCE(_12938)) {
        }
        else {
            Concat((object_ptr)&_s_22879, _s_22879, _12938);
        }
        DeRef(_12938);
        _12938 = NOVALUE;

        /** compress.e:107			end for*/
        _i_22951 = _i_22951 + 1LL;
        goto LC; // [375] 357
LD: 
        ;
    }

    /** compress.e:108			return s*/
    DeRef(_x_22877);
    DeRef(_x4_22878);
    DeRef(_12893);
    _12893 = NOVALUE;
    DeRef(_12928);
    _12928 = NOVALUE;
    DeRef(_12894);
    _12894 = NOVALUE;
    DeRef(_12917);
    _12917 = NOVALUE;
    DeRef(_12922);
    _12922 = NOVALUE;
    DeRef(_12914);
    _12914 = NOVALUE;
    DeRef(_12889);
    _12889 = NOVALUE;
    DeRef(_12910);
    _12910 = NOVALUE;
    DeRef(_12926);
    _12926 = NOVALUE;
    DeRef(_12909);
    _12909 = NOVALUE;
    DeRef(_12901);
    _12901 = NOVALUE;
    DeRef(_12900);
    _12900 = NOVALUE;
    return _s_22879;
L3: 
    ;
}



// 0xD7AB7BB6
