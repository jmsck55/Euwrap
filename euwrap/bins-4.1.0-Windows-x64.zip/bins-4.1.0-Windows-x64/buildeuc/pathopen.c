// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _48convert_from_OEM(object _s_50693)
{
    object _ls_50694 = NOVALUE;
    object _rc_50695 = NOVALUE;
    object _26024 = NOVALUE;
    object _26023 = NOVALUE;
    object _26021 = NOVALUE;
    object _26020 = NOVALUE;
    object _26017 = NOVALUE;
    object _26016 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:37		ls=length(s)*/
    if (IS_SEQUENCE(_s_50693)){
            _ls_50694 = SEQ_PTR(_s_50693)->length;
    }
    else {
        _ls_50694 = 1;
    }

    /** pathopen.e:38		if ls>convert_length then*/
    if (_ls_50694 <= _48convert_length_50673)
    goto L1; // [12] 47

    /** pathopen.e:39			free(convert_buffer)*/
    Ref(_48convert_buffer_50672);
    _9free(_48convert_buffer_50672);

    /** pathopen.e:40			convert_length=and_bits(ls+15,-16)+1*/
    _26016 = _ls_50694 + 15LL;
    {uintptr_t tu;
         tu = (uintptr_t)_26016 & (uintptr_t)-16LL;
         _26017 = MAKE_UINT(tu);
    }
    _26016 = NOVALUE;
    if (IS_ATOM_INT(_26017)) {
        _48convert_length_50673 = _26017 + 1;
    }
    else
    { // coercing _48convert_length_50673 to an integer 1
        _48convert_length_50673 = 1+(object)(DBL_PTR(_26017)->dbl);
        if( !IS_ATOM_INT(_48convert_length_50673) ){
            _48convert_length_50673 = (object)DBL_PTR(_48convert_length_50673)->dbl;
        }
    }
    DeRef(_26017);
    _26017 = NOVALUE;

    /** pathopen.e:41			convert_buffer=allocate(convert_length)*/
    _0 = _9allocate(_48convert_length_50673, 0LL);
    DeRef(_48convert_buffer_50672);
    _48convert_buffer_50672 = _0;
L1: 

    /** pathopen.e:43		poke(convert_buffer,s)*/
    if (IS_ATOM_INT(_48convert_buffer_50672)){
        poke_addr = (uint8_t *)_48convert_buffer_50672;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_48convert_buffer_50672)->dbl);
    }
    _1 = (object)SEQ_PTR(_s_50693);
    _1 = (object)((s1_ptr)_1)->base;
    while (1) {
        _1 += sizeof(object);
        _2 = *((object *)_1);
        if (IS_ATOM_INT(_2)) {
            *poke_addr++ = (uint8_t)_2;
        }
        else if (_2 == NOVALUE) {
            break;
        }
        else {
            *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
        }
    }

    /** pathopen.e:44		poke(convert_buffer+ls,0)*/
    if (IS_ATOM_INT(_48convert_buffer_50672)) {
        _26020 = _48convert_buffer_50672 + _ls_50694;
        if ((object)((uintptr_t)_26020 + (uintptr_t)HIGH_BITS) >= 0){
            _26020 = NewDouble((eudouble)_26020);
        }
    }
    else {
        _26020 = NewDouble(DBL_PTR(_48convert_buffer_50672)->dbl + (eudouble)_ls_50694);
    }
    if (IS_ATOM_INT(_26020)){
        poke_addr = (uint8_t *)_26020;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_26020)->dbl);
    }
    *poke_addr = (uint8_t)0LL;
    DeRef(_26020);
    _26020 = NOVALUE;

    /** pathopen.e:45		rc=c_func(oem2char,{convert_buffer,convert_buffer}) -- always nonzero*/
    Ref(_48convert_buffer_50672);
    Ref(_48convert_buffer_50672);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _48convert_buffer_50672;
    ((intptr_t *)_2)[2] = _48convert_buffer_50672;
    _26021 = MAKE_SEQ(_1);
    _rc_50695 = call_c(1, _48oem2char_50671, _26021);
    DeRefDS(_26021);
    _26021 = NOVALUE;
    if (!IS_ATOM_INT(_rc_50695)) {
        _1 = (object)(DBL_PTR(_rc_50695)->dbl);
        DeRefDS(_rc_50695);
        _rc_50695 = _1;
    }

    /** pathopen.e:46		return peek({convert_buffer,ls}) */
    Ref(_48convert_buffer_50672);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _48convert_buffer_50672;
    ((intptr_t *)_2)[2] = _ls_50694;
    _26023 = MAKE_SEQ(_1);
    _1 = (object)SEQ_PTR(_26023);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _26024 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_26023);
    _26023 = NOVALUE;
    DeRefDS(_s_50693);
    return _26024;
    ;
}


object _48exe_path()
{
    object _26028 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:70		if sequence(exe_path_cache) then*/
    _26028 = IS_SEQUENCE(_48exe_path_cache_50725);
    if (_26028 == 0)
    {
        _26028 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _26028 = NOVALUE;
    }

    /** pathopen.e:71			return exe_path_cache*/
    Ref(_48exe_path_cache_50725);
    return _48exe_path_cache_50725;
L1: 

    /** pathopen.e:74		exe_path_cache = command_line()*/
    DeRef(_48exe_path_cache_50725);
    _48exe_path_cache_50725 = Command_Line();

    /** pathopen.e:75		exe_path_cache = exe_path_cache[1]*/
    _0 = _48exe_path_cache_50725;
    _2 = (object)SEQ_PTR(_48exe_path_cache_50725);
    _48exe_path_cache_50725 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_48exe_path_cache_50725);
    DeRefDS(_0);

    /** pathopen.e:77		return exe_path_cache*/
    RefDS(_48exe_path_cache_50725);
    return _48exe_path_cache_50725;
    ;
}


object _48check_cache(object _env_50737, object _inc_path_50738)
{
    object _delim_50739 = NOVALUE;
    object _pos_50740 = NOVALUE;
    object _26079 = NOVALUE;
    object _26078 = NOVALUE;
    object _26077 = NOVALUE;
    object _26076 = NOVALUE;
    object _26074 = NOVALUE;
    object _26073 = NOVALUE;
    object _26072 = NOVALUE;
    object _26071 = NOVALUE;
    object _26070 = NOVALUE;
    object _26069 = NOVALUE;
    object _26068 = NOVALUE;
    object _26067 = NOVALUE;
    object _26066 = NOVALUE;
    object _26065 = NOVALUE;
    object _26064 = NOVALUE;
    object _26060 = NOVALUE;
    object _26059 = NOVALUE;
    object _26058 = NOVALUE;
    object _26057 = NOVALUE;
    object _26056 = NOVALUE;
    object _26055 = NOVALUE;
    object _26054 = NOVALUE;
    object _26053 = NOVALUE;
    object _26051 = NOVALUE;
    object _26050 = NOVALUE;
    object _26049 = NOVALUE;
    object _26048 = NOVALUE;
    object _26047 = NOVALUE;
    object _26046 = NOVALUE;
    object _26044 = NOVALUE;
    object _26043 = NOVALUE;
    object _26042 = NOVALUE;
    object _26041 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:83		if not num_var then -- first time the var is accessed, add cache entry*/
    if (_48num_var_50714 != 0)
    goto L1; // [9] 94

    /** pathopen.e:84			cache_vars = append(cache_vars,env)*/
    RefDS(_env_50737);
    Append(&_48cache_vars_50715, _48cache_vars_50715, _env_50737);

    /** pathopen.e:85			cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_50738);
    Append(&_48cache_strings_50716, _48cache_strings_50716, _inc_path_50738);

    /** pathopen.e:86			cache_substrings = append(cache_substrings,{})*/
    RefDS(_22186);
    Append(&_48cache_substrings_50717, _48cache_substrings_50717, _22186);

    /** pathopen.e:87			cache_starts = append(cache_starts,{})*/
    RefDS(_22186);
    Append(&_48cache_starts_50718, _48cache_starts_50718, _22186);

    /** pathopen.e:88			cache_ends = append(cache_ends,{})*/
    RefDS(_22186);
    Append(&_48cache_ends_50719, _48cache_ends_50719, _22186);

    /** pathopen.e:89			ifdef WINDOWS then*/

    /** pathopen.e:90				cache_converted = append(cache_converted,{})*/
    RefDS(_22186);
    Append(&_48cache_converted_50720, _48cache_converted_50720, _22186);

    /** pathopen.e:92			num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_48cache_vars_50715)){
            _48num_var_50714 = SEQ_PTR(_48cache_vars_50715)->length;
    }
    else {
        _48num_var_50714 = 1;
    }

    /** pathopen.e:93			cache_complete &= 0*/
    Append(&_48cache_complete_50721, _48cache_complete_50721, 0LL);

    /** pathopen.e:94			cache_delims &= 0*/
    Append(&_48cache_delims_50722, _48cache_delims_50722, 0LL);

    /** pathopen.e:95			return 0*/
    DeRefDSi(_env_50737);
    DeRefDSi(_inc_path_50738);
    return 0LL;
    goto L2; // [91] 456
L1: 

    /** pathopen.e:97			if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (object)SEQ_PTR(_48cache_strings_50716);
    _26041 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    if (IS_ATOM_INT(_inc_path_50738) && IS_ATOM_INT(_26041)){
        _26042 = (_inc_path_50738 < _26041) ? -1 : (_inc_path_50738 > _26041);
    }
    else{
        _26042 = compare(_inc_path_50738, _26041);
    }
    _26041 = NOVALUE;
    if (_26042 == 0)
    {
        _26042 = NOVALUE;
        goto L3; // [108] 455
    }
    else{
        _26042 = NOVALUE;
    }

    /** pathopen.e:98				cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_50738);
    _2 = (object)SEQ_PTR(_48cache_strings_50716);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_strings_50716 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _inc_path_50738;
    DeRefDS(_1);

    /** pathopen.e:99				cache_complete[num_var] = 0*/
    _2 = (object)SEQ_PTR(_48cache_complete_50721);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50721 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
    *(intptr_t *)_2 = 0LL;

    /** pathopen.e:100				if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (object)SEQ_PTR(_48cache_strings_50716);
    _26043 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    _26044 = e_match_from(_26043, _inc_path_50738, 1LL);
    _26043 = NOVALUE;
    if (_26044 == 1LL)
    goto L4; // [146] 454

    /** pathopen.e:101					pos = -1*/
    _pos_50740 = -1LL;

    /** pathopen.e:102					for i=1 to length(cache_strings[num_var]) do*/
    _2 = (object)SEQ_PTR(_48cache_strings_50716);
    _26046 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    if (IS_SEQUENCE(_26046)){
            _26047 = SEQ_PTR(_26046)->length;
    }
    else {
        _26047 = 1;
    }
    _26046 = NOVALUE;
    {
        object _i_50761;
        _i_50761 = 1LL;
L5: 
        if (_i_50761 > _26047){
            goto L6; // [168] 453
        }

        /** pathopen.e:103						if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        _26048 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26048);
        _26049 = (object)*(((s1_ptr)_2)->base + _i_50761);
        _26048 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_50738)){
                _26050 = SEQ_PTR(_inc_path_50738)->length;
        }
        else {
            _26050 = 1;
        }
        if (IS_ATOM_INT(_26049)) {
            _26051 = (_26049 > _26050);
        }
        else {
            _26051 = binary_op(GREATER, _26049, _26050);
        }
        _26049 = NOVALUE;
        _26050 = NOVALUE;
        if (IS_ATOM_INT(_26051)) {
            if (_26051 != 0) {
                goto L7; // [196] 250
            }
        }
        else {
            if (DBL_PTR(_26051)->dbl != 0.0) {
                goto L7; // [196] 250
            }
        }
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        _26053 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26053);
        _26054 = (object)*(((s1_ptr)_2)->base + _i_50761);
        _26053 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        _26055 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26055);
        _26056 = (object)*(((s1_ptr)_2)->base + _i_50761);
        _26055 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        _26057 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26057);
        _26058 = (object)*(((s1_ptr)_2)->base + _i_50761);
        _26057 = NOVALUE;
        rhs_slice_target = (object_ptr)&_26059;
        RHS_Slice(_inc_path_50738, _26056, _26058);
        if (IS_ATOM_INT(_26054) && IS_ATOM_INT(_26059)){
            _26060 = (_26054 < _26059) ? -1 : (_26054 > _26059);
        }
        else{
            _26060 = compare(_26054, _26059);
        }
        _26054 = NOVALUE;
        DeRefDS(_26059);
        _26059 = NOVALUE;
        if (_26060 == 0)
        {
            _26060 = NOVALUE;
            goto L8; // [246] 261
        }
        else{
            _26060 = NOVALUE;
        }
L7: 

        /** pathopen.e:107							pos = i-1*/
        _pos_50740 = _i_50761 - 1LL;

        /** pathopen.e:108							exit*/
        goto L6; // [258] 453
L8: 

        /** pathopen.e:110						if pos = 0 then*/
        if (_pos_50740 != 0LL)
        goto L9; // [263] 276

        /** pathopen.e:111							return 0*/
        DeRefDSi(_env_50737);
        DeRefDSi(_inc_path_50738);
        _26046 = NOVALUE;
        DeRef(_26051);
        _26051 = NOVALUE;
        _26058 = NOVALUE;
        _26056 = NOVALUE;
        return 0LL;
        goto LA; // [273] 446
L9: 

        /** pathopen.e:112						elsif pos >0 then -- crop cache data*/
        if (_pos_50740 <= 0LL)
        goto LB; // [278] 445

        /** pathopen.e:113							cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        _26064 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        rhs_slice_target = (object_ptr)&_26065;
        RHS_Slice(_26064, 1LL, _pos_50740);
        _26064 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50717 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26065;
        if( _1 != _26065 ){
            DeRefDS(_1);
        }
        _26065 = NOVALUE;

        /** pathopen.e:114							cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        _26066 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        rhs_slice_target = (object_ptr)&_26067;
        RHS_Slice(_26066, 1LL, _pos_50740);
        _26066 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50718 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26067;
        if( _1 != _26067 ){
            DeRef(_1);
        }
        _26067 = NOVALUE;

        /** pathopen.e:115							cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        _26068 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        rhs_slice_target = (object_ptr)&_26069;
        RHS_Slice(_26068, 1LL, _pos_50740);
        _26068 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50719 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26069;
        if( _1 != _26069 ){
            DeRef(_1);
        }
        _26069 = NOVALUE;

        /** pathopen.e:116							ifdef WINDOWS then*/

        /** pathopen.e:117								cache_converted[num_var] = cache_converted[num_var][1..pos]*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26070 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        rhs_slice_target = (object_ptr)&_26071;
        RHS_Slice(_26070, 1LL, _pos_50740);
        _26070 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26071;
        if( _1 != _26071 ){
            DeRef(_1);
        }
        _26071 = NOVALUE;

        /** pathopen.e:119							delim = cache_ends[num_var][$]+1*/
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        _26072 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26072)){
                _26073 = SEQ_PTR(_26072)->length;
        }
        else {
            _26073 = 1;
        }
        _2 = (object)SEQ_PTR(_26072);
        _26074 = (object)*(((s1_ptr)_2)->base + _26073);
        _26072 = NOVALUE;
        if (IS_ATOM_INT(_26074)) {
            _delim_50739 = _26074 + 1;
        }
        else
        { // coercing _delim_50739 to an integer 1
            _delim_50739 = 1+(object)(DBL_PTR(_26074)->dbl);
            if( !IS_ATOM_INT(_delim_50739) ){
                _delim_50739 = (object)DBL_PTR(_delim_50739)->dbl;
            }
        }
        _26074 = NOVALUE;

        /** pathopen.e:120							while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_50738)){
                _26076 = SEQ_PTR(_inc_path_50738)->length;
        }
        else {
            _26076 = 1;
        }
        _26077 = (_delim_50739 <= _26076);
        _26076 = NOVALUE;
        if (_26077 == 0) {
            goto LD; // [409] 434
        }
        _26079 = (_delim_50739 != 59LL);
        if (_26079 == 0)
        {
            DeRef(_26079);
            _26079 = NOVALUE;
            goto LD; // [420] 434
        }
        else{
            DeRef(_26079);
            _26079 = NOVALUE;
        }

        /** pathopen.e:121								delim+=1*/
        _delim_50739 = _delim_50739 + 1;

        /** pathopen.e:122							end while*/
        goto LC; // [431] 402
LD: 

        /** pathopen.e:123							cache_delims[num_var] = delim*/
        _2 = (object)SEQ_PTR(_48cache_delims_50722);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50722 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        *(intptr_t *)_2 = _delim_50739;
LB: 
LA: 

        /** pathopen.e:125					end for*/
        _i_50761 = _i_50761 + 1LL;
        goto L5; // [448] 175
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** pathopen.e:129		return 1*/
    DeRefDSi(_env_50737);
    DeRefDSi(_inc_path_50738);
    _26046 = NOVALUE;
    DeRef(_26051);
    _26051 = NOVALUE;
    _26058 = NOVALUE;
    DeRef(_26077);
    _26077 = NOVALUE;
    _26056 = NOVALUE;
    return 1LL;
    ;
}


object _48get_conf_dirs()
{
    object _delimiter_50804 = NOVALUE;
    object _dirs_50805 = NOVALUE;
    object _26084 = NOVALUE;
    object _26082 = NOVALUE;
    object _26081 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:136		ifdef UNIX then*/

    /** pathopen.e:139			delimiter = ';'*/
    _delimiter_50804 = 59LL;

    /** pathopen.e:142		dirs = ""*/
    RefDS(_22186);
    DeRef(_dirs_50805);
    _dirs_50805 = _22186;

    /** pathopen.e:143		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50723)){
            _26081 = SEQ_PTR(_48config_inc_paths_50723)->length;
    }
    else {
        _26081 = 1;
    }
    {
        object _i_50807;
        _i_50807 = 1LL;
L1: 
        if (_i_50807 > _26081){
            goto L2; // [22] 68
        }

        /** pathopen.e:144			dirs &= config_inc_paths[i]*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50723);
        _26082 = (object)*(((s1_ptr)_2)->base + _i_50807);
        Concat((object_ptr)&_dirs_50805, _dirs_50805, _26082);
        _26082 = NOVALUE;

        /** pathopen.e:145			if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_48config_inc_paths_50723)){
                _26084 = SEQ_PTR(_48config_inc_paths_50723)->length;
        }
        else {
            _26084 = 1;
        }
        if (_i_50807 == _26084)
        goto L3; // [48] 61

        /** pathopen.e:146				dirs &= delimiter*/
        Append(&_dirs_50805, _dirs_50805, _delimiter_50804);
L3: 

        /** pathopen.e:148		end for*/
        _i_50807 = _i_50807 + 1LL;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** pathopen.e:150		return dirs*/
    return _dirs_50805;
    ;
}


object _48strip_file_from_path(object _full_path_50817)
{
    object _26090 = NOVALUE;
    object _26088 = NOVALUE;
    object _26087 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:156		for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_50817)){
            _26087 = SEQ_PTR(_full_path_50817)->length;
    }
    else {
        _26087 = 1;
    }
    {
        object _i_50819;
        _i_50819 = _26087;
L1: 
        if (_i_50819 < 1LL){
            goto L2; // [8] 46
        }

        /** pathopen.e:157			if full_path[i] = SLASH then*/
        _2 = (object)SEQ_PTR(_full_path_50817);
        _26088 = (object)*(((s1_ptr)_2)->base + _i_50819);
        if (binary_op_a(NOTEQ, _26088, 92LL)){
            _26088 = NOVALUE;
            goto L3; // [23] 39
        }
        _26088 = NOVALUE;

        /** pathopen.e:158				return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_26090;
        RHS_Slice(_full_path_50817, 1LL, _i_50819);
        DeRefDS(_full_path_50817);
        return _26090;
L3: 

        /** pathopen.e:160		end for*/
        _i_50819 = _i_50819 + -1LL;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** pathopen.e:162		return ""*/
    RefDS(_22186);
    DeRefDS(_full_path_50817);
    DeRef(_26090);
    _26090 = NOVALUE;
    return _22186;
    ;
}


object _48expand_path(object _path_50828, object _prefix_50829)
{
    object _absolute_50830 = NOVALUE;
    object _26105 = NOVALUE;
    object _26104 = NOVALUE;
    object _26103 = NOVALUE;
    object _26102 = NOVALUE;
    object _26101 = NOVALUE;
    object _26100 = NOVALUE;
    object _26096 = NOVALUE;
    object _26095 = NOVALUE;
    object _26094 = NOVALUE;
    object _26091 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:169		if not length(path) then*/
    if (IS_SEQUENCE(_path_50828)){
            _26091 = SEQ_PTR(_path_50828)->length;
    }
    else {
        _26091 = 1;
    }
    if (_26091 != 0)
    goto L1; // [10] 22
    _26091 = NOVALUE;

    /** pathopen.e:170			return pwd*/
    RefDS(_48pwd_50726);
    DeRefDS(_path_50828);
    DeRefDS(_prefix_50829);
    return _48pwd_50726;
L1: 

    /** pathopen.e:174		ifdef UNIX then*/

    /** pathopen.e:185			absolute = find(path[1], SLASH_CHARS) or find(':', path)*/
    _2 = (object)SEQ_PTR(_path_50828);
    _26094 = (object)*(((s1_ptr)_2)->base + 1LL);
    _26095 = find_from(_26094, _46SLASH_CHARS_21927, 1LL);
    _26094 = NOVALUE;
    _26096 = find_from(58LL, _path_50828, 1LL);
    _absolute_50830 = (_26095 != 0 || _26096 != 0);
    _26095 = NOVALUE;
    _26096 = NOVALUE;

    /** pathopen.e:188		if not absolute then*/
    if (_absolute_50830 != 0)
    goto L2; // [50] 64

    /** pathopen.e:189			path = prefix & SLASH & path*/
    {
        object concat_list[3];

        concat_list[0] = _path_50828;
        concat_list[1] = 92LL;
        concat_list[2] = _prefix_50829;
        Concat_N((object_ptr)&_path_50828, concat_list, 3);
    }
L2: 

    /** pathopen.e:192		if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_50828)){
            _26100 = SEQ_PTR(_path_50828)->length;
    }
    else {
        _26100 = 1;
    }
    if (_26100 == 0) {
        goto L3; // [69] 103
    }
    if (IS_SEQUENCE(_path_50828)){
            _26102 = SEQ_PTR(_path_50828)->length;
    }
    else {
        _26102 = 1;
    }
    _2 = (object)SEQ_PTR(_path_50828);
    _26103 = (object)*(((s1_ptr)_2)->base + _26102);
    _26104 = find_from(_26103, _46SLASH_CHARS_21927, 1LL);
    _26103 = NOVALUE;
    _26105 = (_26104 == 0);
    _26104 = NOVALUE;
    if (_26105 == 0)
    {
        DeRef(_26105);
        _26105 = NOVALUE;
        goto L3; // [91] 103
    }
    else{
        DeRef(_26105);
        _26105 = NOVALUE;
    }

    /** pathopen.e:193			path &= SLASH*/
    Append(&_path_50828, _path_50828, 92LL);
L3: 

    /** pathopen.e:196		return path*/
    DeRefDS(_prefix_50829);
    return _path_50828;
    ;
}


void _48add_include_directory(object _path_50856)
{
    object _26108 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:200		path = expand_path( path, pwd )*/
    RefDS(_path_50856);
    RefDS(_48pwd_50726);
    _0 = _path_50856;
    _path_50856 = _48expand_path(_path_50856, _48pwd_50726);
    DeRefDS(_0);

    /** pathopen.e:202		if not find( path, config_inc_paths ) then*/
    _26108 = find_from(_path_50856, _48config_inc_paths_50723, 1LL);
    if (_26108 != 0)
    goto L1; // [23] 35
    _26108 = NOVALUE;

    /** pathopen.e:203			config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_50856);
    Append(&_48config_inc_paths_50723, _48config_inc_paths_50723, _path_50856);
L1: 

    /** pathopen.e:205	end procedure*/
    DeRefDS(_path_50856);
    return;
    ;
}


object _48load_euphoria_config(object _file_50865)
{
    object _fn_50866 = NOVALUE;
    object _in_50867 = NOVALUE;
    object _spos_50868 = NOVALUE;
    object _epos_50869 = NOVALUE;
    object _conf_path_50870 = NOVALUE;
    object _new_args_50871 = NOVALUE;
    object _arg_50872 = NOVALUE;
    object _parm_50873 = NOVALUE;
    object _section_50874 = NOVALUE;
    object _needed_50971 = NOVALUE;
    object _26205 = NOVALUE;
    object _26204 = NOVALUE;
    object _26201 = NOVALUE;
    object _26199 = NOVALUE;
    object _26198 = NOVALUE;
    object _26176 = NOVALUE;
    object _26173 = NOVALUE;
    object _26172 = NOVALUE;
    object _26170 = NOVALUE;
    object _26166 = NOVALUE;
    object _26164 = NOVALUE;
    object _26162 = NOVALUE;
    object _26160 = NOVALUE;
    object _26158 = NOVALUE;
    object _26156 = NOVALUE;
    object _26155 = NOVALUE;
    object _26154 = NOVALUE;
    object _26153 = NOVALUE;
    object _26152 = NOVALUE;
    object _26151 = NOVALUE;
    object _26150 = NOVALUE;
    object _26149 = NOVALUE;
    object _26147 = NOVALUE;
    object _26145 = NOVALUE;
    object _26143 = NOVALUE;
    object _26139 = NOVALUE;
    object _26138 = NOVALUE;
    object _26133 = NOVALUE;
    object _26131 = NOVALUE;
    object _26129 = NOVALUE;
    object _26128 = NOVALUE;
    object _26120 = NOVALUE;
    object _26114 = NOVALUE;
    object _26113 = NOVALUE;
    object _26111 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:213		sequence new_args = {}*/
    RefDS(_22186);
    DeRef(_new_args_50871);
    _new_args_50871 = _22186;

    /** pathopen.e:219		if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_50865);
    _26111 = _17file_type(_file_50865);
    if (binary_op_a(NOTEQ, _26111, 2LL)){
        DeRef(_26111);
        _26111 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_26111);
    _26111 = NOVALUE;

    /** pathopen.e:220			if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_50865)){
            _26113 = SEQ_PTR(_file_50865)->length;
    }
    else {
        _26113 = 1;
    }
    _2 = (object)SEQ_PTR(_file_50865);
    _26114 = (object)*(((s1_ptr)_2)->base + _26113);
    if (binary_op_a(EQUALS, _26114, 92LL)){
        _26114 = NOVALUE;
        goto L2; // [33] 46
    }
    _26114 = NOVALUE;

    /** pathopen.e:221				file &= SLASH*/
    Append(&_file_50865, _file_50865, 92LL);
L2: 

    /** pathopen.e:223			file &= "eu.cfg"*/
    Concat((object_ptr)&_file_50865, _file_50865, _26117);
L1: 

    /** pathopen.e:226		conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_50865);
    _0 = _conf_path_50870;
    _conf_path_50870 = _17canonical_path(_file_50865, 0LL, 2LL);
    DeRef(_0);

    /** pathopen.e:229		if find(conf_path, seen_conf) != 0 then*/
    _26120 = find_from(_conf_path_50870, _48seen_conf_50862, 1LL);
    if (_26120 == 0LL)
    goto L3; // [74] 85

    /** pathopen.e:230			return {}*/
    RefDS(_22186);
    DeRefDS(_file_50865);
    DeRefi(_in_50867);
    DeRefDS(_conf_path_50870);
    DeRef(_new_args_50871);
    DeRefi(_arg_50872);
    DeRefi(_parm_50873);
    DeRef(_section_50874);
    return _22186;
L3: 

    /** pathopen.e:232		seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_50870);
    Append(&_48seen_conf_50862, _48seen_conf_50862, _conf_path_50870);

    /** pathopen.e:234		section = "all"*/
    RefDS(_26123);
    DeRef(_section_50874);
    _section_50874 = _26123;

    /** pathopen.e:235		fn = open( conf_path, "r" )*/
    _fn_50866 = EOpen(_conf_path_50870, _26124, 0LL);

    /** pathopen.e:236		if fn = -1 then return {} end if*/
    if (_fn_50866 != -1LL)
    goto L4; // [109] 118
    RefDS(_22186);
    DeRefDS(_file_50865);
    DeRefi(_in_50867);
    DeRefDS(_conf_path_50870);
    DeRef(_new_args_50871);
    DeRefi(_arg_50872);
    DeRefi(_parm_50873);
    DeRefDSi(_section_50874);
    return _22186;
L4: 

    /** pathopen.e:238		in = gets( fn )*/
    DeRefi(_in_50867);
    _in_50867 = EGets(_fn_50866);

    /** pathopen.e:239		while sequence( in ) do*/
L5: 
    _26128 = IS_SEQUENCE(_in_50867);
    if (_26128 == 0)
    {
        _26128 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _26128 = NOVALUE;
    }

    /** pathopen.e:241			spos = 1*/
    _spos_50868 = 1LL;

    /** pathopen.e:242			while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_50867)){
            _26129 = SEQ_PTR(_in_50867)->length;
    }
    else {
        _26129 = 1;
    }
    if (_spos_50868 > _26129)
    goto L8; // [147] 182

    /** pathopen.e:243				if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50867);
    _26131 = (object)*(((s1_ptr)_2)->base + _spos_50868);
    _26133 = find_from(_26131, _26132, 1LL);
    _26131 = NOVALUE;
    if (_26133 != 0LL)
    goto L9; // [162] 171

    /** pathopen.e:244					exit*/
    goto L8; // [168] 182
L9: 

    /** pathopen.e:246				spos += 1*/
    _spos_50868 = _spos_50868 + 1;

    /** pathopen.e:247			end while*/
    goto L7; // [179] 144
L8: 

    /** pathopen.e:249			epos = length(in)*/
    if (IS_SEQUENCE(_in_50867)){
            _epos_50869 = SEQ_PTR(_in_50867)->length;
    }
    else {
        _epos_50869 = 1;
    }

    /** pathopen.e:250			while epos >= spos do*/
LA: 
    if (_epos_50869 < _spos_50868)
    goto LB; // [192] 227

    /** pathopen.e:251				if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (object)SEQ_PTR(_in_50867);
    _26138 = (object)*(((s1_ptr)_2)->base + _epos_50869);
    _26139 = find_from(_26138, _26132, 1LL);
    _26138 = NOVALUE;
    if (_26139 != 0LL)
    goto LC; // [207] 216

    /** pathopen.e:252					exit*/
    goto LB; // [213] 227
LC: 

    /** pathopen.e:254				epos -= 1*/
    _epos_50869 = _epos_50869 - 1LL;

    /** pathopen.e:255			end while*/
    goto LA; // [224] 192
LB: 

    /** pathopen.e:257			in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_50867;
    RHS_Slice(_in_50867, _spos_50868, _epos_50869);

    /** pathopen.e:260			arg = ""*/
    RefDS(_22186);
    DeRefi(_arg_50872);
    _arg_50872 = _22186;

    /** pathopen.e:261			parm = ""*/
    RefDS(_22186);
    DeRefi(_parm_50873);
    _parm_50873 = _22186;

    /** pathopen.e:269			if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_50867)){
            _26143 = SEQ_PTR(_in_50867)->length;
    }
    else {
        _26143 = 1;
    }
    if (_26143 <= 0LL)
    goto LD; // [253] 477

    /** pathopen.e:270				if in[1] = '[' then*/
    _2 = (object)SEQ_PTR(_in_50867);
    _26145 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_26145 != 91LL)
    goto LE; // [263] 354

    /** pathopen.e:272					section = in[2..$]*/
    if (IS_SEQUENCE(_in_50867)){
            _26147 = SEQ_PTR(_in_50867)->length;
    }
    else {
        _26147 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_50874;
    RHS_Slice(_in_50867, 2LL, _26147);

    /** pathopen.e:273					if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_50874)){
            _26149 = SEQ_PTR(_section_50874)->length;
    }
    else {
        _26149 = 1;
    }
    _26150 = (_26149 > 0LL);
    _26149 = NOVALUE;
    if (_26150 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_50874)){
            _26152 = SEQ_PTR(_section_50874)->length;
    }
    else {
        _26152 = 1;
    }
    _2 = (object)SEQ_PTR(_section_50874);
    _26153 = (object)*(((s1_ptr)_2)->base + _26152);
    _26154 = (_26153 == 93LL);
    _26153 = NOVALUE;
    if (_26154 == 0)
    {
        DeRef(_26154);
        _26154 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_26154);
        _26154 = NOVALUE;
    }

    /** pathopen.e:274						section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_50874)){
            _26155 = SEQ_PTR(_section_50874)->length;
    }
    else {
        _26155 = 1;
    }
    _26156 = _26155 - 1LL;
    _26155 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_50874;
    RHS_Slice(_section_50874, 1LL, _26156);
LF: 

    /** pathopen.e:276					section = lower(trim(section))*/
    RefDS(_section_50874);
    RefDS(_3922);
    _26158 = _14trim(_section_50874, _3922, 0LL);
    _0 = _section_50874;
    _section_50874 = _14lower(_26158);
    DeRefDS(_0);
    _26158 = NOVALUE;

    /** pathopen.e:277					if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_50874)){
            _26160 = SEQ_PTR(_section_50874)->length;
    }
    else {
        _26160 = 1;
    }
    if (_26160 != 0LL)
    goto L10; // [339] 476

    /** pathopen.e:278						section = "all"*/
    RefDS(_26123);
    DeRefDS(_section_50874);
    _section_50874 = _26123;
    goto L10; // [351] 476
LE: 

    /** pathopen.e:281				elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_50867)){
            _26162 = SEQ_PTR(_in_50867)->length;
    }
    else {
        _26162 = 1;
    }
    if (_26162 <= 2LL)
    goto L11; // [359] 461

    /** pathopen.e:282					if in[1] = '-' then*/
    _2 = (object)SEQ_PTR(_in_50867);
    _26164 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_26164 != 45LL)
    goto L12; // [369] 443

    /** pathopen.e:283						if in[2] != '-' then*/
    _2 = (object)SEQ_PTR(_in_50867);
    _26166 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (_26166 == 45LL)
    goto L10; // [379] 476

    /** pathopen.e:284							spos = find(' ', in)*/
    _spos_50868 = find_from(32LL, _in_50867, 1LL);

    /** pathopen.e:285							if spos = 0 then*/
    if (_spos_50868 != 0LL)
    goto L13; // [392] 413

    /** pathopen.e:286								arg = in*/
    Ref(_in_50867);
    DeRefi(_arg_50872);
    _arg_50872 = _in_50867;

    /** pathopen.e:287								parm = ""*/
    RefDS(_22186);
    DeRefi(_parm_50873);
    _parm_50873 = _22186;
    goto L10; // [410] 476
L13: 

    /** pathopen.e:289								arg = in[1..spos - 1]*/
    _26170 = _spos_50868 - 1LL;
    rhs_slice_target = (object_ptr)&_arg_50872;
    RHS_Slice(_in_50867, 1LL, _26170);

    /** pathopen.e:290								parm = in[spos + 1 .. $]*/
    _26172 = _spos_50868 + 1;
    if (_26172 > MAXINT){
        _26172 = NewDouble((eudouble)_26172);
    }
    if (IS_SEQUENCE(_in_50867)){
            _26173 = SEQ_PTR(_in_50867)->length;
    }
    else {
        _26173 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_50873;
    RHS_Slice(_in_50867, _26172, _26173);
    goto L10; // [440] 476
L12: 

    /** pathopen.e:294						arg = "-i"*/
    RefDS(_26175);
    DeRefi(_arg_50872);
    _arg_50872 = _26175;

    /** pathopen.e:295						parm = in*/
    Ref(_in_50867);
    DeRefi(_parm_50873);
    _parm_50873 = _in_50867;
    goto L10; // [458] 476
L11: 

    /** pathopen.e:298					arg = "-i"*/
    RefDS(_26175);
    DeRefi(_arg_50872);
    _arg_50872 = _26175;

    /** pathopen.e:299					parm = in*/
    Ref(_in_50867);
    DeRefi(_parm_50873);
    _parm_50873 = _in_50867;
L10: 
LD: 

    /** pathopen.e:303			if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_50872)){
            _26176 = SEQ_PTR(_arg_50872)->length;
    }
    else {
        _26176 = 1;
    }
    if (_26176 <= 0LL)
    goto L14; // [482] 756

    /** pathopen.e:304				integer needed = 0*/
    _needed_50971 = 0LL;

    /** pathopen.e:305				switch section do*/
    _1 = find(_section_50874, _26178);
    switch ( _1 ){ 

        /** pathopen.e:306					case "all" then*/
        case 1:

        /** pathopen.e:307						needed = 1*/
        _needed_50971 = 1LL;
        goto L15; // [507] 691

        /** pathopen.e:309					case "windows" then*/
        case 2:

        /** pathopen.e:310						needed = TWINDOWS*/
        _needed_50971 = _46TWINDOWS_21906;
        goto L15; // [522] 691

        /** pathopen.e:312					case "unix" then*/
        case 3:

        /** pathopen.e:313						needed = TUNIX*/
        _needed_50971 = _46TUNIX_21910;
        goto L15; // [537] 691

        /** pathopen.e:315					case "translate" then*/
        case 4:

        /** pathopen.e:316						needed = TRANSLATE*/
        _needed_50971 = _36TRANSLATE_21361;
        goto L15; // [552] 691

        /** pathopen.e:318					case "translate:windows" then*/
        case 5:

        /** pathopen.e:319						needed = TRANSLATE and TWINDOWS*/
        _needed_50971 = (_36TRANSLATE_21361 != 0 && _46TWINDOWS_21906 != 0);
        goto L15; // [570] 691

        /** pathopen.e:321					case "translate:unix" then*/
        case 6:

        /** pathopen.e:322						needed = TRANSLATE and TUNIX*/
        _needed_50971 = (_36TRANSLATE_21361 != 0 && _46TUNIX_21910 != 0);
        goto L15; // [588] 691

        /** pathopen.e:324					case "interpret" then*/
        case 7:

        /** pathopen.e:325						needed = INTERPRET*/
        _needed_50971 = _36INTERPRET_21358;
        goto L15; // [603] 691

        /** pathopen.e:327					case "interpret:windows" then*/
        case 8:

        /** pathopen.e:328						needed = INTERPRET and TWINDOWS*/
        _needed_50971 = (_36INTERPRET_21358 != 0 && _46TWINDOWS_21906 != 0);
        goto L15; // [621] 691

        /** pathopen.e:330					case "interpret:unix" then*/
        case 9:

        /** pathopen.e:331						needed = INTERPRET and TUNIX*/
        _needed_50971 = (_36INTERPRET_21358 != 0 && _46TUNIX_21910 != 0);
        goto L15; // [639] 691

        /** pathopen.e:333					case "bind" then*/
        case 10:

        /** pathopen.e:334						needed = BIND*/
        _needed_50971 = _36BIND_21364;
        goto L15; // [654] 691

        /** pathopen.e:336					case "bind:windows" then*/
        case 11:

        /** pathopen.e:337						needed = BIND and TWINDOWS*/
        _needed_50971 = (_36BIND_21364 != 0 && _46TWINDOWS_21906 != 0);
        goto L15; // [672] 691

        /** pathopen.e:339					case "bind:unix" then*/
        case 12:

        /** pathopen.e:340						needed = BIND and TUNIX*/
        _needed_50971 = (_36BIND_21364 != 0 && _46TUNIX_21910 != 0);
    ;}L15: 

    /** pathopen.e:344				if needed then*/
    if (_needed_50971 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** pathopen.e:345					if equal(arg, "-c") then*/
    if (_arg_50872 == _26197)
    _26198 = 1;
    else if (IS_ATOM_INT(_arg_50872) && IS_ATOM_INT(_26197))
    _26198 = 0;
    else
    _26198 = (compare(_arg_50872, _26197) == 0);
    if (_26198 == 0)
    {
        _26198 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _26198 = NOVALUE;
    }

    /** pathopen.e:346						if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_50873)){
            _26199 = SEQ_PTR(_parm_50873)->length;
    }
    else {
        _26199 = 1;
    }
    if (_26199 <= 0LL)
    goto L18; // [710] 754

    /** pathopen.e:347							new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_50873);
    _26201 = _48load_euphoria_config(_parm_50873);
    if (IS_SEQUENCE(_new_args_50871) && IS_ATOM(_26201)) {
        Ref(_26201);
        Append(&_new_args_50871, _new_args_50871, _26201);
    }
    else if (IS_ATOM(_new_args_50871) && IS_SEQUENCE(_26201)) {
    }
    else {
        Concat((object_ptr)&_new_args_50871, _new_args_50871, _26201);
    }
    DeRef(_26201);
    _26201 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** pathopen.e:350						new_args = append(new_args, arg)*/
    RefDS(_arg_50872);
    Append(&_new_args_50871, _new_args_50871, _arg_50872);

    /** pathopen.e:351						if length(parm > 0) then*/
    _26204 = binary_op(GREATER, _parm_50873, 0LL);
    if (IS_SEQUENCE(_26204)){
            _26205 = SEQ_PTR(_26204)->length;
    }
    else {
        _26205 = 1;
    }
    DeRefDS(_26204);
    _26204 = NOVALUE;
    if (_26205 == 0)
    {
        _26205 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _26205 = NOVALUE;
    }

    /** pathopen.e:352							new_args = append(new_args, parm)*/
    RefDS(_parm_50873);
    Append(&_new_args_50871, _new_args_50871, _parm_50873);
L19: 
L18: 
L16: 
L14: 

    /** pathopen.e:358			in = gets( fn )*/
    DeRefi(_in_50867);
    _in_50867 = EGets(_fn_50866);

    /** pathopen.e:359		end while*/
    goto L5; // [765] 128
L6: 

    /** pathopen.e:360		close(fn)*/
    EClose(_fn_50866);

    /** pathopen.e:362		return new_args*/
    DeRefDS(_file_50865);
    DeRefi(_in_50867);
    DeRef(_conf_path_50870);
    DeRefi(_arg_50872);
    DeRefi(_parm_50873);
    DeRef(_section_50874);
    _26204 = NOVALUE;
    _26166 = NOVALUE;
    DeRef(_26150);
    _26150 = NOVALUE;
    DeRef(_26156);
    _26156 = NOVALUE;
    DeRef(_26172);
    _26172 = NOVALUE;
    _26145 = NOVALUE;
    _26164 = NOVALUE;
    DeRef(_26170);
    _26170 = NOVALUE;
    return _new_args_50871;
    ;
}


object _48GetDefaultArgs(object _user_files_51038)
{
    object _env_51039 = NOVALUE;
    object _default_args_51040 = NOVALUE;
    object _conf_file_51041 = NOVALUE;
    object _cmd_options_51043 = NOVALUE;
    object _user_config_51049 = NOVALUE;
    object _26250 = NOVALUE;
    object _26249 = NOVALUE;
    object _26248 = NOVALUE;
    object _26245 = NOVALUE;
    object _26244 = NOVALUE;
    object _26243 = NOVALUE;
    object _26241 = NOVALUE;
    object _26237 = NOVALUE;
    object _26236 = NOVALUE;
    object _26235 = NOVALUE;
    object _26234 = NOVALUE;
    object _26230 = NOVALUE;
    object _26229 = NOVALUE;
    object _26228 = NOVALUE;
    object _26226 = NOVALUE;
    object _26220 = NOVALUE;
    object _26219 = NOVALUE;
    object _26217 = NOVALUE;
    object _26215 = NOVALUE;
    object _26214 = NOVALUE;
    object _26210 = NOVALUE;
    object _26209 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:367		sequence default_args = {}*/
    RefDS(_22186);
    DeRef(_default_args_51040);
    _default_args_51040 = _22186;

    /** pathopen.e:368		sequence conf_file = "eu.cfg"*/
    RefDS(_26117);
    DeRefi(_conf_file_51041);
    _conf_file_51041 = _26117;

    /** pathopen.e:370		if loaded_config_inc_paths then return "" end if*/
    if (_48loaded_config_inc_paths_50724 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_22186);
    DeRefDS(_user_files_51038);
    DeRef(_env_51039);
    DeRefDS(_default_args_51040);
    DeRefDSi(_conf_file_51041);
    DeRef(_cmd_options_51043);
    return _22186;
L1: 

    /** pathopen.e:371		loaded_config_inc_paths = 1*/
    _48loaded_config_inc_paths_50724 = 1LL;

    /** pathopen.e:380		sequence cmd_options = get_options()*/
    _0 = _cmd_options_51043;
    _cmd_options_51043 = _49get_options();
    DeRef(_0);

    /** pathopen.e:382		default_args = {}*/
    RefDS(_22186);
    DeRef(_default_args_51040);
    _default_args_51040 = _22186;

    /** pathopen.e:385		for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_51038)){
            _26209 = SEQ_PTR(_user_files_51038)->length;
    }
    else {
        _26209 = 1;
    }
    {
        object _i_51047;
        _i_51047 = 1LL;
L2: 
        if (_i_51047 > _26209){
            goto L3; // [53] 92
        }

        /** pathopen.e:386			sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (object)SEQ_PTR(_user_files_51038);
        _26210 = (object)*(((s1_ptr)_2)->base + _i_51047);
        Ref(_26210);
        _0 = _user_config_51049;
        _user_config_51049 = _48load_euphoria_config(_26210);
        DeRef(_0);
        _26210 = NOVALUE;

        /** pathopen.e:387			default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_51049);
        RefDS(_default_args_51040);
        RefDS(_cmd_options_51043);
        _0 = _default_args_51040;
        _default_args_51040 = _49merge_parameters(_user_config_51049, _default_args_51040, _cmd_options_51043, 1LL);
        DeRefDS(_0);
        DeRefDS(_user_config_51049);
        _user_config_51049 = NOVALUE;

        /** pathopen.e:388		end for*/
        _i_51047 = _i_51047 + 1LL;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** pathopen.e:391		default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_26214, _26213, _conf_file_51041);
    _26215 = _48load_euphoria_config(_26214);
    _26214 = NOVALUE;
    RefDS(_default_args_51040);
    RefDS(_cmd_options_51043);
    _0 = _default_args_51040;
    _default_args_51040 = _49merge_parameters(_26215, _default_args_51040, _cmd_options_51043, 1LL);
    DeRefDS(_0);
    _26215 = NOVALUE;

    /** pathopen.e:394		env = strip_file_from_path( exe_path() )*/
    _26217 = _48exe_path();
    _0 = _env_51039;
    _env_51039 = _48strip_file_from_path(_26217);
    DeRef(_0);
    _26217 = NOVALUE;

    /** pathopen.e:395		default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_51039) && IS_ATOM(_conf_file_51041)) {
    }
    else if (IS_ATOM(_env_51039) && IS_SEQUENCE(_conf_file_51041)) {
        Ref(_env_51039);
        Prepend(&_26219, _conf_file_51041, _env_51039);
    }
    else {
        Concat((object_ptr)&_26219, _env_51039, _conf_file_51041);
    }
    _26220 = _48load_euphoria_config(_26219);
    _26219 = NOVALUE;
    RefDS(_default_args_51040);
    RefDS(_cmd_options_51043);
    _0 = _default_args_51040;
    _default_args_51040 = _49merge_parameters(_26220, _default_args_51040, _cmd_options_51043, 1LL);
    DeRefDS(_0);
    _26220 = NOVALUE;

    /** pathopen.e:398		ifdef UNIX then*/

    /** pathopen.e:407			env = getenv( "ALLUSERSPROFILE" )*/
    DeRef(_env_51039);
    _env_51039 = EGetEnv(_26224);

    /** pathopen.e:408			if sequence(env) then*/
    _26226 = IS_SEQUENCE(_env_51039);
    if (_26226 == 0)
    {
        _26226 = NOVALUE;
        goto L4; // [151] 179
    }
    else{
        _26226 = NOVALUE;
    }

    /** pathopen.e:409				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26227);
    Ref(_env_51039);
    _26228 = _48expand_path(_26227, _env_51039);
    if (IS_SEQUENCE(_26228) && IS_ATOM(_conf_file_51041)) {
    }
    else if (IS_ATOM(_26228) && IS_SEQUENCE(_conf_file_51041)) {
        Ref(_26228);
        Prepend(&_26229, _conf_file_51041, _26228);
    }
    else {
        Concat((object_ptr)&_26229, _26228, _conf_file_51041);
        DeRef(_26228);
        _26228 = NOVALUE;
    }
    DeRef(_26228);
    _26228 = NOVALUE;
    _26230 = _48load_euphoria_config(_26229);
    _26229 = NOVALUE;
    RefDS(_default_args_51040);
    RefDS(_cmd_options_51043);
    _0 = _default_args_51040;
    _default_args_51040 = _49merge_parameters(_26230, _default_args_51040, _cmd_options_51043, 1LL);
    DeRefDS(_0);
    _26230 = NOVALUE;
L4: 

    /** pathopen.e:412			env = getenv( "APPDATA" )*/
    DeRef(_env_51039);
    _env_51039 = EGetEnv(_26232);

    /** pathopen.e:413			if sequence(env) then*/
    _26234 = IS_SEQUENCE(_env_51039);
    if (_26234 == 0)
    {
        _26234 = NOVALUE;
        goto L5; // [189] 217
    }
    else{
        _26234 = NOVALUE;
    }

    /** pathopen.e:414				default_args = merge_parameters( load_euphoria_config( expand_path( "euphoria", env ) & conf_file ), default_args, cmd_options, 1 )*/
    RefDS(_26227);
    Ref(_env_51039);
    _26235 = _48expand_path(_26227, _env_51039);
    if (IS_SEQUENCE(_26235) && IS_ATOM(_conf_file_51041)) {
    }
    else if (IS_ATOM(_26235) && IS_SEQUENCE(_conf_file_51041)) {
        Ref(_26235);
        Prepend(&_26236, _conf_file_51041, _26235);
    }
    else {
        Concat((object_ptr)&_26236, _26235, _conf_file_51041);
        DeRef(_26235);
        _26235 = NOVALUE;
    }
    DeRef(_26235);
    _26235 = NOVALUE;
    _26237 = _48load_euphoria_config(_26236);
    _26236 = NOVALUE;
    RefDS(_default_args_51040);
    RefDS(_cmd_options_51043);
    _0 = _default_args_51040;
    _default_args_51040 = _49merge_parameters(_26237, _default_args_51040, _cmd_options_51043, 1LL);
    DeRefDS(_0);
    _26237 = NOVALUE;
L5: 

    /** pathopen.e:417			env = getenv( "HOMEPATH" )*/
    DeRef(_env_51039);
    _env_51039 = EGetEnv(_26239);

    /** pathopen.e:418			if sequence(env) then*/
    _26241 = IS_SEQUENCE(_env_51039);
    if (_26241 == 0)
    {
        _26241 = NOVALUE;
        goto L6; // [227] 256
    }
    else{
        _26241 = NOVALUE;
    }

    /** pathopen.e:419				default_args = merge_parameters( load_euphoria_config( getenv( "HOMEDRIVE" ) & env & "\\" & conf_file ), default_args, cmd_options, 1 )*/
    _26243 = EGetEnv(_26242);
    {
        object concat_list[4];

        concat_list[0] = _conf_file_51041;
        concat_list[1] = _23885;
        concat_list[2] = _env_51039;
        concat_list[3] = _26243;
        Concat_N((object_ptr)&_26244, concat_list, 4);
    }
    DeRef(_26243);
    _26243 = NOVALUE;
    _26245 = _48load_euphoria_config(_26244);
    _26244 = NOVALUE;
    RefDS(_default_args_51040);
    RefDS(_cmd_options_51043);
    _0 = _default_args_51040;
    _default_args_51040 = _49merge_parameters(_26245, _default_args_51040, _cmd_options_51043, 1LL);
    DeRefDS(_0);
    _26245 = NOVALUE;
L6: 

    /** pathopen.e:427		env = get_eudir()*/
    _0 = _env_51039;
    _env_51039 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:428		if sequence(env) then*/
    _26248 = IS_SEQUENCE(_env_51039);
    if (_26248 == 0)
    {
        _26248 = NOVALUE;
        goto L7; // [266] 291
    }
    else{
        _26248 = NOVALUE;
    }

    /** pathopen.e:429			default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        object concat_list[3];

        concat_list[0] = _conf_file_51041;
        concat_list[1] = _23762;
        concat_list[2] = _env_51039;
        Concat_N((object_ptr)&_26249, concat_list, 3);
    }
    _26250 = _48load_euphoria_config(_26249);
    _26249 = NOVALUE;
    RefDS(_default_args_51040);
    RefDS(_cmd_options_51043);
    _0 = _default_args_51040;
    _default_args_51040 = _49merge_parameters(_26250, _default_args_51040, _cmd_options_51043, 1LL);
    DeRefDS(_0);
    _26250 = NOVALUE;
L7: 

    /** pathopen.e:432		return default_args*/
    DeRefDS(_user_files_51038);
    DeRef(_env_51039);
    DeRefi(_conf_file_51041);
    DeRef(_cmd_options_51043);
    return _default_args_51040;
    ;
}


object _48ConfPath(object _file_name_51106)
{
    object _file_path_51107 = NOVALUE;
    object _try_51108 = NOVALUE;
    object _26257 = NOVALUE;
    object _26253 = NOVALUE;
    object _26252 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:440		for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_48config_inc_paths_50723)){
            _26252 = SEQ_PTR(_48config_inc_paths_50723)->length;
    }
    else {
        _26252 = 1;
    }
    {
        object _i_51110;
        _i_51110 = 1LL;
L1: 
        if (_i_51110 > _26252){
            goto L2; // [10] 60
        }

        /** pathopen.e:441			file_path = config_inc_paths[i] & file_name*/
        _2 = (object)SEQ_PTR(_48config_inc_paths_50723);
        _26253 = (object)*(((s1_ptr)_2)->base + _i_51110);
        Concat((object_ptr)&_file_path_51107, _26253, _file_name_51106);
        _26253 = NOVALUE;
        _26253 = NOVALUE;

        /** pathopen.e:442			try = open( file_path, "r" )*/
        _try_51108 = EOpen(_file_path_51107, _26124, 0LL);

        /** pathopen.e:443			if try != -1 then*/
        if (_try_51108 == -1LL)
        goto L3; // [38] 53

        /** pathopen.e:444				return {file_path, try}*/
        RefDS(_file_path_51107);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51107;
        ((intptr_t *)_2)[2] = _try_51108;
        _26257 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51106);
        DeRefDS(_file_path_51107);
        return _26257;
L3: 

        /** pathopen.e:446		end for*/
        _i_51110 = _i_51110 + 1LL;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** pathopen.e:447		return -1*/
    DeRefDS(_file_name_51106);
    DeRef(_file_path_51107);
    DeRef(_26257);
    _26257 = NOVALUE;
    return -1LL;
    ;
}


object _48ScanPath(object _file_name_51120, object _env_51121, object _flag_51122)
{
    object _inc_path_51123 = NOVALUE;
    object _full_path_51124 = NOVALUE;
    object _file_path_51125 = NOVALUE;
    object _strings_51126 = NOVALUE;
    object _end_path_51127 = NOVALUE;
    object _start_path_51128 = NOVALUE;
    object _try_51129 = NOVALUE;
    object _use_cache_51130 = NOVALUE;
    object _pos_51131 = NOVALUE;
    object _26335 = NOVALUE;
    object _26334 = NOVALUE;
    object _26333 = NOVALUE;
    object _26332 = NOVALUE;
    object _26331 = NOVALUE;
    object _26330 = NOVALUE;
    object _26329 = NOVALUE;
    object _26328 = NOVALUE;
    object _26327 = NOVALUE;
    object _26326 = NOVALUE;
    object _26325 = NOVALUE;
    object _26324 = NOVALUE;
    object _26323 = NOVALUE;
    object _26322 = NOVALUE;
    object _26321 = NOVALUE;
    object _26320 = NOVALUE;
    object _26315 = NOVALUE;
    object _26314 = NOVALUE;
    object _26313 = NOVALUE;
    object _26312 = NOVALUE;
    object _26311 = NOVALUE;
    object _26307 = NOVALUE;
    object _26306 = NOVALUE;
    object _26305 = NOVALUE;
    object _26304 = NOVALUE;
    object _26303 = NOVALUE;
    object _26302 = NOVALUE;
    object _26300 = NOVALUE;
    object _26298 = NOVALUE;
    object _26297 = NOVALUE;
    object _26295 = NOVALUE;
    object _26294 = NOVALUE;
    object _26293 = NOVALUE;
    object _26290 = NOVALUE;
    object _26289 = NOVALUE;
    object _26287 = NOVALUE;
    object _26286 = NOVALUE;
    object _26285 = NOVALUE;
    object _26283 = NOVALUE;
    object _26281 = NOVALUE;
    object _26276 = NOVALUE;
    object _26275 = NOVALUE;
    object _26274 = NOVALUE;
    object _26273 = NOVALUE;
    object _26272 = NOVALUE;
    object _26267 = NOVALUE;
    object _26259 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** pathopen.e:459		inc_path = getenv(env)*/
    DeRefi(_inc_path_51123);
    _inc_path_51123 = EGetEnv(_env_51121);

    /** pathopen.e:460		if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_51123) && IS_ATOM_INT(_22186)){
        _26259 = (_inc_path_51123 < _22186) ? -1 : (_inc_path_51123 > _22186);
    }
    else{
        _26259 = compare(_inc_path_51123, _22186);
    }
    if (_26259 == 1LL)
    goto L1; // [18] 29

    /** pathopen.e:461			return -1*/
    DeRefDS(_file_name_51120);
    DeRefDSi(_env_51121);
    DeRefi(_inc_path_51123);
    DeRef(_full_path_51124);
    DeRef(_file_path_51125);
    DeRef(_strings_51126);
    return -1LL;
L1: 

    /** pathopen.e:464		num_var = find(env,cache_vars)*/
    _48num_var_50714 = find_from(_env_51121, _48cache_vars_50715, 1LL);

    /** pathopen.e:465		use_cache = check_cache(env,inc_path)*/
    RefDS(_env_51121);
    Ref(_inc_path_51123);
    _use_cache_51130 = _48check_cache(_env_51121, _inc_path_51123);
    if (!IS_ATOM_INT(_use_cache_51130)) {
        _1 = (object)(DBL_PTR(_use_cache_51130)->dbl);
        DeRefDS(_use_cache_51130);
        _use_cache_51130 = _1;
    }

    /** pathopen.e:466		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51123, _inc_path_51123, 59LL);

    /** pathopen.e:468		file_name = SLASH & file_name*/
    Prepend(&_file_name_51120, _file_name_51120, 92LL);

    /** pathopen.e:469		if flag then*/
    if (_flag_51122 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** pathopen.e:470			file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_51120, _48include_subfolder_50710, _file_name_51120);
L2: 

    /** pathopen.e:472		strings = cache_substrings[num_var]*/
    DeRef(_strings_51126);
    _2 = (object)SEQ_PTR(_48cache_substrings_50717);
    _strings_51126 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    RefDS(_strings_51126);

    /** pathopen.e:474		if use_cache then*/
    if (_use_cache_51130 == 0)
    {
        goto L3; // [91] 292
    }
    else{
    }

    /** pathopen.e:475			for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_51126)){
            _26267 = SEQ_PTR(_strings_51126)->length;
    }
    else {
        _26267 = 1;
    }
    {
        object _i_51147;
        _i_51147 = 1LL;
L4: 
        if (_i_51147 > _26267){
            goto L5; // [99] 252
        }

        /** pathopen.e:476				full_path = strings[i]*/
        DeRef(_full_path_51124);
        _2 = (object)SEQ_PTR(_strings_51126);
        _full_path_51124 = (object)*(((s1_ptr)_2)->base + _i_51147);
        Ref(_full_path_51124);

        /** pathopen.e:477				file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51125, _full_path_51124, _file_name_51120);

        /** pathopen.e:478				try = open_locked(file_path)    */
        RefDS(_file_path_51125);
        _try_51129 = _37open_locked(_file_path_51125);
        if (!IS_ATOM_INT(_try_51129)) {
            _1 = (object)(DBL_PTR(_try_51129)->dbl);
            DeRefDS(_try_51129);
            _try_51129 = _1;
        }

        /** pathopen.e:479				if try != -1 then*/
        if (_try_51129 == -1LL)
        goto L6; // [130] 145

        /** pathopen.e:480					return {file_path,try}*/
        RefDS(_file_path_51125);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51125;
        ((intptr_t *)_2)[2] = _try_51129;
        _26272 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51120);
        DeRefDSi(_env_51121);
        DeRefi(_inc_path_51123);
        DeRefDS(_full_path_51124);
        DeRefDS(_file_path_51125);
        DeRefDS(_strings_51126);
        return _26272;
L6: 

        /** pathopen.e:482				ifdef WINDOWS then */

        /** pathopen.e:483					if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26273 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26273);
        _26274 = (object)*(((s1_ptr)_2)->base + _i_51147);
        _26273 = NOVALUE;
        _26275 = IS_SEQUENCE(_26274);
        _26274 = NOVALUE;
        if (_26275 == 0)
        {
            _26275 = NOVALUE;
            goto L7; // [164] 245
        }
        else{
            _26275 = NOVALUE;
        }

        /** pathopen.e:486						full_path = cache_converted[num_var][i]*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26276 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        DeRef(_full_path_51124);
        _2 = (object)SEQ_PTR(_26276);
        _full_path_51124 = (object)*(((s1_ptr)_2)->base + _i_51147);
        Ref(_full_path_51124);
        _26276 = NOVALUE;

        /** pathopen.e:487						file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51125, _full_path_51124, _file_name_51120);

        /** pathopen.e:488						try = open_locked(file_path)*/
        RefDS(_file_path_51125);
        _try_51129 = _37open_locked(_file_path_51125);
        if (!IS_ATOM_INT(_try_51129)) {
            _1 = (object)(DBL_PTR(_try_51129)->dbl);
            DeRefDS(_try_51129);
            _try_51129 = _1;
        }

        /** pathopen.e:489						if try != -1 then*/
        if (_try_51129 == -1LL)
        goto L8; // [199] 244

        /** pathopen.e:490							cache_converted[num_var][i] = 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _3 = (object)(_48num_var_50714 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51147);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _26281 = NOVALUE;

        /** pathopen.e:491							cache_substrings[num_var][i] = full_path*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50717 = MAKE_SEQ(_2);
        }
        _3 = (object)(_48num_var_50714 + ((s1_ptr)_2)->base);
        RefDS(_full_path_51124);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_51147);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _full_path_51124;
        DeRef(_1);
        _26283 = NOVALUE;

        /** pathopen.e:492							return {file_path,try}*/
        RefDS(_file_path_51125);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51125;
        ((intptr_t *)_2)[2] = _try_51129;
        _26285 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51120);
        DeRefDSi(_env_51121);
        DeRefi(_inc_path_51123);
        DeRefDS(_full_path_51124);
        DeRefDS(_file_path_51125);
        DeRef(_strings_51126);
        DeRef(_26272);
        _26272 = NOVALUE;
        return _26285;
L8: 
L7: 

        /** pathopen.e:496			end for*/
        _i_51147 = _i_51147 + 1LL;
        goto L4; // [247] 106
L5: 
        ;
    }

    /** pathopen.e:497			if cache_complete[num_var] then -- nothing to scan*/
    _2 = (object)SEQ_PTR(_48cache_complete_50721);
    _26286 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    if (_26286 == 0)
    {
        _26286 = NOVALUE;
        goto L9; // [262] 274
    }
    else{
        _26286 = NOVALUE;
    }

    /** pathopen.e:498				return -1*/
    DeRefDS(_file_name_51120);
    DeRefDSi(_env_51121);
    DeRefi(_inc_path_51123);
    DeRef(_full_path_51124);
    DeRef(_file_path_51125);
    DeRef(_strings_51126);
    DeRef(_26272);
    _26272 = NOVALUE;
    DeRef(_26285);
    _26285 = NOVALUE;
    return -1LL;
    goto LA; // [271] 298
L9: 

    /** pathopen.e:500				pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (object)SEQ_PTR(_48cache_delims_50722);
    _26287 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    _pos_51131 = _26287 + 1;
    _26287 = NOVALUE;
    goto LA; // [289] 298
L3: 

    /** pathopen.e:503			pos = 1*/
    _pos_51131 = 1LL;
LA: 

    /** pathopen.e:506		start_path = 0*/
    _start_path_51128 = 0LL;

    /** pathopen.e:507		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51123)){
            _26289 = SEQ_PTR(_inc_path_51123)->length;
    }
    else {
        _26289 = 1;
    }
    {
        object _p_51179;
        _p_51179 = _pos_51131;
LB: 
        if (_p_51179 > _26289){
            goto LC; // [310] 716
        }

        /** pathopen.e:508			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51123);
        _26290 = (object)*(((s1_ptr)_2)->base + _p_51179);
        if (_26290 != 59LL)
        goto LD; // [325] 665

        /** pathopen.e:510				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50722);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50722 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        *(intptr_t *)_2 = _p_51179;

        /** pathopen.e:512				end_path = p-1*/
        _end_path_51127 = _p_51179 - 1LL;

        /** pathopen.e:513				while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LE: 
        _26293 = (_end_path_51127 >= _start_path_51128);
        if (_26293 == 0) {
            goto LF; // [354] 388
        }
        _2 = (object)SEQ_PTR(_inc_path_51123);
        _26295 = (object)*(((s1_ptr)_2)->base + _end_path_51127);
        Concat((object_ptr)&_26297, _26296, _46SLASH_CHARS_21927);
        _26298 = find_from(_26295, _26297, 1LL);
        _26295 = NOVALUE;
        DeRefDS(_26297);
        _26297 = NOVALUE;
        if (_26298 == 0)
        {
            _26298 = NOVALUE;
            goto LF; // [374] 388
        }
        else{
            _26298 = NOVALUE;
        }

        /** pathopen.e:514					end_path-=1*/
        _end_path_51127 = _end_path_51127 - 1LL;

        /** pathopen.e:515				end while*/
        goto LE; // [385] 350
LF: 

        /** pathopen.e:517				if start_path and end_path then*/
        if (_start_path_51128 == 0) {
            goto L10; // [390] 709
        }
        if (_end_path_51127 == 0)
        {
            goto L10; // [395] 709
        }
        else{
        }

        /** pathopen.e:518					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51124;
        RHS_Slice(_inc_path_51123, _start_path_51128, _end_path_51127);

        /** pathopen.e:519					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        _26302 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        RefDS(_full_path_51124);
        Append(&_26303, _26302, _full_path_51124);
        _26302 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50717 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26303;
        if( _1 != _26303 ){
            DeRefDS(_1);
        }
        _26303 = NOVALUE;

        /** pathopen.e:520					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        _26304 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26304) && IS_ATOM(_start_path_51128)) {
            Append(&_26305, _26304, _start_path_51128);
        }
        else if (IS_ATOM(_26304) && IS_SEQUENCE(_start_path_51128)) {
        }
        else {
            Concat((object_ptr)&_26305, _26304, _start_path_51128);
            _26304 = NOVALUE;
        }
        _26304 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50718 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26305;
        if( _1 != _26305 ){
            DeRef(_1);
        }
        _26305 = NOVALUE;

        /** pathopen.e:521					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        _26306 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26306) && IS_ATOM(_end_path_51127)) {
            Append(&_26307, _26306, _end_path_51127);
        }
        else if (IS_ATOM(_26306) && IS_SEQUENCE(_end_path_51127)) {
        }
        else {
            Concat((object_ptr)&_26307, _26306, _end_path_51127);
            _26306 = NOVALUE;
        }
        _26306 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50719 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26307;
        if( _1 != _26307 ){
            DeRef(_1);
        }
        _26307 = NOVALUE;

        /** pathopen.e:522					file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_51125, _full_path_51124, _file_name_51120);

        /** pathopen.e:523					try = open_locked(file_path)*/
        RefDS(_file_path_51125);
        _try_51129 = _37open_locked(_file_path_51125);
        if (!IS_ATOM_INT(_try_51129)) {
            _1 = (object)(DBL_PTR(_try_51129)->dbl);
            DeRefDS(_try_51129);
            _try_51129 = _1;
        }

        /** pathopen.e:524					if try != -1 then -- valid path, no point trying to convert*/
        if (_try_51129 == -1LL)
        goto L11; // [479] 514

        /** pathopen.e:525						ifdef WINDOWS then*/

        /** pathopen.e:526							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26311 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26311) && IS_ATOM(0LL)) {
            Append(&_26312, _26311, 0LL);
        }
        else if (IS_ATOM(_26311) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26312, _26311, 0LL);
            _26311 = NOVALUE;
        }
        _26311 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26312;
        if( _1 != _26312 ){
            DeRef(_1);
        }
        _26312 = NOVALUE;

        /** pathopen.e:528						return {file_path,try}*/
        RefDS(_file_path_51125);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51125;
        ((intptr_t *)_2)[2] = _try_51129;
        _26313 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51120);
        DeRefDSi(_env_51121);
        DeRefi(_inc_path_51123);
        DeRefDSi(_full_path_51124);
        DeRefDS(_file_path_51125);
        DeRef(_strings_51126);
        DeRef(_26272);
        _26272 = NOVALUE;
        DeRef(_26293);
        _26293 = NOVALUE;
        DeRef(_26285);
        _26285 = NOVALUE;
        _26290 = NOVALUE;
        return _26313;
L11: 

        /** pathopen.e:530					ifdef WINDOWS then*/

        /** pathopen.e:531						if find(1, full_path>=128) then*/
        _26314 = binary_op(GREATEREQ, _full_path_51124, 128LL);
        _26315 = find_from(1LL, _26314, 1LL);
        DeRefDS(_26314);
        _26314 = NOVALUE;
        if (_26315 == 0)
        {
            _26315 = NOVALUE;
            goto L12; // [527] 637
        }
        else{
            _26315 = NOVALUE;
        }

        /** pathopen.e:533							full_path = convert_from_OEM(full_path)*/
        RefDS(_full_path_51124);
        _0 = _full_path_51124;
        _full_path_51124 = _48convert_from_OEM(_full_path_51124);
        DeRefDS(_0);

        /** pathopen.e:534							file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_51125, _full_path_51124, _file_name_51120);

        /** pathopen.e:535							try = open_locked(file_path)*/
        RefDS(_file_path_51125);
        _try_51129 = _37open_locked(_file_path_51125);
        if (!IS_ATOM_INT(_try_51129)) {
            _1 = (object)(DBL_PTR(_try_51129)->dbl);
            DeRefDS(_try_51129);
            _try_51129 = _1;
        }

        /** pathopen.e:536							if try != -1 then -- that was it; record translation as the valid path*/
        if (_try_51129 == -1LL)
        goto L13; // [554] 611

        /** pathopen.e:537								cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26320 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26320) && IS_ATOM(0LL)) {
            Append(&_26321, _26320, 0LL);
        }
        else if (IS_ATOM(_26320) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26321, _26320, 0LL);
            _26320 = NOVALUE;
        }
        _26320 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26321;
        if( _1 != _26321 ){
            DeRef(_1);
        }
        _26321 = NOVALUE;

        /** pathopen.e:538								cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        _26322 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        RefDS(_full_path_51124);
        Append(&_26323, _26322, _full_path_51124);
        _26322 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50717 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26323;
        if( _1 != _26323 ){
            DeRefDS(_1);
        }
        _26323 = NOVALUE;

        /** pathopen.e:539								return {file_path,try}*/
        RefDS(_file_path_51125);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _file_path_51125;
        ((intptr_t *)_2)[2] = _try_51129;
        _26324 = MAKE_SEQ(_1);
        DeRefDS(_file_name_51120);
        DeRefDSi(_env_51121);
        DeRefi(_inc_path_51123);
        DeRefDS(_full_path_51124);
        DeRefDS(_file_path_51125);
        DeRef(_strings_51126);
        DeRef(_26313);
        _26313 = NOVALUE;
        DeRef(_26272);
        _26272 = NOVALUE;
        DeRef(_26293);
        _26293 = NOVALUE;
        DeRef(_26285);
        _26285 = NOVALUE;
        _26290 = NOVALUE;
        return _26324;
        goto L14; // [608] 656
L13: 

        /** pathopen.e:541								cache_converted[num_var] = append(cache_converted[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26325 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        RefDS(_full_path_51124);
        Append(&_26326, _26325, _full_path_51124);
        _26325 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26326;
        if( _1 != _26326 ){
            DeRef(_1);
        }
        _26326 = NOVALUE;
        goto L14; // [634] 656
L12: 

        /** pathopen.e:544							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26327 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26327) && IS_ATOM(0LL)) {
            Append(&_26328, _26327, 0LL);
        }
        else if (IS_ATOM(_26327) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26328, _26327, 0LL);
            _26327 = NOVALUE;
        }
        _26327 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26328;
        if( _1 != _26328 ){
            DeRef(_1);
        }
        _26328 = NOVALUE;
L14: 

        /** pathopen.e:547					start_path = 0*/
        _start_path_51128 = 0LL;
        goto L10; // [662] 709
LD: 

        /** pathopen.e:549			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26329 = (_start_path_51128 == 0);
        if (_26329 == 0) {
            goto L15; // [670] 708
        }
        _2 = (object)SEQ_PTR(_inc_path_51123);
        _26331 = (object)*(((s1_ptr)_2)->base + _p_51179);
        _26332 = (_26331 != 32LL);
        _26331 = NOVALUE;
        if (_26332 == 0) {
            DeRef(_26333);
            _26333 = 0;
            goto L16; // [682] 698
        }
        _2 = (object)SEQ_PTR(_inc_path_51123);
        _26334 = (object)*(((s1_ptr)_2)->base + _p_51179);
        _26335 = (_26334 != 9LL);
        _26334 = NOVALUE;
        _26333 = (_26335 != 0);
L16: 
        if (_26333 == 0)
        {
            _26333 = NOVALUE;
            goto L15; // [699] 708
        }
        else{
            _26333 = NOVALUE;
        }

        /** pathopen.e:550				start_path = p*/
        _start_path_51128 = _p_51179;
L15: 
L10: 

        /** pathopen.e:552		end for*/
        _p_51179 = _p_51179 + 1LL;
        goto LB; // [711] 317
LC: 
        ;
    }

    /** pathopen.e:554		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50721);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50721 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:555		return -1*/
    DeRefDS(_file_name_51120);
    DeRefDSi(_env_51121);
    DeRefi(_inc_path_51123);
    DeRef(_full_path_51124);
    DeRef(_file_path_51125);
    DeRef(_strings_51126);
    DeRef(_26324);
    _26324 = NOVALUE;
    DeRef(_26313);
    _26313 = NOVALUE;
    DeRef(_26329);
    _26329 = NOVALUE;
    DeRef(_26272);
    _26272 = NOVALUE;
    DeRef(_26293);
    _26293 = NOVALUE;
    DeRef(_26285);
    _26285 = NOVALUE;
    DeRef(_26335);
    _26335 = NOVALUE;
    DeRef(_26332);
    _26332 = NOVALUE;
    _26290 = NOVALUE;
    return -1LL;
    ;
}


object _48Include_paths(object _add_converted_51243)
{
    object _status_51244 = NOVALUE;
    object _pos_51245 = NOVALUE;
    object _inc_path_51246 = NOVALUE;
    object _full_path_51247 = NOVALUE;
    object _start_path_51248 = NOVALUE;
    object _end_path_51249 = NOVALUE;
    object _eudir_path_51265 = NOVALUE;
    object _26396 = NOVALUE;
    object _26395 = NOVALUE;
    object _26394 = NOVALUE;
    object _26393 = NOVALUE;
    object _26392 = NOVALUE;
    object _26391 = NOVALUE;
    object _26390 = NOVALUE;
    object _26388 = NOVALUE;
    object _26387 = NOVALUE;
    object _26386 = NOVALUE;
    object _26385 = NOVALUE;
    object _26384 = NOVALUE;
    object _26383 = NOVALUE;
    object _26382 = NOVALUE;
    object _26381 = NOVALUE;
    object _26380 = NOVALUE;
    object _26379 = NOVALUE;
    object _26378 = NOVALUE;
    object _26377 = NOVALUE;
    object _26376 = NOVALUE;
    object _26375 = NOVALUE;
    object _26374 = NOVALUE;
    object _26373 = NOVALUE;
    object _26372 = NOVALUE;
    object _26371 = NOVALUE;
    object _26370 = NOVALUE;
    object _26369 = NOVALUE;
    object _26368 = NOVALUE;
    object _26366 = NOVALUE;
    object _26364 = NOVALUE;
    object _26363 = NOVALUE;
    object _26362 = NOVALUE;
    object _26361 = NOVALUE;
    object _26360 = NOVALUE;
    object _26357 = NOVALUE;
    object _26356 = NOVALUE;
    object _26354 = NOVALUE;
    object _26352 = NOVALUE;
    object _26350 = NOVALUE;
    object _26349 = NOVALUE;
    object _26347 = NOVALUE;
    object _26344 = NOVALUE;
    object _26342 = NOVALUE;
    object _26337 = NOVALUE;
    object _26336 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_51243)) {
        _1 = (object)(DBL_PTR(_add_converted_51243)->dbl);
        DeRefDS(_add_converted_51243);
        _add_converted_51243 = _1;
    }

    /** pathopen.e:566		if length(include_Paths) then*/
    if (IS_SEQUENCE(_48include_Paths_51240)){
            _26336 = SEQ_PTR(_48include_Paths_51240)->length;
    }
    else {
        _26336 = 1;
    }
    if (_26336 == 0)
    {
        _26336 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _26336 = NOVALUE;
    }

    /** pathopen.e:567			return include_Paths*/
    RefDS(_48include_Paths_51240);
    DeRefi(_inc_path_51246);
    DeRefi(_full_path_51247);
    DeRef(_eudir_path_51265);
    return _48include_Paths_51240;
L1: 

    /** pathopen.e:570		include_Paths = append(config_inc_paths, current_dir())*/
    _26337 = _17current_dir();
    Ref(_26337);
    Append(&_48include_Paths_51240, _48config_inc_paths_50723, _26337);
    DeRef(_26337);
    _26337 = NOVALUE;

    /** pathopen.e:571		num_var = find("EUINC", cache_vars)*/
    _48num_var_50714 = find_from(_26339, _48cache_vars_50715, 1LL);

    /** pathopen.e:572		inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_51246);
    _inc_path_51246 = EGetEnv(_26339);

    /** pathopen.e:573		if atom(inc_path) then*/
    _26342 = IS_ATOM(_inc_path_51246);
    if (_26342 == 0)
    {
        _26342 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _26342 = NOVALUE;
    }

    /** pathopen.e:574			inc_path = ""*/
    RefDS(_22186);
    DeRefi(_inc_path_51246);
    _inc_path_51246 = _22186;
L2: 

    /** pathopen.e:576		status = check_cache("EUINC", inc_path)*/
    RefDS(_26339);
    Ref(_inc_path_51246);
    _status_51244 = _48check_cache(_26339, _inc_path_51246);
    if (!IS_ATOM_INT(_status_51244)) {
        _1 = (object)(DBL_PTR(_status_51244)->dbl);
        DeRefDS(_status_51244);
        _status_51244 = _1;
    }

    /** pathopen.e:577		if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_51246)){
            _26344 = SEQ_PTR(_inc_path_51246)->length;
    }
    else {
        _26344 = 1;
    }
    if (_26344 == 0)
    {
        _26344 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _26344 = NOVALUE;
    }

    /** pathopen.e:578			inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_51246, _inc_path_51246, 59LL);
L3: 

    /** pathopen.e:580		object eudir_path = get_eudir()*/
    _0 = _eudir_path_51265;
    _eudir_path_51265 = _37get_eudir();
    DeRef(_0);

    /** pathopen.e:581		if sequence(eudir_path) then*/
    _26347 = IS_SEQUENCE(_eudir_path_51265);
    if (_26347 == 0)
    {
        _26347 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _26347 = NOVALUE;
    }

    /** pathopen.e:582			include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_eudir_path_51265);
    ((intptr_t*)_2)[1] = _eudir_path_51265;
    _26349 = MAKE_SEQ(_1);
    _26350 = EPrintf(-9999999, _26348, _26349);
    DeRefDS(_26349);
    _26349 = NOVALUE;
    RefDS(_26350);
    Append(&_48include_Paths_51240, _48include_Paths_51240, _26350);
    DeRefDS(_26350);
    _26350 = NOVALUE;
L4: 

    /** pathopen.e:585		if status then*/
    if (_status_51244 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** pathopen.e:587			if cache_complete[num_var] then*/
    _2 = (object)SEQ_PTR(_48cache_complete_50721);
    _26352 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    if (_26352 == 0)
    {
        _26352 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _26352 = NOVALUE;
    }

    /** pathopen.e:588				goto "cache done"*/
    goto G7;
L6: 

    /** pathopen.e:590			pos = cache_delims[num_var]+1*/
    _2 = (object)SEQ_PTR(_48cache_delims_50722);
    _26354 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    _pos_51245 = _26354 + 1;
    _26354 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /** pathopen.e:592	        pos = 1*/
    _pos_51245 = 1LL;
L8: 

    /** pathopen.e:594		start_path = 0*/
    _start_path_51248 = 0LL;

    /** pathopen.e:595		for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_51246)){
            _26356 = SEQ_PTR(_inc_path_51246)->length;
    }
    else {
        _26356 = 1;
    }
    {
        object _p_51282;
        _p_51282 = _pos_51245;
L9: 
        if (_p_51282 > _26356){
            goto LA; // [179] 456
        }

        /** pathopen.e:596			if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (object)SEQ_PTR(_inc_path_51246);
        _26357 = (object)*(((s1_ptr)_2)->base + _p_51282);
        if (_26357 != 59LL)
        goto LB; // [194] 405

        /** pathopen.e:598				cache_delims[num_var] = p*/
        _2 = (object)SEQ_PTR(_48cache_delims_50722);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_delims_50722 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        *(intptr_t *)_2 = _p_51282;

        /** pathopen.e:600				end_path = p-1*/
        _end_path_51249 = _p_51282 - 1LL;

        /** pathopen.e:601				while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _26360 = (_end_path_51249 >= _start_path_51248);
        if (_26360 == 0) {
            goto LD; // [223] 257
        }
        _2 = (object)SEQ_PTR(_inc_path_51246);
        _26362 = (object)*(((s1_ptr)_2)->base + _end_path_51249);
        Concat((object_ptr)&_26363, _26296, _46SLASH_CHARS_21927);
        _26364 = find_from(_26362, _26363, 1LL);
        _26362 = NOVALUE;
        DeRefDS(_26363);
        _26363 = NOVALUE;
        if (_26364 == 0)
        {
            _26364 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _26364 = NOVALUE;
        }

        /** pathopen.e:602					end_path -= 1*/
        _end_path_51249 = _end_path_51249 - 1LL;

        /** pathopen.e:603				end while*/
        goto LC; // [254] 219
LD: 

        /** pathopen.e:605				if start_path and end_path then*/
        if (_start_path_51248 == 0) {
            goto LE; // [259] 449
        }
        if (_end_path_51249 == 0)
        {
            goto LE; // [264] 449
        }
        else{
        }

        /** pathopen.e:606					full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_51247;
        RHS_Slice(_inc_path_51246, _start_path_51248, _end_path_51249);

        /** pathopen.e:607					cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        _26368 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        RefDS(_full_path_51247);
        Append(&_26369, _26368, _full_path_51247);
        _26368 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_substrings_50717);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_substrings_50717 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26369;
        if( _1 != _26369 ){
            DeRefDS(_1);
        }
        _26369 = NOVALUE;

        /** pathopen.e:608					cache_starts[num_var] &= start_path*/
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        _26370 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26370) && IS_ATOM(_start_path_51248)) {
            Append(&_26371, _26370, _start_path_51248);
        }
        else if (IS_ATOM(_26370) && IS_SEQUENCE(_start_path_51248)) {
        }
        else {
            Concat((object_ptr)&_26371, _26370, _start_path_51248);
            _26370 = NOVALUE;
        }
        _26370 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_starts_50718);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_starts_50718 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26371;
        if( _1 != _26371 ){
            DeRef(_1);
        }
        _26371 = NOVALUE;

        /** pathopen.e:609					cache_ends[num_var] &= end_path*/
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        _26372 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26372) && IS_ATOM(_end_path_51249)) {
            Append(&_26373, _26372, _end_path_51249);
        }
        else if (IS_ATOM(_26372) && IS_SEQUENCE(_end_path_51249)) {
        }
        else {
            Concat((object_ptr)&_26373, _26372, _end_path_51249);
            _26372 = NOVALUE;
        }
        _26372 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_ends_50719);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_ends_50719 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26373;
        if( _1 != _26373 ){
            DeRef(_1);
        }
        _26373 = NOVALUE;

        /** pathopen.e:610					ifdef WINDOWS then*/

        /** pathopen.e:611						if find(1, full_path>=128) then*/
        _26374 = binary_op(GREATEREQ, _full_path_51247, 128LL);
        _26375 = find_from(1LL, _26374, 1LL);
        DeRefDS(_26374);
        _26374 = NOVALUE;
        if (_26375 == 0)
        {
            _26375 = NOVALUE;
            goto LF; // [345] 377
        }
        else{
            _26375 = NOVALUE;
        }

        /** pathopen.e:614							cache_converted[num_var] = append(cache_converted[num_var], */
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26376 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        RefDS(_full_path_51247);
        _26377 = _48convert_from_OEM(_full_path_51247);
        Ref(_26377);
        Append(&_26378, _26376, _26377);
        _26376 = NOVALUE;
        DeRef(_26377);
        _26377 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26378;
        if( _1 != _26378 ){
            DeRef(_1);
        }
        _26378 = NOVALUE;
        goto L10; // [374] 396
LF: 

        /** pathopen.e:617							cache_converted[num_var] &= 0*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26379 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        if (IS_SEQUENCE(_26379) && IS_ATOM(0LL)) {
            Append(&_26380, _26379, 0LL);
        }
        else if (IS_ATOM(_26379) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_26380, _26379, 0LL);
            _26379 = NOVALUE;
        }
        _26379 = NOVALUE;
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _48cache_converted_50720 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _26380;
        if( _1 != _26380 ){
            DeRef(_1);
        }
        _26380 = NOVALUE;
L10: 

        /** pathopen.e:620					start_path = 0*/
        _start_path_51248 = 0LL;
        goto LE; // [402] 449
LB: 

        /** pathopen.e:622			elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _26381 = (_start_path_51248 == 0);
        if (_26381 == 0) {
            goto L11; // [410] 448
        }
        _2 = (object)SEQ_PTR(_inc_path_51246);
        _26383 = (object)*(((s1_ptr)_2)->base + _p_51282);
        _26384 = (_26383 != 32LL);
        _26383 = NOVALUE;
        if (_26384 == 0) {
            DeRef(_26385);
            _26385 = 0;
            goto L12; // [422] 438
        }
        _2 = (object)SEQ_PTR(_inc_path_51246);
        _26386 = (object)*(((s1_ptr)_2)->base + _p_51282);
        _26387 = (_26386 != 9LL);
        _26386 = NOVALUE;
        _26385 = (_26387 != 0);
L12: 
        if (_26385 == 0)
        {
            _26385 = NOVALUE;
            goto L11; // [439] 448
        }
        else{
            _26385 = NOVALUE;
        }

        /** pathopen.e:623				start_path = p*/
        _start_path_51248 = _p_51282;
L11: 
LE: 

        /** pathopen.e:625		end for*/
        _p_51282 = _p_51282 + 1LL;
        goto L9; // [451] 186
LA: 
        ;
    }

    /** pathopen.e:627	label "cache done"*/
G7:

    /** pathopen.e:628		include_Paths &= cache_substrings[num_var]*/
    _2 = (object)SEQ_PTR(_48cache_substrings_50717);
    _26388 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    Concat((object_ptr)&_48include_Paths_51240, _48include_Paths_51240, _26388);
    _26388 = NOVALUE;

    /** pathopen.e:629		cache_complete[num_var] = 1*/
    _2 = (object)SEQ_PTR(_48cache_complete_50721);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _48cache_complete_50721 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _48num_var_50714);
    *(intptr_t *)_2 = 1LL;

    /** pathopen.e:631		ifdef WINDOWS then*/

    /** pathopen.e:632			if add_converted then*/
    if (_add_converted_51243 == 0)
    {
        goto L13; // [490] 562
    }
    else{
    }

    /** pathopen.e:633		    	for i=1 to length(cache_converted[num_var]) do*/
    _2 = (object)SEQ_PTR(_48cache_converted_50720);
    _26390 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
    if (IS_SEQUENCE(_26390)){
            _26391 = SEQ_PTR(_26390)->length;
    }
    else {
        _26391 = 1;
    }
    _26390 = NOVALUE;
    {
        object _i_51327;
        _i_51327 = 1LL;
L14: 
        if (_i_51327 > _26391){
            goto L15; // [506] 561
        }

        /** pathopen.e:634		        	if sequence(cache_converted[num_var][i]) then*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26392 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26392);
        _26393 = (object)*(((s1_ptr)_2)->base + _i_51327);
        _26392 = NOVALUE;
        _26394 = IS_SEQUENCE(_26393);
        _26393 = NOVALUE;
        if (_26394 == 0)
        {
            _26394 = NOVALUE;
            goto L16; // [530] 554
        }
        else{
            _26394 = NOVALUE;
        }

        /** pathopen.e:635			        	include_Paths = append(include_Paths, cache_converted[num_var][i])*/
        _2 = (object)SEQ_PTR(_48cache_converted_50720);
        _26395 = (object)*(((s1_ptr)_2)->base + _48num_var_50714);
        _2 = (object)SEQ_PTR(_26395);
        _26396 = (object)*(((s1_ptr)_2)->base + _i_51327);
        _26395 = NOVALUE;
        Ref(_26396);
        Append(&_48include_Paths_51240, _48include_Paths_51240, _26396);
        _26396 = NOVALUE;
L16: 

        /** pathopen.e:637				end for*/
        _i_51327 = _i_51327 + 1LL;
        goto L14; // [556] 513
L15: 
        ;
    }
L13: 

    /** pathopen.e:640		return include_Paths*/
    RefDS(_48include_Paths_51240);
    DeRefi(_inc_path_51246);
    DeRefi(_full_path_51247);
    DeRef(_eudir_path_51265);
    _26390 = NOVALUE;
    DeRef(_26384);
    _26384 = NOVALUE;
    _26357 = NOVALUE;
    DeRef(_26360);
    _26360 = NOVALUE;
    DeRef(_26381);
    _26381 = NOVALUE;
    DeRef(_26387);
    _26387 = NOVALUE;
    return _48include_Paths_51240;
    ;
}


object _48e_path_find(object _name_51339)
{
    object _scan_result_51340 = NOVALUE;
    object _26406 = NOVALUE;
    object _26405 = NOVALUE;
    object _26404 = NOVALUE;
    object _26401 = NOVALUE;
    object _26400 = NOVALUE;
    object _26399 = NOVALUE;
    object _26398 = NOVALUE;
    object _0, _1, _2;
    

    /** pathopen.e:656		if file_exists(name) then*/
    RefDS(_name_51339);
    _26398 = _17file_exists(_name_51339);
    if (_26398 == 0) {
        DeRef(_26398);
        _26398 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_26398) && DBL_PTR(_26398)->dbl == 0.0){
            DeRef(_26398);
            _26398 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_26398);
        _26398 = NOVALUE;
    }
    DeRef(_26398);
    _26398 = NOVALUE;

    /** pathopen.e:657			return name*/
    DeRef(_scan_result_51340);
    return _name_51339;
L1: 

    /** pathopen.e:661		for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_46SLASH_CHARS_21927)){
            _26399 = SEQ_PTR(_46SLASH_CHARS_21927)->length;
    }
    else {
        _26399 = 1;
    }
    {
        object _i_51345;
        _i_51345 = 1LL;
L2: 
        if (_i_51345 > _26399){
            goto L3; // [26] 63
        }

        /** pathopen.e:662			if find(SLASH_CHARS[i], name) then*/
        _2 = (object)SEQ_PTR(_46SLASH_CHARS_21927);
        _26400 = (object)*(((s1_ptr)_2)->base + _i_51345);
        _26401 = find_from(_26400, _name_51339, 1LL);
        _26400 = NOVALUE;
        if (_26401 == 0)
        {
            _26401 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _26401 = NOVALUE;
        }

        /** pathopen.e:663				return -1*/
        DeRefDS(_name_51339);
        DeRef(_scan_result_51340);
        return -1LL;
L4: 

        /** pathopen.e:665		end for*/
        _i_51345 = _i_51345 + 1LL;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** pathopen.e:667		scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_51339);
    RefDS(_26402);
    _0 = _scan_result_51340;
    _scan_result_51340 = _48ScanPath(_name_51339, _26402, 0LL);
    DeRef(_0);

    /** pathopen.e:668		if sequence(scan_result) then*/
    _26404 = IS_SEQUENCE(_scan_result_51340);
    if (_26404 == 0)
    {
        _26404 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26404 = NOVALUE;
    }

    /** pathopen.e:669			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_51340);
    _26405 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_26405))
    EClose(_26405);
    else
    EClose((object)DBL_PTR(_26405)->dbl);
    _26405 = NOVALUE;

    /** pathopen.e:670			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_51340);
    _26406 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_26406);
    DeRefDS(_name_51339);
    DeRef(_scan_result_51340);
    return _26406;
L5: 

    /** pathopen.e:673		return -1*/
    DeRefDS(_name_51339);
    DeRef(_scan_result_51340);
    _26406 = NOVALUE;
    return -1LL;
    ;
}



// 0x38EE2AEE
