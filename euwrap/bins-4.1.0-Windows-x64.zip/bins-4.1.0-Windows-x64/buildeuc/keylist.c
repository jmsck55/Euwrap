// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _63find_category(object _tokid_24316)
{
    object _catname_24317 = NOVALUE;
    object _13695 = NOVALUE;
    object _13694 = NOVALUE;
    object _13692 = NOVALUE;
    object _13691 = NOVALUE;
    object _13690 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24316)) {
        _1 = (object)(DBL_PTR(_tokid_24316)->dbl);
        DeRefDS(_tokid_24316);
        _tokid_24316 = _1;
    }

    /** keylist.e:194		sequence catname = "reserved word"*/
    RefDS(_13689);
    DeRef(_catname_24317);
    _catname_24317 = _13689;

    /** keylist.e:195		for i = 1 to length(token_category) do*/
    _13690 = 73;
    {
        object _i_24320;
        _i_24320 = 1LL;
L1: 
        if (_i_24320 > 73LL){
            goto L2; // [17] 72
        }

        /** keylist.e:196			if token_category[i][1] = tokid then*/
        _2 = (object)SEQ_PTR(_38token_category_16218);
        _13691 = (object)*(((s1_ptr)_2)->base + _i_24320);
        _2 = (object)SEQ_PTR(_13691);
        _13692 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13691 = NOVALUE;
        if (binary_op_a(NOTEQ, _13692, _tokid_24316)){
            _13692 = NOVALUE;
            goto L3; // [36] 65
        }
        _13692 = NOVALUE;

        /** keylist.e:197				catname = token_catname[token_category[i][2]]*/
        _2 = (object)SEQ_PTR(_38token_category_16218);
        _13694 = (object)*(((s1_ptr)_2)->base + _i_24320);
        _2 = (object)SEQ_PTR(_13694);
        _13695 = (object)*(((s1_ptr)_2)->base + 2LL);
        _13694 = NOVALUE;
        DeRef(_catname_24317);
        _2 = (object)SEQ_PTR(_38token_catname_16205);
        if (!IS_ATOM_INT(_13695)){
            _catname_24317 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13695)->dbl));
        }
        else{
            _catname_24317 = (object)*(((s1_ptr)_2)->base + _13695);
        }
        RefDS(_catname_24317);

        /** keylist.e:198				exit*/
        goto L2; // [62] 72
L3: 

        /** keylist.e:200		end for*/
        _i_24320 = _i_24320 + 1LL;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** keylist.e:201		return catname*/
    _13695 = NOVALUE;
    return _catname_24317;
    ;
}


object _63find_token_text(object _tokid_24335)
{
    object _13704 = NOVALUE;
    object _13702 = NOVALUE;
    object _13701 = NOVALUE;
    object _13699 = NOVALUE;
    object _13698 = NOVALUE;
    object _13697 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24335)) {
        _1 = (object)(DBL_PTR(_tokid_24335)->dbl);
        DeRefDS(_tokid_24335);
        _tokid_24335 = _1;
    }

    /** keylist.e:205		for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23435)){
            _13697 = SEQ_PTR(_63keylist_23435)->length;
    }
    else {
        _13697 = 1;
    }
    {
        object _i_24337;
        _i_24337 = 1LL;
L1: 
        if (_i_24337 > _13697){
            goto L2; // [10] 57
        }

        /** keylist.e:206			if keylist[i][3] = tokid then*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _13698 = (object)*(((s1_ptr)_2)->base + _i_24337);
        _2 = (object)SEQ_PTR(_13698);
        _13699 = (object)*(((s1_ptr)_2)->base + 3LL);
        _13698 = NOVALUE;
        if (binary_op_a(NOTEQ, _13699, _tokid_24335)){
            _13699 = NOVALUE;
            goto L3; // [29] 50
        }
        _13699 = NOVALUE;

        /** keylist.e:207				return keylist[i][1]*/
        _2 = (object)SEQ_PTR(_63keylist_23435);
        _13701 = (object)*(((s1_ptr)_2)->base + _i_24337);
        _2 = (object)SEQ_PTR(_13701);
        _13702 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13701 = NOVALUE;
        Ref(_13702);
        return _13702;
L3: 

        /** keylist.e:209		end for*/
        _i_24337 = _i_24337 + 1LL;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** keylist.e:210		return LexName(tokid, "unknown word")*/
    RefDS(_13703);
    _13704 = _47LexName(_tokid_24335, _13703);
    _13702 = NOVALUE;
    return _13704;
    ;
}



// 0x7549D9C3
