// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _51check_coverage()
{
    object _25315 = NOVALUE;
    object _25314 = NOVALUE;
    object _25313 = NOVALUE;
    object _25312 = NOVALUE;
    object _25311 = NOVALUE;
    object _25310 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:45		for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_51file_coverage_49177)){
            _25310 = SEQ_PTR(_51file_coverage_49177)->length;
    }
    else {
        _25310 = 1;
    }
    _25311 = _25310 + 1;
    _25310 = NOVALUE;
    if (IS_SEQUENCE(_37known_files_15638)){
            _25312 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _25312 = 1;
    }
    {
        object _i_49188;
        _i_49188 = _25311;
L1: 
        if (_i_49188 > _25312){
            goto L2; // [17] 58
        }

        /** coverage.e:46			file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _25313 = (object)*(((s1_ptr)_2)->base + _i_49188);
        Ref(_25313);
        _25314 = _17canonical_path(_25313, 0LL, 1LL);
        _25313 = NOVALUE;
        _25315 = find_from(_25314, _51covered_files_49176, 1LL);
        DeRef(_25314);
        _25314 = NOVALUE;
        Append(&_51file_coverage_49177, _51file_coverage_49177, _25315);
        _25315 = NOVALUE;

        /** coverage.e:47		end for*/
        _i_49188 = _i_49188 + 1LL;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** coverage.e:48	end procedure*/
    DeRef(_25311);
    _25311 = NOVALUE;
    return;
    ;
}


void _51init_coverage()
{
    object _cmd_49212 = NOVALUE;
    object _25333 = NOVALUE;
    object _25332 = NOVALUE;
    object _25330 = NOVALUE;
    object _25329 = NOVALUE;
    object _25328 = NOVALUE;
    object _25326 = NOVALUE;
    object _25324 = NOVALUE;
    object _25323 = NOVALUE;
    object _25321 = NOVALUE;
    object _25320 = NOVALUE;
    object _25319 = NOVALUE;
    object _25318 = NOVALUE;
    object _25317 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:54		if initialized_coverage then*/
    if (_51initialized_coverage_49184 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** coverage.e:55			return*/
    return;
L1: 

    /** coverage.e:57		initialized_coverage = 1*/
    _51initialized_coverage_49184 = 1LL;

    /** coverage.e:58		for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_51file_coverage_49177)){
            _25317 = SEQ_PTR(_51file_coverage_49177)->length;
    }
    else {
        _25317 = 1;
    }
    {
        object _i_49203;
        _i_49203 = 1LL;
L2: 
        if (_i_49203 > _25317){
            goto L3; // [26] 67
        }

        /** coverage.e:59			file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _25318 = (object)*(((s1_ptr)_2)->base + _i_49203);
        Ref(_25318);
        _25319 = _17canonical_path(_25318, 0LL, 1LL);
        _25318 = NOVALUE;
        _25320 = find_from(_25319, _51covered_files_49176, 1LL);
        DeRef(_25319);
        _25319 = NOVALUE;
        _2 = (object)SEQ_PTR(_51file_coverage_49177);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _51file_coverage_49177 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_49203);
        *(intptr_t *)_2 = _25320;
        if( _1 != _25320 ){
        }
        _25320 = NOVALUE;

        /** coverage.e:60		end for*/
        _i_49203 = _i_49203 + 1LL;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** coverage.e:62		if equal( coverage_db_name, "" ) then*/
    if (_51coverage_db_name_49178 == _22186)
    _25321 = 1;
    else if (IS_ATOM_INT(_51coverage_db_name_49178) && IS_ATOM_INT(_22186))
    _25321 = 0;
    else
    _25321 = (compare(_51coverage_db_name_49178, _22186) == 0);
    if (_25321 == 0)
    {
        _25321 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _25321 = NOVALUE;
    }

    /** coverage.e:63			sequence cmd = command_line()*/
    DeRef(_cmd_49212);
    _cmd_49212 = Command_Line();

    /** coverage.e:64			coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (object)SEQ_PTR(_cmd_49212);
    _25323 = (object)*(((s1_ptr)_2)->base + 2LL);
    RefDS(_25323);
    _25324 = _17filebase(_25323);
    _25323 = NOVALUE;
    if (IS_SEQUENCE(_25324) && IS_ATOM(_25325)) {
    }
    else if (IS_ATOM(_25324) && IS_SEQUENCE(_25325)) {
        Ref(_25324);
        Prepend(&_25326, _25325, _25324);
    }
    else {
        Concat((object_ptr)&_25326, _25324, _25325);
        DeRef(_25324);
        _25324 = NOVALUE;
    }
    DeRef(_25324);
    _25324 = NOVALUE;
    _0 = _17canonical_path(_25326, 0LL, 0LL);
    DeRefDS(_51coverage_db_name_49178);
    _51coverage_db_name_49178 = _0;
    _25326 = NOVALUE;
L4: 
    DeRef(_cmd_49212);
    _cmd_49212 = NOVALUE;

    /** coverage.e:67		if coverage_erase and file_exists( coverage_db_name ) then*/
    if (0LL == 0) {
        goto L5; // [111] 153
    }
    RefDS(_51coverage_db_name_49178);
    _25329 = _17file_exists(_51coverage_db_name_49178);
    if (_25329 == 0) {
        DeRef(_25329);
        _25329 = NOVALUE;
        goto L5; // [122] 153
    }
    else {
        if (!IS_ATOM_INT(_25329) && DBL_PTR(_25329)->dbl == 0.0){
            DeRef(_25329);
            _25329 = NOVALUE;
            goto L5; // [122] 153
        }
        DeRef(_25329);
        _25329 = NOVALUE;
    }
    DeRef(_25329);
    _25329 = NOVALUE;

    /** coverage.e:68			if not delete_file( coverage_db_name ) then*/
    RefDS(_51coverage_db_name_49178);
    _25330 = _17delete_file(_51coverage_db_name_49178);
    if (IS_ATOM_INT(_25330)) {
        if (_25330 != 0){
            DeRef(_25330);
            _25330 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    else {
        if (DBL_PTR(_25330)->dbl != 0.0){
            DeRef(_25330);
            _25330 = NOVALUE;
            goto L6; // [133] 152
        }
    }
    DeRef(_25330);
    _25330 = NOVALUE;

    /** coverage.e:69				CompileErr( COULD_NOT_ERASE_COVERAGE_DATABASE_1, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_51coverage_db_name_49178);
    ((intptr_t*)_2)[1] = _51coverage_db_name_49178;
    _25332 = MAKE_SEQ(_1);
    _50CompileErr(335LL, _25332, 0LL);
    _25332 = NOVALUE;
L6: 
L5: 

    /** coverage.e:73		if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_51coverage_db_name_49178);
    _25333 = _43db_open(_51coverage_db_name_49178, 0LL);
    if (binary_op_a(NOTEQ, _25333, 0LL)){
        DeRef(_25333);
        _25333 = NOVALUE;
        goto L7; // [164] 177
    }
    DeRef(_25333);
    _25333 = NOVALUE;

    /** coverage.e:74			read_coverage_db()*/
    _51read_coverage_db();

    /** coverage.e:75			db_close()*/
    _43db_close();
L7: 

    /** coverage.e:77	end procedure*/
    return;
    ;
}


void _51read_coverage_db()
{
    object _tables_49318 = NOVALUE;
    object _name_49324 = NOVALUE;
    object _fx_49328 = NOVALUE;
    object _the_map_49335 = NOVALUE;
    object _31968 = NOVALUE;
    object _25381 = NOVALUE;
    object _25380 = NOVALUE;
    object _25379 = NOVALUE;
    object _25375 = NOVALUE;
    object _25374 = NOVALUE;
    object _25373 = NOVALUE;
    object _25369 = NOVALUE;
    object _25368 = NOVALUE;
    object _25367 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:135		sequence tables = db_table_list()*/
    _0 = _tables_49318;
    _tables_49318 = _43db_table_list();
    DeRef(_0);

    /** coverage.e:137		for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_49318)){
            _25367 = SEQ_PTR(_tables_49318)->length;
    }
    else {
        _25367 = 1;
    }
    {
        object _i_49322;
        _i_49322 = 1LL;
L1: 
        if (_i_49322 > _25367){
            goto L2; // [13] 157
        }

        /** coverage.e:138			sequence name = tables[i][2..$]*/
        _2 = (object)SEQ_PTR(_tables_49318);
        _25368 = (object)*(((s1_ptr)_2)->base + _i_49322);
        if (IS_SEQUENCE(_25368)){
                _25369 = SEQ_PTR(_25368)->length;
        }
        else {
            _25369 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_49324;
        RHS_Slice(_25368, 2LL, _25369);
        _25368 = NOVALUE;

        /** coverage.e:139			integer fx = find( name, covered_files )*/
        _fx_49328 = find_from(_name_49324, _51covered_files_49176, 1LL);

        /** coverage.e:140			if not fx then*/
        if (_fx_49328 != 0)
        goto L3; // [45] 55

        /** coverage.e:141				continue*/
        DeRefDS(_name_49324);
        _name_49324 = NOVALUE;
        DeRef(_the_map_49335);
        _the_map_49335 = NOVALUE;
        goto L4; // [52] 152
L3: 

        /** coverage.e:144			db_select_table( tables[i] )*/
        _2 = (object)SEQ_PTR(_tables_49318);
        _25373 = (object)*(((s1_ptr)_2)->base + _i_49322);
        Ref(_25373);
        _31968 = _43db_select_table(_25373);
        _25373 = NOVALUE;
        DeRef(_31968);
        _31968 = NOVALUE;

        /** coverage.e:146			if tables[i][1] = 'r' then*/
        _2 = (object)SEQ_PTR(_tables_49318);
        _25374 = (object)*(((s1_ptr)_2)->base + _i_49322);
        _2 = (object)SEQ_PTR(_25374);
        _25375 = (object)*(((s1_ptr)_2)->base + 1LL);
        _25374 = NOVALUE;
        if (binary_op_a(NOTEQ, _25375, 114LL)){
            _25375 = NOVALUE;
            goto L5; // [77] 92
        }
        _25375 = NOVALUE;

        /** coverage.e:148				the_map = routine_map[fx]*/
        DeRef(_the_map_49335);
        _2 = (object)SEQ_PTR(_51routine_map_49182);
        _the_map_49335 = (object)*(((s1_ptr)_2)->base + _fx_49328);
        Ref(_the_map_49335);
        goto L6; // [89] 101
L5: 

        /** coverage.e:152				the_map = line_map[fx]*/
        DeRef(_the_map_49335);
        _2 = (object)SEQ_PTR(_51line_map_49181);
        _the_map_49335 = (object)*(((s1_ptr)_2)->base + _fx_49328);
        Ref(_the_map_49335);
L6: 

        /** coverage.e:156			for j = 1 to db_table_size() do*/
        RefDS(_43current_table_name_17117);
        _25379 = _43db_table_size(_43current_table_name_17117);
        {
            object _j_49344;
            _j_49344 = 1LL;
L7: 
            if (binary_op_a(GREATER, _j_49344, _25379)){
                goto L8; // [109] 148
            }

            /** coverage.e:157				map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_49344);
            RefDS(_43current_table_name_17117);
            _25380 = _43db_record_key(_j_49344, _43current_table_name_17117);
            Ref(_j_49344);
            RefDS(_43current_table_name_17117);
            _25381 = _43db_record_data(_j_49344, _43current_table_name_17117);
            Ref(_the_map_49335);
            _29put(_the_map_49335, _25380, _25381, 2LL, 0LL);
            _25380 = NOVALUE;
            _25381 = NOVALUE;

            /** coverage.e:158			end for*/
            _0 = _j_49344;
            if (IS_ATOM_INT(_j_49344)) {
                _j_49344 = _j_49344 + 1LL;
                if ((object)((uintptr_t)_j_49344 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_49344 = NewDouble((eudouble)_j_49344);
                }
            }
            else {
                _j_49344 = binary_op_a(PLUS, _j_49344, 1LL);
            }
            DeRef(_0);
            goto L7; // [143] 116
L8: 
            ;
            DeRef(_j_49344);
        }
        DeRef(_name_49324);
        _name_49324 = NOVALUE;
        DeRef(_the_map_49335);
        _the_map_49335 = NOVALUE;

        /** coverage.e:160		end for*/
L4: 
        _i_49322 = _i_49322 + 1LL;
        goto L1; // [152] 20
L2: 
        ;
    }

    /** coverage.e:161	end procedure*/
    DeRef(_tables_49318);
    DeRef(_25379);
    _25379 = NOVALUE;
    return;
    ;
}


object _51coverage_on()
{
    object _25382 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:170		return file_coverage[current_file_no]*/
    _2 = (object)SEQ_PTR(_51file_coverage_49177);
    _25382 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    return _25382;
    ;
}


void _51include_line(object _line_number_49484)
{
    object _25443 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:247		if coverage_on() then*/
    _25443 = _51coverage_on();
    if (_25443 == 0) {
        DeRef(_25443);
        _25443 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25443) && DBL_PTR(_25443)->dbl == 0.0){
            DeRef(_25443);
            _25443 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25443);
        _25443 = NOVALUE;
    }
    DeRef(_25443);
    _25443 = NOVALUE;

    /** coverage.e:248			emit_op( COVERAGE_LINE )*/
    _47emit_op(210LL);

    /** coverage.e:249			emit_addr( gline_number )*/
    _47emit_addr(_36gline_number_21764);

    /** coverage.e:251			included_lines &= line_number*/
    Append(&_51included_lines_49183, _51included_lines_49183, _line_number_49484);
L1: 

    /** coverage.e:253	end procedure*/
    return;
    ;
}


void _51include_routine()
{
    object _file_no_49500 = NOVALUE;
    object _25450 = NOVALUE;
    object _25449 = NOVALUE;
    object _25448 = NOVALUE;
    object _25446 = NOVALUE;
    object _25445 = NOVALUE;
    object _0, _1, _2;
    

    /** coverage.e:256		if coverage_on() then*/
    _25445 = _51coverage_on();
    if (_25445 == 0) {
        DeRef(_25445);
        _25445 = NOVALUE;
        goto L1; // [6] 69
    }
    else {
        if (!IS_ATOM_INT(_25445) && DBL_PTR(_25445)->dbl == 0.0){
            DeRef(_25445);
            _25445 = NOVALUE;
            goto L1; // [6] 69
        }
        DeRef(_25445);
        _25445 = NOVALUE;
    }
    DeRef(_25445);
    _25445 = NOVALUE;

    /** coverage.e:257			emit_op( COVERAGE_ROUTINE )*/
    _47emit_op(211LL);

    /** coverage.e:258			emit_addr( CurrentSub )*/
    _47emit_addr(_36CurrentSub_21767);

    /** coverage.e:261			integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _25446 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21767);
    _2 = (object)SEQ_PTR(_25446);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _file_no_49500 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _file_no_49500 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (!IS_ATOM_INT(_file_no_49500)){
        _file_no_49500 = (object)DBL_PTR(_file_no_49500)->dbl;
    }
    _25446 = NOVALUE;

    /** coverage.e:262			map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (object)SEQ_PTR(_51file_coverage_49177);
    _25448 = (object)*(((s1_ptr)_2)->base + _file_no_49500);
    _2 = (object)SEQ_PTR(_51routine_map_49182);
    _25449 = (object)*(((s1_ptr)_2)->base + _25448);
    _25450 = _54sym_name(_36CurrentSub_21767);
    Ref(_25449);
    _29put(_25449, _25450, 0LL, 2LL, 0LL);
    _25449 = NOVALUE;
    _25450 = NOVALUE;
L1: 

    /** coverage.e:264	end procedure*/
    _25448 = NOVALUE;
    return;
    ;
}



// 0x6691FC76
