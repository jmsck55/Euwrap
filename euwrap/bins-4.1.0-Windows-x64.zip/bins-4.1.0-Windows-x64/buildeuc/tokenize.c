// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _71default_state()
{
    object _32392 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:177		return {*/
    _1 = NewS1(8);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 1LL;
    ((intptr_t*)_2)[2] = 1LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 1LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 1LL;
    ((intptr_t*)_2)[7] = 0LL;
    ((intptr_t*)_2)[8] = 0LL;
    _32392 = MAKE_SEQ(_1);
    return _32392;
    ;
}


object _71new()
{
    object _state_65936 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:200		atom state = eumem:malloc()*/
    _0 = _state_65936;
    _state_65936 = _30malloc(1LL, 1LL);
    DeRef(_0);

    /** tokenize.e:202		reset(state)*/
    Ref(_state_65936);
    _71reset(_state_65936);

    /** tokenize.e:204		return state*/
    return _state_65936;
    ;
}


void _71reset(object _state_65941)
{
    object _32396 = NOVALUE;
    object _0, _1, _2;
    

    /** tokenize.e:215		eumem:ram_space[state] = default_state()*/
    _32396 = _71default_state();
    _2 = (object)SEQ_PTR(_30ram_space_11346);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _30ram_space_11346 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_state_65941))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_state_65941)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _state_65941);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _32396;
    if( _1 != _32396 ){
        DeRef(_1);
    }
    _32396 = NOVALUE;

    /** tokenize.e:216	end procedure*/
    DeRef(_state_65941);
    return;
    ;
}



// 0x46EE1CEC
