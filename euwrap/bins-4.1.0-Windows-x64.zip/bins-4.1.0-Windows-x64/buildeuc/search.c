// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _16find_all(object _needle_1429, object _haystack_1430, object _start_1431)
{
    object _kx_1432 = NOVALUE;
    object _564 = NOVALUE;
    object _563 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:292		integer kx = 0*/
    _kx_1432 = 0LL;

    /** search.e:293		while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1431 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** search.e:294			kx += 1*/
    _kx_1432 = _kx_1432 + 1;

    /** search.e:295			haystack[kx] = start*/
    _2 = (object)SEQ_PTR(_haystack_1430);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1430 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _kx_1432);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _start_1431;
    DeRef(_1);

    /** search.e:296			start += 1*/
    _start_1431 = _start_1431 + 1;

    /** search.e:297		entry*/
L1: 

    /** search.e:298			start = find(needle, haystack, start)*/
    _start_1431 = find_from(_needle_1429, _haystack_1430, _start_1431);

    /** search.e:299		end while*/
    goto L2; // [48] 15
L3: 

    /** search.e:301		haystack = remove( haystack, kx+1, length( haystack ) )*/
    _563 = _kx_1432 + 1;
    if (_563 > MAXINT){
        _563 = NewDouble((eudouble)_563);
    }
    if (IS_SEQUENCE(_haystack_1430)){
            _564 = SEQ_PTR(_haystack_1430)->length;
    }
    else {
        _564 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1430);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_563)) ? _563 : (object)(DBL_PTR(_563)->dbl);
        int stop = (IS_ATOM_INT(_564)) ? _564 : (object)(DBL_PTR(_564)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1430), start, &_haystack_1430 );
            }
            else Tail(SEQ_PTR(_haystack_1430), stop+1, &_haystack_1430);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1430), start, &_haystack_1430);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1430 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1430)->ref == 1));
        }
    }
    DeRef(_563);
    _563 = NOVALUE;
    _564 = NOVALUE;

    /** search.e:302		return haystack*/
    return _haystack_1430;
    ;
}


object _16rfind(object _needle_1547, object _haystack_1548, object _start_1549)
{
    object _len_1551 = NOVALUE;
    object _625 = NOVALUE;
    object _624 = NOVALUE;
    object _621 = NOVALUE;
    object _620 = NOVALUE;
    object _618 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:550		integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1548)){
            _len_1551 = SEQ_PTR(_haystack_1548)->length;
    }
    else {
        _len_1551 = 1;
    }

    /** search.e:552		if start = 0 then start = len end if*/
    if (_start_1549 != 0LL)
    goto L1; // [12] 20
    _start_1549 = _len_1551;
L1: 

    /** search.e:553		if (start > len) or (len + start < 1) then*/
    _618 = (_start_1549 > _len_1551);
    if (_618 != 0) {
        goto L2; // [26] 43
    }
    _620 = _len_1551 + _start_1549;
    if ((object)((uintptr_t)_620 + (uintptr_t)HIGH_BITS) >= 0){
        _620 = NewDouble((eudouble)_620);
    }
    if (IS_ATOM_INT(_620)) {
        _621 = (_620 < 1LL);
    }
    else {
        _621 = (DBL_PTR(_620)->dbl < (eudouble)1LL);
    }
    DeRef(_620);
    _620 = NOVALUE;
    if (_621 == 0)
    {
        DeRef(_621);
        _621 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_621);
        _621 = NOVALUE;
    }
L2: 

    /** search.e:554			return 0*/
    DeRef(_needle_1547);
    DeRefDS(_haystack_1548);
    DeRef(_618);
    _618 = NOVALUE;
    return 0LL;
L3: 

    /** search.e:557		if start < 1 then*/
    if (_start_1549 >= 1LL)
    goto L4; // [52] 63

    /** search.e:558			start = len + start*/
    _start_1549 = _len_1551 + _start_1549;
L4: 

    /** search.e:561		for i = start to 1 by -1 do*/
    {
        object _i_1564;
        _i_1564 = _start_1549;
L5: 
        if (_i_1564 < 1LL){
            goto L6; // [65] 99
        }

        /** search.e:562			if equal(haystack[i], needle) then*/
        _2 = (object)SEQ_PTR(_haystack_1548);
        _624 = (object)*(((s1_ptr)_2)->base + _i_1564);
        if (_624 == _needle_1547)
        _625 = 1;
        else if (IS_ATOM_INT(_624) && IS_ATOM_INT(_needle_1547))
        _625 = 0;
        else
        _625 = (compare(_624, _needle_1547) == 0);
        _624 = NOVALUE;
        if (_625 == 0)
        {
            _625 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _625 = NOVALUE;
        }

        /** search.e:563				return i*/
        DeRef(_needle_1547);
        DeRefDS(_haystack_1548);
        DeRef(_618);
        _618 = NOVALUE;
        return _i_1564;
L7: 

        /** search.e:565		end for*/
        _i_1564 = _i_1564 + -1LL;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** search.e:567		return 0*/
    DeRef(_needle_1547);
    DeRefDS(_haystack_1548);
    DeRef(_618);
    _618 = NOVALUE;
    return 0LL;
    ;
}


object _16find_replace(object _needle_1570, object _haystack_1571, object _replacement_1572, object _max_1573)
{
    object _posn_1574 = NOVALUE;
    object _629 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:612		integer posn = 0*/
    _posn_1574 = 0LL;

    /** search.e:614		while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1574 == 0LL)
    goto L3; // [15] 61

    /** search.e:615			haystack[posn] = replacement*/
    Ref(_replacement_1572);
    _2 = (object)SEQ_PTR(_haystack_1571);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _haystack_1571 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _posn_1574);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _replacement_1572;
    DeRef(_1);

    /** search.e:616			max -= 1*/
    _max_1573 = _max_1573 - 1LL;

    /** search.e:617			if max = 0 then*/
    if (_max_1573 != 0LL)
    goto L4; // [33] 42

    /** search.e:618				exit*/
    goto L3; // [39] 61
L4: 

    /** search.e:620		entry*/
L1: 

    /** search.e:621			posn = find(needle, haystack, posn + 1)*/
    _629 = _posn_1574 + 1;
    if (_629 > MAXINT){
        _629 = NewDouble((eudouble)_629);
    }
    _posn_1574 = find_from(_needle_1570, _haystack_1571, _629);
    DeRef(_629);
    _629 = NOVALUE;

    /** search.e:622		end while*/
    goto L2; // [58] 15
L3: 

    /** search.e:624		return haystack*/
    DeRef(_needle_1570);
    DeRefi(_replacement_1572);
    return _haystack_1571;
    ;
}


object _16match_replace(object _needle_1584, object _haystack_1585, object _replacement_1586, object _max_1587)
{
    object _posn_1588 = NOVALUE;
    object _needle_len_1589 = NOVALUE;
    object _replacement_len_1590 = NOVALUE;
    object _scan_from_1591 = NOVALUE;
    object _cnt_1592 = NOVALUE;
    object _641 = NOVALUE;
    object _638 = NOVALUE;
    object _636 = NOVALUE;
    object _634 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:692		if max < 0 then*/

    /** search.e:696		cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1585)){
            _cnt_1592 = SEQ_PTR(_haystack_1585)->length;
    }
    else {
        _cnt_1592 = 1;
    }

    /** search.e:697		if max != 0 then*/

    /** search.e:701		if atom(needle) then*/
    _634 = IS_ATOM(_needle_1584);
    if (_634 == 0)
    {
        _634 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _634 = NOVALUE;
    }

    /** search.e:702			needle = {needle}*/
    _0 = _needle_1584;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_needle_1584);
    ((intptr_t*)_2)[1] = _needle_1584;
    _needle_1584 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** search.e:704		if atom(replacement) then*/
    _636 = IS_ATOM(_replacement_1586);
    if (_636 == 0)
    {
        _636 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _636 = NOVALUE;
    }

    /** search.e:705			replacement = {replacement}*/
    _0 = _replacement_1586;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_replacement_1586);
    ((intptr_t*)_2)[1] = _replacement_1586;
    _replacement_1586 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** search.e:708		needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1584)){
            _638 = SEQ_PTR(_needle_1584)->length;
    }
    else {
        _638 = 1;
    }
    _needle_len_1589 = _638 - 1LL;
    _638 = NOVALUE;

    /** search.e:709		replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1586)){
            _replacement_len_1590 = SEQ_PTR(_replacement_1586)->length;
    }
    else {
        _replacement_len_1590 = 1;
    }

    /** search.e:711		scan_from = 1*/
    _scan_from_1591 = 1LL;

    /** search.e:712		while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1588 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** search.e:713			haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _641 = _posn_1588 + _needle_len_1589;
    if ((object)((uintptr_t)_641 + (uintptr_t)HIGH_BITS) >= 0){
        _641 = NewDouble((eudouble)_641);
    }
    {
        intptr_t p1 = _haystack_1585;
        intptr_t p2 = _replacement_1586;
        intptr_t p3 = _posn_1588;
        intptr_t p4 = _641;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1585;
        Replace( &replace_params );
    }
    DeRef(_641);
    _641 = NOVALUE;

    /** search.e:715			cnt -= 1*/
    _cnt_1592 = _cnt_1592 - 1LL;

    /** search.e:716			if cnt = 0 then*/
    if (_cnt_1592 != 0LL)
    goto L6; // [114] 123

    /** search.e:717				exit*/
    goto L5; // [120] 144
L6: 

    /** search.e:719			scan_from = posn + replacement_len*/
    _scan_from_1591 = _posn_1588 + _replacement_len_1590;

    /** search.e:720		entry*/
L3: 

    /** search.e:721			posn = match(needle, haystack, scan_from)*/
    _posn_1588 = e_match_from(_needle_1584, _haystack_1585, _scan_from_1591);

    /** search.e:722		end while*/
    goto L4; // [141] 89
L5: 

    /** search.e:724		return haystack*/
    DeRef(_needle_1584);
    DeRef(_replacement_1586);
    return _haystack_1585;
    ;
}


object _16begins(object _sub_text_1705, object _full_text_1706)
{
    object _705 = NOVALUE;
    object _704 = NOVALUE;
    object _703 = NOVALUE;
    object _701 = NOVALUE;
    object _700 = NOVALUE;
    object _699 = NOVALUE;
    object _698 = NOVALUE;
    object _697 = NOVALUE;
    object _695 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:976		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1706)){
            _695 = SEQ_PTR(_full_text_1706)->length;
    }
    else {
        _695 = 1;
    }
    if (_695 != 0LL)
    goto L1; // [8] 19

    /** search.e:977			return 0*/
    DeRef(_sub_text_1705);
    DeRefDS(_full_text_1706);
    return 0LL;
L1: 

    /** search.e:980		if atom(sub_text) then*/
    _697 = IS_ATOM(_sub_text_1705);
    if (_697 == 0)
    {
        _697 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _697 = NOVALUE;
    }

    /** search.e:981			if equal(sub_text, full_text[1]) then*/
    _2 = (object)SEQ_PTR(_full_text_1706);
    _698 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_sub_text_1705 == _698)
    _699 = 1;
    else if (IS_ATOM_INT(_sub_text_1705) && IS_ATOM_INT(_698))
    _699 = 0;
    else
    _699 = (compare(_sub_text_1705, _698) == 0);
    _698 = NOVALUE;
    if (_699 == 0)
    {
        _699 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _699 = NOVALUE;
    }

    /** search.e:982				return 1*/
    DeRef(_sub_text_1705);
    DeRefDS(_full_text_1706);
    return 1LL;
    goto L4; // [46] 56
L3: 

    /** search.e:984				return 0*/
    DeRef(_sub_text_1705);
    DeRefDS(_full_text_1706);
    return 0LL;
L4: 
L2: 

    /** search.e:988		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1705)){
            _700 = SEQ_PTR(_sub_text_1705)->length;
    }
    else {
        _700 = 1;
    }
    if (IS_SEQUENCE(_full_text_1706)){
            _701 = SEQ_PTR(_full_text_1706)->length;
    }
    else {
        _701 = 1;
    }
    if (_700 <= _701)
    goto L5; // [65] 76

    /** search.e:989			return 0*/
    DeRef(_sub_text_1705);
    DeRefDS(_full_text_1706);
    return 0LL;
L5: 

    /** search.e:992		if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_1705)){
            _703 = SEQ_PTR(_sub_text_1705)->length;
    }
    else {
        _703 = 1;
    }
    rhs_slice_target = (object_ptr)&_704;
    RHS_Slice(_full_text_1706, 1LL, _703);
    if (_sub_text_1705 == _704)
    _705 = 1;
    else if (IS_ATOM_INT(_sub_text_1705) && IS_ATOM_INT(_704))
    _705 = 0;
    else
    _705 = (compare(_sub_text_1705, _704) == 0);
    DeRefDS(_704);
    _704 = NOVALUE;
    if (_705 == 0)
    {
        _705 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _705 = NOVALUE;
    }

    /** search.e:993			return 1*/
    DeRef(_sub_text_1705);
    DeRefDS(_full_text_1706);
    return 1LL;
    goto L7; // [99] 109
L6: 

    /** search.e:995			return 0*/
    DeRef(_sub_text_1705);
    DeRefDS(_full_text_1706);
    return 0LL;
L7: 
    ;
}


object _16ends(object _sub_text_1727, object _full_text_1728)
{
    object _721 = NOVALUE;
    object _720 = NOVALUE;
    object _719 = NOVALUE;
    object _718 = NOVALUE;
    object _717 = NOVALUE;
    object _716 = NOVALUE;
    object _715 = NOVALUE;
    object _713 = NOVALUE;
    object _712 = NOVALUE;
    object _711 = NOVALUE;
    object _710 = NOVALUE;
    object _709 = NOVALUE;
    object _708 = NOVALUE;
    object _706 = NOVALUE;
    object _0, _1, _2;
    

    /** search.e:1026		if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1728)){
            _706 = SEQ_PTR(_full_text_1728)->length;
    }
    else {
        _706 = 1;
    }
    if (_706 != 0LL)
    goto L1; // [8] 19

    /** search.e:1027			return 0*/
    DeRefDSi(_sub_text_1727);
    DeRefDS(_full_text_1728);
    return 0LL;
L1: 

    /** search.e:1030		if atom(sub_text) then*/
    _708 = IS_ATOM(_sub_text_1727);
    if (_708 == 0)
    {
        _708 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _708 = NOVALUE;
    }

    /** search.e:1031			if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_1728)){
            _709 = SEQ_PTR(_full_text_1728)->length;
    }
    else {
        _709 = 1;
    }
    _2 = (object)SEQ_PTR(_full_text_1728);
    _710 = (object)*(((s1_ptr)_2)->base + _709);
    if (_sub_text_1727 == _710)
    _711 = 1;
    else if (IS_ATOM_INT(_sub_text_1727) && IS_ATOM_INT(_710))
    _711 = 0;
    else
    _711 = (compare(_sub_text_1727, _710) == 0);
    _710 = NOVALUE;
    if (_711 == 0)
    {
        _711 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _711 = NOVALUE;
    }

    /** search.e:1032				return 1*/
    DeRefi(_sub_text_1727);
    DeRefDS(_full_text_1728);
    return 1LL;
    goto L4; // [49] 59
L3: 

    /** search.e:1034				return 0*/
    DeRefi(_sub_text_1727);
    DeRefDS(_full_text_1728);
    return 0LL;
L4: 
L2: 

    /** search.e:1038		if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1727)){
            _712 = SEQ_PTR(_sub_text_1727)->length;
    }
    else {
        _712 = 1;
    }
    if (IS_SEQUENCE(_full_text_1728)){
            _713 = SEQ_PTR(_full_text_1728)->length;
    }
    else {
        _713 = 1;
    }
    if (_712 <= _713)
    goto L5; // [68] 79

    /** search.e:1039			return 0*/
    DeRefi(_sub_text_1727);
    DeRefDS(_full_text_1728);
    return 0LL;
L5: 

    /** search.e:1042		if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_1728)){
            _715 = SEQ_PTR(_full_text_1728)->length;
    }
    else {
        _715 = 1;
    }
    if (IS_SEQUENCE(_sub_text_1727)){
            _716 = SEQ_PTR(_sub_text_1727)->length;
    }
    else {
        _716 = 1;
    }
    _717 = _715 - _716;
    _715 = NOVALUE;
    _716 = NOVALUE;
    _718 = _717 + 1;
    _717 = NOVALUE;
    if (IS_SEQUENCE(_full_text_1728)){
            _719 = SEQ_PTR(_full_text_1728)->length;
    }
    else {
        _719 = 1;
    }
    rhs_slice_target = (object_ptr)&_720;
    RHS_Slice(_full_text_1728, _718, _719);
    if (_sub_text_1727 == _720)
    _721 = 1;
    else if (IS_ATOM_INT(_sub_text_1727) && IS_ATOM_INT(_720))
    _721 = 0;
    else
    _721 = (compare(_sub_text_1727, _720) == 0);
    DeRefDS(_720);
    _720 = NOVALUE;
    if (_721 == 0)
    {
        _721 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _721 = NOVALUE;
    }

    /** search.e:1043			return 1*/
    DeRefi(_sub_text_1727);
    DeRefDS(_full_text_1728);
    _718 = NOVALUE;
    return 1LL;
    goto L7; // [116] 126
L6: 

    /** search.e:1045			return 0*/
    DeRefi(_sub_text_1727);
    DeRefDS(_full_text_1728);
    DeRef(_718);
    _718 = NOVALUE;
    return 0LL;
L7: 
    ;
}



// 0xC1C40F15
