// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _18isLeap(object _year_2369)
{
    object _ly_2370 = NOVALUE;
    object _1061 = NOVALUE;
    object _1060 = NOVALUE;
    object _1059 = NOVALUE;
    object _1058 = NOVALUE;
    object _1057 = NOVALUE;
    object _1056 = NOVALUE;
    object _1055 = NOVALUE;
    object _1054 = NOVALUE;
    object _1053 = NOVALUE;
    object _1050 = NOVALUE;
    object _1048 = NOVALUE;
    object _1047 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:89			ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 4LL;
    ((intptr_t*)_2)[2] = 100LL;
    ((intptr_t*)_2)[3] = 400LL;
    ((intptr_t*)_2)[4] = 3200LL;
    ((intptr_t*)_2)[5] = 80000LL;
    _1047 = MAKE_SEQ(_1);
    _1048 = binary_op(REMAINDER, _year_2369, _1047);
    DeRefDS(_1047);
    _1047 = NOVALUE;
    DeRefi(_ly_2370);
    _ly_2370 = binary_op(EQUALS, _1048, 0LL);
    DeRefDS(_1048);
    _1048 = NOVALUE;

    /** datetime.e:91			if not ly[1] then return 0 end if*/
    _2 = (object)SEQ_PTR(_ly_2370);
    _1050 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_1050 != 0)
    goto L1; // [29] 37
    _1050 = NOVALUE;
    DeRefDSi(_ly_2370);
    return 0LL;
L1: 

    /** datetime.e:93			if year <= Gregorian_Reformation then*/
    if (_year_2369 > 1752LL)
    goto L2; // [39] 52

    /** datetime.e:94					return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_2370);
    return 1LL;
    goto L3; // [49] 95
L2: 

    /** datetime.e:96					return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (object)SEQ_PTR(_ly_2370);
    _1053 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_ly_2370);
    _1054 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1055 = _1053 - _1054;
    if ((object)((uintptr_t)_1055 +(uintptr_t) HIGH_BITS) >= 0){
        _1055 = NewDouble((eudouble)_1055);
    }
    _1053 = NOVALUE;
    _1054 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_2370);
    _1056 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_1055)) {
        _1057 = _1055 + _1056;
        if ((object)((uintptr_t)_1057 + (uintptr_t)HIGH_BITS) >= 0){
            _1057 = NewDouble((eudouble)_1057);
        }
    }
    else {
        _1057 = NewDouble(DBL_PTR(_1055)->dbl + (eudouble)_1056);
    }
    DeRef(_1055);
    _1055 = NOVALUE;
    _1056 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_2370);
    _1058 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_1057)) {
        _1059 = _1057 - _1058;
        if ((object)((uintptr_t)_1059 +(uintptr_t) HIGH_BITS) >= 0){
            _1059 = NewDouble((eudouble)_1059);
        }
    }
    else {
        _1059 = NewDouble(DBL_PTR(_1057)->dbl - (eudouble)_1058);
    }
    DeRef(_1057);
    _1057 = NOVALUE;
    _1058 = NOVALUE;
    _2 = (object)SEQ_PTR(_ly_2370);
    _1060 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_1059)) {
        _1061 = _1059 + _1060;
        if ((object)((uintptr_t)_1061 + (uintptr_t)HIGH_BITS) >= 0){
            _1061 = NewDouble((eudouble)_1061);
        }
    }
    else {
        _1061 = NewDouble(DBL_PTR(_1059)->dbl + (eudouble)_1060);
    }
    DeRef(_1059);
    _1059 = NOVALUE;
    _1060 = NOVALUE;
    DeRefDSi(_ly_2370);
    return _1061;
L3: 
    ;
}


object _18daysInMonth(object _year_2394, object _month_2395)
{
    object _1069 = NOVALUE;
    object _1068 = NOVALUE;
    object _1067 = NOVALUE;
    object _1066 = NOVALUE;
    object _1064 = NOVALUE;
    object _1063 = NOVALUE;
    object _1062 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_2395)) {
        _1 = (object)(DBL_PTR(_month_2395)->dbl);
        DeRefDS(_month_2395);
        _month_2395 = _1;
    }

    /** datetime.e:101		if year = Gregorian_Reformation and month = 9 then*/
    _1062 = (_year_2394 == 1752LL);
    if (_1062 == 0) {
        goto L1; // [11] 32
    }
    _1064 = (_month_2395 == 9LL);
    if (_1064 == 0)
    {
        DeRef(_1064);
        _1064 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_1064);
        _1064 = NOVALUE;
    }

    /** datetime.e:102			return 19*/
    DeRef(_1062);
    _1062 = NOVALUE;
    return 19LL;
    goto L2; // [29] 70
L1: 

    /** datetime.e:103		elsif month != 2 then*/
    if (_month_2395 == 2LL)
    goto L3; // [34] 51

    /** datetime.e:104			return DaysPerMonth[month]*/
    _2 = (object)SEQ_PTR(_18DaysPerMonth_2352);
    _1066 = (object)*(((s1_ptr)_2)->base + _month_2395);
    Ref(_1066);
    DeRef(_1062);
    _1062 = NOVALUE;
    return _1066;
    goto L2; // [48] 70
L3: 

    /** datetime.e:106			return DaysPerMonth[month] + isLeap(year)*/
    _2 = (object)SEQ_PTR(_18DaysPerMonth_2352);
    _1067 = (object)*(((s1_ptr)_2)->base + _month_2395);
    _1068 = _18isLeap(_year_2394);
    if (IS_ATOM_INT(_1067) && IS_ATOM_INT(_1068)) {
        _1069 = _1067 + _1068;
        if ((object)((uintptr_t)_1069 + (uintptr_t)HIGH_BITS) >= 0){
            _1069 = NewDouble((eudouble)_1069);
        }
    }
    else {
        _1069 = binary_op(PLUS, _1067, _1068);
    }
    _1067 = NOVALUE;
    DeRef(_1068);
    _1068 = NOVALUE;
    _1066 = NOVALUE;
    DeRef(_1062);
    _1062 = NOVALUE;
    return _1069;
L2: 
    ;
}


object _18julianDayOfYear(object _ymd_2418)
{
    object _year_2419 = NOVALUE;
    object _month_2420 = NOVALUE;
    object _day_2421 = NOVALUE;
    object _d_2422 = NOVALUE;
    object _1085 = NOVALUE;
    object _1084 = NOVALUE;
    object _1083 = NOVALUE;
    object _1080 = NOVALUE;
    object _1079 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:124		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_2418);
    _year_2419 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_year_2419)){
        _year_2419 = (object)DBL_PTR(_year_2419)->dbl;
    }

    /** datetime.e:125		month = ymd[2]*/
    _2 = (object)SEQ_PTR(_ymd_2418);
    _month_2420 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_month_2420)){
        _month_2420 = (object)DBL_PTR(_month_2420)->dbl;
    }

    /** datetime.e:126		day = ymd[3]*/
    _2 = (object)SEQ_PTR(_ymd_2418);
    _day_2421 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_day_2421)){
        _day_2421 = (object)DBL_PTR(_day_2421)->dbl;
    }

    /** datetime.e:128		if month = 1 then return day end if*/
    if (_month_2420 != 1LL)
    goto L1; // [27] 36
    DeRef(_ymd_2418);
    return _day_2421;
L1: 

    /** datetime.e:130		d = 0*/
    _d_2422 = 0LL;

    /** datetime.e:131		for i = 1 to month - 1 do*/
    _1079 = _month_2420 - 1LL;
    if ((object)((uintptr_t)_1079 +(uintptr_t) HIGH_BITS) >= 0){
        _1079 = NewDouble((eudouble)_1079);
    }
    {
        object _i_2429;
        _i_2429 = 1LL;
L2: 
        if (binary_op_a(GREATER, _i_2429, _1079)){
            goto L3; // [47] 74
        }

        /** datetime.e:132			d += daysInMonth(year, i)*/
        Ref(_i_2429);
        _1080 = _18daysInMonth(_year_2419, _i_2429);
        if (IS_ATOM_INT(_1080)) {
            _d_2422 = _d_2422 + _1080;
        }
        else {
            _d_2422 = binary_op(PLUS, _d_2422, _1080);
        }
        DeRef(_1080);
        _1080 = NOVALUE;
        if (!IS_ATOM_INT(_d_2422)) {
            _1 = (object)(DBL_PTR(_d_2422)->dbl);
            DeRefDS(_d_2422);
            _d_2422 = _1;
        }

        /** datetime.e:133		end for*/
        _0 = _i_2429;
        if (IS_ATOM_INT(_i_2429)) {
            _i_2429 = _i_2429 + 1LL;
            if ((object)((uintptr_t)_i_2429 +(uintptr_t) HIGH_BITS) >= 0){
                _i_2429 = NewDouble((eudouble)_i_2429);
            }
        }
        else {
            _i_2429 = binary_op_a(PLUS, _i_2429, 1LL);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_2429);
    }

    /** datetime.e:135		d += day*/
    _d_2422 = _d_2422 + _day_2421;

    /** datetime.e:137		if year = Gregorian_Reformation and month = 9 then*/
    _1083 = (_year_2419 == 1752LL);
    if (_1083 == 0) {
        goto L4; // [86] 128
    }
    _1085 = (_month_2420 == 9LL);
    if (_1085 == 0)
    {
        DeRef(_1085);
        _1085 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1085);
        _1085 = NOVALUE;
    }

    /** datetime.e:138			if day > 13 then*/
    if (_day_2421 <= 13LL)
    goto L5; // [100] 113

    /** datetime.e:139				d -= 11*/
    _d_2422 = _d_2422 - 11LL;
    goto L6; // [110] 127
L5: 

    /** datetime.e:140			elsif day > 2 then*/
    if (_day_2421 <= 2LL)
    goto L7; // [115] 126

    /** datetime.e:141				return 0*/
    DeRef(_ymd_2418);
    DeRef(_1083);
    _1083 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    return 0LL;
L7: 
L6: 
L4: 

    /** datetime.e:145		return d*/
    DeRef(_ymd_2418);
    DeRef(_1083);
    _1083 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    return _d_2422;
    ;
}


object _18julianDay(object _ymd_2445)
{
    object _year_2446 = NOVALUE;
    object _j_2447 = NOVALUE;
    object _greg00_2448 = NOVALUE;
    object _1114 = NOVALUE;
    object _1111 = NOVALUE;
    object _1108 = NOVALUE;
    object _1107 = NOVALUE;
    object _1106 = NOVALUE;
    object _1105 = NOVALUE;
    object _1104 = NOVALUE;
    object _1103 = NOVALUE;
    object _1102 = NOVALUE;
    object _1101 = NOVALUE;
    object _1099 = NOVALUE;
    object _1098 = NOVALUE;
    object _1097 = NOVALUE;
    object _1096 = NOVALUE;
    object _1095 = NOVALUE;
    object _1094 = NOVALUE;
    object _1093 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:152		year = ymd[1]*/
    _2 = (object)SEQ_PTR(_ymd_2445);
    _year_2446 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_year_2446)){
        _year_2446 = (object)DBL_PTR(_year_2446)->dbl;
    }

    /** datetime.e:153		j = julianDayOfYear(ymd)*/
    Ref(_ymd_2445);
    _j_2447 = _18julianDayOfYear(_ymd_2445);
    if (!IS_ATOM_INT(_j_2447)) {
        _1 = (object)(DBL_PTR(_j_2447)->dbl);
        DeRefDS(_j_2447);
        _j_2447 = _1;
    }

    /** datetime.e:155		year  -= 1*/
    _year_2446 = _year_2446 - 1LL;

    /** datetime.e:156		greg00 = year - Gregorian_Reformation00*/
    _greg00_2448 = _year_2446 - 1700LL;

    /** datetime.e:158		j += (*/
    {
        int128_t p128 = (int128_t)365LL * (int128_t)_year_2446;
        if( p128 != (int128_t)(_1093 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _1093 = NewDouble( (eudouble)p128 );
        }
    }
    if (4LL > 0 && _year_2446 >= 0) {
        _1094 = _year_2446 / 4LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_2446 / (eudouble)4LL);
        _1094 = (object)temp_dbl;
    }
    if (IS_ATOM_INT(_1093)) {
        _1095 = _1093 + _1094;
        if ((object)((uintptr_t)_1095 + (uintptr_t)HIGH_BITS) >= 0){
            _1095 = NewDouble((eudouble)_1095);
        }
    }
    else {
        _1095 = NewDouble(DBL_PTR(_1093)->dbl + (eudouble)_1094);
    }
    DeRef(_1093);
    _1093 = NOVALUE;
    _1094 = NOVALUE;
    _1096 = (_greg00_2448 > 0LL);
    if (100LL > 0 && _greg00_2448 >= 0) {
        _1097 = _greg00_2448 / 100LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_greg00_2448 / (eudouble)100LL);
        _1097 = (object)temp_dbl;
    }
    _1098 = - _1097;
    _1099 = (_greg00_2448 % 400LL) ? NewDouble((eudouble)_greg00_2448 / 400LL) : (_greg00_2448 / 400LL);
    if (IS_ATOM_INT(_1099)) {
        _1101 = NewDouble((eudouble)_1099 + DBL_PTR(_1100)->dbl);
    }
    else {
        _1101 = NewDouble(DBL_PTR(_1099)->dbl + DBL_PTR(_1100)->dbl);
    }
    DeRef(_1099);
    _1099 = NOVALUE;
    _1102 = unary_op(FLOOR, _1101);
    DeRefDS(_1101);
    _1101 = NOVALUE;
    if (IS_ATOM_INT(_1102)) {
        _1103 = _1098 + _1102;
        if ((object)((uintptr_t)_1103 + (uintptr_t)HIGH_BITS) >= 0){
            _1103 = NewDouble((eudouble)_1103);
        }
    }
    else {
        _1103 = binary_op(PLUS, _1098, _1102);
    }
    _1098 = NOVALUE;
    DeRef(_1102);
    _1102 = NOVALUE;
    if (IS_ATOM_INT(_1103)) {
        {
            int128_t p128 = (int128_t)_1096 * (int128_t)_1103;
            if( p128 != (int128_t)(_1104 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1104 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1104 = binary_op(MULTIPLY, _1096, _1103);
    }
    _1096 = NOVALUE;
    DeRef(_1103);
    _1103 = NOVALUE;
    if (IS_ATOM_INT(_1095) && IS_ATOM_INT(_1104)) {
        _1105 = _1095 + _1104;
        if ((object)((uintptr_t)_1105 + (uintptr_t)HIGH_BITS) >= 0){
            _1105 = NewDouble((eudouble)_1105);
        }
    }
    else {
        _1105 = binary_op(PLUS, _1095, _1104);
    }
    DeRef(_1095);
    _1095 = NOVALUE;
    DeRef(_1104);
    _1104 = NOVALUE;
    _1106 = (_year_2446 >= 1752LL);
    _1107 = 11LL * _1106;
    _1106 = NOVALUE;
    if (IS_ATOM_INT(_1105)) {
        _1108 = _1105 - _1107;
        if ((object)((uintptr_t)_1108 +(uintptr_t) HIGH_BITS) >= 0){
            _1108 = NewDouble((eudouble)_1108);
        }
    }
    else {
        _1108 = binary_op(MINUS, _1105, _1107);
    }
    DeRef(_1105);
    _1105 = NOVALUE;
    _1107 = NOVALUE;
    if (IS_ATOM_INT(_1108)) {
        _j_2447 = _j_2447 + _1108;
    }
    else {
        _j_2447 = binary_op(PLUS, _j_2447, _1108);
    }
    DeRef(_1108);
    _1108 = NOVALUE;
    if (!IS_ATOM_INT(_j_2447)) {
        _1 = (object)(DBL_PTR(_j_2447)->dbl);
        DeRefDS(_j_2447);
        _j_2447 = _1;
    }

    /** datetime.e:169		if year >= 3200 then*/
    if (_year_2446 < 3200LL)
    goto L1; // [97] 133

    /** datetime.e:170			j -= floor(year/ 3200)*/
    if (3200LL > 0 && _year_2446 >= 0) {
        _1111 = _year_2446 / 3200LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_2446 / (eudouble)3200LL);
        _1111 = (object)temp_dbl;
    }
    _j_2447 = _j_2447 - _1111;
    _1111 = NOVALUE;

    /** datetime.e:171			if year >= 80000 then*/
    if (_year_2446 < 80000LL)
    goto L2; // [115] 132

    /** datetime.e:172				j += floor(year/80000)*/
    if (80000LL > 0 && _year_2446 >= 0) {
        _1114 = _year_2446 / 80000LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_year_2446 / (eudouble)80000LL);
        _1114 = (object)temp_dbl;
    }
    _j_2447 = _j_2447 + _1114;
    _1114 = NOVALUE;
L2: 
L1: 

    /** datetime.e:176		return j*/
    DeRef(_ymd_2445);
    DeRef(_1097);
    _1097 = NOVALUE;
    return _j_2447;
    ;
}


object _18datetimeToSeconds(object _dt_2534)
{
    object _1158 = NOVALUE;
    object _1157 = NOVALUE;
    object _1156 = NOVALUE;
    object _1155 = NOVALUE;
    object _1154 = NOVALUE;
    object _1153 = NOVALUE;
    object _1152 = NOVALUE;
    object _1150 = NOVALUE;
    object _1149 = NOVALUE;
    object _1148 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:226		return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_2534);
    _1148 = _18julianDay(_dt_2534);
    if (IS_ATOM_INT(_1148)) {
        {
            int128_t p128 = (int128_t)_1148 * (int128_t)86400LL;
            if( p128 != (int128_t)(_1149 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1149 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1149 = binary_op(MULTIPLY, _1148, 86400LL);
    }
    DeRef(_1148);
    _1148 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_2534);
    _1150 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_1150)) {
        {
            int128_t p128 = (int128_t)_1150 * (int128_t)60LL;
            if( p128 != (int128_t)(_1152 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1152 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1152 = binary_op(MULTIPLY, _1150, 60LL);
    }
    _1150 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_2534);
    _1153 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_1152) && IS_ATOM_INT(_1153)) {
        _1154 = _1152 + _1153;
        if ((object)((uintptr_t)_1154 + (uintptr_t)HIGH_BITS) >= 0){
            _1154 = NewDouble((eudouble)_1154);
        }
    }
    else {
        _1154 = binary_op(PLUS, _1152, _1153);
    }
    DeRef(_1152);
    _1152 = NOVALUE;
    _1153 = NOVALUE;
    if (IS_ATOM_INT(_1154)) {
        {
            int128_t p128 = (int128_t)_1154 * (int128_t)60LL;
            if( p128 != (int128_t)(_1155 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _1155 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _1155 = binary_op(MULTIPLY, _1154, 60LL);
    }
    DeRef(_1154);
    _1154 = NOVALUE;
    if (IS_ATOM_INT(_1149) && IS_ATOM_INT(_1155)) {
        _1156 = _1149 + _1155;
        if ((object)((uintptr_t)_1156 + (uintptr_t)HIGH_BITS) >= 0){
            _1156 = NewDouble((eudouble)_1156);
        }
    }
    else {
        _1156 = binary_op(PLUS, _1149, _1155);
    }
    DeRef(_1149);
    _1149 = NOVALUE;
    DeRef(_1155);
    _1155 = NOVALUE;
    _2 = (object)SEQ_PTR(_dt_2534);
    _1157 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (IS_ATOM_INT(_1156) && IS_ATOM_INT(_1157)) {
        _1158 = _1156 + _1157;
        if ((object)((uintptr_t)_1158 + (uintptr_t)HIGH_BITS) >= 0){
            _1158 = NewDouble((eudouble)_1158);
        }
    }
    else {
        _1158 = binary_op(PLUS, _1156, _1157);
    }
    DeRef(_1156);
    _1156 = NOVALUE;
    _1157 = NOVALUE;
    DeRef(_dt_2534);
    return _1158;
    ;
}


object _18from_date(object _src_2701)
{
    object _1273 = NOVALUE;
    object _1272 = NOVALUE;
    object _1271 = NOVALUE;
    object _1270 = NOVALUE;
    object _1269 = NOVALUE;
    object _1268 = NOVALUE;
    object _1267 = NOVALUE;
    object _1265 = NOVALUE;
    object _0, _1, _2;
    

    /** datetime.e:513		return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (object)SEQ_PTR(_src_2701);
    _1265 = (object)*(((s1_ptr)_2)->base + 1LL);
    _1267 = _1265 + 1900LL;
    if ((object)((uintptr_t)_1267 + (uintptr_t)HIGH_BITS) >= 0){
        _1267 = NewDouble((eudouble)_1267);
    }
    _1265 = NOVALUE;
    _2 = (object)SEQ_PTR(_src_2701);
    _1268 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_src_2701);
    _1269 = (object)*(((s1_ptr)_2)->base + 3LL);
    _2 = (object)SEQ_PTR(_src_2701);
    _1270 = (object)*(((s1_ptr)_2)->base + 4LL);
    _2 = (object)SEQ_PTR(_src_2701);
    _1271 = (object)*(((s1_ptr)_2)->base + 5LL);
    _2 = (object)SEQ_PTR(_src_2701);
    _1272 = (object)*(((s1_ptr)_2)->base + 6LL);
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _1267;
    ((intptr_t*)_2)[2] = _1268;
    ((intptr_t*)_2)[3] = _1269;
    ((intptr_t*)_2)[4] = _1270;
    ((intptr_t*)_2)[5] = _1271;
    ((intptr_t*)_2)[6] = _1272;
    _1273 = MAKE_SEQ(_1);
    _1272 = NOVALUE;
    _1271 = NOVALUE;
    _1270 = NOVALUE;
    _1269 = NOVALUE;
    _1268 = NOVALUE;
    _1267 = NOVALUE;
    DeRefDSi(_src_2701);
    return _1273;
    ;
}


object _18new(object _year_2731, object _month_2732, object _day_2733, object _hour_2734, object _minute_2735, object _second_2736)
{
    object _d_2737 = NOVALUE;
    object _now_1__tmp_at41_2744 = NOVALUE;
    object _now_inlined_now_at_41_2743 = NOVALUE;
    object _1289 = NOVALUE;
    object _1288 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_2731)) {
        _1 = (object)(DBL_PTR(_year_2731)->dbl);
        DeRefDS(_year_2731);
        _year_2731 = _1;
    }
    if (!IS_ATOM_INT(_month_2732)) {
        _1 = (object)(DBL_PTR(_month_2732)->dbl);
        DeRefDS(_month_2732);
        _month_2732 = _1;
    }
    if (!IS_ATOM_INT(_day_2733)) {
        _1 = (object)(DBL_PTR(_day_2733)->dbl);
        DeRefDS(_day_2733);
        _day_2733 = _1;
    }
    if (!IS_ATOM_INT(_hour_2734)) {
        _1 = (object)(DBL_PTR(_hour_2734)->dbl);
        DeRefDS(_hour_2734);
        _hour_2734 = _1;
    }
    if (!IS_ATOM_INT(_minute_2735)) {
        _1 = (object)(DBL_PTR(_minute_2735)->dbl);
        DeRefDS(_minute_2735);
        _minute_2735 = _1;
    }

    /** datetime.e:587		d = {year, month, day, hour, minute, second}*/
    _0 = _d_2737;
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _year_2731;
    ((intptr_t*)_2)[2] = _month_2732;
    ((intptr_t*)_2)[3] = _day_2733;
    ((intptr_t*)_2)[4] = _hour_2734;
    ((intptr_t*)_2)[5] = _minute_2735;
    Ref(_second_2736);
    ((intptr_t*)_2)[6] = _second_2736;
    _d_2737 = MAKE_SEQ(_1);
    DeRef(_0);

    /** datetime.e:588		if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    ((intptr_t*)_2)[5] = 0LL;
    ((intptr_t*)_2)[6] = 0LL;
    _1288 = MAKE_SEQ(_1);
    if (_d_2737 == _1288)
    _1289 = 1;
    else if (IS_ATOM_INT(_d_2737) && IS_ATOM_INT(_1288))
    _1289 = 0;
    else
    _1289 = (compare(_d_2737, _1288) == 0);
    DeRefDS(_1288);
    _1288 = NOVALUE;
    if (_1289 == 0)
    {
        _1289 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1289 = NOVALUE;
    }

    /** datetime.e:589			return now()*/

    /** datetime.e:533		return from_date(date())*/
    DeRefi(_now_1__tmp_at41_2744);
    _now_1__tmp_at41_2744 = Date();
    RefDS(_now_1__tmp_at41_2744);
    _0 = _now_inlined_now_at_41_2743;
    _now_inlined_now_at_41_2743 = _18from_date(_now_1__tmp_at41_2744);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_2744);
    _now_1__tmp_at41_2744 = NOVALUE;
    DeRef(_second_2736);
    DeRef(_d_2737);
    return _now_inlined_now_at_41_2743;
    goto L2; // [57] 67
L1: 

    /** datetime.e:591			return d*/
    DeRef(_second_2736);
    return _d_2737;
L2: 
    ;
}



// 0xF4BF287D
