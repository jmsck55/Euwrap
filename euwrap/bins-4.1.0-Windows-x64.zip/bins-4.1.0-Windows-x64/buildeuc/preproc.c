// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _64is_file_newer(object _f1_24356, object _f2_24357)
{
    object _d1_24358 = NOVALUE;
    object _d2_24361 = NOVALUE;
    object _diff_2__tmp_at33_24370 = NOVALUE;
    object _diff_1__tmp_at33_24369 = NOVALUE;
    object _diff_inlined_diff_at_33_24368 = NOVALUE;
    object _13707 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:22		object d1 = file_timestamp(f1)*/
    RefDS(_f1_24356);
    _0 = _d1_24358;
    _d1_24358 = _17file_timestamp(_f1_24356);
    DeRef(_0);

    /** preproc.e:23		object d2 = file_timestamp(f2)*/
    RefDS(_f2_24357);
    _0 = _d2_24361;
    _d2_24361 = _17file_timestamp(_f2_24357);
    DeRef(_0);

    /** preproc.e:25		if atom(d2) then return 1 end if*/
    _13707 = IS_ATOM(_d2_24361);
    if (_13707 == 0)
    {
        _13707 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13707 = NOVALUE;
    }
    DeRefDS(_f1_24356);
    DeRefDS(_f2_24357);
    DeRef(_d1_24358);
    DeRef(_d2_24361);
    return 1LL;
L1: 

    /** preproc.e:27		if dt:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_24361);
    _0 = _diff_1__tmp_at33_24369;
    _diff_1__tmp_at33_24369 = _18datetimeToSeconds(_d2_24361);
    DeRef(_0);
    Ref(_d1_24358);
    _0 = _diff_2__tmp_at33_24370;
    _diff_2__tmp_at33_24370 = _18datetimeToSeconds(_d1_24358);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_24368);
    if (IS_ATOM_INT(_diff_1__tmp_at33_24369) && IS_ATOM_INT(_diff_2__tmp_at33_24370)) {
        _diff_inlined_diff_at_33_24368 = _diff_1__tmp_at33_24369 - _diff_2__tmp_at33_24370;
        if ((object)((uintptr_t)_diff_inlined_diff_at_33_24368 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_24368 = NewDouble((eudouble)_diff_inlined_diff_at_33_24368);
        }
    }
    else {
        _diff_inlined_diff_at_33_24368 = binary_op(MINUS, _diff_1__tmp_at33_24369, _diff_2__tmp_at33_24370);
    }
    DeRef(_diff_1__tmp_at33_24369);
    _diff_1__tmp_at33_24369 = NOVALUE;
    DeRef(_diff_2__tmp_at33_24370);
    _diff_2__tmp_at33_24370 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_24368, 0LL)){
        goto L2; // [49] 60
    }

    /** preproc.e:28			return 1*/
    DeRefDS(_f1_24356);
    DeRefDS(_f2_24357);
    DeRef(_d1_24358);
    DeRef(_d2_24361);
    return 1LL;
L2: 

    /** preproc.e:31		return 0*/
    DeRefDS(_f1_24356);
    DeRefDS(_f2_24357);
    DeRef(_d1_24358);
    DeRef(_d2_24361);
    return 0LL;
    ;
}


void _64add_preprocessor(object _file_ext_24374, object _command_24375, object _params_24376)
{
    object _tmp_24379 = NOVALUE;
    object _file_exts_24389 = NOVALUE;
    object _exts_24395 = NOVALUE;
    object _13724 = NOVALUE;
    object _13723 = NOVALUE;
    object _13722 = NOVALUE;
    object _13721 = NOVALUE;
    object _13719 = NOVALUE;
    object _13714 = NOVALUE;
    object _13709 = NOVALUE;
    object _0, _1, _2;
    

    /** preproc.e:46		if atom(command) then*/
    _13709 = 1;
    if (_13709 == 0)
    {
        _13709 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13709 = NOVALUE;
    }

    /** preproc.e:47			sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_24374);
    RefDS(_13710);
    _0 = _tmp_24379;
    _tmp_24379 = _23split(_file_ext_24374, _13710, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:48			file_ext = tmp[1]*/
    DeRefDS(_file_ext_24374);
    _2 = (object)SEQ_PTR(_tmp_24379);
    _file_ext_24374 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_file_ext_24374);

    /** preproc.e:49			command = tmp[2]*/
    _2 = (object)SEQ_PTR(_tmp_24379);
    _command_24375 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_command_24375);

    /** preproc.e:50			if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_24379)){
            _13714 = SEQ_PTR(_tmp_24379)->length;
    }
    else {
        _13714 = 1;
    }
    if (_13714 < 3LL)
    goto L2; // [41] 52

    /** preproc.e:51				params = tmp[3]*/
    _2 = (object)SEQ_PTR(_tmp_24379);
    _params_24376 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_params_24376);
L2: 
L1: 
    DeRef(_tmp_24379);
    _tmp_24379 = NOVALUE;

    /** preproc.e:55		sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_24374);
    RefDS(_13717);
    _0 = _file_exts_24389;
    _file_exts_24389 = _23split(_file_ext_24374, _13717, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:57		if atom(params) then*/
    _13719 = IS_ATOM(_params_24376);
    if (_13719 == 0)
    {
        _13719 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13719 = NOVALUE;
    }

    /** preproc.e:58			params = ""*/
    RefDS(_5);
    DeRef(_params_24376);
    _params_24376 = _5;
L3: 

    /** preproc.e:61		sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_24374);
    RefDS(_13717);
    _0 = _exts_24395;
    _exts_24395 = _23split(_file_ext_24374, _13717, 0LL, 0LL);
    DeRef(_0);

    /** preproc.e:62		for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_24395)){
            _13721 = SEQ_PTR(_exts_24395)->length;
    }
    else {
        _13721 = 1;
    }
    {
        object _i_24399;
        _i_24399 = 1LL;
L4: 
        if (_i_24399 > _13721){
            goto L5; // [96] 135
        }

        /** preproc.e:63			preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (object)SEQ_PTR(_exts_24395);
        _13722 = (object)*(((s1_ptr)_2)->base + _i_24399);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_13722);
        ((intptr_t*)_2)[1] = _13722;
        Ref(_command_24375);
        ((intptr_t*)_2)[2] = _command_24375;
        Ref(_params_24376);
        ((intptr_t*)_2)[3] = _params_24376;
        ((intptr_t*)_2)[4] = -1LL;
        _13723 = MAKE_SEQ(_1);
        _13722 = NOVALUE;
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _13723;
        _13724 = MAKE_SEQ(_1);
        _13723 = NOVALUE;
        Concat((object_ptr)&_37preprocessors_15654, _37preprocessors_15654, _13724);
        DeRefDS(_13724);
        _13724 = NOVALUE;

        /** preproc.e:64		end for*/
        _i_24399 = _i_24399 + 1LL;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** preproc.e:65	end procedure */
    DeRefDS(_file_ext_24374);
    DeRef(_command_24375);
    DeRef(_params_24376);
    DeRef(_file_exts_24389);
    DeRef(_exts_24395);
    return;
    ;
}


object _64maybe_preprocess(object _fname_24408)
{
    object _pp_24409 = NOVALUE;
    object _pp_id_24410 = NOVALUE;
    object _fext_24414 = NOVALUE;
    object _post_fname_24431 = NOVALUE;
    object _rid_24459 = NOVALUE;
    object _dll_id_24463 = NOVALUE;
    object _public_cmd_args_24499 = NOVALUE;
    object _cmd_args_24502 = NOVALUE;
    object _cmd_24531 = NOVALUE;
    object _pcmd_24536 = NOVALUE;
    object _result_24541 = NOVALUE;
    object _13803 = NOVALUE;
    object _13802 = NOVALUE;
    object _13797 = NOVALUE;
    object _13796 = NOVALUE;
    object _13794 = NOVALUE;
    object _13793 = NOVALUE;
    object _13791 = NOVALUE;
    object _13789 = NOVALUE;
    object _13788 = NOVALUE;
    object _13786 = NOVALUE;
    object _13783 = NOVALUE;
    object _13781 = NOVALUE;
    object _13779 = NOVALUE;
    object _13777 = NOVALUE;
    object _13776 = NOVALUE;
    object _13774 = NOVALUE;
    object _13773 = NOVALUE;
    object _13771 = NOVALUE;
    object _13768 = NOVALUE;
    object _13767 = NOVALUE;
    object _13766 = NOVALUE;
    object _13764 = NOVALUE;
    object _13760 = NOVALUE;
    object _13758 = NOVALUE;
    object _13757 = NOVALUE;
    object _13756 = NOVALUE;
    object _13752 = NOVALUE;
    object _13749 = NOVALUE;
    object _13748 = NOVALUE;
    object _13747 = NOVALUE;
    object _13745 = NOVALUE;
    object _13742 = NOVALUE;
    object _13740 = NOVALUE;
    object _13739 = NOVALUE;
    object _13737 = NOVALUE;
    object _13735 = NOVALUE;
    object _13733 = NOVALUE;
    object _13731 = NOVALUE;
    object _13730 = NOVALUE;
    object _13729 = NOVALUE;
    object _13728 = NOVALUE;
    object _13726 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** preproc.e:81		sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_24409);
    _pp_24409 = _5;

    /** preproc.e:84		if length(preprocessors) then*/
    if (IS_SEQUENCE(_37preprocessors_15654)){
            _13726 = SEQ_PTR(_37preprocessors_15654)->length;
    }
    else {
        _13726 = 1;
    }
    if (_13726 == 0)
    {
        _13726 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13726 = NOVALUE;
    }

    /** preproc.e:85			sequence fext = fileext(fname)*/
    RefDS(_fname_24408);
    _0 = _fext_24414;
    _fext_24414 = _17fileext(_fname_24408);
    DeRef(_0);

    /** preproc.e:87			for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_37preprocessors_15654)){
            _13728 = SEQ_PTR(_37preprocessors_15654)->length;
    }
    else {
        _13728 = 1;
    }
    {
        object _i_24418;
        _i_24418 = 1LL;
L2: 
        if (_i_24418 > _13728){
            goto L3; // [35] 88
        }

        /** preproc.e:88				if equal(fext, preprocessors[i][1]) then*/
        _2 = (object)SEQ_PTR(_37preprocessors_15654);
        _13729 = (object)*(((s1_ptr)_2)->base + _i_24418);
        _2 = (object)SEQ_PTR(_13729);
        _13730 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13729 = NOVALUE;
        if (_fext_24414 == _13730)
        _13731 = 1;
        else if (IS_ATOM_INT(_fext_24414) && IS_ATOM_INT(_13730))
        _13731 = 0;
        else
        _13731 = (compare(_fext_24414, _13730) == 0);
        _13730 = NOVALUE;
        if (_13731 == 0)
        {
            _13731 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13731 = NOVALUE;
        }

        /** preproc.e:89					pp_id = i*/
        _pp_id_24410 = _i_24418;

        /** preproc.e:90					pp = preprocessors[pp_id]*/
        DeRef(_pp_24409);
        _2 = (object)SEQ_PTR(_37preprocessors_15654);
        _pp_24409 = (object)*(((s1_ptr)_2)->base + _pp_id_24410);
        RefDS(_pp_24409);

        /** preproc.e:91					exit*/
        goto L3; // [78] 88
L4: 

        /** preproc.e:93			end for*/
        _i_24418 = _i_24418 + 1LL;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_24414);
    _fext_24414 = NOVALUE;

    /** preproc.e:96		if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_24409)){
            _13733 = SEQ_PTR(_pp_24409)->length;
    }
    else {
        _13733 = 1;
    }
    if (_13733 != 0LL)
    goto L5; // [96] 107

    /** preproc.e:97			return fname*/
    DeRefDS(_pp_24409);
    DeRef(_post_fname_24431);
    return _fname_24408;
L5: 

    /** preproc.e:100		sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_24408);
    _13735 = _17filebase(_fname_24408);
    RefDS(_fname_24408);
    _13737 = _17fileext(_fname_24408);
    {
        object concat_list[3];

        concat_list[0] = _13737;
        concat_list[1] = _13736;
        concat_list[2] = _13735;
        Concat_N((object_ptr)&_post_fname_24431, concat_list, 3);
    }
    DeRef(_13737);
    _13737 = NOVALUE;
    DeRef(_13735);
    _13735 = NOVALUE;

    /** preproc.e:101		if length(dirname(fname)) > 0 then*/
    RefDS(_fname_24408);
    _13739 = _17dirname(_fname_24408, 0LL);
    if (IS_SEQUENCE(_13739)){
            _13740 = SEQ_PTR(_13739)->length;
    }
    else {
        _13740 = 1;
    }
    DeRef(_13739);
    _13739 = NOVALUE;
    if (_13740 <= 0LL)
    goto L6; // [133] 153

    /** preproc.e:102			post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_24408);
    _13742 = _17dirname(_fname_24408, 0LL);
    {
        object concat_list[3];

        concat_list[0] = _post_fname_24431;
        concat_list[1] = 92LL;
        concat_list[2] = _13742;
        Concat_N((object_ptr)&_post_fname_24431, concat_list, 3);
    }
    DeRef(_13742);
    _13742 = NOVALUE;
L6: 

    /** preproc.e:105		if not force_preprocessor then*/
    if (_37force_preprocessor_15655 != 0)
    goto L7; // [157] 178

    /** preproc.e:106			if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_24408);
    RefDS(_post_fname_24431);
    _13745 = _64is_file_newer(_fname_24408, _post_fname_24431);
    if (IS_ATOM_INT(_13745)) {
        if (_13745 != 0){
            DeRef(_13745);
            _13745 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13745)->dbl != 0.0){
            DeRef(_13745);
            _13745 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13745);
    _13745 = NOVALUE;

    /** preproc.e:107				return post_fname*/
    DeRefDS(_fname_24408);
    DeRef(_pp_24409);
    _13739 = NOVALUE;
    return _post_fname_24431;
L8: 
L7: 

    /** preproc.e:112		if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13747 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13747);
    _13748 = _17fileext(_13747);
    _13747 = NOVALUE;
    if (_13748 == _17SHARED_LIB_EXT_6042)
    _13749 = 1;
    else if (IS_ATOM_INT(_13748) && IS_ATOM_INT(_17SHARED_LIB_EXT_6042))
    _13749 = 0;
    else
    _13749 = (compare(_13748, _17SHARED_LIB_EXT_6042) == 0);
    DeRef(_13748);
    _13748 = NOVALUE;
    if (_13749 == 0)
    {
        _13749 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13749 = NOVALUE;
    }

    /** preproc.e:113			integer rid = pp[PP_RID]*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _rid_24459 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_rid_24459))
    _rid_24459 = (object)DBL_PTR(_rid_24459)->dbl;

    /** preproc.e:114			if rid = -1 then*/
    if (_rid_24459 != -1LL)
    goto LA; // [205] 307

    /** preproc.e:115				integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13752 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13752);
    _dll_id_24463 = _12open_dll(_13752);
    _13752 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_24463)) {
        _1 = (object)(DBL_PTR(_dll_id_24463)->dbl);
        DeRefDS(_dll_id_24463);
        _dll_id_24463 = _1;
    }

    /** preproc.e:116				if dll_id = -1 then*/
    if (_dll_id_24463 != -1LL)
    goto LB; // [223] 247

    /** preproc.e:117					CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13756 = (object)*(((s1_ptr)_2)->base + 2LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13756);
    ((intptr_t*)_2)[1] = _13756;
    _13757 = MAKE_SEQ(_1);
    _13756 = NOVALUE;
    _13758 = EPrintf(-9999999, _13755, _13757);
    DeRefDS(_13757);
    _13757 = NOVALUE;
    RefDS(_22186);
    _50CompileErr(_13758, _22186, 1LL);
    _13758 = NOVALUE;
LB: 

    /** preproc.e:121				rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 134217732LL;
    ((intptr_t*)_2)[2] = 134217732LL;
    ((intptr_t*)_2)[3] = 134217732LL;
    _13760 = MAKE_SEQ(_1);
    RefDS(_13759);
    _rid_24459 = _12define_c_func(_dll_id_24463, _13759, _13760, 100663300LL);
    _13760 = NOVALUE;
    if (!IS_ATOM_INT(_rid_24459)) {
        _1 = (object)(DBL_PTR(_rid_24459)->dbl);
        DeRefDS(_rid_24459);
        _rid_24459 = _1;
    }

    /** preproc.e:123				if rid = -1 then*/
    if (_rid_24459 != -1LL)
    goto LC; // [274] 291

    /** preproc.e:124					CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13763);
    RefDS(_22186);
    _50CompileErr(_13763, _22186, 1LL);

    /** preproc.e:126					Cleanup(1)*/
    _50Cleanup(1LL);
LC: 

    /** preproc.e:129				preprocessors[pp_id][PP_RID] = rid*/
    _2 = (object)SEQ_PTR(_37preprocessors_15654);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37preprocessors_15654 = MAKE_SEQ(_2);
    }
    _3 = (object)(_pp_id_24410 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _rid_24459;
    DeRef(_1);
    _13764 = NOVALUE;
LA: 

    /** preproc.e:132			if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13766 = (object)*(((s1_ptr)_2)->base + 3LL);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_fname_24408);
    ((intptr_t*)_2)[1] = _fname_24408;
    RefDS(_post_fname_24431);
    ((intptr_t*)_2)[2] = _post_fname_24431;
    Ref(_13766);
    ((intptr_t*)_2)[3] = _13766;
    _13767 = MAKE_SEQ(_1);
    _13766 = NOVALUE;
    _13768 = call_c(1, _rid_24459, _13767);
    DeRefDS(_13767);
    _13767 = NOVALUE;
    if (binary_op_a(EQUALS, _13768, 0LL)){
        DeRef(_13768);
        _13768 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13768);
    _13768 = NOVALUE;

    /** preproc.e:133				CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13770);
    RefDS(_22186);
    _50CompileErr(_13770, _22186, 1LL);

    /** preproc.e:135				Cleanup(1)*/
    _50Cleanup(1LL);
LD: 
    goto LE; // [345] 520
L9: 

    /** preproc.e:138			sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13771 = (object)*(((s1_ptr)_2)->base + 2LL);
    _0 = _public_cmd_args_24499;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_13771);
    ((intptr_t*)_2)[1] = _13771;
    _public_cmd_args_24499 = MAKE_SEQ(_1);
    DeRef(_0);
    _13771 = NOVALUE;

    /** preproc.e:139			sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13773 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13773);
    _13774 = _17canonical_path(_13773, 0LL, 4LL);
    _13773 = NOVALUE;
    _0 = _cmd_args_24502;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _13774;
    _cmd_args_24502 = MAKE_SEQ(_1);
    DeRef(_0);
    _13774 = NOVALUE;

    /** preproc.e:141			if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (object)SEQ_PTR(_pp_24409);
    _13776 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_13776);
    _13777 = _17fileext(_13776);
    _13776 = NOVALUE;
    if (_13777 == _13778)
    _13779 = 1;
    else if (IS_ATOM_INT(_13777) && IS_ATOM_INT(_13778))
    _13779 = 0;
    else
    _13779 = (compare(_13777, _13778) == 0);
    DeRef(_13777);
    _13777 = NOVALUE;
    if (_13779 == 0)
    {
        _13779 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13779 = NOVALUE;
    }

    /** preproc.e:142				public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13780);
    ((intptr_t*)_2)[1] = _13780;
    _13781 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24499, _13781, _public_cmd_args_24499);
    DeRefDS(_13781);
    _13781 = NOVALUE;
    DeRef(_13781);
    _13781 = NOVALUE;

    /** preproc.e:143				cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13780);
    ((intptr_t*)_2)[1] = _13780;
    _13783 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_24502, _13783, _cmd_args_24502);
    DeRefDS(_13783);
    _13783 = NOVALUE;
    DeRef(_13783);
    _13783 = NOVALUE;
LF: 

    /** preproc.e:146			cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_24408);
    _13786 = _17canonical_path(_fname_24408, 0LL, 4LL);
    RefDS(_post_fname_24431);
    _13788 = _17canonical_path(_post_fname_24431, 0LL, 4LL);
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13785);
    ((intptr_t*)_2)[1] = _13785;
    ((intptr_t*)_2)[2] = _13786;
    RefDS(_13787);
    ((intptr_t*)_2)[3] = _13787;
    ((intptr_t*)_2)[4] = _13788;
    _13789 = MAKE_SEQ(_1);
    _13788 = NOVALUE;
    _13786 = NOVALUE;
    Concat((object_ptr)&_cmd_args_24502, _cmd_args_24502, _13789);
    DeRefDS(_13789);
    _13789 = NOVALUE;

    /** preproc.e:147			public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_13785);
    ((intptr_t*)_2)[1] = _13785;
    RefDS(_fname_24408);
    ((intptr_t*)_2)[2] = _fname_24408;
    RefDS(_13787);
    ((intptr_t*)_2)[3] = _13787;
    RefDS(_post_fname_24431);
    ((intptr_t*)_2)[4] = _post_fname_24431;
    _13791 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_24499, _public_cmd_args_24499, _13791);
    DeRefDS(_13791);
    _13791 = NOVALUE;

    /** preproc.e:148			sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_24502);
    _13793 = _4build_commandline(_cmd_args_24502);
    _2 = (object)SEQ_PTR(_pp_24409);
    _13794 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_SEQUENCE(_13793) && IS_ATOM(_13794)) {
        Ref(_13794);
        Append(&_cmd_24531, _13793, _13794);
    }
    else if (IS_ATOM(_13793) && IS_SEQUENCE(_13794)) {
        Ref(_13793);
        Prepend(&_cmd_24531, _13794, _13793);
    }
    else {
        Concat((object_ptr)&_cmd_24531, _13793, _13794);
        DeRef(_13793);
        _13793 = NOVALUE;
    }
    DeRef(_13793);
    _13793 = NOVALUE;
    _13794 = NOVALUE;

    /** preproc.e:149			sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_24499);
    _13796 = _4build_commandline(_public_cmd_args_24499);
    _2 = (object)SEQ_PTR(_pp_24409);
    _13797 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_SEQUENCE(_13796) && IS_ATOM(_13797)) {
        Ref(_13797);
        Append(&_pcmd_24536, _13796, _13797);
    }
    else if (IS_ATOM(_13796) && IS_SEQUENCE(_13797)) {
        Ref(_13796);
        Prepend(&_pcmd_24536, _13797, _13796);
    }
    else {
        Concat((object_ptr)&_pcmd_24536, _13796, _13797);
        DeRef(_13796);
        _13796 = NOVALUE;
    }
    DeRef(_13796);
    _13796 = NOVALUE;
    _13797 = NOVALUE;

    /** preproc.e:150			integer result = system_exec(cmd, 2)*/
    _result_24541 = system_exec_call(_cmd_24531, 2LL);

    /** preproc.e:151			if result != 0 then*/
    if (_result_24541 == 0LL)
    goto L10; // [492] 517

    /** preproc.e:152				CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_24536);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _result_24541;
    ((intptr_t *)_2)[2] = _pcmd_24536;
    _13802 = MAKE_SEQ(_1);
    _13803 = EPrintf(-9999999, _13801, _13802);
    DeRefDS(_13802);
    _13802 = NOVALUE;
    RefDS(_22186);
    _50CompileErr(_13803, _22186, 1LL);
    _13803 = NOVALUE;

    /** preproc.e:154				Cleanup(1)*/
    _50Cleanup(1LL);
L10: 
    DeRef(_public_cmd_args_24499);
    _public_cmd_args_24499 = NOVALUE;
    DeRef(_cmd_args_24502);
    _cmd_args_24502 = NOVALUE;
    DeRef(_cmd_24531);
    _cmd_24531 = NOVALUE;
    DeRef(_pcmd_24536);
    _pcmd_24536 = NOVALUE;
LE: 

    /** preproc.e:158		return post_fname*/
    DeRefDS(_fname_24408);
    DeRef(_pp_24409);
    _13739 = NOVALUE;
    return _post_fname_24431;
    ;
}



// 0x76075230
