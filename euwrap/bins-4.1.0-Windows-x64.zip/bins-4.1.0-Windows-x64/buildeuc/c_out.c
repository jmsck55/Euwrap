// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _55c_putc(object _c_46982)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_46982)) {
        _1 = (object)(DBL_PTR(_c_46982)->dbl);
        DeRefDS(_c_46982);
        _c_46982 = _1;
    }

    /** c_out.e:62		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:63			puts(c_code, c)*/
    EPuts(_55c_code_46972, _c_46982); // DJP 

    /** c_out.e:64			update_checksum( c )*/
    _56update_checksum(_c_46982);
L1: 

    /** c_out.e:66	end procedure*/
    return;
    ;
}


void _55c_hputs(object _c_source_46987)
{
    object _0, _1, _2;
    

    /** c_out.e:71		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_out.e:72			puts(c_h, c_source)    */
    EPuts(_55c_h_46973, _c_source_46987); // DJP 
L1: 

    /** c_out.e:74	end procedure*/
    DeRefDS(_c_source_46987);
    return;
    ;
}


void _55c_puts(object _c_source_46991)
{
    object _0, _1, _2;
    

    /** c_out.e:79		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** c_out.e:80			puts(c_code, c_source)*/
    EPuts(_55c_code_46972, _c_source_46991); // DJP 

    /** c_out.e:81			update_checksum( c_source )*/
    RefDS(_c_source_46991);
    _56update_checksum(_c_source_46991);
L1: 

    /** c_out.e:83	end procedure*/
    DeRefDS(_c_source_46991);
    return;
    ;
}


void _55c_hprintf(object _format_46996, object _value_46997)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_46997)) {
        _1 = (object)(DBL_PTR(_value_46997)->dbl);
        DeRefDS(_value_46997);
        _value_46997 = _1;
    }

    /** c_out.e:88		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** c_out.e:89			printf(c_h, format, value)*/
    EPrintf(_55c_h_46973, _format_46996, _value_46997);
L1: 

    /** c_out.e:91	end procedure*/
    DeRefDSi(_format_46996);
    return;
    ;
}


void _55c_printf(object _format_47001, object _value_47002)
{
    object _text_47004 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:96		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** c_out.e:97			sequence text = sprintf( format, value )*/
    DeRefi(_text_47004);
    _text_47004 = EPrintf(-9999999, _format_47001, _value_47002);

    /** c_out.e:98			puts(c_code, text)*/
    EPuts(_55c_code_46972, _text_47004); // DJP 

    /** c_out.e:99			update_checksum( text )*/
    RefDS(_text_47004);
    _56update_checksum(_text_47004);
L1: 
    DeRefi(_text_47004);
    _text_47004 = NOVALUE;

    /** c_out.e:101	end procedure*/
    DeRefDSi(_format_47001);
    DeRef(_value_47002);
    return;
    ;
}


void _55c_printf8(object _value_47015)
{
    object _buff_47016 = NOVALUE;
    object _neg_47017 = NOVALUE;
    object _p_47018 = NOVALUE;
    object _24444 = NOVALUE;
    object _24443 = NOVALUE;
    object _24442 = NOVALUE;
    object _24440 = NOVALUE;
    object _24439 = NOVALUE;
    object _24437 = NOVALUE;
    object _24436 = NOVALUE;
    object _24434 = NOVALUE;
    object _24433 = NOVALUE;
    object _24431 = NOVALUE;
    object _24429 = NOVALUE;
    object _24427 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:115		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [5] 217
    }
    else{
    }

    /** c_out.e:116			neg = 0*/
    _neg_47017 = 0LL;

    /** c_out.e:117			buff = sprintf("%.20eL", value)*/
    DeRef(_buff_47016);
    _buff_47016 = EPrintf(-9999999, _24425, _value_47015);

    /** c_out.e:118			if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_47016)){
            _24427 = SEQ_PTR(_buff_47016)->length;
    }
    else {
        _24427 = 1;
    }
    if (_24427 >= 10LL)
    goto L2; // [24] 209

    /** c_out.e:120				p = 1*/
    _p_47018 = 1LL;

    /** c_out.e:121				while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_47016)){
            _24429 = SEQ_PTR(_buff_47016)->length;
    }
    else {
        _24429 = 1;
    }
    if (_p_47018 > _24429)
    goto L4; // [41] 208

    /** c_out.e:122					if buff[p] = '-' then*/
    _2 = (object)SEQ_PTR(_buff_47016);
    _24431 = (object)*(((s1_ptr)_2)->base + _p_47018);
    if (binary_op_a(NOTEQ, _24431, 45LL)){
        _24431 = NOVALUE;
        goto L5; // [51] 63
    }
    _24431 = NOVALUE;

    /** c_out.e:123						neg = 1*/
    _neg_47017 = 1LL;
    goto L6; // [60] 197
L5: 

    /** c_out.e:125					elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (object)SEQ_PTR(_buff_47016);
    _24433 = (object)*(((s1_ptr)_2)->base + _p_47018);
    if (IS_ATOM_INT(_24433)) {
        _24434 = (_24433 == 105LL);
    }
    else {
        _24434 = binary_op(EQUALS, _24433, 105LL);
    }
    _24433 = NOVALUE;
    if (IS_ATOM_INT(_24434)) {
        if (_24434 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_24434)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (object)SEQ_PTR(_buff_47016);
    _24436 = (object)*(((s1_ptr)_2)->base + _p_47018);
    if (IS_ATOM_INT(_24436)) {
        _24437 = (_24436 == 73LL);
    }
    else {
        _24437 = binary_op(EQUALS, _24436, 73LL);
    }
    _24436 = NOVALUE;
    if (_24437 == 0) {
        DeRef(_24437);
        _24437 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_24437) && DBL_PTR(_24437)->dbl == 0.0){
            DeRef(_24437);
            _24437 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_24437);
        _24437 = NOVALUE;
    }
    DeRef(_24437);
    _24437 = NOVALUE;
L7: 

    /** c_out.e:127						buff = CREATE_INF*/
    RefDS(_55CREATE_INF_47007);
    DeRef(_buff_47016);
    _buff_47016 = _55CREATE_INF_47007;

    /** c_out.e:128						if neg then*/
    if (_neg_47017 == 0)
    {
        goto L4; // [97] 208
    }
    else{
    }

    /** c_out.e:129							buff = prepend(buff, '-')*/
    Prepend(&_buff_47016, _buff_47016, 45LL);

    /** c_out.e:131						exit*/
    goto L4; // [109] 208
    goto L6; // [111] 197
L8: 

    /** c_out.e:133					elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (object)SEQ_PTR(_buff_47016);
    _24439 = (object)*(((s1_ptr)_2)->base + _p_47018);
    if (IS_ATOM_INT(_24439)) {
        _24440 = (_24439 == 110LL);
    }
    else {
        _24440 = binary_op(EQUALS, _24439, 110LL);
    }
    _24439 = NOVALUE;
    if (IS_ATOM_INT(_24440)) {
        if (_24440 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_24440)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (object)SEQ_PTR(_buff_47016);
    _24442 = (object)*(((s1_ptr)_2)->base + _p_47018);
    if (IS_ATOM_INT(_24442)) {
        _24443 = (_24442 == 78LL);
    }
    else {
        _24443 = binary_op(EQUALS, _24442, 78LL);
    }
    _24442 = NOVALUE;
    if (_24443 == 0) {
        DeRef(_24443);
        _24443 = NOVALUE;
        goto LA; // [137] 196
    }
    else {
        if (!IS_ATOM_INT(_24443) && DBL_PTR(_24443)->dbl == 0.0){
            DeRef(_24443);
            _24443 = NOVALUE;
            goto LA; // [137] 196
        }
        DeRef(_24443);
        _24443 = NOVALUE;
    }
    DeRef(_24443);
    _24443 = NOVALUE;
L9: 

    /** c_out.e:135						ifdef UNIX then*/

    /** c_out.e:141							if sequence(wat_path) then*/
    _24444 = IS_SEQUENCE(_36wat_path_21840);
    if (_24444 == 0)
    {
        _24444 = NOVALUE;
        goto LB; // [150] 173
    }
    else{
        _24444 = NOVALUE;
    }

    /** c_out.e:142								buff = CREATE_NAN2*/
    RefDS(_55CREATE_NAN2_47011);
    DeRef(_buff_47016);
    _buff_47016 = _55CREATE_NAN2_47011;

    /** c_out.e:143								if not neg then*/
    if (_neg_47017 != 0)
    goto L4; // [160] 208

    /** c_out.e:144									buff = prepend(buff, '-')*/
    Prepend(&_buff_47016, _buff_47016, 45LL);
    goto L4; // [170] 208
LB: 

    /** c_out.e:148								buff = CREATE_NAN1*/
    RefDS(_55CREATE_NAN1_47009);
    DeRef(_buff_47016);
    _buff_47016 = _55CREATE_NAN1_47009;

    /** c_out.e:149								if neg then*/
    if (_neg_47017 == 0)
    {
        goto L4; // [180] 208
    }
    else{
    }

    /** c_out.e:150									buff = prepend(buff, '-')*/
    Prepend(&_buff_47016, _buff_47016, 45LL);

    /** c_out.e:153							exit*/
    goto L4; // [193] 208
LA: 
L6: 

    /** c_out.e:156					p += 1*/
    _p_47018 = _p_47018 + 1;

    /** c_out.e:157				end while*/
    goto L3; // [205] 38
L4: 
L2: 

    /** c_out.e:159			puts(c_code, buff)*/
    EPuts(_55c_code_46972, _buff_47016); // DJP 
L1: 

    /** c_out.e:161	end procedure*/
    DeRef(_value_47015);
    DeRef(_buff_47016);
    DeRef(_24434);
    _24434 = NOVALUE;
    DeRef(_24440);
    _24440 = NOVALUE;
    return;
    ;
}


void _55adjust_indent_before(object _stmt_47061)
{
    object _i_47062 = NOVALUE;
    object _lb_47064 = NOVALUE;
    object _rb_47065 = NOVALUE;
    object _24461 = NOVALUE;
    object _24459 = NOVALUE;
    object _24457 = NOVALUE;
    object _24451 = NOVALUE;
    object _24450 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:177		lb = FALSE*/
    _lb_47064 = _13FALSE_445;

    /** c_out.e:178		rb = FALSE*/
    _rb_47065 = _13FALSE_445;

    /** c_out.e:180		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47061)){
            _24450 = SEQ_PTR(_stmt_47061)->length;
    }
    else {
        _24450 = 1;
    }
    {
        object _p_47069;
        _p_47069 = 1LL;
L1: 
        if (_p_47069 > _24450){
            goto L2; // [22] 102
        }

        /** c_out.e:181			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47061);
        _24451 = (object)*(((s1_ptr)_2)->base + _p_47069);
        if (IS_SEQUENCE(_24451) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_24451)){
            if( (DBL_PTR(_24451)->dbl != (eudouble) ((object) DBL_PTR(_24451)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (object) DBL_PTR(_24451)->dbl;
        }
        else {
            _0 = _24451;
        };
        _24451 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:182				case '\n' then*/
            case 10:

            /** c_out.e:183					exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** c_out.e:185				case  '}' then*/
            case 125:

            /** c_out.e:186					rb = TRUE*/
            _rb_47065 = _13TRUE_447;

            /** c_out.e:187					if lb then*/
            if (_lb_47064 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** c_out.e:188						exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** c_out.e:191				case '{' then*/
            case 123:

            /** c_out.e:192					lb = TRUE*/
            _lb_47064 = _13TRUE_447;

            /** c_out.e:193					if rb then */
            if (_rb_47065 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** c_out.e:194						exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** c_out.e:198		end for*/
        _p_47069 = _p_47069 + 1LL;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** c_out.e:200		if rb then*/
    if (_rb_47065 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** c_out.e:201			if not lb then*/
    if (_lb_47064 != 0)
    goto L6; // [109] 121

    /** c_out.e:202				indent -= 4*/
    _55indent_47055 = _55indent_47055 - 4LL;
L6: 
L5: 

    /** c_out.e:206		i = indent + temp_indent*/
    _i_47062 = _55indent_47055 + _55temp_indent_47056;

    /** c_out.e:207		while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_55big_blanks_47057)){
            _24457 = SEQ_PTR(_55big_blanks_47057)->length;
    }
    else {
        _24457 = 1;
    }
    if (_i_47062 < _24457)
    goto L8; // [140] 163

    /** c_out.e:208			c_puts(big_blanks)*/
    RefDS(_55big_blanks_47057);
    _55c_puts(_55big_blanks_47057);

    /** c_out.e:209			i -= length(big_blanks)*/
    if (IS_SEQUENCE(_55big_blanks_47057)){
            _24459 = SEQ_PTR(_55big_blanks_47057)->length;
    }
    else {
        _24459 = 1;
    }
    _i_47062 = _i_47062 - _24459;
    _24459 = NOVALUE;

    /** c_out.e:210		end while*/
    goto L7; // [160] 137
L8: 

    /** c_out.e:212		c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_24461;
    RHS_Slice(_55big_blanks_47057, 1LL, _i_47062);
    _55c_puts(_24461);
    _24461 = NOVALUE;

    /** c_out.e:214		temp_indent = 0    */
    _55temp_indent_47056 = 0LL;

    /** c_out.e:215	end procedure*/
    DeRefDS(_stmt_47061);
    return;
    ;
}


void _55adjust_indent_after(object _stmt_47094)
{
    object _24482 = NOVALUE;
    object _24481 = NOVALUE;
    object _24479 = NOVALUE;
    object _24477 = NOVALUE;
    object _24476 = NOVALUE;
    object _24473 = NOVALUE;
    object _24471 = NOVALUE;
    object _24470 = NOVALUE;
    object _24467 = NOVALUE;
    object _24463 = NOVALUE;
    object _24462 = NOVALUE;
    object _0, _1, _2;
    

    /** c_out.e:221		for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_47094)){
            _24462 = SEQ_PTR(_stmt_47094)->length;
    }
    else {
        _24462 = 1;
    }
    {
        object _p_47096;
        _p_47096 = 1LL;
L1: 
        if (_p_47096 > _24462){
            goto L2; // [8] 61
        }

        /** c_out.e:222			switch stmt[p] do*/
        _2 = (object)SEQ_PTR(_stmt_47094);
        _24463 = (object)*(((s1_ptr)_2)->base + _p_47096);
        if (IS_SEQUENCE(_24463) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_24463)){
            if( (DBL_PTR(_24463)->dbl != (eudouble) ((object) DBL_PTR(_24463)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (object) DBL_PTR(_24463)->dbl;
        }
        else {
            _0 = _24463;
        };
        _24463 = NOVALUE;
        switch ( _0 ){ 

            /** c_out.e:223				case '\n' then*/
            case 10:

            /** c_out.e:224					exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** c_out.e:226				case '{' then*/
            case 123:

            /** c_out.e:227					indent += 4*/
            _55indent_47055 = _55indent_47055 + 4LL;

            /** c_out.e:228					return*/
            DeRefDS(_stmt_47094);
            return;
        ;}L3: 

        /** c_out.e:230		end for*/
        _p_47096 = _p_47096 + 1LL;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** c_out.e:232		if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_47094)){
            _24467 = SEQ_PTR(_stmt_47094)->length;
    }
    else {
        _24467 = 1;
    }
    if (_24467 >= 3LL)
    goto L4; // [66] 76

    /** c_out.e:233			return*/
    DeRefDS(_stmt_47094);
    return;
L4: 

    /** c_out.e:236		if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_24470;
    RHS_Slice(_stmt_47094, 1LL, 3LL);
    if (_24469 == _24470)
    _24471 = 1;
    else if (IS_ATOM_INT(_24469) && IS_ATOM_INT(_24470))
    _24471 = 0;
    else
    _24471 = (compare(_24469, _24470) == 0);
    DeRefDS(_24470);
    _24470 = NOVALUE;
    if (_24471 != 0)
    goto L5; // [87] 96
    _24471 = NOVALUE;

    /** c_out.e:237			return*/
    DeRefDS(_stmt_47094);
    return;
L5: 

    /** c_out.e:240		if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_47094)){
            _24473 = SEQ_PTR(_stmt_47094)->length;
    }
    else {
        _24473 = 1;
    }
    if (_24473 >= 5LL)
    goto L6; // [101] 111

    /** c_out.e:241			return*/
    DeRefDS(_stmt_47094);
    return;
L6: 

    /** c_out.e:244		if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_24476;
    RHS_Slice(_stmt_47094, 1LL, 4LL);
    if (_24475 == _24476)
    _24477 = 1;
    else if (IS_ATOM_INT(_24475) && IS_ATOM_INT(_24476))
    _24477 = 0;
    else
    _24477 = (compare(_24475, _24476) == 0);
    DeRefDS(_24476);
    _24476 = NOVALUE;
    if (_24477 != 0)
    goto L7; // [122] 131
    _24477 = NOVALUE;

    /** c_out.e:245			return*/
    DeRefDS(_stmt_47094);
    return;
L7: 

    /** c_out.e:248		if not find(stmt[5], {" \n"}) then*/
    _2 = (object)SEQ_PTR(_stmt_47094);
    _24479 = (object)*(((s1_ptr)_2)->base + 5LL);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_24480);
    ((intptr_t*)_2)[1] = _24480;
    _24481 = MAKE_SEQ(_1);
    _24482 = find_from(_24479, _24481, 1LL);
    _24479 = NOVALUE;
    DeRefDS(_24481);
    _24481 = NOVALUE;
    if (_24482 != 0)
    goto L8; // [146] 155
    _24482 = NOVALUE;

    /** c_out.e:249			return*/
    DeRefDS(_stmt_47094);
    return;
L8: 

    /** c_out.e:252		temp_indent = 4*/
    _55temp_indent_47056 = 4LL;

    /** c_out.e:254	end procedure*/
    DeRefDS(_stmt_47094);
    return;
    ;
}



// 0x08735970
