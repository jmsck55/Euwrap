// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _62set_qualified_fwd(object _fwd_25902)
{
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_25902)) {
        _1 = (object)(DBL_PTR(_fwd_25902)->dbl);
        DeRefDS(_fwd_25902);
        _fwd_25902 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25899 = _fwd_25902;

    /** scanner.e:105	end procedure*/
    return;
    ;
}


object _62get_qualified_fwd()
{
    object _fwd_25905 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:108		integer fwd = qualified_fwd*/
    _fwd_25905 = _62qualified_fwd_25899;

    /** scanner.e:109		set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25899 = -1LL;

    /** scanner.e:105	end procedure*/
    goto L1; // [17] 20
L1: 

    /** scanner.e:110		return fwd*/
    return _fwd_25905;
    ;
}


void _62InitLex()
{
    object _14439 = NOVALUE;
    object _14438 = NOVALUE;
    object _14437 = NOVALUE;
    object _14435 = NOVALUE;
    object _14434 = NOVALUE;
    object _14433 = NOVALUE;
    object _14432 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:117		gline_number = 0*/
    _36gline_number_21764 = 0LL;

    /** scanner.e:118		line_number = 0*/
    _36line_number_21760 = 0LL;

    /** scanner.e:119		IncludeStk = {}*/
    RefDS(_5);
    DeRef(_62IncludeStk_25876);
    _62IncludeStk_25876 = _5;

    /** scanner.e:120		char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_62char_class_25874);
    _62char_class_25874 = Repeat(-20LL, 255LL);

    /** scanner.e:122		char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25874;
    AssignSlice(48LL, 57LL, -7LL);

    /** scanner.e:123		char_class['_']      = DIGIT*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 95LL);
    *(intptr_t *)_2 = -7LL;

    /** scanner.e:124		char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25874;
    AssignSlice(97LL, 122LL, -2LL);

    /** scanner.e:125		char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_62char_class_25874;
    AssignSlice(65LL, 90LL, -2LL);

    /** scanner.e:126		char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _14432 = 129;
    _14433 = 152LL;
    assign_slice_seq = (s1_ptr *)&_62char_class_25874;
    AssignSlice(129LL, 152LL, -10LL);
    _14432 = NOVALUE;
    _14433 = NOVALUE;

    /** scanner.e:127		char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _14434 = 171;
    _14435 = 234LL;
    assign_slice_seq = (s1_ptr *)&_62char_class_25874;
    AssignSlice(171LL, 234LL, -9LL);
    _14434 = NOVALUE;
    _14435 = NOVALUE;

    /** scanner.e:129		char_class[' '] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    *(intptr_t *)_2 = -8LL;

    /** scanner.e:130		char_class['\t'] = BLANK*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    *(intptr_t *)_2 = -8LL;

    /** scanner.e:131		char_class['+'] = PLUS*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    *(intptr_t *)_2 = 11LL;

    /** scanner.e:132		char_class['-'] = MINUS*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    *(intptr_t *)_2 = 10LL;

    /** scanner.e:133		char_class['*'] = res:MULTIPLY*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    *(intptr_t *)_2 = 13LL;

    /** scanner.e:134		char_class['/'] = res:DIVIDE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    *(intptr_t *)_2 = 14LL;

    /** scanner.e:135		char_class['='] = EQUALS*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 61LL);
    *(intptr_t *)_2 = 3LL;

    /** scanner.e:136		char_class['<'] = LESS*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 60LL);
    *(intptr_t *)_2 = 1LL;

    /** scanner.e:137		char_class['>'] = GREATER*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 62LL);
    *(intptr_t *)_2 = 6LL;

    /** scanner.e:138		char_class['\''] = SINGLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    *(intptr_t *)_2 = -5LL;

    /** scanner.e:139		char_class['"'] = DOUBLE_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    *(intptr_t *)_2 = -4LL;

    /** scanner.e:140		char_class['`'] = BACK_QUOTE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 96LL);
    *(intptr_t *)_2 = -12LL;

    /** scanner.e:141		char_class['.'] = DOT*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    *(intptr_t *)_2 = -3LL;

    /** scanner.e:142		char_class[':'] = COLON*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 58LL);
    *(intptr_t *)_2 = -23LL;

    /** scanner.e:143		char_class['\r'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 13LL);
    *(intptr_t *)_2 = -6LL;

    /** scanner.e:144		char_class['\n'] = NEWLINE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 10LL);
    *(intptr_t *)_2 = -6LL;

    /** scanner.e:145		char_class['!'] = BANG*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    *(intptr_t *)_2 = -1LL;

    /** scanner.e:146		char_class['{'] = LEFT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 123LL);
    *(intptr_t *)_2 = -24LL;

    /** scanner.e:147		char_class['}'] = RIGHT_BRACE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 125LL);
    *(intptr_t *)_2 = -25LL;

    /** scanner.e:148		char_class['('] = LEFT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    *(intptr_t *)_2 = -26LL;

    /** scanner.e:149		char_class[')'] = RIGHT_ROUND*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    *(intptr_t *)_2 = -27LL;

    /** scanner.e:150		char_class['['] = LEFT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 91LL);
    *(intptr_t *)_2 = -28LL;

    /** scanner.e:151		char_class[']'] = RIGHT_SQUARE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 93LL);
    *(intptr_t *)_2 = -29LL;

    /** scanner.e:152		char_class['$'] = DOLLAR*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    *(intptr_t *)_2 = -22LL;

    /** scanner.e:153		char_class[','] = COMMA*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    *(intptr_t *)_2 = -30LL;

    /** scanner.e:154		char_class['&'] = res:CONCAT*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    *(intptr_t *)_2 = 15LL;

    /** scanner.e:155		char_class['?'] = QUESTION_MARK*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 63LL);
    *(intptr_t *)_2 = -31LL;

    /** scanner.e:156		char_class['#'] = NUMBER_SIGN*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    *(intptr_t *)_2 = -11LL;

    /** scanner.e:159		char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _2 = (object)(((s1_ptr)_2)->base + 26LL);
    *(intptr_t *)_2 = -21LL;

    /** scanner.e:162		id_char = repeat(FALSE, 255)*/
    DeRefi(_62id_char_25875);
    _62id_char_25875 = Repeat(_13FALSE_445, 255LL);

    /** scanner.e:163		for i = 1 to 255 do*/
    {
        object _i_25953;
        _i_25953 = 1LL;
L1: 
        if (_i_25953 > 255LL){
            goto L2; // [407] 456
        }

        /** scanner.e:164			if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (object)SEQ_PTR(_62char_class_25874);
        _14437 = (object)*(((s1_ptr)_2)->base + _i_25953);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = -2LL;
        ((intptr_t *)_2)[2] = -7LL;
        _14438 = MAKE_SEQ(_1);
        _14439 = find_from(_14437, _14438, 1LL);
        _14437 = NOVALUE;
        DeRefDS(_14438);
        _14438 = NOVALUE;
        if (_14439 == 0)
        {
            _14439 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _14439 = NOVALUE;
        }

        /** scanner.e:165				id_char[i] = TRUE*/
        _2 = (object)SEQ_PTR(_62id_char_25875);
        _2 = (object)(((s1_ptr)_2)->base + _i_25953);
        *(intptr_t *)_2 = _13TRUE_447;
L3: 

        /** scanner.e:167		end for*/
        _i_25953 = _i_25953 + 1LL;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** scanner.e:169		default_namespaces = {0}*/
    _0 = _62default_namespaces_25873;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    _62default_namespaces_25873 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:170	end procedure*/
    return;
    ;
}


void _62ResetTP()
{
    object _0, _1, _2;
    

    /** scanner.e:174		OpTrace = FALSE*/
    _36OpTrace_21832 = _13FALSE_445;

    /** scanner.e:175		OpProfileStatement = FALSE*/
    _36OpProfileStatement_21834 = _13FALSE_445;

    /** scanner.e:176		OpProfileTime = FALSE*/
    _36OpProfileTime_21835 = _13FALSE_445;

    /** scanner.e:177		AnyStatementProfile = FALSE*/
    _37AnyStatementProfile_15660 = _13FALSE_445;

    /** scanner.e:178		AnyTimeProfile = FALSE*/
    _37AnyTimeProfile_15659 = _13FALSE_445;

    /** scanner.e:179	end procedure*/
    return;
    ;
}


object _62pack_source(object _src_25983)
{
    object _start_25984 = NOVALUE;
    object _14463 = NOVALUE;
    object _14462 = NOVALUE;
    object _14461 = NOVALUE;
    object _14460 = NOVALUE;
    object _14458 = NOVALUE;
    object _14456 = NOVALUE;
    object _14455 = NOVALUE;
    object _14454 = NOVALUE;
    object _14450 = NOVALUE;
    object _14448 = NOVALUE;
    object _14447 = NOVALUE;
    object _14444 = NOVALUE;
    object _14443 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:197		if equal(src, 0) then*/
    if (_src_25983 == 0LL)
    _14443 = 1;
    else if (IS_ATOM_INT(_src_25983) && IS_ATOM_INT(0LL))
    _14443 = 0;
    else
    _14443 = (compare(_src_25983, 0LL) == 0);
    if (_14443 == 0)
    {
        _14443 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _14443 = NOVALUE;
    }

    /** scanner.e:198			return 0*/
    DeRef(_src_25983);
    return 0LL;
L1: 

    /** scanner.e:201		if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25983)){
            _14444 = SEQ_PTR(_src_25983)->length;
    }
    else {
        _14444 = 1;
    }
    if (_14444 < 10000LL)
    goto L2; // [22] 34

    /** scanner.e:202			src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_25983;
    RHS_Slice(_src_25983, 1LL, 100LL);
L2: 

    /** scanner.e:205		if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_25983)){
            _14447 = SEQ_PTR(_src_25983)->length;
    }
    else {
        _14447 = 1;
    }
    _14448 = _62current_source_next_25979 + _14447;
    if ((object)((uintptr_t)_14448 + (uintptr_t)HIGH_BITS) >= 0){
        _14448 = NewDouble((eudouble)_14448);
    }
    _14447 = NOVALUE;
    if (binary_op_a(LESS, _14448, 10000LL)){
        DeRef(_14448);
        _14448 = NOVALUE;
        goto L3; // [45] 96
    }
    DeRef(_14448);
    _14448 = NOVALUE;

    /** scanner.e:207			current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _14450 = 10400LL;
    _0 = _9allocate(10400LL, 0LL);
    DeRef(_62current_source_25978);
    _62current_source_25978 = _0;
    _14450 = NOVALUE;

    /** scanner.e:208			if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _62current_source_25978, 0LL)){
        goto L4; // [64] 78
    }

    /** scanner.e:209				CompileErr(OUT_OF_MEMORY__TURN_OFF_TRACE_AND_PROFILE)*/
    RefDS(_22186);
    _50CompileErr(123LL, _22186, 0LL);
L4: 

    /** scanner.e:211			all_source = append(all_source, current_source)*/
    Ref(_62current_source_25978);
    Append(&_37all_source_15661, _37all_source_15661, _62current_source_25978);

    /** scanner.e:213			current_source_next = 1*/
    _62current_source_next_25979 = 1LL;
L3: 

    /** scanner.e:216		start = current_source_next*/
    _start_25984 = _62current_source_next_25979;

    /** scanner.e:217		poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_62current_source_25978)) {
        _14454 = _62current_source_25978 + _62current_source_next_25979;
        if ((object)((uintptr_t)_14454 + (uintptr_t)HIGH_BITS) >= 0){
            _14454 = NewDouble((eudouble)_14454);
        }
    }
    else {
        _14454 = NewDouble(DBL_PTR(_62current_source_25978)->dbl + (eudouble)_62current_source_next_25979);
    }
    if (IS_ATOM_INT(_14454)){
        poke_addr = (uint8_t *)_14454;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14454)->dbl);
    }
    if (IS_ATOM_INT(_src_25983)) {
        *poke_addr = (uint8_t)_src_25983;
    }
    else if (IS_ATOM(_src_25983)) {
        *poke_addr = (uint8_t)DBL_PTR(_src_25983)->dbl;
    }
    else {
        _1 = (object)SEQ_PTR(_src_25983);
        _1 = (object)((s1_ptr)_1)->base;
        while (1) {
            _1 += sizeof(object);
            _2 = *((object *)_1);
            if (IS_ATOM_INT(_2)) {
                *poke_addr++ = (uint8_t)_2;
            }
            else if (_2 == NOVALUE) {
                break;
            }
            else {
                *poke_addr++ = (uint8_t)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_14454);
    _14454 = NOVALUE;

    /** scanner.e:218		current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_25983)){
            _14455 = SEQ_PTR(_src_25983)->length;
    }
    else {
        _14455 = 1;
    }
    _14456 = _14455 - 1LL;
    _14455 = NOVALUE;
    _62current_source_next_25979 = _62current_source_next_25979 + _14456;
    _14456 = NOVALUE;

    /** scanner.e:219		poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_62current_source_25978)) {
        _14458 = _62current_source_25978 + _62current_source_next_25979;
        if ((object)((uintptr_t)_14458 + (uintptr_t)HIGH_BITS) >= 0){
            _14458 = NewDouble((eudouble)_14458);
        }
    }
    else {
        _14458 = NewDouble(DBL_PTR(_62current_source_25978)->dbl + (eudouble)_62current_source_next_25979);
    }
    if (IS_ATOM_INT(_14458)){
        poke_addr = (uint8_t *)_14458;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_14458)->dbl);
    }
    *poke_addr = (uint8_t)0LL;
    DeRef(_14458);
    _14458 = NOVALUE;

    /** scanner.e:220		current_source_next += 1*/
    _62current_source_next_25979 = _62current_source_next_25979 + 1;

    /** scanner.e:221		return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_37all_source_15661)){
            _14460 = SEQ_PTR(_37all_source_15661)->length;
    }
    else {
        _14460 = 1;
    }
    _14461 = _14460 - 1LL;
    _14460 = NOVALUE;
    {
        int128_t p128 = (int128_t)10000LL * (int128_t)_14461;
        if( p128 != (int128_t)(_14462 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _14462 = NewDouble( (eudouble)p128 );
        }
    }
    _14461 = NOVALUE;
    if (IS_ATOM_INT(_14462)) {
        _14463 = _start_25984 + _14462;
        if ((object)((uintptr_t)_14463 + (uintptr_t)HIGH_BITS) >= 0){
            _14463 = NewDouble((eudouble)_14463);
        }
    }
    else {
        _14463 = NewDouble((eudouble)_start_25984 + DBL_PTR(_14462)->dbl);
    }
    DeRef(_14462);
    _14462 = NOVALUE;
    DeRef(_src_25983);
    return _14463;
    ;
}


object _62fetch_line(object _start_26018)
{
    object _line_26019 = NOVALUE;
    object _memdata_26020 = NOVALUE;
    object _c_26021 = NOVALUE;
    object _chunk_26022 = NOVALUE;
    object _p_26023 = NOVALUE;
    object _n_26024 = NOVALUE;
    object _m_26025 = NOVALUE;
    object _14488 = NOVALUE;
    object _14487 = NOVALUE;
    object _14485 = NOVALUE;
    object _14483 = NOVALUE;
    object _14477 = NOVALUE;
    object _14475 = NOVALUE;
    object _14471 = NOVALUE;
    object _14469 = NOVALUE;
    object _14466 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:234		if start = 0 then*/
    if (_start_26018 != 0LL)
    goto L1; // [5] 16

    /** scanner.e:235			return ""*/
    RefDS(_5);
    DeRef(_line_26019);
    DeRefi(_memdata_26020);
    DeRef(_p_26023);
    return _5;
L1: 

    /** scanner.e:237		line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_26019);
    _line_26019 = Repeat(0LL, 400LL);

    /** scanner.e:238		n = 0*/
    _n_26024 = 0LL;

    /** scanner.e:239		chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000LL > 0 && _start_26018 >= 0) {
        _14466 = _start_26018 / 10000LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_start_26018 / (eudouble)10000LL);
        _14466 = (object)temp_dbl;
    }
    _chunk_26022 = _14466 + 1;
    _14466 = NOVALUE;

    /** scanner.e:240		start = remainder(start, SOURCE_CHUNK)*/
    _start_26018 = (_start_26018 % 10000LL);

    /** scanner.e:241		p = all_source[chunk] + start*/
    _2 = (object)SEQ_PTR(_37all_source_15661);
    _14469 = (object)*(((s1_ptr)_2)->base + _chunk_26022);
    DeRef(_p_26023);
    if (IS_ATOM_INT(_14469)) {
        _p_26023 = _14469 + _start_26018;
        if ((object)((uintptr_t)_p_26023 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26023 = NewDouble((eudouble)_p_26023);
        }
    }
    else {
        _p_26023 = NewDouble(DBL_PTR(_14469)->dbl + (eudouble)_start_26018);
    }
    _14469 = NOVALUE;

    /** scanner.e:242		memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_26023);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_26023;
    ((intptr_t *)_2)[2] = 400LL;
    _14471 = MAKE_SEQ(_1);
    DeRefi(_memdata_26020);
    _1 = (object)SEQ_PTR(_14471);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_26020 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14471);
    _14471 = NOVALUE;

    /** scanner.e:243		p += LINE_BUFLEN*/
    _0 = _p_26023;
    if (IS_ATOM_INT(_p_26023)) {
        _p_26023 = _p_26023 + 400LL;
        if ((object)((uintptr_t)_p_26023 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26023 = NewDouble((eudouble)_p_26023);
        }
    }
    else {
        _p_26023 = NewDouble(DBL_PTR(_p_26023)->dbl + (eudouble)400LL);
    }
    DeRef(_0);

    /** scanner.e:244		m = 0*/
    _m_26025 = 0LL;

    /** scanner.e:245		while TRUE do*/
L2: 
    if (_13TRUE_447 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** scanner.e:246			m += 1*/
    _m_26025 = _m_26025 + 1;

    /** scanner.e:247			if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_26020)){
            _14475 = SEQ_PTR(_memdata_26020)->length;
    }
    else {
        _14475 = 1;
    }
    if (_m_26025 <= _14475)
    goto L4; // [98] 125

    /** scanner.e:248				memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_26023);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _p_26023;
    ((intptr_t *)_2)[2] = 400LL;
    _14477 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_26020);
    _1 = (object)SEQ_PTR(_14477);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _memdata_26020 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    DeRefDS(_14477);
    _14477 = NOVALUE;

    /** scanner.e:249				p += LINE_BUFLEN*/
    _0 = _p_26023;
    if (IS_ATOM_INT(_p_26023)) {
        _p_26023 = _p_26023 + 400LL;
        if ((object)((uintptr_t)_p_26023 + (uintptr_t)HIGH_BITS) >= 0){
            _p_26023 = NewDouble((eudouble)_p_26023);
        }
    }
    else {
        _p_26023 = NewDouble(DBL_PTR(_p_26023)->dbl + (eudouble)400LL);
    }
    DeRef(_0);

    /** scanner.e:250				m = 1*/
    _m_26025 = 1LL;
L4: 

    /** scanner.e:252			c = memdata[m]*/
    _2 = (object)SEQ_PTR(_memdata_26020);
    _c_26021 = (object)*(((s1_ptr)_2)->base + _m_26025);

    /** scanner.e:253			if c = 0 then*/
    if (_c_26021 != 0LL)
    goto L5; // [133] 142

    /** scanner.e:254				exit*/
    goto L3; // [139] 179
L5: 

    /** scanner.e:256			n += 1*/
    _n_26024 = _n_26024 + 1;

    /** scanner.e:257			if n > length(line) then*/
    if (IS_SEQUENCE(_line_26019)){
            _14483 = SEQ_PTR(_line_26019)->length;
    }
    else {
        _14483 = 1;
    }
    if (_n_26024 <= _14483)
    goto L6; // [153] 168

    /** scanner.e:258				line &= repeat(0, LINE_BUFLEN)*/
    _14485 = Repeat(0LL, 400LL);
    Concat((object_ptr)&_line_26019, _line_26019, _14485);
    DeRefDS(_14485);
    _14485 = NOVALUE;
L6: 

    /** scanner.e:260			line[n] = c*/
    _2 = (object)SEQ_PTR(_line_26019);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _line_26019 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _n_26024);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _c_26021;
    DeRef(_1);

    /** scanner.e:261		end while*/
    goto L2; // [176] 82
L3: 

    /** scanner.e:262		line = remove( line, n+1, length( line ) )*/
    _14487 = _n_26024 + 1;
    if (_14487 > MAXINT){
        _14487 = NewDouble((eudouble)_14487);
    }
    if (IS_SEQUENCE(_line_26019)){
            _14488 = SEQ_PTR(_line_26019)->length;
    }
    else {
        _14488 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_26019);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14487)) ? _14487 : (object)(DBL_PTR(_14487)->dbl);
        int stop = (IS_ATOM_INT(_14488)) ? _14488 : (object)(DBL_PTR(_14488)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_26019), start, &_line_26019 );
            }
            else Tail(SEQ_PTR(_line_26019), stop+1, &_line_26019);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_26019), start, &_line_26019);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_26019 = Remove_elements(start, stop, (SEQ_PTR(_line_26019)->ref == 1));
        }
    }
    DeRef(_14487);
    _14487 = NOVALUE;
    _14488 = NOVALUE;

    /** scanner.e:263		return line*/
    DeRefi(_memdata_26020);
    DeRef(_p_26023);
    return _line_26019;
    ;
}


void _62AppendSourceLine()
{
    object _new_26061 = NOVALUE;
    object _old_26062 = NOVALUE;
    object _options_26063 = NOVALUE;
    object _src_26064 = NOVALUE;
    object _14529 = NOVALUE;
    object _14525 = NOVALUE;
    object _14523 = NOVALUE;
    object _14522 = NOVALUE;
    object _14519 = NOVALUE;
    object _14518 = NOVALUE;
    object _14517 = NOVALUE;
    object _14516 = NOVALUE;
    object _14515 = NOVALUE;
    object _14514 = NOVALUE;
    object _14513 = NOVALUE;
    object _14512 = NOVALUE;
    object _14511 = NOVALUE;
    object _14510 = NOVALUE;
    object _14509 = NOVALUE;
    object _14508 = NOVALUE;
    object _14507 = NOVALUE;
    object _14506 = NOVALUE;
    object _14505 = NOVALUE;
    object _14504 = NOVALUE;
    object _14503 = NOVALUE;
    object _14502 = NOVALUE;
    object _14500 = NOVALUE;
    object _14499 = NOVALUE;
    object _14498 = NOVALUE;
    object _14496 = NOVALUE;
    object _14491 = NOVALUE;
    object _14490 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:272		src = 0*/
    DeRef(_src_26064);
    _src_26064 = 0LL;

    /** scanner.e:273		options = 0*/
    _options_26063 = 0LL;

    /** scanner.e:275		if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_36TRANSLATE_21361 != 0) {
        _14490 = 1;
        goto L1; // [15] 25
    }
    _14490 = (_36OpTrace_21832 != 0);
L1: 
    if (_14490 != 0) {
        _14491 = 1;
        goto L2; // [25] 35
    }
    _14491 = (_36OpProfileStatement_21834 != 0);
L2: 
    if (_14491 != 0) {
        goto L3; // [35] 46
    }
    if (_36OpProfileTime_21835 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** scanner.e:277			src = ThisLine*/
    Ref(_50ThisLine_49590);
    DeRef(_src_26064);
    _src_26064 = _50ThisLine_49590;

    /** scanner.e:279			if OpTrace then*/
    if (_36OpTrace_21832 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** scanner.e:280				options = SOP_TRACE*/
    _options_26063 = 1LL;
L5: 

    /** scanner.e:282			if OpProfileTime then*/
    if (_36OpProfileTime_21835 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** scanner.e:283				options = or_bits(options, SOP_PROFILE_TIME)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_26063 | (uintptr_t)2LL;
         _options_26063 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_26063)) {
        _1 = (object)(DBL_PTR(_options_26063)->dbl);
        DeRefDS(_options_26063);
        _options_26063 = _1;
    }
L6: 

    /** scanner.e:285			if OpProfileStatement then*/
    if (_36OpProfileStatement_21834 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** scanner.e:286				options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {uintptr_t tu;
         tu = (uintptr_t)_options_26063 | (uintptr_t)4LL;
         _options_26063 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_26063)) {
        _1 = (object)(DBL_PTR(_options_26063)->dbl);
        DeRefDS(_options_26063);
        _options_26063 = _1;
    }
L7: 

    /** scanner.e:288			if OpProfileStatement or OpProfileTime then*/
    if (_36OpProfileStatement_21834 != 0) {
        goto L8; // [110] 121
    }
    if (_36OpProfileTime_21835 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** scanner.e:289				src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = 0LL;
    ((intptr_t*)_2)[3] = 0LL;
    ((intptr_t*)_2)[4] = 0LL;
    _14496 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_14496) && IS_ATOM(_src_26064)) {
        Ref(_src_26064);
        Append(&_src_26064, _14496, _src_26064);
    }
    else if (IS_ATOM(_14496) && IS_SEQUENCE(_src_26064)) {
    }
    else {
        Concat((object_ptr)&_src_26064, _14496, _src_26064);
        DeRefDS(_14496);
        _14496 = NOVALUE;
    }
    DeRef(_14496);
    _14496 = NOVALUE;
L9: 
L4: 

    /** scanner.e:293		if length(slist) then*/
    if (IS_SEQUENCE(_36slist_21853)){
            _14498 = SEQ_PTR(_36slist_21853)->length;
    }
    else {
        _14498 = 1;
    }
    if (_14498 == 0)
    {
        _14498 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _14498 = NOVALUE;
    }

    /** scanner.e:294			old = slist[$-1]*/
    if (IS_SEQUENCE(_36slist_21853)){
            _14499 = SEQ_PTR(_36slist_21853)->length;
    }
    else {
        _14499 = 1;
    }
    _14500 = _14499 - 1LL;
    _14499 = NOVALUE;
    DeRef(_old_26062);
    _2 = (object)SEQ_PTR(_36slist_21853);
    _old_26062 = (object)*(((s1_ptr)_2)->base + _14500);
    Ref(_old_26062);

    /** scanner.e:296			if equal(src, old[SRC]) and*/
    _2 = (object)SEQ_PTR(_old_26062);
    _14502 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (_src_26064 == _14502)
    _14503 = 1;
    else if (IS_ATOM_INT(_src_26064) && IS_ATOM_INT(_14502))
    _14503 = 0;
    else
    _14503 = (compare(_src_26064, _14502) == 0);
    _14502 = NOVALUE;
    if (_14503 == 0) {
        _14504 = 0;
        goto LB; // [175] 195
    }
    _2 = (object)SEQ_PTR(_old_26062);
    _14505 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_14505)) {
        _14506 = (_36current_file_no_21759 == _14505);
    }
    else {
        _14506 = binary_op(EQUALS, _36current_file_no_21759, _14505);
    }
    _14505 = NOVALUE;
    if (IS_ATOM_INT(_14506))
    _14504 = (_14506 != 0);
    else
    _14504 = DBL_PTR(_14506)->dbl != 0.0;
LB: 
    if (_14504 == 0) {
        _14507 = 0;
        goto LC; // [195] 232
    }
    _2 = (object)SEQ_PTR(_old_26062);
    _14508 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_14508)) {
        _14509 = _14508 + 1;
        if (_14509 > MAXINT){
            _14509 = NewDouble((eudouble)_14509);
        }
    }
    else
    _14509 = binary_op(PLUS, 1, _14508);
    _14508 = NOVALUE;
    if (IS_SEQUENCE(_36slist_21853)){
            _14510 = SEQ_PTR(_36slist_21853)->length;
    }
    else {
        _14510 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21853);
    _14511 = (object)*(((s1_ptr)_2)->base + _14510);
    if (IS_ATOM_INT(_14509) && IS_ATOM_INT(_14511)) {
        _14512 = _14509 + _14511;
        if ((object)((uintptr_t)_14512 + (uintptr_t)HIGH_BITS) >= 0){
            _14512 = NewDouble((eudouble)_14512);
        }
    }
    else {
        _14512 = binary_op(PLUS, _14509, _14511);
    }
    DeRef(_14509);
    _14509 = NOVALUE;
    _14511 = NOVALUE;
    if (IS_ATOM_INT(_14512)) {
        _14513 = (_36line_number_21760 == _14512);
    }
    else {
        _14513 = binary_op(EQUALS, _36line_number_21760, _14512);
    }
    DeRef(_14512);
    _14512 = NOVALUE;
    if (IS_ATOM_INT(_14513))
    _14507 = (_14513 != 0);
    else
    _14507 = DBL_PTR(_14513)->dbl != 0.0;
LC: 
    if (_14507 == 0) {
        goto LD; // [232] 272
    }
    _2 = (object)SEQ_PTR(_old_26062);
    _14515 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_14515)) {
        _14516 = (_options_26063 == _14515);
    }
    else {
        _14516 = binary_op(EQUALS, _options_26063, _14515);
    }
    _14515 = NOVALUE;
    if (_14516 == 0) {
        DeRef(_14516);
        _14516 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_14516) && DBL_PTR(_14516)->dbl == 0.0){
            DeRef(_14516);
            _14516 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_14516);
        _14516 = NOVALUE;
    }
    DeRef(_14516);
    _14516 = NOVALUE;

    /** scanner.e:302				slist[$] += 1*/
    if (IS_SEQUENCE(_36slist_21853)){
            _14517 = SEQ_PTR(_36slist_21853)->length;
    }
    else {
        _14517 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21853);
    _14518 = (object)*(((s1_ptr)_2)->base + _14517);
    if (IS_ATOM_INT(_14518)) {
        _14519 = _14518 + 1;
        if (_14519 > MAXINT){
            _14519 = NewDouble((eudouble)_14519);
        }
    }
    else
    _14519 = binary_op(PLUS, 1, _14518);
    _14518 = NOVALUE;
    _2 = (object)SEQ_PTR(_36slist_21853);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21853 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14517);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14519;
    if( _1 != _14519 ){
        DeRef(_1);
    }
    _14519 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** scanner.e:304				src = pack_source(src)*/
    Ref(_src_26064);
    _0 = _src_26064;
    _src_26064 = _62pack_source(_src_26064);
    DeRef(_0);

    /** scanner.e:305				new = {src, line_number, current_file_no, options}*/
    _0 = _new_26061;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_26064);
    ((intptr_t*)_2)[1] = _src_26064;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    ((intptr_t*)_2)[3] = _36current_file_no_21759;
    ((intptr_t*)_2)[4] = _options_26063;
    _new_26061 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:306				if slist[$] = 0 then*/
    if (IS_SEQUENCE(_36slist_21853)){
            _14522 = SEQ_PTR(_36slist_21853)->length;
    }
    else {
        _14522 = 1;
    }
    _2 = (object)SEQ_PTR(_36slist_21853);
    _14523 = (object)*(((s1_ptr)_2)->base + _14522);
    if (binary_op_a(NOTEQ, _14523, 0LL)){
        _14523 = NOVALUE;
        goto LF; // [302] 320
    }
    _14523 = NOVALUE;

    /** scanner.e:307					slist[$] = new*/
    if (IS_SEQUENCE(_36slist_21853)){
            _14525 = SEQ_PTR(_36slist_21853)->length;
    }
    else {
        _14525 = 1;
    }
    RefDS(_new_26061);
    _2 = (object)SEQ_PTR(_36slist_21853);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36slist_21853 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14525);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_26061;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** scanner.e:309					slist = append(slist, new)*/
    RefDS(_new_26061);
    Append(&_36slist_21853, _36slist_21853, _new_26061);
L10: 

    /** scanner.e:311				slist = append(slist, 0)*/
    Append(&_36slist_21853, _36slist_21853, 0LL);
    goto LE; // [342] 371
LA: 

    /** scanner.e:314			src = pack_source(src)*/
    Ref(_src_26064);
    _0 = _src_26064;
    _src_26064 = _62pack_source(_src_26064);
    DeRef(_0);

    /** scanner.e:315			slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_src_26064);
    ((intptr_t*)_2)[1] = _src_26064;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    ((intptr_t*)_2)[3] = _36current_file_no_21759;
    ((intptr_t*)_2)[4] = _options_26063;
    _14529 = MAKE_SEQ(_1);
    DeRef(_36slist_21853);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _14529;
    ((intptr_t *)_2)[2] = 0LL;
    _36slist_21853 = MAKE_SEQ(_1);
    _14529 = NOVALUE;
LE: 

    /** scanner.e:317	end procedure*/
    DeRef(_new_26061);
    DeRef(_old_26062);
    DeRef(_src_26064);
    DeRef(_14513);
    _14513 = NOVALUE;
    DeRef(_14506);
    _14506 = NOVALUE;
    DeRef(_14500);
    _14500 = NOVALUE;
    return;
    ;
}


object _62s_expand(object _slist_26153)
{
    object _new_slist_26154 = NOVALUE;
    object _14543 = NOVALUE;
    object _14542 = NOVALUE;
    object _14541 = NOVALUE;
    object _14540 = NOVALUE;
    object _14538 = NOVALUE;
    object _14537 = NOVALUE;
    object _14536 = NOVALUE;
    object _14534 = NOVALUE;
    object _14533 = NOVALUE;
    object _14532 = NOVALUE;
    object _14531 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:323		new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_26154);
    _new_slist_26154 = _5;

    /** scanner.e:325		for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_26153)){
            _14531 = SEQ_PTR(_slist_26153)->length;
    }
    else {
        _14531 = 1;
    }
    {
        object _i_26156;
        _i_26156 = 1LL;
L1: 
        if (_i_26156 > _14531){
            goto L2; // [15] 114
        }

        /** scanner.e:326			if sequence(slist[i]) then*/
        _2 = (object)SEQ_PTR(_slist_26153);
        _14532 = (object)*(((s1_ptr)_2)->base + _i_26156);
        _14533 = IS_SEQUENCE(_14532);
        _14532 = NOVALUE;
        if (_14533 == 0)
        {
            _14533 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _14533 = NOVALUE;
        }

        /** scanner.e:327				new_slist = append(new_slist, slist[i])*/
        _2 = (object)SEQ_PTR(_slist_26153);
        _14534 = (object)*(((s1_ptr)_2)->base + _i_26156);
        Ref(_14534);
        Append(&_new_slist_26154, _new_slist_26154, _14534);
        _14534 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** scanner.e:329				for j = 1 to slist[i] do*/
        _2 = (object)SEQ_PTR(_slist_26153);
        _14536 = (object)*(((s1_ptr)_2)->base + _i_26156);
        {
            object _j_26165;
            _j_26165 = 1LL;
L5: 
            if (binary_op_a(GREATER, _j_26165, _14536)){
                goto L6; // [53] 106
            }

            /** scanner.e:330					slist[i-1][LINE] += 1*/
            _14537 = _i_26156 - 1LL;
            _2 = (object)SEQ_PTR(_slist_26153);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _slist_26153 = MAKE_SEQ(_2);
            }
            _3 = (object)(_14537 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            _14540 = (object)*(((s1_ptr)_2)->base + 2LL);
            _14538 = NOVALUE;
            if (IS_ATOM_INT(_14540)) {
                _14541 = _14540 + 1;
                if (_14541 > MAXINT){
                    _14541 = NewDouble((eudouble)_14541);
                }
            }
            else
            _14541 = binary_op(PLUS, 1, _14540);
            _14540 = NOVALUE;
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 2LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _14541;
            if( _1 != _14541 ){
                DeRef(_1);
            }
            _14541 = NOVALUE;
            _14538 = NOVALUE;

            /** scanner.e:331					new_slist = append(new_slist, slist[i-1])*/
            _14542 = _i_26156 - 1LL;
            _2 = (object)SEQ_PTR(_slist_26153);
            _14543 = (object)*(((s1_ptr)_2)->base + _14542);
            Ref(_14543);
            Append(&_new_slist_26154, _new_slist_26154, _14543);
            _14543 = NOVALUE;

            /** scanner.e:332				end for*/
            _0 = _j_26165;
            if (IS_ATOM_INT(_j_26165)) {
                _j_26165 = _j_26165 + 1LL;
                if ((object)((uintptr_t)_j_26165 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_26165 = NewDouble((eudouble)_j_26165);
                }
            }
            else {
                _j_26165 = binary_op_a(PLUS, _j_26165, 1LL);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_26165);
        }
L4: 

        /** scanner.e:334		end for*/
        _i_26156 = _i_26156 + 1LL;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** scanner.e:335		return new_slist*/
    DeRefDS(_slist_26153);
    DeRef(_14542);
    _14542 = NOVALUE;
    DeRef(_14537);
    _14537 = NOVALUE;
    _14536 = NOVALUE;
    return _new_slist_26154;
    ;
}


void _62set_dont_read(object _read_26180)
{
    object _0, _1, _2;
    

    /** scanner.e:357		dont_read = read*/
    _62dont_read_26177 = _read_26180;

    /** scanner.e:358	end procedure*/
    return;
    ;
}


void _62read_line()
{
    object _n_26186 = NOVALUE;
    object _14573 = NOVALUE;
    object _14572 = NOVALUE;
    object _14571 = NOVALUE;
    object _14570 = NOVALUE;
    object _14569 = NOVALUE;
    object _14567 = NOVALUE;
    object _14566 = NOVALUE;
    object _14564 = NOVALUE;
    object _14563 = NOVALUE;
    object _14562 = NOVALUE;
    object _14561 = NOVALUE;
    object _14553 = NOVALUE;
    object _14551 = NOVALUE;
    object _14550 = NOVALUE;
    object _14549 = NOVALUE;
    object _14548 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:367		line_number += 1*/
    _36line_number_21760 = _36line_number_21760 + 1LL;

    /** scanner.e:368		gline_number += 1*/
    _36gline_number_21764 = _36gline_number_21764 + 1LL;

    /** scanner.e:370		if dont_read then*/
    if (_62dont_read_26177 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** scanner.e:371			ThisLine = -1*/
    DeRef(_50ThisLine_49590);
    _50ThisLine_49590 = -1LL;
    goto L2; // [33] 216
L1: 

    /** scanner.e:372		elsif repl and src_file = repl_file then*/
    if (0LL == 0) {
        goto L3; // [40] 144
    }
    _14549 = (_36src_file_21884 == 5555LL);
    if (_14549 == 0)
    {
        DeRef(_14549);
        _14549 = NOVALUE;
        goto L3; // [53] 144
    }
    else{
        DeRef(_14549);
        _14549 = NOVALUE;
    }

    /** scanner.e:373			if repl_line_was_read and current_block = top_level_block then*/
    if (_62repl_line_was_read_26181 == 0) {
        goto L4; // [60] 118
    }
    _14551 = (_65current_block_25434 == _65top_level_block_25435);
    if (_14551 == 0)
    {
        DeRef(_14551);
        _14551 = NOVALUE;
        goto L4; // [73] 118
    }
    else{
        DeRef(_14551);
        _14551 = NOVALUE;
    }

    /** scanner.e:374				if repl_line_was_read > 1 then*/
    if (_62repl_line_was_read_26181 <= 1LL)
    goto L5; // [80] 110

    /** scanner.e:375					if not match("end", ThisLine) then*/
    _14553 = e_match_from(_13327, _50ThisLine_49590, 1LL);
    if (_14553 != 0)
    goto L6; // [93] 109
    _14553 = NOVALUE;

    /** scanner.e:376						goto "lol"*/
    goto G7;
L6: 
L5: 

    /** scanner.e:379				ThisLine = -1*/
    DeRef(_50ThisLine_49590);
    _50ThisLine_49590 = -1LL;
    goto L2; // [115] 216
L4: 

    /** scanner.e:381				label "lol"*/
G7:

    /** scanner.e:382				puts(1, "Enter line:\n")*/
    EPuts(1LL, _14556); // DJP 

    /** scanner.e:383				repl_line_was_read += 1*/
    _62repl_line_was_read_26181 = _62repl_line_was_read_26181 + 1;

    /** scanner.e:384				ThisLine = gets(0)*/
    DeRef(_50ThisLine_49590);
    _50ThisLine_49590 = EGets(0LL);
    goto L2; // [141] 216
L3: 

    /** scanner.e:386		elsif src_file < 0 then*/
    if (_36src_file_21884 >= 0LL)
    goto L8; // [148] 160

    /** scanner.e:387			ThisLine = -1*/
    DeRef(_50ThisLine_49590);
    _50ThisLine_49590 = -1LL;
    goto L2; // [157] 216
L8: 

    /** scanner.e:389			ThisLine = gets(src_file)*/
    DeRef(_50ThisLine_49590);
    _50ThisLine_49590 = EGets(_36src_file_21884);

    /** scanner.e:390			if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _14561 = IS_SEQUENCE(_50ThisLine_49590);
    if (_14561 == 0) {
        goto L9; // [174] 215
    }
    RefDS(_12355);
    Ref(_50ThisLine_49590);
    _14563 = _16ends(_12355, _50ThisLine_49590);
    if (_14563 == 0) {
        DeRef(_14563);
        _14563 = NOVALUE;
        goto L9; // [186] 215
    }
    else {
        if (!IS_ATOM_INT(_14563) && DBL_PTR(_14563)->dbl == 0.0){
            DeRef(_14563);
            _14563 = NOVALUE;
            goto L9; // [186] 215
        }
        DeRef(_14563);
        _14563 = NOVALUE;
    }
    DeRef(_14563);
    _14563 = NOVALUE;

    /** scanner.e:391				ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_50ThisLine_49590)){
            _14564 = SEQ_PTR(_50ThisLine_49590)->length;
    }
    else {
        _14564 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_50ThisLine_49590);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_14564)) ? _14564 : (object)(DBL_PTR(_14564)->dbl);
        int stop = (IS_ATOM_INT(_14564)) ? _14564 : (object)(DBL_PTR(_14564)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_50ThisLine_49590), start, &_50ThisLine_49590 );
            }
            else Tail(SEQ_PTR(_50ThisLine_49590), stop+1, &_50ThisLine_49590);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_50ThisLine_49590), start, &_50ThisLine_49590);
        }
        else {
            assign_slice_seq = &assign_space;
            _50ThisLine_49590 = Remove_elements(start, stop, (SEQ_PTR(_50ThisLine_49590)->ref == 1));
        }
    }
    _14564 = NOVALUE;
    _14564 = NOVALUE;

    /** scanner.e:392				ThisLine[$] = 10*/
    if (IS_SEQUENCE(_50ThisLine_49590)){
            _14566 = SEQ_PTR(_50ThisLine_49590)->length;
    }
    else {
        _14566 = 1;
    }
    _2 = (object)SEQ_PTR(_50ThisLine_49590);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _50ThisLine_49590 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14566);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 10LL;
    DeRef(_1);
L9: 
L2: 

    /** scanner.e:395		if atom(ThisLine) then*/
    _14567 = IS_ATOM(_50ThisLine_49590);
    if (_14567 == 0)
    {
        _14567 = NOVALUE;
        goto LA; // [223] 286
    }
    else{
        _14567 = NOVALUE;
    }

    /** scanner.e:396			ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _50ThisLine_49590;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 26LL;
    _50ThisLine_49590 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:397			if src_file >= 0 and (src_file != repl_file or not repl) then*/
    _14569 = (_36src_file_21884 >= 0LL);
    if (_14569 == 0) {
        goto LB; // [242] 278
    }
    _14571 = (_36src_file_21884 != 5555LL);
    if (_14571 != 0) {
        DeRef(_14572);
        _14572 = 1;
        goto LC; // [254] 267
    }
    _14573 = (0LL == 0);
    _14572 = (_14573 != 0);
LC: 
    if (_14572 == 0)
    {
        _14572 = NOVALUE;
        goto LB; // [268] 278
    }
    else{
        _14572 = NOVALUE;
    }

    /** scanner.e:398				close(src_file)*/
    EClose(_36src_file_21884);
LB: 

    /** scanner.e:400			src_file = -1*/
    _36src_file_21884 = -1LL;
LA: 

    /** scanner.e:403		bp = 1*/
    _50bp_49594 = 1LL;

    /** scanner.e:411		AppendSourceLine()*/
    _62AppendSourceLine();

    /** scanner.e:412	end procedure*/
    DeRef(_14573);
    _14573 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14571);
    _14571 = NOVALUE;
    return;
    ;
}


object _62getch()
{
    object _c_26260 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:417		c = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49590);
    _c_26260 = (object)*(((s1_ptr)_2)->base + _50bp_49594);
    if (!IS_ATOM_INT(_c_26260)){
        _c_26260 = (object)DBL_PTR(_c_26260)->dbl;
    }

    /** scanner.e:418		bp += 1*/
    _50bp_49594 = _50bp_49594 + 1LL;

    /** scanner.e:419		return c*/
    return _c_26260;
    ;
}


void _62ungetch()
{
    object _0, _1, _2;
    

    /** scanner.e:424		bp -= 1*/
    _50bp_49594 = _50bp_49594 - 1LL;

    /** scanner.e:425	end procedure*/
    return;
    ;
}


object _62get_file_path(object _s_26272)
{
    object _14582 = NOVALUE;
    object _14580 = NOVALUE;
    object _14579 = NOVALUE;
    object _14578 = NOVALUE;
    object _14577 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:429			for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_26272)){
            _14577 = SEQ_PTR(_s_26272)->length;
    }
    else {
        _14577 = 1;
    }
    {
        object _t_26274;
        _t_26274 = _14577;
L1: 
        if (_t_26274 < 1LL){
            goto L2; // [8] 50
        }

        /** scanner.e:430					if find(s[t],SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_s_26272);
        _14578 = (object)*(((s1_ptr)_2)->base + _t_26274);
        _14579 = find_from(_14578, _46SLASH_CHARS_21927, 1LL);
        _14578 = NOVALUE;
        if (_14579 == 0)
        {
            _14579 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _14579 = NOVALUE;
        }

        /** scanner.e:431							return s[1..t]*/
        rhs_slice_target = (object_ptr)&_14580;
        RHS_Slice(_s_26272, 1LL, _t_26274);
        DeRefDS(_s_26272);
        return _14580;
L3: 

        /** scanner.e:433			end for*/
        _t_26274 = _t_26274 + -1LL;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** scanner.e:435			return "." & SLASH*/
    Append(&_14582, _14581, 92LL);
    DeRefDS(_s_26272);
    DeRef(_14580);
    _14580 = NOVALUE;
    return _14582;
    ;
}


object _62find_file(object _fname_26286)
{
    object _try_26287 = NOVALUE;
    object _full_path_26288 = NOVALUE;
    object _errbuff_26289 = NOVALUE;
    object _currdir_26290 = NOVALUE;
    object _conf_path_26291 = NOVALUE;
    object _scan_result_26292 = NOVALUE;
    object _inc_path_26293 = NOVALUE;
    object _mainpath_26313 = NOVALUE;
    object _31988 = NOVALUE;
    object _31987 = NOVALUE;
    object _14679 = NOVALUE;
    object _14677 = NOVALUE;
    object _14676 = NOVALUE;
    object _14675 = NOVALUE;
    object _14673 = NOVALUE;
    object _14671 = NOVALUE;
    object _14669 = NOVALUE;
    object _14668 = NOVALUE;
    object _14666 = NOVALUE;
    object _14665 = NOVALUE;
    object _14662 = NOVALUE;
    object _14659 = NOVALUE;
    object _14658 = NOVALUE;
    object _14657 = NOVALUE;
    object _14656 = NOVALUE;
    object _14655 = NOVALUE;
    object _14654 = NOVALUE;
    object _14653 = NOVALUE;
    object _14652 = NOVALUE;
    object _14649 = NOVALUE;
    object _14648 = NOVALUE;
    object _14644 = NOVALUE;
    object _14641 = NOVALUE;
    object _14640 = NOVALUE;
    object _14639 = NOVALUE;
    object _14638 = NOVALUE;
    object _14637 = NOVALUE;
    object _14636 = NOVALUE;
    object _14635 = NOVALUE;
    object _14634 = NOVALUE;
    object _14631 = NOVALUE;
    object _14627 = NOVALUE;
    object _14625 = NOVALUE;
    object _14624 = NOVALUE;
    object _14623 = NOVALUE;
    object _14622 = NOVALUE;
    object _14621 = NOVALUE;
    object _14618 = NOVALUE;
    object _14617 = NOVALUE;
    object _14616 = NOVALUE;
    object _14615 = NOVALUE;
    object _14614 = NOVALUE;
    object _14613 = NOVALUE;
    object _14611 = NOVALUE;
    object _14610 = NOVALUE;
    object _14609 = NOVALUE;
    object _14608 = NOVALUE;
    object _14607 = NOVALUE;
    object _14605 = NOVALUE;
    object _14604 = NOVALUE;
    object _14601 = NOVALUE;
    object _14598 = NOVALUE;
    object _14596 = NOVALUE;
    object _14593 = NOVALUE;
    object _14591 = NOVALUE;
    object _14590 = NOVALUE;
    object _14587 = NOVALUE;
    object _14586 = NOVALUE;
    object _14584 = NOVALUE;
    object _14583 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:449		if absolute_path(fname) then*/
    RefDS(_fname_26286);
    _14583 = _17absolute_path(_fname_26286);
    if (_14583 == 0) {
        DeRef(_14583);
        _14583 = NOVALUE;
        goto L1; // [9] 44
    }
    else {
        if (!IS_ATOM_INT(_14583) && DBL_PTR(_14583)->dbl == 0.0){
            DeRef(_14583);
            _14583 = NOVALUE;
            goto L1; // [9] 44
        }
        DeRef(_14583);
        _14583 = NOVALUE;
    }
    DeRef(_14583);
    _14583 = NOVALUE;

    /** scanner.e:451			if not file_exists(fname) then*/
    RefDS(_fname_26286);
    _14584 = _17file_exists(_fname_26286);
    if (IS_ATOM_INT(_14584)) {
        if (_14584 != 0){
            DeRef(_14584);
            _14584 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    else {
        if (DBL_PTR(_14584)->dbl != 0.0){
            DeRef(_14584);
            _14584 = NOVALUE;
            goto L2; // [18] 37
        }
    }
    DeRef(_14584);
    _14584 = NOVALUE;

    /** scanner.e:452				CompileErr(CANT_OPEN_1, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_36new_include_name_21885);
    ((intptr_t*)_2)[1] = _36new_include_name_21885;
    _14586 = MAKE_SEQ(_1);
    _50CompileErr(51LL, _14586, 0LL);
    _14586 = NOVALUE;
L2: 

    /** scanner.e:455			return fname*/
    DeRef(_full_path_26288);
    DeRef(_errbuff_26289);
    DeRef(_currdir_26290);
    DeRef(_conf_path_26291);
    DeRef(_scan_result_26292);
    DeRef(_inc_path_26293);
    DeRef(_mainpath_26313);
    return _fname_26286;
L1: 

    /** scanner.e:460		currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (object)SEQ_PTR(_37known_files_15638);
    _14587 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    Ref(_14587);
    _0 = _currdir_26290;
    _currdir_26290 = _62get_file_path(_14587);
    DeRef(_0);
    _14587 = NOVALUE;

    /** scanner.e:461		full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_26288, _currdir_26290, _fname_26286);

    /** scanner.e:462		if file_exists(full_path) then*/
    RefDS(_full_path_26288);
    _14590 = _17file_exists(_full_path_26288);
    if (_14590 == 0) {
        DeRef(_14590);
        _14590 = NOVALUE;
        goto L3; // [72] 82
    }
    else {
        if (!IS_ATOM_INT(_14590) && DBL_PTR(_14590)->dbl == 0.0){
            DeRef(_14590);
            _14590 = NOVALUE;
            goto L3; // [72] 82
        }
        DeRef(_14590);
        _14590 = NOVALUE;
    }
    DeRef(_14590);
    _14590 = NOVALUE;

    /** scanner.e:463			return full_path*/
    DeRefDS(_fname_26286);
    DeRef(_errbuff_26289);
    DeRefDS(_currdir_26290);
    DeRef(_conf_path_26291);
    DeRef(_scan_result_26292);
    DeRef(_inc_path_26293);
    DeRef(_mainpath_26313);
    return _full_path_26288;
L3: 

    /** scanner.e:467		sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_36main_path_21883);
    DeRef(_31987);
    _31987 = _36main_path_21883;
    if (IS_SEQUENCE(_31987)){
            _31988 = SEQ_PTR(_31987)->length;
    }
    else {
        _31988 = 1;
    }
    _31987 = NOVALUE;
    RefDS(_36main_path_21883);
    _14591 = _16rfind(92LL, _36main_path_21883, _31988);
    _31988 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_26313;
    RHS_Slice(_36main_path_21883, 1LL, _14591);

    /** scanner.e:468		if not equal(mainpath, currdir) then*/
    if (_mainpath_26313 == _currdir_26290)
    _14593 = 1;
    else if (IS_ATOM_INT(_mainpath_26313) && IS_ATOM_INT(_currdir_26290))
    _14593 = 0;
    else
    _14593 = (compare(_mainpath_26313, _currdir_26290) == 0);
    if (_14593 != 0)
    goto L4; // [113] 141
    _14593 = NOVALUE;

    /** scanner.e:469			full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_26288, _mainpath_26313, _36new_include_name_21885);

    /** scanner.e:470			if file_exists(full_path) then*/
    RefDS(_full_path_26288);
    _14596 = _17file_exists(_full_path_26288);
    if (_14596 == 0) {
        DeRef(_14596);
        _14596 = NOVALUE;
        goto L5; // [130] 140
    }
    else {
        if (!IS_ATOM_INT(_14596) && DBL_PTR(_14596)->dbl == 0.0){
            DeRef(_14596);
            _14596 = NOVALUE;
            goto L5; // [130] 140
        }
        DeRef(_14596);
        _14596 = NOVALUE;
    }
    DeRef(_14596);
    _14596 = NOVALUE;

    /** scanner.e:471				return full_path*/
    DeRefDS(_fname_26286);
    DeRef(_errbuff_26289);
    DeRefDS(_currdir_26290);
    DeRef(_conf_path_26291);
    DeRef(_scan_result_26292);
    DeRef(_inc_path_26293);
    DeRefDS(_mainpath_26313);
    DeRef(_14591);
    _14591 = NOVALUE;
    _31987 = NOVALUE;
    return _full_path_26288;
L5: 
L4: 

    /** scanner.e:475		scan_result = ConfPath(new_include_name)*/
    RefDS(_36new_include_name_21885);
    _0 = _scan_result_26292;
    _scan_result_26292 = _48ConfPath(_36new_include_name_21885);
    DeRef(_0);

    /** scanner.e:477		if atom(scan_result) then*/
    _14598 = IS_ATOM(_scan_result_26292);
    if (_14598 == 0)
    {
        _14598 = NOVALUE;
        goto L6; // [154] 166
    }
    else{
        _14598 = NOVALUE;
    }

    /** scanner.e:478			scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_26286);
    RefDS(_14599);
    _0 = _scan_result_26292;
    _scan_result_26292 = _48ScanPath(_fname_26286, _14599, 0LL);
    DeRef(_0);
L6: 

    /** scanner.e:481		if atom(scan_result) then*/
    _14601 = IS_ATOM(_scan_result_26292);
    if (_14601 == 0)
    {
        _14601 = NOVALUE;
        goto L7; // [171] 183
    }
    else{
        _14601 = NOVALUE;
    }

    /** scanner.e:482			scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_26286);
    RefDS(_14602);
    _0 = _scan_result_26292;
    _scan_result_26292 = _48ScanPath(_fname_26286, _14602, 1LL);
    DeRef(_0);
L7: 

    /** scanner.e:485		if atom(scan_result) then*/
    _14604 = IS_ATOM(_scan_result_26292);
    if (_14604 == 0)
    {
        _14604 = NOVALUE;
        goto L8; // [188] 225
    }
    else{
        _14604 = NOVALUE;
    }

    /** scanner.e:487			full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _14605 = _37get_eudir();
    {
        object concat_list[5];

        concat_list[0] = _fname_26286;
        concat_list[1] = 92LL;
        concat_list[2] = _13365;
        concat_list[3] = 92LL;
        concat_list[4] = _14605;
        Concat_N((object_ptr)&_full_path_26288, concat_list, 5);
    }
    DeRef(_14605);
    _14605 = NOVALUE;

    /** scanner.e:488			if file_exists(full_path) then*/
    RefDS(_full_path_26288);
    _14607 = _17file_exists(_full_path_26288);
    if (_14607 == 0) {
        DeRef(_14607);
        _14607 = NOVALUE;
        goto L9; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_14607) && DBL_PTR(_14607)->dbl == 0.0){
            DeRef(_14607);
            _14607 = NOVALUE;
            goto L9; // [214] 224
        }
        DeRef(_14607);
        _14607 = NOVALUE;
    }
    DeRef(_14607);
    _14607 = NOVALUE;

    /** scanner.e:489				return full_path*/
    DeRefDS(_fname_26286);
    DeRef(_errbuff_26289);
    DeRef(_currdir_26290);
    DeRef(_conf_path_26291);
    DeRef(_scan_result_26292);
    DeRef(_inc_path_26293);
    DeRef(_mainpath_26313);
    DeRef(_14591);
    _14591 = NOVALUE;
    _31987 = NOVALUE;
    return _full_path_26288;
L9: 
L8: 

    /** scanner.e:493		if sequence(scan_result) then*/
    _14608 = IS_SEQUENCE(_scan_result_26292);
    if (_14608 == 0)
    {
        _14608 = NOVALUE;
        goto LA; // [230] 252
    }
    else{
        _14608 = NOVALUE;
    }

    /** scanner.e:495			close(scan_result[2])*/
    _2 = (object)SEQ_PTR(_scan_result_26292);
    _14609 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_ATOM_INT(_14609))
    EClose(_14609);
    else
    EClose((object)DBL_PTR(_14609)->dbl);
    _14609 = NOVALUE;

    /** scanner.e:496			return scan_result[1]*/
    _2 = (object)SEQ_PTR(_scan_result_26292);
    _14610 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_14610);
    DeRefDS(_fname_26286);
    DeRef(_full_path_26288);
    DeRef(_errbuff_26289);
    DeRef(_currdir_26290);
    DeRef(_conf_path_26291);
    DeRef(_scan_result_26292);
    DeRef(_inc_path_26293);
    DeRef(_mainpath_26313);
    DeRef(_14591);
    _14591 = NOVALUE;
    _31987 = NOVALUE;
    return _14610;
LA: 

    /** scanner.e:500		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26289);
    _errbuff_26289 = _5;

    /** scanner.e:501		full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_26288);
    _full_path_26288 = _5;

    /** scanner.e:502		if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_26290)){
            _14611 = SEQ_PTR(_currdir_26290)->length;
    }
    else {
        _14611 = 1;
    }
    if (_14611 <= 0LL)
    goto LB; // [271] 323

    /** scanner.e:503			if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_26290)){
            _14613 = SEQ_PTR(_currdir_26290)->length;
    }
    else {
        _14613 = 1;
    }
    _2 = (object)SEQ_PTR(_currdir_26290);
    _14614 = (object)*(((s1_ptr)_2)->base + _14613);
    _14615 = find_from(_14614, _46SLASH_CHARS_21927, 1LL);
    _14614 = NOVALUE;
    if (_14615 == 0)
    {
        _14615 = NOVALUE;
        goto LC; // [291] 315
    }
    else{
        _14615 = NOVALUE;
    }

    /** scanner.e:504				full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_26290)){
            _14616 = SEQ_PTR(_currdir_26290)->length;
    }
    else {
        _14616 = 1;
    }
    _14617 = _14616 - 1LL;
    _14616 = NOVALUE;
    rhs_slice_target = (object_ptr)&_14618;
    RHS_Slice(_currdir_26290, 1LL, _14617);
    RefDS(_14618);
    Append(&_full_path_26288, _full_path_26288, _14618);
    DeRefDS(_14618);
    _14618 = NOVALUE;
    goto LD; // [312] 322
LC: 

    /** scanner.e:506				full_path = append(full_path, currdir)*/
    RefDS(_currdir_26290);
    Append(&_full_path_26288, _full_path_26288, _currdir_26290);
LD: 
LB: 

    /** scanner.e:511		if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_36main_path_21883)){
            _14621 = SEQ_PTR(_36main_path_21883)->length;
    }
    else {
        _14621 = 1;
    }
    _2 = (object)SEQ_PTR(_36main_path_21883);
    _14622 = (object)*(((s1_ptr)_2)->base + _14621);
    _14623 = find_from(_14622, _46SLASH_CHARS_21927, 1LL);
    _14622 = NOVALUE;
    if (_14623 == 0)
    {
        _14623 = NOVALUE;
        goto LE; // [341] 363
    }
    else{
        _14623 = NOVALUE;
    }

    /** scanner.e:512			errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_36main_path_21883)){
            _14624 = SEQ_PTR(_36main_path_21883)->length;
    }
    else {
        _14624 = 1;
    }
    _14625 = _14624 - 1LL;
    _14624 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_26289;
    RHS_Slice(_36main_path_21883, 1LL, _14625);
    goto LF; // [360] 373
LE: 

    /** scanner.e:514			errbuff = main_path*/
    RefDS(_36main_path_21883);
    DeRef(_errbuff_26289);
    _errbuff_26289 = _36main_path_21883;
LF: 

    /** scanner.e:516		if not find(errbuff, full_path) then*/
    _14627 = find_from(_errbuff_26289, _full_path_26288, 1LL);
    if (_14627 != 0)
    goto L10; // [380] 390
    _14627 = NOVALUE;

    /** scanner.e:517			full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_26289);
    Append(&_full_path_26288, _full_path_26288, _errbuff_26289);
L10: 

    /** scanner.e:520		conf_path = get_conf_dirs()*/
    _0 = _conf_path_26291;
    _conf_path_26291 = _48get_conf_dirs();
    DeRef(_0);

    /** scanner.e:521		if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_26291)){
            _14631 = SEQ_PTR(_conf_path_26291)->length;
    }
    else {
        _14631 = 1;
    }
    if (_14631 <= 0LL)
    goto L11; // [402] 509

    /** scanner.e:522			conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_26291);
    _0 = _conf_path_26291;
    _conf_path_26291 = _23split(_conf_path_26291, 59LL, 0LL, 0LL);
    DeRefDS(_0);

    /** scanner.e:523			for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_26291)){
            _14634 = SEQ_PTR(_conf_path_26291)->length;
    }
    else {
        _14634 = 1;
    }
    {
        object _i_26394;
        _i_26394 = 1LL;
L12: 
        if (_i_26394 > _14634){
            goto L13; // [424] 508
        }

        /** scanner.e:524				if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_conf_path_26291);
        _14635 = (object)*(((s1_ptr)_2)->base + _i_26394);
        if (IS_SEQUENCE(_14635)){
                _14636 = SEQ_PTR(_14635)->length;
        }
        else {
            _14636 = 1;
        }
        _2 = (object)SEQ_PTR(_14635);
        _14637 = (object)*(((s1_ptr)_2)->base + _14636);
        _14635 = NOVALUE;
        _14638 = find_from(_14637, _46SLASH_CHARS_21927, 1LL);
        _14637 = NOVALUE;
        if (_14638 == 0)
        {
            _14638 = NOVALUE;
            goto L14; // [451] 475
        }
        else{
            _14638 = NOVALUE;
        }

        /** scanner.e:525					errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_conf_path_26291);
        _14639 = (object)*(((s1_ptr)_2)->base + _i_26394);
        if (IS_SEQUENCE(_14639)){
                _14640 = SEQ_PTR(_14639)->length;
        }
        else {
            _14640 = 1;
        }
        _14641 = _14640 - 1LL;
        _14640 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26289;
        RHS_Slice(_14639, 1LL, _14641);
        _14639 = NOVALUE;
        goto L15; // [472] 484
L14: 

        /** scanner.e:527					errbuff = conf_path[i]*/
        DeRef(_errbuff_26289);
        _2 = (object)SEQ_PTR(_conf_path_26291);
        _errbuff_26289 = (object)*(((s1_ptr)_2)->base + _i_26394);
        Ref(_errbuff_26289);
L15: 

        /** scanner.e:529				if not find(errbuff, full_path) then*/
        _14644 = find_from(_errbuff_26289, _full_path_26288, 1LL);
        if (_14644 != 0)
        goto L16; // [491] 501
        _14644 = NOVALUE;

        /** scanner.e:530					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26289);
        Append(&_full_path_26288, _full_path_26288, _errbuff_26289);
L16: 

        /** scanner.e:532			end for*/
        _i_26394 = _i_26394 + 1LL;
        goto L12; // [503] 431
L13: 
        ;
    }
L11: 

    /** scanner.e:535		inc_path = getenv("EUINC")*/
    DeRef(_inc_path_26293);
    _inc_path_26293 = EGetEnv(_14599);

    /** scanner.e:536		if sequence(inc_path) then*/
    _14648 = IS_SEQUENCE(_inc_path_26293);
    if (_14648 == 0)
    {
        _14648 = NOVALUE;
        goto L17; // [519] 633
    }
    else{
        _14648 = NOVALUE;
    }

    /** scanner.e:537			if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_26293)){
            _14649 = SEQ_PTR(_inc_path_26293)->length;
    }
    else {
        _14649 = 1;
    }
    if (_14649 <= 0LL)
    goto L18; // [527] 632

    /** scanner.e:538				inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_26293);
    _0 = _inc_path_26293;
    _inc_path_26293 = _23split(_inc_path_26293, 59LL, 0LL, 0LL);
    DeRefi(_0);

    /** scanner.e:539				for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_26293)){
            _14652 = SEQ_PTR(_inc_path_26293)->length;
    }
    else {
        _14652 = 1;
    }
    {
        object _i_26422;
        _i_26422 = 1LL;
L19: 
        if (_i_26422 > _14652){
            goto L1A; // [547] 631
        }

        /** scanner.e:540					if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (object)SEQ_PTR(_inc_path_26293);
        _14653 = (object)*(((s1_ptr)_2)->base + _i_26422);
        if (IS_SEQUENCE(_14653)){
                _14654 = SEQ_PTR(_14653)->length;
        }
        else {
            _14654 = 1;
        }
        _2 = (object)SEQ_PTR(_14653);
        _14655 = (object)*(((s1_ptr)_2)->base + _14654);
        _14653 = NOVALUE;
        _14656 = find_from(_14655, _46SLASH_CHARS_21927, 1LL);
        _14655 = NOVALUE;
        if (_14656 == 0)
        {
            _14656 = NOVALUE;
            goto L1B; // [574] 598
        }
        else{
            _14656 = NOVALUE;
        }

        /** scanner.e:541						errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (object)SEQ_PTR(_inc_path_26293);
        _14657 = (object)*(((s1_ptr)_2)->base + _i_26422);
        if (IS_SEQUENCE(_14657)){
                _14658 = SEQ_PTR(_14657)->length;
        }
        else {
            _14658 = 1;
        }
        _14659 = _14658 - 1LL;
        _14658 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_26289;
        RHS_Slice(_14657, 1LL, _14659);
        _14657 = NOVALUE;
        goto L1C; // [595] 607
L1B: 

        /** scanner.e:543						errbuff = inc_path[i]*/
        DeRef(_errbuff_26289);
        _2 = (object)SEQ_PTR(_inc_path_26293);
        _errbuff_26289 = (object)*(((s1_ptr)_2)->base + _i_26422);
        Ref(_errbuff_26289);
L1C: 

        /** scanner.e:545					if not find(errbuff, full_path) then*/
        _14662 = find_from(_errbuff_26289, _full_path_26288, 1LL);
        if (_14662 != 0)
        goto L1D; // [614] 624
        _14662 = NOVALUE;

        /** scanner.e:546						full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_26289);
        Append(&_full_path_26288, _full_path_26288, _errbuff_26289);
L1D: 

        /** scanner.e:548				end for*/
        _i_26422 = _i_26422 + 1LL;
        goto L19; // [626] 554
L1A: 
        ;
    }
L18: 
L17: 

    /** scanner.e:552		if length(get_eudir()) > 0 then*/
    _14665 = _37get_eudir();
    if (IS_SEQUENCE(_14665)){
            _14666 = SEQ_PTR(_14665)->length;
    }
    else {
        _14666 = 1;
    }
    DeRef(_14665);
    _14665 = NOVALUE;
    if (_14666 <= 0LL)
    goto L1E; // [641] 669

    /** scanner.e:553			if not find(get_eudir(), full_path) then*/
    _14668 = _37get_eudir();
    _14669 = find_from(_14668, _full_path_26288, 1LL);
    DeRef(_14668);
    _14668 = NOVALUE;
    if (_14669 != 0)
    goto L1F; // [655] 668
    _14669 = NOVALUE;

    /** scanner.e:554				full_path = append(full_path, get_eudir())*/
    _14671 = _37get_eudir();
    Ref(_14671);
    Append(&_full_path_26288, _full_path_26288, _14671);
    DeRef(_14671);
    _14671 = NOVALUE;
L1F: 
L1E: 

    /** scanner.e:558		errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_26289);
    _errbuff_26289 = _5;

    /** scanner.e:559		for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_26288)){
            _14673 = SEQ_PTR(_full_path_26288)->length;
    }
    else {
        _14673 = 1;
    }
    {
        object _i_26454;
        _i_26454 = 1LL;
L20: 
        if (_i_26454 > _14673){
            goto L21; // [681] 713
        }

        /** scanner.e:560			errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (object)SEQ_PTR(_full_path_26288);
        _14675 = (object)*(((s1_ptr)_2)->base + _i_26454);
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_14675);
        ((intptr_t*)_2)[1] = _14675;
        _14676 = MAKE_SEQ(_1);
        _14675 = NOVALUE;
        _14677 = EPrintf(-9999999, _14674, _14676);
        DeRefDS(_14676);
        _14676 = NOVALUE;
        Concat((object_ptr)&_errbuff_26289, _errbuff_26289, _14677);
        DeRefDS(_14677);
        _14677 = NOVALUE;

        /** scanner.e:561		end for*/
        _i_26454 = _i_26454 + 1LL;
        goto L20; // [708] 688
L21: 
        ;
    }

    /** scanner.e:563		CompileErr(CANT_FIND_1_IN_ANY_OF_2, {new_include_name, errbuff})*/
    RefDS(_errbuff_26289);
    RefDS(_36new_include_name_21885);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _36new_include_name_21885;
    ((intptr_t *)_2)[2] = _errbuff_26289;
    _14679 = MAKE_SEQ(_1);
    _50CompileErr(52LL, _14679, 0LL);
    _14679 = NOVALUE;
    ;
}


object _62path_open()
{
    object _fh_26467 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:569		new_include_name = find_file(new_include_name)*/
    RefDS(_36new_include_name_21885);
    _0 = _62find_file(_36new_include_name_21885);
    DeRefDS(_36new_include_name_21885);
    _36new_include_name_21885 = _0;

    /** scanner.e:570		new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_36new_include_name_21885);
    _0 = _64maybe_preprocess(_36new_include_name_21885);
    DeRefDS(_36new_include_name_21885);
    _36new_include_name_21885 = _0;

    /** scanner.e:572		fh = open_locked(new_include_name)*/
    RefDS(_36new_include_name_21885);
    _fh_26467 = _37open_locked(_36new_include_name_21885);
    if (!IS_ATOM_INT(_fh_26467)) {
        _1 = (object)(DBL_PTR(_fh_26467)->dbl);
        DeRefDS(_fh_26467);
        _fh_26467 = _1;
    }

    /** scanner.e:573		return fh*/
    return _fh_26467;
    ;
}


object _62NameSpace_declaration(object _sym_26495)
{
    object _h_26496 = NOVALUE;
    object _14703 = NOVALUE;
    object _14701 = NOVALUE;
    object _14699 = NOVALUE;
    object _14697 = NOVALUE;
    object _14696 = NOVALUE;
    object _14695 = NOVALUE;
    object _14693 = NOVALUE;
    object _14692 = NOVALUE;
    object _14691 = NOVALUE;
    object _14690 = NOVALUE;
    object _14689 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_26495)) {
        _1 = (object)(DBL_PTR(_sym_26495)->dbl);
        DeRefDS(_sym_26495);
        _sym_26495 = _1;
    }

    /** scanner.e:594		DefinedYet(sym)*/
    _54DefinedYet(_sym_26495);

    /** scanner.e:595		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14689 = (object)*(((s1_ptr)_2)->base + _sym_26495);
    _2 = (object)SEQ_PTR(_14689);
    _14690 = (object)*(((s1_ptr)_2)->base + 4LL);
    _14689 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 11LL;
    ((intptr_t*)_2)[4] = 7LL;
    _14691 = MAKE_SEQ(_1);
    _14692 = find_from(_14690, _14691, 1LL);
    _14690 = NOVALUE;
    DeRefDS(_14691);
    _14691 = NOVALUE;
    if (_14692 == 0)
    {
        _14692 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _14692 = NOVALUE;
    }

    /** scanner.e:597			h = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14693 = (object)*(((s1_ptr)_2)->base + _sym_26495);
    _2 = (object)SEQ_PTR(_14693);
    _h_26496 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_h_26496)){
        _h_26496 = (object)DBL_PTR(_h_26496)->dbl;
    }
    _14693 = NOVALUE;

    /** scanner.e:599			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14695 = (object)*(((s1_ptr)_2)->base + _sym_26495);
    _2 = (object)SEQ_PTR(_14695);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _14696 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _14696 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _14695 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _14697 = (object)*(((s1_ptr)_2)->base + _h_26496);
    Ref(_14696);
    Ref(_14697);
    _sym_26495 = _54NewEntry(_14696, 0LL, 0LL, -100LL, _h_26496, _14697, 0LL);
    _14696 = NOVALUE;
    _14697 = NOVALUE;
    if (!IS_ATOM_INT(_sym_26495)) {
        _1 = (object)(DBL_PTR(_sym_26495)->dbl);
        DeRefDS(_sym_26495);
        _sym_26495 = _1;
    }

    /** scanner.e:600			buckets[h] = sym*/
    _2 = (object)SEQ_PTR(_54buckets_47128);
    _2 = (object)(((s1_ptr)_2)->base + _h_26496);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_26495;
    DeRef(_1);
L1: 

    /** scanner.e:602		SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26495 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 5LL;
    DeRef(_1);
    _14699 = NOVALUE;

    /** scanner.e:603		SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26495 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _14701 = NOVALUE;

    /** scanner.e:604		SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26495 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21401))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 523LL;
    DeRef(_1);
    _14703 = NOVALUE;

    /** scanner.e:605		if TRANSLATE then*/
    if (_36TRANSLATE_21361 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** scanner.e:606			num_routines += 1 -- order of ns declaration relative to routines*/
    _36num_routines_21768 = _36num_routines_21768 + 1LL;
L2: 

    /** scanner.e:609		return sym*/
    return _sym_26495;
    ;
}


void _62default_namespace()
{
    object _tok_26546 = NOVALUE;
    object _sym_26548 = NOVALUE;
    object _14727 = NOVALUE;
    object _14726 = NOVALUE;
    object _14724 = NOVALUE;
    object _14722 = NOVALUE;
    object _14719 = NOVALUE;
    object _14716 = NOVALUE;
    object _14714 = NOVALUE;
    object _14712 = NOVALUE;
    object _14711 = NOVALUE;
    object _14710 = NOVALUE;
    object _14709 = NOVALUE;
    object _14708 = NOVALUE;
    object _14707 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:618		tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26542].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26546);
    _tok_26546 = _1;

    /** scanner.e:619		if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (object)SEQ_PTR(_tok_26546);
    _14707 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_14707)) {
        _14708 = (_14707 == -100LL);
    }
    else {
        _14708 = binary_op(EQUALS, _14707, -100LL);
    }
    _14707 = NOVALUE;
    if (IS_ATOM_INT(_14708)) {
        if (_14708 == 0) {
            goto L1; // [23] 179
        }
    }
    else {
        if (DBL_PTR(_14708)->dbl == 0.0) {
            goto L1; // [23] 179
        }
    }
    _2 = (object)SEQ_PTR(_tok_26546);
    _14710 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_14710)){
        _14711 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14710)->dbl));
    }
    else{
        _14711 = (object)*(((s1_ptr)_2)->base + _14710);
    }
    _2 = (object)SEQ_PTR(_14711);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _14712 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _14712 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _14711 = NOVALUE;
    if (_14712 == _14713)
    _14714 = 1;
    else if (IS_ATOM_INT(_14712) && IS_ATOM_INT(_14713))
    _14714 = 0;
    else
    _14714 = (compare(_14712, _14713) == 0);
    _14712 = NOVALUE;
    if (_14714 == 0)
    {
        _14714 = NOVALUE;
        goto L1; // [50] 179
    }
    else{
        _14714 = NOVALUE;
    }

    /** scanner.e:621			tok = call_func( scanner_rid, {} )*/
    _0 = (object)_00[_62scanner_rid_26542].addr;
    _1 = (*(intptr_t (*)())_0)(
                         );
    DeRef(_tok_26546);
    _tok_26546 = _1;

    /** scanner.e:622			if tok[T_ID] != VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_26546);
    _14716 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _14716, -100LL)){
        _14716 = NOVALUE;
        goto L2; // [71] 85
    }
    _14716 = NOVALUE;

    /** scanner.e:623				CompileErr(MISSING_DEFAULT_NAMESPACE_QUALIFIER)*/
    RefDS(_22186);
    _50CompileErr(114LL, _22186, 0LL);
L2: 

    /** scanner.e:626			sym = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_26546);
    _sym_26548 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_sym_26548)){
        _sym_26548 = (object)DBL_PTR(_sym_26548)->dbl;
    }

    /** scanner.e:628			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26548 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21392))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21759;
    DeRef(_1);
    _14719 = NOVALUE;

    /** scanner.e:629			sym  = NameSpace_declaration( sym )*/
    _sym_26548 = _62NameSpace_declaration(_sym_26548);
    if (!IS_ATOM_INT(_sym_26548)) {
        _1 = (object)(DBL_PTR(_sym_26548)->dbl);
        DeRefDS(_sym_26548);
        _sym_26548 = _1;
    }

    /** scanner.e:630			SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26548 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21759;
    DeRef(_1);
    _14722 = NOVALUE;

    /** scanner.e:631			SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_sym_26548 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 13LL;
    DeRef(_1);
    _14724 = NOVALUE;

    /** scanner.e:633			default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _14726 = (object)*(((s1_ptr)_2)->base + _sym_26548);
    _2 = (object)SEQ_PTR(_14726);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _14727 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _14727 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _14726 = NOVALUE;
    Ref(_14727);
    _2 = (object)SEQ_PTR(_62default_namespaces_25873);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14727;
    if( _1 != _14727 ){
        DeRef(_1);
    }
    _14727 = NOVALUE;
    goto L3; // [176] 187
L1: 

    /** scanner.e:637			bp = 1*/
    _50bp_49594 = 1LL;
L3: 

    /** scanner.e:640	end procedure*/
    DeRef(_tok_26546);
    _14710 = NOVALUE;
    DeRef(_14708);
    _14708 = NOVALUE;
    return;
    ;
}


void _62add_exports(object _from_file_26599, object _to_file_26600)
{
    object _exports_26601 = NOVALUE;
    object _direct_26602 = NOVALUE;
    object _14747 = NOVALUE;
    object _14746 = NOVALUE;
    object _14745 = NOVALUE;
    object _14744 = NOVALUE;
    object _14743 = NOVALUE;
    object _14741 = NOVALUE;
    object _14739 = NOVALUE;
    object _14738 = NOVALUE;
    object _14736 = NOVALUE;
    object _14735 = NOVALUE;
    object _14734 = NOVALUE;
    object _14732 = NOVALUE;
    object _14731 = NOVALUE;
    object _14730 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:645		direct = file_include[to_file]*/
    DeRef(_direct_26602);
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _direct_26602 = (object)*(((s1_ptr)_2)->base + _to_file_26600);
    Ref(_direct_26602);

    /** scanner.e:646		exports = file_public[from_file]*/
    DeRef(_exports_26601);
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _exports_26601 = (object)*(((s1_ptr)_2)->base + _from_file_26599);
    Ref(_exports_26601);

    /** scanner.e:647		for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_26601)){
            _14730 = SEQ_PTR(_exports_26601)->length;
    }
    else {
        _14730 = 1;
    }
    {
        object _i_26608;
        _i_26608 = 1LL;
L1: 
        if (_i_26608 > _14730){
            goto L2; // [30] 127
        }

        /** scanner.e:648			if not find( exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26601);
        _14731 = (object)*(((s1_ptr)_2)->base + _i_26608);
        _14732 = find_from(_14731, _direct_26602, 1LL);
        _14731 = NOVALUE;
        if (_14732 != 0)
        goto L3; // [48] 120
        _14732 = NOVALUE;

        /** scanner.e:649				if not find( -exports[i], direct ) then*/
        _2 = (object)SEQ_PTR(_exports_26601);
        _14734 = (object)*(((s1_ptr)_2)->base + _i_26608);
        if (IS_ATOM_INT(_14734)) {
            if ((uintptr_t)_14734 == (uintptr_t)HIGH_BITS){
                _14735 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14735 = - _14734;
            }
        }
        else {
            _14735 = unary_op(UMINUS, _14734);
        }
        _14734 = NOVALUE;
        _14736 = find_from(_14735, _direct_26602, 1LL);
        DeRef(_14735);
        _14735 = NOVALUE;
        if (_14736 != 0)
        goto L4; // [65] 82
        _14736 = NOVALUE;

        /** scanner.e:650					direct &= -exports[i]*/
        _2 = (object)SEQ_PTR(_exports_26601);
        _14738 = (object)*(((s1_ptr)_2)->base + _i_26608);
        if (IS_ATOM_INT(_14738)) {
            if ((uintptr_t)_14738 == (uintptr_t)HIGH_BITS){
                _14739 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _14739 = - _14738;
            }
        }
        else {
            _14739 = unary_op(UMINUS, _14738);
        }
        _14738 = NOVALUE;
        if (IS_SEQUENCE(_direct_26602) && IS_ATOM(_14739)) {
            Ref(_14739);
            Append(&_direct_26602, _direct_26602, _14739);
        }
        else if (IS_ATOM(_direct_26602) && IS_SEQUENCE(_14739)) {
        }
        else {
            Concat((object_ptr)&_direct_26602, _direct_26602, _14739);
        }
        DeRef(_14739);
        _14739 = NOVALUE;
L4: 

        /** scanner.e:654				include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        _3 = (object)(_to_file_26600 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_exports_26601);
        _14743 = (object)*(((s1_ptr)_2)->base + _i_26608);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14744 = (object)*(((s1_ptr)_2)->base + _to_file_26600);
        _2 = (object)SEQ_PTR(_exports_26601);
        _14745 = (object)*(((s1_ptr)_2)->base + _i_26608);
        _2 = (object)SEQ_PTR(_14744);
        if (!IS_ATOM_INT(_14745)){
            _14746 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14745)->dbl));
        }
        else{
            _14746 = (object)*(((s1_ptr)_2)->base + _14745);
        }
        _14744 = NOVALUE;
        if (IS_ATOM_INT(_14746)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14746;
                 _14747 = MAKE_UINT(tu);
            }
        }
        else {
            _14747 = binary_op(OR_BITS, 4LL, _14746);
        }
        _14746 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14743))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14743)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _14743);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14747;
        if( _1 != _14747 ){
            DeRef(_1);
        }
        _14747 = NOVALUE;
        _14741 = NOVALUE;
L3: 

        /** scanner.e:656		end for*/
        _i_26608 = _i_26608 + 1LL;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** scanner.e:657		file_include[to_file] = direct*/
    RefDS(_direct_26602);
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _to_file_26600);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _direct_26602;
    DeRef(_1);

    /** scanner.e:658	end procedure*/
    DeRef(_exports_26601);
    DeRefDS(_direct_26602);
    _14743 = NOVALUE;
    _14745 = NOVALUE;
    return;
    ;
}


void _62patch_exports(object _for_file_26635)
{
    object _export_len_26636 = NOVALUE;
    object _14758 = NOVALUE;
    object _14757 = NOVALUE;
    object _14755 = NOVALUE;
    object _14754 = NOVALUE;
    object _14753 = NOVALUE;
    object _14752 = NOVALUE;
    object _14750 = NOVALUE;
    object _14749 = NOVALUE;
    object _14748 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:663		for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14748 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14748 = 1;
    }
    {
        object _i_26638;
        _i_26638 = 1LL;
L1: 
        if (_i_26638 > _14748){
            goto L2; // [10] 99
        }

        /** scanner.e:664			if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14749 = (object)*(((s1_ptr)_2)->base + _i_26638);
        _14750 = find_from(_for_file_26635, _14749, 1LL);
        _14749 = NOVALUE;
        if (_14750 != 0) {
            goto L3; // [30] 53
        }
        if ((uintptr_t)_for_file_26635 == (uintptr_t)HIGH_BITS){
            _14752 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _14752 = - _for_file_26635;
        }
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14753 = (object)*(((s1_ptr)_2)->base + _i_26638);
        _14754 = find_from(_14752, _14753, 1LL);
        DeRef(_14752);
        _14752 = NOVALUE;
        _14753 = NOVALUE;
        if (_14754 == 0)
        {
            _14754 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _14754 = NOVALUE;
        }
L3: 

        /** scanner.e:665				export_len = length( file_include[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14755 = (object)*(((s1_ptr)_2)->base + _i_26638);
        if (IS_SEQUENCE(_14755)){
                _export_len_26636 = SEQ_PTR(_14755)->length;
        }
        else {
            _export_len_26636 = 1;
        }
        _14755 = NOVALUE;

        /** scanner.e:666				add_exports( for_file, i )*/
        _62add_exports(_for_file_26635, _i_26638);

        /** scanner.e:667				if length( file_include[i] ) != export_len then*/
        _2 = (object)SEQ_PTR(_37file_include_15642);
        _14757 = (object)*(((s1_ptr)_2)->base + _i_26638);
        if (IS_SEQUENCE(_14757)){
                _14758 = SEQ_PTR(_14757)->length;
        }
        else {
            _14758 = 1;
        }
        _14757 = NOVALUE;
        if (_14758 == _export_len_26636)
        goto L5; // [81] 91

        /** scanner.e:669					patch_exports( i )*/
        _62patch_exports(_i_26638);
L5: 
L4: 

        /** scanner.e:672		end for*/
        _i_26638 = _i_26638 + 1LL;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** scanner.e:673	end procedure*/
    _14755 = NOVALUE;
    _14757 = NOVALUE;
    return;
    ;
}


void _62update_include_matrix(object _included_file_26660, object _from_file_26661)
{
    object _add_public_26671 = NOVALUE;
    object _px_26689 = NOVALUE;
    object _indirect_26748 = NOVALUE;
    object _mask_26751 = NOVALUE;
    object _ix_26762 = NOVALUE;
    object _indirect_file_26766 = NOVALUE;
    object _14834 = NOVALUE;
    object _14833 = NOVALUE;
    object _14831 = NOVALUE;
    object _14830 = NOVALUE;
    object _14829 = NOVALUE;
    object _14828 = NOVALUE;
    object _14827 = NOVALUE;
    object _14826 = NOVALUE;
    object _14825 = NOVALUE;
    object _14824 = NOVALUE;
    object _14823 = NOVALUE;
    object _14820 = NOVALUE;
    object _14818 = NOVALUE;
    object _14817 = NOVALUE;
    object _14816 = NOVALUE;
    object _14814 = NOVALUE;
    object _14812 = NOVALUE;
    object _14811 = NOVALUE;
    object _14809 = NOVALUE;
    object _14808 = NOVALUE;
    object _14807 = NOVALUE;
    object _14806 = NOVALUE;
    object _14805 = NOVALUE;
    object _14803 = NOVALUE;
    object _14802 = NOVALUE;
    object _14801 = NOVALUE;
    object _14800 = NOVALUE;
    object _14799 = NOVALUE;
    object _14798 = NOVALUE;
    object _14796 = NOVALUE;
    object _14795 = NOVALUE;
    object _14794 = NOVALUE;
    object _14792 = NOVALUE;
    object _14791 = NOVALUE;
    object _14790 = NOVALUE;
    object _14789 = NOVALUE;
    object _14788 = NOVALUE;
    object _14787 = NOVALUE;
    object _14786 = NOVALUE;
    object _14785 = NOVALUE;
    object _14784 = NOVALUE;
    object _14783 = NOVALUE;
    object _14782 = NOVALUE;
    object _14780 = NOVALUE;
    object _14779 = NOVALUE;
    object _14777 = NOVALUE;
    object _14775 = NOVALUE;
    object _14773 = NOVALUE;
    object _14772 = NOVALUE;
    object _14771 = NOVALUE;
    object _14770 = NOVALUE;
    object _14768 = NOVALUE;
    object _14767 = NOVALUE;
    object _14766 = NOVALUE;
    object _14764 = NOVALUE;
    object _14763 = NOVALUE;
    object _14762 = NOVALUE;
    object _14760 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:684		include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_from_file_26661 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14762 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    _2 = (object)SEQ_PTR(_14762);
    _14763 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
    _14762 = NOVALUE;
    if (IS_ATOM_INT(_14763)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_14763;
             _14764 = MAKE_UINT(tu);
        }
    }
    else {
        _14764 = binary_op(OR_BITS, 2LL, _14763);
    }
    _14763 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26660);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14764;
    if( _1 != _14764 ){
        DeRef(_1);
    }
    _14764 = NOVALUE;
    _14760 = NOVALUE;

    /** scanner.e:686		if public_include then*/
    if (_62public_include_25870 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** scanner.e:689			sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_26671);
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _add_public_26671 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    Ref(_add_public_26671);

    /** scanner.e:690			for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_26671)){
            _14766 = SEQ_PTR(_add_public_26671)->length;
    }
    else {
        _14766 = 1;
    }
    {
        object _i_26675;
        _i_26675 = 1LL;
L2: 
        if (_i_26675 > _14766){
            goto L3; // [56] 107
        }

        /** scanner.e:692				include_matrix[add_public[i]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26671);
        _14767 = (object)*(((s1_ptr)_2)->base + _i_26675);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14767))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14767)->dbl));
        else
        _3 = (object)(_14767 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26671);
        _14770 = (object)*(((s1_ptr)_2)->base + _i_26675);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!IS_ATOM_INT(_14770)){
            _14771 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14770)->dbl));
        }
        else{
            _14771 = (object)*(((s1_ptr)_2)->base + _14770);
        }
        _2 = (object)SEQ_PTR(_14771);
        _14772 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
        _14771 = NOVALUE;
        if (IS_ATOM_INT(_14772)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14772;
                 _14773 = MAKE_UINT(tu);
            }
        }
        else {
            _14773 = binary_op(OR_BITS, 4LL, _14772);
        }
        _14772 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26660);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14773;
        if( _1 != _14773 ){
            DeRef(_1);
        }
        _14773 = NOVALUE;
        _14768 = NOVALUE;

        /** scanner.e:695			end for*/
        _i_26675 = _i_26675 + 1LL;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** scanner.e:698			add_public = file_public_by[from_file]*/
    DeRef(_add_public_26671);
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _add_public_26671 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    Ref(_add_public_26671);

    /** scanner.e:699			integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_26671)){
            _14775 = SEQ_PTR(_add_public_26671)->length;
    }
    else {
        _14775 = 1;
    }
    _px_26689 = _14775 + 1;
    _14775 = NOVALUE;

    /** scanner.e:700			while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_26671)){
            _14777 = SEQ_PTR(_add_public_26671)->length;
    }
    else {
        _14777 = 1;
    }
    if (_px_26689 > _14777)
    goto L5; // [134] 338

    /** scanner.e:701				include_matrix[add_public[px]][included_file] =*/
    _2 = (object)SEQ_PTR(_add_public_26671);
    _14779 = (object)*(((s1_ptr)_2)->base + _px_26689);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_14779))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14779)->dbl));
    else
    _3 = (object)(_14779 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_add_public_26671);
    _14782 = (object)*(((s1_ptr)_2)->base + _px_26689);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!IS_ATOM_INT(_14782)){
        _14783 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14782)->dbl));
    }
    else{
        _14783 = (object)*(((s1_ptr)_2)->base + _14782);
    }
    _2 = (object)SEQ_PTR(_14783);
    _14784 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
    _14783 = NOVALUE;
    if (IS_ATOM_INT(_14784)) {
        {uintptr_t tu;
             tu = (uintptr_t)4LL | (uintptr_t)_14784;
             _14785 = MAKE_UINT(tu);
        }
    }
    else {
        _14785 = binary_op(OR_BITS, 4LL, _14784);
    }
    _14784 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26660);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14785;
    if( _1 != _14785 ){
        DeRef(_1);
    }
    _14785 = NOVALUE;
    _14780 = NOVALUE;

    /** scanner.e:704				for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26671);
    _14786 = (object)*(((s1_ptr)_2)->base + _px_26689);
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    if (!IS_ATOM_INT(_14786)){
        _14787 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14786)->dbl));
    }
    else{
        _14787 = (object)*(((s1_ptr)_2)->base + _14786);
    }
    if (IS_SEQUENCE(_14787)){
            _14788 = SEQ_PTR(_14787)->length;
    }
    else {
        _14788 = 1;
    }
    _14787 = NOVALUE;
    {
        object _i_26706;
        _i_26706 = 1LL;
L6: 
        if (_i_26706 > _14788){
            goto L7; // [190] 249
        }

        /** scanner.e:705					if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (object)SEQ_PTR(_add_public_26671);
        _14789 = (object)*(((s1_ptr)_2)->base + _px_26689);
        _2 = (object)SEQ_PTR(_37file_public_15648);
        if (!IS_ATOM_INT(_14789)){
            _14790 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14789)->dbl));
        }
        else{
            _14790 = (object)*(((s1_ptr)_2)->base + _14789);
        }
        _2 = (object)SEQ_PTR(_14790);
        _14791 = (object)*(((s1_ptr)_2)->base + _i_26706);
        _14790 = NOVALUE;
        _14792 = find_from(_14791, _add_public_26671, 1LL);
        _14791 = NOVALUE;
        if (_14792 != 0)
        goto L8; // [218] 242
        _14792 = NOVALUE;

        /** scanner.e:706						add_public &= file_public[add_public[px]][i]*/
        _2 = (object)SEQ_PTR(_add_public_26671);
        _14794 = (object)*(((s1_ptr)_2)->base + _px_26689);
        _2 = (object)SEQ_PTR(_37file_public_15648);
        if (!IS_ATOM_INT(_14794)){
            _14795 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14794)->dbl));
        }
        else{
            _14795 = (object)*(((s1_ptr)_2)->base + _14794);
        }
        _2 = (object)SEQ_PTR(_14795);
        _14796 = (object)*(((s1_ptr)_2)->base + _i_26706);
        _14795 = NOVALUE;
        if (IS_SEQUENCE(_add_public_26671) && IS_ATOM(_14796)) {
            Ref(_14796);
            Append(&_add_public_26671, _add_public_26671, _14796);
        }
        else if (IS_ATOM(_add_public_26671) && IS_SEQUENCE(_14796)) {
        }
        else {
            Concat((object_ptr)&_add_public_26671, _add_public_26671, _14796);
        }
        _14796 = NOVALUE;
L8: 

        /** scanner.e:708				end for*/
        _i_26706 = _i_26706 + 1LL;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** scanner.e:710				for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (object)SEQ_PTR(_add_public_26671);
    _14798 = (object)*(((s1_ptr)_2)->base + _px_26689);
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    if (!IS_ATOM_INT(_14798)){
        _14799 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14798)->dbl));
    }
    else{
        _14799 = (object)*(((s1_ptr)_2)->base + _14798);
    }
    if (IS_SEQUENCE(_14799)){
            _14800 = SEQ_PTR(_14799)->length;
    }
    else {
        _14800 = 1;
    }
    _14799 = NOVALUE;
    {
        object _i_26724;
        _i_26724 = 1LL;
L9: 
        if (_i_26724 > _14800){
            goto LA; // [264] 327
        }

        /** scanner.e:711					include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (object)SEQ_PTR(_add_public_26671);
        _14801 = (object)*(((s1_ptr)_2)->base + _px_26689);
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        if (!IS_ATOM_INT(_14801)){
            _14802 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14801)->dbl));
        }
        else{
            _14802 = (object)*(((s1_ptr)_2)->base + _14801);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_14802))
        _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_14802)->dbl));
        else
        _3 = (object)(_14802 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_add_public_26671);
        _14805 = (object)*(((s1_ptr)_2)->base + _px_26689);
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        if (!IS_ATOM_INT(_14805)){
            _14806 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14805)->dbl));
        }
        else{
            _14806 = (object)*(((s1_ptr)_2)->base + _14805);
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!IS_ATOM_INT(_14806)){
            _14807 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_14806)->dbl));
        }
        else{
            _14807 = (object)*(((s1_ptr)_2)->base + _14806);
        }
        _2 = (object)SEQ_PTR(_14807);
        _14808 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
        _14807 = NOVALUE;
        if (IS_ATOM_INT(_14808)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14808;
                 _14809 = MAKE_UINT(tu);
            }
        }
        else {
            _14809 = binary_op(OR_BITS, 4LL, _14808);
        }
        _14808 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _included_file_26660);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14809;
        if( _1 != _14809 ){
            DeRef(_1);
        }
        _14809 = NOVALUE;
        _14803 = NOVALUE;

        /** scanner.e:713				end for*/
        _i_26724 = _i_26724 + 1LL;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** scanner.e:715				px += 1*/
    _px_26689 = _px_26689 + 1;

    /** scanner.e:716			end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_26671);
    _add_public_26671 = NOVALUE;

    /** scanner.e:721		if indirect_include[from_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    _14811 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    _2 = (object)SEQ_PTR(_14811);
    _14812 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
    _14811 = NOVALUE;
    if (_14812 == 0) {
        _14812 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_14812) && DBL_PTR(_14812)->dbl == 0.0){
            _14812 = NOVALUE;
            goto LB; // [353] 545
        }
        _14812 = NOVALUE;
    }
    _14812 = NOVALUE;

    /** scanner.e:723			sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_26748);
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _indirect_26748 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    Ref(_indirect_26748);

    /** scanner.e:725			sequence mask = include_matrix[included_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14814 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
    DeRef(_mask_26751);
    if (IS_ATOM_INT(_14814)) {
        _mask_26751 = (_14814 != 0LL);
    }
    else {
        _mask_26751 = binary_op(NOTEQ, _14814, 0LL);
    }
    _14814 = NOVALUE;

    /** scanner.e:726			include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14816 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    _14817 = binary_op(OR_BITS, _14816, _mask_26751);
    _14816 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _2 = (object)(((s1_ptr)_2)->base + _from_file_26661);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14817;
    if( _1 != _14817 ){
        DeRef(_1);
    }
    _14817 = NOVALUE;

    /** scanner.e:727			mask = include_matrix[from_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14818 = (object)*(((s1_ptr)_2)->base + _from_file_26661);
    DeRefDS(_mask_26751);
    if (IS_ATOM_INT(_14818)) {
        _mask_26751 = (_14818 != 0LL);
    }
    else {
        _mask_26751 = binary_op(NOTEQ, _14818, 0LL);
    }
    _14818 = NOVALUE;

    /** scanner.e:728			integer ix = 1*/
    _ix_26762 = 1LL;

    /** scanner.e:729			while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_26748)){
            _14820 = SEQ_PTR(_indirect_26748)->length;
    }
    else {
        _14820 = 1;
    }
    if (_ix_26762 > _14820)
    goto LD; // [425] 544

    /** scanner.e:730				integer indirect_file = indirect[ix]*/
    _2 = (object)SEQ_PTR(_indirect_26748);
    _indirect_file_26766 = (object)*(((s1_ptr)_2)->base + _ix_26762);
    if (!IS_ATOM_INT(_indirect_file_26766))
    _indirect_file_26766 = (object)DBL_PTR(_indirect_file_26766)->dbl;

    /** scanner.e:731				if indirect_include[indirect_file][included_file] then*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    _14823 = (object)*(((s1_ptr)_2)->base + _indirect_file_26766);
    _2 = (object)SEQ_PTR(_14823);
    _14824 = (object)*(((s1_ptr)_2)->base + _included_file_26660);
    _14823 = NOVALUE;
    if (_14824 == 0) {
        _14824 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_14824) && DBL_PTR(_14824)->dbl == 0.0){
            _14824 = NOVALUE;
            goto LE; // [447] 531
        }
        _14824 = NOVALUE;
    }
    _14824 = NOVALUE;

    /** scanner.e:732					include_matrix[indirect_file] =*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14825 = (object)*(((s1_ptr)_2)->base + _indirect_file_26766);
    _14826 = binary_op(OR_BITS, _mask_26751, _14825);
    _14825 = NOVALUE;
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _2 = (object)(((s1_ptr)_2)->base + _indirect_file_26766);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14826;
    if( _1 != _14826 ){
        DeRef(_1);
    }
    _14826 = NOVALUE;

    /** scanner.e:734					for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _14827 = (object)*(((s1_ptr)_2)->base + _indirect_file_26766);
    if (IS_SEQUENCE(_14827)){
            _14828 = SEQ_PTR(_14827)->length;
    }
    else {
        _14828 = 1;
    }
    _14827 = NOVALUE;
    {
        object _i_26777;
        _i_26777 = 1LL;
LF: 
        if (_i_26777 > _14828){
            goto L10; // [479] 530
        }

        /** scanner.e:736						if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        _14829 = (object)*(((s1_ptr)_2)->base + _indirect_file_26766);
        _2 = (object)SEQ_PTR(_14829);
        _14830 = (object)*(((s1_ptr)_2)->base + _i_26777);
        _14829 = NOVALUE;
        _14831 = find_from(_14830, _indirect_26748, 1LL);
        _14830 = NOVALUE;
        if (_14831 != 0)
        goto L11; // [503] 523
        _14831 = NOVALUE;

        /** scanner.e:737							indirect &= file_include_by[indirect_file][i]*/
        _2 = (object)SEQ_PTR(_37file_include_by_15650);
        _14833 = (object)*(((s1_ptr)_2)->base + _indirect_file_26766);
        _2 = (object)SEQ_PTR(_14833);
        _14834 = (object)*(((s1_ptr)_2)->base + _i_26777);
        _14833 = NOVALUE;
        if (IS_SEQUENCE(_indirect_26748) && IS_ATOM(_14834)) {
            Ref(_14834);
            Append(&_indirect_26748, _indirect_26748, _14834);
        }
        else if (IS_ATOM(_indirect_26748) && IS_SEQUENCE(_14834)) {
        }
        else {
            Concat((object_ptr)&_indirect_26748, _indirect_26748, _14834);
        }
        _14834 = NOVALUE;
L11: 

        /** scanner.e:740					end for*/
        _i_26777 = _i_26777 + 1LL;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** scanner.e:742				ix += 1*/
    _ix_26762 = _ix_26762 + 1;

    /** scanner.e:743			end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_26748);
    _indirect_26748 = NOVALUE;
    DeRef(_mask_26751);
    _mask_26751 = NOVALUE;

    /** scanner.e:746		public_include = FALSE*/
    _62public_include_25870 = _13FALSE_445;

    /** scanner.e:747	end procedure*/
    _14767 = NOVALUE;
    _14799 = NOVALUE;
    _14794 = NOVALUE;
    _14786 = NOVALUE;
    _14798 = NOVALUE;
    _14770 = NOVALUE;
    _14801 = NOVALUE;
    _14827 = NOVALUE;
    _14789 = NOVALUE;
    _14802 = NOVALUE;
    _14782 = NOVALUE;
    _14787 = NOVALUE;
    _14805 = NOVALUE;
    _14779 = NOVALUE;
    _14806 = NOVALUE;
    return;
    ;
}


void _62add_include_by(object _by_file_26795, object _included_file_26796, object _is_public_26797)
{
    object _14881 = NOVALUE;
    object _14880 = NOVALUE;
    object _14879 = NOVALUE;
    object _14877 = NOVALUE;
    object _14876 = NOVALUE;
    object _14875 = NOVALUE;
    object _14874 = NOVALUE;
    object _14872 = NOVALUE;
    object _14871 = NOVALUE;
    object _14870 = NOVALUE;
    object _14869 = NOVALUE;
    object _14868 = NOVALUE;
    object _14867 = NOVALUE;
    object _14866 = NOVALUE;
    object _14865 = NOVALUE;
    object _14863 = NOVALUE;
    object _14862 = NOVALUE;
    object _14861 = NOVALUE;
    object _14860 = NOVALUE;
    object _14858 = NOVALUE;
    object _14857 = NOVALUE;
    object _14856 = NOVALUE;
    object _14855 = NOVALUE;
    object _14853 = NOVALUE;
    object _14852 = NOVALUE;
    object _14851 = NOVALUE;
    object _14850 = NOVALUE;
    object _14848 = NOVALUE;
    object _14847 = NOVALUE;
    object _14846 = NOVALUE;
    object _14845 = NOVALUE;
    object _14844 = NOVALUE;
    object _14842 = NOVALUE;
    object _14841 = NOVALUE;
    object _14840 = NOVALUE;
    object _14839 = NOVALUE;
    object _14837 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:750		include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26795 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14839 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
    _2 = (object)SEQ_PTR(_14839);
    _14840 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    _14839 = NOVALUE;
    if (IS_ATOM_INT(_14840)) {
        {uintptr_t tu;
             tu = (uintptr_t)2LL | (uintptr_t)_14840;
             _14841 = MAKE_UINT(tu);
        }
    }
    else {
        _14841 = binary_op(OR_BITS, 2LL, _14840);
    }
    _14840 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26796);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14841;
    if( _1 != _14841 ){
        DeRef(_1);
    }
    _14841 = NOVALUE;
    _14837 = NOVALUE;

    /** scanner.e:751		if is_public then*/
    if (_is_public_26797 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** scanner.e:752			include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_by_file_26795 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14844 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
    _2 = (object)SEQ_PTR(_14844);
    _14845 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    _14844 = NOVALUE;
    if (IS_ATOM_INT(_14845)) {
        {uintptr_t tu;
             tu = (uintptr_t)4LL | (uintptr_t)_14845;
             _14846 = MAKE_UINT(tu);
        }
    }
    else {
        _14846 = binary_op(OR_BITS, 4LL, _14845);
    }
    _14845 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26796);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14846;
    if( _1 != _14846 ){
        DeRef(_1);
    }
    _14846 = NOVALUE;
    _14842 = NOVALUE;
L1: 

    /** scanner.e:754		if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _14847 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    _14848 = find_from(_by_file_26795, _14847, 1LL);
    _14847 = NOVALUE;
    if (_14848 != 0)
    goto L2; // [84] 104
    _14848 = NOVALUE;

    /** scanner.e:755			file_include_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _14850 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    if (IS_SEQUENCE(_14850) && IS_ATOM(_by_file_26795)) {
        Append(&_14851, _14850, _by_file_26795);
    }
    else if (IS_ATOM(_14850) && IS_SEQUENCE(_by_file_26795)) {
    }
    else {
        Concat((object_ptr)&_14851, _14850, _by_file_26795);
        _14850 = NOVALUE;
    }
    _14850 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_by_15650);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26796);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14851;
    if( _1 != _14851 ){
        DeRef(_1);
    }
    _14851 = NOVALUE;
L2: 

    /** scanner.e:758		if not find( included_file, file_include[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14852 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
    _14853 = find_from(_included_file_26796, _14852, 1LL);
    _14852 = NOVALUE;
    if (_14853 != 0)
    goto L3; // [117] 137
    _14853 = NOVALUE;

    /** scanner.e:759			file_include[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14855 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
    if (IS_SEQUENCE(_14855) && IS_ATOM(_included_file_26796)) {
        Append(&_14856, _14855, _included_file_26796);
    }
    else if (IS_ATOM(_14855) && IS_SEQUENCE(_included_file_26796)) {
    }
    else {
        Concat((object_ptr)&_14856, _14855, _included_file_26796);
        _14855 = NOVALUE;
    }
    _14855 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26795);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14856;
    if( _1 != _14856 ){
        DeRef(_1);
    }
    _14856 = NOVALUE;
L3: 

    /** scanner.e:762		if is_public then*/
    if (_is_public_26797 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** scanner.e:763			if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _14857 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    _14858 = find_from(_by_file_26795, _14857, 1LL);
    _14857 = NOVALUE;
    if (_14858 != 0)
    goto L5; // [155] 175
    _14858 = NOVALUE;

    /** scanner.e:764				file_public_by[included_file] &= by_file*/
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _14860 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    if (IS_SEQUENCE(_14860) && IS_ATOM(_by_file_26795)) {
        Append(&_14861, _14860, _by_file_26795);
    }
    else if (IS_ATOM(_14860) && IS_SEQUENCE(_by_file_26795)) {
    }
    else {
        Concat((object_ptr)&_14861, _14860, _by_file_26795);
        _14860 = NOVALUE;
    }
    _14860 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_by_15652);
    _2 = (object)(((s1_ptr)_2)->base + _included_file_26796);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14861;
    if( _1 != _14861 ){
        DeRef(_1);
    }
    _14861 = NOVALUE;
L5: 

    /** scanner.e:767			if not find( included_file, file_public[by_file] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14862 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
    _14863 = find_from(_included_file_26796, _14862, 1LL);
    _14862 = NOVALUE;
    if (_14863 != 0)
    goto L6; // [188] 208
    _14863 = NOVALUE;

    /** scanner.e:768				file_public[by_file] &= included_file*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14865 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
    if (IS_SEQUENCE(_14865) && IS_ATOM(_included_file_26796)) {
        Append(&_14866, _14865, _included_file_26796);
    }
    else if (IS_ATOM(_14865) && IS_SEQUENCE(_included_file_26796)) {
    }
    else {
        Concat((object_ptr)&_14866, _14865, _included_file_26796);
        _14865 = NOVALUE;
    }
    _14865 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _2 = (object)(((s1_ptr)_2)->base + _by_file_26795);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14866;
    if( _1 != _14866 ){
        DeRef(_1);
    }
    _14866 = NOVALUE;
L6: 
L4: 

    /** scanner.e:772		for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _14867 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
    if (IS_SEQUENCE(_14867)){
            _14868 = SEQ_PTR(_14867)->length;
    }
    else {
        _14868 = 1;
    }
    _14867 = NOVALUE;
    {
        object _propagate_26849;
        _propagate_26849 = 1LL;
L7: 
        if (_propagate_26849 > _14868){
            goto L8; // [220] 320
        }

        /** scanner.e:773			if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14869 = (object)*(((s1_ptr)_2)->base + _included_file_26796);
        _2 = (object)SEQ_PTR(_14869);
        _14870 = (object)*(((s1_ptr)_2)->base + _propagate_26849);
        _14869 = NOVALUE;
        if (IS_ATOM_INT(_14870)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL & (uintptr_t)_14870;
                 _14871 = MAKE_UINT(tu);
            }
        }
        else {
            _14871 = binary_op(AND_BITS, 4LL, _14870);
        }
        _14870 = NOVALUE;
        if (_14871 == 0) {
            DeRef(_14871);
            _14871 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_14871) && DBL_PTR(_14871)->dbl == 0.0){
                DeRef(_14871);
                _14871 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_14871);
            _14871 = NOVALUE;
        }
        DeRef(_14871);
        _14871 = NOVALUE;

        /** scanner.e:774				include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26795 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14874 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
        _2 = (object)SEQ_PTR(_14874);
        _14875 = (object)*(((s1_ptr)_2)->base + _propagate_26849);
        _14874 = NOVALUE;
        if (IS_ATOM_INT(_14875)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL | (uintptr_t)_14875;
                 _14876 = MAKE_UINT(tu);
            }
        }
        else {
            _14876 = binary_op(OR_BITS, 2LL, _14875);
        }
        _14875 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26849);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14876;
        if( _1 != _14876 ){
            DeRef(_1);
        }
        _14876 = NOVALUE;
        _14872 = NOVALUE;

        /** scanner.e:775				if is_public then*/
        if (_is_public_26797 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** scanner.e:776					include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37include_matrix_15644 = MAKE_SEQ(_2);
        }
        _3 = (object)(_by_file_26795 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14879 = (object)*(((s1_ptr)_2)->base + _by_file_26795);
        _2 = (object)SEQ_PTR(_14879);
        _14880 = (object)*(((s1_ptr)_2)->base + _propagate_26849);
        _14879 = NOVALUE;
        if (IS_ATOM_INT(_14880)) {
            {uintptr_t tu;
                 tu = (uintptr_t)4LL | (uintptr_t)_14880;
                 _14881 = MAKE_UINT(tu);
            }
        }
        else {
            _14881 = binary_op(OR_BITS, 4LL, _14880);
        }
        _14880 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _propagate_26849);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14881;
        if( _1 != _14881 ){
            DeRef(_1);
        }
        _14881 = NOVALUE;
        _14877 = NOVALUE;
LA: 
L9: 

        /** scanner.e:779		end for*/
        _propagate_26849 = _propagate_26849 + 1LL;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** scanner.e:780	end procedure*/
    _14867 = NOVALUE;
    return;
    ;
}


void _62IncludePush()
{
    object _new_file_handle_26878 = NOVALUE;
    object _old_file_no_26879 = NOVALUE;
    object _new_hash_26880 = NOVALUE;
    object _idx_26881 = NOVALUE;
    object _14968 = NOVALUE;
    object _14965 = NOVALUE;
    object _14963 = NOVALUE;
    object _14962 = NOVALUE;
    object _14961 = NOVALUE;
    object _14959 = NOVALUE;
    object _14958 = NOVALUE;
    object _14952 = NOVALUE;
    object _14951 = NOVALUE;
    object _14950 = NOVALUE;
    object _14949 = NOVALUE;
    object _14948 = NOVALUE;
    object _14947 = NOVALUE;
    object _14946 = NOVALUE;
    object _14943 = NOVALUE;
    object _14941 = NOVALUE;
    object _14939 = NOVALUE;
    object _14938 = NOVALUE;
    object _14937 = NOVALUE;
    object _14935 = NOVALUE;
    object _14934 = NOVALUE;
    object _14932 = NOVALUE;
    object _14931 = NOVALUE;
    object _14929 = NOVALUE;
    object _14928 = NOVALUE;
    object _14927 = NOVALUE;
    object _14926 = NOVALUE;
    object _14925 = NOVALUE;
    object _14924 = NOVALUE;
    object _14923 = NOVALUE;
    object _14919 = NOVALUE;
    object _14917 = NOVALUE;
    object _14916 = NOVALUE;
    object _14915 = NOVALUE;
    object _14914 = NOVALUE;
    object _14913 = NOVALUE;
    object _14912 = NOVALUE;
    object _14911 = NOVALUE;
    object _14910 = NOVALUE;
    object _14909 = NOVALUE;
    object _14907 = NOVALUE;
    object _14906 = NOVALUE;
    object _14905 = NOVALUE;
    object _14903 = NOVALUE;
    object _14902 = NOVALUE;
    object _14901 = NOVALUE;
    object _14900 = NOVALUE;
    object _14898 = NOVALUE;
    object _14897 = NOVALUE;
    object _14896 = NOVALUE;
    object _14895 = NOVALUE;
    object _14894 = NOVALUE;
    object _14892 = NOVALUE;
    object _14891 = NOVALUE;
    object _14890 = NOVALUE;
    object _14889 = NOVALUE;
    object _14887 = NOVALUE;
    object _14883 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:788		start_include = FALSE*/
    _62start_include_25867 = _13FALSE_445;

    /** scanner.e:790		new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_26878 = _62path_open();
    if (!IS_ATOM_INT(_new_file_handle_26878)) {
        _1 = (object)(DBL_PTR(_new_file_handle_26878)->dbl);
        DeRefDS(_new_file_handle_26878);
        _new_file_handle_26878 = _1;
    }

    /** scanner.e:792		new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_36new_include_name_21885);
    _14883 = _17canonical_path(_36new_include_name_21885, 0LL, 2LL);
    DeRef(_new_hash_26880);
    _new_hash_26880 = calc_hash(_14883, -5LL);
    DeRef(_14883);
    _14883 = NOVALUE;

    /** scanner.e:794		idx = find(new_hash, known_files_hash)*/
    _idx_26881 = find_from(_new_hash_26880, _37known_files_hash_15639, 1LL);

    /** scanner.e:795		if idx then*/
    if (_idx_26881 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** scanner.e:797			if new_include_space != 0 then*/
    if (_62new_include_space_25865 == 0LL)
    goto L2; // [49] 71

    /** scanner.e:798				SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25865 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26881;
    DeRef(_1);
    _14887 = NOVALUE;
L2: 

    /** scanner.e:801			close(new_file_handle)*/
    EClose(_new_file_handle_26878);

    /** scanner.e:803			if find( -idx, file_include[current_file_no] ) then*/
    if ((uintptr_t)_idx_26881 == (uintptr_t)HIGH_BITS){
        _14889 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14889 = - _idx_26881;
    }
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14890 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _14891 = find_from(_14889, _14890, 1LL);
    DeRef(_14889);
    _14889 = NOVALUE;
    _14890 = NOVALUE;
    if (_14891 == 0)
    {
        _14891 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14891 = NOVALUE;
    }

    /** scanner.e:805				file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_15642 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21759 + ((s1_ptr)_2)->base);
    if ((uintptr_t)_idx_26881 == (uintptr_t)HIGH_BITS){
        _14894 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _14894 = - _idx_26881;
    }
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14895 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _14896 = find_from(_14894, _14895, 1LL);
    DeRef(_14894);
    _14894 = NOVALUE;
    _14895 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14896);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _idx_26881;
    DeRef(_1);
    _14892 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** scanner.e:809			elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14897 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _14898 = find_from(_idx_26881, _14897, 1LL);
    _14897 = NOVALUE;
    if (_14898 != 0)
    goto L5; // [145] 227
    _14898 = NOVALUE;

    /** scanner.e:811				file_include[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14900 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_14900) && IS_ATOM(_idx_26881)) {
        Append(&_14901, _14900, _idx_26881);
    }
    else if (IS_ATOM(_14900) && IS_SEQUENCE(_idx_26881)) {
    }
    else {
        Concat((object_ptr)&_14901, _14900, _idx_26881);
        _14900 = NOVALUE;
    }
    _14900 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14901;
    if( _1 != _14901 ){
        DeRef(_1);
    }
    _14901 = NOVALUE;

    /** scanner.e:814				add_exports( idx, current_file_no )*/
    _62add_exports(_idx_26881, _36current_file_no_21759);

    /** scanner.e:816				if public_include then*/
    if (_62public_include_25870 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** scanner.e:818					if not find( idx, file_public[current_file_no] ) then*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14902 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _14903 = find_from(_idx_26881, _14902, 1LL);
    _14902 = NOVALUE;
    if (_14903 != 0)
    goto L7; // [196] 225
    _14903 = NOVALUE;

    /** scanner.e:819						file_public[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14905 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_14905) && IS_ATOM(_idx_26881)) {
        Append(&_14906, _14905, _idx_26881);
    }
    else if (IS_ATOM(_14905) && IS_SEQUENCE(_idx_26881)) {
    }
    else {
        Concat((object_ptr)&_14906, _14905, _idx_26881);
        _14905 = NOVALUE;
    }
    _14905 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14906;
    if( _1 != _14906 ){
        DeRef(_1);
    }
    _14906 = NOVALUE;

    /** scanner.e:820						patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21759);
L7: 
L6: 
L5: 
L4: 

    /** scanner.e:825			indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15646 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21759 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _idx_26881);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21838;
    DeRef(_1);
    _14907 = NOVALUE;

    /** scanner.e:826			add_include_by( current_file_no, idx, public_include )*/
    _62add_include_by(_36current_file_no_21759, _idx_26881, _62public_include_25870);

    /** scanner.e:827			update_include_matrix( idx, current_file_no )*/
    _62update_include_matrix(_idx_26881, _36current_file_no_21759);

    /** scanner.e:828			public_include = FALSE*/
    _62public_include_25870 = _13FALSE_445;

    /** scanner.e:829			read_line() -- we can't return without reading a line first*/
    _62read_line();

    /** scanner.e:830			if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    _14909 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    _14910 = find_from(_idx_26881, _14909, 1LL);
    _14909 = NOVALUE;
    _14911 = (_14910 == 0);
    _14910 = NOVALUE;
    if (_14911 == 0) {
        goto L8; // [293] 329
    }
    _2 = (object)SEQ_PTR(_37finished_files_15640);
    _14913 = (object)*(((s1_ptr)_2)->base + _idx_26881);
    _14914 = (_14913 == 0);
    _14913 = NOVALUE;
    if (_14914 == 0)
    {
        DeRef(_14914);
        _14914 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14914);
        _14914 = NOVALUE;
    }

    /** scanner.e:831				file_include_depend[current_file_no] &= idx*/
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    _14915 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_14915) && IS_ATOM(_idx_26881)) {
        Append(&_14916, _14915, _idx_26881);
    }
    else if (IS_ATOM(_14915) && IS_SEQUENCE(_idx_26881)) {
    }
    else {
        Concat((object_ptr)&_14916, _14915, _idx_26881);
        _14915 = NOVALUE;
    }
    _14915 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15641 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14916;
    if( _1 != _14916 ){
        DeRef(_1);
    }
    _14916 = NOVALUE;
L8: 

    /** scanner.e:833			return -- ignore it*/
    DeRef(_new_hash_26880);
    DeRef(_14911);
    _14911 = NOVALUE;
    return;
L1: 

    /** scanner.e:836		if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_62IncludeStk_25876)){
            _14917 = SEQ_PTR(_62IncludeStk_25876)->length;
    }
    else {
        _14917 = 1;
    }
    if (_14917 < 30LL)
    goto L9; // [342] 356

    /** scanner.e:837			CompileErr(INCLUDES_ARE_NESTED_TOO_DEEPLY)*/
    RefDS(_22186);
    _50CompileErr(104LL, _22186, 0LL);
L9: 

    /** scanner.e:840		IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _36current_file_no_21759;
    ((intptr_t*)_2)[2] = _36line_number_21760;
    ((intptr_t*)_2)[3] = _36src_file_21884;
    ((intptr_t*)_2)[4] = _36file_start_sym_21765;
    ((intptr_t*)_2)[5] = _36OpWarning_21830;
    ((intptr_t*)_2)[6] = _36OpTrace_21832;
    ((intptr_t*)_2)[7] = _36OpTypeCheck_21833;
    ((intptr_t*)_2)[8] = _36OpProfileTime_21835;
    ((intptr_t*)_2)[9] = _36OpProfileStatement_21834;
    RefDS(_36OpDefines_21836);
    ((intptr_t*)_2)[10] = _36OpDefines_21836;
    ((intptr_t*)_2)[11] = _36prev_OpWarning_21831;
    ((intptr_t*)_2)[12] = _36OpInline_21837;
    ((intptr_t*)_2)[13] = _36OpIndirectInclude_21838;
    ((intptr_t*)_2)[14] = _36putback_fwd_line_number_21762;
    Ref(_50putback_ForwardLine_49592);
    ((intptr_t*)_2)[15] = _50putback_ForwardLine_49592;
    ((intptr_t*)_2)[16] = _50putback_forward_bp_49596;
    ((intptr_t*)_2)[17] = _36last_fwd_line_number_21763;
    Ref(_50last_ForwardLine_49593);
    ((intptr_t*)_2)[18] = _50last_ForwardLine_49593;
    ((intptr_t*)_2)[19] = _50last_forward_bp_49597;
    Ref(_50ThisLine_49590);
    ((intptr_t*)_2)[20] = _50ThisLine_49590;
    ((intptr_t*)_2)[21] = _36fwd_line_number_21761;
    ((intptr_t*)_2)[22] = _50forward_bp_49595;
    _14919 = MAKE_SEQ(_1);
    RefDS(_14919);
    Append(&_62IncludeStk_25876, _62IncludeStk_25876, _14919);
    DeRefDS(_14919);
    _14919 = NOVALUE;

    /** scanner.e:864		file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_37file_include_15642, _37file_include_15642, _5);

    /** scanner.e:865		file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_37file_include_by_15650, _37file_include_by_15650, _5);

    /** scanner.e:866		for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_37include_matrix_15644)){
            _14923 = SEQ_PTR(_37include_matrix_15644)->length;
    }
    else {
        _14923 = 1;
    }
    {
        object _i_26994;
        _i_26994 = 1LL;
LA: 
        if (_i_26994 > _14923){
            goto LB; // [460] 506
        }

        /** scanner.e:867			include_matrix[i]   &= 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _14924 = (object)*(((s1_ptr)_2)->base + _i_26994);
        if (IS_SEQUENCE(_14924) && IS_ATOM(0LL)) {
            Append(&_14925, _14924, 0LL);
        }
        else if (IS_ATOM(_14924) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_14925, _14924, 0LL);
            _14924 = NOVALUE;
        }
        _14924 = NOVALUE;
        _2 = (object)SEQ_PTR(_37include_matrix_15644);
        _2 = (object)(((s1_ptr)_2)->base + _i_26994);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14925;
        if( _1 != _14925 ){
            DeRef(_1);
        }
        _14925 = NOVALUE;

        /** scanner.e:868			indirect_include[i] &= 0*/
        _2 = (object)SEQ_PTR(_37indirect_include_15646);
        _14926 = (object)*(((s1_ptr)_2)->base + _i_26994);
        if (IS_SEQUENCE(_14926) && IS_ATOM(0LL)) {
            Append(&_14927, _14926, 0LL);
        }
        else if (IS_ATOM(_14926) && IS_SEQUENCE(0LL)) {
        }
        else {
            Concat((object_ptr)&_14927, _14926, 0LL);
            _14926 = NOVALUE;
        }
        _14926 = NOVALUE;
        _2 = (object)SEQ_PTR(_37indirect_include_15646);
        _2 = (object)(((s1_ptr)_2)->base + _i_26994);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14927;
        if( _1 != _14927 ){
            DeRef(_1);
        }
        _14927 = NOVALUE;

        /** scanner.e:869		end for*/
        _i_26994 = _i_26994 + 1LL;
        goto LA; // [501] 467
LB: 
        ;
    }

    /** scanner.e:870		include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14928 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14928 = 1;
    }
    _14929 = Repeat(0LL, _14928);
    _14928 = NOVALUE;
    RefDS(_14929);
    Append(&_37include_matrix_15644, _37include_matrix_15644, _14929);
    DeRefDS(_14929);
    _14929 = NOVALUE;

    /** scanner.e:871		include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_37include_matrix_15644)){
            _14931 = SEQ_PTR(_37include_matrix_15644)->length;
    }
    else {
        _14931 = 1;
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_14931 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14934 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14934 = 1;
    }
    _14932 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14934);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _14932 = NOVALUE;

    /** scanner.e:872		include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37include_matrix_15644 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21759 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14937 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14937 = 1;
    }
    _14935 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14937);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _14935 = NOVALUE;

    /** scanner.e:874		indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14938 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14938 = 1;
    }
    _14939 = Repeat(0LL, _14938);
    _14938 = NOVALUE;
    RefDS(_14939);
    Append(&_37indirect_include_15646, _37indirect_include_15646, _14939);
    DeRefDS(_14939);
    _14939 = NOVALUE;

    /** scanner.e:875		indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (object)SEQ_PTR(_37indirect_include_15646);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37indirect_include_15646 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36current_file_no_21759 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14943 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14943 = 1;
    }
    _14941 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _14943);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36OpIndirectInclude_21838;
    DeRef(_1);
    _14941 = NOVALUE;

    /** scanner.e:876		OpIndirectInclude = 1*/
    _36OpIndirectInclude_21838 = 1LL;

    /** scanner.e:878		file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_37file_public_15648, _37file_public_15648, _5);

    /** scanner.e:879		file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_37file_public_by_15652, _37file_public_by_15652, _5);

    /** scanner.e:880		file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14946 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14946 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _14947 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_14947) && IS_ATOM(_14946)) {
        Append(&_14948, _14947, _14946);
    }
    else if (IS_ATOM(_14947) && IS_SEQUENCE(_14946)) {
    }
    else {
        Concat((object_ptr)&_14948, _14947, _14946);
        _14947 = NOVALUE;
    }
    _14947 = NOVALUE;
    _14946 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_15642);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14948;
    if( _1 != _14948 ){
        DeRef(_1);
    }
    _14948 = NOVALUE;

    /** scanner.e:881		add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14949 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14949 = 1;
    }
    _62add_include_by(_36current_file_no_21759, _14949, _62public_include_25870);
    _14949 = NOVALUE;

    /** scanner.e:882		if public_include then*/
    if (_62public_include_25870 == 0)
    {
        goto LC; // [675] 709
    }
    else{
    }

    /** scanner.e:883			file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_37file_public_15648)){
            _14950 = SEQ_PTR(_37file_public_15648)->length;
    }
    else {
        _14950 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _14951 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_14951) && IS_ATOM(_14950)) {
        Append(&_14952, _14951, _14950);
    }
    else if (IS_ATOM(_14951) && IS_SEQUENCE(_14950)) {
    }
    else {
        Concat((object_ptr)&_14952, _14951, _14950);
        _14951 = NOVALUE;
    }
    _14951 = NOVALUE;
    _14950 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_public_15648);
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14952;
    if( _1 != _14952 ){
        DeRef(_1);
    }
    _14952 = NOVALUE;

    /** scanner.e:884			patch_exports( current_file_no )*/
    _62patch_exports(_36current_file_no_21759);
LC: 

    /** scanner.e:887	ifdef STDDEBUG then*/

    /** scanner.e:893		src_file = new_file_handle*/
    _36src_file_21884 = _new_file_handle_26878;

    /** scanner.e:894		file_start_sym = last_sym*/
    _36file_start_sym_21765 = _54last_sym_47141;

    /** scanner.e:895		if current_file_no >= MAX_FILE then*/
    if (_36current_file_no_21759 < 256LL)
    goto LD; // [731] 745

    /** scanner.e:896			CompileErr(PROGRAM_INCLUDES_TOO_MANY_FILES)*/
    RefDS(_22186);
    _50CompileErr(126LL, _22186, 0LL);
LD: 

    /** scanner.e:898		known_files = append(known_files, new_include_name)*/
    RefDS(_36new_include_name_21885);
    Append(&_37known_files_15638, _37known_files_15638, _36new_include_name_21885);

    /** scanner.e:899		known_files_hash &= new_hash*/
    Ref(_new_hash_26880);
    Append(&_37known_files_hash_15639, _37known_files_hash_15639, _new_hash_26880);

    /** scanner.e:900		finished_files &= 0*/
    Append(&_37finished_files_15640, _37finished_files_15640, 0LL);

    /** scanner.e:901		file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _14958 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _14958 = 1;
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _14958;
    _14959 = MAKE_SEQ(_1);
    _14958 = NOVALUE;
    RefDS(_14959);
    Append(&_37file_include_depend_15641, _37file_include_depend_15641, _14959);
    DeRefDS(_14959);
    _14959 = NOVALUE;

    /** scanner.e:902		file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _14961 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _14961 = 1;
    }
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    _14962 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21759);
    if (IS_SEQUENCE(_14962) && IS_ATOM(_14961)) {
        Append(&_14963, _14962, _14961);
    }
    else if (IS_ATOM(_14962) && IS_SEQUENCE(_14961)) {
    }
    else {
        Concat((object_ptr)&_14963, _14962, _14961);
        _14962 = NOVALUE;
    }
    _14962 = NOVALUE;
    _14961 = NOVALUE;
    _2 = (object)SEQ_PTR(_37file_include_depend_15641);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37file_include_depend_15641 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _36current_file_no_21759);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _14963;
    if( _1 != _14963 ){
        DeRef(_1);
    }
    _14963 = NOVALUE;

    /** scanner.e:903		check_coverage()*/
    _51check_coverage();

    /** scanner.e:904		default_namespaces &= 0*/
    Append(&_62default_namespaces_25873, _62default_namespaces_25873, 0LL);

    /** scanner.e:906		update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_37file_include_15642)){
            _14965 = SEQ_PTR(_37file_include_15642)->length;
    }
    else {
        _14965 = 1;
    }
    _62update_include_matrix(_14965, _36current_file_no_21759);
    _14965 = NOVALUE;

    /** scanner.e:907		old_file_no = current_file_no*/
    _old_file_no_26879 = _36current_file_no_21759;

    /** scanner.e:908		current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _36current_file_no_21759 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _36current_file_no_21759 = 1;
    }

    /** scanner.e:909		line_number = 0*/
    _36line_number_21760 = 0LL;

    /** scanner.e:910		read_line()*/
    _62read_line();

    /** scanner.e:912		if new_include_space != 0 then*/
    if (_62new_include_space_25865 == 0LL)
    goto LE; // [877] 901

    /** scanner.e:913			SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_62new_include_space_25865 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21759;
    DeRef(_1);
    _14968 = NOVALUE;
LE: 

    /** scanner.e:915		default_namespace( )*/
    _62default_namespace();

    /** scanner.e:916	end procedure*/
    DeRef(_new_hash_26880);
    DeRef(_14911);
    _14911 = NOVALUE;
    return;
    ;
}


void _62update_include_completion(object _file_no_27105)
{
    object _fx_27114 = NOVALUE;
    object _14978 = NOVALUE;
    object _14977 = NOVALUE;
    object _14976 = NOVALUE;
    object _14975 = NOVALUE;
    object _14973 = NOVALUE;
    object _14972 = NOVALUE;
    object _14971 = NOVALUE;
    object _14970 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:919		for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_37file_include_depend_15641)){
            _14970 = SEQ_PTR(_37file_include_depend_15641)->length;
    }
    else {
        _14970 = 1;
    }
    {
        object _i_27107;
        _i_27107 = 1LL;
L1: 
        if (_i_27107 > _14970){
            goto L2; // [10] 114
        }

        /** scanner.e:920			if length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14971 = (object)*(((s1_ptr)_2)->base + _i_27107);
        if (IS_SEQUENCE(_14971)){
                _14972 = SEQ_PTR(_14971)->length;
        }
        else {
            _14972 = 1;
        }
        _14971 = NOVALUE;
        if (_14972 == 0)
        {
            _14972 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14972 = NOVALUE;
        }

        /** scanner.e:921				integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14973 = (object)*(((s1_ptr)_2)->base + _i_27107);
        _fx_27114 = find_from(_file_no_27105, _14973, 1LL);
        _14973 = NOVALUE;

        /** scanner.e:922				if fx then*/
        if (_fx_27114 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** scanner.e:923					file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14975 = (object)*(((s1_ptr)_2)->base + _i_27107);
        {
            s1_ptr assign_space = SEQ_PTR(_14975);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_27114)) ? _fx_27114 : (object)(DBL_PTR(_fx_27114)->dbl);
            int stop = (IS_ATOM_INT(_fx_27114)) ? _fx_27114 : (object)(DBL_PTR(_fx_27114)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
                RefDS(_14975);
                DeRef(_14976);
                _14976 = _14975;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14975), start, &_14976 );
                }
                else Tail(SEQ_PTR(_14975), stop+1, &_14976);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14975), start, &_14976);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14976);
                _14976 = _1;
            }
        }
        _14975 = NOVALUE;
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37file_include_depend_15641 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_27107);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _14976;
        if( _1 != _14976 ){
            DeRef(_1);
        }
        _14976 = NOVALUE;

        /** scanner.e:924					if not length( file_include_depend[i] ) then*/
        _2 = (object)SEQ_PTR(_37file_include_depend_15641);
        _14977 = (object)*(((s1_ptr)_2)->base + _i_27107);
        if (IS_SEQUENCE(_14977)){
                _14978 = SEQ_PTR(_14977)->length;
        }
        else {
            _14978 = 1;
        }
        _14977 = NOVALUE;
        if (_14978 != 0)
        goto L5; // [79] 103
        _14978 = NOVALUE;

        /** scanner.e:925						finished_files[i] = 1*/
        _2 = (object)SEQ_PTR(_37finished_files_15640);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37finished_files_15640 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_27107);
        *(intptr_t *)_2 = 1LL;

        /** scanner.e:926						if i != file_no then*/
        if (_i_27107 == _file_no_27105)
        goto L6; // [92] 102

        /** scanner.e:927							update_include_completion( i )*/
        _62update_include_completion(_i_27107);
L6: 
L5: 
L4: 
L3: 

        /** scanner.e:932		end for*/
        _i_27107 = _i_27107 + 1LL;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** scanner.e:933	end procedure*/
    _14971 = NOVALUE;
    _14977 = NOVALUE;
    return;
    ;
}


object _62IncludePop()
{
    object _top_27145 = NOVALUE;
    object _15009 = NOVALUE;
    object _15007 = NOVALUE;
    object _15006 = NOVALUE;
    object _14984 = NOVALUE;
    object _14982 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:940		update_include_completion( current_file_no )*/
    _62update_include_completion(_36current_file_no_21759);

    /** scanner.e:941		Resolve_forward_references()*/
    _44Resolve_forward_references(0LL);

    /** scanner.e:942		HideLocals()*/
    _54HideLocals();

    /** scanner.e:944		if src_file >= 0 then*/
    if (_36src_file_21884 < 0LL)
    goto L1; // [21] 39

    /** scanner.e:945			close(src_file)*/
    EClose(_36src_file_21884);

    /** scanner.e:946			src_file = -1*/
    _36src_file_21884 = -1LL;
L1: 

    /** scanner.e:949		if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_62IncludeStk_25876)){
            _14982 = SEQ_PTR(_62IncludeStk_25876)->length;
    }
    else {
        _14982 = 1;
    }
    if (_14982 != 0LL)
    goto L2; // [46] 59

    /** scanner.e:950			return FALSE  -- the end*/
    DeRef(_top_27145);
    return _13FALSE_445;
L2: 

    /** scanner.e:953		sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_62IncludeStk_25876)){
            _14984 = SEQ_PTR(_62IncludeStk_25876)->length;
    }
    else {
        _14984 = 1;
    }
    DeRef(_top_27145);
    _2 = (object)SEQ_PTR(_62IncludeStk_25876);
    _top_27145 = (object)*(((s1_ptr)_2)->base + _14984);
    RefDS(_top_27145);

    /** scanner.e:955		current_file_no    = top[FILE_NO]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36current_file_no_21759 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_36current_file_no_21759)){
        _36current_file_no_21759 = (object)DBL_PTR(_36current_file_no_21759)->dbl;
    }

    /** scanner.e:956		line_number        = top[LINE_NO]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36line_number_21760 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_36line_number_21760)){
        _36line_number_21760 = (object)DBL_PTR(_36line_number_21760)->dbl;
    }

    /** scanner.e:957		src_file           = top[FILE_PTR]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36src_file_21884 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_36src_file_21884)){
        _36src_file_21884 = (object)DBL_PTR(_36src_file_21884)->dbl;
    }

    /** scanner.e:958		file_start_sym     = top[FILE_START_SYM]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36file_start_sym_21765 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_36file_start_sym_21765)){
        _36file_start_sym_21765 = (object)DBL_PTR(_36file_start_sym_21765)->dbl;
    }

    /** scanner.e:959		OpWarning          = top[OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpWarning_21830 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_36OpWarning_21830)){
        _36OpWarning_21830 = (object)DBL_PTR(_36OpWarning_21830)->dbl;
    }

    /** scanner.e:960		OpTrace            = top[OP_TRACE]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpTrace_21832 = (object)*(((s1_ptr)_2)->base + 6LL);
    if (!IS_ATOM_INT(_36OpTrace_21832)){
        _36OpTrace_21832 = (object)DBL_PTR(_36OpTrace_21832)->dbl;
    }

    /** scanner.e:961		OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpTypeCheck_21833 = (object)*(((s1_ptr)_2)->base + 7LL);
    if (!IS_ATOM_INT(_36OpTypeCheck_21833)){
        _36OpTypeCheck_21833 = (object)DBL_PTR(_36OpTypeCheck_21833)->dbl;
    }

    /** scanner.e:962		OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpProfileTime_21835 = (object)*(((s1_ptr)_2)->base + 8LL);
    if (!IS_ATOM_INT(_36OpProfileTime_21835)){
        _36OpProfileTime_21835 = (object)DBL_PTR(_36OpProfileTime_21835)->dbl;
    }

    /** scanner.e:963		OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpProfileStatement_21834 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_36OpProfileStatement_21834)){
        _36OpProfileStatement_21834 = (object)DBL_PTR(_36OpProfileStatement_21834)->dbl;
    }

    /** scanner.e:964		OpDefines          = top[OP_DEFINES]*/
    DeRef(_36OpDefines_21836);
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpDefines_21836 = (object)*(((s1_ptr)_2)->base + 10LL);
    Ref(_36OpDefines_21836);

    /** scanner.e:965		prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36prev_OpWarning_21831 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_36prev_OpWarning_21831)){
        _36prev_OpWarning_21831 = (object)DBL_PTR(_36prev_OpWarning_21831)->dbl;
    }

    /** scanner.e:966		OpInline           = top[OP_INLINE]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpInline_21837 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (!IS_ATOM_INT(_36OpInline_21837)){
        _36OpInline_21837 = (object)DBL_PTR(_36OpInline_21837)->dbl;
    }

    /** scanner.e:967		OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36OpIndirectInclude_21838 = (object)*(((s1_ptr)_2)->base + 13LL);
    if (!IS_ATOM_INT(_36OpIndirectInclude_21838)){
        _36OpIndirectInclude_21838 = (object)DBL_PTR(_36OpIndirectInclude_21838)->dbl;
    }

    /** scanner.e:968		putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _36putback_fwd_line_number_21762 = _36line_number_21760;

    /** scanner.e:969		putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_50putback_ForwardLine_49592);
    _2 = (object)SEQ_PTR(_top_27145);
    _50putback_ForwardLine_49592 = (object)*(((s1_ptr)_2)->base + 15LL);
    Ref(_50putback_ForwardLine_49592);

    /** scanner.e:970		putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _50putback_forward_bp_49596 = (object)*(((s1_ptr)_2)->base + 16LL);
    if (!IS_ATOM_INT(_50putback_forward_bp_49596)){
        _50putback_forward_bp_49596 = (object)DBL_PTR(_50putback_forward_bp_49596)->dbl;
    }

    /** scanner.e:971		last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _36last_fwd_line_number_21763 = (object)*(((s1_ptr)_2)->base + 17LL);
    if (!IS_ATOM_INT(_36last_fwd_line_number_21763)){
        _36last_fwd_line_number_21763 = (object)DBL_PTR(_36last_fwd_line_number_21763)->dbl;
    }

    /** scanner.e:972		last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_50last_ForwardLine_49593);
    _2 = (object)SEQ_PTR(_top_27145);
    _50last_ForwardLine_49593 = (object)*(((s1_ptr)_2)->base + 18LL);
    Ref(_50last_ForwardLine_49593);

    /** scanner.e:973		last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _50last_forward_bp_49597 = (object)*(((s1_ptr)_2)->base + 19LL);
    if (!IS_ATOM_INT(_50last_forward_bp_49597)){
        _50last_forward_bp_49597 = (object)DBL_PTR(_50last_forward_bp_49597)->dbl;
    }

    /** scanner.e:974		ThisLine = top[THISLINE]*/
    DeRef(_50ThisLine_49590);
    _2 = (object)SEQ_PTR(_top_27145);
    _50ThisLine_49590 = (object)*(((s1_ptr)_2)->base + 20LL);
    Ref(_50ThisLine_49590);

    /** scanner.e:976		fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _36fwd_line_number_21761 = _36line_number_21760;

    /** scanner.e:977		forward_bp = top[FORWARD_BP]*/
    _2 = (object)SEQ_PTR(_top_27145);
    _50forward_bp_49595 = (object)*(((s1_ptr)_2)->base + 22LL);
    if (!IS_ATOM_INT(_50forward_bp_49595)){
        _50forward_bp_49595 = (object)DBL_PTR(_50forward_bp_49595)->dbl;
    }

    /** scanner.e:978		ForwardLine = ThisLine*/
    Ref(_50ThisLine_49590);
    DeRef(_50ForwardLine_49591);
    _50ForwardLine_49591 = _50ThisLine_49590;

    /** scanner.e:980		putback_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49590);
    DeRef(_50putback_ForwardLine_49592);
    _50putback_ForwardLine_49592 = _50ThisLine_49590;

    /** scanner.e:981		last_ForwardLine = ThisLine*/
    Ref(_50ThisLine_49590);
    DeRef(_50last_ForwardLine_49593);
    _50last_ForwardLine_49593 = _50ThisLine_49590;

    /** scanner.e:983		IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_62IncludeStk_25876)){
            _15006 = SEQ_PTR(_62IncludeStk_25876)->length;
    }
    else {
        _15006 = 1;
    }
    _15007 = _15006 - 1LL;
    _15006 = NOVALUE;
    rhs_slice_target = (object_ptr)&_62IncludeStk_25876;
    RHS_Slice(_62IncludeStk_25876, 1LL, _15007);

    /** scanner.e:984		SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36TopLevelSub_21766 + ((s1_ptr)_2)->base);
    RefDS(_36Code_21851);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_CODE_21408))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21408);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36Code_21851;
    DeRef(_1);
    _15009 = NOVALUE;

    /** scanner.e:987		return TRUE*/
    DeRefDS(_top_27145);
    _15007 = NOVALUE;
    return _13TRUE_447;
    ;
}


object _62MakeInt(object _text_27246, object _nBase_27247)
{
    object _num_27248 = NOVALUE;
    object _maxchk_27249 = NOVALUE;
    object _fnum_27250 = NOVALUE;
    object _digit_27251 = NOVALUE;
    object _15059 = NOVALUE;
    object _15057 = NOVALUE;
    object _15055 = NOVALUE;
    object _15052 = NOVALUE;
    object _15051 = NOVALUE;
    object _15050 = NOVALUE;
    object _15048 = NOVALUE;
    object _15046 = NOVALUE;
    object _15045 = NOVALUE;
    object _15044 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_27247)) {
        _1 = (object)(DBL_PTR(_nBase_27247)->dbl);
        DeRefDS(_nBase_27247);
        _nBase_27247 = _1;
    }

    /** scanner.e:1012		ifdef BITS32 then*/

    /** scanner.e:1015			integer num, maxchk*/

    /** scanner.e:1017		atom fnum*/

    /** scanner.e:1018		integer digit*/

    /** scanner.e:1021		switch nBase do*/
    _0 = _nBase_27247;
    switch ( _0 ){ 

        /** scanner.e:1022			case 2 then*/
        case 2:

        /** scanner.e:1023				maxchk = MAXCHK2*/
        _maxchk_27249 = 2305843009213693949LL;
        goto L1; // [29] 90

        /** scanner.e:1025			case 8 then*/
        case 8:

        /** scanner.e:1026				maxchk = MAXCHK8*/
        _maxchk_27249 = 576460752303423479LL;
        goto L1; // [40] 90

        /** scanner.e:1028			case 10 then*/
        case 10:

        /** scanner.e:1030				num = find(text, common_int_text)*/
        _num_27248 = find_from(_text_27246, _62common_int_text_27221, 1LL);

        /** scanner.e:1031				if num then*/
        if (_num_27248 == 0)
        {
            goto L2; // [57] 73
        }
        else{
        }

        /** scanner.e:1032					return common_ints[num]*/
        _2 = (object)SEQ_PTR(_62common_ints_27241);
        _15044 = (object)*(((s1_ptr)_2)->base + _num_27248);
        DeRefDS(_text_27246);
        DeRef(_fnum_27250);
        return _15044;
L2: 

        /** scanner.e:1035				maxchk = MAXCHK10*/
        _maxchk_27249 = 461168601842738782LL;
        goto L1; // [78] 90

        /** scanner.e:1037			case 16 then*/
        case 16:

        /** scanner.e:1038				maxchk = MAXCHK16*/
        _maxchk_27249 = 288230376151711728LL;
    ;}L1: 

    /** scanner.e:1042		num = 0*/
    _num_27248 = 0LL;

    /** scanner.e:1043		fnum = 0*/
    DeRef(_fnum_27250);
    _fnum_27250 = 0LL;

    /** scanner.e:1044		for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_27246)){
            _15045 = SEQ_PTR(_text_27246)->length;
    }
    else {
        _15045 = 1;
    }
    {
        object _i_27262;
        _i_27262 = 1LL;
L3: 
        if (_i_27262 > _15045){
            goto L4; // [105] 222
        }

        /** scanner.e:1045			digit = (text[i] - '0')*/
        _2 = (object)SEQ_PTR(_text_27246);
        _15046 = (object)*(((s1_ptr)_2)->base + _i_27262);
        if (IS_ATOM_INT(_15046)) {
            _digit_27251 = _15046 - 48LL;
        }
        else {
            _digit_27251 = binary_op(MINUS, _15046, 48LL);
        }
        _15046 = NOVALUE;
        if (!IS_ATOM_INT(_digit_27251)) {
            _1 = (object)(DBL_PTR(_digit_27251)->dbl);
            DeRefDS(_digit_27251);
            _digit_27251 = _1;
        }

        /** scanner.e:1046			if digit >= nBase or digit < 0 then*/
        _15048 = (_digit_27251 >= _nBase_27247);
        if (_15048 != 0) {
            goto L5; // [130] 143
        }
        _15050 = (_digit_27251 < 0LL);
        if (_15050 == 0)
        {
            DeRef(_15050);
            _15050 = NOVALUE;
            goto L6; // [139] 161
        }
        else{
            DeRef(_15050);
            _15050 = NOVALUE;
        }
L5: 

        /** scanner.e:1047				CompileErr(DIGIT_1_AT_POSITION_2_IS_OUTSIDE_OF_NUMBER_BASE, {text[i],i})*/
        _2 = (object)SEQ_PTR(_text_27246);
        _15051 = (object)*(((s1_ptr)_2)->base + _i_27262);
        Ref(_15051);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _15051;
        ((intptr_t *)_2)[2] = _i_27262;
        _15052 = MAKE_SEQ(_1);
        _15051 = NOVALUE;
        _50CompileErr(62LL, _15052, 0LL);
        _15052 = NOVALUE;
L6: 

        /** scanner.e:1049			if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_27250, 0LL)){
            goto L7; // [163] 204
        }

        /** scanner.e:1050				if num <= maxchk then*/
        if (_num_27248 > _maxchk_27249)
        goto L8; // [171] 190

        /** scanner.e:1051					num = num * nBase + digit*/
        {
            int128_t p128 = (int128_t)_num_27248 * (int128_t)_nBase_27247;
            if( p128 != (int128_t)(_15055 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15055 = NewDouble( (eudouble)p128 );
            }
        }
        if (IS_ATOM_INT(_15055)) {
            _num_27248 = _15055 + _digit_27251;
        }
        else {
            _num_27248 = NewDouble(DBL_PTR(_15055)->dbl + (eudouble)_digit_27251);
        }
        DeRef(_15055);
        _15055 = NOVALUE;
        if (!IS_ATOM_INT(_num_27248)) {
            _1 = (object)(DBL_PTR(_num_27248)->dbl);
            DeRefDS(_num_27248);
            _num_27248 = _1;
        }
        goto L9; // [187] 215
L8: 

        /** scanner.e:1053					fnum = num * nBase + digit*/
        {
            int128_t p128 = (int128_t)_num_27248 * (int128_t)_nBase_27247;
            if( p128 != (int128_t)(_15057 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15057 = NewDouble( (eudouble)p128 );
            }
        }
        DeRef(_fnum_27250);
        if (IS_ATOM_INT(_15057)) {
            _fnum_27250 = _15057 + _digit_27251;
            if ((object)((uintptr_t)_fnum_27250 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_27250 = NewDouble((eudouble)_fnum_27250);
            }
        }
        else {
            _fnum_27250 = NewDouble(DBL_PTR(_15057)->dbl + (eudouble)_digit_27251);
        }
        DeRef(_15057);
        _15057 = NOVALUE;
        goto L9; // [201] 215
L7: 

        /** scanner.e:1056				fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_27250)) {
            {
                int128_t p128 = (int128_t)_fnum_27250 * (int128_t)_nBase_27247;
                if( p128 != (int128_t)(_15059 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _15059 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _15059 = NewDouble(DBL_PTR(_fnum_27250)->dbl * (eudouble)_nBase_27247);
        }
        DeRef(_fnum_27250);
        if (IS_ATOM_INT(_15059)) {
            _fnum_27250 = _15059 + _digit_27251;
            if ((object)((uintptr_t)_fnum_27250 + (uintptr_t)HIGH_BITS) >= 0){
                _fnum_27250 = NewDouble((eudouble)_fnum_27250);
            }
        }
        else {
            _fnum_27250 = NewDouble(DBL_PTR(_15059)->dbl + (eudouble)_digit_27251);
        }
        DeRef(_15059);
        _15059 = NOVALUE;
L9: 

        /** scanner.e:1058		end for*/
        _i_27262 = _i_27262 + 1LL;
        goto L3; // [217] 112
L4: 
        ;
    }

    /** scanner.e:1060		if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_27250, 0LL)){
        goto LA; // [224] 237
    }

    /** scanner.e:1061			return num*/
    DeRefDS(_text_27246);
    DeRef(_fnum_27250);
    DeRef(_15048);
    _15048 = NOVALUE;
    _15044 = NOVALUE;
    return _num_27248;
    goto LB; // [234] 244
LA: 

    /** scanner.e:1063			return fnum*/
    DeRefDS(_text_27246);
    DeRef(_15048);
    _15048 = NOVALUE;
    _15044 = NOVALUE;
    return _fnum_27250;
LB: 
    ;
}


object _62GetHexChar(object _cnt_27291, object _errno_27292)
{
    object _val_27293 = NOVALUE;
    object _d_27294 = NOVALUE;
    object _15069 = NOVALUE;
    object _15068 = NOVALUE;
    object _15063 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1070		val = 0*/
    DeRef(_val_27293);
    _val_27293 = 0LL;

    /** scanner.e:1072		while cnt > 0 do*/
L1: 
    if (_cnt_27291 <= 0LL)
    goto L2; // [15] 88

    /** scanner.e:1073			d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _15063 = _62getch();
    _d_27294 = find_from(_15063, _15064, 1LL);
    DeRef(_15063);
    _15063 = NOVALUE;

    /** scanner.e:1074			if d = 0 then*/
    if (_d_27294 != 0LL)
    goto L3; // [31] 43

    /** scanner.e:1075				CompileErr( errno )*/
    RefDS(_22186);
    _50CompileErr(_errno_27292, _22186, 0LL);
L3: 

    /** scanner.e:1077			if d != 23 then*/
    if (_d_27294 == 23LL)
    goto L1; // [45] 15

    /** scanner.e:1078				val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_27293)) {
        {
            int128_t p128 = (int128_t)_val_27293 * (int128_t)16LL;
            if( p128 != (int128_t)(_15068 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15068 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15068 = NewDouble(DBL_PTR(_val_27293)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15068)) {
        _15069 = _15068 + _d_27294;
        if ((object)((uintptr_t)_15069 + (uintptr_t)HIGH_BITS) >= 0){
            _15069 = NewDouble((eudouble)_15069);
        }
    }
    else {
        _15069 = NewDouble(DBL_PTR(_15068)->dbl + (eudouble)_d_27294);
    }
    DeRef(_15068);
    _15068 = NOVALUE;
    DeRef(_val_27293);
    if (IS_ATOM_INT(_15069)) {
        _val_27293 = _15069 - 1LL;
        if ((object)((uintptr_t)_val_27293 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27293 = NewDouble((eudouble)_val_27293);
        }
    }
    else {
        _val_27293 = NewDouble(DBL_PTR(_15069)->dbl - (eudouble)1LL);
    }
    DeRef(_15069);
    _15069 = NOVALUE;

    /** scanner.e:1079				if d > 16 then*/
    if (_d_27294 <= 16LL)
    goto L4; // [65] 76

    /** scanner.e:1080					val -= 6*/
    _0 = _val_27293;
    if (IS_ATOM_INT(_val_27293)) {
        _val_27293 = _val_27293 - 6LL;
        if ((object)((uintptr_t)_val_27293 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27293 = NewDouble((eudouble)_val_27293);
        }
    }
    else {
        _val_27293 = NewDouble(DBL_PTR(_val_27293)->dbl - (eudouble)6LL);
    }
    DeRef(_0);
L4: 

    /** scanner.e:1082				cnt -= 1*/
    _cnt_27291 = _cnt_27291 - 1LL;

    /** scanner.e:1084		end while*/
    goto L1; // [85] 15
L2: 

    /** scanner.e:1086		return val*/
    return _val_27293;
    ;
}


object _62GetBinaryChar(object _delim_27314)
{
    object _val_27315 = NOVALUE;
    object _d_27316 = NOVALUE;
    object _vchars_27317 = NOVALUE;
    object _cnt_27320 = NOVALUE;
    object _15083 = NOVALUE;
    object _15082 = NOVALUE;
    object _15076 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1092		sequence vchars = "01_ " & delim*/
    Append(&_vchars_27317, _15074, _delim_27314);

    /** scanner.e:1093		integer cnt = 0*/
    _cnt_27320 = 0LL;

    /** scanner.e:1094		val = 0*/
    DeRef(_val_27315);
    _val_27315 = 0LL;

    /** scanner.e:1095		while 1 do*/
L1: 

    /** scanner.e:1096			d = find(getch(), vchars)*/
    _15076 = _62getch();
    _d_27316 = find_from(_15076, _vchars_27317, 1LL);
    DeRef(_15076);
    _15076 = NOVALUE;

    /** scanner.e:1097			if d = 0 then*/
    if (_d_27316 != 0LL)
    goto L2; // [36] 50

    /** scanner.e:1098				CompileErr( EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22186);
    _50CompileErr(343LL, _22186, 0LL);
L2: 

    /** scanner.e:1100			if d = 5 then*/
    if (_d_27316 != 5LL)
    goto L3; // [52] 65

    /** scanner.e:1101				ungetch()*/
    _62ungetch();

    /** scanner.e:1102				exit*/
    goto L4; // [62] 108
L3: 

    /** scanner.e:1104			if d = 4 then*/
    if (_d_27316 != 4LL)
    goto L5; // [67] 76

    /** scanner.e:1105				exit*/
    goto L4; // [73] 108
L5: 

    /** scanner.e:1107			if d != 3 then*/
    if (_d_27316 == 3LL)
    goto L1; // [78] 24

    /** scanner.e:1108				val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_27315) && IS_ATOM_INT(_val_27315)) {
        _15082 = _val_27315 + _val_27315;
        if ((object)((uintptr_t)_15082 + (uintptr_t)HIGH_BITS) >= 0){
            _15082 = NewDouble((eudouble)_15082);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27315)) {
            _15082 = NewDouble((eudouble)_val_27315 + DBL_PTR(_val_27315)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27315)) {
                _15082 = NewDouble(DBL_PTR(_val_27315)->dbl + (eudouble)_val_27315);
            }
            else
            _15082 = NewDouble(DBL_PTR(_val_27315)->dbl + DBL_PTR(_val_27315)->dbl);
        }
    }
    if (IS_ATOM_INT(_15082)) {
        _15083 = _15082 + _d_27316;
        if ((object)((uintptr_t)_15083 + (uintptr_t)HIGH_BITS) >= 0){
            _15083 = NewDouble((eudouble)_15083);
        }
    }
    else {
        _15083 = NewDouble(DBL_PTR(_15082)->dbl + (eudouble)_d_27316);
    }
    DeRef(_15082);
    _15082 = NOVALUE;
    DeRef(_val_27315);
    if (IS_ATOM_INT(_15083)) {
        _val_27315 = _15083 - 1LL;
        if ((object)((uintptr_t)_val_27315 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27315 = NewDouble((eudouble)_val_27315);
        }
    }
    else {
        _val_27315 = NewDouble(DBL_PTR(_15083)->dbl - (eudouble)1LL);
    }
    DeRef(_15083);
    _15083 = NOVALUE;

    /** scanner.e:1109				cnt += 1*/
    _cnt_27320 = _cnt_27320 + 1;

    /** scanner.e:1111		end while*/
    goto L1; // [105] 24
L4: 

    /** scanner.e:1113		if cnt = 0 then*/
    if (_cnt_27320 != 0LL)
    goto L6; // [110] 124

    /** scanner.e:1114			CompileErr(EXPECTING_ONLY_0_1_OR_SPACE_TO_FOLLOW_THE_B)*/
    RefDS(_22186);
    _50CompileErr(343LL, _22186, 0LL);
L6: 

    /** scanner.e:1116		return val*/
    DeRefi(_vchars_27317);
    return _val_27315;
    ;
}


object _62EscapeChar(object _delim_27344)
{
    object _c_27345 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1124		c = getch()*/
    _0 = _c_27345;
    _c_27345 = _62getch();
    DeRef(_0);

    /** scanner.e:1125		switch c do*/
    if (IS_SEQUENCE(_c_27345) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_27345)){
        if( (DBL_PTR(_c_27345)->dbl != (eudouble) ((object) DBL_PTR(_c_27345)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (object) DBL_PTR(_c_27345)->dbl;
    }
    else {
        _0 = _c_27345;
    };
    switch ( _0 ){ 

        /** scanner.e:1126			case 'n' then*/
        case 110:

        /** scanner.e:1127				c = 10 -- Newline*/
        DeRef(_c_27345);
        _c_27345 = 10LL;
        goto L2; // [24] 147

        /** scanner.e:1129			case 't' then*/
        case 116:

        /** scanner.e:1130				c = 9 -- Tabulator*/
        DeRef(_c_27345);
        _c_27345 = 9LL;
        goto L2; // [35] 147

        /** scanner.e:1132			case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** scanner.e:1137			case 'r' then*/
        goto L2; // [47] 147
        case 114:

        /** scanner.e:1138				c = 13 -- Carriage Return*/
        DeRef(_c_27345);
        _c_27345 = 13LL;
        goto L2; // [56] 147

        /** scanner.e:1140			case '0' then*/
        case 48:

        /** scanner.e:1141				c = 0 -- Null*/
        DeRef(_c_27345);
        _c_27345 = 0LL;
        goto L2; // [67] 147

        /** scanner.e:1143			case 'e', 'E' then*/
        case 101:
        case 69:

        /** scanner.e:1144				c = 27 -- escape char.*/
        DeRef(_c_27345);
        _c_27345 = 27LL;
        goto L2; // [80] 147

        /** scanner.e:1146			case 'x' then*/
        case 120:

        /** scanner.e:1148				c = GetHexChar(2, 340)*/
        _0 = _c_27345;
        _c_27345 = _62GetHexChar(2LL, 340LL);
        DeRef(_0);
        goto L2; // [93] 147

        /** scanner.e:1150			case 'u' then*/
        case 117:

        /** scanner.e:1152				c = GetHexChar(4, 341)*/
        _0 = _c_27345;
        _c_27345 = _62GetHexChar(4LL, 341LL);
        DeRef(_0);
        goto L2; // [106] 147

        /** scanner.e:1154			case 'U' then*/
        case 85:

        /** scanner.e:1156				c = GetHexChar(8, 342)*/
        _0 = _c_27345;
        _c_27345 = _62GetHexChar(8LL, 342LL);
        DeRef(_0);
        goto L2; // [119] 147

        /** scanner.e:1158			case 'b' then*/
        case 98:

        /** scanner.e:1160				c = GetBinaryChar(delim)*/
        _0 = _c_27345;
        _c_27345 = _62GetBinaryChar(_delim_27344);
        DeRef(_0);
        goto L2; // [131] 147

        /** scanner.e:1162			case else*/
        default:
L1: 

        /** scanner.e:1163				CompileErr(UNKNOWN_ESCAPE_CHARACTER)*/
        RefDS(_22186);
        _50CompileErr(155LL, _22186, 0LL);
    ;}L2: 

    /** scanner.e:1166		return c*/
    return _c_27345;
    ;
}


object _62my_sscanf(object _yytext_27369)
{
    object _e_sign_27370 = NOVALUE;
    object _ndigits_27371 = NOVALUE;
    object _e_mag_27372 = NOVALUE;
    object _mantissa_27373 = NOVALUE;
    object _c_27374 = NOVALUE;
    object _i_27375 = NOVALUE;
    object _dec_27376 = NOVALUE;
    object _frac_27409 = NOVALUE;
    object _15129 = NOVALUE;
    object _15124 = NOVALUE;
    object _15123 = NOVALUE;
    object _15121 = NOVALUE;
    object _15120 = NOVALUE;
    object _15119 = NOVALUE;
    object _15111 = NOVALUE;
    object _15110 = NOVALUE;
    object _15107 = NOVALUE;
    object _15106 = NOVALUE;
    object _15105 = NOVALUE;
    object _15100 = NOVALUE;
    object _15099 = NOVALUE;
    object _15097 = NOVALUE;
    object _15095 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1179		if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_27369)){
            _15095 = SEQ_PTR(_yytext_27369)->length;
    }
    else {
        _15095 = 1;
    }
    if (_15095 >= 2LL)
    goto L1; // [8] 22

    /** scanner.e:1180			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22186);
    _50CompileErr(121LL, _22186, 0LL);
L1: 

    /** scanner.e:1184		if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _15097 = find_from(101LL, _yytext_27369, 1LL);
    if (_15097 != 0) {
        goto L2; // [29] 43
    }
    _15099 = find_from(69LL, _yytext_27369, 1LL);
    if (_15099 == 0)
    {
        _15099 = NOVALUE;
        goto L3; // [39] 59
    }
    else{
        _15099 = NOVALUE;
    }
L2: 

    /** scanner.e:1185			ifdef BITS32 then*/

    /** scanner.e:1188				return scientific_to_atom( yytext, EXTENDED )*/
    RefDS(_yytext_27369);
    _15100 = _28scientific_to_atom(_yytext_27369, 3LL);
    DeRefDS(_yytext_27369);
    DeRef(_mantissa_27373);
    DeRef(_dec_27376);
    return _15100;
L3: 

    /** scanner.e:1193		mantissa = 0.0*/
    RefDS(_15102);
    DeRef(_mantissa_27373);
    _mantissa_27373 = _15102;

    /** scanner.e:1194		ndigits = 0*/
    _ndigits_27371 = 0LL;

    /** scanner.e:1198		yytext &= 0 -- end marker*/
    Append(&_yytext_27369, _yytext_27369, 0LL);

    /** scanner.e:1199		c = yytext[1]*/
    _2 = (object)SEQ_PTR(_yytext_27369);
    _c_27374 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_c_27374))
    _c_27374 = (object)DBL_PTR(_c_27374)->dbl;

    /** scanner.e:1200		i = 2*/
    _i_27375 = 2LL;

    /** scanner.e:1201		while c >= '0' and c <= '9' do*/
L4: 
    _15105 = (_c_27374 >= 48LL);
    if (_15105 == 0) {
        goto L5; // [95] 144
    }
    _15107 = (_c_27374 <= 57LL);
    if (_15107 == 0)
    {
        DeRef(_15107);
        _15107 = NOVALUE;
        goto L5; // [104] 144
    }
    else{
        DeRef(_15107);
        _15107 = NOVALUE;
    }

    /** scanner.e:1202			ndigits += 1*/
    _ndigits_27371 = _ndigits_27371 + 1;

    /** scanner.e:1203			mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_27373)) {
        _15110 = NewDouble((eudouble)_mantissa_27373 * DBL_PTR(_15109)->dbl);
    }
    else {
        _15110 = NewDouble(DBL_PTR(_mantissa_27373)->dbl * DBL_PTR(_15109)->dbl);
    }
    _15111 = _c_27374 - 48LL;
    if ((object)((uintptr_t)_15111 +(uintptr_t) HIGH_BITS) >= 0){
        _15111 = NewDouble((eudouble)_15111);
    }
    DeRef(_mantissa_27373);
    if (IS_ATOM_INT(_15111)) {
        _mantissa_27373 = NewDouble(DBL_PTR(_15110)->dbl + (eudouble)_15111);
    }
    else
    _mantissa_27373 = NewDouble(DBL_PTR(_15110)->dbl + DBL_PTR(_15111)->dbl);
    DeRefDS(_15110);
    _15110 = NOVALUE;
    DeRef(_15111);
    _15111 = NOVALUE;

    /** scanner.e:1204			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27369);
    _c_27374 = (object)*(((s1_ptr)_2)->base + _i_27375);
    if (!IS_ATOM_INT(_c_27374))
    _c_27374 = (object)DBL_PTR(_c_27374)->dbl;

    /** scanner.e:1205			i += 1*/
    _i_27375 = _i_27375 + 1;

    /** scanner.e:1206		end while*/
    goto L4; // [141] 91
L5: 

    /** scanner.e:1208		if c = '.' then*/
    if (_c_27374 != 46LL)
    goto L6; // [146] 247

    /** scanner.e:1210			c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27369);
    _c_27374 = (object)*(((s1_ptr)_2)->base + _i_27375);
    if (!IS_ATOM_INT(_c_27374))
    _c_27374 = (object)DBL_PTR(_c_27374)->dbl;

    /** scanner.e:1211			i += 1*/
    _i_27375 = _i_27375 + 1;

    /** scanner.e:1212			dec = 1.0*/
    RefDS(_15118);
    DeRef(_dec_27376);
    _dec_27376 = _15118;

    /** scanner.e:1213			atom frac = 0*/
    DeRef(_frac_27409);
    _frac_27409 = 0LL;

    /** scanner.e:1214			while c >= '0' and c <= '9' do*/
L7: 
    _15119 = (_c_27374 >= 48LL);
    if (_15119 == 0) {
        goto L8; // [181] 236
    }
    _15121 = (_c_27374 <= 57LL);
    if (_15121 == 0)
    {
        DeRef(_15121);
        _15121 = NOVALUE;
        goto L8; // [190] 236
    }
    else{
        DeRef(_15121);
        _15121 = NOVALUE;
    }

    /** scanner.e:1215				ndigits += 1*/
    _ndigits_27371 = _ndigits_27371 + 1;

    /** scanner.e:1216				frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_27409)) {
        {
            int128_t p128 = (int128_t)_frac_27409 * (int128_t)10LL;
            if( p128 != (int128_t)(_15123 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15123 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15123 = NewDouble(DBL_PTR(_frac_27409)->dbl * (eudouble)10LL);
    }
    _15124 = _c_27374 - 48LL;
    if ((object)((uintptr_t)_15124 +(uintptr_t) HIGH_BITS) >= 0){
        _15124 = NewDouble((eudouble)_15124);
    }
    DeRef(_frac_27409);
    if (IS_ATOM_INT(_15123) && IS_ATOM_INT(_15124)) {
        _frac_27409 = _15123 + _15124;
        if ((object)((uintptr_t)_frac_27409 + (uintptr_t)HIGH_BITS) >= 0){
            _frac_27409 = NewDouble((eudouble)_frac_27409);
        }
    }
    else {
        if (IS_ATOM_INT(_15123)) {
            _frac_27409 = NewDouble((eudouble)_15123 + DBL_PTR(_15124)->dbl);
        }
        else {
            if (IS_ATOM_INT(_15124)) {
                _frac_27409 = NewDouble(DBL_PTR(_15123)->dbl + (eudouble)_15124);
            }
            else
            _frac_27409 = NewDouble(DBL_PTR(_15123)->dbl + DBL_PTR(_15124)->dbl);
        }
    }
    DeRef(_15123);
    _15123 = NOVALUE;
    DeRef(_15124);
    _15124 = NOVALUE;

    /** scanner.e:1217				dec *= 10.0*/
    _0 = _dec_27376;
    if (IS_ATOM_INT(_dec_27376)) {
        _dec_27376 = NewDouble((eudouble)_dec_27376 * DBL_PTR(_15109)->dbl);
    }
    else {
        _dec_27376 = NewDouble(DBL_PTR(_dec_27376)->dbl * DBL_PTR(_15109)->dbl);
    }
    DeRef(_0);

    /** scanner.e:1218				c = yytext[i]*/
    _2 = (object)SEQ_PTR(_yytext_27369);
    _c_27374 = (object)*(((s1_ptr)_2)->base + _i_27375);
    if (!IS_ATOM_INT(_c_27374))
    _c_27374 = (object)DBL_PTR(_c_27374)->dbl;

    /** scanner.e:1219				i += 1*/
    _i_27375 = _i_27375 + 1;

    /** scanner.e:1220			end while*/
    goto L7; // [233] 177
L8: 

    /** scanner.e:1221			mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_27409) && IS_ATOM_INT(_dec_27376)) {
        _15129 = (_frac_27409 % _dec_27376) ? NewDouble((eudouble)_frac_27409 / _dec_27376) : (_frac_27409 / _dec_27376);
    }
    else {
        if (IS_ATOM_INT(_frac_27409)) {
            _15129 = NewDouble((eudouble)_frac_27409 / DBL_PTR(_dec_27376)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_27376)) {
                _15129 = NewDouble(DBL_PTR(_frac_27409)->dbl / (eudouble)_dec_27376);
            }
            else
            _15129 = NewDouble(DBL_PTR(_frac_27409)->dbl / DBL_PTR(_dec_27376)->dbl);
        }
    }
    _0 = _mantissa_27373;
    if (IS_ATOM_INT(_mantissa_27373) && IS_ATOM_INT(_15129)) {
        _mantissa_27373 = _mantissa_27373 + _15129;
        if ((object)((uintptr_t)_mantissa_27373 + (uintptr_t)HIGH_BITS) >= 0){
            _mantissa_27373 = NewDouble((eudouble)_mantissa_27373);
        }
    }
    else {
        if (IS_ATOM_INT(_mantissa_27373)) {
            _mantissa_27373 = NewDouble((eudouble)_mantissa_27373 + DBL_PTR(_15129)->dbl);
        }
        else {
            if (IS_ATOM_INT(_15129)) {
                _mantissa_27373 = NewDouble(DBL_PTR(_mantissa_27373)->dbl + (eudouble)_15129);
            }
            else
            _mantissa_27373 = NewDouble(DBL_PTR(_mantissa_27373)->dbl + DBL_PTR(_15129)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_15129);
    _15129 = NOVALUE;
L6: 
    DeRef(_frac_27409);
    _frac_27409 = NOVALUE;

    /** scanner.e:1224		if ndigits = 0 then*/
    if (_ndigits_27371 != 0LL)
    goto L9; // [251] 265

    /** scanner.e:1225			CompileErr(NUMBER_NOT_FORMED_CORRECTLY)  -- no digits*/
    RefDS(_22186);
    _50CompileErr(121LL, _22186, 0LL);
L9: 

    /** scanner.e:1271		return mantissa*/
    DeRefDS(_yytext_27369);
    DeRef(_dec_27376);
    DeRef(_15119);
    _15119 = NOVALUE;
    DeRef(_15100);
    _15100 = NOVALUE;
    DeRef(_15105);
    _15105 = NOVALUE;
    return _mantissa_27373;
    ;
}


void _62maybe_namespace()
{
    object _0, _1, _2;
    

    /** scanner.e:1276		might_be_namespace = 1*/
    _62might_be_namespace_27427 = 1LL;

    /** scanner.e:1277	end procedure*/
    return;
    ;
}


object _62ExtendedString(object _ech_27437)
{
    object _ch_27438 = NOVALUE;
    object _fch_27439 = NOVALUE;
    object _cline_27440 = NOVALUE;
    object _string_text_27441 = NOVALUE;
    object _trimming_27442 = NOVALUE;
    object _15182 = NOVALUE;
    object _15181 = NOVALUE;
    object _15179 = NOVALUE;
    object _15178 = NOVALUE;
    object _15177 = NOVALUE;
    object _15176 = NOVALUE;
    object _15175 = NOVALUE;
    object _15174 = NOVALUE;
    object _15173 = NOVALUE;
    object _15172 = NOVALUE;
    object _15170 = NOVALUE;
    object _15169 = NOVALUE;
    object _15168 = NOVALUE;
    object _15167 = NOVALUE;
    object _15166 = NOVALUE;
    object _15165 = NOVALUE;
    object _15162 = NOVALUE;
    object _15161 = NOVALUE;
    object _15160 = NOVALUE;
    object _15158 = NOVALUE;
    object _15157 = NOVALUE;
    object _15156 = NOVALUE;
    object _15155 = NOVALUE;
    object _15152 = NOVALUE;
    object _15137 = NOVALUE;
    object _15135 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1290		cline = line_number*/
    _cline_27440 = _36line_number_21760;

    /** scanner.e:1291		string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_27441);
    _string_text_27441 = _5;

    /** scanner.e:1292		trimming = 0*/
    _trimming_27442 = 0LL;

    /** scanner.e:1293		ch = getch()*/
    _ch_27438 = _62getch();
    if (!IS_ATOM_INT(_ch_27438)) {
        _1 = (object)(DBL_PTR(_ch_27438)->dbl);
        DeRefDS(_ch_27438);
        _ch_27438 = _1;
    }

    /** scanner.e:1294		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49590)){
            _15135 = SEQ_PTR(_50ThisLine_49590)->length;
    }
    else {
        _15135 = 1;
    }
    if (_50bp_49594 <= _15135)
    goto L1; // [40] 101

    /** scanner.e:1296			read_line()*/
    _62read_line();

    /** scanner.e:1297			while ThisLine[bp] = '_' do*/
L2: 
    _2 = (object)SEQ_PTR(_50ThisLine_49590);
    _15137 = (object)*(((s1_ptr)_2)->base + _50bp_49594);
    if (binary_op_a(NOTEQ, _15137, 95LL)){
        _15137 = NOVALUE;
        goto L3; // [61] 86
    }
    _15137 = NOVALUE;

    /** scanner.e:1298				trimming += 1*/
    _trimming_27442 = _trimming_27442 + 1;

    /** scanner.e:1299				bp += 1*/
    _50bp_49594 = _50bp_49594 + 1LL;

    /** scanner.e:1300			end while*/
    goto L2; // [83] 53
L3: 

    /** scanner.e:1301			if trimming > 0 then*/
    if (_trimming_27442 <= 0LL)
    goto L4; // [88] 100

    /** scanner.e:1302				ch = getch()*/
    _ch_27438 = _62getch();
    if (!IS_ATOM_INT(_ch_27438)) {
        _1 = (object)(DBL_PTR(_ch_27438)->dbl);
        DeRefDS(_ch_27438);
        _ch_27438 = _1;
    }
L4: 
L1: 

    /** scanner.e:1306		while 1 do*/
L5: 

    /** scanner.e:1307			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27438 != 26LL)
    goto L6; // [110] 124

    /** scanner.e:1308				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129LL, _cline_27440, 0LL);
L6: 

    /** scanner.e:1311			if ch = ech then*/
    if (_ch_27438 != _ech_27437)
    goto L7; // [126] 182

    /** scanner.e:1312				if ech != '"' then*/
    if (_ech_27437 == 34LL)
    goto L8; // [132] 141

    /** scanner.e:1313					exit*/
    goto L9; // [138] 312
L8: 

    /** scanner.e:1315				fch = getch()*/
    _fch_27439 = _62getch();
    if (!IS_ATOM_INT(_fch_27439)) {
        _1 = (object)(DBL_PTR(_fch_27439)->dbl);
        DeRefDS(_fch_27439);
        _fch_27439 = _1;
    }

    /** scanner.e:1316				if fch = '"' then*/
    if (_fch_27439 != 34LL)
    goto LA; // [150] 177

    /** scanner.e:1317					fch = getch()*/
    _fch_27439 = _62getch();
    if (!IS_ATOM_INT(_fch_27439)) {
        _1 = (object)(DBL_PTR(_fch_27439)->dbl);
        DeRefDS(_fch_27439);
        _fch_27439 = _1;
    }

    /** scanner.e:1318					if fch = '"' then*/
    if (_fch_27439 != 34LL)
    goto LB; // [163] 172

    /** scanner.e:1319						exit*/
    goto L9; // [169] 312
LB: 

    /** scanner.e:1321					ungetch()*/
    _62ungetch();
LA: 

    /** scanner.e:1323				ungetch()*/
    _62ungetch();
L7: 

    /** scanner.e:1326			if ch != '\r' then*/
    if (_ch_27438 == 13LL)
    goto LC; // [184] 195

    /** scanner.e:1329				string_text &= ch*/
    Append(&_string_text_27441, _string_text_27441, _ch_27438);
LC: 

    /** scanner.e:1332			if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_50ThisLine_49590)){
            _15152 = SEQ_PTR(_50ThisLine_49590)->length;
    }
    else {
        _15152 = 1;
    }
    if (_50bp_49594 <= _15152)
    goto LD; // [204] 300

    /** scanner.e:1333				read_line() -- sets bp to 1, btw.*/
    _62read_line();

    /** scanner.e:1334				if trimming > 0 then*/
    if (_trimming_27442 <= 0LL)
    goto LE; // [214] 299

    /** scanner.e:1335					while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _15155 = (_50bp_49594 <= _trimming_27442);
    if (_15155 == 0) {
        goto L10; // [229] 298
    }
    if (IS_SEQUENCE(_50ThisLine_49590)){
            _15157 = SEQ_PTR(_50ThisLine_49590)->length;
    }
    else {
        _15157 = 1;
    }
    _15158 = (_50bp_49594 <= _15157);
    _15157 = NOVALUE;
    if (_15158 == 0)
    {
        DeRef(_15158);
        _15158 = NOVALUE;
        goto L10; // [245] 298
    }
    else{
        DeRef(_15158);
        _15158 = NOVALUE;
    }

    /** scanner.e:1336						ch = ThisLine[bp]*/
    _2 = (object)SEQ_PTR(_50ThisLine_49590);
    _ch_27438 = (object)*(((s1_ptr)_2)->base + _50bp_49594);
    if (!IS_ATOM_INT(_ch_27438)){
        _ch_27438 = (object)DBL_PTR(_ch_27438)->dbl;
    }

    /** scanner.e:1337						if ch != ' ' and ch != '\t' then*/
    _15160 = (_ch_27438 != 32LL);
    if (_15160 == 0) {
        goto L11; // [266] 283
    }
    _15162 = (_ch_27438 != 9LL);
    if (_15162 == 0)
    {
        DeRef(_15162);
        _15162 = NOVALUE;
        goto L11; // [275] 283
    }
    else{
        DeRef(_15162);
        _15162 = NOVALUE;
    }

    /** scanner.e:1338							exit*/
    goto L10; // [280] 298
L11: 

    /** scanner.e:1340						bp += 1*/
    _50bp_49594 = _50bp_49594 + 1LL;

    /** scanner.e:1341					end while*/
    goto LF; // [295] 223
L10: 
LE: 
LD: 

    /** scanner.e:1344			ch = getch()*/
    _ch_27438 = _62getch();
    if (!IS_ATOM_INT(_ch_27438)) {
        _1 = (object)(DBL_PTR(_ch_27438)->dbl);
        DeRefDS(_ch_27438);
        _ch_27438 = _1;
    }

    /** scanner.e:1345		end while*/
    goto L5; // [309] 106
L9: 

    /** scanner.e:1346		if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27441)){
            _15165 = SEQ_PTR(_string_text_27441)->length;
    }
    else {
        _15165 = 1;
    }
    _15166 = (_15165 > 0LL);
    _15165 = NOVALUE;
    if (_15166 == 0) {
        goto L12; // [321] 391
    }
    _2 = (object)SEQ_PTR(_string_text_27441);
    _15168 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15169 = (_15168 == 10LL);
    _15168 = NOVALUE;
    if (_15169 == 0)
    {
        DeRef(_15169);
        _15169 = NOVALUE;
        goto L12; // [334] 391
    }
    else{
        DeRef(_15169);
        _15169 = NOVALUE;
    }

    /** scanner.e:1347			string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_27441)){
            _15170 = SEQ_PTR(_string_text_27441)->length;
    }
    else {
        _15170 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_27441;
    RHS_Slice(_string_text_27441, 2LL, _15170);

    /** scanner.e:1348			if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_27441)){
            _15172 = SEQ_PTR(_string_text_27441)->length;
    }
    else {
        _15172 = 1;
    }
    _15173 = (_15172 > 0LL);
    _15172 = NOVALUE;
    if (_15173 == 0) {
        goto L13; // [356] 390
    }
    if (IS_SEQUENCE(_string_text_27441)){
            _15175 = SEQ_PTR(_string_text_27441)->length;
    }
    else {
        _15175 = 1;
    }
    _2 = (object)SEQ_PTR(_string_text_27441);
    _15176 = (object)*(((s1_ptr)_2)->base + _15175);
    _15177 = (_15176 == 10LL);
    _15176 = NOVALUE;
    if (_15177 == 0)
    {
        DeRef(_15177);
        _15177 = NOVALUE;
        goto L13; // [372] 390
    }
    else{
        DeRef(_15177);
        _15177 = NOVALUE;
    }

    /** scanner.e:1349				string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_27441)){
            _15178 = SEQ_PTR(_string_text_27441)->length;
    }
    else {
        _15178 = 1;
    }
    _15179 = _15178 - 1LL;
    _15178 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_27441;
    RHS_Slice(_string_text_27441, 1LL, _15179);
L13: 
L12: 

    /** scanner.e:1352		return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_27441);
    _15181 = _54NewStringSym(_string_text_27441);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503LL;
    ((intptr_t *)_2)[2] = _15181;
    _15182 = MAKE_SEQ(_1);
    _15181 = NOVALUE;
    DeRefDSi(_string_text_27441);
    DeRef(_15166);
    _15166 = NOVALUE;
    DeRef(_15160);
    _15160 = NOVALUE;
    DeRef(_15155);
    _15155 = NOVALUE;
    DeRef(_15173);
    _15173 = NOVALUE;
    DeRef(_15179);
    _15179 = NOVALUE;
    return _15182;
    ;
}


object _62GetHexString(object _maxnibbles_27529)
{
    object _ch_27530 = NOVALUE;
    object _digit_27531 = NOVALUE;
    object _val_27532 = NOVALUE;
    object _cline_27533 = NOVALUE;
    object _nibble_27534 = NOVALUE;
    object _string_text_27535 = NOVALUE;
    object _15196 = NOVALUE;
    object _15195 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1363		cline = line_number*/
    _cline_27533 = _36line_number_21760;

    /** scanner.e:1364		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27535);
    _string_text_27535 = _5;

    /** scanner.e:1365		nibble = 1*/
    _nibble_27534 = 1LL;

    /** scanner.e:1366		val = -1*/
    DeRef(_val_27532);
    _val_27532 = -1LL;

    /** scanner.e:1367		ch = getch()*/
    _ch_27530 = _62getch();
    if (!IS_ATOM_INT(_ch_27530)) {
        _1 = (object)(DBL_PTR(_ch_27530)->dbl);
        DeRefDS(_ch_27530);
        _ch_27530 = _1;
    }

    /** scanner.e:1368		while 1 do*/
L1: 

    /** scanner.e:1369			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27530 != 26LL)
    goto L2; // [45] 59

    /** scanner.e:1370				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129LL, _cline_27533, 0LL);
L2: 

    /** scanner.e:1373			if ch = '"' then*/
    if (_ch_27530 != 34LL)
    goto L3; // [61] 70

    /** scanner.e:1374				exit*/
    goto L4; // [67] 228
L3: 

    /** scanner.e:1377			digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_27531 = find_from(_ch_27530, _15186, 1LL);

    /** scanner.e:1378			if digit = 0 then*/
    if (_digit_27531 != 0LL)
    goto L5; // [79] 93

    /** scanner.e:1379				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22186);
    _50CompileErr(329LL, _22186, 0LL);
L5: 

    /** scanner.e:1381			if digit <= 23 then*/
    if (_digit_27531 > 23LL)
    goto L6; // [95] 181

    /** scanner.e:1382				if digit != 23 then*/
    if (_digit_27531 == 23LL)
    goto L7; // [101] 216

    /** scanner.e:1383					if digit > 16 then*/
    if (_digit_27531 <= 16LL)
    goto L8; // [107] 118

    /** scanner.e:1384						digit -= 6*/
    _digit_27531 = _digit_27531 - 6LL;
L8: 

    /** scanner.e:1386					if nibble = 1 then*/
    if (_nibble_27534 != 1LL)
    goto L9; // [120] 133

    /** scanner.e:1387						val = digit - 1*/
    DeRef(_val_27532);
    _val_27532 = _digit_27531 - 1LL;
    if ((object)((uintptr_t)_val_27532 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27532 = NewDouble((eudouble)_val_27532);
    }
    goto LA; // [130] 171
L9: 

    /** scanner.e:1389						val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_27532)) {
        {
            int128_t p128 = (int128_t)_val_27532 * (int128_t)16LL;
            if( p128 != (int128_t)(_15195 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15195 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15195 = NewDouble(DBL_PTR(_val_27532)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15195)) {
        _15196 = _15195 + _digit_27531;
        if ((object)((uintptr_t)_15196 + (uintptr_t)HIGH_BITS) >= 0){
            _15196 = NewDouble((eudouble)_15196);
        }
    }
    else {
        _15196 = NewDouble(DBL_PTR(_15195)->dbl + (eudouble)_digit_27531);
    }
    DeRef(_15195);
    _15195 = NOVALUE;
    DeRef(_val_27532);
    if (IS_ATOM_INT(_15196)) {
        _val_27532 = _15196 - 1LL;
        if ((object)((uintptr_t)_val_27532 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27532 = NewDouble((eudouble)_val_27532);
        }
    }
    else {
        _val_27532 = NewDouble(DBL_PTR(_15196)->dbl - (eudouble)1LL);
    }
    DeRef(_15196);
    _15196 = NOVALUE;

    /** scanner.e:1390						if nibble = maxnibbles then*/
    if (_nibble_27534 != _maxnibbles_27529)
    goto LB; // [149] 170

    /** scanner.e:1391							string_text &= val*/
    Ref(_val_27532);
    Append(&_string_text_27535, _string_text_27535, _val_27532);

    /** scanner.e:1392							val = -1*/
    DeRef(_val_27532);
    _val_27532 = -1LL;

    /** scanner.e:1393							nibble = 0*/
    _nibble_27534 = 0LL;
LB: 
LA: 

    /** scanner.e:1396					nibble += 1*/
    _nibble_27534 = _nibble_27534 + 1;
    goto L7; // [178] 216
L6: 

    /** scanner.e:1399				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27532, 0LL)){
        goto LC; // [183] 199
    }

    /** scanner.e:1401					string_text &= val*/
    Ref(_val_27532);
    Append(&_string_text_27535, _string_text_27535, _val_27532);

    /** scanner.e:1402					val = -1*/
    DeRef(_val_27532);
    _val_27532 = -1LL;
LC: 

    /** scanner.e:1404				nibble = 1*/
    _nibble_27534 = 1LL;

    /** scanner.e:1405				if ch = '\n' then*/
    if (_ch_27530 != 10LL)
    goto LD; // [206] 215

    /** scanner.e:1406					read_line()*/
    _62read_line();
LD: 
L7: 

    /** scanner.e:1409			ch = getch()*/
    _ch_27530 = _62getch();
    if (!IS_ATOM_INT(_ch_27530)) {
        _1 = (object)(DBL_PTR(_ch_27530)->dbl);
        DeRefDS(_ch_27530);
        _ch_27530 = _1;
    }

    /** scanner.e:1410		end while*/
    goto L1; // [225] 41
L4: 

    /** scanner.e:1412		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27532, 0LL)){
        goto LE; // [230] 241
    }

    /** scanner.e:1414			string_text &= val*/
    Ref(_val_27532);
    Append(&_string_text_27535, _string_text_27535, _val_27532);
LE: 

    /** scanner.e:1417		return string_text*/
    DeRef(_val_27532);
    return _string_text_27535;
    ;
}


object _62GetBitString()
{
    object _ch_27582 = NOVALUE;
    object _digit_27583 = NOVALUE;
    object _val_27584 = NOVALUE;
    object _cline_27585 = NOVALUE;
    object _bitcnt_27586 = NOVALUE;
    object _string_text_27587 = NOVALUE;
    object _15218 = NOVALUE;
    object _15217 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1428		cline = line_number*/
    _cline_27585 = _36line_number_21760;

    /** scanner.e:1429		string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_27587);
    _string_text_27587 = _5;

    /** scanner.e:1430		bitcnt = 1*/
    _bitcnt_27586 = 1LL;

    /** scanner.e:1431		val = -1*/
    DeRef(_val_27584);
    _val_27584 = -1LL;

    /** scanner.e:1432		ch = getch()*/
    _ch_27582 = _62getch();
    if (!IS_ATOM_INT(_ch_27582)) {
        _1 = (object)(DBL_PTR(_ch_27582)->dbl);
        DeRefDS(_ch_27582);
        _ch_27582 = _1;
    }

    /** scanner.e:1433		while 1 do*/
L1: 

    /** scanner.e:1434			if ch = END_OF_FILE_CHAR then*/
    if (_ch_27582 != 26LL)
    goto L2; // [43] 57

    /** scanner.e:1435				CompileErr(RAW_STRING_LITERAL_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(129LL, _cline_27585, 0LL);
L2: 

    /** scanner.e:1438			if ch = '"' then*/
    if (_ch_27582 != 34LL)
    goto L3; // [59] 68

    /** scanner.e:1439				exit*/
    goto L4; // [65] 190
L3: 

    /** scanner.e:1442			digit = find(ch, "01_ \t\n\r")*/
    _digit_27583 = find_from(_ch_27582, _15210, 1LL);

    /** scanner.e:1443			if digit = 0 then*/
    if (_digit_27583 != 0LL)
    goto L5; // [77] 91

    /** scanner.e:1444				CompileErr(INVALID_CHARACTER_IN_HEX_STRING)*/
    RefDS(_22186);
    _50CompileErr(329LL, _22186, 0LL);
L5: 

    /** scanner.e:1446			if digit <= 3 then*/
    if (_digit_27583 > 3LL)
    goto L6; // [93] 143

    /** scanner.e:1447				if digit != 3 then*/
    if (_digit_27583 == 3LL)
    goto L7; // [99] 178

    /** scanner.e:1448					if bitcnt = 1 then*/
    if (_bitcnt_27586 != 1LL)
    goto L8; // [105] 118

    /** scanner.e:1449						val = digit - 1*/
    DeRef(_val_27584);
    _val_27584 = _digit_27583 - 1LL;
    if ((object)((uintptr_t)_val_27584 +(uintptr_t) HIGH_BITS) >= 0){
        _val_27584 = NewDouble((eudouble)_val_27584);
    }
    goto L9; // [115] 133
L8: 

    /** scanner.e:1451						val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_27584) && IS_ATOM_INT(_val_27584)) {
        _15217 = _val_27584 + _val_27584;
        if ((object)((uintptr_t)_15217 + (uintptr_t)HIGH_BITS) >= 0){
            _15217 = NewDouble((eudouble)_15217);
        }
    }
    else {
        if (IS_ATOM_INT(_val_27584)) {
            _15217 = NewDouble((eudouble)_val_27584 + DBL_PTR(_val_27584)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_27584)) {
                _15217 = NewDouble(DBL_PTR(_val_27584)->dbl + (eudouble)_val_27584);
            }
            else
            _15217 = NewDouble(DBL_PTR(_val_27584)->dbl + DBL_PTR(_val_27584)->dbl);
        }
    }
    if (IS_ATOM_INT(_15217)) {
        _15218 = _15217 + _digit_27583;
        if ((object)((uintptr_t)_15218 + (uintptr_t)HIGH_BITS) >= 0){
            _15218 = NewDouble((eudouble)_15218);
        }
    }
    else {
        _15218 = NewDouble(DBL_PTR(_15217)->dbl + (eudouble)_digit_27583);
    }
    DeRef(_15217);
    _15217 = NOVALUE;
    DeRef(_val_27584);
    if (IS_ATOM_INT(_15218)) {
        _val_27584 = _15218 - 1LL;
        if ((object)((uintptr_t)_val_27584 +(uintptr_t) HIGH_BITS) >= 0){
            _val_27584 = NewDouble((eudouble)_val_27584);
        }
    }
    else {
        _val_27584 = NewDouble(DBL_PTR(_15218)->dbl - (eudouble)1LL);
    }
    DeRef(_15218);
    _15218 = NOVALUE;
L9: 

    /** scanner.e:1453					bitcnt += 1*/
    _bitcnt_27586 = _bitcnt_27586 + 1;
    goto L7; // [140] 178
L6: 

    /** scanner.e:1456				if val >= 0 then*/
    if (binary_op_a(LESS, _val_27584, 0LL)){
        goto LA; // [145] 161
    }

    /** scanner.e:1458					string_text &= val*/
    Ref(_val_27584);
    Append(&_string_text_27587, _string_text_27587, _val_27584);

    /** scanner.e:1459					val = -1*/
    DeRef(_val_27584);
    _val_27584 = -1LL;
LA: 

    /** scanner.e:1461				bitcnt = 1*/
    _bitcnt_27586 = 1LL;

    /** scanner.e:1462				if ch = '\n' then*/
    if (_ch_27582 != 10LL)
    goto LB; // [168] 177

    /** scanner.e:1463					read_line()*/
    _62read_line();
LB: 
L7: 

    /** scanner.e:1466			ch = getch()*/
    _ch_27582 = _62getch();
    if (!IS_ATOM_INT(_ch_27582)) {
        _1 = (object)(DBL_PTR(_ch_27582)->dbl);
        DeRefDS(_ch_27582);
        _ch_27582 = _1;
    }

    /** scanner.e:1467		end while*/
    goto L1; // [187] 39
L4: 

    /** scanner.e:1469		if val >= 0 then	*/
    if (binary_op_a(LESS, _val_27584, 0LL)){
        goto LC; // [192] 203
    }

    /** scanner.e:1471			string_text &= val*/
    Ref(_val_27584);
    Append(&_string_text_27587, _string_text_27587, _val_27584);
LC: 

    /** scanner.e:1474		return string_text*/
    DeRef(_val_27584);
    return _string_text_27587;
    ;
}


object _62Scanner()
{
    object _fwd_inlined_set_qualified_fwd_at_441_27727 = NOVALUE;
    object _ch_27628 = NOVALUE;
    object _sp_27629 = NOVALUE;
    object _prev_Nne_27630 = NOVALUE;
    object _i_27631 = NOVALUE;
    object _pch_27632 = NOVALUE;
    object _cline_27633 = NOVALUE;
    object _yytext_27634 = NOVALUE;
    object _namespaces_27635 = NOVALUE;
    object _d_27636 = NOVALUE;
    object _tok_27638 = NOVALUE;
    object _is_int_27639 = NOVALUE;
    object _class_27640 = NOVALUE;
    object _name_27641 = NOVALUE;
    object _is_namespace_27700 = NOVALUE;
    object _basetype_27936 = NOVALUE;
    object _hdigit_27977 = NOVALUE;
    object _fch_28117 = NOVALUE;
    object _cnest_28301 = NOVALUE;
    object _ach_28331 = NOVALUE;
    object _31986 = NOVALUE;
    object _31985 = NOVALUE;
    object _31984 = NOVALUE;
    object _31983 = NOVALUE;
    object _31982 = NOVALUE;
    object _31981 = NOVALUE;
    object _31980 = NOVALUE;
    object _15611 = NOVALUE;
    object _15610 = NOVALUE;
    object _15608 = NOVALUE;
    object _15606 = NOVALUE;
    object _15605 = NOVALUE;
    object _15604 = NOVALUE;
    object _15602 = NOVALUE;
    object _15601 = NOVALUE;
    object _15600 = NOVALUE;
    object _15599 = NOVALUE;
    object _15597 = NOVALUE;
    object _15596 = NOVALUE;
    object _15594 = NOVALUE;
    object _15592 = NOVALUE;
    object _15591 = NOVALUE;
    object _15589 = NOVALUE;
    object _15587 = NOVALUE;
    object _15586 = NOVALUE;
    object _15584 = NOVALUE;
    object _15582 = NOVALUE;
    object _15581 = NOVALUE;
    object _15580 = NOVALUE;
    object _15579 = NOVALUE;
    object _15578 = NOVALUE;
    object _15576 = NOVALUE;
    object _15575 = NOVALUE;
    object _15565 = NOVALUE;
    object _15552 = NOVALUE;
    object _15548 = NOVALUE;
    object _15547 = NOVALUE;
    object _15543 = NOVALUE;
    object _15542 = NOVALUE;
    object _15541 = NOVALUE;
    object _15540 = NOVALUE;
    object _15538 = NOVALUE;
    object _15537 = NOVALUE;
    object _15536 = NOVALUE;
    object _15535 = NOVALUE;
    object _15532 = NOVALUE;
    object _15531 = NOVALUE;
    object _15530 = NOVALUE;
    object _15529 = NOVALUE;
    object _15528 = NOVALUE;
    object _15527 = NOVALUE;
    object _15525 = NOVALUE;
    object _15524 = NOVALUE;
    object _15523 = NOVALUE;
    object _15522 = NOVALUE;
    object _15521 = NOVALUE;
    object _15520 = NOVALUE;
    object _15518 = NOVALUE;
    object _15517 = NOVALUE;
    object _15514 = NOVALUE;
    object _15511 = NOVALUE;
    object _15506 = NOVALUE;
    object _15505 = NOVALUE;
    object _15504 = NOVALUE;
    object _15503 = NOVALUE;
    object _15502 = NOVALUE;
    object _15501 = NOVALUE;
    object _15499 = NOVALUE;
    object _15498 = NOVALUE;
    object _15497 = NOVALUE;
    object _15496 = NOVALUE;
    object _15495 = NOVALUE;
    object _15494 = NOVALUE;
    object _15492 = NOVALUE;
    object _15491 = NOVALUE;
    object _15488 = NOVALUE;
    object _15485 = NOVALUE;
    object _15483 = NOVALUE;
    object _15482 = NOVALUE;
    object _15478 = NOVALUE;
    object _15477 = NOVALUE;
    object _15473 = NOVALUE;
    object _15472 = NOVALUE;
    object _15471 = NOVALUE;
    object _15469 = NOVALUE;
    object _15464 = NOVALUE;
    object _15461 = NOVALUE;
    object _15460 = NOVALUE;
    object _15459 = NOVALUE;
    object _15458 = NOVALUE;
    object _15452 = NOVALUE;
    object _15450 = NOVALUE;
    object _15445 = NOVALUE;
    object _15444 = NOVALUE;
    object _15443 = NOVALUE;
    object _15442 = NOVALUE;
    object _15441 = NOVALUE;
    object _15440 = NOVALUE;
    object _15439 = NOVALUE;
    object _15437 = NOVALUE;
    object _15435 = NOVALUE;
    object _15434 = NOVALUE;
    object _15433 = NOVALUE;
    object _15432 = NOVALUE;
    object _15431 = NOVALUE;
    object _15429 = NOVALUE;
    object _15424 = NOVALUE;
    object _15423 = NOVALUE;
    object _15421 = NOVALUE;
    object _15417 = NOVALUE;
    object _15414 = NOVALUE;
    object _15413 = NOVALUE;
    object _15411 = NOVALUE;
    object _15410 = NOVALUE;
    object _15409 = NOVALUE;
    object _15406 = NOVALUE;
    object _15404 = NOVALUE;
    object _15403 = NOVALUE;
    object _15399 = NOVALUE;
    object _15395 = NOVALUE;
    object _15392 = NOVALUE;
    object _15386 = NOVALUE;
    object _15378 = NOVALUE;
    object _15377 = NOVALUE;
    object _15376 = NOVALUE;
    object _15374 = NOVALUE;
    object _15371 = NOVALUE;
    object _15369 = NOVALUE;
    object _15367 = NOVALUE;
    object _15364 = NOVALUE;
    object _15361 = NOVALUE;
    object _15359 = NOVALUE;
    object _15357 = NOVALUE;
    object _15355 = NOVALUE;
    object _15354 = NOVALUE;
    object _15350 = NOVALUE;
    object _15347 = NOVALUE;
    object _15345 = NOVALUE;
    object _15342 = NOVALUE;
    object _15335 = NOVALUE;
    object _15333 = NOVALUE;
    object _15330 = NOVALUE;
    object _15324 = NOVALUE;
    object _15323 = NOVALUE;
    object _15322 = NOVALUE;
    object _15321 = NOVALUE;
    object _15320 = NOVALUE;
    object _15319 = NOVALUE;
    object _15318 = NOVALUE;
    object _15316 = NOVALUE;
    object _15314 = NOVALUE;
    object _15312 = NOVALUE;
    object _15310 = NOVALUE;
    object _15308 = NOVALUE;
    object _15307 = NOVALUE;
    object _15306 = NOVALUE;
    object _15305 = NOVALUE;
    object _15304 = NOVALUE;
    object _15302 = NOVALUE;
    object _15299 = NOVALUE;
    object _15297 = NOVALUE;
    object _15296 = NOVALUE;
    object _15295 = NOVALUE;
    object _15293 = NOVALUE;
    object _15288 = NOVALUE;
    object _15284 = NOVALUE;
    object _15281 = NOVALUE;
    object _15279 = NOVALUE;
    object _15278 = NOVALUE;
    object _15276 = NOVALUE;
    object _15274 = NOVALUE;
    object _15272 = NOVALUE;
    object _15271 = NOVALUE;
    object _15270 = NOVALUE;
    object _15268 = NOVALUE;
    object _15263 = NOVALUE;
    object _15260 = NOVALUE;
    object _15258 = NOVALUE;
    object _15255 = NOVALUE;
    object _15254 = NOVALUE;
    object _15252 = NOVALUE;
    object _15251 = NOVALUE;
    object _15250 = NOVALUE;
    object _15249 = NOVALUE;
    object _15248 = NOVALUE;
    object _15247 = NOVALUE;
    object _15246 = NOVALUE;
    object _15245 = NOVALUE;
    object _15244 = NOVALUE;
    object _15243 = NOVALUE;
    object _15242 = NOVALUE;
    object _15241 = NOVALUE;
    object _15240 = NOVALUE;
    object _15235 = NOVALUE;
    object _15233 = NOVALUE;
    object _15230 = NOVALUE;
    object _15228 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:1486		integer is_int, class*/

    /** scanner.e:1487		sequence name*/

    /** scanner.e:1489		while TRUE do*/
L1: 
    if (_13TRUE_447 == 0)
    {
        goto L2; // [12] 3821
    }
    else{
    }

    /** scanner.e:1490			ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1491			while ch = ' ' or ch = '\t' do*/
L3: 
    _15228 = (_ch_27628 == 32LL);
    if (_15228 != 0) {
        goto L4; // [31] 44
    }
    _15230 = (_ch_27628 == 9LL);
    if (_15230 == 0)
    {
        DeRef(_15230);
        _15230 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_15230);
        _15230 = NOVALUE;
    }
L4: 

    /** scanner.e:1492				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1493			end while*/
    goto L3; // [53] 27
L5: 

    /** scanner.e:1495			class = char_class[ch]*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _class_27640 = (object)*(((s1_ptr)_2)->base + _ch_27628);

    /** scanner.e:1498			if class = LETTER or ch = '_' then*/
    _15233 = (_class_27640 == -2LL);
    if (_15233 != 0) {
        goto L6; // [72] 85
    }
    _15235 = (_ch_27628 == 95LL);
    if (_15235 == 0)
    {
        DeRef(_15235);
        _15235 = NOVALUE;
        goto L7; // [81] 1284
    }
    else{
        DeRef(_15235);
        _15235 = NOVALUE;
    }
L6: 

    /** scanner.e:1499				sp = bp*/
    _sp_27629 = _50bp_49594;

    /** scanner.e:1500				pch = ch*/
    _pch_27632 = _ch_27628;

    /** scanner.e:1501				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1502				if ch = '"' then*/
    if (_ch_27628 != 34LL)
    goto L8; // [108] 222

    /** scanner.e:1503					switch pch do*/
    _0 = _pch_27632;
    switch ( _0 ){ 

        /** scanner.e:1504						case 'x' then*/
        case 120:

        /** scanner.e:1505							return {STRING, NewStringSym(GetHexString(2))}*/
        _15240 = _62GetHexString(2LL);
        _15241 = _54NewStringSym(_15240);
        _15240 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15241;
        _15242 = MAKE_SEQ(_1);
        _15241 = NOVALUE;
        DeRef(_i_27631);
        DeRef(_yytext_27634);
        DeRef(_namespaces_27635);
        DeRef(_d_27636);
        DeRef(_tok_27638);
        DeRef(_name_27641);
        DeRef(_15233);
        _15233 = NOVALUE;
        DeRef(_15228);
        _15228 = NOVALUE;
        return _15242;
        goto L9; // [143] 221

        /** scanner.e:1507						case 'u' then*/
        case 117:

        /** scanner.e:1508							return {STRING, NewStringSym(GetHexString(4))}*/
        _15243 = _62GetHexString(4LL);
        _15244 = _54NewStringSym(_15243);
        _15243 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15244;
        _15245 = MAKE_SEQ(_1);
        _15244 = NOVALUE;
        DeRef(_i_27631);
        DeRef(_yytext_27634);
        DeRef(_namespaces_27635);
        DeRef(_d_27636);
        DeRef(_tok_27638);
        DeRef(_name_27641);
        DeRef(_15233);
        _15233 = NOVALUE;
        DeRef(_15242);
        _15242 = NOVALUE;
        DeRef(_15228);
        _15228 = NOVALUE;
        return _15245;
        goto L9; // [169] 221

        /** scanner.e:1510						case 'U' then*/
        case 85:

        /** scanner.e:1511							return {STRING, NewStringSym(GetHexString(8))}*/
        _15246 = _62GetHexString(8LL);
        _15247 = _54NewStringSym(_15246);
        _15246 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15247;
        _15248 = MAKE_SEQ(_1);
        _15247 = NOVALUE;
        DeRef(_i_27631);
        DeRef(_yytext_27634);
        DeRef(_namespaces_27635);
        DeRef(_d_27636);
        DeRef(_tok_27638);
        DeRef(_name_27641);
        DeRef(_15233);
        _15233 = NOVALUE;
        DeRef(_15242);
        _15242 = NOVALUE;
        DeRef(_15245);
        _15245 = NOVALUE;
        DeRef(_15228);
        _15228 = NOVALUE;
        return _15248;
        goto L9; // [195] 221

        /** scanner.e:1513						case 'b' then*/
        case 98:

        /** scanner.e:1514							return {STRING, NewStringSym(GetBitString())}*/
        _15249 = _62GetBitString();
        _15250 = _54NewStringSym(_15249);
        _15249 = NOVALUE;
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = 503LL;
        ((intptr_t *)_2)[2] = _15250;
        _15251 = MAKE_SEQ(_1);
        _15250 = NOVALUE;
        DeRef(_i_27631);
        DeRef(_yytext_27634);
        DeRef(_namespaces_27635);
        DeRef(_d_27636);
        DeRef(_tok_27638);
        DeRef(_name_27641);
        DeRef(_15233);
        _15233 = NOVALUE;
        DeRef(_15242);
        _15242 = NOVALUE;
        DeRef(_15245);
        _15245 = NOVALUE;
        DeRef(_15228);
        _15228 = NOVALUE;
        DeRef(_15248);
        _15248 = NOVALUE;
        return _15251;
    ;}L9: 
L8: 

    /** scanner.e:1519				while id_char[ch] do*/
LA: 
    _2 = (object)SEQ_PTR(_62id_char_25875);
    _15252 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15252 == 0)
    {
        _15252 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _15252 = NOVALUE;
    }

    /** scanner.e:1520					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1521				end while*/
    goto LA; // [245] 227
LB: 

    /** scanner.e:1522				yytext = ThisLine[sp-1..bp-2]*/
    _15254 = _sp_27629 - 1LL;
    if ((object)((uintptr_t)_15254 +(uintptr_t) HIGH_BITS) >= 0){
        _15254 = NewDouble((eudouble)_15254);
    }
    _15255 = _50bp_49594 - 2LL;
    rhs_slice_target = (object_ptr)&_yytext_27634;
    RHS_Slice(_50ThisLine_49590, _15254, _15255);

    /** scanner.e:1523				ungetch()*/
    _62ungetch();

    /** scanner.e:1525				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1526				while ch = ' ' or ch = '\t' do*/
LC: 
    _15258 = (_ch_27628 == 32LL);
    if (_15258 != 0) {
        goto LD; // [287] 300
    }
    _15260 = (_ch_27628 == 9LL);
    if (_15260 == 0)
    {
        DeRef(_15260);
        _15260 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_15260);
        _15260 = NOVALUE;
    }
LD: 

    /** scanner.e:1527					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1528				end while*/
    goto LC; // [309] 283
LE: 

    /** scanner.e:1529				integer is_namespace*/

    /** scanner.e:1531				if might_be_namespace then*/
    if (_62might_be_namespace_27427 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** scanner.e:1532					tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_27634);
    _31986 = _54hashfn(_yytext_27634);
    RefDS(_yytext_27634);
    _0 = _tok_27638;
    _tok_27638 = _54keyfind(_yytext_27634, -1LL, _36current_file_no_21759, -1LL, _31986);
    DeRef(_0);
    _31986 = NOVALUE;

    /** scanner.e:1533					is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15263 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_15263)) {
        _is_namespace_27700 = (_15263 == 523LL);
    }
    else {
        _is_namespace_27700 = binary_op(EQUALS, _15263, 523LL);
    }
    _15263 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_27700)) {
        _1 = (object)(DBL_PTR(_is_namespace_27700)->dbl);
        DeRefDS(_is_namespace_27700);
        _is_namespace_27700 = _1;
    }

    /** scanner.e:1534					might_be_namespace = 0*/
    _62might_be_namespace_27427 = 0LL;
    goto L10; // [358] 384
LF: 

    /** scanner.e:1536					is_namespace = ch = ':'*/
    _is_namespace_27700 = (_ch_27628 == 58LL);

    /** scanner.e:1537					tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_27634);
    _31985 = _54hashfn(_yytext_27634);
    RefDS(_yytext_27634);
    _0 = _tok_27638;
    _tok_27638 = _54keyfind(_yytext_27634, -1LL, _36current_file_no_21759, _is_namespace_27700, _31985);
    DeRef(_0);
    _31985 = NOVALUE;
L10: 

    /** scanner.e:1541				if not is_namespace then*/
    if (_is_namespace_27700 != 0)
    goto L11; // [388] 396

    /** scanner.e:1542					ungetch()*/
    _62ungetch();
L11: 

    /** scanner.e:1545				if is_namespace then*/
    if (_is_namespace_27700 == 0)
    {
        goto L12; // [398] 1121
    }
    else{
    }

    /** scanner.e:1547					namespaces = yytext*/
    RefDS(_yytext_27634);
    DeRef(_namespaces_27635);
    _namespaces_27635 = _yytext_27634;

    /** scanner.e:1550					if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15268 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15268, 523LL)){
        _15268 = NOVALUE;
        goto L13; // [420] 976
    }
    _15268 = NOVALUE;

    /** scanner.e:1551						set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15270 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15270)){
        _15271 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15270)->dbl));
    }
    else{
        _15271 = (object)*(((s1_ptr)_2)->base + _15270);
    }
    _2 = (object)SEQ_PTR(_15271);
    _15272 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15271 = NOVALUE;
    Ref(_15272);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27727);
    _fwd_inlined_set_qualified_fwd_at_441_27727 = _15272;
    _15272 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_27727)) {
        _1 = (object)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_27727)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_27727);
        _fwd_inlined_set_qualified_fwd_at_441_27727 = _1;
    }

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25899 = _fwd_inlined_set_qualified_fwd_at_441_27727;

    /** scanner.e:105	end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_27727);
    _fwd_inlined_set_qualified_fwd_at_441_27727 = NOVALUE;

    /** scanner.e:1554						ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1555						while ch = ' ' or ch = '\t' do*/
L15: 
    _15274 = (_ch_27628 == 32LL);
    if (_15274 != 0) {
        goto L16; // [477] 490
    }
    _15276 = (_ch_27628 == 9LL);
    if (_15276 == 0)
    {
        DeRef(_15276);
        _15276 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_15276);
        _15276 = NOVALUE;
    }
L16: 

    /** scanner.e:1556							ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1557						end while*/
    goto L15; // [499] 473
L17: 

    /** scanner.e:1558						yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27634);
    _yytext_27634 = _5;

    /** scanner.e:1559						if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15278 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    _15279 = (_15278 == -2LL);
    _15278 = NOVALUE;
    if (_15279 != 0) {
        goto L18; // [523] 536
    }
    _15281 = (_ch_27628 == 95LL);
    if (_15281 == 0)
    {
        DeRef(_15281);
        _15281 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_15281);
        _15281 = NOVALUE;
    }
L18: 

    /** scanner.e:1560							yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);

    /** scanner.e:1561							ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1562							while id_char[ch] = TRUE do*/
L1A: 
    _2 = (object)SEQ_PTR(_62id_char_25875);
    _15284 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15284 != _13TRUE_447)
    goto L1B; // [562] 584

    /** scanner.e:1563								yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);

    /** scanner.e:1564								ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1565							end while*/
    goto L1A; // [581] 554
L1B: 

    /** scanner.e:1566							ungetch()*/
    _62ungetch();
L19: 

    /** scanner.e:1569						if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_27634)){
            _15288 = SEQ_PTR(_yytext_27634)->length;
    }
    else {
        _15288 = 1;
    }
    if (_15288 != 0LL)
    goto L1C; // [594] 608

    /** scanner.e:1570							CompileErr(AN_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22186);
    _50CompileErr(32LL, _22186, 0LL);
L1C: 

    /** scanner.e:1576					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21868 != 1LL)
    goto L1D; // [614] 775

    /** scanner.e:1577			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27634);
    Append(&_36Recorded_21869, _36Recorded_21869, _yytext_27634);

    /** scanner.e:1578			                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_27635);
    Append(&_36Ns_recorded_21870, _36Ns_recorded_21870, _namespaces_27635);

    /** scanner.e:1579			                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15293 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Ns_recorded_sym_21872) && IS_ATOM(_15293)) {
        Ref(_15293);
        Append(&_36Ns_recorded_sym_21872, _36Ns_recorded_sym_21872, _15293);
    }
    else if (IS_ATOM(_36Ns_recorded_sym_21872) && IS_SEQUENCE(_15293)) {
    }
    else {
        Concat((object_ptr)&_36Ns_recorded_sym_21872, _36Ns_recorded_sym_21872, _15293);
    }
    _15293 = NOVALUE;

    /** scanner.e:1580			                prev_Nne = No_new_entry*/
    _prev_Nne_27630 = _54No_new_entry_48330;

    /** scanner.e:1581							No_new_entry = 1*/
    _54No_new_entry_48330 = 1LL;

    /** scanner.e:1582							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15295 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15295)){
        _15296 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15295)->dbl));
    }
    else{
        _15296 = (object)*(((s1_ptr)_2)->base + _15295);
    }
    _2 = (object)SEQ_PTR(_15296);
    _15297 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15296 = NOVALUE;
    RefDS(_yytext_27634);
    _31984 = _54hashfn(_yytext_27634);
    RefDS(_yytext_27634);
    Ref(_15297);
    _0 = _tok_27638;
    _tok_27638 = _54keyfind(_yytext_27634, _15297, _36current_file_no_21759, 0LL, _31984);
    DeRef(_0);
    _15297 = NOVALUE;
    _31984 = NOVALUE;

    /** scanner.e:1583							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15299 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15299, 509LL)){
        _15299 = NOVALUE;
        goto L1E; // [714] 731
    }
    _15299 = NOVALUE;

    /** scanner.e:1584								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21871, _36Recorded_sym_21871, 0LL);
    goto L1F; // [728] 748
L1E: 

    /** scanner.e:1586								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15302 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Recorded_sym_21871) && IS_ATOM(_15302)) {
        Ref(_15302);
        Append(&_36Recorded_sym_21871, _36Recorded_sym_21871, _15302);
    }
    else if (IS_ATOM(_36Recorded_sym_21871) && IS_SEQUENCE(_15302)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21871, _36Recorded_sym_21871, _15302);
    }
    _15302 = NOVALUE;
L1F: 

    /** scanner.e:1588			                No_new_entry = prev_Nne*/
    _54No_new_entry_48330 = _prev_Nne_27630;

    /** scanner.e:1589			                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21869)){
            _15304 = SEQ_PTR(_36Recorded_21869)->length;
    }
    else {
        _15304 = 1;
    }
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _15304;
    _15305 = MAKE_SEQ(_1);
    _15304 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15305;
    goto L20; // [772] 917
L1D: 

    /** scanner.e:1591							tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15306 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15306)){
        _15307 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15306)->dbl));
    }
    else{
        _15307 = (object)*(((s1_ptr)_2)->base + _15306);
    }
    _2 = (object)SEQ_PTR(_15307);
    _15308 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15307 = NOVALUE;
    RefDS(_yytext_27634);
    _31983 = _54hashfn(_yytext_27634);
    RefDS(_yytext_27634);
    Ref(_15308);
    _0 = _tok_27638;
    _tok_27638 = _54keyfind(_yytext_27634, _15308, _36current_file_no_21759, 0LL, _31983);
    DeRef(_0);
    _15308 = NOVALUE;
    _31983 = NOVALUE;

    /** scanner.e:1593							if tok[T_ID] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15310 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15310, -100LL)){
        _15310 = NOVALUE;
        goto L21; // [819] 836
    }
    _15310 = NOVALUE;

    /** scanner.e:1594								tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (object)SEQ_PTR(_tok_27638);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27638 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 512LL;
    DeRef(_1);
    goto L22; // [833] 916
L21: 

    /** scanner.e:1595							elsif tok[T_ID] = FUNC then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15312 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15312, 501LL)){
        _15312 = NOVALUE;
        goto L23; // [846] 863
    }
    _15312 = NOVALUE;

    /** scanner.e:1596								tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (object)SEQ_PTR(_tok_27638);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27638 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 520LL;
    DeRef(_1);
    goto L22; // [860] 916
L23: 

    /** scanner.e:1597							elsif tok[T_ID] = PROC then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15314 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15314, 27LL)){
        _15314 = NOVALUE;
        goto L24; // [873] 890
    }
    _15314 = NOVALUE;

    /** scanner.e:1598								tok[T_ID] = QUALIFIED_PROC*/
    _2 = (object)SEQ_PTR(_tok_27638);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27638 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 521LL;
    DeRef(_1);
    goto L22; // [887] 916
L24: 

    /** scanner.e:1599							elsif tok[T_ID] = TYPE then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15316 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15316, 504LL)){
        _15316 = NOVALUE;
        goto L25; // [900] 915
    }
    _15316 = NOVALUE;

    /** scanner.e:1600								tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (object)SEQ_PTR(_tok_27638);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _tok_27638 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 522LL;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** scanner.e:1605						if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15318 = (object)*(((s1_ptr)_2)->base + 2LL);
    _15319 = IS_ATOM(_15318);
    _15318 = NOVALUE;
    if (_15319 == 0) {
        goto L26; // [928] 1271
    }
    _2 = (object)SEQ_PTR(_tok_27638);
    _15321 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!IS_ATOM_INT(_15321)){
        _15322 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15321)->dbl));
    }
    else{
        _15322 = (object)*(((s1_ptr)_2)->base + _15321);
    }
    _2 = (object)SEQ_PTR(_15322);
    _15323 = (object)*(((s1_ptr)_2)->base + 4LL);
    _15322 = NOVALUE;
    if (IS_ATOM_INT(_15323)) {
        _15324 = (_15323 != 9LL);
    }
    else {
        _15324 = binary_op(NOTEQ, _15323, 9LL);
    }
    _15323 = NOVALUE;
    if (_15324 == 0) {
        DeRef(_15324);
        _15324 = NOVALUE;
        goto L26; // [957] 1271
    }
    else {
        if (!IS_ATOM_INT(_15324) && DBL_PTR(_15324)->dbl == 0.0){
            DeRef(_15324);
            _15324 = NOVALUE;
            goto L26; // [957] 1271
        }
        DeRef(_15324);
        _15324 = NOVALUE;
    }
    DeRef(_15324);
    _15324 = NOVALUE;

    /** scanner.e:1606							set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25899 = -1LL;

    /** scanner.e:105	end procedure*/
    goto L26; // [969] 1271
    goto L26; // [973] 1271
L13: 

    /** scanner.e:1610						ungetch()*/
    _62ungetch();

    /** scanner.e:1611					    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21868 != 1LL)
    goto L26; // [986] 1271

    /** scanner.e:1612			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21870, _36Ns_recorded_21870, 0LL);

    /** scanner.e:1613			                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21872, _36Ns_recorded_sym_21872, 0LL);

    /** scanner.e:1614			                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_27634);
    Append(&_36Recorded_21869, _36Recorded_21869, _yytext_27634);

    /** scanner.e:1615			                prev_Nne = No_new_entry*/
    _prev_Nne_27630 = _54No_new_entry_48330;

    /** scanner.e:1616							No_new_entry = 1*/
    _54No_new_entry_48330 = 1LL;

    /** scanner.e:1617							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27634);
    _31982 = _54hashfn(_yytext_27634);
    RefDS(_yytext_27634);
    _0 = _tok_27638;
    _tok_27638 = _54keyfind(_yytext_27634, -1LL, _36current_file_no_21759, 0LL, _31982);
    DeRef(_0);
    _31982 = NOVALUE;

    /** scanner.e:1618							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15330 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15330, 509LL)){
        _15330 = NOVALUE;
        goto L27; // [1062] 1079
    }
    _15330 = NOVALUE;

    /** scanner.e:1619								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21871, _36Recorded_sym_21871, 0LL);
    goto L28; // [1076] 1096
L27: 

    /** scanner.e:1621								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15333 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Recorded_sym_21871) && IS_ATOM(_15333)) {
        Ref(_15333);
        Append(&_36Recorded_sym_21871, _36Recorded_sym_21871, _15333);
    }
    else if (IS_ATOM(_36Recorded_sym_21871) && IS_SEQUENCE(_15333)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21871, _36Recorded_sym_21871, _15333);
    }
    _15333 = NOVALUE;
L28: 

    /** scanner.e:1623			                No_new_entry = prev_Nne*/
    _54No_new_entry_48330 = _prev_Nne_27630;

    /** scanner.e:1624			                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21869)){
            _15335 = SEQ_PTR(_36Recorded_21869)->length;
    }
    else {
        _15335 = 1;
    }
    DeRef(_tok_27638);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _15335;
    _tok_27638 = MAKE_SEQ(_1);
    _15335 = NOVALUE;
    goto L26; // [1118] 1271
L12: 

    /** scanner.e:1628					set_qualified_fwd( -1 )*/

    /** scanner.e:104		qualified_fwd = fwd*/
    _62qualified_fwd_25899 = -1LL;

    /** scanner.e:105	end procedure*/
    goto L29; // [1130] 1133
L29: 

    /** scanner.e:1629				    if Parser_mode = PAM_RECORD then*/
    if (_36Parser_mode_21868 != 1LL)
    goto L2A; // [1139] 1270

    /** scanner.e:1630		                Ns_recorded_sym &= 0*/
    Append(&_36Ns_recorded_sym_21872, _36Ns_recorded_sym_21872, 0LL);

    /** scanner.e:1631							Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_27634);
    Append(&_36Recorded_21869, _36Recorded_21869, _yytext_27634);

    /** scanner.e:1632			                Ns_recorded &= 0*/
    Append(&_36Ns_recorded_21870, _36Ns_recorded_21870, 0LL);

    /** scanner.e:1633			                prev_Nne = No_new_entry*/
    _prev_Nne_27630 = _54No_new_entry_48330;

    /** scanner.e:1634							No_new_entry = 1*/
    _54No_new_entry_48330 = 1LL;

    /** scanner.e:1635							tok = keyfind(yytext, -1)*/
    RefDS(_yytext_27634);
    _31981 = _54hashfn(_yytext_27634);
    RefDS(_yytext_27634);
    _0 = _tok_27638;
    _tok_27638 = _54keyfind(_yytext_27634, -1LL, _36current_file_no_21759, 0LL, _31981);
    DeRef(_0);
    _31981 = NOVALUE;

    /** scanner.e:1636							if tok[T_ID] = IGNORED then*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15342 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15342, 509LL)){
        _15342 = NOVALUE;
        goto L2B; // [1215] 1232
    }
    _15342 = NOVALUE;

    /** scanner.e:1637								Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_36Recorded_sym_21871, _36Recorded_sym_21871, 0LL);
    goto L2C; // [1229] 1249
L2B: 

    /** scanner.e:1639								Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (object)SEQ_PTR(_tok_27638);
    _15345 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (IS_SEQUENCE(_36Recorded_sym_21871) && IS_ATOM(_15345)) {
        Ref(_15345);
        Append(&_36Recorded_sym_21871, _36Recorded_sym_21871, _15345);
    }
    else if (IS_ATOM(_36Recorded_sym_21871) && IS_SEQUENCE(_15345)) {
    }
    else {
        Concat((object_ptr)&_36Recorded_sym_21871, _36Recorded_sym_21871, _15345);
    }
    _15345 = NOVALUE;
L2C: 

    /** scanner.e:1641			                No_new_entry = prev_Nne*/
    _54No_new_entry_48330 = _prev_Nne_27630;

    /** scanner.e:1642		                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_36Recorded_21869)){
            _15347 = SEQ_PTR(_36Recorded_21869)->length;
    }
    else {
        _15347 = 1;
    }
    DeRef(_tok_27638);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 508LL;
    ((intptr_t *)_2)[2] = _15347;
    _tok_27638 = MAKE_SEQ(_1);
    _15347 = NOVALUE;
L2A: 
L26: 

    /** scanner.e:1646				return tok*/
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_name_27641);
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _tok_27638;
    goto L1; // [1281] 10
L7: 

    /** scanner.e:1648			elsif class < ILLEGAL_CHAR then*/
    if (_class_27640 >= -20LL)
    goto L2D; // [1288] 1305

    /** scanner.e:1649				return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27640;
    ((intptr_t *)_2)[2] = 0LL;
    _15350 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15350;
    goto L1; // [1302] 10
L2D: 

    /** scanner.e:1651			elsif class = ILLEGAL_CHAR then*/
    if (_class_27640 != -20LL)
    goto L2E; // [1309] 1325

    /** scanner.e:1652				CompileErr(ILLEGAL_CHARACTER_IN_SOURCE)*/
    RefDS(_22186);
    _50CompileErr(101LL, _22186, 0LL);
    goto L1; // [1322] 10
L2E: 

    /** scanner.e:1654			elsif class = NEWLINE then*/
    if (_class_27640 != -6LL)
    goto L2F; // [1329] 1355

    /** scanner.e:1655				if start_include then*/
    if (_62start_include_25867 == 0)
    {
        goto L30; // [1337] 1347
    }
    else{
    }

    /** scanner.e:1656					IncludePush()*/
    _62IncludePush();
    goto L1; // [1344] 10
L30: 

    /** scanner.e:1658					read_line()*/
    _62read_line();
    goto L1; // [1352] 10
L2F: 

    /** scanner.e:1662			elsif class = EQUALS then*/
    if (_class_27640 != 3LL)
    goto L31; // [1359] 1376

    /** scanner.e:1663				return {class, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _class_27640;
    ((intptr_t *)_2)[2] = 0LL;
    _15354 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15354;
    goto L1; // [1373] 10
L31: 

    /** scanner.e:1665			elsif class = DOT or class = DIGIT then*/
    _15355 = (_class_27640 == -3LL);
    if (_15355 != 0) {
        goto L32; // [1384] 1399
    }
    _15357 = (_class_27640 == -7LL);
    if (_15357 == 0)
    {
        DeRef(_15357);
        _15357 = NOVALUE;
        goto L33; // [1395] 2195
    }
    else{
        DeRef(_15357);
        _15357 = NOVALUE;
    }
L32: 

    /** scanner.e:1666				integer basetype*/

    /** scanner.e:1667				if class = DOT then*/
    if (_class_27640 != -3LL)
    goto L34; // [1405] 1439

    /** scanner.e:1668					if getch() = '.' then*/
    _15359 = _62getch();
    if (binary_op_a(NOTEQ, _15359, 46LL)){
        DeRef(_15359);
        _15359 = NOVALUE;
        goto L35; // [1414] 1433
    }
    DeRef(_15359);
    _15359 = NOVALUE;

    /** scanner.e:1669						return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 513LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15361 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15361;
    goto L36; // [1430] 1438
L35: 

    /** scanner.e:1671						ungetch()*/
    _62ungetch();
L36: 
L34: 

    /** scanner.e:1675				yytext = {ch}*/
    _0 = _yytext_27634;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27628;
    _yytext_27634 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:1676				is_int = (ch != '.')*/
    _is_int_27639 = (_ch_27628 != 46LL);

    /** scanner.e:1677				basetype = -1 -- default is decimal*/
    _basetype_27936 = -1LL;

    /** scanner.e:1678				while 1 with entry do*/
    goto L37; // [1458] 1651
L38: 

    /** scanner.e:1679					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15364 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15364 != -7LL)
    goto L39; // [1471] 1484

    /** scanner.e:1680						yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);
    goto L3A; // [1481] 1648
L39: 

    /** scanner.e:1682					elsif equal(yytext, "0") then*/
    if (_yytext_27634 == _15020)
    _15367 = 1;
    else if (IS_ATOM_INT(_yytext_27634) && IS_ATOM_INT(_15020))
    _15367 = 0;
    else
    _15367 = (compare(_yytext_27634, _15020) == 0);
    if (_15367 == 0)
    {
        _15367 = NOVALUE;
        goto L3B; // [1490] 1587
    }
    else{
        _15367 = NOVALUE;
    }

    /** scanner.e:1683						basetype = find(ch, nbasecode)*/
    _basetype_27936 = find_from(_ch_27628, _62nbasecode_27431, 1LL);

    /** scanner.e:1684						if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_62nbase_27430)){
            _15369 = SEQ_PTR(_62nbase_27430)->length;
    }
    else {
        _15369 = 1;
    }
    if (_basetype_27936 <= _15369)
    goto L3C; // [1505] 1519

    /** scanner.e:1685							basetype -= length(nbase)*/
    if (IS_SEQUENCE(_62nbase_27430)){
            _15371 = SEQ_PTR(_62nbase_27430)->length;
    }
    else {
        _15371 = 1;
    }
    _basetype_27936 = _basetype_27936 - _15371;
    _15371 = NOVALUE;
L3C: 

    /** scanner.e:1688						if basetype = 0 then*/
    if (_basetype_27936 != 0LL)
    goto L3D; // [1521] 1578

    /** scanner.e:1689							if char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15374 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15374 != -2LL)
    goto L3E; // [1535] 1568

    /** scanner.e:1690								if ch != 'e' and ch != 'E' then*/
    _15376 = (_ch_27628 != 101LL);
    if (_15376 == 0) {
        goto L3F; // [1545] 1567
    }
    _15378 = (_ch_27628 != 69LL);
    if (_15378 == 0)
    {
        DeRef(_15378);
        _15378 = NOVALUE;
        goto L3F; // [1554] 1567
    }
    else{
        DeRef(_15378);
        _15378 = NOVALUE;
    }

    /** scanner.e:1691									CompileErr(INVALID_NUMBER_BASE_SPECIFIER_1, ch)*/
    _50CompileErr(105LL, _ch_27628, 0LL);
L3F: 
L3E: 

    /** scanner.e:1695							basetype = -1 -- decimal*/
    _basetype_27936 = -1LL;

    /** scanner.e:1696							exit*/
    goto L40; // [1575] 1663
L3D: 

    /** scanner.e:1698						yytext &= '0'*/
    Append(&_yytext_27634, _yytext_27634, 48LL);
    goto L3A; // [1584] 1648
L3B: 

    /** scanner.e:1700					elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_27936 != 4LL)
    goto L40; // [1589] 1663

    /** scanner.e:1701						integer hdigit*/

    /** scanner.e:1702						hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_27977 = find_from(_ch_27628, _15381, 1LL);

    /** scanner.e:1703						if hdigit = 0 then*/
    if (_hdigit_27977 != 0LL)
    goto L41; // [1604] 1615

    /** scanner.e:1704							exit*/
    goto L40; // [1612] 1663
L41: 

    /** scanner.e:1706						if hdigit > 6 then*/
    if (_hdigit_27977 <= 6LL)
    goto L42; // [1617] 1628

    /** scanner.e:1707							hdigit -= 6*/
    _hdigit_27977 = _hdigit_27977 - 6LL;
L42: 

    /** scanner.e:1709						yytext &= hexasc[hdigit]*/
    _2 = (object)SEQ_PTR(_62hexasc_27433);
    _15386 = (object)*(((s1_ptr)_2)->base + _hdigit_27977);
    if (IS_SEQUENCE(_yytext_27634) && IS_ATOM(_15386)) {
        Ref(_15386);
        Append(&_yytext_27634, _yytext_27634, _15386);
    }
    else if (IS_ATOM(_yytext_27634) && IS_SEQUENCE(_15386)) {
    }
    else {
        Concat((object_ptr)&_yytext_27634, _yytext_27634, _15386);
    }
    _15386 = NOVALUE;
    goto L3A; // [1640] 1648

    /** scanner.e:1712						exit*/
    goto L40; // [1645] 1663
L3A: 

    /** scanner.e:1714				entry*/
L37: 

    /** scanner.e:1715					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1716				end while*/
    goto L38; // [1660] 1461
L40: 

    /** scanner.e:1718				if ch = '.' then*/
    if (_ch_27628 != 46LL)
    goto L43; // [1665] 1804

    /** scanner.e:1719					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1720					if ch = '.' then*/
    if (_ch_27628 != 46LL)
    goto L44; // [1678] 1689

    /** scanner.e:1722						ungetch()*/
    _62ungetch();
    goto L45; // [1686] 1803
L44: 

    /** scanner.e:1724						is_int = FALSE*/
    _is_int_27639 = _13FALSE_445;

    /** scanner.e:1725						if yytext[1] = '.' then*/
    _2 = (object)SEQ_PTR(_yytext_27634);
    _15392 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _15392, 46LL)){
        _15392 = NOVALUE;
        goto L46; // [1704] 1720
    }
    _15392 = NOVALUE;

    /** scanner.e:1726							CompileErr(ONLY_ONE_DECIMAL_POINT_ALLOWED)*/
    RefDS(_22186);
    _50CompileErr(124LL, _22186, 0LL);
    goto L47; // [1717] 1727
L46: 

    /** scanner.e:1728							yytext &= '.'*/
    Append(&_yytext_27634, _yytext_27634, 46LL);
L47: 

    /** scanner.e:1730						if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15395 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15395 != -7LL)
    goto L48; // [1737] 1792

    /** scanner.e:1731							yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);

    /** scanner.e:1732							ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1733							while char_class[ch] = DIGIT do*/
L49: 
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15399 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15399 != -7LL)
    goto L4A; // [1767] 1802

    /** scanner.e:1734								yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);

    /** scanner.e:1735								ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1736							end while*/
    goto L49; // [1786] 1759
    goto L4A; // [1789] 1802
L48: 

    /** scanner.e:1738							CompileErr(FRACTIONAL_PART_OF_NUMBER_IS_MISSING)*/
    RefDS(_22186);
    _50CompileErr(94LL, _22186, 0LL);
L4A: 
L45: 
L43: 

    /** scanner.e:1743				if basetype = -1 and find(ch, "eE") then*/
    _15403 = (_basetype_27936 == -1LL);
    if (_15403 == 0) {
        goto L4B; // [1810] 1948
    }
    _15406 = find_from(_ch_27628, _15405, 1LL);
    if (_15406 == 0)
    {
        _15406 = NOVALUE;
        goto L4B; // [1820] 1948
    }
    else{
        _15406 = NOVALUE;
    }

    /** scanner.e:1744					is_int = FALSE*/
    _is_int_27639 = _13FALSE_445;

    /** scanner.e:1745					yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);

    /** scanner.e:1746					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1747					if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _15409 = (_ch_27628 == 45LL);
    if (_15409 != 0) {
        _15410 = 1;
        goto L4C; // [1851] 1863
    }
    _15411 = (_ch_27628 == 43LL);
    _15410 = (_15411 != 0);
L4C: 
    if (_15410 != 0) {
        goto L4D; // [1863] 1884
    }
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15413 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    _15414 = (_15413 == -7LL);
    _15413 = NOVALUE;
    if (_15414 == 0)
    {
        DeRef(_15414);
        _15414 = NOVALUE;
        goto L4E; // [1880] 1893
    }
    else{
        DeRef(_15414);
        _15414 = NOVALUE;
    }
L4D: 

    /** scanner.e:1748						yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);
    goto L4F; // [1890] 1903
L4E: 

    /** scanner.e:1750						CompileErr(EXPONENT_NOT_FORMED_CORRECTLY)*/
    RefDS(_22186);
    _50CompileErr(86LL, _22186, 0LL);
L4F: 

    /** scanner.e:1752					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1753					while char_class[ch] = DIGIT do*/
L50: 
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15417 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15417 != -7LL)
    goto L51; // [1923] 1981

    /** scanner.e:1754						yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);

    /** scanner.e:1755						ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1756					end while*/
    goto L50; // [1942] 1915
    goto L51; // [1945] 1981
L4B: 

    /** scanner.e:1757				elsif char_class[ch] = LETTER then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15421 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15421 != -2LL)
    goto L52; // [1958] 1980

    /** scanner.e:1758					CompileErr(PUNCTUATION_MISSING_IN_BETWEEN_NUMBER_AND_1, {{ch}})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_27628;
    _15423 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _15423;
    _15424 = MAKE_SEQ(_1);
    _15423 = NOVALUE;
    _50CompileErr(127LL, _15424, 0LL);
    _15424 = NOVALUE;
L52: 
L51: 

    /** scanner.e:1761				ungetch()*/
    _62ungetch();

    /** scanner.e:1763				while i != 0 with entry do*/
    goto L53; // [1987] 2006
L54: 
    if (binary_op_a(EQUALS, _i_27631, 0LL)){
        goto L55; // [1992] 2018
    }

    /** scanner.e:1764					yytext = remove( yytext, i )*/
    {
        s1_ptr assign_space = SEQ_PTR(_yytext_27634);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_27631)) ? _i_27631 : (object)(DBL_PTR(_i_27631)->dbl);
        int stop = (IS_ATOM_INT(_i_27631)) ? _i_27631 : (object)(DBL_PTR(_i_27631)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_yytext_27634), start, &_yytext_27634 );
            }
            else Tail(SEQ_PTR(_yytext_27634), stop+1, &_yytext_27634);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_yytext_27634), start, &_yytext_27634);
        }
        else {
            assign_slice_seq = &assign_space;
            _yytext_27634 = Remove_elements(start, stop, (SEQ_PTR(_yytext_27634)->ref == 1));
        }
    }

    /** scanner.e:1765				  entry*/
L53: 

    /** scanner.e:1766				    i = find('_', yytext)*/
    DeRef(_i_27631);
    _i_27631 = find_from(95LL, _yytext_27634, 1LL);

    /** scanner.e:1767				end while*/
    goto L54; // [2015] 1990
L55: 

    /** scanner.e:1769				if is_int then*/
    if (_is_int_27639 == 0)
    {
        goto L56; // [2020] 2092
    }
    else{
    }

    /** scanner.e:1770					if basetype = -1 then*/
    if (_basetype_27936 != -1LL)
    goto L57; // [2025] 2035

    /** scanner.e:1771						basetype = 3 -- decimal*/
    _basetype_27936 = 3LL;
L57: 

    /** scanner.e:1773					d = MakeInt(yytext, nbase[basetype])*/
    _2 = (object)SEQ_PTR(_62nbase_27430);
    _15429 = (object)*(((s1_ptr)_2)->base + _basetype_27936);
    RefDS(_yytext_27634);
    Ref(_15429);
    _0 = _d_27636;
    _d_27636 = _62MakeInt(_yytext_27634, _15429);
    DeRef(_0);
    _15429 = NOVALUE;

    /** scanner.e:1774					if is_integer(d) then*/
    Ref(_d_27636);
    _15431 = _36is_integer(_d_27636);
    if (_15431 == 0) {
        DeRef(_15431);
        _15431 = NOVALUE;
        goto L58; // [2052] 2074
    }
    else {
        if (!IS_ATOM_INT(_15431) && DBL_PTR(_15431)->dbl == 0.0){
            DeRef(_15431);
            _15431 = NOVALUE;
            goto L58; // [2052] 2074
        }
        DeRef(_15431);
        _15431 = NOVALUE;
    }
    DeRef(_15431);
    _15431 = NOVALUE;

    /** scanner.e:1775						return {ATOM, NewIntSym(d)}*/
    Ref(_d_27636);
    _15432 = _54NewIntSym(_d_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15432;
    _15433 = MAKE_SEQ(_1);
    _15432 = NOVALUE;
    DeRef(_i_27631);
    DeRefDS(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15433;
    goto L59; // [2071] 2091
L58: 

    /** scanner.e:1777						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27636);
    _15434 = _54NewDoubleSym(_d_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15434;
    _15435 = MAKE_SEQ(_1);
    _15434 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15435;
L59: 
L56: 

    /** scanner.e:1782				if basetype != -1 then*/
    if (_basetype_27936 == -1LL)
    goto L5A; // [2094] 2112

    /** scanner.e:1783					CompileErr(ONLY_INTEGER_LITERALS_CAN_USE_THE_01_FORMAT, nbasecode[basetype])*/
    _2 = (object)SEQ_PTR(_62nbasecode_27431);
    _15437 = (object)*(((s1_ptr)_2)->base + _basetype_27936);
    Ref(_15437);
    _50CompileErr(125LL, _15437, 0LL);
    _15437 = NOVALUE;
L5A: 

    /** scanner.e:1787				d = my_sscanf(yytext)*/
    RefDS(_yytext_27634);
    _0 = _d_27636;
    _d_27636 = _62my_sscanf(_yytext_27634);
    DeRef(_0);

    /** scanner.e:1788				if sequence(d) then*/
    _15439 = IS_SEQUENCE(_d_27636);
    if (_15439 == 0)
    {
        _15439 = NOVALUE;
        goto L5B; // [2123] 2138
    }
    else{
        _15439 = NOVALUE;
    }

    /** scanner.e:1789					CompileErr(NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22186);
    _50CompileErr(121LL, _22186, 0LL);
    goto L5C; // [2135] 2190
L5B: 

    /** scanner.e:1790				elsif is_int and d <= TMAXINT_DBL then*/
    if (_is_int_27639 == 0) {
        goto L5D; // [2140] 2173
    }
    if (IS_ATOM_INT(_d_27636) && IS_ATOM_INT(_36TMAXINT_DBL_21591)) {
        _15441 = (_d_27636 <= _36TMAXINT_DBL_21591);
    }
    else {
        _15441 = binary_op(LESSEQ, _d_27636, _36TMAXINT_DBL_21591);
    }
    if (_15441 == 0) {
        DeRef(_15441);
        _15441 = NOVALUE;
        goto L5D; // [2151] 2173
    }
    else {
        if (!IS_ATOM_INT(_15441) && DBL_PTR(_15441)->dbl == 0.0){
            DeRef(_15441);
            _15441 = NOVALUE;
            goto L5D; // [2151] 2173
        }
        DeRef(_15441);
        _15441 = NOVALUE;
    }
    DeRef(_15441);
    _15441 = NOVALUE;

    /** scanner.e:1791					return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_27636);
    _15442 = _54NewIntSym(_d_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15442;
    _15443 = MAKE_SEQ(_1);
    _15442 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15443;
    goto L5C; // [2170] 2190
L5D: 

    /** scanner.e:1793					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27636);
    _15444 = _54NewDoubleSym(_d_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15444;
    _15445 = MAKE_SEQ(_1);
    _15444 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15445;
L5C: 
    goto L1; // [2192] 10
L33: 

    /** scanner.e:1797			elsif class = MINUS then*/
    if (_class_27640 != 10LL)
    goto L5E; // [2199] 2285

    /** scanner.e:1798				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1799				if ch = '-' then*/
    if (_ch_27628 != 45LL)
    goto L5F; // [2212] 2238

    /** scanner.e:1801					if start_include then*/
    if (_62start_include_25867 == 0)
    {
        goto L60; // [2220] 2230
    }
    else{
    }

    /** scanner.e:1802						IncludePush()*/
    _62IncludePush();
    goto L1; // [2227] 10
L60: 

    /** scanner.e:1804						read_line()*/
    _62read_line();
    goto L1; // [2235] 10
L5F: 

    /** scanner.e:1806				elsif ch = '=' then*/
    if (_ch_27628 != 61LL)
    goto L61; // [2240] 2259

    /** scanner.e:1807					return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 516LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15450 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15450;
    goto L1; // [2256] 10
L61: 

    /** scanner.e:1809					bp -= 1*/
    _50bp_49594 = _50bp_49594 - 1LL;

    /** scanner.e:1810					return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15452 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15452;
    goto L1; // [2282] 10
L5E: 

    /** scanner.e:1812			elsif class = DOUBLE_QUOTE then*/
    if (_class_27640 != -4LL)
    goto L62; // [2289] 2487

    /** scanner.e:1813				integer fch*/

    /** scanner.e:1814				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1815				if ch = '"' then*/
    if (_ch_27628 != 34LL)
    goto L63; // [2304] 2340

    /** scanner.e:1816					fch = getch()*/
    _fch_28117 = _62getch();
    if (!IS_ATOM_INT(_fch_28117)) {
        _1 = (object)(DBL_PTR(_fch_28117)->dbl);
        DeRefDS(_fch_28117);
        _fch_28117 = _1;
    }

    /** scanner.e:1817					if fch = '"' then*/
    if (_fch_28117 != 34LL)
    goto L64; // [2317] 2334

    /** scanner.e:1819						return ExtendedString( fch )*/
    _15458 = _62ExtendedString(_fch_28117);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15458;
    goto L65; // [2331] 2339
L64: 

    /** scanner.e:1821						ungetch()*/
    _62ungetch();
L65: 
L63: 

    /** scanner.e:1824				yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_27634);
    _yytext_27634 = _5;

    /** scanner.e:1825				while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _15459 = (_ch_27628 != 10LL);
    if (_15459 == 0) {
        goto L67; // [2356] 2437
    }
    _15461 = (_ch_27628 != 13LL);
    if (_15461 == 0)
    {
        DeRef(_15461);
        _15461 = NOVALUE;
        goto L67; // [2365] 2437
    }
    else{
        DeRef(_15461);
        _15461 = NOVALUE;
    }

    /** scanner.e:1826					if ch = '"' then*/
    if (_ch_27628 != 34LL)
    goto L68; // [2370] 2381

    /** scanner.e:1827						exit*/
    goto L67; // [2376] 2437
    goto L69; // [2378] 2425
L68: 

    /** scanner.e:1828					elsif ch = '\\' then*/
    if (_ch_27628 != 92LL)
    goto L6A; // [2383] 2400

    /** scanner.e:1829						yytext &= EscapeChar('"')*/
    _15464 = _62EscapeChar(34LL);
    if (IS_SEQUENCE(_yytext_27634) && IS_ATOM(_15464)) {
        Ref(_15464);
        Append(&_yytext_27634, _yytext_27634, _15464);
    }
    else if (IS_ATOM(_yytext_27634) && IS_SEQUENCE(_15464)) {
    }
    else {
        Concat((object_ptr)&_yytext_27634, _yytext_27634, _15464);
    }
    DeRef(_15464);
    _15464 = NOVALUE;
    goto L69; // [2397] 2425
L6A: 

    /** scanner.e:1830					elsif ch = '\t' then*/
    if (_ch_27628 != 9LL)
    goto L6B; // [2402] 2418

    /** scanner.e:1831						CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22186);
    _50CompileErr(145LL, _22186, 0LL);
    goto L69; // [2415] 2425
L6B: 

    /** scanner.e:1833						yytext &= ch*/
    Append(&_yytext_27634, _yytext_27634, _ch_27628);
L69: 

    /** scanner.e:1835					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1836				end while*/
    goto L66; // [2434] 2352
L67: 

    /** scanner.e:1837				if ch = '\n' or ch = '\r' then*/
    _15469 = (_ch_27628 == 10LL);
    if (_15469 != 0) {
        goto L6C; // [2443] 2456
    }
    _15471 = (_ch_27628 == 13LL);
    if (_15471 == 0)
    {
        DeRef(_15471);
        _15471 = NOVALUE;
        goto L6D; // [2452] 2466
    }
    else{
        DeRef(_15471);
        _15471 = NOVALUE;
    }
L6C: 

    /** scanner.e:1838					CompileErr(END_OF_LINE_REACHED_WITH_NO_CLOSING)*/
    RefDS(_22186);
    _50CompileErr(67LL, _22186, 0LL);
L6D: 

    /** scanner.e:1840				return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_27634);
    _15472 = _54NewStringSym(_yytext_27634);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 503LL;
    ((intptr_t *)_2)[2] = _15472;
    _15473 = MAKE_SEQ(_1);
    _15472 = NOVALUE;
    DeRef(_i_27631);
    DeRefDS(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15473;
    goto L1; // [2484] 10
L62: 

    /** scanner.e:1842			elsif class = PLUS then*/
    if (_class_27640 != 11LL)
    goto L6E; // [2491] 2543

    /** scanner.e:1843				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1844				if ch = '=' then*/
    if (_ch_27628 != 61LL)
    goto L6F; // [2504] 2523

    /** scanner.e:1845					return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 515LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15477 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15477;
    goto L1; // [2520] 10
L6F: 

    /** scanner.e:1847					ungetch()*/
    _62ungetch();

    /** scanner.e:1848					return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 11LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15478 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15478;
    goto L1; // [2540] 10
L6E: 

    /** scanner.e:1851			elsif class = res:CONCAT then*/
    if (_class_27640 != 15LL)
    goto L70; // [2545] 2595

    /** scanner.e:1852				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1853				if ch = '=' then*/
    if (_ch_27628 != 61LL)
    goto L71; // [2558] 2577

    /** scanner.e:1854					return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 519LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15482 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15482;
    goto L1; // [2574] 10
L71: 

    /** scanner.e:1856					ungetch()*/
    _62ungetch();

    /** scanner.e:1857					return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 15LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15483 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    return _15483;
    goto L1; // [2592] 10
L70: 

    /** scanner.e:1860			elsif class = NUMBER_SIGN then*/
    if (_class_27640 != -11LL)
    goto L72; // [2599] 3122

    /** scanner.e:1861				i = 0*/
    DeRef(_i_27631);
    _i_27631 = 0LL;

    /** scanner.e:1862				is_int = -1*/
    _is_int_27639 = -1LL;

    /** scanner.e:1863				while i < TMAXINT/32 do*/
L73: 
    if (IS_ATOM_INT(_36TMAXINT_21588)) {
        _15485 = (_36TMAXINT_21588 % 32LL) ? NewDouble((eudouble)_36TMAXINT_21588 / 32LL) : (_36TMAXINT_21588 / 32LL);
    }
    else {
        _15485 = NewDouble(DBL_PTR(_36TMAXINT_21588)->dbl / (eudouble)32LL);
    }
    if (binary_op_a(GREATEREQ, _i_27631, _15485)){
        DeRef(_15485);
        _15485 = NOVALUE;
        goto L74; // [2624] 2788
    }
    DeRef(_15485);
    _15485 = NOVALUE;

    /** scanner.e:1864					ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1865					if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15488 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15488 != -7LL)
    goto L75; // [2645] 2682

    /** scanner.e:1866						if ch != '_' then*/
    if (_ch_27628 == 95LL)
    goto L73; // [2651] 2618

    /** scanner.e:1867							i = i * 16 + ch - '0'*/
    if (IS_ATOM_INT(_i_27631)) {
        {
            int128_t p128 = (int128_t)_i_27631 * (int128_t)16LL;
            if( p128 != (int128_t)(_15491 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15491 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15491 = NewDouble(DBL_PTR(_i_27631)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15491)) {
        _15492 = _15491 + _ch_27628;
        if ((object)((uintptr_t)_15492 + (uintptr_t)HIGH_BITS) >= 0){
            _15492 = NewDouble((eudouble)_15492);
        }
    }
    else {
        _15492 = NewDouble(DBL_PTR(_15491)->dbl + (eudouble)_ch_27628);
    }
    DeRef(_15491);
    _15491 = NOVALUE;
    DeRef(_i_27631);
    if (IS_ATOM_INT(_15492)) {
        _i_27631 = _15492 - 48LL;
        if ((object)((uintptr_t)_i_27631 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27631 = NewDouble((eudouble)_i_27631);
        }
    }
    else {
        _i_27631 = NewDouble(DBL_PTR(_15492)->dbl - (eudouble)48LL);
    }
    DeRef(_15492);
    _15492 = NOVALUE;

    /** scanner.e:1868							is_int = TRUE*/
    _is_int_27639 = _13TRUE_447;
    goto L73; // [2679] 2618
L75: 

    /** scanner.e:1870					elsif ch >= 'A' and ch <= 'F' then*/
    _15494 = (_ch_27628 >= 65LL);
    if (_15494 == 0) {
        goto L76; // [2688] 2730
    }
    _15496 = (_ch_27628 <= 70LL);
    if (_15496 == 0)
    {
        DeRef(_15496);
        _15496 = NOVALUE;
        goto L76; // [2697] 2730
    }
    else{
        DeRef(_15496);
        _15496 = NOVALUE;
    }

    /** scanner.e:1871						i = (i * 16) + ch - ('A'-10)*/
    if (IS_ATOM_INT(_i_27631)) {
        {
            int128_t p128 = (int128_t)_i_27631 * (int128_t)16LL;
            if( p128 != (int128_t)(_15497 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15497 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15497 = NewDouble(DBL_PTR(_i_27631)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15497)) {
        _15498 = _15497 + _ch_27628;
        if ((object)((uintptr_t)_15498 + (uintptr_t)HIGH_BITS) >= 0){
            _15498 = NewDouble((eudouble)_15498);
        }
    }
    else {
        _15498 = NewDouble(DBL_PTR(_15497)->dbl + (eudouble)_ch_27628);
    }
    DeRef(_15497);
    _15497 = NOVALUE;
    _15499 = 55LL;
    DeRef(_i_27631);
    if (IS_ATOM_INT(_15498)) {
        _i_27631 = _15498 - 55LL;
        if ((object)((uintptr_t)_i_27631 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27631 = NewDouble((eudouble)_i_27631);
        }
    }
    else {
        _i_27631 = NewDouble(DBL_PTR(_15498)->dbl - (eudouble)55LL);
    }
    DeRef(_15498);
    _15498 = NOVALUE;
    _15499 = NOVALUE;

    /** scanner.e:1872						is_int = TRUE*/
    _is_int_27639 = _13TRUE_447;
    goto L73; // [2727] 2618
L76: 

    /** scanner.e:1873					elsif ch >= 'a' and ch <= 'f' then*/
    _15501 = (_ch_27628 >= 97LL);
    if (_15501 == 0) {
        goto L74; // [2736] 2788
    }
    _15503 = (_ch_27628 <= 102LL);
    if (_15503 == 0)
    {
        DeRef(_15503);
        _15503 = NOVALUE;
        goto L74; // [2745] 2788
    }
    else{
        DeRef(_15503);
        _15503 = NOVALUE;
    }

    /** scanner.e:1874						i = (i * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_i_27631)) {
        {
            int128_t p128 = (int128_t)_i_27631 * (int128_t)16LL;
            if( p128 != (int128_t)(_15504 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15504 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15504 = NewDouble(DBL_PTR(_i_27631)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_15504)) {
        _15505 = _15504 + _ch_27628;
        if ((object)((uintptr_t)_15505 + (uintptr_t)HIGH_BITS) >= 0){
            _15505 = NewDouble((eudouble)_15505);
        }
    }
    else {
        _15505 = NewDouble(DBL_PTR(_15504)->dbl + (eudouble)_ch_27628);
    }
    DeRef(_15504);
    _15504 = NOVALUE;
    _15506 = 87LL;
    DeRef(_i_27631);
    if (IS_ATOM_INT(_15505)) {
        _i_27631 = _15505 - 87LL;
        if ((object)((uintptr_t)_i_27631 +(uintptr_t) HIGH_BITS) >= 0){
            _i_27631 = NewDouble((eudouble)_i_27631);
        }
    }
    else {
        _i_27631 = NewDouble(DBL_PTR(_15505)->dbl - (eudouble)87LL);
    }
    DeRef(_15505);
    _15505 = NOVALUE;
    _15506 = NOVALUE;

    /** scanner.e:1875						is_int = TRUE*/
    _is_int_27639 = _13TRUE_447;
    goto L73; // [2775] 2618

    /** scanner.e:1877						exit*/
    goto L74; // [2780] 2788

    /** scanner.e:1879				end while*/
    goto L73; // [2785] 2618
L74: 

    /** scanner.e:1881				if is_int = -1 then*/
    if (_is_int_27639 != -1LL)
    goto L77; // [2790] 2857

    /** scanner.e:1882					if ch = '!' then*/
    if (_ch_27628 != 33LL)
    goto L78; // [2796] 2844

    /** scanner.e:1883						if line_number > 1 then*/
    if (_36line_number_21760 <= 1LL)
    goto L79; // [2804] 2818

    /** scanner.e:1884							CompileErr(MSG__MAY_ONLY_BE_ON_THE_FIRST_LINE_OF_A_PROGRAM)*/
    RefDS(_22186);
    _50CompileErr(161LL, _22186, 0LL);
L79: 

    /** scanner.e:1887						shebang = ThisLine*/
    Ref(_50ThisLine_49590);
    DeRef(_62shebang_25872);
    _62shebang_25872 = _50ThisLine_49590;

    /** scanner.e:1888						if start_include then*/
    if (_62start_include_25867 == 0)
    {
        goto L7A; // [2829] 2837
    }
    else{
    }

    /** scanner.e:1889							IncludePush()*/
    _62IncludePush();
L7A: 

    /** scanner.e:1891						read_line()*/
    _62read_line();
    goto L1; // [2841] 10
L78: 

    /** scanner.e:1893						CompileErr(HEX_NUMBER_NOT_FORMED_CORRECTLY)*/
    RefDS(_22186);
    _50CompileErr(97LL, _22186, 0LL);
    goto L1; // [2854] 10
L77: 

    /** scanner.e:1896					d = i*/
    Ref(_i_27631);
    DeRef(_d_27636);
    _d_27636 = _i_27631;

    /** scanner.e:1897					if i >= TMAXINT/32 then*/
    if (IS_ATOM_INT(_36TMAXINT_21588)) {
        _15511 = (_36TMAXINT_21588 % 32LL) ? NewDouble((eudouble)_36TMAXINT_21588 / 32LL) : (_36TMAXINT_21588 / 32LL);
    }
    else {
        _15511 = NewDouble(DBL_PTR(_36TMAXINT_21588)->dbl / (eudouble)32LL);
    }
    if (binary_op_a(LESS, _i_27631, _15511)){
        DeRef(_15511);
        _15511 = NOVALUE;
        goto L7B; // [2870] 3036
    }
    DeRef(_15511);
    _15511 = NOVALUE;

    /** scanner.e:1898						is_int = FALSE*/
    _is_int_27639 = _13FALSE_445;

    /** scanner.e:1899						while TRUE do*/
L7C: 
    if (_13TRUE_447 == 0)
    {
        goto L7D; // [2890] 3035
    }
    else{
    }

    /** scanner.e:1900							ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1901							if char_class[ch] = DIGIT then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15514 = (object)*(((s1_ptr)_2)->base + _ch_27628);
    if (_15514 != -7LL)
    goto L7E; // [2910] 2938

    /** scanner.e:1902								if ch != '_' then*/
    if (_ch_27628 == 95LL)
    goto L7C; // [2916] 2888

    /** scanner.e:1903									d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_27636)) {
        {
            int128_t p128 = (int128_t)_d_27636 * (int128_t)16LL;
            if( p128 != (int128_t)(_15517 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15517 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15517 = binary_op(MULTIPLY, _d_27636, 16LL);
    }
    if (IS_ATOM_INT(_15517)) {
        _15518 = _15517 + _ch_27628;
        if ((object)((uintptr_t)_15518 + (uintptr_t)HIGH_BITS) >= 0){
            _15518 = NewDouble((eudouble)_15518);
        }
    }
    else {
        _15518 = binary_op(PLUS, _15517, _ch_27628);
    }
    DeRef(_15517);
    _15517 = NOVALUE;
    DeRef(_d_27636);
    if (IS_ATOM_INT(_15518)) {
        _d_27636 = _15518 - 48LL;
        if ((object)((uintptr_t)_d_27636 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27636 = NewDouble((eudouble)_d_27636);
        }
    }
    else {
        _d_27636 = binary_op(MINUS, _15518, 48LL);
    }
    DeRef(_15518);
    _15518 = NOVALUE;
    goto L7C; // [2935] 2888
L7E: 

    /** scanner.e:1905							elsif ch >= 'A' and ch <= 'F' then*/
    _15520 = (_ch_27628 >= 65LL);
    if (_15520 == 0) {
        goto L7F; // [2944] 2977
    }
    _15522 = (_ch_27628 <= 70LL);
    if (_15522 == 0)
    {
        DeRef(_15522);
        _15522 = NOVALUE;
        goto L7F; // [2953] 2977
    }
    else{
        DeRef(_15522);
        _15522 = NOVALUE;
    }

    /** scanner.e:1906								d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_27636)) {
        {
            int128_t p128 = (int128_t)_d_27636 * (int128_t)16LL;
            if( p128 != (int128_t)(_15523 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15523 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15523 = binary_op(MULTIPLY, _d_27636, 16LL);
    }
    if (IS_ATOM_INT(_15523)) {
        _15524 = _15523 + _ch_27628;
        if ((object)((uintptr_t)_15524 + (uintptr_t)HIGH_BITS) >= 0){
            _15524 = NewDouble((eudouble)_15524);
        }
    }
    else {
        _15524 = binary_op(PLUS, _15523, _ch_27628);
    }
    DeRef(_15523);
    _15523 = NOVALUE;
    _15525 = 55LL;
    DeRef(_d_27636);
    if (IS_ATOM_INT(_15524)) {
        _d_27636 = _15524 - 55LL;
        if ((object)((uintptr_t)_d_27636 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27636 = NewDouble((eudouble)_d_27636);
        }
    }
    else {
        _d_27636 = binary_op(MINUS, _15524, 55LL);
    }
    DeRef(_15524);
    _15524 = NOVALUE;
    _15525 = NOVALUE;
    goto L7C; // [2974] 2888
L7F: 

    /** scanner.e:1907							elsif ch >= 'a' and ch <= 'f' then*/
    _15527 = (_ch_27628 >= 97LL);
    if (_15527 == 0) {
        goto L80; // [2983] 3016
    }
    _15529 = (_ch_27628 <= 102LL);
    if (_15529 == 0)
    {
        DeRef(_15529);
        _15529 = NOVALUE;
        goto L80; // [2992] 3016
    }
    else{
        DeRef(_15529);
        _15529 = NOVALUE;
    }

    /** scanner.e:1908								d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_27636)) {
        {
            int128_t p128 = (int128_t)_d_27636 * (int128_t)16LL;
            if( p128 != (int128_t)(_15530 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _15530 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _15530 = binary_op(MULTIPLY, _d_27636, 16LL);
    }
    if (IS_ATOM_INT(_15530)) {
        _15531 = _15530 + _ch_27628;
        if ((object)((uintptr_t)_15531 + (uintptr_t)HIGH_BITS) >= 0){
            _15531 = NewDouble((eudouble)_15531);
        }
    }
    else {
        _15531 = binary_op(PLUS, _15530, _ch_27628);
    }
    DeRef(_15530);
    _15530 = NOVALUE;
    _15532 = 87LL;
    DeRef(_d_27636);
    if (IS_ATOM_INT(_15531)) {
        _d_27636 = _15531 - 87LL;
        if ((object)((uintptr_t)_d_27636 +(uintptr_t) HIGH_BITS) >= 0){
            _d_27636 = NewDouble((eudouble)_d_27636);
        }
    }
    else {
        _d_27636 = binary_op(MINUS, _15531, 87LL);
    }
    DeRef(_15531);
    _15531 = NOVALUE;
    _15532 = NOVALUE;
    goto L7C; // [3013] 2888
L80: 

    /** scanner.e:1909							elsif ch = '_' then*/
    if (_ch_27628 != 95LL)
    goto L7D; // [3018] 3035
    goto L7C; // [3022] 2888

    /** scanner.e:1912								exit*/
    goto L7D; // [3027] 3035

    /** scanner.e:1914						end while*/
    goto L7C; // [3032] 2888
L7D: 
L7B: 

    /** scanner.e:1917					ungetch()*/
    _62ungetch();

    /** scanner.e:1918					if is_int and is_integer(i) then*/
    if (_is_int_27639 == 0) {
        goto L81; // [3042] 3073
    }
    Ref(_i_27631);
    _15536 = _36is_integer(_i_27631);
    if (_15536 == 0) {
        DeRef(_15536);
        _15536 = NOVALUE;
        goto L81; // [3051] 3073
    }
    else {
        if (!IS_ATOM_INT(_15536) && DBL_PTR(_15536)->dbl == 0.0){
            DeRef(_15536);
            _15536 = NOVALUE;
            goto L81; // [3051] 3073
        }
        DeRef(_15536);
        _15536 = NOVALUE;
    }
    DeRef(_15536);
    _15536 = NOVALUE;

    /** scanner.e:1919						return {ATOM, NewIntSym(i)}*/
    Ref(_i_27631);
    _15537 = _54NewIntSym(_i_27631);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15537;
    _15538 = MAKE_SEQ(_1);
    _15537 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15538;
    goto L1; // [3070] 10
L81: 

    /** scanner.e:1921						if d <= TMAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_27636, _36TMAXINT_DBL_21591)){
        goto L82; // [3077] 3100
    }

    /** scanner.e:1922							return {ATOM, NewIntSym(d)}*/
    Ref(_d_27636);
    _15540 = _54NewIntSym(_d_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15540;
    _15541 = MAKE_SEQ(_1);
    _15540 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15541;
    goto L1; // [3097] 10
L82: 

    /** scanner.e:1924							return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_27636);
    _15542 = _54NewDoubleSym(_d_27636);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15542;
    _15543 = MAKE_SEQ(_1);
    _15542 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15543;
    goto L1; // [3119] 10
L72: 

    /** scanner.e:1929			elsif class = res:MULTIPLY then*/
    if (_class_27640 != 13LL)
    goto L83; // [3124] 3174

    /** scanner.e:1930				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1931				if ch = '=' then*/
    if (_ch_27628 != 61LL)
    goto L84; // [3137] 3156

    /** scanner.e:1932					return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 517LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15547 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15547;
    goto L1; // [3153] 10
L84: 

    /** scanner.e:1934					ungetch()*/
    _62ungetch();

    /** scanner.e:1935					return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 13LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15548 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15548;
    goto L1; // [3171] 10
L83: 

    /** scanner.e:1938			elsif class = res:DIVIDE then*/
    if (_class_27640 != 14LL)
    goto L85; // [3176] 3380

    /** scanner.e:1939				ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1940				if ch = '=' then*/
    if (_ch_27628 != 61LL)
    goto L86; // [3189] 3208

    /** scanner.e:1941					return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 518LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15552 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15552;
    goto L1; // [3205] 10
L86: 

    /** scanner.e:1942				elsif ch = '*' then*/
    if (_ch_27628 != 42LL)
    goto L87; // [3210] 3362

    /** scanner.e:1944					cline = line_number*/
    _cline_27633 = _36line_number_21760;

    /** scanner.e:1945					integer cnest = 1*/
    _cnest_28301 = 1LL;

    /** scanner.e:1946					while cnest > 0 do*/
L88: 
    if (_cnest_28301 <= 0LL)
    goto L89; // [3233] 3341

    /** scanner.e:1947						ch = getch()*/
    _ch_27628 = _62getch();
    if (!IS_ATOM_INT(_ch_27628)) {
        _1 = (object)(DBL_PTR(_ch_27628)->dbl);
        DeRefDS(_ch_27628);
        _ch_27628 = _1;
    }

    /** scanner.e:1948						switch ch do*/
    _0 = _ch_27628;
    switch ( _0 ){ 

        /** scanner.e:1949							case  END_OF_FILE_CHAR then*/
        case 26:

        /** scanner.e:1950								exit*/
        goto L89; // [3257] 3341
        goto L88; // [3259] 3233

        /** scanner.e:1952							case '\n' then*/
        case 10:

        /** scanner.e:1953								read_line()*/
        _62read_line();
        goto L88; // [3269] 3233

        /** scanner.e:1955							case '*' then*/
        case 42:

        /** scanner.e:1956								ch = getch()*/
        _ch_27628 = _62getch();
        if (!IS_ATOM_INT(_ch_27628)) {
            _1 = (object)(DBL_PTR(_ch_27628)->dbl);
            DeRefDS(_ch_27628);
            _ch_27628 = _1;
        }

        /** scanner.e:1957								if ch = '/' then*/
        if (_ch_27628 != 47LL)
        goto L8A; // [3284] 3297

        /** scanner.e:1958									cnest -= 1*/
        _cnest_28301 = _cnest_28301 - 1LL;
        goto L88; // [3294] 3233
L8A: 

        /** scanner.e:1960									ungetch()*/
        _62ungetch();
        goto L88; // [3302] 3233

        /** scanner.e:1963							case '/' then*/
        case 47:

        /** scanner.e:1964								ch = getch()*/
        _ch_27628 = _62getch();
        if (!IS_ATOM_INT(_ch_27628)) {
            _1 = (object)(DBL_PTR(_ch_27628)->dbl);
            DeRefDS(_ch_27628);
            _ch_27628 = _1;
        }

        /** scanner.e:1965								if ch = '*' then*/
        if (_ch_27628 != 42LL)
        goto L8B; // [3317] 3330

        /** scanner.e:1966									cnest += 1*/
        _cnest_28301 = _cnest_28301 + 1;
        goto L8C; // [3327] 3335
L8B: 

        /** scanner.e:1968									ungetch()*/
        _62ungetch();
L8C: 
    ;}
    /** scanner.e:1972					end while*/
    goto L88; // [3338] 3233
L89: 

    /** scanner.e:1974					if cnest > 0 then*/
    if (_cnest_28301 <= 0LL)
    goto L8D; // [3343] 3357

    /** scanner.e:1975						CompileErr(BLOCK_COMMENT_FROM_LINE_1_NOT_TERMINATED, cline)*/
    _50CompileErr(42LL, _cline_27633, 0LL);
L8D: 
    goto L1; // [3359] 10
L87: 

    /** scanner.e:1978					ungetch()*/
    _62ungetch();

    /** scanner.e:1979					return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 14LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15565 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15565;
    goto L1; // [3377] 10
L85: 

    /** scanner.e:1981			elsif class = SINGLE_QUOTE then*/
    if (_class_27640 != -5LL)
    goto L8E; // [3384] 3534

    /** scanner.e:1982				atom ach = getch()*/
    _0 = _ach_28331;
    _ach_28331 = _62getch();
    DeRef(_0);

    /** scanner.e:1983				if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_28331, 92LL)){
        goto L8F; // [3395] 3408
    }

    /** scanner.e:1984					ach = EscapeChar('\'')*/
    _0 = _ach_28331;
    _ach_28331 = _62EscapeChar(39LL);
    DeRef(_0);
    goto L90; // [3405] 3465
L8F: 

    /** scanner.e:1985				elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_28331, 9LL)){
        goto L91; // [3410] 3426
    }

    /** scanner.e:1986					CompileErr(MSG_TAB_CHARACTER_FOUND_IN_STRING__USE_T_INSTEAD)*/
    RefDS(_22186);
    _50CompileErr(145LL, _22186, 0LL);
    goto L90; // [3423] 3465
L91: 

    /** scanner.e:1987				elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_28331, 39LL)){
        goto L92; // [3428] 3444
    }

    /** scanner.e:1988					CompileErr(SINGLEQUOTE_CHARACTER_IS_EMPTY)*/
    RefDS(_22186);
    _50CompileErr(137LL, _22186, 0LL);
    goto L90; // [3441] 3465
L92: 

    /** scanner.e:1989				elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_28331, 10LL)){
        goto L93; // [3446] 3464
    }

    /** scanner.e:1990					CompileErr(EXPECTED_1_NOT_2, {"character", "end of line"})*/
    RefDS(_15574);
    RefDS(_15573);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15573;
    ((intptr_t *)_2)[2] = _15574;
    _15575 = MAKE_SEQ(_1);
    _50CompileErr(68LL, _15575, 0LL);
    _15575 = NOVALUE;
L93: 
L90: 

    /** scanner.e:1992				if getch() != '\'' then*/
    _15576 = _62getch();
    if (binary_op_a(EQUALS, _15576, 39LL)){
        DeRef(_15576);
        _15576 = NOVALUE;
        goto L94; // [3470] 3484
    }
    DeRef(_15576);
    _15576 = NOVALUE;

    /** scanner.e:1993					CompileErr(CHARACTER_CONSTANT_IS_MISSING_A_CLOSING)*/
    RefDS(_22186);
    _50CompileErr(56LL, _22186, 0LL);
L94: 

    /** scanner.e:1995				if is_integer(ach) then*/
    Ref(_ach_28331);
    _15578 = _36is_integer(_ach_28331);
    if (_15578 == 0) {
        DeRef(_15578);
        _15578 = NOVALUE;
        goto L95; // [3490] 3512
    }
    else {
        if (!IS_ATOM_INT(_15578) && DBL_PTR(_15578)->dbl == 0.0){
            DeRef(_15578);
            _15578 = NOVALUE;
            goto L95; // [3490] 3512
        }
        DeRef(_15578);
        _15578 = NOVALUE;
    }
    DeRef(_15578);
    _15578 = NOVALUE;

    /** scanner.e:1996					return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_28331);
    _15579 = _54NewIntSym(_ach_28331);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15579;
    _15580 = MAKE_SEQ(_1);
    _15579 = NOVALUE;
    DeRef(_ach_28331);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15580;
    goto L96; // [3509] 3529
L95: 

    /** scanner.e:1998					return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_28331);
    _15581 = _54NewDoubleSym(_ach_28331);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 502LL;
    ((intptr_t *)_2)[2] = _15581;
    _15582 = MAKE_SEQ(_1);
    _15581 = NOVALUE;
    DeRef(_ach_28331);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15582;
L96: 
    DeRef(_ach_28331);
    _ach_28331 = NOVALUE;
    goto L1; // [3531] 10
L8E: 

    /** scanner.e:2001			elsif class = LESS then*/
    if (_class_27640 != 1LL)
    goto L97; // [3538] 3586

    /** scanner.e:2002				if getch() = '=' then*/
    _15584 = _62getch();
    if (binary_op_a(NOTEQ, _15584, 61LL)){
        DeRef(_15584);
        _15584 = NOVALUE;
        goto L98; // [3547] 3566
    }
    DeRef(_15584);
    _15584 = NOVALUE;

    /** scanner.e:2003					return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 5LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15586 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15586;
    goto L1; // [3563] 10
L98: 

    /** scanner.e:2005					ungetch()*/
    _62ungetch();

    /** scanner.e:2006					return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15587 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15587;
    goto L1; // [3583] 10
L97: 

    /** scanner.e:2009			elsif class = GREATER then*/
    if (_class_27640 != 6LL)
    goto L99; // [3590] 3638

    /** scanner.e:2010				if getch() = '=' then*/
    _15589 = _62getch();
    if (binary_op_a(NOTEQ, _15589, 61LL)){
        DeRef(_15589);
        _15589 = NOVALUE;
        goto L9A; // [3599] 3618
    }
    DeRef(_15589);
    _15589 = NOVALUE;

    /** scanner.e:2011					return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 2LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15591 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15591;
    goto L1; // [3615] 10
L9A: 

    /** scanner.e:2013					ungetch()*/
    _62ungetch();

    /** scanner.e:2014					return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 6LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15592 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15592;
    goto L1; // [3635] 10
L99: 

    /** scanner.e:2017			elsif class = BANG then*/
    if (_class_27640 != -1LL)
    goto L9B; // [3642] 3690

    /** scanner.e:2018				if getch() = '=' then*/
    _15594 = _62getch();
    if (binary_op_a(NOTEQ, _15594, 61LL)){
        DeRef(_15594);
        _15594 = NOVALUE;
        goto L9C; // [3651] 3670
    }
    DeRef(_15594);
    _15594 = NOVALUE;

    /** scanner.e:2019					return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 4LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15596 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15596;
    goto L1; // [3667] 10
L9C: 

    /** scanner.e:2021					ungetch()*/
    _62ungetch();

    /** scanner.e:2022					return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -1LL;
    ((intptr_t *)_2)[2] = 0LL;
    _15597 = MAKE_SEQ(_1);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15597;
    goto L1; // [3687] 10
L9B: 

    /** scanner.e:2025			elsif class = KEYWORD then*/
    if (_class_27640 != -10LL)
    goto L9D; // [3694] 3727

    /** scanner.e:2026				return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _15599 = _ch_27628 - 128LL;
    _2 = (object)SEQ_PTR(_63keylist_23435);
    _15600 = (object)*(((s1_ptr)_2)->base + _15599);
    _2 = (object)SEQ_PTR(_15600);
    _15601 = (object)*(((s1_ptr)_2)->base + 3LL);
    _15600 = NOVALUE;
    Ref(_15601);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _15601;
    ((intptr_t *)_2)[2] = 0LL;
    _15602 = MAKE_SEQ(_1);
    _15601 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    _15599 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15602;
    goto L1; // [3724] 10
L9D: 

    /** scanner.e:2028			elsif class = BUILTIN then*/
    if (_class_27640 != -9LL)
    goto L9E; // [3731] 3784

    /** scanner.e:2029				name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _15604 = _ch_27628 - 170LL;
    if ((object)((uintptr_t)_15604 +(uintptr_t) HIGH_BITS) >= 0){
        _15604 = NewDouble((eudouble)_15604);
    }
    if (IS_ATOM_INT(_15604)) {
        _15605 = _15604 + 24LL;
    }
    else {
        _15605 = NewDouble(DBL_PTR(_15604)->dbl + (eudouble)24LL);
    }
    DeRef(_15604);
    _15604 = NOVALUE;
    _2 = (object)SEQ_PTR(_63keylist_23435);
    if (!IS_ATOM_INT(_15605)){
        _15606 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_15605)->dbl));
    }
    else{
        _15606 = (object)*(((s1_ptr)_2)->base + _15605);
    }
    DeRef(_name_27641);
    _2 = (object)SEQ_PTR(_15606);
    _name_27641 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_name_27641);
    _15606 = NOVALUE;

    /** scanner.e:2030				return keyfind(name, -1)*/
    RefDS(_name_27641);
    _31980 = _54hashfn(_name_27641);
    RefDS(_name_27641);
    _15608 = _54keyfind(_name_27641, -1LL, _36current_file_no_21759, 0LL, _31980);
    _31980 = NOVALUE;
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRefDS(_name_27641);
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15602);
    _15602 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15599);
    _15599 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15608;
    goto L1; // [3781] 10
L9E: 

    /** scanner.e:2032			elsif class = BACK_QUOTE then*/
    if (_class_27640 != -12LL)
    goto L9F; // [3788] 3805

    /** scanner.e:2033				return ExtendedString( '`' )*/
    _15610 = _62ExtendedString(96LL);
    DeRef(_i_27631);
    DeRef(_yytext_27634);
    DeRef(_namespaces_27635);
    DeRef(_d_27636);
    DeRef(_tok_27638);
    DeRef(_name_27641);
    DeRef(_15608);
    _15608 = NOVALUE;
    DeRef(_15538);
    _15538 = NOVALUE;
    DeRef(_15403);
    _15403 = NOVALUE;
    DeRef(_15547);
    _15547 = NOVALUE;
    _15306 = NOVALUE;
    DeRef(_15586);
    _15586 = NOVALUE;
    DeRef(_15251);
    _15251 = NOVALUE;
    DeRef(_15596);
    _15596 = NOVALUE;
    DeRef(_15494);
    _15494 = NOVALUE;
    DeRef(_15233);
    _15233 = NOVALUE;
    DeRef(_15552);
    _15552 = NOVALUE;
    DeRef(_15411);
    _15411 = NOVALUE;
    DeRef(_15242);
    _15242 = NOVALUE;
    DeRef(_15587);
    _15587 = NOVALUE;
    DeRef(_15477);
    _15477 = NOVALUE;
    DeRef(_15602);
    _15602 = NOVALUE;
    DeRef(_15376);
    _15376 = NOVALUE;
    DeRef(_15254);
    _15254 = NOVALUE;
    _15514 = NOVALUE;
    DeRef(_15354);
    _15354 = NOVALUE;
    DeRef(_15450);
    _15450 = NOVALUE;
    DeRef(_15255);
    _15255 = NOVALUE;
    DeRef(_15305);
    _15305 = NOVALUE;
    _15399 = NOVALUE;
    DeRef(_15478);
    _15478 = NOVALUE;
    DeRef(_15443);
    _15443 = NOVALUE;
    DeRef(_15565);
    _15565 = NOVALUE;
    _15284 = NOVALUE;
    _15270 = NOVALUE;
    DeRef(_15245);
    _15245 = NOVALUE;
    DeRef(_15541);
    _15541 = NOVALUE;
    DeRef(_15445);
    _15445 = NOVALUE;
    _15417 = NOVALUE;
    DeRef(_15482);
    _15482 = NOVALUE;
    _15321 = NOVALUE;
    DeRef(_15548);
    _15548 = NOVALUE;
    DeRef(_15597);
    _15597 = NOVALUE;
    DeRef(_15274);
    _15274 = NOVALUE;
    DeRef(_15279);
    _15279 = NOVALUE;
    DeRef(_15409);
    _15409 = NOVALUE;
    _15374 = NOVALUE;
    DeRef(_15469);
    _15469 = NOVALUE;
    DeRef(_15527);
    _15527 = NOVALUE;
    DeRef(_15258);
    _15258 = NOVALUE;
    _15295 = NOVALUE;
    _15364 = NOVALUE;
    DeRef(_15355);
    _15355 = NOVALUE;
    DeRef(_15452);
    _15452 = NOVALUE;
    DeRef(_15361);
    _15361 = NOVALUE;
    DeRef(_15580);
    _15580 = NOVALUE;
    DeRef(_15501);
    _15501 = NOVALUE;
    DeRef(_15582);
    _15582 = NOVALUE;
    DeRef(_15592);
    _15592 = NOVALUE;
    _15395 = NOVALUE;
    DeRef(_15458);
    _15458 = NOVALUE;
    DeRef(_15459);
    _15459 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    DeRef(_15543);
    _15543 = NOVALUE;
    DeRef(_15433);
    _15433 = NOVALUE;
    DeRef(_15350);
    _15350 = NOVALUE;
    DeRef(_15605);
    _15605 = NOVALUE;
    DeRef(_15435);
    _15435 = NOVALUE;
    DeRef(_15599);
    _15599 = NOVALUE;
    DeRef(_15473);
    _15473 = NOVALUE;
    _15421 = NOVALUE;
    _15488 = NOVALUE;
    DeRef(_15483);
    _15483 = NOVALUE;
    DeRef(_15248);
    _15248 = NOVALUE;
    DeRef(_15591);
    _15591 = NOVALUE;
    DeRef(_15520);
    _15520 = NOVALUE;
    return _15610;
    goto L1; // [3802] 10
L9F: 

    /** scanner.e:2036				InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _class_27640;
    _15611 = MAKE_SEQ(_1);
    _50InternalErr(268LL, _15611);
    _15611 = NOVALUE;

    /** scanner.e:2039	   end while*/
    goto L1; // [3818] 10
L2: 
    ;
}


void _62eu_namespace()
{
    object _eu_tok_28433 = NOVALUE;
    object _eu_ns_28435 = NOVALUE;
    object _31979 = NOVALUE;
    object _31978 = NOVALUE;
    object _15620 = NOVALUE;
    object _15618 = NOVALUE;
    object _15616 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** scanner.e:2047		eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_15614);
    _31978 = _15614;
    _31979 = _54hashfn(_31978);
    _31978 = NOVALUE;
    RefDS(_15614);
    _0 = _eu_tok_28433;
    _eu_tok_28433 = _54keyfind(_15614, -1LL, _36current_file_no_21759, 1LL, _31979);
    DeRef(_0);
    _31979 = NOVALUE;

    /** scanner.e:2050		eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (object)SEQ_PTR(_eu_tok_28433);
    _15616 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_15616);
    _eu_ns_28435 = _62NameSpace_declaration(_15616);
    _15616 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_28435)) {
        _1 = (object)(DBL_PTR(_eu_ns_28435)->dbl);
        DeRefDS(_eu_ns_28435);
        _eu_ns_28435 = _1;
    }

    /** scanner.e:2051		SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28435 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _15618 = NOVALUE;

    /** scanner.e:2052		SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_eu_ns_28435 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 6LL;
    DeRef(_1);
    _15620 = NOVALUE;

    /** scanner.e:2053	end procedure*/
    DeRef(_eu_tok_28433);
    return;
    ;
}


object _62StringToken(object _pDelims_28453)
{
    object _ch_28454 = NOVALUE;
    object _m_28455 = NOVALUE;
    object _gtext_28456 = NOVALUE;
    object _level_28487 = NOVALUE;
    object _15659 = NOVALUE;
    object _15657 = NOVALUE;
    object _15655 = NOVALUE;
    object _15636 = NOVALUE;
    object _15635 = NOVALUE;
    object _15629 = NOVALUE;
    object _15627 = NOVALUE;
    object _15625 = NOVALUE;
    object _15623 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2064		ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2065		while ch = ' ' or ch = '\t' do*/
L1: 
    _15623 = (_ch_28454 == 32LL);
    if (_15623 != 0) {
        goto L2; // [19] 32
    }
    _15625 = (_ch_28454 == 9LL);
    if (_15625 == 0)
    {
        DeRef(_15625);
        _15625 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15625);
        _15625 = NOVALUE;
    }
L2: 

    /** scanner.e:2066			ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2067		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2069		pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32LL;
    ((intptr_t*)_2)[2] = 9LL;
    ((intptr_t*)_2)[3] = 10LL;
    ((intptr_t*)_2)[4] = 13LL;
    ((intptr_t*)_2)[5] = 26LL;
    _15627 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_28453, _pDelims_28453, _15627);
    DeRefDS(_15627);
    _15627 = NOVALUE;

    /** scanner.e:2070		gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_28456);
    _gtext_28456 = _5;

    /** scanner.e:2071		while not find(ch,  pDelims) label "top" do*/
L4: 
    _15629 = find_from(_ch_28454, _pDelims_28453, 1LL);
    if (_15629 != 0)
    goto L5; // [77] 391
    _15629 = NOVALUE;

    /** scanner.e:2072			if ch = '-' then*/
    if (_ch_28454 != 45LL)
    goto L6; // [82] 145

    /** scanner.e:2073				ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2074				if ch = '-' then*/
    if (_ch_28454 != 45LL)
    goto L7; // [95] 137

    /** scanner.e:2075					while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 10LL;
    ((intptr_t *)_2)[2] = 26LL;
    _15635 = MAKE_SEQ(_1);
    _15636 = find_from(_ch_28454, _15635, 1LL);
    DeRefDS(_15635);
    _15635 = NOVALUE;
    if (_15636 != 0)
    goto L5; // [115] 391
    _15636 = NOVALUE;

    /** scanner.e:2076						ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2077					end while*/
    goto L8; // [127] 104

    /** scanner.e:2078					exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** scanner.e:2080					ungetch()*/
    _62ungetch();
    goto L9; // [142] 373
L6: 

    /** scanner.e:2082			elsif ch = '/' then*/
    if (_ch_28454 != 47LL)
    goto LA; // [147] 372

    /** scanner.e:2083				ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2084				if ch = '*' then*/
    if (_ch_28454 != 42LL)
    goto LB; // [160] 361

    /** scanner.e:2085					integer level = 1*/
    _level_28487 = 1LL;

    /** scanner.e:2086					while level > 0 do*/
LC: 
    if (_level_28487 <= 0LL)
    goto LD; // [174] 293

    /** scanner.e:2087						ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2088						if ch = '/' then*/
    if (_ch_28454 != 47LL)
    goto LE; // [187] 221

    /** scanner.e:2089							ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2090							if ch = '*' then*/
    if (_ch_28454 != 42LL)
    goto LF; // [200] 213

    /** scanner.e:2091								level += 1*/
    _level_28487 = _level_28487 + 1;
    goto LC; // [210] 174
LF: 

    /** scanner.e:2093								ungetch()*/
    _62ungetch();
    goto LC; // [218] 174
LE: 

    /** scanner.e:2095						elsif ch = '*' then*/
    if (_ch_28454 != 42LL)
    goto L10; // [223] 257

    /** scanner.e:2096							ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2097							if ch = '/' then*/
    if (_ch_28454 != 47LL)
    goto L11; // [236] 249

    /** scanner.e:2098								level -= 1*/
    _level_28487 = _level_28487 - 1LL;
    goto LC; // [246] 174
L11: 

    /** scanner.e:2100								ungetch()*/
    _62ungetch();
    goto LC; // [254] 174
L10: 

    /** scanner.e:2102						elsif ch = '\n' then*/
    if (_ch_28454 != 10LL)
    goto L12; // [259] 270

    /** scanner.e:2103							read_line()*/
    _62read_line();
    goto LC; // [267] 174
L12: 

    /** scanner.e:2104						elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_28454 != 26LL)
    goto LC; // [274] 174

    /** scanner.e:2105							ungetch()*/
    _62ungetch();

    /** scanner.e:2106							exit*/
    goto LD; // [284] 293

    /** scanner.e:2108					end while*/
    goto LC; // [290] 174
LD: 

    /** scanner.e:2109					ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2110					if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28456)){
            _15655 = SEQ_PTR(_gtext_28456)->length;
    }
    else {
        _15655 = 1;
    }
    if (_15655 != 0LL)
    goto L13; // [305] 350

    /** scanner.e:2111						while ch = ' ' or ch = '\t' do*/
L14: 
    _15657 = (_ch_28454 == 32LL);
    if (_15657 != 0) {
        goto L15; // [318] 331
    }
    _15659 = (_ch_28454 == 9LL);
    if (_15659 == 0)
    {
        DeRef(_15659);
        _15659 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_15659);
        _15659 = NOVALUE;
    }
L15: 

    /** scanner.e:2112							ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2113						end while*/
    goto L14; // [340] 314
L16: 

    /** scanner.e:2114						continue "top"*/
    goto L4; // [347] 72
L13: 

    /** scanner.e:2116					exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** scanner.e:2119					ungetch()*/
    _62ungetch();

    /** scanner.e:2120					ch = '/'*/
    _ch_28454 = 47LL;
L17: 
LA: 
L9: 

    /** scanner.e:2123			gtext &= ch*/
    Append(&_gtext_28456, _gtext_28456, _ch_28454);

    /** scanner.e:2124			ch = getch()*/
    _ch_28454 = _62getch();
    if (!IS_ATOM_INT(_ch_28454)) {
        _1 = (object)(DBL_PTR(_ch_28454)->dbl);
        DeRefDS(_ch_28454);
        _ch_28454 = _1;
    }

    /** scanner.e:2125		end while*/
    goto L4; // [388] 72
L5: 

    /** scanner.e:2127		ungetch() -- put back end-word token.*/
    _62ungetch();

    /** scanner.e:2129		return gtext*/
    DeRefDSi(_pDelims_28453);
    DeRef(_15657);
    _15657 = NOVALUE;
    DeRef(_15623);
    _15623 = NOVALUE;
    return _gtext_28456;
    ;
}


void _62IncludeScan(object _is_public_28524)
{
    object _ch_28525 = NOVALUE;
    object _gtext_28526 = NOVALUE;
    object _s_28528 = NOVALUE;
    object _31977 = NOVALUE;
    object _15723 = NOVALUE;
    object _15722 = NOVALUE;
    object _15720 = NOVALUE;
    object _15718 = NOVALUE;
    object _15717 = NOVALUE;
    object _15712 = NOVALUE;
    object _15709 = NOVALUE;
    object _15707 = NOVALUE;
    object _15706 = NOVALUE;
    object _15704 = NOVALUE;
    object _15702 = NOVALUE;
    object _15700 = NOVALUE;
    object _15698 = NOVALUE;
    object _15692 = NOVALUE;
    object _15690 = NOVALUE;
    object _15684 = NOVALUE;
    object _15680 = NOVALUE;
    object _15679 = NOVALUE;
    object _15674 = NOVALUE;
    object _15671 = NOVALUE;
    object _15670 = NOVALUE;
    object _15666 = NOVALUE;
    object _15664 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2149		ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2150		while ch = ' ' or ch = '\t' do*/
L1: 
    _15664 = (_ch_28525 == 32LL);
    if (_15664 != 0) {
        goto L2; // [19] 32
    }
    _15666 = (_ch_28525 == 9LL);
    if (_15666 == 0)
    {
        DeRef(_15666);
        _15666 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_15666);
        _15666 = NOVALUE;
    }
L2: 

    /** scanner.e:2151			ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2152		end while*/
    goto L1; // [41] 15
L3: 

    /** scanner.e:2155		gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_28526);
    _gtext_28526 = _5;

    /** scanner.e:2157		if ch = '"' then*/
    if (_ch_28525 != 34LL)
    goto L4; // [53] 143

    /** scanner.e:2159			ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2160			while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 34LL;
    ((intptr_t*)_2)[4] = 26LL;
    _15670 = MAKE_SEQ(_1);
    _15671 = find_from(_ch_28525, _15670, 1LL);
    DeRefDS(_15670);
    _15670 = NOVALUE;
    if (_15671 != 0)
    goto L6; // [83] 124
    _15671 = NOVALUE;

    /** scanner.e:2161				if ch = '\\' then*/
    if (_ch_28525 != 92LL)
    goto L7; // [88] 105

    /** scanner.e:2162					gtext &= EscapeChar('"')*/
    _15674 = _62EscapeChar(34LL);
    if (IS_SEQUENCE(_gtext_28526) && IS_ATOM(_15674)) {
        Ref(_15674);
        Append(&_gtext_28526, _gtext_28526, _15674);
    }
    else if (IS_ATOM(_gtext_28526) && IS_SEQUENCE(_15674)) {
    }
    else {
        Concat((object_ptr)&_gtext_28526, _gtext_28526, _15674);
    }
    DeRef(_15674);
    _15674 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** scanner.e:2164					gtext &= ch*/
    Append(&_gtext_28526, _gtext_28526, _ch_28525);
L8: 

    /** scanner.e:2166				ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2167			end while*/
    goto L5; // [121] 69
L6: 

    /** scanner.e:2168			if ch != '"' then*/
    if (_ch_28525 == 34LL)
    goto L9; // [126] 189

    /** scanner.e:2169				CompileErr(MISSING_CLOSING_QUOTE_ON_FILE_NAME)*/
    RefDS(_22186);
    _50CompileErr(115LL, _22186, 0LL);
    goto L9; // [140] 189
L4: 

    /** scanner.e:2173			while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 32LL;
    ((intptr_t*)_2)[2] = 9LL;
    ((intptr_t*)_2)[3] = 10LL;
    ((intptr_t*)_2)[4] = 13LL;
    ((intptr_t*)_2)[5] = 26LL;
    _15679 = MAKE_SEQ(_1);
    _15680 = find_from(_ch_28525, _15679, 1LL);
    DeRefDS(_15679);
    _15679 = NOVALUE;
    if (_15680 != 0)
    goto LB; // [163] 184
    _15680 = NOVALUE;

    /** scanner.e:2174				gtext &= ch*/
    Append(&_gtext_28526, _gtext_28526, _ch_28525);

    /** scanner.e:2175				ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2176			end while*/
    goto LA; // [181] 148
LB: 

    /** scanner.e:2177			ungetch()*/
    _62ungetch();
L9: 

    /** scanner.e:2180		if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_28526)){
            _15684 = SEQ_PTR(_gtext_28526)->length;
    }
    else {
        _15684 = 1;
    }
    if (_15684 != 0LL)
    goto LC; // [194] 208

    /** scanner.e:2181			CompileErr(FILE_NAME_IS_MISSING)*/
    RefDS(_22186);
    _50CompileErr(95LL, _22186, 0LL);
LC: 

    /** scanner.e:2185		ifdef WINDOWS then*/

    /** scanner.e:2186			new_include_name = match_replace(`/`, gtext, `\`)*/
    RefDS(_15686);
    RefDS(_gtext_28526);
    RefDS(_15687);
    _0 = _16match_replace(_15686, _gtext_28526, _15687, 0LL);
    DeRef(_36new_include_name_21885);
    _36new_include_name_21885 = _0;

    /** scanner.e:2192		ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2193		while ch = ' ' or ch = '\t' do*/
LD: 
    _15690 = (_ch_28525 == 32LL);
    if (_15690 != 0) {
        goto LE; // [237] 250
    }
    _15692 = (_ch_28525 == 9LL);
    if (_15692 == 0)
    {
        DeRef(_15692);
        _15692 = NOVALUE;
        goto LF; // [246] 262
    }
    else{
        DeRef(_15692);
        _15692 = NOVALUE;
    }
LE: 

    /** scanner.e:2194			ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2195		end while*/
    goto LD; // [259] 233
LF: 

    /** scanner.e:2197		new_include_space = 0*/
    _62new_include_space_25865 = 0LL;

    /** scanner.e:2199		if ch = 'a' then*/
    if (_ch_28525 != 97LL)
    goto L10; // [271] 536

    /** scanner.e:2201			ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2202			if ch = 's' then*/
    if (_ch_28525 != 115LL)
    goto L11; // [284] 523

    /** scanner.e:2203				ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2204				if ch = ' ' or ch = '\t' then*/
    _15698 = (_ch_28525 == 32LL);
    if (_15698 != 0) {
        goto L12; // [301] 314
    }
    _15700 = (_ch_28525 == 9LL);
    if (_15700 == 0)
    {
        DeRef(_15700);
        _15700 = NOVALUE;
        goto L13; // [310] 510
    }
    else{
        DeRef(_15700);
        _15700 = NOVALUE;
    }
L12: 

    /** scanner.e:2207					ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2208					while ch = ' ' or ch = '\t' do*/
L14: 
    _15702 = (_ch_28525 == 32LL);
    if (_15702 != 0) {
        goto L15; // [330] 343
    }
    _15704 = (_ch_28525 == 9LL);
    if (_15704 == 0)
    {
        DeRef(_15704);
        _15704 = NOVALUE;
        goto L16; // [339] 355
    }
    else{
        DeRef(_15704);
        _15704 = NOVALUE;
    }
L15: 

    /** scanner.e:2209						ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2210					end while*/
    goto L14; // [352] 326
L16: 

    /** scanner.e:2213					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (object)SEQ_PTR(_62char_class_25874);
    _15706 = (object)*(((s1_ptr)_2)->base + _ch_28525);
    _15707 = (_15706 == -2LL);
    _15706 = NOVALUE;
    if (_15707 != 0) {
        goto L17; // [369] 382
    }
    _15709 = (_ch_28525 == 95LL);
    if (_15709 == 0)
    {
        DeRef(_15709);
        _15709 = NOVALUE;
        goto L18; // [378] 497
    }
    else{
        DeRef(_15709);
        _15709 = NOVALUE;
    }
L17: 

    /** scanner.e:2214						gtext = {ch}*/
    _0 = _gtext_28526;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _ch_28525;
    _gtext_28526 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scanner.e:2215						ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2216						while id_char[ch] = TRUE do*/
L19: 
    _2 = (object)SEQ_PTR(_62id_char_25875);
    _15712 = (object)*(((s1_ptr)_2)->base + _ch_28525);
    if (_15712 != _13TRUE_447)
    goto L1A; // [408] 430

    /** scanner.e:2217							gtext &= ch*/
    Append(&_gtext_28526, _gtext_28526, _ch_28525);

    /** scanner.e:2218							ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2219						end while*/
    goto L19; // [427] 400
L1A: 

    /** scanner.e:2221						ungetch()*/
    _62ungetch();

    /** scanner.e:2222						s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_28526);
    _31977 = _54hashfn(_gtext_28526);
    RefDS(_gtext_28526);
    _0 = _s_28528;
    _s_28528 = _54keyfind(_gtext_28526, -1LL, _36current_file_no_21759, 1LL, _31977);
    DeRef(_0);
    _31977 = NOVALUE;

    /** scanner.e:2223						if not find(s[T_ID], ID_TOKS) then*/
    _2 = (object)SEQ_PTR(_s_28528);
    _15717 = (object)*(((s1_ptr)_2)->base + 1LL);
    _15718 = find_from(_15717, _38ID_TOKS_16297, 1LL);
    _15717 = NOVALUE;
    if (_15718 != 0)
    goto L1B; // [467] 480
    _15718 = NOVALUE;

    /** scanner.e:2224							CompileErr(A_NEW_NAMESPACE_IDENTIFIER_IS_EXPECTED_HERE)*/
    RefDS(_22186);
    _50CompileErr(36LL, _22186, 0LL);
L1B: 

    /** scanner.e:2226						new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (object)SEQ_PTR(_s_28528);
    _15720 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_15720);
    _0 = _62NameSpace_declaration(_15720);
    _62new_include_space_25865 = _0;
    _15720 = NOVALUE;
    if (!IS_ATOM_INT(_62new_include_space_25865)) {
        _1 = (object)(DBL_PTR(_62new_include_space_25865)->dbl);
        DeRefDS(_62new_include_space_25865);
        _62new_include_space_25865 = _1;
    }
    goto L1C; // [494] 651
L18: 

    /** scanner.e:2228						CompileErr(MISSING_NAMESPACE_QUALIFIER)*/
    RefDS(_22186);
    _50CompileErr(113LL, _22186, 0LL);
    goto L1C; // [507] 651
L13: 

    /** scanner.e:2231					CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22186);
    _50CompileErr(100LL, _22186, 0LL);
    goto L1C; // [520] 651
L11: 

    /** scanner.e:2234				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22186);
    _50CompileErr(100LL, _22186, 0LL);
    goto L1C; // [533] 651
L10: 

    /** scanner.e:2237		elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 10LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 26LL;
    _15722 = MAKE_SEQ(_1);
    _15723 = find_from(_ch_28525, _15722, 1LL);
    DeRefDS(_15722);
    _15722 = NOVALUE;
    if (_15723 == 0)
    {
        _15723 = NOVALUE;
        goto L1D; // [551] 561
    }
    else{
        _15723 = NOVALUE;
    }

    /** scanner.e:2238			ungetch()*/
    _62ungetch();
    goto L1C; // [558] 651
L1D: 

    /** scanner.e:2240		elsif ch = '-' then*/
    if (_ch_28525 != 45LL)
    goto L1E; // [563] 601

    /** scanner.e:2241			ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2242			if ch != '-' then*/
    if (_ch_28525 == 45LL)
    goto L1F; // [576] 590

    /** scanner.e:2243				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22186);
    _50CompileErr(100LL, _22186, 0LL);
L1F: 

    /** scanner.e:2245			ungetch()*/
    _62ungetch();

    /** scanner.e:2246			ungetch()*/
    _62ungetch();
    goto L1C; // [598] 651
L1E: 

    /** scanner.e:2248		elsif ch = '/' then*/
    if (_ch_28525 != 47LL)
    goto L20; // [603] 641

    /** scanner.e:2249			ch = getch()*/
    _ch_28525 = _62getch();
    if (!IS_ATOM_INT(_ch_28525)) {
        _1 = (object)(DBL_PTR(_ch_28525)->dbl);
        DeRefDS(_ch_28525);
        _ch_28525 = _1;
    }

    /** scanner.e:2250			if ch != '*' then*/
    if (_ch_28525 == 42LL)
    goto L21; // [616] 630

    /** scanner.e:2251				CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22186);
    _50CompileErr(100LL, _22186, 0LL);
L21: 

    /** scanner.e:2253			ungetch()*/
    _62ungetch();

    /** scanner.e:2254			ungetch()*/
    _62ungetch();
    goto L1C; // [638] 651
L20: 

    /** scanner.e:2257			CompileErr(EXPECTING_AS_OR_ENDOF_LINE_UNEXPECTED_TEXT_ON_INCLUDE_DIRECTIVE)*/
    RefDS(_22186);
    _50CompileErr(100LL, _22186, 0LL);
L1C: 

    /** scanner.e:2260		start_include = TRUE -- let scanner know*/
    _62start_include_25867 = _13TRUE_447;

    /** scanner.e:2261		public_include = is_public*/
    _62public_include_25870 = _is_public_28524;

    /** scanner.e:2262	end procedure*/
    DeRef(_gtext_28526);
    DeRef(_s_28528);
    DeRef(_15664);
    _15664 = NOVALUE;
    DeRef(_15702);
    _15702 = NOVALUE;
    DeRef(_15698);
    _15698 = NOVALUE;
    DeRef(_15707);
    _15707 = NOVALUE;
    _15712 = NOVALUE;
    DeRef(_15690);
    _15690 = NOVALUE;
    return;
    ;
}


void _62main_file()
{
    object _15732 = NOVALUE;
    object _15731 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2275		if repl and top_level_block = -1 then*/
    if (0LL == 0) {
        goto L1; // [5] 29
    }
    _15732 = (_65top_level_block_25435 == -1LL);
    if (_15732 == 0)
    {
        DeRef(_15732);
        _15732 = NOVALUE;
        goto L1; // [16] 29
    }
    else{
        DeRef(_15732);
        _15732 = NOVALUE;
    }

    /** scanner.e:2276			top_level_block = current_block*/
    _65top_level_block_25435 = _65current_block_25434;
L1: 

    /** scanner.e:2278		ifdef STDDEBUG then*/

    /** scanner.e:2283			read_line()*/
    _62read_line();

    /** scanner.e:2284			default_namespace( )*/
    _62default_namespace();

    /** scanner.e:2286	end procedure*/
    return;
    ;
}


void _62cleanup_open_includes()
{
    object _15735 = NOVALUE;
    object _15734 = NOVALUE;
    object _15733 = NOVALUE;
    object _0, _1, _2;
    

    /** scanner.e:2289		for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_62IncludeStk_25876)){
            _15733 = SEQ_PTR(_62IncludeStk_25876)->length;
    }
    else {
        _15733 = 1;
    }
    {
        object _i_28665;
        _i_28665 = 1LL;
L1: 
        if (_i_28665 > _15733){
            goto L2; // [8] 36
        }

        /** scanner.e:2290			close( IncludeStk[i][FILE_PTR] )*/
        _2 = (object)SEQ_PTR(_62IncludeStk_25876);
        _15734 = (object)*(((s1_ptr)_2)->base + _i_28665);
        _2 = (object)SEQ_PTR(_15734);
        _15735 = (object)*(((s1_ptr)_2)->base + 3LL);
        _15734 = NOVALUE;
        if (IS_ATOM_INT(_15735))
        EClose(_15735);
        else
        EClose((object)DBL_PTR(_15735)->dbl);
        _15735 = NOVALUE;

        /** scanner.e:2291		end for*/
        _i_28665 = _i_28665 + 1LL;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** scanner.e:2292	end procedure*/
    return;
    ;
}



// 0xA2A3B15A
