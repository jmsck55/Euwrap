// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _28reverse(object _s_10362)
{
    object _lower_10363 = NOVALUE;
    object _n_10364 = NOVALUE;
    object _n2_10365 = NOVALUE;
    object _t_10366 = NOVALUE;
    object _5782 = NOVALUE;
    object _5781 = NOVALUE;
    object _5780 = NOVALUE;
    object _5777 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:87		n = length(s)*/
    if (IS_SEQUENCE(_s_10362)){
            _n_10364 = SEQ_PTR(_s_10362)->length;
    }
    else {
        _n_10364 = 1;
    }

    /** scinot.e:88		n2 = floor(n/2)+1*/
    _5777 = _n_10364 >> 1;
    _n2_10365 = _5777 + 1;
    _5777 = NOVALUE;

    /** scinot.e:89		t = repeat(0, n)*/
    DeRef(_t_10366);
    _t_10366 = Repeat(0LL, _n_10364);

    /** scinot.e:90		lower = 1*/
    _lower_10363 = 1LL;

    /** scinot.e:91		for upper = n to n2 by -1 do*/
    _5780 = _n2_10365;
    {
        object _upper_10372;
        _upper_10372 = _n_10364;
L1: 
        if (_upper_10372 < _5780){
            goto L2; // [34] 74
        }

        /** scinot.e:92			t[upper] = s[lower]*/
        _2 = (object)SEQ_PTR(_s_10362);
        _5781 = (object)*(((s1_ptr)_2)->base + _lower_10363);
        Ref(_5781);
        _2 = (object)SEQ_PTR(_t_10366);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_10366 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _upper_10372);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5781;
        if( _1 != _5781 ){
            DeRef(_1);
        }
        _5781 = NOVALUE;

        /** scinot.e:93			t[lower] = s[upper]*/
        _2 = (object)SEQ_PTR(_s_10362);
        _5782 = (object)*(((s1_ptr)_2)->base + _upper_10372);
        Ref(_5782);
        _2 = (object)SEQ_PTR(_t_10366);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _t_10366 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _lower_10363);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5782;
        if( _1 != _5782 ){
            DeRef(_1);
        }
        _5782 = NOVALUE;

        /** scinot.e:94			lower += 1*/
        _lower_10363 = _lower_10363 + 1;

        /** scinot.e:95		end for*/
        _upper_10372 = _upper_10372 + -1LL;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** scinot.e:96		return t*/
    DeRefDS(_s_10362);
    return _t_10366;
    ;
}


object _28carry(object _a_10379, object _radix_10380)
{
    object _q_10381 = NOVALUE;
    object _r_10382 = NOVALUE;
    object _b_10383 = NOVALUE;
    object _rmax_10384 = NOVALUE;
    object _i_10385 = NOVALUE;
    object _5796 = NOVALUE;
    object _5795 = NOVALUE;
    object _5794 = NOVALUE;
    object _5791 = NOVALUE;
    object _5785 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:102		rmax = radix - 1*/
    DeRef(_rmax_10384);
    _rmax_10384 = _radix_10380 - 1LL;
    if ((object)((uintptr_t)_rmax_10384 +(uintptr_t) HIGH_BITS) >= 0){
        _rmax_10384 = NewDouble((eudouble)_rmax_10384);
    }

    /** scinot.e:103		i = 1*/
    DeRef(_i_10385);
    _i_10385 = 1LL;

    /** scinot.e:104		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_10379)){
            _5785 = SEQ_PTR(_a_10379)->length;
    }
    else {
        _5785 = 1;
    }
    if (binary_op_a(GREATER, _i_10385, _5785)){
        _5785 = NOVALUE;
        goto L2; // [24] 104
    }
    _5785 = NOVALUE;

    /** scinot.e:105			b = a[i]*/
    DeRef(_b_10383);
    _2 = (object)SEQ_PTR(_a_10379);
    if (!IS_ATOM_INT(_i_10385)){
        _b_10383 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_10385)->dbl));
    }
    else{
        _b_10383 = (object)*(((s1_ptr)_2)->base + _i_10385);
    }
    Ref(_b_10383);

    /** scinot.e:106			if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_10383, _rmax_10384)){
        goto L3; // [36] 93
    }

    /** scinot.e:107				q = floor( b / radix )*/
    DeRef(_q_10381);
    if (IS_ATOM_INT(_b_10383)) {
        if (_radix_10380 > 0 && _b_10383 >= 0) {
            _q_10381 = _b_10383 / _radix_10380;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_b_10383 / (eudouble)_radix_10380);
            if (_b_10383 != MININT)
            _q_10381 = (object)temp_dbl;
            else
            _q_10381 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_10383, _radix_10380);
        _q_10381 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** scinot.e:108				r = remainder( b, radix )*/
    DeRef(_r_10382);
    if (IS_ATOM_INT(_b_10383)) {
        _r_10382 = (_b_10383 % _radix_10380);
    }
    else {
        temp_d.dbl = (eudouble)_radix_10380;
        _r_10382 = Dremainder(DBL_PTR(_b_10383), &temp_d);
    }

    /** scinot.e:109				a[i] = r*/
    Ref(_r_10382);
    _2 = (object)SEQ_PTR(_a_10379);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_10379 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_10385))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_i_10385)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _i_10385);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _r_10382;
    DeRef(_1);

    /** scinot.e:110				if i = length(a) then*/
    if (IS_SEQUENCE(_a_10379)){
            _5791 = SEQ_PTR(_a_10379)->length;
    }
    else {
        _5791 = 1;
    }
    if (binary_op_a(NOTEQ, _i_10385, _5791)){
        _5791 = NOVALUE;
        goto L4; // [63] 74
    }
    _5791 = NOVALUE;

    /** scinot.e:111					a &= 0*/
    Append(&_a_10379, _a_10379, 0LL);
L4: 

    /** scinot.e:113				a[i+1] += q*/
    if (IS_ATOM_INT(_i_10385)) {
        _5794 = _i_10385 + 1;
    }
    else
    _5794 = binary_op(PLUS, 1, _i_10385);
    _2 = (object)SEQ_PTR(_a_10379);
    if (!IS_ATOM_INT(_5794)){
        _5795 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_5794)->dbl));
    }
    else{
        _5795 = (object)*(((s1_ptr)_2)->base + _5794);
    }
    if (IS_ATOM_INT(_5795) && IS_ATOM_INT(_q_10381)) {
        _5796 = _5795 + _q_10381;
        if ((object)((uintptr_t)_5796 + (uintptr_t)HIGH_BITS) >= 0){
            _5796 = NewDouble((eudouble)_5796);
        }
    }
    else {
        _5796 = binary_op(PLUS, _5795, _q_10381);
    }
    _5795 = NOVALUE;
    _2 = (object)SEQ_PTR(_a_10379);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _a_10379 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5794))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_5794)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _5794);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5796;
    if( _1 != _5796 ){
        DeRef(_1);
    }
    _5796 = NOVALUE;
L3: 

    /** scinot.e:115			i += 1*/
    _0 = _i_10385;
    if (IS_ATOM_INT(_i_10385)) {
        _i_10385 = _i_10385 + 1;
        if (_i_10385 > MAXINT){
            _i_10385 = NewDouble((eudouble)_i_10385);
        }
    }
    else
    _i_10385 = binary_op(PLUS, 1, _i_10385);
    DeRef(_0);

    /** scinot.e:116		end while*/
    goto L1; // [101] 21
L2: 

    /** scinot.e:118		return a*/
    DeRef(_q_10381);
    DeRef(_r_10382);
    DeRef(_b_10383);
    DeRef(_rmax_10384);
    DeRef(_i_10385);
    DeRef(_5794);
    _5794 = NOVALUE;
    return _a_10379;
    ;
}


object _28add(object _a_10405, object _b_10406)
{
    object _5814 = NOVALUE;
    object _5812 = NOVALUE;
    object _5811 = NOVALUE;
    object _5810 = NOVALUE;
    object _5809 = NOVALUE;
    object _5807 = NOVALUE;
    object _5806 = NOVALUE;
    object _5804 = NOVALUE;
    object _5803 = NOVALUE;
    object _5802 = NOVALUE;
    object _5801 = NOVALUE;
    object _5799 = NOVALUE;
    object _5798 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:123		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_10405)){
            _5798 = SEQ_PTR(_a_10405)->length;
    }
    else {
        _5798 = 1;
    }
    if (IS_SEQUENCE(_b_10406)){
            _5799 = SEQ_PTR(_b_10406)->length;
    }
    else {
        _5799 = 1;
    }
    if (_5798 >= _5799)
    goto L1; // [13] 40

    /** scinot.e:124			a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_10406)){
            _5801 = SEQ_PTR(_b_10406)->length;
    }
    else {
        _5801 = 1;
    }
    if (IS_SEQUENCE(_a_10405)){
            _5802 = SEQ_PTR(_a_10405)->length;
    }
    else {
        _5802 = 1;
    }
    _5803 = _5801 - _5802;
    _5801 = NOVALUE;
    _5802 = NOVALUE;
    _5804 = Repeat(0LL, _5803);
    _5803 = NOVALUE;
    Concat((object_ptr)&_a_10405, _a_10405, _5804);
    DeRefDS(_5804);
    _5804 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** scinot.e:125		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_10406)){
            _5806 = SEQ_PTR(_b_10406)->length;
    }
    else {
        _5806 = 1;
    }
    if (IS_SEQUENCE(_a_10405)){
            _5807 = SEQ_PTR(_a_10405)->length;
    }
    else {
        _5807 = 1;
    }
    if (_5806 >= _5807)
    goto L3; // [48] 73

    /** scinot.e:126			b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_10405)){
            _5809 = SEQ_PTR(_a_10405)->length;
    }
    else {
        _5809 = 1;
    }
    if (IS_SEQUENCE(_b_10406)){
            _5810 = SEQ_PTR(_b_10406)->length;
    }
    else {
        _5810 = 1;
    }
    _5811 = _5809 - _5810;
    _5809 = NOVALUE;
    _5810 = NOVALUE;
    _5812 = Repeat(0LL, _5811);
    _5811 = NOVALUE;
    Concat((object_ptr)&_b_10406, _b_10406, _5812);
    DeRefDS(_5812);
    _5812 = NOVALUE;
L3: 
L2: 

    /** scinot.e:129		return a + b*/
    _5814 = binary_op(PLUS, _a_10405, _b_10406);
    DeRefDS(_a_10405);
    DeRefDS(_b_10406);
    return _5814;
    ;
}


object _28borrow(object _a_10428, object _radix_10429)
{
    object _5822 = NOVALUE;
    object _5821 = NOVALUE;
    object _5820 = NOVALUE;
    object _5819 = NOVALUE;
    object _5818 = NOVALUE;
    object _5816 = NOVALUE;
    object _5815 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:134		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_10428)){
            _5815 = SEQ_PTR(_a_10428)->length;
    }
    else {
        _5815 = 1;
    }
    {
        object _i_10431;
        _i_10431 = _5815;
L1: 
        if (_i_10431 < 2LL){
            goto L2; // [10] 67
        }

        /** scinot.e:135			if a[i] < 0 then*/
        _2 = (object)SEQ_PTR(_a_10428);
        _5816 = (object)*(((s1_ptr)_2)->base + _i_10431);
        if (binary_op_a(GREATEREQ, _5816, 0LL)){
            _5816 = NOVALUE;
            goto L3; // [23] 60
        }
        _5816 = NOVALUE;

        /** scinot.e:136				a[i] += radix*/
        _2 = (object)SEQ_PTR(_a_10428);
        _5818 = (object)*(((s1_ptr)_2)->base + _i_10431);
        if (IS_ATOM_INT(_5818)) {
            _5819 = _5818 + _radix_10429;
            if ((object)((uintptr_t)_5819 + (uintptr_t)HIGH_BITS) >= 0){
                _5819 = NewDouble((eudouble)_5819);
            }
        }
        else {
            _5819 = binary_op(PLUS, _5818, _radix_10429);
        }
        _5818 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_10428);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_10428 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10431);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5819;
        if( _1 != _5819 ){
            DeRef(_1);
        }
        _5819 = NOVALUE;

        /** scinot.e:137				a[i-1] -= 1*/
        _5820 = _i_10431 - 1LL;
        _2 = (object)SEQ_PTR(_a_10428);
        _5821 = (object)*(((s1_ptr)_2)->base + _5820);
        if (IS_ATOM_INT(_5821)) {
            _5822 = _5821 - 1LL;
            if ((object)((uintptr_t)_5822 +(uintptr_t) HIGH_BITS) >= 0){
                _5822 = NewDouble((eudouble)_5822);
            }
        }
        else {
            _5822 = binary_op(MINUS, _5821, 1LL);
        }
        _5821 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_10428);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_10428 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _5820);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5822;
        if( _1 != _5822 ){
            DeRef(_1);
        }
        _5822 = NOVALUE;
L3: 

        /** scinot.e:139		end for*/
        _i_10431 = _i_10431 + -1LL;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** scinot.e:140		return a*/
    DeRef(_5820);
    _5820 = NOVALUE;
    return _a_10428;
    ;
}


object _28bits_to_bytes(object _bits_10443)
{
    object _bytes_10444 = NOVALUE;
    object _r_10445 = NOVALUE;
    object _5831 = NOVALUE;
    object _5830 = NOVALUE;
    object _5829 = NOVALUE;
    object _5828 = NOVALUE;
    object _5826 = NOVALUE;
    object _5825 = NOVALUE;
    object _5823 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:155		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_10443)){
            _5823 = SEQ_PTR(_bits_10443)->length;
    }
    else {
        _5823 = 1;
    }
    _r_10445 = (_5823 % 8LL);
    _5823 = NOVALUE;

    /** scinot.e:156		if r  then*/
    if (_r_10445 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** scinot.e:157			bits &= repeat( 0, 8 - r )*/
    _5825 = 8LL - _r_10445;
    _5826 = Repeat(0LL, _5825);
    _5825 = NOVALUE;
    Concat((object_ptr)&_bits_10443, _bits_10443, _5826);
    DeRefDS(_5826);
    _5826 = NOVALUE;
L1: 

    /** scinot.e:160		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_10444);
    _bytes_10444 = _5;

    /** scinot.e:161		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_10443)){
            _5828 = SEQ_PTR(_bits_10443)->length;
    }
    else {
        _5828 = 1;
    }
    {
        object _i_10453;
        _i_10453 = 1LL;
L2: 
        if (_i_10453 > _5828){
            goto L3; // [44] 77
        }

        /** scinot.e:162			bytes &= bits_to_int( bits[i..i+7] )*/
        _5829 = _i_10453 + 7LL;
        rhs_slice_target = (object_ptr)&_5830;
        RHS_Slice(_bits_10443, _i_10453, _5829);
        _5831 = _15bits_to_int(_5830);
        _5830 = NOVALUE;
        if (IS_SEQUENCE(_bytes_10444) && IS_ATOM(_5831)) {
            Ref(_5831);
            Append(&_bytes_10444, _bytes_10444, _5831);
        }
        else if (IS_ATOM(_bytes_10444) && IS_SEQUENCE(_5831)) {
        }
        else {
            Concat((object_ptr)&_bytes_10444, _bytes_10444, _5831);
        }
        DeRef(_5831);
        _5831 = NOVALUE;

        /** scinot.e:163		end for*/
        _i_10453 = _i_10453 + 8LL;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** scinot.e:164		return bytes*/
    DeRefDS(_bits_10443);
    DeRef(_5829);
    _5829 = NOVALUE;
    return _bytes_10444;
    ;
}


object _28bytes_to_bits(object _bytes_10462)
{
    object _bits_10463 = NOVALUE;
    object _5835 = NOVALUE;
    object _5834 = NOVALUE;
    object _5833 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:179		bits = {}*/
    RefDS(_5);
    DeRef(_bits_10463);
    _bits_10463 = _5;

    /** scinot.e:180		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_10462)){
            _5833 = SEQ_PTR(_bytes_10462)->length;
    }
    else {
        _5833 = 1;
    }
    {
        object _i_10465;
        _i_10465 = 1LL;
L1: 
        if (_i_10465 > _5833){
            goto L2; // [15] 44
        }

        /** scinot.e:181			bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (object)SEQ_PTR(_bytes_10462);
        _5834 = (object)*(((s1_ptr)_2)->base + _i_10465);
        Ref(_5834);
        _5835 = _15int_to_bits(_5834, 8LL);
        _5834 = NOVALUE;
        if (IS_SEQUENCE(_bits_10463) && IS_ATOM(_5835)) {
            Ref(_5835);
            Append(&_bits_10463, _bits_10463, _5835);
        }
        else if (IS_ATOM(_bits_10463) && IS_SEQUENCE(_5835)) {
        }
        else {
            Concat((object_ptr)&_bits_10463, _bits_10463, _5835);
        }
        DeRef(_5835);
        _5835 = NOVALUE;

        /** scinot.e:182		end for*/
        _i_10465 = _i_10465 + 1LL;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** scinot.e:184		return bits*/
    DeRefDS(_bytes_10462);
    return _bits_10463;
    ;
}


object _28convert_radix(object _number_10473, object _from_radix_10474, object _to_radix_10475)
{
    object _target_10476 = NOVALUE;
    object _base_10477 = NOVALUE;
    object _5842 = NOVALUE;
    object _5841 = NOVALUE;
    object _5840 = NOVALUE;
    object _5839 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:190		base = {1}*/
    RefDS(_5837);
    DeRef(_base_10477);
    _base_10477 = _5837;

    /** scinot.e:191		target = {0}*/
    _0 = _target_10476;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    _target_10476 = MAKE_SEQ(_1);
    DeRef(_0);

    /** scinot.e:192		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_10473)){
            _5839 = SEQ_PTR(_number_10473)->length;
    }
    else {
        _5839 = 1;
    }
    {
        object _i_10481;
        _i_10481 = 1LL;
L1: 
        if (_i_10481 > _5839){
            goto L2; // [25] 78
        }

        /** scinot.e:193			target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (object)SEQ_PTR(_number_10473);
        _5840 = (object)*(((s1_ptr)_2)->base + _i_10481);
        _5841 = binary_op(MULTIPLY, _base_10477, _5840);
        _5840 = NOVALUE;
        RefDS(_target_10476);
        _5842 = _28add(_5841, _target_10476);
        _5841 = NOVALUE;
        _0 = _target_10476;
        _target_10476 = _28carry(_5842, _to_radix_10475);
        DeRefDS(_0);
        _5842 = NOVALUE;

        /** scinot.e:194			base *= from_radix*/
        _0 = _base_10477;
        _base_10477 = binary_op(MULTIPLY, _base_10477, _from_radix_10474);
        DeRefDS(_0);

        /** scinot.e:195			base = carry( base, to_radix )*/
        RefDS(_base_10477);
        _0 = _base_10477;
        _base_10477 = _28carry(_base_10477, _to_radix_10475);
        DeRefDS(_0);

        /** scinot.e:196		end for*/
        _i_10481 = _i_10481 + 1LL;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** scinot.e:198		return target*/
    DeRefDS(_number_10473);
    DeRef(_base_10477);
    return _target_10476;
    ;
}


object _28half(object _decimal_10491)
{
    object _quotient_10492 = NOVALUE;
    object _q_10493 = NOVALUE;
    object _Q_10494 = NOVALUE;
    object _5863 = NOVALUE;
    object _5862 = NOVALUE;
    object _5861 = NOVALUE;
    object _5860 = NOVALUE;
    object _5859 = NOVALUE;
    object _5858 = NOVALUE;
    object _5855 = NOVALUE;
    object _5853 = NOVALUE;
    object _5852 = NOVALUE;
    object _5849 = NOVALUE;
    object _5848 = NOVALUE;
    object _5846 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:205		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_10491)){
            _5846 = SEQ_PTR(_decimal_10491)->length;
    }
    else {
        _5846 = 1;
    }
    DeRef(_quotient_10492);
    _quotient_10492 = Repeat(0LL, _5846);
    _5846 = NOVALUE;

    /** scinot.e:206		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_10491)){
            _5848 = SEQ_PTR(_decimal_10491)->length;
    }
    else {
        _5848 = 1;
    }
    {
        object _i_10498;
        _i_10498 = 1LL;
L1: 
        if (_i_10498 > _5848){
            goto L2; // [17] 101
        }

        /** scinot.e:207			q = decimal[i] / 2*/
        _2 = (object)SEQ_PTR(_decimal_10491);
        _5849 = (object)*(((s1_ptr)_2)->base + _i_10498);
        DeRef(_q_10493);
        if (IS_ATOM_INT(_5849)) {
            if (_5849 & 1) {
                _q_10493 = NewDouble((_5849 >> 1) + 0.5);
            }
            else
            _q_10493 = _5849 >> 1;
        }
        else {
            _q_10493 = binary_op(DIVIDE, _5849, 2);
        }
        _5849 = NOVALUE;

        /** scinot.e:208			Q = floor( q )*/
        DeRef(_Q_10494);
        if (IS_ATOM_INT(_q_10493))
        _Q_10494 = e_floor(_q_10493);
        else
        _Q_10494 = unary_op(FLOOR, _q_10493);

        /** scinot.e:209			quotient[i] +=  Q*/
        _2 = (object)SEQ_PTR(_quotient_10492);
        _5852 = (object)*(((s1_ptr)_2)->base + _i_10498);
        if (IS_ATOM_INT(_5852) && IS_ATOM_INT(_Q_10494)) {
            _5853 = _5852 + _Q_10494;
            if ((object)((uintptr_t)_5853 + (uintptr_t)HIGH_BITS) >= 0){
                _5853 = NewDouble((eudouble)_5853);
            }
        }
        else {
            _5853 = binary_op(PLUS, _5852, _Q_10494);
        }
        _5852 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_10492);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_10492 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_10498);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5853;
        if( _1 != _5853 ){
            DeRef(_1);
        }
        _5853 = NOVALUE;

        /** scinot.e:211			if q != Q then*/
        if (binary_op_a(EQUALS, _q_10493, _Q_10494)){
            goto L3; // [55] 94
        }

        /** scinot.e:212				if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_10492)){
                _5855 = SEQ_PTR(_quotient_10492)->length;
        }
        else {
            _5855 = 1;
        }
        if (_5855 != _i_10498)
        goto L4; // [64] 75

        /** scinot.e:213					quotient &= 0*/
        Append(&_quotient_10492, _quotient_10492, 0LL);
L4: 

        /** scinot.e:215				quotient[i+1] += 5*/
        _5858 = _i_10498 + 1;
        _2 = (object)SEQ_PTR(_quotient_10492);
        _5859 = (object)*(((s1_ptr)_2)->base + _5858);
        if (IS_ATOM_INT(_5859)) {
            _5860 = _5859 + 5LL;
            if ((object)((uintptr_t)_5860 + (uintptr_t)HIGH_BITS) >= 0){
                _5860 = NewDouble((eudouble)_5860);
            }
        }
        else {
            _5860 = binary_op(PLUS, _5859, 5LL);
        }
        _5859 = NOVALUE;
        _2 = (object)SEQ_PTR(_quotient_10492);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _quotient_10492 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _5858);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5860;
        if( _1 != _5860 ){
            DeRef(_1);
        }
        _5860 = NOVALUE;
L3: 

        /** scinot.e:217		end for*/
        _i_10498 = _i_10498 + 1LL;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** scinot.e:218		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_10492);
    _5861 = _28reverse(_quotient_10492);
    _5862 = _28carry(_5861, 10LL);
    _5861 = NOVALUE;
    _5863 = _28reverse(_5862);
    _5862 = NOVALUE;
    DeRefDS(_decimal_10491);
    DeRefDS(_quotient_10492);
    DeRef(_q_10493);
    DeRef(_Q_10494);
    DeRef(_5858);
    _5858 = NOVALUE;
    return _5863;
    ;
}


object _28decimals_to_bits(object _decimals_10527, object _size_10528)
{
    object _sub_10529 = NOVALUE;
    object _bits_10530 = NOVALUE;
    object _bit_10531 = NOVALUE;
    object _assigned_10532 = NOVALUE;
    object _5891 = NOVALUE;
    object _5887 = NOVALUE;
    object _5886 = NOVALUE;
    object _5885 = NOVALUE;
    object _5884 = NOVALUE;
    object _5882 = NOVALUE;
    object _5881 = NOVALUE;
    object _5880 = NOVALUE;
    object _5878 = NOVALUE;
    object _5876 = NOVALUE;
    object _5875 = NOVALUE;
    object _5874 = NOVALUE;
    object _5873 = NOVALUE;
    object _5872 = NOVALUE;
    object _5870 = NOVALUE;
    object _5868 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:233		sub = {5}*/
    RefDS(_5866);
    DeRef(_sub_10529);
    _sub_10529 = _5866;

    /** scinot.e:234		bits = repeat( 0, size )*/
    DeRef(_bits_10530);
    _bits_10530 = Repeat(0LL, _size_10528);

    /** scinot.e:235		bit = 1*/
    _bit_10531 = 1LL;

    /** scinot.e:236		assigned = 0*/
    _assigned_10532 = 0LL;

    /** scinot.e:240		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_10527) && IS_ATOM_INT(_bits_10530)){
        _5868 = (_decimals_10527 < _bits_10530) ? -1 : (_decimals_10527 > _bits_10530);
    }
    else{
        _5868 = compare(_decimals_10527, _bits_10530);
    }
    if (_5868 <= 0LL)
    goto L1; // [34] 166

    /** scinot.e:242			while (not assigned) or (bit < find( 1, bits ) + size + 1)  do*/
L2: 
    _5870 = (_assigned_10532 == 0);
    if (_5870 != 0) {
        goto L3; // [46] 72
    }
    _5872 = find_from(1LL, _bits_10530, 1LL);
    _5873 = _5872 + _size_10528;
    if ((object)((uintptr_t)_5873 + (uintptr_t)HIGH_BITS) >= 0){
        _5873 = NewDouble((eudouble)_5873);
    }
    _5872 = NOVALUE;
    if (IS_ATOM_INT(_5873)) {
        _5874 = _5873 + 1;
        if (_5874 > MAXINT){
            _5874 = NewDouble((eudouble)_5874);
        }
    }
    else
    _5874 = binary_op(PLUS, 1, _5873);
    DeRef(_5873);
    _5873 = NOVALUE;
    if (IS_ATOM_INT(_5874)) {
        _5875 = (_bit_10531 < _5874);
    }
    else {
        _5875 = ((eudouble)_bit_10531 < DBL_PTR(_5874)->dbl);
    }
    DeRef(_5874);
    _5874 = NOVALUE;
    if (_5875 == 0)
    {
        DeRef(_5875);
        _5875 = NOVALUE;
        goto L4; // [68] 165
    }
    else{
        DeRef(_5875);
        _5875 = NOVALUE;
    }
L3: 

    /** scinot.e:243				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_10529) && IS_ATOM_INT(_decimals_10527)){
        _5876 = (_sub_10529 < _decimals_10527) ? -1 : (_sub_10529 > _decimals_10527);
    }
    else{
        _5876 = compare(_sub_10529, _decimals_10527);
    }
    if (_5876 > 0LL)
    goto L5; // [78] 146

    /** scinot.e:244					assigned = 1*/
    _assigned_10532 = 1LL;

    /** scinot.e:245					if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_10530)){
            _5878 = SEQ_PTR(_bits_10530)->length;
    }
    else {
        _5878 = 1;
    }
    if (_5878 >= _bit_10531)
    goto L6; // [92] 114

    /** scinot.e:246						bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_10530)){
            _5880 = SEQ_PTR(_bits_10530)->length;
    }
    else {
        _5880 = 1;
    }
    _5881 = _bit_10531 - _5880;
    _5880 = NOVALUE;
    _5882 = Repeat(0LL, _5881);
    _5881 = NOVALUE;
    Concat((object_ptr)&_bits_10530, _bits_10530, _5882);
    DeRefDS(_5882);
    _5882 = NOVALUE;
L6: 

    /** scinot.e:249					bits[bit] += 1*/
    _2 = (object)SEQ_PTR(_bits_10530);
    _5884 = (object)*(((s1_ptr)_2)->base + _bit_10531);
    if (IS_ATOM_INT(_5884)) {
        _5885 = _5884 + 1;
        if (_5885 > MAXINT){
            _5885 = NewDouble((eudouble)_5885);
        }
    }
    else
    _5885 = binary_op(PLUS, 1, _5884);
    _5884 = NOVALUE;
    _2 = (object)SEQ_PTR(_bits_10530);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bits_10530 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _bit_10531);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _5885;
    if( _1 != _5885 ){
        DeRef(_1);
    }
    _5885 = NOVALUE;

    /** scinot.e:250					decimals = borrow( add( decimals, -sub ), 10 )*/
    _5886 = unary_op(UMINUS, _sub_10529);
    RefDS(_decimals_10527);
    _5887 = _28add(_decimals_10527, _5886);
    _5886 = NOVALUE;
    _0 = _decimals_10527;
    _decimals_10527 = _28borrow(_5887, 10LL);
    DeRefDS(_0);
    _5887 = NOVALUE;
L5: 

    /** scinot.e:252				sub = half( sub )*/
    RefDS(_sub_10529);
    _0 = _sub_10529;
    _sub_10529 = _28half(_sub_10529);
    DeRefDS(_0);

    /** scinot.e:254				bit += 1*/
    _bit_10531 = _bit_10531 + 1;

    /** scinot.e:255			end while*/
    goto L2; // [162] 43
L4: 
L1: 

    /** scinot.e:258		return reverse(bits)*/
    RefDS(_bits_10530);
    _5891 = _28reverse(_bits_10530);
    DeRefDS(_decimals_10527);
    DeRef(_sub_10529);
    DeRefDS(_bits_10530);
    DeRef(_5870);
    _5870 = NOVALUE;
    return _5891;
    ;
}


object _28string_to_int(object _s_10565)
{
    object _int_10566 = NOVALUE;
    object _5895 = NOVALUE;
    object _5894 = NOVALUE;
    object _5892 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:263		int = 0*/
    _int_10566 = 0LL;

    /** scinot.e:264		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_10565)){
            _5892 = SEQ_PTR(_s_10565)->length;
    }
    else {
        _5892 = 1;
    }
    {
        object _i_10568;
        _i_10568 = 1LL;
L1: 
        if (_i_10568 > _5892){
            goto L2; // [13] 51
        }

        /** scinot.e:265			int *= 10*/
        _int_10566 = _int_10566 * 10LL;

        /** scinot.e:266			int += s[i] - '0'*/
        _2 = (object)SEQ_PTR(_s_10565);
        _5894 = (object)*(((s1_ptr)_2)->base + _i_10568);
        if (IS_ATOM_INT(_5894)) {
            _5895 = _5894 - 48LL;
            if ((object)((uintptr_t)_5895 +(uintptr_t) HIGH_BITS) >= 0){
                _5895 = NewDouble((eudouble)_5895);
            }
        }
        else {
            _5895 = binary_op(MINUS, _5894, 48LL);
        }
        _5894 = NOVALUE;
        if (IS_ATOM_INT(_5895)) {
            _int_10566 = _int_10566 + _5895;
        }
        else {
            _int_10566 = binary_op(PLUS, _int_10566, _5895);
        }
        DeRef(_5895);
        _5895 = NOVALUE;
        if (!IS_ATOM_INT(_int_10566)) {
            _1 = (object)(DBL_PTR(_int_10566)->dbl);
            DeRefDS(_int_10566);
            _int_10566 = _1;
        }

        /** scinot.e:267		end for*/
        _i_10568 = _i_10568 + 1LL;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** scinot.e:268		return int*/
    DeRefDS(_s_10565);
    return _int_10566;
    ;
}


object _28trim_bits(object _bits_10576)
{
    object _5902 = NOVALUE;
    object _5901 = NOVALUE;
    object _5900 = NOVALUE;
    object _5899 = NOVALUE;
    object _5898 = NOVALUE;
    object _5897 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:272			while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_10576)){
            _5897 = SEQ_PTR(_bits_10576)->length;
    }
    else {
        _5897 = 1;
    }
    if (_5897 == 0) {
        goto L2; // [11] 44
    }
    if (IS_SEQUENCE(_bits_10576)){
            _5899 = SEQ_PTR(_bits_10576)->length;
    }
    else {
        _5899 = 1;
    }
    _2 = (object)SEQ_PTR(_bits_10576);
    _5900 = (object)*(((s1_ptr)_2)->base + _5899);
    if (IS_ATOM_INT(_5900)) {
        _5901 = (_5900 == 0);
    }
    else {
        _5901 = unary_op(NOT, _5900);
    }
    _5900 = NOVALUE;
    if (_5901 <= 0) {
        if (_5901 == 0) {
            DeRef(_5901);
            _5901 = NOVALUE;
            goto L2; // [26] 44
        }
        else {
            if (!IS_ATOM_INT(_5901) && DBL_PTR(_5901)->dbl == 0.0){
                DeRef(_5901);
                _5901 = NOVALUE;
                goto L2; // [26] 44
            }
            DeRef(_5901);
            _5901 = NOVALUE;
        }
    }
    DeRef(_5901);
    _5901 = NOVALUE;

    /** scinot.e:273				bits = remove( bits, length( bits ) )*/
    if (IS_SEQUENCE(_bits_10576)){
            _5902 = SEQ_PTR(_bits_10576)->length;
    }
    else {
        _5902 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_bits_10576);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5902)) ? _5902 : (object)(DBL_PTR(_5902)->dbl);
        int stop = (IS_ATOM_INT(_5902)) ? _5902 : (object)(DBL_PTR(_5902)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_bits_10576), start, &_bits_10576 );
            }
            else Tail(SEQ_PTR(_bits_10576), stop+1, &_bits_10576);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_bits_10576), start, &_bits_10576);
        }
        else {
            assign_slice_seq = &assign_space;
            _bits_10576 = Remove_elements(start, stop, (SEQ_PTR(_bits_10576)->ref == 1));
        }
    }
    _5902 = NOVALUE;
    _5902 = NOVALUE;

    /** scinot.e:274			end while*/
    goto L1; // [41] 8
L2: 

    /** scinot.e:275			return bits*/
    return _bits_10576;
    ;
}


object _28scientific_to_float(object _s_10599, object _fp_10600)
{
    object _dp_10601 = NOVALUE;
    object _e_10602 = NOVALUE;
    object _exp_10603 = NOVALUE;
    object _int_bits_10604 = NOVALUE;
    object _frac_bits_10605 = NOVALUE;
    object _mbits_10606 = NOVALUE;
    object _ebits_10607 = NOVALUE;
    object _sbits_10608 = NOVALUE;
    object _significand_10609 = NOVALUE;
    object _exponent_10610 = NOVALUE;
    object _min_exp_10611 = NOVALUE;
    object _exp_bias_10612 = NOVALUE;
    object _6061 = NOVALUE;
    object _6060 = NOVALUE;
    object _6058 = NOVALUE;
    object _6056 = NOVALUE;
    object _6055 = NOVALUE;
    object _6053 = NOVALUE;
    object _6052 = NOVALUE;
    object _6051 = NOVALUE;
    object _6050 = NOVALUE;
    object _6049 = NOVALUE;
    object _6048 = NOVALUE;
    object _6047 = NOVALUE;
    object _6045 = NOVALUE;
    object _6044 = NOVALUE;
    object _6042 = NOVALUE;
    object _6041 = NOVALUE;
    object _6040 = NOVALUE;
    object _6039 = NOVALUE;
    object _6036 = NOVALUE;
    object _6035 = NOVALUE;
    object _6034 = NOVALUE;
    object _6033 = NOVALUE;
    object _6032 = NOVALUE;
    object _6031 = NOVALUE;
    object _6030 = NOVALUE;
    object _6029 = NOVALUE;
    object _6026 = NOVALUE;
    object _6025 = NOVALUE;
    object _6022 = NOVALUE;
    object _6021 = NOVALUE;
    object _6020 = NOVALUE;
    object _6019 = NOVALUE;
    object _6016 = NOVALUE;
    object _6015 = NOVALUE;
    object _6013 = NOVALUE;
    object _6012 = NOVALUE;
    object _6010 = NOVALUE;
    object _6008 = NOVALUE;
    object _6007 = NOVALUE;
    object _6006 = NOVALUE;
    object _6005 = NOVALUE;
    object _6004 = NOVALUE;
    object _6003 = NOVALUE;
    object _6002 = NOVALUE;
    object _6001 = NOVALUE;
    object _6000 = NOVALUE;
    object _5999 = NOVALUE;
    object _5997 = NOVALUE;
    object _5996 = NOVALUE;
    object _5995 = NOVALUE;
    object _5994 = NOVALUE;
    object _5992 = NOVALUE;
    object _5991 = NOVALUE;
    object _5990 = NOVALUE;
    object _5989 = NOVALUE;
    object _5986 = NOVALUE;
    object _5984 = NOVALUE;
    object _5983 = NOVALUE;
    object _5982 = NOVALUE;
    object _5981 = NOVALUE;
    object _5980 = NOVALUE;
    object _5978 = NOVALUE;
    object _5977 = NOVALUE;
    object _5976 = NOVALUE;
    object _5975 = NOVALUE;
    object _5974 = NOVALUE;
    object _5973 = NOVALUE;
    object _5971 = NOVALUE;
    object _5970 = NOVALUE;
    object _5969 = NOVALUE;
    object _5968 = NOVALUE;
    object _5967 = NOVALUE;
    object _5965 = NOVALUE;
    object _5964 = NOVALUE;
    object _5962 = NOVALUE;
    object _5961 = NOVALUE;
    object _5960 = NOVALUE;
    object _5959 = NOVALUE;
    object _5958 = NOVALUE;
    object _5956 = NOVALUE;
    object _5954 = NOVALUE;
    object _5951 = NOVALUE;
    object _5950 = NOVALUE;
    object _5948 = NOVALUE;
    object _5947 = NOVALUE;
    object _5945 = NOVALUE;
    object _5941 = NOVALUE;
    object _5940 = NOVALUE;
    object _5939 = NOVALUE;
    object _5938 = NOVALUE;
    object _5936 = NOVALUE;
    object _5935 = NOVALUE;
    object _5934 = NOVALUE;
    object _5933 = NOVALUE;
    object _5931 = NOVALUE;
    object _5930 = NOVALUE;
    object _5928 = NOVALUE;
    object _5927 = NOVALUE;
    object _5926 = NOVALUE;
    object _5925 = NOVALUE;
    object _5923 = NOVALUE;
    object _5922 = NOVALUE;
    object _5915 = NOVALUE;
    object _5911 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:316		if fp = NATIVE then*/
    if (_fp_10600 != 1LL)
    goto L1; // [5] 17

    /** scinot.e:317			fp = NATIVE_FORMAT*/
    _fp_10600 = _28NATIVE_FORMAT_10354;
L1: 

    /** scinot.e:319		if fp = DOUBLE then*/
    if (_fp_10600 != 2LL)
    goto L2; // [19] 46

    /** scinot.e:320			significand = DOUBLE_SIGNIFICAND*/
    _significand_10609 = 52LL;

    /** scinot.e:321			exponent    = DOUBLE_EXPONENT*/
    _exponent_10610 = 11LL;

    /** scinot.e:322			min_exp     = DOUBLE_MIN_EXP*/
    _min_exp_10611 = -1023LL;

    /** scinot.e:323			exp_bias    = DOUBLE_EXP_BIAS*/
    _exp_bias_10612 = 1023LL;
    goto L3; // [43] 74
L2: 

    /** scinot.e:325		elsif fp = EXTENDED then*/
    if (_fp_10600 != 3LL)
    goto L4; // [48] 73

    /** scinot.e:326			significand = EXTENDED_SIGNIFICAND*/
    _significand_10609 = 64LL;

    /** scinot.e:327			exponent    = EXTENDED_EXPONENT*/
    _exponent_10610 = 15LL;

    /** scinot.e:328			min_exp     = EXTENDED_MIN_EXP*/
    _min_exp_10611 = -16383LL;

    /** scinot.e:329			exp_bias    = EXTENDED_EXP_BIAS*/
    _exp_bias_10612 = 16383LL;
L4: 
L3: 

    /** scinot.e:333		if s[1] = '-' then*/
    _2 = (object)SEQ_PTR(_s_10599);
    _5911 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _5911, 45LL)){
        _5911 = NOVALUE;
        goto L5; // [80] 101
    }
    _5911 = NOVALUE;

    /** scinot.e:334			sbits = {1}*/
    RefDS(_5837);
    DeRefi(_sbits_10608);
    _sbits_10608 = _5837;

    /** scinot.e:335			s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_10599);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_10599), start, &_s_10599 );
            }
            else Tail(SEQ_PTR(_s_10599), stop+1, &_s_10599);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_10599), start, &_s_10599);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_10599 = Remove_elements(start, stop, (SEQ_PTR(_s_10599)->ref == 1));
        }
    }
    goto L6; // [98] 126
L5: 

    /** scinot.e:337			sbits = {0}*/
    _0 = _sbits_10608;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    _sbits_10608 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** scinot.e:338			if s[1] = '+' then*/
    _2 = (object)SEQ_PTR(_s_10599);
    _5915 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _5915, 43LL)){
        _5915 = NOVALUE;
        goto L7; // [113] 125
    }
    _5915 = NOVALUE;

    /** scinot.e:339				s = remove( s, 1 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_10599);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_10599), start, &_s_10599 );
            }
            else Tail(SEQ_PTR(_s_10599), stop+1, &_s_10599);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_10599), start, &_s_10599);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_10599 = Remove_elements(start, stop, (SEQ_PTR(_s_10599)->ref == 1));
        }
    }
L7: 
L6: 

    /** scinot.e:344		dp = find('.', s)*/
    _dp_10601 = find_from(46LL, _s_10599, 1LL);

    /** scinot.e:345		e = find( 'e', s )*/
    _e_10602 = find_from(101LL, _s_10599, 1LL);

    /** scinot.e:346		if not e then*/
    if (_e_10602 != 0)
    goto L8; // [142] 153

    /** scinot.e:347			e = find('E', s )*/
    _e_10602 = find_from(69LL, _s_10599, 1LL);
L8: 

    /** scinot.e:351		exp = 0*/
    _exp_10603 = 0LL;

    /** scinot.e:352		if s[e+1] = '-' then*/
    _5922 = _e_10602 + 1;
    _2 = (object)SEQ_PTR(_s_10599);
    _5923 = (object)*(((s1_ptr)_2)->base + _5922);
    if (binary_op_a(NOTEQ, _5923, 45LL)){
        _5923 = NOVALUE;
        goto L9; // [168] 199
    }
    _5923 = NOVALUE;

    /** scinot.e:353			exp -= string_to_int( s[e+2..$] )*/
    _5925 = _e_10602 + 2LL;
    if ((object)((uintptr_t)_5925 + (uintptr_t)HIGH_BITS) >= 0){
        _5925 = NewDouble((eudouble)_5925);
    }
    if (IS_SEQUENCE(_s_10599)){
            _5926 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5926 = 1;
    }
    rhs_slice_target = (object_ptr)&_5927;
    RHS_Slice(_s_10599, _5925, _5926);
    _5928 = _28string_to_int(_5927);
    _5927 = NOVALUE;
    if (IS_ATOM_INT(_5928)) {
        _exp_10603 = _exp_10603 - _5928;
    }
    else {
        _exp_10603 = binary_op(MINUS, _exp_10603, _5928);
    }
    DeRef(_5928);
    _5928 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10603)) {
        _1 = (object)(DBL_PTR(_exp_10603)->dbl);
        DeRefDS(_exp_10603);
        _exp_10603 = _1;
    }
    goto LA; // [196] 266
L9: 

    /** scinot.e:356			if s[e+1] = '+' then*/
    _5930 = _e_10602 + 1;
    _2 = (object)SEQ_PTR(_s_10599);
    _5931 = (object)*(((s1_ptr)_2)->base + _5930);
    if (binary_op_a(NOTEQ, _5931, 43LL)){
        _5931 = NOVALUE;
        goto LB; // [209] 240
    }
    _5931 = NOVALUE;

    /** scinot.e:357				exp += string_to_int( s[e+2..$] )*/
    _5933 = _e_10602 + 2LL;
    if ((object)((uintptr_t)_5933 + (uintptr_t)HIGH_BITS) >= 0){
        _5933 = NewDouble((eudouble)_5933);
    }
    if (IS_SEQUENCE(_s_10599)){
            _5934 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5934 = 1;
    }
    rhs_slice_target = (object_ptr)&_5935;
    RHS_Slice(_s_10599, _5933, _5934);
    _5936 = _28string_to_int(_5935);
    _5935 = NOVALUE;
    if (IS_ATOM_INT(_5936)) {
        _exp_10603 = _exp_10603 + _5936;
    }
    else {
        _exp_10603 = binary_op(PLUS, _exp_10603, _5936);
    }
    DeRef(_5936);
    _5936 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10603)) {
        _1 = (object)(DBL_PTR(_exp_10603)->dbl);
        DeRefDS(_exp_10603);
        _exp_10603 = _1;
    }
    goto LC; // [237] 265
LB: 

    /** scinot.e:359				exp += string_to_int( s[e+1..$] )*/
    _5938 = _e_10602 + 1;
    if (_5938 > MAXINT){
        _5938 = NewDouble((eudouble)_5938);
    }
    if (IS_SEQUENCE(_s_10599)){
            _5939 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5939 = 1;
    }
    rhs_slice_target = (object_ptr)&_5940;
    RHS_Slice(_s_10599, _5938, _5939);
    _5941 = _28string_to_int(_5940);
    _5940 = NOVALUE;
    if (IS_ATOM_INT(_5941)) {
        _exp_10603 = _exp_10603 + _5941;
    }
    else {
        _exp_10603 = binary_op(PLUS, _exp_10603, _5941);
    }
    DeRef(_5941);
    _5941 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10603)) {
        _1 = (object)(DBL_PTR(_exp_10603)->dbl);
        DeRefDS(_exp_10603);
        _exp_10603 = _1;
    }
LC: 
LA: 

    /** scinot.e:363		if dp then*/
    if (_dp_10601 == 0)
    {
        goto LD; // [268] 297
    }
    else{
    }

    /** scinot.e:365			s = remove( s, dp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_s_10599);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_dp_10601)) ? _dp_10601 : (object)(DBL_PTR(_dp_10601)->dbl);
        int stop = (IS_ATOM_INT(_dp_10601)) ? _dp_10601 : (object)(DBL_PTR(_dp_10601)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_s_10599), start, &_s_10599 );
            }
            else Tail(SEQ_PTR(_s_10599), stop+1, &_s_10599);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_s_10599), start, &_s_10599);
        }
        else {
            assign_slice_seq = &assign_space;
            _s_10599 = Remove_elements(start, stop, (SEQ_PTR(_s_10599)->ref == 1));
        }
    }

    /** scinot.e:366			e -= 1*/
    _e_10602 = _e_10602 - 1LL;

    /** scinot.e:369			exp -= e - dp*/
    _5945 = _e_10602 - _dp_10601;
    if ((object)((uintptr_t)_5945 +(uintptr_t) HIGH_BITS) >= 0){
        _5945 = NewDouble((eudouble)_5945);
    }
    if (IS_ATOM_INT(_5945)) {
        _exp_10603 = _exp_10603 - _5945;
    }
    else {
        _exp_10603 = NewDouble((eudouble)_exp_10603 - DBL_PTR(_5945)->dbl);
    }
    DeRef(_5945);
    _5945 = NOVALUE;
    if (!IS_ATOM_INT(_exp_10603)) {
        _1 = (object)(DBL_PTR(_exp_10603)->dbl);
        DeRefDS(_exp_10603);
        _exp_10603 = _1;
    }
LD: 

    /** scinot.e:374		s = s[1..e-1] - '0'*/
    _5947 = _e_10602 - 1LL;
    rhs_slice_target = (object_ptr)&_5948;
    RHS_Slice(_s_10599, 1LL, _5947);
    DeRefDS(_s_10599);
    _s_10599 = binary_op(MINUS, _5948, 48LL);
    DeRefDS(_5948);
    _5948 = NOVALUE;

    /** scinot.e:377		if not find(0, s = 0) then*/
    _5950 = binary_op(EQUALS, _s_10599, 0LL);
    _5951 = find_from(0LL, _5950, 1LL);
    DeRefDS(_5950);
    _5950 = NOVALUE;
    if (_5951 != 0)
    goto LE; // [325] 366
    _5951 = NOVALUE;

    /** scinot.e:378			if fp = DOUBLE then*/
    if (_fp_10600 != 2LL)
    goto LF; // [330] 347

    /** scinot.e:379				return atom_to_float64(0)*/
    _5954 = _15atom_to_float64(0LL);
    DeRefDS(_s_10599);
    DeRef(_int_bits_10604);
    DeRef(_frac_bits_10605);
    DeRef(_mbits_10606);
    DeRef(_ebits_10607);
    DeRefi(_sbits_10608);
    DeRef(_5925);
    _5925 = NOVALUE;
    _5947 = NOVALUE;
    DeRef(_5933);
    _5933 = NOVALUE;
    DeRef(_5938);
    _5938 = NOVALUE;
    DeRef(_5922);
    _5922 = NOVALUE;
    DeRef(_5930);
    _5930 = NOVALUE;
    return _5954;
    goto L10; // [344] 365
LF: 

    /** scinot.e:380			elsif fp = EXTENDED then*/
    if (_fp_10600 != 3LL)
    goto L11; // [349] 364

    /** scinot.e:381				return atom_to_float80(0)*/
    _5956 = _15atom_to_float80(0LL);
    DeRefDS(_s_10599);
    DeRef(_int_bits_10604);
    DeRef(_frac_bits_10605);
    DeRef(_mbits_10606);
    DeRef(_ebits_10607);
    DeRefi(_sbits_10608);
    DeRef(_5925);
    _5925 = NOVALUE;
    DeRef(_5947);
    _5947 = NOVALUE;
    DeRef(_5933);
    _5933 = NOVALUE;
    DeRef(_5954);
    _5954 = NOVALUE;
    DeRef(_5938);
    _5938 = NOVALUE;
    DeRef(_5922);
    _5922 = NOVALUE;
    DeRef(_5930);
    _5930 = NOVALUE;
    return _5956;
L11: 
L10: 
LE: 

    /** scinot.e:385		if exp >= 0 then*/
    if (_exp_10603 < 0LL)
    goto L12; // [368] 412

    /** scinot.e:388			int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _5958 = Repeat(0LL, _exp_10603);
    RefDS(_s_10599);
    _5959 = _28reverse(_s_10599);
    if (IS_SEQUENCE(_5958) && IS_ATOM(_5959)) {
        Ref(_5959);
        Append(&_5960, _5958, _5959);
    }
    else if (IS_ATOM(_5958) && IS_SEQUENCE(_5959)) {
    }
    else {
        Concat((object_ptr)&_5960, _5958, _5959);
        DeRefDS(_5958);
        _5958 = NOVALUE;
    }
    DeRef(_5958);
    _5958 = NOVALUE;
    DeRef(_5959);
    _5959 = NOVALUE;
    _5961 = _28convert_radix(_5960, 10LL, 256LL);
    _5960 = NOVALUE;
    _5962 = _28bytes_to_bits(_5961);
    _5961 = NOVALUE;
    _0 = _int_bits_10604;
    _int_bits_10604 = _28trim_bits(_5962);
    DeRef(_0);
    _5962 = NOVALUE;

    /** scinot.e:389			frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_10605);
    _frac_bits_10605 = _5;
    goto L13; // [409] 529
L12: 

    /** scinot.e:391			if -exp > length(s) then*/
    if ((uintptr_t)_exp_10603 == (uintptr_t)HIGH_BITS){
        _5964 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _5964 = - _exp_10603;
    }
    if (IS_SEQUENCE(_s_10599)){
            _5965 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5965 = 1;
    }
    if (binary_op_a(LESSEQ, _5964, _5965)){
        DeRef(_5964);
        _5964 = NOVALUE;
        _5965 = NOVALUE;
        goto L14; // [420] 463
    }
    DeRef(_5964);
    _5964 = NOVALUE;
    _5965 = NOVALUE;

    /** scinot.e:393				int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_10604);
    _int_bits_10604 = _5;

    /** scinot.e:394				frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s, significand ) */
    if ((uintptr_t)_exp_10603 == (uintptr_t)HIGH_BITS){
        _5967 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _5967 = - _exp_10603;
    }
    if (IS_SEQUENCE(_s_10599)){
            _5968 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5968 = 1;
    }
    if (IS_ATOM_INT(_5967)) {
        _5969 = _5967 - _5968;
    }
    else {
        _5969 = NewDouble(DBL_PTR(_5967)->dbl - (eudouble)_5968);
    }
    DeRef(_5967);
    _5967 = NOVALUE;
    _5968 = NOVALUE;
    _5970 = Repeat(0LL, _5969);
    DeRef(_5969);
    _5969 = NOVALUE;
    Concat((object_ptr)&_5971, _5970, _s_10599);
    DeRefDS(_5970);
    _5970 = NOVALUE;
    DeRef(_5970);
    _5970 = NOVALUE;
    _0 = _frac_bits_10605;
    _frac_bits_10605 = _28decimals_to_bits(_5971, _significand_10609);
    DeRef(_0);
    _5971 = NOVALUE;
    goto L15; // [460] 528
L14: 

    /** scinot.e:398				int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_10599)){
            _5973 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5973 = 1;
    }
    _5974 = _5973 + _exp_10603;
    _5973 = NOVALUE;
    rhs_slice_target = (object_ptr)&_5975;
    RHS_Slice(_s_10599, 1LL, _5974);
    _5976 = _28reverse(_5975);
    _5975 = NOVALUE;
    _5977 = _28convert_radix(_5976, 10LL, 256LL);
    _5976 = NOVALUE;
    _5978 = _28bytes_to_bits(_5977);
    _5977 = NOVALUE;
    _0 = _int_bits_10604;
    _int_bits_10604 = _28trim_bits(_5978);
    DeRef(_0);
    _5978 = NOVALUE;

    /** scinot.e:399				frac_bits =  decimals_to_bits( s[$+exp+1..$], significand )*/
    if (IS_SEQUENCE(_s_10599)){
            _5980 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5980 = 1;
    }
    _5981 = _5980 + _exp_10603;
    if ((object)((uintptr_t)_5981 + (uintptr_t)HIGH_BITS) >= 0){
        _5981 = NewDouble((eudouble)_5981);
    }
    _5980 = NOVALUE;
    if (IS_ATOM_INT(_5981)) {
        _5982 = _5981 + 1;
        if (_5982 > MAXINT){
            _5982 = NewDouble((eudouble)_5982);
        }
    }
    else
    _5982 = binary_op(PLUS, 1, _5981);
    DeRef(_5981);
    _5981 = NOVALUE;
    if (IS_SEQUENCE(_s_10599)){
            _5983 = SEQ_PTR(_s_10599)->length;
    }
    else {
        _5983 = 1;
    }
    rhs_slice_target = (object_ptr)&_5984;
    RHS_Slice(_s_10599, _5982, _5983);
    _0 = _frac_bits_10605;
    _frac_bits_10605 = _28decimals_to_bits(_5984, _significand_10609);
    DeRef(_0);
    _5984 = NOVALUE;
L15: 
L13: 

    /** scinot.e:403		if length(int_bits) > significand then*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _5986 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _5986 = 1;
    }
    if (_5986 <= _significand_10609)
    goto L16; // [538] 668

    /** scinot.e:406			if fp = DOUBLE then*/
    if (_fp_10600 != 2LL)
    goto L17; // [544] 572

    /** scinot.e:408				mbits = int_bits[$-significand..$-1]*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _5989 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _5989 = 1;
    }
    _5990 = _5989 - _significand_10609;
    if ((object)((uintptr_t)_5990 +(uintptr_t) HIGH_BITS) >= 0){
        _5990 = NewDouble((eudouble)_5990);
    }
    _5989 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_10604)){
            _5991 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _5991 = 1;
    }
    _5992 = _5991 - 1LL;
    _5991 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_10606;
    RHS_Slice(_int_bits_10604, _5990, _5992);
    goto L18; // [569] 594
L17: 

    /** scinot.e:411				mbits = int_bits[$-significand+1..$]*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _5994 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _5994 = 1;
    }
    _5995 = _5994 - _significand_10609;
    if ((object)((uintptr_t)_5995 +(uintptr_t) HIGH_BITS) >= 0){
        _5995 = NewDouble((eudouble)_5995);
    }
    _5994 = NOVALUE;
    if (IS_ATOM_INT(_5995)) {
        _5996 = _5995 + 1;
        if (_5996 > MAXINT){
            _5996 = NewDouble((eudouble)_5996);
        }
    }
    else
    _5996 = binary_op(PLUS, 1, _5995);
    DeRef(_5995);
    _5995 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_10604)){
            _5997 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _5997 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_10606;
    RHS_Slice(_int_bits_10604, _5996, _5997);
L18: 

    /** scinot.e:414			if length(int_bits) > significand + 1 and int_bits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _5999 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _5999 = 1;
    }
    _6000 = _significand_10609 + 1;
    if (_6000 > MAXINT){
        _6000 = NewDouble((eudouble)_6000);
    }
    if (IS_ATOM_INT(_6000)) {
        _6001 = (_5999 > _6000);
    }
    else {
        _6001 = ((eudouble)_5999 > DBL_PTR(_6000)->dbl);
    }
    _5999 = NOVALUE;
    DeRef(_6000);
    _6000 = NOVALUE;
    if (_6001 == 0) {
        goto L19; // [607] 656
    }
    if (IS_SEQUENCE(_int_bits_10604)){
            _6003 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _6003 = 1;
    }
    _6004 = _significand_10609 + 1;
    if (_6004 > MAXINT){
        _6004 = NewDouble((eudouble)_6004);
    }
    if (IS_ATOM_INT(_6004)) {
        _6005 = _6003 - _6004;
    }
    else {
        _6005 = NewDouble((eudouble)_6003 - DBL_PTR(_6004)->dbl);
    }
    _6003 = NOVALUE;
    DeRef(_6004);
    _6004 = NOVALUE;
    _2 = (object)SEQ_PTR(_int_bits_10604);
    if (!IS_ATOM_INT(_6005)){
        _6006 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_6005)->dbl));
    }
    else{
        _6006 = (object)*(((s1_ptr)_2)->base + _6005);
    }
    if (_6006 == 0) {
        _6006 = NOVALUE;
        goto L19; // [627] 656
    }
    else {
        if (!IS_ATOM_INT(_6006) && DBL_PTR(_6006)->dbl == 0.0){
            _6006 = NOVALUE;
            goto L19; // [627] 656
        }
        _6006 = NOVALUE;
    }
    _6006 = NOVALUE;

    /** scinot.e:416				mbits[1] += 1*/
    _2 = (object)SEQ_PTR(_mbits_10606);
    _6007 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_6007)) {
        _6008 = _6007 + 1;
        if (_6008 > MAXINT){
            _6008 = NewDouble((eudouble)_6008);
        }
    }
    else
    _6008 = binary_op(PLUS, 1, _6007);
    _6007 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_10606 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6008;
    if( _1 != _6008 ){
        DeRef(_1);
    }
    _6008 = NOVALUE;

    /** scinot.e:417				mbits = carry( mbits, 2 )*/
    RefDS(_mbits_10606);
    _0 = _mbits_10606;
    _mbits_10606 = _28carry(_mbits_10606, 2LL);
    DeRefDS(_0);
L19: 

    /** scinot.e:419			exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _6010 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _6010 = 1;
    }
    _exp_10603 = _6010 - 1LL;
    _6010 = NOVALUE;
    goto L1A; // [665] 940
L16: 

    /** scinot.e:422			if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _6012 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _6012 = 1;
    }
    if (_6012 == 0)
    {
        _6012 = NOVALUE;
        goto L1B; // [673] 688
    }
    else{
        _6012 = NOVALUE;
    }

    /** scinot.e:424				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_10604)){
            _6013 = SEQ_PTR(_int_bits_10604)->length;
    }
    else {
        _6013 = 1;
    }
    _exp_10603 = _6013 - 1LL;
    _6013 = NOVALUE;
    goto L1C; // [685] 748
L1B: 

    /** scinot.e:428				exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_10605);
    _6015 = _28reverse(_frac_bits_10605);
    _6016 = find_from(1LL, _6015, 1LL);
    DeRef(_6015);
    _6015 = NOVALUE;
    _exp_10603 = - _6016;

    /** scinot.e:429				if exp < min_exp then*/
    if (_exp_10603 >= _min_exp_10611)
    goto L1D; // [710] 720

    /** scinot.e:432					exp = min_exp*/
    _exp_10603 = _min_exp_10611;
L1D: 

    /** scinot.e:435				if exp then*/
    if (_exp_10603 == 0)
    {
        goto L1E; // [722] 747
    }
    else{
    }

    /** scinot.e:437					frac_bits = remove( frac_bits, length(frac_bits) + exp + 2, length( frac_bits ) )*/
    if (IS_SEQUENCE(_frac_bits_10605)){
            _6019 = SEQ_PTR(_frac_bits_10605)->length;
    }
    else {
        _6019 = 1;
    }
    _6020 = _6019 + _exp_10603;
    if ((object)((uintptr_t)_6020 + (uintptr_t)HIGH_BITS) >= 0){
        _6020 = NewDouble((eudouble)_6020);
    }
    _6019 = NOVALUE;
    if (IS_ATOM_INT(_6020)) {
        _6021 = _6020 + 2LL;
        if ((object)((uintptr_t)_6021 + (uintptr_t)HIGH_BITS) >= 0){
            _6021 = NewDouble((eudouble)_6021);
        }
    }
    else {
        _6021 = NewDouble(DBL_PTR(_6020)->dbl + (eudouble)2LL);
    }
    DeRef(_6020);
    _6020 = NOVALUE;
    if (IS_SEQUENCE(_frac_bits_10605)){
            _6022 = SEQ_PTR(_frac_bits_10605)->length;
    }
    else {
        _6022 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_frac_bits_10605);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_6021)) ? _6021 : (object)(DBL_PTR(_6021)->dbl);
        int stop = (IS_ATOM_INT(_6022)) ? _6022 : (object)(DBL_PTR(_6022)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_frac_bits_10605), start, &_frac_bits_10605 );
            }
            else Tail(SEQ_PTR(_frac_bits_10605), stop+1, &_frac_bits_10605);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_frac_bits_10605), start, &_frac_bits_10605);
        }
        else {
            assign_slice_seq = &assign_space;
            _frac_bits_10605 = Remove_elements(start, stop, (SEQ_PTR(_frac_bits_10605)->ref == 1));
        }
    }
    DeRef(_6021);
    _6021 = NOVALUE;
    _6022 = NOVALUE;
L1E: 
L1C: 

    /** scinot.e:444			mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_10606, _frac_bits_10605, _int_bits_10604);

    /** scinot.e:445			mbits = repeat( 0, significand + 1 ) & mbits*/
    _6025 = _significand_10609 + 1;
    _6026 = Repeat(0LL, _6025);
    _6025 = NOVALUE;
    Concat((object_ptr)&_mbits_10606, _6026, _mbits_10606);
    DeRefDS(_6026);
    _6026 = NOVALUE;
    DeRef(_6026);
    _6026 = NOVALUE;

    /** scinot.e:447			if exp > min_exp then*/
    if (_exp_10603 <= _min_exp_10611)
    goto L1F; // [774] 877

    /** scinot.e:449				if mbits[$-(significand+1)] then*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6029 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6029 = 1;
    }
    _6030 = _significand_10609 + 1;
    if (_6030 > MAXINT){
        _6030 = NewDouble((eudouble)_6030);
    }
    if (IS_ATOM_INT(_6030)) {
        _6031 = _6029 - _6030;
    }
    else {
        _6031 = NewDouble((eudouble)_6029 - DBL_PTR(_6030)->dbl);
    }
    _6029 = NOVALUE;
    DeRef(_6030);
    _6030 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    if (!IS_ATOM_INT(_6031)){
        _6032 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_6031)->dbl));
    }
    else{
        _6032 = (object)*(((s1_ptr)_2)->base + _6031);
    }
    if (_6032 == 0) {
        _6032 = NOVALUE;
        goto L20; // [795] 829
    }
    else {
        if (!IS_ATOM_INT(_6032) && DBL_PTR(_6032)->dbl == 0.0){
            _6032 = NOVALUE;
            goto L20; // [795] 829
        }
        _6032 = NOVALUE;
    }
    _6032 = NOVALUE;

    /** scinot.e:451					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6033 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6033 = 1;
    }
    _6034 = _6033 - _significand_10609;
    _6033 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    _6035 = (object)*(((s1_ptr)_2)->base + _6034);
    if (IS_ATOM_INT(_6035)) {
        _6036 = _6035 + 1;
        if (_6036 > MAXINT){
            _6036 = NewDouble((eudouble)_6036);
        }
    }
    else
    _6036 = binary_op(PLUS, 1, _6035);
    _6035 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_10606 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _6034);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6036;
    if( _1 != _6036 ){
        DeRef(_1);
    }
    _6036 = NOVALUE;

    /** scinot.e:452					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_10606);
    _0 = _mbits_10606;
    _mbits_10606 = _28carry(_mbits_10606, 2LL);
    DeRefDS(_0);
L20: 

    /** scinot.e:454				if fp = DOUBLE then*/
    if (_fp_10600 != 2LL)
    goto L21; // [831] 859

    /** scinot.e:456					mbits = mbits[$-significand..$-1]*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6039 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6039 = 1;
    }
    _6040 = _6039 - _significand_10609;
    if ((object)((uintptr_t)_6040 +(uintptr_t) HIGH_BITS) >= 0){
        _6040 = NewDouble((eudouble)_6040);
    }
    _6039 = NOVALUE;
    if (IS_SEQUENCE(_mbits_10606)){
            _6041 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6041 = 1;
    }
    _6042 = _6041 - 1LL;
    _6041 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_10606;
    RHS_Slice(_mbits_10606, _6040, _6042);
    goto L22; // [856] 939
L21: 

    /** scinot.e:459					mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6044 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6044 = 1;
    }
    _6045 = _6044 - _significand_10609;
    if ((object)((uintptr_t)_6045 +(uintptr_t) HIGH_BITS) >= 0){
        _6045 = NewDouble((eudouble)_6045);
    }
    _6044 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_10606);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(_6045)) ? _6045 : (object)(DBL_PTR(_6045)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_10606), start, &_mbits_10606 );
            }
            else Tail(SEQ_PTR(_mbits_10606), stop+1, &_mbits_10606);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_10606), start, &_mbits_10606);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_10606 = Remove_elements(start, stop, (SEQ_PTR(_mbits_10606)->ref == 1));
        }
    }
    DeRef(_6045);
    _6045 = NOVALUE;
    goto L22; // [874] 939
L1F: 

    /** scinot.e:463				if mbits[$-significand] then*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6047 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6047 = 1;
    }
    _6048 = _6047 - _significand_10609;
    _6047 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    _6049 = (object)*(((s1_ptr)_2)->base + _6048);
    if (_6049 == 0) {
        _6049 = NOVALUE;
        goto L23; // [890] 924
    }
    else {
        if (!IS_ATOM_INT(_6049) && DBL_PTR(_6049)->dbl == 0.0){
            _6049 = NOVALUE;
            goto L23; // [890] 924
        }
        _6049 = NOVALUE;
    }
    _6049 = NOVALUE;

    /** scinot.e:465					mbits[$-significand] += 1*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6050 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6050 = 1;
    }
    _6051 = _6050 - _significand_10609;
    _6050 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    _6052 = (object)*(((s1_ptr)_2)->base + _6051);
    if (IS_ATOM_INT(_6052)) {
        _6053 = _6052 + 1;
        if (_6053 > MAXINT){
            _6053 = NewDouble((eudouble)_6053);
        }
    }
    else
    _6053 = binary_op(PLUS, 1, _6052);
    _6052 = NOVALUE;
    _2 = (object)SEQ_PTR(_mbits_10606);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _mbits_10606 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _6051);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _6053;
    if( _1 != _6053 ){
        DeRef(_1);
    }
    _6053 = NOVALUE;

    /** scinot.e:466					mbits = carry( mbits, 2 )*/
    RefDS(_mbits_10606);
    _0 = _mbits_10606;
    _mbits_10606 = _28carry(_mbits_10606, 2LL);
    DeRefDS(_0);
L23: 

    /** scinot.e:468				mbits = remove( mbits, 1, length(mbits) - significand )*/
    if (IS_SEQUENCE(_mbits_10606)){
            _6055 = SEQ_PTR(_mbits_10606)->length;
    }
    else {
        _6055 = 1;
    }
    _6056 = _6055 - _significand_10609;
    if ((object)((uintptr_t)_6056 +(uintptr_t) HIGH_BITS) >= 0){
        _6056 = NewDouble((eudouble)_6056);
    }
    _6055 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_mbits_10606);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1LL)) ? 1LL : (object)(DBL_PTR(1LL)->dbl);
        int stop = (IS_ATOM_INT(_6056)) ? _6056 : (object)(DBL_PTR(_6056)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_mbits_10606), start, &_mbits_10606 );
            }
            else Tail(SEQ_PTR(_mbits_10606), stop+1, &_mbits_10606);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_mbits_10606), start, &_mbits_10606);
        }
        else {
            assign_slice_seq = &assign_space;
            _mbits_10606 = Remove_elements(start, stop, (SEQ_PTR(_mbits_10606)->ref == 1));
        }
    }
    DeRef(_6056);
    _6056 = NOVALUE;
L22: 
L1A: 

    /** scinot.e:474		ebits = int_to_bits( exp + exp_bias, exponent )*/
    _6058 = _exp_10603 + _exp_bias_10612;
    if ((object)((uintptr_t)_6058 + (uintptr_t)HIGH_BITS) >= 0){
        _6058 = NewDouble((eudouble)_6058);
    }
    _0 = _ebits_10607;
    _ebits_10607 = _15int_to_bits(_6058, _exponent_10610);
    DeRef(_0);
    _6058 = NOVALUE;

    /** scinot.e:477		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        object concat_list[3];

        concat_list[0] = _sbits_10608;
        concat_list[1] = _ebits_10607;
        concat_list[2] = _mbits_10606;
        Concat_N((object_ptr)&_6060, concat_list, 3);
    }
    _6061 = _28bits_to_bytes(_6060);
    _6060 = NOVALUE;
    DeRefDS(_s_10599);
    DeRef(_int_bits_10604);
    DeRef(_frac_bits_10605);
    DeRefDS(_mbits_10606);
    DeRefDS(_ebits_10607);
    DeRefDSi(_sbits_10608);
    DeRef(_5992);
    _5992 = NOVALUE;
    DeRef(_5925);
    _5925 = NOVALUE;
    DeRef(_5947);
    _5947 = NOVALUE;
    DeRef(_5996);
    _5996 = NOVALUE;
    DeRef(_5990);
    _5990 = NOVALUE;
    DeRef(_6031);
    _6031 = NOVALUE;
    DeRef(_6034);
    _6034 = NOVALUE;
    DeRef(_6048);
    _6048 = NOVALUE;
    DeRef(_5933);
    _5933 = NOVALUE;
    DeRef(_6005);
    _6005 = NOVALUE;
    DeRef(_5982);
    _5982 = NOVALUE;
    DeRef(_5954);
    _5954 = NOVALUE;
    DeRef(_6001);
    _6001 = NOVALUE;
    DeRef(_6051);
    _6051 = NOVALUE;
    DeRef(_5938);
    _5938 = NOVALUE;
    DeRef(_5956);
    _5956 = NOVALUE;
    DeRef(_6042);
    _6042 = NOVALUE;
    DeRef(_5922);
    _5922 = NOVALUE;
    DeRef(_6040);
    _6040 = NOVALUE;
    DeRef(_5930);
    _5930 = NOVALUE;
    DeRef(_5974);
    _5974 = NOVALUE;
    return _6061;
    ;
}


object _28scientific_to_atom(object _s_10806, object _fp_10807)
{
    object _float_10810 = NOVALUE;
    object _6067 = NOVALUE;
    object _6065 = NOVALUE;
    object _0, _1, _2;
    

    /** scinot.e:495		if fp = NATIVE then*/
    if (_fp_10807 != 1LL)
    goto L1; // [5] 17

    /** scinot.e:496			fp = NATIVE_FORMAT*/
    _fp_10807 = _28NATIVE_FORMAT_10354;
L1: 

    /** scinot.e:498		sequence float = scientific_to_float( s, fp )*/
    RefDS(_s_10806);
    _0 = _float_10810;
    _float_10810 = _28scientific_to_float(_s_10806, _fp_10807);
    DeRef(_0);

    /** scinot.e:499		if fp = DOUBLE then*/
    if (_fp_10807 != 2LL)
    goto L2; // [28] 45

    /** scinot.e:500			return float64_to_atom( float )*/
    RefDS(_float_10810);
    _6065 = _15float64_to_atom(_float_10810);
    DeRefDS(_s_10806);
    DeRefDS(_float_10810);
    return _6065;
    goto L3; // [42] 63
L2: 

    /** scinot.e:501		elsif fp = EXTENDED then*/
    if (_fp_10807 != 3LL)
    goto L4; // [47] 62

    /** scinot.e:502			return float80_to_atom( float )*/
    RefDS(_float_10810);
    _6067 = _15float80_to_atom(_float_10810);
    DeRefDS(_s_10806);
    DeRefDS(_float_10810);
    DeRef(_6065);
    _6065 = NOVALUE;
    return _6067;
L4: 
L3: 
    ;
}



// 0x6A659CD2
