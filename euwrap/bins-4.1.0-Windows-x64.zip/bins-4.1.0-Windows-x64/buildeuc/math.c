// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _20abs(object _a_3382)
{
    object _t_3383 = NOVALUE;
    object _1645 = NOVALUE;
    object _1644 = NOVALUE;
    object _1643 = NOVALUE;
    object _1641 = NOVALUE;
    object _1639 = NOVALUE;
    object _1638 = NOVALUE;
    object _1636 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:58		if atom(a) then*/
    _1636 = IS_ATOM(_a_3382);
    if (_1636 == 0)
    {
        _1636 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _1636 = NOVALUE;
    }

    /** math.e:59			if a >= 0 then*/
    if (binary_op_a(LESS, _a_3382, 0LL)){
        goto L2; // [11] 24
    }

    /** math.e:60				return a*/
    DeRef(_t_3383);
    return _a_3382;
    goto L3; // [21] 34
L2: 

    /** math.e:62				return - a*/
    if (IS_ATOM_INT(_a_3382)) {
        if ((uintptr_t)_a_3382 == (uintptr_t)HIGH_BITS){
            _1638 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _1638 = - _a_3382;
        }
    }
    else {
        _1638 = unary_op(UMINUS, _a_3382);
    }
    DeRef(_a_3382);
    DeRef(_t_3383);
    return _1638;
L3: 
L1: 

    /** math.e:65		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3382)){
            _1639 = SEQ_PTR(_a_3382)->length;
    }
    else {
        _1639 = 1;
    }
    {
        object _i_3391;
        _i_3391 = 1LL;
L4: 
        if (_i_3391 > _1639){
            goto L5; // [40] 101
        }

        /** math.e:66			t = a[i]*/
        DeRef(_t_3383);
        _2 = (object)SEQ_PTR(_a_3382);
        _t_3383 = (object)*(((s1_ptr)_2)->base + _i_3391);
        Ref(_t_3383);

        /** math.e:67			if atom(t) then*/
        _1641 = IS_ATOM(_t_3383);
        if (_1641 == 0)
        {
            _1641 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _1641 = NOVALUE;
        }

        /** math.e:68				if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_3383, 0LL)){
            goto L7; // [63] 94
        }

        /** math.e:69					a[i] = - t*/
        if (IS_ATOM_INT(_t_3383)) {
            if ((uintptr_t)_t_3383 == (uintptr_t)HIGH_BITS){
                _1643 = (object)NewDouble((eudouble) -HIGH_BITS);
            }
            else{
                _1643 = - _t_3383;
            }
        }
        else {
            _1643 = unary_op(UMINUS, _t_3383);
        }
        _2 = (object)SEQ_PTR(_a_3382);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_3382 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_3391);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1643;
        if( _1 != _1643 ){
            DeRef(_1);
        }
        _1643 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** math.e:72				a[i] = abs(t)*/
        Ref(_t_3383);
        DeRef(_1644);
        _1644 = _t_3383;
        _1645 = _20abs(_1644);
        _1644 = NOVALUE;
        _2 = (object)SEQ_PTR(_a_3382);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _a_3382 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_3391);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _1645;
        if( _1 != _1645 ){
            DeRef(_1);
        }
        _1645 = NOVALUE;
L7: 

        /** math.e:74		end for*/
        _i_3391 = _i_3391 + 1LL;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** math.e:75		return a*/
    DeRef(_t_3383);
    DeRef(_1638);
    _1638 = NOVALUE;
    return _a_3382;
    ;
}


object _20max(object _a_3426)
{
    object _b_3427 = NOVALUE;
    object _c_3428 = NOVALUE;
    object _1655 = NOVALUE;
    object _1654 = NOVALUE;
    object _1653 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:199		if atom(a) then*/
    _1653 = IS_ATOM(_a_3426);
    if (_1653 == 0)
    {
        _1653 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1653 = NOVALUE;
    }

    /** math.e:200			return a*/
    DeRef(_b_3427);
    DeRef(_c_3428);
    return _a_3426;
L1: 

    /** math.e:202		b = mathcons:MINF*/
    Ref(_22MINF_3360);
    DeRef(_b_3427);
    _b_3427 = _22MINF_3360;

    /** math.e:203		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3426)){
            _1654 = SEQ_PTR(_a_3426)->length;
    }
    else {
        _1654 = 1;
    }
    {
        object _i_3432;
        _i_3432 = 1LL;
L2: 
        if (_i_3432 > _1654){
            goto L3; // [28] 64
        }

        /** math.e:204			c = max(a[i])*/
        _2 = (object)SEQ_PTR(_a_3426);
        _1655 = (object)*(((s1_ptr)_2)->base + _i_3432);
        Ref(_1655);
        _0 = _c_3428;
        _c_3428 = _20max(_1655);
        DeRef(_0);
        _1655 = NOVALUE;

        /** math.e:205			if c > b then*/
        if (binary_op_a(LESSEQ, _c_3428, _b_3427)){
            goto L4; // [47] 57
        }

        /** math.e:206				b = c*/
        Ref(_c_3428);
        DeRef(_b_3427);
        _b_3427 = _c_3428;
L4: 

        /** math.e:208		end for*/
        _i_3432 = _i_3432 + 1LL;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:209		return b*/
    DeRef(_a_3426);
    DeRef(_c_3428);
    return _b_3427;
    ;
}


object _20min(object _a_3440)
{
    object _b_3441 = NOVALUE;
    object _c_3442 = NOVALUE;
    object _1660 = NOVALUE;
    object _1659 = NOVALUE;
    object _1658 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:232		if atom(a) then*/
    _1658 = IS_ATOM(_a_3440);
    if (_1658 == 0)
    {
        _1658 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1658 = NOVALUE;
    }

    /** math.e:233				return a*/
    DeRef(_b_3441);
    DeRef(_c_3442);
    return _a_3440;
L1: 

    /** math.e:235		b = mathcons:PINF*/
    Ref(_22PINF_3358);
    DeRef(_b_3441);
    _b_3441 = _22PINF_3358;

    /** math.e:236		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3440)){
            _1659 = SEQ_PTR(_a_3440)->length;
    }
    else {
        _1659 = 1;
    }
    {
        object _i_3446;
        _i_3446 = 1LL;
L2: 
        if (_i_3446 > _1659){
            goto L3; // [28] 64
        }

        /** math.e:237			c = min(a[i])*/
        _2 = (object)SEQ_PTR(_a_3440);
        _1660 = (object)*(((s1_ptr)_2)->base + _i_3446);
        Ref(_1660);
        _0 = _c_3442;
        _c_3442 = _20min(_1660);
        DeRef(_0);
        _1660 = NOVALUE;

        /** math.e:238				if c < b then*/
        if (binary_op_a(GREATEREQ, _c_3442, _b_3441)){
            goto L4; // [47] 57
        }

        /** math.e:239					b = c*/
        Ref(_c_3442);
        DeRef(_b_3441);
        _b_3441 = _c_3442;
L4: 

        /** math.e:241		end for*/
        _i_3446 = _i_3446 + 1LL;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** math.e:242		return b*/
    DeRef(_a_3440);
    DeRef(_c_3442);
    return _b_3441;
    ;
}


object _20or_all(object _a_3819)
{
    object _b_3820 = NOVALUE;
    object _1859 = NOVALUE;
    object _1858 = NOVALUE;
    object _1856 = NOVALUE;
    object _1855 = NOVALUE;
    object _1854 = NOVALUE;
    object _1853 = NOVALUE;
    object _1852 = NOVALUE;
    object _0, _1, _2;
    

    /** math.e:1469		if atom(a) then*/
    _1852 = IS_ATOM(_a_3819);
    if (_1852 == 0)
    {
        _1852 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1852 = NOVALUE;
    }

    /** math.e:1470			return a*/
    DeRef(_b_3820);
    return _a_3819;
L1: 

    /** math.e:1472		b = 0*/
    DeRef(_b_3820);
    _b_3820 = 0LL;

    /** math.e:1473		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3819)){
            _1853 = SEQ_PTR(_a_3819)->length;
    }
    else {
        _1853 = 1;
    }
    {
        object _i_3824;
        _i_3824 = 1LL;
L2: 
        if (_i_3824 > _1853){
            goto L3; // [26] 80
        }

        /** math.e:1474			if atom(a[i]) then*/
        _2 = (object)SEQ_PTR(_a_3819);
        _1854 = (object)*(((s1_ptr)_2)->base + _i_3824);
        _1855 = IS_ATOM(_1854);
        _1854 = NOVALUE;
        if (_1855 == 0)
        {
            _1855 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _1855 = NOVALUE;
        }

        /** math.e:1475				b = or_bits(b, a[i])*/
        _2 = (object)SEQ_PTR(_a_3819);
        _1856 = (object)*(((s1_ptr)_2)->base + _i_3824);
        _0 = _b_3820;
        if (IS_ATOM_INT(_b_3820) && IS_ATOM_INT(_1856)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_3820 | (uintptr_t)_1856;
                 _b_3820 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3820 = binary_op(OR_BITS, _b_3820, _1856);
        }
        DeRef(_0);
        _1856 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** math.e:1477				b = or_bits(b, or_all(a[i]))*/
        _2 = (object)SEQ_PTR(_a_3819);
        _1858 = (object)*(((s1_ptr)_2)->base + _i_3824);
        Ref(_1858);
        _1859 = _20or_all(_1858);
        _1858 = NOVALUE;
        _0 = _b_3820;
        if (IS_ATOM_INT(_b_3820) && IS_ATOM_INT(_1859)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_b_3820 | (uintptr_t)_1859;
                 _b_3820 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3820 = binary_op(OR_BITS, _b_3820, _1859);
        }
        DeRef(_0);
        DeRef(_1859);
        _1859 = NOVALUE;
L5: 

        /** math.e:1479		end for*/
        _i_3824 = _i_3824 + 1LL;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** math.e:1480		return b*/
    DeRef(_a_3819);
    return _b_3820;
    ;
}



// 0x44EA1344
