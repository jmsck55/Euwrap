// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _58get_eucompiledir()
{
    object _x_42907 = NOVALUE;
    object _22553 = NOVALUE;
    object _22549 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:133		object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_42907);
    _x_42907 = EGetEnv(_22547);

    /** c_decl.e:134		if is_eudir_from_cmdline() then*/
    _22549 = _37is_eudir_from_cmdline();
    if (_22549 == 0) {
        DeRef(_22549);
        _22549 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22549) && DBL_PTR(_22549)->dbl == 0.0){
            DeRef(_22549);
            _22549 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22549);
        _22549 = NOVALUE;
    }
    DeRef(_22549);
    _22549 = NOVALUE;

    /** c_decl.e:135			x = get_eudir()*/
    _0 = _x_42907;
    _x_42907 = _37get_eudir();
    DeRefi(_0);
L1: 

    /** c_decl.e:138		ifdef UNIX then*/

    /** c_decl.e:152		if equal(x, -1) then*/
    if (_x_42907 == -1LL)
    _22553 = 1;
    else if (IS_ATOM_INT(_x_42907) && IS_ATOM_INT(-1LL))
    _22553 = 0;
    else
    _22553 = (compare(_x_42907, -1LL) == 0);
    if (_22553 == 0)
    {
        _22553 = NOVALUE;
        goto L2; // [28] 37
    }
    else{
        _22553 = NOVALUE;
    }

    /** c_decl.e:153			x = get_eudir()*/
    _0 = _x_42907;
    _x_42907 = _37get_eudir();
    DeRef(_0);
L2: 

    /** c_decl.e:156		return x*/
    return _x_42907;
    ;
}


void _58NewBB(object _a_call_42923, object _mask_42924, object _sub_42926)
{
    object _s_42928 = NOVALUE;
    object _22586 = NOVALUE;
    object _22585 = NOVALUE;
    object _22583 = NOVALUE;
    object _22582 = NOVALUE;
    object _22580 = NOVALUE;
    object _22579 = NOVALUE;
    object _22578 = NOVALUE;
    object _22577 = NOVALUE;
    object _22576 = NOVALUE;
    object _22575 = NOVALUE;
    object _22574 = NOVALUE;
    object _22573 = NOVALUE;
    object _22572 = NOVALUE;
    object _22571 = NOVALUE;
    object _22570 = NOVALUE;
    object _22569 = NOVALUE;
    object _22568 = NOVALUE;
    object _22567 = NOVALUE;
    object _22566 = NOVALUE;
    object _22565 = NOVALUE;
    object _22564 = NOVALUE;
    object _22563 = NOVALUE;
    object _22562 = NOVALUE;
    object _22561 = NOVALUE;
    object _22560 = NOVALUE;
    object _22559 = NOVALUE;
    object _22558 = NOVALUE;
    object _22556 = NOVALUE;
    object _22555 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_mask_42924)) {
        _1 = (object)(DBL_PTR(_mask_42924)->dbl);
        DeRefDS(_mask_42924);
        _mask_42924 = _1;
    }

    /** c_decl.e:166		if a_call then*/
    if (_a_call_42923 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** c_decl.e:169			for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22555 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22555 = 1;
    }
    {
        object _i_42931;
        _i_42931 = 1LL;
L2: 
        if (_i_42931 > _22555){
            goto L3; // [19] 249
        }

        /** c_decl.e:170				s = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22556 = (object)*(((s1_ptr)_2)->base + _i_42931);
        _2 = (object)SEQ_PTR(_22556);
        _s_42928 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_s_42928)){
            _s_42928 = (object)DBL_PTR(_s_42928)->dbl;
        }
        _22556 = NOVALUE;

        /** c_decl.e:171				if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22558 = (object)*(((s1_ptr)_2)->base + _s_42928);
        _2 = (object)SEQ_PTR(_22558);
        _22559 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22558 = NOVALUE;
        if (IS_ATOM_INT(_22559)) {
            _22560 = (_22559 == 1LL);
        }
        else {
            _22560 = binary_op(EQUALS, _22559, 1LL);
        }
        _22559 = NOVALUE;
        if (IS_ATOM_INT(_22560)) {
            if (_22560 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22560)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22562 = (object)*(((s1_ptr)_2)->base + _s_42928);
        _2 = (object)SEQ_PTR(_22562);
        _22563 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22562 = NOVALUE;
        if (IS_ATOM_INT(_22563)) {
            _22564 = (_22563 == 6LL);
        }
        else {
            _22564 = binary_op(EQUALS, _22563, 6LL);
        }
        _22563 = NOVALUE;
        if (IS_ATOM_INT(_22564)) {
            if (_22564 != 0) {
                DeRef(_22565);
                _22565 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22564)->dbl != 0.0) {
                DeRef(_22565);
                _22565 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22566 = (object)*(((s1_ptr)_2)->base + _s_42928);
        _2 = (object)SEQ_PTR(_22566);
        _22567 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22566 = NOVALUE;
        if (IS_ATOM_INT(_22567)) {
            _22568 = (_22567 == 5LL);
        }
        else {
            _22568 = binary_op(EQUALS, _22567, 5LL);
        }
        _22567 = NOVALUE;
        DeRef(_22565);
        if (IS_ATOM_INT(_22568))
        _22565 = (_22568 != 0);
        else
        _22565 = DBL_PTR(_22568)->dbl != 0.0;
L5: 
        if (_22565 != 0) {
            _22569 = 1;
            goto L6; // [108] 134
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22570 = (object)*(((s1_ptr)_2)->base + _s_42928);
        _2 = (object)SEQ_PTR(_22570);
        _22571 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22570 = NOVALUE;
        if (IS_ATOM_INT(_22571)) {
            _22572 = (_22571 == 11LL);
        }
        else {
            _22572 = binary_op(EQUALS, _22571, 11LL);
        }
        _22571 = NOVALUE;
        if (IS_ATOM_INT(_22572))
        _22569 = (_22572 != 0);
        else
        _22569 = DBL_PTR(_22572)->dbl != 0.0;
L6: 
        if (_22569 != 0) {
            DeRef(_22573);
            _22573 = 1;
            goto L7; // [134] 160
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22574 = (object)*(((s1_ptr)_2)->base + _s_42928);
        _2 = (object)SEQ_PTR(_22574);
        _22575 = (object)*(((s1_ptr)_2)->base + 4LL);
        _22574 = NOVALUE;
        if (IS_ATOM_INT(_22575)) {
            _22576 = (_22575 == 13LL);
        }
        else {
            _22576 = binary_op(EQUALS, _22575, 13LL);
        }
        _22575 = NOVALUE;
        if (IS_ATOM_INT(_22576))
        _22573 = (_22576 != 0);
        else
        _22573 = DBL_PTR(_22576)->dbl != 0.0;
L7: 
        if (_22573 == 0)
        {
            _22573 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22573 = NOVALUE;
        }

        /** c_decl.e:176					  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22577 = (_s_42928 % 29LL);
        _22578 = power(2LL, _22577);
        _22577 = NOVALUE;
        if (IS_ATOM_INT(_22578)) {
            {uintptr_t tu;
                 tu = (uintptr_t)_mask_42924 & (uintptr_t)_22578;
                 _22579 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (eudouble)_mask_42924;
            _22579 = Dand_bits(&temp_d, DBL_PTR(_22578));
        }
        DeRef(_22578);
        _22578 = NOVALUE;
        if (_22579 == 0) {
            DeRef(_22579);
            _22579 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22579) && DBL_PTR(_22579)->dbl == 0.0){
                DeRef(_22579);
                _22579 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22579);
            _22579 = NOVALUE;
        }
        DeRef(_22579);
        _22579 = NOVALUE;

        /** c_decl.e:177						  if mask = E_ALL_EFFECT or s < sub then*/
        _22580 = (_mask_42924 == 1073741823LL);
        if (_22580 != 0) {
            goto L9; // [191] 204
        }
        _22582 = (_s_42928 < _sub_42926);
        if (_22582 == 0)
        {
            DeRef(_22582);
            _22582 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22582);
            _22582 = NOVALUE;
        }
L9: 

        /** c_decl.e:178							  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _58BB_info_42885 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_42931 + ((s1_ptr)_2)->base);
        Ref(_36MAXINT_21582);
        Ref(_36MININT_21583);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _36MININT_21583;
        ((intptr_t *)_2)[2] = _36MAXINT_21582;
        _22585 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = 0LL;
        ((intptr_t*)_2)[2] = 0LL;
        Ref(_36NOVALUE_21613);
        ((intptr_t*)_2)[3] = _36NOVALUE_21613;
        ((intptr_t*)_2)[4] = _22585;
        _22586 = MAKE_SEQ(_1);
        _22585 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2LL, 5LL, _22586);
        DeRefDS(_22586);
        _22586 = NOVALUE;
LA: 
L8: 
L4: 

        /** c_decl.e:183			end for*/
        _i_42931 = _i_42931 + 1LL;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** c_decl.e:186			BB_info = {}*/
    RefDS(_22186);
    DeRef(_58BB_info_42885);
    _58BB_info_42885 = _22186;
LB: 

    /** c_decl.e:188	end procedure*/
    DeRef(_22568);
    _22568 = NOVALUE;
    DeRef(_22572);
    _22572 = NOVALUE;
    DeRef(_22583);
    _22583 = NOVALUE;
    DeRef(_22576);
    _22576 = NOVALUE;
    DeRef(_22564);
    _22564 = NOVALUE;
    DeRef(_22560);
    _22560 = NOVALUE;
    DeRef(_22580);
    _22580 = NOVALUE;
    return;
    ;
}


object _58BB_var_obj(object _var_42996)
{
    object _bbi_42997 = NOVALUE;
    object _22597 = NOVALUE;
    object _22595 = NOVALUE;
    object _22593 = NOVALUE;
    object _22592 = NOVALUE;
    object _22590 = NOVALUE;
    object _22588 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:196		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22588 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22588 = 1;
    }
    {
        object _i_42999;
        _i_42999 = _22588;
L1: 
        if (_i_42999 < 1LL){
            goto L2; // [10] 99
        }

        /** c_decl.e:197			bbi = BB_info[i]*/
        DeRef(_bbi_42997);
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _bbi_42997 = (object)*(((s1_ptr)_2)->base + _i_42999);
        Ref(_bbi_42997);

        /** c_decl.e:198			if bbi[BB_VAR] != var then*/
        _2 = (object)SEQ_PTR(_bbi_42997);
        _22590 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (binary_op_a(EQUALS, _22590, _var_42996)){
            _22590 = NOVALUE;
            goto L3; // [31] 40
        }
        _22590 = NOVALUE;

        /** c_decl.e:199				continue*/
        goto L4; // [37] 94
L3: 

        /** c_decl.e:202			if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _22592 = (object)*(((s1_ptr)_2)->base + _var_42996);
        _2 = (object)SEQ_PTR(_22592);
        _22593 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22592 = NOVALUE;
        if (binary_op_a(EQUALS, _22593, 1LL)){
            _22593 = NOVALUE;
            goto L5; // [56] 65
        }
        _22593 = NOVALUE;

        /** c_decl.e:203				continue*/
        goto L4; // [62] 94
L5: 

        /** c_decl.e:206			if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (object)SEQ_PTR(_bbi_42997);
        _22595 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (binary_op_a(EQUALS, _22595, 1LL)){
            _22595 = NOVALUE;
            goto L6; // [73] 82
        }
        _22595 = NOVALUE;

        /** c_decl.e:207				exit*/
        goto L2; // [79] 99
L6: 

        /** c_decl.e:210			return bbi[BB_OBJ]*/
        _2 = (object)SEQ_PTR(_bbi_42997);
        _22597 = (object)*(((s1_ptr)_2)->base + 5LL);
        Ref(_22597);
        DeRef(_bbi_42997);
        return _22597;

        /** c_decl.e:211		end for*/
L4: 
        _i_42999 = _i_42999 + -1LL;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** c_decl.e:212		return BB_def_values*/
    RefDS(_58BB_def_values_42990);
    DeRef(_bbi_42997);
    _22597 = NOVALUE;
    return _58BB_def_values_42990;
    ;
}


object _58BB_var_type(object _var_43019)
{
    object _22612 = NOVALUE;
    object _22611 = NOVALUE;
    object _22609 = NOVALUE;
    object _22608 = NOVALUE;
    object _22607 = NOVALUE;
    object _22606 = NOVALUE;
    object _22605 = NOVALUE;
    object _22604 = NOVALUE;
    object _22603 = NOVALUE;
    object _22602 = NOVALUE;
    object _22601 = NOVALUE;
    object _22600 = NOVALUE;
    object _22599 = NOVALUE;
    object _22598 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:218		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22598 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22598 = 1;
    }
    {
        object _i_43021;
        _i_43021 = _22598;
L1: 
        if (_i_43021 < 1LL){
            goto L2; // [10] 125
        }

        /** c_decl.e:219			if BB_info[i][BB_VAR] = var and*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22599 = (object)*(((s1_ptr)_2)->base + _i_43021);
        _2 = (object)SEQ_PTR(_22599);
        _22600 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22599 = NOVALUE;
        if (IS_ATOM_INT(_22600)) {
            _22601 = (_22600 == _var_43019);
        }
        else {
            _22601 = binary_op(EQUALS, _22600, _var_43019);
        }
        _22600 = NOVALUE;
        if (IS_ATOM_INT(_22601)) {
            if (_22601 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22601)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22603 = (object)*(((s1_ptr)_2)->base + _i_43021);
        _2 = (object)SEQ_PTR(_22603);
        _22604 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22603 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!IS_ATOM_INT(_22604)){
            _22605 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22604)->dbl));
        }
        else{
            _22605 = (object)*(((s1_ptr)_2)->base + _22604);
        }
        _2 = (object)SEQ_PTR(_22605);
        _22606 = (object)*(((s1_ptr)_2)->base + 3LL);
        _22605 = NOVALUE;
        if (IS_ATOM_INT(_22606)) {
            _22607 = (_22606 == 1LL);
        }
        else {
            _22607 = binary_op(EQUALS, _22606, 1LL);
        }
        _22606 = NOVALUE;
        if (_22607 == 0) {
            DeRef(_22607);
            _22607 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22607) && DBL_PTR(_22607)->dbl == 0.0){
                DeRef(_22607);
                _22607 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22607);
            _22607 = NOVALUE;
        }
        DeRef(_22607);
        _22607 = NOVALUE;

        /** c_decl.e:221				ifdef DEBUG then*/

        /** c_decl.e:228				if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22608 = (object)*(((s1_ptr)_2)->base + _i_43021);
        _2 = (object)SEQ_PTR(_22608);
        _22609 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22608 = NOVALUE;
        if (binary_op_a(NOTEQ, _22609, 0LL)){
            _22609 = NOVALUE;
            goto L4; // [85] 100
        }
        _22609 = NOVALUE;

        /** c_decl.e:229					return TYPE_OBJECT*/
        DeRef(_22601);
        _22601 = NOVALUE;
        _22604 = NOVALUE;
        return 16LL;
        goto L5; // [97] 117
L4: 

        /** c_decl.e:231					return BB_info[i][BB_TYPE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22611 = (object)*(((s1_ptr)_2)->base + _i_43021);
        _2 = (object)SEQ_PTR(_22611);
        _22612 = (object)*(((s1_ptr)_2)->base + 2LL);
        _22611 = NOVALUE;
        Ref(_22612);
        DeRef(_22601);
        _22601 = NOVALUE;
        _22604 = NOVALUE;
        return _22612;
L5: 
L3: 

        /** c_decl.e:234		end for*/
        _i_43021 = _i_43021 + -1LL;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** c_decl.e:235		return TYPE_OBJECT*/
    DeRef(_22601);
    _22601 = NOVALUE;
    _22604 = NOVALUE;
    _22612 = NOVALUE;
    return 16LL;
    ;
}


object _58GType(object _s_43049)
{
    object _t_43050 = NOVALUE;
    object _local_t_43051 = NOVALUE;
    object _22616 = NOVALUE;
    object _22615 = NOVALUE;
    object _22613 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43049)) {
        _1 = (object)(DBL_PTR(_s_43049)->dbl);
        DeRefDS(_s_43049);
        _s_43049 = _1;
    }

    /** c_decl.e:243		t = SymTab[s][S_GTYPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22613 = (object)*(((s1_ptr)_2)->base + _s_43049);
    _2 = (object)SEQ_PTR(_22613);
    _t_43050 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (!IS_ATOM_INT(_t_43050)){
        _t_43050 = (object)DBL_PTR(_t_43050)->dbl;
    }
    _22613 = NOVALUE;

    /** c_decl.e:244		ifdef DEBUG then*/

    /** c_decl.e:250		if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22615 = (object)*(((s1_ptr)_2)->base + _s_43049);
    _2 = (object)SEQ_PTR(_22615);
    _22616 = (object)*(((s1_ptr)_2)->base + 3LL);
    _22615 = NOVALUE;
    if (binary_op_a(EQUALS, _22616, 1LL)){
        _22616 = NOVALUE;
        goto L1; // [37] 48
    }
    _22616 = NOVALUE;

    /** c_decl.e:251			return t*/
    return _t_43050;
L1: 

    /** c_decl.e:254		local_t = BB_var_type(s)*/
    _local_t_43051 = _58BB_var_type(_s_43049);
    if (!IS_ATOM_INT(_local_t_43051)) {
        _1 = (object)(DBL_PTR(_local_t_43051)->dbl);
        DeRefDS(_local_t_43051);
        _local_t_43051 = _1;
    }

    /** c_decl.e:255		if local_t = TYPE_OBJECT then*/
    if (_local_t_43051 != 16LL)
    goto L2; // [60] 71

    /** c_decl.e:256			return t*/
    return _t_43050;
L2: 

    /** c_decl.e:258		if t = TYPE_INTEGER then*/
    if (_t_43050 != 1LL)
    goto L3; // [75] 88

    /** c_decl.e:259			return TYPE_INTEGER*/
    return 1LL;
L3: 

    /** c_decl.e:261		return local_t*/
    return _local_t_43051;
    ;
}


object _58GDelete()
{
    object _0, _1, _2;
    

    /** c_decl.e:269		return g_has_delete*/
    return _58g_has_delete_43071;
    ;
}


object _58HasDelete(object _s_43078)
{
    object _22631 = NOVALUE;
    object _22630 = NOVALUE;
    object _22628 = NOVALUE;
    object _22627 = NOVALUE;
    object _22626 = NOVALUE;
    object _22625 = NOVALUE;
    object _22623 = NOVALUE;
    object _22622 = NOVALUE;
    object _22621 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43078)) {
        _1 = (object)(DBL_PTR(_s_43078)->dbl);
        DeRefDS(_s_43078);
        _s_43078 = _1;
    }

    /** c_decl.e:274		for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22621 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22621 = 1;
    }
    {
        object _i_43080;
        _i_43080 = _22621;
L1: 
        if (_i_43080 < 1LL){
            goto L2; // [10] 57
        }

        /** c_decl.e:275			if BB_info[i][BB_VAR] = s then*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22622 = (object)*(((s1_ptr)_2)->base + _i_43080);
        _2 = (object)SEQ_PTR(_22622);
        _22623 = (object)*(((s1_ptr)_2)->base + 1LL);
        _22622 = NOVALUE;
        if (binary_op_a(NOTEQ, _22623, _s_43078)){
            _22623 = NOVALUE;
            goto L3; // [29] 50
        }
        _22623 = NOVALUE;

        /** c_decl.e:276				return BB_info[i][BB_DELETE]*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22625 = (object)*(((s1_ptr)_2)->base + _i_43080);
        _2 = (object)SEQ_PTR(_22625);
        _22626 = (object)*(((s1_ptr)_2)->base + 6LL);
        _22625 = NOVALUE;
        Ref(_22626);
        return _22626;
L3: 

        /** c_decl.e:278		end for*/
        _i_43080 = _i_43080 + -1LL;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** c_decl.e:279		if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22627 = (object)*(((s1_ptr)_2)->base + _s_43078);
    if (IS_SEQUENCE(_22627)){
            _22628 = SEQ_PTR(_22627)->length;
    }
    else {
        _22628 = 1;
    }
    _22627 = NOVALUE;
    if (_22628 >= 54LL)
    goto L4; // [70] 81

    /** c_decl.e:280			return 0*/
    _22627 = NOVALUE;
    _22626 = NOVALUE;
    return 0LL;
L4: 

    /** c_decl.e:282		return SymTab[s][S_HAS_DELETE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22630 = (object)*(((s1_ptr)_2)->base + _s_43078);
    _2 = (object)SEQ_PTR(_22630);
    _22631 = (object)*(((s1_ptr)_2)->base + 54LL);
    _22630 = NOVALUE;
    Ref(_22631);
    _22627 = NOVALUE;
    _22626 = NOVALUE;
    return _22631;
    ;
}


object _58ObjValue(object _s_43101)
{
    object _local_t_43102 = NOVALUE;
    object _st_43103 = NOVALUE;
    object _tmin_43104 = NOVALUE;
    object _tmax_43105 = NOVALUE;
    object _22644 = NOVALUE;
    object _22642 = NOVALUE;
    object _22641 = NOVALUE;
    object _22639 = NOVALUE;
    object _22636 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_43101)) {
        _1 = (object)(DBL_PTR(_s_43101)->dbl);
        DeRefDS(_s_43101);
        _s_43101 = _1;
    }

    /** c_decl.e:293		st = SymTab[s]*/
    DeRef(_st_43103);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _st_43103 = (object)*(((s1_ptr)_2)->base + _s_43101);
    Ref(_st_43103);

    /** c_decl.e:294		tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_43104);
    _2 = (object)SEQ_PTR(_st_43103);
    _tmin_43104 = (object)*(((s1_ptr)_2)->base + 30LL);
    Ref(_tmin_43104);

    /** c_decl.e:295		tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_43105);
    _2 = (object)SEQ_PTR(_st_43103);
    _tmax_43105 = (object)*(((s1_ptr)_2)->base + 31LL);
    Ref(_tmax_43105);

    /** c_decl.e:297		if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_43104, _tmax_43105)){
        goto L1; // [29] 41
    }

    /** c_decl.e:298			tmin = NOVALUE*/
    Ref(_36NOVALUE_21613);
    DeRef(_tmin_43104);
    _tmin_43104 = _36NOVALUE_21613;
L1: 

    /** c_decl.e:300		if st[S_MODE] != M_NORMAL then*/
    _2 = (object)SEQ_PTR(_st_43103);
    _22636 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(EQUALS, _22636, 1LL)){
        _22636 = NOVALUE;
        goto L2; // [51] 62
    }
    _22636 = NOVALUE;

    /** c_decl.e:301			return tmin*/
    DeRef(_local_t_43102);
    DeRef(_st_43103);
    DeRef(_tmax_43105);
    return _tmin_43104;
L2: 

    /** c_decl.e:305		local_t = BB_var_obj(s)*/
    _0 = _local_t_43102;
    _local_t_43102 = _58BB_var_obj(_s_43101);
    DeRef(_0);

    /** c_decl.e:306		if local_t[MIN] = NOVALUE then*/
    _2 = (object)SEQ_PTR(_local_t_43102);
    _22639 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _22639, _36NOVALUE_21613)){
        _22639 = NOVALUE;
        goto L3; // [80] 91
    }
    _22639 = NOVALUE;

    /** c_decl.e:307			return tmin*/
    DeRefDS(_local_t_43102);
    DeRef(_st_43103);
    DeRef(_tmax_43105);
    return _tmin_43104;
L3: 

    /** c_decl.e:310		if local_t[MIN] != local_t[MAX] then*/
    _2 = (object)SEQ_PTR(_local_t_43102);
    _22641 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_local_t_43102);
    _22642 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (binary_op_a(EQUALS, _22641, _22642)){
        _22641 = NOVALUE;
        _22642 = NOVALUE;
        goto L4; // [105] 116
    }
    _22641 = NOVALUE;
    _22642 = NOVALUE;

    /** c_decl.e:311			return tmin*/
    DeRefDS(_local_t_43102);
    DeRef(_st_43103);
    DeRef(_tmax_43105);
    return _tmin_43104;
L4: 

    /** c_decl.e:314		return local_t[MIN]*/
    _2 = (object)SEQ_PTR(_local_t_43102);
    _22644 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22644);
    DeRefDS(_local_t_43102);
    DeRef(_st_43103);
    DeRef(_tmin_43104);
    DeRef(_tmax_43105);
    return _22644;
    ;
}


object _58TypeIs(object _x_43136, object _typei_43137)
{
    object _22646 = NOVALUE;
    object _22645 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43136)) {
        _1 = (object)(DBL_PTR(_x_43136)->dbl);
        DeRefDS(_x_43136);
        _x_43136 = _1;
    }

    /** c_decl.e:319		return GType(x) = typei*/
    _22645 = _58GType(_x_43136);
    if (IS_ATOM_INT(_22645)) {
        _22646 = (_22645 == _typei_43137);
    }
    else {
        _22646 = binary_op(EQUALS, _22645, _typei_43137);
    }
    DeRef(_22645);
    _22645 = NOVALUE;
    return _22646;
    ;
}


object _58TypeIsIn(object _x_43142, object _types_43143)
{
    object _22648 = NOVALUE;
    object _22647 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43142)) {
        _1 = (object)(DBL_PTR(_x_43142)->dbl);
        DeRefDS(_x_43142);
        _x_43142 = _1;
    }

    /** c_decl.e:323		return find(GType(x), types)*/
    _22647 = _58GType(_x_43142);
    _22648 = find_from(_22647, _types_43143, 1LL);
    DeRef(_22647);
    _22647 = NOVALUE;
    DeRefDS(_types_43143);
    return _22648;
    ;
}


object _58TypeIsNot(object _x_43148, object _typei_43149)
{
    object _22650 = NOVALUE;
    object _22649 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43148)) {
        _1 = (object)(DBL_PTR(_x_43148)->dbl);
        DeRefDS(_x_43148);
        _x_43148 = _1;
    }

    /** c_decl.e:327		return GType(x) != typei*/
    _22649 = _58GType(_x_43148);
    if (IS_ATOM_INT(_22649)) {
        _22650 = (_22649 != _typei_43149);
    }
    else {
        _22650 = binary_op(NOTEQ, _22649, _typei_43149);
    }
    DeRef(_22649);
    _22649 = NOVALUE;
    return _22650;
    ;
}


object _58TypeIsNotIn(object _x_43154, object _types_43155)
{
    object _22653 = NOVALUE;
    object _22652 = NOVALUE;
    object _22651 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_43154)) {
        _1 = (object)(DBL_PTR(_x_43154)->dbl);
        DeRefDS(_x_43154);
        _x_43154 = _1;
    }

    /** c_decl.e:331		return not find(GType(x), types)*/
    _22651 = _58GType(_x_43154);
    _22652 = find_from(_22651, _types_43155, 1LL);
    DeRef(_22651);
    _22651 = NOVALUE;
    _22653 = (_22652 == 0);
    _22652 = NOVALUE;
    DeRefDS(_types_43155);
    return _22653;
    ;
}


object _58or_type(object _t1_43161, object _t2_43162)
{
    object _22673 = NOVALUE;
    object _22672 = NOVALUE;
    object _22671 = NOVALUE;
    object _22670 = NOVALUE;
    object _22665 = NOVALUE;
    object _22663 = NOVALUE;
    object _22658 = NOVALUE;
    object _22656 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_43161)) {
        _1 = (object)(DBL_PTR(_t1_43161)->dbl);
        DeRefDS(_t1_43161);
        _t1_43161 = _1;
    }
    if (!IS_ATOM_INT(_t2_43162)) {
        _1 = (object)(DBL_PTR(_t2_43162)->dbl);
        DeRefDS(_t2_43162);
        _t2_43162 = _1;
    }

    /** c_decl.e:337		if t1 = TYPE_NULL then*/
    if (_t1_43161 != 0LL)
    goto L1; // [9] 22

    /** c_decl.e:338			return t2*/
    return _t2_43162;
    goto L2; // [19] 307
L1: 

    /** c_decl.e:340		elsif t2 = TYPE_NULL then*/
    if (_t2_43162 != 0LL)
    goto L3; // [26] 39

    /** c_decl.e:341			return t1*/
    return _t1_43161;
    goto L2; // [36] 307
L3: 

    /** c_decl.e:343		elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22656 = (_t1_43161 == 16LL);
    if (_22656 != 0) {
        goto L4; // [47] 62
    }
    _22658 = (_t2_43162 == 16LL);
    if (_22658 == 0)
    {
        DeRef(_22658);
        _22658 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22658);
        _22658 = NOVALUE;
    }
L4: 

    /** c_decl.e:344			return TYPE_OBJECT*/
    DeRef(_22656);
    _22656 = NOVALUE;
    return 16LL;
    goto L2; // [70] 307
L5: 

    /** c_decl.e:346		elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_43161 != 8LL)
    goto L6; // [77] 112

    /** c_decl.e:347			if t2 = TYPE_SEQUENCE then*/
    if (_t2_43162 != 8LL)
    goto L7; // [85] 100

    /** c_decl.e:348				return TYPE_SEQUENCE*/
    DeRef(_22656);
    _22656 = NOVALUE;
    return 8LL;
    goto L2; // [97] 307
L7: 

    /** c_decl.e:350				return TYPE_OBJECT*/
    DeRef(_22656);
    _22656 = NOVALUE;
    return 16LL;
    goto L2; // [109] 307
L6: 

    /** c_decl.e:353		elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_43162 != 8LL)
    goto L8; // [116] 151

    /** c_decl.e:354			if t1 = TYPE_SEQUENCE then*/
    if (_t1_43161 != 8LL)
    goto L9; // [124] 139

    /** c_decl.e:355				return TYPE_SEQUENCE*/
    DeRef(_22656);
    _22656 = NOVALUE;
    return 8LL;
    goto L2; // [136] 307
L9: 

    /** c_decl.e:357				return TYPE_OBJECT*/
    DeRef(_22656);
    _22656 = NOVALUE;
    return 16LL;
    goto L2; // [148] 307
L8: 

    /** c_decl.e:360		elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22663 = (_t1_43161 == 4LL);
    if (_22663 != 0) {
        goto LA; // [159] 174
    }
    _22665 = (_t2_43162 == 4LL);
    if (_22665 == 0)
    {
        DeRef(_22665);
        _22665 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22665);
        _22665 = NOVALUE;
    }
LA: 

    /** c_decl.e:361			return TYPE_ATOM*/
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    return 4LL;
    goto L2; // [182] 307
LB: 

    /** c_decl.e:363		elsif t1 = TYPE_DOUBLE then*/
    if (_t1_43161 != 2LL)
    goto LC; // [189] 224

    /** c_decl.e:364			if t2 = TYPE_INTEGER then*/
    if (_t2_43162 != 1LL)
    goto LD; // [197] 212

    /** c_decl.e:365				return TYPE_ATOM*/
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    return 4LL;
    goto L2; // [209] 307
LD: 

    /** c_decl.e:367				return TYPE_DOUBLE*/
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    return 2LL;
    goto L2; // [221] 307
LC: 

    /** c_decl.e:370		elsif t2 = TYPE_DOUBLE then*/
    if (_t2_43162 != 2LL)
    goto LE; // [228] 263

    /** c_decl.e:371			if t1 = TYPE_INTEGER then*/
    if (_t1_43161 != 1LL)
    goto LF; // [236] 251

    /** c_decl.e:372				return TYPE_ATOM*/
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    return 4LL;
    goto L2; // [248] 307
LF: 

    /** c_decl.e:374				return TYPE_DOUBLE*/
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    return 2LL;
    goto L2; // [260] 307
LE: 

    /** c_decl.e:377		elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22670 = (_t1_43161 == 1LL);
    if (_22670 == 0) {
        goto L10; // [271] 296
    }
    _22672 = (_t2_43162 == 1LL);
    if (_22672 == 0)
    {
        DeRef(_22672);
        _22672 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22672);
        _22672 = NOVALUE;
    }

    /** c_decl.e:378			return TYPE_INTEGER*/
    DeRef(_22670);
    _22670 = NOVALUE;
    DeRef(_22663);
    _22663 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    return 1LL;
    goto L2; // [293] 307
L10: 

    /** c_decl.e:381			InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _t1_43161;
    ((intptr_t *)_2)[2] = _t2_43162;
    _22673 = MAKE_SEQ(_1);
    _50InternalErr(258LL, _22673);
    _22673 = NOVALUE;
L2: 
    ;
}


void _58RemoveFromBB(object _s_43232)
{
    object _int_43233 = NOVALUE;
    object _22675 = NOVALUE;
    object _22674 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:388		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22674 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22674 = 1;
    }
    {
        object _i_43235;
        _i_43235 = 1LL;
L1: 
        if (_i_43235 > _22674){
            goto L2; // [10] 59
        }

        /** c_decl.e:389			int = BB_info[i][BB_VAR]*/
        _2 = (object)SEQ_PTR(_58BB_info_42885);
        _22675 = (object)*(((s1_ptr)_2)->base + _i_43235);
        _2 = (object)SEQ_PTR(_22675);
        _int_43233 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_int_43233)){
            _int_43233 = (object)DBL_PTR(_int_43233)->dbl;
        }
        _22675 = NOVALUE;

        /** c_decl.e:390			if int = s then*/
        if (_int_43233 != _s_43232)
        goto L3; // [33] 52

        /** c_decl.e:391				BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_58BB_info_42885);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_43233)) ? _int_43233 : (object)(DBL_PTR(_int_43233)->dbl);
            int stop = (IS_ATOM_INT(_int_43233)) ? _int_43233 : (object)(DBL_PTR(_int_43233)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_58BB_info_42885), start, &_58BB_info_42885 );
                }
                else Tail(SEQ_PTR(_58BB_info_42885), stop+1, &_58BB_info_42885);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_58BB_info_42885), start, &_58BB_info_42885);
            }
            else {
                assign_slice_seq = &assign_space;
                _58BB_info_42885 = Remove_elements(start, stop, (SEQ_PTR(_58BB_info_42885)->ref == 1));
            }
        }

        /** c_decl.e:392				return*/
        return;
L3: 

        /** c_decl.e:394		end for*/
        _i_43235 = _i_43235 + 1LL;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** c_decl.e:395	end procedure*/
    return;
    ;
}


void _58SetBBType(object _s_43253, object _t_43254, object _val_43255, object _etype_43256, object _has_delete_43257)
{
    object _found_43258 = NOVALUE;
    object _i_43259 = NOVALUE;
    object _tn_43260 = NOVALUE;
    object _int_43261 = NOVALUE;
    object _sym_43262 = NOVALUE;
    object _mode_43267 = NOVALUE;
    object _gtype_43282 = NOVALUE;
    object _new_type_43319 = NOVALUE;
    object _bbsym_43342 = NOVALUE;
    object _bbi_43478 = NOVALUE;
    object _22794 = NOVALUE;
    object _22793 = NOVALUE;
    object _22792 = NOVALUE;
    object _22790 = NOVALUE;
    object _22789 = NOVALUE;
    object _22788 = NOVALUE;
    object _22786 = NOVALUE;
    object _22785 = NOVALUE;
    object _22783 = NOVALUE;
    object _22781 = NOVALUE;
    object _22780 = NOVALUE;
    object _22778 = NOVALUE;
    object _22776 = NOVALUE;
    object _22775 = NOVALUE;
    object _22774 = NOVALUE;
    object _22773 = NOVALUE;
    object _22772 = NOVALUE;
    object _22771 = NOVALUE;
    object _22770 = NOVALUE;
    object _22769 = NOVALUE;
    object _22768 = NOVALUE;
    object _22765 = NOVALUE;
    object _22761 = NOVALUE;
    object _22756 = NOVALUE;
    object _22754 = NOVALUE;
    object _22753 = NOVALUE;
    object _22752 = NOVALUE;
    object _22750 = NOVALUE;
    object _22748 = NOVALUE;
    object _22747 = NOVALUE;
    object _22746 = NOVALUE;
    object _22744 = NOVALUE;
    object _22743 = NOVALUE;
    object _22741 = NOVALUE;
    object _22740 = NOVALUE;
    object _22739 = NOVALUE;
    object _22737 = NOVALUE;
    object _22736 = NOVALUE;
    object _22733 = NOVALUE;
    object _22732 = NOVALUE;
    object _22731 = NOVALUE;
    object _22729 = NOVALUE;
    object _22727 = NOVALUE;
    object _22726 = NOVALUE;
    object _22724 = NOVALUE;
    object _22723 = NOVALUE;
    object _22722 = NOVALUE;
    object _22720 = NOVALUE;
    object _22719 = NOVALUE;
    object _22708 = NOVALUE;
    object _22706 = NOVALUE;
    object _22703 = NOVALUE;
    object _22702 = NOVALUE;
    object _22699 = NOVALUE;
    object _22698 = NOVALUE;
    object _22697 = NOVALUE;
    object _22695 = NOVALUE;
    object _22694 = NOVALUE;
    object _22693 = NOVALUE;
    object _22691 = NOVALUE;
    object _22690 = NOVALUE;
    object _22688 = NOVALUE;
    object _22685 = NOVALUE;
    object _22683 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43253)) {
        _1 = (object)(DBL_PTR(_s_43253)->dbl);
        DeRefDS(_s_43253);
        _s_43253 = _1;
    }
    if (!IS_ATOM_INT(_t_43254)) {
        _1 = (object)(DBL_PTR(_t_43254)->dbl);
        DeRefDS(_t_43254);
        _t_43254 = _1;
    }
    if (!IS_ATOM_INT(_etype_43256)) {
        _1 = (object)(DBL_PTR(_etype_43256)->dbl);
        DeRefDS(_etype_43256);
        _etype_43256 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_43257)) {
        _1 = (object)(DBL_PTR(_has_delete_43257)->dbl);
        DeRefDS(_has_delete_43257);
        _has_delete_43257 = _1;
    }

    /** c_decl.e:416		if has_delete then*/
    if (_has_delete_43257 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** c_decl.e:417			p_has_delete = 1*/
    _58p_has_delete_43072 = 1LL;

    /** c_decl.e:418			g_has_delete = 1*/
    _58g_has_delete_43071 = 1LL;
L1: 

    /** c_decl.e:421		sym = SymTab[s]*/
    DeRef(_sym_43262);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _sym_43262 = (object)*(((s1_ptr)_2)->base + _s_43253);
    Ref(_sym_43262);

    /** c_decl.e:422		SymTab[s] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43253);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:424		integer mode = sym[S_MODE]*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _mode_43267 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_43267))
    _mode_43267 = (object)DBL_PTR(_mode_43267)->dbl;

    /** c_decl.e:425		if mode = M_NORMAL or mode = M_TEMP  then*/
    _22683 = (_mode_43267 == 1LL);
    if (_22683 != 0) {
        goto L2; // [61] 76
    }
    _22685 = (_mode_43267 == 3LL);
    if (_22685 == 0)
    {
        DeRef(_22685);
        _22685 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22685);
        _22685 = NOVALUE;
    }
L2: 

    /** c_decl.e:427			found = FALSE*/
    _found_43258 = _13FALSE_445;

    /** c_decl.e:428			if mode = M_TEMP then*/
    if (_mode_43267 != 3LL)
    goto L4; // [89] 465

    /** c_decl.e:429				sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43254;
    DeRef(_1);

    /** c_decl.e:430				sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43256;
    DeRef(_1);

    /** c_decl.e:431				integer gtype = sym[S_GTYPE]*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _gtype_43282 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (!IS_ATOM_INT(_gtype_43282))
    _gtype_43282 = (object)DBL_PTR(_gtype_43282)->dbl;

    /** c_decl.e:432				if gtype = TYPE_OBJECT*/
    _22688 = (_gtype_43282 == 16LL);
    if (_22688 != 0) {
        goto L5; // [125] 140
    }
    _22690 = (_gtype_43282 == 8LL);
    if (_22690 == 0)
    {
        DeRef(_22690);
        _22690 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22690);
        _22690 = NOVALUE;
    }
L5: 

    /** c_decl.e:435					if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22691 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22691, 0LL)){
        _22691 = NOVALUE;
        goto L7; // [148] 165
    }
    _22691 = NOVALUE;

    /** c_decl.e:436						sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** c_decl.e:438						sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22693 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22693);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22693;
    if( _1 != _22693 ){
        DeRef(_1);
    }
    _22693 = NOVALUE;
L8: 

    /** c_decl.e:440					sym[S_OBJ] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** c_decl.e:442					sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** c_decl.e:443					sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** c_decl.e:445					sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22694 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22694);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22694;
    if( _1 != _22694 ){
        DeRef(_1);
    }
    _22694 = NOVALUE;

    /** c_decl.e:446					sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22695 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22695);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22695;
    if( _1 != _22695 ){
        DeRef(_1);
    }
    _22695 = NOVALUE;

    /** c_decl.e:447					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
L9: 

    /** c_decl.e:449				if not Initializing then*/
    if (_36Initializing_21843 != 0)
    goto LA; // [256] 326

    /** c_decl.e:450					integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22697 = (object)*(((s1_ptr)_2)->base + 34LL);
    _2 = (object)SEQ_PTR(_36temp_name_type_21845);
    if (!IS_ATOM_INT(_22697)){
        _22698 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22697)->dbl));
    }
    else{
        _22698 = (object)*(((s1_ptr)_2)->base + _22697);
    }
    _2 = (object)SEQ_PTR(_22698);
    _22699 = (object)*(((s1_ptr)_2)->base + 2LL);
    _22698 = NOVALUE;
    Ref(_22699);
    _new_type_43319 = _58or_type(_22699, _t_43254);
    _22699 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_43319)) {
        _1 = (object)(DBL_PTR(_new_type_43319)->dbl);
        DeRefDS(_new_type_43319);
        _new_type_43319 = _1;
    }

    /** c_decl.e:451					if new_type = TYPE_NULL then*/
    if (_new_type_43319 != 0LL)
    goto LB; // [290] 304

    /** c_decl.e:452						new_type = TYPE_OBJECT*/
    _new_type_43319 = 16LL;
LB: 

    /** c_decl.e:454					temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22702 = (object)*(((s1_ptr)_2)->base + 34LL);
    _2 = (object)SEQ_PTR(_36temp_name_type_21845);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _36temp_name_type_21845 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22702))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_22702)->dbl));
    else
    _3 = (object)(_22702 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_type_43319;
    DeRef(_1);
    _22703 = NOVALUE;
LA: 

    /** c_decl.e:458				tn = sym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _tn_43260 = (object)*(((s1_ptr)_2)->base + 34LL);
    if (!IS_ATOM_INT(_tn_43260))
    _tn_43260 = (object)DBL_PTR(_tn_43260)->dbl;

    /** c_decl.e:459				i = 1*/
    _i_43259 = 1LL;

    /** c_decl.e:460				while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22706 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22706 = 1;
    }
    if (_i_43259 > _22706)
    goto LD; // [351] 460

    /** c_decl.e:461					sequence bbsym*/

    /** c_decl.e:462					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    _22708 = (object)*(((s1_ptr)_2)->base + _i_43259);
    _2 = (object)SEQ_PTR(_22708);
    _int_43261 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_int_43261)){
        _int_43261 = (object)DBL_PTR(_int_43261)->dbl;
    }
    _22708 = NOVALUE;

    /** c_decl.e:463					if int = s then*/
    if (_int_43261 != _s_43253)
    goto LE; // [373] 387

    /** c_decl.e:464						bbsym = sym*/
    RefDS(_sym_43262);
    DeRef(_bbsym_43342);
    _bbsym_43342 = _sym_43262;
    goto LF; // [384] 398
LE: 

    /** c_decl.e:466						bbsym = SymTab[int]*/
    DeRef(_bbsym_43342);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _bbsym_43342 = (object)*(((s1_ptr)_2)->base + _int_43261);
    Ref(_bbsym_43342);
LF: 

    /** c_decl.e:468					int = bbsym[S_MODE]*/
    _2 = (object)SEQ_PTR(_bbsym_43342);
    _int_43261 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_int_43261))
    _int_43261 = (object)DBL_PTR(_int_43261)->dbl;

    /** c_decl.e:469					if int = M_TEMP then*/
    if (_int_43261 != 3LL)
    goto L10; // [412] 447

    /** c_decl.e:470						int = bbsym[S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_bbsym_43342);
    _int_43261 = (object)*(((s1_ptr)_2)->base + 34LL);
    if (!IS_ATOM_INT(_int_43261))
    _int_43261 = (object)DBL_PTR(_int_43261)->dbl;

    /** c_decl.e:471						if int = tn then*/
    if (_int_43261 != _tn_43260)
    goto L11; // [426] 446

    /** c_decl.e:472							found = TRUE*/
    _found_43258 = _13TRUE_447;

    /** c_decl.e:473							exit*/
    DeRefDS(_bbsym_43342);
    _bbsym_43342 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** c_decl.e:476					i += 1*/
    _i_43259 = _i_43259 + 1;
    DeRef(_bbsym_43342);
    _bbsym_43342 = NOVALUE;

    /** c_decl.e:477				end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** c_decl.e:479				if t != TYPE_NULL then*/
    if (_t_43254 == 0LL)
    goto L13; // [469] 824

    /** c_decl.e:480					if not Initializing then*/
    if (_36Initializing_21843 != 0)
    goto L14; // [477] 500

    /** c_decl.e:481						sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22719 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_22719);
    _22720 = _58or_type(_22719, _t_43254);
    _22719 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22720;
    if( _1 != _22720 ){
        DeRef(_1);
    }
    _22720 = NOVALUE;
L14: 

    /** c_decl.e:484					if t = TYPE_SEQUENCE then*/
    if (_t_43254 != 8LL)
    goto L15; // [504] 633

    /** c_decl.e:485						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22722 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22722);
    _22723 = _58or_type(_22722, _etype_43256);
    _22722 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22723;
    if( _1 != _22723 ){
        DeRef(_1);
    }
    _22723 = NOVALUE;

    /** c_decl.e:488						if val[MIN] != -1 then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22724 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(EQUALS, _22724, -1LL)){
        _22724 = NOVALUE;
        goto L16; // [535] 823
    }
    _22724 = NOVALUE;

    /** c_decl.e:489							if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22726 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _22727 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22727 = - _36NOVALUE_21613;
        }
    }
    else {
        _22727 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    if (binary_op_a(NOTEQ, _22726, _22727)){
        _22726 = NOVALUE;
        DeRef(_22727);
        _22727 = NOVALUE;
        goto L17; // [552] 599
    }
    _22726 = NOVALUE;
    DeRef(_22727);
    _22727 = NOVALUE;

    /** c_decl.e:490								if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22729 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22729, 0LL)){
        _22729 = NOVALUE;
        goto L18; // [564] 581
    }
    _22729 = NOVALUE;

    /** c_decl.e:491									sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** c_decl.e:493									sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22731 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22731);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22731;
    if( _1 != _22731 ){
        DeRef(_1);
    }
    _22731 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** c_decl.e:495							elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22732 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_sym_43262);
    _22733 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (binary_op_a(EQUALS, _22732, _22733)){
        _22732 = NOVALUE;
        _22733 = NOVALUE;
        goto L16; // [613] 823
    }
    _22732 = NOVALUE;
    _22733 = NOVALUE;

    /** c_decl.e:496								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** c_decl.e:500					elsif t = TYPE_INTEGER then*/
    if (_t_43254 != 1LL)
    goto L19; // [637] 774

    /** c_decl.e:502						if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22736 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _22737 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _22737 = - _36NOVALUE_21613;
        }
    }
    else {
        _22737 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    if (binary_op_a(NOTEQ, _22736, _22737)){
        _22736 = NOVALUE;
        DeRef(_22737);
        _22737 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22736 = NOVALUE;
    DeRef(_22737);
    _22737 = NOVALUE;

    /** c_decl.e:504							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22739 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22739);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22739;
    if( _1 != _22739 ){
        DeRef(_1);
    }
    _22739 = NOVALUE;

    /** c_decl.e:505							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22740 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22740);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22740;
    if( _1 != _22740 ){
        DeRef(_1);
    }
    _22740 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** c_decl.e:507						elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22741 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (binary_op_a(EQUALS, _22741, _36NOVALUE_21613)){
        _22741 = NOVALUE;
        goto L16; // [699] 823
    }
    _22741 = NOVALUE;

    /** c_decl.e:509							if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22743 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_sym_43262);
    _22744 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (binary_op_a(GREATEREQ, _22743, _22744)){
        _22743 = NOVALUE;
        _22744 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22743 = NOVALUE;
    _22744 = NOVALUE;

    /** c_decl.e:510								sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22746 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22746);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22746;
    if( _1 != _22746 ){
        DeRef(_1);
    }
    _22746 = NOVALUE;
L1B: 

    /** c_decl.e:512							if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22747 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_sym_43262);
    _22748 = (object)*(((s1_ptr)_2)->base + 42LL);
    if (binary_op_a(LESSEQ, _22747, _22748)){
        _22747 = NOVALUE;
        _22748 = NOVALUE;
        goto L16; // [750] 823
    }
    _22747 = NOVALUE;
    _22748 = NOVALUE;

    /** c_decl.e:513								sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22750 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22750);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22750;
    if( _1 != _22750 ){
        DeRef(_1);
    }
    _22750 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** c_decl.e:518						sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);

    /** c_decl.e:519						if t = TYPE_OBJECT then*/
    if (_t_43254 != 16LL)
    goto L1C; // [788] 822

    /** c_decl.e:522							sym[S_SEQ_ELEM_NEW] =*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22752 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_22752);
    _22753 = _58or_type(_22752, _etype_43256);
    _22752 = NOVALUE;
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22753;
    if( _1 != _22753 ){
        DeRef(_1);
    }
    _22753 = NOVALUE;

    /** c_decl.e:524							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** c_decl.e:529				i = 1*/
    _i_43259 = 1LL;

    /** c_decl.e:530				while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_58BB_info_42885)){
            _22754 = SEQ_PTR(_58BB_info_42885)->length;
    }
    else {
        _22754 = 1;
    }
    if (_i_43259 > _22754)
    goto L1E; // [839] 888

    /** c_decl.e:531					int = BB_info[i][BB_VAR]*/
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    _22756 = (object)*(((s1_ptr)_2)->base + _i_43259);
    _2 = (object)SEQ_PTR(_22756);
    _int_43261 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_int_43261)){
        _int_43261 = (object)DBL_PTR(_int_43261)->dbl;
    }
    _22756 = NOVALUE;

    /** c_decl.e:532					if int = s then*/
    if (_int_43261 != _s_43253)
    goto L1F; // [859] 877

    /** c_decl.e:533						found = TRUE*/
    _found_43258 = _13TRUE_447;

    /** c_decl.e:534						exit*/
    goto L1E; // [874] 888
L1F: 

    /** c_decl.e:536					i += 1*/
    _i_43259 = _i_43259 + 1;

    /** c_decl.e:537				end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** c_decl.e:541			if not found then*/
    if (_found_43258 != 0)
    goto L20; // [891] 907

    /** c_decl.e:543				BB_info = append(BB_info, repeat(0, 6))*/
    _22761 = Repeat(0LL, 6LL);
    RefDS(_22761);
    Append(&_58BB_info_42885, _58BB_info_42885, _22761);
    DeRefDS(_22761);
    _22761 = NOVALUE;
L20: 

    /** c_decl.e:546			if t = TYPE_NULL then*/
    if (_t_43254 != 0LL)
    goto L21; // [911] 949

    /** c_decl.e:547				if not found then*/
    if (_found_43258 != 0)
    goto L22; // [917] 1308

    /** c_decl.e:549					BB_info[i] = dummy_bb*/
    RefDS(_58dummy_bb_43242);
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42885 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43259);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _58dummy_bb_43242;
    DeRef(_1);

    /** c_decl.e:550					BB_info[i][BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42885 = MAKE_SEQ(_2);
    }
    _3 = (object)(_i_43259 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43253;
    DeRef(_1);
    _22765 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** c_decl.e:554				sequence bbi = BB_info[i]*/
    DeRef(_bbi_43478);
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    _bbi_43478 = (object)*(((s1_ptr)_2)->base + _i_43259);
    Ref(_bbi_43478);

    /** c_decl.e:555				BB_info[i] = 0*/
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42885 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43259);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:556				bbi[BB_VAR] = s*/
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_43253;
    DeRef(_1);

    /** c_decl.e:557				bbi[BB_TYPE] = t*/
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43254;
    DeRef(_1);

    /** c_decl.e:558				bbi[BB_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 6LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43257;
    DeRef(_1);

    /** c_decl.e:560				if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22768 = (_t_43254 == 8LL);
    if (_22768 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (object)SEQ_PTR(_val_43255);
    _22770 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_22770)) {
        _22771 = (_22770 == -1LL);
    }
    else {
        _22771 = binary_op(EQUALS, _22770, -1LL);
    }
    _22770 = NOVALUE;
    if (_22771 == 0) {
        DeRef(_22771);
        _22771 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22771) && DBL_PTR(_22771)->dbl == 0.0){
            DeRef(_22771);
            _22771 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22771);
        _22771 = NOVALUE;
    }
    DeRef(_22771);
    _22771 = NOVALUE;

    /** c_decl.e:562					if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_43258 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (object)SEQ_PTR(_bbi_43478);
    _22773 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_22773)) {
        _22774 = (_22773 != 0LL);
    }
    else {
        _22774 = binary_op(NOTEQ, _22773, 0LL);
    }
    _22773 = NOVALUE;
    if (_22774 == 0) {
        DeRef(_22774);
        _22774 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22774) && DBL_PTR(_22774)->dbl == 0.0){
            DeRef(_22774);
            _22774 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22774);
        _22774 = NOVALUE;
    }
    DeRef(_22774);
    _22774 = NOVALUE;

    /** c_decl.e:564						bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (object)SEQ_PTR(_bbi_43478);
    _22775 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_22775);
    _22776 = _58or_type(_22775, _etype_43256);
    _22775 = NOVALUE;
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22776;
    if( _1 != _22776 ){
        DeRef(_1);
    }
    _22776 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** c_decl.e:566						bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
L25: 

    /** c_decl.e:568					if not found then*/
    if (_found_43258 != 0)
    goto L26; // [1062] 1153

    /** c_decl.e:569						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** c_decl.e:572					bbi[BB_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43256;
    DeRef(_1);

    /** c_decl.e:573					if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22778 = (_t_43254 == 8LL);
    if (_22778 != 0) {
        goto L27; // [1091] 1106
    }
    _22780 = (_t_43254 == 16LL);
    if (_22780 == 0)
    {
        DeRef(_22780);
        _22780 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22780);
        _22780 = NOVALUE;
    }
L27: 

    /** c_decl.e:574						if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22781 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22781, 0LL)){
        _22781 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22781 = NOVALUE;

    /** c_decl.e:575							bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** c_decl.e:577							bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22783 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22783);
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22783;
    if( _1 != _22783 ){
        DeRef(_1);
    }
    _22783 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** c_decl.e:580						bbi[BB_OBJ] = val*/
    RefDS(_val_43255);
    _2 = (object)SEQ_PTR(_bbi_43478);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _bbi_43478 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _val_43255;
    DeRef(_1);
L2A: 
L26: 

    /** c_decl.e:583				BB_info[i] = bbi*/
    RefDS(_bbi_43478);
    _2 = (object)SEQ_PTR(_58BB_info_42885);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58BB_info_42885 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _i_43259);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _bbi_43478;
    DeRef(_1);
    DeRefDS(_bbi_43478);
    _bbi_43478 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** c_decl.e:586		elsif mode = M_CONSTANT then*/
    if (_mode_43267 != 2LL)
    goto L2B; // [1171] 1307

    /** c_decl.e:587			sym[S_GTYPE] = t*/
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _t_43254;
    DeRef(_1);

    /** c_decl.e:588			sym[S_SEQ_ELEM] = etype*/
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _etype_43256;
    DeRef(_1);

    /** c_decl.e:589			if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (object)SEQ_PTR(_sym_43262);
    _22785 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22785)) {
        _22786 = (_22785 == 8LL);
    }
    else {
        _22786 = binary_op(EQUALS, _22785, 8LL);
    }
    _22785 = NOVALUE;
    if (IS_ATOM_INT(_22786)) {
        if (_22786 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22786)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (object)SEQ_PTR(_sym_43262);
    _22788 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_22788)) {
        _22789 = (_22788 == 16LL);
    }
    else {
        _22789 = binary_op(EQUALS, _22788, 16LL);
    }
    _22788 = NOVALUE;
    if (_22789 == 0) {
        DeRef(_22789);
        _22789 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22789) && DBL_PTR(_22789)->dbl == 0.0){
            DeRef(_22789);
            _22789 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22789);
        _22789 = NOVALUE;
    }
    DeRef(_22789);
    _22789 = NOVALUE;
L2C: 

    /** c_decl.e:591				if val[MIN] < 0 then*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22790 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(GREATEREQ, _22790, 0LL)){
        _22790 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22790 = NOVALUE;

    /** c_decl.e:592					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** c_decl.e:594					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22792 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22792);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22792;
    if( _1 != _22792 ){
        DeRef(_1);
    }
    _22792 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** c_decl.e:597				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22793 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22793);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22793;
    if( _1 != _22793 ){
        DeRef(_1);
    }
    _22793 = NOVALUE;

    /** c_decl.e:598				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (object)SEQ_PTR(_val_43255);
    _22794 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_22794);
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22794;
    if( _1 != _22794 ){
        DeRef(_1);
    }
    _22794 = NOVALUE;
L2F: 

    /** c_decl.e:600			sym[S_HAS_DELETE] = has_delete*/
    _2 = (object)SEQ_PTR(_sym_43262);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_43262 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 54LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _has_delete_43257;
    DeRef(_1);
L2B: 
L22: 

    /** c_decl.e:603		SymTab[s] = sym*/
    RefDS(_sym_43262);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_43253);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_43262;
    DeRef(_1);

    /** c_decl.e:605	end procedure*/
    DeRefDS(_val_43255);
    DeRefDS(_sym_43262);
    _22697 = NOVALUE;
    _22702 = NOVALUE;
    DeRef(_22786);
    _22786 = NOVALUE;
    DeRef(_22683);
    _22683 = NOVALUE;
    DeRef(_22778);
    _22778 = NOVALUE;
    DeRef(_22768);
    _22768 = NOVALUE;
    DeRef(_22688);
    _22688 = NOVALUE;
    return;
    ;
}


void _58CName(object _s_43552)
{
    object _v_43553 = NOVALUE;
    object _mode_43555 = NOVALUE;
    object _22859 = NOVALUE;
    object _22858 = NOVALUE;
    object _22856 = NOVALUE;
    object _22855 = NOVALUE;
    object _22854 = NOVALUE;
    object _22853 = NOVALUE;
    object _22852 = NOVALUE;
    object _22851 = NOVALUE;
    object _22850 = NOVALUE;
    object _22849 = NOVALUE;
    object _22847 = NOVALUE;
    object _22845 = NOVALUE;
    object _22844 = NOVALUE;
    object _22843 = NOVALUE;
    object _22842 = NOVALUE;
    object _22841 = NOVALUE;
    object _22840 = NOVALUE;
    object _22838 = NOVALUE;
    object _22837 = NOVALUE;
    object _22836 = NOVALUE;
    object _22835 = NOVALUE;
    object _22834 = NOVALUE;
    object _22832 = NOVALUE;
    object _22831 = NOVALUE;
    object _22830 = NOVALUE;
    object _22829 = NOVALUE;
    object _22828 = NOVALUE;
    object _22827 = NOVALUE;
    object _22825 = NOVALUE;
    object _22824 = NOVALUE;
    object _22822 = NOVALUE;
    object _22821 = NOVALUE;
    object _22820 = NOVALUE;
    object _22819 = NOVALUE;
    object _22818 = NOVALUE;
    object _22817 = NOVALUE;
    object _22816 = NOVALUE;
    object _22815 = NOVALUE;
    object _22814 = NOVALUE;
    object _22813 = NOVALUE;
    object _22812 = NOVALUE;
    object _22811 = NOVALUE;
    object _22809 = NOVALUE;
    object _22808 = NOVALUE;
    object _22804 = NOVALUE;
    object _22803 = NOVALUE;
    object _22802 = NOVALUE;
    object _22801 = NOVALUE;
    object _22800 = NOVALUE;
    object _22799 = NOVALUE;
    object _22796 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_43552)) {
        _1 = (object)(DBL_PTR(_s_43552)->dbl);
        DeRefDS(_s_43552);
        _s_43552 = _1;
    }

    /** c_decl.e:612		v = ObjValue(s)*/
    _0 = _v_43553;
    _v_43553 = _58ObjValue(_s_43552);
    DeRef(_0);

    /** c_decl.e:613		integer mode = SymTab[s][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22796 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22796);
    _mode_43555 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_mode_43555)){
        _mode_43555 = (object)DBL_PTR(_mode_43555)->dbl;
    }
    _22796 = NOVALUE;

    /** c_decl.e:614	 	if mode = M_NORMAL then*/
    if (_mode_43555 != 1LL)
    goto L1; // [29] 254

    /** c_decl.e:617			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22799 = (_58LeftSym_42886 == _13FALSE_445);
    if (_22799 == 0) {
        _22800 = 0;
        goto L2; // [43] 61
    }
    _22801 = _58GType(_s_43552);
    if (IS_ATOM_INT(_22801)) {
        _22802 = (_22801 == 1LL);
    }
    else {
        _22802 = binary_op(EQUALS, _22801, 1LL);
    }
    DeRef(_22801);
    _22801 = NOVALUE;
    if (IS_ATOM_INT(_22802))
    _22800 = (_22802 != 0);
    else
    _22800 = DBL_PTR(_22802)->dbl != 0.0;
L2: 
    if (_22800 == 0) {
        goto L3; // [61] 98
    }
    if (IS_ATOM_INT(_v_43553) && IS_ATOM_INT(_36NOVALUE_21613)) {
        _22804 = (_v_43553 != _36NOVALUE_21613);
    }
    else {
        _22804 = binary_op(NOTEQ, _v_43553, _36NOVALUE_21613);
    }
    if (_22804 == 0) {
        DeRef(_22804);
        _22804 = NOVALUE;
        goto L3; // [72] 98
    }
    else {
        if (!IS_ATOM_INT(_22804) && DBL_PTR(_22804)->dbl == 0.0){
            DeRef(_22804);
            _22804 = NOVALUE;
            goto L3; // [72] 98
        }
        DeRef(_22804);
        _22804 = NOVALUE;
    }
    DeRef(_22804);
    _22804 = NOVALUE;

    /** c_decl.e:618				c_printf("%d", v)*/
    RefDS(_22805);
    Ref(_v_43553);
    _55c_printf(_22805, _v_43553);

    /** c_decl.e:619				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21581 != 8LL)
    goto L4; // [85] 180

    /** c_decl.e:620					c_puts( "LL" )*/
    RefDS(_22807);
    _55c_puts(_22807);
    goto L4; // [95] 180
L3: 

    /** c_decl.e:623				if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22808 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22808);
    _22809 = (object)*(((s1_ptr)_2)->base + 4LL);
    _22808 = NOVALUE;
    if (binary_op_a(LESSEQ, _22809, 3LL)){
        _22809 = NOVALUE;
        goto L5; // [114] 156
    }
    _22809 = NOVALUE;

    /** c_decl.e:624					c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22811 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22811);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _22812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _22812 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _22811 = NOVALUE;
    RefDS(_22309);
    Ref(_22812);
    _55c_printf(_22309, _22812);
    _22812 = NOVALUE;

    /** c_decl.e:625					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22813 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22813);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _22814 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _22814 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _22813 = NOVALUE;
    Ref(_22814);
    _55c_puts(_22814);
    _22814 = NOVALUE;
    goto L6; // [153] 179
L5: 

    /** c_decl.e:627					c_puts("_")*/
    RefDS(_22258);
    _55c_puts(_22258);

    /** c_decl.e:628					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22815 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22815);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _22816 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _22816 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _22815 = NOVALUE;
    Ref(_22816);
    _55c_puts(_22816);
    _22816 = NOVALUE;
L6: 
L4: 

    /** c_decl.e:631			if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22817 = (_s_43552 != _36CurrentSub_21767);
    if (_22817 == 0) {
        goto L7; // [188] 236
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22819 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22819);
    _22820 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22819 = NOVALUE;
    if (IS_ATOM_INT(_22820)) {
        _22821 = (_22820 < 2LL);
    }
    else {
        _22821 = binary_op(LESS, _22820, 2LL);
    }
    _22820 = NOVALUE;
    if (_22821 == 0) {
        DeRef(_22821);
        _22821 = NOVALUE;
        goto L7; // [209] 236
    }
    else {
        if (!IS_ATOM_INT(_22821) && DBL_PTR(_22821)->dbl == 0.0){
            DeRef(_22821);
            _22821 = NOVALUE;
            goto L7; // [209] 236
        }
        DeRef(_22821);
        _22821 = NOVALUE;
    }
    DeRef(_22821);
    _22821 = NOVALUE;

    /** c_decl.e:632				SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43552 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22824 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22822 = NOVALUE;
    if (IS_ATOM_INT(_22824)) {
        _22825 = _22824 + 1;
        if (_22825 > MAXINT){
            _22825 = NewDouble((eudouble)_22825);
        }
    }
    else
    _22825 = binary_op(PLUS, 1, _22824);
    _22824 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22825;
    if( _1 != _22825 ){
        DeRef(_1);
    }
    _22825 = NOVALUE;
    _22822 = NOVALUE;
L7: 

    /** c_decl.e:634			SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_55novalue_46976);
    _58SetBBType(_s_43552, 0LL, _55novalue_46976, 16LL, 0LL);
    goto L8; // [251] 533
L1: 

    /** c_decl.e:636	 	elsif mode = M_CONSTANT then*/
    if (_mode_43555 != 2LL)
    goto L9; // [258] 448

    /** c_decl.e:638			if (is_integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22827 = _54sym_obj(_s_43552);
    _22828 = _36is_integer(_22827);
    _22827 = NOVALUE;
    if (IS_ATOM_INT(_22828)) {
        if (_22828 == 0) {
            DeRef(_22829);
            _22829 = 0;
            goto LA; // [272] 298
        }
    }
    else {
        if (DBL_PTR(_22828)->dbl == 0.0) {
            DeRef(_22829);
            _22829 = 0;
            goto LA; // [272] 298
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22830 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22830);
    _22831 = (object)*(((s1_ptr)_2)->base + 36LL);
    _22830 = NOVALUE;
    if (IS_ATOM_INT(_22831)) {
        _22832 = (_22831 != 2LL);
    }
    else {
        _22832 = binary_op(NOTEQ, _22831, 2LL);
    }
    _22831 = NOVALUE;
    DeRef(_22829);
    if (IS_ATOM_INT(_22832))
    _22829 = (_22832 != 0);
    else
    _22829 = DBL_PTR(_22832)->dbl != 0.0;
LA: 
    if (_22829 != 0) {
        goto LB; // [298] 344
    }
    _22834 = (_58LeftSym_42886 == _13FALSE_445);
    if (_22834 == 0) {
        _22835 = 0;
        goto LC; // [310] 325
    }
    _22836 = _58TypeIs(_s_43552, 1LL);
    if (IS_ATOM_INT(_22836))
    _22835 = (_22836 != 0);
    else
    _22835 = DBL_PTR(_22836)->dbl != 0.0;
LC: 
    if (_22835 == 0) {
        DeRef(_22837);
        _22837 = 0;
        goto LD; // [325] 339
    }
    if (IS_ATOM_INT(_v_43553) && IS_ATOM_INT(_36NOVALUE_21613)) {
        _22838 = (_v_43553 != _36NOVALUE_21613);
    }
    else {
        _22838 = binary_op(NOTEQ, _v_43553, _36NOVALUE_21613);
    }
    if (IS_ATOM_INT(_22838))
    _22837 = (_22838 != 0);
    else
    _22837 = DBL_PTR(_22838)->dbl != 0.0;
LD: 
    if (_22837 == 0)
    {
        _22837 = NOVALUE;
        goto LE; // [340] 367
    }
    else{
        _22837 = NOVALUE;
    }
LB: 

    /** c_decl.e:641				c_printf("%d", v)*/
    RefDS(_22805);
    Ref(_v_43553);
    _55c_printf(_22805, _v_43553);

    /** c_decl.e:642				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21581 != 8LL)
    goto L8; // [354] 533

    /** c_decl.e:643					c_puts( "LL" )*/
    RefDS(_22807);
    _55c_puts(_22807);
    goto L8; // [364] 533
LE: 

    /** c_decl.e:647				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22840 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22840);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _22841 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _22841 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _22840 = NOVALUE;
    RefDS(_22309);
    Ref(_22841);
    _55c_printf(_22309, _22841);
    _22841 = NOVALUE;

    /** c_decl.e:648				c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22842 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22842);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _22843 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _22843 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _22842 = NOVALUE;
    Ref(_22843);
    _55c_puts(_22843);
    _22843 = NOVALUE;

    /** c_decl.e:649				if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22844 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22844);
    _22845 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22844 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22845, 2LL)){
        _22845 = NOVALUE;
        goto L8; // [416] 533
    }
    _22845 = NOVALUE;

    /** c_decl.e:650					SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_43552 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _22849 = (object)*(((s1_ptr)_2)->base + 12LL);
    _22847 = NOVALUE;
    if (IS_ATOM_INT(_22849)) {
        _22850 = _22849 + 1;
        if (_22850 > MAXINT){
            _22850 = NewDouble((eudouble)_22850);
        }
    }
    else
    _22850 = binary_op(PLUS, 1, _22849);
    _22849 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _22850;
    if( _1 != _22850 ){
        DeRef(_1);
    }
    _22850 = NOVALUE;
    _22847 = NOVALUE;
    goto L8; // [445] 533
L9: 

    /** c_decl.e:656			if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22851 = (_58LeftSym_42886 == _13FALSE_445);
    if (_22851 == 0) {
        _22852 = 0;
        goto LF; // [458] 476
    }
    _22853 = _58GType(_s_43552);
    if (IS_ATOM_INT(_22853)) {
        _22854 = (_22853 == 1LL);
    }
    else {
        _22854 = binary_op(EQUALS, _22853, 1LL);
    }
    DeRef(_22853);
    _22853 = NOVALUE;
    if (IS_ATOM_INT(_22854))
    _22852 = (_22854 != 0);
    else
    _22852 = DBL_PTR(_22854)->dbl != 0.0;
LF: 
    if (_22852 == 0) {
        goto L10; // [476] 513
    }
    if (IS_ATOM_INT(_v_43553) && IS_ATOM_INT(_36NOVALUE_21613)) {
        _22856 = (_v_43553 != _36NOVALUE_21613);
    }
    else {
        _22856 = binary_op(NOTEQ, _v_43553, _36NOVALUE_21613);
    }
    if (_22856 == 0) {
        DeRef(_22856);
        _22856 = NOVALUE;
        goto L10; // [487] 513
    }
    else {
        if (!IS_ATOM_INT(_22856) && DBL_PTR(_22856)->dbl == 0.0){
            DeRef(_22856);
            _22856 = NOVALUE;
            goto L10; // [487] 513
        }
        DeRef(_22856);
        _22856 = NOVALUE;
    }
    DeRef(_22856);
    _22856 = NOVALUE;

    /** c_decl.e:657				c_printf("%d", v)*/
    RefDS(_22805);
    Ref(_v_43553);
    _55c_printf(_22805, _v_43553);

    /** c_decl.e:658				if TARGET_SIZEOF_POINTER = 8 then*/
    if (_36TARGET_SIZEOF_POINTER_21581 != 8LL)
    goto L11; // [500] 532

    /** c_decl.e:659					c_puts( "LL" )*/
    RefDS(_22807);
    _55c_puts(_22807);
    goto L11; // [510] 532
L10: 

    /** c_decl.e:662				c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22858 = (object)*(((s1_ptr)_2)->base + _s_43552);
    _2 = (object)SEQ_PTR(_22858);
    _22859 = (object)*(((s1_ptr)_2)->base + 34LL);
    _22858 = NOVALUE;
    RefDS(_22309);
    Ref(_22859);
    _55c_printf(_22309, _22859);
    _22859 = NOVALUE;
L11: 
L8: 

    /** c_decl.e:666		LeftSym = FALSE*/
    _58LeftSym_42886 = _13FALSE_445;

    /** c_decl.e:667	end procedure*/
    DeRef(_v_43553);
    DeRef(_22828);
    _22828 = NOVALUE;
    DeRef(_22851);
    _22851 = NOVALUE;
    DeRef(_22854);
    _22854 = NOVALUE;
    DeRef(_22836);
    _22836 = NOVALUE;
    DeRef(_22832);
    _22832 = NOVALUE;
    DeRef(_22817);
    _22817 = NOVALUE;
    DeRef(_22834);
    _22834 = NOVALUE;
    DeRef(_22802);
    _22802 = NOVALUE;
    DeRef(_22838);
    _22838 = NOVALUE;
    DeRef(_22799);
    _22799 = NOVALUE;
    return;
    ;
}


void _58c_stmt(object _stmt_43700, object _arg_43701, object _lhs_arg_43703)
{
    object _argcount_43704 = NOVALUE;
    object _i_43705 = NOVALUE;
    object _22914 = NOVALUE;
    object _22913 = NOVALUE;
    object _22912 = NOVALUE;
    object _22911 = NOVALUE;
    object _22910 = NOVALUE;
    object _22909 = NOVALUE;
    object _22908 = NOVALUE;
    object _22907 = NOVALUE;
    object _22906 = NOVALUE;
    object _22905 = NOVALUE;
    object _22904 = NOVALUE;
    object _22903 = NOVALUE;
    object _22902 = NOVALUE;
    object _22901 = NOVALUE;
    object _22900 = NOVALUE;
    object _22899 = NOVALUE;
    object _22898 = NOVALUE;
    object _22896 = NOVALUE;
    object _22894 = NOVALUE;
    object _22892 = NOVALUE;
    object _22891 = NOVALUE;
    object _22890 = NOVALUE;
    object _22889 = NOVALUE;
    object _22887 = NOVALUE;
    object _22886 = NOVALUE;
    object _22885 = NOVALUE;
    object _22884 = NOVALUE;
    object _22883 = NOVALUE;
    object _22882 = NOVALUE;
    object _22881 = NOVALUE;
    object _22880 = NOVALUE;
    object _22879 = NOVALUE;
    object _22878 = NOVALUE;
    object _22877 = NOVALUE;
    object _22876 = NOVALUE;
    object _22875 = NOVALUE;
    object _22874 = NOVALUE;
    object _22871 = NOVALUE;
    object _22870 = NOVALUE;
    object _22869 = NOVALUE;
    object _22868 = NOVALUE;
    object _22867 = NOVALUE;
    object _22866 = NOVALUE;
    object _22864 = NOVALUE;
    object _22862 = NOVALUE;
    object _22861 = NOVALUE;
    object _22860 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_43703)) {
        _1 = (object)(DBL_PTR(_lhs_arg_43703)->dbl);
        DeRefDS(_lhs_arg_43703);
        _lhs_arg_43703 = _1;
    }

    /** c_decl.e:675		if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22860 = (_58LAST_PASS_42876 == _13TRUE_447);
    if (_22860 == 0) {
        goto L1; // [15] 47
    }
    _22862 = (_36Initializing_21843 == _13FALSE_445);
    if (_22862 == 0)
    {
        DeRef(_22862);
        _22862 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22862);
        _22862 = NOVALUE;
    }

    /** c_decl.e:676			cfile_size += 1*/
    _36cfile_size_21842 = _36cfile_size_21842 + 1LL;

    /** c_decl.e:677			update_checksum( stmt )*/
    RefDS(_stmt_43700);
    _56update_checksum(_stmt_43700);
L1: 

    /** c_decl.e:681		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** c_decl.e:682			adjust_indent_before(stmt)*/
    RefDS(_stmt_43700);
    _55adjust_indent_before(_stmt_43700);
L2: 

    /** c_decl.e:685		if atom(arg) then*/
    _22864 = IS_ATOM(_arg_43701);
    if (_22864 == 0)
    {
        _22864 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22864 = NOVALUE;
    }

    /** c_decl.e:686			arg = {arg}*/
    _0 = _arg_43701;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_arg_43701);
    ((intptr_t*)_2)[1] = _arg_43701;
    _arg_43701 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** c_decl.e:689		argcount = 1*/
    _argcount_43704 = 1LL;

    /** c_decl.e:690		i = 1*/
    _i_43705 = 1LL;

    /** c_decl.e:691		while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_43700)){
            _22866 = SEQ_PTR(_stmt_43700)->length;
    }
    else {
        _22866 = 1;
    }
    _22867 = (_i_43705 <= _22866);
    _22866 = NOVALUE;
    if (_22867 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_43700)){
            _22869 = SEQ_PTR(_stmt_43700)->length;
    }
    else {
        _22869 = 1;
    }
    _22870 = (_22869 > 0LL);
    _22869 = NOVALUE;
    if (_22870 == 0)
    {
        DeRef(_22870);
        _22870 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22870);
        _22870 = NOVALUE;
    }

    /** c_decl.e:692			if stmt[i] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22871 = (object)*(((s1_ptr)_2)->base + _i_43705);
    if (binary_op_a(NOTEQ, _22871, 64LL)){
        _22871 = NOVALUE;
        goto L6; // [118] 288
    }
    _22871 = NOVALUE;

    /** c_decl.e:694				if i = 1 then*/
    if (_i_43705 != 1LL)
    goto L7; // [124] 138

    /** c_decl.e:695					LeftSym = TRUE*/
    _58LeftSym_42886 = _13TRUE_447;
L7: 

    /** c_decl.e:698				if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_43700)){
            _22874 = SEQ_PTR(_stmt_43700)->length;
    }
    else {
        _22874 = 1;
    }
    _22875 = (_i_43705 < _22874);
    _22874 = NOVALUE;
    if (_22875 == 0) {
        _22876 = 0;
        goto L8; // [147] 167
    }
    _22877 = _i_43705 + 1;
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22878 = (object)*(((s1_ptr)_2)->base + _22877);
    if (IS_ATOM_INT(_22878)) {
        _22879 = (_22878 > 48LL);
    }
    else {
        _22879 = binary_op(GREATER, _22878, 48LL);
    }
    _22878 = NOVALUE;
    if (IS_ATOM_INT(_22879))
    _22876 = (_22879 != 0);
    else
    _22876 = DBL_PTR(_22879)->dbl != 0.0;
L8: 
    if (_22876 == 0) {
        goto L9; // [167] 249
    }
    _22881 = _i_43705 + 1;
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22882 = (object)*(((s1_ptr)_2)->base + _22881);
    if (IS_ATOM_INT(_22882)) {
        _22883 = (_22882 <= 57LL);
    }
    else {
        _22883 = binary_op(LESSEQ, _22882, 57LL);
    }
    _22882 = NOVALUE;
    if (_22883 == 0) {
        DeRef(_22883);
        _22883 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22883) && DBL_PTR(_22883)->dbl == 0.0){
            DeRef(_22883);
            _22883 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22883);
        _22883 = NOVALUE;
    }
    DeRef(_22883);
    _22883 = NOVALUE;

    /** c_decl.e:700					if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22884 = _i_43705 + 1;
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22885 = (object)*(((s1_ptr)_2)->base + _22884);
    if (IS_ATOM_INT(_22885)) {
        _22886 = _22885 - 48LL;
    }
    else {
        _22886 = binary_op(MINUS, _22885, 48LL);
    }
    _22885 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43701);
    if (!IS_ATOM_INT(_22886)){
        _22887 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22886)->dbl));
    }
    else{
        _22887 = (object)*(((s1_ptr)_2)->base + _22886);
    }
    if (binary_op_a(NOTEQ, _22887, _lhs_arg_43703)){
        _22887 = NOVALUE;
        goto LA; // [205] 219
    }
    _22887 = NOVALUE;

    /** c_decl.e:701						LeftSym = TRUE*/
    _58LeftSym_42886 = _13TRUE_447;
LA: 

    /** c_decl.e:703					CName(arg[stmt[i+1]-'0'])*/
    _22889 = _i_43705 + 1;
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22890 = (object)*(((s1_ptr)_2)->base + _22889);
    if (IS_ATOM_INT(_22890)) {
        _22891 = _22890 - 48LL;
    }
    else {
        _22891 = binary_op(MINUS, _22890, 48LL);
    }
    _22890 = NOVALUE;
    _2 = (object)SEQ_PTR(_arg_43701);
    if (!IS_ATOM_INT(_22891)){
        _22892 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_22891)->dbl));
    }
    else{
        _22892 = (object)*(((s1_ptr)_2)->base + _22891);
    }
    Ref(_22892);
    _58CName(_22892);
    _22892 = NOVALUE;

    /** c_decl.e:704					i += 1*/
    _i_43705 = _i_43705 + 1;
    goto LB; // [246] 279
L9: 

    /** c_decl.e:708					if arg[argcount] = lhs_arg then*/
    _2 = (object)SEQ_PTR(_arg_43701);
    _22894 = (object)*(((s1_ptr)_2)->base + _argcount_43704);
    if (binary_op_a(NOTEQ, _22894, _lhs_arg_43703)){
        _22894 = NOVALUE;
        goto LC; // [255] 269
    }
    _22894 = NOVALUE;

    /** c_decl.e:709						LeftSym = TRUE*/
    _58LeftSym_42886 = _13TRUE_447;
LC: 

    /** c_decl.e:711					CName(arg[argcount])*/
    _2 = (object)SEQ_PTR(_arg_43701);
    _22896 = (object)*(((s1_ptr)_2)->base + _argcount_43704);
    Ref(_22896);
    _58CName(_22896);
    _22896 = NOVALUE;
LB: 

    /** c_decl.e:714				argcount += 1*/
    _argcount_43704 = _argcount_43704 + 1;
    goto LD; // [285] 353
L6: 

    /** c_decl.e:717				c_putc(stmt[i])*/
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22898 = (object)*(((s1_ptr)_2)->base + _i_43705);
    Ref(_22898);
    _55c_putc(_22898);
    _22898 = NOVALUE;

    /** c_decl.e:718				if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22899 = (object)*(((s1_ptr)_2)->base + _i_43705);
    if (IS_ATOM_INT(_22899)) {
        _22900 = (_22899 == 38LL);
    }
    else {
        _22900 = binary_op(EQUALS, _22899, 38LL);
    }
    _22899 = NOVALUE;
    if (IS_ATOM_INT(_22900)) {
        if (_22900 == 0) {
            DeRef(_22901);
            _22901 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22900)->dbl == 0.0) {
            DeRef(_22901);
            _22901 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_43700)){
            _22902 = SEQ_PTR(_stmt_43700)->length;
    }
    else {
        _22902 = 1;
    }
    _22903 = (_i_43705 < _22902);
    _22902 = NOVALUE;
    DeRef(_22901);
    _22901 = (_22903 != 0);
LE: 
    if (_22901 == 0) {
        goto LF; // [322] 352
    }
    _22905 = _i_43705 + 1;
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22906 = (object)*(((s1_ptr)_2)->base + _22905);
    if (IS_ATOM_INT(_22906)) {
        _22907 = (_22906 == 64LL);
    }
    else {
        _22907 = binary_op(EQUALS, _22906, 64LL);
    }
    _22906 = NOVALUE;
    if (_22907 == 0) {
        DeRef(_22907);
        _22907 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22907) && DBL_PTR(_22907)->dbl == 0.0){
            DeRef(_22907);
            _22907 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22907);
        _22907 = NOVALUE;
    }
    DeRef(_22907);
    _22907 = NOVALUE;

    /** c_decl.e:719					LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _58LeftSym_42886 = _13TRUE_447;
LF: 
LD: 

    /** c_decl.e:723			if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (object)SEQ_PTR(_stmt_43700);
    _22908 = (object)*(((s1_ptr)_2)->base + _i_43705);
    if (IS_ATOM_INT(_22908)) {
        _22909 = (_22908 == 10LL);
    }
    else {
        _22909 = binary_op(EQUALS, _22908, 10LL);
    }
    _22908 = NOVALUE;
    if (IS_ATOM_INT(_22909)) {
        if (_22909 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22909)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_43700)){
            _22911 = SEQ_PTR(_stmt_43700)->length;
    }
    else {
        _22911 = 1;
    }
    _22912 = (_i_43705 < _22911);
    _22911 = NOVALUE;
    if (_22912 == 0)
    {
        DeRef(_22912);
        _22912 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22912);
        _22912 = NOVALUE;
    }

    /** c_decl.e:724				if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** c_decl.e:725					adjust_indent_after(stmt)*/
    RefDS(_stmt_43700);
    _55adjust_indent_after(_stmt_43700);
L11: 

    /** c_decl.e:727				stmt = stmt[i+1..$]*/
    _22913 = _i_43705 + 1;
    if (_22913 > MAXINT){
        _22913 = NewDouble((eudouble)_22913);
    }
    if (IS_SEQUENCE(_stmt_43700)){
            _22914 = SEQ_PTR(_stmt_43700)->length;
    }
    else {
        _22914 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_43700;
    RHS_Slice(_stmt_43700, _22913, _22914);

    /** c_decl.e:728				i = 0*/
    _i_43705 = 0LL;

    /** c_decl.e:729				if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** c_decl.e:730					adjust_indent_before(stmt)*/
    RefDS(_stmt_43700);
    _55adjust_indent_before(_stmt_43700);
L12: 
L10: 

    /** c_decl.e:734			i += 1*/
    _i_43705 = _i_43705 + 1;

    /** c_decl.e:735		end while*/
    goto L4; // [432] 90
L5: 

    /** c_decl.e:737		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** c_decl.e:738			adjust_indent_after(stmt)*/
    RefDS(_stmt_43700);
    _55adjust_indent_after(_stmt_43700);
L13: 

    /** c_decl.e:740	end procedure*/
    DeRefDS(_stmt_43700);
    DeRef(_arg_43701);
    DeRef(_22905);
    _22905 = NOVALUE;
    DeRef(_22889);
    _22889 = NOVALUE;
    DeRef(_22877);
    _22877 = NOVALUE;
    DeRef(_22860);
    _22860 = NOVALUE;
    DeRef(_22884);
    _22884 = NOVALUE;
    DeRef(_22909);
    _22909 = NOVALUE;
    DeRef(_22886);
    _22886 = NOVALUE;
    DeRef(_22903);
    _22903 = NOVALUE;
    DeRef(_22867);
    _22867 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22879);
    _22879 = NOVALUE;
    DeRef(_22891);
    _22891 = NOVALUE;
    DeRef(_22913);
    _22913 = NOVALUE;
    DeRef(_22875);
    _22875 = NOVALUE;
    DeRef(_22881);
    _22881 = NOVALUE;
    return;
    ;
}


void _58c_stmt0(object _stmt_43799)
{
    object _0, _1, _2;
    

    /** c_decl.e:745		if emit_c_output then*/
    if (_55emit_c_output_46969 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** c_decl.e:746			c_stmt(stmt, {})*/
    RefDS(_stmt_43799);
    RefDS(_22186);
    _58c_stmt(_stmt_43799, _22186, 0LL);
L1: 

    /** c_decl.e:748	end procedure*/
    DeRefDS(_stmt_43799);
    return;
    ;
}


object _58needs_uninit(object _eentry_43804)
{
    object _22937 = NOVALUE;
    object _22936 = NOVALUE;
    object _22935 = NOVALUE;
    object _22934 = NOVALUE;
    object _22933 = NOVALUE;
    object _22932 = NOVALUE;
    object _22931 = NOVALUE;
    object _22930 = NOVALUE;
    object _22929 = NOVALUE;
    object _22928 = NOVALUE;
    object _22927 = NOVALUE;
    object _22926 = NOVALUE;
    object _22925 = NOVALUE;
    object _22924 = NOVALUE;
    object _22923 = NOVALUE;
    object _22922 = NOVALUE;
    object _22921 = NOVALUE;
    object _22920 = NOVALUE;
    object _22919 = NOVALUE;
    object _22918 = NOVALUE;
    object _22917 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:751		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43804);
    _22917 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22917)) {
        _22918 = (_22917 >= 5LL);
    }
    else {
        _22918 = binary_op(GREATEREQ, _22917, 5LL);
    }
    _22917 = NOVALUE;
    if (IS_ATOM_INT(_22918)) {
        if (_22918 == 0) {
            _22919 = 0;
            goto L1; // [17] 77
        }
    }
    else {
        if (DBL_PTR(_22918)->dbl == 0.0) {
            _22919 = 0;
            goto L1; // [17] 77
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43804);
    _22920 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22920)) {
        _22921 = (_22920 <= 6LL);
    }
    else {
        _22921 = binary_op(LESSEQ, _22920, 6LL);
    }
    _22920 = NOVALUE;
    if (IS_ATOM_INT(_22921)) {
        if (_22921 != 0) {
            _22922 = 1;
            goto L2; // [33] 53
        }
    }
    else {
        if (DBL_PTR(_22921)->dbl != 0.0) {
            _22922 = 1;
            goto L2; // [33] 53
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43804);
    _22923 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22923)) {
        _22924 = (_22923 == 11LL);
    }
    else {
        _22924 = binary_op(EQUALS, _22923, 11LL);
    }
    _22923 = NOVALUE;
    DeRef(_22922);
    if (IS_ATOM_INT(_22924))
    _22922 = (_22924 != 0);
    else
    _22922 = DBL_PTR(_22924)->dbl != 0.0;
L2: 
    if (_22922 != 0) {
        _22925 = 1;
        goto L3; // [53] 73
    }
    _2 = (object)SEQ_PTR(_eentry_43804);
    _22926 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22926)) {
        _22927 = (_22926 == 13LL);
    }
    else {
        _22927 = binary_op(EQUALS, _22926, 13LL);
    }
    _22926 = NOVALUE;
    if (IS_ATOM_INT(_22927))
    _22925 = (_22927 != 0);
    else
    _22925 = DBL_PTR(_22927)->dbl != 0.0;
L3: 
    DeRef(_22919);
    _22919 = (_22925 != 0);
L1: 
    if (_22919 == 0) {
        _22928 = 0;
        goto L4; // [77] 97
    }
    _2 = (object)SEQ_PTR(_eentry_43804);
    _22929 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22929)) {
        _22930 = (_22929 != 0LL);
    }
    else {
        _22930 = binary_op(NOTEQ, _22929, 0LL);
    }
    _22929 = NOVALUE;
    if (IS_ATOM_INT(_22930))
    _22928 = (_22930 != 0);
    else
    _22928 = DBL_PTR(_22930)->dbl != 0.0;
L4: 
    if (_22928 == 0) {
        _22931 = 0;
        goto L5; // [97] 117
    }
    _2 = (object)SEQ_PTR(_eentry_43804);
    _22932 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22932)) {
        _22933 = (_22932 != 99LL);
    }
    else {
        _22933 = binary_op(NOTEQ, _22932, 99LL);
    }
    _22932 = NOVALUE;
    if (IS_ATOM_INT(_22933))
    _22931 = (_22933 != 0);
    else
    _22931 = DBL_PTR(_22933)->dbl != 0.0;
L5: 
    if (_22931 == 0) {
        goto L6; // [117] 150
    }
    _2 = (object)SEQ_PTR(_eentry_43804);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _22935 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _22935 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _22936 = find_from(_22935, _38RTN_TOKS_16291, 1LL);
    _22935 = NOVALUE;
    _22937 = (_22936 == 0);
    _22936 = NOVALUE;
    if (_22937 == 0)
    {
        DeRef(_22937);
        _22937 = NOVALUE;
        goto L6; // [138] 150
    }
    else{
        DeRef(_22937);
        _22937 = NOVALUE;
    }

    /** c_decl.e:757			return 1*/
    DeRefDS(_eentry_43804);
    DeRef(_22924);
    _22924 = NOVALUE;
    DeRef(_22921);
    _22921 = NOVALUE;
    DeRef(_22927);
    _22927 = NOVALUE;
    DeRef(_22933);
    _22933 = NOVALUE;
    DeRef(_22918);
    _22918 = NOVALUE;
    DeRef(_22930);
    _22930 = NOVALUE;
    return 1LL;
    goto L7; // [147] 157
L6: 

    /** c_decl.e:759			return 0*/
    DeRefDS(_eentry_43804);
    DeRef(_22924);
    _22924 = NOVALUE;
    DeRef(_22921);
    _22921 = NOVALUE;
    DeRef(_22927);
    _22927 = NOVALUE;
    DeRef(_22933);
    _22933 = NOVALUE;
    DeRef(_22918);
    _22918 = NOVALUE;
    DeRef(_22930);
    _22930 = NOVALUE;
    return 0LL;
L7: 
    ;
}


void _58DeclareFileVars()
{
    object _s_43845 = NOVALUE;
    object _eentry_43847 = NOVALUE;
    object _cleanup_vars_43941 = NOVALUE;
    object _23020 = NOVALUE;
    object _23013 = NOVALUE;
    object _23008 = NOVALUE;
    object _23005 = NOVALUE;
    object _23004 = NOVALUE;
    object _23003 = NOVALUE;
    object _23001 = NOVALUE;
    object _22997 = NOVALUE;
    object _22993 = NOVALUE;
    object _22990 = NOVALUE;
    object _22989 = NOVALUE;
    object _22988 = NOVALUE;
    object _22986 = NOVALUE;
    object _22982 = NOVALUE;
    object _22978 = NOVALUE;
    object _22977 = NOVALUE;
    object _22976 = NOVALUE;
    object _22973 = NOVALUE;
    object _22972 = NOVALUE;
    object _22970 = NOVALUE;
    object _22969 = NOVALUE;
    object _22968 = NOVALUE;
    object _22967 = NOVALUE;
    object _22963 = NOVALUE;
    object _22962 = NOVALUE;
    object _22961 = NOVALUE;
    object _22960 = NOVALUE;
    object _22959 = NOVALUE;
    object _22958 = NOVALUE;
    object _22957 = NOVALUE;
    object _22956 = NOVALUE;
    object _22955 = NOVALUE;
    object _22954 = NOVALUE;
    object _22953 = NOVALUE;
    object _22952 = NOVALUE;
    object _22951 = NOVALUE;
    object _22950 = NOVALUE;
    object _22949 = NOVALUE;
    object _22948 = NOVALUE;
    object _22947 = NOVALUE;
    object _22946 = NOVALUE;
    object _22945 = NOVALUE;
    object _22944 = NOVALUE;
    object _22943 = NOVALUE;
    object _22942 = NOVALUE;
    object _22939 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:769		c_puts("// Declaring file vars\n")*/
    RefDS(_22938);
    _55c_puts(_22938);

    /** c_decl.e:770		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22939 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    _2 = (object)SEQ_PTR(_22939);
    _s_43845 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43845)){
        _s_43845 = (object)DBL_PTR(_s_43845)->dbl;
    }
    _22939 = NOVALUE;

    /** c_decl.e:772		while s do*/
L1: 
    if (_s_43845 == 0)
    {
        goto L2; // [29] 328
    }
    else{
    }

    /** c_decl.e:773			eentry = SymTab[s]*/
    DeRef(_eentry_43847);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_43847 = (object)*(((s1_ptr)_2)->base + _s_43845);
    Ref(_eentry_43847);

    /** c_decl.e:774			if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22942 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22942)) {
        _22943 = (_22942 >= 5LL);
    }
    else {
        _22943 = binary_op(GREATEREQ, _22942, 5LL);
    }
    _22942 = NOVALUE;
    if (IS_ATOM_INT(_22943)) {
        if (_22943 == 0) {
            DeRef(_22944);
            _22944 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22943)->dbl == 0.0) {
            DeRef(_22944);
            _22944 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22945 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22945)) {
        _22946 = (_22945 <= 6LL);
    }
    else {
        _22946 = binary_op(LESSEQ, _22945, 6LL);
    }
    _22945 = NOVALUE;
    if (IS_ATOM_INT(_22946)) {
        if (_22946 != 0) {
            DeRef(_22947);
            _22947 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22946)->dbl != 0.0) {
            DeRef(_22947);
            _22947 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22948 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22948)) {
        _22949 = (_22948 == 11LL);
    }
    else {
        _22949 = binary_op(EQUALS, _22948, 11LL);
    }
    _22948 = NOVALUE;
    DeRef(_22947);
    if (IS_ATOM_INT(_22949))
    _22947 = (_22949 != 0);
    else
    _22947 = DBL_PTR(_22949)->dbl != 0.0;
L4: 
    if (_22947 != 0) {
        _22950 = 1;
        goto L5; // [92] 112
    }
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22951 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (IS_ATOM_INT(_22951)) {
        _22952 = (_22951 == 13LL);
    }
    else {
        _22952 = binary_op(EQUALS, _22951, 13LL);
    }
    _22951 = NOVALUE;
    if (IS_ATOM_INT(_22952))
    _22950 = (_22952 != 0);
    else
    _22950 = DBL_PTR(_22952)->dbl != 0.0;
L5: 
    DeRef(_22944);
    _22944 = (_22950 != 0);
L3: 
    if (_22944 == 0) {
        _22953 = 0;
        goto L6; // [116] 136
    }
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22954 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22954)) {
        _22955 = (_22954 != 0LL);
    }
    else {
        _22955 = binary_op(NOTEQ, _22954, 0LL);
    }
    _22954 = NOVALUE;
    if (IS_ATOM_INT(_22955))
    _22953 = (_22955 != 0);
    else
    _22953 = DBL_PTR(_22955)->dbl != 0.0;
L6: 
    if (_22953 == 0) {
        _22956 = 0;
        goto L7; // [136] 156
    }
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22957 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (IS_ATOM_INT(_22957)) {
        _22958 = (_22957 != 99LL);
    }
    else {
        _22958 = binary_op(NOTEQ, _22957, 99LL);
    }
    _22957 = NOVALUE;
    if (IS_ATOM_INT(_22958))
    _22956 = (_22958 != 0);
    else
    _22956 = DBL_PTR(_22958)->dbl != 0.0;
L7: 
    if (_22956 == 0) {
        goto L8; // [156] 307
    }
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _22960 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _22960 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _22961 = find_from(_22960, _38RTN_TOKS_16291, 1LL);
    _22960 = NOVALUE;
    _22962 = (_22961 == 0);
    _22961 = NOVALUE;
    if (_22962 == 0)
    {
        DeRef(_22962);
        _22962 = NOVALUE;
        goto L8; // [177] 307
    }
    else{
        DeRef(_22962);
        _22962 = NOVALUE;
    }

    /** c_decl.e:780				if eentry[S_TOKEN] = PROC then*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _22963 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _22963 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    if (binary_op_a(NOTEQ, _22963, 27LL)){
        _22963 = NOVALUE;
        goto L9; // [190] 202
    }
    _22963 = NOVALUE;

    /** c_decl.e:781					c_puts( "void ")*/
    RefDS(_22965);
    _55c_puts(_22965);
    goto LA; // [199] 208
L9: 

    /** c_decl.e:783					c_puts("object ")*/
    RefDS(_22966);
    _55c_puts(_22966);
LA: 

    /** c_decl.e:785				c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _22967 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _22967 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    RefDS(_22309);
    Ref(_22967);
    _55c_printf(_22309, _22967);
    _22967 = NOVALUE;

    /** c_decl.e:786				c_puts(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _22968 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _22968 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    Ref(_22968);
    _55c_puts(_22968);
    _22968 = NOVALUE;

    /** c_decl.e:787				if is_integer( eentry[S_OBJ] ) then*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22969 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_22969);
    _22970 = _36is_integer(_22969);
    _22969 = NOVALUE;
    if (_22970 == 0) {
        DeRef(_22970);
        _22970 = NOVALUE;
        goto LB; // [243] 267
    }
    else {
        if (!IS_ATOM_INT(_22970) && DBL_PTR(_22970)->dbl == 0.0){
            DeRef(_22970);
            _22970 = NOVALUE;
            goto LB; // [243] 267
        }
        DeRef(_22970);
        _22970 = NOVALUE;
    }
    DeRef(_22970);
    _22970 = NOVALUE;

    /** c_decl.e:788						c_printf(" = %d%s;\n", { eentry[S_OBJ], LL_suffix} )*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    _22972 = (object)*(((s1_ptr)_2)->base + 1LL);
    RefDS(_59LL_suffix_30330);
    Ref(_22972);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _22972;
    ((intptr_t *)_2)[2] = _59LL_suffix_30330;
    _22973 = MAKE_SEQ(_1);
    _22972 = NOVALUE;
    RefDS(_22971);
    _55c_printf(_22971, _22973);
    _22973 = NOVALUE;
    goto LC; // [264] 273
LB: 

    /** c_decl.e:790					c_puts(" = NOVALUE;\n")*/
    RefDS(_22974);
    _55c_puts(_22974);
LC: 

    /** c_decl.e:793				c_hputs("extern object ")*/
    RefDS(_22975);
    _55c_hputs(_22975);

    /** c_decl.e:794				c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _22976 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _22976 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    RefDS(_22309);
    Ref(_22976);
    _55c_hprintf(_22309, _22976);
    _22976 = NOVALUE;

    /** c_decl.e:795				c_hputs(eentry[S_NAME])*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _22977 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _22977 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    Ref(_22977);
    _55c_hputs(_22977);
    _22977 = NOVALUE;

    /** c_decl.e:797				c_hputs(";\n")*/
    RefDS(_22462);
    _55c_hputs(_22462);
L8: 

    /** c_decl.e:799			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22978 = (object)*(((s1_ptr)_2)->base + _s_43845);
    _2 = (object)SEQ_PTR(_22978);
    _s_43845 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43845)){
        _s_43845 = (object)DBL_PTR(_s_43845)->dbl;
    }
    _22978 = NOVALUE;

    /** c_decl.e:800		end while*/
    goto L1; // [325] 29
L2: 

    /** c_decl.e:801		c_puts("\n")*/
    RefDS(_22381);
    _55c_puts(_22381);

    /** c_decl.e:802		c_hputs("\n")*/
    RefDS(_22381);
    _55c_hputs(_22381);

    /** c_decl.e:803		if dll_option or debug_option then*/
    if (_58dll_option_42889 != 0) {
        goto LD; // [342] 353
    }
    if (_58debug_option_42899 == 0)
    {
        goto LE; // [349] 707
    }
    else{
    }
LD: 

    /** c_decl.e:804			integer cleanup_vars = 0*/
    _cleanup_vars_43941 = 0LL;

    /** c_decl.e:805			c_puts("// Declaring var array for cleanup\n")*/
    RefDS(_22981);
    _55c_puts(_22981);

    /** c_decl.e:806			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22982 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    _2 = (object)SEQ_PTR(_22982);
    _s_43845 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43845)){
        _s_43845 = (object)DBL_PTR(_s_43845)->dbl;
    }
    _22982 = NOVALUE;

    /** c_decl.e:807			c_stmt0( "object_ptr _0var_cleanup[] = {\n" )*/
    RefDS(_22984);
    _58c_stmt0(_22984);

    /** c_decl.e:808			while s do*/
LF: 
    if (_s_43845 == 0)
    {
        goto L10; // [391] 473
    }
    else{
    }

    /** c_decl.e:809				eentry = SymTab[s]*/
    DeRef(_eentry_43847);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_43847 = (object)*(((s1_ptr)_2)->base + _s_43845);
    Ref(_eentry_43847);

    /** c_decl.e:810				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43847);
    _22986 = _58needs_uninit(_eentry_43847);
    if (_22986 == 0) {
        DeRef(_22986);
        _22986 = NOVALUE;
        goto L11; // [410] 452
    }
    else {
        if (!IS_ATOM_INT(_22986) && DBL_PTR(_22986)->dbl == 0.0){
            DeRef(_22986);
            _22986 = NOVALUE;
            goto L11; // [410] 452
        }
        DeRef(_22986);
        _22986 = NOVALUE;
    }
    DeRef(_22986);
    _22986 = NOVALUE;

    /** c_decl.e:812					c_stmt0( sprintf("&_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _22988 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _22988 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _22989 = EPrintf(-9999999, _22987, _22988);
    _22988 = NOVALUE;
    _58c_stmt0(_22989);
    _22989 = NOVALUE;

    /** c_decl.e:813					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _22990 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _22990 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    Ref(_22990);
    _55c_puts(_22990);
    _22990 = NOVALUE;

    /** c_decl.e:814					c_printf(", // %d\n", cleanup_vars )*/
    RefDS(_22991);
    _55c_printf(_22991, _cleanup_vars_43941);

    /** c_decl.e:815					cleanup_vars += 1*/
    _cleanup_vars_43941 = _cleanup_vars_43941 + 1;
L11: 

    /** c_decl.e:818				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22993 = (object)*(((s1_ptr)_2)->base + _s_43845);
    _2 = (object)SEQ_PTR(_22993);
    _s_43845 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43845)){
        _s_43845 = (object)DBL_PTR(_s_43845)->dbl;
    }
    _22993 = NOVALUE;

    /** c_decl.e:819			end while*/
    goto LF; // [470] 391
L10: 

    /** c_decl.e:820			c_stmt0( "0\n" )*/
    RefDS(_22995);
    _58c_stmt0(_22995);

    /** c_decl.e:821			c_stmt0( "};\n" )*/
    RefDS(_22996);
    _58c_stmt0(_22996);

    /** c_decl.e:822			s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _22997 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    _2 = (object)SEQ_PTR(_22997);
    _s_43845 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43845)){
        _s_43845 = (object)DBL_PTR(_s_43845)->dbl;
    }
    _22997 = NOVALUE;

    /** c_decl.e:823			c_stmt0( "char *_0var_cleanup_name[] = {\n" )*/
    RefDS(_22999);
    _58c_stmt0(_22999);

    /** c_decl.e:824			cleanup_vars = 0*/
    _cleanup_vars_43941 = 0LL;

    /** c_decl.e:825			while s do*/
L12: 
    if (_s_43845 == 0)
    {
        goto L13; // [516] 598
    }
    else{
    }

    /** c_decl.e:826				eentry = SymTab[s]*/
    DeRef(_eentry_43847);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_43847 = (object)*(((s1_ptr)_2)->base + _s_43845);
    Ref(_eentry_43847);

    /** c_decl.e:827				if needs_uninit( eentry ) then*/
    RefDS(_eentry_43847);
    _23001 = _58needs_uninit(_eentry_43847);
    if (_23001 == 0) {
        DeRef(_23001);
        _23001 = NOVALUE;
        goto L14; // [535] 577
    }
    else {
        if (!IS_ATOM_INT(_23001) && DBL_PTR(_23001)->dbl == 0.0){
            DeRef(_23001);
            _23001 = NOVALUE;
            goto L14; // [535] 577
        }
        DeRef(_23001);
        _23001 = NOVALUE;
    }
    DeRef(_23001);
    _23001 = NOVALUE;

    /** c_decl.e:828					c_stmt0( sprintf("\"_%d", eentry[S_FILE_NO]))*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23003 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23003 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _23004 = EPrintf(-9999999, _23002, _23003);
    _23003 = NOVALUE;
    _58c_stmt0(_23004);
    _23004 = NOVALUE;

    /** c_decl.e:829					c_puts(eentry[S_NAME] )*/
    _2 = (object)SEQ_PTR(_eentry_43847);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _23005 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _23005 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    Ref(_23005);
    _55c_puts(_23005);
    _23005 = NOVALUE;

    /** c_decl.e:830					c_printf("\", // %d\n", cleanup_vars )*/
    RefDS(_23006);
    _55c_printf(_23006, _cleanup_vars_43941);

    /** c_decl.e:831					cleanup_vars += 1*/
    _cleanup_vars_43941 = _cleanup_vars_43941 + 1;
L14: 

    /** c_decl.e:834				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23008 = (object)*(((s1_ptr)_2)->base + _s_43845);
    _2 = (object)SEQ_PTR(_23008);
    _s_43845 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_43845)){
        _s_43845 = (object)DBL_PTR(_s_43845)->dbl;
    }
    _23008 = NOVALUE;

    /** c_decl.e:835			end while*/
    goto L12; // [595] 516
L13: 

    /** c_decl.e:836			c_stmt0( "0\n" )*/
    RefDS(_22995);
    _58c_stmt0(_22995);

    /** c_decl.e:837			c_stmt0( "};\n" )*/
    RefDS(_22996);
    _58c_stmt0(_22996);

    /** c_decl.e:838			c_stmt0( "void _0cleanup_vars(){\n" )*/
    RefDS(_23010);
    _58c_stmt0(_23010);

    /** c_decl.e:839				c_stmt0( "int i;\n" )*/
    RefDS(_22270);
    _58c_stmt0(_22270);

    /** c_decl.e:840				c_stmt0( "object x;\n" )*/
    RefDS(_23011);
    _58c_stmt0(_23011);

    /** c_decl.e:841				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23013 = EPrintf(-9999999, _23012, _cleanup_vars_43941);
    _58c_stmt0(_23013);
    _23013 = NOVALUE;

    /** c_decl.e:842					c_stmt0( "x = *_0var_cleanup[i];\n" )*/
    RefDS(_23014);
    _58c_stmt0(_23014);

    //c_decl.e:843					c_stmt0( "if( x >= NOVALUE ) /* do nothing */;\n" )
    RefDS(_23015);
    _58c_stmt0(_23015);

    /** c_decl.e:844					c_stmt0( "else if ( IS_ATOM_DBL( x ) && DBL_PTR( x )->cleanup != 0) {\n")*/
    RefDS(_23016);
    _58c_stmt0(_23016);

    /** c_decl.e:845						c_stmt0( "cleanup_double( DBL_PTR( x ) );\n")*/
    RefDS(_23017);
    _58c_stmt0(_23017);

    /** c_decl.e:846					c_stmt0( "}\n" )*/
    RefDS(_16164);
    _58c_stmt0(_16164);

    /** c_decl.e:847						c_stmt0( "else if (IS_SEQUENCE( x ) && SEQ_PTR( x )->cleanup != 0 ) {\n")*/
    RefDS(_23018);
    _58c_stmt0(_23018);

    /** c_decl.e:848						c_stmt0( "cleanup_sequence( SEQ_PTR( x ) );\n")*/
    RefDS(_23019);
    _58c_stmt0(_23019);

    /** c_decl.e:849					c_stmt0( "}\n" )*/
    RefDS(_16164);
    _58c_stmt0(_16164);

    /** c_decl.e:850				c_stmt0( "}\n" )*/
    RefDS(_16164);
    _58c_stmt0(_16164);

    /** c_decl.e:851				c_stmt0( sprintf( "for( i = 0; i < %d; ++i ){\n", cleanup_vars ) )*/
    _23020 = EPrintf(-9999999, _23012, _cleanup_vars_43941);
    _58c_stmt0(_23020);
    _23020 = NOVALUE;

    /** c_decl.e:852					c_stmt0( "DeRef( *_0var_cleanup[i] );\n" )*/
    RefDS(_23021);
    _58c_stmt0(_23021);

    /** c_decl.e:853					c_stmt0( "*_0var_cleanup[i] = NOVALUE;\n" )*/
    RefDS(_23022);
    _58c_stmt0(_23022);

    /** c_decl.e:854				c_stmt0( "}\n" )*/
    RefDS(_16164);
    _58c_stmt0(_16164);

    /** c_decl.e:855			c_stmt0( "}\n" )*/
    RefDS(_16164);
    _58c_stmt0(_16164);
LE: 

    /** c_decl.e:857	end procedure*/
    DeRef(_eentry_43847);
    DeRef(_22952);
    _22952 = NOVALUE;
    DeRef(_22949);
    _22949 = NOVALUE;
    DeRef(_22958);
    _22958 = NOVALUE;
    DeRef(_22955);
    _22955 = NOVALUE;
    DeRef(_22946);
    _22946 = NOVALUE;
    DeRef(_22943);
    _22943 = NOVALUE;
    return;
    ;
}


object _58PromoteTypeInfo()
{
    object _updsym_44012 = NOVALUE;
    object _s_44014 = NOVALUE;
    object _sym_44015 = NOVALUE;
    object _symo_44016 = NOVALUE;
    object _upd_44245 = NOVALUE;
    object _23121 = NOVALUE;
    object _23119 = NOVALUE;
    object _23118 = NOVALUE;
    object _23117 = NOVALUE;
    object _23116 = NOVALUE;
    object _23114 = NOVALUE;
    object _23112 = NOVALUE;
    object _23111 = NOVALUE;
    object _23110 = NOVALUE;
    object _23109 = NOVALUE;
    object _23108 = NOVALUE;
    object _23104 = NOVALUE;
    object _23101 = NOVALUE;
    object _23100 = NOVALUE;
    object _23099 = NOVALUE;
    object _23098 = NOVALUE;
    object _23097 = NOVALUE;
    object _23096 = NOVALUE;
    object _23095 = NOVALUE;
    object _23094 = NOVALUE;
    object _23093 = NOVALUE;
    object _23092 = NOVALUE;
    object _23091 = NOVALUE;
    object _23089 = NOVALUE;
    object _23088 = NOVALUE;
    object _23087 = NOVALUE;
    object _23086 = NOVALUE;
    object _23085 = NOVALUE;
    object _23084 = NOVALUE;
    object _23083 = NOVALUE;
    object _23082 = NOVALUE;
    object _23081 = NOVALUE;
    object _23080 = NOVALUE;
    object _23078 = NOVALUE;
    object _23077 = NOVALUE;
    object _23076 = NOVALUE;
    object _23074 = NOVALUE;
    object _23073 = NOVALUE;
    object _23072 = NOVALUE;
    object _23070 = NOVALUE;
    object _23069 = NOVALUE;
    object _23068 = NOVALUE;
    object _23067 = NOVALUE;
    object _23066 = NOVALUE;
    object _23065 = NOVALUE;
    object _23064 = NOVALUE;
    object _23062 = NOVALUE;
    object _23061 = NOVALUE;
    object _23060 = NOVALUE;
    object _23059 = NOVALUE;
    object _23057 = NOVALUE;
    object _23056 = NOVALUE;
    object _23054 = NOVALUE;
    object _23053 = NOVALUE;
    object _23052 = NOVALUE;
    object _23051 = NOVALUE;
    object _23050 = NOVALUE;
    object _23049 = NOVALUE;
    object _23048 = NOVALUE;
    object _23046 = NOVALUE;
    object _23045 = NOVALUE;
    object _23044 = NOVALUE;
    object _23043 = NOVALUE;
    object _23042 = NOVALUE;
    object _23041 = NOVALUE;
    object _23040 = NOVALUE;
    object _23039 = NOVALUE;
    object _23038 = NOVALUE;
    object _23037 = NOVALUE;
    object _23036 = NOVALUE;
    object _23035 = NOVALUE;
    object _23034 = NOVALUE;
    object _23033 = NOVALUE;
    object _23031 = NOVALUE;
    object _23030 = NOVALUE;
    object _23029 = NOVALUE;
    object _23027 = NOVALUE;
    object _23026 = NOVALUE;
    object _23023 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:866		sequence sym, symo*/

    /** c_decl.e:868		updsym = 0*/
    _updsym_44012 = 0LL;

    /** c_decl.e:869		g_has_delete = p_has_delete*/
    _58g_has_delete_43071 = _58p_has_delete_43072;

    /** c_decl.e:870		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23023 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    _2 = (object)SEQ_PTR(_23023);
    _s_44014 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44014)){
        _s_44014 = (object)DBL_PTR(_s_44014)->dbl;
    }
    _23023 = NOVALUE;

    /** c_decl.e:871		while s do*/
L1: 
    if (_s_44014 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** c_decl.e:872			sym = SymTab[s]*/
    DeRef(_sym_44015);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _sym_44015 = (object)*(((s1_ptr)_2)->base + _s_44014);
    Ref(_sym_44015);

    /** c_decl.e:873			symo = sym*/
    RefDS(_sym_44015);
    DeRef(_symo_44016);
    _symo_44016 = _sym_44015;

    /** c_decl.e:874			if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23026 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23026 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    if (IS_ATOM_INT(_23026)) {
        _23027 = (_23026 == 501LL);
    }
    else {
        _23027 = binary_op(EQUALS, _23026, 501LL);
    }
    _23026 = NOVALUE;
    if (IS_ATOM_INT(_23027)) {
        if (_23027 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_23027)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23029 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23029 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    if (IS_ATOM_INT(_23029)) {
        _23030 = (_23029 == 504LL);
    }
    else {
        _23030 = binary_op(EQUALS, _23029, 504LL);
    }
    _23029 = NOVALUE;
    if (_23030 == 0) {
        DeRef(_23030);
        _23030 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_23030) && DBL_PTR(_23030)->dbl == 0.0){
            DeRef(_23030);
            _23030 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_23030);
        _23030 = NOVALUE;
    }
    DeRef(_23030);
    _23030 = NOVALUE;
L3: 

    /** c_decl.e:875				if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23031 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (binary_op_a(NOTEQ, _23031, 0LL)){
        _23031 = NOVALUE;
        goto L5; // [103] 120
    }
    _23031 = NOVALUE;

    /** c_decl.e:876					sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** c_decl.e:878					sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23033 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_23033);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23033;
    if( _1 != _23033 ){
        DeRef(_1);
    }
    _23033 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** c_decl.e:883				if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23034 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_23034)) {
        _23035 = (_23034 != 1LL);
    }
    else {
        _23035 = binary_op(NOTEQ, _23034, 1LL);
    }
    _23034 = NOVALUE;
    if (IS_ATOM_INT(_23035)) {
        if (_23035 == 0) {
            DeRef(_23036);
            _23036 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_23035)->dbl == 0.0) {
            DeRef(_23036);
            _23036 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23037 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23037)) {
        _23038 = (_23037 != 16LL);
    }
    else {
        _23038 = binary_op(NOTEQ, _23037, 16LL);
    }
    _23037 = NOVALUE;
    DeRef(_23036);
    if (IS_ATOM_INT(_23038))
    _23036 = (_23038 != 0);
    else
    _23036 = DBL_PTR(_23038)->dbl != 0.0;
L7: 
    if (_23036 == 0) {
        goto L8; // [172] 283
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23040 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23040)) {
        _23041 = (_23040 != 0LL);
    }
    else {
        _23041 = binary_op(NOTEQ, _23040, 0LL);
    }
    _23040 = NOVALUE;
    if (_23041 == 0) {
        DeRef(_23041);
        _23041 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_23041) && DBL_PTR(_23041)->dbl == 0.0){
            DeRef(_23041);
            _23041 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_23041);
        _23041 = NOVALUE;
    }
    DeRef(_23041);
    _23041 = NOVALUE;

    /** c_decl.e:886					if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23042 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23042)) {
        _23043 = (_23042 == 1LL);
    }
    else {
        _23043 = binary_op(EQUALS, _23042, 1LL);
    }
    _23042 = NOVALUE;
    if (IS_ATOM_INT(_23043)) {
        if (_23043 != 0) {
            DeRef(_23044);
            _23044 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_23043)->dbl != 0.0) {
            DeRef(_23044);
            _23044 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23045 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_23045)) {
        _23046 = (_23045 == 16LL);
    }
    else {
        _23046 = binary_op(EQUALS, _23045, 16LL);
    }
    _23045 = NOVALUE;
    DeRef(_23044);
    if (IS_ATOM_INT(_23046))
    _23044 = (_23046 != 0);
    else
    _23044 = DBL_PTR(_23046)->dbl != 0.0;
L9: 
    if (_23044 != 0) {
        goto LA; // [226] 267
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23048 = (object)*(((s1_ptr)_2)->base + 36LL);
    if (IS_ATOM_INT(_23048)) {
        _23049 = (_23048 == 4LL);
    }
    else {
        _23049 = binary_op(EQUALS, _23048, 4LL);
    }
    _23048 = NOVALUE;
    if (IS_ATOM_INT(_23049)) {
        if (_23049 == 0) {
            DeRef(_23050);
            _23050 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_23049)->dbl == 0.0) {
            DeRef(_23050);
            _23050 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23051 = (object)*(((s1_ptr)_2)->base + 38LL);
    if (IS_ATOM_INT(_23051)) {
        _23052 = (_23051 == 2LL);
    }
    else {
        _23052 = binary_op(EQUALS, _23051, 2LL);
    }
    _23051 = NOVALUE;
    DeRef(_23050);
    if (IS_ATOM_INT(_23052))
    _23050 = (_23052 != 0);
    else
    _23050 = DBL_PTR(_23052)->dbl != 0.0;
LB: 
    if (_23050 == 0)
    {
        _23050 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _23050 = NOVALUE;
    }
LA: 

    /** c_decl.e:890							sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23053 = (object)*(((s1_ptr)_2)->base + 38LL);
    Ref(_23053);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23053;
    if( _1 != _23053 ){
        DeRef(_1);
    }
    _23053 = NOVALUE;
LC: 
L8: 

    /** c_decl.e:893				if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23054 = (object)*(((s1_ptr)_2)->base + 44LL);
    if (binary_op_a(NOTEQ, _23054, 0LL)){
        _23054 = NOVALUE;
        goto LD; // [293] 310
    }
    _23054 = NOVALUE;

    /** c_decl.e:894					sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** c_decl.e:896					sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23056 = (object)*(((s1_ptr)_2)->base + 44LL);
    Ref(_23056);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23056;
    if( _1 != _23056 ){
        DeRef(_1);
    }
    _23056 = NOVALUE;
LE: 

    /** c_decl.e:898				sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:900				if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23057 = (object)*(((s1_ptr)_2)->base + 46LL);
    if (binary_op_a(NOTEQ, _23057, 0LL)){
        _23057 = NOVALUE;
        goto LF; // [345] 362
    }
    _23057 = NOVALUE;

    /** c_decl.e:901					sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** c_decl.e:903					sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23059 = (object)*(((s1_ptr)_2)->base + 46LL);
    Ref(_23059);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23059;
    if( _1 != _23059 ){
        DeRef(_1);
    }
    _23059 = NOVALUE;
L10: 

    /** c_decl.e:905				sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:907				if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23060 = (object)*(((s1_ptr)_2)->base + 49LL);
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23061 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23061 = - _36NOVALUE_21613;
        }
    }
    else {
        _23061 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    if (IS_ATOM_INT(_23060) && IS_ATOM_INT(_23061)) {
        _23062 = (_23060 == _23061);
    }
    else {
        _23062 = binary_op(EQUALS, _23060, _23061);
    }
    _23060 = NOVALUE;
    DeRef(_23061);
    _23061 = NOVALUE;
    if (IS_ATOM_INT(_23062)) {
        if (_23062 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_23062)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23064 = (object)*(((s1_ptr)_2)->base + 49LL);
    if (IS_ATOM_INT(_23064) && IS_ATOM_INT(_36NOVALUE_21613)) {
        _23065 = (_23064 == _36NOVALUE_21613);
    }
    else {
        _23065 = binary_op(EQUALS, _23064, _36NOVALUE_21613);
    }
    _23064 = NOVALUE;
    if (_23065 == 0) {
        DeRef(_23065);
        _23065 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_23065) && DBL_PTR(_23065)->dbl == 0.0){
            DeRef(_23065);
            _23065 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_23065);
        _23065 = NOVALUE;
    }
    DeRef(_23065);
    _23065 = NOVALUE;
L11: 

    /** c_decl.e:909					sym[S_ARG_MIN] = MININT*/
    Ref(_36MININT_21583);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MININT_21583;
    DeRef(_1);

    /** c_decl.e:910					sym[S_ARG_MAX] = MAXINT*/
    Ref(_36MAXINT_21582);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21582;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** c_decl.e:912					sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23066 = (object)*(((s1_ptr)_2)->base + 49LL);
    Ref(_23066);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23066;
    if( _1 != _23066 ){
        DeRef(_1);
    }
    _23066 = NOVALUE;

    /** c_decl.e:913					sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23067 = (object)*(((s1_ptr)_2)->base + 50LL);
    Ref(_23067);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 48LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23067;
    if( _1 != _23067 ){
        DeRef(_1);
    }
    _23067 = NOVALUE;
L13: 

    /** c_decl.e:915				sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23068 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23068 = - _36NOVALUE_21613;
        }
    }
    else {
        _23068 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23068;
    if( _1 != _23068 ){
        DeRef(_1);
    }
    _23068 = NOVALUE;

    /** c_decl.e:917				if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23069 = (object)*(((s1_ptr)_2)->base + 52LL);
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23070 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23070 = - _36NOVALUE_21613;
        }
    }
    else {
        _23070 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    if (binary_op_a(NOTEQ, _23069, _23070)){
        _23069 = NOVALUE;
        DeRef(_23070);
        _23070 = NOVALUE;
        goto L14; // [503] 520
    }
    _23069 = NOVALUE;
    DeRef(_23070);
    _23070 = NOVALUE;

    /** c_decl.e:918					sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** c_decl.e:920					sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23072 = (object)*(((s1_ptr)_2)->base + 52LL);
    Ref(_23072);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23072;
    if( _1 != _23072 ){
        DeRef(_1);
    }
    _23072 = NOVALUE;
L15: 

    /** c_decl.e:922				sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23073 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23073 = - _36NOVALUE_21613;
        }
    }
    else {
        _23073 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23073;
    if( _1 != _23073 ){
        DeRef(_1);
    }
    _23073 = NOVALUE;
L6: 

    /** c_decl.e:925			sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:927			if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23074 = (object)*(((s1_ptr)_2)->base + 40LL);
    if (binary_op_a(NOTEQ, _23074, 0LL)){
        _23074 = NOVALUE;
        goto L16; // [569] 586
    }
    _23074 = NOVALUE;

    /** c_decl.e:928			   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** c_decl.e:930				sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23076 = (object)*(((s1_ptr)_2)->base + 40LL);
    Ref(_23076);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23076;
    if( _1 != _23076 ){
        DeRef(_1);
    }
    _23076 = NOVALUE;
L17: 

    /** c_decl.e:932			sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:934			if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23077 = (object)*(((s1_ptr)_2)->base + 39LL);
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23078 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23078 = - _36NOVALUE_21613;
        }
    }
    else {
        _23078 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    if (binary_op_a(NOTEQ, _23077, _23078)){
        _23077 = NOVALUE;
        DeRef(_23078);
        _23078 = NOVALUE;
        goto L18; // [624] 641
    }
    _23077 = NOVALUE;
    DeRef(_23078);
    _23078 = NOVALUE;

    /** c_decl.e:935				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21613);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21613;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** c_decl.e:937				sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23080 = (object)*(((s1_ptr)_2)->base + 39LL);
    Ref(_23080);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23080;
    if( _1 != _23080 ){
        DeRef(_1);
    }
    _23080 = NOVALUE;
L19: 

    /** c_decl.e:939			sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23081 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23081 = - _36NOVALUE_21613;
        }
    }
    else {
        _23081 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23081;
    if( _1 != _23081 ){
        DeRef(_1);
    }
    _23081 = NOVALUE;

    /** c_decl.e:941			if sym[S_TOKEN] != NAMESPACE*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23082 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23082 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    if (IS_ATOM_INT(_23082)) {
        _23083 = (_23082 != 523LL);
    }
    else {
        _23083 = binary_op(NOTEQ, _23082, 523LL);
    }
    _23082 = NOVALUE;
    if (IS_ATOM_INT(_23083)) {
        if (_23083 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_23083)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23085 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (IS_ATOM_INT(_23085)) {
        _23086 = (_23085 != 2LL);
    }
    else {
        _23086 = binary_op(NOTEQ, _23085, 2LL);
    }
    _23085 = NOVALUE;
    if (_23086 == 0) {
        DeRef(_23086);
        _23086 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_23086) && DBL_PTR(_23086)->dbl == 0.0){
            DeRef(_23086);
            _23086 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_23086);
        _23086 = NOVALUE;
    }
    DeRef(_23086);
    _23086 = NOVALUE;

    /** c_decl.e:944				if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23087 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23088 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23088 = - _36NOVALUE_21613;
        }
    }
    else {
        _23088 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    if (IS_ATOM_INT(_23087) && IS_ATOM_INT(_23088)) {
        _23089 = (_23087 == _23088);
    }
    else {
        _23089 = binary_op(EQUALS, _23087, _23088);
    }
    _23087 = NOVALUE;
    DeRef(_23088);
    _23088 = NOVALUE;
    if (IS_ATOM_INT(_23089)) {
        if (_23089 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_23089)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    _23091 = (object)*(((s1_ptr)_2)->base + 41LL);
    if (IS_ATOM_INT(_23091) && IS_ATOM_INT(_36NOVALUE_21613)) {
        _23092 = (_23091 == _36NOVALUE_21613);
    }
    else {
        _23092 = binary_op(EQUALS, _23091, _36NOVALUE_21613);
    }
    _23091 = NOVALUE;
    if (_23092 == 0) {
        DeRef(_23092);
        _23092 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_23092) && DBL_PTR(_23092)->dbl == 0.0){
            DeRef(_23092);
            _23092 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_23092);
        _23092 = NOVALUE;
    }
    DeRef(_23092);
    _23092 = NOVALUE;
L1B: 

    /** c_decl.e:946					sym[S_OBJ_MIN] = MININT*/
    Ref(_36MININT_21583);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MININT_21583;
    DeRef(_1);

    /** c_decl.e:947					sym[S_OBJ_MAX] = MAXINT*/
    Ref(_36MAXINT_21582);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21582;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** c_decl.e:949					sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23093 = (object)*(((s1_ptr)_2)->base + 41LL);
    Ref(_23093);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23093;
    if( _1 != _23093 ){
        DeRef(_1);
    }
    _23093 = NOVALUE;

    /** c_decl.e:950					sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23094 = (object)*(((s1_ptr)_2)->base + 42LL);
    Ref(_23094);
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23094;
    if( _1 != _23094 ){
        DeRef(_1);
    }
    _23094 = NOVALUE;
L1D: 
L1A: 

    /** c_decl.e:953			sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21613)) {
        if ((uintptr_t)_36NOVALUE_21613 == (uintptr_t)HIGH_BITS){
            _23095 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _23095 = - _36NOVALUE_21613;
        }
    }
    else {
        _23095 = unary_op(UMINUS, _36NOVALUE_21613);
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23095;
    if( _1 != _23095 ){
        DeRef(_1);
    }
    _23095 = NOVALUE;

    /** c_decl.e:955			if sym[S_NREFS] = 1 and*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23096 = (object)*(((s1_ptr)_2)->base + 12LL);
    if (IS_ATOM_INT(_23096)) {
        _23097 = (_23096 == 1LL);
    }
    else {
        _23097 = binary_op(EQUALS, _23096, 1LL);
    }
    _23096 = NOVALUE;
    if (IS_ATOM_INT(_23097)) {
        if (_23097 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_23097)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23099 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23099 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _23100 = find_from(_23099, _38RTN_TOKS_16291, 1LL);
    _23099 = NOVALUE;
    if (_23100 == 0)
    {
        _23100 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _23100 = NOVALUE;
    }

    /** c_decl.e:957				if sym[S_USAGE] != U_DELETED then*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _23101 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (binary_op_a(EQUALS, _23101, 99LL)){
        _23101 = NOVALUE;
        goto L1F; // [850] 873
    }
    _23101 = NOVALUE;

    /** c_decl.e:958					sym[S_USAGE] = U_DELETED*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 99LL;
    DeRef(_1);

    /** c_decl.e:959					deleted_routines += 1*/
    _58deleted_routines_44009 = _58deleted_routines_44009 + 1;
L1F: 
L1E: 

    /** c_decl.e:962			sym[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_sym_44015);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _sym_44015 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** c_decl.e:963			if not equal(symo, sym) then*/
    if (_symo_44016 == _sym_44015)
    _23104 = 1;
    else if (IS_ATOM_INT(_symo_44016) && IS_ATOM_INT(_sym_44015))
    _23104 = 0;
    else
    _23104 = (compare(_symo_44016, _sym_44015) == 0);
    if (_23104 != 0)
    goto L20; // [888] 906
    _23104 = NOVALUE;

    /** c_decl.e:964				SymTab[s] = sym*/
    RefDS(_sym_44015);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _s_44014);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _sym_44015;
    DeRef(_1);

    /** c_decl.e:965				updsym += 1*/
    _updsym_44012 = _updsym_44012 + 1;
L20: 

    /** c_decl.e:967			s = sym[S_NEXT]*/
    _2 = (object)SEQ_PTR(_sym_44015);
    _s_44014 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44014)){
        _s_44014 = (object)DBL_PTR(_s_44014)->dbl;
    }

    /** c_decl.e:968		end while*/
    goto L1; // [918] 38
L2: 

    /** c_decl.e:971		for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_36temp_name_type_21845)){
            _23108 = SEQ_PTR(_36temp_name_type_21845)->length;
    }
    else {
        _23108 = 1;
    }
    {
        object _i_44242;
        _i_44242 = 1LL;
L21: 
        if (_i_44242 > _23108){
            goto L22; // [928] 1061
        }

        /** c_decl.e:972			integer upd = 0*/
        _upd_44245 = 0LL;

        /** c_decl.e:974			if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21845);
        _23109 = (object)*(((s1_ptr)_2)->base + _i_44242);
        _2 = (object)SEQ_PTR(_23109);
        _23110 = (object)*(((s1_ptr)_2)->base + 1LL);
        _23109 = NOVALUE;
        _2 = (object)SEQ_PTR(_36temp_name_type_21845);
        _23111 = (object)*(((s1_ptr)_2)->base + _i_44242);
        _2 = (object)SEQ_PTR(_23111);
        _23112 = (object)*(((s1_ptr)_2)->base + 2LL);
        _23111 = NOVALUE;
        if (binary_op_a(EQUALS, _23110, _23112)){
            _23110 = NOVALUE;
            _23112 = NOVALUE;
            goto L23; // [966] 1003
        }
        _23110 = NOVALUE;
        _23112 = NOVALUE;

        /** c_decl.e:975				temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21845);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21845 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44242 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_36temp_name_type_21845);
        _23116 = (object)*(((s1_ptr)_2)->base + _i_44242);
        _2 = (object)SEQ_PTR(_23116);
        _23117 = (object)*(((s1_ptr)_2)->base + 2LL);
        _23116 = NOVALUE;
        Ref(_23117);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 1LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _23117;
        if( _1 != _23117 ){
            DeRef(_1);
        }
        _23117 = NOVALUE;
        _23114 = NOVALUE;

        /** c_decl.e:976				upd = 1*/
        _upd_44245 = 1LL;
L23: 

        /** c_decl.e:978			if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21845);
        _23118 = (object)*(((s1_ptr)_2)->base + _i_44242);
        _2 = (object)SEQ_PTR(_23118);
        _23119 = (object)*(((s1_ptr)_2)->base + 2LL);
        _23118 = NOVALUE;
        if (binary_op_a(EQUALS, _23119, 0LL)){
            _23119 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _23119 = NOVALUE;

        /** c_decl.e:979				temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (object)SEQ_PTR(_36temp_name_type_21845);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _36temp_name_type_21845 = MAKE_SEQ(_2);
        }
        _3 = (object)(_i_44242 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 2LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 0LL;
        DeRef(_1);
        _23121 = NOVALUE;

        /** c_decl.e:980				upd = 1*/
        _upd_44245 = 1LL;
L24: 

        /** c_decl.e:982			updsym += upd*/
        _updsym_44012 = _updsym_44012 + _upd_44245;

        /** c_decl.e:983		end for*/
        _i_44242 = _i_44242 + 1LL;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** c_decl.e:985		return updsym*/
    DeRef(_sym_44015);
    DeRef(_symo_44016);
    DeRef(_23083);
    _23083 = NOVALUE;
    DeRef(_23097);
    _23097 = NOVALUE;
    DeRef(_23046);
    _23046 = NOVALUE;
    DeRef(_23049);
    _23049 = NOVALUE;
    DeRef(_23027);
    _23027 = NOVALUE;
    DeRef(_23043);
    _23043 = NOVALUE;
    DeRef(_23035);
    _23035 = NOVALUE;
    DeRef(_23062);
    _23062 = NOVALUE;
    DeRef(_23052);
    _23052 = NOVALUE;
    DeRef(_23038);
    _23038 = NOVALUE;
    DeRef(_23089);
    _23089 = NOVALUE;
    return _updsym_44012;
    ;
}


void _58declare_prototype(object _s_44280)
{
    object _ret_type_44281 = NOVALUE;
    object _scope_44292 = NOVALUE;
    object _23141 = NOVALUE;
    object _23140 = NOVALUE;
    object _23138 = NOVALUE;
    object _23137 = NOVALUE;
    object _23136 = NOVALUE;
    object _23135 = NOVALUE;
    object _23133 = NOVALUE;
    object _23132 = NOVALUE;
    object _23131 = NOVALUE;
    object _23130 = NOVALUE;
    object _23129 = NOVALUE;
    object _23127 = NOVALUE;
    object _23126 = NOVALUE;
    object _23124 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:990		if sym_token( s ) = PROC then*/
    _23124 = _54sym_token(_s_44280);
    if (binary_op_a(NOTEQ, _23124, 27LL)){
        DeRef(_23124);
        _23124 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_23124);
    _23124 = NOVALUE;

    /** c_decl.e:991			ret_type = "void "*/
    RefDS(_22965);
    DeRefi(_ret_type_44281);
    _ret_type_44281 = _22965;
    goto L2; // [22] 33
L1: 

    /** c_decl.e:993			ret_type ="object "*/
    RefDS(_22966);
    DeRefi(_ret_type_44281);
    _ret_type_44281 = _22966;
L2: 

    /** c_decl.e:996		c_hputs(ret_type)*/
    RefDS(_ret_type_44281);
    _55c_hputs(_ret_type_44281);

    /** c_decl.e:999		if dll_option and TWINDOWS  then*/
    if (_58dll_option_42889 == 0) {
        goto L3; // [44] 116
    }
    if (_46TWINDOWS_21906 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** c_decl.e:1000			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23127 = (object)*(((s1_ptr)_2)->base + _s_44280);
    _2 = (object)SEQ_PTR(_23127);
    _scope_44292 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_44292)){
        _scope_44292 = (object)DBL_PTR(_scope_44292)->dbl;
    }
    _23127 = NOVALUE;

    /** c_decl.e:1001			if (scope = SC_PUBLIC*/
    _23129 = (_scope_44292 == 13LL);
    if (_23129 != 0) {
        _23130 = 1;
        goto L4; // [78] 92
    }
    _23131 = (_scope_44292 == 11LL);
    _23130 = (_23131 != 0);
L4: 
    if (_23130 != 0) {
        DeRef(_23132);
        _23132 = 1;
        goto L5; // [92] 106
    }
    _23133 = (_scope_44292 == 6LL);
    _23132 = (_23133 != 0);
L5: 
    if (_23132 == 0)
    {
        _23132 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _23132 = NOVALUE;
    }

    /** c_decl.e:1006				c_hputs("__stdcall ")*/
    RefDS(_23134);
    _55c_hputs(_23134);
L6: 
L3: 

    /** c_decl.e:1010		c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23135 = (object)*(((s1_ptr)_2)->base + _s_44280);
    _2 = (object)SEQ_PTR(_23135);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23136 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23136 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _23135 = NOVALUE;
    RefDS(_22309);
    Ref(_23136);
    _55c_hprintf(_22309, _23136);
    _23136 = NOVALUE;

    /** c_decl.e:1011		c_hputs(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23137 = (object)*(((s1_ptr)_2)->base + _s_44280);
    _2 = (object)SEQ_PTR(_23137);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _23138 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _23138 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _23137 = NOVALUE;
    Ref(_23138);
    _55c_hputs(_23138);
    _23138 = NOVALUE;

    /** c_decl.e:1012		c_hputs("(")*/
    RefDS(_23139);
    _55c_hputs(_23139);

    /** c_decl.e:1014		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23140 = (object)*(((s1_ptr)_2)->base + _s_44280);
    _2 = (object)SEQ_PTR(_23140);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _23141 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _23141 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _23140 = NOVALUE;
    {
        object _i_44321;
        _i_44321 = 1LL;
L7: 
        if (binary_op_a(GREATER, _i_44321, _23141)){
            goto L8; // [172] 206
        }

        /** c_decl.e:1015			if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_44321, 1LL)){
            goto L9; // [181] 193
        }

        /** c_decl.e:1016				c_hputs("object")*/
        RefDS(_23143);
        _55c_hputs(_23143);
        goto LA; // [190] 199
L9: 

        /** c_decl.e:1018				c_hputs(", object")*/
        RefDS(_23144);
        _55c_hputs(_23144);
LA: 

        /** c_decl.e:1020		end for*/
        _0 = _i_44321;
        if (IS_ATOM_INT(_i_44321)) {
            _i_44321 = _i_44321 + 1LL;
            if ((object)((uintptr_t)_i_44321 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44321 = NewDouble((eudouble)_i_44321);
            }
        }
        else {
            _i_44321 = binary_op_a(PLUS, _i_44321, 1LL);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_44321);
    }

    /** c_decl.e:1021		c_hputs(");\n")*/
    RefDS(_22490);
    _55c_hputs(_22490);

    /** c_decl.e:1022	end procedure*/
    DeRefi(_ret_type_44281);
    DeRef(_23131);
    _23131 = NOVALUE;
    _23141 = NOVALUE;
    DeRef(_23129);
    _23129 = NOVALUE;
    DeRef(_23133);
    _23133 = NOVALUE;
    return;
    ;
}


void _58add_to_routine_list(object _s_44337, object _seq_num_44338, object _first_44339)
{
    object _p_44414 = NOVALUE;
    object _23190 = NOVALUE;
    object _23188 = NOVALUE;
    object _23186 = NOVALUE;
    object _23184 = NOVALUE;
    object _23182 = NOVALUE;
    object _23181 = NOVALUE;
    object _23180 = NOVALUE;
    object _23178 = NOVALUE;
    object _23176 = NOVALUE;
    object _23174 = NOVALUE;
    object _23173 = NOVALUE;
    object _23171 = NOVALUE;
    object _23170 = NOVALUE;
    object _23166 = NOVALUE;
    object _23165 = NOVALUE;
    object _23164 = NOVALUE;
    object _23163 = NOVALUE;
    object _23162 = NOVALUE;
    object _23161 = NOVALUE;
    object _23160 = NOVALUE;
    object _23159 = NOVALUE;
    object _23158 = NOVALUE;
    object _23157 = NOVALUE;
    object _23155 = NOVALUE;
    object _23154 = NOVALUE;
    object _23153 = NOVALUE;
    object _23152 = NOVALUE;
    object _23149 = NOVALUE;
    object _23148 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1025		if not first then*/
    if (_first_44339 != 0)
    goto L1; // [9] 18

    /** c_decl.e:1026			c_puts(",\n")*/
    RefDS(_23146);
    _55c_puts(_23146);
L1: 

    /** c_decl.e:1029		c_puts("  {\"")*/
    RefDS(_23147);
    _55c_puts(_23147);

    /** c_decl.e:1031		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23148 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23148);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _23149 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _23149 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _23148 = NOVALUE;
    Ref(_23149);
    _55c_puts(_23149);
    _23149 = NOVALUE;

    /** c_decl.e:1032		c_puts("\", ")*/
    RefDS(_23150);
    _55c_puts(_23150);

    /** c_decl.e:1033		c_puts("(object (*)())")*/
    RefDS(_23151);
    _55c_puts(_23151);

    /** c_decl.e:1034		c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23152 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23152);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23153 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23153 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _23152 = NOVALUE;
    RefDS(_22309);
    Ref(_23153);
    _55c_printf(_22309, _23153);
    _23153 = NOVALUE;

    /** c_decl.e:1035		c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23154 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23154);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _23155 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _23155 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _23154 = NOVALUE;
    Ref(_23155);
    _55c_puts(_23155);
    _23155 = NOVALUE;

    /** c_decl.e:1036		c_printf(", %d", seq_num)*/
    RefDS(_23156);
    _55c_printf(_23156, _seq_num_44338);

    /** c_decl.e:1037		c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23157 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23157);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23158 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23158 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _23157 = NOVALUE;
    RefDS(_23156);
    Ref(_23158);
    _55c_printf(_23156, _23158);
    _23158 = NOVALUE;

    /** c_decl.e:1038		c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23159 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23159);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _23160 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _23160 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _23159 = NOVALUE;
    RefDS(_23156);
    Ref(_23160);
    _55c_printf(_23156, _23160);
    _23160 = NOVALUE;

    /** c_decl.e:1040		if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_46TWINDOWS_21906 == 0) {
        _23161 = 0;
        goto L2; // [131] 141
    }
    _23161 = (_58dll_option_42889 != 0);
L2: 
    if (_23161 == 0) {
        goto L3; // [141] 186
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23163 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23163);
    _23164 = (object)*(((s1_ptr)_2)->base + 4LL);
    _23163 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 6LL;
    ((intptr_t*)_2)[2] = 11LL;
    ((intptr_t*)_2)[3] = 13LL;
    _23165 = MAKE_SEQ(_1);
    _23166 = find_from(_23164, _23165, 1LL);
    _23164 = NOVALUE;
    DeRefDS(_23165);
    _23165 = NOVALUE;
    if (_23166 == 0)
    {
        _23166 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _23166 = NOVALUE;
    }

    /** c_decl.e:1041			c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_23167);
    _55c_puts(_23167);
    goto L4; // [183] 192
L3: 

    /** c_decl.e:1043			c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_23168);
    _55c_puts(_23168);
L4: 

    /** c_decl.e:1046		c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23170 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23170);
    _23171 = (object)*(((s1_ptr)_2)->base + 4LL);
    _23170 = NOVALUE;
    RefDS(_23169);
    Ref(_23171);
    _55c_printf(_23169, _23171);
    _23171 = NOVALUE;

    /** c_decl.e:1047		c_puts("}")*/
    RefDS(_23172);
    _55c_puts(_23172);

    /** c_decl.e:1049		if SymTab[s][S_NREFS] < 2 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23173 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23173);
    _23174 = (object)*(((s1_ptr)_2)->base + 12LL);
    _23173 = NOVALUE;
    if (binary_op_a(GREATEREQ, _23174, 2LL)){
        _23174 = NOVALUE;
        goto L5; // [229] 249
    }
    _23174 = NOVALUE;

    /** c_decl.e:1050			SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15637 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_44337 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _23176 = NOVALUE;
L5: 

    /** c_decl.e:1055		symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23178 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23178);
    _p_44414 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_44414)){
        _p_44414 = (object)DBL_PTR(_p_44414)->dbl;
    }
    _23178 = NOVALUE;

    /** c_decl.e:1056		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23180 = (object)*(((s1_ptr)_2)->base + _s_44337);
    _2 = (object)SEQ_PTR(_23180);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
        _23181 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
    }
    else{
        _23181 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
    }
    _23180 = NOVALUE;
    {
        object _i_44420;
        _i_44420 = 1LL;
L6: 
        if (binary_op_a(GREATER, _i_44420, _23181)){
            goto L7; // [279] 377
        }

        /** c_decl.e:1057			SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44414 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 46LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16LL;
        DeRef(_1);
        _23182 = NOVALUE;

        /** c_decl.e:1058			SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44414 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 44LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = 16LL;
        DeRef(_1);
        _23184 = NOVALUE;

        /** c_decl.e:1059			SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44414 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21613);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 49LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21613;
        DeRef(_1);
        _23186 = NOVALUE;

        /** c_decl.e:1060			SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15637 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_44414 + ((s1_ptr)_2)->base);
        Ref(_36NOVALUE_21613);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 52LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _36NOVALUE_21613;
        DeRef(_1);
        _23188 = NOVALUE;

        /** c_decl.e:1061			p = SymTab[p][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23190 = (object)*(((s1_ptr)_2)->base + _p_44414);
        _2 = (object)SEQ_PTR(_23190);
        _p_44414 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_p_44414)){
            _p_44414 = (object)DBL_PTR(_p_44414)->dbl;
        }
        _23190 = NOVALUE;

        /** c_decl.e:1062		end for*/
        _0 = _i_44420;
        if (IS_ATOM_INT(_i_44420)) {
            _i_44420 = _i_44420 + 1LL;
            if ((object)((uintptr_t)_i_44420 +(uintptr_t) HIGH_BITS) >= 0){
                _i_44420 = NewDouble((eudouble)_i_44420);
            }
        }
        else {
            _i_44420 = binary_op_a(PLUS, _i_44420, 1LL);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_44420);
    }

    /** c_decl.e:1063	end procedure*/
    _23181 = NOVALUE;
    return;
    ;
}


void _58DeclareRoutineList()
{
    object _s_44452 = NOVALUE;
    object _first_44453 = NOVALUE;
    object _seq_num_44454 = NOVALUE;
    object _these_routines_44462 = NOVALUE;
    object _these_routines_44484 = NOVALUE;
    object _23206 = NOVALUE;
    object _23205 = NOVALUE;
    object _23203 = NOVALUE;
    object _23201 = NOVALUE;
    object _23198 = NOVALUE;
    object _23197 = NOVALUE;
    object _23195 = NOVALUE;
    object _23193 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1069		integer first, seq_num*/

    /** c_decl.e:1071		c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_23192);
    _55c_hputs(_23192);

    /** c_decl.e:1073		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1074		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_45041)){
            _23193 = SEQ_PTR(_58file_routines_45041)->length;
    }
    else {
        _23193 = 1;
    }
    {
        object _f_44459;
        _f_44459 = 1LL;
L1: 
        if (_f_44459 > _23193){
            goto L2; // [19] 98
        }

        /** c_decl.e:1075			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44462);
        _2 = (object)SEQ_PTR(_58file_routines_45041);
        _these_routines_44462 = (object)*(((s1_ptr)_2)->base + _f_44459);
        Ref(_these_routines_44462);

        /** c_decl.e:1076			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44462)){
                _23195 = SEQ_PTR(_these_routines_44462)->length;
        }
        else {
            _23195 = 1;
        }
        {
            object _r_44466;
            _r_44466 = 1LL;
L3: 
            if (_r_44466 > _23195){
                goto L4; // [41] 89
            }

            /** c_decl.e:1077				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44462);
            _s_44452 = (object)*(((s1_ptr)_2)->base + _r_44466);
            if (!IS_ATOM_INT(_s_44452)){
                _s_44452 = (object)DBL_PTR(_s_44452)->dbl;
            }

            /** c_decl.e:1078				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23197 = (object)*(((s1_ptr)_2)->base + _s_44452);
            _2 = (object)SEQ_PTR(_23197);
            _23198 = (object)*(((s1_ptr)_2)->base + 5LL);
            _23197 = NOVALUE;
            if (binary_op_a(EQUALS, _23198, 99LL)){
                _23198 = NOVALUE;
                goto L5; // [72] 82
            }
            _23198 = NOVALUE;

            /** c_decl.e:1080					declare_prototype( s )*/
            _58declare_prototype(_s_44452);
L5: 

            /** c_decl.e:1083			end for*/
            _r_44466 = _r_44466 + 1LL;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_44462);
        _these_routines_44462 = NOVALUE;

        /** c_decl.e:1084		end for*/
        _f_44459 = _f_44459 + 1LL;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** c_decl.e:1085		c_puts("\n")*/
    RefDS(_22381);
    _55c_puts(_22381);

    /** c_decl.e:1088		seq_num = 0*/
    _seq_num_44454 = 0LL;

    /** c_decl.e:1089		first = TRUE*/
    _first_44453 = _13TRUE_447;

    /** c_decl.e:1090		c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_23200);
    _55c_puts(_23200);

    /** c_decl.e:1092		for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_58file_routines_45041)){
            _23201 = SEQ_PTR(_58file_routines_45041)->length;
    }
    else {
        _23201 = 1;
    }
    {
        object _f_44481;
        _f_44481 = 1LL;
L6: 
        if (_f_44481 > _23201){
            goto L7; // [129] 222
        }

        /** c_decl.e:1093			sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_44484);
        _2 = (object)SEQ_PTR(_58file_routines_45041);
        _these_routines_44484 = (object)*(((s1_ptr)_2)->base + _f_44481);
        Ref(_these_routines_44484);

        /** c_decl.e:1094			for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_44484)){
                _23203 = SEQ_PTR(_these_routines_44484)->length;
        }
        else {
            _23203 = 1;
        }
        {
            object _r_44488;
            _r_44488 = 1LL;
L8: 
            if (_r_44488 > _23203){
                goto L9; // [151] 213
            }

            /** c_decl.e:1095				s = these_routines[r]*/
            _2 = (object)SEQ_PTR(_these_routines_44484);
            _s_44452 = (object)*(((s1_ptr)_2)->base + _r_44488);
            if (!IS_ATOM_INT(_s_44452)){
                _s_44452 = (object)DBL_PTR(_s_44452)->dbl;
            }

            /** c_decl.e:1096				if SymTab[s][S_RI_TARGET] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23205 = (object)*(((s1_ptr)_2)->base + _s_44452);
            _2 = (object)SEQ_PTR(_23205);
            _23206 = (object)*(((s1_ptr)_2)->base + 53LL);
            _23205 = NOVALUE;
            if (_23206 == 0) {
                _23206 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_23206) && DBL_PTR(_23206)->dbl == 0.0){
                    _23206 = NOVALUE;
                    goto LA; // [180] 200
                }
                _23206 = NOVALUE;
            }
            _23206 = NOVALUE;

            /** c_decl.e:1098					add_to_routine_list( s, seq_num, first )*/
            _58add_to_routine_list(_s_44452, _seq_num_44454, _first_44453);

            /** c_decl.e:1099					first = FALSE*/
            _first_44453 = _13FALSE_445;
LA: 

            /** c_decl.e:1102				seq_num += 1*/
            _seq_num_44454 = _seq_num_44454 + 1;

            /** c_decl.e:1103			end for*/
            _r_44488 = _r_44488 + 1LL;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_44484);
        _these_routines_44484 = NOVALUE;

        /** c_decl.e:1104		end for*/
        _f_44481 = _f_44481 + 1LL;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** c_decl.e:1105		if not first then*/
    if (_first_44453 != 0)
    goto LB; // [224] 233

    /** c_decl.e:1106			c_puts(",\n")*/
    RefDS(_23146);
    _55c_puts(_23146);
LB: 

    /** c_decl.e:1108		c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_23209);
    _55c_puts(_23209);

    /** c_decl.e:1110		c_hputs("extern char ** _02;\n")*/
    RefDS(_23210);
    _55c_hputs(_23210);

    /** c_decl.e:1111		c_puts("char ** _02;\n")*/
    RefDS(_23211);
    _55c_puts(_23211);

    /** c_decl.e:1113		c_hputs("extern object _0switches;\n")*/
    RefDS(_23212);
    _55c_hputs(_23212);

    /** c_decl.e:1114		c_puts("object _0switches;\n")*/
    RefDS(_23213);
    _55c_puts(_23213);

    /** c_decl.e:1115	end procedure*/
    return;
    ;
}


void _58DeclareNameSpaceList()
{
    object _s_44514 = NOVALUE;
    object _first_44515 = NOVALUE;
    object _seq_num_44516 = NOVALUE;
    object _23233 = NOVALUE;
    object _23231 = NOVALUE;
    object _23230 = NOVALUE;
    object _23229 = NOVALUE;
    object _23228 = NOVALUE;
    object _23226 = NOVALUE;
    object _23225 = NOVALUE;
    object _23222 = NOVALUE;
    object _23221 = NOVALUE;
    object _23220 = NOVALUE;
    object _23219 = NOVALUE;
    object _23218 = NOVALUE;
    object _23216 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1121		integer first, seq_num*/

    /** c_decl.e:1123		c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_23214);
    _55c_hputs(_23214);

    /** c_decl.e:1124		c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_23215);
    _55c_puts(_23215);

    /** c_decl.e:1126		seq_num = 0*/
    _seq_num_44516 = 0LL;

    /** c_decl.e:1127		first = TRUE*/
    _first_44515 = _13TRUE_447;

    /** c_decl.e:1129		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23216 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    _2 = (object)SEQ_PTR(_23216);
    _s_44514 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44514)){
        _s_44514 = (object)DBL_PTR(_s_44514)->dbl;
    }
    _23216 = NOVALUE;

    /** c_decl.e:1130		while s do*/
L1: 
    if (_s_44514 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** c_decl.e:1131			if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23218 = (object)*(((s1_ptr)_2)->base + _s_44514);
    _2 = (object)SEQ_PTR(_23218);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23219 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23219 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _23218 = NOVALUE;
    _23220 = find_from(_23219, _38NAMED_TOKS_16293, 1LL);
    _23219 = NOVALUE;
    if (_23220 == 0)
    {
        _23220 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _23220 = NOVALUE;
    }

    /** c_decl.e:1132				if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23221 = (object)*(((s1_ptr)_2)->base + _s_44514);
    _2 = (object)SEQ_PTR(_23221);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23222 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23222 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _23221 = NOVALUE;
    if (binary_op_a(NOTEQ, _23222, 523LL)){
        _23222 = NOVALUE;
        goto L4; // [93] 187
    }
    _23222 = NOVALUE;

    /** c_decl.e:1133					if not first then*/
    if (_first_44515 != 0)
    goto L5; // [99] 108

    /** c_decl.e:1134						c_puts(",\n")*/
    RefDS(_23146);
    _55c_puts(_23146);
L5: 

    /** c_decl.e:1136					first = FALSE*/
    _first_44515 = _13FALSE_445;

    /** c_decl.e:1138					c_puts("  {\"")*/
    RefDS(_23147);
    _55c_puts(_23147);

    /** c_decl.e:1139					c_puts(SymTab[s][S_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23225 = (object)*(((s1_ptr)_2)->base + _s_44514);
    _2 = (object)SEQ_PTR(_23225);
    if (!IS_ATOM_INT(_36S_NAME_21396)){
        _23226 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
    }
    else{
        _23226 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
    }
    _23225 = NOVALUE;
    Ref(_23226);
    _55c_puts(_23226);
    _23226 = NOVALUE;

    /** c_decl.e:1140					c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23228 = (object)*(((s1_ptr)_2)->base + _s_44514);
    _2 = (object)SEQ_PTR(_23228);
    _23229 = (object)*(((s1_ptr)_2)->base + 1LL);
    _23228 = NOVALUE;
    RefDS(_23227);
    Ref(_23229);
    _55c_printf(_23227, _23229);
    _23229 = NOVALUE;

    /** c_decl.e:1141					c_printf(", %d", seq_num)*/
    RefDS(_23156);
    _55c_printf(_23156, _seq_num_44516);

    /** c_decl.e:1142					c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23230 = (object)*(((s1_ptr)_2)->base + _s_44514);
    _2 = (object)SEQ_PTR(_23230);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23231 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23231 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _23230 = NOVALUE;
    RefDS(_23156);
    Ref(_23231);
    _55c_printf(_23156, _23231);
    _23231 = NOVALUE;

    /** c_decl.e:1144					c_puts("}")*/
    RefDS(_23172);
    _55c_puts(_23172);
L4: 

    /** c_decl.e:1146				seq_num += 1*/
    _seq_num_44516 = _seq_num_44516 + 1;
L3: 

    /** c_decl.e:1148			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23233 = (object)*(((s1_ptr)_2)->base + _s_44514);
    _2 = (object)SEQ_PTR(_23233);
    _s_44514 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_44514)){
        _s_44514 = (object)DBL_PTR(_s_44514)->dbl;
    }
    _23233 = NOVALUE;

    /** c_decl.e:1149		end while*/
    goto L1; // [212] 50
L2: 

    /** c_decl.e:1150		if not first then*/
    if (_first_44515 != 0)
    goto L6; // [217] 226

    /** c_decl.e:1151			c_puts(",\n")*/
    RefDS(_23146);
    _55c_puts(_23146);
L6: 

    /** c_decl.e:1153		c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_23236);
    _55c_puts(_23236);

    /** c_decl.e:1154	end procedure*/
    return;
    ;
}


object _58is_exported(object _s_44578)
{
    object _eentry_44579 = NOVALUE;
    object _scope_44582 = NOVALUE;
    object _23251 = NOVALUE;
    object _23250 = NOVALUE;
    object _23249 = NOVALUE;
    object _23248 = NOVALUE;
    object _23247 = NOVALUE;
    object _23246 = NOVALUE;
    object _23245 = NOVALUE;
    object _23244 = NOVALUE;
    object _23243 = NOVALUE;
    object _23242 = NOVALUE;
    object _23241 = NOVALUE;
    object _23239 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_44578)) {
        _1 = (object)(DBL_PTR(_s_44578)->dbl);
        DeRefDS(_s_44578);
        _s_44578 = _1;
    }

    /** c_decl.e:1159		sequence eentry = SymTab[s]*/
    DeRef(_eentry_44579);
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _eentry_44579 = (object)*(((s1_ptr)_2)->base + _s_44578);
    Ref(_eentry_44579);

    /** c_decl.e:1160		integer scope = eentry[S_SCOPE]*/
    _2 = (object)SEQ_PTR(_eentry_44579);
    _scope_44582 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_44582))
    _scope_44582 = (object)DBL_PTR(_scope_44582)->dbl;

    /** c_decl.e:1162		if eentry[S_MODE] = M_NORMAL then*/
    _2 = (object)SEQ_PTR(_eentry_44579);
    _23239 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(NOTEQ, _23239, 1LL)){
        _23239 = NOVALUE;
        goto L1; // [31] 125
    }
    _23239 = NOVALUE;

    /** c_decl.e:1163			if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (object)SEQ_PTR(_eentry_44579);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23241 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23241 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    if (IS_ATOM_INT(_23241)) {
        _23242 = (_23241 == 1LL);
    }
    else {
        _23242 = binary_op(EQUALS, _23241, 1LL);
    }
    _23241 = NOVALUE;
    if (IS_ATOM_INT(_23242)) {
        if (_23242 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_23242)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 11LL;
    ((intptr_t*)_2)[2] = 13LL;
    ((intptr_t*)_2)[3] = 6LL;
    _23244 = MAKE_SEQ(_1);
    _23245 = find_from(_scope_44582, _23244, 1LL);
    DeRefDS(_23244);
    _23244 = NOVALUE;
    if (_23245 == 0)
    {
        _23245 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _23245 = NOVALUE;
    }

    /** c_decl.e:1164				return 1*/
    DeRef(_eentry_44579);
    DeRef(_23242);
    _23242 = NOVALUE;
    return 1LL;
L2: 

    /** c_decl.e:1167			if scope = SC_PUBLIC and*/
    _23246 = (_scope_44582 == 13LL);
    if (_23246 == 0) {
        goto L3; // [87] 124
    }
    _2 = (object)SEQ_PTR(_37include_matrix_15644);
    _23248 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_eentry_44579);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23249 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23249 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _2 = (object)SEQ_PTR(_23248);
    if (!IS_ATOM_INT(_23249)){
        _23250 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23249)->dbl));
    }
    else{
        _23250 = (object)*(((s1_ptr)_2)->base + _23249);
    }
    _23248 = NOVALUE;
    if (IS_ATOM_INT(_23250)) {
        {uintptr_t tu;
             tu = (uintptr_t)_23250 & (uintptr_t)4LL;
             _23251 = MAKE_UINT(tu);
        }
    }
    else {
        _23251 = binary_op(AND_BITS, _23250, 4LL);
    }
    _23250 = NOVALUE;
    if (_23251 == 0) {
        DeRef(_23251);
        _23251 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_23251) && DBL_PTR(_23251)->dbl == 0.0){
            DeRef(_23251);
            _23251 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_23251);
        _23251 = NOVALUE;
    }
    DeRef(_23251);
    _23251 = NOVALUE;

    /** c_decl.e:1170				return 1*/
    DeRef(_eentry_44579);
    DeRef(_23242);
    _23242 = NOVALUE;
    DeRef(_23246);
    _23246 = NOVALUE;
    _23249 = NOVALUE;
    return 1LL;
L3: 
L1: 

    /** c_decl.e:1174		return 0*/
    DeRef(_eentry_44579);
    DeRef(_23242);
    _23242 = NOVALUE;
    DeRef(_23246);
    _23246 = NOVALUE;
    _23249 = NOVALUE;
    return 0LL;
    ;
}


void _58version()
{
    object _23285 = NOVALUE;
    object _23284 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1207		c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _23284 = _33version_string(0LL);
    {
        object concat_list[3];

        concat_list[0] = _22381;
        concat_list[1] = _23284;
        concat_list[2] = _23283;
        Concat_N((object_ptr)&_23285, concat_list, 3);
    }
    DeRef(_23284);
    _23284 = NOVALUE;
    _55c_puts(_23285);
    _23285 = NOVALUE;

    /** c_decl.e:1208	end procedure*/
    return;
    ;
}


void _58new_c_file(object _name_44686)
{
    object _23288 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1213		cfile_size = 0*/
    _36cfile_size_21842 = 0LL;

    /** c_decl.e:1216		if LAST_PASS = FALSE then*/
    if (_58LAST_PASS_42876 != _13FALSE_445)
    goto L1; // [16] 26

    /** c_decl.e:1217			return*/
    DeRefDS(_name_44686);
    return;
L1: 

    /** c_decl.e:1220		write_checksum( c_code )*/
    _56write_checksum(_55c_code_46972);

    /** c_decl.e:1221		close(c_code)*/
    EClose(_55c_code_46972);

    /** c_decl.e:1223		c_code = open(output_dir & name & ".c", "w")*/
    {
        object concat_list[3];

        concat_list[0] = _23287;
        concat_list[1] = _name_44686;
        concat_list[2] = _58output_dir_42903;
        Concat_N((object_ptr)&_23288, concat_list, 3);
    }
    _55c_code_46972 = EOpen(_23288, _22322, 0LL);
    DeRefDS(_23288);
    _23288 = NOVALUE;

    /** c_decl.e:1224		if c_code = -1 then*/
    if (_55c_code_46972 != -1LL)
    goto L2; // [60] 74

    /** c_decl.e:1225			CompileErr(COULDNT_OPEN_C_FILE_FOR_OUTPUT)*/
    RefDS(_22186);
    _50CompileErr(57LL, _22186, 0LL);
L2: 

    /** c_decl.e:1228		cfile_count += 1*/
    _36cfile_count_21841 = _36cfile_count_21841 + 1LL;

    /** c_decl.e:1229		version()*/
    _58version();

    /** c_decl.e:1231		c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_22327);
    _55c_puts(_22327);

    /** c_decl.e:1233		c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_22328);
    _55c_puts(_22328);

    /** c_decl.e:1235		if not TUNIX then*/
    if (_46TUNIX_21910 != 0)
    goto L3; // [102] 114

    /** c_decl.e:1236			name = lower(name)  -- for faster compare later*/
    RefDS(_name_44686);
    _0 = _name_44686;
    _name_44686 = _14lower(_name_44686);
    DeRefDS(_0);
L3: 

    /** c_decl.e:1238	end procedure*/
    DeRefDS(_name_44686);
    return;
    ;
}


object _58unique_c_name(object _name_44716)
{
    object _i_44717 = NOVALUE;
    object _compare_name_44718 = NOVALUE;
    object _next_fc_44719 = NOVALUE;
    object _23304 = NOVALUE;
    object _23302 = NOVALUE;
    object _23301 = NOVALUE;
    object _23300 = NOVALUE;
    object _23298 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1253		compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44718, _name_44716, _23287);

    /** c_decl.e:1254		if not TUNIX then*/
    if (_46TUNIX_21910 != 0)
    goto L1; // [13] 25

    /** c_decl.e:1255			compare_name = lower(compare_name)*/
    RefDS(_compare_name_44718);
    _0 = _compare_name_44718;
    _compare_name_44718 = _14lower(_compare_name_44718);
    DeRefDS(_0);
L1: 

    /** c_decl.e:1258		next_fc = 1*/
    _next_fc_44719 = 1LL;

    /** c_decl.e:1259		i = 1*/
    _i_44717 = 1LL;

    /** c_decl.e:1261		while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_58generated_files_42893)){
            _23298 = SEQ_PTR(_58generated_files_42893)->length;
    }
    else {
        _23298 = 1;
    }
    if (_i_44717 > _23298)
    goto L3; // [45] 141

    /** c_decl.e:1263			if equal(generated_files[i], compare_name) then*/
    _2 = (object)SEQ_PTR(_58generated_files_42893);
    _23300 = (object)*(((s1_ptr)_2)->base + _i_44717);
    if (_23300 == _compare_name_44718)
    _23301 = 1;
    else if (IS_ATOM_INT(_23300) && IS_ATOM_INT(_compare_name_44718))
    _23301 = 0;
    else
    _23301 = (compare(_23300, _compare_name_44718) == 0);
    _23300 = NOVALUE;
    if (_23301 == 0)
    {
        _23301 = NOVALUE;
        goto L4; // [61] 129
    }
    else{
        _23301 = NOVALUE;
    }

    /** c_decl.e:1265				if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_58file_chars_44712)){
            _23302 = SEQ_PTR(_58file_chars_44712)->length;
    }
    else {
        _23302 = 1;
    }
    if (_next_fc_44719 <= _23302)
    goto L5; // [69] 83

    /** c_decl.e:1266					CompileErr(SORRY_TOO_MANY_C_FILES_WITH_THE_SAME_BASE_NAME)*/
    RefDS(_22186);
    _50CompileErr(140LL, _22186, 0LL);
L5: 

    /** c_decl.e:1269				name[1] = file_chars[next_fc]*/
    _2 = (object)SEQ_PTR(_58file_chars_44712);
    _23304 = (object)*(((s1_ptr)_2)->base + _next_fc_44719);
    Ref(_23304);
    _2 = (object)SEQ_PTR(_name_44716);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _name_44716 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23304;
    if( _1 != _23304 ){
        DeRef(_1);
    }
    _23304 = NOVALUE;

    /** c_decl.e:1270				compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_44718, _name_44716, _23287);

    /** c_decl.e:1271				if not TUNIX then*/
    if (_46TUNIX_21910 != 0)
    goto L6; // [103] 115

    /** c_decl.e:1272					compare_name = lower(compare_name)*/
    RefDS(_compare_name_44718);
    _0 = _compare_name_44718;
    _compare_name_44718 = _14lower(_compare_name_44718);
    DeRefDS(_0);
L6: 

    /** c_decl.e:1275				next_fc += 1*/
    _next_fc_44719 = _next_fc_44719 + 1;

    /** c_decl.e:1276				i = 1 -- start over and compare again*/
    _i_44717 = 1LL;
    goto L2; // [126] 40
L4: 

    /** c_decl.e:1279				i += 1*/
    _i_44717 = _i_44717 + 1;

    /** c_decl.e:1281		end while*/
    goto L2; // [138] 40
L3: 

    /** c_decl.e:1283		return name*/
    DeRef(_compare_name_44718);
    return _name_44716;
    ;
}


object _58is_file_newer(object _f1_44749, object _f2_44750)
{
    object _d1_44751 = NOVALUE;
    object _d2_44754 = NOVALUE;
    object _diff_2__tmp_at42_44765 = NOVALUE;
    object _diff_1__tmp_at42_44764 = NOVALUE;
    object _diff_inlined_diff_at_42_44763 = NOVALUE;
    object _23314 = NOVALUE;
    object _23312 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1287		object d1 = file_timestamp(f1)*/
    RefDS(_f1_44749);
    _0 = _d1_44751;
    _d1_44751 = _17file_timestamp(_f1_44749);
    DeRef(_0);

    /** c_decl.e:1288		object d2 = file_timestamp(f2)*/
    RefDS(_f2_44750);
    _0 = _d2_44754;
    _d2_44754 = _17file_timestamp(_f2_44750);
    DeRef(_0);

    /** c_decl.e:1290		if atom(d1) or atom(d2) then return 1 end if*/
    _23312 = IS_ATOM(_d1_44751);
    if (_23312 != 0) {
        goto L1; // [22] 34
    }
    _23314 = IS_ATOM(_d2_44754);
    if (_23314 == 0)
    {
        _23314 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _23314 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_44749);
    DeRefDS(_f2_44750);
    DeRef(_d1_44751);
    DeRef(_d2_44754);
    return 1LL;
L2: 

    /** c_decl.e:1291		if datetime:diff(d1, d2) < 0 then*/

    /** datetime.e:1253		return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_44754);
    _0 = _diff_1__tmp_at42_44764;
    _diff_1__tmp_at42_44764 = _18datetimeToSeconds(_d2_44754);
    DeRef(_0);
    Ref(_d1_44751);
    _0 = _diff_2__tmp_at42_44765;
    _diff_2__tmp_at42_44765 = _18datetimeToSeconds(_d1_44751);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_44763);
    if (IS_ATOM_INT(_diff_1__tmp_at42_44764) && IS_ATOM_INT(_diff_2__tmp_at42_44765)) {
        _diff_inlined_diff_at_42_44763 = _diff_1__tmp_at42_44764 - _diff_2__tmp_at42_44765;
        if ((object)((uintptr_t)_diff_inlined_diff_at_42_44763 +(uintptr_t) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_44763 = NewDouble((eudouble)_diff_inlined_diff_at_42_44763);
        }
    }
    else {
        _diff_inlined_diff_at_42_44763 = binary_op(MINUS, _diff_1__tmp_at42_44764, _diff_2__tmp_at42_44765);
    }
    DeRef(_diff_1__tmp_at42_44764);
    _diff_1__tmp_at42_44764 = NOVALUE;
    DeRef(_diff_2__tmp_at42_44765);
    _diff_2__tmp_at42_44765 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_44763, 0LL)){
        goto L3; // [58] 69
    }

    /** c_decl.e:1292			return 1*/
    DeRefDS(_f1_44749);
    DeRefDS(_f2_44750);
    DeRef(_d1_44751);
    DeRef(_d2_44754);
    return 1LL;
L3: 

    /** c_decl.e:1295		return 0*/
    DeRefDS(_f1_44749);
    DeRefDS(_f2_44750);
    DeRef(_d1_44751);
    DeRef(_d2_44754);
    return 0LL;
    ;
}


void _58add_file(object _filename_44769, object _eu_filename_44770)
{
    object _obj_fname_44790 = NOVALUE;
    object _src_fname_44791 = NOVALUE;
    object _23338 = NOVALUE;
    object _23337 = NOVALUE;
    object _23324 = NOVALUE;
    object _23323 = NOVALUE;
    object _23320 = NOVALUE;
    object _23319 = NOVALUE;
    object _23318 = NOVALUE;
    object _23317 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1303		if equal("c", fileext(filename)) then*/
    RefDS(_filename_44769);
    _23317 = _17fileext(_filename_44769);
    if (_23316 == _23317)
    _23318 = 1;
    else if (IS_ATOM_INT(_23316) && IS_ATOM_INT(_23317))
    _23318 = 0;
    else
    _23318 = (compare(_23316, _23317) == 0);
    DeRef(_23317);
    _23317 = NOVALUE;
    if (_23318 == 0)
    {
        _23318 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _23318 = NOVALUE;
    }

    /** c_decl.e:1304			filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_44769)){
            _23319 = SEQ_PTR(_filename_44769)->length;
    }
    else {
        _23319 = 1;
    }
    _23320 = _23319 - 2LL;
    _23319 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_44769;
    RHS_Slice(_filename_44769, 1LL, _23320);
    goto L2; // [32] 82
L1: 

    /** c_decl.e:1305		elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_44769);
    _23323 = _17fileext(_filename_44769);
    if (_23322 == _23323)
    _23324 = 1;
    else if (IS_ATOM_INT(_23322) && IS_ATOM_INT(_23323))
    _23324 = 0;
    else
    _23324 = (compare(_23322, _23323) == 0);
    DeRef(_23323);
    _23323 = NOVALUE;
    if (_23324 == 0)
    {
        _23324 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _23324 = NOVALUE;
    }

    /** c_decl.e:1306			generated_files = append(generated_files, filename)*/
    RefDS(_filename_44769);
    Append(&_58generated_files_42893, _58generated_files_42893, _filename_44769);

    /** c_decl.e:1307			if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45701 != 3LL)
    goto L4; // [62] 75

    /** c_decl.e:1308				outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42894, _58outdated_files_42894, 0LL);
L4: 

    /** c_decl.e:1311			return*/
    DeRefDS(_filename_44769);
    DeRefDS(_eu_filename_44770);
    DeRef(_obj_fname_44790);
    DeRef(_src_fname_44791);
    DeRef(_23320);
    _23320 = NOVALUE;
    return;
L3: 
L2: 

    /** c_decl.e:1314		sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_44769);
    DeRef(_obj_fname_44790);
    _obj_fname_44790 = _filename_44769;
    Concat((object_ptr)&_src_fname_44791, _filename_44769, _23287);

    /** c_decl.e:1316		if compiler_type = COMPILER_WATCOM then*/
    if (_56compiler_type_45705 != 2LL)
    goto L5; // [99] 112

    /** c_decl.e:1317			obj_fname &= ".obj"*/
    Concat((object_ptr)&_obj_fname_44790, _obj_fname_44790, _23330);
    goto L6; // [109] 119
L5: 

    /** c_decl.e:1319			obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_44790, _obj_fname_44790, _23332);
L6: 

    /** c_decl.e:1322		generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_44791);
    Append(&_58generated_files_42893, _58generated_files_42893, _src_fname_44791);

    /** c_decl.e:1323		generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_44790);
    Append(&_58generated_files_42893, _58generated_files_42893, _obj_fname_44790);

    /** c_decl.e:1324		if build_system_type = BUILD_DIRECT then*/
    if (_56build_system_type_45701 != 3LL)
    goto L7; // [141] 173

    /** c_decl.e:1325			outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_23337, _58output_dir_42903, _src_fname_44791);
    RefDS(_eu_filename_44770);
    _23338 = _58is_file_newer(_eu_filename_44770, _23337);
    _23337 = NOVALUE;
    Ref(_23338);
    Append(&_58outdated_files_42894, _58outdated_files_42894, _23338);
    DeRef(_23338);
    _23338 = NOVALUE;

    /** c_decl.e:1326			outdated_files  = append(outdated_files, 0)*/
    Append(&_58outdated_files_42894, _58outdated_files_42894, 0LL);
L7: 

    /** c_decl.e:1328	end procedure*/
    DeRefDS(_filename_44769);
    DeRefDS(_eu_filename_44770);
    DeRef(_obj_fname_44790);
    DeRef(_src_fname_44791);
    DeRef(_23320);
    _23320 = NOVALUE;
    return;
    ;
}


object _58any_code(object _file_no_44814)
{
    object _these_routines_44816 = NOVALUE;
    object _s_44823 = NOVALUE;
    object _23354 = NOVALUE;
    object _23353 = NOVALUE;
    object _23352 = NOVALUE;
    object _23351 = NOVALUE;
    object _23350 = NOVALUE;
    object _23349 = NOVALUE;
    object _23348 = NOVALUE;
    object _23347 = NOVALUE;
    object _23346 = NOVALUE;
    object _23345 = NOVALUE;
    object _23344 = NOVALUE;
    object _23342 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1334		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1336		sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_44816);
    _2 = (object)SEQ_PTR(_58file_routines_45041);
    _these_routines_44816 = (object)*(((s1_ptr)_2)->base + _file_no_44814);
    Ref(_these_routines_44816);

    /** c_decl.e:1337		for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_44816)){
            _23342 = SEQ_PTR(_these_routines_44816)->length;
    }
    else {
        _23342 = 1;
    }
    {
        object _i_44820;
        _i_44820 = 1LL;
L1: 
        if (_i_44820 > _23342){
            goto L2; // [22] 126
        }

        /** c_decl.e:1338			symtab_index s = these_routines[i]*/
        _2 = (object)SEQ_PTR(_these_routines_44816);
        _s_44823 = (object)*(((s1_ptr)_2)->base + _i_44820);
        if (!IS_ATOM_INT(_s_44823)){
            _s_44823 = (object)DBL_PTR(_s_44823)->dbl;
        }

        /** c_decl.e:1339			if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23344 = (object)*(((s1_ptr)_2)->base + _s_44823);
        _2 = (object)SEQ_PTR(_23344);
        if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
            _23345 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
        }
        else{
            _23345 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
        }
        _23344 = NOVALUE;
        if (IS_ATOM_INT(_23345)) {
            _23346 = (_23345 == _file_no_44814);
        }
        else {
            _23346 = binary_op(EQUALS, _23345, _file_no_44814);
        }
        _23345 = NOVALUE;
        if (IS_ATOM_INT(_23346)) {
            if (_23346 == 0) {
                DeRef(_23347);
                _23347 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_23346)->dbl == 0.0) {
                DeRef(_23347);
                _23347 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23348 = (object)*(((s1_ptr)_2)->base + _s_44823);
        _2 = (object)SEQ_PTR(_23348);
        _23349 = (object)*(((s1_ptr)_2)->base + 5LL);
        _23348 = NOVALUE;
        if (IS_ATOM_INT(_23349)) {
            _23350 = (_23349 != 99LL);
        }
        else {
            _23350 = binary_op(NOTEQ, _23349, 99LL);
        }
        _23349 = NOVALUE;
        DeRef(_23347);
        if (IS_ATOM_INT(_23350))
        _23347 = (_23350 != 0);
        else
        _23347 = DBL_PTR(_23350)->dbl != 0.0;
L3: 
        if (_23347 == 0) {
            goto L4; // [81] 117
        }
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23352 = (object)*(((s1_ptr)_2)->base + _s_44823);
        _2 = (object)SEQ_PTR(_23352);
        if (!IS_ATOM_INT(_36S_TOKEN_21401)){
            _23353 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
        }
        else{
            _23353 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
        }
        _23352 = NOVALUE;
        _23354 = find_from(_23353, _38RTN_TOKS_16291, 1LL);
        _23353 = NOVALUE;
        if (_23354 == 0)
        {
            _23354 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _23354 = NOVALUE;
        }

        /** c_decl.e:1342				return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_44816);
        DeRef(_23350);
        _23350 = NOVALUE;
        DeRef(_23346);
        _23346 = NOVALUE;
        return _13TRUE_447;
L4: 

        /** c_decl.e:1344		end for*/
        _i_44820 = _i_44820 + 1LL;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** c_decl.e:1345		return FALSE*/
    DeRef(_these_routines_44816);
    DeRef(_23350);
    _23350 = NOVALUE;
    DeRef(_23346);
    _23346 = NOVALUE;
    return _13FALSE_445;
    ;
}


void _58check_file_routines()
{
    object _s_45050 = NOVALUE;
    object _23516 = NOVALUE;
    object _23515 = NOVALUE;
    object _23514 = NOVALUE;
    object _23513 = NOVALUE;
    object _23512 = NOVALUE;
    object _23511 = NOVALUE;
    object _23510 = NOVALUE;
    object _23509 = NOVALUE;
    object _23508 = NOVALUE;
    object _23507 = NOVALUE;
    object _23506 = NOVALUE;
    object _23505 = NOVALUE;
    object _23503 = NOVALUE;
    object _23501 = NOVALUE;
    object _23499 = NOVALUE;
    object _0, _1, _2;
    

    /** c_decl.e:1451		if not length( file_routines ) then*/
    if (IS_SEQUENCE(_58file_routines_45041)){
            _23499 = SEQ_PTR(_58file_routines_45041)->length;
    }
    else {
        _23499 = 1;
    }
    if (_23499 != 0)
    goto L1; // [8] 146
    _23499 = NOVALUE;

    /** c_decl.e:1452			file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _23501 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _23501 = 1;
    }
    DeRefDS(_58file_routines_45041);
    _58file_routines_45041 = Repeat(_22186, _23501);
    _23501 = NOVALUE;

    /** c_decl.e:1453			integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23503 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
    _2 = (object)SEQ_PTR(_23503);
    _s_45050 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_45050)){
        _s_45050 = (object)DBL_PTR(_s_45050)->dbl;
    }
    _23503 = NOVALUE;

    /** c_decl.e:1454			while s do*/
L2: 
    if (_s_45050 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** c_decl.e:1455				if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23505 = (object)*(((s1_ptr)_2)->base + _s_45050);
    _2 = (object)SEQ_PTR(_23505);
    _23506 = (object)*(((s1_ptr)_2)->base + 5LL);
    _23505 = NOVALUE;
    if (IS_ATOM_INT(_23506)) {
        _23507 = (_23506 != 99LL);
    }
    else {
        _23507 = binary_op(NOTEQ, _23506, 99LL);
    }
    _23506 = NOVALUE;
    if (IS_ATOM_INT(_23507)) {
        if (_23507 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23507)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23509 = (object)*(((s1_ptr)_2)->base + _s_45050);
    _2 = (object)SEQ_PTR(_23509);
    if (!IS_ATOM_INT(_36S_TOKEN_21401)){
        _23510 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
    }
    else{
        _23510 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
    }
    _23509 = NOVALUE;
    _23511 = find_from(_23510, _38RTN_TOKS_16291, 1LL);
    _23510 = NOVALUE;
    if (_23511 == 0)
    {
        _23511 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23511 = NOVALUE;
    }

    /** c_decl.e:1458					file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23512 = (object)*(((s1_ptr)_2)->base + _s_45050);
    _2 = (object)SEQ_PTR(_23512);
    if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
        _23513 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
    }
    else{
        _23513 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
    }
    _23512 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_45041);
    if (!IS_ATOM_INT(_23513)){
        _23514 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23513)->dbl));
    }
    else{
        _23514 = (object)*(((s1_ptr)_2)->base + _23513);
    }
    if (IS_SEQUENCE(_23514) && IS_ATOM(_s_45050)) {
        Append(&_23515, _23514, _s_45050);
    }
    else if (IS_ATOM(_23514) && IS_SEQUENCE(_s_45050)) {
    }
    else {
        Concat((object_ptr)&_23515, _23514, _s_45050);
        _23514 = NOVALUE;
    }
    _23514 = NOVALUE;
    _2 = (object)SEQ_PTR(_58file_routines_45041);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _58file_routines_45041 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23513))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_23513)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _23513);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _23515;
    if( _1 != _23515 ){
        DeRef(_1);
    }
    _23515 = NOVALUE;
L4: 

    /** c_decl.e:1460				s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15637);
    _23516 = (object)*(((s1_ptr)_2)->base + _s_45050);
    _2 = (object)SEQ_PTR(_23516);
    _s_45050 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_45050)){
        _s_45050 = (object)DBL_PTR(_s_45050)->dbl;
    }
    _23516 = NOVALUE;

    /** c_decl.e:1461			end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** c_decl.e:1464	end procedure*/
    DeRef(_23507);
    _23507 = NOVALUE;
    _23513 = NOVALUE;
    return;
    ;
}


void _58GenerateUserRoutines()
{
    object _s_45084 = NOVALUE;
    object _sp_45085 = NOVALUE;
    object _next_c_char_45086 = NOVALUE;
    object _q_45087 = NOVALUE;
    object _temps_45088 = NOVALUE;
    object _buff_45089 = NOVALUE;
    object _base_name_45090 = NOVALUE;
    object _long_c_file_45091 = NOVALUE;
    object _c_file_45092 = NOVALUE;
    object _these_routines_45163 = NOVALUE;
    object _ret_type_45221 = NOVALUE;
    object _s_scope_45230 = NOVALUE;
    object _s_file_45233 = NOVALUE;
    object _scope_45310 = NOVALUE;
    object _names_45344 = NOVALUE;
    object _name_45354 = NOVALUE;
    object _23752 = NOVALUE;
    object _23750 = NOVALUE;
    object _23749 = NOVALUE;
    object _23748 = NOVALUE;
    object _23747 = NOVALUE;
    object _23746 = NOVALUE;
    object _23745 = NOVALUE;
    object _23743 = NOVALUE;
    object _23741 = NOVALUE;
    object _23740 = NOVALUE;
    object _23737 = NOVALUE;
    object _23735 = NOVALUE;
    object _23734 = NOVALUE;
    object _23733 = NOVALUE;
    object _23732 = NOVALUE;
    object _23731 = NOVALUE;
    object _23730 = NOVALUE;
    object _23728 = NOVALUE;
    object _23724 = NOVALUE;
    object _23722 = NOVALUE;
    object _23721 = NOVALUE;
    object _23720 = NOVALUE;
    object _23719 = NOVALUE;
    object _23717 = NOVALUE;
    object _23716 = NOVALUE;
    object _23714 = NOVALUE;
    object _23713 = NOVALUE;
    object _23711 = NOVALUE;
    object _23710 = NOVALUE;
    object _23709 = NOVALUE;
    object _23708 = NOVALUE;
    object _23706 = NOVALUE;
    object _23704 = NOVALUE;
    object _23703 = NOVALUE;
    object _23702 = NOVALUE;
    object _23701 = NOVALUE;
    object _23700 = NOVALUE;
    object _23699 = NOVALUE;
    object _23698 = NOVALUE;
    object _23696 = NOVALUE;
    object _23695 = NOVALUE;
    object _23694 = NOVALUE;
    object _23693 = NOVALUE;
    object _23692 = NOVALUE;
    object _23691 = NOVALUE;
    object _23690 = NOVALUE;
    object _23689 = NOVALUE;
    object _23687 = NOVALUE;
    object _23686 = NOVALUE;
    object _23684 = NOVALUE;
    object _23683 = NOVALUE;
    object _23682 = NOVALUE;
    object _23681 = NOVALUE;
    object _23680 = NOVALUE;
    object _23679 = NOVALUE;
    object _23678 = NOVALUE;
    object _23677 = NOVALUE;
    object _23675 = NOVALUE;
    object _23674 = NOVALUE;
    object _23672 = NOVALUE;
    object _23671 = NOVALUE;
    object _23670 = NOVALUE;
    object _23668 = NOVALUE;
    object _23663 = NOVALUE;
    object _23662 = NOVALUE;
    object _23660 = NOVALUE;
    object _23658 = NOVALUE;
    object _23652 = NOVALUE;
    object _23651 = NOVALUE;
    object _23650 = NOVALUE;
    object _23649 = NOVALUE;
    object _23648 = NOVALUE;
    object _23647 = NOVALUE;
    object _23646 = NOVALUE;
    object _23645 = NOVALUE;
    object _23643 = NOVALUE;
    object _23642 = NOVALUE;
    object _23640 = NOVALUE;
    object _23639 = NOVALUE;
    object _23636 = NOVALUE;
    object _23634 = NOVALUE;
    object _23633 = NOVALUE;
    object _23632 = NOVALUE;
    object _23628 = NOVALUE;
    object _23625 = NOVALUE;
    object _23622 = NOVALUE;
    object _23621 = NOVALUE;
    object _23620 = NOVALUE;
    object _23619 = NOVALUE;
    object _23617 = NOVALUE;
    object _23616 = NOVALUE;
    object _23614 = NOVALUE;
    object _23613 = NOVALUE;
    object _23612 = NOVALUE;
    object _23610 = NOVALUE;
    object _23607 = NOVALUE;
    object _23606 = NOVALUE;
    object _23605 = NOVALUE;
    object _23604 = NOVALUE;
    object _23603 = NOVALUE;
    object _23602 = NOVALUE;
    object _23601 = NOVALUE;
    object _23600 = NOVALUE;
    object _23599 = NOVALUE;
    object _23598 = NOVALUE;
    object _23597 = NOVALUE;
    object _23596 = NOVALUE;
    object _23595 = NOVALUE;
    object _23594 = NOVALUE;
    object _23593 = NOVALUE;
    object _23591 = NOVALUE;
    object _23588 = NOVALUE;
    object _23587 = NOVALUE;
    object _23585 = NOVALUE;
    object _23582 = NOVALUE;
    object _23581 = NOVALUE;
    object _23577 = NOVALUE;
    object _23576 = NOVALUE;
    object _23574 = NOVALUE;
    object _23570 = NOVALUE;
    object _23569 = NOVALUE;
    object _23568 = NOVALUE;
    object _23567 = NOVALUE;
    object _23566 = NOVALUE;
    object _23565 = NOVALUE;
    object _23564 = NOVALUE;
    object _23563 = NOVALUE;
    object _23562 = NOVALUE;
    object _23561 = NOVALUE;
    object _23560 = NOVALUE;
    object _23559 = NOVALUE;
    object _23558 = NOVALUE;
    object _23557 = NOVALUE;
    object _23555 = NOVALUE;
    object _23554 = NOVALUE;
    object _23552 = NOVALUE;
    object _23549 = NOVALUE;
    object _23546 = NOVALUE;
    object _23543 = NOVALUE;
    object _23540 = NOVALUE;
    object _23539 = NOVALUE;
    object _23538 = NOVALUE;
    object _23535 = NOVALUE;
    object _23532 = NOVALUE;
    object _23530 = NOVALUE;
    object _23526 = NOVALUE;
    object _23525 = NOVALUE;
    object _23523 = NOVALUE;
    object _23522 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** c_decl.e:1468		integer next_c_char, q, temps*/

    /** c_decl.e:1469		sequence buff, base_name, long_c_file, c_file*/

    /** c_decl.e:1471		if not silent then*/
    if (_36silent_21878 != 0)
    goto L1; // [9] 68

    /** c_decl.e:1472			if Pass = 1 then*/
    if (_58Pass_42878 != 1LL)
    goto L2; // [16] 31

    /** c_decl.e:1473				ShowMsg(1, TRANSLATING_CODE_PASS,,0)*/
    RefDS(_22186);
    _39ShowMsg(1LL, 239LL, _22186, 0LL);
L2: 

    /** c_decl.e:1476			if LAST_PASS = TRUE then*/
    if (_58LAST_PASS_42876 != _13TRUE_447)
    goto L3; // [37] 54

    /** c_decl.e:1477				ShowMsg(1, MSG__GENERATING)*/
    RefDS(_22186);
    _39ShowMsg(1LL, 240LL, _22186, 1LL);
    goto L4; // [51] 67
L3: 

    /** c_decl.e:1479				ShowMsg(1, MSG_1, Pass, 0)*/
    _39ShowMsg(1LL, 241LL, _58Pass_42878, 0LL);
L4: 
L1: 

    /** c_decl.e:1483		check_file_routines()*/
    _58check_file_routines();

    /** c_decl.e:1485		c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23521);
    _55c_puts(_23521);

    /** c_decl.e:1486		for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_37known_files_15638)){
            _23522 = SEQ_PTR(_37known_files_15638)->length;
    }
    else {
        _23522 = 1;
    }
    {
        object _file_no_45111;
        _file_no_45111 = 1LL;
L5: 
        if (_file_no_45111 > _23522){
            goto L6; // [84] 2208
        }

        /** c_decl.e:1487			if file_no = 1 or any_code(file_no) then*/
        _23523 = (_file_no_45111 == 1LL);
        if (_23523 != 0) {
            goto L7; // [97] 110
        }
        _23525 = _58any_code(_file_no_45111);
        if (_23525 == 0) {
            DeRef(_23525);
            _23525 = NOVALUE;
            goto L8; // [106] 2199
        }
        else {
            if (!IS_ATOM_INT(_23525) && DBL_PTR(_23525)->dbl == 0.0){
                DeRef(_23525);
                _23525 = NOVALUE;
                goto L8; // [106] 2199
            }
            DeRef(_23525);
            _23525 = NOVALUE;
        }
        DeRef(_23525);
        _23525 = NOVALUE;
L7: 

        /** c_decl.e:1490				next_c_char = 1*/
        _next_c_char_45086 = 1LL;

        /** c_decl.e:1491				base_name = name_ext(known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _23526 = (object)*(((s1_ptr)_2)->base + _file_no_45111);
        Ref(_23526);
        _0 = _base_name_45090;
        _base_name_45090 = _54name_ext(_23526);
        DeRef(_0);
        _23526 = NOVALUE;

        /** c_decl.e:1492				c_file = base_name*/
        RefDS(_base_name_45090);
        DeRef(_c_file_45092);
        _c_file_45092 = _base_name_45090;

        /** c_decl.e:1494				q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_45092)){
                _q_45087 = SEQ_PTR(_c_file_45092)->length;
        }
        else {
            _q_45087 = 1;
        }

        /** c_decl.e:1495				while q >= 1 do*/
L9: 
        if (_q_45087 < 1LL)
        goto LA; // [146] 187

        /** c_decl.e:1496					if c_file[q] = '.' then*/
        _2 = (object)SEQ_PTR(_c_file_45092);
        _23530 = (object)*(((s1_ptr)_2)->base + _q_45087);
        if (binary_op_a(NOTEQ, _23530, 46LL)){
            _23530 = NOVALUE;
            goto LB; // [156] 176
        }
        _23530 = NOVALUE;

        /** c_decl.e:1497						c_file = c_file[1..q-1]*/
        _23532 = _q_45087 - 1LL;
        rhs_slice_target = (object_ptr)&_c_file_45092;
        RHS_Slice(_c_file_45092, 1LL, _23532);

        /** c_decl.e:1498						exit*/
        goto LA; // [173] 187
LB: 

        /** c_decl.e:1500					q -= 1*/
        _q_45087 = _q_45087 - 1LL;

        /** c_decl.e:1501				end while*/
        goto L9; // [184] 146
LA: 

        /** c_decl.e:1503				if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_45092);
        _23535 = _14lower(_c_file_45092);
        RefDS(_23537);
        RefDS(_23536);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _23536;
        ((intptr_t *)_2)[2] = _23537;
        _23538 = MAKE_SEQ(_1);
        _23539 = find_from(_23535, _23538, 1LL);
        DeRef(_23535);
        _23535 = NOVALUE;
        DeRefDS(_23538);
        _23538 = NOVALUE;
        if (_23539 == 0)
        {
            _23539 = NOVALUE;
            goto LC; // [202] 219
        }
        else{
            _23539 = NOVALUE;
        }

        /** c_decl.e:1504					CompileErr(MSG_1_CONFLICTS_WITH_A_FILE_NAME_USED_INTERNALLY_BY_THE_TRANSLATOR, {base_name})*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        RefDS(_base_name_45090);
        ((intptr_t*)_2)[1] = _base_name_45090;
        _23540 = MAKE_SEQ(_1);
        _50CompileErr(12LL, _23540, 0LL);
        _23540 = NOVALUE;
LC: 

        /** c_decl.e:1507				long_c_file = c_file*/
        RefDS(_c_file_45092);
        DeRef(_long_c_file_45091);
        _long_c_file_45091 = _c_file_45092;

        /** c_decl.e:1508				if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42876 != _13TRUE_447)
        goto LD; // [232] 257

        /** c_decl.e:1509					c_file = unique_c_name(c_file)*/
        RefDS(_c_file_45092);
        _0 = _c_file_45092;
        _c_file_45092 = _58unique_c_name(_c_file_45092);
        DeRefDS(_0);

        /** c_decl.e:1510					add_file(c_file, known_files[file_no])*/
        _2 = (object)SEQ_PTR(_37known_files_15638);
        _23543 = (object)*(((s1_ptr)_2)->base + _file_no_45111);
        RefDS(_c_file_45092);
        Ref(_23543);
        _58add_file(_c_file_45092, _23543);
        _23543 = NOVALUE;
LD: 

        /** c_decl.e:1513				if file_no = 1 then*/
        if (_file_no_45111 != 1LL)
        goto LE; // [259] 322

        /** c_decl.e:1515					if LAST_PASS = TRUE then*/
        if (_58LAST_PASS_42876 != _13TRUE_447)
        goto LF; // [269] 314

        /** c_decl.e:1516						add_file("main-")*/
        RefDS(_23536);
        RefDS(_22186);
        _58add_file(_23536, _22186);

        /** c_decl.e:1517						for i = 0 to main_name_num-1 do*/
        _23546 = _55main_name_num_46974 - 1LL;
        if ((object)((uintptr_t)_23546 +(uintptr_t) HIGH_BITS) >= 0){
            _23546 = NewDouble((eudouble)_23546);
        }
        {
            object _i_45153;
            _i_45153 = 0LL;
L10: 
            if (binary_op_a(GREATER, _i_45153, _23546)){
                goto L11; // [287] 313
            }

            /** c_decl.e:1518							buff = sprintf("main-%d", i)*/
            DeRefi(_buff_45089);
            _buff_45089 = EPrintf(-9999999, _23547, _i_45153);

            /** c_decl.e:1519							add_file(buff)*/
            RefDS(_buff_45089);
            RefDS(_22186);
            _58add_file(_buff_45089, _22186);

            /** c_decl.e:1520						end for*/
            _0 = _i_45153;
            if (IS_ATOM_INT(_i_45153)) {
                _i_45153 = _i_45153 + 1LL;
                if ((object)((uintptr_t)_i_45153 +(uintptr_t) HIGH_BITS) >= 0){
                    _i_45153 = NewDouble((eudouble)_i_45153);
                }
            }
            else {
                _i_45153 = binary_op_a(PLUS, _i_45153, 1LL);
            }
            DeRef(_0);
            goto L10; // [308] 294
L11: 
            ;
            DeRef(_i_45153);
        }
LF: 

        /** c_decl.e:1523					file0 = long_c_file*/
        RefDS(_long_c_file_45091);
        DeRef(_58file0_44847);
        _58file0_44847 = _long_c_file_45091;
LE: 

        /** c_decl.e:1526				new_c_file(c_file)*/
        RefDS(_c_file_45092);
        _58new_c_file(_c_file_45092);

        /** c_decl.e:1528				s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15637);
        _23549 = (object)*(((s1_ptr)_2)->base + _36TopLevelSub_21766);
        _2 = (object)SEQ_PTR(_23549);
        _s_45084 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_s_45084)){
            _s_45084 = (object)DBL_PTR(_s_45084)->dbl;
        }
        _23549 = NOVALUE;

        /** c_decl.e:1530				sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_45163);
        _2 = (object)SEQ_PTR(_58file_routines_45041);
        _these_routines_45163 = (object)*(((s1_ptr)_2)->base + _file_no_45111);
        Ref(_these_routines_45163);

        /** c_decl.e:1531				for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_45163)){
                _23552 = SEQ_PTR(_these_routines_45163)->length;
        }
        else {
            _23552 = 1;
        }
        {
            object _routine_no_45166;
            _routine_no_45166 = 1LL;
L12: 
            if (_routine_no_45166 > _23552){
                goto L13; // [360] 2198
            }

            /** c_decl.e:1532					s = these_routines[routine_no]*/
            _2 = (object)SEQ_PTR(_these_routines_45163);
            _s_45084 = (object)*(((s1_ptr)_2)->base + _routine_no_45166);
            if (!IS_ATOM_INT(_s_45084)){
                _s_45084 = (object)DBL_PTR(_s_45084)->dbl;
            }

            /** c_decl.e:1533					if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23554 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23554);
            _23555 = (object)*(((s1_ptr)_2)->base + 5LL);
            _23554 = NOVALUE;
            if (binary_op_a(EQUALS, _23555, 99LL)){
                _23555 = NOVALUE;
                goto L14; // [391] 2189
            }
            _23555 = NOVALUE;

            /** c_decl.e:1537						if LAST_PASS = TRUE and*/
            _23557 = (_58LAST_PASS_42876 == _13TRUE_447);
            if (_23557 == 0) {
                goto L15; // [405] 601
            }
            _23559 = (_36cfile_size_21842 > _56max_cfile_size_45721);
            if (_23559 != 0) {
                DeRef(_23560);
                _23560 = 1;
                goto L16; // [417] 480
            }
            _23561 = (_s_45084 != _36TopLevelSub_21766);
            if (_23561 == 0) {
                _23562 = 0;
                goto L17; // [427] 447
            }
            _23563 = (_56max_cfile_size_45721 % 4LL) ? NewDouble((eudouble)_56max_cfile_size_45721 / 4LL) : (_56max_cfile_size_45721 / 4LL);
            if (IS_ATOM_INT(_23563)) {
                _23564 = (_36cfile_size_21842 > _23563);
            }
            else {
                _23564 = ((eudouble)_36cfile_size_21842 > DBL_PTR(_23563)->dbl);
            }
            DeRef(_23563);
            _23563 = NOVALUE;
            _23562 = (_23564 != 0);
L17: 
            if (_23562 == 0) {
                _23565 = 0;
                goto L18; // [447] 476
            }
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23566 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23566);
            if (!IS_ATOM_INT(_36S_CODE_21408)){
                _23567 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21408)->dbl));
            }
            else{
                _23567 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21408);
            }
            _23566 = NOVALUE;
            if (IS_SEQUENCE(_23567)){
                    _23568 = SEQ_PTR(_23567)->length;
            }
            else {
                _23568 = 1;
            }
            _23567 = NOVALUE;
            _23569 = (_23568 > _56max_cfile_size_45721);
            _23568 = NOVALUE;
            _23565 = (_23569 != 0);
L18: 
            DeRef(_23560);
            _23560 = (_23565 != 0);
L16: 
            if (_23560 == 0)
            {
                _23560 = NOVALUE;
                goto L15; // [481] 601
            }
            else{
                _23560 = NOVALUE;
            }

            /** c_decl.e:1546							if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_45092)){
                    _23570 = SEQ_PTR(_c_file_45092)->length;
            }
            else {
                _23570 = 1;
            }
            if (_23570 != 7LL)
            goto L19; // [489] 500

            /** c_decl.e:1548								c_file &= " "*/
            Concat((object_ptr)&_c_file_45092, _c_file_45092, _23572);
L19: 

            /** c_decl.e:1551							if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_45092)){
                    _23574 = SEQ_PTR(_c_file_45092)->length;
            }
            else {
                _23574 = 1;
            }
            if (_23574 < 8LL)
            goto L1A; // [505] 528

            /** c_decl.e:1552								c_file[7] = '_'*/
            _2 = (object)SEQ_PTR(_c_file_45092);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45092 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 7LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 95LL;
            DeRef(_1);

            /** c_decl.e:1553								c_file[8] = file_chars[next_c_char]*/
            _2 = (object)SEQ_PTR(_58file_chars_44712);
            _23576 = (object)*(((s1_ptr)_2)->base + _next_c_char_45086);
            Ref(_23576);
            _2 = (object)SEQ_PTR(_c_file_45092);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45092 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 8LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23576;
            if( _1 != _23576 ){
                DeRef(_1);
            }
            _23576 = NOVALUE;
            goto L1B; // [525] 560
L1A: 

            /** c_decl.e:1556								if find('_', c_file) = 0 then*/
            _23577 = find_from(95LL, _c_file_45092, 1LL);
            if (_23577 != 0LL)
            goto L1C; // [535] 546

            /** c_decl.e:1557									c_file &= "_ "*/
            Concat((object_ptr)&_c_file_45092, _c_file_45092, _23579);
L1C: 

            /** c_decl.e:1560								c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_45092)){
                    _23581 = SEQ_PTR(_c_file_45092)->length;
            }
            else {
                _23581 = 1;
            }
            _2 = (object)SEQ_PTR(_58file_chars_44712);
            _23582 = (object)*(((s1_ptr)_2)->base + _next_c_char_45086);
            Ref(_23582);
            _2 = (object)SEQ_PTR(_c_file_45092);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _c_file_45092 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _23581);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _23582;
            if( _1 != _23582 ){
                DeRef(_1);
            }
            _23582 = NOVALUE;
L1B: 

            /** c_decl.e:1564							c_file = unique_c_name(c_file)*/
            RefDS(_c_file_45092);
            _0 = _c_file_45092;
            _c_file_45092 = _58unique_c_name(_c_file_45092);
            DeRefDS(_0);

            /** c_decl.e:1565							new_c_file(c_file)*/
            RefDS(_c_file_45092);
            _58new_c_file(_c_file_45092);

            /** c_decl.e:1567							next_c_char += 1*/
            _next_c_char_45086 = _next_c_char_45086 + 1;

            /** c_decl.e:1568							if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_58file_chars_44712)){
                    _23585 = SEQ_PTR(_58file_chars_44712)->length;
            }
            else {
                _23585 = 1;
            }
            if (_next_c_char_45086 <= _23585)
            goto L1D; // [584] 594

            /** c_decl.e:1569								next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_45086 = 1LL;
L1D: 

            /** c_decl.e:1572							add_file(c_file)*/
            RefDS(_c_file_45092);
            RefDS(_22186);
            _58add_file(_c_file_45092, _22186);
L15: 

            /** c_decl.e:1575						sequence ret_type*/

            /** c_decl.e:1576						if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23587 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23587);
            if (!IS_ATOM_INT(_36S_TOKEN_21401)){
                _23588 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21401)->dbl));
            }
            else{
                _23588 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21401);
            }
            _23587 = NOVALUE;
            if (binary_op_a(NOTEQ, _23588, 27LL)){
                _23588 = NOVALUE;
                goto L1E; // [619] 633
            }
            _23588 = NOVALUE;

            /** c_decl.e:1577							ret_type = "void "*/
            RefDS(_22965);
            DeRefi(_ret_type_45221);
            _ret_type_45221 = _22965;
            goto L1F; // [630] 641
L1E: 

            /** c_decl.e:1579							ret_type = "object "*/
            RefDS(_22966);
            DeRefi(_ret_type_45221);
            _ret_type_45221 = _22966;
L1F: 

            /** c_decl.e:1581						integer s_scope = sym_scope( s )*/
            _s_scope_45230 = _54sym_scope(_s_45084);
            if (!IS_ATOM_INT(_s_scope_45230)) {
                _1 = (object)(DBL_PTR(_s_scope_45230)->dbl);
                DeRefDS(_s_scope_45230);
                _s_scope_45230 = _1;
            }

            /** c_decl.e:1582						integer s_file  = SymTab[s][S_FILE_NO]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23591 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23591);
            if (!IS_ATOM_INT(_36S_FILE_NO_21392)){
                _s_file_45233 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21392)->dbl));
            }
            else{
                _s_file_45233 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21392);
            }
            if (!IS_ATOM_INT(_s_file_45233)){
                _s_file_45233 = (object)DBL_PTR(_s_file_45233)->dbl;
            }
            _23591 = NOVALUE;

            /** c_decl.e:1583						if dll_option and*/
            if (_58dll_option_42889 == 0) {
                goto L20; // [669] 827
            }
            _23594 = (_s_scope_45230 == 6LL);
            if (_23594 != 0) {
                DeRef(_23595);
                _23595 = 1;
                goto L21; // [679] 757
            }
            _23596 = (_s_file_45233 == 1LL);
            if (_23596 == 0) {
                _23597 = 0;
                goto L22; // [687] 715
            }
            _23598 = (_s_scope_45230 == 13LL);
            if (_23598 != 0) {
                _23599 = 1;
                goto L23; // [697] 711
            }
            _23600 = (_s_scope_45230 == 11LL);
            _23599 = (_23600 != 0);
L23: 
            _23597 = (_23599 != 0);
L22: 
            if (_23597 != 0) {
                _23601 = 1;
                goto L24; // [715] 753
            }
            _23602 = (_s_scope_45230 == 13LL);
            if (_23602 == 0) {
                _23603 = 0;
                goto L25; // [725] 749
            }
            _2 = (object)SEQ_PTR(_37include_matrix_15644);
            _23604 = (object)*(((s1_ptr)_2)->base + 1LL);
            _2 = (object)SEQ_PTR(_23604);
            _23605 = (object)*(((s1_ptr)_2)->base + _s_file_45233);
            _23604 = NOVALUE;
            if (IS_ATOM_INT(_23605)) {
                {uintptr_t tu;
                     tu = (uintptr_t)_23605 & (uintptr_t)4LL;
                     _23606 = MAKE_UINT(tu);
                }
            }
            else {
                _23606 = binary_op(AND_BITS, _23605, 4LL);
            }
            _23605 = NOVALUE;
            if (IS_ATOM_INT(_23606))
            _23603 = (_23606 != 0);
            else
            _23603 = DBL_PTR(_23606)->dbl != 0.0;
L25: 
            _23601 = (_23603 != 0);
L24: 
            DeRef(_23595);
            _23595 = (_23601 != 0);
L21: 
            if (_23595 == 0)
            {
                _23595 = NOVALUE;
                goto L20; // [758] 827
            }
            else{
                _23595 = NOVALUE;
            }

            /** c_decl.e:1589							SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_s_45084 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 53LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _13TRUE_447;
            DeRef(_1);
            _23607 = NOVALUE;

            /** c_decl.e:1590							LeftSym = TRUE*/
            _58LeftSym_42886 = _13TRUE_447;

            /** c_decl.e:1593							if TWINDOWS then*/
            if (_46TWINDOWS_21906 == 0)
            {
                goto L26; // [791] 810
            }
            else{
            }

            /** c_decl.e:1594								c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23610, _ret_type_45221, _23609);
            _58c_stmt(_23610, _s_45084, 0LL);
            _23610 = NOVALUE;
            goto L27; // [807] 850
L26: 

            /** c_decl.e:1596								c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23612, _ret_type_45221, _23611);
            _58c_stmt(_23612, _s_45084, 0LL);
            _23612 = NOVALUE;
            goto L27; // [824] 850
L20: 

            /** c_decl.e:1600							LeftSym = TRUE*/
            _58LeftSym_42886 = _13TRUE_447;

            /** c_decl.e:1601							c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23613, _ret_type_45221, _23611);
            _58c_stmt(_23613, _s_45084, 0LL);
            _23613 = NOVALUE;
L27: 

            /** c_decl.e:1605						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23614 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23614);
            _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45085)){
                _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
            }
            _23614 = NOVALUE;

            /** c_decl.e:1606						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23616 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23616);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                _23617 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
            }
            else{
                _23617 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
            }
            _23616 = NOVALUE;
            {
                object _p_45280;
                _p_45280 = 1LL;
L28: 
                if (binary_op_a(GREATER, _p_45280, _23617)){
                    goto L29; // [880] 956
                }

                /** c_decl.e:1607							c_puts("object _")*/
                RefDS(_23618);
                _55c_puts(_23618);

                /** c_decl.e:1608							c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23619 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23619);
                if (!IS_ATOM_INT(_36S_NAME_21396)){
                    _23620 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
                }
                else{
                    _23620 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
                }
                _23619 = NOVALUE;
                Ref(_23620);
                _55c_puts(_23620);
                _23620 = NOVALUE;

                /** c_decl.e:1609							if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23621 = (object)*(((s1_ptr)_2)->base + _s_45084);
                _2 = (object)SEQ_PTR(_23621);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                    _23622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
                }
                else{
                    _23622 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
                }
                _23621 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45280, _23622)){
                    _23622 = NOVALUE;
                    goto L2A; // [923] 933
                }
                _23622 = NOVALUE;

                /** c_decl.e:1610								c_puts(", ")*/
                RefDS(_23624);
                _55c_puts(_23624);
L2A: 

                /** c_decl.e:1612							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23625 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23625);
                _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_45085)){
                    _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
                }
                _23625 = NOVALUE;

                /** c_decl.e:1613						end for*/
                _0 = _p_45280;
                if (IS_ATOM_INT(_p_45280)) {
                    _p_45280 = _p_45280 + 1LL;
                    if ((object)((uintptr_t)_p_45280 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45280 = NewDouble((eudouble)_p_45280);
                    }
                }
                else {
                    _p_45280 = binary_op_a(PLUS, _p_45280, 1LL);
                }
                DeRef(_0);
                goto L28; // [951] 887
L29: 
                ;
                DeRef(_p_45280);
            }

            /** c_decl.e:1615						c_puts(")\n")*/
            RefDS(_23627);
            _55c_puts(_23627);

            /** c_decl.e:1616						c_stmt0("{\n")*/
            RefDS(_22290);
            _58c_stmt0(_22290);

            /** c_decl.e:1618						NewBB(0, E_ALL_EFFECT, 0)*/
            _58NewBB(0LL, 1073741823LL, 0LL);

            /** c_decl.e:1619						Initializing = TRUE*/
            _36Initializing_21843 = _13TRUE_447;

            /** c_decl.e:1622						while sp do*/
L2B: 
            if (_sp_45085 == 0)
            {
                goto L2C; // [989] 1128
            }
            else{
            }

            /** c_decl.e:1623							integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23628 = (object)*(((s1_ptr)_2)->base + _sp_45085);
            _2 = (object)SEQ_PTR(_23628);
            _scope_45310 = (object)*(((s1_ptr)_2)->base + 4LL);
            if (!IS_ATOM_INT(_scope_45310)){
                _scope_45310 = (object)DBL_PTR(_scope_45310)->dbl;
            }
            _23628 = NOVALUE;

            /** c_decl.e:1624							switch scope with fallthru do*/
            _0 = _scope_45310;
            switch ( _0 ){ 

                /** c_decl.e:1625								case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** c_decl.e:1628									break*/
                goto L2D; // [1023] 1105

                /** c_decl.e:1630								case SC_PRIVATE then*/
                case 3:

                /** c_decl.e:1631									c_stmt0("object ")*/
                RefDS(_22966);
                _58c_stmt0(_22966);

                /** c_decl.e:1632									c_puts("_")*/
                RefDS(_22258);
                _55c_puts(_22258);

                /** c_decl.e:1633									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23632 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23632);
                if (!IS_ATOM_INT(_36S_NAME_21396)){
                    _23633 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
                }
                else{
                    _23633 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
                }
                _23632 = NOVALUE;
                Ref(_23633);
                _55c_puts(_23633);
                _23633 = NOVALUE;

                /** c_decl.e:1635									c_puts(" = NOVALUE;\n")*/
                RefDS(_22974);
                _55c_puts(_22974);

                /** c_decl.e:1636									target[MIN] = NOVALUE*/
                Ref(_36NOVALUE_21613);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21613;
                DeRef(_1);

                /** c_decl.e:1637									target[MAX] = NOVALUE*/
                Ref(_36NOVALUE_21613);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36NOVALUE_21613;
                DeRef(_1);

                /** c_decl.e:1638									RemoveFromBB( sp )*/
                _58RemoveFromBB(_sp_45085);

                /** c_decl.e:1640									break*/
                goto L2D; // [1092] 1105

                /** c_decl.e:1642								case else*/
                default:

                /** c_decl.e:1643									exit*/
                goto L2C; // [1102] 1128
            ;}L2D: 

            /** c_decl.e:1645							sp = SymTab[sp][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23634 = (object)*(((s1_ptr)_2)->base + _sp_45085);
            _2 = (object)SEQ_PTR(_23634);
            _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45085)){
                _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
            }
            _23634 = NOVALUE;

            /** c_decl.e:1646						end while*/
            goto L2B; // [1125] 989
L2C: 

            /** c_decl.e:1649						temps = SymTab[s][S_TEMPS]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23636 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23636);
            if (!IS_ATOM_INT(_36S_TEMPS_21441)){
                _temps_45088 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21441)->dbl));
            }
            else{
                _temps_45088 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21441);
            }
            if (!IS_ATOM_INT(_temps_45088)){
                _temps_45088 = (object)DBL_PTR(_temps_45088)->dbl;
            }
            _23636 = NOVALUE;

            /** c_decl.e:1650						sequence names = {}*/
            RefDS(_22186);
            DeRef(_names_45344);
            _names_45344 = _22186;

            /** c_decl.e:1651						while temps != 0 do*/
L2E: 
            if (_temps_45088 == 0LL)
            goto L2F; // [1156] 1348

            /** c_decl.e:1652							if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23639 = (object)*(((s1_ptr)_2)->base + _temps_45088);
            _2 = (object)SEQ_PTR(_23639);
            _23640 = (object)*(((s1_ptr)_2)->base + 4LL);
            _23639 = NOVALUE;
            if (binary_op_a(EQUALS, _23640, 2LL)){
                _23640 = NOVALUE;
                goto L30; // [1176] 1308
            }
            _23640 = NOVALUE;

            /** c_decl.e:1653								sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23642 = (object)*(((s1_ptr)_2)->base + _temps_45088);
            _2 = (object)SEQ_PTR(_23642);
            _23643 = (object)*(((s1_ptr)_2)->base + 34LL);
            _23642 = NOVALUE;
            DeRefi(_name_45354);
            _name_45354 = EPrintf(-9999999, _22309, _23643);
            _23643 = NOVALUE;

            /** c_decl.e:1654								if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23645 = (object)*(((s1_ptr)_2)->base + _temps_45088);
            _2 = (object)SEQ_PTR(_23645);
            _23646 = (object)*(((s1_ptr)_2)->base + 34LL);
            _23645 = NOVALUE;
            _2 = (object)SEQ_PTR(_36temp_name_type_21845);
            if (!IS_ATOM_INT(_23646)){
                _23647 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_23646)->dbl));
            }
            else{
                _23647 = (object)*(((s1_ptr)_2)->base + _23646);
            }
            _2 = (object)SEQ_PTR(_23647);
            _23648 = (object)*(((s1_ptr)_2)->base + 1LL);
            _23647 = NOVALUE;
            if (IS_ATOM_INT(_23648)) {
                _23649 = (_23648 != 0LL);
            }
            else {
                _23649 = binary_op(NOTEQ, _23648, 0LL);
            }
            _23648 = NOVALUE;
            if (IS_ATOM_INT(_23649)) {
                if (_23649 == 0) {
                    goto L31; // [1230] 1304
                }
            }
            else {
                if (DBL_PTR(_23649)->dbl == 0.0) {
                    goto L31; // [1230] 1304
                }
            }
            _23651 = find_from(_name_45354, _names_45344, 1LL);
            _23652 = (_23651 == 0);
            _23651 = NOVALUE;
            if (_23652 == 0)
            {
                DeRef(_23652);
                _23652 = NOVALUE;
                goto L31; // [1243] 1304
            }
            else{
                DeRef(_23652);
                _23652 = NOVALUE;
            }

            /** c_decl.e:1657									c_stmt0("object ")*/
            RefDS(_22966);
            _58c_stmt0(_22966);

            /** c_decl.e:1658									c_puts( name )*/
            RefDS(_name_45354);
            _55c_puts(_name_45354);

            /** c_decl.e:1659									c_puts(" = NOVALUE")*/
            RefDS(_23653);
            _55c_puts(_23653);

            /** c_decl.e:1661									target = {NOVALUE, NOVALUE}*/
            Ref(_36NOVALUE_21613);
            Ref(_36NOVALUE_21613);
            DeRef(_59target_28717);
            _1 = NewS1(2);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t *)_2)[1] = _36NOVALUE_21613;
            ((intptr_t *)_2)[2] = _36NOVALUE_21613;
            _59target_28717 = MAKE_SEQ(_1);

            /** c_decl.e:1663									SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_59target_28717);
            _58SetBBType(_temps_45088, 1LL, _59target_28717, 16LL, 0LL);

            /** c_decl.e:1664									ifdef DEBUG then*/

            /** c_decl.e:1667										c_puts(";\n")*/
            RefDS(_22462);
            _55c_puts(_22462);

            /** c_decl.e:1669									names = prepend( names, name )*/
            RefDS(_name_45354);
            Prepend(&_names_45344, _names_45344, _name_45354);
            goto L32; // [1301] 1307
L31: 

            /** c_decl.e:1671									ifdef DEBUG then*/
L32: 
L30: 
            DeRefi(_name_45354);
            _name_45354 = NOVALUE;

            /** c_decl.e:1677							SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _37SymTab_15637 = MAKE_SEQ(_2);
            }
            _3 = (object)(_temps_45088 + ((s1_ptr)_2)->base);
            _2 = (object)SEQ_PTR(*(intptr_t *)_3);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                *(intptr_t *)_3 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + 36LL);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = 16LL;
            DeRef(_1);
            _23658 = NOVALUE;

            /** c_decl.e:1678							temps = SymTab[temps][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23660 = (object)*(((s1_ptr)_2)->base + _temps_45088);
            _2 = (object)SEQ_PTR(_23660);
            _temps_45088 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_temps_45088)){
                _temps_45088 = (object)DBL_PTR(_temps_45088)->dbl;
            }
            _23660 = NOVALUE;

            /** c_decl.e:1679						end while*/
            goto L2E; // [1345] 1156
L2F: 

            /** c_decl.e:1680						Initializing = FALSE*/
            _36Initializing_21843 = _13FALSE_445;

            /** c_decl.e:1682						if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23662 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23662);
            _23663 = (object)*(((s1_ptr)_2)->base + 37LL);
            _23662 = NOVALUE;
            if (_23663 == 0) {
                _23663 = NOVALUE;
                goto L33; // [1371] 1384
            }
            else {
                if (!IS_ATOM_INT(_23663) && DBL_PTR(_23663)->dbl == 0.0){
                    _23663 = NOVALUE;
                    goto L33; // [1371] 1384
                }
                _23663 = NOVALUE;
            }
            _23663 = NOVALUE;

            /** c_decl.e:1683							c_stmt0("object _0, _1, _2, _3;\n\n")*/
            RefDS(_23664);
            _58c_stmt0(_23664);

            /** c_decl.e:1684							ifdef DEBUG then*/
            goto L34; // [1381] 1392
L33: 

            /** c_decl.e:1688							c_stmt0("object _0, _1, _2;\n\n")*/
            RefDS(_23666);
            _58c_stmt0(_23666);

            /** c_decl.e:1689							ifdef DEBUG then*/
L34: 

            /** c_decl.e:1696						sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23668 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23668);
            _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45085)){
                _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
            }
            _23668 = NOVALUE;

            /** c_decl.e:1697						for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23670 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23670);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                _23671 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
            }
            else{
                _23671 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
            }
            _23670 = NOVALUE;
            {
                object _p_45415;
                _p_45415 = 1LL;
L35: 
                if (binary_op_a(GREATER, _p_45415, _23671)){
                    goto L36; // [1422] 1773
                }

                /** c_decl.e:1698							SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _37SymTab_15637 = MAKE_SEQ(_2);
                }
                _3 = (object)(_sp_45085 + ((s1_ptr)_2)->base);
                _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    *(intptr_t *)_3 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 35LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _13FALSE_445;
                DeRef(_1);
                _23672 = NOVALUE;

                /** c_decl.e:1699							if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23674 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23674);
                _23675 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23674 = NOVALUE;
                if (binary_op_a(NOTEQ, _23675, 8LL)){
                    _23675 = NOVALUE;
                    goto L37; // [1462] 1526
                }
                _23675 = NOVALUE;

                /** c_decl.e:1700								target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23677 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23677);
                _23678 = (object)*(((s1_ptr)_2)->base + 51LL);
                _23677 = NOVALUE;
                Ref(_23678);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23678;
                if( _1 != _23678 ){
                    DeRef(_1);
                }
                _23678 = NOVALUE;

                /** c_decl.e:1701								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23679 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23679);
                _23680 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23679 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23681 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23681);
                _23682 = (object)*(((s1_ptr)_2)->base + 45LL);
                _23681 = NOVALUE;
                Ref(_23680);
                RefDS(_59target_28717);
                Ref(_23682);
                _58SetBBType(_sp_45085, _23680, _59target_28717, _23682, 0LL);
                _23680 = NOVALUE;
                _23682 = NOVALUE;
                goto L38; // [1523] 1750
L37: 

                /** c_decl.e:1704							elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23683 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23683);
                _23684 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23683 = NOVALUE;
                if (binary_op_a(NOTEQ, _23684, 1LL)){
                    _23684 = NOVALUE;
                    goto L39; // [1542] 1666
                }
                _23684 = NOVALUE;

                /** c_decl.e:1705								if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23686 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23686);
                _23687 = (object)*(((s1_ptr)_2)->base + 47LL);
                _23686 = NOVALUE;
                if (binary_op_a(NOTEQ, _23687, _36NOVALUE_21613)){
                    _23687 = NOVALUE;
                    goto L3A; // [1562] 1593
                }
                _23687 = NOVALUE;

                /** c_decl.e:1706									target[MIN] = MININT*/
                Ref(_36MININT_21583);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36MININT_21583;
                DeRef(_1);

                /** c_decl.e:1707									target[MAX] = MAXINT*/
                Ref(_36MAXINT_21582);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _36MAXINT_21582;
                DeRef(_1);
                goto L3B; // [1590] 1638
L3A: 

                /** c_decl.e:1709									target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23689 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23689);
                _23690 = (object)*(((s1_ptr)_2)->base + 47LL);
                _23689 = NOVALUE;
                Ref(_23690);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 1LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23690;
                if( _1 != _23690 ){
                    DeRef(_1);
                }
                _23690 = NOVALUE;

                /** c_decl.e:1710									target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23691 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23691);
                _23692 = (object)*(((s1_ptr)_2)->base + 48LL);
                _23691 = NOVALUE;
                Ref(_23692);
                _2 = (object)SEQ_PTR(_59target_28717);
                if (!UNIQUE(_2)) {
                    _2 = (object)SequenceCopy((s1_ptr)_2);
                    _59target_28717 = MAKE_SEQ(_2);
                }
                _2 = (object)(((s1_ptr)_2)->base + 2LL);
                _1 = *(intptr_t *)_2;
                *(intptr_t *)_2 = _23692;
                if( _1 != _23692 ){
                    DeRef(_1);
                }
                _23692 = NOVALUE;
L3B: 

                /** c_decl.e:1712								SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23693 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23693);
                _23694 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23693 = NOVALUE;
                Ref(_23694);
                RefDS(_59target_28717);
                _58SetBBType(_sp_45085, _23694, _59target_28717, 16LL, 0LL);
                _23694 = NOVALUE;
                goto L38; // [1663] 1750
L39: 

                /** c_decl.e:1714							elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23695 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23695);
                _23696 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23695 = NOVALUE;
                if (binary_op_a(NOTEQ, _23696, 16LL)){
                    _23696 = NOVALUE;
                    goto L3C; // [1682] 1724
                }
                _23696 = NOVALUE;

                /** c_decl.e:1716								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23698 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23698);
                _23699 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23698 = NOVALUE;
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23700 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23700);
                _23701 = (object)*(((s1_ptr)_2)->base + 45LL);
                _23700 = NOVALUE;
                Ref(_23699);
                RefDS(_55novalue_46976);
                Ref(_23701);
                _58SetBBType(_sp_45085, _23699, _55novalue_46976, _23701, 0LL);
                _23699 = NOVALUE;
                _23701 = NOVALUE;
                goto L38; // [1721] 1750
L3C: 

                /** c_decl.e:1720								SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23702 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23702);
                _23703 = (object)*(((s1_ptr)_2)->base + 43LL);
                _23702 = NOVALUE;
                Ref(_23703);
                RefDS(_55novalue_46976);
                _58SetBBType(_sp_45085, _23703, _55novalue_46976, 16LL, 0LL);
                _23703 = NOVALUE;
L38: 

                /** c_decl.e:1723							sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23704 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23704);
                _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_45085)){
                    _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
                }
                _23704 = NOVALUE;

                /** c_decl.e:1724						end for*/
                _0 = _p_45415;
                if (IS_ATOM_INT(_p_45415)) {
                    _p_45415 = _p_45415 + 1LL;
                    if ((object)((uintptr_t)_p_45415 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45415 = NewDouble((eudouble)_p_45415);
                    }
                }
                else {
                    _p_45415 = binary_op_a(PLUS, _p_45415, 1LL);
                }
                DeRef(_0);
                goto L35; // [1768] 1429
L36: 
                ;
                DeRef(_p_45415);
            }

            /** c_decl.e:1727						call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (object)((s1_ptr)_1)->base;
            ((intptr_t*)_2)[1] = _s_45084;
            _23706 = MAKE_SEQ(_1);
            _1 = (object)SEQ_PTR(_23706);
            _2 = (object)((s1_ptr)_1)->base;
            _0 = (object)_00[_36Execute_id_21850].addr;
            Ref( *(( (intptr_t*)_2) + 1) );
            (*(intptr_t (*)())_0)(
                                *( ((intptr_t *)_2) + 1)
                                 );
            DeRefDS(_23706);
            _23706 = NOVALUE;

            /** c_decl.e:1729						c_puts("    ;\n}\n")*/
            RefDS(_23707);
            _55c_puts(_23707);

            /** c_decl.e:1730						if dll_option and is_exported( s ) then*/
            if (_58dll_option_42889 == 0) {
                goto L3D; // [1793] 2183
            }
            _23709 = _58is_exported(_s_45084);
            if (_23709 == 0) {
                DeRef(_23709);
                _23709 = NOVALUE;
                goto L3D; // [1802] 2183
            }
            else {
                if (!IS_ATOM_INT(_23709) && DBL_PTR(_23709)->dbl == 0.0){
                    DeRef(_23709);
                    _23709 = NOVALUE;
                    goto L3D; // [1802] 2183
                }
                DeRef(_23709);
                _23709 = NOVALUE;
            }
            DeRef(_23709);
            _23709 = NOVALUE;

            /** c_decl.e:1732							LeftSym = TRUE*/
            _58LeftSym_42886 = _13TRUE_447;

            /** c_decl.e:1733							if TOSX then*/
            if (_46TOSX_21914 == 0)
            {
                goto L3E; // [1818] 2078
            }
            else{
            }

            /** c_decl.e:1737								c_stmt0( ret_type & SymTab[s][S_NAME] & " (" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23710 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23710);
            if (!IS_ATOM_INT(_36S_NAME_21396)){
                _23711 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
            }
            else{
                _23711 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
            }
            _23710 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23712;
                concat_list[1] = _23711;
                concat_list[2] = _ret_type_45221;
                Concat_N((object_ptr)&_23713, concat_list, 3);
            }
            _23711 = NOVALUE;
            _58c_stmt0(_23713);
            _23713 = NOVALUE;

            /** c_decl.e:1739								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23714 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23714);
            _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45085)){
                _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
            }
            _23714 = NOVALUE;

            /** c_decl.e:1740								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23716 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23716);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                _23717 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
            }
            else{
                _23717 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
            }
            _23716 = NOVALUE;
            {
                object _p_45534;
                _p_45534 = 1LL;
L3F: 
                if (binary_op_a(GREATER, _p_45534, _23717)){
                    goto L40; // [1876] 1952
                }

                /** c_decl.e:1741									c_puts("int _")*/
                RefDS(_23718);
                _55c_puts(_23718);

                /** c_decl.e:1742									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23719 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23719);
                if (!IS_ATOM_INT(_36S_NAME_21396)){
                    _23720 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
                }
                else{
                    _23720 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
                }
                _23719 = NOVALUE;
                Ref(_23720);
                _55c_puts(_23720);
                _23720 = NOVALUE;

                /** c_decl.e:1743									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23721 = (object)*(((s1_ptr)_2)->base + _s_45084);
                _2 = (object)SEQ_PTR(_23721);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                    _23722 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
                }
                else{
                    _23722 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
                }
                _23721 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45534, _23722)){
                    _23722 = NOVALUE;
                    goto L41; // [1919] 1929
                }
                _23722 = NOVALUE;

                /** c_decl.e:1744										c_puts(", ")*/
                RefDS(_23624);
                _55c_puts(_23624);
L41: 

                /** c_decl.e:1746									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23724 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23724);
                _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_45085)){
                    _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
                }
                _23724 = NOVALUE;

                /** c_decl.e:1747								end for*/
                _0 = _p_45534;
                if (IS_ATOM_INT(_p_45534)) {
                    _p_45534 = _p_45534 + 1LL;
                    if ((object)((uintptr_t)_p_45534 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45534 = NewDouble((eudouble)_p_45534);
                    }
                }
                else {
                    _p_45534 = binary_op_a(PLUS, _p_45534, 1LL);
                }
                DeRef(_0);
                goto L3F; // [1947] 1883
L40: 
                ;
                DeRef(_p_45534);
            }

            /** c_decl.e:1749								c_puts( ") {\n")*/
            RefDS(_23726);
            _55c_puts(_23726);

            /** c_decl.e:1750								c_stmt("    return @(", s)*/
            RefDS(_23727);
            _58c_stmt(_23727, _s_45084, 0LL);

            /** c_decl.e:1751								sp = SymTab[s][S_NEXT]*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23728 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23728);
            _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
            if (!IS_ATOM_INT(_sp_45085)){
                _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
            }
            _23728 = NOVALUE;

            /** c_decl.e:1752								for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23730 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23730);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                _23731 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
            }
            else{
                _23731 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
            }
            _23730 = NOVALUE;
            {
                object _p_45565;
                _p_45565 = 1LL;
L42: 
                if (binary_op_a(GREATER, _p_45565, _23731)){
                    goto L43; // [1994] 2070
                }

                /** c_decl.e:1753									c_puts("_")*/
                RefDS(_22258);
                _55c_puts(_22258);

                /** c_decl.e:1754									c_puts(SymTab[sp][S_NAME])*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23732 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23732);
                if (!IS_ATOM_INT(_36S_NAME_21396)){
                    _23733 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
                }
                else{
                    _23733 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
                }
                _23732 = NOVALUE;
                Ref(_23733);
                _55c_puts(_23733);
                _23733 = NOVALUE;

                /** c_decl.e:1755									if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23734 = (object)*(((s1_ptr)_2)->base + _s_45084);
                _2 = (object)SEQ_PTR(_23734);
                if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                    _23735 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
                }
                else{
                    _23735 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
                }
                _23734 = NOVALUE;
                if (binary_op_a(EQUALS, _p_45565, _23735)){
                    _23735 = NOVALUE;
                    goto L44; // [2037] 2047
                }
                _23735 = NOVALUE;

                /** c_decl.e:1756										c_puts(", ")*/
                RefDS(_23624);
                _55c_puts(_23624);
L44: 

                /** c_decl.e:1758									sp = SymTab[sp][S_NEXT]*/
                _2 = (object)SEQ_PTR(_37SymTab_15637);
                _23737 = (object)*(((s1_ptr)_2)->base + _sp_45085);
                _2 = (object)SEQ_PTR(_23737);
                _sp_45085 = (object)*(((s1_ptr)_2)->base + 2LL);
                if (!IS_ATOM_INT(_sp_45085)){
                    _sp_45085 = (object)DBL_PTR(_sp_45085)->dbl;
                }
                _23737 = NOVALUE;

                /** c_decl.e:1759								end for*/
                _0 = _p_45565;
                if (IS_ATOM_INT(_p_45565)) {
                    _p_45565 = _p_45565 + 1LL;
                    if ((object)((uintptr_t)_p_45565 +(uintptr_t) HIGH_BITS) >= 0){
                        _p_45565 = NewDouble((eudouble)_p_45565);
                    }
                }
                else {
                    _p_45565 = binary_op_a(PLUS, _p_45565, 1LL);
                }
                DeRef(_0);
                goto L42; // [2065] 2001
L43: 
                ;
                DeRef(_p_45565);
            }

            /** c_decl.e:1761								c_puts( ");\n}\n" )*/
            RefDS(_23739);
            _55c_puts(_23739);
            goto L45; // [2075] 2173
L3E: 

            /** c_decl.e:1762							elsif TWINDOWS then*/
            if (_46TWINDOWS_21906 == 0)
            {
                goto L46; // [2082] 2145
            }
            else{
            }

            /** c_decl.e:1766								c_stmt0( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"" )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23740 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23740);
            if (!IS_ATOM_INT(_36S_NAME_21396)){
                _23741 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
            }
            else{
                _23741 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
            }
            _23740 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23742;
                concat_list[1] = _23741;
                concat_list[2] = _ret_type_45221;
                Concat_N((object_ptr)&_23743, concat_list, 3);
            }
            _23741 = NOVALUE;
            _58c_stmt0(_23743);
            _23743 = NOVALUE;

            /** c_decl.e:1767								CName( s )*/
            _58CName(_s_45084);

            /** c_decl.e:1768								c_puts( sprintf( "@%d\")));\n", SymTab[s][S_NUM_ARGS] * TARGET_SIZEOF_POINTER ) )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23745 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23745);
            if (!IS_ATOM_INT(_36S_NUM_ARGS_21447)){
                _23746 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21447)->dbl));
            }
            else{
                _23746 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21447);
            }
            _23745 = NOVALUE;
            if (IS_ATOM_INT(_23746)) {
                {
                    int128_t p128 = (int128_t)_23746 * (int128_t)_36TARGET_SIZEOF_POINTER_21581;
                    if( p128 != (int128_t)(_23747 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                        _23747 = NewDouble( (eudouble)p128 );
                    }
                }
            }
            else {
                _23747 = binary_op(MULTIPLY, _23746, _36TARGET_SIZEOF_POINTER_21581);
            }
            _23746 = NOVALUE;
            _23748 = EPrintf(-9999999, _23744, _23747);
            DeRef(_23747);
            _23747 = NOVALUE;
            _55c_puts(_23748);
            _23748 = NOVALUE;
            goto L45; // [2142] 2173
L46: 

            /** c_decl.e:1770								c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (object)SEQ_PTR(_37SymTab_15637);
            _23749 = (object)*(((s1_ptr)_2)->base + _s_45084);
            _2 = (object)SEQ_PTR(_23749);
            if (!IS_ATOM_INT(_36S_NAME_21396)){
                _23750 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21396)->dbl));
            }
            else{
                _23750 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21396);
            }
            _23749 = NOVALUE;
            {
                object concat_list[3];

                concat_list[0] = _23751;
                concat_list[1] = _23750;
                concat_list[2] = _ret_type_45221;
                Concat_N((object_ptr)&_23752, concat_list, 3);
            }
            _23750 = NOVALUE;
            _58c_stmt(_23752, _s_45084, 0LL);
            _23752 = NOVALUE;
L45: 

            /** c_decl.e:1772							LeftSym = FALSE*/
            _58LeftSym_42886 = _13FALSE_445;
L3D: 

            /** c_decl.e:1774						c_puts("\n\n" )*/
            RefDS(_22330);
            _55c_puts(_22330);
L14: 
            DeRefi(_ret_type_45221);
            _ret_type_45221 = NOVALUE;
            DeRef(_names_45344);
            _names_45344 = NOVALUE;

            /** c_decl.e:1776				end for*/
            _routine_no_45166 = _routine_no_45166 + 1LL;
            goto L12; // [2193] 367
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_45163);
        _these_routines_45163 = NOVALUE;

        /** c_decl.e:1778		end for*/
        _file_no_45111 = _file_no_45111 + 1LL;
        goto L5; // [2203] 91
L6: 
        ;
    }

    /** c_decl.e:1779	end procedure*/
    DeRefi(_buff_45089);
    DeRef(_base_name_45090);
    DeRef(_long_c_file_45091);
    DeRef(_c_file_45092);
    DeRef(_23561);
    _23561 = NOVALUE;
    DeRef(_23600);
    _23600 = NOVALUE;
    DeRef(_23557);
    _23557 = NOVALUE;
    DeRef(_23559);
    _23559 = NOVALUE;
    DeRef(_23523);
    _23523 = NOVALUE;
    _23717 = NOVALUE;
    _23617 = NOVALUE;
    DeRef(_23564);
    _23564 = NOVALUE;
    _23567 = NOVALUE;
    _23731 = NOVALUE;
    _23646 = NOVALUE;
    DeRef(_23596);
    _23596 = NOVALUE;
    DeRef(_23546);
    _23546 = NOVALUE;
    DeRef(_23598);
    _23598 = NOVALUE;
    DeRef(_23532);
    _23532 = NOVALUE;
    DeRef(_23569);
    _23569 = NOVALUE;
    DeRef(_23606);
    _23606 = NOVALUE;
    DeRef(_23594);
    _23594 = NOVALUE;
    DeRef(_23602);
    _23602 = NOVALUE;
    _23671 = NOVALUE;
    DeRef(_23649);
    _23649 = NOVALUE;
    return;
    ;
}



// 0xB03EFF26
