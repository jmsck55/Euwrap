// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _34map(object _m_15067)
{
    object _8628 = NOVALUE;
    object _8627 = NOVALUE;
    object _8626 = NOVALUE;
    object _8624 = NOVALUE;
    object _8623 = NOVALUE;
    object _8622 = NOVALUE;
    object _8620 = NOVALUE;
    object _8619 = NOVALUE;
    object _8618 = NOVALUE;
    object _8616 = NOVALUE;
    object _8615 = NOVALUE;
    object _8612 = NOVALUE;
    object _8610 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:126		if not atom( m ) then*/
    _8610 = IS_ATOM(_m_15067);
    if (_8610 != 0)
    goto L1; // [6] 16
    _8610 = NOVALUE;

    /** map.e:127			return 0*/
    DeRef(_m_15067);
    return 0LL;
L1: 

    /** map.e:129		if length( eumem:ram_space ) < m then*/
    if (IS_SEQUENCE(_35ram_space_13045)){
            _8612 = SEQ_PTR(_35ram_space_13045)->length;
    }
    else {
        _8612 = 1;
    }
    if (binary_op_a(GREATEREQ, _8612, _m_15067)){
        _8612 = NOVALUE;
        goto L2; // [23] 34
    }
    _8612 = NOVALUE;

    /** map.e:130			return 0*/
    DeRef(_m_15067);
    return 0LL;
L2: 

    /** map.e:132		if m < 1 then*/
    if (binary_op_a(GREATEREQ, _m_15067, 1LL)){
        goto L3; // [36] 47
    }

    /** map.e:133			return 0*/
    DeRef(_m_15067);
    return 0LL;
L3: 

    /** map.e:135		if length( eumem:ram_space[m] ) != MAP_MAX then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15067)){
        _8615 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15067)->dbl));
    }
    else{
        _8615 = (object)*(((s1_ptr)_2)->base + _m_15067);
    }
    if (IS_SEQUENCE(_8615)){
            _8616 = SEQ_PTR(_8615)->length;
    }
    else {
        _8616 = 1;
    }
    _8615 = NOVALUE;
    if (_8616 == 3LL)
    goto L4; // [58] 69

    /** map.e:136			return 0*/
    DeRef(_m_15067);
    _8615 = NOVALUE;
    return 0LL;
L4: 

    /** map.e:138		if not atom( eumem:ram_space[m][MAP_SIZE] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15067)){
        _8618 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15067)->dbl));
    }
    else{
        _8618 = (object)*(((s1_ptr)_2)->base + _m_15067);
    }
    _2 = (object)SEQ_PTR(_8618);
    _8619 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8618 = NOVALUE;
    _8620 = IS_ATOM(_8619);
    _8619 = NOVALUE;
    if (_8620 != 0)
    goto L5; // [84] 94
    _8620 = NOVALUE;

    /** map.e:139			return 0*/
    DeRef(_m_15067);
    _8615 = NOVALUE;
    return 0LL;
L5: 

    /** map.e:141		if not sequence( eumem:ram_space[m][MAP_SLOTS] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15067)){
        _8622 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15067)->dbl));
    }
    else{
        _8622 = (object)*(((s1_ptr)_2)->base + _m_15067);
    }
    _2 = (object)SEQ_PTR(_8622);
    _8623 = (object)*(((s1_ptr)_2)->base + 2LL);
    _8622 = NOVALUE;
    _8624 = IS_SEQUENCE(_8623);
    _8623 = NOVALUE;
    if (_8624 != 0)
    goto L6; // [109] 119
    _8624 = NOVALUE;

    /** map.e:142			return 0*/
    DeRef(_m_15067);
    _8615 = NOVALUE;
    return 0LL;
L6: 

    /** map.e:144		if not atom( eumem:ram_space[m][MAP_MAX] ) then*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_m_15067)){
        _8626 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_m_15067)->dbl));
    }
    else{
        _8626 = (object)*(((s1_ptr)_2)->base + _m_15067);
    }
    _2 = (object)SEQ_PTR(_8626);
    _8627 = (object)*(((s1_ptr)_2)->base + 3LL);
    _8626 = NOVALUE;
    _8628 = IS_ATOM(_8627);
    _8627 = NOVALUE;
    if (_8628 != 0)
    goto L7; // [134] 144
    _8628 = NOVALUE;

    /** map.e:145			return 0*/
    DeRef(_m_15067);
    _8615 = NOVALUE;
    return 0LL;
L7: 

    /** map.e:147		return 1*/
    DeRef(_m_15067);
    _8615 = NOVALUE;
    return 1LL;
    ;
}


object _34new_map_seq(object _size_15098)
{
    object _slots_15099 = NOVALUE;
    object _8640 = NOVALUE;
    object _8639 = NOVALUE;
    object _8638 = NOVALUE;
    object _8637 = NOVALUE;
    object _8633 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:155		integer slots = DEFAULT_SIZE * 2*/
    _slots_15099 = 16LL;

    /** map.e:156		if size <= DEFAULT_SIZE then*/
    if (_size_15098 > 8LL)
    goto L1; // [11] 23

    /** map.e:157			size = DEFAULT_SIZE*/
    _size_15098 = 8LL;
    goto L2; // [20] 55
L1: 

    /** map.e:159			size = floor( size * 1.5 )*/
    _8633 = NewDouble((eudouble)_size_15098 * DBL_PTR(_8632)->dbl);
    _size_15098 = unary_op(FLOOR, _8633);
    DeRefDS(_8633);
    _8633 = NOVALUE;
    if (!IS_ATOM_INT(_size_15098)) {
        _1 = (object)(DBL_PTR(_size_15098)->dbl);
        DeRefDS(_size_15098);
        _size_15098 = _1;
    }

    /** map.e:160			while slots < size do*/
L3: 
    if (_slots_15099 >= _size_15098)
    goto L4; // [39] 54

    /** map.e:162				slots *= 2*/
    _slots_15099 = _slots_15099 + _slots_15099;

    /** map.e:163			end while*/
    goto L3; // [51] 39
L4: 
L2: 

    /** map.e:165		return { 0, repeat( EMPTY_SLOT, slots ), floor( size * 2/3 ) }*/
    _8637 = Repeat(_34EMPTY_SLOT_15055, _slots_15099);
    _8638 = _size_15098 + _size_15098;
    if ((object)((uintptr_t)_8638 + (uintptr_t)HIGH_BITS) >= 0){
        _8638 = NewDouble((eudouble)_8638);
    }
    if (IS_ATOM_INT(_8638)) {
        if (3LL > 0 && _8638 >= 0) {
            _8639 = _8638 / 3LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_8638 / (eudouble)3LL);
            if (_8638 != MININT)
            _8639 = (object)temp_dbl;
            else
            _8639 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _8638, 3LL);
        _8639 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_8638);
    _8638 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 0LL;
    ((intptr_t*)_2)[2] = _8637;
    ((intptr_t*)_2)[3] = _8639;
    _8640 = MAKE_SEQ(_1);
    _8639 = NOVALUE;
    _8637 = NOVALUE;
    return _8640;
    ;
}


object _34lookup(object _key_15142, object _hashval_15143, object _slots_15145)
{
    object _mask_15146 = NOVALUE;
    object _index_15149 = NOVALUE;
    object _index_hash_15152 = NOVALUE;
    object _slot_15153 = NOVALUE;
    object _perturb_15154 = NOVALUE;
    object _this_hash_15155 = NOVALUE;
    object _this_key_15156 = NOVALUE;
    object _looks_15157 = NOVALUE;
    object _removed_slot_15158 = NOVALUE;
    object _8669 = NOVALUE;
    object _8656 = NOVALUE;
    object _8655 = NOVALUE;
    object _8654 = NOVALUE;
    object _8653 = NOVALUE;
    object _8651 = NOVALUE;
    object _8649 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:275		integer mask = length( slots ) - 1*/
    if (IS_SEQUENCE(_slots_15145)){
            _8649 = SEQ_PTR(_slots_15145)->length;
    }
    else {
        _8649 = 1;
    }
    _mask_15146 = _8649 - 1LL;
    _8649 = NOVALUE;

    /** map.e:276		integer index = and_bits( hashval, mask ) + 1*/
    {uintptr_t tu;
         tu = (uintptr_t)_hashval_15143 & (uintptr_t)_mask_15146;
         _8651 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_8651)) {
        _index_15149 = _8651 + 1;
    }
    else
    { // coercing _index_15149 to an integer 1
        _index_15149 = 1+(object)(DBL_PTR(_8651)->dbl);
        if( !IS_ATOM_INT(_index_15149) ){
            _index_15149 = (object)DBL_PTR(_index_15149)->dbl;
        }
    }
    DeRef(_8651);
    _8651 = NOVALUE;

    /** map.e:277		ifdef BITS64 then*/

    /** map.e:278			integer index_hash = index*/
    _index_hash_15152 = _index_15149;

    /** map.e:282		sequence slot*/

    /** map.e:284		integer perturb = hashval*/
    _perturb_15154 = _hashval_15143;

    /** map.e:285		integer this_hash*/

    /** map.e:286		object this_key*/

    /** map.e:287		integer looks = 0*/
    _looks_15157 = 0LL;

    /** map.e:288		integer removed_slot = 0*/
    _removed_slot_15158 = 0LL;

    /** map.e:289		while this_hash != hashval or not equal( this_key, key ) with entry do*/
    goto L1; // [54] 140
L2: 
    _8653 = (_this_hash_15155 != _hashval_15143);
    if (_8653 != 0) {
        DeRef(_8654);
        _8654 = 1;
        goto L3; // [63] 80
    }
    if (_this_key_15156 == _key_15142)
    _8655 = 1;
    else if (IS_ATOM_INT(_this_key_15156) && IS_ATOM_INT(_key_15142))
    _8655 = 0;
    else
    _8655 = (compare(_this_key_15156, _key_15142) == 0);
    _8656 = (_8655 == 0);
    _8655 = NOVALUE;
    _8654 = (_8656 != 0);
L3: 
    if (_8654 == 0)
    {
        _8654 = NOVALUE;
        goto L4; // [80] 217
    }
    else{
        _8654 = NOVALUE;
    }

    /** map.e:290			index_hash *= 4*/
    _index_hash_15152 = _index_hash_15152 * 4LL;

    /** map.e:291			index_hash += index*/
    _index_hash_15152 = _index_hash_15152 + _index_15149;

    /** map.e:292			index_hash += perturb*/
    _index_hash_15152 = _index_hash_15152 + _perturb_15154;

    /** map.e:293			index_hash += 1*/
    _index_hash_15152 = _index_hash_15152 + 1;

    /** map.e:294			index_hash = and_bits( 0xffff_ffff, index_hash )*/
    {uintptr_t tu;
         tu = (uintptr_t)4294967295LL & (uintptr_t)_index_hash_15152;
         _index_hash_15152 = MAKE_UINT(tu);
    }

    /** map.e:295			index = and_bits( mask, index_hash )*/
    {uintptr_t tu;
         tu = (uintptr_t)_mask_15146 & (uintptr_t)_index_hash_15152;
         _index_15149 = MAKE_UINT(tu);
    }

    /** map.e:296			index += 1*/
    _index_15149 = _index_15149 + 1;

    /** map.e:297			perturb = floor( perturb / 32 )*/
    if (32LL > 0 && _perturb_15154 >= 0) {
        _perturb_15154 = _perturb_15154 / 32LL;
    }
    else {
        temp_dbl = EUFLOOR((eudouble)_perturb_15154 / (eudouble)32LL);
        _perturb_15154 = (object)temp_dbl;
    }

    /** map.e:298		entry*/
L1: 

    /** map.e:299			slot = slots[index]*/
    DeRef(_slot_15153);
    _2 = (object)SEQ_PTR(_slots_15145);
    _slot_15153 = (object)*(((s1_ptr)_2)->base + _index_15149);
    Ref(_slot_15153);

    /** map.e:300			this_hash = slot[SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slot_15153);
    _this_hash_15155 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_this_hash_15155))
    _this_hash_15155 = (object)DBL_PTR(_this_hash_15155)->dbl;

    /** map.e:301			if this_hash = EMPTY then*/
    if (_this_hash_15155 != -2LL)
    goto L5; // [156] 169

    /** map.e:302				return index*/
    DeRef(_key_15142);
    DeRefDS(_slots_15145);
    DeRefDS(_slot_15153);
    DeRef(_this_key_15156);
    DeRef(_8656);
    _8656 = NOVALUE;
    DeRef(_8653);
    _8653 = NOVALUE;
    return _index_15149;
    goto L6; // [166] 200
L5: 

    /** map.e:303			elsif looks > length( slots ) then*/
    if (IS_SEQUENCE(_slots_15145)){
            _8669 = SEQ_PTR(_slots_15145)->length;
    }
    else {
        _8669 = 1;
    }
    if (_looks_15157 <= _8669)
    goto L7; // [174] 187

    /** map.e:304				return removed_slot*/
    DeRef(_key_15142);
    DeRefDS(_slots_15145);
    DeRef(_slot_15153);
    DeRef(_this_key_15156);
    DeRef(_8656);
    _8656 = NOVALUE;
    DeRef(_8653);
    _8653 = NOVALUE;
    return _removed_slot_15158;
    goto L6; // [184] 200
L7: 

    /** map.e:305			elsif this_hash = REMOVED then*/
    if (_this_hash_15155 != -1LL)
    goto L8; // [189] 199

    /** map.e:306				removed_slot = index*/
    _removed_slot_15158 = _index_15149;
L8: 
L6: 

    /** map.e:308			this_key = slot[SLOT_KEY]*/
    DeRef(_this_key_15156);
    _2 = (object)SEQ_PTR(_slot_15153);
    _this_key_15156 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_this_key_15156);

    /** map.e:309			looks += 1*/
    _looks_15157 = _looks_15157 + 1;

    /** map.e:310		end while*/
    goto L2; // [214] 57
L4: 

    /** map.e:311		return index*/
    DeRef(_key_15142);
    DeRefDS(_slots_15145);
    DeRef(_slot_15153);
    DeRef(_this_key_15156);
    DeRef(_8656);
    _8656 = NOVALUE;
    DeRef(_8653);
    _8653 = NOVALUE;
    return _index_15149;
    ;
}


object _34rehash_seq(object _old_map_15186, object _size_15187)
{
    object _old_size_15188 = NOVALUE;
    object _index_15190 = NOVALUE;
    object _new_map_15203 = NOVALUE;
    object _slots_15205 = NOVALUE;
    object _old_slots_15208 = NOVALUE;
    object _old_slot_15213 = NOVALUE;
    object _old_hash_15215 = NOVALUE;
    object _8690 = NOVALUE;
    object _8686 = NOVALUE;
    object _8684 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:316		integer old_size = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_15186);
    _old_size_15188 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_size_15188))
    _old_size_15188 = (object)DBL_PTR(_old_size_15188)->dbl;

    /** map.e:319		if size = 0 then*/

    /** map.e:320			if old_size > 50_000 then*/
    if (_old_size_15188 <= 50000LL)
    goto L1; // [19] 32

    /** map.e:321				size = old_size * 2*/
    _size_15187 = _old_size_15188 + _old_size_15188;
    goto L2; // [29] 69
L1: 

    /** map.e:323				size = old_size * 4*/
    _size_15187 = _old_size_15188 * 4LL;
    goto L2; // [41] 69

    /** map.e:325		elsif size < old_size then*/
    if (_size_15187 >= _old_size_15188)
    goto L3; // [46] 68

    /** map.e:326			size = old_size*/
    _size_15187 = _old_size_15188;

    /** map.e:327			if size < DEFAULT_SIZE then*/
    if (_size_15187 >= 8LL)
    goto L4; // [57] 67

    /** map.e:328				size = DEFAULT_SIZE*/
    _size_15187 = 8LL;
L4: 
L3: 
L2: 

    /** map.e:332		sequence new_map = new_map_seq( size )*/
    _0 = _new_map_15203;
    _new_map_15203 = _34new_map_seq(_size_15187);
    DeRef(_0);

    /** map.e:333		sequence slots = new_map[MAP_SLOTS]*/
    DeRef(_slots_15205);
    _2 = (object)SEQ_PTR(_new_map_15203);
    _slots_15205 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15205);

    /** map.e:334		new_map[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_new_map_15203);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_15203 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:335		new_map[MAP_SIZE] = old_map[MAP_SIZE]*/
    _2 = (object)SEQ_PTR(_old_map_15186);
    _8684 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_8684);
    _2 = (object)SEQ_PTR(_new_map_15203);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_15203 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8684;
    if( _1 != _8684 ){
        DeRef(_1);
    }
    _8684 = NOVALUE;

    /** map.e:337		sequence old_slots = old_map[MAP_SLOTS]*/
    DeRef(_old_slots_15208);
    _2 = (object)SEQ_PTR(_old_map_15186);
    _old_slots_15208 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_old_slots_15208);

    /** map.e:338		for i = 1 to length( old_slots ) do*/
    if (IS_SEQUENCE(_old_slots_15208)){
            _8686 = SEQ_PTR(_old_slots_15208)->length;
    }
    else {
        _8686 = 1;
    }
    {
        object _i_15211;
        _i_15211 = 1LL;
L5: 
        if (_i_15211 > _8686){
            goto L6; // [114] 171
        }

        /** map.e:339			sequence old_slot = old_slots[i]*/
        DeRef(_old_slot_15213);
        _2 = (object)SEQ_PTR(_old_slots_15208);
        _old_slot_15213 = (object)*(((s1_ptr)_2)->base + _i_15211);
        Ref(_old_slot_15213);

        /** map.e:340			integer old_hash = old_slot[SLOT_HASH]*/
        _2 = (object)SEQ_PTR(_old_slot_15213);
        _old_hash_15215 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_old_hash_15215))
        _old_hash_15215 = (object)DBL_PTR(_old_hash_15215)->dbl;

        /** map.e:341			if old_hash != -1 then*/
        if (_old_hash_15215 == -1LL)
        goto L7; // [137] 162

        /** map.e:342				index = lookup( old_slot[SLOT_KEY], old_hash, slots )*/
        _2 = (object)SEQ_PTR(_old_slot_15213);
        _8690 = (object)*(((s1_ptr)_2)->base + 2LL);
        Ref(_8690);
        RefDS(_slots_15205);
        _index_15190 = _34lookup(_8690, _old_hash_15215, _slots_15205);
        _8690 = NOVALUE;
        if (!IS_ATOM_INT(_index_15190)) {
            _1 = (object)(DBL_PTR(_index_15190)->dbl);
            DeRefDS(_index_15190);
            _index_15190 = _1;
        }

        /** map.e:343				slots[index] = old_slot*/
        RefDS(_old_slot_15213);
        _2 = (object)SEQ_PTR(_slots_15205);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15205 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15190);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _old_slot_15213;
        DeRef(_1);
L7: 
        DeRef(_old_slot_15213);
        _old_slot_15213 = NOVALUE;

        /** map.e:345		end for*/
        _i_15211 = _i_15211 + 1LL;
        goto L5; // [166] 121
L6: 
        ;
    }

    /** map.e:346		new_map[MAP_SLOTS] = slots*/
    RefDS(_slots_15205);
    _2 = (object)SEQ_PTR(_new_map_15203);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_map_15203 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_15205;
    DeRef(_1);

    /** map.e:347		return new_map*/
    DeRefDS(_old_map_15186);
    DeRefDS(_slots_15205);
    DeRef(_old_slots_15208);
    return _new_map_15203;
    ;
}


object _34new_extra(object _the_map_p_15223, object _initial_size_p_15224)
{
    object _new_1__tmp_at22_15230 = NOVALUE;
    object _new_inlined_new_at_22_15229 = NOVALUE;
    object _8692 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:376		if map(the_map_p) then*/
    Ref(_the_map_p_15223);
    _8692 = _34map(_the_map_p_15223);
    if (_8692 == 0) {
        DeRef(_8692);
        _8692 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_8692) && DBL_PTR(_8692)->dbl == 0.0){
            DeRef(_8692);
            _8692 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_8692);
        _8692 = NOVALUE;
    }
    DeRef(_8692);
    _8692 = NOVALUE;

    /** map.e:377			return the_map_p*/
    return _the_map_p_15223;
    goto L2; // [18] 42
L1: 

    /** map.e:379			return new(initial_size_p)*/

    /** map.e:271		return eumem:malloc( new_map_seq( initial_size_p ) )*/
    _0 = _new_1__tmp_at22_15230;
    _new_1__tmp_at22_15230 = _34new_map_seq(_initial_size_p_15224);
    DeRef(_0);
    Ref(_new_1__tmp_at22_15230);
    _0 = _new_inlined_new_at_22_15229;
    _new_inlined_new_at_22_15229 = _35malloc(_new_1__tmp_at22_15230, 1LL);
    DeRef(_0);
    DeRef(_new_1__tmp_at22_15230);
    _new_1__tmp_at22_15230 = NOVALUE;
    DeRef(_the_map_p_15223);
    return _new_inlined_new_at_22_15229;
L2: 
    ;
}


object _34has(object _the_map_p_15264, object _key_15265)
{
    object _hashval_15266 = NOVALUE;
    object _hash_inlined_hash_at_2_15268 = NOVALUE;
    object _slots_15269 = NOVALUE;
    object _index_15272 = NOVALUE;
    object _8711 = NOVALUE;
    object _8710 = NOVALUE;
    object _8709 = NOVALUE;
    object _8706 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:464		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15266 = calc_hash(_key_15265, -6LL);

    /** map.e:465		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15264)){
        _8706 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15264)->dbl));
    }
    else{
        _8706 = (object)*(((s1_ptr)_2)->base + _the_map_p_15264);
    }
    DeRef(_slots_15269);
    _2 = (object)SEQ_PTR(_8706);
    _slots_15269 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15269);
    _8706 = NOVALUE;

    /** map.e:466		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15265);
    RefDS(_slots_15269);
    _index_15272 = _34lookup(_key_15265, _hashval_15266, _slots_15269);
    if (!IS_ATOM_INT(_index_15272)) {
        _1 = (object)(DBL_PTR(_index_15272)->dbl);
        DeRefDS(_index_15272);
        _index_15272 = _1;
    }

    /** map.e:468		return hashval = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15269);
    _8709 = (object)*(((s1_ptr)_2)->base + _index_15272);
    _2 = (object)SEQ_PTR(_8709);
    _8710 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8709 = NOVALUE;
    if (IS_ATOM_INT(_8710)) {
        _8711 = (_hashval_15266 == _8710);
    }
    else {
        _8711 = binary_op(EQUALS, _hashval_15266, _8710);
    }
    _8710 = NOVALUE;
    DeRef(_the_map_p_15264);
    DeRef(_key_15265);
    DeRefDS(_slots_15269);
    return _8711;
    ;
}


object _34get(object _the_map_p_15279, object _key_15280, object _default_15281)
{
    object _hashval_15282 = NOVALUE;
    object _hash_inlined_hash_at_2_15284 = NOVALUE;
    object _slots_15285 = NOVALUE;
    object _index_15288 = NOVALUE;
    object _slot_15290 = NOVALUE;
    object _8718 = NOVALUE;
    object _8716 = NOVALUE;
    object _8712 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:505		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15282 = calc_hash(_key_15280, -6LL);

    /** map.e:506		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15279)){
        _8712 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15279)->dbl));
    }
    else{
        _8712 = (object)*(((s1_ptr)_2)->base + _the_map_p_15279);
    }
    DeRef(_slots_15285);
    _2 = (object)SEQ_PTR(_8712);
    _slots_15285 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15285);
    _8712 = NOVALUE;

    /** map.e:507		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15280);
    RefDS(_slots_15285);
    _index_15288 = _34lookup(_key_15280, _hashval_15282, _slots_15285);
    if (!IS_ATOM_INT(_index_15288)) {
        _1 = (object)(DBL_PTR(_index_15288)->dbl);
        DeRefDS(_index_15288);
        _index_15288 = _1;
    }

    /** map.e:508		sequence slot = slots[index]*/
    DeRef(_slot_15290);
    _2 = (object)SEQ_PTR(_slots_15285);
    _slot_15290 = (object)*(((s1_ptr)_2)->base + _index_15288);
    Ref(_slot_15290);

    /** map.e:509		if hashval = slot[SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slot_15290);
    _8716 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (binary_op_a(NOTEQ, _hashval_15282, _8716)){
        _8716 = NOVALUE;
        goto L1; // [50] 65
    }
    _8716 = NOVALUE;

    /** map.e:510			return slot[SLOT_VALUE]*/
    _2 = (object)SEQ_PTR(_slot_15290);
    _8718 = (object)*(((s1_ptr)_2)->base + 3LL);
    Ref(_8718);
    DeRef(_the_map_p_15279);
    DeRef(_key_15280);
    DeRef(_default_15281);
    DeRefDS(_slots_15285);
    DeRefDS(_slot_15290);
    return _8718;
L1: 

    /** map.e:512		return default*/
    DeRef(_the_map_p_15279);
    DeRef(_key_15280);
    DeRef(_slots_15285);
    DeRef(_slot_15290);
    _8718 = NOVALUE;
    return _default_15281;
    ;
}


void _34put(object _the_map_p_15318, object _key_15319, object _val_15320, object _op_15321, object _deprecated_15322)
{
    object _hashval_15323 = NOVALUE;
    object _hash_inlined_hash_at_2_15325 = NOVALUE;
    object _the_map_seq_15326 = NOVALUE;
    object _slots_15328 = NOVALUE;
    object _index_15330 = NOVALUE;
    object _old_hash_15332 = NOVALUE;
    object _msg_inlined_crash_at_288_15375 = NOVALUE;
    object _msg_inlined_crash_at_348_15385 = NOVALUE;
    object _msg_inlined_crash_at_535_15417 = NOVALUE;
    object _8785 = NOVALUE;
    object _8783 = NOVALUE;
    object _8782 = NOVALUE;
    object _8781 = NOVALUE;
    object _8780 = NOVALUE;
    object _8779 = NOVALUE;
    object _8777 = NOVALUE;
    object _8776 = NOVALUE;
    object _8775 = NOVALUE;
    object _8774 = NOVALUE;
    object _8773 = NOVALUE;
    object _8772 = NOVALUE;
    object _8770 = NOVALUE;
    object _8769 = NOVALUE;
    object _8768 = NOVALUE;
    object _8767 = NOVALUE;
    object _8765 = NOVALUE;
    object _8764 = NOVALUE;
    object _8763 = NOVALUE;
    object _8762 = NOVALUE;
    object _8759 = NOVALUE;
    object _8758 = NOVALUE;
    object _8757 = NOVALUE;
    object _8756 = NOVALUE;
    object _8755 = NOVALUE;
    object _8753 = NOVALUE;
    object _8752 = NOVALUE;
    object _8751 = NOVALUE;
    object _8750 = NOVALUE;
    object _8749 = NOVALUE;
    object _8747 = NOVALUE;
    object _8744 = NOVALUE;
    object _8743 = NOVALUE;
    object _8741 = NOVALUE;
    object _8736 = NOVALUE;
    object _8735 = NOVALUE;
    object _8732 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:579		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15323 = calc_hash(_key_15319, -6LL);

    /** map.e:580		sequence the_map_seq = eumem:ram_space[the_map_p]*/
    DeRef(_the_map_seq_15326);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15318)){
        _the_map_seq_15326 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15318)->dbl));
    }
    else{
        _the_map_seq_15326 = (object)*(((s1_ptr)_2)->base + _the_map_p_15318);
    }
    Ref(_the_map_seq_15326);

    /** map.e:581		eumem:ram_space[the_map_p] = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15318))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15318)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15318);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:582		sequence slots = the_map_seq[MAP_SLOTS]*/
    DeRef(_slots_15328);
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    _slots_15328 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15328);

    /** map.e:584		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15319);
    RefDS(_slots_15328);
    _index_15330 = _34lookup(_key_15319, _hashval_15323, _slots_15328);
    if (!IS_ATOM_INT(_index_15330)) {
        _1 = (object)(DBL_PTR(_index_15330)->dbl);
        DeRefDS(_index_15330);
        _index_15330 = _1;
    }

    /** map.e:585		integer old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15328);
    _8732 = (object)*(((s1_ptr)_2)->base + _index_15330);
    _2 = (object)SEQ_PTR(_8732);
    _old_hash_15332 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_hash_15332)){
        _old_hash_15332 = (object)DBL_PTR(_old_hash_15332)->dbl;
    }
    _8732 = NOVALUE;

    /** map.e:587		if old_hash < 0 then*/
    if (_old_hash_15332 >= 0LL)
    goto L1; // [62] 142

    /** map.e:589			if the_map_seq[MAP_SIZE] > the_map_seq[MAP_MAX] then*/
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    _8735 = (object)*(((s1_ptr)_2)->base + 1LL);
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    _8736 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (binary_op_a(LESSEQ, _8735, _8736)){
        _8735 = NOVALUE;
        _8736 = NOVALUE;
        goto L2; // [76] 127
    }
    _8735 = NOVALUE;
    _8736 = NOVALUE;

    /** map.e:590				slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15328);
    _slots_15328 = _5;

    /** map.e:591				the_map_seq = rehash_seq( the_map_seq )*/
    RefDS(_the_map_seq_15326);
    _0 = _the_map_seq_15326;
    _the_map_seq_15326 = _34rehash_seq(_the_map_seq_15326, 0LL);
    DeRefDS(_0);

    /** map.e:592				slots = the_map_seq[MAP_SLOTS]*/
    DeRefDS(_slots_15328);
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    _slots_15328 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15328);

    /** map.e:593				index = lookup( key, hashval, slots )*/
    Ref(_key_15319);
    RefDS(_slots_15328);
    _index_15330 = _34lookup(_key_15319, _hashval_15323, _slots_15328);
    if (!IS_ATOM_INT(_index_15330)) {
        _1 = (object)(DBL_PTR(_index_15330)->dbl);
        DeRefDS(_index_15330);
        _index_15330 = _1;
    }

    /** map.e:594				old_hash = slots[index][SLOT_HASH]*/
    _2 = (object)SEQ_PTR(_slots_15328);
    _8741 = (object)*(((s1_ptr)_2)->base + _index_15330);
    _2 = (object)SEQ_PTR(_8741);
    _old_hash_15332 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_old_hash_15332)){
        _old_hash_15332 = (object)DBL_PTR(_old_hash_15332)->dbl;
    }
    _8741 = NOVALUE;
L2: 

    /** map.e:596			the_map_seq[MAP_SIZE] += 1*/
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    _8743 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_8743)) {
        _8744 = _8743 + 1;
        if (_8744 > MAXINT){
            _8744 = NewDouble((eudouble)_8744);
        }
    }
    else
    _8744 = binary_op(PLUS, 1, _8743);
    _8743 = NOVALUE;
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8744;
    if( _1 != _8744 ){
        DeRef(_1);
    }
    _8744 = NOVALUE;
L1: 

    /** map.e:599		the_map_seq[MAP_SLOTS] = 0*/
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** map.e:601		switch op do*/
    _0 = _op_15321;
    switch ( _0 ){ 

        /** map.e:602			case PUT then*/
        case 1:

        /** map.e:603				slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        Ref(_val_15320);
        ((intptr_t*)_2)[3] = _val_15320;
        _8747 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8747;
        if( _1 != _8747 ){
            DeRef(_1);
        }
        _8747 = NOVALUE;
        goto L3; // [171] 555

        /** map.e:604			case ADD then*/
        case 2:

        /** map.e:605				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto L4; // [179] 198

        /** map.e:606					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        Ref(_val_15320);
        ((intptr_t*)_2)[3] = _val_15320;
        _8749 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8749;
        if( _1 != _8749 ){
            DeRef(_1);
        }
        _8749 = NOVALUE;
        goto L3; // [195] 555
L4: 

        /** map.e:608					slots[index] = { hashval, key, val + slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15328);
        _8750 = (object)*(((s1_ptr)_2)->base + _index_15330);
        _2 = (object)SEQ_PTR(_8750);
        _8751 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8750 = NOVALUE;
        if (IS_ATOM_INT(_val_15320) && IS_ATOM_INT(_8751)) {
            _8752 = _val_15320 + _8751;
            if ((object)((uintptr_t)_8752 + (uintptr_t)HIGH_BITS) >= 0){
                _8752 = NewDouble((eudouble)_8752);
            }
        }
        else {
            _8752 = binary_op(PLUS, _val_15320, _8751);
        }
        _8751 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8752;
        _8753 = MAKE_SEQ(_1);
        _8752 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8753;
        if( _1 != _8753 ){
            DeRef(_1);
        }
        _8753 = NOVALUE;
        goto L3; // [223] 555

        /** map.e:610			case SUBTRACT then*/
        case 3:

        /** map.e:611				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto L5; // [231] 250

        /** map.e:612					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        Ref(_val_15320);
        ((intptr_t*)_2)[3] = _val_15320;
        _8755 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8755;
        if( _1 != _8755 ){
            DeRef(_1);
        }
        _8755 = NOVALUE;
        goto L3; // [247] 555
L5: 

        /** map.e:614					slots[index] = { hashval, key, slots[index][SLOT_VALUE] - val }*/
        _2 = (object)SEQ_PTR(_slots_15328);
        _8756 = (object)*(((s1_ptr)_2)->base + _index_15330);
        _2 = (object)SEQ_PTR(_8756);
        _8757 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8756 = NOVALUE;
        if (IS_ATOM_INT(_8757) && IS_ATOM_INT(_val_15320)) {
            _8758 = _8757 - _val_15320;
            if ((object)((uintptr_t)_8758 +(uintptr_t) HIGH_BITS) >= 0){
                _8758 = NewDouble((eudouble)_8758);
            }
        }
        else {
            _8758 = binary_op(MINUS, _8757, _val_15320);
        }
        _8757 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8758;
        _8759 = MAKE_SEQ(_1);
        _8758 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8759;
        if( _1 != _8759 ){
            DeRef(_1);
        }
        _8759 = NOVALUE;
        goto L3; // [275] 555

        /** map.e:617			case MULTIPLY then*/
        case 4:

        /** map.e:618				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto L6; // [283] 310

        /** map.e:619					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_288_15375);
        _msg_inlined_crash_at_288_15375 = EPrintf(-9999999, _8761, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_288_15375);

        /** error.e:53	end procedure*/
        goto L7; // [302] 305
L7: 
        DeRefi(_msg_inlined_crash_at_288_15375);
        _msg_inlined_crash_at_288_15375 = NOVALUE;
        goto L3; // [307] 555
L6: 

        /** map.e:621					slots[index] = { hashval, key, val * slots[index][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15328);
        _8762 = (object)*(((s1_ptr)_2)->base + _index_15330);
        _2 = (object)SEQ_PTR(_8762);
        _8763 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8762 = NOVALUE;
        if (IS_ATOM_INT(_val_15320) && IS_ATOM_INT(_8763)) {
            {
                int128_t p128 = (int128_t)_val_15320 * (int128_t)_8763;
                if( p128 != (int128_t)(_8764 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _8764 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _8764 = binary_op(MULTIPLY, _val_15320, _8763);
        }
        _8763 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8764;
        _8765 = MAKE_SEQ(_1);
        _8764 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8765;
        if( _1 != _8765 ){
            DeRef(_1);
        }
        _8765 = NOVALUE;
        goto L3; // [335] 555

        /** map.e:624			case DIVIDE then*/
        case 5:

        /** map.e:625				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto L8; // [343] 370

        /** map.e:626					error:crash("Inappropriate initial operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_348_15385);
        _msg_inlined_crash_at_348_15385 = EPrintf(-9999999, _8761, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_348_15385);

        /** error.e:53	end procedure*/
        goto L9; // [362] 365
L9: 
        DeRefi(_msg_inlined_crash_at_348_15385);
        _msg_inlined_crash_at_348_15385 = NOVALUE;
        goto L3; // [367] 555
L8: 

        /** map.e:628					slots[index] = { hashval, key, slots[index][SLOT_VALUE] / val }*/
        _2 = (object)SEQ_PTR(_slots_15328);
        _8767 = (object)*(((s1_ptr)_2)->base + _index_15330);
        _2 = (object)SEQ_PTR(_8767);
        _8768 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8767 = NOVALUE;
        if (IS_ATOM_INT(_8768) && IS_ATOM_INT(_val_15320)) {
            _8769 = (_8768 % _val_15320) ? NewDouble((eudouble)_8768 / _val_15320) : (_8768 / _val_15320);
        }
        else {
            _8769 = binary_op(DIVIDE, _8768, _val_15320);
        }
        _8768 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8769;
        _8770 = MAKE_SEQ(_1);
        _8769 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8770;
        if( _1 != _8770 ){
            DeRef(_1);
        }
        _8770 = NOVALUE;
        goto L3; // [395] 555

        /** map.e:631			case APPEND then*/
        case 6:

        /** map.e:632				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto LA; // [403] 426

        /** map.e:633					slots[index] = { hashval, key, {val} }*/
        _1 = NewS1(1);
        _2 = (object)((s1_ptr)_1)->base;
        Ref(_val_15320);
        ((intptr_t*)_2)[1] = _val_15320;
        _8772 = MAKE_SEQ(_1);
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8772;
        _8773 = MAKE_SEQ(_1);
        _8772 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8773;
        if( _1 != _8773 ){
            DeRef(_1);
        }
        _8773 = NOVALUE;
        goto L3; // [423] 555
LA: 

        /** map.e:635					slots[index] = { hashval, key, append( slots[index][SLOT_VALUE], val ) }*/
        _2 = (object)SEQ_PTR(_slots_15328);
        _8774 = (object)*(((s1_ptr)_2)->base + _index_15330);
        _2 = (object)SEQ_PTR(_8774);
        _8775 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8774 = NOVALUE;
        Ref(_val_15320);
        Append(&_8776, _8775, _val_15320);
        _8775 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8776;
        _8777 = MAKE_SEQ(_1);
        _8776 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8777;
        if( _1 != _8777 ){
            DeRef(_1);
        }
        _8777 = NOVALUE;
        goto L3; // [451] 555

        /** map.e:638			case CONCAT then*/
        case 7:

        /** map.e:639				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto LB; // [459] 478

        /** map.e:640					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        Ref(_val_15320);
        ((intptr_t*)_2)[3] = _val_15320;
        _8779 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8779;
        if( _1 != _8779 ){
            DeRef(_1);
        }
        _8779 = NOVALUE;
        goto L3; // [475] 555
LB: 

        /** map.e:642					slots[index] = { hashval, key, slots[index][SLOT_VALUE] & val }*/
        _2 = (object)SEQ_PTR(_slots_15328);
        _8780 = (object)*(((s1_ptr)_2)->base + _index_15330);
        _2 = (object)SEQ_PTR(_8780);
        _8781 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8780 = NOVALUE;
        if (IS_SEQUENCE(_8781) && IS_ATOM(_val_15320)) {
            Ref(_val_15320);
            Append(&_8782, _8781, _val_15320);
        }
        else if (IS_ATOM(_8781) && IS_SEQUENCE(_val_15320)) {
            Ref(_8781);
            Prepend(&_8782, _val_15320, _8781);
        }
        else {
            Concat((object_ptr)&_8782, _8781, _val_15320);
            _8781 = NOVALUE;
        }
        _8781 = NOVALUE;
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        ((intptr_t*)_2)[3] = _8782;
        _8783 = MAKE_SEQ(_1);
        _8782 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8783;
        if( _1 != _8783 ){
            DeRef(_1);
        }
        _8783 = NOVALUE;
        goto L3; // [503] 555

        /** map.e:645			case LEAVE then*/
        case 8:

        /** map.e:646				if old_hash < 0 then*/
        if (_old_hash_15332 >= 0LL)
        goto L3; // [511] 555

        /** map.e:647					slots[index] = { hashval, key, val }*/
        _1 = NewS1(3);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _hashval_15323;
        Ref(_key_15319);
        ((intptr_t*)_2)[2] = _key_15319;
        Ref(_val_15320);
        ((intptr_t*)_2)[3] = _val_15320;
        _8785 = MAKE_SEQ(_1);
        _2 = (object)SEQ_PTR(_slots_15328);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _slots_15328 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _index_15330);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8785;
        if( _1 != _8785 ){
            DeRef(_1);
        }
        _8785 = NOVALUE;
        goto L3; // [528] 555

        /** map.e:649			case else*/
        default:

        /** map.e:650				error:crash("Unknown operation given to map.e:put()")*/

        /** error.e:51		msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_535_15417);
        _msg_inlined_crash_at_535_15417 = EPrintf(-9999999, _8786, _5);

        /** error.e:52		machine_proc(M_CRASH, msg)*/
        machine(67LL, _msg_inlined_crash_at_535_15417);

        /** error.e:53	end procedure*/
        goto LC; // [549] 552
LC: 
        DeRefi(_msg_inlined_crash_at_535_15417);
        _msg_inlined_crash_at_535_15417 = NOVALUE;
    ;}L3: 

    /** map.e:654		the_map_seq[MAP_SLOTS] = slots*/
    RefDS(_slots_15328);
    _2 = (object)SEQ_PTR(_the_map_seq_15326);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _the_map_seq_15326 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _slots_15328;
    DeRef(_1);

    /** map.e:655		eumem:ram_space[the_map_p] = the_map_seq*/
    RefDS(_the_map_seq_15326);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15318))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15318)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _the_map_p_15318);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _the_map_seq_15326;
    DeRef(_1);

    /** map.e:656	end procedure*/
    DeRef(_the_map_p_15318);
    DeRef(_key_15319);
    DeRef(_val_15320);
    DeRefDS(_the_map_seq_15326);
    DeRefDS(_slots_15328);
    return;
    ;
}


void _34nested_put(object _the_map_p_15420, object _the_keys_p_15421, object _the_value_p_15422, object _operation_p_15423, object _deprecated_trigger_p_15424)
{
    object _temp_map__15425 = NOVALUE;
    object _8797 = NOVALUE;
    object _8796 = NOVALUE;
    object _8795 = NOVALUE;
    object _8794 = NOVALUE;
    object _8793 = NOVALUE;
    object _8791 = NOVALUE;
    object _8790 = NOVALUE;
    object _8789 = NOVALUE;
    object _8787 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:701		if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_15421)){
            _8787 = SEQ_PTR(_the_keys_p_15421)->length;
    }
    else {
        _8787 = 1;
    }
    if (_8787 != 1LL)
    goto L1; // [10] 30

    /** map.e:702			put( the_map_p, the_keys_p[1], the_value_p, operation_p )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15421);
    _8789 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_15420);
    Ref(_8789);
    Ref(_the_value_p_15422);
    _34put(_the_map_p_15420, _8789, _the_value_p_15422, _operation_p_15423, 0LL);
    _8789 = NOVALUE;
    goto L2; // [27] 84
L1: 

    /** map.e:704			temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15421);
    _8790 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_15420);
    Ref(_8790);
    _8791 = _34get(_the_map_p_15420, _8790, 0LL);
    _8790 = NOVALUE;
    _0 = _temp_map__15425;
    _temp_map__15425 = _34new_extra(_8791, 8LL);
    DeRef(_0);
    _8791 = NOVALUE;

    /** map.e:705			nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p )*/
    if (IS_SEQUENCE(_the_keys_p_15421)){
            _8793 = SEQ_PTR(_the_keys_p_15421)->length;
    }
    else {
        _8793 = 1;
    }
    rhs_slice_target = (object_ptr)&_8794;
    RHS_Slice(_the_keys_p_15421, 2LL, _8793);
    Ref(_the_value_p_15422);
    DeRef(_8795);
    _8795 = _the_value_p_15422;
    DeRef(_8796);
    _8796 = _operation_p_15423;
    Ref(_temp_map__15425);
    _34nested_put(_temp_map__15425, _8794, _8795, _8796, 0LL);
    _8794 = NOVALUE;
    _8795 = NOVALUE;
    _8796 = NOVALUE;

    /** map.e:706			put( the_map_p, the_keys_p[1], temp_map_, PUT )*/
    _2 = (object)SEQ_PTR(_the_keys_p_15421);
    _8797 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_the_map_p_15420);
    Ref(_8797);
    Ref(_temp_map__15425);
    _34put(_the_map_p_15420, _8797, _temp_map__15425, 1LL, 0LL);
    _8797 = NOVALUE;
L2: 

    /** map.e:708	end procedure*/
    DeRef(_the_map_p_15420);
    DeRefDS(_the_keys_p_15421);
    DeRef(_the_value_p_15422);
    DeRef(_temp_map__15425);
    return;
    ;
}


void _34remove(object _the_map_p_15441, object _key_15442)
{
    object _hashval_15443 = NOVALUE;
    object _hash_inlined_hash_at_2_15445 = NOVALUE;
    object _slots_15446 = NOVALUE;
    object _index_15449 = NOVALUE;
    object _8809 = NOVALUE;
    object _8808 = NOVALUE;
    object _8806 = NOVALUE;
    object _8804 = NOVALUE;
    object _8802 = NOVALUE;
    object _8801 = NOVALUE;
    object _8798 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:733		integer hashval = hash( key )*/

    /** map.e:107		return eu:hash( x, DEFAULT_HASH )*/
    _hashval_15443 = calc_hash(_key_15442, -6LL);

    /** map.e:734		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15441)){
        _8798 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15441)->dbl));
    }
    else{
        _8798 = (object)*(((s1_ptr)_2)->base + _the_map_p_15441);
    }
    DeRef(_slots_15446);
    _2 = (object)SEQ_PTR(_8798);
    _slots_15446 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15446);
    _8798 = NOVALUE;

    /** map.e:736		integer index = lookup( key, hashval, slots )*/
    Ref(_key_15442);
    RefDS(_slots_15446);
    _index_15449 = _34lookup(_key_15442, _hashval_15443, _slots_15446);
    if (!IS_ATOM_INT(_index_15449)) {
        _1 = (object)(DBL_PTR(_index_15449)->dbl);
        DeRefDS(_index_15449);
        _index_15449 = _1;
    }

    /** map.e:737		if hashval = slots[index][SLOT_HASH] then*/
    _2 = (object)SEQ_PTR(_slots_15446);
    _8801 = (object)*(((s1_ptr)_2)->base + _index_15449);
    _2 = (object)SEQ_PTR(_8801);
    _8802 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8801 = NOVALUE;
    if (binary_op_a(NOTEQ, _hashval_15443, _8802)){
        _8802 = NOVALUE;
        goto L1; // [46] 99
    }
    _8802 = NOVALUE;

    /** map.e:738			slots = {}*/
    RefDS(_5);
    DeRefDS(_slots_15446);
    _slots_15446 = _5;

    /** map.e:739			eumem:ram_space[the_map_p][MAP_SLOTS][index] = REMOVED_SLOT*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15441))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15441)->dbl));
    else
    _3 = (object)(_the_map_p_15441 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (object)(2LL + ((s1_ptr)_2)->base);
    _8804 = NOVALUE;
    RefDS(_34REMOVED_SLOT_15057);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _index_15449);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _34REMOVED_SLOT_15057;
    DeRef(_1);
    _8804 = NOVALUE;

    /** map.e:740			eumem:ram_space[the_map_p][MAP_SIZE] -= 1*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15441))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15441)->dbl));
    else
    _3 = (object)(_the_map_p_15441 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _8808 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8806 = NOVALUE;
    if (IS_ATOM_INT(_8808)) {
        _8809 = _8808 - 1LL;
        if ((object)((uintptr_t)_8809 +(uintptr_t) HIGH_BITS) >= 0){
            _8809 = NewDouble((eudouble)_8809);
        }
    }
    else {
        _8809 = binary_op(MINUS, _8808, 1LL);
    }
    _8808 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8809;
    if( _1 != _8809 ){
        DeRef(_1);
    }
    _8809 = NOVALUE;
    _8806 = NOVALUE;
L1: 

    /** map.e:742	end procedure*/
    DeRef(_the_map_p_15441);
    DeRef(_key_15442);
    DeRef(_slots_15446);
    return;
    ;
}


void _34clear(object _the_map_p_15463)
{
    object _8816 = NOVALUE;
    object _8815 = NOVALUE;
    object _8814 = NOVALUE;
    object _8813 = NOVALUE;
    object _8812 = NOVALUE;
    object _8810 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** map.e:771		eumem:ram_space[the_map_p][MAP_SLOTS] = repeat( EMPTY_SLOT, length( eumem:ram_space[the_map_p][MAP_SLOTS] ) )*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15463))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15463)->dbl));
    else
    _3 = (object)(_the_map_p_15463 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15463)){
        _8812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15463)->dbl));
    }
    else{
        _8812 = (object)*(((s1_ptr)_2)->base + _the_map_p_15463);
    }
    _2 = (object)SEQ_PTR(_8812);
    _8813 = (object)*(((s1_ptr)_2)->base + 2LL);
    _8812 = NOVALUE;
    if (IS_SEQUENCE(_8813)){
            _8814 = SEQ_PTR(_8813)->length;
    }
    else {
        _8814 = 1;
    }
    _8813 = NOVALUE;
    _8815 = Repeat(_34EMPTY_SLOT_15055, _8814);
    _8814 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _8815;
    if( _1 != _8815 ){
        DeRef(_1);
    }
    _8815 = NOVALUE;
    _8810 = NOVALUE;

    /** map.e:772		eumem:ram_space[the_map_p][MAP_SIZE]  = 0*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _35ram_space_13045 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_15463))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15463)->dbl));
    else
    _3 = (object)(_the_map_p_15463 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _8816 = NOVALUE;

    /** map.e:773	end procedure*/
    DeRef(_the_map_p_15463);
    _8813 = NOVALUE;
    return;
    ;
}


object _34keys(object _the_map_p_15518, object _sorted_result_15519)
{
    object _slots_15520 = NOVALUE;
    object _keys_15523 = NOVALUE;
    object _kx_15527 = NOVALUE;
    object _8847 = NOVALUE;
    object _8845 = NOVALUE;
    object _8844 = NOVALUE;
    object _8843 = NOVALUE;
    object _8840 = NOVALUE;
    object _8839 = NOVALUE;
    object _8838 = NOVALUE;
    object _8836 = NOVALUE;
    object _8835 = NOVALUE;
    object _8833 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:901		sequence slots = eumem:ram_space[the_map_p][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15518)){
        _8833 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15518)->dbl));
    }
    else{
        _8833 = (object)*(((s1_ptr)_2)->base + _the_map_p_15518);
    }
    DeRef(_slots_15520);
    _2 = (object)SEQ_PTR(_8833);
    _slots_15520 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15520);
    _8833 = NOVALUE;

    /** map.e:902		sequence keys = repeat( 0, eumem:ram_space[the_map_p][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_p_15518)){
        _8835 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_p_15518)->dbl));
    }
    else{
        _8835 = (object)*(((s1_ptr)_2)->base + _the_map_p_15518);
    }
    _2 = (object)SEQ_PTR(_8835);
    _8836 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8835 = NOVALUE;
    DeRef(_keys_15523);
    _keys_15523 = Repeat(0LL, _8836);
    _8836 = NOVALUE;

    /** map.e:903		integer kx = 0*/
    _kx_15527 = 0LL;

    /** map.e:904		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15520)){
            _8838 = SEQ_PTR(_slots_15520)->length;
    }
    else {
        _8838 = 1;
    }
    {
        object _i_15529;
        _i_15529 = 1LL;
L1: 
        if (_i_15529 > _8838){
            goto L2; // [43] 106
        }

        /** map.e:905			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15520);
        _8839 = (object)*(((s1_ptr)_2)->base + _i_15529);
        _2 = (object)SEQ_PTR(_8839);
        _8840 = (object)*(((s1_ptr)_2)->base + 1LL);
        _8839 = NOVALUE;
        if (binary_op_a(LESS, _8840, 0LL)){
            _8840 = NOVALUE;
            goto L3; // [60] 99
        }
        _8840 = NOVALUE;

        /** map.e:906				kx += 1*/
        _kx_15527 = _kx_15527 + 1;

        /** map.e:907				keys[kx] = slots[i][SLOT_KEY]*/
        _2 = (object)SEQ_PTR(_slots_15520);
        _8843 = (object)*(((s1_ptr)_2)->base + _i_15529);
        _2 = (object)SEQ_PTR(_8843);
        _8844 = (object)*(((s1_ptr)_2)->base + 2LL);
        _8843 = NOVALUE;
        Ref(_8844);
        _2 = (object)SEQ_PTR(_keys_15523);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _keys_15523 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _kx_15527);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8844;
        if( _1 != _8844 ){
            DeRef(_1);
        }
        _8844 = NOVALUE;

        /** map.e:908				if kx = length( keys ) then*/
        if (IS_SEQUENCE(_keys_15523)){
                _8845 = SEQ_PTR(_keys_15523)->length;
        }
        else {
            _8845 = 1;
        }
        if (_kx_15527 != _8845)
        goto L4; // [89] 98

        /** map.e:909					exit*/
        goto L2; // [95] 106
L4: 
L3: 

        /** map.e:912		end for*/
        _i_15529 = _i_15529 + 1LL;
        goto L1; // [101] 50
L2: 
        ;
    }

    /** map.e:913		if sorted_result then*/
    if (_sorted_result_15519 == 0)
    {
        goto L5; // [108] 123
    }
    else{
    }

    /** map.e:914			return stdsort:sort( keys )*/
    RefDS(_keys_15523);
    _8847 = _25sort(_keys_15523, 1LL);
    DeRef(_the_map_p_15518);
    DeRef(_slots_15520);
    DeRefDS(_keys_15523);
    return _8847;
L5: 

    /** map.e:916		return keys*/
    DeRef(_the_map_p_15518);
    DeRef(_slots_15520);
    DeRef(_8847);
    _8847 = NOVALUE;
    return _keys_15523;
    ;
}


object _34pairs(object _the_map_15594, object _sorted_result_15595)
{
    object _slots_15596 = NOVALUE;
    object _pairs_15599 = NOVALUE;
    object _px_15603 = NOVALUE;
    object _8897 = NOVALUE;
    object _8895 = NOVALUE;
    object _8894 = NOVALUE;
    object _8893 = NOVALUE;
    object _8892 = NOVALUE;
    object _8891 = NOVALUE;
    object _8890 = NOVALUE;
    object _8887 = NOVALUE;
    object _8886 = NOVALUE;
    object _8885 = NOVALUE;
    object _8883 = NOVALUE;
    object _8882 = NOVALUE;
    object _8880 = NOVALUE;
    object _0, _1, _2;
    

    /** map.e:1045		sequence slots = eumem:ram_space[the_map][MAP_SLOTS]*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_15594)){
        _8880 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15594)->dbl));
    }
    else{
        _8880 = (object)*(((s1_ptr)_2)->base + _the_map_15594);
    }
    DeRef(_slots_15596);
    _2 = (object)SEQ_PTR(_8880);
    _slots_15596 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_slots_15596);
    _8880 = NOVALUE;

    /** map.e:1046		sequence pairs = repeat( 0, eumem:ram_space[the_map][MAP_SIZE] )*/
    _2 = (object)SEQ_PTR(_35ram_space_13045);
    if (!IS_ATOM_INT(_the_map_15594)){
        _8882 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_the_map_15594)->dbl));
    }
    else{
        _8882 = (object)*(((s1_ptr)_2)->base + _the_map_15594);
    }
    _2 = (object)SEQ_PTR(_8882);
    _8883 = (object)*(((s1_ptr)_2)->base + 1LL);
    _8882 = NOVALUE;
    DeRef(_pairs_15599);
    _pairs_15599 = Repeat(0LL, _8883);
    _8883 = NOVALUE;

    /** map.e:1047		integer px = 0*/
    _px_15603 = 0LL;

    /** map.e:1048		for i = 1 to length( slots ) do*/
    if (IS_SEQUENCE(_slots_15596)){
            _8885 = SEQ_PTR(_slots_15596)->length;
    }
    else {
        _8885 = 1;
    }
    {
        object _i_15605;
        _i_15605 = 1LL;
L1: 
        if (_i_15605 > _8885){
            goto L2; // [43] 118
        }

        /** map.e:1049			if slots[i][SLOT_HASH] >= 0 then*/
        _2 = (object)SEQ_PTR(_slots_15596);
        _8886 = (object)*(((s1_ptr)_2)->base + _i_15605);
        _2 = (object)SEQ_PTR(_8886);
        _8887 = (object)*(((s1_ptr)_2)->base + 1LL);
        _8886 = NOVALUE;
        if (binary_op_a(LESS, _8887, 0LL)){
            _8887 = NOVALUE;
            goto L3; // [60] 111
        }
        _8887 = NOVALUE;

        /** map.e:1050				px += 1*/
        _px_15603 = _px_15603 + 1;

        /** map.e:1051				pairs[px] = { slots[i][SLOT_KEY], slots[i][SLOT_VALUE] }*/
        _2 = (object)SEQ_PTR(_slots_15596);
        _8890 = (object)*(((s1_ptr)_2)->base + _i_15605);
        _2 = (object)SEQ_PTR(_8890);
        _8891 = (object)*(((s1_ptr)_2)->base + 2LL);
        _8890 = NOVALUE;
        _2 = (object)SEQ_PTR(_slots_15596);
        _8892 = (object)*(((s1_ptr)_2)->base + _i_15605);
        _2 = (object)SEQ_PTR(_8892);
        _8893 = (object)*(((s1_ptr)_2)->base + 3LL);
        _8892 = NOVALUE;
        Ref(_8893);
        Ref(_8891);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _8891;
        ((intptr_t *)_2)[2] = _8893;
        _8894 = MAKE_SEQ(_1);
        _8893 = NOVALUE;
        _8891 = NOVALUE;
        _2 = (object)SEQ_PTR(_pairs_15599);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _pairs_15599 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _px_15603);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _8894;
        if( _1 != _8894 ){
            DeRef(_1);
        }
        _8894 = NOVALUE;

        /** map.e:1052				if px = length( pairs ) then*/
        if (IS_SEQUENCE(_pairs_15599)){
                _8895 = SEQ_PTR(_pairs_15599)->length;
        }
        else {
            _8895 = 1;
        }
        if (_px_15603 != _8895)
        goto L4; // [101] 110

        /** map.e:1053					exit*/
        goto L2; // [107] 118
L4: 
L3: 

        /** map.e:1056		end for*/
        _i_15605 = _i_15605 + 1LL;
        goto L1; // [113] 50
L2: 
        ;
    }

    /** map.e:1057		if sorted_result then*/
    if (_sorted_result_15595 == 0)
    {
        goto L5; // [120] 135
    }
    else{
    }

    /** map.e:1058			return stdsort:sort( pairs )*/
    RefDS(_pairs_15599);
    _8897 = _25sort(_pairs_15599, 1LL);
    DeRef(_the_map_15594);
    DeRef(_slots_15596);
    DeRefDS(_pairs_15599);
    return _8897;
L5: 

    /** map.e:1060		return pairs*/
    DeRef(_the_map_15594);
    DeRef(_slots_15596);
    DeRef(_8897);
    _8897 = NOVALUE;
    return _pairs_15599;
    ;
}



// 0xB18B40E0
