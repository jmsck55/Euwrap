// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _41fatal(object _errcode_16067, object _msg_16068, object _routine_name_16069, object _parms_16070)
{
    object _9138 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:231		vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _errcode_16067;
    RefDS(_msg_16068);
    ((intptr_t*)_2)[2] = _msg_16068;
    RefDS(_routine_name_16069);
    ((intptr_t*)_2)[3] = _routine_name_16069;
    RefDS(_parms_16070);
    ((intptr_t*)_2)[4] = _parms_16070;
    _9138 = MAKE_SEQ(_1);
    RefDS(_9138);
    Append(&_41vLastErrors_16064, _41vLastErrors_16064, _9138);
    DeRefDS(_9138);
    _9138 = NOVALUE;

    /** eds.e:232		if db_fatal_id >= 0 then*/

    /** eds.e:235	end procedure*/
    DeRefDSi(_msg_16068);
    DeRefDSi(_routine_name_16069);
    DeRefDS(_parms_16070);
    return;
    ;
}


object _41get4()
{
    object _9154 = NOVALUE;
    object _9153 = NOVALUE;
    object _9152 = NOVALUE;
    object _9151 = NOVALUE;
    object _9150 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:250		poke(mem0, getc(current_db))*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9150 = getKBchar();
        }
        else{
            _9150 = getc(last_r_file_ptr);
        }
    }
    else{
        _9150 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem0_16082)){
        poke_addr = (uint8_t *)_41mem0_16082;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke_addr = (uint8_t)_9150;
    _9150 = NOVALUE;

    /** eds.e:251		poke(mem1, getc(current_db))*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9151 = getKBchar();
        }
        else{
            _9151 = getc(last_r_file_ptr);
        }
    }
    else{
        _9151 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem1_16083)){
        poke_addr = (uint8_t *)_41mem1_16083;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem1_16083)->dbl);
    }
    *poke_addr = (uint8_t)_9151;
    _9151 = NOVALUE;

    /** eds.e:252		poke(mem2, getc(current_db))*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9152 = getKBchar();
        }
        else{
            _9152 = getc(last_r_file_ptr);
        }
    }
    else{
        _9152 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem2_16084)){
        poke_addr = (uint8_t *)_41mem2_16084;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem2_16084)->dbl);
    }
    *poke_addr = (uint8_t)_9152;
    _9152 = NOVALUE;

    /** eds.e:253		poke(mem3, getc(current_db))*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _9153 = getKBchar();
        }
        else{
            _9153 = getc(last_r_file_ptr);
        }
    }
    else{
        _9153 = getc(last_r_file_ptr);
    }
    if (IS_ATOM_INT(_41mem3_16085)){
        poke_addr = (uint8_t *)_41mem3_16085;
    }
    else {
        poke_addr = (uint8_t *)(uintptr_t)(DBL_PTR(_41mem3_16085)->dbl);
    }
    *poke_addr = (uint8_t)_9153;
    _9153 = NOVALUE;

    /** eds.e:254		return peek4u(mem0)*/
    if (IS_ATOM_INT(_41mem0_16082)) {
        _9154 = (object)*(uint32_t *)_41mem0_16082;
        if ((uintptr_t)_9154 > (uintptr_t)MAXINT){
            _9154 = NewDouble((eudouble)(uintptr_t)_9154);
        }
    }
    else {
        _9154 = (object)*(uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        if ((uintptr_t)_9154 > (uintptr_t)MAXINT){
            _9154 = NewDouble((eudouble)(uintptr_t)_9154);
        }
    }
    return _9154;
    ;
}


object _41get_string()
{
    object _where_inlined_where_at_31_16110 = NOVALUE;
    object _s_16099 = NOVALUE;
    object _c_16100 = NOVALUE;
    object _i_16101 = NOVALUE;
    object _9167 = NOVALUE;
    object _9164 = NOVALUE;
    object _9162 = NOVALUE;
    object _9160 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:263		s = repeat(0, 256)*/
    DeRefi(_s_16099);
    _s_16099 = Repeat(0LL, 256LL);

    /** eds.e:264		i = 0*/
    _i_16101 = 0LL;

    /** eds.e:265		while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_16100 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** eds.e:266			if c = -1 then*/
    if (_c_16100 != -1LL)
    goto L4; // [24] 54

    /** eds.e:267				fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_16110);
    _where_inlined_where_at_31_16110 = machine(20LL, _41current_db_16040);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_16110);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_31_16110;
    _9160 = MAKE_SEQ(_1);
    RefDS(_9158);
    RefDS(_9159);
    _41fatal(900LL, _9158, _9159, _9160);
    _9160 = NOVALUE;

    /** eds.e:268				exit*/
    goto L3; // [51] 101
L4: 

    /** eds.e:270			i += 1*/
    _i_16101 = _i_16101 + 1;

    /** eds.e:271			if i > length(s) then*/
    if (IS_SEQUENCE(_s_16099)){
            _9162 = SEQ_PTR(_s_16099)->length;
    }
    else {
        _9162 = 1;
    }
    if (_i_16101 <= _9162)
    goto L5; // [65] 80

    /** eds.e:272				s &= repeat(0, 256)*/
    _9164 = Repeat(0LL, 256LL);
    Concat((object_ptr)&_s_16099, _s_16099, _9164);
    DeRefDS(_9164);
    _9164 = NOVALUE;
L5: 

    /** eds.e:274			s[i] = c*/
    _2 = (object)SEQ_PTR(_s_16099);
    _2 = (object)(((s1_ptr)_2)->base + _i_16101);
    *(intptr_t *)_2 = _c_16100;

    /** eds.e:275		  entry*/
L1: 

    /** eds.e:276			c = getc(current_db)*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16100 = getKBchar();
        }
        else{
            _c_16100 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16100 = getc(last_r_file_ptr);
    }

    /** eds.e:277		end while*/
    goto L2; // [98] 17
L3: 

    /** eds.e:278		return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9167;
    RHS_Slice(_s_16099, 1LL, _i_16101);
    DeRefDSi(_s_16099);
    return _9167;
    ;
}


object _41equal_string(object _target_16122)
{
    object _c_16123 = NOVALUE;
    object _i_16124 = NOVALUE;
    object _where_inlined_where_at_27_16130 = NOVALUE;
    object _9178 = NOVALUE;
    object _9177 = NOVALUE;
    object _9174 = NOVALUE;
    object _9172 = NOVALUE;
    object _9170 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:286		i = 0*/
    _i_16124 = 0LL;

    /** eds.e:287		while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_16123 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** eds.e:288			if c = -1 then*/
    if (_c_16123 != -1LL)
    goto L4; // [20] 52

    /** eds.e:289				fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_16130);
    _where_inlined_where_at_27_16130 = machine(20LL, _41current_db_16040);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_16130);
    ((intptr_t*)_2)[1] = _where_inlined_where_at_27_16130;
    _9170 = MAKE_SEQ(_1);
    RefDS(_9158);
    RefDS(_9169);
    _41fatal(900LL, _9158, _9169, _9170);
    _9170 = NOVALUE;

    /** eds.e:290				return DB_FATAL_FAIL*/
    DeRefDS(_target_16122);
    return -404LL;
L4: 

    /** eds.e:292			i += 1*/
    _i_16124 = _i_16124 + 1;

    /** eds.e:293			if i > length(target) then*/
    if (IS_SEQUENCE(_target_16122)){
            _9172 = SEQ_PTR(_target_16122)->length;
    }
    else {
        _9172 = 1;
    }
    if (_i_16124 <= _9172)
    goto L5; // [63] 74

    /** eds.e:294				return 0*/
    DeRefDS(_target_16122);
    return 0LL;
L5: 

    /** eds.e:296			if target[i] != c then*/
    _2 = (object)SEQ_PTR(_target_16122);
    _9174 = (object)*(((s1_ptr)_2)->base + _i_16124);
    if (binary_op_a(EQUALS, _9174, _c_16123)){
        _9174 = NOVALUE;
        goto L6; // [80] 91
    }
    _9174 = NOVALUE;

    /** eds.e:297				return 0*/
    DeRefDS(_target_16122);
    return 0LL;
L6: 

    /** eds.e:299		  entry*/
L1: 

    /** eds.e:300			c = getc(current_db)*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16123 = getKBchar();
        }
        else{
            _c_16123 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16123 = getc(last_r_file_ptr);
    }

    /** eds.e:301		end while*/
    goto L2; // [103] 13
L3: 

    /** eds.e:302		return (i = length(target))*/
    if (IS_SEQUENCE(_target_16122)){
            _9177 = SEQ_PTR(_target_16122)->length;
    }
    else {
        _9177 = 1;
    }
    _9178 = (_i_16124 == _9177);
    _9177 = NOVALUE;
    DeRefDS(_target_16122);
    return _9178;
    ;
}


object _41decompress(object _c_16170)
{
    object _s_16171 = NOVALUE;
    object _len_16172 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_176_16208 = NOVALUE;
    object _ieee32_inlined_float32_to_atom_at_173_16207 = NOVALUE;
    object _float64_to_atom_inlined_float64_to_atom_at_251_16221 = NOVALUE;
    object _ieee64_inlined_float64_to_atom_at_248_16220 = NOVALUE;
    object _9236 = NOVALUE;
    object _9235 = NOVALUE;
    object _9234 = NOVALUE;
    object _9231 = NOVALUE;
    object _9226 = NOVALUE;
    object _9225 = NOVALUE;
    object _9224 = NOVALUE;
    object _9223 = NOVALUE;
    object _9222 = NOVALUE;
    object _9221 = NOVALUE;
    object _9220 = NOVALUE;
    object _9219 = NOVALUE;
    object _9218 = NOVALUE;
    object _9217 = NOVALUE;
    object _9216 = NOVALUE;
    object _9215 = NOVALUE;
    object _9214 = NOVALUE;
    object _9213 = NOVALUE;
    object _9212 = NOVALUE;
    object _9211 = NOVALUE;
    object _9210 = NOVALUE;
    object _9209 = NOVALUE;
    object _9208 = NOVALUE;
    object _9207 = NOVALUE;
    object _9205 = NOVALUE;
    object _9204 = NOVALUE;
    object _9203 = NOVALUE;
    object _9202 = NOVALUE;
    object _9201 = NOVALUE;
    object _9200 = NOVALUE;
    object _9199 = NOVALUE;
    object _9198 = NOVALUE;
    object _9197 = NOVALUE;
    object _9194 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:332		if c = 0 then*/
    if (_c_16170 != 0LL)
    goto L1; // [5] 34

    /** eds.e:333			c = getc(current_db)*/
    if (_41current_db_16040 != last_r_file_no) {
        last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
        last_r_file_no = _41current_db_16040;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _c_16170 = getKBchar();
        }
        else{
            _c_16170 = getc(last_r_file_ptr);
        }
    }
    else{
        _c_16170 = getc(last_r_file_ptr);
    }

    /** eds.e:334			if c < I2B then*/
    if (_c_16170 >= 249LL)
    goto L2; // [18] 33

    /** eds.e:335				return c + MIN1B*/
    _9194 = _c_16170 + -9LL;
    DeRef(_s_16171);
    return _9194;
L2: 
L1: 

    /** eds.e:339		switch c with fallthru do*/
    _0 = _c_16170;
    switch ( _0 ){ 

        /** eds.e:340			case I2B then*/
        case 249:

        /** eds.e:341				return getc(current_db) +*/
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9197 = getKBchar();
            }
            else{
                _9197 = getc(last_r_file_ptr);
            }
        }
        else{
            _9197 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9198 = getKBchar();
            }
            else{
                _9198 = getc(last_r_file_ptr);
            }
        }
        else{
            _9198 = getc(last_r_file_ptr);
        }
        _9199 = 256LL * _9198;
        _9198 = NOVALUE;
        _9200 = _9197 + _9199;
        _9197 = NOVALUE;
        _9199 = NOVALUE;
        _9201 = _9200 + _41MIN2B_16153;
        if ((object)((uintptr_t)_9201 + (uintptr_t)HIGH_BITS) >= 0){
            _9201 = NewDouble((eudouble)_9201);
        }
        _9200 = NOVALUE;
        DeRef(_s_16171);
        DeRef(_9194);
        _9194 = NOVALUE;
        return _9201;

        /** eds.e:345			case I3B then*/
        case 250:

        /** eds.e:346				return getc(current_db) +*/
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9202 = getKBchar();
            }
            else{
                _9202 = getc(last_r_file_ptr);
            }
        }
        else{
            _9202 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9203 = getKBchar();
            }
            else{
                _9203 = getc(last_r_file_ptr);
            }
        }
        else{
            _9203 = getc(last_r_file_ptr);
        }
        _9204 = 256LL * _9203;
        _9203 = NOVALUE;
        _9205 = _9202 + _9204;
        _9202 = NOVALUE;
        _9204 = NOVALUE;
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9207 = getKBchar();
            }
            else{
                _9207 = getc(last_r_file_ptr);
            }
        }
        else{
            _9207 = getc(last_r_file_ptr);
        }
        _9208 = 65536LL * _9207;
        _9207 = NOVALUE;
        _9209 = _9205 + _9208;
        _9205 = NOVALUE;
        _9208 = NOVALUE;
        _9210 = _9209 + _41MIN3B_16159;
        if ((object)((uintptr_t)_9210 + (uintptr_t)HIGH_BITS) >= 0){
            _9210 = NewDouble((eudouble)_9210);
        }
        _9209 = NOVALUE;
        DeRef(_s_16171);
        DeRef(_9194);
        _9194 = NOVALUE;
        DeRef(_9201);
        _9201 = NOVALUE;
        return _9210;

        /** eds.e:351			case I4B then*/
        case 251:

        /** eds.e:352				return get4() + MIN4B*/
        _9211 = _41get4();
        if (IS_ATOM_INT(_9211)) {
            _9212 = _9211 + _41MIN4B_16165;
            if ((object)((uintptr_t)_9212 + (uintptr_t)HIGH_BITS) >= 0){
                _9212 = NewDouble((eudouble)_9212);
            }
        }
        else {
            _9212 = binary_op(PLUS, _9211, _41MIN4B_16165);
        }
        DeRef(_9211);
        _9211 = NOVALUE;
        DeRef(_s_16171);
        DeRef(_9210);
        _9210 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        DeRef(_9201);
        _9201 = NOVALUE;
        return _9212;

        /** eds.e:354			case F4B then*/
        case 252:

        /** eds.e:355				return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9213 = getKBchar();
            }
            else{
                _9213 = getc(last_r_file_ptr);
            }
        }
        else{
            _9213 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9214 = getKBchar();
            }
            else{
                _9214 = getc(last_r_file_ptr);
            }
        }
        else{
            _9214 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9215 = getKBchar();
            }
            else{
                _9215 = getc(last_r_file_ptr);
            }
        }
        else{
            _9215 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9216 = getKBchar();
            }
            else{
                _9216 = getc(last_r_file_ptr);
            }
        }
        else{
            _9216 = getc(last_r_file_ptr);
        }
        _1 = NewS1(4);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9213;
        ((intptr_t*)_2)[2] = _9214;
        ((intptr_t*)_2)[3] = _9215;
        ((intptr_t*)_2)[4] = _9216;
        _9217 = MAKE_SEQ(_1);
        _9216 = NOVALUE;
        _9215 = NOVALUE;
        _9214 = NOVALUE;
        _9213 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16207);
        _ieee32_inlined_float32_to_atom_at_173_16207 = _9217;
        _9217 = NOVALUE;

        /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_16208);
        _float32_to_atom_inlined_float32_to_atom_at_176_16208 = machine(49LL, _ieee32_inlined_float32_to_atom_at_173_16207);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_16207);
        _ieee32_inlined_float32_to_atom_at_173_16207 = NOVALUE;
        DeRef(_s_16171);
        DeRef(_9212);
        _9212 = NOVALUE;
        DeRef(_9210);
        _9210 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        DeRef(_9201);
        _9201 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_16208;

        /** eds.e:358			case F8B then*/
        case 253:

        /** eds.e:359				return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9218 = getKBchar();
            }
            else{
                _9218 = getc(last_r_file_ptr);
            }
        }
        else{
            _9218 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9219 = getKBchar();
            }
            else{
                _9219 = getc(last_r_file_ptr);
            }
        }
        else{
            _9219 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9220 = getKBchar();
            }
            else{
                _9220 = getc(last_r_file_ptr);
            }
        }
        else{
            _9220 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9221 = getKBchar();
            }
            else{
                _9221 = getc(last_r_file_ptr);
            }
        }
        else{
            _9221 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9222 = getKBchar();
            }
            else{
                _9222 = getc(last_r_file_ptr);
            }
        }
        else{
            _9222 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9223 = getKBchar();
            }
            else{
                _9223 = getc(last_r_file_ptr);
            }
        }
        else{
            _9223 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9224 = getKBchar();
            }
            else{
                _9224 = getc(last_r_file_ptr);
            }
        }
        else{
            _9224 = getc(last_r_file_ptr);
        }
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _9225 = getKBchar();
            }
            else{
                _9225 = getc(last_r_file_ptr);
            }
        }
        else{
            _9225 = getc(last_r_file_ptr);
        }
        _1 = NewS1(8);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t*)_2)[1] = _9218;
        ((intptr_t*)_2)[2] = _9219;
        ((intptr_t*)_2)[3] = _9220;
        ((intptr_t*)_2)[4] = _9221;
        ((intptr_t*)_2)[5] = _9222;
        ((intptr_t*)_2)[6] = _9223;
        ((intptr_t*)_2)[7] = _9224;
        ((intptr_t*)_2)[8] = _9225;
        _9226 = MAKE_SEQ(_1);
        _9225 = NOVALUE;
        _9224 = NOVALUE;
        _9223 = NOVALUE;
        _9222 = NOVALUE;
        _9221 = NOVALUE;
        _9220 = NOVALUE;
        _9219 = NOVALUE;
        _9218 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16220);
        _ieee64_inlined_float64_to_atom_at_248_16220 = _9226;
        _9226 = NOVALUE;

        /** convert.e:343		return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_16221);
        _float64_to_atom_inlined_float64_to_atom_at_251_16221 = machine(47LL, _ieee64_inlined_float64_to_atom_at_248_16220);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_16220);
        _ieee64_inlined_float64_to_atom_at_248_16220 = NOVALUE;
        DeRef(_s_16171);
        DeRef(_9212);
        _9212 = NOVALUE;
        DeRef(_9210);
        _9210 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        DeRef(_9201);
        _9201 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_16221;

        /** eds.e:364			case else*/
        default:

        /** eds.e:366				if c = S1B then*/
        if (_c_16170 != 254LL)
        goto L3; // [273] 287

        /** eds.e:367					len = getc(current_db)*/
        if (_41current_db_16040 != last_r_file_no) {
            last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
            last_r_file_no = _41current_db_16040;
        }
        if (last_r_file_ptr == xstdin) {
            show_console();
            if (in_from_keyb) {
                _len_16172 = getKBchar();
            }
            else{
                _len_16172 = getc(last_r_file_ptr);
            }
        }
        else{
            _len_16172 = getc(last_r_file_ptr);
        }
        goto L4; // [284] 295
L3: 

        /** eds.e:369					len = get4()*/
        _len_16172 = _41get4();
        if (!IS_ATOM_INT(_len_16172)) {
            _1 = (object)(DBL_PTR(_len_16172)->dbl);
            DeRefDS(_len_16172);
            _len_16172 = _1;
        }
L4: 

        /** eds.e:371				s = repeat(0, len)*/
        DeRef(_s_16171);
        _s_16171 = Repeat(0LL, _len_16172);

        /** eds.e:372				for i = 1 to len do*/
        _9231 = _len_16172;
        {
            object _i_16230;
            _i_16230 = 1LL;
L5: 
            if (_i_16230 > _9231){
                goto L6; // [308] 362
            }

            /** eds.e:374					c = getc(current_db)*/
            if (_41current_db_16040 != last_r_file_no) {
                last_r_file_ptr = which_file(_41current_db_16040, EF_READ);
                last_r_file_no = _41current_db_16040;
            }
            if (last_r_file_ptr == xstdin) {
                show_console();
                if (in_from_keyb) {
                    _c_16170 = getKBchar();
                }
                else{
                    _c_16170 = getc(last_r_file_ptr);
                }
            }
            else{
                _c_16170 = getc(last_r_file_ptr);
            }

            /** eds.e:375					if c < I2B then*/
            if (_c_16170 >= 249LL)
            goto L7; // [324] 341

            /** eds.e:376						s[i] = c + MIN1B*/
            _9234 = _c_16170 + -9LL;
            _2 = (object)SEQ_PTR(_s_16171);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_16171 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_16230);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9234;
            if( _1 != _9234 ){
                DeRef(_1);
            }
            _9234 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** eds.e:378						s[i] = decompress(c)*/
            DeRef(_9235);
            _9235 = _c_16170;
            _9236 = _41decompress(_9235);
            _9235 = NOVALUE;
            _2 = (object)SEQ_PTR(_s_16171);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _s_16171 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _i_16230);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9236;
            if( _1 != _9236 ){
                DeRef(_1);
            }
            _9236 = NOVALUE;
L8: 

            /** eds.e:380				end for*/
            _i_16230 = _i_16230 + 1LL;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** eds.e:381				return s*/
        DeRef(_9212);
        _9212 = NOVALUE;
        DeRef(_9210);
        _9210 = NOVALUE;
        DeRef(_9194);
        _9194 = NOVALUE;
        DeRef(_9201);
        _9201 = NOVALUE;
        return _s_16171;
    ;}    ;
}


object _41compress(object _x_16241)
{
    object _x4_16242 = NOVALUE;
    object _s_16243 = NOVALUE;
    object _atom_to_float32_inlined_atom_to_float32_at_193_16277 = NOVALUE;
    object _float32_to_atom_inlined_float32_to_atom_at_204_16280 = NOVALUE;
    object _atom_to_float64_inlined_atom_to_float64_at_230_16285 = NOVALUE;
    object _9275 = NOVALUE;
    object _9274 = NOVALUE;
    object _9273 = NOVALUE;
    object _9271 = NOVALUE;
    object _9270 = NOVALUE;
    object _9268 = NOVALUE;
    object _9266 = NOVALUE;
    object _9265 = NOVALUE;
    object _9264 = NOVALUE;
    object _9262 = NOVALUE;
    object _9261 = NOVALUE;
    object _9260 = NOVALUE;
    object _9259 = NOVALUE;
    object _9258 = NOVALUE;
    object _9257 = NOVALUE;
    object _9256 = NOVALUE;
    object _9255 = NOVALUE;
    object _9254 = NOVALUE;
    object _9252 = NOVALUE;
    object _9251 = NOVALUE;
    object _9250 = NOVALUE;
    object _9249 = NOVALUE;
    object _9248 = NOVALUE;
    object _9247 = NOVALUE;
    object _9245 = NOVALUE;
    object _9244 = NOVALUE;
    object _9243 = NOVALUE;
    object _9242 = NOVALUE;
    object _9241 = NOVALUE;
    object _9240 = NOVALUE;
    object _9239 = NOVALUE;
    object _9238 = NOVALUE;
    object _9237 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:390		if integer(x) then*/
    if (IS_ATOM_INT(_x_16241))
    _9237 = 1;
    else if (IS_ATOM_DBL(_x_16241))
    _9237 = IS_ATOM_INT(DoubleToInt(_x_16241));
    else
    _9237 = 0;
    if (_9237 == 0)
    {
        _9237 = NOVALUE;
        goto L1; // [6] 184
    }
    else{
        _9237 = NOVALUE;
    }

    /** eds.e:391			if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_16241)) {
        _9238 = (_x_16241 >= -9LL);
    }
    else {
        _9238 = binary_op(GREATEREQ, _x_16241, -9LL);
    }
    if (IS_ATOM_INT(_9238)) {
        if (_9238 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9238)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_16241)) {
        _9240 = (_x_16241 <= 239LL);
    }
    else {
        _9240 = binary_op(LESSEQ, _x_16241, 239LL);
    }
    if (_9240 == 0) {
        DeRef(_9240);
        _9240 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9240) && DBL_PTR(_9240)->dbl == 0.0){
            DeRef(_9240);
            _9240 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9240);
        _9240 = NOVALUE;
    }
    DeRef(_9240);
    _9240 = NOVALUE;

    /** eds.e:392				return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_16241)) {
        _9241 = _x_16241 - -9LL;
        if ((object)((uintptr_t)_9241 +(uintptr_t) HIGH_BITS) >= 0){
            _9241 = NewDouble((eudouble)_9241);
        }
    }
    else {
        _9241 = binary_op(MINUS, _x_16241, -9LL);
    }
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _9241;
    _9242 = MAKE_SEQ(_1);
    _9241 = NOVALUE;
    DeRef(_x_16241);
    DeRefi(_x4_16242);
    DeRef(_s_16243);
    DeRef(_9238);
    _9238 = NOVALUE;
    return _9242;
    goto L3; // [41] 330
L2: 

    /** eds.e:394			elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_16241)) {
        _9243 = (_x_16241 >= _41MIN2B_16153);
    }
    else {
        _9243 = binary_op(GREATEREQ, _x_16241, _41MIN2B_16153);
    }
    if (IS_ATOM_INT(_9243)) {
        if (_9243 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9243)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_16241)) {
        _9245 = (_x_16241 <= 32767LL);
    }
    else {
        _9245 = binary_op(LESSEQ, _x_16241, 32767LL);
    }
    if (_9245 == 0) {
        DeRef(_9245);
        _9245 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9245) && DBL_PTR(_9245)->dbl == 0.0){
            DeRef(_9245);
            _9245 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9245);
        _9245 = NOVALUE;
    }
    DeRef(_9245);
    _9245 = NOVALUE;

    /** eds.e:395				x -= MIN2B*/
    _0 = _x_16241;
    if (IS_ATOM_INT(_x_16241)) {
        _x_16241 = _x_16241 - _41MIN2B_16153;
        if ((object)((uintptr_t)_x_16241 +(uintptr_t) HIGH_BITS) >= 0){
            _x_16241 = NewDouble((eudouble)_x_16241);
        }
    }
    else {
        _x_16241 = binary_op(MINUS, _x_16241, _41MIN2B_16153);
    }
    DeRef(_0);

    /** eds.e:396				return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_16241)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_16241 & (uintptr_t)255LL;
             _9247 = MAKE_UINT(tu);
        }
    }
    else {
        _9247 = binary_op(AND_BITS, _x_16241, 255LL);
    }
    if (IS_ATOM_INT(_x_16241)) {
        if (256LL > 0 && _x_16241 >= 0) {
            _9248 = _x_16241 / 256LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_16241 / (eudouble)256LL);
            if (_x_16241 != MININT)
            _9248 = (object)temp_dbl;
            else
            _9248 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16241, 256LL);
        _9248 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 249LL;
    ((intptr_t*)_2)[2] = _9247;
    ((intptr_t*)_2)[3] = _9248;
    _9249 = MAKE_SEQ(_1);
    _9248 = NOVALUE;
    _9247 = NOVALUE;
    DeRef(_x_16241);
    DeRefi(_x4_16242);
    DeRef(_s_16243);
    DeRef(_9238);
    _9238 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    DeRef(_9243);
    _9243 = NOVALUE;
    return _9249;
    goto L3; // [94] 330
L4: 

    /** eds.e:398			elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_16241)) {
        _9250 = (_x_16241 >= _41MIN3B_16159);
    }
    else {
        _9250 = binary_op(GREATEREQ, _x_16241, _41MIN3B_16159);
    }
    if (IS_ATOM_INT(_9250)) {
        if (_9250 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9250)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_16241)) {
        _9252 = (_x_16241 <= 8388607LL);
    }
    else {
        _9252 = binary_op(LESSEQ, _x_16241, 8388607LL);
    }
    if (_9252 == 0) {
        DeRef(_9252);
        _9252 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9252) && DBL_PTR(_9252)->dbl == 0.0){
            DeRef(_9252);
            _9252 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9252);
        _9252 = NOVALUE;
    }
    DeRef(_9252);
    _9252 = NOVALUE;

    /** eds.e:399				x -= MIN3B*/
    _0 = _x_16241;
    if (IS_ATOM_INT(_x_16241)) {
        _x_16241 = _x_16241 - _41MIN3B_16159;
        if ((object)((uintptr_t)_x_16241 +(uintptr_t) HIGH_BITS) >= 0){
            _x_16241 = NewDouble((eudouble)_x_16241);
        }
    }
    else {
        _x_16241 = binary_op(MINUS, _x_16241, _41MIN3B_16159);
    }
    DeRef(_0);

    /** eds.e:400				return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_16241)) {
        {uintptr_t tu;
             tu = (uintptr_t)_x_16241 & (uintptr_t)255LL;
             _9254 = MAKE_UINT(tu);
        }
    }
    else {
        _9254 = binary_op(AND_BITS, _x_16241, 255LL);
    }
    if (IS_ATOM_INT(_x_16241)) {
        if (256LL > 0 && _x_16241 >= 0) {
            _9255 = _x_16241 / 256LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_16241 / (eudouble)256LL);
            if (_x_16241 != MININT)
            _9255 = (object)temp_dbl;
            else
            _9255 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16241, 256LL);
        _9255 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9255)) {
        {uintptr_t tu;
             tu = (uintptr_t)_9255 & (uintptr_t)255LL;
             _9256 = MAKE_UINT(tu);
        }
    }
    else {
        _9256 = binary_op(AND_BITS, _9255, 255LL);
    }
    DeRef(_9255);
    _9255 = NOVALUE;
    if (IS_ATOM_INT(_x_16241)) {
        if (65536LL > 0 && _x_16241 >= 0) {
            _9257 = _x_16241 / 65536LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_x_16241 / (eudouble)65536LL);
            if (_x_16241 != MININT)
            _9257 = (object)temp_dbl;
            else
            _9257 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_16241, 65536LL);
        _9257 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 250LL;
    ((intptr_t*)_2)[2] = _9254;
    ((intptr_t*)_2)[3] = _9256;
    ((intptr_t*)_2)[4] = _9257;
    _9258 = MAKE_SEQ(_1);
    _9257 = NOVALUE;
    _9256 = NOVALUE;
    _9254 = NOVALUE;
    DeRef(_x_16241);
    DeRefi(_x4_16242);
    DeRef(_s_16243);
    DeRef(_9238);
    _9238 = NOVALUE;
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    DeRef(_9243);
    _9243 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    return _9258;
    goto L3; // [156] 330
L5: 

    /** eds.e:403				return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_16241)) {
        _9259 = _x_16241 - _41MIN4B_16165;
        if ((object)((uintptr_t)_9259 +(uintptr_t) HIGH_BITS) >= 0){
            _9259 = NewDouble((eudouble)_9259);
        }
    }
    else {
        _9259 = binary_op(MINUS, _x_16241, _41MIN4B_16165);
    }
    _9260 = _13int_to_bytes(_9259, 4LL);
    _9259 = NOVALUE;
    if (IS_SEQUENCE(251LL) && IS_ATOM(_9260)) {
    }
    else if (IS_ATOM(251LL) && IS_SEQUENCE(_9260)) {
        Prepend(&_9261, _9260, 251LL);
    }
    else {
        Concat((object_ptr)&_9261, 251LL, _9260);
    }
    DeRef(_9260);
    _9260 = NOVALUE;
    DeRef(_x_16241);
    DeRefi(_x4_16242);
    DeRef(_s_16243);
    DeRef(_9238);
    _9238 = NOVALUE;
    DeRef(_9258);
    _9258 = NOVALUE;
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    DeRef(_9243);
    _9243 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    return _9261;
    goto L3; // [181] 330
L1: 

    /** eds.e:407		elsif atom(x) then*/
    _9262 = IS_ATOM(_x_16241);
    if (_9262 == 0)
    {
        _9262 = NOVALUE;
        goto L6; // [189] 250
    }
    else{
        _9262 = NOVALUE;
    }

    /** eds.e:409			x4 = convert:atom_to_float32(x)*/

    /** convert.e:312		return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_16242);
    _x4_16242 = machine(48LL, _x_16241);

    /** eds.e:410			if x = convert:float32_to_atom(x4) then*/

    /** convert.e:374		return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_204_16280);
    _float32_to_atom_inlined_float32_to_atom_at_204_16280 = machine(49LL, _x4_16242);
    if (binary_op_a(NOTEQ, _x_16241, _float32_to_atom_inlined_float32_to_atom_at_204_16280)){
        goto L7; // [212] 229
    }

    /** eds.e:412				return F4B & x4*/
    Prepend(&_9264, _x4_16242, 252LL);
    DeRef(_x_16241);
    DeRefDSi(_x4_16242);
    DeRef(_s_16243);
    DeRef(_9238);
    _9238 = NOVALUE;
    DeRef(_9261);
    _9261 = NOVALUE;
    DeRef(_9258);
    _9258 = NOVALUE;
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    DeRef(_9243);
    _9243 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    return _9264;
    goto L3; // [226] 330
L7: 

    /** eds.e:414				return F8B & convert:atom_to_float64(x)*/

    /** convert.e:262		return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_230_16285);
    _atom_to_float64_inlined_atom_to_float64_at_230_16285 = machine(46LL, _x_16241);
    Prepend(&_9265, _atom_to_float64_inlined_atom_to_float64_at_230_16285, 253LL);
    DeRef(_x_16241);
    DeRefi(_x4_16242);
    DeRef(_s_16243);
    DeRef(_9238);
    _9238 = NOVALUE;
    DeRef(_9261);
    _9261 = NOVALUE;
    DeRef(_9258);
    _9258 = NOVALUE;
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    DeRef(_9264);
    _9264 = NOVALUE;
    DeRef(_9243);
    _9243 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    return _9265;
    goto L3; // [247] 330
L6: 

    /** eds.e:419			if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_16241)){
            _9266 = SEQ_PTR(_x_16241)->length;
    }
    else {
        _9266 = 1;
    }
    if (_9266 > 255LL)
    goto L8; // [255] 271

    /** eds.e:420				s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_16241)){
            _9268 = SEQ_PTR(_x_16241)->length;
    }
    else {
        _9268 = 1;
    }
    DeRef(_s_16243);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 254LL;
    ((intptr_t *)_2)[2] = _9268;
    _s_16243 = MAKE_SEQ(_1);
    _9268 = NOVALUE;
    goto L9; // [268] 286
L8: 

    /** eds.e:422				s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_16241)){
            _9270 = SEQ_PTR(_x_16241)->length;
    }
    else {
        _9270 = 1;
    }
    _9271 = _13int_to_bytes(_9270, 4LL);
    _9270 = NOVALUE;
    if (IS_SEQUENCE(255LL) && IS_ATOM(_9271)) {
    }
    else if (IS_ATOM(255LL) && IS_SEQUENCE(_9271)) {
        Prepend(&_s_16243, _9271, 255LL);
    }
    else {
        Concat((object_ptr)&_s_16243, 255LL, _9271);
    }
    DeRef(_9271);
    _9271 = NOVALUE;
L9: 

    /** eds.e:424			for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_16241)){
            _9273 = SEQ_PTR(_x_16241)->length;
    }
    else {
        _9273 = 1;
    }
    {
        object _i_16298;
        _i_16298 = 1LL;
LA: 
        if (_i_16298 > _9273){
            goto LB; // [291] 321
        }

        /** eds.e:425				s &= compress(x[i])*/
        _2 = (object)SEQ_PTR(_x_16241);
        _9274 = (object)*(((s1_ptr)_2)->base + _i_16298);
        Ref(_9274);
        _9275 = _41compress(_9274);
        _9274 = NOVALUE;
        if (IS_SEQUENCE(_s_16243) && IS_ATOM(_9275)) {
            Ref(_9275);
            Append(&_s_16243, _s_16243, _9275);
        }
        else if (IS_ATOM(_s_16243) && IS_SEQUENCE(_9275)) {
        }
        else {
            Concat((object_ptr)&_s_16243, _s_16243, _9275);
        }
        DeRef(_9275);
        _9275 = NOVALUE;

        /** eds.e:426			end for*/
        _i_16298 = _i_16298 + 1LL;
        goto LA; // [316] 298
LB: 
        ;
    }

    /** eds.e:427			return s*/
    DeRef(_x_16241);
    DeRefi(_x4_16242);
    DeRef(_9238);
    _9238 = NOVALUE;
    DeRef(_9261);
    _9261 = NOVALUE;
    DeRef(_9258);
    _9258 = NOVALUE;
    DeRef(_9265);
    _9265 = NOVALUE;
    DeRef(_9249);
    _9249 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    DeRef(_9264);
    _9264 = NOVALUE;
    DeRef(_9243);
    _9243 = NOVALUE;
    DeRef(_9250);
    _9250 = NOVALUE;
    return _s_16243;
L3: 
    ;
}


object _41db_allocate(object _n_16669)
{
    object _free_list_16670 = NOVALUE;
    object _size_16671 = NOVALUE;
    object _size_ptr_16672 = NOVALUE;
    object _addr_16673 = NOVALUE;
    object _free_count_16674 = NOVALUE;
    object _remaining_16675 = NOVALUE;
    object _seek_1__tmp_at4_16678 = NOVALUE;
    object _seek_inlined_seek_at_4_16677 = NOVALUE;
    object _seek_1__tmp_at39_16685 = NOVALUE;
    object _seek_inlined_seek_at_39_16684 = NOVALUE;
    object _seek_1__tmp_at111_16702 = NOVALUE;
    object _seek_inlined_seek_at_111_16701 = NOVALUE;
    object _pos_inlined_seek_at_108_16700 = NOVALUE;
    object _put4_1__tmp_at137_16707 = NOVALUE;
    object _x_inlined_put4_at_134_16706 = NOVALUE;
    object _seek_1__tmp_at167_16710 = NOVALUE;
    object _seek_inlined_seek_at_167_16709 = NOVALUE;
    object _put4_1__tmp_at193_16715 = NOVALUE;
    object _x_inlined_put4_at_190_16714 = NOVALUE;
    object _seek_1__tmp_at244_16723 = NOVALUE;
    object _seek_inlined_seek_at_244_16722 = NOVALUE;
    object _pos_inlined_seek_at_241_16721 = NOVALUE;
    object _put4_1__tmp_at266_16727 = NOVALUE;
    object _x_inlined_put4_at_263_16726 = NOVALUE;
    object _seek_1__tmp_at333_16738 = NOVALUE;
    object _seek_inlined_seek_at_333_16737 = NOVALUE;
    object _pos_inlined_seek_at_330_16736 = NOVALUE;
    object _seek_1__tmp_at364_16742 = NOVALUE;
    object _seek_inlined_seek_at_364_16741 = NOVALUE;
    object _put4_1__tmp_at386_16746 = NOVALUE;
    object _x_inlined_put4_at_383_16745 = NOVALUE;
    object _seek_1__tmp_at423_16751 = NOVALUE;
    object _seek_inlined_seek_at_423_16750 = NOVALUE;
    object _pos_inlined_seek_at_420_16749 = NOVALUE;
    object _put4_1__tmp_at438_16753 = NOVALUE;
    object _seek_1__tmp_at490_16757 = NOVALUE;
    object _seek_inlined_seek_at_490_16756 = NOVALUE;
    object _put4_1__tmp_at512_16761 = NOVALUE;
    object _x_inlined_put4_at_509_16760 = NOVALUE;
    object _where_inlined_where_at_542_16763 = NOVALUE;
    object _9474 = NOVALUE;
    object _9472 = NOVALUE;
    object _9471 = NOVALUE;
    object _9470 = NOVALUE;
    object _9469 = NOVALUE;
    object _9468 = NOVALUE;
    object _9466 = NOVALUE;
    object _9465 = NOVALUE;
    object _9464 = NOVALUE;
    object _9463 = NOVALUE;
    object _9461 = NOVALUE;
    object _9460 = NOVALUE;
    object _9459 = NOVALUE;
    object _9458 = NOVALUE;
    object _9457 = NOVALUE;
    object _9456 = NOVALUE;
    object _9455 = NOVALUE;
    object _9453 = NOVALUE;
    object _9451 = NOVALUE;
    object _9448 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:795		io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_16678);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 7LL;
    _seek_1__tmp_at4_16678 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_16677 = machine(19LL, _seek_1__tmp_at4_16678);
    DeRefi(_seek_1__tmp_at4_16678);
    _seek_1__tmp_at4_16678 = NOVALUE;

    /** eds.e:796		free_count = get4()*/
    _free_count_16674 = _41get4();
    if (!IS_ATOM_INT(_free_count_16674)) {
        _1 = (object)(DBL_PTR(_free_count_16674)->dbl);
        DeRefDS(_free_count_16674);
        _free_count_16674 = _1;
    }

    /** eds.e:797		if free_count > 0 then*/
    if (_free_count_16674 <= 0LL)
    goto L1; // [27] 487

    /** eds.e:798			free_list = get4()*/
    _0 = _free_list_16670;
    _free_list_16670 = _41get4();
    DeRef(_0);

    /** eds.e:799			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16670);
    DeRef(_seek_1__tmp_at39_16685);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _free_list_16670;
    _seek_1__tmp_at39_16685 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_16684 = machine(19LL, _seek_1__tmp_at39_16685);
    DeRef(_seek_1__tmp_at39_16685);
    _seek_1__tmp_at39_16685 = NOVALUE;

    /** eds.e:800			size_ptr = free_list + 4*/
    DeRef(_size_ptr_16672);
    if (IS_ATOM_INT(_free_list_16670)) {
        _size_ptr_16672 = _free_list_16670 + 4LL;
        if ((object)((uintptr_t)_size_ptr_16672 + (uintptr_t)HIGH_BITS) >= 0){
            _size_ptr_16672 = NewDouble((eudouble)_size_ptr_16672);
        }
    }
    else {
        _size_ptr_16672 = NewDouble(DBL_PTR(_free_list_16670)->dbl + (eudouble)4LL);
    }

    /** eds.e:801			for i = 1 to free_count do*/
    _9448 = _free_count_16674;
    {
        object _i_16688;
        _i_16688 = 1LL;
L2: 
        if (_i_16688 > _9448){
            goto L3; // [64] 486
        }

        /** eds.e:802				addr = get4()*/
        _0 = _addr_16673;
        _addr_16673 = _41get4();
        DeRef(_0);

        /** eds.e:803				size = get4()*/
        _0 = _size_16671;
        _size_16671 = _41get4();
        DeRef(_0);

        /** eds.e:804				if size >= n+4 then*/
        if (IS_ATOM_INT(_n_16669)) {
            _9451 = _n_16669 + 4LL;
            if ((object)((uintptr_t)_9451 + (uintptr_t)HIGH_BITS) >= 0){
                _9451 = NewDouble((eudouble)_9451);
            }
        }
        else {
            _9451 = NewDouble(DBL_PTR(_n_16669)->dbl + (eudouble)4LL);
        }
        if (binary_op_a(LESS, _size_16671, _9451)){
            DeRef(_9451);
            _9451 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_9451);
        _9451 = NOVALUE;

        /** eds.e:806					if size >= n+16 then*/
        if (IS_ATOM_INT(_n_16669)) {
            _9453 = _n_16669 + 16LL;
            if ((object)((uintptr_t)_9453 + (uintptr_t)HIGH_BITS) >= 0){
                _9453 = NewDouble((eudouble)_9453);
            }
        }
        else {
            _9453 = NewDouble(DBL_PTR(_n_16669)->dbl + (eudouble)16LL);
        }
        if (binary_op_a(LESS, _size_16671, _9453)){
            DeRef(_9453);
            _9453 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_9453);
        _9453 = NOVALUE;

        /** eds.e:808						io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_16673)) {
            _9455 = _addr_16673 - 4LL;
            if ((object)((uintptr_t)_9455 +(uintptr_t) HIGH_BITS) >= 0){
                _9455 = NewDouble((eudouble)_9455);
            }
        }
        else {
            _9455 = NewDouble(DBL_PTR(_addr_16673)->dbl - (eudouble)4LL);
        }
        DeRef(_pos_inlined_seek_at_108_16700);
        _pos_inlined_seek_at_108_16700 = _9455;
        _9455 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_16700);
        DeRef(_seek_1__tmp_at111_16702);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_108_16700;
        _seek_1__tmp_at111_16702 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_16701 = machine(19LL, _seek_1__tmp_at111_16702);
        DeRef(_pos_inlined_seek_at_108_16700);
        _pos_inlined_seek_at_108_16700 = NOVALUE;
        DeRef(_seek_1__tmp_at111_16702);
        _seek_1__tmp_at111_16702 = NOVALUE;

        /** eds.e:809						put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_16671) && IS_ATOM_INT(_n_16669)) {
            _9456 = _size_16671 - _n_16669;
            if ((object)((uintptr_t)_9456 +(uintptr_t) HIGH_BITS) >= 0){
                _9456 = NewDouble((eudouble)_9456);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16671)) {
                _9456 = NewDouble((eudouble)_size_16671 - DBL_PTR(_n_16669)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16669)) {
                    _9456 = NewDouble(DBL_PTR(_size_16671)->dbl - (eudouble)_n_16669);
                }
                else
                _9456 = NewDouble(DBL_PTR(_size_16671)->dbl - DBL_PTR(_n_16669)->dbl);
            }
        }
        if (IS_ATOM_INT(_9456)) {
            _9457 = _9456 - 4LL;
            if ((object)((uintptr_t)_9457 +(uintptr_t) HIGH_BITS) >= 0){
                _9457 = NewDouble((eudouble)_9457);
            }
        }
        else {
            _9457 = NewDouble(DBL_PTR(_9456)->dbl - (eudouble)4LL);
        }
        DeRef(_9456);
        _9456 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_16706);
        _x_inlined_put4_at_134_16706 = _9457;
        _9457 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16082)){
            poke4_addr = (uint32_t *)_41mem0_16082;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_16706)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_134_16706;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_134_16706)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_16707);
        _1 = (object)SEQ_PTR(_41memseq_16306);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at137_16707 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16040, _put4_1__tmp_at137_16707); // DJP 

        /** eds.e:444	end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_16706);
        _x_inlined_put4_at_134_16706 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_16707);
        _put4_1__tmp_at137_16707 = NOVALUE;

        /** eds.e:810						io:seek(current_db, size_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_16672);
        DeRef(_seek_1__tmp_at167_16710);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _size_ptr_16672;
        _seek_1__tmp_at167_16710 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_16709 = machine(19LL, _seek_1__tmp_at167_16710);
        DeRef(_seek_1__tmp_at167_16710);
        _seek_1__tmp_at167_16710 = NOVALUE;

        /** eds.e:811						put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_16671) && IS_ATOM_INT(_n_16669)) {
            _9458 = _size_16671 - _n_16669;
            if ((object)((uintptr_t)_9458 +(uintptr_t) HIGH_BITS) >= 0){
                _9458 = NewDouble((eudouble)_9458);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16671)) {
                _9458 = NewDouble((eudouble)_size_16671 - DBL_PTR(_n_16669)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16669)) {
                    _9458 = NewDouble(DBL_PTR(_size_16671)->dbl - (eudouble)_n_16669);
                }
                else
                _9458 = NewDouble(DBL_PTR(_size_16671)->dbl - DBL_PTR(_n_16669)->dbl);
            }
        }
        if (IS_ATOM_INT(_9458)) {
            _9459 = _9458 - 4LL;
            if ((object)((uintptr_t)_9459 +(uintptr_t) HIGH_BITS) >= 0){
                _9459 = NewDouble((eudouble)_9459);
            }
        }
        else {
            _9459 = NewDouble(DBL_PTR(_9458)->dbl - (eudouble)4LL);
        }
        DeRef(_9458);
        _9458 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_16714);
        _x_inlined_put4_at_190_16714 = _9459;
        _9459 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16082)){
            poke4_addr = (uint32_t *)_41mem0_16082;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_16714)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_190_16714;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_190_16714)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_16715);
        _1 = (object)SEQ_PTR(_41memseq_16306);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at193_16715 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16040, _put4_1__tmp_at193_16715); // DJP 

        /** eds.e:444	end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_16714);
        _x_inlined_put4_at_190_16714 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_16715);
        _put4_1__tmp_at193_16715 = NOVALUE;

        /** eds.e:812						addr += size-n-4*/
        if (IS_ATOM_INT(_size_16671) && IS_ATOM_INT(_n_16669)) {
            _9460 = _size_16671 - _n_16669;
            if ((object)((uintptr_t)_9460 +(uintptr_t) HIGH_BITS) >= 0){
                _9460 = NewDouble((eudouble)_9460);
            }
        }
        else {
            if (IS_ATOM_INT(_size_16671)) {
                _9460 = NewDouble((eudouble)_size_16671 - DBL_PTR(_n_16669)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_16669)) {
                    _9460 = NewDouble(DBL_PTR(_size_16671)->dbl - (eudouble)_n_16669);
                }
                else
                _9460 = NewDouble(DBL_PTR(_size_16671)->dbl - DBL_PTR(_n_16669)->dbl);
            }
        }
        if (IS_ATOM_INT(_9460)) {
            _9461 = _9460 - 4LL;
            if ((object)((uintptr_t)_9461 +(uintptr_t) HIGH_BITS) >= 0){
                _9461 = NewDouble((eudouble)_9461);
            }
        }
        else {
            _9461 = NewDouble(DBL_PTR(_9460)->dbl - (eudouble)4LL);
        }
        DeRef(_9460);
        _9460 = NOVALUE;
        _0 = _addr_16673;
        if (IS_ATOM_INT(_addr_16673) && IS_ATOM_INT(_9461)) {
            _addr_16673 = _addr_16673 + _9461;
            if ((object)((uintptr_t)_addr_16673 + (uintptr_t)HIGH_BITS) >= 0){
                _addr_16673 = NewDouble((eudouble)_addr_16673);
            }
        }
        else {
            if (IS_ATOM_INT(_addr_16673)) {
                _addr_16673 = NewDouble((eudouble)_addr_16673 + DBL_PTR(_9461)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9461)) {
                    _addr_16673 = NewDouble(DBL_PTR(_addr_16673)->dbl + (eudouble)_9461);
                }
                else
                _addr_16673 = NewDouble(DBL_PTR(_addr_16673)->dbl + DBL_PTR(_9461)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_9461);
        _9461 = NOVALUE;

        /** eds.e:813						io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_16673)) {
            _9463 = _addr_16673 - 4LL;
            if ((object)((uintptr_t)_9463 +(uintptr_t) HIGH_BITS) >= 0){
                _9463 = NewDouble((eudouble)_9463);
            }
        }
        else {
            _9463 = NewDouble(DBL_PTR(_addr_16673)->dbl - (eudouble)4LL);
        }
        DeRef(_pos_inlined_seek_at_241_16721);
        _pos_inlined_seek_at_241_16721 = _9463;
        _9463 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_16721);
        DeRef(_seek_1__tmp_at244_16723);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_241_16721;
        _seek_1__tmp_at244_16723 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_16722 = machine(19LL, _seek_1__tmp_at244_16723);
        DeRef(_pos_inlined_seek_at_241_16721);
        _pos_inlined_seek_at_241_16721 = NOVALUE;
        DeRef(_seek_1__tmp_at244_16723);
        _seek_1__tmp_at244_16723 = NOVALUE;

        /** eds.e:814						put4(n+4)*/
        if (IS_ATOM_INT(_n_16669)) {
            _9464 = _n_16669 + 4LL;
            if ((object)((uintptr_t)_9464 + (uintptr_t)HIGH_BITS) >= 0){
                _9464 = NewDouble((eudouble)_9464);
            }
        }
        else {
            _9464 = NewDouble(DBL_PTR(_n_16669)->dbl + (eudouble)4LL);
        }
        DeRef(_x_inlined_put4_at_263_16726);
        _x_inlined_put4_at_263_16726 = _9464;
        _9464 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16082)){
            poke4_addr = (uint32_t *)_41mem0_16082;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_16726)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_263_16726;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_263_16726)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_16727);
        _1 = (object)SEQ_PTR(_41memseq_16306);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at266_16727 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16040, _put4_1__tmp_at266_16727); // DJP 

        /** eds.e:444	end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_16726);
        _x_inlined_put4_at_263_16726 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_16727);
        _put4_1__tmp_at266_16727 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** eds.e:817						remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _9465 = _free_count_16674 - _i_16688;
        if ((object)((uintptr_t)_9465 +(uintptr_t) HIGH_BITS) >= 0){
            _9465 = NewDouble((eudouble)_9465);
        }
        if (IS_ATOM_INT(_9465)) {
            {
                int128_t p128 = (int128_t)_9465 * (int128_t)8LL;
                if( p128 != (int128_t)(_9466 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _9466 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _9466 = NewDouble(DBL_PTR(_9465)->dbl * (eudouble)8LL);
        }
        DeRef(_9465);
        _9465 = NOVALUE;
        _0 = _remaining_16675;
        _remaining_16675 = _18get_bytes(_41current_db_16040, _9466);
        DeRef(_0);
        _9466 = NOVALUE;

        /** eds.e:818						io:seek(current_db, free_list+8*(i-1))*/
        _9468 = _i_16688 - 1LL;
        {
            int128_t p128 = (int128_t)8LL * (int128_t)_9468;
            if( p128 != (int128_t)(_9469 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9469 = NewDouble( (eudouble)p128 );
            }
        }
        _9468 = NOVALUE;
        if (IS_ATOM_INT(_free_list_16670) && IS_ATOM_INT(_9469)) {
            _9470 = _free_list_16670 + _9469;
            if ((object)((uintptr_t)_9470 + (uintptr_t)HIGH_BITS) >= 0){
                _9470 = NewDouble((eudouble)_9470);
            }
        }
        else {
            if (IS_ATOM_INT(_free_list_16670)) {
                _9470 = NewDouble((eudouble)_free_list_16670 + DBL_PTR(_9469)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9469)) {
                    _9470 = NewDouble(DBL_PTR(_free_list_16670)->dbl + (eudouble)_9469);
                }
                else
                _9470 = NewDouble(DBL_PTR(_free_list_16670)->dbl + DBL_PTR(_9469)->dbl);
            }
        }
        DeRef(_9469);
        _9469 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_16736);
        _pos_inlined_seek_at_330_16736 = _9470;
        _9470 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_16736);
        DeRef(_seek_1__tmp_at333_16738);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_330_16736;
        _seek_1__tmp_at333_16738 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_16737 = machine(19LL, _seek_1__tmp_at333_16738);
        DeRef(_pos_inlined_seek_at_330_16736);
        _pos_inlined_seek_at_330_16736 = NOVALUE;
        DeRef(_seek_1__tmp_at333_16738);
        _seek_1__tmp_at333_16738 = NOVALUE;

        /** eds.e:819						putn(remaining)*/

        /** eds.e:448		puts(current_db, s)*/
        EPuts(_41current_db_16040, _remaining_16675); // DJP 

        /** eds.e:449	end procedure*/
        goto LA; // [358] 361
LA: 

        /** eds.e:820						io:seek(current_db, FREE_COUNT)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_16742);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = 7LL;
        _seek_1__tmp_at364_16742 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_16741 = machine(19LL, _seek_1__tmp_at364_16742);
        DeRefi(_seek_1__tmp_at364_16742);
        _seek_1__tmp_at364_16742 = NOVALUE;

        /** eds.e:821						put4(free_count-1)*/
        _9471 = _free_count_16674 - 1LL;
        if ((object)((uintptr_t)_9471 +(uintptr_t) HIGH_BITS) >= 0){
            _9471 = NewDouble((eudouble)_9471);
        }
        DeRef(_x_inlined_put4_at_383_16745);
        _x_inlined_put4_at_383_16745 = _9471;
        _9471 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16082)){
            poke4_addr = (uint32_t *)_41mem0_16082;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_16745)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_383_16745;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_383_16745)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_16746);
        _1 = (object)SEQ_PTR(_41memseq_16306);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at386_16746 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16040, _put4_1__tmp_at386_16746); // DJP 

        /** eds.e:444	end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_16745);
        _x_inlined_put4_at_383_16745 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_16746);
        _put4_1__tmp_at386_16746 = NOVALUE;

        /** eds.e:822						io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_16673)) {
            _9472 = _addr_16673 - 4LL;
            if ((object)((uintptr_t)_9472 +(uintptr_t) HIGH_BITS) >= 0){
                _9472 = NewDouble((eudouble)_9472);
            }
        }
        else {
            _9472 = NewDouble(DBL_PTR(_addr_16673)->dbl - (eudouble)4LL);
        }
        DeRef(_pos_inlined_seek_at_420_16749);
        _pos_inlined_seek_at_420_16749 = _9472;
        _9472 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_16749);
        DeRef(_seek_1__tmp_at423_16751);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_420_16749;
        _seek_1__tmp_at423_16751 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_16750 = machine(19LL, _seek_1__tmp_at423_16751);
        DeRef(_pos_inlined_seek_at_420_16749);
        _pos_inlined_seek_at_420_16749 = NOVALUE;
        DeRef(_seek_1__tmp_at423_16751);
        _seek_1__tmp_at423_16751 = NOVALUE;

        /** eds.e:823						put4(size) -- in case size was not updated by db_free()*/

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16082)){
            poke4_addr = (uint32_t *)_41mem0_16082;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        }
        if (IS_ATOM_INT(_size_16671)) {
            *poke4_addr = (uint32_t)_size_16671;
        }
        else {
            *poke4_addr = (uint32_t)DBL_PTR(_size_16671)->dbl;
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_16753);
        _1 = (object)SEQ_PTR(_41memseq_16306);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at438_16753 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16040, _put4_1__tmp_at438_16753); // DJP 

        /** eds.e:444	end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_16753);
        _put4_1__tmp_at438_16753 = NOVALUE;
L9: 

        /** eds.e:825					return addr*/
        DeRef(_n_16669);
        DeRef(_free_list_16670);
        DeRef(_size_16671);
        DeRef(_size_ptr_16672);
        DeRef(_remaining_16675);
        return _addr_16673;
L4: 

        /** eds.e:827				size_ptr += 8*/
        _0 = _size_ptr_16672;
        if (IS_ATOM_INT(_size_ptr_16672)) {
            _size_ptr_16672 = _size_ptr_16672 + 8LL;
            if ((object)((uintptr_t)_size_ptr_16672 + (uintptr_t)HIGH_BITS) >= 0){
                _size_ptr_16672 = NewDouble((eudouble)_size_ptr_16672);
            }
        }
        else {
            _size_ptr_16672 = NewDouble(DBL_PTR(_size_ptr_16672)->dbl + (eudouble)8LL);
        }
        DeRef(_0);

        /** eds.e:828			end for*/
        _i_16688 = _i_16688 + 1LL;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** eds.e:831		io:seek(current_db, -1)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_16757);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = -1LL;
    _seek_1__tmp_at490_16757 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_16756 = machine(19LL, _seek_1__tmp_at490_16757);
    DeRefi(_seek_1__tmp_at490_16757);
    _seek_1__tmp_at490_16757 = NOVALUE;

    /** eds.e:832		put4(n+4)*/
    if (IS_ATOM_INT(_n_16669)) {
        _9474 = _n_16669 + 4LL;
        if ((object)((uintptr_t)_9474 + (uintptr_t)HIGH_BITS) >= 0){
            _9474 = NewDouble((eudouble)_9474);
        }
    }
    else {
        _9474 = NewDouble(DBL_PTR(_n_16669)->dbl + (eudouble)4LL);
    }
    DeRef(_x_inlined_put4_at_509_16760);
    _x_inlined_put4_at_509_16760 = _9474;
    _9474 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_16760)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_509_16760;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_509_16760)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_16761);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at512_16761 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at512_16761); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_16760);
    _x_inlined_put4_at_509_16760 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_16761);
    _put4_1__tmp_at512_16761 = NOVALUE;

    /** eds.e:833		return io:where(current_db)*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_16763);
    _where_inlined_where_at_542_16763 = machine(20LL, _41current_db_16040);
    DeRef(_n_16669);
    DeRef(_free_list_16670);
    DeRef(_size_16671);
    DeRef(_size_ptr_16672);
    DeRef(_addr_16673);
    DeRef(_remaining_16675);
    return _where_inlined_where_at_542_16763;
    ;
}


void _41db_free(object _p_16766)
{
    object _psize_16767 = NOVALUE;
    object _i_16768 = NOVALUE;
    object _size_16769 = NOVALUE;
    object _addr_16770 = NOVALUE;
    object _free_list_16771 = NOVALUE;
    object _free_list_space_16772 = NOVALUE;
    object _new_space_16773 = NOVALUE;
    object _to_be_freed_16774 = NOVALUE;
    object _prev_addr_16775 = NOVALUE;
    object _prev_size_16776 = NOVALUE;
    object _free_count_16777 = NOVALUE;
    object _remaining_16778 = NOVALUE;
    object _seek_1__tmp_at11_16783 = NOVALUE;
    object _seek_inlined_seek_at_11_16782 = NOVALUE;
    object _pos_inlined_seek_at_8_16781 = NOVALUE;
    object _seek_1__tmp_at33_16787 = NOVALUE;
    object _seek_inlined_seek_at_33_16786 = NOVALUE;
    object _seek_1__tmp_at69_16794 = NOVALUE;
    object _seek_inlined_seek_at_69_16793 = NOVALUE;
    object _pos_inlined_seek_at_66_16792 = NOVALUE;
    object _seek_1__tmp_at133_16807 = NOVALUE;
    object _seek_inlined_seek_at_133_16806 = NOVALUE;
    object _seek_1__tmp_at157_16811 = NOVALUE;
    object _seek_inlined_seek_at_157_16810 = NOVALUE;
    object _put4_1__tmp_at172_16813 = NOVALUE;
    object _seek_1__tmp_at202_16816 = NOVALUE;
    object _seek_inlined_seek_at_202_16815 = NOVALUE;
    object _seek_1__tmp_at234_16821 = NOVALUE;
    object _seek_inlined_seek_at_234_16820 = NOVALUE;
    object _s_inlined_putn_at_274_16827 = NOVALUE;
    object _seek_1__tmp_at297_16830 = NOVALUE;
    object _seek_inlined_seek_at_297_16829 = NOVALUE;
    object _seek_1__tmp_at430_16851 = NOVALUE;
    object _seek_inlined_seek_at_430_16850 = NOVALUE;
    object _pos_inlined_seek_at_427_16849 = NOVALUE;
    object _put4_1__tmp_at482_16861 = NOVALUE;
    object _x_inlined_put4_at_479_16860 = NOVALUE;
    object _seek_1__tmp_at523_16867 = NOVALUE;
    object _seek_inlined_seek_at_523_16866 = NOVALUE;
    object _pos_inlined_seek_at_520_16865 = NOVALUE;
    object _seek_1__tmp_at574_16877 = NOVALUE;
    object _seek_inlined_seek_at_574_16876 = NOVALUE;
    object _pos_inlined_seek_at_571_16875 = NOVALUE;
    object _seek_1__tmp_at611_16882 = NOVALUE;
    object _seek_inlined_seek_at_611_16881 = NOVALUE;
    object _put4_1__tmp_at626_16884 = NOVALUE;
    object _put4_1__tmp_at664_16889 = NOVALUE;
    object _x_inlined_put4_at_661_16888 = NOVALUE;
    object _seek_1__tmp_at737_16901 = NOVALUE;
    object _seek_inlined_seek_at_737_16900 = NOVALUE;
    object _pos_inlined_seek_at_734_16899 = NOVALUE;
    object _put4_1__tmp_at752_16903 = NOVALUE;
    object _put4_1__tmp_at789_16907 = NOVALUE;
    object _x_inlined_put4_at_786_16906 = NOVALUE;
    object _seek_1__tmp_at837_16915 = NOVALUE;
    object _seek_inlined_seek_at_837_16914 = NOVALUE;
    object _pos_inlined_seek_at_834_16913 = NOVALUE;
    object _seek_1__tmp_at883_16923 = NOVALUE;
    object _seek_inlined_seek_at_883_16922 = NOVALUE;
    object _put4_1__tmp_at898_16925 = NOVALUE;
    object _seek_1__tmp_at943_16932 = NOVALUE;
    object _seek_inlined_seek_at_943_16931 = NOVALUE;
    object _pos_inlined_seek_at_940_16930 = NOVALUE;
    object _put4_1__tmp_at958_16934 = NOVALUE;
    object _put4_1__tmp_at986_16936 = NOVALUE;
    object _9542 = NOVALUE;
    object _9541 = NOVALUE;
    object _9540 = NOVALUE;
    object _9537 = NOVALUE;
    object _9536 = NOVALUE;
    object _9535 = NOVALUE;
    object _9534 = NOVALUE;
    object _9533 = NOVALUE;
    object _9532 = NOVALUE;
    object _9531 = NOVALUE;
    object _9530 = NOVALUE;
    object _9529 = NOVALUE;
    object _9528 = NOVALUE;
    object _9527 = NOVALUE;
    object _9526 = NOVALUE;
    object _9525 = NOVALUE;
    object _9524 = NOVALUE;
    object _9523 = NOVALUE;
    object _9521 = NOVALUE;
    object _9520 = NOVALUE;
    object _9519 = NOVALUE;
    object _9517 = NOVALUE;
    object _9516 = NOVALUE;
    object _9515 = NOVALUE;
    object _9514 = NOVALUE;
    object _9513 = NOVALUE;
    object _9512 = NOVALUE;
    object _9511 = NOVALUE;
    object _9510 = NOVALUE;
    object _9509 = NOVALUE;
    object _9508 = NOVALUE;
    object _9507 = NOVALUE;
    object _9506 = NOVALUE;
    object _9505 = NOVALUE;
    object _9504 = NOVALUE;
    object _9503 = NOVALUE;
    object _9502 = NOVALUE;
    object _9501 = NOVALUE;
    object _9500 = NOVALUE;
    object _9494 = NOVALUE;
    object _9493 = NOVALUE;
    object _9492 = NOVALUE;
    object _9490 = NOVALUE;
    object _9486 = NOVALUE;
    object _9485 = NOVALUE;
    object _9483 = NOVALUE;
    object _9482 = NOVALUE;
    object _9480 = NOVALUE;
    object _9479 = NOVALUE;
    object _9475 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:844		io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_16766)) {
        _9475 = _p_16766 - 4LL;
        if ((object)((uintptr_t)_9475 +(uintptr_t) HIGH_BITS) >= 0){
            _9475 = NewDouble((eudouble)_9475);
        }
    }
    else {
        _9475 = NewDouble(DBL_PTR(_p_16766)->dbl - (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_8_16781);
    _pos_inlined_seek_at_8_16781 = _9475;
    _9475 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_16781);
    DeRef(_seek_1__tmp_at11_16783);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_16781;
    _seek_1__tmp_at11_16783 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_16782 = machine(19LL, _seek_1__tmp_at11_16783);
    DeRef(_pos_inlined_seek_at_8_16781);
    _pos_inlined_seek_at_8_16781 = NOVALUE;
    DeRef(_seek_1__tmp_at11_16783);
    _seek_1__tmp_at11_16783 = NOVALUE;

    /** eds.e:845		psize = get4()*/
    _0 = _psize_16767;
    _psize_16767 = _41get4();
    DeRef(_0);

    /** eds.e:847		io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_16787);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 7LL;
    _seek_1__tmp_at33_16787 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_16786 = machine(19LL, _seek_1__tmp_at33_16787);
    DeRefi(_seek_1__tmp_at33_16787);
    _seek_1__tmp_at33_16787 = NOVALUE;

    /** eds.e:848		free_count = get4()*/
    _free_count_16777 = _41get4();
    if (!IS_ATOM_INT(_free_count_16777)) {
        _1 = (object)(DBL_PTR(_free_count_16777)->dbl);
        DeRefDS(_free_count_16777);
        _free_count_16777 = _1;
    }

    /** eds.e:849		free_list = get4()*/
    _0 = _free_list_16771;
    _free_list_16771 = _41get4();
    DeRef(_0);

    /** eds.e:850		io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_16771)) {
        _9479 = _free_list_16771 - 4LL;
        if ((object)((uintptr_t)_9479 +(uintptr_t) HIGH_BITS) >= 0){
            _9479 = NewDouble((eudouble)_9479);
        }
    }
    else {
        _9479 = NewDouble(DBL_PTR(_free_list_16771)->dbl - (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_66_16792);
    _pos_inlined_seek_at_66_16792 = _9479;
    _9479 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_16792);
    DeRef(_seek_1__tmp_at69_16794);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_66_16792;
    _seek_1__tmp_at69_16794 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_16793 = machine(19LL, _seek_1__tmp_at69_16794);
    DeRef(_pos_inlined_seek_at_66_16792);
    _pos_inlined_seek_at_66_16792 = NOVALUE;
    DeRef(_seek_1__tmp_at69_16794);
    _seek_1__tmp_at69_16794 = NOVALUE;

    /** eds.e:851		free_list_space = get4()-4*/
    _9480 = _41get4();
    DeRef(_free_list_space_16772);
    if (IS_ATOM_INT(_9480)) {
        _free_list_space_16772 = _9480 - 4LL;
        if ((object)((uintptr_t)_free_list_space_16772 +(uintptr_t) HIGH_BITS) >= 0){
            _free_list_space_16772 = NewDouble((eudouble)_free_list_space_16772);
        }
    }
    else {
        _free_list_space_16772 = binary_op(MINUS, _9480, 4LL);
    }
    DeRef(_9480);
    _9480 = NOVALUE;

    /** eds.e:852		if free_list_space < 8 * (free_count+1) then*/
    _9482 = _free_count_16777 + 1;
    if (_9482 > MAXINT){
        _9482 = NewDouble((eudouble)_9482);
    }
    if (IS_ATOM_INT(_9482)) {
        {
            int128_t p128 = (int128_t)8LL * (int128_t)_9482;
            if( p128 != (int128_t)(_9483 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9483 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9483 = NewDouble((eudouble)8LL * DBL_PTR(_9482)->dbl);
    }
    DeRef(_9482);
    _9482 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_16772, _9483)){
        DeRef(_9483);
        _9483 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_9483);
    _9483 = NOVALUE;

    /** eds.e:854			new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_16772)) {
        if (_free_list_space_16772 & 1) {
            _9485 = NewDouble((_free_list_space_16772 >> 1) + 0.5);
        }
        else
        _9485 = _free_list_space_16772 >> 1;
    }
    else {
        _9485 = binary_op(DIVIDE, _free_list_space_16772, 2);
    }
    if (IS_ATOM_INT(_free_list_space_16772) && IS_ATOM_INT(_9485)) {
        _9486 = _free_list_space_16772 + _9485;
        if ((object)((uintptr_t)_9486 + (uintptr_t)HIGH_BITS) >= 0){
            _9486 = NewDouble((eudouble)_9486);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_space_16772)) {
            _9486 = NewDouble((eudouble)_free_list_space_16772 + DBL_PTR(_9485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9485)) {
                _9486 = NewDouble(DBL_PTR(_free_list_space_16772)->dbl + (eudouble)_9485);
            }
            else
            _9486 = NewDouble(DBL_PTR(_free_list_space_16772)->dbl + DBL_PTR(_9485)->dbl);
        }
    }
    DeRef(_9485);
    _9485 = NOVALUE;
    DeRef(_new_space_16773);
    if (IS_ATOM_INT(_9486))
    _new_space_16773 = e_floor(_9486);
    else
    _new_space_16773 = unary_op(FLOOR, _9486);
    DeRef(_9486);
    _9486 = NOVALUE;

    /** eds.e:855			to_be_freed = free_list*/
    Ref(_free_list_16771);
    DeRef(_to_be_freed_16774);
    _to_be_freed_16774 = _free_list_16771;

    /** eds.e:856			free_list = db_allocate(new_space)*/
    Ref(_new_space_16773);
    _0 = _free_list_16771;
    _free_list_16771 = _41db_allocate(_new_space_16773);
    DeRef(_0);

    /** eds.e:857			io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_16807);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 7LL;
    _seek_1__tmp_at133_16807 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_16806 = machine(19LL, _seek_1__tmp_at133_16807);
    DeRefi(_seek_1__tmp_at133_16807);
    _seek_1__tmp_at133_16807 = NOVALUE;

    /** eds.e:858			free_count = get4() -- db_allocate may have changed it*/
    _free_count_16777 = _41get4();
    if (!IS_ATOM_INT(_free_count_16777)) {
        _1 = (object)(DBL_PTR(_free_count_16777)->dbl);
        DeRefDS(_free_count_16777);
        _free_count_16777 = _1;
    }

    /** eds.e:859			io:seek(current_db, FREE_LIST)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_16811);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 11LL;
    _seek_1__tmp_at157_16811 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_16810 = machine(19LL, _seek_1__tmp_at157_16811);
    DeRefi(_seek_1__tmp_at157_16811);
    _seek_1__tmp_at157_16811 = NOVALUE;

    /** eds.e:860			put4(free_list)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_free_list_16771)) {
        *poke4_addr = (uint32_t)_free_list_16771;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_free_list_16771)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_16813);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at172_16813 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at172_16813); // DJP 

    /** eds.e:444	end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_16813);
    _put4_1__tmp_at172_16813 = NOVALUE;

    /** eds.e:861			io:seek(current_db, to_be_freed)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_16774);
    DeRef(_seek_1__tmp_at202_16816);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _to_be_freed_16774;
    _seek_1__tmp_at202_16816 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_16815 = machine(19LL, _seek_1__tmp_at202_16816);
    DeRef(_seek_1__tmp_at202_16816);
    _seek_1__tmp_at202_16816 = NOVALUE;

    /** eds.e:862			remaining = io:get_bytes(current_db, 8*free_count)*/
    {
        int128_t p128 = (int128_t)8LL * (int128_t)_free_count_16777;
        if( p128 != (int128_t)(_9490 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9490 = NewDouble( (eudouble)p128 );
        }
    }
    _0 = _remaining_16778;
    _remaining_16778 = _18get_bytes(_41current_db_16040, _9490);
    DeRef(_0);
    _9490 = NOVALUE;

    /** eds.e:863			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16771);
    DeRef(_seek_1__tmp_at234_16821);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _free_list_16771;
    _seek_1__tmp_at234_16821 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_16820 = machine(19LL, _seek_1__tmp_at234_16821);
    DeRef(_seek_1__tmp_at234_16821);
    _seek_1__tmp_at234_16821 = NOVALUE;

    /** eds.e:864			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _remaining_16778); // DJP 

    /** eds.e:449	end procedure*/
    goto L3; // [259] 262
L3: 

    /** eds.e:865			putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_16778)){
            _9492 = SEQ_PTR(_remaining_16778)->length;
    }
    else {
        _9492 = 1;
    }
    if (IS_ATOM_INT(_new_space_16773)) {
        _9493 = _new_space_16773 - _9492;
    }
    else {
        _9493 = NewDouble(DBL_PTR(_new_space_16773)->dbl - (eudouble)_9492);
    }
    _9492 = NOVALUE;
    _9494 = Repeat(0LL, _9493);
    DeRef(_9493);
    _9493 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_16827);
    _s_inlined_putn_at_274_16827 = _9494;
    _9494 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_274_16827); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_16827);
    _s_inlined_putn_at_274_16827 = NOVALUE;

    /** eds.e:866			io:seek(current_db, free_list)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_16771);
    DeRef(_seek_1__tmp_at297_16830);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _free_list_16771;
    _seek_1__tmp_at297_16830 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_16829 = machine(19LL, _seek_1__tmp_at297_16830);
    DeRef(_seek_1__tmp_at297_16830);
    _seek_1__tmp_at297_16830 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** eds.e:868			new_space = 0*/
    DeRef(_new_space_16773);
    _new_space_16773 = 0LL;
L5: 

    /** eds.e:871		i = 1*/
    DeRef(_i_16768);
    _i_16768 = 1LL;

    /** eds.e:872		prev_addr = 0*/
    DeRef(_prev_addr_16775);
    _prev_addr_16775 = 0LL;

    /** eds.e:873		prev_size = 0*/
    DeRef(_prev_size_16776);
    _prev_size_16776 = 0LL;

    /** eds.e:874		while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_16768, _free_count_16777)){
        goto L7; // [340] 386
    }

    /** eds.e:875			addr = get4()*/
    _0 = _addr_16770;
    _addr_16770 = _41get4();
    DeRef(_0);

    /** eds.e:876			size = get4()*/
    _0 = _size_16769;
    _size_16769 = _41get4();
    DeRef(_0);

    /** eds.e:877			if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_16766, _addr_16770)){
        goto L8; // [356] 365
    }

    /** eds.e:878				exit*/
    goto L7; // [362] 386
L8: 

    /** eds.e:880			prev_addr = addr*/
    Ref(_addr_16770);
    DeRef(_prev_addr_16775);
    _prev_addr_16775 = _addr_16770;

    /** eds.e:881			prev_size = size*/
    Ref(_size_16769);
    DeRef(_prev_size_16776);
    _prev_size_16776 = _size_16769;

    /** eds.e:882			i += 1*/
    _0 = _i_16768;
    if (IS_ATOM_INT(_i_16768)) {
        _i_16768 = _i_16768 + 1;
        if (_i_16768 > MAXINT){
            _i_16768 = NewDouble((eudouble)_i_16768);
        }
    }
    else
    _i_16768 = binary_op(PLUS, 1, _i_16768);
    DeRef(_0);

    /** eds.e:883		end while*/
    goto L6; // [383] 340
L7: 

    /** eds.e:885		if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_16768)) {
        _9500 = (_i_16768 > 1LL);
    }
    else {
        _9500 = (DBL_PTR(_i_16768)->dbl > (eudouble)1LL);
    }
    if (_9500 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_16775) && IS_ATOM_INT(_prev_size_16776)) {
        _9502 = _prev_addr_16775 + _prev_size_16776;
        if ((object)((uintptr_t)_9502 + (uintptr_t)HIGH_BITS) >= 0){
            _9502 = NewDouble((eudouble)_9502);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_addr_16775)) {
            _9502 = NewDouble((eudouble)_prev_addr_16775 + DBL_PTR(_prev_size_16776)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_16776)) {
                _9502 = NewDouble(DBL_PTR(_prev_addr_16775)->dbl + (eudouble)_prev_size_16776);
            }
            else
            _9502 = NewDouble(DBL_PTR(_prev_addr_16775)->dbl + DBL_PTR(_prev_size_16776)->dbl);
        }
    }
    if (IS_ATOM_INT(_9502) && IS_ATOM_INT(_p_16766)) {
        _9503 = (_9502 == _p_16766);
    }
    else {
        if (IS_ATOM_INT(_9502)) {
            _9503 = ((eudouble)_9502 == DBL_PTR(_p_16766)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_16766)) {
                _9503 = (DBL_PTR(_9502)->dbl == (eudouble)_p_16766);
            }
            else
            _9503 = (DBL_PTR(_9502)->dbl == DBL_PTR(_p_16766)->dbl);
        }
    }
    DeRef(_9502);
    _9502 = NOVALUE;
    if (_9503 == 0)
    {
        DeRef(_9503);
        _9503 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_9503);
        _9503 = NOVALUE;
    }

    /** eds.e:887			io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9504 = _i_16768 - 2LL;
        if ((object)((uintptr_t)_9504 +(uintptr_t) HIGH_BITS) >= 0){
            _9504 = NewDouble((eudouble)_9504);
        }
    }
    else {
        _9504 = NewDouble(DBL_PTR(_i_16768)->dbl - (eudouble)2LL);
    }
    if (IS_ATOM_INT(_9504)) {
        {
            int128_t p128 = (int128_t)_9504 * (int128_t)8LL;
            if( p128 != (int128_t)(_9505 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9505 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9505 = NewDouble(DBL_PTR(_9504)->dbl * (eudouble)8LL);
    }
    DeRef(_9504);
    _9504 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16771) && IS_ATOM_INT(_9505)) {
        _9506 = _free_list_16771 + _9505;
        if ((object)((uintptr_t)_9506 + (uintptr_t)HIGH_BITS) >= 0){
            _9506 = NewDouble((eudouble)_9506);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16771)) {
            _9506 = NewDouble((eudouble)_free_list_16771 + DBL_PTR(_9505)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9505)) {
                _9506 = NewDouble(DBL_PTR(_free_list_16771)->dbl + (eudouble)_9505);
            }
            else
            _9506 = NewDouble(DBL_PTR(_free_list_16771)->dbl + DBL_PTR(_9505)->dbl);
        }
    }
    DeRef(_9505);
    _9505 = NOVALUE;
    if (IS_ATOM_INT(_9506)) {
        _9507 = _9506 + 4LL;
        if ((object)((uintptr_t)_9507 + (uintptr_t)HIGH_BITS) >= 0){
            _9507 = NewDouble((eudouble)_9507);
        }
    }
    else {
        _9507 = NewDouble(DBL_PTR(_9506)->dbl + (eudouble)4LL);
    }
    DeRef(_9506);
    _9506 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_16849);
    _pos_inlined_seek_at_427_16849 = _9507;
    _9507 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_16849);
    DeRef(_seek_1__tmp_at430_16851);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_427_16849;
    _seek_1__tmp_at430_16851 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_16850 = machine(19LL, _seek_1__tmp_at430_16851);
    DeRef(_pos_inlined_seek_at_427_16849);
    _pos_inlined_seek_at_427_16849 = NOVALUE;
    DeRef(_seek_1__tmp_at430_16851);
    _seek_1__tmp_at430_16851 = NOVALUE;

    /** eds.e:888			if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_16768)) {
        _9508 = (_i_16768 < _free_count_16777);
    }
    else {
        _9508 = (DBL_PTR(_i_16768)->dbl < (eudouble)_free_count_16777);
    }
    if (_9508 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_16766) && IS_ATOM_INT(_psize_16767)) {
        _9510 = _p_16766 + _psize_16767;
        if ((object)((uintptr_t)_9510 + (uintptr_t)HIGH_BITS) >= 0){
            _9510 = NewDouble((eudouble)_9510);
        }
    }
    else {
        if (IS_ATOM_INT(_p_16766)) {
            _9510 = NewDouble((eudouble)_p_16766 + DBL_PTR(_psize_16767)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16767)) {
                _9510 = NewDouble(DBL_PTR(_p_16766)->dbl + (eudouble)_psize_16767);
            }
            else
            _9510 = NewDouble(DBL_PTR(_p_16766)->dbl + DBL_PTR(_psize_16767)->dbl);
        }
    }
    if (IS_ATOM_INT(_9510) && IS_ATOM_INT(_addr_16770)) {
        _9511 = (_9510 == _addr_16770);
    }
    else {
        if (IS_ATOM_INT(_9510)) {
            _9511 = ((eudouble)_9510 == DBL_PTR(_addr_16770)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_16770)) {
                _9511 = (DBL_PTR(_9510)->dbl == (eudouble)_addr_16770);
            }
            else
            _9511 = (DBL_PTR(_9510)->dbl == DBL_PTR(_addr_16770)->dbl);
        }
    }
    DeRef(_9510);
    _9510 = NOVALUE;
    if (_9511 == 0)
    {
        DeRef(_9511);
        _9511 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_9511);
        _9511 = NOVALUE;
    }

    /** eds.e:890				put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_16776) && IS_ATOM_INT(_psize_16767)) {
        _9512 = _prev_size_16776 + _psize_16767;
        if ((object)((uintptr_t)_9512 + (uintptr_t)HIGH_BITS) >= 0){
            _9512 = NewDouble((eudouble)_9512);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_size_16776)) {
            _9512 = NewDouble((eudouble)_prev_size_16776 + DBL_PTR(_psize_16767)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16767)) {
                _9512 = NewDouble(DBL_PTR(_prev_size_16776)->dbl + (eudouble)_psize_16767);
            }
            else
            _9512 = NewDouble(DBL_PTR(_prev_size_16776)->dbl + DBL_PTR(_psize_16767)->dbl);
        }
    }
    if (IS_ATOM_INT(_9512) && IS_ATOM_INT(_size_16769)) {
        _9513 = _9512 + _size_16769;
        if ((object)((uintptr_t)_9513 + (uintptr_t)HIGH_BITS) >= 0){
            _9513 = NewDouble((eudouble)_9513);
        }
    }
    else {
        if (IS_ATOM_INT(_9512)) {
            _9513 = NewDouble((eudouble)_9512 + DBL_PTR(_size_16769)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_16769)) {
                _9513 = NewDouble(DBL_PTR(_9512)->dbl + (eudouble)_size_16769);
            }
            else
            _9513 = NewDouble(DBL_PTR(_9512)->dbl + DBL_PTR(_size_16769)->dbl);
        }
    }
    DeRef(_9512);
    _9512 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_16860);
    _x_inlined_put4_at_479_16860 = _9513;
    _9513 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_16860)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_479_16860;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_479_16860)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_16861);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at482_16861 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at482_16861); // DJP 

    /** eds.e:444	end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_16860);
    _x_inlined_put4_at_479_16860 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_16861);
    _put4_1__tmp_at482_16861 = NOVALUE;

    /** eds.e:891				io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        {
            int128_t p128 = (int128_t)_i_16768 * (int128_t)8LL;
            if( p128 != (int128_t)(_9514 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9514 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9514 = NewDouble(DBL_PTR(_i_16768)->dbl * (eudouble)8LL);
    }
    if (IS_ATOM_INT(_free_list_16771) && IS_ATOM_INT(_9514)) {
        _9515 = _free_list_16771 + _9514;
        if ((object)((uintptr_t)_9515 + (uintptr_t)HIGH_BITS) >= 0){
            _9515 = NewDouble((eudouble)_9515);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16771)) {
            _9515 = NewDouble((eudouble)_free_list_16771 + DBL_PTR(_9514)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9514)) {
                _9515 = NewDouble(DBL_PTR(_free_list_16771)->dbl + (eudouble)_9514);
            }
            else
            _9515 = NewDouble(DBL_PTR(_free_list_16771)->dbl + DBL_PTR(_9514)->dbl);
        }
    }
    DeRef(_9514);
    _9514 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_16865);
    _pos_inlined_seek_at_520_16865 = _9515;
    _9515 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_16865);
    DeRef(_seek_1__tmp_at523_16867);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_520_16865;
    _seek_1__tmp_at523_16867 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_16866 = machine(19LL, _seek_1__tmp_at523_16867);
    DeRef(_pos_inlined_seek_at_520_16865);
    _pos_inlined_seek_at_520_16865 = NOVALUE;
    DeRef(_seek_1__tmp_at523_16867);
    _seek_1__tmp_at523_16867 = NOVALUE;

    /** eds.e:892				remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9516 = _free_count_16777 - _i_16768;
        if ((object)((uintptr_t)_9516 +(uintptr_t) HIGH_BITS) >= 0){
            _9516 = NewDouble((eudouble)_9516);
        }
    }
    else {
        _9516 = NewDouble((eudouble)_free_count_16777 - DBL_PTR(_i_16768)->dbl);
    }
    if (IS_ATOM_INT(_9516)) {
        {
            int128_t p128 = (int128_t)_9516 * (int128_t)8LL;
            if( p128 != (int128_t)(_9517 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9517 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9517 = NewDouble(DBL_PTR(_9516)->dbl * (eudouble)8LL);
    }
    DeRef(_9516);
    _9516 = NOVALUE;
    _0 = _remaining_16778;
    _remaining_16778 = _18get_bytes(_41current_db_16040, _9517);
    DeRef(_0);
    _9517 = NOVALUE;

    /** eds.e:893				io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9519 = _i_16768 - 1LL;
        if ((object)((uintptr_t)_9519 +(uintptr_t) HIGH_BITS) >= 0){
            _9519 = NewDouble((eudouble)_9519);
        }
    }
    else {
        _9519 = NewDouble(DBL_PTR(_i_16768)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9519)) {
        {
            int128_t p128 = (int128_t)_9519 * (int128_t)8LL;
            if( p128 != (int128_t)(_9520 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9520 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9520 = NewDouble(DBL_PTR(_9519)->dbl * (eudouble)8LL);
    }
    DeRef(_9519);
    _9519 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16771) && IS_ATOM_INT(_9520)) {
        _9521 = _free_list_16771 + _9520;
        if ((object)((uintptr_t)_9521 + (uintptr_t)HIGH_BITS) >= 0){
            _9521 = NewDouble((eudouble)_9521);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16771)) {
            _9521 = NewDouble((eudouble)_free_list_16771 + DBL_PTR(_9520)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9520)) {
                _9521 = NewDouble(DBL_PTR(_free_list_16771)->dbl + (eudouble)_9520);
            }
            else
            _9521 = NewDouble(DBL_PTR(_free_list_16771)->dbl + DBL_PTR(_9520)->dbl);
        }
    }
    DeRef(_9520);
    _9520 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_16875);
    _pos_inlined_seek_at_571_16875 = _9521;
    _9521 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_16875);
    DeRef(_seek_1__tmp_at574_16877);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_571_16875;
    _seek_1__tmp_at574_16877 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_16876 = machine(19LL, _seek_1__tmp_at574_16877);
    DeRef(_pos_inlined_seek_at_571_16875);
    _pos_inlined_seek_at_571_16875 = NOVALUE;
    DeRef(_seek_1__tmp_at574_16877);
    _seek_1__tmp_at574_16877 = NOVALUE;

    /** eds.e:894				putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _remaining_16778); // DJP 

    /** eds.e:449	end procedure*/
    goto LC; // [599] 602
LC: 

    /** eds.e:895				free_count -= 1*/
    _free_count_16777 = _free_count_16777 - 1LL;

    /** eds.e:896				io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_16882);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 7LL;
    _seek_1__tmp_at611_16882 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_16881 = machine(19LL, _seek_1__tmp_at611_16882);
    DeRefi(_seek_1__tmp_at611_16882);
    _seek_1__tmp_at611_16882 = NOVALUE;

    /** eds.e:897				put4(free_count)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)_free_count_16777;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_16884);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at626_16884 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at626_16884); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_16884);
    _put4_1__tmp_at626_16884 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** eds.e:899				put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_16776) && IS_ATOM_INT(_psize_16767)) {
        _9523 = _prev_size_16776 + _psize_16767;
        if ((object)((uintptr_t)_9523 + (uintptr_t)HIGH_BITS) >= 0){
            _9523 = NewDouble((eudouble)_9523);
        }
    }
    else {
        if (IS_ATOM_INT(_prev_size_16776)) {
            _9523 = NewDouble((eudouble)_prev_size_16776 + DBL_PTR(_psize_16767)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16767)) {
                _9523 = NewDouble(DBL_PTR(_prev_size_16776)->dbl + (eudouble)_psize_16767);
            }
            else
            _9523 = NewDouble(DBL_PTR(_prev_size_16776)->dbl + DBL_PTR(_psize_16767)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_16888);
    _x_inlined_put4_at_661_16888 = _9523;
    _9523 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_16888)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_661_16888;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_661_16888)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_16889);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at664_16889 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at664_16889); // DJP 

    /** eds.e:444	end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_16888);
    _x_inlined_put4_at_661_16888 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_16889);
    _put4_1__tmp_at664_16889 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** eds.e:901		elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_16768)) {
        _9524 = (_i_16768 < _free_count_16777);
    }
    else {
        _9524 = (DBL_PTR(_i_16768)->dbl < (eudouble)_free_count_16777);
    }
    if (_9524 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_16766) && IS_ATOM_INT(_psize_16767)) {
        _9526 = _p_16766 + _psize_16767;
        if ((object)((uintptr_t)_9526 + (uintptr_t)HIGH_BITS) >= 0){
            _9526 = NewDouble((eudouble)_9526);
        }
    }
    else {
        if (IS_ATOM_INT(_p_16766)) {
            _9526 = NewDouble((eudouble)_p_16766 + DBL_PTR(_psize_16767)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_16767)) {
                _9526 = NewDouble(DBL_PTR(_p_16766)->dbl + (eudouble)_psize_16767);
            }
            else
            _9526 = NewDouble(DBL_PTR(_p_16766)->dbl + DBL_PTR(_psize_16767)->dbl);
        }
    }
    if (IS_ATOM_INT(_9526) && IS_ATOM_INT(_addr_16770)) {
        _9527 = (_9526 == _addr_16770);
    }
    else {
        if (IS_ATOM_INT(_9526)) {
            _9527 = ((eudouble)_9526 == DBL_PTR(_addr_16770)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_16770)) {
                _9527 = (DBL_PTR(_9526)->dbl == (eudouble)_addr_16770);
            }
            else
            _9527 = (DBL_PTR(_9526)->dbl == DBL_PTR(_addr_16770)->dbl);
        }
    }
    DeRef(_9526);
    _9526 = NOVALUE;
    if (_9527 == 0)
    {
        DeRef(_9527);
        _9527 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_9527);
        _9527 = NOVALUE;
    }

    /** eds.e:903			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9528 = _i_16768 - 1LL;
        if ((object)((uintptr_t)_9528 +(uintptr_t) HIGH_BITS) >= 0){
            _9528 = NewDouble((eudouble)_9528);
        }
    }
    else {
        _9528 = NewDouble(DBL_PTR(_i_16768)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9528)) {
        {
            int128_t p128 = (int128_t)_9528 * (int128_t)8LL;
            if( p128 != (int128_t)(_9529 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9529 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9529 = NewDouble(DBL_PTR(_9528)->dbl * (eudouble)8LL);
    }
    DeRef(_9528);
    _9528 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16771) && IS_ATOM_INT(_9529)) {
        _9530 = _free_list_16771 + _9529;
        if ((object)((uintptr_t)_9530 + (uintptr_t)HIGH_BITS) >= 0){
            _9530 = NewDouble((eudouble)_9530);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16771)) {
            _9530 = NewDouble((eudouble)_free_list_16771 + DBL_PTR(_9529)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9529)) {
                _9530 = NewDouble(DBL_PTR(_free_list_16771)->dbl + (eudouble)_9529);
            }
            else
            _9530 = NewDouble(DBL_PTR(_free_list_16771)->dbl + DBL_PTR(_9529)->dbl);
        }
    }
    DeRef(_9529);
    _9529 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_16899);
    _pos_inlined_seek_at_734_16899 = _9530;
    _9530 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_16899);
    DeRef(_seek_1__tmp_at737_16901);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_734_16899;
    _seek_1__tmp_at737_16901 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_16900 = machine(19LL, _seek_1__tmp_at737_16901);
    DeRef(_pos_inlined_seek_at_734_16899);
    _pos_inlined_seek_at_734_16899 = NOVALUE;
    DeRef(_seek_1__tmp_at737_16901);
    _seek_1__tmp_at737_16901 = NOVALUE;

    /** eds.e:904			put4(p)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_p_16766)) {
        *poke4_addr = (uint32_t)_p_16766;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_p_16766)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_16903);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at752_16903 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at752_16903); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_16903);
    _put4_1__tmp_at752_16903 = NOVALUE;

    /** eds.e:905			put4(psize+size)*/
    if (IS_ATOM_INT(_psize_16767) && IS_ATOM_INT(_size_16769)) {
        _9531 = _psize_16767 + _size_16769;
        if ((object)((uintptr_t)_9531 + (uintptr_t)HIGH_BITS) >= 0){
            _9531 = NewDouble((eudouble)_9531);
        }
    }
    else {
        if (IS_ATOM_INT(_psize_16767)) {
            _9531 = NewDouble((eudouble)_psize_16767 + DBL_PTR(_size_16769)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_16769)) {
                _9531 = NewDouble(DBL_PTR(_psize_16767)->dbl + (eudouble)_size_16769);
            }
            else
            _9531 = NewDouble(DBL_PTR(_psize_16767)->dbl + DBL_PTR(_size_16769)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_16906);
    _x_inlined_put4_at_786_16906 = _9531;
    _9531 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_16906)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_786_16906;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_786_16906)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_16907);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at789_16907 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at789_16907); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_16906);
    _x_inlined_put4_at_786_16906 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_16907);
    _put4_1__tmp_at789_16907 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** eds.e:908			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9532 = _i_16768 - 1LL;
        if ((object)((uintptr_t)_9532 +(uintptr_t) HIGH_BITS) >= 0){
            _9532 = NewDouble((eudouble)_9532);
        }
    }
    else {
        _9532 = NewDouble(DBL_PTR(_i_16768)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9532)) {
        {
            int128_t p128 = (int128_t)_9532 * (int128_t)8LL;
            if( p128 != (int128_t)(_9533 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9533 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9533 = NewDouble(DBL_PTR(_9532)->dbl * (eudouble)8LL);
    }
    DeRef(_9532);
    _9532 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16771) && IS_ATOM_INT(_9533)) {
        _9534 = _free_list_16771 + _9533;
        if ((object)((uintptr_t)_9534 + (uintptr_t)HIGH_BITS) >= 0){
            _9534 = NewDouble((eudouble)_9534);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16771)) {
            _9534 = NewDouble((eudouble)_free_list_16771 + DBL_PTR(_9533)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9533)) {
                _9534 = NewDouble(DBL_PTR(_free_list_16771)->dbl + (eudouble)_9533);
            }
            else
            _9534 = NewDouble(DBL_PTR(_free_list_16771)->dbl + DBL_PTR(_9533)->dbl);
        }
    }
    DeRef(_9533);
    _9533 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_16913);
    _pos_inlined_seek_at_834_16913 = _9534;
    _9534 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_16913);
    DeRef(_seek_1__tmp_at837_16915);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_834_16913;
    _seek_1__tmp_at837_16915 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_16914 = machine(19LL, _seek_1__tmp_at837_16915);
    DeRef(_pos_inlined_seek_at_834_16913);
    _pos_inlined_seek_at_834_16913 = NOVALUE;
    DeRef(_seek_1__tmp_at837_16915);
    _seek_1__tmp_at837_16915 = NOVALUE;

    /** eds.e:909			remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9535 = _free_count_16777 - _i_16768;
        if ((object)((uintptr_t)_9535 +(uintptr_t) HIGH_BITS) >= 0){
            _9535 = NewDouble((eudouble)_9535);
        }
    }
    else {
        _9535 = NewDouble((eudouble)_free_count_16777 - DBL_PTR(_i_16768)->dbl);
    }
    if (IS_ATOM_INT(_9535)) {
        _9536 = _9535 + 1;
        if (_9536 > MAXINT){
            _9536 = NewDouble((eudouble)_9536);
        }
    }
    else
    _9536 = binary_op(PLUS, 1, _9535);
    DeRef(_9535);
    _9535 = NOVALUE;
    if (IS_ATOM_INT(_9536)) {
        {
            int128_t p128 = (int128_t)_9536 * (int128_t)8LL;
            if( p128 != (int128_t)(_9537 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9537 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9537 = NewDouble(DBL_PTR(_9536)->dbl * (eudouble)8LL);
    }
    DeRef(_9536);
    _9536 = NOVALUE;
    _0 = _remaining_16778;
    _remaining_16778 = _18get_bytes(_41current_db_16040, _9537);
    DeRef(_0);
    _9537 = NOVALUE;

    /** eds.e:910			free_count += 1*/
    _free_count_16777 = _free_count_16777 + 1;

    /** eds.e:911			io:seek(current_db, FREE_COUNT)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_16923);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 7LL;
    _seek_1__tmp_at883_16923 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_16922 = machine(19LL, _seek_1__tmp_at883_16923);
    DeRefi(_seek_1__tmp_at883_16923);
    _seek_1__tmp_at883_16923 = NOVALUE;

    /** eds.e:912			put4(free_count)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)_free_count_16777;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_16925);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at898_16925 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at898_16925); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_16925);
    _put4_1__tmp_at898_16925 = NOVALUE;

    /** eds.e:913			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_16768)) {
        _9540 = _i_16768 - 1LL;
        if ((object)((uintptr_t)_9540 +(uintptr_t) HIGH_BITS) >= 0){
            _9540 = NewDouble((eudouble)_9540);
        }
    }
    else {
        _9540 = NewDouble(DBL_PTR(_i_16768)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9540)) {
        {
            int128_t p128 = (int128_t)_9540 * (int128_t)8LL;
            if( p128 != (int128_t)(_9541 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9541 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9541 = NewDouble(DBL_PTR(_9540)->dbl * (eudouble)8LL);
    }
    DeRef(_9540);
    _9540 = NOVALUE;
    if (IS_ATOM_INT(_free_list_16771) && IS_ATOM_INT(_9541)) {
        _9542 = _free_list_16771 + _9541;
        if ((object)((uintptr_t)_9542 + (uintptr_t)HIGH_BITS) >= 0){
            _9542 = NewDouble((eudouble)_9542);
        }
    }
    else {
        if (IS_ATOM_INT(_free_list_16771)) {
            _9542 = NewDouble((eudouble)_free_list_16771 + DBL_PTR(_9541)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9541)) {
                _9542 = NewDouble(DBL_PTR(_free_list_16771)->dbl + (eudouble)_9541);
            }
            else
            _9542 = NewDouble(DBL_PTR(_free_list_16771)->dbl + DBL_PTR(_9541)->dbl);
        }
    }
    DeRef(_9541);
    _9541 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_16930);
    _pos_inlined_seek_at_940_16930 = _9542;
    _9542 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_16930);
    DeRef(_seek_1__tmp_at943_16932);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_940_16930;
    _seek_1__tmp_at943_16932 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_16931 = machine(19LL, _seek_1__tmp_at943_16932);
    DeRef(_pos_inlined_seek_at_940_16930);
    _pos_inlined_seek_at_940_16930 = NOVALUE;
    DeRef(_seek_1__tmp_at943_16932);
    _seek_1__tmp_at943_16932 = NOVALUE;

    /** eds.e:914			put4(p)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_p_16766)) {
        *poke4_addr = (uint32_t)_p_16766;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_p_16766)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_16934);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at958_16934 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at958_16934); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_16934);
    _put4_1__tmp_at958_16934 = NOVALUE;

    /** eds.e:915			put4(psize)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_psize_16767)) {
        *poke4_addr = (uint32_t)_psize_16767;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_psize_16767)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_16936);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at986_16936 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at986_16936); // DJP 

    /** eds.e:444	end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_16936);
    _put4_1__tmp_at986_16936 = NOVALUE;

    /** eds.e:916			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _remaining_16778); // DJP 

    /** eds.e:449	end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** eds.e:919		if new_space then*/
    if (_new_space_16773 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_16773) && DBL_PTR(_new_space_16773)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** eds.e:920			db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_16774);
    _41db_free(_to_be_freed_16774);
L17: 

    /** eds.e:922	end procedure*/
    DeRef(_p_16766);
    DeRef(_psize_16767);
    DeRef(_i_16768);
    DeRef(_size_16769);
    DeRef(_addr_16770);
    DeRef(_free_list_16771);
    DeRef(_free_list_space_16772);
    DeRef(_new_space_16773);
    DeRef(_to_be_freed_16774);
    DeRef(_prev_addr_16775);
    DeRef(_prev_size_16776);
    DeRef(_remaining_16778);
    DeRef(_9524);
    _9524 = NOVALUE;
    DeRef(_9500);
    _9500 = NOVALUE;
    DeRef(_9508);
    _9508 = NOVALUE;
    return;
    ;
}


void _41save_keys()
{
    object _k_16941 = NOVALUE;
    object _9549 = NOVALUE;
    object _9545 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:926		if caching_option = 1 then*/

    /** eds.e:927			if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _41current_table_pos_16041, 0LL)){
        goto L1; // [13] 81
    }

    /** eds.e:928				k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_41current_table_pos_16041);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _41current_table_pos_16041;
    _9545 = MAKE_SEQ(_1);
    _k_16941 = find_from(_9545, _41cache_index_16049, 1LL);
    DeRefDS(_9545);
    _9545 = NOVALUE;

    /** eds.e:929				if k != 0 then*/
    if (_k_16941 == 0LL)
    goto L2; // [36] 53

    /** eds.e:930					key_cache[k] = key_pointers*/
    RefDS(_41key_pointers_16047);
    _2 = (object)SEQ_PTR(_41key_cache_16048);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _41key_cache_16048 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _k_16941);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _41key_pointers_16047;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** eds.e:932					key_cache = append(key_cache, key_pointers)*/
    RefDS(_41key_pointers_16047);
    Append(&_41key_cache_16048, _41key_cache_16048, _41key_pointers_16047);

    /** eds.e:933					cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_41current_table_pos_16041);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _41current_table_pos_16041;
    _9549 = MAKE_SEQ(_1);
    RefDS(_9549);
    Append(&_41cache_index_16049, _41cache_index_16049, _9549);
    DeRefDS(_9549);
    _9549 = NOVALUE;
L3: 
L1: 

    /** eds.e:937	end procedure*/
    return;
    ;
}


object _41db_create(object _path_17038, object _lock_method_17039, object _init_tables_17040, object _init_free_17041)
{
    object _db_17042 = NOVALUE;
    object _lock_file_1__tmp_at222_17081 = NOVALUE;
    object _lock_file_inlined_lock_file_at_222_17080 = NOVALUE;
    object _put4_1__tmp_at342_17090 = NOVALUE;
    object _put4_1__tmp_at370_17092 = NOVALUE;
    object _put4_1__tmp_at413_17098 = NOVALUE;
    object _x_inlined_put4_at_410_17097 = NOVALUE;
    object _put4_1__tmp_at452_17103 = NOVALUE;
    object _x_inlined_put4_at_449_17102 = NOVALUE;
    object _put4_1__tmp_at480_17105 = NOVALUE;
    object _s_inlined_putn_at_516_17109 = NOVALUE;
    object _put4_1__tmp_at548_17114 = NOVALUE;
    object _x_inlined_put4_at_545_17113 = NOVALUE;
    object _s_inlined_putn_at_584_17118 = NOVALUE;
    object _9647 = NOVALUE;
    object _9646 = NOVALUE;
    object _9645 = NOVALUE;
    object _9644 = NOVALUE;
    object _9643 = NOVALUE;
    object _9642 = NOVALUE;
    object _9641 = NOVALUE;
    object _9640 = NOVALUE;
    object _9639 = NOVALUE;
    object _9638 = NOVALUE;
    object _9637 = NOVALUE;
    object _9620 = NOVALUE;
    object _9618 = NOVALUE;
    object _9617 = NOVALUE;
    object _9615 = NOVALUE;
    object _9614 = NOVALUE;
    object _9612 = NOVALUE;
    object _9611 = NOVALUE;
    object _9609 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1133		db = find(path, Known_Aliases)*/
    _db_17042 = find_from(_path_17038, _41Known_Aliases_16061, 1LL);

    /** eds.e:1134		if db then*/
    if (_db_17042 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** eds.e:1136			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9609 = (object)*(((s1_ptr)_2)->base + _db_17042);
    DeRefDS(_path_17038);
    _2 = (object)SEQ_PTR(_9609);
    _path_17038 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_path_17038);
    _9609 = NOVALUE;

    /** eds.e:1137			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9611 = (object)*(((s1_ptr)_2)->base + _db_17042);
    _2 = (object)SEQ_PTR(_9611);
    _9612 = (object)*(((s1_ptr)_2)->base + 2LL);
    _9611 = NOVALUE;
    _2 = (object)SEQ_PTR(_9612);
    _lock_method_17039 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_lock_method_17039)){
        _lock_method_17039 = (object)DBL_PTR(_lock_method_17039)->dbl;
    }
    _9612 = NOVALUE;

    /** eds.e:1138			init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9614 = (object)*(((s1_ptr)_2)->base + _db_17042);
    _2 = (object)SEQ_PTR(_9614);
    _9615 = (object)*(((s1_ptr)_2)->base + 2LL);
    _9614 = NOVALUE;
    _2 = (object)SEQ_PTR(_9615);
    _init_tables_17040 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_init_tables_17040)){
        _init_tables_17040 = (object)DBL_PTR(_init_tables_17040)->dbl;
    }
    _9615 = NOVALUE;

    /** eds.e:1139			init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9617 = (object)*(((s1_ptr)_2)->base + _db_17042);
    _2 = (object)SEQ_PTR(_9617);
    _9618 = (object)*(((s1_ptr)_2)->base + 2LL);
    _9617 = NOVALUE;
    _2 = (object)SEQ_PTR(_9618);
    _init_free_17041 = (object)*(((s1_ptr)_2)->base + 3LL);
    if (!IS_ATOM_INT(_init_free_17041)){
        _init_free_17041 = (object)DBL_PTR(_init_free_17041)->dbl;
    }
    _9618 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** eds.e:1141			path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_17038);
    RefDS(_9603);
    _9620 = _15defaultext(_path_17038, _9603);
    _0 = _path_17038;
    _path_17038 = _15canonical_path(_9620, 0LL, 0LL);
    DeRefDS(_0);
    _9620 = NOVALUE;

    /** eds.e:1143			if init_tables < 1 then*/
    if (_init_tables_17040 >= 1LL)
    goto L3; // [111] 121

    /** eds.e:1144				init_tables = 1*/
    _init_tables_17040 = 1LL;
L3: 

    /** eds.e:1147			if init_free < 0 then*/
    if (_init_free_17041 >= 0LL)
    goto L4; // [123] 133

    /** eds.e:1148				init_free = 0*/
    _init_free_17041 = 0LL;
L4: 
L2: 

    /** eds.e:1154		db = open(path, "rb")*/
    _db_17042 = EOpen(_path_17038, _8900, 0LL);

    /** eds.e:1155		if db != -1 then*/
    if (_db_17042 == -1LL)
    goto L5; // [143] 158

    /** eds.e:1157			close(db)*/
    EClose(_db_17042);

    /** eds.e:1158			return DB_EXISTS_ALREADY*/
    DeRefDS(_path_17038);
    return -2LL;
L5: 

    /** eds.e:1162		db = open(path, "wb")*/
    _db_17042 = EOpen(_path_17038, _9029, 0LL);

    /** eds.e:1163		if db = -1 then*/
    if (_db_17042 != -1LL)
    goto L6; // [167] 178

    /** eds.e:1164			return DB_OPEN_FAIL*/
    DeRefDS(_path_17038);
    return -1LL;
L6: 

    /** eds.e:1166		close(db)*/
    EClose(_db_17042);

    /** eds.e:1169		db = open(path, "ub")*/
    _db_17042 = EOpen(_path_17038, _9628, 0LL);

    /** eds.e:1170		if db = -1 then*/
    if (_db_17042 != -1LL)
    goto L7; // [191] 202

    /** eds.e:1171			return DB_OPEN_FAIL*/
    DeRefDS(_path_17038);
    return -1LL;
L7: 

    /** eds.e:1173		if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17039 != 1LL)
    goto L8; // [204] 214

    /** eds.e:1175			lock_method = DB_LOCK_NO*/
    _lock_method_17039 = 0LL;
L8: 

    /** eds.e:1177		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17039 != 2LL)
    goto L9; // [216] 248

    /** eds.e:1178			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_17081;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17042;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at222_17081 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_17080 = machine(61LL, _lock_file_1__tmp_at222_17081);
    DeRef(_lock_file_1__tmp_at222_17081);
    _lock_file_1__tmp_at222_17081 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_17080 != 0)
    goto LA; // [237] 247

    /** eds.e:1179				return DB_LOCK_FAIL*/
    DeRefDS(_path_17038);
    return -3LL;
LA: 
L9: 

    /** eds.e:1182		save_keys()*/
    _41save_keys();

    /** eds.e:1183		current_db = db*/
    _41current_db_16040 = _db_17042;

    /** eds.e:1184		current_lock = lock_method*/
    _41current_lock_16046 = _lock_method_17039;

    /** eds.e:1185		current_table_pos = -1*/
    DeRef(_41current_table_pos_16041);
    _41current_table_pos_16041 = -1LL;

    /** eds.e:1186		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_16042);
    _41current_table_name_16042 = _5;

    /** eds.e:1187		db_names = append(db_names, path)*/
    RefDS(_path_17038);
    Append(&_41db_names_16043, _41db_names_16043, _path_17038);

    /** eds.e:1188		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_41db_lock_methods_16045, _41db_lock_methods_16045, _lock_method_17039);

    /** eds.e:1189		db_file_nums = append(db_file_nums, db)*/
    Append(&_41db_file_nums_16044, _41db_file_nums_16044, _db_17042);

    /** eds.e:1192		put1(DB_MAGIC) -- so we know what type of file it is*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_16040, 77LL); // DJP 

    /** eds.e:434	end procedure*/
    goto LB; // [309] 312
LB: 

    /** eds.e:1193		put1(DB_MAJOR) -- major version*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_16040, 4LL); // DJP 

    /** eds.e:434	end procedure*/
    goto LC; // [323] 326
LC: 

    /** eds.e:1194		put1(DB_MINOR) -- minor version*/

    /** eds.e:433		puts(current_db, x)*/
    EPuts(_41current_db_16040, 0LL); // DJP 

    /** eds.e:434	end procedure*/
    goto LD; // [337] 340
LD: 

    /** eds.e:1196		put4(19)  -- pointer to tables*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)19LL;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_17090);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at342_17090 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at342_17090); // DJP 

    /** eds.e:444	end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_17090);
    _put4_1__tmp_at342_17090 = NOVALUE;

    /** eds.e:1198		put4(0)   -- number of free blocks*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)0LL;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_17092);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at370_17092 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at370_17092); // DJP 

    /** eds.e:444	end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_17092);
    _put4_1__tmp_at370_17092 = NOVALUE;

    /** eds.e:1200		put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    {
        int128_t p128 = (int128_t)_init_tables_17040 * (int128_t)16LL;
        if( p128 != (int128_t)(_9637 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9637 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_9637)) {
        _9638 = 23LL + _9637;
        if ((object)((uintptr_t)_9638 + (uintptr_t)HIGH_BITS) >= 0){
            _9638 = NewDouble((eudouble)_9638);
        }
    }
    else {
        _9638 = NewDouble((eudouble)23LL + DBL_PTR(_9637)->dbl);
    }
    DeRef(_9637);
    _9637 = NOVALUE;
    if (IS_ATOM_INT(_9638)) {
        _9639 = _9638 + 4LL;
        if ((object)((uintptr_t)_9639 + (uintptr_t)HIGH_BITS) >= 0){
            _9639 = NewDouble((eudouble)_9639);
        }
    }
    else {
        _9639 = NewDouble(DBL_PTR(_9638)->dbl + (eudouble)4LL);
    }
    DeRef(_9638);
    _9638 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_17097);
    _x_inlined_put4_at_410_17097 = _9639;
    _9639 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_17097)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_410_17097;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_410_17097)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_17098);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at413_17098 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at413_17098); // DJP 

    /** eds.e:444	end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_17097);
    _x_inlined_put4_at_410_17097 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_17098);
    _put4_1__tmp_at413_17098 = NOVALUE;

    /** eds.e:1202		put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    {
        int128_t p128 = (int128_t)_init_tables_17040 * (int128_t)16LL;
        if( p128 != (int128_t)(_9640 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9640 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_9640)) {
        _9641 = 8LL + _9640;
        if ((object)((uintptr_t)_9641 + (uintptr_t)HIGH_BITS) >= 0){
            _9641 = NewDouble((eudouble)_9641);
        }
    }
    else {
        _9641 = NewDouble((eudouble)8LL + DBL_PTR(_9640)->dbl);
    }
    DeRef(_9640);
    _9640 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_17102);
    _x_inlined_put4_at_449_17102 = _9641;
    _9641 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_17102)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_449_17102;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_449_17102)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_17103);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at452_17103 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at452_17103); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_17102);
    _x_inlined_put4_at_449_17102 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_17103);
    _put4_1__tmp_at452_17103 = NOVALUE;

    /** eds.e:1204		put4(0)   -- number of tables that currently exist*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)0LL;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_17105);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at480_17105 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at480_17105); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_17105);
    _put4_1__tmp_at480_17105 = NOVALUE;

    /** eds.e:1206		putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _9642 = _init_tables_17040 * 16LL;
    _9643 = Repeat(0LL, _9642);
    _9642 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_17109);
    _s_inlined_putn_at_516_17109 = _9643;
    _9643 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_516_17109); // DJP 

    /** eds.e:449	end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_17109);
    _s_inlined_putn_at_516_17109 = NOVALUE;

    /** eds.e:1208		put4(4+init_free*8)   -- allocated size*/
    {
        int128_t p128 = (int128_t)_init_free_17041 * (int128_t)8LL;
        if( p128 != (int128_t)(_9644 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9644 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_9644)) {
        _9645 = 4LL + _9644;
        if ((object)((uintptr_t)_9645 + (uintptr_t)HIGH_BITS) >= 0){
            _9645 = NewDouble((eudouble)_9645);
        }
    }
    else {
        _9645 = NewDouble((eudouble)4LL + DBL_PTR(_9644)->dbl);
    }
    DeRef(_9644);
    _9644 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_17113);
    _x_inlined_put4_at_545_17113 = _9645;
    _9645 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_17113)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_545_17113;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_545_17113)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_17114);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at548_17114 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at548_17114); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_17113);
    _x_inlined_put4_at_545_17113 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_17114);
    _put4_1__tmp_at548_17114 = NOVALUE;

    /** eds.e:1209		putn(repeat(0, init_free * 8))*/
    _9646 = _init_free_17041 * 8LL;
    _9647 = Repeat(0LL, _9646);
    _9646 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_17118);
    _s_inlined_putn_at_584_17118 = _9647;
    _9647 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_584_17118); // DJP 

    /** eds.e:449	end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_17118);
    _s_inlined_putn_at_584_17118 = NOVALUE;

    /** eds.e:1210		return DB_OK*/
    DeRefDS(_path_17038);
    return 0LL;
    ;
}


object _41db_open(object _path_17121, object _lock_method_17122)
{
    object _db_17123 = NOVALUE;
    object _magic_17124 = NOVALUE;
    object _lock_file_1__tmp_at141_17151 = NOVALUE;
    object _lock_file_inlined_lock_file_at_141_17150 = NOVALUE;
    object _lock_file_1__tmp_at181_17158 = NOVALUE;
    object _lock_file_inlined_lock_file_at_181_17157 = NOVALUE;
    object _9658 = NOVALUE;
    object _9656 = NOVALUE;
    object _9654 = NOVALUE;
    object _9652 = NOVALUE;
    object _9651 = NOVALUE;
    object _9649 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1273		db = find(path, Known_Aliases)*/
    _db_17123 = find_from(_path_17121, _41Known_Aliases_16061, 1LL);

    /** eds.e:1274		if db then*/
    if (_db_17123 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1276			path = Alias_Details[db][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9649 = (object)*(((s1_ptr)_2)->base + _db_17123);
    DeRefDS(_path_17121);
    _2 = (object)SEQ_PTR(_9649);
    _path_17121 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_path_17121);
    _9649 = NOVALUE;

    /** eds.e:1277			lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9651 = (object)*(((s1_ptr)_2)->base + _db_17123);
    _2 = (object)SEQ_PTR(_9651);
    _9652 = (object)*(((s1_ptr)_2)->base + 2LL);
    _9651 = NOVALUE;
    _2 = (object)SEQ_PTR(_9652);
    _lock_method_17122 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_lock_method_17122)){
        _lock_method_17122 = (object)DBL_PTR(_lock_method_17122)->dbl;
    }
    _9652 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1279			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17121);
    RefDS(_9603);
    _9654 = _15defaultext(_path_17121, _9603);
    _0 = _path_17121;
    _path_17121 = _15canonical_path(_9654, 0LL, 0LL);
    DeRefDS(_0);
    _9654 = NOVALUE;
L2: 

    /** eds.e:1282		if lock_method = DB_LOCK_NO or*/
    _9656 = (_lock_method_17122 == 0LL);
    if (_9656 != 0) {
        goto L3; // [76] 89
    }
    _9658 = (_lock_method_17122 == 2LL);
    if (_9658 == 0)
    {
        DeRef(_9658);
        _9658 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_9658);
        _9658 = NOVALUE;
    }
L3: 

    /** eds.e:1285			db = open(path, "ub")*/
    _db_17123 = EOpen(_path_17121, _9628, 0LL);
    goto L5; // [96] 107
L4: 

    /** eds.e:1288			db = open(path, "rb")*/
    _db_17123 = EOpen(_path_17121, _8900, 0LL);
L5: 

    /** eds.e:1291	ifdef WINDOWS then*/

    /** eds.e:1292		if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17122 != 1LL)
    goto L6; // [111] 121

    /** eds.e:1293			lock_method = DB_LOCK_EXCLUSIVE*/
    _lock_method_17122 = 2LL;
L6: 

    /** eds.e:1298		if db = -1 then*/
    if (_db_17123 != -1LL)
    goto L7; // [123] 134

    /** eds.e:1299			return DB_OPEN_FAIL*/
    DeRefDS(_path_17121);
    DeRef(_9656);
    _9656 = NOVALUE;
    return -1LL;
L7: 

    /** eds.e:1301		if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_17122 != 2LL)
    goto L8; // [136] 174

    /** eds.e:1302			if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at141_17151;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17123;
    ((intptr_t*)_2)[2] = 2LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at141_17151 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_141_17150 = machine(61LL, _lock_file_1__tmp_at141_17151);
    DeRef(_lock_file_1__tmp_at141_17151);
    _lock_file_1__tmp_at141_17151 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_141_17150 != 0)
    goto L9; // [157] 213

    /** eds.e:1303				close(db)*/
    EClose(_db_17123);

    /** eds.e:1304				return DB_LOCK_FAIL*/
    DeRefDS(_path_17121);
    DeRef(_9656);
    _9656 = NOVALUE;
    return -3LL;
    goto L9; // [171] 213
L8: 

    /** eds.e:1306		elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_17122 != 1LL)
    goto LA; // [176] 212

    /** eds.e:1307			if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** io.e:1055		return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at181_17158;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _db_17123;
    ((intptr_t*)_2)[2] = 1LL;
    RefDS(_5);
    ((intptr_t*)_2)[3] = _5;
    _lock_file_1__tmp_at181_17158 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_181_17157 = machine(61LL, _lock_file_1__tmp_at181_17158);
    DeRef(_lock_file_1__tmp_at181_17158);
    _lock_file_1__tmp_at181_17158 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_181_17157 != 0)
    goto LB; // [197] 211

    /** eds.e:1308				close(db)*/
    EClose(_db_17123);

    /** eds.e:1309				return DB_LOCK_FAIL*/
    DeRefDS(_path_17121);
    DeRef(_9656);
    _9656 = NOVALUE;
    return -3LL;
LB: 
LA: 
L9: 

    /** eds.e:1312		magic = getc(db)*/
    if (_db_17123 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_17123, EF_READ);
        last_r_file_no = _db_17123;
    }
    if (last_r_file_ptr == xstdin) {
        show_console();
        if (in_from_keyb) {
            _magic_17124 = getKBchar();
        }
        else{
            _magic_17124 = getc(last_r_file_ptr);
        }
    }
    else{
        _magic_17124 = getc(last_r_file_ptr);
    }

    /** eds.e:1313		if magic != DB_MAGIC then*/
    if (_magic_17124 == 77LL)
    goto LC; // [220] 235

    /** eds.e:1314			close(db)*/
    EClose(_db_17123);

    /** eds.e:1315			return DB_OPEN_FAIL*/
    DeRefDS(_path_17121);
    DeRef(_9656);
    _9656 = NOVALUE;
    return -1LL;
LC: 

    /** eds.e:1317		save_keys()*/
    _41save_keys();

    /** eds.e:1318		current_db = db */
    _41current_db_16040 = _db_17123;

    /** eds.e:1319		current_table_pos = -1*/
    DeRef(_41current_table_pos_16041);
    _41current_table_pos_16041 = -1LL;

    /** eds.e:1320		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_16042);
    _41current_table_name_16042 = _5;

    /** eds.e:1321		current_lock = lock_method*/
    _41current_lock_16046 = _lock_method_17122;

    /** eds.e:1322		db_names = append(db_names, path)*/
    RefDS(_path_17121);
    Append(&_41db_names_16043, _41db_names_16043, _path_17121);

    /** eds.e:1323		db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_41db_lock_methods_16045, _41db_lock_methods_16045, _lock_method_17122);

    /** eds.e:1324		db_file_nums = append(db_file_nums, db)*/
    Append(&_41db_file_nums_16044, _41db_file_nums_16044, _db_17123);

    /** eds.e:1325		return DB_OK*/
    DeRefDS(_path_17121);
    DeRef(_9656);
    _9656 = NOVALUE;
    return 0LL;
    ;
}


object _41db_select(object _path_17168, object _lock_method_17169)
{
    object _index_17170 = NOVALUE;
    object _9678 = NOVALUE;
    object _9676 = NOVALUE;
    object _9675 = NOVALUE;
    object _9673 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1372		index = find(path, Known_Aliases)*/
    _index_17170 = find_from(_path_17168, _41Known_Aliases_16061, 1LL);

    /** eds.e:1373		if index then*/
    if (_index_17170 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** eds.e:1375			path = Alias_Details[index][1]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9673 = (object)*(((s1_ptr)_2)->base + _index_17170);
    DeRefDS(_path_17168);
    _2 = (object)SEQ_PTR(_9673);
    _path_17168 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_path_17168);
    _9673 = NOVALUE;

    /** eds.e:1376			lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (object)SEQ_PTR(_41Alias_Details_16062);
    _9675 = (object)*(((s1_ptr)_2)->base + _index_17170);
    _2 = (object)SEQ_PTR(_9675);
    _9676 = (object)*(((s1_ptr)_2)->base + 2LL);
    _9675 = NOVALUE;
    _2 = (object)SEQ_PTR(_9676);
    _lock_method_17169 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_lock_method_17169)){
        _lock_method_17169 = (object)DBL_PTR(_lock_method_17169)->dbl;
    }
    _9676 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** eds.e:1378			path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_17168);
    RefDS(_9603);
    _9678 = _15defaultext(_path_17168, _9603);
    _0 = _path_17168;
    _path_17168 = _15canonical_path(_9678, 0LL, 0LL);
    DeRefDS(_0);
    _9678 = NOVALUE;
L2: 

    /** eds.e:1381		index = eu:find(path, db_names)*/
    _index_17170 = find_from(_path_17168, _41db_names_16043, 1LL);

    /** eds.e:1382		if index = 0 then*/
    if (_index_17170 != 0LL)
    goto L3; // [81] 130

    /** eds.e:1383			if lock_method = -1 then*/
    if (_lock_method_17169 != -1LL)
    goto L4; // [87] 98

    /** eds.e:1384				return DB_OPEN_FAIL*/
    DeRefDS(_path_17168);
    return -1LL;
L4: 

    /** eds.e:1386			index = db_open(path, lock_method)*/
    RefDS(_path_17168);
    _index_17170 = _41db_open(_path_17168, _lock_method_17169);
    if (!IS_ATOM_INT(_index_17170)) {
        _1 = (object)(DBL_PTR(_index_17170)->dbl);
        DeRefDS(_index_17170);
        _index_17170 = _1;
    }

    /** eds.e:1387			if index != DB_OK then*/
    if (_index_17170 == 0LL)
    goto L5; // [109] 120

    /** eds.e:1388				return index*/
    DeRefDS(_path_17168);
    return _index_17170;
L5: 

    /** eds.e:1390			index = eu:find(path, db_names)*/
    _index_17170 = find_from(_path_17168, _41db_names_16043, 1LL);
L3: 

    /** eds.e:1392		save_keys()*/
    _41save_keys();

    /** eds.e:1393		current_db = db_file_nums[index]*/
    _2 = (object)SEQ_PTR(_41db_file_nums_16044);
    _41current_db_16040 = (object)*(((s1_ptr)_2)->base + _index_17170);
    if (!IS_ATOM_INT(_41current_db_16040))
    _41current_db_16040 = (object)DBL_PTR(_41current_db_16040)->dbl;

    /** eds.e:1394		current_lock = db_lock_methods[index]*/
    _2 = (object)SEQ_PTR(_41db_lock_methods_16045);
    _41current_lock_16046 = (object)*(((s1_ptr)_2)->base + _index_17170);
    if (!IS_ATOM_INT(_41current_lock_16046))
    _41current_lock_16046 = (object)DBL_PTR(_41current_lock_16046)->dbl;

    /** eds.e:1395		current_table_pos = -1*/
    DeRef(_41current_table_pos_16041);
    _41current_table_pos_16041 = -1LL;

    /** eds.e:1396		current_table_name = ""*/
    RefDS(_5);
    DeRef(_41current_table_name_16042);
    _41current_table_name_16042 = _5;

    /** eds.e:1397		key_pointers = {}*/
    RefDS(_5);
    DeRef(_41key_pointers_16047);
    _41key_pointers_16047 = _5;

    /** eds.e:1398		return DB_OK*/
    DeRefDS(_path_17168);
    return 0LL;
    ;
}


void _41db_close()
{
    object _unlock_file_1__tmp_at25_17199 = NOVALUE;
    object _index_17194 = NOVALUE;
    object _9695 = NOVALUE;
    object _9694 = NOVALUE;
    object _9693 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1413		if current_db = -1 then*/
    if (_41current_db_16040 != -1LL)
    goto L1; // [5] 15

    /** eds.e:1414			return*/
    return;
L1: 

    /** eds.e:1417		if current_lock then*/
    if (_41current_lock_16046 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** eds.e:1418			io:unlock_file(current_db, {})*/

    /** io.e:1086		machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_17199);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_17199 = MAKE_SEQ(_1);
    machine(62LL, _unlock_file_1__tmp_at25_17199);

    /** io.e:1087	end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_17199);
    _unlock_file_1__tmp_at25_17199 = NOVALUE;
L2: 

    /** eds.e:1420		close(current_db)*/
    EClose(_41current_db_16040);

    /** eds.e:1422		index = eu:find(current_db, db_file_nums)*/
    _index_17194 = find_from(_41current_db_16040, _41db_file_nums_16044, 1LL);

    /** eds.e:1423		db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_names_16043);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17194)) ? _index_17194 : (object)(DBL_PTR(_index_17194)->dbl);
        int stop = (IS_ATOM_INT(_index_17194)) ? _index_17194 : (object)(DBL_PTR(_index_17194)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_names_16043), start, &_41db_names_16043 );
            }
            else Tail(SEQ_PTR(_41db_names_16043), stop+1, &_41db_names_16043);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_names_16043), start, &_41db_names_16043);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_names_16043 = Remove_elements(start, stop, (SEQ_PTR(_41db_names_16043)->ref == 1));
        }
    }

    /** eds.e:1424		db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_file_nums_16044);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17194)) ? _index_17194 : (object)(DBL_PTR(_index_17194)->dbl);
        int stop = (IS_ATOM_INT(_index_17194)) ? _index_17194 : (object)(DBL_PTR(_index_17194)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_file_nums_16044), start, &_41db_file_nums_16044 );
            }
            else Tail(SEQ_PTR(_41db_file_nums_16044), stop+1, &_41db_file_nums_16044);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_file_nums_16044), start, &_41db_file_nums_16044);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_file_nums_16044 = Remove_elements(start, stop, (SEQ_PTR(_41db_file_nums_16044)->ref == 1));
        }
    }

    /** eds.e:1425		db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_41db_lock_methods_16045);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_17194)) ? _index_17194 : (object)(DBL_PTR(_index_17194)->dbl);
        int stop = (IS_ATOM_INT(_index_17194)) ? _index_17194 : (object)(DBL_PTR(_index_17194)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41db_lock_methods_16045), start, &_41db_lock_methods_16045 );
            }
            else Tail(SEQ_PTR(_41db_lock_methods_16045), stop+1, &_41db_lock_methods_16045);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41db_lock_methods_16045), start, &_41db_lock_methods_16045);
        }
        else {
            assign_slice_seq = &assign_space;
            _41db_lock_methods_16045 = Remove_elements(start, stop, (SEQ_PTR(_41db_lock_methods_16045)->ref == 1));
        }
    }

    /** eds.e:1427		for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_41cache_index_16049)){
            _9693 = SEQ_PTR(_41cache_index_16049)->length;
    }
    else {
        _9693 = 1;
    }
    {
        object _i_17205;
        _i_17205 = _9693;
L4: 
        if (_i_17205 < 1LL){
            goto L5; // [94] 145
        }

        /** eds.e:1428			if cache_index[i][1] = current_db then*/
        _2 = (object)SEQ_PTR(_41cache_index_16049);
        _9694 = (object)*(((s1_ptr)_2)->base + _i_17205);
        _2 = (object)SEQ_PTR(_9694);
        _9695 = (object)*(((s1_ptr)_2)->base + 1LL);
        _9694 = NOVALUE;
        if (binary_op_a(NOTEQ, _9695, _41current_db_16040)){
            _9695 = NOVALUE;
            goto L6; // [115] 138
        }
        _9695 = NOVALUE;

        /** eds.e:1429				cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_41cache_index_16049);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17205)) ? _i_17205 : (object)(DBL_PTR(_i_17205)->dbl);
            int stop = (IS_ATOM_INT(_i_17205)) ? _i_17205 : (object)(DBL_PTR(_i_17205)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_41cache_index_16049), start, &_41cache_index_16049 );
                }
                else Tail(SEQ_PTR(_41cache_index_16049), stop+1, &_41cache_index_16049);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_41cache_index_16049), start, &_41cache_index_16049);
            }
            else {
                assign_slice_seq = &assign_space;
                _41cache_index_16049 = Remove_elements(start, stop, (SEQ_PTR(_41cache_index_16049)->ref == 1));
            }
        }

        /** eds.e:1430				key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_41key_cache_16048);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_17205)) ? _i_17205 : (object)(DBL_PTR(_i_17205)->dbl);
            int stop = (IS_ATOM_INT(_i_17205)) ? _i_17205 : (object)(DBL_PTR(_i_17205)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<1) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_41key_cache_16048), start, &_41key_cache_16048 );
                }
                else Tail(SEQ_PTR(_41key_cache_16048), stop+1, &_41key_cache_16048);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_41key_cache_16048), start, &_41key_cache_16048);
            }
            else {
                assign_slice_seq = &assign_space;
                _41key_cache_16048 = Remove_elements(start, stop, (SEQ_PTR(_41key_cache_16048)->ref == 1));
            }
        }
L6: 

        /** eds.e:1432		end for*/
        _i_17205 = _i_17205 + -1LL;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** eds.e:1433		current_table_pos = -1*/
    DeRef(_41current_table_pos_16041);
    _41current_table_pos_16041 = -1LL;

    /** eds.e:1434		current_table_name = ""	*/
    RefDS(_5);
    DeRef(_41current_table_name_16042);
    _41current_table_name_16042 = _5;

    /** eds.e:1435		current_db = -1*/
    _41current_db_16040 = -1LL;

    /** eds.e:1436		key_pointers = {}*/
    RefDS(_5);
    DeRef(_41key_pointers_16047);
    _41key_pointers_16047 = _5;

    /** eds.e:1437	end procedure*/
    return;
    ;
}


object _41table_find(object _name_17215)
{
    object _tables_17216 = NOVALUE;
    object _nt_17217 = NOVALUE;
    object _t_header_17218 = NOVALUE;
    object _name_ptr_17219 = NOVALUE;
    object _seek_1__tmp_at6_17222 = NOVALUE;
    object _seek_inlined_seek_at_6_17221 = NOVALUE;
    object _seek_1__tmp_at44_17229 = NOVALUE;
    object _seek_inlined_seek_at_44_17228 = NOVALUE;
    object _seek_1__tmp_at84_17237 = NOVALUE;
    object _seek_inlined_seek_at_84_17236 = NOVALUE;
    object _seek_1__tmp_at106_17241 = NOVALUE;
    object _seek_inlined_seek_at_106_17240 = NOVALUE;
    object _9706 = NOVALUE;
    object _9704 = NOVALUE;
    object _9699 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1446		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_17222);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 3LL;
    _seek_1__tmp_at6_17222 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_17221 = machine(19LL, _seek_1__tmp_at6_17222);
    DeRefi(_seek_1__tmp_at6_17222);
    _seek_1__tmp_at6_17222 = NOVALUE;

    /** eds.e:1447		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_41vLastErrors_16064)){
            _9699 = SEQ_PTR(_41vLastErrors_16064)->length;
    }
    else {
        _9699 = 1;
    }
    if (_9699 <= 0LL)
    goto L1; // [27] 36
    DeRefDS(_name_17215);
    DeRef(_tables_17216);
    DeRef(_nt_17217);
    DeRef(_t_header_17218);
    DeRef(_name_ptr_17219);
    return -1LL;
L1: 

    /** eds.e:1448		tables = get4()*/
    _0 = _tables_17216;
    _tables_17216 = _41get4();
    DeRef(_0);

    /** eds.e:1449		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17216);
    DeRef(_seek_1__tmp_at44_17229);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _tables_17216;
    _seek_1__tmp_at44_17229 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_17228 = machine(19LL, _seek_1__tmp_at44_17229);
    DeRef(_seek_1__tmp_at44_17229);
    _seek_1__tmp_at44_17229 = NOVALUE;

    /** eds.e:1450		nt = get4()*/
    _0 = _nt_17217;
    _nt_17217 = _41get4();
    DeRef(_0);

    /** eds.e:1451		t_header = tables+4*/
    DeRef(_t_header_17218);
    if (IS_ATOM_INT(_tables_17216)) {
        _t_header_17218 = _tables_17216 + 4LL;
        if ((object)((uintptr_t)_t_header_17218 + (uintptr_t)HIGH_BITS) >= 0){
            _t_header_17218 = NewDouble((eudouble)_t_header_17218);
        }
    }
    else {
        _t_header_17218 = NewDouble(DBL_PTR(_tables_17216)->dbl + (eudouble)4LL);
    }

    /** eds.e:1452		for i = 1 to nt do*/
    Ref(_nt_17217);
    DeRef(_9704);
    _9704 = _nt_17217;
    {
        object _i_17233;
        _i_17233 = 1LL;
L2: 
        if (binary_op_a(GREATER, _i_17233, _9704)){
            goto L3; // [74] 150
        }

        /** eds.e:1453			io:seek(current_db, t_header)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_17218);
        DeRef(_seek_1__tmp_at84_17237);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _t_header_17218;
        _seek_1__tmp_at84_17237 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_17236 = machine(19LL, _seek_1__tmp_at84_17237);
        DeRef(_seek_1__tmp_at84_17237);
        _seek_1__tmp_at84_17237 = NOVALUE;

        /** eds.e:1454			name_ptr = get4()*/
        _0 = _name_ptr_17219;
        _name_ptr_17219 = _41get4();
        DeRef(_0);

        /** eds.e:1455			io:seek(current_db, name_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_17219);
        DeRef(_seek_1__tmp_at106_17241);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _name_ptr_17219;
        _seek_1__tmp_at106_17241 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_17240 = machine(19LL, _seek_1__tmp_at106_17241);
        DeRef(_seek_1__tmp_at106_17241);
        _seek_1__tmp_at106_17241 = NOVALUE;

        /** eds.e:1456			if equal_string(name) > 0 then*/
        RefDS(_name_17215);
        _9706 = _41equal_string(_name_17215);
        if (binary_op_a(LESSEQ, _9706, 0LL)){
            DeRef(_9706);
            _9706 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_9706);
        _9706 = NOVALUE;

        /** eds.e:1458				return t_header*/
        DeRef(_i_17233);
        DeRefDS(_name_17215);
        DeRef(_tables_17216);
        DeRef(_nt_17217);
        DeRef(_name_ptr_17219);
        return _t_header_17218;
L4: 

        /** eds.e:1460			t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_17218;
        if (IS_ATOM_INT(_t_header_17218)) {
            _t_header_17218 = _t_header_17218 + 16LL;
            if ((object)((uintptr_t)_t_header_17218 + (uintptr_t)HIGH_BITS) >= 0){
                _t_header_17218 = NewDouble((eudouble)_t_header_17218);
            }
        }
        else {
            _t_header_17218 = NewDouble(DBL_PTR(_t_header_17218)->dbl + (eudouble)16LL);
        }
        DeRef(_0);

        /** eds.e:1461		end for*/
        _0 = _i_17233;
        if (IS_ATOM_INT(_i_17233)) {
            _i_17233 = _i_17233 + 1LL;
            if ((object)((uintptr_t)_i_17233 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17233 = NewDouble((eudouble)_i_17233);
            }
        }
        else {
            _i_17233 = binary_op_a(PLUS, _i_17233, 1LL);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_17233);
    }

    /** eds.e:1462		return -1*/
    DeRefDS(_name_17215);
    DeRef(_tables_17216);
    DeRef(_nt_17217);
    DeRef(_t_header_17218);
    DeRef(_name_ptr_17219);
    return -1LL;
    ;
}


object _41db_select_table(object _name_17248)
{
    object _table_17249 = NOVALUE;
    object _nkeys_17250 = NOVALUE;
    object _index_17251 = NOVALUE;
    object _block_ptr_17252 = NOVALUE;
    object _block_size_17253 = NOVALUE;
    object _blocks_17254 = NOVALUE;
    object _k_17255 = NOVALUE;
    object _seek_1__tmp_at120_17274 = NOVALUE;
    object _seek_inlined_seek_at_120_17273 = NOVALUE;
    object _pos_inlined_seek_at_117_17272 = NOVALUE;
    object _seek_1__tmp_at178_17284 = NOVALUE;
    object _seek_inlined_seek_at_178_17283 = NOVALUE;
    object _seek_1__tmp_at205_17289 = NOVALUE;
    object _seek_inlined_seek_at_205_17288 = NOVALUE;
    object _9727 = NOVALUE;
    object _9726 = NOVALUE;
    object _9723 = NOVALUE;
    object _9718 = NOVALUE;
    object _9713 = NOVALUE;
    object _9709 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1501		if equal(current_table_name, name) then*/
    if (_41current_table_name_16042 == _name_17248)
    _9709 = 1;
    else if (IS_ATOM_INT(_41current_table_name_16042) && IS_ATOM_INT(_name_17248))
    _9709 = 0;
    else
    _9709 = (compare(_41current_table_name_16042, _name_17248) == 0);
    if (_9709 == 0)
    {
        _9709 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _9709 = NOVALUE;
    }

    /** eds.e:1502			return DB_OK*/
    DeRefDS(_name_17248);
    DeRef(_table_17249);
    DeRef(_nkeys_17250);
    DeRef(_index_17251);
    DeRef(_block_ptr_17252);
    DeRef(_block_size_17253);
    return 0LL;
L1: 

    /** eds.e:1504		table = table_find(name)*/
    RefDS(_name_17248);
    _0 = _table_17249;
    _table_17249 = _41table_find(_name_17248);
    DeRef(_0);

    /** eds.e:1505		if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_17249, -1LL)){
        goto L2; // [29] 40
    }

    /** eds.e:1506			return DB_OPEN_FAIL*/
    DeRefDS(_name_17248);
    DeRef(_table_17249);
    DeRef(_nkeys_17250);
    DeRef(_index_17251);
    DeRef(_block_ptr_17252);
    DeRef(_block_size_17253);
    return -1LL;
L2: 

    /** eds.e:1509		save_keys()*/
    _41save_keys();

    /** eds.e:1511		current_table_pos = table*/
    Ref(_table_17249);
    DeRef(_41current_table_pos_16041);
    _41current_table_pos_16041 = _table_17249;

    /** eds.e:1512		current_table_name = name*/
    RefDS(_name_17248);
    DeRef(_41current_table_name_16042);
    _41current_table_name_16042 = _name_17248;

    /** eds.e:1514		k = 0*/
    _k_17255 = 0LL;

    /** eds.e:1515		if caching_option = 1 then*/

    /** eds.e:1516			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_41current_table_pos_16041);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _41current_table_pos_16041;
    _9713 = MAKE_SEQ(_1);
    _k_17255 = find_from(_9713, _41cache_index_16049, 1LL);
    DeRefDS(_9713);
    _9713 = NOVALUE;

    /** eds.e:1517			if k != 0 then*/
    if (_k_17255 == 0LL)
    goto L3; // [88] 103

    /** eds.e:1518				key_pointers = key_cache[k]*/
    DeRef(_41key_pointers_16047);
    _2 = (object)SEQ_PTR(_41key_cache_16048);
    _41key_pointers_16047 = (object)*(((s1_ptr)_2)->base + _k_17255);
    Ref(_41key_pointers_16047);
L3: 

    /** eds.e:1521		if k = 0 then*/
    if (_k_17255 != 0LL)
    goto L4; // [106] 269

    /** eds.e:1523			io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_17249)) {
        _9718 = _table_17249 + 4LL;
        if ((object)((uintptr_t)_9718 + (uintptr_t)HIGH_BITS) >= 0){
            _9718 = NewDouble((eudouble)_9718);
        }
    }
    else {
        _9718 = NewDouble(DBL_PTR(_table_17249)->dbl + (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_117_17272);
    _pos_inlined_seek_at_117_17272 = _9718;
    _9718 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_17272);
    DeRef(_seek_1__tmp_at120_17274);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_117_17272;
    _seek_1__tmp_at120_17274 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_17273 = machine(19LL, _seek_1__tmp_at120_17274);
    DeRef(_pos_inlined_seek_at_117_17272);
    _pos_inlined_seek_at_117_17272 = NOVALUE;
    DeRef(_seek_1__tmp_at120_17274);
    _seek_1__tmp_at120_17274 = NOVALUE;

    /** eds.e:1524			nkeys = get4()*/
    _0 = _nkeys_17250;
    _nkeys_17250 = _41get4();
    DeRef(_0);

    /** eds.e:1525			blocks = get4()*/
    _blocks_17254 = _41get4();
    if (!IS_ATOM_INT(_blocks_17254)) {
        _1 = (object)(DBL_PTR(_blocks_17254)->dbl);
        DeRefDS(_blocks_17254);
        _blocks_17254 = _1;
    }

    /** eds.e:1526			index = get4()*/
    _0 = _index_17251;
    _index_17251 = _41get4();
    DeRef(_0);

    /** eds.e:1527			key_pointers = repeat(0, nkeys)*/
    DeRef(_41key_pointers_16047);
    _41key_pointers_16047 = Repeat(0LL, _nkeys_17250);

    /** eds.e:1528			k = 1*/
    _k_17255 = 1LL;

    /** eds.e:1529			for b = 0 to blocks-1 do*/
    _9723 = _blocks_17254 - 1LL;
    if ((object)((uintptr_t)_9723 +(uintptr_t) HIGH_BITS) >= 0){
        _9723 = NewDouble((eudouble)_9723);
    }
    {
        object _b_17280;
        _b_17280 = 0LL;
L5: 
        if (binary_op_a(GREATER, _b_17280, _9723)){
            goto L6; // [168] 268
        }

        /** eds.e:1530				io:seek(current_db, index)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_17251);
        DeRef(_seek_1__tmp_at178_17284);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _index_17251;
        _seek_1__tmp_at178_17284 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_17283 = machine(19LL, _seek_1__tmp_at178_17284);
        DeRef(_seek_1__tmp_at178_17284);
        _seek_1__tmp_at178_17284 = NOVALUE;

        /** eds.e:1531				block_size = get4()*/
        _0 = _block_size_17253;
        _block_size_17253 = _41get4();
        DeRef(_0);

        /** eds.e:1532				block_ptr = get4()*/
        _0 = _block_ptr_17252;
        _block_ptr_17252 = _41get4();
        DeRef(_0);

        /** eds.e:1533				io:seek(current_db, block_ptr)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_17252);
        DeRef(_seek_1__tmp_at205_17289);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _block_ptr_17252;
        _seek_1__tmp_at205_17289 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_17288 = machine(19LL, _seek_1__tmp_at205_17289);
        DeRef(_seek_1__tmp_at205_17289);
        _seek_1__tmp_at205_17289 = NOVALUE;

        /** eds.e:1534				for j = 1 to block_size do*/
        Ref(_block_size_17253);
        DeRef(_9726);
        _9726 = _block_size_17253;
        {
            object _j_17291;
            _j_17291 = 1LL;
L7: 
            if (binary_op_a(GREATER, _j_17291, _9726)){
                goto L8; // [224] 255
            }

            /** eds.e:1535					key_pointers[k] = get4()*/
            _9727 = _41get4();
            _2 = (object)SEQ_PTR(_41key_pointers_16047);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _41key_pointers_16047 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _k_17255);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _9727;
            if( _1 != _9727 ){
                DeRef(_1);
            }
            _9727 = NOVALUE;

            /** eds.e:1536					k += 1*/
            _k_17255 = _k_17255 + 1;

            /** eds.e:1537				end for*/
            _0 = _j_17291;
            if (IS_ATOM_INT(_j_17291)) {
                _j_17291 = _j_17291 + 1LL;
                if ((object)((uintptr_t)_j_17291 +(uintptr_t) HIGH_BITS) >= 0){
                    _j_17291 = NewDouble((eudouble)_j_17291);
                }
            }
            else {
                _j_17291 = binary_op_a(PLUS, _j_17291, 1LL);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_17291);
        }

        /** eds.e:1538				index += 8*/
        _0 = _index_17251;
        if (IS_ATOM_INT(_index_17251)) {
            _index_17251 = _index_17251 + 8LL;
            if ((object)((uintptr_t)_index_17251 + (uintptr_t)HIGH_BITS) >= 0){
                _index_17251 = NewDouble((eudouble)_index_17251);
            }
        }
        else {
            _index_17251 = NewDouble(DBL_PTR(_index_17251)->dbl + (eudouble)8LL);
        }
        DeRef(_0);

        /** eds.e:1539			end for*/
        _0 = _b_17280;
        if (IS_ATOM_INT(_b_17280)) {
            _b_17280 = _b_17280 + 1LL;
            if ((object)((uintptr_t)_b_17280 +(uintptr_t) HIGH_BITS) >= 0){
                _b_17280 = NewDouble((eudouble)_b_17280);
            }
        }
        else {
            _b_17280 = binary_op_a(PLUS, _b_17280, 1LL);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_17280);
    }
L4: 

    /** eds.e:1541		return DB_OK*/
    DeRefDS(_name_17248);
    DeRef(_table_17249);
    DeRef(_nkeys_17250);
    DeRef(_index_17251);
    DeRef(_block_ptr_17252);
    DeRef(_block_size_17253);
    DeRef(_9723);
    _9723 = NOVALUE;
    return 0LL;
    ;
}


object _41db_create_table(object _name_17300, object _init_records_17301)
{
    object _name_ptr_17302 = NOVALUE;
    object _nt_17303 = NOVALUE;
    object _tables_17304 = NOVALUE;
    object _newtables_17305 = NOVALUE;
    object _table_17306 = NOVALUE;
    object _records_ptr_17307 = NOVALUE;
    object _size_17308 = NOVALUE;
    object _newsize_17309 = NOVALUE;
    object _index_ptr_17310 = NOVALUE;
    object _remaining_17311 = NOVALUE;
    object _init_index_17312 = NOVALUE;
    object _seek_1__tmp_at61_17324 = NOVALUE;
    object _seek_inlined_seek_at_61_17323 = NOVALUE;
    object _seek_1__tmp_at90_17330 = NOVALUE;
    object _seek_inlined_seek_at_90_17329 = NOVALUE;
    object _pos_inlined_seek_at_87_17328 = NOVALUE;
    object _put4_1__tmp_at152_17343 = NOVALUE;
    object _seek_1__tmp_at189_17348 = NOVALUE;
    object _seek_inlined_seek_at_189_17347 = NOVALUE;
    object _pos_inlined_seek_at_186_17346 = NOVALUE;
    object _seek_1__tmp_at232_17356 = NOVALUE;
    object _seek_inlined_seek_at_232_17355 = NOVALUE;
    object _pos_inlined_seek_at_229_17354 = NOVALUE;
    object _s_inlined_putn_at_281_17364 = NOVALUE;
    object _seek_1__tmp_at309_17367 = NOVALUE;
    object _seek_inlined_seek_at_309_17366 = NOVALUE;
    object _put4_1__tmp_at324_17369 = NOVALUE;
    object _seek_1__tmp_at362_17373 = NOVALUE;
    object _seek_inlined_seek_at_362_17372 = NOVALUE;
    object _put4_1__tmp_at377_17375 = NOVALUE;
    object _s_inlined_putn_at_424_17381 = NOVALUE;
    object _put4_1__tmp_at455_17385 = NOVALUE;
    object _put4_1__tmp_at483_17387 = NOVALUE;
    object _s_inlined_putn_at_523_17392 = NOVALUE;
    object _s_inlined_putn_at_561_17398 = NOVALUE;
    object _seek_1__tmp_at603_17406 = NOVALUE;
    object _seek_inlined_seek_at_603_17405 = NOVALUE;
    object _pos_inlined_seek_at_600_17404 = NOVALUE;
    object _put4_1__tmp_at618_17408 = NOVALUE;
    object _put4_1__tmp_at646_17410 = NOVALUE;
    object _put4_1__tmp_at674_17412 = NOVALUE;
    object _put4_1__tmp_at702_17414 = NOVALUE;
    object _9774 = NOVALUE;
    object _9773 = NOVALUE;
    object _9772 = NOVALUE;
    object _9771 = NOVALUE;
    object _9770 = NOVALUE;
    object _9769 = NOVALUE;
    object _9767 = NOVALUE;
    object _9766 = NOVALUE;
    object _9765 = NOVALUE;
    object _9764 = NOVALUE;
    object _9763 = NOVALUE;
    object _9761 = NOVALUE;
    object _9760 = NOVALUE;
    object _9759 = NOVALUE;
    object _9757 = NOVALUE;
    object _9756 = NOVALUE;
    object _9755 = NOVALUE;
    object _9754 = NOVALUE;
    object _9753 = NOVALUE;
    object _9752 = NOVALUE;
    object _9751 = NOVALUE;
    object _9749 = NOVALUE;
    object _9748 = NOVALUE;
    object _9747 = NOVALUE;
    object _9744 = NOVALUE;
    object _9743 = NOVALUE;
    object _9741 = NOVALUE;
    object _9740 = NOVALUE;
    object _9738 = NOVALUE;
    object _9736 = NOVALUE;
    object _9730 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1603		if not cstring(name) then*/
    RefDS(_name_17300);
    _9730 = _9cstring(_name_17300);
    if (IS_ATOM_INT(_9730)) {
        if (_9730 != 0){
            DeRef(_9730);
            _9730 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_9730)->dbl != 0.0){
            DeRef(_9730);
            _9730 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_9730);
    _9730 = NOVALUE;

    /** eds.e:1604			return DB_BAD_NAME*/
    DeRefDS(_name_17300);
    DeRef(_name_ptr_17302);
    DeRef(_nt_17303);
    DeRef(_tables_17304);
    DeRef(_newtables_17305);
    DeRef(_table_17306);
    DeRef(_records_ptr_17307);
    DeRef(_size_17308);
    DeRef(_newsize_17309);
    DeRef(_index_ptr_17310);
    DeRef(_remaining_17311);
    return -4LL;
L1: 

    /** eds.e:1607		table = table_find(name)*/
    RefDS(_name_17300);
    _0 = _table_17306;
    _table_17306 = _41table_find(_name_17300);
    DeRef(_0);

    /** eds.e:1608		if table != -1 then*/
    if (binary_op_a(EQUALS, _table_17306, -1LL)){
        goto L2; // [29] 40
    }

    /** eds.e:1609			return DB_EXISTS_ALREADY*/
    DeRefDS(_name_17300);
    DeRef(_name_ptr_17302);
    DeRef(_nt_17303);
    DeRef(_tables_17304);
    DeRef(_newtables_17305);
    DeRef(_table_17306);
    DeRef(_records_ptr_17307);
    DeRef(_size_17308);
    DeRef(_newsize_17309);
    DeRef(_index_ptr_17310);
    DeRef(_remaining_17311);
    return -2LL;
L2: 

    /** eds.e:1612		if init_records < MAX_INDEX then*/
    if (_init_records_17301 >= 10LL)
    goto L3; // [42] 52

    /** eds.e:1613			init_records = MAX_INDEX*/
    _init_records_17301 = 10LL;
L3: 

    /** eds.e:1615		init_index = MAX_INDEX*/
    _init_index_17312 = 10LL;

    /** eds.e:1618		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at61_17324);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 3LL;
    _seek_1__tmp_at61_17324 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_61_17323 = machine(19LL, _seek_1__tmp_at61_17324);
    DeRefi(_seek_1__tmp_at61_17324);
    _seek_1__tmp_at61_17324 = NOVALUE;

    /** eds.e:1619		tables = get4()*/
    _0 = _tables_17304;
    _tables_17304 = _41get4();
    DeRef(_0);

    /** eds.e:1620		io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_17304)) {
        _9736 = _tables_17304 - 4LL;
        if ((object)((uintptr_t)_9736 +(uintptr_t) HIGH_BITS) >= 0){
            _9736 = NewDouble((eudouble)_9736);
        }
    }
    else {
        _9736 = NewDouble(DBL_PTR(_tables_17304)->dbl - (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_87_17328);
    _pos_inlined_seek_at_87_17328 = _9736;
    _9736 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_17328);
    DeRef(_seek_1__tmp_at90_17330);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_87_17328;
    _seek_1__tmp_at90_17330 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_17329 = machine(19LL, _seek_1__tmp_at90_17330);
    DeRef(_pos_inlined_seek_at_87_17328);
    _pos_inlined_seek_at_87_17328 = NOVALUE;
    DeRef(_seek_1__tmp_at90_17330);
    _seek_1__tmp_at90_17330 = NOVALUE;

    /** eds.e:1621		size = get4()*/
    _0 = _size_17308;
    _size_17308 = _41get4();
    DeRef(_0);

    /** eds.e:1622		nt = get4()+1*/
    _9738 = _41get4();
    DeRef(_nt_17303);
    if (IS_ATOM_INT(_9738)) {
        _nt_17303 = _9738 + 1;
        if (_nt_17303 > MAXINT){
            _nt_17303 = NewDouble((eudouble)_nt_17303);
        }
    }
    else
    _nt_17303 = binary_op(PLUS, 1, _9738);
    DeRef(_9738);
    _9738 = NOVALUE;

    /** eds.e:1623		if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_17303)) {
        {
            int128_t p128 = (int128_t)_nt_17303 * (int128_t)16LL;
            if( p128 != (int128_t)(_9740 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9740 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9740 = NewDouble(DBL_PTR(_nt_17303)->dbl * (eudouble)16LL);
    }
    if (IS_ATOM_INT(_9740)) {
        _9741 = _9740 + 8LL;
        if ((object)((uintptr_t)_9741 + (uintptr_t)HIGH_BITS) >= 0){
            _9741 = NewDouble((eudouble)_9741);
        }
    }
    else {
        _9741 = NewDouble(DBL_PTR(_9740)->dbl + (eudouble)8LL);
    }
    DeRef(_9740);
    _9740 = NOVALUE;
    if (binary_op_a(LESSEQ, _9741, _size_17308)){
        DeRef(_9741);
        _9741 = NOVALUE;
        goto L4; // [127] 358
    }
    DeRef(_9741);
    _9741 = NOVALUE;

    /** eds.e:1625			newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_17308)) {
        if (_size_17308 & 1) {
            _9743 = NewDouble((_size_17308 >> 1) + 0.5);
        }
        else
        _9743 = _size_17308 >> 1;
    }
    else {
        _9743 = binary_op(DIVIDE, _size_17308, 2);
    }
    if (IS_ATOM_INT(_size_17308) && IS_ATOM_INT(_9743)) {
        _9744 = _size_17308 + _9743;
        if ((object)((uintptr_t)_9744 + (uintptr_t)HIGH_BITS) >= 0){
            _9744 = NewDouble((eudouble)_9744);
        }
    }
    else {
        if (IS_ATOM_INT(_size_17308)) {
            _9744 = NewDouble((eudouble)_size_17308 + DBL_PTR(_9743)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9743)) {
                _9744 = NewDouble(DBL_PTR(_size_17308)->dbl + (eudouble)_9743);
            }
            else
            _9744 = NewDouble(DBL_PTR(_size_17308)->dbl + DBL_PTR(_9743)->dbl);
        }
    }
    DeRef(_9743);
    _9743 = NOVALUE;
    DeRef(_newsize_17309);
    if (IS_ATOM_INT(_9744))
    _newsize_17309 = e_floor(_9744);
    else
    _newsize_17309 = unary_op(FLOOR, _9744);
    DeRef(_9744);
    _9744 = NOVALUE;

    /** eds.e:1626			newtables = db_allocate(newsize)*/
    Ref(_newsize_17309);
    _0 = _newtables_17305;
    _newtables_17305 = _41db_allocate(_newsize_17309);
    DeRef(_0);

    /** eds.e:1627			put4(nt)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_nt_17303)) {
        *poke4_addr = (uint32_t)_nt_17303;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nt_17303)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at152_17343);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at152_17343 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at152_17343); // DJP 

    /** eds.e:444	end procedure*/
    goto L5; // [173] 176
L5: 
    DeRefi(_put4_1__tmp_at152_17343);
    _put4_1__tmp_at152_17343 = NOVALUE;

    /** eds.e:1629			io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_17304)) {
        _9747 = _tables_17304 + 4LL;
        if ((object)((uintptr_t)_9747 + (uintptr_t)HIGH_BITS) >= 0){
            _9747 = NewDouble((eudouble)_9747);
        }
    }
    else {
        _9747 = NewDouble(DBL_PTR(_tables_17304)->dbl + (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_186_17346);
    _pos_inlined_seek_at_186_17346 = _9747;
    _9747 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_186_17346);
    DeRef(_seek_1__tmp_at189_17348);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_186_17346;
    _seek_1__tmp_at189_17348 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_189_17347 = machine(19LL, _seek_1__tmp_at189_17348);
    DeRef(_pos_inlined_seek_at_186_17346);
    _pos_inlined_seek_at_186_17346 = NOVALUE;
    DeRef(_seek_1__tmp_at189_17348);
    _seek_1__tmp_at189_17348 = NOVALUE;

    /** eds.e:1630			remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_17303)) {
        _9748 = _nt_17303 - 1LL;
        if ((object)((uintptr_t)_9748 +(uintptr_t) HIGH_BITS) >= 0){
            _9748 = NewDouble((eudouble)_9748);
        }
    }
    else {
        _9748 = NewDouble(DBL_PTR(_nt_17303)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9748)) {
        {
            int128_t p128 = (int128_t)_9748 * (int128_t)16LL;
            if( p128 != (int128_t)(_9749 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9749 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9749 = NewDouble(DBL_PTR(_9748)->dbl * (eudouble)16LL);
    }
    DeRef(_9748);
    _9748 = NOVALUE;
    _0 = _remaining_17311;
    _remaining_17311 = _18get_bytes(_41current_db_16040, _9749);
    DeRef(_0);
    _9749 = NOVALUE;

    /** eds.e:1631			io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_17305)) {
        _9751 = _newtables_17305 + 4LL;
        if ((object)((uintptr_t)_9751 + (uintptr_t)HIGH_BITS) >= 0){
            _9751 = NewDouble((eudouble)_9751);
        }
    }
    else {
        _9751 = NewDouble(DBL_PTR(_newtables_17305)->dbl + (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_229_17354);
    _pos_inlined_seek_at_229_17354 = _9751;
    _9751 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_229_17354);
    DeRef(_seek_1__tmp_at232_17356);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_229_17354;
    _seek_1__tmp_at232_17356 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_232_17355 = machine(19LL, _seek_1__tmp_at232_17356);
    DeRef(_pos_inlined_seek_at_229_17354);
    _pos_inlined_seek_at_229_17354 = NOVALUE;
    DeRef(_seek_1__tmp_at232_17356);
    _seek_1__tmp_at232_17356 = NOVALUE;

    /** eds.e:1632			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _remaining_17311); // DJP 

    /** eds.e:449	end procedure*/
    goto L6; // [256] 259
L6: 

    /** eds.e:1634			putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_17309)) {
        _9752 = _newsize_17309 - 4LL;
        if ((object)((uintptr_t)_9752 +(uintptr_t) HIGH_BITS) >= 0){
            _9752 = NewDouble((eudouble)_9752);
        }
    }
    else {
        _9752 = NewDouble(DBL_PTR(_newsize_17309)->dbl - (eudouble)4LL);
    }
    if (IS_ATOM_INT(_nt_17303)) {
        _9753 = _nt_17303 - 1LL;
        if ((object)((uintptr_t)_9753 +(uintptr_t) HIGH_BITS) >= 0){
            _9753 = NewDouble((eudouble)_9753);
        }
    }
    else {
        _9753 = NewDouble(DBL_PTR(_nt_17303)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9753)) {
        {
            int128_t p128 = (int128_t)_9753 * (int128_t)16LL;
            if( p128 != (int128_t)(_9754 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9754 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9754 = NewDouble(DBL_PTR(_9753)->dbl * (eudouble)16LL);
    }
    DeRef(_9753);
    _9753 = NOVALUE;
    if (IS_ATOM_INT(_9752) && IS_ATOM_INT(_9754)) {
        _9755 = _9752 - _9754;
    }
    else {
        if (IS_ATOM_INT(_9752)) {
            _9755 = NewDouble((eudouble)_9752 - DBL_PTR(_9754)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9754)) {
                _9755 = NewDouble(DBL_PTR(_9752)->dbl - (eudouble)_9754);
            }
            else
            _9755 = NewDouble(DBL_PTR(_9752)->dbl - DBL_PTR(_9754)->dbl);
        }
    }
    DeRef(_9752);
    _9752 = NOVALUE;
    DeRef(_9754);
    _9754 = NOVALUE;
    _9756 = Repeat(0LL, _9755);
    DeRef(_9755);
    _9755 = NOVALUE;
    DeRefi(_s_inlined_putn_at_281_17364);
    _s_inlined_putn_at_281_17364 = _9756;
    _9756 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_281_17364); // DJP 

    /** eds.e:449	end procedure*/
    goto L7; // [295] 298
L7: 
    DeRefi(_s_inlined_putn_at_281_17364);
    _s_inlined_putn_at_281_17364 = NOVALUE;

    /** eds.e:1635			db_free(tables)*/
    Ref(_tables_17304);
    _41db_free(_tables_17304);

    /** eds.e:1636			io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at309_17367);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 3LL;
    _seek_1__tmp_at309_17367 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_309_17366 = machine(19LL, _seek_1__tmp_at309_17367);
    DeRefi(_seek_1__tmp_at309_17367);
    _seek_1__tmp_at309_17367 = NOVALUE;

    /** eds.e:1637			put4(newtables)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_newtables_17305)) {
        *poke4_addr = (uint32_t)_newtables_17305;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_newtables_17305)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at324_17369);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at324_17369 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at324_17369); // DJP 

    /** eds.e:444	end procedure*/
    goto L8; // [345] 348
L8: 
    DeRefi(_put4_1__tmp_at324_17369);
    _put4_1__tmp_at324_17369 = NOVALUE;

    /** eds.e:1638			tables = newtables*/
    Ref(_newtables_17305);
    DeRef(_tables_17304);
    _tables_17304 = _newtables_17305;
    goto L9; // [355] 404
L4: 

    /** eds.e:1640			io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17304);
    DeRef(_seek_1__tmp_at362_17373);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _tables_17304;
    _seek_1__tmp_at362_17373 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_362_17372 = machine(19LL, _seek_1__tmp_at362_17373);
    DeRef(_seek_1__tmp_at362_17373);
    _seek_1__tmp_at362_17373 = NOVALUE;

    /** eds.e:1641			put4(nt)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_nt_17303)) {
        *poke4_addr = (uint32_t)_nt_17303;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nt_17303)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at377_17375);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at377_17375 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at377_17375); // DJP 

    /** eds.e:444	end procedure*/
    goto LA; // [398] 401
LA: 
    DeRefi(_put4_1__tmp_at377_17375);
    _put4_1__tmp_at377_17375 = NOVALUE;
L9: 

    /** eds.e:1645		records_ptr = db_allocate(init_records * 4)*/
    {
        int128_t p128 = (int128_t)_init_records_17301 * (int128_t)4LL;
        if( p128 != (int128_t)(_9757 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9757 = NewDouble( (eudouble)p128 );
        }
    }
    _0 = _records_ptr_17307;
    _records_ptr_17307 = _41db_allocate(_9757);
    DeRef(_0);
    _9757 = NOVALUE;

    /** eds.e:1646		putn(repeat(0, init_records * 4))*/
    _9759 = _init_records_17301 * 4LL;
    _9760 = Repeat(0LL, _9759);
    _9759 = NOVALUE;
    DeRefi(_s_inlined_putn_at_424_17381);
    _s_inlined_putn_at_424_17381 = _9760;
    _9760 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_424_17381); // DJP 

    /** eds.e:449	end procedure*/
    goto LB; // [438] 441
LB: 
    DeRefi(_s_inlined_putn_at_424_17381);
    _s_inlined_putn_at_424_17381 = NOVALUE;

    /** eds.e:1649		index_ptr = db_allocate(init_index * 8)*/
    {
        int128_t p128 = (int128_t)_init_index_17312 * (int128_t)8LL;
        if( p128 != (int128_t)(_9761 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9761 = NewDouble( (eudouble)p128 );
        }
    }
    _0 = _index_ptr_17310;
    _index_ptr_17310 = _41db_allocate(_9761);
    DeRef(_0);
    _9761 = NOVALUE;

    /** eds.e:1650		put4(0)  -- 0 records*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)0LL;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at455_17385);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at455_17385 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at455_17385); // DJP 

    /** eds.e:444	end procedure*/
    goto LC; // [476] 479
LC: 
    DeRefi(_put4_1__tmp_at455_17385);
    _put4_1__tmp_at455_17385 = NOVALUE;

    /** eds.e:1651		put4(records_ptr) -- point to 1st block*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_17307)) {
        *poke4_addr = (uint32_t)_records_ptr_17307;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_records_ptr_17307)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at483_17387);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at483_17387 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at483_17387); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [504] 507
LD: 
    DeRefi(_put4_1__tmp_at483_17387);
    _put4_1__tmp_at483_17387 = NOVALUE;

    /** eds.e:1652		putn(repeat(0, (init_index-1) * 8))*/
    _9763 = _init_index_17312 - 1LL;
    if ((object)((uintptr_t)_9763 +(uintptr_t) HIGH_BITS) >= 0){
        _9763 = NewDouble((eudouble)_9763);
    }
    if (IS_ATOM_INT(_9763)) {
        _9764 = _9763 * 8LL;
    }
    else {
        _9764 = NewDouble(DBL_PTR(_9763)->dbl * (eudouble)8LL);
    }
    DeRef(_9763);
    _9763 = NOVALUE;
    _9765 = Repeat(0LL, _9764);
    DeRef(_9764);
    _9764 = NOVALUE;
    DeRefi(_s_inlined_putn_at_523_17392);
    _s_inlined_putn_at_523_17392 = _9765;
    _9765 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_523_17392); // DJP 

    /** eds.e:449	end procedure*/
    goto LE; // [537] 540
LE: 
    DeRefi(_s_inlined_putn_at_523_17392);
    _s_inlined_putn_at_523_17392 = NOVALUE;

    /** eds.e:1655		name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_17300)){
            _9766 = SEQ_PTR(_name_17300)->length;
    }
    else {
        _9766 = 1;
    }
    _9767 = _9766 + 1;
    _9766 = NOVALUE;
    _0 = _name_ptr_17302;
    _name_ptr_17302 = _41db_allocate(_9767);
    DeRef(_0);
    _9767 = NOVALUE;

    /** eds.e:1656		putn(name & 0)*/
    Append(&_9769, _name_17300, 0LL);
    DeRef(_s_inlined_putn_at_561_17398);
    _s_inlined_putn_at_561_17398 = _9769;
    _9769 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_561_17398); // DJP 

    /** eds.e:449	end procedure*/
    goto LF; // [575] 578
LF: 
    DeRef(_s_inlined_putn_at_561_17398);
    _s_inlined_putn_at_561_17398 = NOVALUE;

    /** eds.e:1658		io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_17304)) {
        _9770 = _tables_17304 + 4LL;
        if ((object)((uintptr_t)_9770 + (uintptr_t)HIGH_BITS) >= 0){
            _9770 = NewDouble((eudouble)_9770);
        }
    }
    else {
        _9770 = NewDouble(DBL_PTR(_tables_17304)->dbl + (eudouble)4LL);
    }
    if (IS_ATOM_INT(_nt_17303)) {
        _9771 = _nt_17303 - 1LL;
        if ((object)((uintptr_t)_9771 +(uintptr_t) HIGH_BITS) >= 0){
            _9771 = NewDouble((eudouble)_9771);
        }
    }
    else {
        _9771 = NewDouble(DBL_PTR(_nt_17303)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9771)) {
        {
            int128_t p128 = (int128_t)_9771 * (int128_t)16LL;
            if( p128 != (int128_t)(_9772 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9772 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9772 = NewDouble(DBL_PTR(_9771)->dbl * (eudouble)16LL);
    }
    DeRef(_9771);
    _9771 = NOVALUE;
    if (IS_ATOM_INT(_9770) && IS_ATOM_INT(_9772)) {
        _9773 = _9770 + _9772;
        if ((object)((uintptr_t)_9773 + (uintptr_t)HIGH_BITS) >= 0){
            _9773 = NewDouble((eudouble)_9773);
        }
    }
    else {
        if (IS_ATOM_INT(_9770)) {
            _9773 = NewDouble((eudouble)_9770 + DBL_PTR(_9772)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9772)) {
                _9773 = NewDouble(DBL_PTR(_9770)->dbl + (eudouble)_9772);
            }
            else
            _9773 = NewDouble(DBL_PTR(_9770)->dbl + DBL_PTR(_9772)->dbl);
        }
    }
    DeRef(_9770);
    _9770 = NOVALUE;
    DeRef(_9772);
    _9772 = NOVALUE;
    DeRef(_pos_inlined_seek_at_600_17404);
    _pos_inlined_seek_at_600_17404 = _9773;
    _9773 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_600_17404);
    DeRef(_seek_1__tmp_at603_17406);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_600_17404;
    _seek_1__tmp_at603_17406 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_603_17405 = machine(19LL, _seek_1__tmp_at603_17406);
    DeRef(_pos_inlined_seek_at_600_17404);
    _pos_inlined_seek_at_600_17404 = NOVALUE;
    DeRef(_seek_1__tmp_at603_17406);
    _seek_1__tmp_at603_17406 = NOVALUE;

    /** eds.e:1659		put4(name_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_17302)) {
        *poke4_addr = (uint32_t)_name_ptr_17302;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_name_ptr_17302)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at618_17408);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at618_17408 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at618_17408); // DJP 

    /** eds.e:444	end procedure*/
    goto L10; // [639] 642
L10: 
    DeRefi(_put4_1__tmp_at618_17408);
    _put4_1__tmp_at618_17408 = NOVALUE;

    /** eds.e:1660		put4(0)  -- start with 0 records total*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)0LL;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at646_17410);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at646_17410 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at646_17410); // DJP 

    /** eds.e:444	end procedure*/
    goto L11; // [667] 670
L11: 
    DeRefi(_put4_1__tmp_at646_17410);
    _put4_1__tmp_at646_17410 = NOVALUE;

    /** eds.e:1661		put4(1)  -- start with 1 block of records in index*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)1LL;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at674_17412);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at674_17412 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at674_17412); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [695] 698
L12: 
    DeRefi(_put4_1__tmp_at674_17412);
    _put4_1__tmp_at674_17412 = NOVALUE;

    /** eds.e:1662		put4(index_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_17310)) {
        *poke4_addr = (uint32_t)_index_ptr_17310;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_index_ptr_17310)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at702_17414);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at702_17414 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at702_17414); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [723] 726
L13: 
    DeRefi(_put4_1__tmp_at702_17414);
    _put4_1__tmp_at702_17414 = NOVALUE;

    /** eds.e:1663		if db_select_table(name) then*/
    RefDS(_name_17300);
    _9774 = _41db_select_table(_name_17300);
    if (_9774 == 0) {
        DeRef(_9774);
        _9774 = NOVALUE;
        goto L14; // [734] 738
    }
    else {
        if (!IS_ATOM_INT(_9774) && DBL_PTR(_9774)->dbl == 0.0){
            DeRef(_9774);
            _9774 = NOVALUE;
            goto L14; // [734] 738
        }
        DeRef(_9774);
        _9774 = NOVALUE;
    }
    DeRef(_9774);
    _9774 = NOVALUE;
L14: 

    /** eds.e:1665		return DB_OK*/
    DeRefDS(_name_17300);
    DeRef(_name_ptr_17302);
    DeRef(_nt_17303);
    DeRef(_tables_17304);
    DeRef(_newtables_17305);
    DeRef(_table_17306);
    DeRef(_records_ptr_17307);
    DeRef(_size_17308);
    DeRef(_newsize_17309);
    DeRef(_index_ptr_17310);
    DeRef(_remaining_17311);
    return 0LL;
    ;
}


object _41db_table_list()
{
    object _seek_1__tmp_at120_17671 = NOVALUE;
    object _seek_inlined_seek_at_120_17670 = NOVALUE;
    object _seek_1__tmp_at98_17667 = NOVALUE;
    object _seek_inlined_seek_at_98_17666 = NOVALUE;
    object _pos_inlined_seek_at_95_17665 = NOVALUE;
    object _seek_1__tmp_at42_17655 = NOVALUE;
    object _seek_inlined_seek_at_42_17654 = NOVALUE;
    object _seek_1__tmp_at4_17648 = NOVALUE;
    object _seek_inlined_seek_at_4_17647 = NOVALUE;
    object _table_names_17642 = NOVALUE;
    object _tables_17643 = NOVALUE;
    object _nt_17644 = NOVALUE;
    object _name_17645 = NOVALUE;
    object _9871 = NOVALUE;
    object _9870 = NOVALUE;
    object _9868 = NOVALUE;
    object _9867 = NOVALUE;
    object _9866 = NOVALUE;
    object _9865 = NOVALUE;
    object _9860 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1923		io:seek(current_db, TABLE_HEADERS)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17648);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = 3LL;
    _seek_1__tmp_at4_17648 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17647 = machine(19LL, _seek_1__tmp_at4_17648);
    DeRefi(_seek_1__tmp_at4_17648);
    _seek_1__tmp_at4_17648 = NOVALUE;

    /** eds.e:1924		if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_41vLastErrors_16064)){
            _9860 = SEQ_PTR(_41vLastErrors_16064)->length;
    }
    else {
        _9860 = 1;
    }
    if (_9860 <= 0LL)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_17642);
    DeRef(_tables_17643);
    DeRef(_nt_17644);
    DeRef(_name_17645);
    return _5;
L1: 

    /** eds.e:1925		tables = get4()*/
    _0 = _tables_17643;
    _tables_17643 = _41get4();
    DeRef(_0);

    /** eds.e:1926		io:seek(current_db, tables)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_17643);
    DeRef(_seek_1__tmp_at42_17655);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _tables_17643;
    _seek_1__tmp_at42_17655 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_17654 = machine(19LL, _seek_1__tmp_at42_17655);
    DeRef(_seek_1__tmp_at42_17655);
    _seek_1__tmp_at42_17655 = NOVALUE;

    /** eds.e:1927		nt = get4()*/
    _0 = _nt_17644;
    _nt_17644 = _41get4();
    DeRef(_0);

    /** eds.e:1928		table_names = repeat(0, nt)*/
    DeRef(_table_names_17642);
    _table_names_17642 = Repeat(0LL, _nt_17644);

    /** eds.e:1929		for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_17644)) {
        _9865 = _nt_17644 - 1LL;
        if ((object)((uintptr_t)_9865 +(uintptr_t) HIGH_BITS) >= 0){
            _9865 = NewDouble((eudouble)_9865);
        }
    }
    else {
        _9865 = NewDouble(DBL_PTR(_nt_17644)->dbl - (eudouble)1LL);
    }
    {
        object _i_17659;
        _i_17659 = 0LL;
L2: 
        if (binary_op_a(GREATER, _i_17659, _9865)){
            goto L3; // [73] 154
        }

        /** eds.e:1930			io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_17643)) {
            _9866 = _tables_17643 + 4LL;
            if ((object)((uintptr_t)_9866 + (uintptr_t)HIGH_BITS) >= 0){
                _9866 = NewDouble((eudouble)_9866);
            }
        }
        else {
            _9866 = NewDouble(DBL_PTR(_tables_17643)->dbl + (eudouble)4LL);
        }
        if (IS_ATOM_INT(_i_17659)) {
            {
                int128_t p128 = (int128_t)_i_17659 * (int128_t)16LL;
                if( p128 != (int128_t)(_9867 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                    _9867 = NewDouble( (eudouble)p128 );
                }
            }
        }
        else {
            _9867 = NewDouble(DBL_PTR(_i_17659)->dbl * (eudouble)16LL);
        }
        if (IS_ATOM_INT(_9866) && IS_ATOM_INT(_9867)) {
            _9868 = _9866 + _9867;
            if ((object)((uintptr_t)_9868 + (uintptr_t)HIGH_BITS) >= 0){
                _9868 = NewDouble((eudouble)_9868);
            }
        }
        else {
            if (IS_ATOM_INT(_9866)) {
                _9868 = NewDouble((eudouble)_9866 + DBL_PTR(_9867)->dbl);
            }
            else {
                if (IS_ATOM_INT(_9867)) {
                    _9868 = NewDouble(DBL_PTR(_9866)->dbl + (eudouble)_9867);
                }
                else
                _9868 = NewDouble(DBL_PTR(_9866)->dbl + DBL_PTR(_9867)->dbl);
            }
        }
        DeRef(_9866);
        _9866 = NOVALUE;
        DeRef(_9867);
        _9867 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_17665);
        _pos_inlined_seek_at_95_17665 = _9868;
        _9868 = NOVALUE;

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_17665);
        DeRef(_seek_1__tmp_at98_17667);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _pos_inlined_seek_at_95_17665;
        _seek_1__tmp_at98_17667 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_17666 = machine(19LL, _seek_1__tmp_at98_17667);
        DeRef(_pos_inlined_seek_at_95_17665);
        _pos_inlined_seek_at_95_17665 = NOVALUE;
        DeRef(_seek_1__tmp_at98_17667);
        _seek_1__tmp_at98_17667 = NOVALUE;

        /** eds.e:1931			name = get4()*/
        _0 = _name_17645;
        _name_17645 = _41get4();
        DeRef(_0);

        /** eds.e:1932			io:seek(current_db, name)*/

        /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_17645);
        DeRef(_seek_1__tmp_at120_17671);
        _1 = NewS1(2);
        _2 = (object)((s1_ptr)_1)->base;
        ((intptr_t *)_2)[1] = _41current_db_16040;
        ((intptr_t *)_2)[2] = _name_17645;
        _seek_1__tmp_at120_17671 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_17670 = machine(19LL, _seek_1__tmp_at120_17671);
        DeRef(_seek_1__tmp_at120_17671);
        _seek_1__tmp_at120_17671 = NOVALUE;

        /** eds.e:1933			table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_17659)) {
            _9870 = _i_17659 + 1;
            if (_9870 > MAXINT){
                _9870 = NewDouble((eudouble)_9870);
            }
        }
        else
        _9870 = binary_op(PLUS, 1, _i_17659);
        _9871 = _41get_string();
        _2 = (object)SEQ_PTR(_table_names_17642);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _table_names_17642 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_9870))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_9870)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _9870);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _9871;
        if( _1 != _9871 ){
            DeRef(_1);
        }
        _9871 = NOVALUE;

        /** eds.e:1934		end for*/
        _0 = _i_17659;
        if (IS_ATOM_INT(_i_17659)) {
            _i_17659 = _i_17659 + 1LL;
            if ((object)((uintptr_t)_i_17659 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17659 = NewDouble((eudouble)_i_17659);
            }
        }
        else {
            _i_17659 = binary_op_a(PLUS, _i_17659, 1LL);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_17659);
    }

    /** eds.e:1935		return table_names*/
    DeRef(_tables_17643);
    DeRef(_nt_17644);
    DeRef(_name_17645);
    DeRef(_9870);
    _9870 = NOVALUE;
    DeRef(_9865);
    _9865 = NOVALUE;
    return _table_names_17642;
    ;
}


object _41key_value(object _ptr_17676)
{
    object _seek_1__tmp_at11_17681 = NOVALUE;
    object _seek_inlined_seek_at_11_17680 = NOVALUE;
    object _pos_inlined_seek_at_8_17679 = NOVALUE;
    object _9873 = NOVALUE;
    object _9872 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:1941		io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_17676)) {
        _9872 = _ptr_17676 + 4LL;
        if ((object)((uintptr_t)_9872 + (uintptr_t)HIGH_BITS) >= 0){
            _9872 = NewDouble((eudouble)_9872);
        }
    }
    else {
        _9872 = NewDouble(DBL_PTR(_ptr_17676)->dbl + (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_8_17679);
    _pos_inlined_seek_at_8_17679 = _9872;
    _9872 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17679);
    DeRef(_seek_1__tmp_at11_17681);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_8_17679;
    _seek_1__tmp_at11_17681 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17680 = machine(19LL, _seek_1__tmp_at11_17681);
    DeRef(_pos_inlined_seek_at_8_17679);
    _pos_inlined_seek_at_8_17679 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17681);
    _seek_1__tmp_at11_17681 = NOVALUE;

    /** eds.e:1942		return decompress(0)*/
    _9873 = _41decompress(0LL);
    DeRef(_ptr_17676);
    return _9873;
    ;
}


object _41db_find_key(object _key_17685, object _table_name_17686)
{
    object _lo_17687 = NOVALUE;
    object _hi_17688 = NOVALUE;
    object _mid_17689 = NOVALUE;
    object _c_17690 = NOVALUE;
    object _9897 = NOVALUE;
    object _9889 = NOVALUE;
    object _9888 = NOVALUE;
    object _9886 = NOVALUE;
    object _9883 = NOVALUE;
    object _9880 = NOVALUE;
    object _9876 = NOVALUE;
    object _9874 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2003		if not equal(table_name, current_table_name) then*/
    if (_table_name_17686 == _41current_table_name_16042)
    _9874 = 1;
    else if (IS_ATOM_INT(_table_name_17686) && IS_ATOM_INT(_41current_table_name_16042))
    _9874 = 0;
    else
    _9874 = (compare(_table_name_17686, _41current_table_name_16042) == 0);
    if (_9874 != 0)
    goto L1; // [9] 42
    _9874 = NOVALUE;

    /** eds.e:2004			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_17686);
    _9876 = _41db_select_table(_table_name_17686);
    if (binary_op_a(EQUALS, _9876, 0LL)){
        DeRef(_9876);
        _9876 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_9876);
    _9876 = NOVALUE;

    /** eds.e:2005				fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_17686);
    Ref(_key_17685);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_17685;
    ((intptr_t *)_2)[2] = _table_name_17686;
    _9880 = MAKE_SEQ(_1);
    RefDS(_9878);
    RefDS(_9879);
    _41fatal(903LL, _9878, _9879, _9880);
    _9880 = NOVALUE;

    /** eds.e:2006				return 0*/
    DeRef(_key_17685);
    DeRefDS(_table_name_17686);
    return 0LL;
L2: 
L1: 

    /** eds.e:2010		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16041, -1LL)){
        goto L3; // [46] 69
    }

    /** eds.e:2011			fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_17686);
    Ref(_key_17685);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_17685;
    ((intptr_t *)_2)[2] = _table_name_17686;
    _9883 = MAKE_SEQ(_1);
    RefDS(_9882);
    RefDS(_9879);
    _41fatal(903LL, _9882, _9879, _9883);
    _9883 = NOVALUE;

    /** eds.e:2012			return 0*/
    DeRef(_key_17685);
    DeRef(_table_name_17686);
    return 0LL;
L3: 

    /** eds.e:2015		lo = 1*/
    _lo_17687 = 1LL;

    /** eds.e:2016		hi = length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_16047)){
            _hi_17688 = SEQ_PTR(_41key_pointers_16047)->length;
    }
    else {
        _hi_17688 = 1;
    }

    /** eds.e:2017		mid = 1*/
    _mid_17689 = 1LL;

    /** eds.e:2018		c = 0*/
    _c_17690 = 0LL;

    /** eds.e:2019		while lo <= hi do*/
L4: 
    if (_lo_17687 > _hi_17688)
    goto L5; // [96] 170

    /** eds.e:2020			mid = floor((lo + hi) / 2)*/
    _9886 = _lo_17687 + _hi_17688;
    if ((object)((uintptr_t)_9886 + (uintptr_t)HIGH_BITS) >= 0){
        _9886 = NewDouble((eudouble)_9886);
    }
    if (IS_ATOM_INT(_9886)) {
        _mid_17689 = _9886 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _9886, 2);
        _mid_17689 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_9886);
    _9886 = NOVALUE;
    if (!IS_ATOM_INT(_mid_17689)) {
        _1 = (object)(DBL_PTR(_mid_17689)->dbl);
        DeRefDS(_mid_17689);
        _mid_17689 = _1;
    }

    /** eds.e:2021			c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (object)SEQ_PTR(_41key_pointers_16047);
    _9888 = (object)*(((s1_ptr)_2)->base + _mid_17689);
    Ref(_9888);
    _9889 = _41key_value(_9888);
    _9888 = NOVALUE;
    if (IS_ATOM_INT(_key_17685) && IS_ATOM_INT(_9889)){
        _c_17690 = (_key_17685 < _9889) ? -1 : (_key_17685 > _9889);
    }
    else{
        _c_17690 = compare(_key_17685, _9889);
    }
    DeRef(_9889);
    _9889 = NOVALUE;

    /** eds.e:2022			if c < 0 then*/
    if (_c_17690 >= 0LL)
    goto L6; // [130] 143

    /** eds.e:2023				hi = mid - 1*/
    _hi_17688 = _mid_17689 - 1LL;
    goto L4; // [140] 96
L6: 

    /** eds.e:2024			elsif c > 0 then*/
    if (_c_17690 <= 0LL)
    goto L7; // [145] 158

    /** eds.e:2025				lo = mid + 1*/
    _lo_17687 = _mid_17689 + 1;
    goto L4; // [155] 96
L7: 

    /** eds.e:2027				return mid*/
    DeRef(_key_17685);
    DeRef(_table_name_17686);
    return _mid_17689;

    /** eds.e:2029		end while*/
    goto L4; // [167] 96
L5: 

    /** eds.e:2031		if c > 0 then*/
    if (_c_17690 <= 0LL)
    goto L8; // [172] 183

    /** eds.e:2032			mid += 1*/
    _mid_17689 = _mid_17689 + 1;
L8: 

    /** eds.e:2034		return -mid*/
    if ((uintptr_t)_mid_17689 == (uintptr_t)HIGH_BITS){
        _9897 = (object)NewDouble((eudouble) -HIGH_BITS);
    }
    else{
        _9897 = - _mid_17689;
    }
    DeRef(_key_17685);
    DeRef(_table_name_17686);
    return _9897;
    ;
}


object _41db_insert(object _key_17725, object _data_17726, object _table_name_17727)
{
    object _key_string_17728 = NOVALUE;
    object _data_string_17729 = NOVALUE;
    object _last_part_17730 = NOVALUE;
    object _remaining_17731 = NOVALUE;
    object _key_ptr_17732 = NOVALUE;
    object _data_ptr_17733 = NOVALUE;
    object _records_ptr_17734 = NOVALUE;
    object _nrecs_17735 = NOVALUE;
    object _current_block_17736 = NOVALUE;
    object _size_17737 = NOVALUE;
    object _new_size_17738 = NOVALUE;
    object _key_location_17739 = NOVALUE;
    object _new_block_17740 = NOVALUE;
    object _index_ptr_17741 = NOVALUE;
    object _new_index_ptr_17742 = NOVALUE;
    object _total_recs_17743 = NOVALUE;
    object _r_17744 = NOVALUE;
    object _blocks_17745 = NOVALUE;
    object _new_recs_17746 = NOVALUE;
    object _n_17747 = NOVALUE;
    object _put4_1__tmp_at79_17761 = NOVALUE;
    object _seek_1__tmp_at132_17767 = NOVALUE;
    object _seek_inlined_seek_at_132_17766 = NOVALUE;
    object _pos_inlined_seek_at_129_17765 = NOVALUE;
    object _seek_1__tmp_at174_17775 = NOVALUE;
    object _seek_inlined_seek_at_174_17774 = NOVALUE;
    object _pos_inlined_seek_at_171_17773 = NOVALUE;
    object _put4_1__tmp_at189_17777 = NOVALUE;
    object _seek_1__tmp_at317_17794 = NOVALUE;
    object _seek_inlined_seek_at_317_17793 = NOVALUE;
    object _pos_inlined_seek_at_314_17792 = NOVALUE;
    object _seek_1__tmp_at339_17798 = NOVALUE;
    object _seek_inlined_seek_at_339_17797 = NOVALUE;
    object _where_inlined_where_at_404_17807 = NOVALUE;
    object _seek_1__tmp_at448_17817 = NOVALUE;
    object _seek_inlined_seek_at_448_17816 = NOVALUE;
    object _pos_inlined_seek_at_445_17815 = NOVALUE;
    object _put4_1__tmp_at493_17826 = NOVALUE;
    object _x_inlined_put4_at_490_17825 = NOVALUE;
    object _seek_1__tmp_at530_17829 = NOVALUE;
    object _seek_inlined_seek_at_530_17828 = NOVALUE;
    object _put4_1__tmp_at551_17832 = NOVALUE;
    object _seek_1__tmp_at588_17837 = NOVALUE;
    object _seek_inlined_seek_at_588_17836 = NOVALUE;
    object _pos_inlined_seek_at_585_17835 = NOVALUE;
    object _seek_1__tmp_at690_17860 = NOVALUE;
    object _seek_inlined_seek_at_690_17859 = NOVALUE;
    object _pos_inlined_seek_at_687_17858 = NOVALUE;
    object _s_inlined_putn_at_751_17869 = NOVALUE;
    object _seek_1__tmp_at774_17872 = NOVALUE;
    object _seek_inlined_seek_at_774_17871 = NOVALUE;
    object _put4_1__tmp_at796_17876 = NOVALUE;
    object _x_inlined_put4_at_793_17875 = NOVALUE;
    object _seek_1__tmp_at833_17881 = NOVALUE;
    object _seek_inlined_seek_at_833_17880 = NOVALUE;
    object _pos_inlined_seek_at_830_17879 = NOVALUE;
    object _seek_1__tmp_at884_17891 = NOVALUE;
    object _seek_inlined_seek_at_884_17890 = NOVALUE;
    object _pos_inlined_seek_at_881_17889 = NOVALUE;
    object _put4_1__tmp_at899_17893 = NOVALUE;
    object _put4_1__tmp_at927_17895 = NOVALUE;
    object _seek_1__tmp_at980_17901 = NOVALUE;
    object _seek_inlined_seek_at_980_17900 = NOVALUE;
    object _pos_inlined_seek_at_977_17899 = NOVALUE;
    object _put4_1__tmp_at1001_17904 = NOVALUE;
    object _seek_1__tmp_at1038_17909 = NOVALUE;
    object _seek_inlined_seek_at_1038_17908 = NOVALUE;
    object _pos_inlined_seek_at_1035_17907 = NOVALUE;
    object _s_inlined_putn_at_1136_17927 = NOVALUE;
    object _seek_1__tmp_at1173_17932 = NOVALUE;
    object _seek_inlined_seek_at_1173_17931 = NOVALUE;
    object _pos_inlined_seek_at_1170_17930 = NOVALUE;
    object _put4_1__tmp_at1188_17934 = NOVALUE;
    object _9990 = NOVALUE;
    object _9989 = NOVALUE;
    object _9988 = NOVALUE;
    object _9987 = NOVALUE;
    object _9984 = NOVALUE;
    object _9983 = NOVALUE;
    object _9981 = NOVALUE;
    object _9979 = NOVALUE;
    object _9978 = NOVALUE;
    object _9976 = NOVALUE;
    object _9975 = NOVALUE;
    object _9973 = NOVALUE;
    object _9972 = NOVALUE;
    object _9970 = NOVALUE;
    object _9969 = NOVALUE;
    object _9968 = NOVALUE;
    object _9967 = NOVALUE;
    object _9966 = NOVALUE;
    object _9965 = NOVALUE;
    object _9964 = NOVALUE;
    object _9963 = NOVALUE;
    object _9962 = NOVALUE;
    object _9959 = NOVALUE;
    object _9958 = NOVALUE;
    object _9957 = NOVALUE;
    object _9956 = NOVALUE;
    object _9953 = NOVALUE;
    object _9950 = NOVALUE;
    object _9949 = NOVALUE;
    object _9948 = NOVALUE;
    object _9947 = NOVALUE;
    object _9945 = NOVALUE;
    object _9944 = NOVALUE;
    object _9942 = NOVALUE;
    object _9941 = NOVALUE;
    object _9939 = NOVALUE;
    object _9938 = NOVALUE;
    object _9937 = NOVALUE;
    object _9936 = NOVALUE;
    object _9935 = NOVALUE;
    object _9934 = NOVALUE;
    object _9933 = NOVALUE;
    object _9931 = NOVALUE;
    object _9928 = NOVALUE;
    object _9923 = NOVALUE;
    object _9922 = NOVALUE;
    object _9921 = NOVALUE;
    object _9919 = NOVALUE;
    object _9918 = NOVALUE;
    object _9917 = NOVALUE;
    object _9914 = NOVALUE;
    object _9912 = NOVALUE;
    object _9909 = NOVALUE;
    object _9908 = NOVALUE;
    object _9906 = NOVALUE;
    object _9905 = NOVALUE;
    object _9903 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2071		key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_17725);
    RefDS(_table_name_17727);
    _0 = _key_location_17739;
    _key_location_17739 = _41db_find_key(_key_17725, _table_name_17727);
    DeRef(_0);

    /** eds.e:2073		if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_17739, 0LL)){
        goto L1; // [10] 21
    }

    /** eds.e:2075			return DB_EXISTS_ALREADY*/
    DeRef(_key_17725);
    DeRefDS(_table_name_17727);
    DeRef(_key_string_17728);
    DeRef(_data_string_17729);
    DeRef(_last_part_17730);
    DeRef(_remaining_17731);
    DeRef(_key_ptr_17732);
    DeRef(_data_ptr_17733);
    DeRef(_records_ptr_17734);
    DeRef(_nrecs_17735);
    DeRef(_current_block_17736);
    DeRef(_size_17737);
    DeRef(_new_size_17738);
    DeRef(_key_location_17739);
    DeRef(_new_block_17740);
    DeRef(_index_ptr_17741);
    DeRef(_new_index_ptr_17742);
    DeRef(_total_recs_17743);
    return -2LL;
L1: 

    /** eds.e:2077		key_location = -key_location*/
    _0 = _key_location_17739;
    if (IS_ATOM_INT(_key_location_17739)) {
        if ((uintptr_t)_key_location_17739 == (uintptr_t)HIGH_BITS){
            _key_location_17739 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _key_location_17739 = - _key_location_17739;
        }
    }
    else {
        _key_location_17739 = unary_op(UMINUS, _key_location_17739);
    }
    DeRef(_0);

    /** eds.e:2079		data_string = compress(data)*/
    _0 = _data_string_17729;
    _data_string_17729 = _41compress(_data_17726);
    DeRef(_0);

    /** eds.e:2080		key_string  = compress(key)*/
    Ref(_key_17725);
    _0 = _key_string_17728;
    _key_string_17728 = _41compress(_key_17725);
    DeRef(_0);

    /** eds.e:2082		data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_17729)){
            _9903 = SEQ_PTR(_data_string_17729)->length;
    }
    else {
        _9903 = 1;
    }
    _0 = _data_ptr_17733;
    _data_ptr_17733 = _41db_allocate(_9903);
    DeRef(_0);
    _9903 = NOVALUE;

    /** eds.e:2083		putn(data_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _data_string_17729); // DJP 

    /** eds.e:449	end procedure*/
    goto L2; // [62] 65
L2: 

    /** eds.e:2085		key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_17728)){
            _9905 = SEQ_PTR(_key_string_17728)->length;
    }
    else {
        _9905 = 1;
    }
    _9906 = 4LL + _9905;
    _9905 = NOVALUE;
    _0 = _key_ptr_17732;
    _key_ptr_17732 = _41db_allocate(_9906);
    DeRef(_0);
    _9906 = NOVALUE;

    /** eds.e:2086		put4(data_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_17733)) {
        *poke4_addr = (uint32_t)_data_ptr_17733;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_data_ptr_17733)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_17761);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at79_17761 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at79_17761); // DJP 

    /** eds.e:444	end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_17761);
    _put4_1__tmp_at79_17761 = NOVALUE;

    /** eds.e:2087		putn(key_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _key_string_17728); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [117] 120
L4: 

    /** eds.e:2091		io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_41current_table_pos_16041)) {
        _9908 = _41current_table_pos_16041 + 4LL;
        if ((object)((uintptr_t)_9908 + (uintptr_t)HIGH_BITS) >= 0){
            _9908 = NewDouble((eudouble)_9908);
        }
    }
    else {
        _9908 = NewDouble(DBL_PTR(_41current_table_pos_16041)->dbl + (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_129_17765);
    _pos_inlined_seek_at_129_17765 = _9908;
    _9908 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_17765);
    DeRef(_seek_1__tmp_at132_17767);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_129_17765;
    _seek_1__tmp_at132_17767 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_17766 = machine(19LL, _seek_1__tmp_at132_17767);
    DeRef(_pos_inlined_seek_at_129_17765);
    _pos_inlined_seek_at_129_17765 = NOVALUE;
    DeRef(_seek_1__tmp_at132_17767);
    _seek_1__tmp_at132_17767 = NOVALUE;

    /** eds.e:2092		total_recs = get4()+1*/
    _9909 = _41get4();
    DeRef(_total_recs_17743);
    if (IS_ATOM_INT(_9909)) {
        _total_recs_17743 = _9909 + 1;
        if (_total_recs_17743 > MAXINT){
            _total_recs_17743 = NewDouble((eudouble)_total_recs_17743);
        }
    }
    else
    _total_recs_17743 = binary_op(PLUS, 1, _9909);
    DeRef(_9909);
    _9909 = NOVALUE;

    /** eds.e:2093		blocks = get4()*/
    _blocks_17745 = _41get4();
    if (!IS_ATOM_INT(_blocks_17745)) {
        _1 = (object)(DBL_PTR(_blocks_17745)->dbl);
        DeRefDS(_blocks_17745);
        _blocks_17745 = _1;
    }

    /** eds.e:2094		io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_41current_table_pos_16041)) {
        _9912 = _41current_table_pos_16041 + 4LL;
        if ((object)((uintptr_t)_9912 + (uintptr_t)HIGH_BITS) >= 0){
            _9912 = NewDouble((eudouble)_9912);
        }
    }
    else {
        _9912 = NewDouble(DBL_PTR(_41current_table_pos_16041)->dbl + (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_171_17773);
    _pos_inlined_seek_at_171_17773 = _9912;
    _9912 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_17773);
    DeRef(_seek_1__tmp_at174_17775);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_171_17773;
    _seek_1__tmp_at174_17775 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_17774 = machine(19LL, _seek_1__tmp_at174_17775);
    DeRef(_pos_inlined_seek_at_171_17773);
    _pos_inlined_seek_at_171_17773 = NOVALUE;
    DeRef(_seek_1__tmp_at174_17775);
    _seek_1__tmp_at174_17775 = NOVALUE;

    /** eds.e:2095		put4(total_recs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_17743)) {
        *poke4_addr = (uint32_t)_total_recs_17743;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_total_recs_17743)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_17777);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at189_17777 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at189_17777); // DJP 

    /** eds.e:444	end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_17777);
    _put4_1__tmp_at189_17777 = NOVALUE;

    /** eds.e:2097		n = length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_16047)){
            _n_17747 = SEQ_PTR(_41key_pointers_16047)->length;
    }
    else {
        _n_17747 = 1;
    }

    /** eds.e:2098		if key_location >= floor(n/2) then*/
    _9914 = _n_17747 >> 1;
    if (binary_op_a(LESS, _key_location_17739, _9914)){
        _9914 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_9914);
    _9914 = NOVALUE;

    /** eds.e:2100			key_pointers = append(key_pointers, 0)*/
    Append(&_41key_pointers_16047, _41key_pointers_16047, 0LL);

    /** eds.e:2102			key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_17739)) {
        _9917 = _key_location_17739 + 1;
        if (_9917 > MAXINT){
            _9917 = NewDouble((eudouble)_9917);
        }
    }
    else
    _9917 = binary_op(PLUS, 1, _key_location_17739);
    _9918 = _n_17747 + 1;
    rhs_slice_target = (object_ptr)&_9919;
    RHS_Slice(_41key_pointers_16047, _key_location_17739, _n_17747);
    assign_slice_seq = (s1_ptr *)&_41key_pointers_16047;
    AssignSlice(_9917, _9918, _9919);
    DeRef(_9917);
    _9917 = NOVALUE;
    _9918 = NOVALUE;
    DeRefDS(_9919);
    _9919 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** eds.e:2105			key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_41key_pointers_16047, _41key_pointers_16047, 0LL);

    /** eds.e:2107			key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_17739)) {
        _9921 = _key_location_17739 - 1LL;
        if ((object)((uintptr_t)_9921 +(uintptr_t) HIGH_BITS) >= 0){
            _9921 = NewDouble((eudouble)_9921);
        }
    }
    else {
        _9921 = NewDouble(DBL_PTR(_key_location_17739)->dbl - (eudouble)1LL);
    }
    rhs_slice_target = (object_ptr)&_9922;
    RHS_Slice(_41key_pointers_16047, 2LL, _key_location_17739);
    assign_slice_seq = (s1_ptr *)&_41key_pointers_16047;
    AssignSlice(1LL, _9921, _9922);
    DeRef(_9921);
    _9921 = NOVALUE;
    DeRefDS(_9922);
    _9922 = NOVALUE;
L7: 

    /** eds.e:2109		key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_17732);
    _2 = (object)SEQ_PTR(_41key_pointers_16047);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _41key_pointers_16047 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_17739))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_key_location_17739)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _key_location_17739);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _key_ptr_17732;
    DeRef(_1);

    /** eds.e:2111		io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_41current_table_pos_16041)) {
        _9923 = _41current_table_pos_16041 + 12LL;
        if ((object)((uintptr_t)_9923 + (uintptr_t)HIGH_BITS) >= 0){
            _9923 = NewDouble((eudouble)_9923);
        }
    }
    else {
        _9923 = NewDouble(DBL_PTR(_41current_table_pos_16041)->dbl + (eudouble)12LL);
    }
    DeRef(_pos_inlined_seek_at_314_17792);
    _pos_inlined_seek_at_314_17792 = _9923;
    _9923 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_17792);
    DeRef(_seek_1__tmp_at317_17794);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_314_17792;
    _seek_1__tmp_at317_17794 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_17793 = machine(19LL, _seek_1__tmp_at317_17794);
    DeRef(_pos_inlined_seek_at_314_17792);
    _pos_inlined_seek_at_314_17792 = NOVALUE;
    DeRef(_seek_1__tmp_at317_17794);
    _seek_1__tmp_at317_17794 = NOVALUE;

    /** eds.e:2112		index_ptr = get4()*/
    _0 = _index_ptr_17741;
    _index_ptr_17741 = _41get4();
    DeRef(_0);

    /** eds.e:2114		io:seek(current_db, index_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_17741);
    DeRef(_seek_1__tmp_at339_17798);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _index_ptr_17741;
    _seek_1__tmp_at339_17798 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_17797 = machine(19LL, _seek_1__tmp_at339_17798);
    DeRef(_seek_1__tmp_at339_17798);
    _seek_1__tmp_at339_17798 = NOVALUE;

    /** eds.e:2115		r = 0*/
    _r_17744 = 0LL;

    /** eds.e:2116		while TRUE do*/
L8: 

    /** eds.e:2117			nrecs = get4()*/
    _0 = _nrecs_17735;
    _nrecs_17735 = _41get4();
    DeRef(_0);

    /** eds.e:2118			records_ptr = get4()*/
    _0 = _records_ptr_17734;
    _records_ptr_17734 = _41get4();
    DeRef(_0);

    /** eds.e:2119			r += nrecs*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _r_17744 = _r_17744 + _nrecs_17735;
    }
    else {
        _r_17744 = NewDouble((eudouble)_r_17744 + DBL_PTR(_nrecs_17735)->dbl);
    }
    if (!IS_ATOM_INT(_r_17744)) {
        _1 = (object)(DBL_PTR(_r_17744)->dbl);
        DeRefDS(_r_17744);
        _r_17744 = _1;
    }

    /** eds.e:2120			if r + 1 >= key_location then*/
    _9928 = _r_17744 + 1;
    if (_9928 > MAXINT){
        _9928 = NewDouble((eudouble)_9928);
    }
    if (binary_op_a(LESS, _9928, _key_location_17739)){
        DeRef(_9928);
        _9928 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_9928);
    _9928 = NOVALUE;

    /** eds.e:2121				exit*/
    goto L9; // [393] 401

    /** eds.e:2123		end while*/
    goto L8; // [398] 363
L9: 

    /** eds.e:2125		current_block = io:where(current_db)-8*/

    /** io.e:932		return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_17807);
    _where_inlined_where_at_404_17807 = machine(20LL, _41current_db_16040);
    DeRef(_current_block_17736);
    if (IS_ATOM_INT(_where_inlined_where_at_404_17807)) {
        _current_block_17736 = _where_inlined_where_at_404_17807 - 8LL;
        if ((object)((uintptr_t)_current_block_17736 +(uintptr_t) HIGH_BITS) >= 0){
            _current_block_17736 = NewDouble((eudouble)_current_block_17736);
        }
    }
    else {
        _current_block_17736 = NewDouble(DBL_PTR(_where_inlined_where_at_404_17807)->dbl - (eudouble)8LL);
    }

    /** eds.e:2127		key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _9931 = _r_17744 - _nrecs_17735;
        if ((object)((uintptr_t)_9931 +(uintptr_t) HIGH_BITS) >= 0){
            _9931 = NewDouble((eudouble)_9931);
        }
    }
    else {
        _9931 = NewDouble((eudouble)_r_17744 - DBL_PTR(_nrecs_17735)->dbl);
    }
    _0 = _key_location_17739;
    if (IS_ATOM_INT(_key_location_17739) && IS_ATOM_INT(_9931)) {
        _key_location_17739 = _key_location_17739 - _9931;
        if ((object)((uintptr_t)_key_location_17739 +(uintptr_t) HIGH_BITS) >= 0){
            _key_location_17739 = NewDouble((eudouble)_key_location_17739);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_17739)) {
            _key_location_17739 = NewDouble((eudouble)_key_location_17739 - DBL_PTR(_9931)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9931)) {
                _key_location_17739 = NewDouble(DBL_PTR(_key_location_17739)->dbl - (eudouble)_9931);
            }
            else
            _key_location_17739 = NewDouble(DBL_PTR(_key_location_17739)->dbl - DBL_PTR(_9931)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_9931);
    _9931 = NOVALUE;

    /** eds.e:2129		io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_17739)) {
        _9933 = _key_location_17739 - 1LL;
        if ((object)((uintptr_t)_9933 +(uintptr_t) HIGH_BITS) >= 0){
            _9933 = NewDouble((eudouble)_9933);
        }
    }
    else {
        _9933 = NewDouble(DBL_PTR(_key_location_17739)->dbl - (eudouble)1LL);
    }
    if (IS_ATOM_INT(_9933)) {
        {
            int128_t p128 = (int128_t)4LL * (int128_t)_9933;
            if( p128 != (int128_t)(_9934 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9934 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9934 = NewDouble((eudouble)4LL * DBL_PTR(_9933)->dbl);
    }
    DeRef(_9933);
    _9933 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_17734) && IS_ATOM_INT(_9934)) {
        _9935 = _records_ptr_17734 + _9934;
        if ((object)((uintptr_t)_9935 + (uintptr_t)HIGH_BITS) >= 0){
            _9935 = NewDouble((eudouble)_9935);
        }
    }
    else {
        if (IS_ATOM_INT(_records_ptr_17734)) {
            _9935 = NewDouble((eudouble)_records_ptr_17734 + DBL_PTR(_9934)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9934)) {
                _9935 = NewDouble(DBL_PTR(_records_ptr_17734)->dbl + (eudouble)_9934);
            }
            else
            _9935 = NewDouble(DBL_PTR(_records_ptr_17734)->dbl + DBL_PTR(_9934)->dbl);
        }
    }
    DeRef(_9934);
    _9934 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_17815);
    _pos_inlined_seek_at_445_17815 = _9935;
    _9935 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_17815);
    DeRef(_seek_1__tmp_at448_17817);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_445_17815;
    _seek_1__tmp_at448_17817 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_17816 = machine(19LL, _seek_1__tmp_at448_17817);
    DeRef(_pos_inlined_seek_at_445_17815);
    _pos_inlined_seek_at_445_17815 = NOVALUE;
    DeRef(_seek_1__tmp_at448_17817);
    _seek_1__tmp_at448_17817 = NOVALUE;

    /** eds.e:2130		for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _9936 = _nrecs_17735 + 1;
        if (_9936 > MAXINT){
            _9936 = NewDouble((eudouble)_9936);
        }
    }
    else
    _9936 = binary_op(PLUS, 1, _nrecs_17735);
    {
        object _i_17819;
        Ref(_key_location_17739);
        _i_17819 = _key_location_17739;
LA: 
        if (binary_op_a(GREATER, _i_17819, _9936)){
            goto LB; // [468] 527
        }

        /** eds.e:2131			put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_17819)) {
            _9937 = _i_17819 + _r_17744;
            if ((object)((uintptr_t)_9937 + (uintptr_t)HIGH_BITS) >= 0){
                _9937 = NewDouble((eudouble)_9937);
            }
        }
        else {
            _9937 = NewDouble(DBL_PTR(_i_17819)->dbl + (eudouble)_r_17744);
        }
        if (IS_ATOM_INT(_9937) && IS_ATOM_INT(_nrecs_17735)) {
            _9938 = _9937 - _nrecs_17735;
        }
        else {
            if (IS_ATOM_INT(_9937)) {
                _9938 = NewDouble((eudouble)_9937 - DBL_PTR(_nrecs_17735)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_17735)) {
                    _9938 = NewDouble(DBL_PTR(_9937)->dbl - (eudouble)_nrecs_17735);
                }
                else
                _9938 = NewDouble(DBL_PTR(_9937)->dbl - DBL_PTR(_nrecs_17735)->dbl);
            }
        }
        DeRef(_9937);
        _9937 = NOVALUE;
        _2 = (object)SEQ_PTR(_41key_pointers_16047);
        if (!IS_ATOM_INT(_9938)){
            _9939 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_9938)->dbl));
        }
        else{
            _9939 = (object)*(((s1_ptr)_2)->base + _9938);
        }
        Ref(_9939);
        DeRef(_x_inlined_put4_at_490_17825);
        _x_inlined_put4_at_490_17825 = _9939;
        _9939 = NOVALUE;

        /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_41mem0_16082)){
            poke4_addr = (uint32_t *)_41mem0_16082;
        }
        else {
            poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_17825)) {
            *poke4_addr = (uint32_t)_x_inlined_put4_at_490_17825;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_17825)) {
            *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_490_17825)->dbl;
        }
        else {
            _1 = (object)SEQ_PTR(_x_inlined_put4_at_490_17825);
            _1 = (object)((s1_ptr)_1)->base;
            while (1) {
                _1 += sizeof(object);
                _2 = *((object *)_1);
                if (IS_ATOM_INT(_2)) {
                    *poke4_addr++ = (int32_t)_2;
                }
                else if (_2 == NOVALUE) {
                    break;
                }
                else {
                    *(object *)poke4_addr++ = (uint32_t)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** eds.e:443		puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_17826);
        _1 = (object)SEQ_PTR(_41memseq_16306);
        peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        pokeptr_addr = (uintptr_t *)NewS1(_2);
        _put4_1__tmp_at493_17826 = MAKE_SEQ(pokeptr_addr);
        pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
        while (--_2 >= 0) {
            pokeptr_addr++;
            *pokeptr_addr = (object)*peek_addr++;
        }
        EPuts(_41current_db_16040, _put4_1__tmp_at493_17826); // DJP 

        /** eds.e:444	end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_17825);
        _x_inlined_put4_at_490_17825 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_17826);
        _put4_1__tmp_at493_17826 = NOVALUE;

        /** eds.e:2132		end for*/
        _0 = _i_17819;
        if (IS_ATOM_INT(_i_17819)) {
            _i_17819 = _i_17819 + 1LL;
            if ((object)((uintptr_t)_i_17819 +(uintptr_t) HIGH_BITS) >= 0){
                _i_17819 = NewDouble((eudouble)_i_17819);
            }
        }
        else {
            _i_17819 = binary_op_a(PLUS, _i_17819, 1LL);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_17819);
    }

    /** eds.e:2135		io:seek(current_db, current_block)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_17736);
    DeRef(_seek_1__tmp_at530_17829);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _current_block_17736;
    _seek_1__tmp_at530_17829 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_17828 = machine(19LL, _seek_1__tmp_at530_17829);
    DeRef(_seek_1__tmp_at530_17829);
    _seek_1__tmp_at530_17829 = NOVALUE;

    /** eds.e:2136		nrecs += 1*/
    _0 = _nrecs_17735;
    if (IS_ATOM_INT(_nrecs_17735)) {
        _nrecs_17735 = _nrecs_17735 + 1;
        if (_nrecs_17735 > MAXINT){
            _nrecs_17735 = NewDouble((eudouble)_nrecs_17735);
        }
    }
    else
    _nrecs_17735 = binary_op(PLUS, 1, _nrecs_17735);
    DeRef(_0);

    /** eds.e:2137		put4(nrecs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_17735)) {
        *poke4_addr = (uint32_t)_nrecs_17735;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_nrecs_17735)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_17832);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at551_17832 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at551_17832); // DJP 

    /** eds.e:444	end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_17832);
    _put4_1__tmp_at551_17832 = NOVALUE;

    /** eds.e:2140		io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_17734)) {
        _9941 = _records_ptr_17734 - 4LL;
        if ((object)((uintptr_t)_9941 +(uintptr_t) HIGH_BITS) >= 0){
            _9941 = NewDouble((eudouble)_9941);
        }
    }
    else {
        _9941 = NewDouble(DBL_PTR(_records_ptr_17734)->dbl - (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_585_17835);
    _pos_inlined_seek_at_585_17835 = _9941;
    _9941 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_17835);
    DeRef(_seek_1__tmp_at588_17837);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_585_17835;
    _seek_1__tmp_at588_17837 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_17836 = machine(19LL, _seek_1__tmp_at588_17837);
    DeRef(_pos_inlined_seek_at_585_17835);
    _pos_inlined_seek_at_585_17835 = NOVALUE;
    DeRef(_seek_1__tmp_at588_17837);
    _seek_1__tmp_at588_17837 = NOVALUE;

    /** eds.e:2141		size = get4() - 4*/
    _9942 = _41get4();
    DeRef(_size_17737);
    if (IS_ATOM_INT(_9942)) {
        _size_17737 = _9942 - 4LL;
        if ((object)((uintptr_t)_size_17737 +(uintptr_t) HIGH_BITS) >= 0){
            _size_17737 = NewDouble((eudouble)_size_17737);
        }
    }
    else {
        _size_17737 = binary_op(MINUS, _9942, 4LL);
    }
    DeRef(_9942);
    _9942 = NOVALUE;

    /** eds.e:2142		if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        {
            int128_t p128 = (int128_t)_nrecs_17735 * (int128_t)4LL;
            if( p128 != (int128_t)(_9944 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9944 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9944 = NewDouble(DBL_PTR(_nrecs_17735)->dbl * (eudouble)4LL);
    }
    if (IS_ATOM_INT(_size_17737)) {
        _9945 = _size_17737 - 4LL;
        if ((object)((uintptr_t)_9945 +(uintptr_t) HIGH_BITS) >= 0){
            _9945 = NewDouble((eudouble)_9945);
        }
    }
    else {
        _9945 = NewDouble(DBL_PTR(_size_17737)->dbl - (eudouble)4LL);
    }
    if (binary_op_a(LESSEQ, _9944, _9945)){
        DeRef(_9944);
        _9944 = NOVALUE;
        DeRef(_9945);
        _9945 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_9944);
    _9944 = NOVALUE;
    DeRef(_9945);
    _9945 = NOVALUE;

    /** eds.e:2150			new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_17743)) {
        _9947 = NewDouble(DBL_PTR(_8632)->dbl * (eudouble)_total_recs_17743);
    }
    else
    _9947 = NewDouble(DBL_PTR(_8632)->dbl * DBL_PTR(_total_recs_17743)->dbl);
    _9948 = unary_op(SQRT, _9947);
    DeRefDS(_9947);
    _9947 = NOVALUE;
    _9949 = unary_op(FLOOR, _9948);
    DeRefDS(_9948);
    _9948 = NOVALUE;
    if (IS_ATOM_INT(_9949)) {
        _9950 = 20LL + _9949;
        if ((object)((uintptr_t)_9950 + (uintptr_t)HIGH_BITS) >= 0){
            _9950 = NewDouble((eudouble)_9950);
        }
    }
    else {
        _9950 = binary_op(PLUS, 20LL, _9949);
    }
    DeRef(_9949);
    _9949 = NOVALUE;
    DeRef(_new_size_17738);
    if (IS_ATOM_INT(_9950)) {
        {
            int128_t p128 = (int128_t)8LL * (int128_t)_9950;
            if( p128 != (int128_t)(_new_size_17738 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _new_size_17738 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _new_size_17738 = binary_op(MULTIPLY, 8LL, _9950);
    }
    DeRef(_9950);
    _9950 = NOVALUE;

    /** eds.e:2152			new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_17738)) {
        if (8LL > 0 && _new_size_17738 >= 0) {
            _new_recs_17746 = _new_size_17738 / 8LL;
        }
        else {
            temp_dbl = EUFLOOR((eudouble)_new_size_17738 / (eudouble)8LL);
            _new_recs_17746 = (object)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_17738, 8LL);
        _new_recs_17746 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_17746)) {
        _1 = (object)(DBL_PTR(_new_recs_17746)->dbl);
        DeRefDS(_new_recs_17746);
        _new_recs_17746 = _1;
    }

    /** eds.e:2153			if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _9953 = _nrecs_17735 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_17735, 2);
        _9953 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_17746, _9953)){
        DeRef(_9953);
        _9953 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_9953);
    _9953 = NOVALUE;

    /** eds.e:2154				new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _new_recs_17746 = _nrecs_17735 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_17735, 2);
        _new_recs_17746 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_17746)) {
        _1 = (object)(DBL_PTR(_new_recs_17746)->dbl);
        DeRefDS(_new_recs_17746);
        _new_recs_17746 = _1;
    }
LF: 

    /** eds.e:2158			io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _9956 = _nrecs_17735 - _new_recs_17746;
        if ((object)((uintptr_t)_9956 +(uintptr_t) HIGH_BITS) >= 0){
            _9956 = NewDouble((eudouble)_9956);
        }
    }
    else {
        _9956 = NewDouble(DBL_PTR(_nrecs_17735)->dbl - (eudouble)_new_recs_17746);
    }
    if (IS_ATOM_INT(_9956)) {
        {
            int128_t p128 = (int128_t)_9956 * (int128_t)4LL;
            if( p128 != (int128_t)(_9957 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
                _9957 = NewDouble( (eudouble)p128 );
            }
        }
    }
    else {
        _9957 = NewDouble(DBL_PTR(_9956)->dbl * (eudouble)4LL);
    }
    DeRef(_9956);
    _9956 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_17734) && IS_ATOM_INT(_9957)) {
        _9958 = _records_ptr_17734 + _9957;
        if ((object)((uintptr_t)_9958 + (uintptr_t)HIGH_BITS) >= 0){
            _9958 = NewDouble((eudouble)_9958);
        }
    }
    else {
        if (IS_ATOM_INT(_records_ptr_17734)) {
            _9958 = NewDouble((eudouble)_records_ptr_17734 + DBL_PTR(_9957)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9957)) {
                _9958 = NewDouble(DBL_PTR(_records_ptr_17734)->dbl + (eudouble)_9957);
            }
            else
            _9958 = NewDouble(DBL_PTR(_records_ptr_17734)->dbl + DBL_PTR(_9957)->dbl);
        }
    }
    DeRef(_9957);
    _9957 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_17858);
    _pos_inlined_seek_at_687_17858 = _9958;
    _9958 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_17858);
    DeRef(_seek_1__tmp_at690_17860);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_687_17858;
    _seek_1__tmp_at690_17860 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_17859 = machine(19LL, _seek_1__tmp_at690_17860);
    DeRef(_pos_inlined_seek_at_687_17858);
    _pos_inlined_seek_at_687_17858 = NOVALUE;
    DeRef(_seek_1__tmp_at690_17860);
    _seek_1__tmp_at690_17860 = NOVALUE;

    /** eds.e:2159			last_part = io:get_bytes(current_db, new_recs*4)*/
    {
        int128_t p128 = (int128_t)_new_recs_17746 * (int128_t)4LL;
        if( p128 != (int128_t)(_9959 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9959 = NewDouble( (eudouble)p128 );
        }
    }
    _0 = _last_part_17730;
    _last_part_17730 = _18get_bytes(_41current_db_16040, _9959);
    DeRef(_0);
    _9959 = NOVALUE;

    /** eds.e:2160			new_block = db_allocate(new_size)*/
    Ref(_new_size_17738);
    _0 = _new_block_17740;
    _new_block_17740 = _41db_allocate(_new_size_17738);
    DeRef(_0);

    /** eds.e:2161			putn(last_part)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _last_part_17730); // DJP 

    /** eds.e:449	end procedure*/
    goto L10; // [736] 739
L10: 

    /** eds.e:2163			putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_17730)){
            _9962 = SEQ_PTR(_last_part_17730)->length;
    }
    else {
        _9962 = 1;
    }
    if (IS_ATOM_INT(_new_size_17738)) {
        _9963 = _new_size_17738 - _9962;
    }
    else {
        _9963 = NewDouble(DBL_PTR(_new_size_17738)->dbl - (eudouble)_9962);
    }
    _9962 = NOVALUE;
    _9964 = Repeat(0LL, _9963);
    DeRef(_9963);
    _9963 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_17869);
    _s_inlined_putn_at_751_17869 = _9964;
    _9964 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_751_17869); // DJP 

    /** eds.e:449	end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_17869);
    _s_inlined_putn_at_751_17869 = NOVALUE;

    /** eds.e:2166			io:seek(current_db, current_block)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_17736);
    DeRef(_seek_1__tmp_at774_17872);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _current_block_17736;
    _seek_1__tmp_at774_17872 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_17871 = machine(19LL, _seek_1__tmp_at774_17872);
    DeRef(_seek_1__tmp_at774_17872);
    _seek_1__tmp_at774_17872 = NOVALUE;

    /** eds.e:2167			put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_17735)) {
        _9965 = _nrecs_17735 - _new_recs_17746;
        if ((object)((uintptr_t)_9965 +(uintptr_t) HIGH_BITS) >= 0){
            _9965 = NewDouble((eudouble)_9965);
        }
    }
    else {
        _9965 = NewDouble(DBL_PTR(_nrecs_17735)->dbl - (eudouble)_new_recs_17746);
    }
    DeRef(_x_inlined_put4_at_793_17875);
    _x_inlined_put4_at_793_17875 = _9965;
    _9965 = NOVALUE;

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_17875)) {
        *poke4_addr = (uint32_t)_x_inlined_put4_at_793_17875;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_x_inlined_put4_at_793_17875)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_17876);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at796_17876 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at796_17876); // DJP 

    /** eds.e:444	end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_17875);
    _x_inlined_put4_at_793_17875 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_17876);
    _put4_1__tmp_at796_17876 = NOVALUE;

    /** eds.e:2170			io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_17736)) {
        _9966 = _current_block_17736 + 8LL;
        if ((object)((uintptr_t)_9966 + (uintptr_t)HIGH_BITS) >= 0){
            _9966 = NewDouble((eudouble)_9966);
        }
    }
    else {
        _9966 = NewDouble(DBL_PTR(_current_block_17736)->dbl + (eudouble)8LL);
    }
    DeRef(_pos_inlined_seek_at_830_17879);
    _pos_inlined_seek_at_830_17879 = _9966;
    _9966 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_17879);
    DeRef(_seek_1__tmp_at833_17881);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_830_17879;
    _seek_1__tmp_at833_17881 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_17880 = machine(19LL, _seek_1__tmp_at833_17881);
    DeRef(_pos_inlined_seek_at_830_17879);
    _pos_inlined_seek_at_830_17879 = NOVALUE;
    DeRef(_seek_1__tmp_at833_17881);
    _seek_1__tmp_at833_17881 = NOVALUE;

    /** eds.e:2171			remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    {
        int128_t p128 = (int128_t)_blocks_17745 * (int128_t)8LL;
        if( p128 != (int128_t)(_9967 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9967 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_index_ptr_17741) && IS_ATOM_INT(_9967)) {
        _9968 = _index_ptr_17741 + _9967;
        if ((object)((uintptr_t)_9968 + (uintptr_t)HIGH_BITS) >= 0){
            _9968 = NewDouble((eudouble)_9968);
        }
    }
    else {
        if (IS_ATOM_INT(_index_ptr_17741)) {
            _9968 = NewDouble((eudouble)_index_ptr_17741 + DBL_PTR(_9967)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9967)) {
                _9968 = NewDouble(DBL_PTR(_index_ptr_17741)->dbl + (eudouble)_9967);
            }
            else
            _9968 = NewDouble(DBL_PTR(_index_ptr_17741)->dbl + DBL_PTR(_9967)->dbl);
        }
    }
    DeRef(_9967);
    _9967 = NOVALUE;
    if (IS_ATOM_INT(_current_block_17736)) {
        _9969 = _current_block_17736 + 8LL;
        if ((object)((uintptr_t)_9969 + (uintptr_t)HIGH_BITS) >= 0){
            _9969 = NewDouble((eudouble)_9969);
        }
    }
    else {
        _9969 = NewDouble(DBL_PTR(_current_block_17736)->dbl + (eudouble)8LL);
    }
    if (IS_ATOM_INT(_9968) && IS_ATOM_INT(_9969)) {
        _9970 = _9968 - _9969;
        if ((object)((uintptr_t)_9970 +(uintptr_t) HIGH_BITS) >= 0){
            _9970 = NewDouble((eudouble)_9970);
        }
    }
    else {
        if (IS_ATOM_INT(_9968)) {
            _9970 = NewDouble((eudouble)_9968 - DBL_PTR(_9969)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9969)) {
                _9970 = NewDouble(DBL_PTR(_9968)->dbl - (eudouble)_9969);
            }
            else
            _9970 = NewDouble(DBL_PTR(_9968)->dbl - DBL_PTR(_9969)->dbl);
        }
    }
    DeRef(_9968);
    _9968 = NOVALUE;
    DeRef(_9969);
    _9969 = NOVALUE;
    _0 = _remaining_17731;
    _remaining_17731 = _18get_bytes(_41current_db_16040, _9970);
    DeRef(_0);
    _9970 = NOVALUE;

    /** eds.e:2172			io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_17736)) {
        _9972 = _current_block_17736 + 8LL;
        if ((object)((uintptr_t)_9972 + (uintptr_t)HIGH_BITS) >= 0){
            _9972 = NewDouble((eudouble)_9972);
        }
    }
    else {
        _9972 = NewDouble(DBL_PTR(_current_block_17736)->dbl + (eudouble)8LL);
    }
    DeRef(_pos_inlined_seek_at_881_17889);
    _pos_inlined_seek_at_881_17889 = _9972;
    _9972 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_17889);
    DeRef(_seek_1__tmp_at884_17891);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_881_17889;
    _seek_1__tmp_at884_17891 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_17890 = machine(19LL, _seek_1__tmp_at884_17891);
    DeRef(_pos_inlined_seek_at_881_17889);
    _pos_inlined_seek_at_881_17889 = NOVALUE;
    DeRef(_seek_1__tmp_at884_17891);
    _seek_1__tmp_at884_17891 = NOVALUE;

    /** eds.e:2173			put4(new_recs)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)_new_recs_17746;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_17893);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at899_17893 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at899_17893); // DJP 

    /** eds.e:444	end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_17893);
    _put4_1__tmp_at899_17893 = NOVALUE;

    /** eds.e:2174			put4(new_block)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_new_block_17740)) {
        *poke4_addr = (uint32_t)_new_block_17740;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_new_block_17740)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_17895);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at927_17895 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at927_17895); // DJP 

    /** eds.e:444	end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_17895);
    _put4_1__tmp_at927_17895 = NOVALUE;

    /** eds.e:2175			putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _remaining_17731); // DJP 

    /** eds.e:449	end procedure*/
    goto L15; // [965] 968
L15: 

    /** eds.e:2176			io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_41current_table_pos_16041)) {
        _9973 = _41current_table_pos_16041 + 8LL;
        if ((object)((uintptr_t)_9973 + (uintptr_t)HIGH_BITS) >= 0){
            _9973 = NewDouble((eudouble)_9973);
        }
    }
    else {
        _9973 = NewDouble(DBL_PTR(_41current_table_pos_16041)->dbl + (eudouble)8LL);
    }
    DeRef(_pos_inlined_seek_at_977_17899);
    _pos_inlined_seek_at_977_17899 = _9973;
    _9973 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_17899);
    DeRef(_seek_1__tmp_at980_17901);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_977_17899;
    _seek_1__tmp_at980_17901 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_17900 = machine(19LL, _seek_1__tmp_at980_17901);
    DeRef(_pos_inlined_seek_at_977_17899);
    _pos_inlined_seek_at_977_17899 = NOVALUE;
    DeRef(_seek_1__tmp_at980_17901);
    _seek_1__tmp_at980_17901 = NOVALUE;

    /** eds.e:2177			blocks += 1*/
    _blocks_17745 = _blocks_17745 + 1;

    /** eds.e:2178			put4(blocks)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    *poke4_addr = (uint32_t)_blocks_17745;

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_17904);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at1001_17904 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at1001_17904); // DJP 

    /** eds.e:444	end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_17904);
    _put4_1__tmp_at1001_17904 = NOVALUE;

    /** eds.e:2180			io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_17741)) {
        _9975 = _index_ptr_17741 - 4LL;
        if ((object)((uintptr_t)_9975 +(uintptr_t) HIGH_BITS) >= 0){
            _9975 = NewDouble((eudouble)_9975);
        }
    }
    else {
        _9975 = NewDouble(DBL_PTR(_index_ptr_17741)->dbl - (eudouble)4LL);
    }
    DeRef(_pos_inlined_seek_at_1035_17907);
    _pos_inlined_seek_at_1035_17907 = _9975;
    _9975 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_17907);
    DeRef(_seek_1__tmp_at1038_17909);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_1035_17907;
    _seek_1__tmp_at1038_17909 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_17908 = machine(19LL, _seek_1__tmp_at1038_17909);
    DeRef(_pos_inlined_seek_at_1035_17907);
    _pos_inlined_seek_at_1035_17907 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_17909);
    _seek_1__tmp_at1038_17909 = NOVALUE;

    /** eds.e:2181			size = get4() - 4*/
    _9976 = _41get4();
    DeRef(_size_17737);
    if (IS_ATOM_INT(_9976)) {
        _size_17737 = _9976 - 4LL;
        if ((object)((uintptr_t)_size_17737 +(uintptr_t) HIGH_BITS) >= 0){
            _size_17737 = NewDouble((eudouble)_size_17737);
        }
    }
    else {
        _size_17737 = binary_op(MINUS, _9976, 4LL);
    }
    DeRef(_9976);
    _9976 = NOVALUE;

    /** eds.e:2182			if blocks*8 > size-8 then*/
    {
        int128_t p128 = (int128_t)_blocks_17745 * (int128_t)8LL;
        if( p128 != (int128_t)(_9978 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9978 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_size_17737)) {
        _9979 = _size_17737 - 8LL;
        if ((object)((uintptr_t)_9979 +(uintptr_t) HIGH_BITS) >= 0){
            _9979 = NewDouble((eudouble)_9979);
        }
    }
    else {
        _9979 = NewDouble(DBL_PTR(_size_17737)->dbl - (eudouble)8LL);
    }
    if (binary_op_a(LESSEQ, _9978, _9979)){
        DeRef(_9978);
        _9978 = NOVALUE;
        DeRef(_9979);
        _9979 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_9978);
    _9978 = NOVALUE;
    DeRef(_9979);
    _9979 = NOVALUE;

    /** eds.e:2184				remaining = io:get_bytes(current_db, blocks*8)*/
    {
        int128_t p128 = (int128_t)_blocks_17745 * (int128_t)8LL;
        if( p128 != (int128_t)(_9981 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9981 = NewDouble( (eudouble)p128 );
        }
    }
    _0 = _remaining_17731;
    _remaining_17731 = _18get_bytes(_41current_db_16040, _9981);
    DeRef(_0);
    _9981 = NOVALUE;

    /** eds.e:2185				new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_17737)) {
        if (_size_17737 & 1) {
            _9983 = NewDouble((_size_17737 >> 1) + 0.5);
        }
        else
        _9983 = _size_17737 >> 1;
    }
    else {
        _9983 = binary_op(DIVIDE, _size_17737, 2);
    }
    if (IS_ATOM_INT(_size_17737) && IS_ATOM_INT(_9983)) {
        _9984 = _size_17737 + _9983;
        if ((object)((uintptr_t)_9984 + (uintptr_t)HIGH_BITS) >= 0){
            _9984 = NewDouble((eudouble)_9984);
        }
    }
    else {
        if (IS_ATOM_INT(_size_17737)) {
            _9984 = NewDouble((eudouble)_size_17737 + DBL_PTR(_9983)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9983)) {
                _9984 = NewDouble(DBL_PTR(_size_17737)->dbl + (eudouble)_9983);
            }
            else
            _9984 = NewDouble(DBL_PTR(_size_17737)->dbl + DBL_PTR(_9983)->dbl);
        }
    }
    DeRef(_9983);
    _9983 = NOVALUE;
    DeRef(_new_size_17738);
    if (IS_ATOM_INT(_9984))
    _new_size_17738 = e_floor(_9984);
    else
    _new_size_17738 = unary_op(FLOOR, _9984);
    DeRef(_9984);
    _9984 = NOVALUE;

    /** eds.e:2186				new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_17738);
    _0 = _new_index_ptr_17742;
    _new_index_ptr_17742 = _41db_allocate(_new_size_17738);
    DeRef(_0);

    /** eds.e:2187				putn(remaining)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _remaining_17731); // DJP 

    /** eds.e:449	end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** eds.e:2188				putn(repeat(0, new_size-blocks*8))*/
    {
        int128_t p128 = (int128_t)_blocks_17745 * (int128_t)8LL;
        if( p128 != (int128_t)(_9987 = (intptr_t)p128) || !IS_ATOM_INT( p128 ) ){
            _9987 = NewDouble( (eudouble)p128 );
        }
    }
    if (IS_ATOM_INT(_new_size_17738) && IS_ATOM_INT(_9987)) {
        _9988 = _new_size_17738 - _9987;
    }
    else {
        if (IS_ATOM_INT(_new_size_17738)) {
            _9988 = NewDouble((eudouble)_new_size_17738 - DBL_PTR(_9987)->dbl);
        }
        else {
            if (IS_ATOM_INT(_9987)) {
                _9988 = NewDouble(DBL_PTR(_new_size_17738)->dbl - (eudouble)_9987);
            }
            else
            _9988 = NewDouble(DBL_PTR(_new_size_17738)->dbl - DBL_PTR(_9987)->dbl);
        }
    }
    DeRef(_9987);
    _9987 = NOVALUE;
    _9989 = Repeat(0LL, _9988);
    DeRef(_9988);
    _9988 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_17927);
    _s_inlined_putn_at_1136_17927 = _9989;
    _9989 = NOVALUE;

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _s_inlined_putn_at_1136_17927); // DJP 

    /** eds.e:449	end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_17927);
    _s_inlined_putn_at_1136_17927 = NOVALUE;

    /** eds.e:2189				db_free(index_ptr)*/
    Ref(_index_ptr_17741);
    _41db_free(_index_ptr_17741);

    /** eds.e:2190				io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_41current_table_pos_16041)) {
        _9990 = _41current_table_pos_16041 + 12LL;
        if ((object)((uintptr_t)_9990 + (uintptr_t)HIGH_BITS) >= 0){
            _9990 = NewDouble((eudouble)_9990);
        }
    }
    else {
        _9990 = NewDouble(DBL_PTR(_41current_table_pos_16041)->dbl + (eudouble)12LL);
    }
    DeRef(_pos_inlined_seek_at_1170_17930);
    _pos_inlined_seek_at_1170_17930 = _9990;
    _9990 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_17930);
    DeRef(_seek_1__tmp_at1173_17932);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_1170_17930;
    _seek_1__tmp_at1173_17932 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_17931 = machine(19LL, _seek_1__tmp_at1173_17932);
    DeRef(_pos_inlined_seek_at_1170_17930);
    _pos_inlined_seek_at_1170_17930 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_17932);
    _seek_1__tmp_at1173_17932 = NOVALUE;

    /** eds.e:2191				put4(new_index_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_17742)) {
        *poke4_addr = (uint32_t)_new_index_ptr_17742;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_new_index_ptr_17742)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_17934);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at1188_17934 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at1188_17934); // DJP 

    /** eds.e:444	end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_17934);
    _put4_1__tmp_at1188_17934 = NOVALUE;
L17: 
LE: 

    /** eds.e:2194		return DB_OK*/
    DeRef(_key_17725);
    DeRef(_table_name_17727);
    DeRef(_key_string_17728);
    DeRef(_data_string_17729);
    DeRef(_last_part_17730);
    DeRef(_remaining_17731);
    DeRef(_key_ptr_17732);
    DeRef(_data_ptr_17733);
    DeRef(_records_ptr_17734);
    DeRef(_nrecs_17735);
    DeRef(_current_block_17736);
    DeRef(_size_17737);
    DeRef(_new_size_17738);
    DeRef(_key_location_17739);
    DeRef(_new_block_17740);
    DeRef(_index_ptr_17741);
    DeRef(_new_index_ptr_17742);
    DeRef(_total_recs_17743);
    DeRef(_9938);
    _9938 = NOVALUE;
    DeRef(_9936);
    _9936 = NOVALUE;
    return 0LL;
    ;
}


void _41db_replace_data(object _key_location_18069, object _data_18070, object _table_name_18071)
{
    object _10064 = NOVALUE;
    object _10063 = NOVALUE;
    object _10062 = NOVALUE;
    object _10061 = NOVALUE;
    object _10059 = NOVALUE;
    object _10058 = NOVALUE;
    object _10056 = NOVALUE;
    object _10053 = NOVALUE;
    object _10051 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2323		if not equal(table_name, current_table_name) then*/
    if (_table_name_18071 == _41current_table_name_16042)
    _10051 = 1;
    else if (IS_ATOM_INT(_table_name_18071) && IS_ATOM_INT(_41current_table_name_16042))
    _10051 = 0;
    else
    _10051 = (compare(_table_name_18071, _41current_table_name_16042) == 0);
    if (_10051 != 0)
    goto L1; // [11] 45
    _10051 = NOVALUE;

    /** eds.e:2324			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18071);
    _10053 = _41db_select_table(_table_name_18071);
    if (binary_op_a(EQUALS, _10053, 0LL)){
        DeRef(_10053);
        _10053 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10053);
    _10053 = NOVALUE;

    /** eds.e:2325				fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_18069;
    ((intptr_t*)_2)[2] = _data_18070;
    RefDS(_table_name_18071);
    ((intptr_t*)_2)[3] = _table_name_18071;
    _10056 = MAKE_SEQ(_1);
    RefDS(_9878);
    RefDS(_10055);
    _41fatal(903LL, _9878, _10055, _10056);
    _10056 = NOVALUE;

    /** eds.e:2326				return*/
    DeRefDS(_table_name_18071);
    return;
L2: 
L1: 

    /** eds.e:2330		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16041, -1LL)){
        goto L3; // [49] 73
    }

    /** eds.e:2331			fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_18069;
    ((intptr_t*)_2)[2] = _data_18070;
    Ref(_table_name_18071);
    ((intptr_t*)_2)[3] = _table_name_18071;
    _10058 = MAKE_SEQ(_1);
    RefDS(_9882);
    RefDS(_10055);
    _41fatal(903LL, _9882, _10055, _10058);
    _10058 = NOVALUE;

    /** eds.e:2332			return*/
    DeRef(_table_name_18071);
    return;
L3: 

    /** eds.e:2334		if key_location < 1 or key_location > length(key_pointers) then*/
    _10059 = (_key_location_18069 < 1LL);
    if (_10059 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_41key_pointers_16047)){
            _10061 = SEQ_PTR(_41key_pointers_16047)->length;
    }
    else {
        _10061 = 1;
    }
    _10062 = (_key_location_18069 > _10061);
    _10061 = NOVALUE;
    if (_10062 == 0)
    {
        DeRef(_10062);
        _10062 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10062);
        _10062 = NOVALUE;
    }
L4: 

    /** eds.e:2335			fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _key_location_18069;
    ((intptr_t*)_2)[2] = _data_18070;
    Ref(_table_name_18071);
    ((intptr_t*)_2)[3] = _table_name_18071;
    _10063 = MAKE_SEQ(_1);
    RefDS(_10003);
    RefDS(_10055);
    _41fatal(905LL, _10003, _10055, _10063);
    _10063 = NOVALUE;

    /** eds.e:2336			return*/
    DeRef(_table_name_18071);
    DeRef(_10059);
    _10059 = NOVALUE;
    return;
L5: 

    /** eds.e:2338		db_replace_recid(key_pointers[key_location], data)*/
    _2 = (object)SEQ_PTR(_41key_pointers_16047);
    _10064 = (object)*(((s1_ptr)_2)->base + _key_location_18069);
    Ref(_10064);
    _41db_replace_recid(_10064, _data_18070);
    _10064 = NOVALUE;

    /** eds.e:2339	end procedure*/
    DeRef(_table_name_18071);
    DeRef(_10059);
    _10059 = NOVALUE;
    return;
    ;
}


object _41db_table_size(object _table_name_18093)
{
    object _10073 = NOVALUE;
    object _10072 = NOVALUE;
    object _10070 = NOVALUE;
    object _10067 = NOVALUE;
    object _10065 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2369		if not equal(table_name, current_table_name) then*/
    if (_table_name_18093 == _41current_table_name_16042)
    _10065 = 1;
    else if (IS_ATOM_INT(_table_name_18093) && IS_ATOM_INT(_41current_table_name_16042))
    _10065 = 0;
    else
    _10065 = (compare(_table_name_18093, _41current_table_name_16042) == 0);
    if (_10065 != 0)
    goto L1; // [9] 42
    _10065 = NOVALUE;

    /** eds.e:2370			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18093);
    _10067 = _41db_select_table(_table_name_18093);
    if (binary_op_a(EQUALS, _10067, 0LL)){
        DeRef(_10067);
        _10067 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10067);
    _10067 = NOVALUE;

    /** eds.e:2371				fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_table_name_18093);
    ((intptr_t*)_2)[1] = _table_name_18093;
    _10070 = MAKE_SEQ(_1);
    RefDS(_9878);
    RefDS(_10069);
    _41fatal(903LL, _9878, _10069, _10070);
    _10070 = NOVALUE;

    /** eds.e:2372				return -1*/
    DeRefDS(_table_name_18093);
    return -1LL;
L2: 
L1: 

    /** eds.e:2376		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16041, -1LL)){
        goto L3; // [46] 69
    }

    /** eds.e:2377			fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_table_name_18093);
    ((intptr_t*)_2)[1] = _table_name_18093;
    _10072 = MAKE_SEQ(_1);
    RefDS(_9882);
    RefDS(_10069);
    _41fatal(903LL, _9882, _10069, _10072);
    _10072 = NOVALUE;

    /** eds.e:2378			return -1*/
    DeRef(_table_name_18093);
    return -1LL;
L3: 

    /** eds.e:2380		return length(key_pointers)*/
    if (IS_SEQUENCE(_41key_pointers_16047)){
            _10073 = SEQ_PTR(_41key_pointers_16047)->length;
    }
    else {
        _10073 = 1;
    }
    DeRef(_table_name_18093);
    return _10073;
    ;
}


object _41db_record_data(object _key_location_18108, object _table_name_18109)
{
    object _data_ptr_18110 = NOVALUE;
    object _data_value_18111 = NOVALUE;
    object _seek_1__tmp_at126_18133 = NOVALUE;
    object _seek_inlined_seek_at_126_18132 = NOVALUE;
    object _pos_inlined_seek_at_123_18131 = NOVALUE;
    object _seek_1__tmp_at164_18140 = NOVALUE;
    object _seek_inlined_seek_at_164_18139 = NOVALUE;
    object _10088 = NOVALUE;
    object _10087 = NOVALUE;
    object _10086 = NOVALUE;
    object _10085 = NOVALUE;
    object _10084 = NOVALUE;
    object _10082 = NOVALUE;
    object _10081 = NOVALUE;
    object _10079 = NOVALUE;
    object _10076 = NOVALUE;
    object _10074 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18108)) {
        _1 = (object)(DBL_PTR(_key_location_18108)->dbl);
        DeRefDS(_key_location_18108);
        _key_location_18108 = _1;
    }

    /** eds.e:2417		if not equal(table_name, current_table_name) then*/
    if (_table_name_18109 == _41current_table_name_16042)
    _10074 = 1;
    else if (IS_ATOM_INT(_table_name_18109) && IS_ATOM_INT(_41current_table_name_16042))
    _10074 = 0;
    else
    _10074 = (compare(_table_name_18109, _41current_table_name_16042) == 0);
    if (_10074 != 0)
    goto L1; // [11] 44
    _10074 = NOVALUE;

    /** eds.e:2418			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18109);
    _10076 = _41db_select_table(_table_name_18109);
    if (binary_op_a(EQUALS, _10076, 0LL)){
        DeRef(_10076);
        _10076 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10076);
    _10076 = NOVALUE;

    /** eds.e:2419				fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_18109);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18108;
    ((intptr_t *)_2)[2] = _table_name_18109;
    _10079 = MAKE_SEQ(_1);
    RefDS(_9878);
    RefDS(_10078);
    _41fatal(903LL, _9878, _10078, _10079);
    _10079 = NOVALUE;

    /** eds.e:2420				return -1*/
    DeRefDS(_table_name_18109);
    DeRef(_data_ptr_18110);
    DeRef(_data_value_18111);
    return -1LL;
L2: 
L1: 

    /** eds.e:2424		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16041, -1LL)){
        goto L3; // [48] 71
    }

    /** eds.e:2425			fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18109);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18108;
    ((intptr_t *)_2)[2] = _table_name_18109;
    _10081 = MAKE_SEQ(_1);
    RefDS(_9882);
    RefDS(_10078);
    _41fatal(903LL, _9882, _10078, _10081);
    _10081 = NOVALUE;

    /** eds.e:2426			return -1*/
    DeRef(_table_name_18109);
    DeRef(_data_ptr_18110);
    DeRef(_data_value_18111);
    return -1LL;
L3: 

    /** eds.e:2428		if key_location < 1 or key_location > length(key_pointers) then*/
    _10082 = (_key_location_18108 < 1LL);
    if (_10082 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_41key_pointers_16047)){
            _10084 = SEQ_PTR(_41key_pointers_16047)->length;
    }
    else {
        _10084 = 1;
    }
    _10085 = (_key_location_18108 > _10084);
    _10084 = NOVALUE;
    if (_10085 == 0)
    {
        DeRef(_10085);
        _10085 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10085);
        _10085 = NOVALUE;
    }
L4: 

    /** eds.e:2429			fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_18109);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18108;
    ((intptr_t *)_2)[2] = _table_name_18109;
    _10086 = MAKE_SEQ(_1);
    RefDS(_10003);
    RefDS(_10078);
    _41fatal(905LL, _10003, _10078, _10086);
    _10086 = NOVALUE;

    /** eds.e:2430			return -1*/
    DeRef(_table_name_18109);
    DeRef(_data_ptr_18110);
    DeRef(_data_value_18111);
    DeRef(_10082);
    _10082 = NOVALUE;
    return -1LL;
L5: 

    /** eds.e:2433		io:seek(current_db, key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_41key_pointers_16047);
    _10087 = (object)*(((s1_ptr)_2)->base + _key_location_18108);
    Ref(_10087);
    DeRef(_pos_inlined_seek_at_123_18131);
    _pos_inlined_seek_at_123_18131 = _10087;
    _10087 = NOVALUE;

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_18131);
    DeRef(_seek_1__tmp_at126_18133);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _pos_inlined_seek_at_123_18131;
    _seek_1__tmp_at126_18133 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_18132 = machine(19LL, _seek_1__tmp_at126_18133);
    DeRef(_pos_inlined_seek_at_123_18131);
    _pos_inlined_seek_at_123_18131 = NOVALUE;
    DeRef(_seek_1__tmp_at126_18133);
    _seek_1__tmp_at126_18133 = NOVALUE;

    /** eds.e:2434		if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_41vLastErrors_16064)){
            _10088 = SEQ_PTR(_41vLastErrors_16064)->length;
    }
    else {
        _10088 = 1;
    }
    if (_10088 <= 0LL)
    goto L6; // [147] 156
    DeRef(_table_name_18109);
    DeRef(_data_ptr_18110);
    DeRef(_data_value_18111);
    DeRef(_10082);
    _10082 = NOVALUE;
    return -1LL;
L6: 

    /** eds.e:2435		data_ptr = get4()*/
    _0 = _data_ptr_18110;
    _data_ptr_18110 = _41get4();
    DeRef(_0);

    /** eds.e:2436		io:seek(current_db, data_ptr)*/

    /** io.e:907		return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_18110);
    DeRef(_seek_1__tmp_at164_18140);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _41current_db_16040;
    ((intptr_t *)_2)[2] = _data_ptr_18110;
    _seek_1__tmp_at164_18140 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_18139 = machine(19LL, _seek_1__tmp_at164_18140);
    DeRef(_seek_1__tmp_at164_18140);
    _seek_1__tmp_at164_18140 = NOVALUE;

    /** eds.e:2437		data_value = decompress(0)*/
    _0 = _data_value_18111;
    _data_value_18111 = _41decompress(0LL);
    DeRef(_0);

    /** eds.e:2439		return data_value*/
    DeRef(_table_name_18109);
    DeRef(_data_ptr_18110);
    DeRef(_10082);
    _10082 = NOVALUE;
    return _data_value_18111;
    ;
}


object _41db_fetch_record(object _key_18144, object _table_name_18145)
{
    object _pos_18146 = NOVALUE;
    object _10094 = NOVALUE;
    object _0, _1, _2;
    

    /** eds.e:2481		pos = db_find_key(key, table_name)*/
    Ref(_key_18144);
    RefDS(_table_name_18145);
    _pos_18146 = _41db_find_key(_key_18144, _table_name_18145);
    if (!IS_ATOM_INT(_pos_18146)) {
        _1 = (object)(DBL_PTR(_pos_18146)->dbl);
        DeRefDS(_pos_18146);
        _pos_18146 = _1;
    }

    /** eds.e:2482		if pos > 0 then*/
    if (_pos_18146 <= 0LL)
    goto L1; // [12] 30

    /** eds.e:2483			return db_record_data(pos, table_name)*/
    RefDS(_table_name_18145);
    _10094 = _41db_record_data(_pos_18146, _table_name_18145);
    DeRef(_key_18144);
    DeRefDS(_table_name_18145);
    return _10094;
    goto L2; // [27] 37
L1: 

    /** eds.e:2485			return pos*/
    DeRef(_key_18144);
    DeRef(_table_name_18145);
    DeRef(_10094);
    _10094 = NOVALUE;
    return _pos_18146;
L2: 
    ;
}


object _41db_record_key(object _key_location_18154, object _table_name_18155)
{
    object _10109 = NOVALUE;
    object _10108 = NOVALUE;
    object _10107 = NOVALUE;
    object _10106 = NOVALUE;
    object _10105 = NOVALUE;
    object _10103 = NOVALUE;
    object _10102 = NOVALUE;
    object _10100 = NOVALUE;
    object _10097 = NOVALUE;
    object _10095 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_18154)) {
        _1 = (object)(DBL_PTR(_key_location_18154)->dbl);
        DeRefDS(_key_location_18154);
        _key_location_18154 = _1;
    }

    /** eds.e:2519		if not equal(table_name, current_table_name) then*/
    if (_table_name_18155 == _41current_table_name_16042)
    _10095 = 1;
    else if (IS_ATOM_INT(_table_name_18155) && IS_ATOM_INT(_41current_table_name_16042))
    _10095 = 0;
    else
    _10095 = (compare(_table_name_18155, _41current_table_name_16042) == 0);
    if (_10095 != 0)
    goto L1; // [11] 44
    _10095 = NOVALUE;

    /** eds.e:2520			if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18155);
    _10097 = _41db_select_table(_table_name_18155);
    if (binary_op_a(EQUALS, _10097, 0LL)){
        DeRef(_10097);
        _10097 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10097);
    _10097 = NOVALUE;

    /** eds.e:2521				fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_18155);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18154;
    ((intptr_t *)_2)[2] = _table_name_18155;
    _10100 = MAKE_SEQ(_1);
    RefDS(_9878);
    RefDS(_10099);
    _41fatal(903LL, _9878, _10099, _10100);
    _10100 = NOVALUE;

    /** eds.e:2522				return -1*/
    DeRefDS(_table_name_18155);
    return -1LL;
L2: 
L1: 

    /** eds.e:2526		if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _41current_table_pos_16041, -1LL)){
        goto L3; // [48] 71
    }

    /** eds.e:2527			fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18155);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18154;
    ((intptr_t *)_2)[2] = _table_name_18155;
    _10102 = MAKE_SEQ(_1);
    RefDS(_9882);
    RefDS(_10099);
    _41fatal(903LL, _9882, _10099, _10102);
    _10102 = NOVALUE;

    /** eds.e:2528			return -1*/
    DeRef(_table_name_18155);
    return -1LL;
L3: 

    /** eds.e:2530		if key_location < 1 or key_location > length(key_pointers) then*/
    _10103 = (_key_location_18154 < 1LL);
    if (_10103 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_41key_pointers_16047)){
            _10105 = SEQ_PTR(_41key_pointers_16047)->length;
    }
    else {
        _10105 = 1;
    }
    _10106 = (_key_location_18154 > _10105);
    _10105 = NOVALUE;
    if (_10106 == 0)
    {
        DeRef(_10106);
        _10106 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10106);
        _10106 = NOVALUE;
    }
L4: 

    /** eds.e:2531			fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_18155);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _key_location_18154;
    ((intptr_t *)_2)[2] = _table_name_18155;
    _10107 = MAKE_SEQ(_1);
    RefDS(_10003);
    RefDS(_10099);
    _41fatal(905LL, _10003, _10099, _10107);
    _10107 = NOVALUE;

    /** eds.e:2532			return -1*/
    DeRef(_table_name_18155);
    DeRef(_10103);
    _10103 = NOVALUE;
    return -1LL;
L5: 

    /** eds.e:2534		return key_value(key_pointers[key_location])*/
    _2 = (object)SEQ_PTR(_41key_pointers_16047);
    _10108 = (object)*(((s1_ptr)_2)->base + _key_location_18154);
    Ref(_10108);
    _10109 = _41key_value(_10108);
    _10108 = NOVALUE;
    DeRef(_table_name_18155);
    DeRef(_10103);
    _10103 = NOVALUE;
    return _10109;
    ;
}


void _41db_replace_recid(object _recid_18267, object _data_18268)
{
    object _old_size_18269 = NOVALUE;
    object _new_size_18270 = NOVALUE;
    object _data_ptr_18271 = NOVALUE;
    object _data_string_18272 = NOVALUE;
    object _put4_1__tmp_at111_18292 = NOVALUE;
    object _10207 = NOVALUE;
    object _10206 = NOVALUE;
    object _10205 = NOVALUE;
    object _10204 = NOVALUE;
    object _10203 = NOVALUE;
    object _10175 = NOVALUE;
    object _10173 = NOVALUE;
    object _10172 = NOVALUE;
    object _10171 = NOVALUE;
    object _10170 = NOVALUE;
    object _10169 = NOVALUE;
    object _10165 = NOVALUE;
    object _10164 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_18267)) {
        _1 = (object)(DBL_PTR(_recid_18267)->dbl);
        DeRefDS(_recid_18267);
        _recid_18267 = _1;
    }

    /** eds.e:2760		seek(current_db, recid)*/
    _10207 = _18seek(_41current_db_16040, _recid_18267);
    DeRef(_10207);
    _10207 = NOVALUE;

    /** eds.e:2761		data_ptr = get4()*/
    _0 = _data_ptr_18271;
    _data_ptr_18271 = _41get4();
    DeRef(_0);

    /** eds.e:2762		seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_18271)) {
        _10164 = _data_ptr_18271 - 4LL;
        if ((object)((uintptr_t)_10164 +(uintptr_t) HIGH_BITS) >= 0){
            _10164 = NewDouble((eudouble)_10164);
        }
    }
    else {
        _10164 = NewDouble(DBL_PTR(_data_ptr_18271)->dbl - (eudouble)4LL);
    }
    _10206 = _18seek(_41current_db_16040, _10164);
    _10164 = NOVALUE;
    DeRef(_10206);
    _10206 = NOVALUE;

    /** eds.e:2763		old_size = get4()-4*/
    _10165 = _41get4();
    DeRef(_old_size_18269);
    if (IS_ATOM_INT(_10165)) {
        _old_size_18269 = _10165 - 4LL;
        if ((object)((uintptr_t)_old_size_18269 +(uintptr_t) HIGH_BITS) >= 0){
            _old_size_18269 = NewDouble((eudouble)_old_size_18269);
        }
    }
    else {
        _old_size_18269 = binary_op(MINUS, _10165, 4LL);
    }
    DeRef(_10165);
    _10165 = NOVALUE;

    /** eds.e:2764		data_string = compress(data)*/
    _0 = _data_string_18272;
    _data_string_18272 = _41compress(_data_18268);
    DeRef(_0);

    /** eds.e:2765		new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_18272)){
            _new_size_18270 = SEQ_PTR(_data_string_18272)->length;
    }
    else {
        _new_size_18270 = 1;
    }

    /** eds.e:2766		if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_18269)) {
        _10169 = (_new_size_18270 <= _old_size_18269);
    }
    else {
        _10169 = ((eudouble)_new_size_18270 <= DBL_PTR(_old_size_18269)->dbl);
    }
    if (_10169 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_18269)) {
        _10171 = _old_size_18269 - 16LL;
        if ((object)((uintptr_t)_10171 +(uintptr_t) HIGH_BITS) >= 0){
            _10171 = NewDouble((eudouble)_10171);
        }
    }
    else {
        _10171 = NewDouble(DBL_PTR(_old_size_18269)->dbl - (eudouble)16LL);
    }
    if (IS_ATOM_INT(_10171)) {
        _10172 = (_new_size_18270 >= _10171);
    }
    else {
        _10172 = ((eudouble)_new_size_18270 >= DBL_PTR(_10171)->dbl);
    }
    DeRef(_10171);
    _10171 = NOVALUE;
    if (_10172 == 0)
    {
        DeRef(_10172);
        _10172 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10172);
        _10172 = NOVALUE;
    }

    /** eds.e:2769			seek(current_db, data_ptr)*/
    Ref(_data_ptr_18271);
    _10205 = _18seek(_41current_db_16040, _data_ptr_18271);
    DeRef(_10205);
    _10205 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** eds.e:2772			db_free(data_ptr)*/
    Ref(_data_ptr_18271);
    _41db_free(_data_ptr_18271);

    /** eds.e:2774			data_ptr = db_allocate(new_size + 8)*/
    _10173 = _new_size_18270 + 8LL;
    if ((object)((uintptr_t)_10173 + (uintptr_t)HIGH_BITS) >= 0){
        _10173 = NewDouble((eudouble)_10173);
    }
    _0 = _data_ptr_18271;
    _data_ptr_18271 = _41db_allocate(_10173);
    DeRef(_0);
    _10173 = NOVALUE;

    /** eds.e:2775			seek(current_db, recid)*/
    _10204 = _18seek(_41current_db_16040, _recid_18267);
    DeRef(_10204);
    _10204 = NOVALUE;

    /** eds.e:2776			put4(data_ptr)*/

    /** eds.e:442		poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_41mem0_16082)){
        poke4_addr = (uint32_t *)_41mem0_16082;
    }
    else {
        poke4_addr = (uint32_t *)(uintptr_t)(DBL_PTR(_41mem0_16082)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18271)) {
        *poke4_addr = (uint32_t)_data_ptr_18271;
    }
    else {
        *poke4_addr = (uint32_t)DBL_PTR(_data_ptr_18271)->dbl;
    }

    /** eds.e:443		puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_18292);
    _1 = (object)SEQ_PTR(_41memseq_16306);
    peek_addr = (uint8_t *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    pokeptr_addr = (uintptr_t *)NewS1(_2);
    _put4_1__tmp_at111_18292 = MAKE_SEQ(pokeptr_addr);
    pokeptr_addr = (uintptr_t *)((s1_ptr)pokeptr_addr)->base;
    while (--_2 >= 0) {
        pokeptr_addr++;
        *pokeptr_addr = (object)*peek_addr++;
    }
    EPuts(_41current_db_16040, _put4_1__tmp_at111_18292); // DJP 

    /** eds.e:444	end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_18292);
    _put4_1__tmp_at111_18292 = NOVALUE;

    /** eds.e:2777			seek(current_db, data_ptr)*/
    Ref(_data_ptr_18271);
    _10203 = _18seek(_41current_db_16040, _data_ptr_18271);
    DeRef(_10203);
    _10203 = NOVALUE;

    /** eds.e:2781			data_string &= repeat( 0, 8 )*/
    _10175 = Repeat(0LL, 8LL);
    Concat((object_ptr)&_data_string_18272, _data_string_18272, _10175);
    DeRefDS(_10175);
    _10175 = NOVALUE;
L2: 

    /** eds.e:2784		putn(data_string)*/

    /** eds.e:448		puts(current_db, s)*/
    EPuts(_41current_db_16040, _data_string_18272); // DJP 

    /** eds.e:449	end procedure*/
    goto L4; // [179] 182
L4: 

    /** eds.e:2785	end procedure*/
    DeRef(_old_size_18269);
    DeRef(_data_ptr_18271);
    DeRef(_data_string_18272);
    DeRef(_10169);
    _10169 = NOVALUE;
    return;
    ;
}



// 0x3820FD8A
