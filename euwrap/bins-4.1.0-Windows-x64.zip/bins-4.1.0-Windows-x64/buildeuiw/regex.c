// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _51regex(object _o_22500)
{
    object _12714 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:609		return sequence(o)*/
    _12714 = IS_SEQUENCE(_o_22500);
    DeRef(_o_22500);
    return _12714;
    ;
}


object _51new(object _pattern_22541, object _options_22542)
{
    object _12735 = NOVALUE;
    object _12734 = NOVALUE;
    object _12732 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:723		if sequence(options) then */
    _12732 = 0;
    if (_12732 == 0)
    {
        _12732 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12732 = NOVALUE;
    }

    /** regex.e:724			options = math:or_all(options) */
    _options_22542 = _21or_all(_options_22542);
L1: 

    /** regex.e:730		return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_22542);
    Ref(_pattern_22541);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _pattern_22541;
    ((intptr_t *)_2)[2] = _options_22542;
    _12734 = MAKE_SEQ(_1);
    _12735 = machine(68LL, _12734);
    DeRefDS(_12734);
    _12734 = NOVALUE;
    DeRef(_pattern_22541);
    DeRef(_options_22542);
    return _12735;
    ;
}


object _51get_ovector_size(object _ex_22561, object _maxsize_22562)
{
    object _m_22563 = NOVALUE;
    object _12743 = NOVALUE;
    object _12740 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:804		integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22561);
    ((intptr_t*)_2)[1] = _ex_22561;
    _12740 = MAKE_SEQ(_1);
    _m_22563 = machine(97LL, _12740);
    DeRefDS(_12740);
    _12740 = NOVALUE;
    if (!IS_ATOM_INT(_m_22563)) {
        _1 = (object)(DBL_PTR(_m_22563)->dbl);
        DeRefDS(_m_22563);
        _m_22563 = _1;
    }

    /** regex.e:805		if (m > maxsize) then*/
    if (_m_22563 <= 30LL)
    goto L1; // [17] 28

    /** regex.e:806			return maxsize*/
    DeRef(_ex_22561);
    return 30LL;
L1: 

    /** regex.e:809		return m+1*/
    _12743 = _m_22563 + 1;
    if (_12743 > MAXINT){
        _12743 = NewDouble((eudouble)_12743);
    }
    DeRef(_ex_22561);
    return _12743;
    ;
}


object _51find(object _re_22571, object _haystack_22573, object _from_22574, object _options_22575, object _size_22576)
{
    object _12750 = NOVALUE;
    object _12749 = NOVALUE;
    object _12748 = NOVALUE;
    object _12745 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22576)) {
        _1 = (object)(DBL_PTR(_size_22576)->dbl);
        DeRefDS(_size_22576);
        _size_22576 = _1;
    }

    /** regex.e:872		if sequence(options) then */
    _12745 = 0;
    if (_12745 == 0)
    {
        _12745 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12745 = NOVALUE;
    }

    /** regex.e:873			options = math:or_all(options) */
    _options_22575 = _21or_all(0LL);
L1: 

    /** regex.e:876		if size < 0 then*/
    if (_size_22576 >= 0LL)
    goto L2; // [22] 32

    /** regex.e:877			size = 0*/
    _size_22576 = 0LL;
L2: 

    /** regex.e:880		return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22573)){
            _12748 = SEQ_PTR(_haystack_22573)->length;
    }
    else {
        _12748 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22571);
    ((intptr_t*)_2)[1] = _re_22571;
    Ref(_haystack_22573);
    ((intptr_t*)_2)[2] = _haystack_22573;
    ((intptr_t*)_2)[3] = _12748;
    Ref(_options_22575);
    ((intptr_t*)_2)[4] = _options_22575;
    ((intptr_t*)_2)[5] = _from_22574;
    ((intptr_t*)_2)[6] = _size_22576;
    _12749 = MAKE_SEQ(_1);
    _12748 = NOVALUE;
    _12750 = machine(70LL, _12749);
    DeRefDS(_12749);
    _12749 = NOVALUE;
    DeRef(_re_22571);
    DeRef(_haystack_22573);
    DeRef(_options_22575);
    return _12750;
    ;
}


object _51find_all(object _re_22588, object _haystack_22590, object _from_22591, object _options_22592, object _size_22593)
{
    object _result_22600 = NOVALUE;
    object _results_22601 = NOVALUE;
    object _pHaystack_22602 = NOVALUE;
    object _12763 = NOVALUE;
    object _12762 = NOVALUE;
    object _12760 = NOVALUE;
    object _12758 = NOVALUE;
    object _12756 = NOVALUE;
    object _12752 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_22593)) {
        _1 = (object)(DBL_PTR(_size_22593)->dbl);
        DeRefDS(_size_22593);
        _size_22593 = _1;
    }

    /** regex.e:917		if sequence(options) then */
    _12752 = IS_SEQUENCE(_options_22592);
    if (_12752 == 0)
    {
        _12752 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12752 = NOVALUE;
    }

    /** regex.e:918			options = math:or_all(options) */
    Ref(_options_22592);
    _0 = _options_22592;
    _options_22592 = _21or_all(_options_22592);
    DeRef(_0);
L1: 

    /** regex.e:921		if size < 0 then*/
    if (_size_22593 >= 0LL)
    goto L2; // [22] 32

    /** regex.e:922			size = 0*/
    _size_22593 = 0LL;
L2: 

    /** regex.e:925		object result*/

    /** regex.e:926		sequence results = {}*/
    RefDS(_5);
    DeRef(_results_22601);
    _results_22601 = _5;

    /** regex.e:927		atom pHaystack = machine:allocate_string(haystack)*/
    Ref(_haystack_22590);
    _0 = _pHaystack_22602;
    _pHaystack_22602 = _6allocate_string(_haystack_22590, 0LL);
    DeRef(_0);

    /** regex.e:928		while sequence(result) with entry do*/
    goto L3; // [50] 94
L4: 
    _12756 = IS_SEQUENCE(_result_22600);
    if (_12756 == 0)
    {
        _12756 = NOVALUE;
        goto L5; // [58] 117
    }
    else{
        _12756 = NOVALUE;
    }

    /** regex.e:929			results = append(results, result)*/
    Ref(_result_22600);
    Append(&_results_22601, _results_22601, _result_22600);

    /** regex.e:930			from = math:max(result) + 1*/
    Ref(_result_22600);
    _12758 = _21max(_result_22600);
    if (IS_ATOM_INT(_12758)) {
        _from_22591 = _12758 + 1;
    }
    else
    { // coercing _from_22591 to an integer 1
        _from_22591 = 1+(object)(DBL_PTR(_12758)->dbl);
        if( !IS_ATOM_INT(_from_22591) ){
            _from_22591 = (object)DBL_PTR(_from_22591)->dbl;
        }
    }
    DeRef(_12758);
    _12758 = NOVALUE;

    /** regex.e:932			if from > length(haystack) then*/
    if (IS_SEQUENCE(_haystack_22590)){
            _12760 = SEQ_PTR(_haystack_22590)->length;
    }
    else {
        _12760 = 1;
    }
    if (_from_22591 <= _12760)
    goto L6; // [82] 91

    /** regex.e:933				exit*/
    goto L5; // [88] 117
L6: 

    /** regex.e:935		entry*/
L3: 

    /** regex.e:936			result = machine_func(M_PCRE_EXEC, { re, pHaystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_22590)){
            _12762 = SEQ_PTR(_haystack_22590)->length;
    }
    else {
        _12762 = 1;
    }
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_re_22588);
    ((intptr_t*)_2)[1] = _re_22588;
    Ref(_pHaystack_22602);
    ((intptr_t*)_2)[2] = _pHaystack_22602;
    ((intptr_t*)_2)[3] = _12762;
    Ref(_options_22592);
    ((intptr_t*)_2)[4] = _options_22592;
    ((intptr_t*)_2)[5] = _from_22591;
    ((intptr_t*)_2)[6] = _size_22593;
    _12763 = MAKE_SEQ(_1);
    _12762 = NOVALUE;
    DeRef(_result_22600);
    _result_22600 = machine(70LL, _12763);
    DeRefDS(_12763);
    _12763 = NOVALUE;

    /** regex.e:937		end while*/
    goto L4; // [114] 53
L5: 

    /** regex.e:939		machine:free(pHaystack)*/
    Ref(_pHaystack_22602);
    _6free(_pHaystack_22602);

    /** regex.e:941		return results*/
    DeRef(_re_22588);
    DeRef(_haystack_22590);
    DeRef(_options_22592);
    DeRef(_result_22600);
    DeRef(_pHaystack_22602);
    return _results_22601;
    ;
}


object _51has_match(object _re_22617, object _haystack_22619, object _from_22620, object _options_22621)
{
    object _12767 = NOVALUE;
    object _12766 = NOVALUE;
    object _12765 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:961		return sequence(find(re, haystack, from, options))*/
    Ref(_re_22617);
    _12765 = _51get_ovector_size(_re_22617, 30LL);
    Ref(_re_22617);
    Ref(_haystack_22619);
    _12766 = _51find(_re_22617, _haystack_22619, 1LL, 0LL, _12765);
    _12765 = NOVALUE;
    _12767 = IS_SEQUENCE(_12766);
    DeRef(_12766);
    _12766 = NOVALUE;
    DeRef(_re_22617);
    DeRef(_haystack_22619);
    return _12767;
    ;
}


object _51split(object _re_22738, object _text_22740, object _from_22741, object _options_22742)
{
    object _12830 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1198		return split_limit(re, text, 0, from, options)*/
    Ref(_re_22738);
    RefDS(_text_22740);
    _12830 = _51split_limit(_re_22738, _text_22740, 0LL, 1LL, 0LL);
    DeRef(_re_22738);
    DeRefDS(_text_22740);
    return _12830;
    ;
}


object _51split_limit(object _re_22747, object _text_22749, object _limit_22750, object _from_22751, object _options_22752)
{
    object _match_data_22756 = NOVALUE;
    object _result_22759 = NOVALUE;
    object _last_22760 = NOVALUE;
    object _a_22771 = NOVALUE;
    object _12856 = NOVALUE;
    object _12855 = NOVALUE;
    object _12854 = NOVALUE;
    object _12852 = NOVALUE;
    object _12850 = NOVALUE;
    object _12849 = NOVALUE;
    object _12848 = NOVALUE;
    object _12847 = NOVALUE;
    object _12846 = NOVALUE;
    object _12843 = NOVALUE;
    object _12842 = NOVALUE;
    object _12841 = NOVALUE;
    object _12838 = NOVALUE;
    object _12837 = NOVALUE;
    object _12835 = NOVALUE;
    object _12833 = NOVALUE;
    object _12831 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1202		if sequence(options) then */
    _12831 = 0;
    if (_12831 == 0)
    {
        _12831 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12831 = NOVALUE;
    }

    /** regex.e:1203			options = math:or_all(options) */
    _options_22752 = _21or_all(0LL);
L1: 

    /** regex.e:1205		sequence match_data = find_all(re, text, from, options), result*/
    Ref(_re_22747);
    _12833 = _51get_ovector_size(_re_22747, 30LL);
    Ref(_re_22747);
    Ref(_text_22749);
    Ref(_options_22752);
    _0 = _match_data_22756;
    _match_data_22756 = _51find_all(_re_22747, _text_22749, _from_22751, _options_22752, _12833);
    DeRef(_0);
    _12833 = NOVALUE;

    /** regex.e:1206		integer last = 1*/
    _last_22760 = 1LL;

    /** regex.e:1208		if limit = 0 or limit > length(match_data) then*/
    _12835 = (_limit_22750 == 0LL);
    if (_12835 != 0) {
        goto L2; // [48] 64
    }
    if (IS_SEQUENCE(_match_data_22756)){
            _12837 = SEQ_PTR(_match_data_22756)->length;
    }
    else {
        _12837 = 1;
    }
    _12838 = (_limit_22750 > _12837);
    _12837 = NOVALUE;
    if (_12838 == 0)
    {
        DeRef(_12838);
        _12838 = NOVALUE;
        goto L3; // [60] 70
    }
    else{
        DeRef(_12838);
        _12838 = NOVALUE;
    }
L2: 

    /** regex.e:1209			limit = length(match_data)*/
    if (IS_SEQUENCE(_match_data_22756)){
            _limit_22750 = SEQ_PTR(_match_data_22756)->length;
    }
    else {
        _limit_22750 = 1;
    }
L3: 

    /** regex.e:1212		result = repeat(0, limit)*/
    DeRef(_result_22759);
    _result_22759 = Repeat(0LL, _limit_22750);

    /** regex.e:1214		for i = 1 to limit do*/
    _12841 = _limit_22750;
    {
        object _i_22769;
        _i_22769 = 1LL;
L4: 
        if (_i_22769 > _12841){
            goto L5; // [81] 164
        }

        /** regex.e:1215			integer a*/

        /** regex.e:1216			a = match_data[i][1][1]*/
        _2 = (object)SEQ_PTR(_match_data_22756);
        _12842 = (object)*(((s1_ptr)_2)->base + _i_22769);
        _2 = (object)SEQ_PTR(_12842);
        _12843 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12842 = NOVALUE;
        _2 = (object)SEQ_PTR(_12843);
        _a_22771 = (object)*(((s1_ptr)_2)->base + 1LL);
        if (!IS_ATOM_INT(_a_22771)){
            _a_22771 = (object)DBL_PTR(_a_22771)->dbl;
        }
        _12843 = NOVALUE;

        /** regex.e:1217			if a = 0 then*/
        if (_a_22771 != 0LL)
        goto L6; // [108] 121

        /** regex.e:1218				result[i] = ""*/
        RefDS(_5);
        _2 = (object)SEQ_PTR(_result_22759);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _result_22759 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22769);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _5;
        DeRef(_1);
        goto L7; // [118] 155
L6: 

        /** regex.e:1220				result[i] = text[last..a - 1]*/
        _12846 = _a_22771 - 1LL;
        rhs_slice_target = (object_ptr)&_12847;
        RHS_Slice(_text_22749, _last_22760, _12846);
        _2 = (object)SEQ_PTR(_result_22759);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _result_22759 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _i_22769);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _12847;
        if( _1 != _12847 ){
            DeRef(_1);
        }
        _12847 = NOVALUE;

        /** regex.e:1221				last = match_data[i][1][2] + 1*/
        _2 = (object)SEQ_PTR(_match_data_22756);
        _12848 = (object)*(((s1_ptr)_2)->base + _i_22769);
        _2 = (object)SEQ_PTR(_12848);
        _12849 = (object)*(((s1_ptr)_2)->base + 1LL);
        _12848 = NOVALUE;
        _2 = (object)SEQ_PTR(_12849);
        _12850 = (object)*(((s1_ptr)_2)->base + 2LL);
        _12849 = NOVALUE;
        if (IS_ATOM_INT(_12850)) {
            _last_22760 = _12850 + 1;
        }
        else
        { // coercing _last_22760 to an integer 1
            _last_22760 = 1+(object)(DBL_PTR(_12850)->dbl);
            if( !IS_ATOM_INT(_last_22760) ){
                _last_22760 = (object)DBL_PTR(_last_22760)->dbl;
            }
        }
        _12850 = NOVALUE;
L7: 

        /** regex.e:1223		end for*/
        _i_22769 = _i_22769 + 1LL;
        goto L4; // [159] 88
L5: 
        ;
    }

    /** regex.e:1225		if last < length(text) then*/
    if (IS_SEQUENCE(_text_22749)){
            _12852 = SEQ_PTR(_text_22749)->length;
    }
    else {
        _12852 = 1;
    }
    if (_last_22760 >= _12852)
    goto L8; // [169] 192

    /** regex.e:1226			result &= { text[last..$] }*/
    if (IS_SEQUENCE(_text_22749)){
            _12854 = SEQ_PTR(_text_22749)->length;
    }
    else {
        _12854 = 1;
    }
    rhs_slice_target = (object_ptr)&_12855;
    RHS_Slice(_text_22749, _last_22760, _12854);
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _12855;
    _12856 = MAKE_SEQ(_1);
    _12855 = NOVALUE;
    Concat((object_ptr)&_result_22759, _result_22759, _12856);
    DeRefDS(_12856);
    _12856 = NOVALUE;
L8: 

    /** regex.e:1229		return result*/
    DeRef(_re_22747);
    DeRef(_text_22749);
    DeRef(_options_22752);
    DeRef(_match_data_22756);
    DeRef(_12846);
    _12846 = NOVALUE;
    DeRef(_12835);
    _12835 = NOVALUE;
    return _result_22759;
    ;
}


object _51find_replace(object _ex_22793, object _text_22795, object _replacement_22796, object _from_22797, object _options_22798)
{
    object _12858 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1280		return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_ex_22793);
    RefDS(_text_22795);
    RefDS(_replacement_22796);
    _12858 = _51find_replace_limit(_ex_22793, _text_22795, _replacement_22796, -1LL, 1LL, 0LL);
    DeRef(_ex_22793);
    DeRefDS(_text_22795);
    DeRefDS(_replacement_22796);
    return _12858;
    ;
}


object _51find_replace_limit(object _ex_22803, object _text_22805, object _replacement_22806, object _limit_22807, object _from_22808, object _options_22809)
{
    object _12862 = NOVALUE;
    object _12861 = NOVALUE;
    object _12859 = NOVALUE;
    object _0, _1, _2;
    

    /** regex.e:1312		if sequence(options) then */
    _12859 = 0;
    if (_12859 == 0)
    {
        _12859 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _12859 = NOVALUE;
    }

    /** regex.e:1313			options = math:or_all(options) */
    _options_22809 = _21or_all(0LL);
L1: 

    /** regex.e:1316	    return machine_func(M_PCRE_REPLACE, { ex, text, replacement, options, */
    _1 = NewS1(6);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_ex_22803);
    ((intptr_t*)_2)[1] = _ex_22803;
    Ref(_text_22805);
    ((intptr_t*)_2)[2] = _text_22805;
    RefDS(_replacement_22806);
    ((intptr_t*)_2)[3] = _replacement_22806;
    Ref(_options_22809);
    ((intptr_t*)_2)[4] = _options_22809;
    ((intptr_t*)_2)[5] = _from_22808;
    ((intptr_t*)_2)[6] = _limit_22807;
    _12861 = MAKE_SEQ(_1);
    _12862 = machine(71LL, _12861);
    DeRefDS(_12861);
    _12861 = NOVALUE;
    DeRef(_ex_22803);
    DeRef(_text_22805);
    DeRefDS(_replacement_22806);
    DeRef(_options_22809);
    return _12862;
    ;
}



// 0xFBA31BFC
