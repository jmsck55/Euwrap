// Euphoria To C version 4.1.0 development (6300:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

void _27set_target_integer_size(object _sizeof_pointer_20407)
{
    object _11505 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:297		if sizeof_pointer = 4 then*/

    /** global.e:300			TMAXINT = max_int64*/
    Ref(_27max_int64_20390);
    DeRef(_27TMAXINT_20401);
    _27TMAXINT_20401 = _27max_int64_20390;

    /** global.e:303		TMININT = -TMAXINT - 1*/
    if (IS_ATOM_INT(_27TMAXINT_20401)) {
        if ((uintptr_t)_27TMAXINT_20401 == (uintptr_t)HIGH_BITS){
            _11505 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _11505 = - _27TMAXINT_20401;
        }
    }
    else {
        _11505 = unary_op(UMINUS, _27TMAXINT_20401);
    }
    DeRef(_27TMININT_20402);
    if (IS_ATOM_INT(_11505)) {
        _27TMININT_20402 = _11505 - 1LL;
        if ((object)((uintptr_t)_27TMININT_20402 +(uintptr_t) HIGH_BITS) >= 0){
            _27TMININT_20402 = NewDouble((eudouble)_27TMININT_20402);
        }
    }
    else {
        _27TMININT_20402 = NewDouble(DBL_PTR(_11505)->dbl - (eudouble)1LL);
    }
    DeRef(_11505);
    _11505 = NOVALUE;

    /** global.e:304		TMAXINT_DBL = TMAXINT*/
    Ref(_27TMAXINT_20401);
    DeRef(_27TMAXINT_DBL_20404);
    _27TMAXINT_DBL_20404 = _27TMAXINT_20401;

    /** global.e:305		TMININT_DBL = TMININT*/
    Ref(_27TMININT_20402);
    DeRef(_27TMININT_DBL_20403);
    _27TMININT_DBL_20403 = _27TMININT_20402;

    /** global.e:306	end procedure*/
    return;
    ;
}


object _27is_integer(object _o_20415)
{
    object _11513 = NOVALUE;
    object _11512 = NOVALUE;
    object _11511 = NOVALUE;
    object _11509 = NOVALUE;
    object _11507 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:310		if not atom( o ) then*/
    _11507 = IS_ATOM(_o_20415);
    if (_11507 != 0)
    goto L1; // [6] 16
    _11507 = NOVALUE;

    /** global.e:311			return 0*/
    DeRef(_o_20415);
    return 0LL;
L1: 

    /** global.e:314		if o = floor( o ) then*/
    if (IS_ATOM_INT(_o_20415))
    _11509 = e_floor(_o_20415);
    else
    _11509 = unary_op(FLOOR, _o_20415);
    if (binary_op_a(NOTEQ, _o_20415, _11509)){
        DeRef(_11509);
        _11509 = NOVALUE;
        goto L2; // [21] 55
    }
    DeRef(_11509);
    _11509 = NOVALUE;

    /** global.e:315			if o <= TMAXINT and o >= TMININT then*/
    if (IS_ATOM_INT(_o_20415) && IS_ATOM_INT(_27TMAXINT_20401)) {
        _11511 = (_o_20415 <= _27TMAXINT_20401);
    }
    else {
        _11511 = binary_op(LESSEQ, _o_20415, _27TMAXINT_20401);
    }
    if (IS_ATOM_INT(_11511)) {
        if (_11511 == 0) {
            goto L3; // [33] 54
        }
    }
    else {
        if (DBL_PTR(_11511)->dbl == 0.0) {
            goto L3; // [33] 54
        }
    }
    if (IS_ATOM_INT(_o_20415) && IS_ATOM_INT(_27TMININT_20402)) {
        _11513 = (_o_20415 >= _27TMININT_20402);
    }
    else {
        _11513 = binary_op(GREATEREQ, _o_20415, _27TMININT_20402);
    }
    if (_11513 == 0) {
        DeRef(_11513);
        _11513 = NOVALUE;
        goto L3; // [44] 54
    }
    else {
        if (!IS_ATOM_INT(_11513) && DBL_PTR(_11513)->dbl == 0.0){
            DeRef(_11513);
            _11513 = NOVALUE;
            goto L3; // [44] 54
        }
        DeRef(_11513);
        _11513 = NOVALUE;
    }
    DeRef(_11513);
    _11513 = NOVALUE;

    /** global.e:316				return 1*/
    DeRef(_o_20415);
    DeRef(_11511);
    _11511 = NOVALUE;
    return 1LL;
L3: 
L2: 

    /** global.e:319		return 0*/
    DeRef(_o_20415);
    DeRef(_11511);
    _11511 = NOVALUE;
    return 0LL;
    ;
}


object _27symtab_index(object _x_20439)
{
    object _11529 = NOVALUE;
    object _11528 = NOVALUE;
    object _11527 = NOVALUE;
    object _11526 = NOVALUE;
    object _11525 = NOVALUE;
    object _11524 = NOVALUE;
    object _11522 = NOVALUE;
    object _0, _1, _2;
    

    /** global.e:337		if x = 0 then*/
    if (_x_20439 != 0LL)
    goto L1; // [5] 18

    /** global.e:338			return TRUE -- NULL value*/
    return _9TRUE_441;
L1: 

    /** global.e:340		if x < 0 or x > length(SymTab) then*/
    _11522 = (_x_20439 < 0LL);
    if (_11522 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_28SymTab_11572)){
            _11524 = SEQ_PTR(_28SymTab_11572)->length;
    }
    else {
        _11524 = 1;
    }
    _11525 = (_x_20439 > _11524);
    _11524 = NOVALUE;
    if (_11525 == 0)
    {
        DeRef(_11525);
        _11525 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_11525);
        _11525 = NOVALUE;
    }
L2: 

    /** global.e:341			return FALSE*/
    DeRef(_11522);
    _11522 = NOVALUE;
    return _9FALSE_439;
L3: 

    /** global.e:343		return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (object)SEQ_PTR(_28SymTab_11572);
    _11526 = (object)*(((s1_ptr)_2)->base + _x_20439);
    if (IS_SEQUENCE(_11526)){
            _11527 = SEQ_PTR(_11526)->length;
    }
    else {
        _11527 = 1;
    }
    _11526 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _27SIZEOF_VAR_ENTRY_20338;
    ((intptr_t*)_2)[2] = _27SIZEOF_ROUTINE_ENTRY_20335;
    ((intptr_t*)_2)[3] = _27SIZEOF_TEMP_ENTRY_20344;
    ((intptr_t*)_2)[4] = _27SIZEOF_BLOCK_ENTRY_20341;
    _11528 = MAKE_SEQ(_1);
    _11529 = find_from(_11527, _11528, 1LL);
    _11527 = NOVALUE;
    DeRefDS(_11528);
    _11528 = NOVALUE;
    DeRef(_11522);
    _11522 = NOVALUE;
    _11526 = NOVALUE;
    return _11529;
    ;
}



// 0x19C856FE
